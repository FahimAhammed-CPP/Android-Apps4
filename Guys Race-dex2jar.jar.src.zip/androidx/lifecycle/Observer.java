package androidx.lifecycle;

public interface Observer<T> {
  void onChanged(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\lifecycle\Observer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */