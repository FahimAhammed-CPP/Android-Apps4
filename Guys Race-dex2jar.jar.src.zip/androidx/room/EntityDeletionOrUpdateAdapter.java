package androidx.room;

import androidx.sqlite.db.SupportSQLiteStatement;
import java.util.Iterator;

public abstract class EntityDeletionOrUpdateAdapter<T> extends SharedSQLiteStatement {
  public EntityDeletionOrUpdateAdapter(RoomDatabase paramRoomDatabase) {
    super(paramRoomDatabase);
  }
  
  protected abstract void bind(SupportSQLiteStatement paramSupportSQLiteStatement, T paramT);
  
  protected abstract String createQuery();
  
  public final int handle(T paramT) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      bind(supportSQLiteStatement, paramT);
      return supportSQLiteStatement.executeUpdateDelete();
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final int handleMultiple(Iterable<? extends T> paramIterable) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    int i = 0;
    try {
      Iterator<? extends T> iterator = paramIterable.iterator();
      while (iterator.hasNext()) {
        bind(supportSQLiteStatement, iterator.next());
        int j = supportSQLiteStatement.executeUpdateDelete();
        i += j;
      } 
      return i;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final int handleMultiple(T[] paramArrayOfT) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      int k = paramArrayOfT.length;
      int i = 0;
      int j = 0;
      while (i < k) {
        bind(supportSQLiteStatement, paramArrayOfT[i]);
        int m = supportSQLiteStatement.executeUpdateDelete();
        j += m;
        i++;
      } 
      return j;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\room\EntityDeletionOrUpdateAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */