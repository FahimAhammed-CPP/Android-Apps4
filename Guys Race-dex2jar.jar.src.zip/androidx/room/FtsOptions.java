package androidx.room;

public class FtsOptions {
  public static final String TOKENIZER_ICU = "icu";
  
  public static final String TOKENIZER_PORTER = "porter";
  
  public static final String TOKENIZER_SIMPLE = "simple";
  
  public static final String TOKENIZER_UNICODE61 = "unicode61";
  
  public enum MatchInfo {
    FTS3, FTS4;
    
    static {
      MatchInfo matchInfo = new MatchInfo("FTS4", 1);
      FTS4 = matchInfo;
      $VALUES = new MatchInfo[] { FTS3, matchInfo };
    }
  }
  
  public enum Order {
    ASC, DESC;
    
    static {
      Order order = new Order("DESC", 1);
      DESC = order;
      $VALUES = new Order[] { ASC, order };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\room\FtsOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */