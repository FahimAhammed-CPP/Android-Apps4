package androidx.room;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IMultiInstanceInvalidationCallback extends IInterface {
  void onInvalidation(String[] paramArrayOfString) throws RemoteException;
  
  public static abstract class Stub extends Binder implements IMultiInstanceInvalidationCallback {
    private static final String DESCRIPTOR = "androidx.room.IMultiInstanceInvalidationCallback";
    
    static final int TRANSACTION_onInvalidation = 1;
    
    public Stub() {
      attachInterface(this, "androidx.room.IMultiInstanceInvalidationCallback");
    }
    
    public static IMultiInstanceInvalidationCallback asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationCallback");
      return (iInterface != null && iInterface instanceof IMultiInstanceInvalidationCallback) ? (IMultiInstanceInvalidationCallback)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 != 1) {
        if (param1Int1 != 1598968902)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        param1Parcel2.writeString("androidx.room.IMultiInstanceInvalidationCallback");
        return true;
      } 
      param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationCallback");
      onInvalidation(param1Parcel1.createStringArray());
      return true;
    }
    
    private static class Proxy implements IMultiInstanceInvalidationCallback {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor() {
        return "androidx.room.IMultiInstanceInvalidationCallback";
      }
      
      public void onInvalidation(String[] param2ArrayOfString) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
          parcel.writeStringArray(param2ArrayOfString);
          this.mRemote.transact(1, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IMultiInstanceInvalidationCallback {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public String getInterfaceDescriptor() {
      return "androidx.room.IMultiInstanceInvalidationCallback";
    }
    
    public void onInvalidation(String[] param1ArrayOfString) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
        parcel.writeStringArray(param1ArrayOfString);
        this.mRemote.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\room\IMultiInstanceInvalidationCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */