package androidx.room;

import android.database.Cursor;
import androidx.sqlite.db.SimpleSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import androidx.sqlite.db.SupportSQLiteQuery;

public class RoomOpenHelper extends SupportSQLiteOpenHelper.Callback {
  private DatabaseConfiguration mConfiguration;
  
  private final Delegate mDelegate;
  
  private final String mIdentityHash;
  
  private final String mLegacyHash;
  
  public RoomOpenHelper(DatabaseConfiguration paramDatabaseConfiguration, Delegate paramDelegate, String paramString) {
    this(paramDatabaseConfiguration, paramDelegate, "", paramString);
  }
  
  public RoomOpenHelper(DatabaseConfiguration paramDatabaseConfiguration, Delegate paramDelegate, String paramString1, String paramString2) {
    super(paramDelegate.version);
    this.mConfiguration = paramDatabaseConfiguration;
    this.mDelegate = paramDelegate;
    this.mIdentityHash = paramString1;
    this.mLegacyHash = paramString2;
  }
  
  private void checkIdentity(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    if (hasRoomMasterTable(paramSupportSQLiteDatabase)) {
      SupportSQLiteDatabase supportSQLiteDatabase = null;
      Cursor cursor = paramSupportSQLiteDatabase.query((SupportSQLiteQuery)new SimpleSQLiteQuery("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"));
      paramSupportSQLiteDatabase = supportSQLiteDatabase;
      try {
        String str;
        if (cursor.moveToFirst())
          str = cursor.getString(0); 
        cursor.close();
      } finally {
        cursor.close();
      } 
    } else {
      ValidationResult validationResult = this.mDelegate.onValidateSchema(paramSupportSQLiteDatabase);
      if (validationResult.isValid) {
        this.mDelegate.onPostMigrate(paramSupportSQLiteDatabase);
        updateIdentity(paramSupportSQLiteDatabase);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Pre-packaged database has an invalid schema: ");
      stringBuilder.append(validationResult.expectedFoundMsg);
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  private void createMasterTableIfNotExists(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    paramSupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
  }
  
  private static boolean hasEmptySchema(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    Cursor cursor = paramSupportSQLiteDatabase.query("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");
    try {
      boolean bool = cursor.moveToFirst();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        int i = cursor.getInt(0);
        bool1 = bool2;
        if (i == 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
    } 
  }
  
  private static boolean hasRoomMasterTable(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    Cursor cursor = paramSupportSQLiteDatabase.query("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");
    try {
      boolean bool = cursor.moveToFirst();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        int i = cursor.getInt(0);
        bool1 = bool2;
        if (i != 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
    } 
  }
  
  private void updateIdentity(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    createMasterTableIfNotExists(paramSupportSQLiteDatabase);
    paramSupportSQLiteDatabase.execSQL(RoomMasterTable.createInsertQuery(this.mIdentityHash));
  }
  
  public void onConfigure(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    super.onConfigure(paramSupportSQLiteDatabase);
  }
  
  public void onCreate(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    StringBuilder stringBuilder;
    boolean bool = hasEmptySchema(paramSupportSQLiteDatabase);
    this.mDelegate.createAllTables(paramSupportSQLiteDatabase);
    if (!bool) {
      ValidationResult validationResult = this.mDelegate.onValidateSchema(paramSupportSQLiteDatabase);
      if (!validationResult.isValid) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Pre-packaged database has an invalid schema: ");
        stringBuilder.append(validationResult.expectedFoundMsg);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
    updateIdentity((SupportSQLiteDatabase)stringBuilder);
    this.mDelegate.onCreate((SupportSQLiteDatabase)stringBuilder);
  }
  
  public void onDowngrade(SupportSQLiteDatabase paramSupportSQLiteDatabase, int paramInt1, int paramInt2) {
    onUpgrade(paramSupportSQLiteDatabase, paramInt1, paramInt2);
  }
  
  public void onOpen(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    super.onOpen(paramSupportSQLiteDatabase);
    checkIdentity(paramSupportSQLiteDatabase);
    this.mDelegate.onOpen(paramSupportSQLiteDatabase);
    this.mConfiguration = null;
  }
  
  public void onUpgrade(SupportSQLiteDatabase paramSupportSQLiteDatabase, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mConfiguration : Landroidx/room/DatabaseConfiguration;
    //   4: astore #5
    //   6: aload #5
    //   8: ifnull -> 146
    //   11: aload #5
    //   13: getfield migrationContainer : Landroidx/room/RoomDatabase$MigrationContainer;
    //   16: iload_2
    //   17: iload_3
    //   18: invokevirtual findMigrationPath : (II)Ljava/util/List;
    //   21: astore #5
    //   23: aload #5
    //   25: ifnull -> 146
    //   28: aload_0
    //   29: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   32: aload_1
    //   33: invokevirtual onPreMigrate : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   36: aload #5
    //   38: invokeinterface iterator : ()Ljava/util/Iterator;
    //   43: astore #5
    //   45: aload #5
    //   47: invokeinterface hasNext : ()Z
    //   52: ifeq -> 72
    //   55: aload #5
    //   57: invokeinterface next : ()Ljava/lang/Object;
    //   62: checkcast androidx/room/migration/Migration
    //   65: aload_1
    //   66: invokevirtual migrate : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   69: goto -> 45
    //   72: aload_0
    //   73: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   76: aload_1
    //   77: invokevirtual onValidateSchema : (Landroidx/sqlite/db/SupportSQLiteDatabase;)Landroidx/room/RoomOpenHelper$ValidationResult;
    //   80: astore #5
    //   82: aload #5
    //   84: getfield isValid : Z
    //   87: ifeq -> 109
    //   90: aload_0
    //   91: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   94: aload_1
    //   95: invokevirtual onPostMigrate : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   98: aload_0
    //   99: aload_1
    //   100: invokespecial updateIdentity : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   103: iconst_1
    //   104: istore #4
    //   106: goto -> 149
    //   109: new java/lang/StringBuilder
    //   112: dup
    //   113: invokespecial <init> : ()V
    //   116: astore_1
    //   117: aload_1
    //   118: ldc 'Migration didn't properly handle: '
    //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: pop
    //   124: aload_1
    //   125: aload #5
    //   127: getfield expectedFoundMsg : Ljava/lang/String;
    //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: pop
    //   134: new java/lang/IllegalStateException
    //   137: dup
    //   138: aload_1
    //   139: invokevirtual toString : ()Ljava/lang/String;
    //   142: invokespecial <init> : (Ljava/lang/String;)V
    //   145: athrow
    //   146: iconst_0
    //   147: istore #4
    //   149: iload #4
    //   151: ifne -> 245
    //   154: aload_0
    //   155: getfield mConfiguration : Landroidx/room/DatabaseConfiguration;
    //   158: astore #5
    //   160: aload #5
    //   162: ifnull -> 192
    //   165: aload #5
    //   167: iload_2
    //   168: iload_3
    //   169: invokevirtual isMigrationRequired : (II)Z
    //   172: ifne -> 192
    //   175: aload_0
    //   176: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   179: aload_1
    //   180: invokevirtual dropAllTables : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   183: aload_0
    //   184: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   187: aload_1
    //   188: invokevirtual createAllTables : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   191: return
    //   192: new java/lang/StringBuilder
    //   195: dup
    //   196: invokespecial <init> : ()V
    //   199: astore_1
    //   200: aload_1
    //   201: ldc 'A migration from '
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: pop
    //   207: aload_1
    //   208: iload_2
    //   209: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   212: pop
    //   213: aload_1
    //   214: ldc ' to '
    //   216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: pop
    //   220: aload_1
    //   221: iload_3
    //   222: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: aload_1
    //   227: ldc ' was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.'
    //   229: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: new java/lang/IllegalStateException
    //   236: dup
    //   237: aload_1
    //   238: invokevirtual toString : ()Ljava/lang/String;
    //   241: invokespecial <init> : (Ljava/lang/String;)V
    //   244: athrow
    //   245: return
  }
  
  public static abstract class Delegate {
    public final int version;
    
    public Delegate(int param1Int) {
      this.version = param1Int;
    }
    
    protected abstract void createAllTables(SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    protected abstract void dropAllTables(SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    protected abstract void onCreate(SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    protected abstract void onOpen(SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    protected void onPostMigrate(SupportSQLiteDatabase param1SupportSQLiteDatabase) {}
    
    protected void onPreMigrate(SupportSQLiteDatabase param1SupportSQLiteDatabase) {}
    
    protected RoomOpenHelper.ValidationResult onValidateSchema(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      validateMigration(param1SupportSQLiteDatabase);
      return new RoomOpenHelper.ValidationResult(true, null);
    }
    
    @Deprecated
    protected void validateMigration(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      throw new UnsupportedOperationException("validateMigration is deprecated");
    }
  }
  
  public static class ValidationResult {
    public final String expectedFoundMsg;
    
    public final boolean isValid;
    
    public ValidationResult(boolean param1Boolean, String param1String) {
      this.isValid = param1Boolean;
      this.expectedFoundMsg = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\room\RoomOpenHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */