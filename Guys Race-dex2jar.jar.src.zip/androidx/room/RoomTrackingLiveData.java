package androidx.room;

import androidx.arch.core.executor.ArchTaskExecutor;
import androidx.lifecycle.LiveData;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

class RoomTrackingLiveData<T> extends LiveData<T> {
  final Callable<T> mComputeFunction;
  
  final AtomicBoolean mComputing = new AtomicBoolean(false);
  
  private final InvalidationLiveDataContainer mContainer;
  
  final RoomDatabase mDatabase;
  
  final boolean mInTransaction;
  
  final AtomicBoolean mInvalid = new AtomicBoolean(true);
  
  final Runnable mInvalidationRunnable = new Runnable() {
      public void run() {
        boolean bool = RoomTrackingLiveData.this.hasActiveObservers();
        if (RoomTrackingLiveData.this.mInvalid.compareAndSet(false, true) && bool)
          RoomTrackingLiveData.this.getQueryExecutor().execute(RoomTrackingLiveData.this.mRefreshRunnable); 
      }
    };
  
  final InvalidationTracker.Observer mObserver;
  
  final Runnable mRefreshRunnable = new Runnable() {
      public void run() {
        if (RoomTrackingLiveData.this.mRegisteredObserver.compareAndSet(false, true))
          RoomTrackingLiveData.this.mDatabase.getInvalidationTracker().addWeakObserver(RoomTrackingLiveData.this.mObserver); 
        while (true) {
          if (RoomTrackingLiveData.this.mComputing.compareAndSet(false, true)) {
            null = null;
            boolean bool1 = false;
            try {
              while (true) {
                boolean bool2 = RoomTrackingLiveData.this.mInvalid.compareAndSet(true, false);
                if (bool2) {
                  try {
                    null = (Exception)RoomTrackingLiveData.this.mComputeFunction.call();
                    bool1 = true;
                  } catch (Exception exception) {
                    throw new RuntimeException("Exception while computing database live data.", exception);
                  } 
                  continue;
                } 
                if (bool1)
                  RoomTrackingLiveData.this.postValue(exception); 
                RoomTrackingLiveData.this.mComputing.set(false);
                if (!bool1 || !RoomTrackingLiveData.this.mInvalid.get())
                  break; 
              } 
            } finally {
              RoomTrackingLiveData.this.mComputing.set(false);
            } 
            break;
          } 
          boolean bool = false;
          continue;
        } 
      }
    };
  
  final AtomicBoolean mRegisteredObserver = new AtomicBoolean(false);
  
  RoomTrackingLiveData(RoomDatabase paramRoomDatabase, InvalidationLiveDataContainer paramInvalidationLiveDataContainer, boolean paramBoolean, Callable<T> paramCallable, String[] paramArrayOfString) {
    this.mDatabase = paramRoomDatabase;
    this.mInTransaction = paramBoolean;
    this.mComputeFunction = paramCallable;
    this.mContainer = paramInvalidationLiveDataContainer;
    this.mObserver = new InvalidationTracker.Observer(paramArrayOfString) {
        public void onInvalidated(Set<String> param1Set) {
          ArchTaskExecutor.getInstance().executeOnMainThread(RoomTrackingLiveData.this.mInvalidationRunnable);
        }
      };
  }
  
  Executor getQueryExecutor() {
    return this.mInTransaction ? this.mDatabase.getTransactionExecutor() : this.mDatabase.getQueryExecutor();
  }
  
  protected void onActive() {
    super.onActive();
    this.mContainer.onActive(this);
    getQueryExecutor().execute(this.mRefreshRunnable);
  }
  
  protected void onInactive() {
    super.onInactive();
    this.mContainer.onInactive(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\room\RoomTrackingLiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */