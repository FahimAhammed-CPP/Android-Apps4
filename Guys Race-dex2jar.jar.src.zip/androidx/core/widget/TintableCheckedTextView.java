package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public interface TintableCheckedTextView {
  ColorStateList getSupportCheckMarkTintList();
  
  PorterDuff.Mode getSupportCheckMarkTintMode();
  
  void setSupportCheckMarkTintList(ColorStateList paramColorStateList);
  
  void setSupportCheckMarkTintMode(PorterDuff.Mode paramMode);
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\core\widget\TintableCheckedTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */