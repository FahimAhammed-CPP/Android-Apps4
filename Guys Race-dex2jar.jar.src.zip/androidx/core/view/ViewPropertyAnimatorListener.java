package androidx.core.view;

import android.view.View;

public interface ViewPropertyAnimatorListener {
  void onAnimationCancel(View paramView);
  
  void onAnimationEnd(View paramView);
  
  void onAnimationStart(View paramView);
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\core\view\ViewPropertyAnimatorListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */