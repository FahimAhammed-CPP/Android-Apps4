package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import java.util.Objects;

public final class wqn<T> implements X9K8CXVSxZWf<T> {
  private final T psJpCSi8_h7NzZZ1vbR;
  
  private wqn(T paramT) {
    this.psJpCSi8_h7NzZZ1vbR = paramT;
  }
  
  public static <T> X9K8CXVSxZWf<T> psJpCSi8_h7NzZZ1vbR(T paramT) {
    Objects.requireNonNull(paramT);
    return new wqn<T>(paramT);
  }
  
  public T psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\wqn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */