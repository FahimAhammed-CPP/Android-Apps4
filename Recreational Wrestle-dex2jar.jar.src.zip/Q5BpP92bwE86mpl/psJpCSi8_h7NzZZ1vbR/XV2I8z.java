package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import javax.inject.Provider;

public final class XV2I8z<T> implements X9K8CXVSxZWf<T> {
  private Provider<T> psJpCSi8_h7NzZZ1vbR;
  
  public T psJpCSi8_h7NzZZ1vbR() {
    Provider<T> provider = this.psJpCSi8_h7NzZZ1vbR;
    if (provider != null)
      return (T)provider.get(); 
    throw new IllegalStateException();
  }
  
  public void psJpCSi8_h7NzZZ1vbR(Provider<T> paramProvider) {
    if (paramProvider != null) {
      if (this.psJpCSi8_h7NzZZ1vbR == null) {
        this.psJpCSi8_h7NzZZ1vbR = paramProvider;
        return;
      } 
      throw new IllegalStateException();
    } 
    throw new IllegalArgumentException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */