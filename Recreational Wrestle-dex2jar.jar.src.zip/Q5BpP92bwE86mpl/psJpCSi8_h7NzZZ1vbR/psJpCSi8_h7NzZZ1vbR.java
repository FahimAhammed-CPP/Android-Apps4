package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Documented
@Retention(RetentionPolicy.SOURCE)
public @interface psJpCSi8_h7NzZZ1vbR {}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */