package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import javax.inject.Provider;

public final class BIRpv<K, V> implements X9K8CXVSxZWf<Map<K, Provider<V>>> {
  private static final BIRpv<Object, Object> psJpCSi8_h7NzZZ1vbR = new BIRpv(Collections.emptyMap());
  
  private final Map<K, Provider<V>> Q_;
  
  private BIRpv(Map<K, Provider<V>> paramMap) {
    this.Q_ = Collections.unmodifiableMap(paramMap);
  }
  
  public static <K, V> psJpCSi8_h7NzZZ1vbR<K, V> psJpCSi8_h7NzZZ1vbR(int paramInt) {
    return new psJpCSi8_h7NzZZ1vbR<K, V>(paramInt);
  }
  
  public static <K, V> BIRpv<K, V> psJpCSi8_h7NzZZ1vbR() {
    return (BIRpv)psJpCSi8_h7NzZZ1vbR;
  }
  
  public Map<K, Provider<V>> Q_() {
    return this.Q_;
  }
  
  public static final class psJpCSi8_h7NzZZ1vbR<K, V> {
    private final LinkedHashMap<K, Provider<V>> psJpCSi8_h7NzZZ1vbR;
    
    private psJpCSi8_h7NzZZ1vbR(int param1Int) {
      this.psJpCSi8_h7NzZZ1vbR = Q_.XV2I8z(param1Int);
    }
    
    public psJpCSi8_h7NzZZ1vbR<K, V> psJpCSi8_h7NzZZ1vbR(K param1K, Provider<V> param1Provider) {
      Objects.requireNonNull(param1K, "The key is null");
      Objects.requireNonNull(param1Provider, "The provider of the value is null");
      this.psJpCSi8_h7NzZZ1vbR.put(param1K, param1Provider);
      return this;
    }
    
    public BIRpv<K, V> psJpCSi8_h7NzZZ1vbR() {
      return new BIRpv<K, V>(this.psJpCSi8_h7NzZZ1vbR);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\BIRpv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */