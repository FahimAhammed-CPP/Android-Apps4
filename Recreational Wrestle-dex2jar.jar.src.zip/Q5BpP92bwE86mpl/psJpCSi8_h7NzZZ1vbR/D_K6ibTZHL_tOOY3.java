package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import Q5BpP92bwE86mpl.D89UfNGBvLPp16h;
import javax.inject.Provider;

public final class D_K6ibTZHL_tOOY3<T> implements D89UfNGBvLPp16h<T>, Provider<T> {
  private static final Object Q_ = new Object();
  
  private volatile Object D89UfNGBvLPp16h = Q_;
  
  private volatile Provider<T> XV2I8z;
  
  private D_K6ibTZHL_tOOY3(Provider<T> paramProvider) {
    if (psJpCSi8_h7NzZZ1vbR || paramProvider != null) {
      this.XV2I8z = paramProvider;
      return;
    } 
    throw new AssertionError();
  }
  
  public static <T> Provider<T> psJpCSi8_h7NzZZ1vbR(Provider<T> paramProvider) {
    return !(paramProvider instanceof D_K6ibTZHL_tOOY3) ? ((paramProvider instanceof D89UfNGBvLPp16h) ? paramProvider : new D_K6ibTZHL_tOOY3<T>(qY.<Provider<T>>psJpCSi8_h7NzZZ1vbR(paramProvider))) : paramProvider;
  }
  
  public T psJpCSi8_h7NzZZ1vbR() {
    Provider<T> provider = this.XV2I8z;
    if (this.D89UfNGBvLPp16h == Q_) {
      this.D89UfNGBvLPp16h = provider.get();
      this.XV2I8z = null;
    } 
    return (T)this.D89UfNGBvLPp16h;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\D_K6ibTZHL_tOOY3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */