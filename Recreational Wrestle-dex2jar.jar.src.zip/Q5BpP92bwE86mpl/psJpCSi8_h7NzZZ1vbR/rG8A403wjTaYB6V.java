package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.inject.Provider;

public final class rG8A403wjTaYB6V<T> implements X9K8CXVSxZWf<Set<T>> {
  private static final X9K8CXVSxZWf<Set<Object>> psJpCSi8_h7NzZZ1vbR = new X9K8CXVSxZWf<Set<Object>>() {
      public Set<Object> psJpCSi8_h7NzZZ1vbR() {
        return Collections.emptySet();
      }
    };
  
  private final List<Provider<T>> Q_;
  
  private final List<Provider<Collection<T>>> XV2I8z;
  
  private rG8A403wjTaYB6V(List<Provider<T>> paramList, List<Provider<Collection<T>>> paramList1) {
    this.Q_ = paramList;
    this.XV2I8z = paramList1;
  }
  
  public static <T> X9K8CXVSxZWf<Set<T>> psJpCSi8_h7NzZZ1vbR() {
    return (X9K8CXVSxZWf)psJpCSi8_h7NzZZ1vbR;
  }
  
  public static <T> psJpCSi8_h7NzZZ1vbR<T> psJpCSi8_h7NzZZ1vbR(int paramInt1, int paramInt2) {
    return new psJpCSi8_h7NzZZ1vbR<T>(paramInt1, paramInt2);
  }
  
  public Set<T> Q_() {
    int j = this.Q_.size();
    ArrayList<Collection> arrayList = new ArrayList(this.XV2I8z.size());
    int k = this.XV2I8z.size();
    boolean bool = false;
    int i;
    for (i = 0; i < k; i++) {
      Collection collection = (Collection)((Provider)this.XV2I8z.get(i)).get();
      j += collection.size();
      arrayList.add(collection);
    } 
    HashSet<?> hashSet = Q_.Q_(j);
    j = this.Q_.size();
    for (i = 0; i < j; i++)
      hashSet.add(qY.psJpCSi8_h7NzZZ1vbR(((Provider)this.Q_.get(i)).get())); 
    j = arrayList.size();
    for (i = bool; i < j; i++) {
      Iterator iterator = ((Collection)arrayList.get(i)).iterator();
      while (iterator.hasNext())
        hashSet.add(qY.psJpCSi8_h7NzZZ1vbR(iterator.next())); 
    } 
    return Collections.unmodifiableSet((Set)hashSet);
  }
  
  public static final class psJpCSi8_h7NzZZ1vbR<T> {
    private final List<Provider<T>> Q_;
    
    private final List<Provider<Collection<T>>> XV2I8z;
    
    private psJpCSi8_h7NzZZ1vbR(int param1Int1, int param1Int2) {
      this.Q_ = Q_.psJpCSi8_h7NzZZ1vbR(param1Int1);
      this.XV2I8z = Q_.psJpCSi8_h7NzZZ1vbR(param1Int2);
    }
    
    public psJpCSi8_h7NzZZ1vbR<T> Q_(Provider<? extends Collection<? extends T>> param1Provider) {
      if (psJpCSi8_h7NzZZ1vbR || param1Provider != null) {
        this.XV2I8z.add(param1Provider);
        return this;
      } 
      throw new AssertionError("Codegen error? Null provider");
    }
    
    public psJpCSi8_h7NzZZ1vbR<T> psJpCSi8_h7NzZZ1vbR(Provider<? extends T> param1Provider) {
      if (psJpCSi8_h7NzZZ1vbR || param1Provider != null) {
        this.Q_.add(param1Provider);
        return this;
      } 
      throw new AssertionError("Codegen error? Null provider");
    }
    
    public rG8A403wjTaYB6V<T> psJpCSi8_h7NzZZ1vbR() {
      boolean bool = psJpCSi8_h7NzZZ1vbR;
      if (bool || !Q_.psJpCSi8_h7NzZZ1vbR(this.Q_)) {
        if (bool || !Q_.psJpCSi8_h7NzZZ1vbR(this.XV2I8z))
          return new rG8A403wjTaYB6V<T>(this.Q_, this.XV2I8z); 
        throw new AssertionError("Codegen error?  Duplicates in the provider list");
      } 
      throw new AssertionError("Codegen error?  Duplicates in the provider list");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\rG8A403wjTaYB6V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */