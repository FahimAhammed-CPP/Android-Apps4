package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;

public final class Q_ {
  private static final int psJpCSi8_h7NzZZ1vbR = 1073741824;
  
  private static int D89UfNGBvLPp16h(int paramInt) {
    return (paramInt < 3) ? (paramInt + 1) : ((paramInt < 1073741824) ? (int)(paramInt / 0.75F + 1.0F) : Integer.MAX_VALUE);
  }
  
  static <T> HashSet<T> Q_(int paramInt) {
    return new HashSet<T>(D89UfNGBvLPp16h(paramInt));
  }
  
  static <K, V> LinkedHashMap<K, V> XV2I8z(int paramInt) {
    return new LinkedHashMap<K, V>(D89UfNGBvLPp16h(paramInt));
  }
  
  public static <T> List<T> psJpCSi8_h7NzZZ1vbR(int paramInt) {
    return (paramInt == 0) ? Collections.emptyList() : new ArrayList<T>(paramInt);
  }
  
  public static boolean psJpCSi8_h7NzZZ1vbR(List<?> paramList) {
    int i = paramList.size();
    boolean bool = false;
    if (i < 2)
      return false; 
    HashSet hashSet = new HashSet(paramList);
    if (paramList.size() != hashSet.size())
      bool = true; 
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */