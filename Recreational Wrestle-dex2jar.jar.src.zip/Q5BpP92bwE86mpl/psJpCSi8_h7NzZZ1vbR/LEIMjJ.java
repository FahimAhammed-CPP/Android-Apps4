package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import Q5BpP92bwE86mpl.MxwALnHp3MNCI;

public final class LEIMjJ {
  public static <T> MxwALnHp3MNCI<T> psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;
  }
  
  public static <T> MxwALnHp3MNCI<T> psJpCSi8_h7NzZZ1vbR(MxwALnHp3MNCI<? super T> paramMxwALnHp3MNCI) {
    return (MxwALnHp3MNCI<T>)qY.<MxwALnHp3MNCI<? super T>>psJpCSi8_h7NzZZ1vbR(paramMxwALnHp3MNCI);
  }
  
  public static <T> T psJpCSi8_h7NzZZ1vbR(MxwALnHp3MNCI<T> paramMxwALnHp3MNCI, T paramT) {
    paramMxwALnHp3MNCI.psJpCSi8_h7NzZZ1vbR(paramT);
    return paramT;
  }
  
  private enum psJpCSi8_h7NzZZ1vbR implements MxwALnHp3MNCI<Object> {
    psJpCSi8_h7NzZZ1vbR;
    
    static {
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = new psJpCSi8_h7NzZZ1vbR("INSTANCE", 0);
      psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR1;
      Q_ = new psJpCSi8_h7NzZZ1vbR[] { psJpCSi8_h7NzZZ1vbR1 };
    }
    
    public void psJpCSi8_h7NzZZ1vbR(Object param1Object) {
      qY.psJpCSi8_h7NzZZ1vbR(param1Object);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\LEIMjJ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */