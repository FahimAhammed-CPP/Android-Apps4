package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.inject.Provider;

public final class wktp1mvgWsB4SzZr<K, V> implements X9K8CXVSxZWf<Map<K, V>> {
  private final Map<K, Provider<V>> psJpCSi8_h7NzZZ1vbR;
  
  private wktp1mvgWsB4SzZr(Map<K, Provider<V>> paramMap) {
    this.psJpCSi8_h7NzZZ1vbR = Collections.unmodifiableMap(paramMap);
  }
  
  public static <K, V> wktp1mvgWsB4SzZr<K, V> psJpCSi8_h7NzZZ1vbR(Provider<Map<K, Provider<V>>> paramProvider) {
    return new wktp1mvgWsB4SzZr<K, V>((Map<K, Provider<V>>)paramProvider.get());
  }
  
  public Map<K, V> psJpCSi8_h7NzZZ1vbR() {
    LinkedHashMap<?, ?> linkedHashMap = Q_.XV2I8z(this.psJpCSi8_h7NzZZ1vbR.size());
    for (Map.Entry<K, Provider<V>> entry : this.psJpCSi8_h7NzZZ1vbR.entrySet())
      linkedHashMap.put(entry.getKey(), ((Provider)entry.getValue()).get()); 
    return Collections.unmodifiableMap((Map)linkedHashMap);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\wktp1mvgWsB4SzZr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */