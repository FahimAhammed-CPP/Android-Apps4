package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import Q5BpP92bwE86mpl.D89UfNGBvLPp16h;
import javax.inject.Provider;

public final class hzEmy<T> implements Provider<D89UfNGBvLPp16h<T>> {
  private final Provider<T> Q_;
  
  private hzEmy(Provider<T> paramProvider) {
    if (psJpCSi8_h7NzZZ1vbR || paramProvider != null) {
      this.Q_ = paramProvider;
      return;
    } 
    throw new AssertionError();
  }
  
  public static <T> Provider<D89UfNGBvLPp16h<T>> psJpCSi8_h7NzZZ1vbR(Provider<T> paramProvider) {
    return new hzEmy<T>(qY.<Provider<T>>psJpCSi8_h7NzZZ1vbR(paramProvider));
  }
  
  public D89UfNGBvLPp16h<T> psJpCSi8_h7NzZZ1vbR() {
    return D89UfNGBvLPp16h.Q_(this.Q_);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\hzEmy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */