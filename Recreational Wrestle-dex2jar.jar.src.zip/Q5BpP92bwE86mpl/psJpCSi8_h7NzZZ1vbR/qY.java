package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import java.util.Objects;

public final class qY {
  public static <T> T psJpCSi8_h7NzZZ1vbR(T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  public static <T> T psJpCSi8_h7NzZZ1vbR(T paramT, String paramString) {
    Objects.requireNonNull(paramT, paramString);
    return paramT;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\qY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */