package Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR;

import Q5BpP92bwE86mpl.D89UfNGBvLPp16h;
import javax.inject.Provider;

public final class D89UfNGBvLPp16h<T> implements D89UfNGBvLPp16h<T>, Provider<T> {
  private static final Object Q_ = new Object();
  
  private volatile Object D89UfNGBvLPp16h = Q_;
  
  private volatile Provider<T> XV2I8z;
  
  private D89UfNGBvLPp16h(Provider<T> paramProvider) {
    if (psJpCSi8_h7NzZZ1vbR || paramProvider != null) {
      this.XV2I8z = paramProvider;
      return;
    } 
    throw new AssertionError();
  }
  
  public static <T> D89UfNGBvLPp16h<T> Q_(Provider<T> paramProvider) {
    return (paramProvider instanceof D89UfNGBvLPp16h) ? (D89UfNGBvLPp16h<T>)paramProvider : new D89UfNGBvLPp16h<T>(qY.<Provider<T>>psJpCSi8_h7NzZZ1vbR(paramProvider));
  }
  
  public static <T> Provider<T> psJpCSi8_h7NzZZ1vbR(Provider<T> paramProvider) {
    qY.psJpCSi8_h7NzZZ1vbR(paramProvider);
    return (paramProvider instanceof D89UfNGBvLPp16h) ? paramProvider : new D89UfNGBvLPp16h<T>(paramProvider);
  }
  
  public T psJpCSi8_h7NzZZ1vbR() {
    // Byte code:
    //   0: aload_0
    //   1: getfield D89UfNGBvLPp16h : Ljava/lang/Object;
    //   4: astore_1
    //   5: getstatic Q5BpP92bwE86mpl/psJpCSi8_h7NzZZ1vbR/D89UfNGBvLPp16h.Q_ : Ljava/lang/Object;
    //   8: astore_3
    //   9: aload_1
    //   10: aload_3
    //   11: if_acmpne -> 121
    //   14: aload_0
    //   15: monitorenter
    //   16: aload_0
    //   17: getfield D89UfNGBvLPp16h : Ljava/lang/Object;
    //   20: astore_2
    //   21: aload_2
    //   22: astore_1
    //   23: aload_2
    //   24: aload_3
    //   25: if_acmpne -> 112
    //   28: aload_0
    //   29: getfield XV2I8z : Ljavax/inject/Provider;
    //   32: invokeinterface get : ()Ljava/lang/Object;
    //   37: astore_1
    //   38: aload_0
    //   39: getfield D89UfNGBvLPp16h : Ljava/lang/Object;
    //   42: astore_2
    //   43: aload_2
    //   44: aload_3
    //   45: if_acmpeq -> 102
    //   48: aload_2
    //   49: aload_1
    //   50: if_acmpne -> 56
    //   53: goto -> 102
    //   56: new java/lang/StringBuilder
    //   59: dup
    //   60: invokespecial <init> : ()V
    //   63: astore_3
    //   64: aload_3
    //   65: ldc 'Scoped provider was invoked recursively returning different results: '
    //   67: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: pop
    //   71: aload_3
    //   72: aload_2
    //   73: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   76: pop
    //   77: aload_3
    //   78: ldc ' & '
    //   80: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: pop
    //   84: aload_3
    //   85: aload_1
    //   86: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   89: pop
    //   90: new java/lang/IllegalStateException
    //   93: dup
    //   94: aload_3
    //   95: invokevirtual toString : ()Ljava/lang/String;
    //   98: invokespecial <init> : (Ljava/lang/String;)V
    //   101: athrow
    //   102: aload_0
    //   103: aload_1
    //   104: putfield D89UfNGBvLPp16h : Ljava/lang/Object;
    //   107: aload_0
    //   108: aconst_null
    //   109: putfield XV2I8z : Ljavax/inject/Provider;
    //   112: aload_0
    //   113: monitorexit
    //   114: aload_1
    //   115: areturn
    //   116: astore_1
    //   117: aload_0
    //   118: monitorexit
    //   119: aload_1
    //   120: athrow
    //   121: aload_1
    //   122: areturn
    // Exception table:
    //   from	to	target	type
    //   16	21	116	finally
    //   28	43	116	finally
    //   56	102	116	finally
    //   102	112	116	finally
    //   112	114	116	finally
    //   117	119	116	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\psJpCSi8_h7NzZZ1vbR\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */