package Q5BpP92bwE86mpl.Q_;

import Q5BpP92bwE86mpl.X9K8CXVSxZWf;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@X9K8CXVSxZWf
@Documented
@Target({ElementType.METHOD})
public @interface XV2I8z {
  int psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\Q_\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */