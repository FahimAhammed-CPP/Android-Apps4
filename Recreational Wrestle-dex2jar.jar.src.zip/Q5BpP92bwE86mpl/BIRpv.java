package Q5BpP92bwE86mpl;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface BIRpv {
  psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() default psJpCSi8_h7NzZZ1vbR.UNIQUE;
  
  public enum psJpCSi8_h7NzZZ1vbR {
    D89UfNGBvLPp16h, Q_, XV2I8z, psJpCSi8_h7NzZZ1vbR;
    
    static {
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = new psJpCSi8_h7NzZZ1vbR("UNIQUE", 0);
      psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR1;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR2 = new psJpCSi8_h7NzZZ1vbR("SET", 1);
      Q_ = psJpCSi8_h7NzZZ1vbR2;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR3 = new psJpCSi8_h7NzZZ1vbR("SET_VALUES", 2);
      XV2I8z = psJpCSi8_h7NzZZ1vbR3;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR4 = new psJpCSi8_h7NzZZ1vbR("MAP", 3);
      D89UfNGBvLPp16h = psJpCSi8_h7NzZZ1vbR4;
      X9K8CXVSxZWf = new psJpCSi8_h7NzZZ1vbR[] { psJpCSi8_h7NzZZ1vbR1, psJpCSi8_h7NzZZ1vbR2, psJpCSi8_h7NzZZ1vbR3, psJpCSi8_h7NzZZ1vbR4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\BIRpv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */