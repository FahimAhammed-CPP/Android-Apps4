package Q5BpP92bwE86mpl;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface wqn {
  Class<?>[] Q_() default {};
  
  Class<?>[] psJpCSi8_h7NzZZ1vbR() default {};
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\wqn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */