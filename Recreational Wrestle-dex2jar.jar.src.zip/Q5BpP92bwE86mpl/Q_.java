package Q5BpP92bwE86mpl;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Documented
@Target({ElementType.METHOD})
public @interface Q_ {}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Q5BpP92bwE86mpl\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */