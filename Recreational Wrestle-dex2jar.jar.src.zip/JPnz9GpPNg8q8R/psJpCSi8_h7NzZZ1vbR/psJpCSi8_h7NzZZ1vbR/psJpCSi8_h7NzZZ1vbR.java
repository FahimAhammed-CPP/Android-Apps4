package JPnz9GpPNg8q8R.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;

public class psJpCSi8_h7NzZZ1vbR {
  protected static long Q_;
  
  private static char X9K8CXVSxZWf;
  
  private long D89UfNGBvLPp16h;
  
  private float XV2I8z;
  
  protected float psJpCSi8_h7NzZZ1vbR;
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\JPnz9GpPNg8q8R\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */