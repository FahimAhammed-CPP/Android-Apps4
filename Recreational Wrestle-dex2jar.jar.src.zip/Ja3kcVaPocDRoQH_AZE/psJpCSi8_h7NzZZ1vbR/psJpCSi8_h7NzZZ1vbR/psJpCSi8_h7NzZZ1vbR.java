package Ja3kcVaPocDRoQH_AZE.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;

import android.util.Log;

public class psJpCSi8_h7NzZZ1vbR {
  protected static void Q_() {
    Log.e("DvnDomBiDC", "VEqZZJuagdsVMi");
    Log.d("VkHkJFfqKFiJc", "aeDTUJAIPDYlOGqJnuaAvitzSKRvFLjSEBJoxRuEG");
    Log.e("twyVIFcuiWIWWGFsOARHAAOXbkSoDiCVJGCSKddUG", "CNhfBTartJIEGSCcqlehNwGKGuWHyAFOMWyYKABSo");
  }
  
  private static void XV2I8z() {
    Log.d("OEUCJkTDDmMmFYAufUCE", "MtZPiECETfEoIDCsgNGzGmjLkhktMDZKOADntHfAs");
  }
  
  public void psJpCSi8_h7NzZZ1vbR() {
    Log.d("RDTdZFmgaVlJCOySEMsAjLeHHCDwyDlyHHwrDOJLT", "hYVBJgAkXRQHEXunjXLPigLzhhnVeJVyJFAvJDHrB");
    Log.i("sHxAshrBwHMfZlvtXOdk", "BhKvhEOqSQQJBBtVv");
    Log.v("fEyAbqJBkguuAjeCGAyvKTUzZUcGrPYCCBTL", "JvGDsbqjkdFpDFbhxEenQKpFFxhMaLxYVrhAQvnWG");
    Log.d("WEdApQThPCvpRBunyUNlXAeYLQEyrpBFAGCacDtfO", "gNhQPqUW");
    Log.i("VBbsAcDxzXIauOiKRqyjEwrhTO", "HWBlDsHTIBPwDWFAEZFqbrQOwDBYBXpFofPCAwYMH");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Ja3kcVaPocDRoQH_AZE\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */