package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

final class Q_ extends rG8A403wjTaYB6V {
  private final long Q_;
  
  private final byte XV2I8z;
  
  private final long psJpCSi8_h7NzZZ1vbR;
  
  Q_(long paramLong1, long paramLong2, byte paramByte) {
    this.psJpCSi8_h7NzZZ1vbR = paramLong1;
    this.Q_ = paramLong2;
    this.XV2I8z = paramByte;
  }
  
  public long Q_() {
    return this.Q_;
  }
  
  public byte XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof rG8A403wjTaYB6V) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR == paramObject.psJpCSi8_h7NzZZ1vbR() && this.Q_ == paramObject.Q_() && this.XV2I8z == paramObject.XV2I8z());
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = 1000003L;
    long l2 = this.psJpCSi8_h7NzZZ1vbR;
    l1 = ((int)(l1 ^ l2 ^ l2 >>> 32L) * 1000003);
    l2 = this.Q_;
    int i = (int)(l1 ^ l2 ^ l2 >>> 32L);
    return this.XV2I8z ^ i * 1000003;
  }
  
  public long psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ServerStats{lbLatencyNs=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", serviceLatencyNs=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", traceOption=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */