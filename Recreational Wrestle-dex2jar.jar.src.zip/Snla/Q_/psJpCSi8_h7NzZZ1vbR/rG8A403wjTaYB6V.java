package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

public abstract class rG8A403wjTaYB6V {
  public static rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR(long paramLong1, long paramLong2, byte paramByte) {
    if (paramLong1 >= 0L) {
      if (paramLong2 >= 0L)
        return new Q_(paramLong1, paramLong2, paramByte); 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("'getServiceLatencyNs' is less than zero: ");
      stringBuilder1.append(paramLong2);
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("'getLbLatencyNs' is less than zero: ");
    stringBuilder.append(paramLong1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public abstract long Q_();
  
  public abstract byte XV2I8z();
  
  public abstract long psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\rG8A403wjTaYB6V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */