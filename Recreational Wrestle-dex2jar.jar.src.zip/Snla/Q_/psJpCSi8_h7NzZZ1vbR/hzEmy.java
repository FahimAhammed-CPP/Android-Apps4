package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

public interface hzEmy extends LEIMjJ {
  void close();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\hzEmy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */