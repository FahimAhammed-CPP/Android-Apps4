package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

import java.util.TreeMap;
import javax.annotation.Nullable;

public final class GUkgqR9XjHnivS {
  private static final int psJpCSi8_h7NzZZ1vbR = Q_();
  
  private static int Q_() {
    Q_[] arrayOfQ_ = Q_.values();
    int k = arrayOfQ_.length;
    int i = 0;
    int j = 0;
    while (i < k) {
      j = j + arrayOfQ_[i].psJpCSi8_h7NzZZ1vbR() + 1;
      i++;
    } 
    return j;
  }
  
  public static int psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public enum Q_ {
    Q_, XV2I8z, psJpCSi8_h7NzZZ1vbR;
    
    private final int D89UfNGBvLPp16h;
    
    static {
      Q_ q_1 = new Q_("SERVER_STATS_LB_LATENCY_SIZE", 0, 8);
      psJpCSi8_h7NzZZ1vbR = q_1;
      Q_ q_2 = new Q_("SERVER_STATS_SERVICE_LATENCY_SIZE", 1, 8);
      Q_ = q_2;
      Q_ q_3 = new Q_("SERVER_STATS_TRACE_OPTION_SIZE", 2, 1);
      XV2I8z = q_3;
      X9K8CXVSxZWf = new Q_[] { q_1, q_2, q_3 };
    }
    
    Q_(int param1Int1) {
      this.D89UfNGBvLPp16h = param1Int1;
    }
    
    public int psJpCSi8_h7NzZZ1vbR() {
      return this.D89UfNGBvLPp16h;
    }
  }
  
  public enum psJpCSi8_h7NzZZ1vbR {
    Q_, XV2I8z, psJpCSi8_h7NzZZ1vbR;
    
    private static final TreeMap<Integer, psJpCSi8_h7NzZZ1vbR> X9K8CXVSxZWf;
    
    private final int D89UfNGBvLPp16h;
    
    static {
      int i = 0;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = new psJpCSi8_h7NzZZ1vbR("SERVER_STATS_LB_LATENCY_ID", 0, 0);
      psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR1;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR2 = new psJpCSi8_h7NzZZ1vbR("SERVER_STATS_SERVICE_LATENCY_ID", 1, 1);
      Q_ = psJpCSi8_h7NzZZ1vbR2;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR3 = new psJpCSi8_h7NzZZ1vbR("SERVER_STATS_TRACE_OPTION_ID", 2, 2);
      XV2I8z = psJpCSi8_h7NzZZ1vbR3;
      MxwALnHp3MNCI = new psJpCSi8_h7NzZZ1vbR[] { psJpCSi8_h7NzZZ1vbR1, psJpCSi8_h7NzZZ1vbR2, psJpCSi8_h7NzZZ1vbR3 };
      X9K8CXVSxZWf = new TreeMap<Integer, psJpCSi8_h7NzZZ1vbR>();
      psJpCSi8_h7NzZZ1vbR[] arrayOfPsJpCSi8_h7NzZZ1vbR = values();
      int j = arrayOfPsJpCSi8_h7NzZZ1vbR.length;
      while (i < j) {
        psJpCSi8_h7NzZZ1vbR2 = arrayOfPsJpCSi8_h7NzZZ1vbR[i];
        X9K8CXVSxZWf.put(Integer.valueOf(psJpCSi8_h7NzZZ1vbR2.D89UfNGBvLPp16h), psJpCSi8_h7NzZZ1vbR2);
        i++;
      } 
    }
    
    psJpCSi8_h7NzZZ1vbR(int param1Int1) {
      this.D89UfNGBvLPp16h = param1Int1;
    }
    
    @Nullable
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(int param1Int) {
      return X9K8CXVSxZWf.get(Integer.valueOf(param1Int));
    }
    
    public int psJpCSi8_h7NzZZ1vbR() {
      return this.D89UfNGBvLPp16h;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\GUkgqR9XjHnivS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */