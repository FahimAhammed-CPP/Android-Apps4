package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class Ap4G4fS9phs {
  public static final byte psJpCSi8_h7NzZZ1vbR = 0;
  
  public static rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte) throws D_K6ibTZHL_tOOY3 {
    ByteBuffer byteBuffer = ByteBuffer.wrap(paramArrayOfbyte);
    byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    if (byteBuffer.hasRemaining()) {
      int i = byteBuffer.get();
      if (i <= 0 && i >= 0) {
        long l2 = 0L;
        byte b = 0;
        long l1 = 0L;
        while (byteBuffer.hasRemaining()) {
          GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(byteBuffer.get() & 0xFF);
          if (psJpCSi8_h7NzZZ1vbR == null) {
            byteBuffer.position(byteBuffer.limit());
            continue;
          } 
          i = null.psJpCSi8_h7NzZZ1vbR[psJpCSi8_h7NzZZ1vbR.ordinal()];
          if (i != 1) {
            if (i != 2) {
              if (i != 3)
                continue; 
              b = byteBuffer.get();
              continue;
            } 
            l1 = byteBuffer.getLong();
            continue;
          } 
          l2 = byteBuffer.getLong();
        } 
        try {
          return rG8A403wjTaYB6V.psJpCSi8_h7NzZZ1vbR(l2, l1, b);
        } catch (IllegalArgumentException illegalArgumentException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Serialized ServiceStats contains invalid values: ");
          stringBuilder1.append(illegalArgumentException.getMessage());
          throw new D_K6ibTZHL_tOOY3(stringBuilder1.toString());
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid ServerStats version: ");
      stringBuilder.append(i);
      throw new D_K6ibTZHL_tOOY3(stringBuilder.toString());
    } 
    throw new D_K6ibTZHL_tOOY3("Serialized ServerStats buffer is empty");
  }
  
  public static byte[] psJpCSi8_h7NzZZ1vbR(rG8A403wjTaYB6V paramrG8A403wjTaYB6V) {
    ByteBuffer byteBuffer = ByteBuffer.allocate(GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR() + 1);
    byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    byteBuffer.put((byte)0);
    byteBuffer.put((byte)GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR());
    byteBuffer.putLong(paramrG8A403wjTaYB6V.psJpCSi8_h7NzZZ1vbR());
    byteBuffer.put((byte)GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR.Q_.psJpCSi8_h7NzZZ1vbR());
    byteBuffer.putLong(paramrG8A403wjTaYB6V.Q_());
    byteBuffer.put((byte)GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR.XV2I8z.psJpCSi8_h7NzZZ1vbR());
    byteBuffer.put(paramrG8A403wjTaYB6V.XV2I8z());
    return byteBuffer.array();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\Ap4G4fS9phs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */