package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

public interface UptK2mZMIFJk1ivmXYH<T> {
  double psJpCSi8_h7NzZZ1vbR(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\UptK2mZMIFJk1ivmXYH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */