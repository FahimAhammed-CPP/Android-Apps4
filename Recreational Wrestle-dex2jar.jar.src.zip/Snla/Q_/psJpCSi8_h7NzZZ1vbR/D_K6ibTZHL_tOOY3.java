package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

public final class D_K6ibTZHL_tOOY3 extends Exception {
  private static final long serialVersionUID = 0L;
  
  public D_K6ibTZHL_tOOY3(String paramString) {
    super(paramString);
  }
  
  public D_K6ibTZHL_tOOY3(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\D_K6ibTZHL_tOOY3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */