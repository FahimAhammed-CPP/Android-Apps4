package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

final class XV2I8z extends LEwT0cz2WRRZ {
  private final int Q_;
  
  private final long psJpCSi8_h7NzZZ1vbR;
  
  XV2I8z(long paramLong, int paramInt) {
    this.psJpCSi8_h7NzZZ1vbR = paramLong;
    this.Q_ = paramInt;
  }
  
  public int Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof LEwT0cz2WRRZ) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR == paramObject.psJpCSi8_h7NzZZ1vbR() && this.Q_ == paramObject.Q_());
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = 1000003L;
    long l2 = this.psJpCSi8_h7NzZZ1vbR;
    int i = (int)(l1 ^ l2 ^ l2 >>> 32L);
    return this.Q_ ^ i * 1000003;
  }
  
  public long psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Timestamp{seconds=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", nanos=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */