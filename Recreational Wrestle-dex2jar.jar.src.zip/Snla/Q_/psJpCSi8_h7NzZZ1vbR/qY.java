package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

public final class qY {
  public static final String psJpCSi8_h7NzZZ1vbR = "0.28.0";
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\qY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */