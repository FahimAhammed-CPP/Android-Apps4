package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

import java.math.BigInteger;

final class oq9TzoD0 {
  static final long D89UfNGBvLPp16h = 1000000L;
  
  private static final BigInteger MxwALnHp3MNCI = BigInteger.valueOf(Long.MAX_VALUE);
  
  static final int Q_ = 999999999;
  
  static final long X9K8CXVSxZWf = 1000000000L;
  
  static final long XV2I8z = 1000L;
  
  static final long psJpCSi8_h7NzZZ1vbR = 315576000000L;
  
  private static final BigInteger wqn = BigInteger.valueOf(Long.MIN_VALUE);
  
  static long Q_(long paramLong1, long paramLong2) {
    BigInteger bigInteger = BigInteger.valueOf(paramLong1).add(BigInteger.valueOf(paramLong2));
    if (bigInteger.compareTo(MxwALnHp3MNCI) <= 0 && bigInteger.compareTo(wqn) >= 0)
      return paramLong1 + paramLong2; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Long sum overflow: x=");
    stringBuilder.append(paramLong1);
    stringBuilder.append(", y=");
    stringBuilder.append(paramLong2);
    throw new ArithmeticException(stringBuilder.toString());
  }
  
  static int psJpCSi8_h7NzZZ1vbR(long paramLong1, long paramLong2) {
    int i = paramLong1 cmp paramLong2;
    return (i < 0) ? -1 : ((i == 0) ? 0 : 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\oq9TzoD0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */