package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

import java.util.concurrent.TimeUnit;

public abstract class X9K8CXVSxZWf implements Comparable<X9K8CXVSxZWf> {
  public static X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR(long paramLong) {
    return psJpCSi8_h7NzZZ1vbR(paramLong / 1000L, (int)(paramLong % 1000L * 1000000L));
  }
  
  public static X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR(long paramLong, int paramInt) {
    if (paramLong >= -315576000000L) {
      if (paramLong <= 315576000000L) {
        if (paramInt >= -999999999) {
          if (paramInt <= 999999999) {
            int i = paramLong cmp 0L;
            if ((i >= 0 || paramInt <= 0) && (i <= 0 || paramInt >= 0))
              return new psJpCSi8_h7NzZZ1vbR(paramLong, paramInt); 
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append("'seconds' and 'nanos' have inconsistent sign: seconds=");
            stringBuilder4.append(paramLong);
            stringBuilder4.append(", nanos=");
            stringBuilder4.append(paramInt);
            throw new IllegalArgumentException(stringBuilder4.toString());
          } 
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append("'nanos' is greater than maximum (999999999): ");
          stringBuilder3.append(paramInt);
          throw new IllegalArgumentException(stringBuilder3.toString());
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("'nanos' is less than minimum (-999999999): ");
        stringBuilder2.append(paramInt);
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("'seconds' is greater than maximum (315576000000): ");
      stringBuilder1.append(paramLong);
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("'seconds' is less than minimum (-315576000000): ");
    stringBuilder.append(paramLong);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public abstract int Q_();
  
  public long XV2I8z() {
    return TimeUnit.SECONDS.toMillis(psJpCSi8_h7NzZZ1vbR()) + TimeUnit.NANOSECONDS.toMillis(Q_());
  }
  
  public int psJpCSi8_h7NzZZ1vbR(X9K8CXVSxZWf paramX9K8CXVSxZWf) {
    int i = oq9TzoD0.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR(), paramX9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR());
    return (i != 0) ? i : oq9TzoD0.psJpCSi8_h7NzZZ1vbR(Q_(), paramX9K8CXVSxZWf.Q_());
  }
  
  public abstract long psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */