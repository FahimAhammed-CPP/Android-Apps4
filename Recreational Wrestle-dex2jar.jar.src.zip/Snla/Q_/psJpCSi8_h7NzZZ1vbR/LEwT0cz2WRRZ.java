package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

import java.math.BigDecimal;
import java.math.RoundingMode;

public abstract class LEwT0cz2WRRZ implements Comparable<LEwT0cz2WRRZ> {
  private static long D89UfNGBvLPp16h(long paramLong1, long paramLong2) {
    return paramLong1 - XV2I8z(paramLong1, paramLong2) * paramLong2;
  }
  
  private static LEwT0cz2WRRZ Q_(long paramLong1, long paramLong2) {
    return psJpCSi8_h7NzZZ1vbR(oq9TzoD0.Q_(paramLong1, XV2I8z(paramLong2, 1000000000L)), (int)D89UfNGBvLPp16h(paramLong2, 1000000000L));
  }
  
  private static long XV2I8z(long paramLong1, long paramLong2) {
    return BigDecimal.valueOf(paramLong1).divide(BigDecimal.valueOf(paramLong2), 0, RoundingMode.FLOOR).longValue();
  }
  
  public static LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR(long paramLong) {
    return psJpCSi8_h7NzZZ1vbR(XV2I8z(paramLong, 1000L), (int)((int)D89UfNGBvLPp16h(paramLong, 1000L) * 1000000L));
  }
  
  public static LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR(long paramLong, int paramInt) {
    if (paramLong >= -315576000000L) {
      if (paramLong <= 315576000000L) {
        if (paramInt >= 0) {
          if (paramInt <= 999999999)
            return new XV2I8z(paramLong, paramInt); 
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append("'nanos' is greater than maximum (999999999): ");
          stringBuilder3.append(paramInt);
          throw new IllegalArgumentException(stringBuilder3.toString());
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("'nanos' is less than zero: ");
        stringBuilder2.append(paramInt);
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("'seconds' is greater than maximum (315576000000): ");
      stringBuilder1.append(paramLong);
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("'seconds' is less than minimum (-315576000000): ");
    stringBuilder.append(paramLong);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR(long paramLong1, long paramLong2) {
    return ((paramLong1 | paramLong2) == 0L) ? this : Q_(oq9TzoD0.Q_(oq9TzoD0.Q_(psJpCSi8_h7NzZZ1vbR(), paramLong1), paramLong2 / 1000000000L), Q_() + paramLong2 % 1000000000L);
  }
  
  public abstract int Q_();
  
  public int Q_(LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    int i = oq9TzoD0.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR(), paramLEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR());
    return (i != 0) ? i : oq9TzoD0.psJpCSi8_h7NzZZ1vbR(Q_(), paramLEwT0cz2WRRZ.Q_());
  }
  
  public LEwT0cz2WRRZ Q_(long paramLong) {
    return psJpCSi8_h7NzZZ1vbR(0L, paramLong);
  }
  
  public abstract long psJpCSi8_h7NzZZ1vbR();
  
  public LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR(X9K8CXVSxZWf paramX9K8CXVSxZWf) {
    return psJpCSi8_h7NzZZ1vbR(paramX9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(), paramX9K8CXVSxZWf.Q_());
  }
  
  public X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    long l1;
    long l2 = psJpCSi8_h7NzZZ1vbR() - paramLEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR();
    int j = Q_() - paramLEwT0cz2WRRZ.Q_();
    int k = l2 cmp 0L;
    if (k < 0 && j > 0) {
      l1 = l2 + 1L;
      l2 = j - 1000000000L;
    } else {
      l1 = l2;
      int m = j;
      if (k > 0) {
        l1 = l2;
        m = j;
        if (j < 0) {
          l1 = l2 - 1L;
          l2 = j + 1000000000L;
        } else {
          return X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(l1, m);
        } 
      } else {
        return X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(l1, m);
      } 
    } 
    int i = (int)l2;
    return X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(l1, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\LEwT0cz2WRRZ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */