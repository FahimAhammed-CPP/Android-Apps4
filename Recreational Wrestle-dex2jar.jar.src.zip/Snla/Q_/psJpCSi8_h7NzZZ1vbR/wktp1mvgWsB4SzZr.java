package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

import javax.annotation.Nullable;

public final class wktp1mvgWsB4SzZr {
  private static final wqn<Object, String> D89UfNGBvLPp16h;
  
  private static final wqn<Object, Void> Q_;
  
  private static final wqn<Object, Void> XV2I8z;
  
  private static final wqn<Object, Void> psJpCSi8_h7NzZZ1vbR = new wqn<Object, Void>() {
      @Nullable
      public Void Q_(Object param1Object) {
        return null;
      }
    };
  
  static {
    Q_ = new wqn<Object, Void>() {
        public Void Q_(Object param1Object) {
          throw new IllegalArgumentException();
        }
      };
    XV2I8z = new wqn<Object, Void>() {
        public Void Q_(Object param1Object) {
          throw new AssertionError();
        }
      };
    D89UfNGBvLPp16h = new wqn<Object, String>() {
        public String Q_(Object param1Object) {
          return (param1Object == null) ? null : param1Object.toString();
        }
      };
  }
  
  public static <T> wqn<Object, T> D89UfNGBvLPp16h() {
    return (wqn)XV2I8z;
  }
  
  public static wqn<Object, String> Q_() {
    return D89UfNGBvLPp16h;
  }
  
  public static <T> wqn<Object, T> XV2I8z() {
    return (wqn)Q_;
  }
  
  public static <T> wqn<Object, T> psJpCSi8_h7NzZZ1vbR() {
    return (wqn)psJpCSi8_h7NzZZ1vbR;
  }
  
  public static <T> wqn<Object, T> psJpCSi8_h7NzZZ1vbR(T paramT) {
    return new wqn<Object, T>(paramT) {
        public T psJpCSi8_h7NzZZ1vbR(Object param1Object) {
          return (T)this.psJpCSi8_h7NzZZ1vbR;
        }
      };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\wktp1mvgWsB4SzZr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */