package Snla.Q_.psJpCSi8_h7NzZZ1vbR;

public abstract class D89UfNGBvLPp16h {
  public abstract long Q_();
  
  public abstract LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\psJpCSi8_h7NzZZ1vbR\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */