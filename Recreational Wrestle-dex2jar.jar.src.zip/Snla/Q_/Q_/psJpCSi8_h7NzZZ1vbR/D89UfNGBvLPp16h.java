package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.wktp1mvgWsB4SzZr.fc4RJByVvAciR;
import Snla.Q_.wqn.qY;
import Snla.Q_.wqn.wktp1mvgWsB4SzZr;
import com.google.common.base.Preconditions;
import java.util.concurrent.atomic.AtomicLong;

public class D89UfNGBvLPp16h {
  static final qY Q_ = qY.psJpCSi8_h7NzZZ1vbR(qY.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR);
  
  static final long psJpCSi8_h7NzZZ1vbR = -1L;
  
  final wktp1mvgWsB4SzZr BIRpv;
  
  final fc4RJByVvAciR D89UfNGBvLPp16h;
  
  AtomicLong MxwALnHp3MNCI = new AtomicLong();
  
  AtomicLong X9K8CXVSxZWf = new AtomicLong();
  
  final long XV2I8z;
  
  AtomicLong wktp1mvgWsB4SzZr = new AtomicLong();
  
  AtomicLong wqn = new AtomicLong();
  
  D89UfNGBvLPp16h(fc4RJByVvAciR paramfc4RJByVvAciR, wktp1mvgWsB4SzZr paramwktp1mvgWsB4SzZr) {
    Preconditions.checkNotNull(paramfc4RJByVvAciR, "span");
    Preconditions.checkNotNull(paramwktp1mvgWsB4SzZr, "tagContext");
    this.D89UfNGBvLPp16h = paramfc4RJByVvAciR;
    this.BIRpv = paramwktp1mvgWsB4SzZr;
    this.XV2I8z = System.nanoTime();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */