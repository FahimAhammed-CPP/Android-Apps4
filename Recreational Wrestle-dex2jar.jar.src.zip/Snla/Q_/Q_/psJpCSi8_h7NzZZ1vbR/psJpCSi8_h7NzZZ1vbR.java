package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf;
import Snla.Q_.wktp1mvgWsB4SzZr.Q_;
import Snla.Q_.wktp1mvgWsB4SzZr.fc4RJByVvAciR;
import Snla.Q_.wktp1mvgWsB4SzZr.jlrPm;
import Snla.Q_.wqn.wktp1mvgWsB4SzZr;
import com.google.common.base.Preconditions;
import javax.annotation.Nullable;

abstract class psJpCSi8_h7NzZZ1vbR<Q, P> {
  final XV2I8z<Q, P> psJpCSi8_h7NzZZ1vbR;
  
  psJpCSi8_h7NzZZ1vbR(XV2I8z<Q, P> paramXV2I8z) {
    Preconditions.checkNotNull(paramXV2I8z, "extractor");
    this.psJpCSi8_h7NzZZ1vbR = paramXV2I8z;
  }
  
  static void psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, long paramLong1, jlrPm.Q_ paramQ_, long paramLong2, long paramLong3) {
    paramfc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR(jlrPm.psJpCSi8_h7NzZZ1vbR(paramQ_, paramLong1).Q_(paramLong2).XV2I8z(paramLong3).psJpCSi8_h7NzZZ1vbR());
  }
  
  private static void psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, String paramString1, @Nullable String paramString2) {
    if (paramString2 != null && !paramString2.isEmpty())
      paramfc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR(paramString1, Q_.psJpCSi8_h7NzZZ1vbR(paramString2)); 
  }
  
  public final void Q_(D89UfNGBvLPp16h paramD89UfNGBvLPp16h, long paramLong) {
    Preconditions.checkNotNull(paramD89UfNGBvLPp16h, "context");
    paramD89UfNGBvLPp16h.MxwALnHp3MNCI.addAndGet(paramLong);
    if (paramD89UfNGBvLPp16h.D89UfNGBvLPp16h.XV2I8z().contains(fc4RJByVvAciR.Q_.psJpCSi8_h7NzZZ1vbR))
      psJpCSi8_h7NzZZ1vbR(paramD89UfNGBvLPp16h.D89UfNGBvLPp16h, paramD89UfNGBvLPp16h.wktp1mvgWsB4SzZr.addAndGet(1L), jlrPm.Q_.Q_, paramLong, 0L); 
  }
  
  D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, wktp1mvgWsB4SzZr paramwktp1mvgWsB4SzZr) {
    return new D89UfNGBvLPp16h(paramfc4RJByVvAciR, paramwktp1mvgWsB4SzZr);
  }
  
  public fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR(D89UfNGBvLPp16h paramD89UfNGBvLPp16h) {
    Preconditions.checkNotNull(paramD89UfNGBvLPp16h, "context");
    return paramD89UfNGBvLPp16h.D89UfNGBvLPp16h;
  }
  
  final String psJpCSi8_h7NzZZ1vbR(Q paramQ, XV2I8z<Q, P> paramXV2I8z) {
    String str2 = paramXV2I8z.X9K8CXVSxZWf(paramQ);
    String str1 = str2;
    if (str2 == null)
      str1 = "/"; 
    str2 = str1;
    if (!str1.startsWith("/")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("/");
      stringBuilder.append(str1);
      str2 = stringBuilder.toString();
    } 
    return str2;
  }
  
  public final void psJpCSi8_h7NzZZ1vbR(D89UfNGBvLPp16h paramD89UfNGBvLPp16h, long paramLong) {
    Preconditions.checkNotNull(paramD89UfNGBvLPp16h, "context");
    paramD89UfNGBvLPp16h.X9K8CXVSxZWf.addAndGet(paramLong);
    if (paramD89UfNGBvLPp16h.D89UfNGBvLPp16h.XV2I8z().contains(fc4RJByVvAciR.Q_.psJpCSi8_h7NzZZ1vbR))
      psJpCSi8_h7NzZZ1vbR(paramD89UfNGBvLPp16h.D89UfNGBvLPp16h, paramD89UfNGBvLPp16h.wqn.addAndGet(1L), jlrPm.Q_.psJpCSi8_h7NzZZ1vbR, paramLong, 0L); 
  }
  
  void psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, int paramInt, @Nullable Throwable paramThrowable) {
    if (paramfc4RJByVvAciR.XV2I8z().contains(fc4RJByVvAciR.Q_.psJpCSi8_h7NzZZ1vbR)) {
      paramfc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR("http.status_code", Q_.psJpCSi8_h7NzZZ1vbR(paramInt));
      paramfc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR(X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramInt, paramThrowable));
    } 
    paramfc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR();
  }
  
  final void psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, Q paramQ, XV2I8z<Q, P> paramXV2I8z) {
    psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, "http.user_agent", paramXV2I8z.MxwALnHp3MNCI(paramQ));
    psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, "http.host", paramXV2I8z.XV2I8z(paramQ));
    psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, "http.method", paramXV2I8z.D89UfNGBvLPp16h(paramQ));
    psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, "http.path", paramXV2I8z.X9K8CXVSxZWf(paramQ));
    psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, "http.route", paramXV2I8z.psJpCSi8_h7NzZZ1vbR(paramQ));
    psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, "http.url", paramXV2I8z.Q_(paramQ));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */