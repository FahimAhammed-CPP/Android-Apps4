package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.MxwALnHp3MNCI.jbUx;
import Snla.Q_.MxwALnHp3MNCI.n4neFNjUxhYqW;
import Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_;
import Snla.Q_.wktp1mvgWsB4SzZr.AYieGTkN28B_;
import Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h.D89UfNGBvLPp16h;
import Snla.Q_.wktp1mvgWsB4SzZr.Q5BpP92bwE86mpl;
import Snla.Q_.wktp1mvgWsB4SzZr.fc4RJByVvAciR;
import Snla.Q_.wqn.Ap4G4fS9phs;
import Snla.Q_.wqn.BIRpv;
import Snla.Q_.wqn.LEIMjJ;
import Snla.Q_.wqn.hzEmy;
import Snla.Q_.wqn.rG8A403wjTaYB6V;
import Snla.Q_.wqn.wktp1mvgWsB4SzZr;
import com.google.common.base.Preconditions;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

public class Q_<Q, P, C> extends psJpCSi8_h7NzZZ1vbR<Q, P> {
  private final Q5BpP92bwE86mpl D89UfNGBvLPp16h;
  
  private final rG8A403wjTaYB6V MxwALnHp3MNCI;
  
  private final D89UfNGBvLPp16h.XV2I8z<C> Q_;
  
  private final jbUx X9K8CXVSxZWf;
  
  private final D89UfNGBvLPp16h XV2I8z;
  
  public Q_(Q5BpP92bwE86mpl paramQ5BpP92bwE86mpl, XV2I8z<Q, P> paramXV2I8z, D89UfNGBvLPp16h paramD89UfNGBvLPp16h, D89UfNGBvLPp16h.XV2I8z<C> paramXV2I8z1) {
    super(paramXV2I8z);
    Preconditions.checkNotNull(paramXV2I8z1, "setter");
    Preconditions.checkNotNull(paramD89UfNGBvLPp16h, "textFormat");
    Preconditions.checkNotNull(paramQ5BpP92bwE86mpl, "tracer");
    this.Q_ = paramXV2I8z1;
    this.XV2I8z = paramD89UfNGBvLPp16h;
    this.D89UfNGBvLPp16h = paramQ5BpP92bwE86mpl;
    this.X9K8CXVSxZWf = n4neFNjUxhYqW.psJpCSi8_h7NzZZ1vbR();
    this.MxwALnHp3MNCI = Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR();
  }
  
  private void psJpCSi8_h7NzZZ1vbR(D89UfNGBvLPp16h paramD89UfNGBvLPp16h, @Nullable Q paramQ, int paramInt) {
    String str2;
    String str1;
    String str3;
    double d = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - paramD89UfNGBvLPp16h.XV2I8z);
    String str5 = "";
    if (paramQ == null) {
      str3 = "";
    } else {
      str3 = this.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h(paramQ);
    } 
    if (paramQ == null) {
      str2 = "null_request";
    } else {
      str2 = this.psJpCSi8_h7NzZZ1vbR.XV2I8z((Q)str2);
    } 
    BIRpv bIRpv3 = this.MxwALnHp3MNCI.psJpCSi8_h7NzZZ1vbR(paramD89UfNGBvLPp16h.BIRpv);
    LEIMjJ lEIMjJ2 = Q_.wqn;
    String str4 = str2;
    if (str2 == null)
      str4 = "null_host"; 
    BIRpv bIRpv1 = bIRpv3.psJpCSi8_h7NzZZ1vbR(lEIMjJ2, hzEmy.psJpCSi8_h7NzZZ1vbR(str4), D89UfNGBvLPp16h.Q_);
    LEIMjJ lEIMjJ1 = Q_.rG8A403wjTaYB6V;
    if (str3 == null)
      str3 = str5; 
    BIRpv bIRpv2 = bIRpv1.psJpCSi8_h7NzZZ1vbR(lEIMjJ1, hzEmy.psJpCSi8_h7NzZZ1vbR(str3), D89UfNGBvLPp16h.Q_);
    lEIMjJ1 = Q_.BIRpv;
    if (paramInt == 0) {
      str1 = "error";
    } else {
      str1 = Integer.toString(paramInt);
    } 
    wktp1mvgWsB4SzZr wktp1mvgWsB4SzZr = bIRpv2.psJpCSi8_h7NzZZ1vbR(lEIMjJ1, hzEmy.psJpCSi8_h7NzZZ1vbR(str1), D89UfNGBvLPp16h.Q_).psJpCSi8_h7NzZZ1vbR();
    this.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR().psJpCSi8_h7NzZZ1vbR(Q_.XV2I8z, d).psJpCSi8_h7NzZZ1vbR(Q_.psJpCSi8_h7NzZZ1vbR, paramD89UfNGBvLPp16h.X9K8CXVSxZWf.get()).psJpCSi8_h7NzZZ1vbR(Q_.Q_, paramD89UfNGBvLPp16h.MxwALnHp3MNCI.get()).psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr);
  }
  
  public D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR(@Nullable fc4RJByVvAciR paramfc4RJByVvAciR, C paramC, Q paramQ) {
    Preconditions.checkNotNull(paramC, "carrier");
    Preconditions.checkNotNull(paramQ, "request");
    fc4RJByVvAciR fc4RJByVvAciR2 = paramfc4RJByVvAciR;
    if (paramfc4RJByVvAciR == null)
      fc4RJByVvAciR2 = this.D89UfNGBvLPp16h.Q_(); 
    String str = psJpCSi8_h7NzZZ1vbR(paramQ, this.psJpCSi8_h7NzZZ1vbR);
    fc4RJByVvAciR fc4RJByVvAciR1 = this.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(str, fc4RJByVvAciR2).psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR.Q_).psJpCSi8_h7NzZZ1vbR();
    if (fc4RJByVvAciR1.XV2I8z().contains(fc4RJByVvAciR.Q_.psJpCSi8_h7NzZZ1vbR))
      psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR1, paramQ, this.psJpCSi8_h7NzZZ1vbR); 
    AYieGTkN28B_ aYieGTkN28B_ = fc4RJByVvAciR1.Q_();
    if (!aYieGTkN28B_.equals(AYieGTkN28B_.psJpCSi8_h7NzZZ1vbR))
      this.XV2I8z.psJpCSi8_h7NzZZ1vbR(aYieGTkN28B_, paramC, this.Q_); 
    return psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR1, this.MxwALnHp3MNCI.Q_());
  }
  
  public void psJpCSi8_h7NzZZ1vbR(D89UfNGBvLPp16h paramD89UfNGBvLPp16h, @Nullable Q paramQ, @Nullable P paramP, @Nullable Throwable paramThrowable) {
    Preconditions.checkNotNull(paramD89UfNGBvLPp16h, "context");
    int i = this.psJpCSi8_h7NzZZ1vbR.wqn(paramP);
    psJpCSi8_h7NzZZ1vbR(paramD89UfNGBvLPp16h, paramQ, i);
    psJpCSi8_h7NzZZ1vbR(paramD89UfNGBvLPp16h.D89UfNGBvLPp16h, i, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */