package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.MxwALnHp3MNCI.jbUx;
import Snla.Q_.MxwALnHp3MNCI.n4neFNjUxhYqW;
import Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_;
import Snla.Q_.wktp1mvgWsB4SzZr.AYieGTkN28B_;
import Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h.D89UfNGBvLPp16h;
import Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h.XV2I8z;
import Snla.Q_.wktp1mvgWsB4SzZr.Q5BpP92bwE86mpl;
import Snla.Q_.wktp1mvgWsB4SzZr.RiEMPm5KxmvYEOsVplu5;
import Snla.Q_.wktp1mvgWsB4SzZr.UptK2mZMIFJk1ivmXYH;
import Snla.Q_.wktp1mvgWsB4SzZr.fc4RJByVvAciR;
import Snla.Q_.wqn.Ap4G4fS9phs;
import Snla.Q_.wqn.BIRpv;
import Snla.Q_.wqn.LEIMjJ;
import Snla.Q_.wqn.hzEmy;
import Snla.Q_.wqn.rG8A403wjTaYB6V;
import Snla.Q_.wqn.wktp1mvgWsB4SzZr;
import com.google.common.base.Preconditions;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

public class X9K8CXVSxZWf<Q, P, C> extends psJpCSi8_h7NzZZ1vbR<Q, P> {
  private final Q5BpP92bwE86mpl D89UfNGBvLPp16h;
  
  private final jbUx MxwALnHp3MNCI;
  
  private final D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR<C> Q_;
  
  private final Boolean X9K8CXVSxZWf;
  
  private final D89UfNGBvLPp16h XV2I8z;
  
  private final rG8A403wjTaYB6V wqn;
  
  public X9K8CXVSxZWf(Q5BpP92bwE86mpl paramQ5BpP92bwE86mpl, XV2I8z<Q, P> paramXV2I8z, D89UfNGBvLPp16h paramD89UfNGBvLPp16h, D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR<C> parampsJpCSi8_h7NzZZ1vbR, Boolean paramBoolean) {
    super(paramXV2I8z);
    Preconditions.checkNotNull(paramQ5BpP92bwE86mpl, "tracer");
    Preconditions.checkNotNull(paramD89UfNGBvLPp16h, "textFormat");
    Preconditions.checkNotNull(parampsJpCSi8_h7NzZZ1vbR, "getter");
    Preconditions.checkNotNull(paramBoolean, "publicEndpoint");
    this.D89UfNGBvLPp16h = paramQ5BpP92bwE86mpl;
    this.XV2I8z = paramD89UfNGBvLPp16h;
    this.Q_ = parampsJpCSi8_h7NzZZ1vbR;
    this.X9K8CXVSxZWf = paramBoolean;
    this.MxwALnHp3MNCI = n4neFNjUxhYqW.psJpCSi8_h7NzZZ1vbR();
    this.wqn = Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR();
  }
  
  private void psJpCSi8_h7NzZZ1vbR(D89UfNGBvLPp16h paramD89UfNGBvLPp16h, Q paramQ, int paramInt) {
    double d = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - paramD89UfNGBvLPp16h.XV2I8z);
    String str3 = this.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h(paramQ);
    String str2 = this.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(paramQ);
    BIRpv bIRpv3 = this.wqn.psJpCSi8_h7NzZZ1vbR(paramD89UfNGBvLPp16h.BIRpv);
    LEIMjJ lEIMjJ3 = Q_.D_K6ibTZHL_tOOY3;
    String str1 = str3;
    if (str3 == null)
      str1 = ""; 
    BIRpv bIRpv2 = bIRpv3.psJpCSi8_h7NzZZ1vbR(lEIMjJ3, hzEmy.psJpCSi8_h7NzZZ1vbR(str1), D89UfNGBvLPp16h.Q_);
    LEIMjJ lEIMjJ2 = Q_.Ap4G4fS9phs;
    str1 = str2;
    if (str2 == null)
      str1 = ""; 
    BIRpv bIRpv1 = bIRpv2.psJpCSi8_h7NzZZ1vbR(lEIMjJ2, hzEmy.psJpCSi8_h7NzZZ1vbR(str1), D89UfNGBvLPp16h.Q_);
    LEIMjJ lEIMjJ1 = Q_.LEIMjJ;
    if (paramInt == 0) {
      str1 = "error";
    } else {
      str1 = Integer.toString(paramInt);
    } 
    wktp1mvgWsB4SzZr wktp1mvgWsB4SzZr = bIRpv1.psJpCSi8_h7NzZZ1vbR(lEIMjJ1, hzEmy.psJpCSi8_h7NzZZ1vbR(str1), D89UfNGBvLPp16h.Q_).psJpCSi8_h7NzZZ1vbR();
    this.MxwALnHp3MNCI.psJpCSi8_h7NzZZ1vbR().psJpCSi8_h7NzZZ1vbR(Q_.MxwALnHp3MNCI, d).psJpCSi8_h7NzZZ1vbR(Q_.D89UfNGBvLPp16h, paramD89UfNGBvLPp16h.MxwALnHp3MNCI.get()).psJpCSi8_h7NzZZ1vbR(Q_.X9K8CXVSxZWf, paramD89UfNGBvLPp16h.X9K8CXVSxZWf.get()).psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr);
  }
  
  public D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR(C paramC, Q paramQ) {
    RiEMPm5KxmvYEOsVplu5 riEMPm5KxmvYEOsVplu5;
    Preconditions.checkNotNull(paramC, "carrier");
    Preconditions.checkNotNull(paramQ, "request");
    String str = psJpCSi8_h7NzZZ1vbR(paramQ, this.psJpCSi8_h7NzZZ1vbR);
    try {
      AYieGTkN28B_ aYieGTkN28B_ = this.XV2I8z.psJpCSi8_h7NzZZ1vbR(paramC, this.Q_);
    } catch (XV2I8z xV2I8z) {
      xV2I8z = null;
    } 
    if (xV2I8z == null || this.X9K8CXVSxZWf.booleanValue()) {
      riEMPm5KxmvYEOsVplu5 = this.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(str);
    } else {
      riEMPm5KxmvYEOsVplu5 = this.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR((String)riEMPm5KxmvYEOsVplu5, (AYieGTkN28B_)xV2I8z);
    } 
    fc4RJByVvAciR fc4RJByVvAciR = riEMPm5KxmvYEOsVplu5.psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR).psJpCSi8_h7NzZZ1vbR();
    if (this.X9K8CXVSxZWf.booleanValue() && xV2I8z != null)
      fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR(UptK2mZMIFJk1ivmXYH.psJpCSi8_h7NzZZ1vbR((AYieGTkN28B_)xV2I8z, UptK2mZMIFJk1ivmXYH.psJpCSi8_h7NzZZ1vbR.Q_)); 
    if (fc4RJByVvAciR.XV2I8z().contains(fc4RJByVvAciR.Q_.psJpCSi8_h7NzZZ1vbR))
      psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR, paramQ, this.psJpCSi8_h7NzZZ1vbR); 
    return psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR, this.wqn.Q_());
  }
  
  public void psJpCSi8_h7NzZZ1vbR(D89UfNGBvLPp16h paramD89UfNGBvLPp16h, Q paramQ, @Nullable P paramP, @Nullable Throwable paramThrowable) {
    Preconditions.checkNotNull(paramD89UfNGBvLPp16h, "context");
    Preconditions.checkNotNull(paramQ, "request");
    int i = this.psJpCSi8_h7NzZZ1vbR.wqn(paramP);
    psJpCSi8_h7NzZZ1vbR(paramD89UfNGBvLPp16h, paramQ, i);
    psJpCSi8_h7NzZZ1vbR(paramD89UfNGBvLPp16h.D89UfNGBvLPp16h, i, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */