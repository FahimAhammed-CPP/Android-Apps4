package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.MxwALnHp3MNCI.PK9FDpOut0CP81dMz;
import Snla.Q_.wqn.LEIMjJ;

public final class Q_ {
  public static final LEIMjJ Ap4G4fS9phs;
  
  public static final LEIMjJ BIRpv;
  
  public static final PK9FDpOut0CP81dMz.Q_ D89UfNGBvLPp16h;
  
  public static final LEIMjJ D_K6ibTZHL_tOOY3;
  
  private static final String GUkgqR9XjHnivS = "By";
  
  public static final LEIMjJ LEIMjJ;
  
  public static final PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR MxwALnHp3MNCI;
  
  public static final PK9FDpOut0CP81dMz.Q_ Q_;
  
  public static final PK9FDpOut0CP81dMz.Q_ X9K8CXVSxZWf;
  
  public static final PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR XV2I8z;
  
  public static final LEIMjJ hzEmy;
  
  private static final String oq9TzoD0 = "ms";
  
  public static final PK9FDpOut0CP81dMz.Q_ psJpCSi8_h7NzZZ1vbR = PK9FDpOut0CP81dMz.Q_.psJpCSi8_h7NzZZ1vbR("opencensus.io/http/client/sent_bytes", "Client-side total bytes sent in request body (uncompressed)", "By");
  
  public static final LEIMjJ qY;
  
  public static final LEIMjJ rG8A403wjTaYB6V;
  
  public static final LEIMjJ wktp1mvgWsB4SzZr;
  
  public static final LEIMjJ wqn;
  
  static {
    Q_ = PK9FDpOut0CP81dMz.Q_.psJpCSi8_h7NzZZ1vbR("opencensus.io/http/client/received_bytes", "Client-side total bytes received in response bodies (uncompressed)", "By");
    XV2I8z = PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR("opencensus.io/http/client/roundtrip_latency", "Client-side time between first byte of request headers sent to last byte of response received, or terminal error", "ms");
    D89UfNGBvLPp16h = PK9FDpOut0CP81dMz.Q_.psJpCSi8_h7NzZZ1vbR("opencensus.io/http/server/received_bytes", "Server-side total bytes received in request body (uncompressed)", "By");
    X9K8CXVSxZWf = PK9FDpOut0CP81dMz.Q_.psJpCSi8_h7NzZZ1vbR("opencensus.io/http/server/sent_bytes", "Server-side total bytes sent in response bodies (uncompressed)", "By");
    MxwALnHp3MNCI = PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR("opencensus.io/http/server/server_latency", "Server-side time between first byte of request headers received to last byte of response sent, or terminal error", "ms");
    wqn = LEIMjJ.psJpCSi8_h7NzZZ1vbR("http_client_host");
    wktp1mvgWsB4SzZr = LEIMjJ.psJpCSi8_h7NzZZ1vbR("http_server_host");
    BIRpv = LEIMjJ.psJpCSi8_h7NzZZ1vbR("http_client_status");
    LEIMjJ = LEIMjJ.psJpCSi8_h7NzZZ1vbR("http_server_status");
    qY = LEIMjJ.psJpCSi8_h7NzZZ1vbR("http_client_path");
    hzEmy = LEIMjJ.psJpCSi8_h7NzZZ1vbR("http_server_path");
    rG8A403wjTaYB6V = LEIMjJ.psJpCSi8_h7NzZZ1vbR("http_client_method");
    D_K6ibTZHL_tOOY3 = LEIMjJ.psJpCSi8_h7NzZZ1vbR("http_server_method");
    Ap4G4fS9phs = LEIMjJ.psJpCSi8_h7NzZZ1vbR("http_server_route");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */