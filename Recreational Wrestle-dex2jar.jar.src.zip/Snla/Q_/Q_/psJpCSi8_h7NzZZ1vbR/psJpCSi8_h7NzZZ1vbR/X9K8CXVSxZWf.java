package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.wktp1mvgWsB4SzZr.DmG0HNQ6;
import javax.annotation.Nullable;

public final class X9K8CXVSxZWf {
  private static final DmG0HNQ6 Ap4G4fS9phs;
  
  private static final DmG0HNQ6 BIRpv;
  
  private static final DmG0HNQ6 D89UfNGBvLPp16h;
  
  private static final DmG0HNQ6 D_K6ibTZHL_tOOY3;
  
  private static final DmG0HNQ6 GUkgqR9XjHnivS;
  
  private static final DmG0HNQ6 LEIMjJ;
  
  private static final DmG0HNQ6 LEwT0cz2WRRZ;
  
  private static final DmG0HNQ6 MxwALnHp3MNCI;
  
  private static final DmG0HNQ6 Q_;
  
  private static final DmG0HNQ6 UptK2mZMIFJk1ivmXYH;
  
  private static final DmG0HNQ6 X9K8CXVSxZWf;
  
  private static final DmG0HNQ6 XV2I8z;
  
  private static final DmG0HNQ6 hzEmy;
  
  private static final DmG0HNQ6 oq9TzoD0;
  
  private static final DmG0HNQ6 psJpCSi8_h7NzZZ1vbR = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Continue");
  
  private static final DmG0HNQ6 qY;
  
  private static final DmG0HNQ6 rG8A403wjTaYB6V;
  
  private static final DmG0HNQ6 wktp1mvgWsB4SzZr;
  
  private static final DmG0HNQ6 wqn;
  
  static {
    Q_ = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Switching Protocols");
    XV2I8z = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Payment Required");
    D89UfNGBvLPp16h = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Method Not Allowed");
    X9K8CXVSxZWf = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Not Acceptable");
    MxwALnHp3MNCI = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Proxy Authentication Required");
    wqn = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Request Time-out");
    wktp1mvgWsB4SzZr = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Conflict");
    BIRpv = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Gone");
    LEIMjJ = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Length Required");
    qY = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Precondition Failed");
    hzEmy = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Request Entity Too Large");
    rG8A403wjTaYB6V = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Request-URI Too Large");
    D_K6ibTZHL_tOOY3 = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Unsupported Media Type");
    Ap4G4fS9phs = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Requested range not satisfiable");
    GUkgqR9XjHnivS = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Expectation Failed");
    oq9TzoD0 = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Internal Server Error");
    LEwT0cz2WRRZ = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("Bad Gateway");
    UptK2mZMIFJk1ivmXYH = DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR("HTTP Version not supported");
  }
  
  public static final DmG0HNQ6 psJpCSi8_h7NzZZ1vbR(int paramInt, @Nullable Throwable paramThrowable) {
    String str;
    if (paramThrowable != null) {
      String str1 = paramThrowable.getMessage();
      str = str1;
      if (str1 == null)
        str = paramThrowable.getClass().getSimpleName(); 
    } else {
      str = null;
    } 
    if (paramInt == 0)
      return DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR(str); 
    if (paramInt >= 200 && paramInt < 400)
      return DmG0HNQ6.psJpCSi8_h7NzZZ1vbR; 
    if (paramInt != 100) {
      if (paramInt != 101) {
        if (paramInt != 429) {
          switch (paramInt) {
            default:
              switch (paramInt) {
                default:
                  return DmG0HNQ6.XV2I8z.psJpCSi8_h7NzZZ1vbR(str);
                case 505:
                  return UptK2mZMIFJk1ivmXYH;
                case 504:
                  return DmG0HNQ6.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(str);
                case 503:
                  return DmG0HNQ6.GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR(str);
                case 502:
                  return LEwT0cz2WRRZ;
                case 501:
                  return DmG0HNQ6.D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR(str);
                case 500:
                  break;
              } 
              return oq9TzoD0;
            case 417:
              return GUkgqR9XjHnivS;
            case 416:
              return Ap4G4fS9phs;
            case 415:
              return D_K6ibTZHL_tOOY3;
            case 414:
              return rG8A403wjTaYB6V;
            case 413:
              return hzEmy;
            case 412:
              return qY;
            case 411:
              return LEIMjJ;
            case 410:
              return BIRpv;
            case 409:
              return wktp1mvgWsB4SzZr;
            case 408:
              return wqn;
            case 407:
              return MxwALnHp3MNCI;
            case 406:
              return X9K8CXVSxZWf;
            case 405:
              return D89UfNGBvLPp16h;
            case 404:
              return DmG0HNQ6.MxwALnHp3MNCI.psJpCSi8_h7NzZZ1vbR(str);
            case 403:
              return DmG0HNQ6.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR(str);
            case 402:
              return XV2I8z;
            case 401:
              return DmG0HNQ6.BIRpv.psJpCSi8_h7NzZZ1vbR(str);
            case 400:
              break;
          } 
          return DmG0HNQ6.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(str);
        } 
        return DmG0HNQ6.LEIMjJ.psJpCSi8_h7NzZZ1vbR(str);
      } 
      return Q_;
    } 
    return psJpCSi8_h7NzZZ1vbR;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */