package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h.D89UfNGBvLPp16h;

public class XV2I8z {
  public static D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR() {
    return new psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */