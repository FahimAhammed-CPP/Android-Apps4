package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;

public final class D89UfNGBvLPp16h {
  public static final String D89UfNGBvLPp16h = "http.method";
  
  public static final String MxwALnHp3MNCI = "http.url";
  
  public static final String Q_ = "http.route";
  
  public static final String X9K8CXVSxZWf = "http.user_agent";
  
  public static final String XV2I8z = "http.path";
  
  public static final String psJpCSi8_h7NzZZ1vbR = "http.host";
  
  public static final String wqn = "http.status_code";
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */