package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.MxwALnHp3MNCI.BkAvsADz8w7ug;
import Snla.Q_.MxwALnHp3MNCI.cN1;
import Snla.Q_.MxwALnHp3MNCI.n4neFNjUxhYqW;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.UnmodifiableIterator;

public final class wqn {
  static final ImmutableSet<BkAvsADz8w7ug> Q_;
  
  static final ImmutableSet<BkAvsADz8w7ug> psJpCSi8_h7NzZZ1vbR = ImmutableSet.of(MxwALnHp3MNCI.wktp1mvgWsB4SzZr, MxwALnHp3MNCI.LEIMjJ, MxwALnHp3MNCI.BIRpv, MxwALnHp3MNCI.qY);
  
  static {
    Q_ = ImmutableSet.of(MxwALnHp3MNCI.D89UfNGBvLPp16h, MxwALnHp3MNCI.MxwALnHp3MNCI, MxwALnHp3MNCI.X9K8CXVSxZWf, MxwALnHp3MNCI.wqn);
  }
  
  public static final void Q_() {
    Q_(n4neFNjUxhYqW.Q_());
  }
  
  static void Q_(cN1 paramcN1) {
    UnmodifiableIterator<BkAvsADz8w7ug> unmodifiableIterator = psJpCSi8_h7NzZZ1vbR.iterator();
    while (unmodifiableIterator.hasNext())
      paramcN1.psJpCSi8_h7NzZZ1vbR(unmodifiableIterator.next()); 
  }
  
  public static final void XV2I8z() {
    XV2I8z(n4neFNjUxhYqW.Q_());
  }
  
  static void XV2I8z(cN1 paramcN1) {
    psJpCSi8_h7NzZZ1vbR(paramcN1);
    Q_(paramcN1);
  }
  
  public static final void psJpCSi8_h7NzZZ1vbR() {
    psJpCSi8_h7NzZZ1vbR(n4neFNjUxhYqW.Q_());
  }
  
  static void psJpCSi8_h7NzZZ1vbR(cN1 paramcN1) {
    UnmodifiableIterator<BkAvsADz8w7ug> unmodifiableIterator = Q_.iterator();
    while (unmodifiableIterator.hasNext())
      paramcN1.psJpCSi8_h7NzZZ1vbR(unmodifiableIterator.next()); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR\wqn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */