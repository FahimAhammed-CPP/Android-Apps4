package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.wktp1mvgWsB4SzZr.AYieGTkN28B_;
import Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h.D89UfNGBvLPp16h;
import Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h.XV2I8z;
import Snla.Q_.wktp1mvgWsB4SzZr.KRly__dqVzGwm1pz;
import Snla.Q_.wktp1mvgWsB4SzZr.bCcldirtq3agvRAiIT;
import Snla.Q_.wktp1mvgWsB4SzZr.emjFZ1;
import Snla.Q_.wktp1mvgWsB4SzZr.n4neFNjUxhYqW;
import com.google.common.base.Preconditions;
import com.google.common.primitives.UnsignedInts;
import com.google.common.primitives.UnsignedLongs;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;

final class psJpCSi8_h7NzZZ1vbR extends D89UfNGBvLPp16h {
  static final int BIRpv = 32;
  
  static final String D89UfNGBvLPp16h = ";o=";
  
  private static final n4neFNjUxhYqW D_K6ibTZHL_tOOY3;
  
  static final int LEIMjJ;
  
  static final String MxwALnHp3MNCI = "0";
  
  static final List<String> Q_ = Collections.singletonList("X-Cloud-Trace-Context");
  
  static final String X9K8CXVSxZWf = "1";
  
  static final char XV2I8z = '/';
  
  static final int hzEmy = 34;
  
  static final String psJpCSi8_h7NzZZ1vbR = "X-Cloud-Trace-Context";
  
  static final int qY = 33;
  
  static final int rG8A403wjTaYB6V = 1;
  
  static final bCcldirtq3agvRAiIT wktp1mvgWsB4SzZr;
  
  static final bCcldirtq3agvRAiIT wqn = bCcldirtq3agvRAiIT.D89UfNGBvLPp16h().psJpCSi8_h7NzZZ1vbR(true).Q_();
  
  static {
    wktp1mvgWsB4SzZr = bCcldirtq3agvRAiIT.Q_;
    LEIMjJ = 3;
    D_K6ibTZHL_tOOY3 = n4neFNjUxhYqW.Q_().psJpCSi8_h7NzZZ1vbR();
  }
  
  private static long psJpCSi8_h7NzZZ1vbR(KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz) {
    ByteBuffer byteBuffer = ByteBuffer.allocate(8);
    byteBuffer.put(paramKRly__dqVzGwm1pz.psJpCSi8_h7NzZZ1vbR());
    return byteBuffer.getLong(0);
  }
  
  private static KRly__dqVzGwm1pz psJpCSi8_h7NzZZ1vbR(long paramLong) {
    ByteBuffer byteBuffer = ByteBuffer.allocate(8);
    byteBuffer.putLong(paramLong);
    return KRly__dqVzGwm1pz.psJpCSi8_h7NzZZ1vbR(byteBuffer.array());
  }
  
  public <C> AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR(C paramC, D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR<C> parampsJpCSi8_h7NzZZ1vbR) throws XV2I8z {
    Preconditions.checkNotNull(paramC, "carrier");
    Preconditions.checkNotNull(parampsJpCSi8_h7NzZZ1vbR, "getter");
    try {
      String str = parampsJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(paramC, "X-Cloud-Trace-Context");
      if (str != null && str.length() >= 34) {
        int i;
        boolean bool;
        if (str.charAt(32) == '/') {
          bool = true;
        } else {
          bool = false;
        } 
        Preconditions.checkArgument(bool, "Invalid TRACE_ID size");
        emjFZ1 emjFZ1 = emjFZ1.psJpCSi8_h7NzZZ1vbR(str.subSequence(0, 32));
        int j = str.indexOf(";o=", 32);
        if (j < 0) {
          i = str.length();
        } else {
          i = j;
        } 
        KRly__dqVzGwm1pz kRly__dqVzGwm1pz = psJpCSi8_h7NzZZ1vbR(UnsignedLongs.parseUnsignedLong(str.subSequence(33, i).toString(), 10));
        bCcldirtq3agvRAiIT bCcldirtq3agvRAiIT2 = wktp1mvgWsB4SzZr;
        bCcldirtq3agvRAiIT bCcldirtq3agvRAiIT1 = bCcldirtq3agvRAiIT2;
        if (j > 0) {
          bCcldirtq3agvRAiIT1 = bCcldirtq3agvRAiIT2;
          if ((UnsignedInts.parseUnsignedInt(str.substring(j + LEIMjJ), 10) & 0x1) != 0)
            bCcldirtq3agvRAiIT1 = wqn; 
        } 
        return AYieGTkN28B_.psJpCSi8_h7NzZZ1vbR(emjFZ1, kRly__dqVzGwm1pz, bCcldirtq3agvRAiIT1, D_K6ibTZHL_tOOY3);
      } 
      throw new XV2I8z("Missing or too short header: X-Cloud-Trace-Context");
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new XV2I8z("Invalid input", illegalArgumentException);
    } 
  }
  
  public List<String> psJpCSi8_h7NzZZ1vbR() {
    return Q_;
  }
  
  public <C> void psJpCSi8_h7NzZZ1vbR(AYieGTkN28B_ paramAYieGTkN28B_, C paramC, D89UfNGBvLPp16h.XV2I8z<C> paramXV2I8z) {
    String str;
    Preconditions.checkNotNull(paramAYieGTkN28B_, "spanContext");
    Preconditions.checkNotNull(paramXV2I8z, "setter");
    Preconditions.checkNotNull(paramC, "carrier");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramAYieGTkN28B_.psJpCSi8_h7NzZZ1vbR().XV2I8z());
    stringBuilder.append('/');
    stringBuilder.append(UnsignedLongs.toString(psJpCSi8_h7NzZZ1vbR(paramAYieGTkN28B_.Q_())));
    stringBuilder.append(";o=");
    if (paramAYieGTkN28B_.XV2I8z().X9K8CXVSxZWf()) {
      str = "1";
    } else {
      str = "0";
    } 
    stringBuilder.append(str);
    paramXV2I8z.put(paramC, "X-Cloud-Trace-Context", stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */