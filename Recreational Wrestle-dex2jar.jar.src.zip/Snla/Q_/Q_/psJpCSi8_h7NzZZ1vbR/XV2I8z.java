package Snla.Q_.Q_.psJpCSi8_h7NzZZ1vbR;

import javax.annotation.Nullable;

public abstract class XV2I8z<Q, P> {
  @Nullable
  public abstract String D89UfNGBvLPp16h(Q paramQ);
  
  @Nullable
  public abstract String MxwALnHp3MNCI(Q paramQ);
  
  @Nullable
  public abstract String Q_(Q paramQ);
  
  @Nullable
  public abstract String X9K8CXVSxZWf(Q paramQ);
  
  @Nullable
  public abstract String XV2I8z(Q paramQ);
  
  @Nullable
  public abstract String psJpCSi8_h7NzZZ1vbR(Q paramQ);
  
  public abstract int wqn(@Nullable P paramP);
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\Q_\psJpCSi8_h7NzZZ1vbR\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */