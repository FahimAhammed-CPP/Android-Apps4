package Snla.Q_.wktp1mvgWsB4SzZr.XV2I8z;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.wktp1mvgWsB4SzZr.D_K6ibTZHL_tOOY3;
import Snla.Q_.wktp1mvgWsB4SzZr.hhkWV822WvWIJ6d;
import Snla.Q_.wktp1mvgWsB4SzZr.jlrPm;

public final class psJpCSi8_h7NzZZ1vbR {
  public static hhkWV822WvWIJ6d Q_(D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3) {
    hhkWV822WvWIJ6d.Q_ q_;
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramD_K6ibTZHL_tOOY3, "event");
    if (paramD_K6ibTZHL_tOOY3 instanceof hhkWV822WvWIJ6d)
      return (hhkWV822WvWIJ6d)paramD_K6ibTZHL_tOOY3; 
    jlrPm jlrPm = (jlrPm)paramD_K6ibTZHL_tOOY3;
    if (jlrPm.psJpCSi8_h7NzZZ1vbR() == jlrPm.Q_.Q_) {
      q_ = hhkWV822WvWIJ6d.Q_.Q_;
    } else {
      q_ = hhkWV822WvWIJ6d.Q_.psJpCSi8_h7NzZZ1vbR;
    } 
    return hhkWV822WvWIJ6d.psJpCSi8_h7NzZZ1vbR(q_, jlrPm.Q_()).Q_(jlrPm.XV2I8z()).XV2I8z(jlrPm.D89UfNGBvLPp16h()).psJpCSi8_h7NzZZ1vbR();
  }
  
  public static jlrPm psJpCSi8_h7NzZZ1vbR(D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3) {
    jlrPm.Q_ q_;
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramD_K6ibTZHL_tOOY3, "event");
    if (paramD_K6ibTZHL_tOOY3 instanceof jlrPm)
      return (jlrPm)paramD_K6ibTZHL_tOOY3; 
    hhkWV822WvWIJ6d hhkWV822WvWIJ6d = (hhkWV822WvWIJ6d)paramD_K6ibTZHL_tOOY3;
    if (hhkWV822WvWIJ6d.Q_() == hhkWV822WvWIJ6d.Q_.Q_) {
      q_ = jlrPm.Q_.Q_;
    } else {
      q_ = jlrPm.Q_.psJpCSi8_h7NzZZ1vbR;
    } 
    return jlrPm.psJpCSi8_h7NzZZ1vbR(q_, hhkWV822WvWIJ6d.XV2I8z()).Q_(hhkWV822WvWIJ6d.D89UfNGBvLPp16h()).XV2I8z(hhkWV822WvWIJ6d.X9K8CXVSxZWf()).psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\XV2I8z\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */