package Snla.Q_.wktp1mvgWsB4SzZr;

import java.util.List;
import java.util.Objects;

final class hzEmy extends n4neFNjUxhYqW {
  private final List<n4neFNjUxhYqW.Q_> psJpCSi8_h7NzZZ1vbR;
  
  hzEmy(List<n4neFNjUxhYqW.Q_> paramList) {
    Objects.requireNonNull(paramList, "Null entries");
    this.psJpCSi8_h7NzZZ1vbR = paramList;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof n4neFNjUxhYqW) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public List<n4neFNjUxhYqW.Q_> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Tracestate{entries=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\hzEmy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */