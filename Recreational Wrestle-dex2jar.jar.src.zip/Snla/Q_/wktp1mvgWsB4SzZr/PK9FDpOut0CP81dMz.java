package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.MxwALnHp3MNCI;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h;
import Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h.Q_;
import Snla.Q_.wktp1mvgWsB4SzZr.Q_.rG8A403wjTaYB6V;
import Snla.Q_.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR.Q_;

public abstract class PK9FDpOut0CP81dMz {
  static PK9FDpOut0CP81dMz MxwALnHp3MNCI() {
    return new psJpCSi8_h7NzZZ1vbR();
  }
  
  public abstract rG8A403wjTaYB6V D89UfNGBvLPp16h();
  
  public abstract Q_ Q_();
  
  public abstract Q_ X9K8CXVSxZWf();
  
  public abstract D89UfNGBvLPp16h XV2I8z();
  
  public abstract Q5BpP92bwE86mpl psJpCSi8_h7NzZZ1vbR();
  
  private static final class psJpCSi8_h7NzZZ1vbR extends PK9FDpOut0CP81dMz {
    private final rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR = rG8A403wjTaYB6V.psJpCSi8_h7NzZZ1vbR();
    
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public rG8A403wjTaYB6V D89UfNGBvLPp16h() {
      return this.psJpCSi8_h7NzZZ1vbR;
    }
    
    public Q_ Q_() {
      return Q_.D89UfNGBvLPp16h();
    }
    
    public Q_ X9K8CXVSxZWf() {
      return Q_.Q_();
    }
    
    public D89UfNGBvLPp16h XV2I8z() {
      return (D89UfNGBvLPp16h)MxwALnHp3MNCI.XV2I8z();
    }
    
    public Q5BpP92bwE86mpl psJpCSi8_h7NzZZ1vbR() {
      return Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\PK9FDpOut0CP81dMz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */