package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.hzEmy;
import Snla.Q_.wktp1mvgWsB4SzZr.MxwALnHp3MNCI.psJpCSi8_h7NzZZ1vbR;
import java.util.concurrent.Callable;
import javax.annotation.Nullable;

final class oq9TzoD0 {
  private static void Q_(fc4RJByVvAciR paramfc4RJByVvAciR, Throwable paramThrowable) {
    String str;
    DmG0HNQ6 dmG0HNQ6 = DmG0HNQ6.XV2I8z;
    if (paramThrowable.getMessage() == null) {
      str = paramThrowable.getClass().getSimpleName();
    } else {
      str = str.getMessage();
    } 
    paramfc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR(dmG0HNQ6.psJpCSi8_h7NzZZ1vbR(str));
  }
  
  static hzEmy psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, boolean paramBoolean) {
    return new XV2I8z(paramfc4RJByVvAciR, paramBoolean);
  }
  
  @Nullable
  static fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_());
  }
  
  static Runnable psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, boolean paramBoolean, Runnable paramRunnable) {
    return new Q_(paramfc4RJByVvAciR, paramRunnable, paramBoolean);
  }
  
  static <C> Callable<C> psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, boolean paramBoolean, Callable<C> paramCallable) {
    return new psJpCSi8_h7NzZZ1vbR<C>(paramfc4RJByVvAciR, paramCallable, paramBoolean);
  }
  
  private static final class Q_ implements Runnable {
    private final Runnable Q_;
    
    private final boolean XV2I8z;
    
    private final fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR;
    
    private Q_(fc4RJByVvAciR param1fc4RJByVvAciR, Runnable param1Runnable, boolean param1Boolean) {
      this.psJpCSi8_h7NzZZ1vbR = param1fc4RJByVvAciR;
      this.Q_ = param1Runnable;
      this.XV2I8z = param1Boolean;
    }
    
    public void run() {
      Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_(), this.psJpCSi8_h7NzZZ1vbR).MxwALnHp3MNCI();
      try {
        this.Q_.run();
        Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_().psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR);
        return;
      } finally {
        null = null;
      } 
    }
  }
  
  private static final class XV2I8z implements hzEmy {
    private final fc4RJByVvAciR Q_;
    
    private final boolean XV2I8z;
    
    private final Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR;
    
    private XV2I8z(fc4RJByVvAciR param1fc4RJByVvAciR, boolean param1Boolean) {
      this.Q_ = param1fc4RJByVvAciR;
      this.XV2I8z = param1Boolean;
      this.psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_(), param1fc4RJByVvAciR).MxwALnHp3MNCI();
    }
    
    public void close() {
      Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_().psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR);
      if (this.XV2I8z)
        this.Q_.psJpCSi8_h7NzZZ1vbR(); 
    }
  }
  
  private static final class psJpCSi8_h7NzZZ1vbR<V> implements Callable<V> {
    private final Callable<V> Q_;
    
    private final boolean XV2I8z;
    
    private final fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR;
    
    private psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR param1fc4RJByVvAciR, Callable<V> param1Callable, boolean param1Boolean) {
      this.psJpCSi8_h7NzZZ1vbR = param1fc4RJByVvAciR;
      this.Q_ = param1Callable;
      this.XV2I8z = param1Boolean;
    }
    
    public V call() throws Exception {
      Exception exception;
      Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_(), this.psJpCSi8_h7NzZZ1vbR).MxwALnHp3MNCI();
      try {
        V v = this.Q_.call();
        Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_().psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR1);
        return v;
      } catch (Exception null) {
        oq9TzoD0.psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR, exception);
        throw exception;
      } finally {
        exception = null;
      } 
      if (this.XV2I8z)
        this.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(); 
      throw exception;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\oq9TzoD0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */