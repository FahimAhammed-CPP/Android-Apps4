package Snla.Q_.wktp1mvgWsB4SzZr;

import java.util.Objects;

final class LEIMjJ extends jlrPm {
  private final long D89UfNGBvLPp16h;
  
  private final long Q_;
  
  private final long XV2I8z;
  
  private final jlrPm.Q_ psJpCSi8_h7NzZZ1vbR;
  
  private LEIMjJ(jlrPm.Q_ paramQ_, long paramLong1, long paramLong2, long paramLong3) {
    this.psJpCSi8_h7NzZZ1vbR = paramQ_;
    this.Q_ = paramLong1;
    this.XV2I8z = paramLong2;
    this.D89UfNGBvLPp16h = paramLong3;
  }
  
  public long D89UfNGBvLPp16h() {
    return this.D89UfNGBvLPp16h;
  }
  
  public long Q_() {
    return this.Q_;
  }
  
  public long XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof jlrPm) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_ == paramObject.Q_() && this.XV2I8z == paramObject.XV2I8z() && this.D89UfNGBvLPp16h == paramObject.D89UfNGBvLPp16h());
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = ((this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003);
    long l2 = this.Q_;
    l1 = ((int)(l1 ^ l2 ^ l2 >>> 32L) * 1000003);
    l2 = this.XV2I8z;
    l1 = ((int)(l1 ^ l2 ^ l2 >>> 32L) * 1000003);
    l2 = this.D89UfNGBvLPp16h;
    return (int)(l1 ^ l2 ^ l2 >>> 32L);
  }
  
  public jlrPm.Q_ psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MessageEvent{type=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", messageId=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", uncompressedMessageSize=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", compressedMessageSize=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class psJpCSi8_h7NzZZ1vbR extends jlrPm.psJpCSi8_h7NzZZ1vbR {
    private Long D89UfNGBvLPp16h;
    
    private Long Q_;
    
    private Long XV2I8z;
    
    private jlrPm.Q_ psJpCSi8_h7NzZZ1vbR;
    
    public jlrPm.psJpCSi8_h7NzZZ1vbR Q_(long param1Long) {
      this.XV2I8z = Long.valueOf(param1Long);
      return this;
    }
    
    public jlrPm.psJpCSi8_h7NzZZ1vbR XV2I8z(long param1Long) {
      this.D89UfNGBvLPp16h = Long.valueOf(param1Long);
      return this;
    }
    
    jlrPm.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(long param1Long) {
      this.Q_ = Long.valueOf(param1Long);
      return this;
    }
    
    jlrPm.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(jlrPm.Q_ param1Q_) {
      Objects.requireNonNull(param1Q_, "Null type");
      this.psJpCSi8_h7NzZZ1vbR = param1Q_;
      return this;
    }
    
    public jlrPm psJpCSi8_h7NzZZ1vbR() {
      jlrPm.Q_ q_ = this.psJpCSi8_h7NzZZ1vbR;
      String str1 = "";
      if (q_ == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("");
        stringBuilder1.append(" type");
        str1 = stringBuilder1.toString();
      } 
      String str2 = str1;
      if (this.Q_ == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append(" messageId");
        str2 = stringBuilder1.toString();
      } 
      str1 = str2;
      if (this.XV2I8z == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str2);
        stringBuilder1.append(" uncompressedMessageSize");
        str1 = stringBuilder1.toString();
      } 
      str2 = str1;
      if (this.D89UfNGBvLPp16h == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append(" compressedMessageSize");
        str2 = stringBuilder1.toString();
      } 
      if (str2.isEmpty())
        return new LEIMjJ(this.psJpCSi8_h7NzZZ1vbR, this.Q_.longValue(), this.XV2I8z.longValue(), this.D89UfNGBvLPp16h.longValue()); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Missing required properties:");
      stringBuilder.append(str2);
      throw new IllegalStateException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\LEIMjJ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */