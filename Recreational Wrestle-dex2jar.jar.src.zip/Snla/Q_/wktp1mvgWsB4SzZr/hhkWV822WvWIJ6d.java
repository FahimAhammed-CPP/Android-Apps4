package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import javax.annotation.Nullable;

@Deprecated
public abstract class hhkWV822WvWIJ6d extends D_K6ibTZHL_tOOY3 {
  public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(Q_ paramQ_, long paramLong) {
    return (new qY.psJpCSi8_h7NzZZ1vbR()).psJpCSi8_h7NzZZ1vbR((Q_)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramQ_, "type")).psJpCSi8_h7NzZZ1vbR(paramLong).Q_(0L).XV2I8z(0L);
  }
  
  public abstract long D89UfNGBvLPp16h();
  
  @Deprecated
  public long MxwALnHp3MNCI() {
    return D89UfNGBvLPp16h();
  }
  
  public abstract Q_ Q_();
  
  public abstract long X9K8CXVSxZWf();
  
  public abstract long XV2I8z();
  
  @Nullable
  public abstract LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR();
  
  public enum Q_ {
    Q_, psJpCSi8_h7NzZZ1vbR;
    
    static {
      Q_ q_1 = new Q_("SENT", 0);
      psJpCSi8_h7NzZZ1vbR = q_1;
      Q_ q_2 = new Q_("RECV", 1);
      Q_ = q_2;
      XV2I8z = new Q_[] { q_1, q_2 };
    }
  }
  
  @Deprecated
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    @Deprecated
    public psJpCSi8_h7NzZZ1vbR D89UfNGBvLPp16h(long param1Long) {
      return Q_(param1Long);
    }
    
    public abstract psJpCSi8_h7NzZZ1vbR Q_(long param1Long);
    
    public abstract psJpCSi8_h7NzZZ1vbR XV2I8z(long param1Long);
    
    abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(long param1Long);
    
    public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(@Nullable LEwT0cz2WRRZ param1LEwT0cz2WRRZ);
    
    abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(hhkWV822WvWIJ6d.Q_ param1Q_);
    
    public abstract hhkWV822WvWIJ6d psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\hhkWV822WvWIJ6d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */