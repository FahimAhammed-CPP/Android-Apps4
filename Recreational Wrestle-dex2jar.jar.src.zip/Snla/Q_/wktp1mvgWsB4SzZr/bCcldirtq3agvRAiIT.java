package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.Arrays;
import javax.annotation.Nullable;

public final class bCcldirtq3agvRAiIT {
  private static final byte D89UfNGBvLPp16h = 1;
  
  public static final bCcldirtq3agvRAiIT Q_ = psJpCSi8_h7NzZZ1vbR((byte)0);
  
  private static final int X9K8CXVSxZWf = 2;
  
  private static final byte XV2I8z = 0;
  
  public static final int psJpCSi8_h7NzZZ1vbR = 1;
  
  private final byte MxwALnHp3MNCI;
  
  private bCcldirtq3agvRAiIT(byte paramByte) {
    this.MxwALnHp3MNCI = paramByte;
  }
  
  public static psJpCSi8_h7NzZZ1vbR D89UfNGBvLPp16h() {
    return new psJpCSi8_h7NzZZ1vbR((byte)0);
  }
  
  public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(bCcldirtq3agvRAiIT parambCcldirtq3agvRAiIT) {
    return new psJpCSi8_h7NzZZ1vbR(parambCcldirtq3agvRAiIT.MxwALnHp3MNCI);
  }
  
  public static bCcldirtq3agvRAiIT psJpCSi8_h7NzZZ1vbR(byte paramByte) {
    return new bCcldirtq3agvRAiIT(paramByte);
  }
  
  public static bCcldirtq3agvRAiIT psJpCSi8_h7NzZZ1vbR(CharSequence paramCharSequence, int paramInt) {
    return new bCcldirtq3agvRAiIT(Ap4G4fS9phs.Q_(paramCharSequence, paramInt));
  }
  
  @Deprecated
  public static bCcldirtq3agvRAiIT psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte) {
    boolean bool;
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, "buffer");
    if (paramArrayOfbyte.length == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Invalid size: expected %s, got %s", new Object[] { Integer.valueOf(1), Integer.valueOf(paramArrayOfbyte.length) });
    return psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte[0]);
  }
  
  @Deprecated
  public static bCcldirtq3agvRAiIT psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte, int paramInt) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramInt, paramArrayOfbyte.length);
    return psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte[paramInt]);
  }
  
  private boolean psJpCSi8_h7NzZZ1vbR(int paramInt) {
    return ((paramInt & this.MxwALnHp3MNCI) != 0);
  }
  
  byte MxwALnHp3MNCI() {
    return this.MxwALnHp3MNCI;
  }
  
  public void Q_(byte[] paramArrayOfbyte, int paramInt) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramInt, paramArrayOfbyte.length);
    paramArrayOfbyte[paramInt] = this.MxwALnHp3MNCI;
  }
  
  @Deprecated
  public byte[] Q_() {
    return new byte[] { this.MxwALnHp3MNCI };
  }
  
  public boolean X9K8CXVSxZWf() {
    return psJpCSi8_h7NzZZ1vbR(1);
  }
  
  public String XV2I8z() {
    char[] arrayOfChar = new char[2];
    psJpCSi8_h7NzZZ1vbR(arrayOfChar, 0);
    return new String(arrayOfChar);
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof bCcldirtq3agvRAiIT))
      return false; 
    paramObject = paramObject;
    return (this.MxwALnHp3MNCI == ((bCcldirtq3agvRAiIT)paramObject).MxwALnHp3MNCI);
  }
  
  public int hashCode() {
    return Arrays.hashCode(new byte[] { this.MxwALnHp3MNCI });
  }
  
  public byte psJpCSi8_h7NzZZ1vbR() {
    return this.MxwALnHp3MNCI;
  }
  
  public void psJpCSi8_h7NzZZ1vbR(char[] paramArrayOfchar, int paramInt) {
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.MxwALnHp3MNCI, paramArrayOfchar, paramInt);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TraceOptions{sampled=");
    stringBuilder.append(X9K8CXVSxZWf());
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public static final class psJpCSi8_h7NzZZ1vbR {
    private byte psJpCSi8_h7NzZZ1vbR;
    
    private psJpCSi8_h7NzZZ1vbR(byte param1Byte) {
      this.psJpCSi8_h7NzZZ1vbR = param1Byte;
    }
    
    public bCcldirtq3agvRAiIT Q_() {
      return bCcldirtq3agvRAiIT.psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR);
    }
    
    @Deprecated
    public psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
      return psJpCSi8_h7NzZZ1vbR(true);
    }
    
    public psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(boolean param1Boolean) {
      if (param1Boolean) {
        this.psJpCSi8_h7NzZZ1vbR = (byte)(this.psJpCSi8_h7NzZZ1vbR | 0x1);
        return this;
      } 
      this.psJpCSi8_h7NzZZ1vbR = (byte)(this.psJpCSi8_h7NzZZ1vbR & 0xFFFFFFFE);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\bCcldirtq3agvRAiIT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */