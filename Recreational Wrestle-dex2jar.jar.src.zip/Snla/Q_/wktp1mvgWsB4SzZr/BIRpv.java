package Snla.Q_.wktp1mvgWsB4SzZr;

import java.util.Map;
import java.util.Objects;

final class BIRpv extends UptK2mZMIFJk1ivmXYH {
  private final Map<String, Q_> D89UfNGBvLPp16h;
  
  private final KRly__dqVzGwm1pz Q_;
  
  private final UptK2mZMIFJk1ivmXYH.psJpCSi8_h7NzZZ1vbR XV2I8z;
  
  private final emjFZ1 psJpCSi8_h7NzZZ1vbR;
  
  BIRpv(emjFZ1 paramemjFZ1, KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz, UptK2mZMIFJk1ivmXYH.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, Map<String, Q_> paramMap) {
    Objects.requireNonNull(paramemjFZ1, "Null traceId");
    this.psJpCSi8_h7NzZZ1vbR = paramemjFZ1;
    Objects.requireNonNull(paramKRly__dqVzGwm1pz, "Null spanId");
    this.Q_ = paramKRly__dqVzGwm1pz;
    Objects.requireNonNull(parampsJpCSi8_h7NzZZ1vbR, "Null type");
    this.XV2I8z = parampsJpCSi8_h7NzZZ1vbR;
    Objects.requireNonNull(paramMap, "Null attributes");
    this.D89UfNGBvLPp16h = paramMap;
  }
  
  public Map<String, Q_> D89UfNGBvLPp16h() {
    return this.D89UfNGBvLPp16h;
  }
  
  public KRly__dqVzGwm1pz Q_() {
    return this.Q_;
  }
  
  public UptK2mZMIFJk1ivmXYH.psJpCSi8_h7NzZZ1vbR XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof UptK2mZMIFJk1ivmXYH) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()) && this.XV2I8z.equals(paramObject.XV2I8z()) && this.D89UfNGBvLPp16h.equals(paramObject.D89UfNGBvLPp16h()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (((this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode()) * 1000003 ^ this.XV2I8z.hashCode()) * 1000003 ^ this.D89UfNGBvLPp16h.hashCode();
  }
  
  public emjFZ1 psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Link{traceId=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", spanId=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", type=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", attributes=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\BIRpv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */