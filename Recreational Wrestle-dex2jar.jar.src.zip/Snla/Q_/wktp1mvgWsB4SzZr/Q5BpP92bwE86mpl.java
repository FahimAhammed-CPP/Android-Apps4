package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.hzEmy;
import java.util.concurrent.Callable;
import javax.annotation.Nullable;

public abstract class Q5BpP92bwE86mpl {
  private static final psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = new psJpCSi8_h7NzZZ1vbR();
  
  static Q5BpP92bwE86mpl psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public final fc4RJByVvAciR Q_() {
    fc4RJByVvAciR fc4RJByVvAciR = oq9TzoD0.psJpCSi8_h7NzZZ1vbR();
    return (fc4RJByVvAciR != null) ? fc4RJByVvAciR : GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR;
  }
  
  public final hzEmy psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR) {
    return oq9TzoD0.psJpCSi8_h7NzZZ1vbR((fc4RJByVvAciR)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, "span"), false);
  }
  
  public final RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(String paramString) {
    return psJpCSi8_h7NzZZ1vbR(paramString, oq9TzoD0.psJpCSi8_h7NzZZ1vbR());
  }
  
  public abstract RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(String paramString, @Nullable AYieGTkN28B_ paramAYieGTkN28B_);
  
  public abstract RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(String paramString, @Nullable fc4RJByVvAciR paramfc4RJByVvAciR);
  
  public final Runnable psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, Runnable paramRunnable) {
    return oq9TzoD0.psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, false, paramRunnable);
  }
  
  public final <C> Callable<C> psJpCSi8_h7NzZZ1vbR(fc4RJByVvAciR paramfc4RJByVvAciR, Callable<C> paramCallable) {
    return oq9TzoD0.psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, false, paramCallable);
  }
  
  private static final class psJpCSi8_h7NzZZ1vbR extends Q5BpP92bwE86mpl {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(String param1String, @Nullable AYieGTkN28B_ param1AYieGTkN28B_) {
      return RiEMPm5KxmvYEOsVplu5.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(param1String, param1AYieGTkN28B_);
    }
    
    public RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(String param1String, @Nullable fc4RJByVvAciR param1fc4RJByVvAciR) {
      return RiEMPm5KxmvYEOsVplu5.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(param1String, param1fc4RJByVvAciR);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q5BpP92bwE86mpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */