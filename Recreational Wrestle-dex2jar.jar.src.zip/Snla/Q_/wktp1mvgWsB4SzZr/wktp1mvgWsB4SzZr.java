package Snla.Q_.wktp1mvgWsB4SzZr;

import javax.annotation.Nullable;

final class wktp1mvgWsB4SzZr extends LEwT0cz2WRRZ {
  private final boolean Q_;
  
  private final DmG0HNQ6 XV2I8z;
  
  private wktp1mvgWsB4SzZr(boolean paramBoolean, @Nullable DmG0HNQ6 paramDmG0HNQ6) {
    this.Q_ = paramBoolean;
    this.XV2I8z = paramDmG0HNQ6;
  }
  
  @Nullable
  public DmG0HNQ6 Q_() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof LEwT0cz2WRRZ) {
      paramObject = paramObject;
      if (this.Q_ == paramObject.psJpCSi8_h7NzZZ1vbR()) {
        DmG0HNQ6 dmG0HNQ6 = this.XV2I8z;
        if (dmG0HNQ6 == null) {
          if (paramObject.Q_() == null)
            return true; 
        } else if (dmG0HNQ6.equals(paramObject.Q_())) {
          return true;
        } 
      } 
      return false;
    } 
    return false;
  }
  
  public int hashCode() {
    char c;
    int i;
    if (this.Q_) {
      c = 'ӏ';
    } else {
      c = 'ӕ';
    } 
    DmG0HNQ6 dmG0HNQ6 = this.XV2I8z;
    if (dmG0HNQ6 == null) {
      i = 0;
    } else {
      i = dmG0HNQ6.hashCode();
    } 
    return (c ^ 0xF4243) * 1000003 ^ i;
  }
  
  public boolean psJpCSi8_h7NzZZ1vbR() {
    return this.Q_;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("EndSpanOptions{sampleToLocalSpanStore=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", status=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class psJpCSi8_h7NzZZ1vbR extends LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR {
    private DmG0HNQ6 Q_;
    
    private Boolean psJpCSi8_h7NzZZ1vbR;
    
    public LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(@Nullable DmG0HNQ6 param1DmG0HNQ6) {
      this.Q_ = param1DmG0HNQ6;
      return this;
    }
    
    public LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(boolean param1Boolean) {
      this.psJpCSi8_h7NzZZ1vbR = Boolean.valueOf(param1Boolean);
      return this;
    }
    
    public LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR() {
      Boolean bool = this.psJpCSi8_h7NzZZ1vbR;
      String str = "";
      if (bool == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("");
        stringBuilder1.append(" sampleToLocalSpanStore");
        str = stringBuilder1.toString();
      } 
      if (str.isEmpty())
        return new wktp1mvgWsB4SzZr(this.psJpCSi8_h7NzZZ1vbR.booleanValue(), this.Q_); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Missing required properties:");
      stringBuilder.append(str);
      throw new IllegalStateException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\wktp1mvgWsB4SzZr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */