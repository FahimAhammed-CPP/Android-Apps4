package Snla.Q_.wktp1mvgWsB4SzZr;

@Deprecated
public abstract class D_K6ibTZHL_tOOY3 {}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\D_K6ibTZHL_tOOY3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */