package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.Random;
import javax.annotation.Nullable;

public final class emjFZ1 implements Comparable<emjFZ1> {
  private static final long D89UfNGBvLPp16h = 0L;
  
  public static final emjFZ1 Q_ = new emjFZ1(0L, 0L);
  
  private static final int XV2I8z = 32;
  
  public static final int psJpCSi8_h7NzZZ1vbR = 16;
  
  private final long MxwALnHp3MNCI;
  
  private final long X9K8CXVSxZWf;
  
  private emjFZ1(long paramLong1, long paramLong2) {
    this.X9K8CXVSxZWf = paramLong1;
    this.MxwALnHp3MNCI = paramLong2;
  }
  
  public static emjFZ1 psJpCSi8_h7NzZZ1vbR(CharSequence paramCharSequence) {
    boolean bool;
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramCharSequence, "src");
    if (paramCharSequence.length() == 32) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Invalid size: expected %s, got %s", new Object[] { Integer.valueOf(32), Integer.valueOf(paramCharSequence.length()) });
    return psJpCSi8_h7NzZZ1vbR(paramCharSequence, 0);
  }
  
  public static emjFZ1 psJpCSi8_h7NzZZ1vbR(CharSequence paramCharSequence, int paramInt) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramCharSequence, "src");
    return new emjFZ1(Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(paramCharSequence, paramInt), Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(paramCharSequence, paramInt + 16));
  }
  
  public static emjFZ1 psJpCSi8_h7NzZZ1vbR(Random paramRandom) {
    long l1;
    long l2;
    do {
      l1 = paramRandom.nextLong();
      l2 = paramRandom.nextLong();
    } while (l1 == 0L && l2 == 0L);
    return new emjFZ1(l1, l2);
  }
  
  public static emjFZ1 psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte) {
    boolean bool;
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, "src");
    if (paramArrayOfbyte.length == 16) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Invalid size: expected %s, got %s", new Object[] { Integer.valueOf(16), Integer.valueOf(paramArrayOfbyte.length) });
    return psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, 0);
  }
  
  public static emjFZ1 psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte, int paramInt) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, "src");
    return new emjFZ1(Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, paramInt), Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, paramInt + 8));
  }
  
  public long D89UfNGBvLPp16h() {
    long l2 = this.X9K8CXVSxZWf;
    long l1 = l2;
    if (l2 < 0L)
      l1 = -l2; 
    return l1;
  }
  
  public void Q_(byte[] paramArrayOfbyte, int paramInt) {
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.X9K8CXVSxZWf, paramArrayOfbyte, paramInt);
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.MxwALnHp3MNCI, paramArrayOfbyte, paramInt + 8);
  }
  
  public boolean Q_() {
    return (this.X9K8CXVSxZWf != 0L || this.MxwALnHp3MNCI != 0L);
  }
  
  public String XV2I8z() {
    char[] arrayOfChar = new char[32];
    psJpCSi8_h7NzZZ1vbR(arrayOfChar, 0);
    return new String(arrayOfChar);
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof emjFZ1))
      return false; 
    paramObject = paramObject;
    return (this.X9K8CXVSxZWf == ((emjFZ1)paramObject).X9K8CXVSxZWf && this.MxwALnHp3MNCI == ((emjFZ1)paramObject).MxwALnHp3MNCI);
  }
  
  public int hashCode() {
    long l = this.X9K8CXVSxZWf;
    int i = (int)(l ^ l >>> 32L);
    l = this.MxwALnHp3MNCI;
    return (i + 31) * 31 + (int)(l >>> 32L ^ l);
  }
  
  public int psJpCSi8_h7NzZZ1vbR(emjFZ1 paramemjFZ1) {
    long l1 = this.X9K8CXVSxZWf;
    long l2 = paramemjFZ1.X9K8CXVSxZWf;
    if (l1 == l2) {
      l1 = this.MxwALnHp3MNCI;
      l2 = paramemjFZ1.MxwALnHp3MNCI;
      return (l1 == l2) ? 0 : ((l1 < l2) ? -1 : 1);
    } 
    return (l1 < l2) ? -1 : 1;
  }
  
  public void psJpCSi8_h7NzZZ1vbR(char[] paramArrayOfchar, int paramInt) {
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.X9K8CXVSxZWf, paramArrayOfchar, paramInt);
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.MxwALnHp3MNCI, paramArrayOfchar, paramInt + 16);
  }
  
  public byte[] psJpCSi8_h7NzZZ1vbR() {
    byte[] arrayOfByte = new byte[16];
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.X9K8CXVSxZWf, arrayOfByte, 0);
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.MxwALnHp3MNCI, arrayOfByte, 8);
    return arrayOfByte;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TraceId{traceId=");
    stringBuilder.append(XV2I8z());
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\emjFZ1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */