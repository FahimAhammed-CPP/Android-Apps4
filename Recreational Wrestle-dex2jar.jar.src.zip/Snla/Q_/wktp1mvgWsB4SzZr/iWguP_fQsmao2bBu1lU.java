package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.XV2I8z;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h;
import Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h.Q_;
import Snla.Q_.wktp1mvgWsB4SzZr.Q_.rG8A403wjTaYB6V;
import Snla.Q_.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR.Q_;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;

public final class iWguP_fQsmao2bBu1lU {
  private static final PK9FDpOut0CP81dMz Q_;
  
  private static final Logger psJpCSi8_h7NzZZ1vbR = Logger.getLogger(iWguP_fQsmao2bBu1lU.class.getName());
  
  static {
    Q_ = psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.class.getClassLoader());
  }
  
  public static rG8A403wjTaYB6V D89UfNGBvLPp16h() {
    return Q_.D89UfNGBvLPp16h();
  }
  
  public static Q_ Q_() {
    return Q_.Q_();
  }
  
  public static Q_ X9K8CXVSxZWf() {
    return Q_.X9K8CXVSxZWf();
  }
  
  public static D89UfNGBvLPp16h XV2I8z() {
    return Q_.XV2I8z();
  }
  
  static PK9FDpOut0CP81dMz psJpCSi8_h7NzZZ1vbR(@Nullable ClassLoader paramClassLoader) {
    try {
      return (PK9FDpOut0CP81dMz)XV2I8z.psJpCSi8_h7NzZZ1vbR(Class.forName("io.opencensus.impl.trace.TraceComponentImpl", true, paramClassLoader), PK9FDpOut0CP81dMz.class);
    } catch (ClassNotFoundException classNotFoundException) {
      psJpCSi8_h7NzZZ1vbR.log(Level.FINE, "Couldn't load full implementation for TraceComponent, now trying to load lite implementation.", classNotFoundException);
      try {
        return (PK9FDpOut0CP81dMz)XV2I8z.psJpCSi8_h7NzZZ1vbR(Class.forName("io.opencensus.impllite.trace.TraceComponentImplLite", true, paramClassLoader), PK9FDpOut0CP81dMz.class);
      } catch (ClassNotFoundException classNotFoundException1) {
        psJpCSi8_h7NzZZ1vbR.log(Level.FINE, "Couldn't load lite implementation for TraceComponent, now using default implementation for TraceComponent.", classNotFoundException1);
        return PK9FDpOut0CP81dMz.MxwALnHp3MNCI();
      } 
    } 
  }
  
  public static Q5BpP92bwE86mpl psJpCSi8_h7NzZZ1vbR() {
    return Q_.psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\iWguP_fQsmao2bBu1lU.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */