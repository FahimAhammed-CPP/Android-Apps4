package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.hzEmy;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.Nullable;

public abstract class RiEMPm5KxmvYEOsVplu5 {
  public final hzEmy Q_() {
    return oq9TzoD0.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR(), true);
  }
  
  public abstract RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(aqqnPTeV paramaqqnPTeV);
  
  public RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(@Nullable fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    return this;
  }
  
  public abstract RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(List<fc4RJByVvAciR> paramList);
  
  public abstract RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(boolean paramBoolean);
  
  public abstract fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR();
  
  public final <V> V psJpCSi8_h7NzZZ1vbR(Callable<V> paramCallable) throws Exception {
    return oq9TzoD0.<V>psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR(), true, paramCallable).call();
  }
  
  public final void psJpCSi8_h7NzZZ1vbR(Runnable paramRunnable) {
    oq9TzoD0.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR(), true, paramRunnable).run();
  }
  
  static final class psJpCSi8_h7NzZZ1vbR extends RiEMPm5KxmvYEOsVplu5 {
    private psJpCSi8_h7NzZZ1vbR(String param1String) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "name");
    }
    
    static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String, @Nullable AYieGTkN28B_ param1AYieGTkN28B_) {
      return new psJpCSi8_h7NzZZ1vbR(param1String);
    }
    
    static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String, @Nullable fc4RJByVvAciR param1fc4RJByVvAciR) {
      return new psJpCSi8_h7NzZZ1vbR(param1String);
    }
    
    public RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(@Nullable aqqnPTeV param1aqqnPTeV) {
      return this;
    }
    
    public RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(@Nullable fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
      return this;
    }
    
    public RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(List<fc4RJByVvAciR> param1List) {
      return this;
    }
    
    public RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(boolean param1Boolean) {
      return this;
    }
    
    public fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR() {
      return GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\RiEMPm5KxmvYEOsVplu5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */