package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import java.util.Objects;

final class X9K8CXVSxZWf extends Ap4G4fS9phs.XV2I8z {
  private final int D89UfNGBvLPp16h;
  
  private final long Q_;
  
  private final long XV2I8z;
  
  private final String psJpCSi8_h7NzZZ1vbR;
  
  X9K8CXVSxZWf(String paramString, long paramLong1, long paramLong2, int paramInt) {
    Objects.requireNonNull(paramString, "Null spanName");
    this.psJpCSi8_h7NzZZ1vbR = paramString;
    this.Q_ = paramLong1;
    this.XV2I8z = paramLong2;
    this.D89UfNGBvLPp16h = paramInt;
  }
  
  public int D89UfNGBvLPp16h() {
    return this.D89UfNGBvLPp16h;
  }
  
  public long Q_() {
    return this.Q_;
  }
  
  public long XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Ap4G4fS9phs.XV2I8z) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_ == paramObject.Q_() && this.XV2I8z == paramObject.XV2I8z() && this.D89UfNGBvLPp16h == paramObject.D89UfNGBvLPp16h());
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = ((this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003);
    long l2 = this.Q_;
    l1 = ((int)(l1 ^ l2 ^ l2 >>> 32L) * 1000003);
    l2 = this.XV2I8z;
    return (int)(l1 ^ l2 ^ l2 >>> 32L) * 1000003 ^ this.D89UfNGBvLPp16h;
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LatencyFilter{spanName=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", latencyLowerNs=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", latencyUpperNs=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", maxSpansToReturn=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */