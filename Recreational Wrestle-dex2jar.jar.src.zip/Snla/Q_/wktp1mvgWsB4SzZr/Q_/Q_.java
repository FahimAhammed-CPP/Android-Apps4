package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

final class Q_ extends D_K6ibTZHL_tOOY3.XV2I8z {
  private final int psJpCSi8_h7NzZZ1vbR;
  
  Q_(int paramInt) {
    this.psJpCSi8_h7NzZZ1vbR = paramInt;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof D_K6ibTZHL_tOOY3.XV2I8z) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR == paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR ^ 0xF4243;
  }
  
  public int psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PerSpanNameSummary{numRunningSpans=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */