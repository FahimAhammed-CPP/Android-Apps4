package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import java.util.Map;
import java.util.Objects;

final class wqn extends Ap4G4fS9phs.MxwALnHp3MNCI {
  private final Map<String, Ap4G4fS9phs.X9K8CXVSxZWf> psJpCSi8_h7NzZZ1vbR;
  
  wqn(Map<String, Ap4G4fS9phs.X9K8CXVSxZWf> paramMap) {
    Objects.requireNonNull(paramMap, "Null perSpanNameSummary");
    this.psJpCSi8_h7NzZZ1vbR = paramMap;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Ap4G4fS9phs.MxwALnHp3MNCI) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public Map<String, Ap4G4fS9phs.X9K8CXVSxZWf> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Summary{perSpanNameSummary=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\wqn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */