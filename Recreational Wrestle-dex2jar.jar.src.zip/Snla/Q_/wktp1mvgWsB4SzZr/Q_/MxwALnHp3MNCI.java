package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import Snla.Q_.wktp1mvgWsB4SzZr.DmG0HNQ6;
import java.util.Map;
import java.util.Objects;

final class MxwALnHp3MNCI extends Ap4G4fS9phs.X9K8CXVSxZWf {
  private final Map<DmG0HNQ6.psJpCSi8_h7NzZZ1vbR, Integer> Q_;
  
  private final Map<Ap4G4fS9phs.Q_, Integer> psJpCSi8_h7NzZZ1vbR;
  
  MxwALnHp3MNCI(Map<Ap4G4fS9phs.Q_, Integer> paramMap, Map<DmG0HNQ6.psJpCSi8_h7NzZZ1vbR, Integer> paramMap1) {
    Objects.requireNonNull(paramMap, "Null numbersOfLatencySampledSpans");
    this.psJpCSi8_h7NzZZ1vbR = paramMap;
    Objects.requireNonNull(paramMap1, "Null numbersOfErrorSampledSpans");
    this.Q_ = paramMap1;
  }
  
  public Map<DmG0HNQ6.psJpCSi8_h7NzZZ1vbR, Integer> Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Ap4G4fS9phs.X9K8CXVSxZWf) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode();
  }
  
  public Map<Ap4G4fS9phs.Q_, Integer> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PerSpanNameSummary{numbersOfLatencySampledSpans=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", numbersOfErrorSampledSpans=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\MxwALnHp3MNCI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */