package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import java.util.Objects;

final class psJpCSi8_h7NzZZ1vbR extends D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR {
  private final int Q_;
  
  private final String psJpCSi8_h7NzZZ1vbR;
  
  psJpCSi8_h7NzZZ1vbR(String paramString, int paramInt) {
    Objects.requireNonNull(paramString, "Null spanName");
    this.psJpCSi8_h7NzZZ1vbR = paramString;
    this.Q_ = paramInt;
  }
  
  public int Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_ == paramObject.Q_());
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_;
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Filter{spanName=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", maxSpansToReturn=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */