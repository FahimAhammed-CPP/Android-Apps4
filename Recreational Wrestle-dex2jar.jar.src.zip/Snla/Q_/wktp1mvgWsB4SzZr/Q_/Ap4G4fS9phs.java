package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import Snla.Q_.wktp1mvgWsB4SzZr.DmG0HNQ6;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

public abstract class Ap4G4fS9phs {
  static Ap4G4fS9phs psJpCSi8_h7NzZZ1vbR() {
    return new D89UfNGBvLPp16h();
  }
  
  public abstract MxwALnHp3MNCI Q_();
  
  @Deprecated
  public abstract void Q_(Collection<String> paramCollection);
  
  public abstract Set<String> XV2I8z();
  
  public abstract Collection<GUkgqR9XjHnivS> psJpCSi8_h7NzZZ1vbR(XV2I8z paramXV2I8z);
  
  public abstract Collection<GUkgqR9XjHnivS> psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR);
  
  @Deprecated
  public abstract void psJpCSi8_h7NzZZ1vbR(Collection<String> paramCollection);
  
  private static final class D89UfNGBvLPp16h extends Ap4G4fS9phs {
    private static final Ap4G4fS9phs.X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR = Ap4G4fS9phs.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(Collections.emptyMap(), Collections.emptyMap());
    
    private final Set<String> Q_ = new HashSet<String>();
    
    private D89UfNGBvLPp16h() {}
    
    public Ap4G4fS9phs.MxwALnHp3MNCI Q_() {
      null = new HashMap<Object, Object>();
      synchronized (this.Q_) {
        Iterator<String> iterator = this.Q_.iterator();
        while (iterator.hasNext())
          null.put(iterator.next(), psJpCSi8_h7NzZZ1vbR); 
        return Ap4G4fS9phs.MxwALnHp3MNCI.psJpCSi8_h7NzZZ1vbR((Map)null);
      } 
    }
    
    public void Q_(Collection<String> param1Collection) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Collection, "spanNames");
      synchronized (this.Q_) {
        this.Q_.removeAll(param1Collection);
        return;
      } 
    }
    
    public Set<String> XV2I8z() {
      synchronized (this.Q_) {
        return (Set)Collections.unmodifiableSet(new HashSet(this.Q_));
      } 
    }
    
    public Collection<GUkgqR9XjHnivS> psJpCSi8_h7NzZZ1vbR(Ap4G4fS9phs.XV2I8z param1XV2I8z) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1XV2I8z, "latencyFilter");
      return Collections.emptyList();
    }
    
    public Collection<GUkgqR9XjHnivS> psJpCSi8_h7NzZZ1vbR(Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1psJpCSi8_h7NzZZ1vbR, "errorFilter");
      return Collections.emptyList();
    }
    
    public void psJpCSi8_h7NzZZ1vbR(Collection<String> param1Collection) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Collection, "spanNames");
      synchronized (this.Q_) {
        this.Q_.addAll(param1Collection);
        return;
      } 
    }
  }
  
  public static abstract class MxwALnHp3MNCI {
    public static MxwALnHp3MNCI psJpCSi8_h7NzZZ1vbR(Map<String, Ap4G4fS9phs.X9K8CXVSxZWf> param1Map) {
      return new wqn(Collections.unmodifiableMap(new HashMap<String, Ap4G4fS9phs.X9K8CXVSxZWf>((Map<? extends String, ? extends Ap4G4fS9phs.X9K8CXVSxZWf>)Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Map, "perSpanNameSummary"))));
    }
    
    public abstract Map<String, Ap4G4fS9phs.X9K8CXVSxZWf> psJpCSi8_h7NzZZ1vbR();
  }
  
  public enum Q_ {
    BIRpv, D89UfNGBvLPp16h, MxwALnHp3MNCI, Q_, X9K8CXVSxZWf, XV2I8z, psJpCSi8_h7NzZZ1vbR, wktp1mvgWsB4SzZr, wqn;
    
    private final long LEIMjJ;
    
    private final long qY;
    
    static {
      Q_ q_1 = new Q_("ZERO_MICROSx10", 0, 0L, TimeUnit.MICROSECONDS.toNanos(10L));
      psJpCSi8_h7NzZZ1vbR = q_1;
      Q_ q_2 = new Q_("MICROSx10_MICROSx100", 1, TimeUnit.MICROSECONDS.toNanos(10L), TimeUnit.MICROSECONDS.toNanos(100L));
      Q_ = q_2;
      Q_ q_3 = new Q_("MICROSx100_MILLIx1", 2, TimeUnit.MICROSECONDS.toNanos(100L), TimeUnit.MILLISECONDS.toNanos(1L));
      XV2I8z = q_3;
      Q_ q_4 = new Q_("MILLIx1_MILLIx10", 3, TimeUnit.MILLISECONDS.toNanos(1L), TimeUnit.MILLISECONDS.toNanos(10L));
      D89UfNGBvLPp16h = q_4;
      Q_ q_5 = new Q_("MILLIx10_MILLIx100", 4, TimeUnit.MILLISECONDS.toNanos(10L), TimeUnit.MILLISECONDS.toNanos(100L));
      X9K8CXVSxZWf = q_5;
      Q_ q_6 = new Q_("MILLIx100_SECONDx1", 5, TimeUnit.MILLISECONDS.toNanos(100L), TimeUnit.SECONDS.toNanos(1L));
      MxwALnHp3MNCI = q_6;
      Q_ q_7 = new Q_("SECONDx1_SECONDx10", 6, TimeUnit.SECONDS.toNanos(1L), TimeUnit.SECONDS.toNanos(10L));
      wqn = q_7;
      Q_ q_8 = new Q_("SECONDx10_SECONDx100", 7, TimeUnit.SECONDS.toNanos(10L), TimeUnit.SECONDS.toNanos(100L));
      wktp1mvgWsB4SzZr = q_8;
      Q_ q_9 = new Q_("SECONDx100_MAX", 8, TimeUnit.SECONDS.toNanos(100L), Long.MAX_VALUE);
      BIRpv = q_9;
      hzEmy = new Q_[] { q_1, q_2, q_3, q_4, q_5, q_6, q_7, q_8, q_9 };
    }
    
    Q_(long param1Long1, long param1Long2) {
      this.LEIMjJ = param1Long1;
      this.qY = param1Long2;
    }
    
    public long Q_() {
      return this.qY;
    }
    
    public long psJpCSi8_h7NzZZ1vbR() {
      return this.LEIMjJ;
    }
  }
  
  public static abstract class X9K8CXVSxZWf {
    public static X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR(Map<Ap4G4fS9phs.Q_, Integer> param1Map, Map<DmG0HNQ6.psJpCSi8_h7NzZZ1vbR, Integer> param1Map1) {
      return new MxwALnHp3MNCI(Collections.unmodifiableMap(new HashMap<Ap4G4fS9phs.Q_, Integer>((Map<? extends Ap4G4fS9phs.Q_, ? extends Integer>)Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Map, "numbersOfLatencySampledSpans"))), Collections.unmodifiableMap(new HashMap<DmG0HNQ6.psJpCSi8_h7NzZZ1vbR, Integer>((Map<? extends DmG0HNQ6.psJpCSi8_h7NzZZ1vbR, ? extends Integer>)Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Map1, "numbersOfErrorSampledSpans"))));
    }
    
    public abstract Map<DmG0HNQ6.psJpCSi8_h7NzZZ1vbR, Integer> Q_();
    
    public abstract Map<Ap4G4fS9phs.Q_, Integer> psJpCSi8_h7NzZZ1vbR();
  }
  
  public static abstract class XV2I8z {
    public static XV2I8z psJpCSi8_h7NzZZ1vbR(String param1String, long param1Long1, long param1Long2, int param1Int) {
      boolean bool1;
      boolean bool2 = true;
      if (param1Int >= 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "Negative maxSpansToReturn.");
      if (param1Long1 >= 0L) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "Negative latencyLowerNs");
      if (param1Long2 >= 0L) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "Negative latencyUpperNs");
      return new X9K8CXVSxZWf(param1String, param1Long1, param1Long2, param1Int);
    }
    
    public abstract int D89UfNGBvLPp16h();
    
    public abstract long Q_();
    
    public abstract long XV2I8z();
    
    public abstract String psJpCSi8_h7NzZZ1vbR();
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String, @Nullable DmG0HNQ6.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR, int param1Int) {
      boolean bool1;
      boolean bool2 = true;
      if (param1psJpCSi8_h7NzZZ1vbR != null) {
        if (param1psJpCSi8_h7NzZZ1vbR != DmG0HNQ6.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "Invalid canonical code.");
      } 
      if (param1Int >= 0) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "Negative maxSpansToReturn.");
      return new D89UfNGBvLPp16h(param1String, param1psJpCSi8_h7NzZZ1vbR, param1Int);
    }
    
    @Nullable
    public abstract DmG0HNQ6.psJpCSi8_h7NzZZ1vbR Q_();
    
    public abstract int XV2I8z();
    
    public abstract String psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\Ap4G4fS9phs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */