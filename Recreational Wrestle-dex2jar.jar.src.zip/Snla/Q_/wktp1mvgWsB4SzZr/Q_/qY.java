package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import java.util.Objects;

final class qY<T> extends GUkgqR9XjHnivS.XV2I8z<T> {
  private final T Q_;
  
  private final LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR;
  
  qY(LEwT0cz2WRRZ paramLEwT0cz2WRRZ, T paramT) {
    Objects.requireNonNull(paramLEwT0cz2WRRZ, "Null timestamp");
    this.psJpCSi8_h7NzZZ1vbR = paramLEwT0cz2WRRZ;
    Objects.requireNonNull(paramT, "Null event");
    this.Q_ = paramT;
  }
  
  public T Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof GUkgqR9XjHnivS.XV2I8z) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode();
  }
  
  public LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TimedEvent{timestamp=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", event=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\qY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */