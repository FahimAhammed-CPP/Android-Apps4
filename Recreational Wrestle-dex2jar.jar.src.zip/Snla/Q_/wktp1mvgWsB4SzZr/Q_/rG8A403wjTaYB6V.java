package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

public abstract class rG8A403wjTaYB6V {
  public static rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR() {
    return new psJpCSi8_h7NzZZ1vbR();
  }
  
  public abstract Ap4G4fS9phs D89UfNGBvLPp16h();
  
  public abstract oq9TzoD0 Q_();
  
  public void X9K8CXVSxZWf() {}
  
  public abstract D_K6ibTZHL_tOOY3 XV2I8z();
  
  private static final class psJpCSi8_h7NzZZ1vbR extends rG8A403wjTaYB6V {
    private final Ap4G4fS9phs psJpCSi8_h7NzZZ1vbR = Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR();
    
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public Ap4G4fS9phs D89UfNGBvLPp16h() {
      return this.psJpCSi8_h7NzZZ1vbR;
    }
    
    public oq9TzoD0 Q_() {
      return oq9TzoD0.psJpCSi8_h7NzZZ1vbR();
    }
    
    public D_K6ibTZHL_tOOY3 XV2I8z() {
      return D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\rG8A403wjTaYB6V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */