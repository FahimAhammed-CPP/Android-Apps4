package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import java.util.Map;
import java.util.Objects;

final class XV2I8z extends D_K6ibTZHL_tOOY3.D89UfNGBvLPp16h {
  private final Map<String, D_K6ibTZHL_tOOY3.XV2I8z> psJpCSi8_h7NzZZ1vbR;
  
  XV2I8z(Map<String, D_K6ibTZHL_tOOY3.XV2I8z> paramMap) {
    Objects.requireNonNull(paramMap, "Null perSpanNameSummary");
    this.psJpCSi8_h7NzZZ1vbR = paramMap;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof D_K6ibTZHL_tOOY3.D89UfNGBvLPp16h) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public Map<String, D_K6ibTZHL_tOOY3.XV2I8z> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Summary{perSpanNameSummary=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */