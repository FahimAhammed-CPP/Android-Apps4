package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import java.util.Collection;

public abstract class oq9TzoD0 {
  private static final oq9TzoD0 psJpCSi8_h7NzZZ1vbR = new Q_();
  
  public static oq9TzoD0 psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public abstract void psJpCSi8_h7NzZZ1vbR(String paramString);
  
  public abstract void psJpCSi8_h7NzZZ1vbR(String paramString, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR);
  
  private static final class Q_ extends oq9TzoD0 {
    private Q_() {}
    
    public void psJpCSi8_h7NzZZ1vbR(String param1String) {}
    
    public void psJpCSi8_h7NzZZ1vbR(String param1String, oq9TzoD0.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {}
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public abstract void psJpCSi8_h7NzZZ1vbR(Collection<GUkgqR9XjHnivS> param1Collection);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\oq9TzoD0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */