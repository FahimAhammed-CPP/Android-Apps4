package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import Snla.Q_.wktp1mvgWsB4SzZr.AYieGTkN28B_;
import Snla.Q_.wktp1mvgWsB4SzZr.D_K6ibTZHL_tOOY3;
import Snla.Q_.wktp1mvgWsB4SzZr.DmG0HNQ6;
import Snla.Q_.wktp1mvgWsB4SzZr.KRly__dqVzGwm1pz;
import Snla.Q_.wktp1mvgWsB4SzZr.UptK2mZMIFJk1ivmXYH;
import Snla.Q_.wktp1mvgWsB4SzZr.fc4RJByVvAciR;
import Snla.Q_.wktp1mvgWsB4SzZr.hhkWV822WvWIJ6d;
import Snla.Q_.wktp1mvgWsB4SzZr.jlrPm;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public abstract class GUkgqR9XjHnivS {
  @Deprecated
  public static GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR(AYieGTkN28B_ paramAYieGTkN28B_, @Nullable KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz, @Nullable Boolean paramBoolean, String paramString, LEwT0cz2WRRZ paramLEwT0cz2WRRZ1, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, D89UfNGBvLPp16h<Snla.Q_.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR> paramD89UfNGBvLPp16h, D89UfNGBvLPp16h<? extends D_K6ibTZHL_tOOY3> paramD89UfNGBvLPp16h1, Q_ paramQ_, @Nullable Integer paramInteger, @Nullable DmG0HNQ6 paramDmG0HNQ6, @Nullable LEwT0cz2WRRZ paramLEwT0cz2WRRZ2) {
    return psJpCSi8_h7NzZZ1vbR(paramAYieGTkN28B_, paramKRly__dqVzGwm1pz, paramBoolean, paramString, null, paramLEwT0cz2WRRZ1, parampsJpCSi8_h7NzZZ1vbR, paramD89UfNGBvLPp16h, paramD89UfNGBvLPp16h1, paramQ_, paramInteger, paramDmG0HNQ6, paramLEwT0cz2WRRZ2);
  }
  
  public static GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR(AYieGTkN28B_ paramAYieGTkN28B_, @Nullable KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz, @Nullable Boolean paramBoolean, String paramString, @Nullable fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, LEwT0cz2WRRZ paramLEwT0cz2WRRZ1, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR1, D89UfNGBvLPp16h<Snla.Q_.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR> paramD89UfNGBvLPp16h, D89UfNGBvLPp16h<? extends D_K6ibTZHL_tOOY3> paramD89UfNGBvLPp16h1, Q_ paramQ_, @Nullable Integer paramInteger, @Nullable DmG0HNQ6 paramDmG0HNQ6, @Nullable LEwT0cz2WRRZ paramLEwT0cz2WRRZ2) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramD89UfNGBvLPp16h1, "messageOrNetworkEvents");
    ArrayList<XV2I8z<D_K6ibTZHL_tOOY3>> arrayList = new ArrayList();
    for (XV2I8z<D_K6ibTZHL_tOOY3> xV2I8z : paramD89UfNGBvLPp16h1.psJpCSi8_h7NzZZ1vbR()) {
      D_K6ibTZHL_tOOY3 d_K6ibTZHL_tOOY3 = xV2I8z.Q_();
      if (d_K6ibTZHL_tOOY3 instanceof jlrPm) {
        arrayList.add(xV2I8z);
        continue;
      } 
      arrayList.add((XV2I8z)XV2I8z.psJpCSi8_h7NzZZ1vbR(xV2I8z.psJpCSi8_h7NzZZ1vbR(), Snla.Q_.wktp1mvgWsB4SzZr.XV2I8z.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(d_K6ibTZHL_tOOY3)));
    } 
    return new wktp1mvgWsB4SzZr(paramAYieGTkN28B_, paramKRly__dqVzGwm1pz, paramBoolean, paramString, parampsJpCSi8_h7NzZZ1vbR, paramLEwT0cz2WRRZ1, parampsJpCSi8_h7NzZZ1vbR1, paramD89UfNGBvLPp16h, (D89UfNGBvLPp16h)D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(arrayList, paramD89UfNGBvLPp16h1.Q_()), paramQ_, paramInteger, paramDmG0HNQ6, paramLEwT0cz2WRRZ2);
  }
  
  public abstract D89UfNGBvLPp16h<jlrPm> BIRpv();
  
  public abstract String D89UfNGBvLPp16h();
  
  @Deprecated
  public D89UfNGBvLPp16h<hhkWV822WvWIJ6d> D_K6ibTZHL_tOOY3() {
    D89UfNGBvLPp16h<jlrPm> d89UfNGBvLPp16h = BIRpv();
    ArrayList<XV2I8z<hhkWV822WvWIJ6d>> arrayList = new ArrayList();
    for (XV2I8z<D_K6ibTZHL_tOOY3> xV2I8z : d89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR())
      arrayList.add(XV2I8z.psJpCSi8_h7NzZZ1vbR(xV2I8z.psJpCSi8_h7NzZZ1vbR(), Snla.Q_.wktp1mvgWsB4SzZr.XV2I8z.psJpCSi8_h7NzZZ1vbR.Q_(xV2I8z.Q_()))); 
    return D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(arrayList, d89UfNGBvLPp16h.Q_());
  }
  
  public abstract Q_ LEIMjJ();
  
  public abstract LEwT0cz2WRRZ MxwALnHp3MNCI();
  
  @Nullable
  public abstract KRly__dqVzGwm1pz Q_();
  
  @Nullable
  public abstract fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR X9K8CXVSxZWf();
  
  @Nullable
  public abstract Boolean XV2I8z();
  
  @Nullable
  public abstract DmG0HNQ6 hzEmy();
  
  public abstract AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR();
  
  @Nullable
  public abstract Integer qY();
  
  @Nullable
  public abstract LEwT0cz2WRRZ rG8A403wjTaYB6V();
  
  public abstract D89UfNGBvLPp16h<Snla.Q_.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR> wktp1mvgWsB4SzZr();
  
  public abstract psJpCSi8_h7NzZZ1vbR wqn();
  
  public static abstract class D89UfNGBvLPp16h<T> {
    public static <T> D89UfNGBvLPp16h<T> psJpCSi8_h7NzZZ1vbR(List<GUkgqR9XjHnivS.XV2I8z<T>> param1List, int param1Int) {
      return new hzEmy<T>(Collections.unmodifiableList(new ArrayList<GUkgqR9XjHnivS.XV2I8z<T>>((Collection<? extends GUkgqR9XjHnivS.XV2I8z<T>>)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List, "events"))), param1Int);
    }
    
    public abstract int Q_();
    
    public abstract List<GUkgqR9XjHnivS.XV2I8z<T>> psJpCSi8_h7NzZZ1vbR();
  }
  
  public static abstract class Q_ {
    public static Q_ psJpCSi8_h7NzZZ1vbR(List<UptK2mZMIFJk1ivmXYH> param1List, int param1Int) {
      return new LEIMjJ(Collections.unmodifiableList(new ArrayList<UptK2mZMIFJk1ivmXYH>((Collection<? extends UptK2mZMIFJk1ivmXYH>)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List, "links"))), param1Int);
    }
    
    public abstract int Q_();
    
    public abstract List<UptK2mZMIFJk1ivmXYH> psJpCSi8_h7NzZZ1vbR();
  }
  
  public static abstract class XV2I8z<T> {
    public static <T> XV2I8z<T> psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ param1LEwT0cz2WRRZ, T param1T) {
      return new qY<T>(param1LEwT0cz2WRRZ, param1T);
    }
    
    public abstract T Q_();
    
    public abstract LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR();
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(Map<String, Snla.Q_.wktp1mvgWsB4SzZr.Q_> param1Map, int param1Int) {
      return new BIRpv(Collections.unmodifiableMap(new HashMap<String, Snla.Q_.wktp1mvgWsB4SzZr.Q_>((Map<? extends String, ? extends Snla.Q_.wktp1mvgWsB4SzZr.Q_>)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Map, "attributeMap"))), param1Int);
    }
    
    public abstract int Q_();
    
    public abstract Map<String, Snla.Q_.wktp1mvgWsB4SzZr.Q_> psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\GUkgqR9XjHnivS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */