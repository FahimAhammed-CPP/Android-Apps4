package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import Snla.Q_.wktp1mvgWsB4SzZr.AYieGTkN28B_;
import Snla.Q_.wktp1mvgWsB4SzZr.DmG0HNQ6;
import Snla.Q_.wktp1mvgWsB4SzZr.KRly__dqVzGwm1pz;
import Snla.Q_.wktp1mvgWsB4SzZr.fc4RJByVvAciR;
import Snla.Q_.wktp1mvgWsB4SzZr.jlrPm;
import Snla.Q_.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR;
import java.util.Objects;
import javax.annotation.Nullable;

final class wktp1mvgWsB4SzZr extends GUkgqR9XjHnivS {
  private final GUkgqR9XjHnivS.D89UfNGBvLPp16h<jlrPm> BIRpv;
  
  private final String D89UfNGBvLPp16h;
  
  private final GUkgqR9XjHnivS.Q_ LEIMjJ;
  
  private final LEwT0cz2WRRZ MxwALnHp3MNCI;
  
  private final KRly__dqVzGwm1pz Q_;
  
  private final fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR X9K8CXVSxZWf;
  
  private final Boolean XV2I8z;
  
  private final DmG0HNQ6 hzEmy;
  
  private final AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR;
  
  private final Integer qY;
  
  private final LEwT0cz2WRRZ rG8A403wjTaYB6V;
  
  private final GUkgqR9XjHnivS.D89UfNGBvLPp16h<psJpCSi8_h7NzZZ1vbR> wktp1mvgWsB4SzZr;
  
  private final GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR wqn;
  
  wktp1mvgWsB4SzZr(AYieGTkN28B_ paramAYieGTkN28B_, @Nullable KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz, @Nullable Boolean paramBoolean, String paramString, @Nullable fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, LEwT0cz2WRRZ paramLEwT0cz2WRRZ1, GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR1, GUkgqR9XjHnivS.D89UfNGBvLPp16h<psJpCSi8_h7NzZZ1vbR> paramD89UfNGBvLPp16h, GUkgqR9XjHnivS.D89UfNGBvLPp16h<jlrPm> paramD89UfNGBvLPp16h1, GUkgqR9XjHnivS.Q_ paramQ_, @Nullable Integer paramInteger, @Nullable DmG0HNQ6 paramDmG0HNQ6, @Nullable LEwT0cz2WRRZ paramLEwT0cz2WRRZ2) {
    Objects.requireNonNull(paramAYieGTkN28B_, "Null context");
    this.psJpCSi8_h7NzZZ1vbR = paramAYieGTkN28B_;
    this.Q_ = paramKRly__dqVzGwm1pz;
    this.XV2I8z = paramBoolean;
    Objects.requireNonNull(paramString, "Null name");
    this.D89UfNGBvLPp16h = paramString;
    this.X9K8CXVSxZWf = parampsJpCSi8_h7NzZZ1vbR;
    Objects.requireNonNull(paramLEwT0cz2WRRZ1, "Null startTimestamp");
    this.MxwALnHp3MNCI = paramLEwT0cz2WRRZ1;
    Objects.requireNonNull(parampsJpCSi8_h7NzZZ1vbR1, "Null attributes");
    this.wqn = parampsJpCSi8_h7NzZZ1vbR1;
    Objects.requireNonNull(paramD89UfNGBvLPp16h, "Null annotations");
    this.wktp1mvgWsB4SzZr = paramD89UfNGBvLPp16h;
    Objects.requireNonNull(paramD89UfNGBvLPp16h1, "Null messageEvents");
    this.BIRpv = paramD89UfNGBvLPp16h1;
    Objects.requireNonNull(paramQ_, "Null links");
    this.LEIMjJ = paramQ_;
    this.qY = paramInteger;
    this.hzEmy = paramDmG0HNQ6;
    this.rG8A403wjTaYB6V = paramLEwT0cz2WRRZ2;
  }
  
  public GUkgqR9XjHnivS.D89UfNGBvLPp16h<jlrPm> BIRpv() {
    return this.BIRpv;
  }
  
  public String D89UfNGBvLPp16h() {
    return this.D89UfNGBvLPp16h;
  }
  
  public GUkgqR9XjHnivS.Q_ LEIMjJ() {
    return this.LEIMjJ;
  }
  
  public LEwT0cz2WRRZ MxwALnHp3MNCI() {
    return this.MxwALnHp3MNCI;
  }
  
  @Nullable
  public KRly__dqVzGwm1pz Q_() {
    return this.Q_;
  }
  
  @Nullable
  public fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR X9K8CXVSxZWf() {
    return this.X9K8CXVSxZWf;
  }
  
  @Nullable
  public Boolean XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof GUkgqR9XjHnivS) {
      paramObject = paramObject;
      if (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR())) {
        KRly__dqVzGwm1pz kRly__dqVzGwm1pz = this.Q_;
        if ((kRly__dqVzGwm1pz == null) ? (paramObject.Q_() == null) : kRly__dqVzGwm1pz.equals(paramObject.Q_())) {
          Boolean bool = this.XV2I8z;
          if (((bool == null) ? (paramObject.XV2I8z() == null) : bool.equals(paramObject.XV2I8z())) && this.D89UfNGBvLPp16h.equals(paramObject.D89UfNGBvLPp16h())) {
            fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = this.X9K8CXVSxZWf;
            if (((psJpCSi8_h7NzZZ1vbR1 == null) ? (paramObject.X9K8CXVSxZWf() == null) : psJpCSi8_h7NzZZ1vbR1.equals(paramObject.X9K8CXVSxZWf())) && this.MxwALnHp3MNCI.equals(paramObject.MxwALnHp3MNCI()) && this.wqn.equals(paramObject.wqn()) && this.wktp1mvgWsB4SzZr.equals(paramObject.wktp1mvgWsB4SzZr()) && this.BIRpv.equals(paramObject.BIRpv()) && this.LEIMjJ.equals(paramObject.LEIMjJ())) {
              Integer integer = this.qY;
              if ((integer == null) ? (paramObject.qY() == null) : integer.equals(paramObject.qY())) {
                DmG0HNQ6 dmG0HNQ6 = this.hzEmy;
                if ((dmG0HNQ6 == null) ? (paramObject.hzEmy() == null) : dmG0HNQ6.equals(paramObject.hzEmy())) {
                  LEwT0cz2WRRZ lEwT0cz2WRRZ = this.rG8A403wjTaYB6V;
                  if (lEwT0cz2WRRZ == null) {
                    if (paramObject.rG8A403wjTaYB6V() == null)
                      return true; 
                  } else if (lEwT0cz2WRRZ.equals(paramObject.rG8A403wjTaYB6V())) {
                    return true;
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
      return false;
    } 
    return false;
  }
  
  public int hashCode() {
    int i;
    int j;
    int k;
    int m;
    int n;
    int i2 = this.psJpCSi8_h7NzZZ1vbR.hashCode();
    KRly__dqVzGwm1pz kRly__dqVzGwm1pz = this.Q_;
    int i1 = 0;
    if (kRly__dqVzGwm1pz == null) {
      i = 0;
    } else {
      i = kRly__dqVzGwm1pz.hashCode();
    } 
    Boolean bool = this.XV2I8z;
    if (bool == null) {
      j = 0;
    } else {
      j = bool.hashCode();
    } 
    int i3 = this.D89UfNGBvLPp16h.hashCode();
    fc4RJByVvAciR.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = this.X9K8CXVSxZWf;
    if (psJpCSi8_h7NzZZ1vbR1 == null) {
      k = 0;
    } else {
      k = psJpCSi8_h7NzZZ1vbR1.hashCode();
    } 
    int i4 = this.MxwALnHp3MNCI.hashCode();
    int i5 = this.wqn.hashCode();
    int i6 = this.wktp1mvgWsB4SzZr.hashCode();
    int i7 = this.BIRpv.hashCode();
    int i8 = this.LEIMjJ.hashCode();
    Integer integer = this.qY;
    if (integer == null) {
      m = 0;
    } else {
      m = integer.hashCode();
    } 
    DmG0HNQ6 dmG0HNQ6 = this.hzEmy;
    if (dmG0HNQ6 == null) {
      n = 0;
    } else {
      n = dmG0HNQ6.hashCode();
    } 
    LEwT0cz2WRRZ lEwT0cz2WRRZ = this.rG8A403wjTaYB6V;
    if (lEwT0cz2WRRZ != null)
      i1 = lEwT0cz2WRRZ.hashCode(); 
    return ((((((((((((i2 ^ 0xF4243) * 1000003 ^ i) * 1000003 ^ j) * 1000003 ^ i3) * 1000003 ^ k) * 1000003 ^ i4) * 1000003 ^ i5) * 1000003 ^ i6) * 1000003 ^ i7) * 1000003 ^ i8) * 1000003 ^ m) * 1000003 ^ n) * 1000003 ^ i1;
  }
  
  @Nullable
  public DmG0HNQ6 hzEmy() {
    return this.hzEmy;
  }
  
  public AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  @Nullable
  public Integer qY() {
    return this.qY;
  }
  
  @Nullable
  public LEwT0cz2WRRZ rG8A403wjTaYB6V() {
    return this.rG8A403wjTaYB6V;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SpanData{context=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", parentSpanId=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", hasRemoteParent=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", name=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append(", kind=");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append(", startTimestamp=");
    stringBuilder.append(this.MxwALnHp3MNCI);
    stringBuilder.append(", attributes=");
    stringBuilder.append(this.wqn);
    stringBuilder.append(", annotations=");
    stringBuilder.append(this.wktp1mvgWsB4SzZr);
    stringBuilder.append(", messageEvents=");
    stringBuilder.append(this.BIRpv);
    stringBuilder.append(", links=");
    stringBuilder.append(this.LEIMjJ);
    stringBuilder.append(", childSpanCount=");
    stringBuilder.append(this.qY);
    stringBuilder.append(", status=");
    stringBuilder.append(this.hzEmy);
    stringBuilder.append(", endTimestamp=");
    stringBuilder.append(this.rG8A403wjTaYB6V);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public GUkgqR9XjHnivS.D89UfNGBvLPp16h<psJpCSi8_h7NzZZ1vbR> wktp1mvgWsB4SzZr() {
    return this.wktp1mvgWsB4SzZr;
  }
  
  public GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR wqn() {
    return this.wqn;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\wktp1mvgWsB4SzZr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */