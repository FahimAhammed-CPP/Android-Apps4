package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import java.util.List;
import java.util.Objects;

final class hzEmy<T> extends GUkgqR9XjHnivS.D89UfNGBvLPp16h<T> {
  private final int Q_;
  
  private final List<GUkgqR9XjHnivS.XV2I8z<T>> psJpCSi8_h7NzZZ1vbR;
  
  hzEmy(List<GUkgqR9XjHnivS.XV2I8z<T>> paramList, int paramInt) {
    Objects.requireNonNull(paramList, "Null events");
    this.psJpCSi8_h7NzZZ1vbR = paramList;
    this.Q_ = paramInt;
  }
  
  public int Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof GUkgqR9XjHnivS.D89UfNGBvLPp16h) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_ == paramObject.Q_());
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_;
  }
  
  public List<GUkgqR9XjHnivS.XV2I8z<T>> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TimedEvents{events=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", droppedEventsCount=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\hzEmy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */