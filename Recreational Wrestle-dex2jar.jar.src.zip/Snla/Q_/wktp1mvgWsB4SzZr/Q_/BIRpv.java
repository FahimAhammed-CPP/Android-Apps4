package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import Snla.Q_.wktp1mvgWsB4SzZr.Q_;
import java.util.Map;
import java.util.Objects;

final class BIRpv extends GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR {
  private final int Q_;
  
  private final Map<String, Q_> psJpCSi8_h7NzZZ1vbR;
  
  BIRpv(Map<String, Q_> paramMap, int paramInt) {
    Objects.requireNonNull(paramMap, "Null attributeMap");
    this.psJpCSi8_h7NzZZ1vbR = paramMap;
    this.Q_ = paramInt;
  }
  
  public int Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_ == paramObject.Q_());
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_;
  }
  
  public Map<String, Q_> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Attributes{attributeMap=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", droppedAttributesCount=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\BIRpv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */