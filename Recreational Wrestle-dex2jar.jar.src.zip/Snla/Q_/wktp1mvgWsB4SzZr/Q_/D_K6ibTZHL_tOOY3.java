package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class D_K6ibTZHL_tOOY3 {
  private static final D_K6ibTZHL_tOOY3 psJpCSi8_h7NzZZ1vbR = new Q_();
  
  static D_K6ibTZHL_tOOY3 psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public abstract D89UfNGBvLPp16h Q_();
  
  public abstract Collection<GUkgqR9XjHnivS> psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR);
  
  public abstract void psJpCSi8_h7NzZZ1vbR(int paramInt);
  
  public static abstract class D89UfNGBvLPp16h {
    public static D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR(Map<String, D_K6ibTZHL_tOOY3.XV2I8z> param1Map) {
      return new XV2I8z(Collections.unmodifiableMap(new HashMap<String, D_K6ibTZHL_tOOY3.XV2I8z>((Map<? extends String, ? extends D_K6ibTZHL_tOOY3.XV2I8z>)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Map, "perSpanNameSummary"))));
    }
    
    public abstract Map<String, D_K6ibTZHL_tOOY3.XV2I8z> psJpCSi8_h7NzZZ1vbR();
  }
  
  private static final class Q_ extends D_K6ibTZHL_tOOY3 {
    private static final D_K6ibTZHL_tOOY3.D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR = D_K6ibTZHL_tOOY3.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(Collections.emptyMap());
    
    private Q_() {}
    
    public D_K6ibTZHL_tOOY3.D89UfNGBvLPp16h Q_() {
      return psJpCSi8_h7NzZZ1vbR;
    }
    
    public Collection<GUkgqR9XjHnivS> psJpCSi8_h7NzZZ1vbR(D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1psJpCSi8_h7NzZZ1vbR, "filter");
      return Collections.emptyList();
    }
    
    public void psJpCSi8_h7NzZZ1vbR(int param1Int) {
      boolean bool;
      if (param1Int >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Invalid negative maxNumberOfElements");
    }
  }
  
  public static abstract class XV2I8z {
    public static XV2I8z psJpCSi8_h7NzZZ1vbR(int param1Int) {
      boolean bool;
      if (param1Int >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Negative numRunningSpans.");
      return new Q_(param1Int);
    }
    
    public abstract int psJpCSi8_h7NzZZ1vbR();
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String, int param1Int) {
      boolean bool;
      if (param1Int >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Negative maxSpansToReturn.");
      return new psJpCSi8_h7NzZZ1vbR(param1String, param1Int);
    }
    
    public abstract int Q_();
    
    public abstract String psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\D_K6ibTZHL_tOOY3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */