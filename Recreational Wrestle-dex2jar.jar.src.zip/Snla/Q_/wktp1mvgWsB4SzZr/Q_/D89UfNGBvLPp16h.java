package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import Snla.Q_.wktp1mvgWsB4SzZr.DmG0HNQ6;
import java.util.Objects;
import javax.annotation.Nullable;

final class D89UfNGBvLPp16h extends Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR {
  private final DmG0HNQ6.psJpCSi8_h7NzZZ1vbR Q_;
  
  private final int XV2I8z;
  
  private final String psJpCSi8_h7NzZZ1vbR;
  
  D89UfNGBvLPp16h(String paramString, @Nullable DmG0HNQ6.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, int paramInt) {
    Objects.requireNonNull(paramString, "Null spanName");
    this.psJpCSi8_h7NzZZ1vbR = paramString;
    this.Q_ = parampsJpCSi8_h7NzZZ1vbR;
    this.XV2I8z = paramInt;
  }
  
  @Nullable
  public DmG0HNQ6.psJpCSi8_h7NzZZ1vbR Q_() {
    return this.Q_;
  }
  
  public int XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      if (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR())) {
        DmG0HNQ6.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = this.Q_;
        if (((psJpCSi8_h7NzZZ1vbR1 == null) ? (paramObject.Q_() == null) : psJpCSi8_h7NzZZ1vbR1.equals(paramObject.Q_())) && this.XV2I8z == paramObject.XV2I8z())
          return true; 
      } 
      return false;
    } 
    return false;
  }
  
  public int hashCode() {
    int i;
    int j = this.psJpCSi8_h7NzZZ1vbR.hashCode();
    DmG0HNQ6.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = this.Q_;
    if (psJpCSi8_h7NzZZ1vbR1 == null) {
      i = 0;
    } else {
      i = psJpCSi8_h7NzZZ1vbR1.hashCode();
    } 
    return ((j ^ 0xF4243) * 1000003 ^ i) * 1000003 ^ this.XV2I8z;
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ErrorFilter{spanName=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", canonicalCode=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", maxSpansToReturn=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */