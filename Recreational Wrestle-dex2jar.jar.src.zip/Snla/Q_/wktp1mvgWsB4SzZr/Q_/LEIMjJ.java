package Snla.Q_.wktp1mvgWsB4SzZr.Q_;

import Snla.Q_.wktp1mvgWsB4SzZr.UptK2mZMIFJk1ivmXYH;
import java.util.List;
import java.util.Objects;

final class LEIMjJ extends GUkgqR9XjHnivS.Q_ {
  private final int Q_;
  
  private final List<UptK2mZMIFJk1ivmXYH> psJpCSi8_h7NzZZ1vbR;
  
  LEIMjJ(List<UptK2mZMIFJk1ivmXYH> paramList, int paramInt) {
    Objects.requireNonNull(paramList, "Null links");
    this.psJpCSi8_h7NzZZ1vbR = paramList;
    this.Q_ = paramInt;
  }
  
  public int Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof GUkgqR9XjHnivS.Q_) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_ == paramObject.Q_());
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_;
  }
  
  public List<UptK2mZMIFJk1ivmXYH> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Links{links=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", droppedLinksCount=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_\LEIMjJ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */