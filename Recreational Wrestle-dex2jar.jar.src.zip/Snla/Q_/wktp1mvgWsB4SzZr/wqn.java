package Snla.Q_.wktp1mvgWsB4SzZr;

import java.util.Objects;

final class wqn extends Q_.D89UfNGBvLPp16h {
  private final String psJpCSi8_h7NzZZ1vbR;
  
  wqn(String paramString) {
    Objects.requireNonNull(paramString, "Null stringValue");
    this.psJpCSi8_h7NzZZ1vbR = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Q_.D89UfNGBvLPp16h) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AttributeValueString{stringValue=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\wqn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */