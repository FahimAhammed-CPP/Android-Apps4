package Snla.Q_.wktp1mvgWsB4SzZr;

import java.util.Objects;

final class rG8A403wjTaYB6V extends n4neFNjUxhYqW.Q_ {
  private final String Q_;
  
  private final String psJpCSi8_h7NzZZ1vbR;
  
  rG8A403wjTaYB6V(String paramString1, String paramString2) {
    Objects.requireNonNull(paramString1, "Null key");
    this.psJpCSi8_h7NzZZ1vbR = paramString1;
    Objects.requireNonNull(paramString2, "Null value");
    this.Q_ = paramString2;
  }
  
  public String Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof n4neFNjUxhYqW.Q_) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode();
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Entry{key=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", value=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\rG8A403wjTaYB6V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */