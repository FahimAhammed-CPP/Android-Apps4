package Snla.Q_.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR;

public abstract class Q_ {
  private static final psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = new psJpCSi8_h7NzZZ1vbR();
  
  public static Q_ Q_() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public abstract XV2I8z psJpCSi8_h7NzZZ1vbR();
  
  public abstract void psJpCSi8_h7NzZZ1vbR(XV2I8z paramXV2I8z);
  
  private static final class psJpCSi8_h7NzZZ1vbR extends Q_ {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public XV2I8z psJpCSi8_h7NzZZ1vbR() {
      return XV2I8z.psJpCSi8_h7NzZZ1vbR;
    }
    
    public void psJpCSi8_h7NzZZ1vbR(XV2I8z param1XV2I8z) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\psJpCSi8_h7NzZZ1vbR\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */