package Snla.Q_.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.wktp1mvgWsB4SzZr.X9K8CXVSxZWf.X9K8CXVSxZWf;
import Snla.Q_.wktp1mvgWsB4SzZr.aqqnPTeV;

public abstract class XV2I8z {
  private static final int D89UfNGBvLPp16h = 32;
  
  private static final int MxwALnHp3MNCI = 128;
  
  private static final double Q_ = 1.0E-4D;
  
  private static final int X9K8CXVSxZWf = 32;
  
  private static final aqqnPTeV XV2I8z;
  
  public static final XV2I8z psJpCSi8_h7NzZZ1vbR;
  
  private static final int wqn = 32;
  
  static {
    aqqnPTeV aqqnPTeV1 = X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(1.0E-4D);
    XV2I8z = aqqnPTeV1;
    psJpCSi8_h7NzZZ1vbR = wktp1mvgWsB4SzZr().psJpCSi8_h7NzZZ1vbR(aqqnPTeV1).psJpCSi8_h7NzZZ1vbR(32).Q_(32).XV2I8z(128).D89UfNGBvLPp16h(32).Q_();
  }
  
  private static psJpCSi8_h7NzZZ1vbR wktp1mvgWsB4SzZr() {
    return new psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR();
  }
  
  public abstract int D89UfNGBvLPp16h();
  
  public abstract psJpCSi8_h7NzZZ1vbR MxwALnHp3MNCI();
  
  public abstract int Q_();
  
  public abstract int X9K8CXVSxZWf();
  
  public abstract int XV2I8z();
  
  public abstract aqqnPTeV psJpCSi8_h7NzZZ1vbR();
  
  @Deprecated
  public int wqn() {
    return D89UfNGBvLPp16h();
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public abstract psJpCSi8_h7NzZZ1vbR D89UfNGBvLPp16h(int param1Int);
    
    public abstract psJpCSi8_h7NzZZ1vbR Q_(int param1Int);
    
    public XV2I8z Q_() {
      boolean bool1;
      XV2I8z xV2I8z = psJpCSi8_h7NzZZ1vbR();
      int i = xV2I8z.Q_();
      boolean bool2 = true;
      if (i > 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "maxNumberOfAttributes");
      if (xV2I8z.XV2I8z() > 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "maxNumberOfAnnotations");
      if (xV2I8z.D89UfNGBvLPp16h() > 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "maxNumberOfMessageEvents");
      if (xV2I8z.X9K8CXVSxZWf() > 0) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "maxNumberOfLinks");
      return xV2I8z;
    }
    
    @Deprecated
    public psJpCSi8_h7NzZZ1vbR X9K8CXVSxZWf(int param1Int) {
      return XV2I8z(param1Int);
    }
    
    public abstract psJpCSi8_h7NzZZ1vbR XV2I8z(int param1Int);
    
    public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(int param1Int);
    
    public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(aqqnPTeV param1aqqnPTeV);
    
    abstract XV2I8z psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\psJpCSi8_h7NzZZ1vbR\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */