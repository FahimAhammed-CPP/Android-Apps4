package Snla.Q_.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.wktp1mvgWsB4SzZr.aqqnPTeV;
import java.util.Objects;

final class psJpCSi8_h7NzZZ1vbR extends XV2I8z {
  private final int D89UfNGBvLPp16h;
  
  private final int MxwALnHp3MNCI;
  
  private final aqqnPTeV Q_;
  
  private final int X9K8CXVSxZWf;
  
  private final int XV2I8z;
  
  private psJpCSi8_h7NzZZ1vbR(aqqnPTeV paramaqqnPTeV, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.Q_ = paramaqqnPTeV;
    this.XV2I8z = paramInt1;
    this.D89UfNGBvLPp16h = paramInt2;
    this.X9K8CXVSxZWf = paramInt3;
    this.MxwALnHp3MNCI = paramInt4;
  }
  
  public int D89UfNGBvLPp16h() {
    return this.X9K8CXVSxZWf;
  }
  
  public XV2I8z.psJpCSi8_h7NzZZ1vbR MxwALnHp3MNCI() {
    return new psJpCSi8_h7NzZZ1vbR(this);
  }
  
  public int Q_() {
    return this.XV2I8z;
  }
  
  public int X9K8CXVSxZWf() {
    return this.MxwALnHp3MNCI;
  }
  
  public int XV2I8z() {
    return this.D89UfNGBvLPp16h;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof XV2I8z) {
      paramObject = paramObject;
      return (this.Q_.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.XV2I8z == paramObject.Q_() && this.D89UfNGBvLPp16h == paramObject.XV2I8z() && this.X9K8CXVSxZWf == paramObject.D89UfNGBvLPp16h() && this.MxwALnHp3MNCI == paramObject.X9K8CXVSxZWf());
    } 
    return false;
  }
  
  public int hashCode() {
    return ((((this.Q_.hashCode() ^ 0xF4243) * 1000003 ^ this.XV2I8z) * 1000003 ^ this.D89UfNGBvLPp16h) * 1000003 ^ this.X9K8CXVSxZWf) * 1000003 ^ this.MxwALnHp3MNCI;
  }
  
  public aqqnPTeV psJpCSi8_h7NzZZ1vbR() {
    return this.Q_;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TraceParams{sampler=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", maxNumberOfAttributes=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", maxNumberOfAnnotations=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append(", maxNumberOfMessageEvents=");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append(", maxNumberOfLinks=");
    stringBuilder.append(this.MxwALnHp3MNCI);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class psJpCSi8_h7NzZZ1vbR extends XV2I8z.psJpCSi8_h7NzZZ1vbR {
    private Integer D89UfNGBvLPp16h;
    
    private Integer Q_;
    
    private Integer X9K8CXVSxZWf;
    
    private Integer XV2I8z;
    
    private aqqnPTeV psJpCSi8_h7NzZZ1vbR;
    
    psJpCSi8_h7NzZZ1vbR() {}
    
    private psJpCSi8_h7NzZZ1vbR(XV2I8z param1XV2I8z) {
      this.psJpCSi8_h7NzZZ1vbR = param1XV2I8z.psJpCSi8_h7NzZZ1vbR();
      this.Q_ = Integer.valueOf(param1XV2I8z.Q_());
      this.XV2I8z = Integer.valueOf(param1XV2I8z.XV2I8z());
      this.D89UfNGBvLPp16h = Integer.valueOf(param1XV2I8z.D89UfNGBvLPp16h());
      this.X9K8CXVSxZWf = Integer.valueOf(param1XV2I8z.X9K8CXVSxZWf());
    }
    
    public XV2I8z.psJpCSi8_h7NzZZ1vbR D89UfNGBvLPp16h(int param1Int) {
      this.X9K8CXVSxZWf = Integer.valueOf(param1Int);
      return this;
    }
    
    public XV2I8z.psJpCSi8_h7NzZZ1vbR Q_(int param1Int) {
      this.XV2I8z = Integer.valueOf(param1Int);
      return this;
    }
    
    public XV2I8z.psJpCSi8_h7NzZZ1vbR XV2I8z(int param1Int) {
      this.D89UfNGBvLPp16h = Integer.valueOf(param1Int);
      return this;
    }
    
    public XV2I8z.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(int param1Int) {
      this.Q_ = Integer.valueOf(param1Int);
      return this;
    }
    
    public XV2I8z.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(aqqnPTeV param1aqqnPTeV) {
      Objects.requireNonNull(param1aqqnPTeV, "Null sampler");
      this.psJpCSi8_h7NzZZ1vbR = param1aqqnPTeV;
      return this;
    }
    
    XV2I8z psJpCSi8_h7NzZZ1vbR() {
      aqqnPTeV aqqnPTeV1 = this.psJpCSi8_h7NzZZ1vbR;
      String str1 = "";
      if (aqqnPTeV1 == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("");
        stringBuilder1.append(" sampler");
        str1 = stringBuilder1.toString();
      } 
      String str2 = str1;
      if (this.Q_ == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append(" maxNumberOfAttributes");
        str2 = stringBuilder1.toString();
      } 
      str1 = str2;
      if (this.XV2I8z == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str2);
        stringBuilder1.append(" maxNumberOfAnnotations");
        str1 = stringBuilder1.toString();
      } 
      str2 = str1;
      if (this.D89UfNGBvLPp16h == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append(" maxNumberOfMessageEvents");
        str2 = stringBuilder1.toString();
      } 
      str1 = str2;
      if (this.X9K8CXVSxZWf == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str2);
        stringBuilder1.append(" maxNumberOfLinks");
        str1 = stringBuilder1.toString();
      } 
      if (str1.isEmpty())
        return new psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR, this.Q_.intValue(), this.XV2I8z.intValue(), this.D89UfNGBvLPp16h.intValue(), this.X9K8CXVSxZWf.intValue()); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Missing required properties:");
      stringBuilder.append(str1);
      throw new IllegalStateException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */