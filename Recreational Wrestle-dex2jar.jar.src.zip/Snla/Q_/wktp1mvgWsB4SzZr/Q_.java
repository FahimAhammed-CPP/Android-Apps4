package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn;

public abstract class Q_ {
  public static Q_ psJpCSi8_h7NzZZ1vbR(double paramDouble) {
    return Q_.psJpCSi8_h7NzZZ1vbR(Double.valueOf(paramDouble));
  }
  
  public static Q_ psJpCSi8_h7NzZZ1vbR(long paramLong) {
    return XV2I8z.psJpCSi8_h7NzZZ1vbR(Long.valueOf(paramLong));
  }
  
  public static Q_ psJpCSi8_h7NzZZ1vbR(String paramString) {
    return D89UfNGBvLPp16h.Q_(paramString);
  }
  
  public static Q_ psJpCSi8_h7NzZZ1vbR(boolean paramBoolean) {
    return psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(Boolean.valueOf(paramBoolean));
  }
  
  @Deprecated
  public abstract <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> paramwqn, wqn<? super Boolean, T> paramwqn1, wqn<? super Long, T> paramwqn2, wqn<Object, T> paramwqn3);
  
  public abstract <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> paramwqn, wqn<? super Boolean, T> paramwqn1, wqn<? super Long, T> paramwqn2, wqn<? super Double, T> paramwqn3, wqn<Object, T> paramwqn4);
  
  static abstract class D89UfNGBvLPp16h extends Q_ {
    static Q_ Q_(String param1String) {
      return new wqn((String)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "stringValue"));
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> param1wqn, wqn<? super Boolean, T> param1wqn1, wqn<? super Long, T> param1wqn2, wqn<Object, T> param1wqn3) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> param1wqn, wqn<? super Boolean, T> param1wqn1, wqn<? super Long, T> param1wqn2, wqn<? super Double, T> param1wqn3, wqn<Object, T> param1wqn4) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
    
    abstract String psJpCSi8_h7NzZZ1vbR();
  }
  
  static abstract class Q_ extends Q_ {
    static Q_ psJpCSi8_h7NzZZ1vbR(Double param1Double) {
      return new X9K8CXVSxZWf((Double)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Double, "doubleValue"));
    }
    
    abstract Double psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> param1wqn, wqn<? super Boolean, T> param1wqn1, wqn<? super Long, T> param1wqn2, wqn<Object, T> param1wqn3) {
      return (T)param1wqn3.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> param1wqn, wqn<? super Boolean, T> param1wqn1, wqn<? super Long, T> param1wqn2, wqn<? super Double, T> param1wqn3, wqn<Object, T> param1wqn4) {
      return (T)param1wqn3.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
  }
  
  static abstract class XV2I8z extends Q_ {
    static Q_ psJpCSi8_h7NzZZ1vbR(Long param1Long) {
      return new MxwALnHp3MNCI((Long)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Long, "longValue"));
    }
    
    abstract Long psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> param1wqn, wqn<? super Boolean, T> param1wqn1, wqn<? super Long, T> param1wqn2, wqn<Object, T> param1wqn3) {
      return (T)param1wqn2.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> param1wqn, wqn<? super Boolean, T> param1wqn1, wqn<? super Long, T> param1wqn2, wqn<? super Double, T> param1wqn3, wqn<Object, T> param1wqn4) {
      return (T)param1wqn2.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
  }
  
  static abstract class psJpCSi8_h7NzZZ1vbR extends Q_ {
    static Q_ psJpCSi8_h7NzZZ1vbR(Boolean param1Boolean) {
      return new D89UfNGBvLPp16h((Boolean)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Boolean, "booleanValue"));
    }
    
    abstract Boolean psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> param1wqn, wqn<? super Boolean, T> param1wqn1, wqn<? super Long, T> param1wqn2, wqn<Object, T> param1wqn3) {
      return (T)param1wqn1.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super String, T> param1wqn, wqn<? super Boolean, T> param1wqn1, wqn<? super Long, T> param1wqn2, wqn<? super Double, T> param1wqn3, wqn<Object, T> param1wqn4) {
      return (T)param1wqn1.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */