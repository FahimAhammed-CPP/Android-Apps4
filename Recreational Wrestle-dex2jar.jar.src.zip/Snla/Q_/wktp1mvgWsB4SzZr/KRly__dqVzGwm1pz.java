package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.Random;
import javax.annotation.Nullable;

public final class KRly__dqVzGwm1pz implements Comparable<KRly__dqVzGwm1pz> {
  private static final long D89UfNGBvLPp16h = 0L;
  
  public static final KRly__dqVzGwm1pz Q_ = new KRly__dqVzGwm1pz(0L);
  
  private static final int XV2I8z = 16;
  
  public static final int psJpCSi8_h7NzZZ1vbR = 8;
  
  private final long X9K8CXVSxZWf;
  
  private KRly__dqVzGwm1pz(long paramLong) {
    this.X9K8CXVSxZWf = paramLong;
  }
  
  public static KRly__dqVzGwm1pz psJpCSi8_h7NzZZ1vbR(CharSequence paramCharSequence) {
    boolean bool;
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramCharSequence, "src");
    if (paramCharSequence.length() == 16) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Invalid size: expected %s, got %s", new Object[] { Integer.valueOf(16), Integer.valueOf(paramCharSequence.length()) });
    return psJpCSi8_h7NzZZ1vbR(paramCharSequence, 0);
  }
  
  public static KRly__dqVzGwm1pz psJpCSi8_h7NzZZ1vbR(CharSequence paramCharSequence, int paramInt) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramCharSequence, "src");
    return new KRly__dqVzGwm1pz(Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(paramCharSequence, paramInt));
  }
  
  public static KRly__dqVzGwm1pz psJpCSi8_h7NzZZ1vbR(Random paramRandom) {
    while (true) {
      long l = paramRandom.nextLong();
      if (l != 0L)
        return new KRly__dqVzGwm1pz(l); 
    } 
  }
  
  public static KRly__dqVzGwm1pz psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte) {
    boolean bool;
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, "src");
    if (paramArrayOfbyte.length == 8) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Invalid size: expected %s, got %s", new Object[] { Integer.valueOf(8), Integer.valueOf(paramArrayOfbyte.length) });
    return psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, 0);
  }
  
  public static KRly__dqVzGwm1pz psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte, int paramInt) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, "src");
    return new KRly__dqVzGwm1pz(Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte, paramInt));
  }
  
  public void Q_(byte[] paramArrayOfbyte, int paramInt) {
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.X9K8CXVSxZWf, paramArrayOfbyte, paramInt);
  }
  
  public boolean Q_() {
    return (this.X9K8CXVSxZWf != 0L);
  }
  
  public String XV2I8z() {
    char[] arrayOfChar = new char[16];
    psJpCSi8_h7NzZZ1vbR(arrayOfChar, 0);
    return new String(arrayOfChar);
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof KRly__dqVzGwm1pz))
      return false; 
    paramObject = paramObject;
    return (this.X9K8CXVSxZWf == ((KRly__dqVzGwm1pz)paramObject).X9K8CXVSxZWf);
  }
  
  public int hashCode() {
    long l = this.X9K8CXVSxZWf;
    return (int)(l ^ l >>> 32L);
  }
  
  public int psJpCSi8_h7NzZZ1vbR(KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz) {
    long l1 = this.X9K8CXVSxZWf;
    long l2 = paramKRly__dqVzGwm1pz.X9K8CXVSxZWf;
    return (l1 < l2) ? -1 : ((l1 == l2) ? 0 : 1);
  }
  
  public void psJpCSi8_h7NzZZ1vbR(char[] paramArrayOfchar, int paramInt) {
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.X9K8CXVSxZWf, paramArrayOfchar, paramInt);
  }
  
  public byte[] psJpCSi8_h7NzZZ1vbR() {
    byte[] arrayOfByte = new byte[8];
    Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR(this.X9K8CXVSxZWf, arrayOfByte, 0);
    return arrayOfByte;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SpanId{spanId=");
    stringBuilder.append(XV2I8z());
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\KRly__dqVzGwm1pz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */