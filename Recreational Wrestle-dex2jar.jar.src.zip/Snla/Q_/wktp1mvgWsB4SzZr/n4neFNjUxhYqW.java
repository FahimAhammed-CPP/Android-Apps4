package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;

public abstract class n4neFNjUxhYqW {
  private static final int Q_ = 256;
  
  private static final int XV2I8z = 32;
  
  private static final int psJpCSi8_h7NzZZ1vbR = 256;
  
  private static boolean D89UfNGBvLPp16h(String paramString) {
    if (paramString.length() <= 256 && !paramString.isEmpty() && paramString.charAt(0) >= 'a') {
      if (paramString.charAt(0) > 'z')
        return false; 
      for (int i = 1; i < paramString.length(); i++) {
        char c = paramString.charAt(i);
        if ((c < 'a' || c > 'z') && (c < '0' || c > '9') && c != '_' && c != '-' && c != '*' && c != '/')
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  public static psJpCSi8_h7NzZZ1vbR Q_() {
    return new psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR.Q_());
  }
  
  private static n4neFNjUxhYqW Q_(List<Q_> paramList) {
    boolean bool;
    if (paramList.size() <= 32) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.Q_(bool, "Invalid size");
    return new hzEmy(Collections.unmodifiableList(paramList));
  }
  
  private static boolean X9K8CXVSxZWf(String paramString) {
    if (paramString.length() <= 256) {
      if (paramString.charAt(paramString.length() - 1) == ' ')
        return false; 
      int i = 0;
      while (i < paramString.length()) {
        char c = paramString.charAt(i);
        if (c != ',' && c != '=' && c >= ' ') {
          if (c > '~')
            return false; 
          i++;
          continue;
        } 
        return false;
      } 
      return true;
    } 
    return false;
  }
  
  public psJpCSi8_h7NzZZ1vbR XV2I8z() {
    return new psJpCSi8_h7NzZZ1vbR(this);
  }
  
  @Nullable
  public String psJpCSi8_h7NzZZ1vbR(String paramString) {
    for (Q_ q_ : psJpCSi8_h7NzZZ1vbR()) {
      if (q_.psJpCSi8_h7NzZZ1vbR().equals(paramString))
        return q_.Q_(); 
    } 
    return null;
  }
  
  public abstract List<Q_> psJpCSi8_h7NzZZ1vbR();
  
  public static abstract class Q_ {
    public static Q_ psJpCSi8_h7NzZZ1vbR(String param1String1, String param1String2) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String1, "key");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String2, "value");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(n4neFNjUxhYqW.Q_(param1String1), "Invalid key %s", new Object[] { param1String1 });
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(n4neFNjUxhYqW.XV2I8z(param1String2), "Invalid value %s", new Object[] { param1String2 });
      return new rG8A403wjTaYB6V(param1String1, param1String2);
    }
    
    public abstract String Q_();
    
    public abstract String psJpCSi8_h7NzZZ1vbR();
  }
  
  public static final class psJpCSi8_h7NzZZ1vbR {
    private static final n4neFNjUxhYqW XV2I8z = n4neFNjUxhYqW.psJpCSi8_h7NzZZ1vbR(Collections.emptyList());
    
    @Nullable
    private ArrayList<n4neFNjUxhYqW.Q_> Q_;
    
    private final n4neFNjUxhYqW psJpCSi8_h7NzZZ1vbR;
    
    private psJpCSi8_h7NzZZ1vbR(n4neFNjUxhYqW param1n4neFNjUxhYqW) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1n4neFNjUxhYqW, "parent");
      this.psJpCSi8_h7NzZZ1vbR = param1n4neFNjUxhYqW;
      this.Q_ = null;
    }
    
    public psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "key");
      if (this.Q_ == null)
        this.Q_ = new ArrayList<n4neFNjUxhYqW.Q_>(this.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR()); 
      for (int i = 0; i < this.Q_.size(); i++) {
        if (((n4neFNjUxhYqW.Q_)this.Q_.get(i)).psJpCSi8_h7NzZZ1vbR().equals(param1String)) {
          this.Q_.remove(i);
          return this;
        } 
      } 
      return this;
    }
    
    public psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String1, String param1String2) {
      n4neFNjUxhYqW.Q_ q_ = n4neFNjUxhYqW.Q_.psJpCSi8_h7NzZZ1vbR(param1String1, param1String2);
      if (this.Q_ == null)
        this.Q_ = new ArrayList<n4neFNjUxhYqW.Q_>(this.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR()); 
      for (int i = 0; i < this.Q_.size(); i++) {
        if (((n4neFNjUxhYqW.Q_)this.Q_.get(i)).psJpCSi8_h7NzZZ1vbR().equals(q_.psJpCSi8_h7NzZZ1vbR())) {
          this.Q_.remove(i);
          break;
        } 
      } 
      this.Q_.add(0, q_);
      return this;
    }
    
    public n4neFNjUxhYqW psJpCSi8_h7NzZZ1vbR() {
      ArrayList<n4neFNjUxhYqW.Q_> arrayList = this.Q_;
      return (arrayList == null) ? this.psJpCSi8_h7NzZZ1vbR : n4neFNjUxhYqW.psJpCSi8_h7NzZZ1vbR(arrayList);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\n4neFNjUxhYqW.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */