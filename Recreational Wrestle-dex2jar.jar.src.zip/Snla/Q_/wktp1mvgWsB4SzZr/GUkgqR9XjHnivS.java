package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.Map;

public final class GUkgqR9XjHnivS extends fc4RJByVvAciR {
  public static final GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR = new GUkgqR9XjHnivS();
  
  private GUkgqR9XjHnivS() {
    super(AYieGTkN28B_.psJpCSi8_h7NzZZ1vbR, null);
  }
  
  public void psJpCSi8_h7NzZZ1vbR(DmG0HNQ6 paramDmG0HNQ6) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramDmG0HNQ6, "status");
  }
  
  public void psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramLEwT0cz2WRRZ, "options");
  }
  
  public void psJpCSi8_h7NzZZ1vbR(UptK2mZMIFJk1ivmXYH paramUptK2mZMIFJk1ivmXYH) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramUptK2mZMIFJk1ivmXYH, "link");
  }
  
  @Deprecated
  public void psJpCSi8_h7NzZZ1vbR(hhkWV822WvWIJ6d paramhhkWV822WvWIJ6d) {}
  
  public void psJpCSi8_h7NzZZ1vbR(jlrPm paramjlrPm) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramjlrPm, "messageEvent");
  }
  
  public void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR, "annotation");
  }
  
  public void psJpCSi8_h7NzZZ1vbR(String paramString, Q_ paramQ_) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramString, "key");
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramQ_, "value");
  }
  
  public void psJpCSi8_h7NzZZ1vbR(String paramString, Map<String, Q_> paramMap) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramString, "description");
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramMap, "attributes");
  }
  
  public void psJpCSi8_h7NzZZ1vbR(Map<String, Q_> paramMap) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramMap, "attributes");
  }
  
  public String toString() {
    return "BlankSpan";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\GUkgqR9XjHnivS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */