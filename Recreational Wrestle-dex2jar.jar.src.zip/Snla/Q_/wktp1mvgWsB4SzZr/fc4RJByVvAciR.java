package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.wktp1mvgWsB4SzZr.XV2I8z.psJpCSi8_h7NzZZ1vbR;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;

public abstract class fc4RJByVvAciR {
  private static final Set<Q_> D89UfNGBvLPp16h;
  
  private static final Map<String, Q_> psJpCSi8_h7NzZZ1vbR = Collections.emptyMap();
  
  private final AYieGTkN28B_ Q_;
  
  private final Set<Q_> XV2I8z;
  
  static {
    D89UfNGBvLPp16h = Collections.unmodifiableSet(EnumSet.noneOf(Q_.class));
  }
  
  protected fc4RJByVvAciR(AYieGTkN28B_ paramAYieGTkN28B_, @Nullable EnumSet<Q_> paramEnumSet) {
    Set<Q_> set;
    boolean bool;
    this.Q_ = (AYieGTkN28B_)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramAYieGTkN28B_, "context");
    if (paramEnumSet == null) {
      set = D89UfNGBvLPp16h;
    } else {
      set = Collections.unmodifiableSet(EnumSet.copyOf((EnumSet<? extends Q_>)set));
    } 
    this.XV2I8z = set;
    if (!paramAYieGTkN28B_.XV2I8z().X9K8CXVSxZWf() || set.contains(Q_.psJpCSi8_h7NzZZ1vbR)) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Span is sampled, but does not have RECORD_EVENTS set.");
  }
  
  public final AYieGTkN28B_ Q_() {
    return this.Q_;
  }
  
  @Deprecated
  public void Q_(Map<String, Q_> paramMap) {
    psJpCSi8_h7NzZZ1vbR(paramMap);
  }
  
  public final Set<Q_> XV2I8z() {
    return this.XV2I8z;
  }
  
  public final void psJpCSi8_h7NzZZ1vbR() {
    psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR);
  }
  
  public void psJpCSi8_h7NzZZ1vbR(DmG0HNQ6 paramDmG0HNQ6) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramDmG0HNQ6, "status");
  }
  
  public abstract void psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ paramLEwT0cz2WRRZ);
  
  public abstract void psJpCSi8_h7NzZZ1vbR(UptK2mZMIFJk1ivmXYH paramUptK2mZMIFJk1ivmXYH);
  
  @Deprecated
  public void psJpCSi8_h7NzZZ1vbR(hhkWV822WvWIJ6d paramhhkWV822WvWIJ6d) {
    psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(paramhhkWV822WvWIJ6d));
  }
  
  public void psJpCSi8_h7NzZZ1vbR(jlrPm paramjlrPm) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramjlrPm, "messageEvent");
    psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR.Q_(paramjlrPm));
  }
  
  public abstract void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR);
  
  public final void psJpCSi8_h7NzZZ1vbR(String paramString) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramString, "description");
    psJpCSi8_h7NzZZ1vbR(paramString, psJpCSi8_h7NzZZ1vbR);
  }
  
  public void psJpCSi8_h7NzZZ1vbR(String paramString, Q_ paramQ_) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramString, "key");
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramQ_, "value");
    psJpCSi8_h7NzZZ1vbR(Collections.singletonMap(paramString, paramQ_));
  }
  
  public abstract void psJpCSi8_h7NzZZ1vbR(String paramString, Map<String, Q_> paramMap);
  
  public void psJpCSi8_h7NzZZ1vbR(Map<String, Q_> paramMap) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramMap, "attributes");
    Q_(paramMap);
  }
  
  public enum Q_ {
    psJpCSi8_h7NzZZ1vbR;
    
    static {
      Q_ q_ = new Q_("RECORD_EVENTS", 0);
      psJpCSi8_h7NzZZ1vbR = q_;
      Q_ = new Q_[] { q_ };
    }
  }
  
  public enum psJpCSi8_h7NzZZ1vbR {
    Q_, psJpCSi8_h7NzZZ1vbR;
    
    static {
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = new psJpCSi8_h7NzZZ1vbR("SERVER", 0);
      psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR1;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR2 = new psJpCSi8_h7NzZZ1vbR("CLIENT", 1);
      Q_ = psJpCSi8_h7NzZZ1vbR2;
      XV2I8z = new psJpCSi8_h7NzZZ1vbR[] { psJpCSi8_h7NzZZ1vbR1, psJpCSi8_h7NzZZ1vbR2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\fc4RJByVvAciR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */