package Snla.Q_.wktp1mvgWsB4SzZr.MxwALnHp3MNCI;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.wktp1mvgWsB4SzZr.GUkgqR9XjHnivS;
import Snla.Q_.wktp1mvgWsB4SzZr.fc4RJByVvAciR;
import javax.annotation.Nullable;

public final class psJpCSi8_h7NzZZ1vbR {
  private static final Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.BIRpv<fc4RJByVvAciR> psJpCSi8_h7NzZZ1vbR = Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR("opencensus-trace-span-key");
  
  public static fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR(Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    GUkgqR9XjHnivS gUkgqR9XjHnivS;
    fc4RJByVvAciR fc4RJByVvAciR2 = (fc4RJByVvAciR)psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR((Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR, "context"));
    fc4RJByVvAciR fc4RJByVvAciR1 = fc4RJByVvAciR2;
    if (fc4RJByVvAciR2 == null)
      gUkgqR9XjHnivS = GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR; 
    return (fc4RJByVvAciR)gUkgqR9XjHnivS;
  }
  
  public static Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, @Nullable fc4RJByVvAciR paramfc4RJByVvAciR) {
    return ((Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR, "context")).psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR, paramfc4RJByVvAciR);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\MxwALnHp3MNCI\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */