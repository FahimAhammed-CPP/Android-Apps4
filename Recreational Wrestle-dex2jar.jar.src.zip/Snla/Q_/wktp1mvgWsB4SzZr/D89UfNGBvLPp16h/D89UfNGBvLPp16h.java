package Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.wktp1mvgWsB4SzZr.AYieGTkN28B_;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;

public abstract class D89UfNGBvLPp16h {
  private static final Q_ psJpCSi8_h7NzZZ1vbR = new Q_();
  
  static D89UfNGBvLPp16h Q_() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public abstract <C> AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR(C paramC, psJpCSi8_h7NzZZ1vbR<C> parampsJpCSi8_h7NzZZ1vbR) throws XV2I8z;
  
  public abstract List<String> psJpCSi8_h7NzZZ1vbR();
  
  public abstract <C> void psJpCSi8_h7NzZZ1vbR(AYieGTkN28B_ paramAYieGTkN28B_, C paramC, XV2I8z<C> paramXV2I8z);
  
  private static final class Q_ extends D89UfNGBvLPp16h {
    private Q_() {}
    
    public <C> AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR(C param1C, D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR<C> param1psJpCSi8_h7NzZZ1vbR) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1C, "carrier");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1psJpCSi8_h7NzZZ1vbR, "getter");
      return AYieGTkN28B_.psJpCSi8_h7NzZZ1vbR;
    }
    
    public List<String> psJpCSi8_h7NzZZ1vbR() {
      return Collections.emptyList();
    }
    
    public <C> void psJpCSi8_h7NzZZ1vbR(AYieGTkN28B_ param1AYieGTkN28B_, C param1C, D89UfNGBvLPp16h.XV2I8z<C> param1XV2I8z) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1AYieGTkN28B_, "spanContext");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1C, "carrier");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1XV2I8z, "setter");
    }
  }
  
  public static abstract class XV2I8z<C> {
    public abstract void put(C param1C, String param1String1, String param1String2);
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR<C> {
    @Nullable
    public abstract String psJpCSi8_h7NzZZ1vbR(C param1C, String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\D89UfNGBvLPp16h\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */