package Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h;

public abstract class Q_ {
  private static final Q_ psJpCSi8_h7NzZZ1vbR = new psJpCSi8_h7NzZZ1vbR();
  
  public static Q_ D89UfNGBvLPp16h() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public abstract D89UfNGBvLPp16h Q_();
  
  public abstract D89UfNGBvLPp16h XV2I8z();
  
  public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR();
  
  private static final class psJpCSi8_h7NzZZ1vbR extends Q_ {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public D89UfNGBvLPp16h Q_() {
      return D89UfNGBvLPp16h.Q_();
    }
    
    public D89UfNGBvLPp16h XV2I8z() {
      return D89UfNGBvLPp16h.Q_();
    }
    
    public psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
      return psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\D89UfNGBvLPp16h\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */