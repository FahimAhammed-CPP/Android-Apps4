package Snla.Q_.wktp1mvgWsB4SzZr.D89UfNGBvLPp16h;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.wktp1mvgWsB4SzZr.AYieGTkN28B_;
import java.text.ParseException;

public abstract class psJpCSi8_h7NzZZ1vbR {
  static final psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = new psJpCSi8_h7NzZZ1vbR();
  
  static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public AYieGTkN28B_ Q_(byte[] paramArrayOfbyte) throws XV2I8z {
    try {
      return psJpCSi8_h7NzZZ1vbR(paramArrayOfbyte);
    } catch (ParseException parseException) {
      throw new XV2I8z("Error while parsing.", parseException);
    } 
  }
  
  public byte[] Q_(AYieGTkN28B_ paramAYieGTkN28B_) {
    return psJpCSi8_h7NzZZ1vbR(paramAYieGTkN28B_);
  }
  
  @Deprecated
  public AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte) throws ParseException {
    try {
      return Q_(paramArrayOfbyte);
    } catch (XV2I8z xV2I8z) {
      throw new ParseException(xV2I8z.toString(), 0);
    } 
  }
  
  @Deprecated
  public byte[] psJpCSi8_h7NzZZ1vbR(AYieGTkN28B_ paramAYieGTkN28B_) {
    return Q_(paramAYieGTkN28B_);
  }
  
  private static final class psJpCSi8_h7NzZZ1vbR extends psJpCSi8_h7NzZZ1vbR {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public AYieGTkN28B_ Q_(byte[] param1ArrayOfbyte) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1ArrayOfbyte, "bytes");
      return AYieGTkN28B_.psJpCSi8_h7NzZZ1vbR;
    }
    
    public byte[] Q_(AYieGTkN28B_ param1AYieGTkN28B_) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1AYieGTkN28B_, "spanContext");
      return new byte[0];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\D89UfNGBvLPp16h\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */