package Snla.Q_.wktp1mvgWsB4SzZr;

import java.util.Objects;

final class MxwALnHp3MNCI extends Q_.XV2I8z {
  private final Long psJpCSi8_h7NzZZ1vbR;
  
  MxwALnHp3MNCI(Long paramLong) {
    Objects.requireNonNull(paramLong, "Null longValue");
    this.psJpCSi8_h7NzZZ1vbR = paramLong;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Q_.XV2I8z) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  Long psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AttributeValueLong{longValue=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\MxwALnHp3MNCI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */