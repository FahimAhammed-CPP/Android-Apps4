package Snla.Q_.wktp1mvgWsB4SzZr;

import java.util.Arrays;
import javax.annotation.Nullable;

public final class AYieGTkN28B_ {
  private static final n4neFNjUxhYqW Q_;
  
  public static final AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR;
  
  private final KRly__dqVzGwm1pz D89UfNGBvLPp16h;
  
  private final n4neFNjUxhYqW MxwALnHp3MNCI;
  
  private final bCcldirtq3agvRAiIT X9K8CXVSxZWf;
  
  private final emjFZ1 XV2I8z;
  
  static {
    n4neFNjUxhYqW n4neFNjUxhYqW1 = n4neFNjUxhYqW.Q_().psJpCSi8_h7NzZZ1vbR();
    Q_ = n4neFNjUxhYqW1;
    psJpCSi8_h7NzZZ1vbR = new AYieGTkN28B_(emjFZ1.Q_, KRly__dqVzGwm1pz.Q_, bCcldirtq3agvRAiIT.Q_, n4neFNjUxhYqW1);
  }
  
  private AYieGTkN28B_(emjFZ1 paramemjFZ1, KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz, bCcldirtq3agvRAiIT parambCcldirtq3agvRAiIT, n4neFNjUxhYqW paramn4neFNjUxhYqW) {
    this.XV2I8z = paramemjFZ1;
    this.D89UfNGBvLPp16h = paramKRly__dqVzGwm1pz;
    this.X9K8CXVSxZWf = parambCcldirtq3agvRAiIT;
    this.MxwALnHp3MNCI = paramn4neFNjUxhYqW;
  }
  
  @Deprecated
  public static AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR(emjFZ1 paramemjFZ1, KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz, bCcldirtq3agvRAiIT parambCcldirtq3agvRAiIT) {
    return psJpCSi8_h7NzZZ1vbR(paramemjFZ1, paramKRly__dqVzGwm1pz, parambCcldirtq3agvRAiIT, Q_);
  }
  
  public static AYieGTkN28B_ psJpCSi8_h7NzZZ1vbR(emjFZ1 paramemjFZ1, KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz, bCcldirtq3agvRAiIT parambCcldirtq3agvRAiIT, n4neFNjUxhYqW paramn4neFNjUxhYqW) {
    return new AYieGTkN28B_(paramemjFZ1, paramKRly__dqVzGwm1pz, parambCcldirtq3agvRAiIT, paramn4neFNjUxhYqW);
  }
  
  public n4neFNjUxhYqW D89UfNGBvLPp16h() {
    return this.MxwALnHp3MNCI;
  }
  
  public KRly__dqVzGwm1pz Q_() {
    return this.D89UfNGBvLPp16h;
  }
  
  public boolean X9K8CXVSxZWf() {
    return (this.XV2I8z.Q_() && this.D89UfNGBvLPp16h.Q_());
  }
  
  public bCcldirtq3agvRAiIT XV2I8z() {
    return this.X9K8CXVSxZWf;
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof AYieGTkN28B_))
      return false; 
    paramObject = paramObject;
    return (this.XV2I8z.equals(((AYieGTkN28B_)paramObject).XV2I8z) && this.D89UfNGBvLPp16h.equals(((AYieGTkN28B_)paramObject).D89UfNGBvLPp16h) && this.X9K8CXVSxZWf.equals(((AYieGTkN28B_)paramObject).X9K8CXVSxZWf));
  }
  
  public int hashCode() {
    return Arrays.hashCode(new Object[] { this.XV2I8z, this.D89UfNGBvLPp16h, this.X9K8CXVSxZWf });
  }
  
  public emjFZ1 psJpCSi8_h7NzZZ1vbR() {
    return this.XV2I8z;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SpanContext{traceId=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", spanId=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append(", traceOptions=");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\AYieGTkN28B_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */