package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class psJpCSi8_h7NzZZ1vbR {
  private static final Map<String, Q_> psJpCSi8_h7NzZZ1vbR = Collections.unmodifiableMap(Collections.emptyMap());
  
  public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String paramString) {
    return new XV2I8z(paramString, psJpCSi8_h7NzZZ1vbR);
  }
  
  public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String paramString, Map<String, Q_> paramMap) {
    return new XV2I8z(paramString, Collections.unmodifiableMap(new HashMap<String, Q_>((Map<? extends String, ? extends Q_>)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramMap, "attributes"))));
  }
  
  public abstract Map<String, Q_> Q_();
  
  public abstract String psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */