package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import java.util.Objects;
import javax.annotation.Nullable;

@Deprecated
final class qY extends hhkWV822WvWIJ6d {
  private final long D89UfNGBvLPp16h;
  
  private final hhkWV822WvWIJ6d.Q_ Q_;
  
  private final long X9K8CXVSxZWf;
  
  private final long XV2I8z;
  
  private final LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR;
  
  private qY(@Nullable LEwT0cz2WRRZ paramLEwT0cz2WRRZ, hhkWV822WvWIJ6d.Q_ paramQ_, long paramLong1, long paramLong2, long paramLong3) {
    this.psJpCSi8_h7NzZZ1vbR = paramLEwT0cz2WRRZ;
    this.Q_ = paramQ_;
    this.XV2I8z = paramLong1;
    this.D89UfNGBvLPp16h = paramLong2;
    this.X9K8CXVSxZWf = paramLong3;
  }
  
  public long D89UfNGBvLPp16h() {
    return this.D89UfNGBvLPp16h;
  }
  
  public hhkWV822WvWIJ6d.Q_ Q_() {
    return this.Q_;
  }
  
  public long X9K8CXVSxZWf() {
    return this.X9K8CXVSxZWf;
  }
  
  public long XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof hhkWV822WvWIJ6d) {
      paramObject = paramObject;
      LEwT0cz2WRRZ lEwT0cz2WRRZ = this.psJpCSi8_h7NzZZ1vbR;
      return (((lEwT0cz2WRRZ == null) ? (paramObject.psJpCSi8_h7NzZZ1vbR() == null) : lEwT0cz2WRRZ.equals(paramObject.psJpCSi8_h7NzZZ1vbR())) && this.Q_.equals(paramObject.Q_()) && this.XV2I8z == paramObject.XV2I8z() && this.D89UfNGBvLPp16h == paramObject.D89UfNGBvLPp16h() && this.X9K8CXVSxZWf == paramObject.X9K8CXVSxZWf());
    } 
    return false;
  }
  
  public int hashCode() {
    int i;
    LEwT0cz2WRRZ lEwT0cz2WRRZ = this.psJpCSi8_h7NzZZ1vbR;
    if (lEwT0cz2WRRZ == null) {
      i = 0;
    } else {
      i = lEwT0cz2WRRZ.hashCode();
    } 
    long l1 = (((i ^ 0xF4243) * 1000003 ^ this.Q_.hashCode()) * 1000003);
    long l2 = this.XV2I8z;
    l1 = ((int)(l1 ^ l2 ^ l2 >>> 32L) * 1000003);
    l2 = this.D89UfNGBvLPp16h;
    l1 = ((int)(l1 ^ l2 ^ l2 >>> 32L) * 1000003);
    l2 = this.X9K8CXVSxZWf;
    return (int)(l1 ^ l2 ^ l2 >>> 32L);
  }
  
  @Nullable
  public LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("NetworkEvent{kernelTimestamp=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", type=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", messageId=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", uncompressedMessageSize=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append(", compressedMessageSize=");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class psJpCSi8_h7NzZZ1vbR extends hhkWV822WvWIJ6d.psJpCSi8_h7NzZZ1vbR {
    private Long D89UfNGBvLPp16h;
    
    private hhkWV822WvWIJ6d.Q_ Q_;
    
    private Long X9K8CXVSxZWf;
    
    private Long XV2I8z;
    
    private LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR;
    
    public hhkWV822WvWIJ6d.psJpCSi8_h7NzZZ1vbR Q_(long param1Long) {
      this.D89UfNGBvLPp16h = Long.valueOf(param1Long);
      return this;
    }
    
    public hhkWV822WvWIJ6d.psJpCSi8_h7NzZZ1vbR XV2I8z(long param1Long) {
      this.X9K8CXVSxZWf = Long.valueOf(param1Long);
      return this;
    }
    
    hhkWV822WvWIJ6d.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(long param1Long) {
      this.XV2I8z = Long.valueOf(param1Long);
      return this;
    }
    
    public hhkWV822WvWIJ6d.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(@Nullable LEwT0cz2WRRZ param1LEwT0cz2WRRZ) {
      this.psJpCSi8_h7NzZZ1vbR = param1LEwT0cz2WRRZ;
      return this;
    }
    
    hhkWV822WvWIJ6d.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(hhkWV822WvWIJ6d.Q_ param1Q_) {
      Objects.requireNonNull(param1Q_, "Null type");
      this.Q_ = param1Q_;
      return this;
    }
    
    public hhkWV822WvWIJ6d psJpCSi8_h7NzZZ1vbR() {
      hhkWV822WvWIJ6d.Q_ q_ = this.Q_;
      String str1 = "";
      if (q_ == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("");
        stringBuilder1.append(" type");
        str1 = stringBuilder1.toString();
      } 
      String str2 = str1;
      if (this.XV2I8z == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append(" messageId");
        str2 = stringBuilder1.toString();
      } 
      str1 = str2;
      if (this.D89UfNGBvLPp16h == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str2);
        stringBuilder1.append(" uncompressedMessageSize");
        str1 = stringBuilder1.toString();
      } 
      str2 = str1;
      if (this.X9K8CXVSxZWf == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append(" compressedMessageSize");
        str2 = stringBuilder1.toString();
      } 
      if (str2.isEmpty())
        return new qY(this.psJpCSi8_h7NzZZ1vbR, this.Q_, this.XV2I8z.longValue(), this.D89UfNGBvLPp16h.longValue(), this.X9K8CXVSxZWf.longValue()); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Missing required properties:");
      stringBuilder.append(str2);
      throw new IllegalStateException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\qY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */