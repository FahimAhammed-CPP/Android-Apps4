package Snla.Q_.wktp1mvgWsB4SzZr.X9K8CXVSxZWf;

import Snla.Q_.wktp1mvgWsB4SzZr.AYieGTkN28B_;
import Snla.Q_.wktp1mvgWsB4SzZr.KRly__dqVzGwm1pz;
import Snla.Q_.wktp1mvgWsB4SzZr.aqqnPTeV;
import Snla.Q_.wktp1mvgWsB4SzZr.emjFZ1;
import Snla.Q_.wktp1mvgWsB4SzZr.fc4RJByVvAciR;
import java.util.List;
import javax.annotation.Nullable;

final class psJpCSi8_h7NzZZ1vbR extends aqqnPTeV {
  public String psJpCSi8_h7NzZZ1vbR() {
    return toString();
  }
  
  public boolean psJpCSi8_h7NzZZ1vbR(@Nullable AYieGTkN28B_ paramAYieGTkN28B_, @Nullable Boolean paramBoolean, emjFZ1 paramemjFZ1, KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz, String paramString, List<fc4RJByVvAciR> paramList) {
    return true;
  }
  
  public String toString() {
    return "AlwaysSampleSampler";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\X9K8CXVSxZWf\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */