package Snla.Q_.wktp1mvgWsB4SzZr.X9K8CXVSxZWf;

import Snla.Q_.wktp1mvgWsB4SzZr.aqqnPTeV;

public final class X9K8CXVSxZWf {
  private static final aqqnPTeV Q_;
  
  private static final aqqnPTeV psJpCSi8_h7NzZZ1vbR = new psJpCSi8_h7NzZZ1vbR();
  
  static {
    Q_ = new XV2I8z();
  }
  
  public static aqqnPTeV Q_() {
    return Q_;
  }
  
  public static aqqnPTeV psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public static aqqnPTeV psJpCSi8_h7NzZZ1vbR(double paramDouble) {
    return D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(paramDouble);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\X9K8CXVSxZWf\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */