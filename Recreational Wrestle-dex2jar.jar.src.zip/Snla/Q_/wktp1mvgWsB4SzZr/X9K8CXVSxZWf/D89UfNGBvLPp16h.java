package Snla.Q_.wktp1mvgWsB4SzZr.X9K8CXVSxZWf;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.wktp1mvgWsB4SzZr.AYieGTkN28B_;
import Snla.Q_.wktp1mvgWsB4SzZr.KRly__dqVzGwm1pz;
import Snla.Q_.wktp1mvgWsB4SzZr.aqqnPTeV;
import Snla.Q_.wktp1mvgWsB4SzZr.emjFZ1;
import Snla.Q_.wktp1mvgWsB4SzZr.fc4RJByVvAciR;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;

abstract class D89UfNGBvLPp16h extends aqqnPTeV {
  static D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR(double paramDouble) {
    boolean bool;
    long l;
    int i = paramDouble cmp 0.0D;
    if (i >= 0 && paramDouble <= 1.0D) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "probability must be in range [0.0, 1.0]");
    if (i == 0) {
      l = Long.MIN_VALUE;
    } else if (paramDouble == 1.0D) {
      l = Long.MAX_VALUE;
    } else {
      l = (long)(9.223372036854776E18D * paramDouble);
    } 
    return new Q_(paramDouble, l);
  }
  
  abstract double Q_();
  
  abstract long XV2I8z();
  
  public final String psJpCSi8_h7NzZZ1vbR() {
    return String.format("ProbabilitySampler{%.6f}", new Object[] { Double.valueOf(Q_()) });
  }
  
  public final boolean psJpCSi8_h7NzZZ1vbR(@Nullable AYieGTkN28B_ paramAYieGTkN28B_, @Nullable Boolean paramBoolean, emjFZ1 paramemjFZ1, KRly__dqVzGwm1pz paramKRly__dqVzGwm1pz, String paramString, @Nullable List<fc4RJByVvAciR> paramList) {
    if (paramAYieGTkN28B_ != null && paramAYieGTkN28B_.XV2I8z().X9K8CXVSxZWf())
      return true; 
    if (paramList != null) {
      Iterator<fc4RJByVvAciR> iterator = paramList.iterator();
      while (iterator.hasNext()) {
        if (((fc4RJByVvAciR)iterator.next()).Q_().XV2I8z().X9K8CXVSxZWf())
          return true; 
      } 
    } 
    return (Math.abs(paramemjFZ1.D89UfNGBvLPp16h()) < XV2I8z());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\X9K8CXVSxZWf\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */