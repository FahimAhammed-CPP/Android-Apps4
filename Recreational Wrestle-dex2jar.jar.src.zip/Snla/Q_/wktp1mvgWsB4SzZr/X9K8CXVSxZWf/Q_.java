package Snla.Q_.wktp1mvgWsB4SzZr.X9K8CXVSxZWf;

final class Q_ extends D89UfNGBvLPp16h {
  private final long Q_;
  
  private final double psJpCSi8_h7NzZZ1vbR;
  
  Q_(double paramDouble, long paramLong) {
    this.psJpCSi8_h7NzZZ1vbR = paramDouble;
    this.Q_ = paramLong;
  }
  
  double Q_() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  long XV2I8z() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof D89UfNGBvLPp16h) {
      paramObject = paramObject;
      return (Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) == Double.doubleToLongBits(paramObject.Q_()) && this.Q_ == paramObject.XV2I8z());
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = ((int)(1000003L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) >>> 32L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR)) * 1000003);
    long l2 = this.Q_;
    return (int)(l1 ^ l2 ^ l2 >>> 32L);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ProbabilitySampler{probability=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", idUpperBound=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\X9K8CXVSxZWf\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */