package Snla.Q_.wktp1mvgWsB4SzZr;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class UptK2mZMIFJk1ivmXYH {
  private static final Map<String, Q_> psJpCSi8_h7NzZZ1vbR = Collections.emptyMap();
  
  public static UptK2mZMIFJk1ivmXYH psJpCSi8_h7NzZZ1vbR(AYieGTkN28B_ paramAYieGTkN28B_, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    return new BIRpv(paramAYieGTkN28B_.psJpCSi8_h7NzZZ1vbR(), paramAYieGTkN28B_.Q_(), parampsJpCSi8_h7NzZZ1vbR, psJpCSi8_h7NzZZ1vbR);
  }
  
  public static UptK2mZMIFJk1ivmXYH psJpCSi8_h7NzZZ1vbR(AYieGTkN28B_ paramAYieGTkN28B_, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, Map<String, Q_> paramMap) {
    return new BIRpv(paramAYieGTkN28B_.psJpCSi8_h7NzZZ1vbR(), paramAYieGTkN28B_.Q_(), parampsJpCSi8_h7NzZZ1vbR, Collections.unmodifiableMap(new HashMap<String, Q_>(paramMap)));
  }
  
  public abstract Map<String, Q_> D89UfNGBvLPp16h();
  
  public abstract KRly__dqVzGwm1pz Q_();
  
  public abstract psJpCSi8_h7NzZZ1vbR XV2I8z();
  
  public abstract emjFZ1 psJpCSi8_h7NzZZ1vbR();
  
  public enum psJpCSi8_h7NzZZ1vbR {
    Q_, psJpCSi8_h7NzZZ1vbR;
    
    static {
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = new psJpCSi8_h7NzZZ1vbR("CHILD_LINKED_SPAN", 0);
      psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR1;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR2 = new psJpCSi8_h7NzZZ1vbR("PARENT_LINKED_SPAN", 1);
      Q_ = psJpCSi8_h7NzZZ1vbR2;
      XV2I8z = new psJpCSi8_h7NzZZ1vbR[] { psJpCSi8_h7NzZZ1vbR1, psJpCSi8_h7NzZZ1vbR2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\UptK2mZMIFJk1ivmXYH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */