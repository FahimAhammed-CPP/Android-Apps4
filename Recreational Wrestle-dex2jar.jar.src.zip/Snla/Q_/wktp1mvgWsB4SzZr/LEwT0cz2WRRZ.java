package Snla.Q_.wktp1mvgWsB4SzZr;

import javax.annotation.Nullable;

public abstract class LEwT0cz2WRRZ {
  public static final LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR = XV2I8z().psJpCSi8_h7NzZZ1vbR();
  
  public static psJpCSi8_h7NzZZ1vbR XV2I8z() {
    return (new wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR()).psJpCSi8_h7NzZZ1vbR(false);
  }
  
  @Nullable
  public abstract DmG0HNQ6 Q_();
  
  public abstract boolean psJpCSi8_h7NzZZ1vbR();
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(DmG0HNQ6 param1DmG0HNQ6);
    
    public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(boolean param1Boolean);
    
    public abstract LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\LEwT0cz2WRRZ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */