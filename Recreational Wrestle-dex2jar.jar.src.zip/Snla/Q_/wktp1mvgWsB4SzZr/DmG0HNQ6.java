package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;
import javax.annotation.Nullable;

public final class DmG0HNQ6 {
  public static final DmG0HNQ6 Ap4G4fS9phs;
  
  public static final DmG0HNQ6 BIRpv;
  
  public static final DmG0HNQ6 D89UfNGBvLPp16h;
  
  public static final DmG0HNQ6 D_K6ibTZHL_tOOY3;
  
  public static final DmG0HNQ6 GUkgqR9XjHnivS;
  
  public static final DmG0HNQ6 LEIMjJ;
  
  private static final List<DmG0HNQ6> LEwT0cz2WRRZ = X9K8CXVSxZWf();
  
  public static final DmG0HNQ6 MxwALnHp3MNCI;
  
  public static final DmG0HNQ6 Q_;
  
  public static final DmG0HNQ6 X9K8CXVSxZWf;
  
  public static final DmG0HNQ6 XV2I8z;
  
  public static final DmG0HNQ6 hzEmy;
  
  public static final DmG0HNQ6 oq9TzoD0;
  
  public static final DmG0HNQ6 psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.Q_();
  
  public static final DmG0HNQ6 qY;
  
  public static final DmG0HNQ6 rG8A403wjTaYB6V;
  
  public static final DmG0HNQ6 wktp1mvgWsB4SzZr;
  
  public static final DmG0HNQ6 wqn;
  
  private final psJpCSi8_h7NzZZ1vbR UptK2mZMIFJk1ivmXYH;
  
  @Nullable
  private final String jlrPm;
  
  static {
    Q_ = psJpCSi8_h7NzZZ1vbR.Q_.Q_();
    XV2I8z = psJpCSi8_h7NzZZ1vbR.XV2I8z.Q_();
    D89UfNGBvLPp16h = psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h.Q_();
    X9K8CXVSxZWf = psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf.Q_();
    MxwALnHp3MNCI = psJpCSi8_h7NzZZ1vbR.MxwALnHp3MNCI.Q_();
    wqn = psJpCSi8_h7NzZZ1vbR.wqn.Q_();
    wktp1mvgWsB4SzZr = psJpCSi8_h7NzZZ1vbR.wktp1mvgWsB4SzZr.Q_();
    BIRpv = psJpCSi8_h7NzZZ1vbR.oq9TzoD0.Q_();
    LEIMjJ = psJpCSi8_h7NzZZ1vbR.BIRpv.Q_();
    qY = psJpCSi8_h7NzZZ1vbR.LEIMjJ.Q_();
    hzEmy = psJpCSi8_h7NzZZ1vbR.qY.Q_();
    rG8A403wjTaYB6V = psJpCSi8_h7NzZZ1vbR.hzEmy.Q_();
    D_K6ibTZHL_tOOY3 = psJpCSi8_h7NzZZ1vbR.rG8A403wjTaYB6V.Q_();
    Ap4G4fS9phs = psJpCSi8_h7NzZZ1vbR.D_K6ibTZHL_tOOY3.Q_();
    GUkgqR9XjHnivS = psJpCSi8_h7NzZZ1vbR.Ap4G4fS9phs.Q_();
    oq9TzoD0 = psJpCSi8_h7NzZZ1vbR.GUkgqR9XjHnivS.Q_();
  }
  
  private DmG0HNQ6(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, @Nullable String paramString) {
    this.UptK2mZMIFJk1ivmXYH = (psJpCSi8_h7NzZZ1vbR)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR, "canonicalCode");
    this.jlrPm = paramString;
  }
  
  private static List<DmG0HNQ6> X9K8CXVSxZWf() {
    StringBuilder stringBuilder;
    TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>();
    psJpCSi8_h7NzZZ1vbR[] arrayOfPsJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR.values();
    int j = arrayOfPsJpCSi8_h7NzZZ1vbR.length;
    int i = 0;
    while (i < j) {
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = arrayOfPsJpCSi8_h7NzZZ1vbR[i];
      DmG0HNQ6 dmG0HNQ6 = (DmG0HNQ6)treeMap.put(Integer.valueOf(psJpCSi8_h7NzZZ1vbR1.psJpCSi8_h7NzZZ1vbR()), new DmG0HNQ6(psJpCSi8_h7NzZZ1vbR1, null));
      if (dmG0HNQ6 == null) {
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Code value duplication between ");
      stringBuilder.append(dmG0HNQ6.psJpCSi8_h7NzZZ1vbR().name());
      stringBuilder.append(" & ");
      stringBuilder.append(psJpCSi8_h7NzZZ1vbR1.name());
      throw new IllegalStateException(stringBuilder.toString());
    } 
    return Collections.unmodifiableList(new ArrayList<DmG0HNQ6>(stringBuilder.values()));
  }
  
  @Nullable
  public String Q_() {
    return this.jlrPm;
  }
  
  public boolean XV2I8z() {
    return (psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR == this.UptK2mZMIFJk1ivmXYH);
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof DmG0HNQ6))
      return false; 
    paramObject = paramObject;
    return (this.UptK2mZMIFJk1ivmXYH == ((DmG0HNQ6)paramObject).UptK2mZMIFJk1ivmXYH && X9K8CXVSxZWf.Q_(this.jlrPm, ((DmG0HNQ6)paramObject).jlrPm));
  }
  
  public int hashCode() {
    return Arrays.hashCode(new Object[] { this.UptK2mZMIFJk1ivmXYH, this.jlrPm });
  }
  
  public psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
    return this.UptK2mZMIFJk1ivmXYH;
  }
  
  public DmG0HNQ6 psJpCSi8_h7NzZZ1vbR(@Nullable String paramString) {
    return X9K8CXVSxZWf.Q_(this.jlrPm, paramString) ? this : new DmG0HNQ6(this.UptK2mZMIFJk1ivmXYH, paramString);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Status{canonicalCode=");
    stringBuilder.append(this.UptK2mZMIFJk1ivmXYH);
    stringBuilder.append(", description=");
    stringBuilder.append(this.jlrPm);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public enum psJpCSi8_h7NzZZ1vbR {
    Ap4G4fS9phs, BIRpv, D89UfNGBvLPp16h, D_K6ibTZHL_tOOY3, GUkgqR9XjHnivS, LEIMjJ, MxwALnHp3MNCI, Q_, X9K8CXVSxZWf, XV2I8z, hzEmy, oq9TzoD0, psJpCSi8_h7NzZZ1vbR, qY, rG8A403wjTaYB6V, wktp1mvgWsB4SzZr, wqn;
    
    private final int LEwT0cz2WRRZ;
    
    static {
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = new psJpCSi8_h7NzZZ1vbR("OK", 0, 0);
      psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR1;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR2 = new psJpCSi8_h7NzZZ1vbR("CANCELLED", 1, 1);
      Q_ = psJpCSi8_h7NzZZ1vbR2;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR3 = new psJpCSi8_h7NzZZ1vbR("UNKNOWN", 2, 2);
      XV2I8z = psJpCSi8_h7NzZZ1vbR3;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR4 = new psJpCSi8_h7NzZZ1vbR("INVALID_ARGUMENT", 3, 3);
      D89UfNGBvLPp16h = psJpCSi8_h7NzZZ1vbR4;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR5 = new psJpCSi8_h7NzZZ1vbR("DEADLINE_EXCEEDED", 4, 4);
      X9K8CXVSxZWf = psJpCSi8_h7NzZZ1vbR5;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR6 = new psJpCSi8_h7NzZZ1vbR("NOT_FOUND", 5, 5);
      MxwALnHp3MNCI = psJpCSi8_h7NzZZ1vbR6;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR7 = new psJpCSi8_h7NzZZ1vbR("ALREADY_EXISTS", 6, 6);
      wqn = psJpCSi8_h7NzZZ1vbR7;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR8 = new psJpCSi8_h7NzZZ1vbR("PERMISSION_DENIED", 7, 7);
      wktp1mvgWsB4SzZr = psJpCSi8_h7NzZZ1vbR8;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR9 = new psJpCSi8_h7NzZZ1vbR("RESOURCE_EXHAUSTED", 8, 8);
      BIRpv = psJpCSi8_h7NzZZ1vbR9;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR10 = new psJpCSi8_h7NzZZ1vbR("FAILED_PRECONDITION", 9, 9);
      LEIMjJ = psJpCSi8_h7NzZZ1vbR10;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR11 = new psJpCSi8_h7NzZZ1vbR("ABORTED", 10, 10);
      qY = psJpCSi8_h7NzZZ1vbR11;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR12 = new psJpCSi8_h7NzZZ1vbR("OUT_OF_RANGE", 11, 11);
      hzEmy = psJpCSi8_h7NzZZ1vbR12;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR13 = new psJpCSi8_h7NzZZ1vbR("UNIMPLEMENTED", 12, 12);
      rG8A403wjTaYB6V = psJpCSi8_h7NzZZ1vbR13;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR14 = new psJpCSi8_h7NzZZ1vbR("INTERNAL", 13, 13);
      D_K6ibTZHL_tOOY3 = psJpCSi8_h7NzZZ1vbR14;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR15 = new psJpCSi8_h7NzZZ1vbR("UNAVAILABLE", 14, 14);
      Ap4G4fS9phs = psJpCSi8_h7NzZZ1vbR15;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR16 = new psJpCSi8_h7NzZZ1vbR("DATA_LOSS", 15, 15);
      GUkgqR9XjHnivS = psJpCSi8_h7NzZZ1vbR16;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR17 = new psJpCSi8_h7NzZZ1vbR("UNAUTHENTICATED", 16, 16);
      oq9TzoD0 = psJpCSi8_h7NzZZ1vbR17;
      UptK2mZMIFJk1ivmXYH = new psJpCSi8_h7NzZZ1vbR[] { 
          psJpCSi8_h7NzZZ1vbR1, psJpCSi8_h7NzZZ1vbR2, psJpCSi8_h7NzZZ1vbR3, psJpCSi8_h7NzZZ1vbR4, psJpCSi8_h7NzZZ1vbR5, psJpCSi8_h7NzZZ1vbR6, psJpCSi8_h7NzZZ1vbR7, psJpCSi8_h7NzZZ1vbR8, psJpCSi8_h7NzZZ1vbR9, psJpCSi8_h7NzZZ1vbR10, 
          psJpCSi8_h7NzZZ1vbR11, psJpCSi8_h7NzZZ1vbR12, psJpCSi8_h7NzZZ1vbR13, psJpCSi8_h7NzZZ1vbR14, psJpCSi8_h7NzZZ1vbR15, psJpCSi8_h7NzZZ1vbR16, psJpCSi8_h7NzZZ1vbR17 };
    }
    
    psJpCSi8_h7NzZZ1vbR(int param1Int1) {
      this.LEwT0cz2WRRZ = param1Int1;
    }
    
    public DmG0HNQ6 Q_() {
      return DmG0HNQ6.D89UfNGBvLPp16h().get(this.LEwT0cz2WRRZ);
    }
    
    public int psJpCSi8_h7NzZZ1vbR() {
      return this.LEwT0cz2WRRZ;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\DmG0HNQ6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */