package Snla.Q_.wktp1mvgWsB4SzZr;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.Arrays;

final class Ap4G4fS9phs {
  private static final String D89UfNGBvLPp16h = "0123456789abcdef";
  
  private static final char[] MxwALnHp3MNCI = psJpCSi8_h7NzZZ1vbR();
  
  static final int Q_ = 2;
  
  private static final int X9K8CXVSxZWf = 128;
  
  static final int XV2I8z = 16;
  
  static final int psJpCSi8_h7NzZZ1vbR = 8;
  
  private static final byte[] wqn = Q_();
  
  static byte Q_(CharSequence paramCharSequence, int paramInt) {
    boolean bool;
    if (paramCharSequence.length() >= paramInt + 2) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "chars too small");
    return psJpCSi8_h7NzZZ1vbR(paramCharSequence.charAt(paramInt), paramCharSequence.charAt(paramInt + 1));
  }
  
  private static void Q_(byte paramByte, char[] paramArrayOfchar, int paramInt) {
    int i = paramByte & 0xFF;
    char[] arrayOfChar = MxwALnHp3MNCI;
    paramArrayOfchar[paramInt] = arrayOfChar[i];
    paramArrayOfchar[paramInt + 1] = arrayOfChar[i | 0x100];
  }
  
  private static byte[] Q_() {
    byte[] arrayOfByte = new byte[128];
    Arrays.fill(arrayOfByte, (byte)-1);
    for (int i = 0; i < 16; i++)
      arrayOfByte["0123456789abcdef".charAt(i)] = (byte)i; 
    return arrayOfByte;
  }
  
  private static byte psJpCSi8_h7NzZZ1vbR(char paramChar1, char paramChar2) {
    boolean bool1;
    boolean bool2 = true;
    if (paramChar2 < '' && wqn[paramChar2] != -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("invalid character ");
    stringBuilder.append(paramChar2);
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, stringBuilder.toString());
    if (paramChar1 < '' && wqn[paramChar1] != -1) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    stringBuilder = new StringBuilder();
    stringBuilder.append("invalid character ");
    stringBuilder.append(paramChar1);
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, stringBuilder.toString());
    byte[] arrayOfByte = wqn;
    return (byte)(arrayOfByte[paramChar1] << 4 | arrayOfByte[paramChar2]);
  }
  
  static long psJpCSi8_h7NzZZ1vbR(CharSequence paramCharSequence, int paramInt) {
    boolean bool;
    if (paramCharSequence.length() >= paramInt + 16) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "chars too small");
    long l1 = psJpCSi8_h7NzZZ1vbR(paramCharSequence.charAt(paramInt), paramCharSequence.charAt(paramInt + 1));
    long l2 = psJpCSi8_h7NzZZ1vbR(paramCharSequence.charAt(paramInt + 2), paramCharSequence.charAt(paramInt + 3));
    long l3 = psJpCSi8_h7NzZZ1vbR(paramCharSequence.charAt(paramInt + 4), paramCharSequence.charAt(paramInt + 5));
    long l4 = psJpCSi8_h7NzZZ1vbR(paramCharSequence.charAt(paramInt + 6), paramCharSequence.charAt(paramInt + 7));
    long l5 = psJpCSi8_h7NzZZ1vbR(paramCharSequence.charAt(paramInt + 8), paramCharSequence.charAt(paramInt + 9));
    long l6 = psJpCSi8_h7NzZZ1vbR(paramCharSequence.charAt(paramInt + 10), paramCharSequence.charAt(paramInt + 11));
    long l7 = psJpCSi8_h7NzZZ1vbR(paramCharSequence.charAt(paramInt + 12), paramCharSequence.charAt(paramInt + 13));
    return psJpCSi8_h7NzZZ1vbR(paramCharSequence.charAt(paramInt + 14), paramCharSequence.charAt(paramInt + 15)) & 0xFFL | (l1 & 0xFFL) << 56L | (l2 & 0xFFL) << 48L | (l3 & 0xFFL) << 40L | (l4 & 0xFFL) << 32L | (l5 & 0xFFL) << 24L | (l6 & 0xFFL) << 16L | (l7 & 0xFFL) << 8L;
  }
  
  static long psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte, int paramInt) {
    boolean bool;
    if (paramArrayOfbyte.length >= paramInt + 8) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "array too small");
    long l1 = paramArrayOfbyte[paramInt];
    long l2 = paramArrayOfbyte[paramInt + 1];
    long l3 = paramArrayOfbyte[paramInt + 2];
    long l4 = paramArrayOfbyte[paramInt + 3];
    long l5 = paramArrayOfbyte[paramInt + 4];
    long l6 = paramArrayOfbyte[paramInt + 5];
    long l7 = paramArrayOfbyte[paramInt + 6];
    return paramArrayOfbyte[paramInt + 7] & 0xFFL | (l1 & 0xFFL) << 56L | (l2 & 0xFFL) << 48L | (l3 & 0xFFL) << 40L | (l4 & 0xFFL) << 32L | (l5 & 0xFFL) << 24L | (l6 & 0xFFL) << 16L | (l7 & 0xFFL) << 8L;
  }
  
  static void psJpCSi8_h7NzZZ1vbR(byte paramByte, char[] paramArrayOfchar, int paramInt) {
    Q_(paramByte, paramArrayOfchar, paramInt);
  }
  
  static void psJpCSi8_h7NzZZ1vbR(long paramLong, byte[] paramArrayOfbyte, int paramInt) {
    boolean bool;
    if (paramArrayOfbyte.length >= paramInt + 8) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "array too small");
    paramArrayOfbyte[paramInt + 7] = (byte)(int)(paramLong & 0xFFL);
    paramArrayOfbyte[paramInt + 6] = (byte)(int)(paramLong >> 8L & 0xFFL);
    paramArrayOfbyte[paramInt + 5] = (byte)(int)(paramLong >> 16L & 0xFFL);
    paramArrayOfbyte[paramInt + 4] = (byte)(int)(paramLong >> 24L & 0xFFL);
    paramArrayOfbyte[paramInt + 3] = (byte)(int)(paramLong >> 32L & 0xFFL);
    paramArrayOfbyte[paramInt + 2] = (byte)(int)(paramLong >> 40L & 0xFFL);
    paramArrayOfbyte[paramInt + 1] = (byte)(int)(paramLong >> 48L & 0xFFL);
    paramArrayOfbyte[paramInt] = (byte)(int)(paramLong >> 56L & 0xFFL);
  }
  
  static void psJpCSi8_h7NzZZ1vbR(long paramLong, char[] paramArrayOfchar, int paramInt) {
    Q_((byte)(int)(paramLong >> 56L & 0xFFL), paramArrayOfchar, paramInt);
    Q_((byte)(int)(paramLong >> 48L & 0xFFL), paramArrayOfchar, paramInt + 2);
    Q_((byte)(int)(paramLong >> 40L & 0xFFL), paramArrayOfchar, paramInt + 4);
    Q_((byte)(int)(paramLong >> 32L & 0xFFL), paramArrayOfchar, paramInt + 6);
    Q_((byte)(int)(paramLong >> 24L & 0xFFL), paramArrayOfchar, paramInt + 8);
    Q_((byte)(int)(paramLong >> 16L & 0xFFL), paramArrayOfchar, paramInt + 10);
    Q_((byte)(int)(paramLong >> 8L & 0xFFL), paramArrayOfchar, paramInt + 12);
    Q_((byte)(int)(paramLong & 0xFFL), paramArrayOfchar, paramInt + 14);
  }
  
  private static char[] psJpCSi8_h7NzZZ1vbR() {
    char[] arrayOfChar = new char[512];
    for (int i = 0; i < 256; i++) {
      arrayOfChar[i] = "0123456789abcdef".charAt(i >>> 4);
      arrayOfChar[i | 0x100] = "0123456789abcdef".charAt(i & 0xF);
    } 
    return arrayOfChar;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wktp1mvgWsB4SzZr\Ap4G4fS9phs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */