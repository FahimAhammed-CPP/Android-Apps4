package Snla.Q_.MxwALnHp3MNCI;

@Deprecated
final class RiEMPm5KxmvYEOsVplu5 extends BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR {
  public boolean equals(Object paramObject) {
    return (paramObject == this) ? true : ((paramObject instanceof BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR));
  }
  
  public int hashCode() {
    return 1;
  }
  
  public String toString() {
    return "Cumulative{}";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\RiEMPm5KxmvYEOsVplu5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */