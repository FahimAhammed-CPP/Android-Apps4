package Snla.Q_.MxwALnHp3MNCI;

final class MxwALnHp3MNCI extends Q_.D89UfNGBvLPp16h {
  private final long psJpCSi8_h7NzZZ1vbR;
  
  MxwALnHp3MNCI(long paramLong) {
    this.psJpCSi8_h7NzZZ1vbR = paramLong;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Q_.D89UfNGBvLPp16h) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR == paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = 1000003L;
    long l2 = this.psJpCSi8_h7NzZZ1vbR;
    return (int)(l1 ^ l2 ^ l2 >>> 32L);
  }
  
  public long psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LastValueDataLong{lastValue=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\MxwALnHp3MNCI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */