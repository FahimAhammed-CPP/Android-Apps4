package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.wqn.LEIMjJ;
import java.util.List;
import java.util.Objects;

final class jlrPm extends BkAvsADz8w7ug {
  private final PK9FDpOut0CP81dMz D89UfNGBvLPp16h;
  
  private final List<LEIMjJ> MxwALnHp3MNCI;
  
  private final BkAvsADz8w7ug.Q_ Q_;
  
  private final psJpCSi8_h7NzZZ1vbR X9K8CXVSxZWf;
  
  private final String XV2I8z;
  
  private final BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR wqn;
  
  jlrPm(BkAvsADz8w7ug.Q_ paramQ_, String paramString, PK9FDpOut0CP81dMz paramPK9FDpOut0CP81dMz, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, List<LEIMjJ> paramList, BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR1) {
    Objects.requireNonNull(paramQ_, "Null name");
    this.Q_ = paramQ_;
    Objects.requireNonNull(paramString, "Null description");
    this.XV2I8z = paramString;
    Objects.requireNonNull(paramPK9FDpOut0CP81dMz, "Null measure");
    this.D89UfNGBvLPp16h = paramPK9FDpOut0CP81dMz;
    Objects.requireNonNull(parampsJpCSi8_h7NzZZ1vbR, "Null aggregation");
    this.X9K8CXVSxZWf = parampsJpCSi8_h7NzZZ1vbR;
    Objects.requireNonNull(paramList, "Null columns");
    this.MxwALnHp3MNCI = paramList;
    Objects.requireNonNull(parampsJpCSi8_h7NzZZ1vbR1, "Null window");
    this.wqn = parampsJpCSi8_h7NzZZ1vbR1;
  }
  
  public psJpCSi8_h7NzZZ1vbR D89UfNGBvLPp16h() {
    return this.X9K8CXVSxZWf;
  }
  
  @Deprecated
  public BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR MxwALnHp3MNCI() {
    return this.wqn;
  }
  
  public String Q_() {
    return this.XV2I8z;
  }
  
  public List<LEIMjJ> X9K8CXVSxZWf() {
    return this.MxwALnHp3MNCI;
  }
  
  public PK9FDpOut0CP81dMz XV2I8z() {
    return this.D89UfNGBvLPp16h;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof BkAvsADz8w7ug) {
      paramObject = paramObject;
      return (this.Q_.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.XV2I8z.equals(paramObject.Q_()) && this.D89UfNGBvLPp16h.equals(paramObject.XV2I8z()) && this.X9K8CXVSxZWf.equals(paramObject.D89UfNGBvLPp16h()) && this.MxwALnHp3MNCI.equals(paramObject.X9K8CXVSxZWf()) && this.wqn.equals(paramObject.MxwALnHp3MNCI()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (((((this.Q_.hashCode() ^ 0xF4243) * 1000003 ^ this.XV2I8z.hashCode()) * 1000003 ^ this.D89UfNGBvLPp16h.hashCode()) * 1000003 ^ this.X9K8CXVSxZWf.hashCode()) * 1000003 ^ this.MxwALnHp3MNCI.hashCode()) * 1000003 ^ this.wqn.hashCode();
  }
  
  public BkAvsADz8w7ug.Q_ psJpCSi8_h7NzZZ1vbR() {
    return this.Q_;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View{name=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", description=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", measure=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append(", aggregation=");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append(", columns=");
    stringBuilder.append(this.MxwALnHp3MNCI);
    stringBuilder.append(", window=");
    stringBuilder.append(this.wqn);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\jlrPm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */