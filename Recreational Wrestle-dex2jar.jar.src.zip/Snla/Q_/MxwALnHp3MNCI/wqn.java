package Snla.Q_.MxwALnHp3MNCI;

@Deprecated
final class wqn extends Q_.X9K8CXVSxZWf {
  private final long Q_;
  
  private final double psJpCSi8_h7NzZZ1vbR;
  
  wqn(double paramDouble, long paramLong) {
    this.psJpCSi8_h7NzZZ1vbR = paramDouble;
    this.Q_ = paramLong;
  }
  
  public long Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Q_.X9K8CXVSxZWf) {
      paramObject = paramObject;
      return (Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) == Double.doubleToLongBits(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_ == paramObject.Q_());
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = ((int)(1000003L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) >>> 32L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR)) * 1000003);
    long l2 = this.Q_;
    return (int)(l1 ^ l2 ^ l2 >>> 32L);
  }
  
  public double psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MeanData{mean=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", count=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\wqn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */