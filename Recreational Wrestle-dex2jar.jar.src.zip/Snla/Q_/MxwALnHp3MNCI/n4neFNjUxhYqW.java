package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.XV2I8z.XV2I8z;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;

public final class n4neFNjUxhYqW {
  private static final uYZX7q8fRQtQu Q_;
  
  private static final Logger psJpCSi8_h7NzZZ1vbR = Logger.getLogger(n4neFNjUxhYqW.class.getName());
  
  static {
    Q_ = psJpCSi8_h7NzZZ1vbR(uYZX7q8fRQtQu.class.getClassLoader());
  }
  
  public static cN1 Q_() {
    return Q_.psJpCSi8_h7NzZZ1vbR();
  }
  
  public static iWguP_fQsmao2bBu1lU XV2I8z() {
    return Q_.XV2I8z();
  }
  
  public static jbUx psJpCSi8_h7NzZZ1vbR() {
    return Q_.Q_();
  }
  
  static uYZX7q8fRQtQu psJpCSi8_h7NzZZ1vbR(@Nullable ClassLoader paramClassLoader) {
    try {
      return (uYZX7q8fRQtQu)XV2I8z.psJpCSi8_h7NzZZ1vbR(Class.forName("io.opencensus.impl.stats.StatsComponentImpl", true, paramClassLoader), uYZX7q8fRQtQu.class);
    } catch (ClassNotFoundException classNotFoundException) {
      psJpCSi8_h7NzZZ1vbR.log(Level.FINE, "Couldn't load full implementation for StatsComponent, now trying to load lite implementation.", classNotFoundException);
      try {
        return (uYZX7q8fRQtQu)XV2I8z.psJpCSi8_h7NzZZ1vbR(Class.forName("io.opencensus.impllite.stats.StatsComponentImplLite", true, paramClassLoader), uYZX7q8fRQtQu.class);
      } catch (ClassNotFoundException classNotFoundException1) {
        psJpCSi8_h7NzZZ1vbR.log(Level.FINE, "Couldn't load lite implementation for StatsComponent, now using default implementation for StatsComponent.", classNotFoundException1);
        return Q5BpP92bwE86mpl.psJpCSi8_h7NzZZ1vbR();
      } 
    } 
  }
  
  @Deprecated
  public static void psJpCSi8_h7NzZZ1vbR(iWguP_fQsmao2bBu1lU paramiWguP_fQsmao2bBu1lU) {
    Q_.psJpCSi8_h7NzZZ1vbR(paramiWguP_fQsmao2bBu1lU);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\n4neFNjUxhYqW.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */