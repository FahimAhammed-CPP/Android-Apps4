package Snla.Q_.MxwALnHp3MNCI;

import java.util.Objects;

final class GUkgqR9XjHnivS extends PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR {
  private final String D89UfNGBvLPp16h;
  
  private final String Q_;
  
  private final String XV2I8z;
  
  GUkgqR9XjHnivS(String paramString1, String paramString2, String paramString3) {
    Objects.requireNonNull(paramString1, "Null name");
    this.Q_ = paramString1;
    Objects.requireNonNull(paramString2, "Null description");
    this.XV2I8z = paramString2;
    Objects.requireNonNull(paramString3, "Null unit");
    this.D89UfNGBvLPp16h = paramString3;
  }
  
  public String Q_() {
    return this.XV2I8z;
  }
  
  public String XV2I8z() {
    return this.D89UfNGBvLPp16h;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      return (this.Q_.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.XV2I8z.equals(paramObject.Q_()) && this.D89UfNGBvLPp16h.equals(paramObject.XV2I8z()));
    } 
    return false;
  }
  
  public int hashCode() {
    return ((this.Q_.hashCode() ^ 0xF4243) * 1000003 ^ this.XV2I8z.hashCode()) * 1000003 ^ this.D89UfNGBvLPp16h.hashCode();
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.Q_;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MeasureDouble{name=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", description=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", unit=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\GUkgqR9XjHnivS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */