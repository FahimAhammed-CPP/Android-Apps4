package Snla.Q_.MxwALnHp3MNCI;

import java.util.Set;
import javax.annotation.Nullable;

public abstract class cN1 {
  @Nullable
  public abstract CyebS psJpCSi8_h7NzZZ1vbR(BkAvsADz8w7ug.Q_ paramQ_);
  
  public abstract Set<BkAvsADz8w7ug> psJpCSi8_h7NzZZ1vbR();
  
  public abstract void psJpCSi8_h7NzZZ1vbR(BkAvsADz8w7ug paramBkAvsADz8w7ug);
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\cN1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */