package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn;

public abstract class psJpCSi8_h7NzZZ1vbR {
  private psJpCSi8_h7NzZZ1vbR() {}
  
  public abstract <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super X9K8CXVSxZWf, T> paramwqn, wqn<? super psJpCSi8_h7NzZZ1vbR, T> paramwqn1, wqn<? super Q_, T> paramwqn2, wqn<? super XV2I8z, T> paramwqn3, wqn<? super psJpCSi8_h7NzZZ1vbR, T> paramwqn4);
  
  @Deprecated
  public static abstract class D89UfNGBvLPp16h extends psJpCSi8_h7NzZZ1vbR {
    private static final D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR = new rG8A403wjTaYB6V();
    
    public static D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR() {
      return psJpCSi8_h7NzZZ1vbR;
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf, T> param1wqn, wqn<? super psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, T> param1wqn1, wqn<? super psJpCSi8_h7NzZZ1vbR.Q_, T> param1wqn2, wqn<? super psJpCSi8_h7NzZZ1vbR.XV2I8z, T> param1wqn3, wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn4) {
      return (T)param1wqn4.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class Q_ extends psJpCSi8_h7NzZZ1vbR {
    public static Q_ psJpCSi8_h7NzZZ1vbR(DmG0HNQ6 param1DmG0HNQ6) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1DmG0HNQ6, "bucketBoundaries");
      return new qY(param1DmG0HNQ6);
    }
    
    public abstract DmG0HNQ6 psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf, T> param1wqn, wqn<? super psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, T> param1wqn1, wqn<? super Q_, T> param1wqn2, wqn<? super psJpCSi8_h7NzZZ1vbR.XV2I8z, T> param1wqn3, wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn4) {
      return (T)param1wqn2.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class X9K8CXVSxZWf extends psJpCSi8_h7NzZZ1vbR {
    private static final X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR = new D_K6ibTZHL_tOOY3();
    
    public static X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR() {
      return psJpCSi8_h7NzZZ1vbR;
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super X9K8CXVSxZWf, T> param1wqn, wqn<? super psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, T> param1wqn1, wqn<? super psJpCSi8_h7NzZZ1vbR.Q_, T> param1wqn2, wqn<? super psJpCSi8_h7NzZZ1vbR.XV2I8z, T> param1wqn3, wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn4) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class XV2I8z extends psJpCSi8_h7NzZZ1vbR {
    private static final XV2I8z psJpCSi8_h7NzZZ1vbR = new hzEmy();
    
    public static XV2I8z psJpCSi8_h7NzZZ1vbR() {
      return psJpCSi8_h7NzZZ1vbR;
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf, T> param1wqn, wqn<? super psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, T> param1wqn1, wqn<? super psJpCSi8_h7NzZZ1vbR.Q_, T> param1wqn2, wqn<? super XV2I8z, T> param1wqn3, wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn4) {
      return (T)param1wqn3.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR extends psJpCSi8_h7NzZZ1vbR {
    private static final psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = new LEIMjJ();
    
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
      return psJpCSi8_h7NzZZ1vbR;
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf, T> param1wqn, wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn1, wqn<? super psJpCSi8_h7NzZZ1vbR.Q_, T> param1wqn2, wqn<? super psJpCSi8_h7NzZZ1vbR.XV2I8z, T> param1wqn3, wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn4) {
      return (T)param1wqn1.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */