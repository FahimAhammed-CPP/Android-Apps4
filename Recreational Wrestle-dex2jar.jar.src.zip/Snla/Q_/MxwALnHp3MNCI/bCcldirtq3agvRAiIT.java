package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn;

public abstract class bCcldirtq3agvRAiIT {
  private bCcldirtq3agvRAiIT() {}
  
  public abstract PK9FDpOut0CP81dMz XV2I8z();
  
  public abstract <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> paramwqn, wqn<? super Q_, T> paramwqn1, wqn<? super bCcldirtq3agvRAiIT, T> paramwqn2);
  
  public static abstract class Q_ extends bCcldirtq3agvRAiIT {
    public static Q_ psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.Q_ param1Q_, long param1Long) {
      return new UptK2mZMIFJk1ivmXYH(param1Q_, param1Long);
    }
    
    public abstract long Q_();
    
    public abstract PK9FDpOut0CP81dMz.Q_ psJpCSi8_h7NzZZ1vbR();
    
    public <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super bCcldirtq3agvRAiIT.psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super Q_, T> param1wqn1, wqn<? super bCcldirtq3agvRAiIT, T> param1wqn2) {
      return (T)param1wqn1.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR extends bCcldirtq3agvRAiIT {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR, double param1Double) {
      return new LEwT0cz2WRRZ(param1psJpCSi8_h7NzZZ1vbR, param1Double);
    }
    
    public abstract double Q_();
    
    public abstract PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR();
    
    public <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super bCcldirtq3agvRAiIT.Q_, T> param1wqn1, wqn<? super bCcldirtq3agvRAiIT, T> param1wqn2) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\bCcldirtq3agvRAiIT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */