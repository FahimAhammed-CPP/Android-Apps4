package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf;
import java.util.Objects;

@Deprecated
final class AYieGTkN28B_ extends BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.Q_ {
  private final X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR;
  
  AYieGTkN28B_(X9K8CXVSxZWf paramX9K8CXVSxZWf) {
    Objects.requireNonNull(paramX9K8CXVSxZWf, "Null duration");
    this.psJpCSi8_h7NzZZ1vbR = paramX9K8CXVSxZWf;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.Q_) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Interval{duration=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\AYieGTkN28B_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */