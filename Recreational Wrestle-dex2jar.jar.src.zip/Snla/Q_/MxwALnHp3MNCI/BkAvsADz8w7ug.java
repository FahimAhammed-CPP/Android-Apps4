package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.XV2I8z.D89UfNGBvLPp16h;
import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn;
import Snla.Q_.wqn.LEIMjJ;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

public abstract class BkAvsADz8w7ug {
  private static final Comparator<LEIMjJ> Q_ = new Comparator<LEIMjJ>() {
      public int psJpCSi8_h7NzZZ1vbR(LEIMjJ param1LEIMjJ1, LEIMjJ param1LEIMjJ2) {
        return param1LEIMjJ1.psJpCSi8_h7NzZZ1vbR().compareToIgnoreCase(param1LEIMjJ2.psJpCSi8_h7NzZZ1vbR());
      }
    };
  
  static final int psJpCSi8_h7NzZZ1vbR = 255;
  
  public static BkAvsADz8w7ug psJpCSi8_h7NzZZ1vbR(Q_ paramQ_, String paramString, PK9FDpOut0CP81dMz paramPK9FDpOut0CP81dMz, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, List<LEIMjJ> paramList) {
    boolean bool;
    if ((new HashSet(paramList)).size() == paramList.size()) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Columns have duplicate.");
    return psJpCSi8_h7NzZZ1vbR(paramQ_, paramString, paramPK9FDpOut0CP81dMz, parampsJpCSi8_h7NzZZ1vbR, paramList, psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR());
  }
  
  @Deprecated
  public static BkAvsADz8w7ug psJpCSi8_h7NzZZ1vbR(Q_ paramQ_, String paramString, PK9FDpOut0CP81dMz paramPK9FDpOut0CP81dMz, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, List<LEIMjJ> paramList, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR1) {
    boolean bool;
    if ((new HashSet(paramList)).size() == paramList.size()) {
      bool = true;
    } else {
      bool = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Columns have duplicate.");
    paramList = new ArrayList<LEIMjJ>(paramList);
    Collections.sort(paramList, Q_);
    return new jlrPm(paramQ_, paramString, paramPK9FDpOut0CP81dMz, parampsJpCSi8_h7NzZZ1vbR, Collections.unmodifiableList(paramList), parampsJpCSi8_h7NzZZ1vbR1);
  }
  
  public abstract psJpCSi8_h7NzZZ1vbR D89UfNGBvLPp16h();
  
  @Deprecated
  public abstract psJpCSi8_h7NzZZ1vbR MxwALnHp3MNCI();
  
  public abstract String Q_();
  
  public abstract List<LEIMjJ> X9K8CXVSxZWf();
  
  public abstract PK9FDpOut0CP81dMz XV2I8z();
  
  public abstract Q_ psJpCSi8_h7NzZZ1vbR();
  
  public static abstract class Q_ {
    public static Q_ psJpCSi8_h7NzZZ1vbR(String param1String) {
      boolean bool;
      if (D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(param1String) && param1String.length() <= 255) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Name should be a ASCII string with a length no greater than 255 characters.");
      return new KRly__dqVzGwm1pz(param1String);
    }
    
    public abstract String psJpCSi8_h7NzZZ1vbR();
  }
  
  @Deprecated
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public abstract <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super Q_, T> param1wqn1, wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn2);
    
    @Deprecated
    public static abstract class Q_ extends psJpCSi8_h7NzZZ1vbR {
      private static final X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR = X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(0L, 0);
      
      public static Q_ psJpCSi8_h7NzZZ1vbR(X9K8CXVSxZWf param2X9K8CXVSxZWf) {
        boolean bool;
        if (param2X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR) > 0) {
          bool = true;
        } else {
          bool = false;
        } 
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Duration must be positive");
        return new AYieGTkN28B_(param2X9K8CXVSxZWf);
      }
      
      public abstract X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR();
      
      public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, T> param2wqn, wqn<? super Q_, T> param2wqn1, wqn<? super BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR, T> param2wqn2) {
        return (T)param2wqn1.psJpCSi8_h7NzZZ1vbR(this);
      }
    }
    
    @Deprecated
    public static abstract class psJpCSi8_h7NzZZ1vbR extends psJpCSi8_h7NzZZ1vbR {
      private static final psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = new RiEMPm5KxmvYEOsVplu5();
      
      public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
        return psJpCSi8_h7NzZZ1vbR;
      }
      
      public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param2wqn, wqn<? super BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.Q_, T> param2wqn1, wqn<? super BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR, T> param2wqn2) {
        return (T)param2wqn.psJpCSi8_h7NzZZ1vbR(this);
      }
    }
  }
  
  @Deprecated
  public static abstract class Q_ extends psJpCSi8_h7NzZZ1vbR {
    private static final X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR = X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(0L, 0);
    
    public static Q_ psJpCSi8_h7NzZZ1vbR(X9K8CXVSxZWf param1X9K8CXVSxZWf) {
      boolean bool;
      if (param1X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR) > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Duration must be positive");
      return new AYieGTkN28B_(param1X9K8CXVSxZWf);
    }
    
    public abstract X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super Q_, T> param1wqn1, wqn<? super BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR, T> param1wqn2) {
      return (T)param1wqn1.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  @Deprecated
  public static abstract class psJpCSi8_h7NzZZ1vbR extends psJpCSi8_h7NzZZ1vbR {
    private static final psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = new RiEMPm5KxmvYEOsVplu5();
    
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
      return psJpCSi8_h7NzZZ1vbR;
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.Q_, T> param1wqn1, wqn<? super BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR, T> param1wqn2) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\BkAvsADz8w7ug.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */