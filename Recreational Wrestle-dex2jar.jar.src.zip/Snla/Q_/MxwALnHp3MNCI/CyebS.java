package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wktp1mvgWsB4SzZr;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn;
import Snla.Q_.wqn.hzEmy;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class CyebS {
  private static CyebS Q_(BkAvsADz8w7ug paramBkAvsADz8w7ug, Map<List<hzEmy>, Q_> paramMap, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, LEwT0cz2WRRZ paramLEwT0cz2WRRZ1, LEwT0cz2WRRZ paramLEwT0cz2WRRZ2) {
    return new hhkWV822WvWIJ6d(paramBkAvsADz8w7ug, paramMap, parampsJpCSi8_h7NzZZ1vbR, paramLEwT0cz2WRRZ1, paramLEwT0cz2WRRZ2);
  }
  
  private static String Q_(BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR1) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AggregationWindow and AggregationWindowData types mismatch. AggregationWindow: ");
    stringBuilder.append(parampsJpCSi8_h7NzZZ1vbR.getClass().getSimpleName());
    stringBuilder.append(" AggregationWindowData: ");
    stringBuilder.append(parampsJpCSi8_h7NzZZ1vbR1.getClass().getSimpleName());
    return stringBuilder.toString();
  }
  
  private static void Q_(boolean paramBoolean, BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR1) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Q_(parampsJpCSi8_h7NzZZ1vbR, parampsJpCSi8_h7NzZZ1vbR1));
  }
  
  private static void Q_(boolean paramBoolean, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, Q_ paramQ_) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR, paramQ_));
  }
  
  @Deprecated
  public static CyebS psJpCSi8_h7NzZZ1vbR(BkAvsADz8w7ug paramBkAvsADz8w7ug, Map<? extends List<hzEmy>, ? extends Q_> paramMap, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    psJpCSi8_h7NzZZ1vbR(paramBkAvsADz8w7ug.MxwALnHp3MNCI(), parampsJpCSi8_h7NzZZ1vbR);
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (Map.Entry<? extends List<hzEmy>, ? extends Q_> entry : paramMap.entrySet()) {
      psJpCSi8_h7NzZZ1vbR(paramBkAvsADz8w7ug.D89UfNGBvLPp16h(), (Q_)entry.getValue(), paramBkAvsADz8w7ug.XV2I8z());
      hashMap.put(Collections.unmodifiableList(new ArrayList((Collection)entry.getKey())), entry.getValue());
    } 
    return parampsJpCSi8_h7NzZZ1vbR.<CyebS>psJpCSi8_h7NzZZ1vbR(new wqn<psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, CyebS>(paramBkAvsADz8w7ug, hashMap) {
          public CyebS psJpCSi8_h7NzZZ1vbR(CyebS.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
            return CyebS.psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR, Collections.unmodifiableMap(this.Q_), param1psJpCSi8_h7NzZZ1vbR, param1psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(), param1psJpCSi8_h7NzZZ1vbR.Q_());
          }
        }new wqn<psJpCSi8_h7NzZZ1vbR.Q_, CyebS>(paramBkAvsADz8w7ug, hashMap) {
          public CyebS psJpCSi8_h7NzZZ1vbR(CyebS.psJpCSi8_h7NzZZ1vbR.Q_ param1Q_) {
            X9K8CXVSxZWf x9K8CXVSxZWf = ((BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.Q_)this.psJpCSi8_h7NzZZ1vbR.MxwALnHp3MNCI()).psJpCSi8_h7NzZZ1vbR();
            return CyebS.psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR, Collections.unmodifiableMap(this.Q_), param1Q_, param1Q_.psJpCSi8_h7NzZZ1vbR().psJpCSi8_h7NzZZ1vbR(X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(-x9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(), -x9K8CXVSxZWf.Q_())), param1Q_.psJpCSi8_h7NzZZ1vbR());
          }
        }wktp1mvgWsB4SzZr.D89UfNGBvLPp16h());
  }
  
  public static CyebS psJpCSi8_h7NzZZ1vbR(BkAvsADz8w7ug paramBkAvsADz8w7ug, Map<? extends List<hzEmy>, ? extends Q_> paramMap, LEwT0cz2WRRZ paramLEwT0cz2WRRZ1, LEwT0cz2WRRZ paramLEwT0cz2WRRZ2) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (Map.Entry<? extends List<hzEmy>, ? extends Q_> entry : paramMap.entrySet()) {
      psJpCSi8_h7NzZZ1vbR(paramBkAvsADz8w7ug.D89UfNGBvLPp16h(), (Q_)entry.getValue(), paramBkAvsADz8w7ug.XV2I8z());
      hashMap.put(Collections.unmodifiableList(new ArrayList((Collection)entry.getKey())), entry.getValue());
    } 
    return Q_(paramBkAvsADz8w7ug, (Map)Collections.unmodifiableMap(hashMap), psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(paramLEwT0cz2WRRZ1, paramLEwT0cz2WRRZ2), paramLEwT0cz2WRRZ1, paramLEwT0cz2WRRZ2);
  }
  
  private static String psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, Q_ paramQ_) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Aggregation and AggregationData types mismatch. Aggregation: ");
    stringBuilder.append(parampsJpCSi8_h7NzZZ1vbR.getClass().getSimpleName());
    stringBuilder.append(" AggregationData: ");
    stringBuilder.append(paramQ_.getClass().getSimpleName());
    return stringBuilder.toString();
  }
  
  private static void psJpCSi8_h7NzZZ1vbR(BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR1) {
    parampsJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(new wqn<BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, Void>(parampsJpCSi8_h7NzZZ1vbR1) {
          public Void psJpCSi8_h7NzZZ1vbR(BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
            CyebS.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = this.psJpCSi8_h7NzZZ1vbR;
            CyebS.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR1 instanceof CyebS.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, param1psJpCSi8_h7NzZZ1vbR, psJpCSi8_h7NzZZ1vbR1);
            return null;
          }
        }new wqn<BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.Q_, Void>(parampsJpCSi8_h7NzZZ1vbR1) {
          public Void psJpCSi8_h7NzZZ1vbR(BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.Q_ param1Q_) {
            CyebS.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = this.psJpCSi8_h7NzZZ1vbR;
            CyebS.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR1 instanceof CyebS.psJpCSi8_h7NzZZ1vbR.Q_, param1Q_, psJpCSi8_h7NzZZ1vbR1);
            return null;
          }
        }wktp1mvgWsB4SzZr.D89UfNGBvLPp16h());
  }
  
  private static void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, Q_ paramQ_, PK9FDpOut0CP81dMz paramPK9FDpOut0CP81dMz) {
    parampsJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(new wqn<psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf, Void>(paramPK9FDpOut0CP81dMz, paramQ_, parampsJpCSi8_h7NzZZ1vbR) {
          public Void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf param1X9K8CXVSxZWf) {
            this.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(new wqn<PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR, Void>(this) {
                  public Void psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR param2psJpCSi8_h7NzZZ1vbR) {
                    CyebS.psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR.Q_ instanceof Q_.MxwALnHp3MNCI, this.psJpCSi8_h7NzZZ1vbR.XV2I8z, this.psJpCSi8_h7NzZZ1vbR.Q_);
                    return null;
                  }
                }new wqn<PK9FDpOut0CP81dMz.Q_, Void>(this) {
                  public Void psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.Q_ param2Q_) {
                    CyebS.psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR.Q_ instanceof Q_.wqn, this.psJpCSi8_h7NzZZ1vbR.XV2I8z, this.psJpCSi8_h7NzZZ1vbR.Q_);
                    return null;
                  }
                }wktp1mvgWsB4SzZr.D89UfNGBvLPp16h());
            return null;
          }
        }new wqn<psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, Void>(paramQ_, parampsJpCSi8_h7NzZZ1vbR) {
          public Void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
            Q_ q_ = this.psJpCSi8_h7NzZZ1vbR;
            CyebS.psJpCSi8_h7NzZZ1vbR(q_ instanceof Q_.psJpCSi8_h7NzZZ1vbR, this.Q_, q_);
            return null;
          }
        }new wqn<psJpCSi8_h7NzZZ1vbR.Q_, Void>(paramQ_, parampsJpCSi8_h7NzZZ1vbR) {
          public Void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR.Q_ param1Q_) {
            Q_ q_ = this.psJpCSi8_h7NzZZ1vbR;
            CyebS.psJpCSi8_h7NzZZ1vbR(q_ instanceof Q_.Q_, this.Q_, q_);
            return null;
          }
        }new wqn<psJpCSi8_h7NzZZ1vbR.XV2I8z, Void>(paramPK9FDpOut0CP81dMz, paramQ_, parampsJpCSi8_h7NzZZ1vbR) {
          public Void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR.XV2I8z param1XV2I8z) {
            this.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(new wqn<PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR, Void>(this) {
                  public Void psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR param2psJpCSi8_h7NzZZ1vbR) {
                    CyebS.psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR.Q_ instanceof Q_.XV2I8z, this.psJpCSi8_h7NzZZ1vbR.XV2I8z, this.psJpCSi8_h7NzZZ1vbR.Q_);
                    return null;
                  }
                }new wqn<PK9FDpOut0CP81dMz.Q_, Void>(this) {
                  public Void psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.Q_ param2Q_) {
                    CyebS.psJpCSi8_h7NzZZ1vbR(this.psJpCSi8_h7NzZZ1vbR.Q_ instanceof Q_.D89UfNGBvLPp16h, this.psJpCSi8_h7NzZZ1vbR.XV2I8z, this.psJpCSi8_h7NzZZ1vbR.Q_);
                    return null;
                  }
                }wktp1mvgWsB4SzZr.D89UfNGBvLPp16h());
            return null;
          }
        }new wqn<psJpCSi8_h7NzZZ1vbR, Void>(paramQ_, parampsJpCSi8_h7NzZZ1vbR) {
          public Void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
            if (param1psJpCSi8_h7NzZZ1vbR instanceof psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h) {
              Q_ q_ = this.psJpCSi8_h7NzZZ1vbR;
              CyebS.psJpCSi8_h7NzZZ1vbR(q_ instanceof Q_.X9K8CXVSxZWf, this.Q_, q_);
              return null;
            } 
            throw new AssertionError();
          }
        });
  }
  
  public abstract LEwT0cz2WRRZ D89UfNGBvLPp16h();
  
  public abstract Map<List<hzEmy>, Q_> Q_();
  
  public abstract LEwT0cz2WRRZ X9K8CXVSxZWf();
  
  @Deprecated
  public abstract psJpCSi8_h7NzZZ1vbR XV2I8z();
  
  public abstract BkAvsADz8w7ug psJpCSi8_h7NzZZ1vbR();
  
  @Deprecated
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public abstract <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super Q_, T> param1wqn1, wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn2);
    
    @Deprecated
    public static abstract class Q_ extends psJpCSi8_h7NzZZ1vbR {
      public static Q_ psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ param2LEwT0cz2WRRZ) {
        return new fc4RJByVvAciR(param2LEwT0cz2WRRZ);
      }
      
      public abstract LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR();
      
      public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super CyebS.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, T> param2wqn, wqn<? super Q_, T> param2wqn1, wqn<? super CyebS.psJpCSi8_h7NzZZ1vbR, T> param2wqn2) {
        return (T)param2wqn1.psJpCSi8_h7NzZZ1vbR(this);
      }
    }
    
    @Deprecated
    public static abstract class psJpCSi8_h7NzZZ1vbR extends psJpCSi8_h7NzZZ1vbR {
      public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ param2LEwT0cz2WRRZ1, LEwT0cz2WRRZ param2LEwT0cz2WRRZ2) {
        if (param2LEwT0cz2WRRZ1.Q_(param2LEwT0cz2WRRZ2) <= 0)
          return new aqqnPTeV(param2LEwT0cz2WRRZ1, param2LEwT0cz2WRRZ2); 
        throw new IllegalArgumentException("Start time is later than end time.");
      }
      
      public abstract LEwT0cz2WRRZ Q_();
      
      public abstract LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR();
      
      public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param2wqn, wqn<? super CyebS.psJpCSi8_h7NzZZ1vbR.Q_, T> param2wqn1, wqn<? super CyebS.psJpCSi8_h7NzZZ1vbR, T> param2wqn2) {
        return (T)param2wqn.psJpCSi8_h7NzZZ1vbR(this);
      }
    }
  }
  
  @Deprecated
  public static abstract class Q_ extends psJpCSi8_h7NzZZ1vbR {
    public static Q_ psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ param1LEwT0cz2WRRZ) {
      return new fc4RJByVvAciR(param1LEwT0cz2WRRZ);
    }
    
    public abstract LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super CyebS.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super Q_, T> param1wqn1, wqn<? super CyebS.psJpCSi8_h7NzZZ1vbR, T> param1wqn2) {
      return (T)param1wqn1.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  @Deprecated
  public static abstract class psJpCSi8_h7NzZZ1vbR extends psJpCSi8_h7NzZZ1vbR {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ param1LEwT0cz2WRRZ1, LEwT0cz2WRRZ param1LEwT0cz2WRRZ2) {
      if (param1LEwT0cz2WRRZ1.Q_(param1LEwT0cz2WRRZ2) <= 0)
        return new aqqnPTeV(param1LEwT0cz2WRRZ1, param1LEwT0cz2WRRZ2); 
      throw new IllegalArgumentException("Start time is later than end time.");
    }
    
    public abstract LEwT0cz2WRRZ Q_();
    
    public abstract LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super CyebS.psJpCSi8_h7NzZZ1vbR.Q_, T> param1wqn1, wqn<? super CyebS.psJpCSi8_h7NzZZ1vbR, T> param1wqn2) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\CyebS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */