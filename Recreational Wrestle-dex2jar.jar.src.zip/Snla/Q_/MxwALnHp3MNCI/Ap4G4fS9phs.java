package Snla.Q_.MxwALnHp3MNCI;

import java.util.List;
import java.util.Objects;

final class Ap4G4fS9phs extends DmG0HNQ6 {
  private final List<Double> psJpCSi8_h7NzZZ1vbR;
  
  Ap4G4fS9phs(List<Double> paramList) {
    Objects.requireNonNull(paramList, "Null boundaries");
    this.psJpCSi8_h7NzZZ1vbR = paramList;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof DmG0HNQ6) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public List<Double> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("BucketBoundaries{boundaries=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\Ap4G4fS9phs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */