package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wktp1mvgWsB4SzZr;
import Snla.Q_.wqn.wktp1mvgWsB4SzZr;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;

final class Q5BpP92bwE86mpl {
  static cN1 D89UfNGBvLPp16h() {
    return new D89UfNGBvLPp16h();
  }
  
  static jbUx Q_() {
    return XV2I8z.psJpCSi8_h7NzZZ1vbR;
  }
  
  static emjFZ1 XV2I8z() {
    return new psJpCSi8_h7NzZZ1vbR();
  }
  
  static uYZX7q8fRQtQu psJpCSi8_h7NzZZ1vbR() {
    return new Q_();
  }
  
  private static final class D89UfNGBvLPp16h extends cN1 {
    private static final LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR = LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR(0L, 0);
    
    private final Map<BkAvsADz8w7ug.Q_, BkAvsADz8w7ug> Q_ = new HashMap<BkAvsADz8w7ug.Q_, BkAvsADz8w7ug>();
    
    @Nullable
    private volatile Set<BkAvsADz8w7ug> XV2I8z;
    
    private D89UfNGBvLPp16h() {}
    
    private static Set<BkAvsADz8w7ug> psJpCSi8_h7NzZZ1vbR(Collection<BkAvsADz8w7ug> param1Collection) {
      HashSet<BkAvsADz8w7ug> hashSet = new HashSet();
      for (BkAvsADz8w7ug bkAvsADz8w7ug : param1Collection) {
        if (bkAvsADz8w7ug.MxwALnHp3MNCI() instanceof BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR.Q_)
          continue; 
        hashSet.add(bkAvsADz8w7ug);
      } 
      return Collections.unmodifiableSet(hashSet);
    }
    
    @Nullable
    public CyebS psJpCSi8_h7NzZZ1vbR(BkAvsADz8w7ug.Q_ param1Q_) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Q_, "name");
      synchronized (this.Q_) {
        BkAvsADz8w7ug bkAvsADz8w7ug = this.Q_.get(param1Q_);
        if (bkAvsADz8w7ug == null)
          return null; 
        Map<?, ?> map = Collections.emptyMap();
        BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = bkAvsADz8w7ug.MxwALnHp3MNCI();
        LEwT0cz2WRRZ lEwT0cz2WRRZ = psJpCSi8_h7NzZZ1vbR;
        return CyebS.psJpCSi8_h7NzZZ1vbR(bkAvsADz8w7ug, (Map)map, psJpCSi8_h7NzZZ1vbR.<CyebS.psJpCSi8_h7NzZZ1vbR>psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR(CyebS.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(lEwT0cz2WRRZ, lEwT0cz2WRRZ)), wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR(CyebS.psJpCSi8_h7NzZZ1vbR.Q_.psJpCSi8_h7NzZZ1vbR(lEwT0cz2WRRZ)), wktp1mvgWsB4SzZr.D89UfNGBvLPp16h()));
      } 
    }
    
    public Set<BkAvsADz8w7ug> psJpCSi8_h7NzZZ1vbR() {
      Set<BkAvsADz8w7ug> set = this.XV2I8z;
      if (set == null)
        synchronized (this.Q_) {
          Set<BkAvsADz8w7ug> set1 = psJpCSi8_h7NzZZ1vbR(this.Q_.values());
          this.XV2I8z = set1;
          return set1;
        }  
      return set;
    }
    
    public void psJpCSi8_h7NzZZ1vbR(BkAvsADz8w7ug param1BkAvsADz8w7ug) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1BkAvsADz8w7ug, "newView");
      synchronized (this.Q_) {
        boolean bool;
        this.XV2I8z = null;
        BkAvsADz8w7ug bkAvsADz8w7ug = this.Q_.get(param1BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR());
        if (bkAvsADz8w7ug == null || param1BkAvsADz8w7ug.equals(bkAvsADz8w7ug)) {
          bool = true;
        } else {
          bool = false;
        } 
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "A different view with the same name already exists.");
        if (bkAvsADz8w7ug == null)
          this.Q_.put(param1BkAvsADz8w7ug.psJpCSi8_h7NzZZ1vbR(), param1BkAvsADz8w7ug); 
        return;
      } 
    }
  }
  
  private static final class Q_ extends uYZX7q8fRQtQu {
    private volatile boolean Q_;
    
    private final cN1 psJpCSi8_h7NzZZ1vbR = Q5BpP92bwE86mpl.D89UfNGBvLPp16h();
    
    private Q_() {}
    
    public jbUx Q_() {
      return Q5BpP92bwE86mpl.Q_();
    }
    
    public iWguP_fQsmao2bBu1lU XV2I8z() {
      this.Q_ = true;
      return iWguP_fQsmao2bBu1lU.Q_;
    }
    
    public cN1 psJpCSi8_h7NzZZ1vbR() {
      return this.psJpCSi8_h7NzZZ1vbR;
    }
    
    @Deprecated
    public void psJpCSi8_h7NzZZ1vbR(iWguP_fQsmao2bBu1lU param1iWguP_fQsmao2bBu1lU) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1iWguP_fQsmao2bBu1lU, "state");
      X9K8CXVSxZWf.Q_(this.Q_ ^ true, "State was already read, cannot set state.");
    }
  }
  
  private static final class XV2I8z extends jbUx {
    static final jbUx psJpCSi8_h7NzZZ1vbR = new XV2I8z();
    
    public emjFZ1 psJpCSi8_h7NzZZ1vbR() {
      return Q5BpP92bwE86mpl.XV2I8z();
    }
  }
  
  private static final class psJpCSi8_h7NzZZ1vbR extends emjFZ1 {
    private static final Logger psJpCSi8_h7NzZZ1vbR = Logger.getLogger(psJpCSi8_h7NzZZ1vbR.class.getName());
    
    private boolean Q_;
    
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public emjFZ1 psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.Q_ param1Q_, long param1Long) {
      if (param1Long < 0L)
        this.Q_ = true; 
      return this;
    }
    
    public emjFZ1 psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR, double param1Double) {
      if (param1Double < 0.0D)
        this.Q_ = true; 
      return this;
    }
    
    public void psJpCSi8_h7NzZZ1vbR() {}
    
    public void psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr param1wktp1mvgWsB4SzZr) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1wktp1mvgWsB4SzZr, "tags");
      if (this.Q_)
        psJpCSi8_h7NzZZ1vbR.log(Level.WARNING, "Dropping values, value to record must be non-negative."); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\Q5BpP92bwE86mpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */