package Snla.Q_.MxwALnHp3MNCI;

import java.util.List;
import java.util.Objects;

final class D89UfNGBvLPp16h extends Q_.Q_ {
  private final List<Long> D89UfNGBvLPp16h;
  
  private final long Q_;
  
  private final List<Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h> X9K8CXVSxZWf;
  
  private final double XV2I8z;
  
  private final double psJpCSi8_h7NzZZ1vbR;
  
  D89UfNGBvLPp16h(double paramDouble1, long paramLong, double paramDouble2, List<Long> paramList, List<Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h> paramList1) {
    this.psJpCSi8_h7NzZZ1vbR = paramDouble1;
    this.Q_ = paramLong;
    this.XV2I8z = paramDouble2;
    Objects.requireNonNull(paramList, "Null bucketCounts");
    this.D89UfNGBvLPp16h = paramList;
    Objects.requireNonNull(paramList1, "Null exemplars");
    this.X9K8CXVSxZWf = paramList1;
  }
  
  public List<Long> MxwALnHp3MNCI() {
    return this.D89UfNGBvLPp16h;
  }
  
  public long Q_() {
    return this.Q_;
  }
  
  public double X9K8CXVSxZWf() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Q_.Q_) {
      paramObject = paramObject;
      return (Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) == Double.doubleToLongBits(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_ == paramObject.Q_() && Double.doubleToLongBits(this.XV2I8z) == Double.doubleToLongBits(paramObject.X9K8CXVSxZWf()) && this.D89UfNGBvLPp16h.equals(paramObject.MxwALnHp3MNCI()) && this.X9K8CXVSxZWf.equals(paramObject.wqn()));
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = ((int)(1000003L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) >>> 32L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR)) * 1000003);
    long l2 = this.Q_;
    int i = (int)(((int)(l1 ^ l2 ^ l2 >>> 32L) * 1000003) ^ Double.doubleToLongBits(this.XV2I8z) >>> 32L ^ Double.doubleToLongBits(this.XV2I8z));
    int j = this.D89UfNGBvLPp16h.hashCode();
    return this.X9K8CXVSxZWf.hashCode() ^ (i * 1000003 ^ j) * 1000003;
  }
  
  public double psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DistributionData{mean=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", count=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", sumOfSquaredDeviations=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", bucketCounts=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append(", exemplars=");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public List<Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h> wqn() {
    return this.X9K8CXVSxZWf;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */