package Snla.Q_.MxwALnHp3MNCI;

public enum iWguP_fQsmao2bBu1lU {
  Q_, psJpCSi8_h7NzZZ1vbR;
  
  static {
    iWguP_fQsmao2bBu1lU iWguP_fQsmao2bBu1lU1 = new iWguP_fQsmao2bBu1lU("ENABLED", 0);
    psJpCSi8_h7NzZZ1vbR = iWguP_fQsmao2bBu1lU1;
    iWguP_fQsmao2bBu1lU iWguP_fQsmao2bBu1lU2 = new iWguP_fQsmao2bBu1lU("DISABLED", 1);
    Q_ = iWguP_fQsmao2bBu1lU2;
    XV2I8z = new iWguP_fQsmao2bBu1lU[] { iWguP_fQsmao2bBu1lU1, iWguP_fQsmao2bBu1lU2 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\iWguP_fQsmao2bBu1lU.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */