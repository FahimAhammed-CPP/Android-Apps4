package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import java.util.Objects;

@Deprecated
final class fc4RJByVvAciR extends CyebS.psJpCSi8_h7NzZZ1vbR.Q_ {
  private final LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR;
  
  fc4RJByVvAciR(LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    Objects.requireNonNull(paramLEwT0cz2WRRZ, "Null end");
    this.psJpCSi8_h7NzZZ1vbR = paramLEwT0cz2WRRZ;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof CyebS.psJpCSi8_h7NzZZ1vbR.Q_) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("IntervalData{end=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\fc4RJByVvAciR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */