package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.XV2I8z.D89UfNGBvLPp16h;
import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn;

public abstract class PK9FDpOut0CP81dMz {
  private static final String Q_ = "Name should be a ASCII string with a length no greater than 255 characters.";
  
  static final int psJpCSi8_h7NzZZ1vbR = 255;
  
  private PK9FDpOut0CP81dMz() {}
  
  public abstract String Q_();
  
  public abstract String XV2I8z();
  
  public abstract <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> paramwqn, wqn<? super Q_, T> paramwqn1, wqn<? super PK9FDpOut0CP81dMz, T> paramwqn2);
  
  public abstract String psJpCSi8_h7NzZZ1vbR();
  
  public static abstract class Q_ extends PK9FDpOut0CP81dMz {
    public static Q_ psJpCSi8_h7NzZZ1vbR(String param1String1, String param1String2, String param1String3) {
      boolean bool;
      if (D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(param1String1) && param1String1.length() <= 255) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Name should be a ASCII string with a length no greater than 255 characters.");
      return new oq9TzoD0(param1String1, param1String2, param1String3);
    }
    
    public abstract String Q_();
    
    public abstract String XV2I8z();
    
    public <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super Q_, T> param1wqn1, wqn<? super PK9FDpOut0CP81dMz, T> param1wqn2) {
      return (T)param1wqn1.psJpCSi8_h7NzZZ1vbR(this);
    }
    
    public abstract String psJpCSi8_h7NzZZ1vbR();
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR extends PK9FDpOut0CP81dMz {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String1, String param1String2, String param1String3) {
      boolean bool;
      if (D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(param1String1) && param1String1.length() <= 255) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Name should be a ASCII string with a length no greater than 255 characters.");
      return new GUkgqR9XjHnivS(param1String1, param1String2, param1String3);
    }
    
    public abstract String Q_();
    
    public abstract String XV2I8z();
    
    public <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super PK9FDpOut0CP81dMz.Q_, T> param1wqn1, wqn<? super PK9FDpOut0CP81dMz, T> param1wqn2) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(this);
    }
    
    public abstract String psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\PK9FDpOut0CP81dMz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */