package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class DmG0HNQ6 {
  private static final Logger psJpCSi8_h7NzZZ1vbR = Logger.getLogger(DmG0HNQ6.class.getName());
  
  private static List<Double> Q_(List<Double> paramList) {
    Iterator<Double> iterator = paramList.iterator();
    int j = 0;
    int i = 0;
    while (iterator.hasNext()) {
      Double double_ = iterator.next();
      if (double_.doubleValue() <= 0.0D) {
        if (double_.doubleValue() == 0.0D) {
          i++;
          continue;
        } 
        j++;
      } 
    } 
    if (j > 0) {
      Logger logger = psJpCSi8_h7NzZZ1vbR;
      Level level = Level.WARNING;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping ");
      stringBuilder.append(j);
      stringBuilder.append(" negative bucket boundaries, the values must be strictly > 0.");
      logger.log(level, stringBuilder.toString());
    } 
    return paramList.subList(j + i, paramList.size());
  }
  
  public static final DmG0HNQ6 psJpCSi8_h7NzZZ1vbR(List<Double> paramList) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramList, "bucketBoundaries");
    paramList = new ArrayList<Double>(paramList);
    if (paramList.size() > 1) {
      double d = ((Double)paramList.get(0)).doubleValue();
      int i = 1;
      while (i < paramList.size()) {
        boolean bool;
        double d1 = ((Double)paramList.get(i)).doubleValue();
        if (d < d1) {
          bool = true;
        } else {
          bool = false;
        } 
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Bucket boundaries not sorted.");
        i++;
        d = d1;
      } 
    } 
    return new Ap4G4fS9phs(Collections.unmodifiableList(Q_(paramList)));
  }
  
  public abstract List<Double> psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\DmG0HNQ6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */