package Snla.Q_.MxwALnHp3MNCI;

public abstract class jbUx {
  public abstract emjFZ1 psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\jbUx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */