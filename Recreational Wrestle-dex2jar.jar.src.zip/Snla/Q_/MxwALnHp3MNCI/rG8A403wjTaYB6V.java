package Snla.Q_.MxwALnHp3MNCI;

@Deprecated
final class rG8A403wjTaYB6V extends psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h {
  public boolean equals(Object paramObject) {
    return (paramObject == this) ? true : ((paramObject instanceof psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h));
  }
  
  public int hashCode() {
    return 1;
  }
  
  public String toString() {
    return "Mean{}";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\rG8A403wjTaYB6V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */