package Snla.Q_.MxwALnHp3MNCI;

final class X9K8CXVSxZWf extends Q_.XV2I8z {
  private final double psJpCSi8_h7NzZZ1vbR;
  
  X9K8CXVSxZWf(double paramDouble) {
    this.psJpCSi8_h7NzZZ1vbR = paramDouble;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Q_.XV2I8z) {
      paramObject = paramObject;
      return (Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) == Double.doubleToLongBits(paramObject.psJpCSi8_h7NzZZ1vbR()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (int)(1000003L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) >>> 32L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR));
  }
  
  public double psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LastValueDataDouble{lastValue=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */