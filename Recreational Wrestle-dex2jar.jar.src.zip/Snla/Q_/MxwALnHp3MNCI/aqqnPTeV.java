package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import java.util.Objects;

@Deprecated
final class aqqnPTeV extends CyebS.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR {
  private final LEwT0cz2WRRZ Q_;
  
  private final LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR;
  
  aqqnPTeV(LEwT0cz2WRRZ paramLEwT0cz2WRRZ1, LEwT0cz2WRRZ paramLEwT0cz2WRRZ2) {
    Objects.requireNonNull(paramLEwT0cz2WRRZ1, "Null start");
    this.psJpCSi8_h7NzZZ1vbR = paramLEwT0cz2WRRZ1;
    Objects.requireNonNull(paramLEwT0cz2WRRZ2, "Null end");
    this.Q_ = paramLEwT0cz2WRRZ2;
  }
  
  public LEwT0cz2WRRZ Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof CyebS.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode();
  }
  
  public LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CumulativeData{start=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", end=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\aqqnPTeV.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */