package Snla.Q_.MxwALnHp3MNCI;

import java.util.Objects;

final class KRly__dqVzGwm1pz extends BkAvsADz8w7ug.Q_ {
  private final String psJpCSi8_h7NzZZ1vbR;
  
  KRly__dqVzGwm1pz(String paramString) {
    Objects.requireNonNull(paramString, "Null asString");
    this.psJpCSi8_h7NzZZ1vbR = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof BkAvsADz8w7ug.Q_) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Name{asString=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\KRly__dqVzGwm1pz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */