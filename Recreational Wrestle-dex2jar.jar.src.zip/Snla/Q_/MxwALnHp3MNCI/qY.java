package Snla.Q_.MxwALnHp3MNCI;

import java.util.Objects;

final class qY extends psJpCSi8_h7NzZZ1vbR.Q_ {
  private final DmG0HNQ6 psJpCSi8_h7NzZZ1vbR;
  
  qY(DmG0HNQ6 paramDmG0HNQ6) {
    Objects.requireNonNull(paramDmG0HNQ6, "Null bucketBoundaries");
    this.psJpCSi8_h7NzZZ1vbR = paramDmG0HNQ6;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof psJpCSi8_h7NzZZ1vbR.Q_) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public DmG0HNQ6 psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Distribution{bucketBoundaries=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\qY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */