package Snla.Q_.MxwALnHp3MNCI;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public abstract class Q_ {
  private Q_() {}
  
  public abstract <T> T psJpCSi8_h7NzZZ1vbR(Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super MxwALnHp3MNCI, T> paramwqn, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super wqn, T> paramwqn1, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super psJpCSi8_h7NzZZ1vbR, T> paramwqn2, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> paramwqn3, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super XV2I8z, T> paramwqn4, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super D89UfNGBvLPp16h, T> paramwqn5, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> paramwqn6);
  
  public static abstract class D89UfNGBvLPp16h extends Q_ {
    public static D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR(long param1Long) {
      return new MxwALnHp3MNCI(param1Long);
    }
    
    public abstract long psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.MxwALnHp3MNCI, T> param1wqn, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.wqn, T> param1wqn1, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.psJpCSi8_h7NzZZ1vbR, T> param1wqn2, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.Q_, T> param1wqn3, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.XV2I8z, T> param1wqn4, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super D89UfNGBvLPp16h, T> param1wqn5, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> param1wqn6) {
      return (T)param1wqn5.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class MxwALnHp3MNCI extends Q_ {
    public static MxwALnHp3MNCI psJpCSi8_h7NzZZ1vbR(double param1Double) {
      return new wktp1mvgWsB4SzZr(param1Double);
    }
    
    public abstract double psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super MxwALnHp3MNCI, T> param1wqn, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.wqn, T> param1wqn1, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.psJpCSi8_h7NzZZ1vbR, T> param1wqn2, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.Q_, T> param1wqn3, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.XV2I8z, T> param1wqn4, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.D89UfNGBvLPp16h, T> param1wqn5, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> param1wqn6) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class Q_ extends Q_ {
    @Deprecated
    public static Q_ psJpCSi8_h7NzZZ1vbR(double param1Double1, long param1Long, double param1Double2, double param1Double3, double param1Double4, List<Long> param1List) {
      return psJpCSi8_h7NzZZ1vbR(param1Double1, param1Long, param1Double4, param1List, Collections.emptyList());
    }
    
    @Deprecated
    public static Q_ psJpCSi8_h7NzZZ1vbR(double param1Double1, long param1Long, double param1Double2, double param1Double3, double param1Double4, List<Long> param1List, List<Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h> param1List1) {
      return psJpCSi8_h7NzZZ1vbR(param1Double1, param1Long, param1Double4, param1List, param1List1);
    }
    
    public static Q_ psJpCSi8_h7NzZZ1vbR(double param1Double1, long param1Long, double param1Double2, List<Long> param1List) {
      return psJpCSi8_h7NzZZ1vbR(param1Double1, param1Long, param1Double2, param1List, Collections.emptyList());
    }
    
    public static Q_ psJpCSi8_h7NzZZ1vbR(double param1Double1, long param1Long, double param1Double2, List<Long> param1List, List<Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h> param1List1) {
      param1List = Collections.unmodifiableList(new ArrayList<Long>((Collection<? extends Long>)Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List, "bucketCounts")));
      Iterator<Long> iterator = param1List.iterator();
      while (iterator.hasNext())
        Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(iterator.next(), "bucketCount"); 
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List1, "exemplars");
      iterator = (Iterator)param1List1.iterator();
      while (iterator.hasNext())
        Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(iterator.next(), "exemplar"); 
      return new D89UfNGBvLPp16h(param1Double1, param1Long, param1Double2, param1List, Collections.unmodifiableList(new ArrayList<Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h>(param1List1)));
    }
    
    @Deprecated
    public double D89UfNGBvLPp16h() {
      return 0.0D;
    }
    
    public abstract List<Long> MxwALnHp3MNCI();
    
    public abstract long Q_();
    
    public abstract double X9K8CXVSxZWf();
    
    @Deprecated
    public double XV2I8z() {
      return 0.0D;
    }
    
    public abstract double psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.MxwALnHp3MNCI, T> param1wqn, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.wqn, T> param1wqn1, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.psJpCSi8_h7NzZZ1vbR, T> param1wqn2, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> param1wqn3, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.XV2I8z, T> param1wqn4, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.D89UfNGBvLPp16h, T> param1wqn5, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> param1wqn6) {
      return (T)param1wqn3.psJpCSi8_h7NzZZ1vbR(this);
    }
    
    public abstract List<Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h> wqn();
  }
  
  @Deprecated
  public static abstract class X9K8CXVSxZWf extends Q_ {
    public static X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR(double param1Double, long param1Long) {
      return new wqn(param1Double, param1Long);
    }
    
    public abstract long Q_();
    
    public abstract double psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.MxwALnHp3MNCI, T> param1wqn, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.wqn, T> param1wqn1, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.psJpCSi8_h7NzZZ1vbR, T> param1wqn2, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.Q_, T> param1wqn3, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.XV2I8z, T> param1wqn4, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.D89UfNGBvLPp16h, T> param1wqn5, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> param1wqn6) {
      return (T)param1wqn6.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class XV2I8z extends Q_ {
    public static XV2I8z psJpCSi8_h7NzZZ1vbR(double param1Double) {
      return new X9K8CXVSxZWf(param1Double);
    }
    
    public abstract double psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.MxwALnHp3MNCI, T> param1wqn, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.wqn, T> param1wqn1, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.psJpCSi8_h7NzZZ1vbR, T> param1wqn2, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.Q_, T> param1wqn3, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super XV2I8z, T> param1wqn4, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.D89UfNGBvLPp16h, T> param1wqn5, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> param1wqn6) {
      return (T)param1wqn4.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR extends Q_ {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(long param1Long) {
      return new XV2I8z(param1Long);
    }
    
    public abstract long psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.MxwALnHp3MNCI, T> param1wqn, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.wqn, T> param1wqn1, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn2, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.Q_, T> param1wqn3, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.XV2I8z, T> param1wqn4, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.D89UfNGBvLPp16h, T> param1wqn5, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> param1wqn6) {
      return (T)param1wqn2.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
  
  public static abstract class wqn extends Q_ {
    public static wqn psJpCSi8_h7NzZZ1vbR(long param1Long) {
      return new BIRpv(param1Long);
    }
    
    public abstract long psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.MxwALnHp3MNCI, T> param1wqn, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super wqn, T> param1wqn1, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.psJpCSi8_h7NzZZ1vbR, T> param1wqn2, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.Q_, T> param1wqn3, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.XV2I8z, T> param1wqn4, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_.D89UfNGBvLPp16h, T> param1wqn5, Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn<? super Q_, T> param1wqn6) {
      return (T)param1wqn1.psJpCSi8_h7NzZZ1vbR(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */