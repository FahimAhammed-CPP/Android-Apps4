package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;
import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.wqn.wktp1mvgWsB4SzZr;

public abstract class emjFZ1 {
  public abstract emjFZ1 psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.Q_ paramQ_, long paramLong);
  
  public abstract emjFZ1 psJpCSi8_h7NzZZ1vbR(PK9FDpOut0CP81dMz.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, double paramDouble);
  
  public emjFZ1 psJpCSi8_h7NzZZ1vbR(String paramString, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramString, "key");
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR, "value");
    return this;
  }
  
  @Deprecated
  public emjFZ1 psJpCSi8_h7NzZZ1vbR(String paramString1, String paramString2) {
    return psJpCSi8_h7NzZZ1vbR(paramString1, (psJpCSi8_h7NzZZ1vbR)psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(paramString2));
  }
  
  public abstract void psJpCSi8_h7NzZZ1vbR();
  
  public abstract void psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr paramwktp1mvgWsB4SzZr);
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\emjFZ1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */