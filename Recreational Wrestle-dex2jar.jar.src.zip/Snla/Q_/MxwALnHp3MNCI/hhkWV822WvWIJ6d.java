package Snla.Q_.MxwALnHp3MNCI;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import Snla.Q_.wqn.hzEmy;
import java.util.List;
import java.util.Map;
import java.util.Objects;

final class hhkWV822WvWIJ6d extends CyebS {
  private final LEwT0cz2WRRZ D89UfNGBvLPp16h;
  
  private final Map<List<hzEmy>, Q_> Q_;
  
  private final LEwT0cz2WRRZ X9K8CXVSxZWf;
  
  private final CyebS.psJpCSi8_h7NzZZ1vbR XV2I8z;
  
  private final BkAvsADz8w7ug psJpCSi8_h7NzZZ1vbR;
  
  hhkWV822WvWIJ6d(BkAvsADz8w7ug paramBkAvsADz8w7ug, Map<List<hzEmy>, Q_> paramMap, CyebS.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, LEwT0cz2WRRZ paramLEwT0cz2WRRZ1, LEwT0cz2WRRZ paramLEwT0cz2WRRZ2) {
    Objects.requireNonNull(paramBkAvsADz8w7ug, "Null view");
    this.psJpCSi8_h7NzZZ1vbR = paramBkAvsADz8w7ug;
    Objects.requireNonNull(paramMap, "Null aggregationMap");
    this.Q_ = paramMap;
    Objects.requireNonNull(parampsJpCSi8_h7NzZZ1vbR, "Null windowData");
    this.XV2I8z = parampsJpCSi8_h7NzZZ1vbR;
    Objects.requireNonNull(paramLEwT0cz2WRRZ1, "Null start");
    this.D89UfNGBvLPp16h = paramLEwT0cz2WRRZ1;
    Objects.requireNonNull(paramLEwT0cz2WRRZ2, "Null end");
    this.X9K8CXVSxZWf = paramLEwT0cz2WRRZ2;
  }
  
  public LEwT0cz2WRRZ D89UfNGBvLPp16h() {
    return this.D89UfNGBvLPp16h;
  }
  
  public Map<List<hzEmy>, Q_> Q_() {
    return this.Q_;
  }
  
  public LEwT0cz2WRRZ X9K8CXVSxZWf() {
    return this.X9K8CXVSxZWf;
  }
  
  @Deprecated
  public CyebS.psJpCSi8_h7NzZZ1vbR XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof CyebS) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()) && this.XV2I8z.equals(paramObject.XV2I8z()) && this.D89UfNGBvLPp16h.equals(paramObject.D89UfNGBvLPp16h()) && this.X9K8CXVSxZWf.equals(paramObject.X9K8CXVSxZWf()));
    } 
    return false;
  }
  
  public int hashCode() {
    return ((((this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode()) * 1000003 ^ this.XV2I8z.hashCode()) * 1000003 ^ this.D89UfNGBvLPp16h.hashCode()) * 1000003 ^ this.X9K8CXVSxZWf.hashCode();
  }
  
  public BkAvsADz8w7ug psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ViewData{view=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", aggregationMap=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", windowData=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", start=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append(", end=");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\hhkWV822WvWIJ6d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */