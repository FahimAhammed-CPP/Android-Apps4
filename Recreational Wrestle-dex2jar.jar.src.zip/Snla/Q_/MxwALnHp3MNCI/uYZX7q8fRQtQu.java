package Snla.Q_.MxwALnHp3MNCI;

public abstract class uYZX7q8fRQtQu {
  public abstract jbUx Q_();
  
  public abstract iWguP_fQsmao2bBu1lU XV2I8z();
  
  public abstract cN1 psJpCSi8_h7NzZZ1vbR();
  
  @Deprecated
  public abstract void psJpCSi8_h7NzZZ1vbR(iWguP_fQsmao2bBu1lU paramiWguP_fQsmao2bBu1lU);
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNC\\uYZX7q8fRQtQu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */