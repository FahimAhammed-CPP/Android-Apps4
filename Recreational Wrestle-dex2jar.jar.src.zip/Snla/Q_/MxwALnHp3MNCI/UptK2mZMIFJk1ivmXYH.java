package Snla.Q_.MxwALnHp3MNCI;

import java.util.Objects;

final class UptK2mZMIFJk1ivmXYH extends bCcldirtq3agvRAiIT.Q_ {
  private final long Q_;
  
  private final PK9FDpOut0CP81dMz.Q_ psJpCSi8_h7NzZZ1vbR;
  
  UptK2mZMIFJk1ivmXYH(PK9FDpOut0CP81dMz.Q_ paramQ_, long paramLong) {
    Objects.requireNonNull(paramQ_, "Null measure");
    this.psJpCSi8_h7NzZZ1vbR = paramQ_;
    this.Q_ = paramLong;
  }
  
  public long Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof bCcldirtq3agvRAiIT.Q_) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_ == paramObject.Q_());
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = ((this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003);
    long l2 = this.Q_;
    return (int)(l1 ^ l2 ^ l2 >>> 32L);
  }
  
  public PK9FDpOut0CP81dMz.Q_ psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MeasurementLong{measure=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", value=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\MxwALnHp3MNCI\UptK2mZMIFJk1ivmXYH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */