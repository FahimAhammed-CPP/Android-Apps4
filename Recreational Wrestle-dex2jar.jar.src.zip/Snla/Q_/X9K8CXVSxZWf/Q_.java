package Snla.Q_.X9K8CXVSxZWf;

import Snla.Q_.XV2I8z.D89UfNGBvLPp16h;
import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public abstract class Q_ {
  private static final Map<String, String> BIRpv;
  
  private static final String D89UfNGBvLPp16h = ",";
  
  private static final String MxwALnHp3MNCI = " should be a ASCII string with a length greater than 0 and not exceed 255 characters.";
  
  private static final String Q_ = "OC_RESOURCE_TYPE";
  
  private static final String X9K8CXVSxZWf = "=";
  
  private static final String XV2I8z = "OC_RESOURCE_LABELS";
  
  static final int psJpCSi8_h7NzZZ1vbR = 255;
  
  @Nullable
  private static final String wktp1mvgWsB4SzZr = psJpCSi8_h7NzZZ1vbR(System.getenv("OC_RESOURCE_TYPE"));
  
  private static final String wqn = " should be a ASCII string with a length not exceed 255 characters.";
  
  static {
    BIRpv = Q_(System.getenv("OC_RESOURCE_LABELS"));
  }
  
  private static boolean D89UfNGBvLPp16h(String paramString) {
    return (!paramString.isEmpty() && XV2I8z(paramString));
  }
  
  private static Q_ Q_(@Nullable String paramString, Map<String, String> paramMap) {
    return new psJpCSi8_h7NzZZ1vbR(paramString, paramMap);
  }
  
  static Map<String, String> Q_(@Nullable String paramString) {
    if (paramString == null)
      return Collections.emptyMap(); 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    String[] arrayOfString = paramString.split(",", -1);
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      String[] arrayOfString1 = arrayOfString[i].split("=", -1);
      if (arrayOfString1.length == 2) {
        String str1 = arrayOfString1[0].trim();
        String str2 = arrayOfString1[1].trim().replaceAll("^\"|\"$", "");
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(D89UfNGBvLPp16h(str1), "Label key should be a ASCII string with a length greater than 0 and not exceed 255 characters.");
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(XV2I8z(str2), "Label value should be a ASCII string with a length not exceed 255 characters.");
        hashMap.put(str1, str2);
      } 
    } 
    return (Map)Collections.unmodifiableMap(hashMap);
  }
  
  public static Q_ XV2I8z() {
    return Q_(wktp1mvgWsB4SzZr, BIRpv);
  }
  
  private static boolean XV2I8z(String paramString) {
    return (paramString.length() <= 255 && D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(paramString));
  }
  
  @Nullable
  private static Q_ psJpCSi8_h7NzZZ1vbR(@Nullable Q_ paramQ_1, @Nullable Q_ paramQ_2) {
    String str;
    if (paramQ_2 == null)
      return paramQ_1; 
    if (paramQ_1 == null)
      return paramQ_2; 
    if (paramQ_1.psJpCSi8_h7NzZZ1vbR() != null) {
      str = paramQ_1.psJpCSi8_h7NzZZ1vbR();
    } else {
      str = paramQ_2.psJpCSi8_h7NzZZ1vbR();
    } 
    LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<String, String>(paramQ_2.Q_());
    for (Map.Entry<String, String> entry : paramQ_1.Q_().entrySet())
      linkedHashMap.put((String)entry.getKey(), (String)entry.getValue()); 
    return Q_(str, Collections.unmodifiableMap(linkedHashMap));
  }
  
  public static Q_ psJpCSi8_h7NzZZ1vbR(@Nullable String paramString, Map<String, String> paramMap) {
    return Q_(paramString, Collections.unmodifiableMap(new LinkedHashMap<String, String>((Map<? extends String, ? extends String>)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramMap, "labels"))));
  }
  
  @Nullable
  public static Q_ psJpCSi8_h7NzZZ1vbR(List<Q_> paramList) {
    Q_ q_;
    Iterator<Q_> iterator = paramList.iterator();
    paramList = null;
    while (iterator.hasNext())
      q_ = psJpCSi8_h7NzZZ1vbR((Q_)paramList, iterator.next()); 
    return q_;
  }
  
  @Nullable
  static String psJpCSi8_h7NzZZ1vbR(@Nullable String paramString) {
    String str = paramString;
    if (paramString != null) {
      str = paramString;
      if (!paramString.isEmpty()) {
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(D89UfNGBvLPp16h(paramString), "Type should be a ASCII string with a length greater than 0 and not exceed 255 characters.");
        str = paramString.trim();
      } 
    } 
    return str;
  }
  
  public abstract Map<String, String> Q_();
  
  @Nullable
  public abstract String psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\X9K8CXVSxZWf\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */