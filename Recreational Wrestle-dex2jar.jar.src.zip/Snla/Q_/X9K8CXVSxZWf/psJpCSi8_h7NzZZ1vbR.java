package Snla.Q_.X9K8CXVSxZWf;

import java.util.Map;
import java.util.Objects;
import javax.annotation.Nullable;

final class psJpCSi8_h7NzZZ1vbR extends Q_ {
  private final String Q_;
  
  private final Map<String, String> XV2I8z;
  
  psJpCSi8_h7NzZZ1vbR(@Nullable String paramString, Map<String, String> paramMap) {
    this.Q_ = paramString;
    Objects.requireNonNull(paramMap, "Null labels");
    this.XV2I8z = paramMap;
  }
  
  public Map<String, String> Q_() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Q_) {
      paramObject = paramObject;
      String str = this.Q_;
      return (((str == null) ? (paramObject.psJpCSi8_h7NzZZ1vbR() == null) : str.equals(paramObject.psJpCSi8_h7NzZZ1vbR())) && this.XV2I8z.equals(paramObject.Q_()));
    } 
    return false;
  }
  
  public int hashCode() {
    int i;
    String str = this.Q_;
    if (str == null) {
      i = 0;
    } else {
      i = str.hashCode();
    } 
    return (i ^ 0xF4243) * 1000003 ^ this.XV2I8z.hashCode();
  }
  
  @Nullable
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.Q_;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Resource{type=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", labels=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\X9K8CXVSxZWf\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */