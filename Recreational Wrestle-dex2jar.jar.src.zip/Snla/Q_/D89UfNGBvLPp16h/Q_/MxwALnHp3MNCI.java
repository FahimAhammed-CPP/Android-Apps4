package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import java.util.Objects;

final class MxwALnHp3MNCI extends hhkWV822WvWIJ6d {
  private final LEwT0cz2WRRZ Q_;
  
  private final RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR;
  
  MxwALnHp3MNCI(RiEMPm5KxmvYEOsVplu5 paramRiEMPm5KxmvYEOsVplu5, LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    Objects.requireNonNull(paramRiEMPm5KxmvYEOsVplu5, "Null value");
    this.psJpCSi8_h7NzZZ1vbR = paramRiEMPm5KxmvYEOsVplu5;
    Objects.requireNonNull(paramLEwT0cz2WRRZ, "Null timestamp");
    this.Q_ = paramLEwT0cz2WRRZ;
  }
  
  public LEwT0cz2WRRZ Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof hhkWV822WvWIJ6d) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode();
  }
  
  public RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Point{value=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", timestamp=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\MxwALnHp3MNCI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */