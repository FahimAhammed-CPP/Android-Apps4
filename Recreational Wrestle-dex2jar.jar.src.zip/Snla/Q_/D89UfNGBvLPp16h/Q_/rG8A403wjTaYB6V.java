package Snla.Q_.D89UfNGBvLPp16h.Q_;

final class rG8A403wjTaYB6V extends RiEMPm5KxmvYEOsVplu5.XV2I8z {
  private final long psJpCSi8_h7NzZZ1vbR;
  
  rG8A403wjTaYB6V(long paramLong) {
    this.psJpCSi8_h7NzZZ1vbR = paramLong;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof RiEMPm5KxmvYEOsVplu5.XV2I8z) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR == paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    long l1 = 1000003L;
    long l2 = this.psJpCSi8_h7NzZZ1vbR;
    return (int)(l1 ^ l2 ^ l2 >>> 32L);
  }
  
  long psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ValueLong{value=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\rG8A403wjTaYB6V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */