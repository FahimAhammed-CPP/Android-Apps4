package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h;
import javax.annotation.Nullable;

final class Q_ extends Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR {
  private final D89UfNGBvLPp16h Q_;
  
  private final long psJpCSi8_h7NzZZ1vbR;
  
  Q_(long paramLong, @Nullable D89UfNGBvLPp16h paramD89UfNGBvLPp16h) {
    this.psJpCSi8_h7NzZZ1vbR = paramLong;
    this.Q_ = paramD89UfNGBvLPp16h;
  }
  
  @Nullable
  public D89UfNGBvLPp16h Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      if (this.psJpCSi8_h7NzZZ1vbR == paramObject.psJpCSi8_h7NzZZ1vbR()) {
        D89UfNGBvLPp16h d89UfNGBvLPp16h = this.Q_;
        if (d89UfNGBvLPp16h == null) {
          if (paramObject.Q_() == null)
            return true; 
        } else if (d89UfNGBvLPp16h.equals(paramObject.Q_())) {
          return true;
        } 
      } 
      return false;
    } 
    return false;
  }
  
  public int hashCode() {
    int i;
    long l1 = 1000003L;
    long l2 = this.psJpCSi8_h7NzZZ1vbR;
    int j = (int)(l1 ^ l2 ^ l2 >>> 32L);
    D89UfNGBvLPp16h d89UfNGBvLPp16h = this.Q_;
    if (d89UfNGBvLPp16h == null) {
      i = 0;
    } else {
      i = d89UfNGBvLPp16h.hashCode();
    } 
    return i ^ j * 1000003;
  }
  
  public long psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bucket{count=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", exemplar=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */