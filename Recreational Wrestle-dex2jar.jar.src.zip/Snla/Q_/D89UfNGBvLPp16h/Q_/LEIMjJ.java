package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.D89UfNGBvLPp16h.qY;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;

final class LEIMjJ extends fc4RJByVvAciR {
  private final List<hhkWV822WvWIJ6d> Q_;
  
  private final LEwT0cz2WRRZ XV2I8z;
  
  private final List<qY> psJpCSi8_h7NzZZ1vbR;
  
  LEIMjJ(List<qY> paramList, List<hhkWV822WvWIJ6d> paramList1, @Nullable LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    Objects.requireNonNull(paramList, "Null labelValues");
    this.psJpCSi8_h7NzZZ1vbR = paramList;
    Objects.requireNonNull(paramList1, "Null points");
    this.Q_ = paramList1;
    this.XV2I8z = paramLEwT0cz2WRRZ;
  }
  
  public List<hhkWV822WvWIJ6d> Q_() {
    return this.Q_;
  }
  
  @Nullable
  public LEwT0cz2WRRZ XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof fc4RJByVvAciR) {
      paramObject = paramObject;
      if (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_())) {
        LEwT0cz2WRRZ lEwT0cz2WRRZ = this.XV2I8z;
        if (lEwT0cz2WRRZ == null) {
          if (paramObject.XV2I8z() == null)
            return true; 
        } else if (lEwT0cz2WRRZ.equals(paramObject.XV2I8z())) {
          return true;
        } 
      } 
      return false;
    } 
    return false;
  }
  
  public int hashCode() {
    int i;
    int j = this.psJpCSi8_h7NzZZ1vbR.hashCode();
    int k = this.Q_.hashCode();
    LEwT0cz2WRRZ lEwT0cz2WRRZ = this.XV2I8z;
    if (lEwT0cz2WRRZ == null) {
      i = 0;
    } else {
      i = lEwT0cz2WRRZ.hashCode();
    } 
    return ((j ^ 0xF4243) * 1000003 ^ k) * 1000003 ^ i;
  }
  
  public List<qY> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TimeSeries{labelValues=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", points=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", startTimestamp=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\LEIMjJ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */