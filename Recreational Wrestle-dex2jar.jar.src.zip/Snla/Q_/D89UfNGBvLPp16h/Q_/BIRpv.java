package Snla.Q_.D89UfNGBvLPp16h.Q_;

final class BIRpv extends aqqnPTeV.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR {
  private final double Q_;
  
  private final double psJpCSi8_h7NzZZ1vbR;
  
  BIRpv(double paramDouble1, double paramDouble2) {
    this.psJpCSi8_h7NzZZ1vbR = paramDouble1;
    this.Q_ = paramDouble2;
  }
  
  public double Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof aqqnPTeV.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      return (Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) == Double.doubleToLongBits(paramObject.psJpCSi8_h7NzZZ1vbR()) && Double.doubleToLongBits(this.Q_) == Double.doubleToLongBits(paramObject.Q_()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (int)(((int)(1000003L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) >>> 32L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR)) * 1000003) ^ Double.doubleToLongBits(this.Q_) >>> 32L ^ Double.doubleToLongBits(this.Q_));
  }
  
  public double psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ValueAtPercentile{percentile=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", value=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\BIRpv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */