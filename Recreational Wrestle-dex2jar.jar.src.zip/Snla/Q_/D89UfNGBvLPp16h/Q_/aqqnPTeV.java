package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;

public abstract class aqqnPTeV {
  private static void Q_(@Nullable Long paramLong, @Nullable Double paramDouble) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_0
    //   3: ifnull -> 23
    //   6: aload_0
    //   7: invokevirtual longValue : ()J
    //   10: lconst_0
    //   11: lcmp
    //   12: iflt -> 18
    //   15: goto -> 23
    //   18: iconst_0
    //   19: istore_2
    //   20: goto -> 25
    //   23: iconst_1
    //   24: istore_2
    //   25: iload_2
    //   26: ldc 'count must be non-negative.'
    //   28: invokestatic psJpCSi8_h7NzZZ1vbR : (ZLjava/lang/Object;)V
    //   31: aload_1
    //   32: ifnull -> 52
    //   35: aload_1
    //   36: invokevirtual doubleValue : ()D
    //   39: dconst_0
    //   40: dcmpl
    //   41: iflt -> 47
    //   44: goto -> 52
    //   47: iconst_0
    //   48: istore_2
    //   49: goto -> 54
    //   52: iconst_1
    //   53: istore_2
    //   54: iload_2
    //   55: ldc 'sum must be non-negative.'
    //   57: invokestatic psJpCSi8_h7NzZZ1vbR : (ZLjava/lang/Object;)V
    //   60: aload_0
    //   61: ifnull -> 96
    //   64: aload_0
    //   65: invokevirtual longValue : ()J
    //   68: lconst_0
    //   69: lcmp
    //   70: ifne -> 96
    //   73: aload_1
    //   74: ifnull -> 88
    //   77: iload_3
    //   78: istore_2
    //   79: aload_1
    //   80: invokevirtual doubleValue : ()D
    //   83: dconst_0
    //   84: dcmpl
    //   85: ifne -> 90
    //   88: iconst_1
    //   89: istore_2
    //   90: iload_2
    //   91: ldc 'sum must be 0 if count is 0.'
    //   93: invokestatic psJpCSi8_h7NzZZ1vbR : (ZLjava/lang/Object;)V
    //   96: return
  }
  
  public static aqqnPTeV psJpCSi8_h7NzZZ1vbR(@Nullable Long paramLong, @Nullable Double paramDouble, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    Q_(paramLong, paramDouble);
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR, "snapshot");
    return new wqn(paramLong, paramDouble, parampsJpCSi8_h7NzZZ1vbR);
  }
  
  @Nullable
  public abstract Double Q_();
  
  public abstract psJpCSi8_h7NzZZ1vbR XV2I8z();
  
  @Nullable
  public abstract Long psJpCSi8_h7NzZZ1vbR();
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(@Nullable Long param1Long, @Nullable Double param1Double, List<psJpCSi8_h7NzZZ1vbR> param1List) {
      aqqnPTeV.psJpCSi8_h7NzZZ1vbR(param1Long, param1Double);
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR((List)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List, "valueAtPercentiles"), "valueAtPercentile");
      return new wktp1mvgWsB4SzZr(param1Long, param1Double, Collections.unmodifiableList(new ArrayList<psJpCSi8_h7NzZZ1vbR>(param1List)));
    }
    
    @Nullable
    public abstract Double Q_();
    
    public abstract List<psJpCSi8_h7NzZZ1vbR> XV2I8z();
    
    @Nullable
    public abstract Long psJpCSi8_h7NzZZ1vbR();
    
    public static abstract class psJpCSi8_h7NzZZ1vbR {
      public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(double param2Double1, double param2Double2) {
        boolean bool1;
        boolean bool2 = true;
        if (0.0D < param2Double1 && param2Double1 <= 100.0D) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "percentile must be in the interval (0.0, 100.0]");
        if (param2Double2 >= 0.0D) {
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "value must be non-negative");
        return new BIRpv(param2Double1, param2Double2);
      }
      
      public abstract double Q_();
      
      public abstract double psJpCSi8_h7NzZZ1vbR();
    }
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(double param1Double1, double param1Double2) {
      boolean bool1;
      boolean bool2 = true;
      if (0.0D < param1Double1 && param1Double1 <= 100.0D) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "percentile must be in the interval (0.0, 100.0]");
      if (param1Double2 >= 0.0D) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "value must be non-negative");
      return new BIRpv(param1Double1, param1Double2);
    }
    
    public abstract double Q_();
    
    public abstract double psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\aqqnPTeV.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */