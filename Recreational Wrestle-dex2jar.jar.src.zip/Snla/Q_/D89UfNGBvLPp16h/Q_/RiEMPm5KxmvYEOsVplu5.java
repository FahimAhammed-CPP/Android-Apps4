package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn;

public abstract class RiEMPm5KxmvYEOsVplu5 {
  public static RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(double paramDouble) {
    return Q_.Q_(paramDouble);
  }
  
  public static RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(long paramLong) {
    return XV2I8z.Q_(paramLong);
  }
  
  public static RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(Ap4G4fS9phs paramAp4G4fS9phs) {
    return psJpCSi8_h7NzZZ1vbR.Q_(paramAp4G4fS9phs);
  }
  
  public static RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR(aqqnPTeV paramaqqnPTeV) {
    return D89UfNGBvLPp16h.Q_(paramaqqnPTeV);
  }
  
  public abstract <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super Double, T> paramwqn, wqn<? super Long, T> paramwqn1, wqn<? super Ap4G4fS9phs, T> paramwqn2, wqn<? super aqqnPTeV, T> paramwqn3, wqn<? super RiEMPm5KxmvYEOsVplu5, T> paramwqn4);
  
  static abstract class D89UfNGBvLPp16h extends RiEMPm5KxmvYEOsVplu5 {
    static D89UfNGBvLPp16h Q_(aqqnPTeV param1aqqnPTeV) {
      return new D_K6ibTZHL_tOOY3(param1aqqnPTeV);
    }
    
    abstract aqqnPTeV psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super Double, T> param1wqn, wqn<? super Long, T> param1wqn1, wqn<? super Ap4G4fS9phs, T> param1wqn2, wqn<? super aqqnPTeV, T> param1wqn3, wqn<? super RiEMPm5KxmvYEOsVplu5, T> param1wqn4) {
      return (T)param1wqn3.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
  }
  
  static abstract class Q_ extends RiEMPm5KxmvYEOsVplu5 {
    static Q_ Q_(double param1Double) {
      return new hzEmy(param1Double);
    }
    
    abstract double psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super Double, T> param1wqn, wqn<? super Long, T> param1wqn1, wqn<? super Ap4G4fS9phs, T> param1wqn2, wqn<? super aqqnPTeV, T> param1wqn3, wqn<? super RiEMPm5KxmvYEOsVplu5, T> param1wqn4) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(Double.valueOf(psJpCSi8_h7NzZZ1vbR()));
    }
  }
  
  static abstract class XV2I8z extends RiEMPm5KxmvYEOsVplu5 {
    static XV2I8z Q_(long param1Long) {
      return new rG8A403wjTaYB6V(param1Long);
    }
    
    abstract long psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super Double, T> param1wqn, wqn<? super Long, T> param1wqn1, wqn<? super Ap4G4fS9phs, T> param1wqn2, wqn<? super aqqnPTeV, T> param1wqn3, wqn<? super RiEMPm5KxmvYEOsVplu5, T> param1wqn4) {
      return (T)param1wqn1.psJpCSi8_h7NzZZ1vbR(Long.valueOf(psJpCSi8_h7NzZZ1vbR()));
    }
  }
  
  static abstract class psJpCSi8_h7NzZZ1vbR extends RiEMPm5KxmvYEOsVplu5 {
    static psJpCSi8_h7NzZZ1vbR Q_(Ap4G4fS9phs param1Ap4G4fS9phs) {
      return new qY(param1Ap4G4fS9phs);
    }
    
    abstract Ap4G4fS9phs psJpCSi8_h7NzZZ1vbR();
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super Double, T> param1wqn, wqn<? super Long, T> param1wqn1, wqn<? super Ap4G4fS9phs, T> param1wqn2, wqn<? super aqqnPTeV, T> param1wqn3, wqn<? super RiEMPm5KxmvYEOsVplu5, T> param1wqn4) {
      return (T)param1wqn2.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\RiEMPm5KxmvYEOsVplu5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */