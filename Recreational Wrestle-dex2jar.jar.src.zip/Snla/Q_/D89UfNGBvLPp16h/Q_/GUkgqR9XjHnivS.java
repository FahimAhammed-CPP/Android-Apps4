package Snla.Q_.D89UfNGBvLPp16h.Q_;

public abstract class GUkgqR9XjHnivS {
  public static GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR() {
    return new psJpCSi8_h7NzZZ1vbR();
  }
  
  public abstract jlrPm Q_();
  
  private static final class psJpCSi8_h7NzZZ1vbR extends GUkgqR9XjHnivS {
    private static final jlrPm psJpCSi8_h7NzZZ1vbR = jlrPm.Q_();
    
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public jlrPm Q_() {
      return psJpCSi8_h7NzZZ1vbR;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\GUkgqR9XjHnivS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */