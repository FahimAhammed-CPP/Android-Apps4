package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public abstract class oq9TzoD0 {
  private static oq9TzoD0 Q_(LEwT0cz2WRRZ paramLEwT0cz2WRRZ, List<fc4RJByVvAciR> paramList) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramLEwT0cz2WRRZ, "metricDescriptor");
    psJpCSi8_h7NzZZ1vbR(paramLEwT0cz2WRRZ.D89UfNGBvLPp16h(), paramList);
    return new D89UfNGBvLPp16h(paramLEwT0cz2WRRZ, paramList);
  }
  
  public static oq9TzoD0 psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ paramLEwT0cz2WRRZ, fc4RJByVvAciR paramfc4RJByVvAciR) {
    return Q_(paramLEwT0cz2WRRZ, Collections.singletonList(X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramfc4RJByVvAciR, "timeSeries")));
  }
  
  public static oq9TzoD0 psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ paramLEwT0cz2WRRZ, List<fc4RJByVvAciR> paramList) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR((List)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramList, "timeSeriesList"), "timeSeries");
    return Q_(paramLEwT0cz2WRRZ, Collections.unmodifiableList(new ArrayList<fc4RJByVvAciR>(paramList)));
  }
  
  private static void psJpCSi8_h7NzZZ1vbR(LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, List<fc4RJByVvAciR> paramList) {
    Iterator<fc4RJByVvAciR> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      Iterator<hhkWV822WvWIJ6d> iterator1 = ((fc4RJByVvAciR)iterator.next()).Q_().iterator();
      while (iterator1.hasNext()) {
        String str;
        RiEMPm5KxmvYEOsVplu5 riEMPm5KxmvYEOsVplu5 = ((hhkWV822WvWIJ6d)iterator1.next()).psJpCSi8_h7NzZZ1vbR();
        if (riEMPm5KxmvYEOsVplu5.getClass().getSuperclass() != null) {
          str = riEMPm5KxmvYEOsVplu5.getClass().getSuperclass().getSimpleName();
        } else {
          str = "";
        } 
        switch (null.psJpCSi8_h7NzZZ1vbR[parampsJpCSi8_h7NzZZ1vbR.ordinal()]) {
          default:
            continue;
          case 7:
            X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(riEMPm5KxmvYEOsVplu5 instanceof RiEMPm5KxmvYEOsVplu5.D89UfNGBvLPp16h, "Type mismatch: %s, %s.", new Object[] { parampsJpCSi8_h7NzZZ1vbR, str });
            continue;
          case 5:
          case 6:
            X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(riEMPm5KxmvYEOsVplu5 instanceof RiEMPm5KxmvYEOsVplu5.psJpCSi8_h7NzZZ1vbR, "Type mismatch: %s, %s.", new Object[] { parampsJpCSi8_h7NzZZ1vbR, str });
            continue;
          case 3:
          case 4:
            X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(riEMPm5KxmvYEOsVplu5 instanceof RiEMPm5KxmvYEOsVplu5.Q_, "Type mismatch: %s, %s.", new Object[] { parampsJpCSi8_h7NzZZ1vbR, str });
            continue;
          case 1:
          case 2:
            break;
        } 
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(riEMPm5KxmvYEOsVplu5 instanceof RiEMPm5KxmvYEOsVplu5.XV2I8z, "Type mismatch: %s, %s.", new Object[] { parampsJpCSi8_h7NzZZ1vbR, str });
      } 
    } 
  }
  
  public abstract List<fc4RJByVvAciR> Q_();
  
  public abstract LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\oq9TzoD0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */