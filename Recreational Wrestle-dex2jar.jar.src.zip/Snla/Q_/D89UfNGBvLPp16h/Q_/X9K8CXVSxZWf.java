package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.D89UfNGBvLPp16h.LEIMjJ;
import java.util.List;
import java.util.Objects;

final class X9K8CXVSxZWf extends LEwT0cz2WRRZ {
  private final LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR D89UfNGBvLPp16h;
  
  private final String Q_;
  
  private final List<LEIMjJ> X9K8CXVSxZWf;
  
  private final String XV2I8z;
  
  private final String psJpCSi8_h7NzZZ1vbR;
  
  X9K8CXVSxZWf(String paramString1, String paramString2, String paramString3, LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, List<LEIMjJ> paramList) {
    Objects.requireNonNull(paramString1, "Null name");
    this.psJpCSi8_h7NzZZ1vbR = paramString1;
    Objects.requireNonNull(paramString2, "Null description");
    this.Q_ = paramString2;
    Objects.requireNonNull(paramString3, "Null unit");
    this.XV2I8z = paramString3;
    Objects.requireNonNull(parampsJpCSi8_h7NzZZ1vbR, "Null type");
    this.D89UfNGBvLPp16h = parampsJpCSi8_h7NzZZ1vbR;
    Objects.requireNonNull(paramList, "Null labelKeys");
    this.X9K8CXVSxZWf = paramList;
  }
  
  public LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR D89UfNGBvLPp16h() {
    return this.D89UfNGBvLPp16h;
  }
  
  public String Q_() {
    return this.Q_;
  }
  
  public List<LEIMjJ> X9K8CXVSxZWf() {
    return this.X9K8CXVSxZWf;
  }
  
  public String XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof LEwT0cz2WRRZ) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()) && this.XV2I8z.equals(paramObject.XV2I8z()) && this.D89UfNGBvLPp16h.equals(paramObject.D89UfNGBvLPp16h()) && this.X9K8CXVSxZWf.equals(paramObject.X9K8CXVSxZWf()));
    } 
    return false;
  }
  
  public int hashCode() {
    return ((((this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode()) * 1000003 ^ this.XV2I8z.hashCode()) * 1000003 ^ this.D89UfNGBvLPp16h.hashCode()) * 1000003 ^ this.X9K8CXVSxZWf.hashCode();
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MetricDescriptor{name=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", description=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", unit=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", type=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append(", labelKeys=");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */