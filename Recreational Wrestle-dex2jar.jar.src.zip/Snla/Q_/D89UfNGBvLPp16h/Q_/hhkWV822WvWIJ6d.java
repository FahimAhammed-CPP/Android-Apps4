package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;

public abstract class hhkWV822WvWIJ6d {
  public static hhkWV822WvWIJ6d psJpCSi8_h7NzZZ1vbR(RiEMPm5KxmvYEOsVplu5 paramRiEMPm5KxmvYEOsVplu5, LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    return new MxwALnHp3MNCI(paramRiEMPm5KxmvYEOsVplu5, paramLEwT0cz2WRRZ);
  }
  
  public abstract LEwT0cz2WRRZ Q_();
  
  public abstract RiEMPm5KxmvYEOsVplu5 psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\hhkWV822WvWIJ6d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */