package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h;
import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.wqn;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;

public abstract class Ap4G4fS9phs {
  public static Ap4G4fS9phs psJpCSi8_h7NzZZ1vbR(long paramLong, double paramDouble1, double paramDouble2, Q_ paramQ_, List<psJpCSi8_h7NzZZ1vbR> paramList) {
    boolean bool1;
    int i = paramLong cmp 0L;
    boolean bool2 = true;
    if (i >= 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "count should be non-negative.");
    int j = paramDouble2 cmp 0.0D;
    if (j >= 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "sum of squared deviations should be non-negative.");
    if (i == 0) {
      if (paramDouble1 == 0.0D) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "sum should be 0 if count is 0.");
      if (j == 0) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool1, "sum of squared deviations should be 0 if count is 0.");
    } 
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramQ_, "bucketOptions");
    paramList = Collections.unmodifiableList(new ArrayList<psJpCSi8_h7NzZZ1vbR>((Collection<? extends psJpCSi8_h7NzZZ1vbR>)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramList, "buckets")));
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramList, "bucket");
    return new psJpCSi8_h7NzZZ1vbR(paramLong, paramDouble1, paramDouble2, paramQ_, paramList);
  }
  
  @Nullable
  public abstract Q_ D89UfNGBvLPp16h();
  
  public abstract double Q_();
  
  public abstract List<psJpCSi8_h7NzZZ1vbR> X9K8CXVSxZWf();
  
  public abstract double XV2I8z();
  
  public abstract long psJpCSi8_h7NzZZ1vbR();
  
  public static abstract class Q_ {
    private Q_() {}
    
    public static Q_ psJpCSi8_h7NzZZ1vbR(List<Double> param1List) {
      return psJpCSi8_h7NzZZ1vbR.Q_(param1List);
    }
    
    public abstract <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super Q_, T> param1wqn1);
    
    public static abstract class psJpCSi8_h7NzZZ1vbR extends Q_ {
      private static void D89UfNGBvLPp16h(List<Double> param2List) {
        if (param2List.size() >= 1) {
          boolean bool;
          double d = ((Double)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param2List.get(0), "bucketBoundary")).doubleValue();
          if (d > 0.0D) {
            bool = true;
          } else {
            bool = false;
          } 
          X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "bucket boundary should be > 0");
          int i = 1;
          while (i < param2List.size()) {
            double d1 = ((Double)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param2List.get(i), "bucketBoundary")).doubleValue();
            if (d < d1) {
              bool = true;
            } else {
              bool = false;
            } 
            X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "bucket boundaries not sorted.");
            i++;
            d = d1;
          } 
        } 
      }
      
      private static psJpCSi8_h7NzZZ1vbR XV2I8z(List<Double> param2List) {
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param2List, "bucketBoundaries");
        param2List = Collections.unmodifiableList(new ArrayList<Double>(param2List));
        D89UfNGBvLPp16h(param2List);
        return new XV2I8z(param2List);
      }
      
      public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param2wqn, wqn<? super Ap4G4fS9phs.Q_, T> param2wqn1) {
        return (T)param2wqn.psJpCSi8_h7NzZZ1vbR(this);
      }
      
      public abstract List<Double> psJpCSi8_h7NzZZ1vbR();
    }
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR extends Q_ {
    private static void D89UfNGBvLPp16h(List<Double> param1List) {
      if (param1List.size() >= 1) {
        boolean bool;
        double d = ((Double)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List.get(0), "bucketBoundary")).doubleValue();
        if (d > 0.0D) {
          bool = true;
        } else {
          bool = false;
        } 
        X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "bucket boundary should be > 0");
        int i = 1;
        while (i < param1List.size()) {
          double d1 = ((Double)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List.get(i), "bucketBoundary")).doubleValue();
          if (d < d1) {
            bool = true;
          } else {
            bool = false;
          } 
          X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "bucket boundaries not sorted.");
          i++;
          d = d1;
        } 
      } 
    }
    
    private static psJpCSi8_h7NzZZ1vbR XV2I8z(List<Double> param1List) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List, "bucketBoundaries");
      param1List = Collections.unmodifiableList(new ArrayList<Double>(param1List));
      D89UfNGBvLPp16h(param1List);
      return new XV2I8z(param1List);
    }
    
    public final <T> T psJpCSi8_h7NzZZ1vbR(wqn<? super psJpCSi8_h7NzZZ1vbR, T> param1wqn, wqn<? super Ap4G4fS9phs.Q_, T> param1wqn1) {
      return (T)param1wqn.psJpCSi8_h7NzZZ1vbR(this);
    }
    
    public abstract List<Double> psJpCSi8_h7NzZZ1vbR();
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(long param1Long) {
      boolean bool;
      if (param1Long >= 0L) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "bucket count should be non-negative.");
      return new Q_(param1Long, null);
    }
    
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(long param1Long, D89UfNGBvLPp16h param1D89UfNGBvLPp16h) {
      boolean bool;
      if (param1Long >= 0L) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "bucket count should be non-negative.");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1D89UfNGBvLPp16h, "exemplar");
      return new Q_(param1Long, param1D89UfNGBvLPp16h);
    }
    
    @Nullable
    public abstract D89UfNGBvLPp16h Q_();
    
    public abstract long psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\Ap4G4fS9phs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */