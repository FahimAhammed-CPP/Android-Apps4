package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.Collections;
import java.util.Set;

public abstract class jlrPm {
  static jlrPm Q_() {
    return new psJpCSi8_h7NzZZ1vbR();
  }
  
  public abstract void Q_(UptK2mZMIFJk1ivmXYH paramUptK2mZMIFJk1ivmXYH);
  
  public abstract Set<UptK2mZMIFJk1ivmXYH> psJpCSi8_h7NzZZ1vbR();
  
  public abstract void psJpCSi8_h7NzZZ1vbR(UptK2mZMIFJk1ivmXYH paramUptK2mZMIFJk1ivmXYH);
  
  private static final class psJpCSi8_h7NzZZ1vbR extends jlrPm {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public void Q_(UptK2mZMIFJk1ivmXYH param1UptK2mZMIFJk1ivmXYH) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1UptK2mZMIFJk1ivmXYH, "metricProducer");
    }
    
    public Set<UptK2mZMIFJk1ivmXYH> psJpCSi8_h7NzZZ1vbR() {
      return Collections.emptySet();
    }
    
    public void psJpCSi8_h7NzZZ1vbR(UptK2mZMIFJk1ivmXYH param1UptK2mZMIFJk1ivmXYH) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1UptK2mZMIFJk1ivmXYH, "metricProducer");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\jlrPm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */