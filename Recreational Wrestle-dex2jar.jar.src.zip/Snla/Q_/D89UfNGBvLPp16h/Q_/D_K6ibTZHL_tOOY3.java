package Snla.Q_.D89UfNGBvLPp16h.Q_;

import java.util.Objects;

final class D_K6ibTZHL_tOOY3 extends RiEMPm5KxmvYEOsVplu5.D89UfNGBvLPp16h {
  private final aqqnPTeV psJpCSi8_h7NzZZ1vbR;
  
  D_K6ibTZHL_tOOY3(aqqnPTeV paramaqqnPTeV) {
    Objects.requireNonNull(paramaqqnPTeV, "Null value");
    this.psJpCSi8_h7NzZZ1vbR = paramaqqnPTeV;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof RiEMPm5KxmvYEOsVplu5.D89UfNGBvLPp16h) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  aqqnPTeV psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ValueSummary{value=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\D_K6ibTZHL_tOOY3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */