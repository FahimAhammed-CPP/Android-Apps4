package Snla.Q_.D89UfNGBvLPp16h.Q_;

import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;

final class wktp1mvgWsB4SzZr extends aqqnPTeV.psJpCSi8_h7NzZZ1vbR {
  private final Double Q_;
  
  private final List<aqqnPTeV.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR> XV2I8z;
  
  private final Long psJpCSi8_h7NzZZ1vbR;
  
  wktp1mvgWsB4SzZr(@Nullable Long paramLong, @Nullable Double paramDouble, List<aqqnPTeV.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR> paramList) {
    this.psJpCSi8_h7NzZZ1vbR = paramLong;
    this.Q_ = paramDouble;
    Objects.requireNonNull(paramList, "Null valueAtPercentiles");
    this.XV2I8z = paramList;
  }
  
  @Nullable
  public Double Q_() {
    return this.Q_;
  }
  
  public List<aqqnPTeV.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR> XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof aqqnPTeV.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      Long long_ = this.psJpCSi8_h7NzZZ1vbR;
      if ((long_ == null) ? (paramObject.psJpCSi8_h7NzZZ1vbR() == null) : long_.equals(paramObject.psJpCSi8_h7NzZZ1vbR())) {
        Double double_ = this.Q_;
        if (((double_ == null) ? (paramObject.Q_() == null) : double_.equals(paramObject.Q_())) && this.XV2I8z.equals(paramObject.XV2I8z()))
          return true; 
      } 
      return false;
    } 
    return false;
  }
  
  public int hashCode() {
    int i;
    Long long_ = this.psJpCSi8_h7NzZZ1vbR;
    int j = 0;
    if (long_ == null) {
      i = 0;
    } else {
      i = long_.hashCode();
    } 
    Double double_ = this.Q_;
    if (double_ != null)
      j = double_.hashCode(); 
    return ((i ^ 0xF4243) * 1000003 ^ j) * 1000003 ^ this.XV2I8z.hashCode();
  }
  
  @Nullable
  public Long psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Snapshot{count=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", sum=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", valueAtPercentiles=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\wktp1mvgWsB4SzZr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */