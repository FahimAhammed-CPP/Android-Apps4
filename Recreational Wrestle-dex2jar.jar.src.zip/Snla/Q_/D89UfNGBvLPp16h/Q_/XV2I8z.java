package Snla.Q_.D89UfNGBvLPp16h.Q_;

import java.util.List;
import java.util.Objects;

final class XV2I8z extends Ap4G4fS9phs.Q_.psJpCSi8_h7NzZZ1vbR {
  private final List<Double> psJpCSi8_h7NzZZ1vbR;
  
  XV2I8z(List<Double> paramList) {
    Objects.requireNonNull(paramList, "Null bucketBoundaries");
    this.psJpCSi8_h7NzZZ1vbR = paramList;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Ap4G4fS9phs.Q_.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public List<Double> psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ExplicitOptions{bucketBoundaries=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */