package Snla.Q_.D89UfNGBvLPp16h.Q_;

import java.util.List;
import java.util.Objects;

final class D89UfNGBvLPp16h extends oq9TzoD0 {
  private final List<fc4RJByVvAciR> Q_;
  
  private final LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR;
  
  D89UfNGBvLPp16h(LEwT0cz2WRRZ paramLEwT0cz2WRRZ, List<fc4RJByVvAciR> paramList) {
    Objects.requireNonNull(paramLEwT0cz2WRRZ, "Null metricDescriptor");
    this.psJpCSi8_h7NzZZ1vbR = paramLEwT0cz2WRRZ;
    Objects.requireNonNull(paramList, "Null timeSeriesList");
    this.Q_ = paramList;
  }
  
  public List<fc4RJByVvAciR> Q_() {
    return this.Q_;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof oq9TzoD0) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode();
  }
  
  public LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Metric{metricDescriptor=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", timeSeriesList=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */