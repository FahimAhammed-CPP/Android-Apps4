package Snla.Q_.D89UfNGBvLPp16h.Q_;

import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;

final class psJpCSi8_h7NzZZ1vbR extends Ap4G4fS9phs {
  private final Ap4G4fS9phs.Q_ D89UfNGBvLPp16h;
  
  private final double Q_;
  
  private final List<Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR> X9K8CXVSxZWf;
  
  private final double XV2I8z;
  
  private final long psJpCSi8_h7NzZZ1vbR;
  
  psJpCSi8_h7NzZZ1vbR(long paramLong, double paramDouble1, double paramDouble2, @Nullable Ap4G4fS9phs.Q_ paramQ_, List<Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR> paramList) {
    this.psJpCSi8_h7NzZZ1vbR = paramLong;
    this.Q_ = paramDouble1;
    this.XV2I8z = paramDouble2;
    this.D89UfNGBvLPp16h = paramQ_;
    Objects.requireNonNull(paramList, "Null buckets");
    this.X9K8CXVSxZWf = paramList;
  }
  
  @Nullable
  public Ap4G4fS9phs.Q_ D89UfNGBvLPp16h() {
    return this.D89UfNGBvLPp16h;
  }
  
  public double Q_() {
    return this.Q_;
  }
  
  public List<Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR> X9K8CXVSxZWf() {
    return this.X9K8CXVSxZWf;
  }
  
  public double XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Ap4G4fS9phs) {
      paramObject = paramObject;
      if (this.psJpCSi8_h7NzZZ1vbR == paramObject.psJpCSi8_h7NzZZ1vbR() && Double.doubleToLongBits(this.Q_) == Double.doubleToLongBits(paramObject.Q_()) && Double.doubleToLongBits(this.XV2I8z) == Double.doubleToLongBits(paramObject.XV2I8z())) {
        Ap4G4fS9phs.Q_ q_ = this.D89UfNGBvLPp16h;
        if (((q_ == null) ? (paramObject.D89UfNGBvLPp16h() == null) : q_.equals(paramObject.D89UfNGBvLPp16h())) && this.X9K8CXVSxZWf.equals(paramObject.X9K8CXVSxZWf()))
          return true; 
      } 
      return false;
    } 
    return false;
  }
  
  public int hashCode() {
    int i;
    long l1 = 1000003L;
    long l2 = this.psJpCSi8_h7NzZZ1vbR;
    int j = (int)(((int)(((int)(l1 ^ l2 ^ l2 >>> 32L) * 1000003) ^ Double.doubleToLongBits(this.Q_) >>> 32L ^ Double.doubleToLongBits(this.Q_)) * 1000003) ^ Double.doubleToLongBits(this.XV2I8z) >>> 32L ^ Double.doubleToLongBits(this.XV2I8z));
    Ap4G4fS9phs.Q_ q_ = this.D89UfNGBvLPp16h;
    if (q_ == null) {
      i = 0;
    } else {
      i = q_.hashCode();
    } 
    return this.X9K8CXVSxZWf.hashCode() ^ (j * 1000003 ^ i) * 1000003;
  }
  
  public long psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Distribution{count=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", sum=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", sumOfSquaredDeviations=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", bucketOptions=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append(", buckets=");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */