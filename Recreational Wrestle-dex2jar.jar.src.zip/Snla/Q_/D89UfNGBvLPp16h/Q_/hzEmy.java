package Snla.Q_.D89UfNGBvLPp16h.Q_;

final class hzEmy extends RiEMPm5KxmvYEOsVplu5.Q_ {
  private final double psJpCSi8_h7NzZZ1vbR;
  
  hzEmy(double paramDouble) {
    this.psJpCSi8_h7NzZZ1vbR = paramDouble;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof RiEMPm5KxmvYEOsVplu5.Q_) {
      paramObject = paramObject;
      return (Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) == Double.doubleToLongBits(paramObject.psJpCSi8_h7NzZZ1vbR()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (int)(1000003L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) >>> 32L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR));
  }
  
  double psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ValueDouble{value=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\hzEmy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */