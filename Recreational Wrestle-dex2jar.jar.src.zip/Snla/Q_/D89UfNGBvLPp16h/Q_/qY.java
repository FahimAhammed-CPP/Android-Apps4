package Snla.Q_.D89UfNGBvLPp16h.Q_;

import java.util.Objects;

final class qY extends RiEMPm5KxmvYEOsVplu5.psJpCSi8_h7NzZZ1vbR {
  private final Ap4G4fS9phs psJpCSi8_h7NzZZ1vbR;
  
  qY(Ap4G4fS9phs paramAp4G4fS9phs) {
    Objects.requireNonNull(paramAp4G4fS9phs, "Null value");
    this.psJpCSi8_h7NzZZ1vbR = paramAp4G4fS9phs;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof RiEMPm5KxmvYEOsVplu5.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  Ap4G4fS9phs psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ValueDistribution{value=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\qY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */