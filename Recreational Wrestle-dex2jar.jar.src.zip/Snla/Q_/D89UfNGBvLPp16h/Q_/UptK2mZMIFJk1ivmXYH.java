package Snla.Q_.D89UfNGBvLPp16h.Q_;

import java.util.Collection;

public abstract class UptK2mZMIFJk1ivmXYH {
  public abstract Collection<oq9TzoD0> psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\UptK2mZMIFJk1ivmXYH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */