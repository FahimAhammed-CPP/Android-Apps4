package Snla.Q_.D89UfNGBvLPp16h.Q_;

import Snla.Q_.D89UfNGBvLPp16h.qY;
import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;

public abstract class fc4RJByVvAciR {
  private static fc4RJByVvAciR Q_(List<qY> paramList, List<hhkWV822WvWIJ6d> paramList1, @Nullable LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR((List)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramList, "labelValues"), "labelValue");
    return new LEIMjJ(Collections.unmodifiableList(new ArrayList<qY>(paramList)), paramList1, paramLEwT0cz2WRRZ);
  }
  
  public static fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR(List<qY> paramList) {
    return Q_(paramList, Collections.emptyList(), null);
  }
  
  public static fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR(List<qY> paramList, hhkWV822WvWIJ6d paramhhkWV822WvWIJ6d, @Nullable LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramhhkWV822WvWIJ6d, "point");
    return Q_(paramList, Collections.singletonList(paramhhkWV822WvWIJ6d), paramLEwT0cz2WRRZ);
  }
  
  public static fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR(List<qY> paramList, List<hhkWV822WvWIJ6d> paramList1, @Nullable LEwT0cz2WRRZ paramLEwT0cz2WRRZ) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR((List)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramList1, "points"), "point");
    return Q_(paramList, Collections.unmodifiableList(new ArrayList<hhkWV822WvWIJ6d>(paramList1)), paramLEwT0cz2WRRZ);
  }
  
  public abstract List<hhkWV822WvWIJ6d> Q_();
  
  @Nullable
  public abstract LEwT0cz2WRRZ XV2I8z();
  
  public fc4RJByVvAciR psJpCSi8_h7NzZZ1vbR(hhkWV822WvWIJ6d paramhhkWV822WvWIJ6d) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramhhkWV822WvWIJ6d, "point");
    return new LEIMjJ(psJpCSi8_h7NzZZ1vbR(), Collections.singletonList(paramhhkWV822WvWIJ6d), null);
  }
  
  public abstract List<qY> psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_\fc4RJByVvAciR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */