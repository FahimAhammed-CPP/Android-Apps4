package Snla.Q_.D89UfNGBvLPp16h;

public abstract class LEIMjJ {
  public static LEIMjJ psJpCSi8_h7NzZZ1vbR(String paramString1, String paramString2) {
    return new psJpCSi8_h7NzZZ1vbR(paramString1, paramString2);
  }
  
  public abstract String Q_();
  
  public abstract String psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\LEIMjJ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */