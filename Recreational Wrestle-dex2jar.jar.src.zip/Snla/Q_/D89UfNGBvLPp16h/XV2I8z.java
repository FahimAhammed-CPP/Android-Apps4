package Snla.Q_.D89UfNGBvLPp16h;

import java.util.List;
import java.util.Map;
import java.util.Objects;

final class XV2I8z extends D_K6ibTZHL_tOOY3 {
  private final Map<LEIMjJ, qY> D89UfNGBvLPp16h;
  
  private final String Q_;
  
  private final List<LEIMjJ> XV2I8z;
  
  private final String psJpCSi8_h7NzZZ1vbR;
  
  private XV2I8z(String paramString1, String paramString2, List<LEIMjJ> paramList, Map<LEIMjJ, qY> paramMap) {
    this.psJpCSi8_h7NzZZ1vbR = paramString1;
    this.Q_ = paramString2;
    this.XV2I8z = paramList;
    this.D89UfNGBvLPp16h = paramMap;
  }
  
  public Map<LEIMjJ, qY> D89UfNGBvLPp16h() {
    return this.D89UfNGBvLPp16h;
  }
  
  public String Q_() {
    return this.Q_;
  }
  
  public List<LEIMjJ> XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof D_K6ibTZHL_tOOY3) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()) && this.XV2I8z.equals(paramObject.XV2I8z()) && this.D89UfNGBvLPp16h.equals(paramObject.D89UfNGBvLPp16h()));
    } 
    return false;
  }
  
  public int hashCode() {
    return (((this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode()) * 1000003 ^ this.XV2I8z.hashCode()) * 1000003 ^ this.D89UfNGBvLPp16h.hashCode();
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MetricOptions{description=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", unit=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", labelKeys=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append(", constantLabels=");
    stringBuilder.append(this.D89UfNGBvLPp16h);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class psJpCSi8_h7NzZZ1vbR extends D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR {
    private Map<LEIMjJ, qY> D89UfNGBvLPp16h;
    
    private String Q_;
    
    private List<LEIMjJ> XV2I8z;
    
    private String psJpCSi8_h7NzZZ1vbR;
    
    public D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR Q_(String param1String) {
      Objects.requireNonNull(param1String, "Null unit");
      this.Q_ = param1String;
      return this;
    }
    
    Map<LEIMjJ, qY> Q_() {
      Map<LEIMjJ, qY> map = this.D89UfNGBvLPp16h;
      if (map != null)
        return map; 
      throw new IllegalStateException("Property \"constantLabels\" has not been set");
    }
    
    D_K6ibTZHL_tOOY3 XV2I8z() {
      String str2 = this.psJpCSi8_h7NzZZ1vbR;
      String str1 = "";
      if (str2 == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("");
        stringBuilder1.append(" description");
        str1 = stringBuilder1.toString();
      } 
      str2 = str1;
      if (this.Q_ == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append(" unit");
        str2 = stringBuilder1.toString();
      } 
      str1 = str2;
      if (this.XV2I8z == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str2);
        stringBuilder1.append(" labelKeys");
        str1 = stringBuilder1.toString();
      } 
      str2 = str1;
      if (this.D89UfNGBvLPp16h == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append(" constantLabels");
        str2 = stringBuilder1.toString();
      } 
      if (str2.isEmpty())
        return new XV2I8z(this.psJpCSi8_h7NzZZ1vbR, this.Q_, this.XV2I8z, this.D89UfNGBvLPp16h); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Missing required properties:");
      stringBuilder.append(str2);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String) {
      Objects.requireNonNull(param1String, "Null description");
      this.psJpCSi8_h7NzZZ1vbR = param1String;
      return this;
    }
    
    public D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(List<LEIMjJ> param1List) {
      Objects.requireNonNull(param1List, "Null labelKeys");
      this.XV2I8z = param1List;
      return this;
    }
    
    public D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(Map<LEIMjJ, qY> param1Map) {
      Objects.requireNonNull(param1Map, "Null constantLabels");
      this.D89UfNGBvLPp16h = param1Map;
      return this;
    }
    
    List<LEIMjJ> psJpCSi8_h7NzZZ1vbR() {
      List<LEIMjJ> list = this.XV2I8z;
      if (list != null)
        return list; 
      throw new IllegalStateException("Property \"labelKeys\" has not been set");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */