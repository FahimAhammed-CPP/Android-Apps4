package Snla.Q_.D89UfNGBvLPp16h;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.List;

public abstract class Ap4G4fS9phs {
  static Ap4G4fS9phs psJpCSi8_h7NzZZ1vbR() {
    return new psJpCSi8_h7NzZZ1vbR();
  }
  
  public abstract X9K8CXVSxZWf D89UfNGBvLPp16h(String paramString, D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3);
  
  @Deprecated
  public X9K8CXVSxZWf D89UfNGBvLPp16h(String paramString1, String paramString2, String paramString3, List<LEIMjJ> paramList) {
    return D89UfNGBvLPp16h(paramString1, D_K6ibTZHL_tOOY3.X9K8CXVSxZWf().psJpCSi8_h7NzZZ1vbR(paramString2).Q_(paramString3).psJpCSi8_h7NzZZ1vbR(paramList).D89UfNGBvLPp16h());
  }
  
  public abstract wktp1mvgWsB4SzZr MxwALnHp3MNCI(String paramString, D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3);
  
  public abstract BIRpv Q_(String paramString, D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3);
  
  @Deprecated
  public BIRpv Q_(String paramString1, String paramString2, String paramString3, List<LEIMjJ> paramList) {
    return Q_(paramString1, D_K6ibTZHL_tOOY3.X9K8CXVSxZWf().psJpCSi8_h7NzZZ1vbR(paramString2).Q_(paramString3).psJpCSi8_h7NzZZ1vbR(paramList).D89UfNGBvLPp16h());
  }
  
  public abstract hzEmy X9K8CXVSxZWf(String paramString, D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3);
  
  public abstract wqn XV2I8z(String paramString, D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3);
  
  @Deprecated
  public wqn XV2I8z(String paramString1, String paramString2, String paramString3, List<LEIMjJ> paramList) {
    return XV2I8z(paramString1, D_K6ibTZHL_tOOY3.X9K8CXVSxZWf().psJpCSi8_h7NzZZ1vbR(paramString2).Q_(paramString3).psJpCSi8_h7NzZZ1vbR(paramList).D89UfNGBvLPp16h());
  }
  
  public abstract rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR(String paramString, D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3);
  
  @Deprecated
  public rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR(String paramString1, String paramString2, String paramString3, List<LEIMjJ> paramList) {
    return psJpCSi8_h7NzZZ1vbR(paramString1, D_K6ibTZHL_tOOY3.X9K8CXVSxZWf().psJpCSi8_h7NzZZ1vbR(paramString2).Q_(paramString3).psJpCSi8_h7NzZZ1vbR(paramList).D89UfNGBvLPp16h());
  }
  
  public abstract D89UfNGBvLPp16h wktp1mvgWsB4SzZr(String paramString, D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3);
  
  public abstract MxwALnHp3MNCI wqn(String paramString, D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3);
  
  private static final class psJpCSi8_h7NzZZ1vbR extends Ap4G4fS9phs {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public X9K8CXVSxZWf D89UfNGBvLPp16h(String param1String, D_K6ibTZHL_tOOY3 param1D_K6ibTZHL_tOOY3) {
      return X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR((String)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "name"), param1D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR(), param1D_K6ibTZHL_tOOY3.Q_(), param1D_K6ibTZHL_tOOY3.XV2I8z());
    }
    
    public wktp1mvgWsB4SzZr MxwALnHp3MNCI(String param1String, D_K6ibTZHL_tOOY3 param1D_K6ibTZHL_tOOY3) {
      return wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR((String)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "name"), param1D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR(), param1D_K6ibTZHL_tOOY3.Q_(), param1D_K6ibTZHL_tOOY3.XV2I8z());
    }
    
    public BIRpv Q_(String param1String, D_K6ibTZHL_tOOY3 param1D_K6ibTZHL_tOOY3) {
      return BIRpv.psJpCSi8_h7NzZZ1vbR((String)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "name"), param1D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR(), param1D_K6ibTZHL_tOOY3.Q_(), param1D_K6ibTZHL_tOOY3.XV2I8z());
    }
    
    public hzEmy X9K8CXVSxZWf(String param1String, D_K6ibTZHL_tOOY3 param1D_K6ibTZHL_tOOY3) {
      return hzEmy.psJpCSi8_h7NzZZ1vbR((String)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "name"), param1D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR(), param1D_K6ibTZHL_tOOY3.Q_(), param1D_K6ibTZHL_tOOY3.XV2I8z());
    }
    
    public wqn XV2I8z(String param1String, D_K6ibTZHL_tOOY3 param1D_K6ibTZHL_tOOY3) {
      return wqn.psJpCSi8_h7NzZZ1vbR((String)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "name"), param1D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR(), param1D_K6ibTZHL_tOOY3.Q_(), param1D_K6ibTZHL_tOOY3.XV2I8z());
    }
    
    public rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR(String param1String, D_K6ibTZHL_tOOY3 param1D_K6ibTZHL_tOOY3) {
      return rG8A403wjTaYB6V.psJpCSi8_h7NzZZ1vbR((String)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "name"), param1D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR(), param1D_K6ibTZHL_tOOY3.Q_(), param1D_K6ibTZHL_tOOY3.XV2I8z());
    }
    
    public D89UfNGBvLPp16h wktp1mvgWsB4SzZr(String param1String, D_K6ibTZHL_tOOY3 param1D_K6ibTZHL_tOOY3) {
      return D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR((String)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "name"), param1D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR(), param1D_K6ibTZHL_tOOY3.Q_(), param1D_K6ibTZHL_tOOY3.XV2I8z());
    }
    
    public MxwALnHp3MNCI wqn(String param1String, D_K6ibTZHL_tOOY3 param1D_K6ibTZHL_tOOY3) {
      return MxwALnHp3MNCI.psJpCSi8_h7NzZZ1vbR((String)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String, "name"), param1D_K6ibTZHL_tOOY3.psJpCSi8_h7NzZZ1vbR(), param1D_K6ibTZHL_tOOY3.Q_(), param1D_K6ibTZHL_tOOY3.XV2I8z());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Ap4G4fS9phs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */