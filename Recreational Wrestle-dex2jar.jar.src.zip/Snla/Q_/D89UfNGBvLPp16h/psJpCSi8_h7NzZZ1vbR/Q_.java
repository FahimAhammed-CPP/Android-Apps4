package Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR;

import java.util.Objects;

final class Q_ extends psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR {
  private final String psJpCSi8_h7NzZZ1vbR;
  
  Q_(String paramString) {
    Objects.requireNonNull(paramString, "Null value");
    this.psJpCSi8_h7NzZZ1vbR = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AttachmentValueString{value=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\psJpCSi8_h7NzZZ1vbR\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */