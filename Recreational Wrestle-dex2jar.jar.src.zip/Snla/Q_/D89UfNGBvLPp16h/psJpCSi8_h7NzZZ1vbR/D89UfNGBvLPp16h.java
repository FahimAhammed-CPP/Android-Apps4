package Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class D89UfNGBvLPp16h {
  public static D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR(double paramDouble, LEwT0cz2WRRZ paramLEwT0cz2WRRZ, Map<String, psJpCSi8_h7NzZZ1vbR> paramMap) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramMap, "attachments");
    paramMap = Collections.unmodifiableMap(new HashMap<String, psJpCSi8_h7NzZZ1vbR>(paramMap));
    for (Map.Entry<String, psJpCSi8_h7NzZZ1vbR> entry : paramMap.entrySet()) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(entry.getKey(), "key of attachments");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(entry.getValue(), "value of attachments");
    } 
    return new XV2I8z(paramDouble, paramLEwT0cz2WRRZ, paramMap);
  }
  
  public abstract LEwT0cz2WRRZ Q_();
  
  public abstract Map<String, psJpCSi8_h7NzZZ1vbR> XV2I8z();
  
  public abstract double psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\psJpCSi8_h7NzZZ1vbR\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */