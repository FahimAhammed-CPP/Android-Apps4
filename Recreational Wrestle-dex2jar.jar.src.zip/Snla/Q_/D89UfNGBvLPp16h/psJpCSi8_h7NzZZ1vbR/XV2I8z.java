package Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;
import java.util.Map;
import java.util.Objects;

final class XV2I8z extends D89UfNGBvLPp16h {
  private final LEwT0cz2WRRZ Q_;
  
  private final Map<String, psJpCSi8_h7NzZZ1vbR> XV2I8z;
  
  private final double psJpCSi8_h7NzZZ1vbR;
  
  XV2I8z(double paramDouble, LEwT0cz2WRRZ paramLEwT0cz2WRRZ, Map<String, psJpCSi8_h7NzZZ1vbR> paramMap) {
    this.psJpCSi8_h7NzZZ1vbR = paramDouble;
    Objects.requireNonNull(paramLEwT0cz2WRRZ, "Null timestamp");
    this.Q_ = paramLEwT0cz2WRRZ;
    Objects.requireNonNull(paramMap, "Null attachments");
    this.XV2I8z = paramMap;
  }
  
  public LEwT0cz2WRRZ Q_() {
    return this.Q_;
  }
  
  public Map<String, psJpCSi8_h7NzZZ1vbR> XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof D89UfNGBvLPp16h) {
      paramObject = paramObject;
      return (Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) == Double.doubleToLongBits(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()) && this.XV2I8z.equals(paramObject.XV2I8z()));
    } 
    return false;
  }
  
  public int hashCode() {
    int i = (int)(1000003L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR) >>> 32L ^ Double.doubleToLongBits(this.psJpCSi8_h7NzZZ1vbR));
    int j = this.Q_.hashCode();
    return this.XV2I8z.hashCode() ^ (i * 1000003 ^ j) * 1000003;
  }
  
  public double psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Exemplar{value=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", timestamp=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", attachments=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\psJpCSi8_h7NzZZ1vbR\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */