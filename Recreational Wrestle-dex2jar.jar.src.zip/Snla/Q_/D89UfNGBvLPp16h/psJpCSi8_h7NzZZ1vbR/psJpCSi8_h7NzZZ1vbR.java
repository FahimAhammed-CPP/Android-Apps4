package Snla.Q_.D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR;

public abstract class psJpCSi8_h7NzZZ1vbR {
  public abstract String psJpCSi8_h7NzZZ1vbR();
  
  public static abstract class psJpCSi8_h7NzZZ1vbR extends psJpCSi8_h7NzZZ1vbR {
    public static psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String) {
      return new Q_(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */