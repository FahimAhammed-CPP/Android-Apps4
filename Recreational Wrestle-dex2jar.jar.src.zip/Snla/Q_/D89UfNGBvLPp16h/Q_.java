package Snla.Q_.D89UfNGBvLPp16h;

import javax.annotation.Nullable;

final class Q_ extends qY {
  private final String psJpCSi8_h7NzZZ1vbR;
  
  Q_(@Nullable String paramString) {
    this.psJpCSi8_h7NzZZ1vbR = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof qY) {
      qY qY1 = (qY)paramObject;
      paramObject = this.psJpCSi8_h7NzZZ1vbR;
      String str = qY1.psJpCSi8_h7NzZZ1vbR();
      return (paramObject == null) ? ((str == null)) : paramObject.equals(str);
    } 
    return false;
  }
  
  public int hashCode() {
    int i;
    String str = this.psJpCSi8_h7NzZZ1vbR;
    if (str == null) {
      i = 0;
    } else {
      i = str.hashCode();
    } 
    return i ^ 0xF4243;
  }
  
  @Nullable
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LabelValue{value=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */