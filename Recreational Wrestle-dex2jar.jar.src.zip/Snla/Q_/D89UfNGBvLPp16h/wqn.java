package Snla.Q_.D89UfNGBvLPp16h;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.jlrPm;
import java.util.List;

public abstract class wqn {
  static wqn psJpCSi8_h7NzZZ1vbR(String paramString1, String paramString2, String paramString3, List<LEIMjJ> paramList) {
    return psJpCSi8_h7NzZZ1vbR.Q_(paramString1, paramString2, paramString3, paramList);
  }
  
  public abstract void psJpCSi8_h7NzZZ1vbR();
  
  public abstract void psJpCSi8_h7NzZZ1vbR(List<qY> paramList);
  
  public abstract <T> void psJpCSi8_h7NzZZ1vbR(List<qY> paramList, T paramT, jlrPm<T> paramjlrPm);
  
  private static final class psJpCSi8_h7NzZZ1vbR extends wqn {
    private final int psJpCSi8_h7NzZZ1vbR;
    
    psJpCSi8_h7NzZZ1vbR(String param1String1, String param1String2, String param1String3, List<LEIMjJ> param1List) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String1, "name");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String2, "description");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1String3, "unit");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR((List)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List, "labelKeys"), "labelKey");
      this.psJpCSi8_h7NzZZ1vbR = param1List.size();
    }
    
    static psJpCSi8_h7NzZZ1vbR Q_(String param1String1, String param1String2, String param1String3, List<LEIMjJ> param1List) {
      return new psJpCSi8_h7NzZZ1vbR(param1String1, param1String2, param1String3, param1List);
    }
    
    public void psJpCSi8_h7NzZZ1vbR() {}
    
    public void psJpCSi8_h7NzZZ1vbR(List<qY> param1List) {
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List, "labelValues");
    }
    
    public <T> void psJpCSi8_h7NzZZ1vbR(List<qY> param1List, T param1T, jlrPm<T> param1jlrPm) {
      boolean bool;
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR((List)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1List, "labelValues"), "labelValue");
      if (this.psJpCSi8_h7NzZZ1vbR == param1List.size()) {
        bool = true;
      } else {
        bool = false;
      } 
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(bool, "Label Keys and Label Values don't have same size.");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1jlrPm, "function");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\wqn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */