package Snla.Q_.D89UfNGBvLPp16h;

import Snla.Q_.D89UfNGBvLPp16h.Q_.GUkgqR9XjHnivS;

public abstract class oq9TzoD0 {
  static oq9TzoD0 XV2I8z() {
    return new psJpCSi8_h7NzZZ1vbR();
  }
  
  public abstract Ap4G4fS9phs Q_();
  
  public abstract GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR();
  
  private static final class psJpCSi8_h7NzZZ1vbR extends oq9TzoD0 {
    private static final Ap4G4fS9phs Q_ = Ap4G4fS9phs.psJpCSi8_h7NzZZ1vbR();
    
    private static final GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR = GUkgqR9XjHnivS.psJpCSi8_h7NzZZ1vbR();
    
    static {
    
    }
    
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public Ap4G4fS9phs Q_() {
      return Q_;
    }
    
    public GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR() {
      return psJpCSi8_h7NzZZ1vbR;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\oq9TzoD0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */