package Snla.Q_.D89UfNGBvLPp16h;

import Snla.Q_.D89UfNGBvLPp16h.Q_.GUkgqR9XjHnivS;
import Snla.Q_.XV2I8z.XV2I8z;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;

public final class GUkgqR9XjHnivS {
  private static final oq9TzoD0 Q_;
  
  private static final Logger psJpCSi8_h7NzZZ1vbR = Logger.getLogger(GUkgqR9XjHnivS.class.getName());
  
  static {
    Q_ = psJpCSi8_h7NzZZ1vbR(oq9TzoD0.class.getClassLoader());
  }
  
  public static Ap4G4fS9phs Q_() {
    return Q_.Q_();
  }
  
  public static GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR() {
    return Q_.psJpCSi8_h7NzZZ1vbR();
  }
  
  static oq9TzoD0 psJpCSi8_h7NzZZ1vbR(@Nullable ClassLoader paramClassLoader) {
    try {
      return (oq9TzoD0)XV2I8z.psJpCSi8_h7NzZZ1vbR(Class.forName("io.opencensus.impl.metrics.MetricsComponentImpl", true, paramClassLoader), oq9TzoD0.class);
    } catch (ClassNotFoundException classNotFoundException) {
      psJpCSi8_h7NzZZ1vbR.log(Level.FINE, "Couldn't load full implementation for MetricsComponent, now trying to load lite implementation.", classNotFoundException);
      try {
        return (oq9TzoD0)XV2I8z.psJpCSi8_h7NzZZ1vbR(Class.forName("io.opencensus.impllite.metrics.MetricsComponentImplLite", true, paramClassLoader), oq9TzoD0.class);
      } catch (ClassNotFoundException classNotFoundException1) {
        psJpCSi8_h7NzZZ1vbR.log(Level.FINE, "Couldn't load lite implementation for MetricsComponent, now using default implementation for MetricsComponent.", classNotFoundException1);
        return oq9TzoD0.XV2I8z();
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\GUkgqR9XjHnivS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */