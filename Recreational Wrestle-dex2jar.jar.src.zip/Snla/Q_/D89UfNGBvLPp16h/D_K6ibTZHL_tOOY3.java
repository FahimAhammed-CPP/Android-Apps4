package Snla.Q_.D89UfNGBvLPp16h;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class D_K6ibTZHL_tOOY3 {
  public static psJpCSi8_h7NzZZ1vbR X9K8CXVSxZWf() {
    return (new XV2I8z.psJpCSi8_h7NzZZ1vbR()).psJpCSi8_h7NzZZ1vbR("").Q_("1").psJpCSi8_h7NzZZ1vbR(Collections.emptyList()).psJpCSi8_h7NzZZ1vbR(Collections.emptyMap());
  }
  
  public abstract Map<LEIMjJ, qY> D89UfNGBvLPp16h();
  
  public abstract String Q_();
  
  public abstract List<LEIMjJ> XV2I8z();
  
  public abstract String psJpCSi8_h7NzZZ1vbR();
  
  public static abstract class psJpCSi8_h7NzZZ1vbR {
    public D_K6ibTZHL_tOOY3 D89UfNGBvLPp16h() {
      psJpCSi8_h7NzZZ1vbR(Collections.unmodifiableList(new ArrayList<LEIMjJ>(psJpCSi8_h7NzZZ1vbR())));
      psJpCSi8_h7NzZZ1vbR(Collections.unmodifiableMap(new LinkedHashMap<LEIMjJ, qY>(Q_())));
      D_K6ibTZHL_tOOY3 d_K6ibTZHL_tOOY3 = XV2I8z();
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(d_K6ibTZHL_tOOY3.XV2I8z(), "labelKeys elements");
      X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(d_K6ibTZHL_tOOY3.D89UfNGBvLPp16h(), "constantLabels elements");
      HashSet<String> hashSet = new HashSet();
      for (LEIMjJ lEIMjJ : d_K6ibTZHL_tOOY3.XV2I8z()) {
        if (!hashSet.contains(lEIMjJ.psJpCSi8_h7NzZZ1vbR())) {
          hashSet.add(lEIMjJ.psJpCSi8_h7NzZZ1vbR());
          continue;
        } 
        throw new IllegalArgumentException("Invalid LabelKey in labelKeys");
      } 
      for (Map.Entry<LEIMjJ, qY> entry : d_K6ibTZHL_tOOY3.D89UfNGBvLPp16h().entrySet()) {
        if (!hashSet.contains(((LEIMjJ)entry.getKey()).psJpCSi8_h7NzZZ1vbR())) {
          hashSet.add(((LEIMjJ)entry.getKey()).psJpCSi8_h7NzZZ1vbR());
          continue;
        } 
        throw new IllegalArgumentException("Invalid LabelKey in constantLabels");
      } 
      return d_K6ibTZHL_tOOY3;
    }
    
    public abstract psJpCSi8_h7NzZZ1vbR Q_(String param1String);
    
    abstract Map<LEIMjJ, qY> Q_();
    
    abstract D_K6ibTZHL_tOOY3 XV2I8z();
    
    public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(String param1String);
    
    public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(List<LEIMjJ> param1List);
    
    public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(Map<LEIMjJ, qY> param1Map);
    
    abstract List<LEIMjJ> psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\D89UfNGBvLPp16h\D_K6ibTZHL_tOOY3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */