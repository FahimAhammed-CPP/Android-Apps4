package Snla.Q_.XV2I8z;

public final class D89UfNGBvLPp16h {
  private static boolean psJpCSi8_h7NzZZ1vbR(char paramChar) {
    return (paramChar >= ' ' && paramChar <= '~');
  }
  
  public static boolean psJpCSi8_h7NzZZ1vbR(String paramString) {
    for (int i = 0; i < paramString.length(); i++) {
      if (!psJpCSi8_h7NzZZ1vbR(paramString.charAt(i)))
        return false; 
    } 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\XV2I8z\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */