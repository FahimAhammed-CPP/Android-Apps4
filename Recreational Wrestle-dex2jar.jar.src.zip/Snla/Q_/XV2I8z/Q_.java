package Snla.Q_.XV2I8z;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.hzEmy;

public final class Q_ implements hzEmy {
  private static final hzEmy psJpCSi8_h7NzZZ1vbR = new Q_();
  
  public static hzEmy psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public void close() {}
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\XV2I8z\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */