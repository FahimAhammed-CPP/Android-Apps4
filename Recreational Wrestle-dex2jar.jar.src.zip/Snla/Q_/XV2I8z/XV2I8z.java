package Snla.Q_.XV2I8z;

import java.util.ServiceConfigurationError;

public final class XV2I8z {
  public static <T> T psJpCSi8_h7NzZZ1vbR(Class<?> paramClass, Class<T> paramClass1) {
    try {
      return (T)paramClass.<Class<T>>asSubclass((Class)paramClass1).getConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Provider ");
      stringBuilder.append(paramClass.getName());
      stringBuilder.append(" could not be instantiated.");
      throw new ServiceConfigurationError(stringBuilder.toString(), exception);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\XV2I8z\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */