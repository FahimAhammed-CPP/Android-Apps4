package Snla.Q_.XV2I8z;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.SOURCE)
@Target({ElementType.ANNOTATION_TYPE, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.METHOD, ElementType.PACKAGE, ElementType.TYPE})
public @interface psJpCSi8_h7NzZZ1vbR {}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\XV2I8z\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */