package Snla.Q_.XV2I8z;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public final class X9K8CXVSxZWf {
  public static void Q_(boolean paramBoolean, @Nullable Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(String.valueOf(paramObject));
  }
  
  public static boolean Q_(@Nullable Object paramObject1, @Nullable Object paramObject2) {
    return (paramObject1 == null) ? ((paramObject2 == null)) : paramObject1.equals(paramObject2);
  }
  
  public static <T> T psJpCSi8_h7NzZZ1vbR(T paramT, @Nullable Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(String.valueOf(paramObject));
  }
  
  private static String psJpCSi8_h7NzZZ1vbR(String paramString, @Nullable Object... paramVarArgs) {
    if (paramVarArgs == null)
      return paramString; 
    StringBuilder stringBuilder = new StringBuilder(paramString.length() + paramVarArgs.length * 16);
    int i = 0;
    int j = 0;
    while (i < paramVarArgs.length) {
      int k = paramString.indexOf("%s", j);
      if (k == -1)
        break; 
      stringBuilder.append(paramString, j, k);
      stringBuilder.append(paramVarArgs[i]);
      j = k + 2;
      i++;
    } 
    stringBuilder.append(paramString, j, paramString.length());
    if (i < paramVarArgs.length) {
      stringBuilder.append(" [");
      j = i + 1;
      stringBuilder.append(paramVarArgs[i]);
      for (i = j; i < paramVarArgs.length; i++) {
        stringBuilder.append(", ");
        stringBuilder.append(paramVarArgs[i]);
      } 
      stringBuilder.append(']');
    } 
    return stringBuilder.toString();
  }
  
  public static void psJpCSi8_h7NzZZ1vbR(int paramInt1, int paramInt2) {
    if (paramInt2 >= 0) {
      if (paramInt1 >= 0 && paramInt1 < paramInt2)
        return; 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Index out of bounds: size=");
      stringBuilder1.append(paramInt2);
      stringBuilder1.append(", index=");
      stringBuilder1.append(paramInt1);
      throw new IndexOutOfBoundsException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Negative size: ");
    stringBuilder.append(paramInt2);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static <T> void psJpCSi8_h7NzZZ1vbR(List<T> paramList, @Nullable Object paramObject) {
    Iterator<T> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      if (iterator.next() != null)
        continue; 
      throw new NullPointerException(String.valueOf(paramObject));
    } 
  }
  
  public static <K, V> void psJpCSi8_h7NzZZ1vbR(Map<K, V> paramMap, @Nullable Object paramObject) {
    for (Map.Entry<K, V> entry : paramMap.entrySet()) {
      if (entry.getKey() != null && entry.getValue() != null)
        continue; 
      throw new NullPointerException(String.valueOf(paramObject));
    } 
  }
  
  public static void psJpCSi8_h7NzZZ1vbR(boolean paramBoolean, @Nullable Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(String.valueOf(paramObject));
  }
  
  public static void psJpCSi8_h7NzZZ1vbR(boolean paramBoolean, String paramString, @Nullable Object... paramVarArgs) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(psJpCSi8_h7NzZZ1vbR(paramString, paramVarArgs));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\XV2I8z\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */