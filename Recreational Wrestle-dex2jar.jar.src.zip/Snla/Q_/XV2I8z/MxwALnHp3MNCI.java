package Snla.Q_.XV2I8z;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h;
import Snla.Q_.psJpCSi8_h7NzZZ1vbR.LEwT0cz2WRRZ;

public final class MxwALnHp3MNCI extends D89UfNGBvLPp16h {
  private static final LEwT0cz2WRRZ Q_;
  
  private static final MxwALnHp3MNCI psJpCSi8_h7NzZZ1vbR = new MxwALnHp3MNCI();
  
  static {
    Q_ = LEwT0cz2WRRZ.psJpCSi8_h7NzZZ1vbR(0L, 0);
  }
  
  public static MxwALnHp3MNCI XV2I8z() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public long Q_() {
    return 0L;
  }
  
  public LEwT0cz2WRRZ psJpCSi8_h7NzZZ1vbR() {
    return Q_;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\XV2I8z\MxwALnHp3MNCI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */