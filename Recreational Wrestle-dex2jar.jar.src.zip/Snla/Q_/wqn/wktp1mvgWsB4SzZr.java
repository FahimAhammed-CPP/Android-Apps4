package Snla.Q_.wqn;

import java.util.HashMap;
import java.util.Iterator;
import javax.annotation.Nullable;

public abstract class wktp1mvgWsB4SzZr {
  public boolean equals(@Nullable Object<wqn> paramObject) {
    if (!(paramObject instanceof wktp1mvgWsB4SzZr))
      return false; 
    wktp1mvgWsB4SzZr wktp1mvgWsB4SzZr1 = (wktp1mvgWsB4SzZr)paramObject;
    paramObject = (Object<wqn>)psJpCSi8_h7NzZZ1vbR();
    Iterator<wqn> iterator = wktp1mvgWsB4SzZr1.psJpCSi8_h7NzZZ1vbR();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    while (paramObject != null && paramObject.hasNext()) {
      wqn wqn = paramObject.next();
      if (hashMap.containsKey(wqn)) {
        hashMap.put(wqn, Integer.valueOf(((Integer)hashMap.get(wqn)).intValue() + 1));
        continue;
      } 
      hashMap.put(wqn, Integer.valueOf(1));
    } 
    while (iterator != null && iterator.hasNext()) {
      paramObject = (Object<wqn>)iterator.next();
      if (!hashMap.containsKey(paramObject))
        return false; 
      int i = ((Integer)hashMap.get(paramObject)).intValue();
      if (i > 1) {
        hashMap.put(paramObject, Integer.valueOf(i - 1));
        continue;
      } 
      hashMap.remove(paramObject);
    } 
    return hashMap.isEmpty();
  }
  
  public final int hashCode() {
    Iterator<wqn> iterator = psJpCSi8_h7NzZZ1vbR();
    int i = 0;
    if (iterator == null)
      return 0; 
    while (iterator.hasNext()) {
      wqn wqn = iterator.next();
      if (wqn != null)
        i += wqn.hashCode(); 
    } 
    return i;
  }
  
  protected abstract Iterator<wqn> psJpCSi8_h7NzZZ1vbR();
  
  public String toString() {
    return "TagContext";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\wktp1mvgWsB4SzZr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */