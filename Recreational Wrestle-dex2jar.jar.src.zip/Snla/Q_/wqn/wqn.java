package Snla.Q_.wqn;

public abstract class wqn {
  private static final qY psJpCSi8_h7NzZZ1vbR = qY.psJpCSi8_h7NzZZ1vbR(qY.psJpCSi8_h7NzZZ1vbR.Q_);
  
  @Deprecated
  public static wqn psJpCSi8_h7NzZZ1vbR(LEIMjJ paramLEIMjJ, hzEmy paramhzEmy) {
    return psJpCSi8_h7NzZZ1vbR(paramLEIMjJ, paramhzEmy, psJpCSi8_h7NzZZ1vbR);
  }
  
  public static wqn psJpCSi8_h7NzZZ1vbR(LEIMjJ paramLEIMjJ, hzEmy paramhzEmy, qY paramqY) {
    return new psJpCSi8_h7NzZZ1vbR(paramLEIMjJ, paramhzEmy, paramqY);
  }
  
  public abstract hzEmy Q_();
  
  public abstract qY XV2I8z();
  
  public abstract LEIMjJ psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\wqn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */