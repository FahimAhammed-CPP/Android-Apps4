package Snla.Q_.wqn;

import Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf;

public abstract class GUkgqR9XjHnivS {
  public abstract X9K8CXVSxZWf Q_();
  
  public abstract D_K6ibTZHL_tOOY3 XV2I8z();
  
  public abstract rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR();
  
  @Deprecated
  public abstract void psJpCSi8_h7NzZZ1vbR(D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3);
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\GUkgqR9XjHnivS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */