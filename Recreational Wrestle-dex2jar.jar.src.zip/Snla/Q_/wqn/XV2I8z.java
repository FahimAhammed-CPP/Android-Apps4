package Snla.Q_.wqn;

import java.util.Objects;

final class XV2I8z extends qY {
  private final qY.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR;
  
  XV2I8z(qY.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    Objects.requireNonNull(parampsJpCSi8_h7NzZZ1vbR, "Null tagTtl");
    this.psJpCSi8_h7NzZZ1vbR = parampsJpCSi8_h7NzZZ1vbR;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof qY) {
      paramObject = paramObject;
      return this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243;
  }
  
  public qY.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TagMetadata{tagTtl=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */