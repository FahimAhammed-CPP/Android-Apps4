package Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR;

public final class Q_ extends Exception {
  private static final long serialVersionUID = 0L;
  
  public Q_(String paramString) {
    super(paramString);
  }
  
  public Q_(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\psJpCSi8_h7NzZZ1vbR\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */