package Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR;

public abstract class X9K8CXVSxZWf {
  public abstract D89UfNGBvLPp16h Q_();
  
  public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\psJpCSi8_h7NzZZ1vbR\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */