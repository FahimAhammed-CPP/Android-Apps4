package Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.wqn.wktp1mvgWsB4SzZr;
import java.util.List;
import javax.annotation.Nullable;

public abstract class D89UfNGBvLPp16h {
  public abstract <C> wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR(C paramC, psJpCSi8_h7NzZZ1vbR<C> parampsJpCSi8_h7NzZZ1vbR) throws Q_;
  
  public abstract List<String> psJpCSi8_h7NzZZ1vbR();
  
  public abstract <C> void psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr paramwktp1mvgWsB4SzZr, C paramC, Q_<C> paramQ_) throws XV2I8z;
  
  public static abstract class Q_<C> {
    public abstract void psJpCSi8_h7NzZZ1vbR(C param1C, String param1String1, String param1String2);
  }
  
  public static abstract class psJpCSi8_h7NzZZ1vbR<C> {
    @Nullable
    public abstract String psJpCSi8_h7NzZZ1vbR(C param1C, String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\psJpCSi8_h7NzZZ1vbR\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */