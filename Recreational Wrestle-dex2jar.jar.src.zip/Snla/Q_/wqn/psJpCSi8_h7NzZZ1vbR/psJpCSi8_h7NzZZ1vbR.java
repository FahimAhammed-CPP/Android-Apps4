package Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR;

import Snla.Q_.wqn.wktp1mvgWsB4SzZr;

public abstract class psJpCSi8_h7NzZZ1vbR {
  public abstract wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR(byte[] paramArrayOfbyte) throws Q_;
  
  public abstract byte[] psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr paramwktp1mvgWsB4SzZr) throws XV2I8z;
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */