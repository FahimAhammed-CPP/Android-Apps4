package Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR;

public final class XV2I8z extends Exception {
  private static final long serialVersionUID = 0L;
  
  public XV2I8z(String paramString) {
    super(paramString);
  }
  
  public XV2I8z(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\psJpCSi8_h7NzZZ1vbR\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */