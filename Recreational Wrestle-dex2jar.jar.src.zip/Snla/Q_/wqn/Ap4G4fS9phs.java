package Snla.Q_.wqn;

import Snla.Q_.XV2I8z.XV2I8z;
import Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;

public final class Ap4G4fS9phs {
  private static final GUkgqR9XjHnivS Q_;
  
  private static final Logger psJpCSi8_h7NzZZ1vbR = Logger.getLogger(Ap4G4fS9phs.class.getName());
  
  static {
    Q_ = psJpCSi8_h7NzZZ1vbR(GUkgqR9XjHnivS.class.getClassLoader());
  }
  
  public static X9K8CXVSxZWf Q_() {
    return Q_.Q_();
  }
  
  public static D_K6ibTZHL_tOOY3 XV2I8z() {
    return Q_.XV2I8z();
  }
  
  static GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR(@Nullable ClassLoader paramClassLoader) {
    try {
      return (GUkgqR9XjHnivS)XV2I8z.psJpCSi8_h7NzZZ1vbR(Class.forName("io.opencensus.impl.tags.TagsComponentImpl", true, paramClassLoader), GUkgqR9XjHnivS.class);
    } catch (ClassNotFoundException classNotFoundException) {
      psJpCSi8_h7NzZZ1vbR.log(Level.FINE, "Couldn't load full implementation for TagsComponent, now trying to load lite implementation.", classNotFoundException);
      try {
        return (GUkgqR9XjHnivS)XV2I8z.psJpCSi8_h7NzZZ1vbR(Class.forName("io.opencensus.impllite.tags.TagsComponentImplLite", true, paramClassLoader), GUkgqR9XjHnivS.class);
      } catch (ClassNotFoundException classNotFoundException1) {
        psJpCSi8_h7NzZZ1vbR.log(Level.FINE, "Couldn't load lite implementation for TagsComponent, now using default implementation for TagsComponent.", classNotFoundException1);
        return MxwALnHp3MNCI.psJpCSi8_h7NzZZ1vbR();
      } 
    } 
  }
  
  public static rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR() {
    return Q_.psJpCSi8_h7NzZZ1vbR();
  }
  
  @Deprecated
  public static void psJpCSi8_h7NzZZ1vbR(D_K6ibTZHL_tOOY3 paramD_K6ibTZHL_tOOY3) {
    Q_.psJpCSi8_h7NzZZ1vbR(paramD_K6ibTZHL_tOOY3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\Ap4G4fS9phs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */