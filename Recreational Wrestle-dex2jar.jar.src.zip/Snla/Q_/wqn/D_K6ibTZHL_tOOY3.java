package Snla.Q_.wqn;

public enum D_K6ibTZHL_tOOY3 {
  Q_, psJpCSi8_h7NzZZ1vbR;
  
  static {
    D_K6ibTZHL_tOOY3 d_K6ibTZHL_tOOY31 = new D_K6ibTZHL_tOOY3("ENABLED", 0);
    psJpCSi8_h7NzZZ1vbR = d_K6ibTZHL_tOOY31;
    D_K6ibTZHL_tOOY3 d_K6ibTZHL_tOOY32 = new D_K6ibTZHL_tOOY3("DISABLED", 1);
    Q_ = d_K6ibTZHL_tOOY32;
    XV2I8z = new D_K6ibTZHL_tOOY3[] { d_K6ibTZHL_tOOY31, d_K6ibTZHL_tOOY32 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\D_K6ibTZHL_tOOY3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */