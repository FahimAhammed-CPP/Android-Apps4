package Snla.Q_.wqn;

public abstract class qY {
  public static qY psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    return new XV2I8z(parampsJpCSi8_h7NzZZ1vbR);
  }
  
  public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR();
  
  public enum psJpCSi8_h7NzZZ1vbR {
    Q_, psJpCSi8_h7NzZZ1vbR;
    
    private final int XV2I8z;
    
    static {
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = new psJpCSi8_h7NzZZ1vbR("NO_PROPAGATION", 0, 0);
      psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR1;
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR2 = new psJpCSi8_h7NzZZ1vbR("UNLIMITED_PROPAGATION", 1, -1);
      Q_ = psJpCSi8_h7NzZZ1vbR2;
      D89UfNGBvLPp16h = new psJpCSi8_h7NzZZ1vbR[] { psJpCSi8_h7NzZZ1vbR1, psJpCSi8_h7NzZZ1vbR2 };
    }
    
    psJpCSi8_h7NzZZ1vbR(int param1Int1) {
      this.XV2I8z = param1Int1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\qY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */