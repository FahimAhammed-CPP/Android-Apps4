package Snla.Q_.wqn;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.hzEmy;
import Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h;
import Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR.Q_;
import Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf;
import Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR.XV2I8z;
import Snla.Q_.wqn.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

final class MxwALnHp3MNCI {
  static wktp1mvgWsB4SzZr D89UfNGBvLPp16h() {
    return psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;
  }
  
  static psJpCSi8_h7NzZZ1vbR MxwALnHp3MNCI() {
    return Q_.psJpCSi8_h7NzZZ1vbR;
  }
  
  static rG8A403wjTaYB6V Q_() {
    return MxwALnHp3MNCI.psJpCSi8_h7NzZZ1vbR;
  }
  
  static X9K8CXVSxZWf X9K8CXVSxZWf() {
    return X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR;
  }
  
  static BIRpv XV2I8z() {
    return XV2I8z.psJpCSi8_h7NzZZ1vbR;
  }
  
  static GUkgqR9XjHnivS psJpCSi8_h7NzZZ1vbR() {
    return new wqn();
  }
  
  static D89UfNGBvLPp16h wqn() {
    return D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR;
  }
  
  private static final class D89UfNGBvLPp16h extends D89UfNGBvLPp16h {
    static final D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR = new D89UfNGBvLPp16h();
    
    public <C> wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR(C param1C, D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR<C> param1psJpCSi8_h7NzZZ1vbR) throws Q_ {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1C, "carrier");
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1psJpCSi8_h7NzZZ1vbR, "getter");
      return MxwALnHp3MNCI.D89UfNGBvLPp16h();
    }
    
    public List<String> psJpCSi8_h7NzZZ1vbR() {
      return Collections.emptyList();
    }
    
    public <C> void psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr param1wktp1mvgWsB4SzZr, C param1C, D89UfNGBvLPp16h.Q_<C> param1Q_) throws XV2I8z {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1wktp1mvgWsB4SzZr, "tagContext");
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1C, "carrier");
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1Q_, "setter");
    }
  }
  
  private static final class MxwALnHp3MNCI extends rG8A403wjTaYB6V {
    static final rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR = new MxwALnHp3MNCI();
    
    public BIRpv D89UfNGBvLPp16h() {
      return MxwALnHp3MNCI.XV2I8z();
    }
    
    public hzEmy Q_(wktp1mvgWsB4SzZr param1wktp1mvgWsB4SzZr) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1wktp1mvgWsB4SzZr, "tags");
      return Snla.Q_.XV2I8z.Q_.psJpCSi8_h7NzZZ1vbR();
    }
    
    public wktp1mvgWsB4SzZr Q_() {
      return MxwALnHp3MNCI.D89UfNGBvLPp16h();
    }
    
    public BIRpv XV2I8z() {
      return MxwALnHp3MNCI.XV2I8z();
    }
    
    public BIRpv psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr param1wktp1mvgWsB4SzZr) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1wktp1mvgWsB4SzZr, "tags");
      return MxwALnHp3MNCI.XV2I8z();
    }
    
    public wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR() {
      return MxwALnHp3MNCI.D89UfNGBvLPp16h();
    }
  }
  
  private static final class Q_ extends psJpCSi8_h7NzZZ1vbR {
    static final byte[] Q_ = new byte[0];
    
    static final psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = new Q_();
    
    static {
    
    }
    
    public wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR(byte[] param1ArrayOfbyte) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1ArrayOfbyte, "bytes");
      return MxwALnHp3MNCI.D89UfNGBvLPp16h();
    }
    
    public byte[] psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr param1wktp1mvgWsB4SzZr) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1wktp1mvgWsB4SzZr, "tags");
      return Q_;
    }
  }
  
  private static final class X9K8CXVSxZWf extends X9K8CXVSxZWf {
    static final X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR = new X9K8CXVSxZWf();
    
    public D89UfNGBvLPp16h Q_() {
      return MxwALnHp3MNCI.wqn();
    }
    
    public psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
      return MxwALnHp3MNCI.MxwALnHp3MNCI();
    }
  }
  
  private static final class XV2I8z extends BIRpv {
    static final BIRpv psJpCSi8_h7NzZZ1vbR = new XV2I8z();
    
    public hzEmy Q_() {
      return Snla.Q_.XV2I8z.Q_.psJpCSi8_h7NzZZ1vbR();
    }
    
    public BIRpv psJpCSi8_h7NzZZ1vbR(LEIMjJ param1LEIMjJ) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1LEIMjJ, "key");
      return this;
    }
    
    public BIRpv psJpCSi8_h7NzZZ1vbR(LEIMjJ param1LEIMjJ, hzEmy param1hzEmy) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1LEIMjJ, "key");
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1hzEmy, "value");
      return this;
    }
    
    public BIRpv psJpCSi8_h7NzZZ1vbR(LEIMjJ param1LEIMjJ, hzEmy param1hzEmy, qY param1qY) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1LEIMjJ, "key");
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1hzEmy, "value");
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1qY, "tagMetadata");
      return this;
    }
    
    public wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR() {
      return MxwALnHp3MNCI.D89UfNGBvLPp16h();
    }
  }
  
  private static final class psJpCSi8_h7NzZZ1vbR extends wktp1mvgWsB4SzZr {
    static final wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR = new psJpCSi8_h7NzZZ1vbR();
    
    protected Iterator<wqn> psJpCSi8_h7NzZZ1vbR() {
      return Collections.<wqn>emptySet().iterator();
    }
  }
  
  private static final class wqn extends GUkgqR9XjHnivS {
    private volatile boolean psJpCSi8_h7NzZZ1vbR;
    
    private wqn() {}
    
    public X9K8CXVSxZWf Q_() {
      return MxwALnHp3MNCI.X9K8CXVSxZWf();
    }
    
    public D_K6ibTZHL_tOOY3 XV2I8z() {
      this.psJpCSi8_h7NzZZ1vbR = true;
      return D_K6ibTZHL_tOOY3.Q_;
    }
    
    public rG8A403wjTaYB6V psJpCSi8_h7NzZZ1vbR() {
      return MxwALnHp3MNCI.Q_();
    }
    
    @Deprecated
    public void psJpCSi8_h7NzZZ1vbR(D_K6ibTZHL_tOOY3 param1D_K6ibTZHL_tOOY3) {
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(param1D_K6ibTZHL_tOOY3, "state");
      Snla.Q_.XV2I8z.X9K8CXVSxZWf.Q_(this.psJpCSi8_h7NzZZ1vbR ^ true, "State was already read, cannot set state.");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\MxwALnHp3MNCI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */