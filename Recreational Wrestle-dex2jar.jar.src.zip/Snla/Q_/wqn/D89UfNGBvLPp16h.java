package Snla.Q_.wqn;

import java.util.Objects;

final class D89UfNGBvLPp16h extends hzEmy {
  private final String Q_;
  
  D89UfNGBvLPp16h(String paramString) {
    Objects.requireNonNull(paramString, "Null asString");
    this.Q_ = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof hzEmy) {
      paramObject = paramObject;
      return this.Q_.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.Q_.hashCode() ^ 0xF4243;
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.Q_;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TagValue{asString=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */