package Snla.Q_.wqn;

import java.util.Objects;

final class psJpCSi8_h7NzZZ1vbR extends wqn {
  private final hzEmy Q_;
  
  private final qY XV2I8z;
  
  private final LEIMjJ psJpCSi8_h7NzZZ1vbR;
  
  psJpCSi8_h7NzZZ1vbR(LEIMjJ paramLEIMjJ, hzEmy paramhzEmy, qY paramqY) {
    Objects.requireNonNull(paramLEIMjJ, "Null key");
    this.psJpCSi8_h7NzZZ1vbR = paramLEIMjJ;
    Objects.requireNonNull(paramhzEmy, "Null value");
    this.Q_ = paramhzEmy;
    Objects.requireNonNull(paramqY, "Null tagMetadata");
    this.XV2I8z = paramqY;
  }
  
  public hzEmy Q_() {
    return this.Q_;
  }
  
  public qY XV2I8z() {
    return this.XV2I8z;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof wqn) {
      paramObject = paramObject;
      return (this.psJpCSi8_h7NzZZ1vbR.equals(paramObject.psJpCSi8_h7NzZZ1vbR()) && this.Q_.equals(paramObject.Q_()) && this.XV2I8z.equals(paramObject.XV2I8z()));
    } 
    return false;
  }
  
  public int hashCode() {
    return ((this.psJpCSi8_h7NzZZ1vbR.hashCode() ^ 0xF4243) * 1000003 ^ this.Q_.hashCode()) * 1000003 ^ this.XV2I8z.hashCode();
  }
  
  public LEIMjJ psJpCSi8_h7NzZZ1vbR() {
    return this.psJpCSi8_h7NzZZ1vbR;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Tag{key=");
    stringBuilder.append(this.psJpCSi8_h7NzZZ1vbR);
    stringBuilder.append(", value=");
    stringBuilder.append(this.Q_);
    stringBuilder.append(", tagMetadata=");
    stringBuilder.append(this.XV2I8z);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */