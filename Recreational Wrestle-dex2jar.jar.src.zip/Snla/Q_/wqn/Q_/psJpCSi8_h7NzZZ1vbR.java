package Snla.Q_.wqn.Q_;

import Snla.Q_.XV2I8z.X9K8CXVSxZWf;
import Snla.Q_.wqn.wktp1mvgWsB4SzZr;
import Snla.Q_.wqn.wqn;
import java.util.Collections;
import java.util.Iterator;
import javax.annotation.Nullable;

public final class psJpCSi8_h7NzZZ1vbR {
  private static final Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.BIRpv<wktp1mvgWsB4SzZr> Q_;
  
  private static final wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR;
  
  static {
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = new psJpCSi8_h7NzZZ1vbR();
    psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR1;
    Q_ = Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR("opencensus-tag-context-key", psJpCSi8_h7NzZZ1vbR1);
  }
  
  public static wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR(Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    wktp1mvgWsB4SzZr wktp1mvgWsB4SzZr2 = (wktp1mvgWsB4SzZr)Q_.psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR);
    wktp1mvgWsB4SzZr wktp1mvgWsB4SzZr1 = wktp1mvgWsB4SzZr2;
    if (wktp1mvgWsB4SzZr2 == null)
      wktp1mvgWsB4SzZr1 = psJpCSi8_h7NzZZ1vbR; 
    return wktp1mvgWsB4SzZr1;
  }
  
  public static Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, @Nullable wktp1mvgWsB4SzZr paramwktp1mvgWsB4SzZr) {
    return ((Snla.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR)X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR, "context")).psJpCSi8_h7NzZZ1vbR(Q_, paramwktp1mvgWsB4SzZr);
  }
  
  private static final class psJpCSi8_h7NzZZ1vbR extends wktp1mvgWsB4SzZr {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    protected Iterator<wqn> psJpCSi8_h7NzZZ1vbR() {
      return Collections.<wqn>emptySet().iterator();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\Q_\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */