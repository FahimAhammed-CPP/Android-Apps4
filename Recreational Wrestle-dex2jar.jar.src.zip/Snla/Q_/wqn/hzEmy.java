package Snla.Q_.wqn;

import Snla.Q_.XV2I8z.D89UfNGBvLPp16h;
import Snla.Q_.XV2I8z.X9K8CXVSxZWf;

public abstract class hzEmy {
  public static final int psJpCSi8_h7NzZZ1vbR = 255;
  
  private static boolean Q_(String paramString) {
    return (paramString.length() <= 255 && D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(paramString));
  }
  
  public static hzEmy psJpCSi8_h7NzZZ1vbR(String paramString) {
    X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(Q_(paramString), "Invalid TagValue: %s", new Object[] { paramString });
    return new D89UfNGBvLPp16h(paramString);
  }
  
  public abstract String psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\hzEmy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */