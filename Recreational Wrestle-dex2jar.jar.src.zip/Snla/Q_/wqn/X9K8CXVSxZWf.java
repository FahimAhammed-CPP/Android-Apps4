package Snla.Q_.wqn;

import java.util.Iterator;

public final class X9K8CXVSxZWf {
  public static Iterator<wqn> psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr paramwktp1mvgWsB4SzZr) {
    return paramwktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\X9K8CXVSxZWf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */