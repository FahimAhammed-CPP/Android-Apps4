package Snla.Q_.wqn;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.hzEmy;

public abstract class BIRpv {
  private static final qY Q_;
  
  private static final qY psJpCSi8_h7NzZZ1vbR = qY.psJpCSi8_h7NzZZ1vbR(qY.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR);
  
  static {
    Q_ = qY.psJpCSi8_h7NzZZ1vbR(qY.psJpCSi8_h7NzZZ1vbR.Q_);
  }
  
  public abstract hzEmy Q_();
  
  public final BIRpv Q_(LEIMjJ paramLEIMjJ, hzEmy paramhzEmy) {
    return psJpCSi8_h7NzZZ1vbR(paramLEIMjJ, paramhzEmy, psJpCSi8_h7NzZZ1vbR);
  }
  
  public final BIRpv XV2I8z(LEIMjJ paramLEIMjJ, hzEmy paramhzEmy) {
    return psJpCSi8_h7NzZZ1vbR(paramLEIMjJ, paramhzEmy, Q_);
  }
  
  public abstract BIRpv psJpCSi8_h7NzZZ1vbR(LEIMjJ paramLEIMjJ);
  
  @Deprecated
  public abstract BIRpv psJpCSi8_h7NzZZ1vbR(LEIMjJ paramLEIMjJ, hzEmy paramhzEmy);
  
  public BIRpv psJpCSi8_h7NzZZ1vbR(LEIMjJ paramLEIMjJ, hzEmy paramhzEmy, qY paramqY) {
    return psJpCSi8_h7NzZZ1vbR(paramLEIMjJ, paramhzEmy);
  }
  
  public abstract wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\BIRpv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */