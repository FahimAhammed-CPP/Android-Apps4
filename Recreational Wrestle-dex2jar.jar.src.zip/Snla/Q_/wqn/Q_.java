package Snla.Q_.wqn;

import java.util.Objects;

final class Q_ extends LEIMjJ {
  private final String Q_;
  
  Q_(String paramString) {
    Objects.requireNonNull(paramString, "Null name");
    this.Q_ = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof LEIMjJ) {
      paramObject = paramObject;
      return this.Q_.equals(paramObject.psJpCSi8_h7NzZZ1vbR());
    } 
    return false;
  }
  
  public int hashCode() {
    return this.Q_.hashCode() ^ 0xF4243;
  }
  
  public String psJpCSi8_h7NzZZ1vbR() {
    return this.Q_;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TagKey{name=");
    stringBuilder.append(this.Q_);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */