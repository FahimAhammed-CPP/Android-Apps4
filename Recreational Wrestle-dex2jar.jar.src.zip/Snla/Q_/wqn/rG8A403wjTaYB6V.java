package Snla.Q_.wqn;

import Snla.Q_.psJpCSi8_h7NzZZ1vbR.hzEmy;

public abstract class rG8A403wjTaYB6V {
  public abstract BIRpv D89UfNGBvLPp16h();
  
  public abstract hzEmy Q_(wktp1mvgWsB4SzZr paramwktp1mvgWsB4SzZr);
  
  public abstract wktp1mvgWsB4SzZr Q_();
  
  public abstract BIRpv XV2I8z();
  
  public abstract BIRpv psJpCSi8_h7NzZZ1vbR(wktp1mvgWsB4SzZr paramwktp1mvgWsB4SzZr);
  
  public abstract wktp1mvgWsB4SzZr psJpCSi8_h7NzZZ1vbR();
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\Q_\wqn\rG8A403wjTaYB6V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */