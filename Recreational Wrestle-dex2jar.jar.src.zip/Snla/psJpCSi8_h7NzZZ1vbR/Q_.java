package Snla.psJpCSi8_h7NzZZ1vbR;

import java.util.Arrays;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public final class Q_ implements Comparable<Q_> {
  private static final long D89UfNGBvLPp16h;
  
  private static final long Q_;
  
  private static final long XV2I8z;
  
  private static final psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR = new psJpCSi8_h7NzZZ1vbR();
  
  private final long MxwALnHp3MNCI;
  
  private final Q_ X9K8CXVSxZWf;
  
  private volatile boolean wqn;
  
  static {
    long l = TimeUnit.DAYS.toNanos(36500L);
    Q_ = l;
    XV2I8z = -l;
    D89UfNGBvLPp16h = TimeUnit.SECONDS.toNanos(1L);
  }
  
  private Q_(Q_ paramQ_, long paramLong1, long paramLong2, boolean paramBoolean) {
    this.X9K8CXVSxZWf = paramQ_;
    paramLong2 = Math.min(Q_, Math.max(XV2I8z, paramLong2));
    this.MxwALnHp3MNCI = paramLong1 + paramLong2;
    if (paramBoolean && paramLong2 <= 0L) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.wqn = paramBoolean;
  }
  
  private Q_(Q_ paramQ_, long paramLong, boolean paramBoolean) {
    this(paramQ_, paramQ_.psJpCSi8_h7NzZZ1vbR(), paramLong, paramBoolean);
  }
  
  private void D89UfNGBvLPp16h(Q_ paramQ_) {
    if (this.X9K8CXVSxZWf == paramQ_.X9K8CXVSxZWf)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Tickers (");
    stringBuilder.append(this.X9K8CXVSxZWf);
    stringBuilder.append(" and ");
    stringBuilder.append(paramQ_.X9K8CXVSxZWf);
    stringBuilder.append(") don't match. Custom Ticker should only be used in tests!");
    throw new AssertionError(stringBuilder.toString());
  }
  
  public static Q_ psJpCSi8_h7NzZZ1vbR() {
    return psJpCSi8_h7NzZZ1vbR;
  }
  
  public static Q_ psJpCSi8_h7NzZZ1vbR(long paramLong, TimeUnit paramTimeUnit) {
    return psJpCSi8_h7NzZZ1vbR(paramLong, paramTimeUnit, psJpCSi8_h7NzZZ1vbR);
  }
  
  public static Q_ psJpCSi8_h7NzZZ1vbR(long paramLong, TimeUnit paramTimeUnit, Q_ paramQ_) {
    psJpCSi8_h7NzZZ1vbR(paramTimeUnit, "units");
    return new Q_(paramQ_, paramTimeUnit.toNanos(paramLong), true);
  }
  
  private static <T> T psJpCSi8_h7NzZZ1vbR(T paramT, Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(String.valueOf(paramObject));
  }
  
  public Q_ Q_(long paramLong, TimeUnit paramTimeUnit) {
    return (paramLong == 0L) ? this : new Q_(this.X9K8CXVSxZWf, this.MxwALnHp3MNCI, paramTimeUnit.toNanos(paramLong), Q_());
  }
  
  public Q_ Q_(Q_ paramQ_) {
    D89UfNGBvLPp16h(paramQ_);
    Q_ q_ = paramQ_;
    if (psJpCSi8_h7NzZZ1vbR(paramQ_))
      q_ = this; 
    return q_;
  }
  
  public boolean Q_() {
    if (!this.wqn) {
      if (this.MxwALnHp3MNCI - this.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR() <= 0L) {
        this.wqn = true;
        return true;
      } 
      return false;
    } 
    return true;
  }
  
  public int XV2I8z(Q_ paramQ_) {
    D89UfNGBvLPp16h(paramQ_);
    int i = this.MxwALnHp3MNCI - paramQ_.MxwALnHp3MNCI cmp 0L;
    return (i < 0) ? -1 : ((i > 0) ? 1 : 0);
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof Q_))
      return false; 
    paramObject = paramObject;
    Q_ q_ = this.X9K8CXVSxZWf;
    if (q_ == null) {
      if (((Q_)paramObject).X9K8CXVSxZWf != null)
        return false; 
    } else if (q_ != ((Q_)paramObject).X9K8CXVSxZWf) {
      return false;
    } 
    return !(this.MxwALnHp3MNCI != ((Q_)paramObject).MxwALnHp3MNCI);
  }
  
  public int hashCode() {
    return Arrays.<Object>asList(new Object[] { this.X9K8CXVSxZWf, Long.valueOf(this.MxwALnHp3MNCI) }).hashCode();
  }
  
  public long psJpCSi8_h7NzZZ1vbR(TimeUnit paramTimeUnit) {
    long l = this.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR();
    if (!this.wqn && this.MxwALnHp3MNCI - l <= 0L)
      this.wqn = true; 
    return paramTimeUnit.convert(this.MxwALnHp3MNCI - l, TimeUnit.NANOSECONDS);
  }
  
  public ScheduledFuture<?> psJpCSi8_h7NzZZ1vbR(Runnable paramRunnable, ScheduledExecutorService paramScheduledExecutorService) {
    psJpCSi8_h7NzZZ1vbR(paramRunnable, "task");
    psJpCSi8_h7NzZZ1vbR(paramScheduledExecutorService, "scheduler");
    return paramScheduledExecutorService.schedule(paramRunnable, this.MxwALnHp3MNCI - this.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(), TimeUnit.NANOSECONDS);
  }
  
  public boolean psJpCSi8_h7NzZZ1vbR(Q_ paramQ_) {
    D89UfNGBvLPp16h(paramQ_);
    return (this.MxwALnHp3MNCI - paramQ_.MxwALnHp3MNCI < 0L);
  }
  
  public String toString() {
    long l1 = psJpCSi8_h7NzZZ1vbR(TimeUnit.NANOSECONDS);
    long l3 = Math.abs(l1);
    long l2 = D89UfNGBvLPp16h;
    l3 /= l2;
    l2 = Math.abs(l1) % l2;
    StringBuilder stringBuilder = new StringBuilder();
    if (l1 < 0L)
      stringBuilder.append('-'); 
    stringBuilder.append(l3);
    if (l2 > 0L)
      stringBuilder.append(String.format(".%09d", new Object[] { Long.valueOf(l2) })); 
    stringBuilder.append("s from now");
    if (this.X9K8CXVSxZWf != psJpCSi8_h7NzZZ1vbR) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" (ticker=");
      stringBuilder1.append(this.X9K8CXVSxZWf);
      stringBuilder1.append(")");
      stringBuilder.append(stringBuilder1.toString());
    } 
    return stringBuilder.toString();
  }
  
  public static abstract class Q_ {
    public abstract long psJpCSi8_h7NzZZ1vbR();
  }
  
  private static class psJpCSi8_h7NzZZ1vbR extends Q_ {
    private psJpCSi8_h7NzZZ1vbR() {}
    
    public long psJpCSi8_h7NzZZ1vbR() {
      return System.nanoTime();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\psJpCSi8_h7NzZZ1vbR\Q_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */