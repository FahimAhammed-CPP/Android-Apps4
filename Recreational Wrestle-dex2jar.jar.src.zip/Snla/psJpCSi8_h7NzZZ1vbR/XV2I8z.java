package Snla.psJpCSi8_h7NzZZ1vbR;

import java.util.Arrays;

final class XV2I8z<K, V> {
  private final D89UfNGBvLPp16h<K, V> psJpCSi8_h7NzZZ1vbR;
  
  XV2I8z() {
    this(null);
  }
  
  private XV2I8z(D89UfNGBvLPp16h<K, V> paramD89UfNGBvLPp16h) {
    this.psJpCSi8_h7NzZZ1vbR = paramD89UfNGBvLPp16h;
  }
  
  public int psJpCSi8_h7NzZZ1vbR() {
    D89UfNGBvLPp16h<K, V> d89UfNGBvLPp16h = this.psJpCSi8_h7NzZZ1vbR;
    return (d89UfNGBvLPp16h == null) ? 0 : d89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR();
  }
  
  public XV2I8z<K, V> psJpCSi8_h7NzZZ1vbR(K paramK, V paramV) {
    D89UfNGBvLPp16h<K, V> d89UfNGBvLPp16h = this.psJpCSi8_h7NzZZ1vbR;
    return (d89UfNGBvLPp16h == null) ? new XV2I8z(new XV2I8z<K, V>(paramK, paramV)) : new XV2I8z(d89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(paramK, paramV, paramK.hashCode(), 0));
  }
  
  public V psJpCSi8_h7NzZZ1vbR(K paramK) {
    D89UfNGBvLPp16h<K, V> d89UfNGBvLPp16h = this.psJpCSi8_h7NzZZ1vbR;
    return (d89UfNGBvLPp16h == null) ? null : d89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(paramK, paramK.hashCode(), 0);
  }
  
  static interface D89UfNGBvLPp16h<K, V> {
    int psJpCSi8_h7NzZZ1vbR();
    
    D89UfNGBvLPp16h<K, V> psJpCSi8_h7NzZZ1vbR(K param1K, V param1V, int param1Int1, int param1Int2);
    
    V psJpCSi8_h7NzZZ1vbR(K param1K, int param1Int1, int param1Int2);
  }
  
  static final class Q_<K, V> implements D89UfNGBvLPp16h<K, V> {
    private static final int D89UfNGBvLPp16h = 5;
    
    private static final int X9K8CXVSxZWf = 31;
    
    private final int MxwALnHp3MNCI;
    
    final XV2I8z.D89UfNGBvLPp16h<K, V>[] Q_;
    
    final int psJpCSi8_h7NzZZ1vbR;
    
    private Q_(int param1Int1, XV2I8z.D89UfNGBvLPp16h<K, V>[] param1ArrayOfD89UfNGBvLPp16h, int param1Int2) {
      this.psJpCSi8_h7NzZZ1vbR = param1Int1;
      this.Q_ = param1ArrayOfD89UfNGBvLPp16h;
      this.MxwALnHp3MNCI = param1Int2;
    }
    
    private static int Q_(int param1Int1, int param1Int2) {
      return 1 << psJpCSi8_h7NzZZ1vbR(param1Int1, param1Int2);
    }
    
    private int psJpCSi8_h7NzZZ1vbR(int param1Int) {
      return Integer.bitCount(param1Int - 1 & this.psJpCSi8_h7NzZZ1vbR);
    }
    
    private static int psJpCSi8_h7NzZZ1vbR(int param1Int1, int param1Int2) {
      return param1Int1 >>> param1Int2 & 0x1F;
    }
    
    static <K, V> XV2I8z.D89UfNGBvLPp16h<K, V> psJpCSi8_h7NzZZ1vbR(XV2I8z.D89UfNGBvLPp16h<K, V> param1D89UfNGBvLPp16h1, int param1Int1, XV2I8z.D89UfNGBvLPp16h<K, V> param1D89UfNGBvLPp16h2, int param1Int2, int param1Int3) {
      if (XV2I8z || param1Int1 != param1Int2) {
        int i = Q_(param1Int1, param1Int3);
        int j = Q_(param1Int2, param1Int3);
        if (i == j) {
          param1D89UfNGBvLPp16h1 = psJpCSi8_h7NzZZ1vbR(param1D89UfNGBvLPp16h1, param1Int1, param1D89UfNGBvLPp16h2, param1Int2, param1Int3 + 5);
          param1Int1 = param1D89UfNGBvLPp16h1.psJpCSi8_h7NzZZ1vbR();
          return new Q_<K, V>(i, (XV2I8z.D89UfNGBvLPp16h<K, V>[])new XV2I8z.D89UfNGBvLPp16h[] { param1D89UfNGBvLPp16h1 }, param1Int1);
        } 
        XV2I8z.D89UfNGBvLPp16h<K, V> d89UfNGBvLPp16h2 = param1D89UfNGBvLPp16h1;
        XV2I8z.D89UfNGBvLPp16h<K, V> d89UfNGBvLPp16h1 = param1D89UfNGBvLPp16h2;
        if (psJpCSi8_h7NzZZ1vbR(param1Int1, param1Int3) > psJpCSi8_h7NzZZ1vbR(param1Int2, param1Int3)) {
          d89UfNGBvLPp16h1 = param1D89UfNGBvLPp16h1;
          d89UfNGBvLPp16h2 = param1D89UfNGBvLPp16h2;
        } 
        param1Int1 = d89UfNGBvLPp16h2.psJpCSi8_h7NzZZ1vbR();
        param1Int2 = d89UfNGBvLPp16h1.psJpCSi8_h7NzZZ1vbR();
        return new Q_<K, V>(i | j, (XV2I8z.D89UfNGBvLPp16h<K, V>[])new XV2I8z.D89UfNGBvLPp16h[] { d89UfNGBvLPp16h2, d89UfNGBvLPp16h1 }, param1Int1 + param1Int2);
      } 
      throw new AssertionError();
    }
    
    public int psJpCSi8_h7NzZZ1vbR() {
      return this.MxwALnHp3MNCI;
    }
    
    public XV2I8z.D89UfNGBvLPp16h<K, V> psJpCSi8_h7NzZZ1vbR(K param1K, V param1V, int param1Int1, int param1Int2) {
      XV2I8z.D89UfNGBvLPp16h<K, V>[] arrayOfD89UfNGBvLPp16h1;
      int j = Q_(param1Int1, param1Int2);
      int i = psJpCSi8_h7NzZZ1vbR(j);
      int k = this.psJpCSi8_h7NzZZ1vbR;
      if ((k & j) == 0) {
        XV2I8z.D89UfNGBvLPp16h<K, V>[] arrayOfD89UfNGBvLPp16h4 = this.Q_;
        XV2I8z.D89UfNGBvLPp16h[] arrayOfD89UfNGBvLPp16h3 = new XV2I8z.D89UfNGBvLPp16h[arrayOfD89UfNGBvLPp16h4.length + 1];
        System.arraycopy(arrayOfD89UfNGBvLPp16h4, 0, arrayOfD89UfNGBvLPp16h3, 0, i);
        arrayOfD89UfNGBvLPp16h3[i] = new XV2I8z.XV2I8z<K, V>(param1K, param1V);
        arrayOfD89UfNGBvLPp16h1 = this.Q_;
        System.arraycopy(arrayOfD89UfNGBvLPp16h1, i, arrayOfD89UfNGBvLPp16h3, i + 1, arrayOfD89UfNGBvLPp16h1.length - i);
        return new Q_(k | j, (XV2I8z.D89UfNGBvLPp16h<K, V>[])arrayOfD89UfNGBvLPp16h3, psJpCSi8_h7NzZZ1vbR() + 1);
      } 
      XV2I8z.D89UfNGBvLPp16h<K, V>[] arrayOfD89UfNGBvLPp16h2 = this.Q_;
      XV2I8z.D89UfNGBvLPp16h[] arrayOfD89UfNGBvLPp16h = Arrays.<XV2I8z.D89UfNGBvLPp16h>copyOf((XV2I8z.D89UfNGBvLPp16h[])arrayOfD89UfNGBvLPp16h2, arrayOfD89UfNGBvLPp16h2.length);
      arrayOfD89UfNGBvLPp16h[i] = this.Q_[i].psJpCSi8_h7NzZZ1vbR((K)arrayOfD89UfNGBvLPp16h1, param1V, param1Int1, param1Int2 + 5);
      param1Int1 = psJpCSi8_h7NzZZ1vbR();
      param1Int2 = arrayOfD89UfNGBvLPp16h[i].psJpCSi8_h7NzZZ1vbR();
      i = this.Q_[i].psJpCSi8_h7NzZZ1vbR();
      return new Q_(this.psJpCSi8_h7NzZZ1vbR, (XV2I8z.D89UfNGBvLPp16h<K, V>[])arrayOfD89UfNGBvLPp16h, param1Int1 + param1Int2 - i);
    }
    
    public V psJpCSi8_h7NzZZ1vbR(K param1K, int param1Int1, int param1Int2) {
      int i = Q_(param1Int1, param1Int2);
      if ((this.psJpCSi8_h7NzZZ1vbR & i) == 0)
        return null; 
      i = psJpCSi8_h7NzZZ1vbR(i);
      return this.Q_[i].psJpCSi8_h7NzZZ1vbR(param1K, param1Int1, param1Int2 + 5);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("CompressedIndex(");
      String str = Integer.toBinaryString(this.psJpCSi8_h7NzZZ1vbR);
      int i = 0;
      stringBuilder.append(String.format("bitmap=%s ", new Object[] { str }));
      XV2I8z.D89UfNGBvLPp16h<K, V>[] arrayOfD89UfNGBvLPp16h = this.Q_;
      int j = arrayOfD89UfNGBvLPp16h.length;
      while (i < j) {
        stringBuilder.append(arrayOfD89UfNGBvLPp16h[i]);
        stringBuilder.append(" ");
        i++;
      } 
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  static final class XV2I8z<K, V> implements D89UfNGBvLPp16h<K, V> {
    private final V Q_;
    
    private final K psJpCSi8_h7NzZZ1vbR;
    
    public XV2I8z(K param1K, V param1V) {
      this.psJpCSi8_h7NzZZ1vbR = param1K;
      this.Q_ = param1V;
    }
    
    public int psJpCSi8_h7NzZZ1vbR() {
      return 1;
    }
    
    public XV2I8z.D89UfNGBvLPp16h<K, V> psJpCSi8_h7NzZZ1vbR(K param1K, V param1V, int param1Int1, int param1Int2) {
      int i = this.psJpCSi8_h7NzZZ1vbR.hashCode();
      return (XV2I8z.D89UfNGBvLPp16h<K, V>)((i != param1Int1) ? XV2I8z.Q_.psJpCSi8_h7NzZZ1vbR(new XV2I8z(param1K, param1V), param1Int1, this, i, param1Int2) : ((this.psJpCSi8_h7NzZZ1vbR == param1K) ? new XV2I8z(param1K, param1V) : new XV2I8z.psJpCSi8_h7NzZZ1vbR<K, V>(this.psJpCSi8_h7NzZZ1vbR, this.Q_, param1K, param1V)));
    }
    
    public V psJpCSi8_h7NzZZ1vbR(K param1K, int param1Int1, int param1Int2) {
      return (this.psJpCSi8_h7NzZZ1vbR == param1K) ? this.Q_ : null;
    }
    
    public String toString() {
      return String.format("Leaf(key=%s value=%s)", new Object[] { this.psJpCSi8_h7NzZZ1vbR, this.Q_ });
    }
  }
  
  static final class psJpCSi8_h7NzZZ1vbR<K, V> implements D89UfNGBvLPp16h<K, V> {
    private final K[] Q_;
    
    private final V[] XV2I8z;
    
    psJpCSi8_h7NzZZ1vbR(K param1K1, V param1V1, K param1K2, V param1V2) {
      this((K[])new Object[] { param1K1, param1K2 }, (V[])new Object[] { param1V1, param1V2 });
      boolean bool = psJpCSi8_h7NzZZ1vbR;
      if (bool || param1K1 != param1K2) {
        if (!bool) {
          if (param1K1.hashCode() == param1K2.hashCode())
            return; 
          throw new AssertionError();
        } 
        return;
      } 
      throw new AssertionError();
    }
    
    private psJpCSi8_h7NzZZ1vbR(K[] param1ArrayOfK, V[] param1ArrayOfV) {
      this.Q_ = param1ArrayOfK;
      this.XV2I8z = param1ArrayOfV;
    }
    
    private int psJpCSi8_h7NzZZ1vbR(K param1K) {
      int i = 0;
      while (true) {
        K[] arrayOfK = this.Q_;
        if (i < arrayOfK.length) {
          if (arrayOfK[i] == param1K)
            return i; 
          i++;
          continue;
        } 
        return -1;
      } 
    }
    
    public int psJpCSi8_h7NzZZ1vbR() {
      return this.XV2I8z.length;
    }
    
    public XV2I8z.D89UfNGBvLPp16h<K, V> psJpCSi8_h7NzZZ1vbR(K param1K, V param1V, int param1Int1, int param1Int2) {
      int i = this.Q_[0].hashCode();
      if (i != param1Int1)
        return XV2I8z.Q_.psJpCSi8_h7NzZZ1vbR(new XV2I8z.XV2I8z<K, V>(param1K, param1V), param1Int1, this, i, param1Int2); 
      param1Int1 = psJpCSi8_h7NzZZ1vbR(param1K);
      if (param1Int1 != -1) {
        K[] arrayOfK = this.Q_;
        arrayOfK = Arrays.copyOf(arrayOfK, arrayOfK.length);
        Object[] arrayOfObject1 = Arrays.copyOf((Object[])this.XV2I8z, this.Q_.length);
        arrayOfK[param1Int1] = param1K;
        arrayOfObject1[param1Int1] = param1V;
        return new psJpCSi8_h7NzZZ1vbR(arrayOfK, (V[])arrayOfObject1);
      } 
      K[] arrayOfK1 = this.Q_;
      arrayOfK1 = Arrays.copyOf(arrayOfK1, arrayOfK1.length + 1);
      Object[] arrayOfObject = Arrays.copyOf((Object[])this.XV2I8z, this.Q_.length + 1);
      K[] arrayOfK2 = this.Q_;
      arrayOfK1[arrayOfK2.length] = param1K;
      arrayOfObject[arrayOfK2.length] = param1V;
      return new psJpCSi8_h7NzZZ1vbR(arrayOfK1, (V[])arrayOfObject);
    }
    
    public V psJpCSi8_h7NzZZ1vbR(K param1K, int param1Int1, int param1Int2) {
      param1Int1 = 0;
      while (true) {
        K[] arrayOfK = this.Q_;
        if (param1Int1 < arrayOfK.length) {
          if (arrayOfK[param1Int1] == param1K)
            return this.XV2I8z[param1Int1]; 
          param1Int1++;
          continue;
        } 
        return null;
      } 
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("CollisionLeaf(");
      for (int i = 0; i < this.XV2I8z.length; i++) {
        stringBuilder.append("(key=");
        stringBuilder.append(this.Q_[i]);
        stringBuilder.append(" value=");
        stringBuilder.append(this.XV2I8z[i]);
        stringBuilder.append(") ");
      } 
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\psJpCSi8_h7NzZZ1vbR\XV2I8z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */