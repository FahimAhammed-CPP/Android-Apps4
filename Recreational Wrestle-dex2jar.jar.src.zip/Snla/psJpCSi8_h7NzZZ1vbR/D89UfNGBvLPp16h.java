package Snla.psJpCSi8_h7NzZZ1vbR;

import java.util.logging.Level;
import java.util.logging.Logger;

final class D89UfNGBvLPp16h extends psJpCSi8_h7NzZZ1vbR.hzEmy {
  private static final Logger Q_ = Logger.getLogger(D89UfNGBvLPp16h.class.getName());
  
  static final ThreadLocal<psJpCSi8_h7NzZZ1vbR> psJpCSi8_h7NzZZ1vbR = new ThreadLocal<psJpCSi8_h7NzZZ1vbR>();
  
  public psJpCSi8_h7NzZZ1vbR Q_(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = psJpCSi8_h7NzZZ1vbR();
    psJpCSi8_h7NzZZ1vbR.set(parampsJpCSi8_h7NzZZ1vbR);
    return psJpCSi8_h7NzZZ1vbR1;
  }
  
  public psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR() {
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR2 = psJpCSi8_h7NzZZ1vbR.get();
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = psJpCSi8_h7NzZZ1vbR2;
    if (psJpCSi8_h7NzZZ1vbR2 == null)
      psJpCSi8_h7NzZZ1vbR1 = psJpCSi8_h7NzZZ1vbR.XV2I8z; 
    return psJpCSi8_h7NzZZ1vbR1;
  }
  
  public void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR1, psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR2) {
    if (psJpCSi8_h7NzZZ1vbR() != parampsJpCSi8_h7NzZZ1vbR1)
      Q_.log(Level.SEVERE, "Context was not attached when detaching", (new Throwable()).fillInStackTrace()); 
    if (parampsJpCSi8_h7NzZZ1vbR2 != psJpCSi8_h7NzZZ1vbR.XV2I8z) {
      psJpCSi8_h7NzZZ1vbR.set(parampsJpCSi8_h7NzZZ1vbR2);
      return;
    } 
    psJpCSi8_h7NzZZ1vbR.set(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\psJpCSi8_h7NzZZ1vbR\D89UfNGBvLPp16h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */