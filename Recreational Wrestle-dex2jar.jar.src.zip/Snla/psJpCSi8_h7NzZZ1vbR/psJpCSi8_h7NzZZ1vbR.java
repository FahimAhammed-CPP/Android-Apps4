package Snla.psJpCSi8_h7NzZZ1vbR;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.logging.Logger;

public class psJpCSi8_h7NzZZ1vbR {
  static final int Q_ = 1000;
  
  public static final psJpCSi8_h7NzZZ1vbR XV2I8z;
  
  static final Logger psJpCSi8_h7NzZZ1vbR = Logger.getLogger(psJpCSi8_h7NzZZ1vbR.class.getName());
  
  private static final XV2I8z<BIRpv<?>, Object> wqn;
  
  private X9K8CXVSxZWf BIRpv;
  
  final D89UfNGBvLPp16h D89UfNGBvLPp16h;
  
  final int MxwALnHp3MNCI;
  
  final XV2I8z<BIRpv<?>, Object> X9K8CXVSxZWf;
  
  private ArrayList<wktp1mvgWsB4SzZr> wktp1mvgWsB4SzZr;
  
  static {
    XV2I8z<Object, Object> xV2I8z = new XV2I8z<Object, Object>();
    wqn = (XV2I8z)xV2I8z;
    XV2I8z = new psJpCSi8_h7NzZZ1vbR(null, (XV2I8z)xV2I8z);
  }
  
  private psJpCSi8_h7NzZZ1vbR(XV2I8z<BIRpv<?>, Object> paramXV2I8z, int paramInt) {
    this.BIRpv = new qY();
    this.D89UfNGBvLPp16h = null;
    this.X9K8CXVSxZWf = paramXV2I8z;
    this.MxwALnHp3MNCI = paramInt;
    psJpCSi8_h7NzZZ1vbR(paramInt);
  }
  
  private psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR, XV2I8z<BIRpv<?>, Object> paramXV2I8z) {
    int i;
    this.BIRpv = new qY();
    this.D89UfNGBvLPp16h = Q_(parampsJpCSi8_h7NzZZ1vbR);
    this.X9K8CXVSxZWf = paramXV2I8z;
    if (parampsJpCSi8_h7NzZZ1vbR == null) {
      i = 0;
    } else {
      i = parampsJpCSi8_h7NzZZ1vbR.MxwALnHp3MNCI + 1;
    } 
    this.MxwALnHp3MNCI = i;
    psJpCSi8_h7NzZZ1vbR(i);
  }
  
  static D89UfNGBvLPp16h Q_(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    return (parampsJpCSi8_h7NzZZ1vbR == null) ? null : ((parampsJpCSi8_h7NzZZ1vbR instanceof D89UfNGBvLPp16h) ? (D89UfNGBvLPp16h)parampsJpCSi8_h7NzZZ1vbR : parampsJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h);
  }
  
  public static psJpCSi8_h7NzZZ1vbR Q_() {
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR2 = psJpCSi8_h7NzZZ1vbR().psJpCSi8_h7NzZZ1vbR();
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = psJpCSi8_h7NzZZ1vbR2;
    if (psJpCSi8_h7NzZZ1vbR2 == null)
      psJpCSi8_h7NzZZ1vbR1 = XV2I8z; 
    return psJpCSi8_h7NzZZ1vbR1;
  }
  
  public static Executor Q_(Executor paramExecutor) {
    return new psJpCSi8_h7NzZZ1vbR(paramExecutor);
  }
  
  public static <T> BIRpv<T> psJpCSi8_h7NzZZ1vbR(String paramString) {
    return new BIRpv<T>(paramString);
  }
  
  public static <T> BIRpv<T> psJpCSi8_h7NzZZ1vbR(String paramString, T paramT) {
    return new BIRpv<T>(paramString, paramT);
  }
  
  static hzEmy psJpCSi8_h7NzZZ1vbR() {
    return LEIMjJ.psJpCSi8_h7NzZZ1vbR;
  }
  
  static <T> T psJpCSi8_h7NzZZ1vbR(T paramT, Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(String.valueOf(paramObject));
  }
  
  private static void psJpCSi8_h7NzZZ1vbR(int paramInt) {
    if (paramInt == 1000)
      psJpCSi8_h7NzZZ1vbR.log(Level.SEVERE, "Context ancestry chain length is abnormally long. This suggests an error in application code. Length exceeded: 1000", new Exception()); 
  }
  
  public Throwable BIRpv() {
    D89UfNGBvLPp16h d89UfNGBvLPp16h = this.D89UfNGBvLPp16h;
    return (d89UfNGBvLPp16h == null) ? null : d89UfNGBvLPp16h.BIRpv();
  }
  
  public psJpCSi8_h7NzZZ1vbR D89UfNGBvLPp16h() {
    return new psJpCSi8_h7NzZZ1vbR(this.X9K8CXVSxZWf, this.MxwALnHp3MNCI + 1);
  }
  
  public Q_ LEIMjJ() {
    D89UfNGBvLPp16h d89UfNGBvLPp16h = this.D89UfNGBvLPp16h;
    return (d89UfNGBvLPp16h == null) ? null : d89UfNGBvLPp16h.LEIMjJ();
  }
  
  public psJpCSi8_h7NzZZ1vbR MxwALnHp3MNCI() {
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR2 = psJpCSi8_h7NzZZ1vbR().Q_(this);
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = psJpCSi8_h7NzZZ1vbR2;
    if (psJpCSi8_h7NzZZ1vbR2 == null)
      psJpCSi8_h7NzZZ1vbR1 = XV2I8z; 
    return psJpCSi8_h7NzZZ1vbR1;
  }
  
  public Runnable Q_(Runnable paramRunnable) {
    return new Runnable(this, paramRunnable) {
        public void run() {
          psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = this.Q_.MxwALnHp3MNCI();
          try {
            this.psJpCSi8_h7NzZZ1vbR.run();
            return;
          } finally {
            this.Q_.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR1);
          } 
        }
      };
  }
  
  public <C> Callable<C> Q_(Callable<C> paramCallable) {
    return new Callable<C>(this, paramCallable) {
        public C call() throws Exception {
          psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = this.Q_.MxwALnHp3MNCI();
          try {
            return (C)this.psJpCSi8_h7NzZZ1vbR.call();
          } finally {
            this.Q_.psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR1);
          } 
        }
      };
  }
  
  boolean X9K8CXVSxZWf() {
    return (this.D89UfNGBvLPp16h != null);
  }
  
  public D89UfNGBvLPp16h XV2I8z() {
    return new D89UfNGBvLPp16h(this);
  }
  
  int hzEmy() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnonnull -> 16
    //   11: iconst_0
    //   12: istore_1
    //   13: goto -> 21
    //   16: aload_2
    //   17: invokevirtual size : ()I
    //   20: istore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: iload_1
    //   24: ireturn
    //   25: astore_2
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_2
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	25	finally
    //   16	21	25	finally
    //   21	23	25	finally
    //   26	28	25	finally
  }
  
  public D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR(long paramLong, TimeUnit paramTimeUnit, ScheduledExecutorService paramScheduledExecutorService) {
    return psJpCSi8_h7NzZZ1vbR(Q_.psJpCSi8_h7NzZZ1vbR(paramLong, paramTimeUnit), paramScheduledExecutorService);
  }
  
  public D89UfNGBvLPp16h psJpCSi8_h7NzZZ1vbR(Q_ paramQ_, ScheduledExecutorService paramScheduledExecutorService) {
    boolean bool;
    psJpCSi8_h7NzZZ1vbR(paramQ_, "deadline");
    psJpCSi8_h7NzZZ1vbR(paramScheduledExecutorService, "scheduler");
    Q_ q_ = LEIMjJ();
    if (q_ != null && q_.XV2I8z(paramQ_) <= 0) {
      bool = false;
      paramQ_ = q_;
    } else {
      bool = true;
    } 
    D89UfNGBvLPp16h d89UfNGBvLPp16h = new D89UfNGBvLPp16h(this, paramQ_);
    if (bool)
      D89UfNGBvLPp16h.psJpCSi8_h7NzZZ1vbR(d89UfNGBvLPp16h, paramQ_, paramScheduledExecutorService); 
    return d89UfNGBvLPp16h;
  }
  
  public <V> psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(BIRpv<V> paramBIRpv, V paramV) {
    return new psJpCSi8_h7NzZZ1vbR(this, this.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramBIRpv, paramV));
  }
  
  public <V1, V2> psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(BIRpv<V1> paramBIRpv, V1 paramV1, BIRpv<V2> paramBIRpv1, V2 paramV2) {
    return new psJpCSi8_h7NzZZ1vbR(this, this.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramBIRpv, paramV1).psJpCSi8_h7NzZZ1vbR(paramBIRpv1, paramV2));
  }
  
  public <V1, V2, V3> psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(BIRpv<V1> paramBIRpv, V1 paramV1, BIRpv<V2> paramBIRpv1, V2 paramV2, BIRpv<V3> paramBIRpv2, V3 paramV3) {
    return new psJpCSi8_h7NzZZ1vbR(this, this.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramBIRpv, paramV1).psJpCSi8_h7NzZZ1vbR(paramBIRpv1, paramV2).psJpCSi8_h7NzZZ1vbR(paramBIRpv2, paramV3));
  }
  
  public <V1, V2, V3, V4> psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR(BIRpv<V1> paramBIRpv, V1 paramV1, BIRpv<V2> paramBIRpv1, V2 paramV2, BIRpv<V3> paramBIRpv2, V3 paramV3, BIRpv<V4> paramBIRpv3, V4 paramV4) {
    return new psJpCSi8_h7NzZZ1vbR(this, this.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramBIRpv, paramV1).psJpCSi8_h7NzZZ1vbR(paramBIRpv1, paramV2).psJpCSi8_h7NzZZ1vbR(paramBIRpv2, paramV3).psJpCSi8_h7NzZZ1vbR(paramBIRpv3, paramV4));
  }
  
  Object psJpCSi8_h7NzZZ1vbR(BIRpv<?> paramBIRpv) {
    return this.X9K8CXVSxZWf.psJpCSi8_h7NzZZ1vbR(paramBIRpv);
  }
  
  public <V> V psJpCSi8_h7NzZZ1vbR(Callable<V> paramCallable) throws Exception {
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = MxwALnHp3MNCI();
    try {
      paramCallable = (Callable<V>)paramCallable.call();
      return (V)paramCallable;
    } finally {
      psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR1);
    } 
  }
  
  public Executor psJpCSi8_h7NzZZ1vbR(Executor paramExecutor) {
    return new Q_(this, paramExecutor);
  }
  
  public void psJpCSi8_h7NzZZ1vbR(X9K8CXVSxZWf paramX9K8CXVSxZWf) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual X9K8CXVSxZWf : ()Z
    //   4: ifne -> 8
    //   7: return
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   14: astore_3
    //   15: aload_3
    //   16: ifnull -> 92
    //   19: aload_3
    //   20: invokevirtual size : ()I
    //   23: iconst_1
    //   24: isub
    //   25: istore_2
    //   26: iload_2
    //   27: iflt -> 60
    //   30: aload_0
    //   31: getfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   34: iload_2
    //   35: invokevirtual get : (I)Ljava/lang/Object;
    //   38: checkcast Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$wktp1mvgWsB4SzZr
    //   41: getfield psJpCSi8_h7NzZZ1vbR : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;
    //   44: aload_1
    //   45: if_acmpne -> 100
    //   48: aload_0
    //   49: getfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   52: iload_2
    //   53: invokevirtual remove : (I)Ljava/lang/Object;
    //   56: pop
    //   57: goto -> 60
    //   60: aload_0
    //   61: getfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   64: invokevirtual isEmpty : ()Z
    //   67: ifeq -> 92
    //   70: aload_0
    //   71: getfield D89UfNGBvLPp16h : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$D89UfNGBvLPp16h;
    //   74: astore_1
    //   75: aload_1
    //   76: ifnull -> 87
    //   79: aload_1
    //   80: aload_0
    //   81: getfield BIRpv : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;
    //   84: invokevirtual psJpCSi8_h7NzZZ1vbR : (LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;)V
    //   87: aload_0
    //   88: aconst_null
    //   89: putfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   92: aload_0
    //   93: monitorexit
    //   94: return
    //   95: astore_1
    //   96: aload_0
    //   97: monitorexit
    //   98: aload_1
    //   99: athrow
    //   100: iload_2
    //   101: iconst_1
    //   102: isub
    //   103: istore_2
    //   104: goto -> 26
    // Exception table:
    //   from	to	target	type
    //   10	15	95	finally
    //   19	26	95	finally
    //   30	57	95	finally
    //   60	75	95	finally
    //   79	87	95	finally
    //   87	92	95	finally
    //   92	94	95	finally
    //   96	98	95	finally
  }
  
  public void psJpCSi8_h7NzZZ1vbR(X9K8CXVSxZWf paramX9K8CXVSxZWf, Executor paramExecutor) {
    // Byte code:
    //   0: aload_1
    //   1: ldc_w 'cancellationListener'
    //   4: invokestatic psJpCSi8_h7NzZZ1vbR : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   7: pop
    //   8: aload_2
    //   9: ldc_w 'executor'
    //   12: invokestatic psJpCSi8_h7NzZZ1vbR : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   15: pop
    //   16: aload_0
    //   17: invokevirtual X9K8CXVSxZWf : ()Z
    //   20: ifeq -> 115
    //   23: new Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$wktp1mvgWsB4SzZr
    //   26: dup
    //   27: aload_0
    //   28: aload_2
    //   29: aload_1
    //   30: invokespecial <init> : (LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR;Ljava/util/concurrent/Executor;LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;)V
    //   33: astore_1
    //   34: aload_0
    //   35: monitorenter
    //   36: aload_0
    //   37: invokevirtual wktp1mvgWsB4SzZr : ()Z
    //   40: ifeq -> 50
    //   43: aload_1
    //   44: invokevirtual psJpCSi8_h7NzZZ1vbR : ()V
    //   47: goto -> 107
    //   50: aload_0
    //   51: getfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   54: astore_2
    //   55: aload_2
    //   56: ifnonnull -> 101
    //   59: new java/util/ArrayList
    //   62: dup
    //   63: invokespecial <init> : ()V
    //   66: astore_2
    //   67: aload_0
    //   68: aload_2
    //   69: putfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   72: aload_2
    //   73: aload_1
    //   74: invokevirtual add : (Ljava/lang/Object;)Z
    //   77: pop
    //   78: aload_0
    //   79: getfield D89UfNGBvLPp16h : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$D89UfNGBvLPp16h;
    //   82: astore_1
    //   83: aload_1
    //   84: ifnull -> 107
    //   87: aload_1
    //   88: aload_0
    //   89: getfield BIRpv : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;
    //   92: getstatic Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$wqn.psJpCSi8_h7NzZZ1vbR : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$wqn;
    //   95: invokevirtual psJpCSi8_h7NzZZ1vbR : (LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;Ljava/util/concurrent/Executor;)V
    //   98: goto -> 107
    //   101: aload_2
    //   102: aload_1
    //   103: invokevirtual add : (Ljava/lang/Object;)Z
    //   106: pop
    //   107: aload_0
    //   108: monitorexit
    //   109: return
    //   110: astore_1
    //   111: aload_0
    //   112: monitorexit
    //   113: aload_1
    //   114: athrow
    //   115: return
    // Exception table:
    //   from	to	target	type
    //   36	47	110	finally
    //   50	55	110	finally
    //   59	83	110	finally
    //   87	98	110	finally
    //   101	107	110	finally
    //   107	109	110	finally
    //   111	113	110	finally
  }
  
  public void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR parampsJpCSi8_h7NzZZ1vbR) {
    psJpCSi8_h7NzZZ1vbR(parampsJpCSi8_h7NzZZ1vbR, "toAttach");
    psJpCSi8_h7NzZZ1vbR().psJpCSi8_h7NzZZ1vbR(this, parampsJpCSi8_h7NzZZ1vbR);
  }
  
  public void psJpCSi8_h7NzZZ1vbR(Runnable paramRunnable) {
    psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = MxwALnHp3MNCI();
    try {
      paramRunnable.run();
      return;
    } finally {
      psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR1);
    } 
  }
  
  void qY() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual X9K8CXVSxZWf : ()Z
    //   4: ifne -> 8
    //   7: return
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   14: astore #4
    //   16: aload #4
    //   18: ifnonnull -> 24
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: aload_0
    //   25: aconst_null
    //   26: putfield wktp1mvgWsB4SzZr : Ljava/util/ArrayList;
    //   29: aload_0
    //   30: monitorexit
    //   31: iconst_0
    //   32: istore_3
    //   33: iconst_0
    //   34: istore_1
    //   35: iload_3
    //   36: istore_2
    //   37: iload_1
    //   38: aload #4
    //   40: invokevirtual size : ()I
    //   43: if_icmpge -> 83
    //   46: aload #4
    //   48: iload_1
    //   49: invokevirtual get : (I)Ljava/lang/Object;
    //   52: checkcast Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$wktp1mvgWsB4SzZr
    //   55: getfield psJpCSi8_h7NzZZ1vbR : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;
    //   58: instanceof Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$qY
    //   61: ifne -> 76
    //   64: aload #4
    //   66: iload_1
    //   67: invokevirtual get : (I)Ljava/lang/Object;
    //   70: checkcast Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$wktp1mvgWsB4SzZr
    //   73: invokevirtual psJpCSi8_h7NzZZ1vbR : ()V
    //   76: iload_1
    //   77: iconst_1
    //   78: iadd
    //   79: istore_1
    //   80: goto -> 35
    //   83: iload_2
    //   84: aload #4
    //   86: invokevirtual size : ()I
    //   89: if_icmpge -> 129
    //   92: aload #4
    //   94: iload_2
    //   95: invokevirtual get : (I)Ljava/lang/Object;
    //   98: checkcast Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$wktp1mvgWsB4SzZr
    //   101: getfield psJpCSi8_h7NzZZ1vbR : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;
    //   104: instanceof Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$qY
    //   107: ifeq -> 122
    //   110: aload #4
    //   112: iload_2
    //   113: invokevirtual get : (I)Ljava/lang/Object;
    //   116: checkcast Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$wktp1mvgWsB4SzZr
    //   119: invokevirtual psJpCSi8_h7NzZZ1vbR : ()V
    //   122: iload_2
    //   123: iconst_1
    //   124: iadd
    //   125: istore_2
    //   126: goto -> 83
    //   129: aload_0
    //   130: getfield D89UfNGBvLPp16h : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$D89UfNGBvLPp16h;
    //   133: astore #4
    //   135: aload #4
    //   137: ifnull -> 149
    //   140: aload #4
    //   142: aload_0
    //   143: getfield BIRpv : LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;
    //   146: invokevirtual psJpCSi8_h7NzZZ1vbR : (LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$X9K8CXVSxZWf;)V
    //   149: return
    //   150: astore #4
    //   152: aload_0
    //   153: monitorexit
    //   154: aload #4
    //   156: athrow
    // Exception table:
    //   from	to	target	type
    //   10	16	150	finally
    //   21	23	150	finally
    //   24	31	150	finally
    //   152	154	150	finally
  }
  
  public boolean wktp1mvgWsB4SzZr() {
    D89UfNGBvLPp16h d89UfNGBvLPp16h = this.D89UfNGBvLPp16h;
    return (d89UfNGBvLPp16h == null) ? false : d89UfNGBvLPp16h.wktp1mvgWsB4SzZr();
  }
  
  boolean wqn() {
    return (Q_() == this);
  }
  
  public static final class BIRpv<T> {
    private final T Q_;
    
    private final String psJpCSi8_h7NzZZ1vbR;
    
    BIRpv(String param1String) {
      this(param1String, null);
    }
    
    BIRpv(String param1String, T param1T) {
      this.psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR.<String>psJpCSi8_h7NzZZ1vbR(param1String, "name");
      this.Q_ = param1T;
    }
    
    public T psJpCSi8_h7NzZZ1vbR() {
      return psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR.Q_());
    }
    
    public T psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
      Object object2 = param1psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(this);
      Object object1 = object2;
      if (object2 == null)
        object1 = this.Q_; 
      return (T)object1;
    }
    
    public String toString() {
      return this.psJpCSi8_h7NzZZ1vbR;
    }
  }
  
  public static final class D89UfNGBvLPp16h extends psJpCSi8_h7NzZZ1vbR implements Closeable {
    private boolean BIRpv;
    
    private Throwable LEIMjJ;
    
    private ScheduledFuture<?> qY;
    
    private final psJpCSi8_h7NzZZ1vbR wktp1mvgWsB4SzZr;
    
    private final Q_ wqn;
    
    private D89UfNGBvLPp16h(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
      super(param1psJpCSi8_h7NzZZ1vbR, param1psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf);
      this.wqn = param1psJpCSi8_h7NzZZ1vbR.LEIMjJ();
      this.wktp1mvgWsB4SzZr = new psJpCSi8_h7NzZZ1vbR(this, this.X9K8CXVSxZWf);
    }
    
    private D89UfNGBvLPp16h(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR, Q_ param1Q_) {
      super(param1psJpCSi8_h7NzZZ1vbR, param1psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf);
      this.wqn = param1Q_;
      this.wktp1mvgWsB4SzZr = new psJpCSi8_h7NzZZ1vbR(this, this.X9K8CXVSxZWf);
    }
    
    private void Q_(Q_ param1Q_, ScheduledExecutorService param1ScheduledExecutorService) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual Q_ : ()Z
      //   4: ifne -> 34
      //   7: aload_0
      //   8: monitorenter
      //   9: aload_0
      //   10: aload_1
      //   11: new Snla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$D89UfNGBvLPp16h$psJpCSi8_h7NzZZ1vbR
      //   14: dup
      //   15: aload_0
      //   16: invokespecial <init> : (LSnla/psJpCSi8_h7NzZZ1vbR/psJpCSi8_h7NzZZ1vbR$D89UfNGBvLPp16h;)V
      //   19: aload_2
      //   20: invokevirtual psJpCSi8_h7NzZZ1vbR : (Ljava/lang/Runnable;Ljava/util/concurrent/ScheduledExecutorService;)Ljava/util/concurrent/ScheduledFuture;
      //   23: putfield qY : Ljava/util/concurrent/ScheduledFuture;
      //   26: aload_0
      //   27: monitorexit
      //   28: return
      //   29: astore_1
      //   30: aload_0
      //   31: monitorexit
      //   32: aload_1
      //   33: athrow
      //   34: aload_0
      //   35: new java/util/concurrent/TimeoutException
      //   38: dup
      //   39: ldc 'context timed out'
      //   41: invokespecial <init> : (Ljava/lang/String;)V
      //   44: invokevirtual psJpCSi8_h7NzZZ1vbR : (Ljava/lang/Throwable;)Z
      //   47: pop
      //   48: return
      // Exception table:
      //   from	to	target	type
      //   9	28	29	finally
      //   30	32	29	finally
    }
    
    public Throwable BIRpv() {
      return wktp1mvgWsB4SzZr() ? this.LEIMjJ : null;
    }
    
    public Q_ LEIMjJ() {
      return this.wqn;
    }
    
    public psJpCSi8_h7NzZZ1vbR MxwALnHp3MNCI() {
      return this.wktp1mvgWsB4SzZr.MxwALnHp3MNCI();
    }
    
    boolean X9K8CXVSxZWf() {
      return true;
    }
    
    public void close() {
      psJpCSi8_h7NzZZ1vbR((Throwable)null);
    }
    
    public void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
      this.wktp1mvgWsB4SzZr.psJpCSi8_h7NzZZ1vbR(param1psJpCSi8_h7NzZZ1vbR);
    }
    
    public void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR, Throwable param1Throwable) {
      try {
        psJpCSi8_h7NzZZ1vbR(param1psJpCSi8_h7NzZZ1vbR);
        return;
      } finally {
        psJpCSi8_h7NzZZ1vbR(param1Throwable);
      } 
    }
    
    public boolean psJpCSi8_h7NzZZ1vbR(Throwable param1Throwable) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield BIRpv : Z
      //   6: istore_3
      //   7: iconst_1
      //   8: istore_2
      //   9: iload_3
      //   10: ifne -> 68
      //   13: aload_0
      //   14: iconst_1
      //   15: putfield BIRpv : Z
      //   18: aload_0
      //   19: getfield qY : Ljava/util/concurrent/ScheduledFuture;
      //   22: astore #4
      //   24: aload #4
      //   26: ifnull -> 43
      //   29: aload #4
      //   31: iconst_0
      //   32: invokeinterface cancel : (Z)Z
      //   37: pop
      //   38: aload_0
      //   39: aconst_null
      //   40: putfield qY : Ljava/util/concurrent/ScheduledFuture;
      //   43: aload_0
      //   44: aload_1
      //   45: putfield LEIMjJ : Ljava/lang/Throwable;
      //   48: goto -> 51
      //   51: aload_0
      //   52: monitorexit
      //   53: iload_2
      //   54: ifeq -> 61
      //   57: aload_0
      //   58: invokevirtual qY : ()V
      //   61: iload_2
      //   62: ireturn
      //   63: astore_1
      //   64: aload_0
      //   65: monitorexit
      //   66: aload_1
      //   67: athrow
      //   68: iconst_0
      //   69: istore_2
      //   70: goto -> 51
      // Exception table:
      //   from	to	target	type
      //   2	7	63	finally
      //   13	24	63	finally
      //   29	43	63	finally
      //   43	48	63	finally
      //   51	53	63	finally
      //   64	66	63	finally
    }
    
    public boolean wktp1mvgWsB4SzZr() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield BIRpv : Z
      //   6: ifeq -> 13
      //   9: aload_0
      //   10: monitorexit
      //   11: iconst_1
      //   12: ireturn
      //   13: aload_0
      //   14: monitorexit
      //   15: aload_0
      //   16: invokespecial wktp1mvgWsB4SzZr : ()Z
      //   19: ifeq -> 33
      //   22: aload_0
      //   23: aload_0
      //   24: invokespecial BIRpv : ()Ljava/lang/Throwable;
      //   27: invokevirtual psJpCSi8_h7NzZZ1vbR : (Ljava/lang/Throwable;)Z
      //   30: pop
      //   31: iconst_1
      //   32: ireturn
      //   33: iconst_0
      //   34: ireturn
      //   35: astore_1
      //   36: aload_0
      //   37: monitorexit
      //   38: aload_1
      //   39: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	35	finally
      //   13	15	35	finally
      //   36	38	35	finally
    }
    
    @Deprecated
    public boolean wqn() {
      return this.wktp1mvgWsB4SzZr.wqn();
    }
    
    final class psJpCSi8_h7NzZZ1vbR implements Runnable {
      psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h this$0) {}
      
      public void run() {
        try {
          return;
        } finally {
          Exception exception = null;
          psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.log(Level.SEVERE, "Cancel threw an exception, which should not happen", exception);
        } 
      }
    }
  }
  
  final class psJpCSi8_h7NzZZ1vbR implements Runnable {
    psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR this$0) {}
    
    public void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.log(Level.SEVERE, "Cancel threw an exception, which should not happen", exception);
      } 
    }
  }
  
  private static final class LEIMjJ {
    static final psJpCSi8_h7NzZZ1vbR.hzEmy psJpCSi8_h7NzZZ1vbR;
    
    static {
      AtomicReference<? super ClassNotFoundException> atomicReference = new AtomicReference();
      psJpCSi8_h7NzZZ1vbR = psJpCSi8_h7NzZZ1vbR(atomicReference);
      Throwable throwable = atomicReference.get();
      if (throwable != null)
        psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.log(Level.FINE, "Storage override doesn't exist. Using default", throwable); 
    }
    
    private static psJpCSi8_h7NzZZ1vbR.hzEmy psJpCSi8_h7NzZZ1vbR(AtomicReference<? super ClassNotFoundException> param1AtomicReference) {
      try {
        return Class.forName("io.grpc.override.ContextStorageOverride").<psJpCSi8_h7NzZZ1vbR.hzEmy>asSubclass(psJpCSi8_h7NzZZ1vbR.hzEmy.class).getConstructor(new Class[0]).newInstance(new Object[0]);
      } catch (ClassNotFoundException classNotFoundException) {
        param1AtomicReference.set(classNotFoundException);
        return new D89UfNGBvLPp16h();
      } catch (Exception exception) {
        throw new RuntimeException("Storage override failed to initialize", exception);
      } 
    }
  }
  
  static @interface MxwALnHp3MNCI {}
  
  final class Q_ implements Executor {
    Q_(psJpCSi8_h7NzZZ1vbR this$0, Executor param1Executor) {}
    
    public void execute(Runnable param1Runnable) {
      this.psJpCSi8_h7NzZZ1vbR.execute(this.Q_.Q_(param1Runnable));
    }
  }
  
  public static interface X9K8CXVSxZWf {
    void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR);
  }
  
  static @interface XV2I8z {}
  
  public static abstract class hzEmy {
    public psJpCSi8_h7NzZZ1vbR Q_(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = psJpCSi8_h7NzZZ1vbR();
      psJpCSi8_h7NzZZ1vbR(param1psJpCSi8_h7NzZZ1vbR);
      return psJpCSi8_h7NzZZ1vbR1;
    }
    
    public abstract psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR();
    
    @Deprecated
    public void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
      throw new UnsupportedOperationException("Deprecated. Do not call.");
    }
    
    public abstract void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR1, psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR2);
  }
  
  final class psJpCSi8_h7NzZZ1vbR implements Executor {
    psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR this$0) {}
    
    public void execute(Runnable param1Runnable) {
      this.psJpCSi8_h7NzZZ1vbR.execute(psJpCSi8_h7NzZZ1vbR.Q_().Q_(param1Runnable));
    }
  }
  
  private final class qY implements X9K8CXVSxZWf {
    private qY(psJpCSi8_h7NzZZ1vbR this$0) {}
    
    public void psJpCSi8_h7NzZZ1vbR(psJpCSi8_h7NzZZ1vbR param1psJpCSi8_h7NzZZ1vbR) {
      psJpCSi8_h7NzZZ1vbR psJpCSi8_h7NzZZ1vbR1 = this.psJpCSi8_h7NzZZ1vbR;
      if (psJpCSi8_h7NzZZ1vbR1 instanceof psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h) {
        ((psJpCSi8_h7NzZZ1vbR.D89UfNGBvLPp16h)psJpCSi8_h7NzZZ1vbR1).psJpCSi8_h7NzZZ1vbR(param1psJpCSi8_h7NzZZ1vbR.BIRpv());
        return;
      } 
      psJpCSi8_h7NzZZ1vbR1.qY();
    }
  }
  
  private final class wktp1mvgWsB4SzZr implements Runnable {
    private final Executor XV2I8z;
    
    final psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf psJpCSi8_h7NzZZ1vbR;
    
    wktp1mvgWsB4SzZr(psJpCSi8_h7NzZZ1vbR this$0, Executor param1Executor, psJpCSi8_h7NzZZ1vbR.X9K8CXVSxZWf param1X9K8CXVSxZWf) {
      this.XV2I8z = param1Executor;
      this.psJpCSi8_h7NzZZ1vbR = param1X9K8CXVSxZWf;
    }
    
    void psJpCSi8_h7NzZZ1vbR() {
      try {
        return;
      } finally {
        Exception exception = null;
        psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR.log(Level.INFO, "Exception notifying context listener", exception);
      } 
    }
    
    public void run() {
      this.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR(this.Q_);
    }
  }
  
  private enum wqn implements Executor {
    psJpCSi8_h7NzZZ1vbR;
    
    static {
      wqn wqn1 = new wqn("INSTANCE", 0);
      psJpCSi8_h7NzZZ1vbR = wqn1;
      Q_ = new wqn[] { wqn1 };
    }
    
    public void execute(Runnable param1Runnable) {
      param1Runnable.run();
    }
    
    public String toString() {
      return "Context.DirectExecutor";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\Snla\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */