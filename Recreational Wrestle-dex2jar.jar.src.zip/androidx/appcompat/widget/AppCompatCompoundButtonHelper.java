package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.widget.CompoundButtonCompat;

class AppCompatCompoundButtonHelper {
  private ColorStateList mButtonTintList = null;
  
  private PorterDuff.Mode mButtonTintMode = null;
  
  private boolean mHasButtonTint = false;
  
  private boolean mHasButtonTintMode = false;
  
  private boolean mSkipNextApply;
  
  private final CompoundButton mView;
  
  AppCompatCompoundButtonHelper(CompoundButton paramCompoundButton) {
    this.mView = paramCompoundButton;
  }
  
  void applyButtonTint() {
    Drawable drawable = CompoundButtonCompat.getButtonDrawable(this.mView);
    if (drawable != null && (this.mHasButtonTint || this.mHasButtonTintMode)) {
      drawable = DrawableCompat.wrap(drawable).mutate();
      if (this.mHasButtonTint)
        DrawableCompat.setTintList(drawable, this.mButtonTintList); 
      if (this.mHasButtonTintMode)
        DrawableCompat.setTintMode(drawable, this.mButtonTintMode); 
      if (drawable.isStateful())
        drawable.setState(this.mView.getDrawableState()); 
      this.mView.setButtonDrawable(drawable);
    } 
  }
  
  int getCompoundPaddingLeft(int paramInt) {
    int i = paramInt;
    if (Build.VERSION.SDK_INT < 17) {
      Drawable drawable = CompoundButtonCompat.getButtonDrawable(this.mView);
      i = paramInt;
      if (drawable != null)
        i = paramInt + drawable.getIntrinsicWidth(); 
    } 
    return i;
  }
  
  ColorStateList getSupportButtonTintList() {
    return this.mButtonTintList;
  }
  
  PorterDuff.Mode getSupportButtonTintMode() {
    return this.mButtonTintMode;
  }
  
  void loadFromAttributes(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mView : Landroid/widget/CompoundButton;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: aload_1
    //   8: getstatic androidx/appcompat/R$styleable.CompoundButton : [I
    //   11: iload_2
    //   12: iconst_0
    //   13: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   16: astore_1
    //   17: aload_1
    //   18: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonCompat : I
    //   21: invokevirtual hasValue : (I)Z
    //   24: ifeq -> 62
    //   27: aload_1
    //   28: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonCompat : I
    //   31: iconst_0
    //   32: invokevirtual getResourceId : (II)I
    //   35: istore_2
    //   36: iload_2
    //   37: ifeq -> 62
    //   40: aload_0
    //   41: getfield mView : Landroid/widget/CompoundButton;
    //   44: astore_3
    //   45: aload_3
    //   46: aload_3
    //   47: invokevirtual getContext : ()Landroid/content/Context;
    //   50: iload_2
    //   51: invokestatic getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   54: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   57: iconst_1
    //   58: istore_2
    //   59: goto -> 64
    //   62: iconst_0
    //   63: istore_2
    //   64: iload_2
    //   65: ifne -> 108
    //   68: aload_1
    //   69: getstatic androidx/appcompat/R$styleable.CompoundButton_android_button : I
    //   72: invokevirtual hasValue : (I)Z
    //   75: ifeq -> 108
    //   78: aload_1
    //   79: getstatic androidx/appcompat/R$styleable.CompoundButton_android_button : I
    //   82: iconst_0
    //   83: invokevirtual getResourceId : (II)I
    //   86: istore_2
    //   87: iload_2
    //   88: ifeq -> 108
    //   91: aload_0
    //   92: getfield mView : Landroid/widget/CompoundButton;
    //   95: astore_3
    //   96: aload_3
    //   97: aload_3
    //   98: invokevirtual getContext : ()Landroid/content/Context;
    //   101: iload_2
    //   102: invokestatic getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   105: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   108: aload_1
    //   109: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonTint : I
    //   112: invokevirtual hasValue : (I)Z
    //   115: ifeq -> 132
    //   118: aload_0
    //   119: getfield mView : Landroid/widget/CompoundButton;
    //   122: aload_1
    //   123: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonTint : I
    //   126: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   129: invokestatic setButtonTintList : (Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V
    //   132: aload_1
    //   133: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonTintMode : I
    //   136: invokevirtual hasValue : (I)Z
    //   139: ifeq -> 161
    //   142: aload_0
    //   143: getfield mView : Landroid/widget/CompoundButton;
    //   146: aload_1
    //   147: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonTintMode : I
    //   150: iconst_m1
    //   151: invokevirtual getInt : (II)I
    //   154: aconst_null
    //   155: invokestatic parseTintMode : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   158: invokestatic setButtonTintMode : (Landroid/widget/CompoundButton;Landroid/graphics/PorterDuff$Mode;)V
    //   161: aload_1
    //   162: invokevirtual recycle : ()V
    //   165: return
    //   166: astore_3
    //   167: aload_1
    //   168: invokevirtual recycle : ()V
    //   171: aload_3
    //   172: athrow
    //   173: astore_3
    //   174: goto -> 62
    // Exception table:
    //   from	to	target	type
    //   17	36	166	finally
    //   40	57	173	android/content/res/Resources$NotFoundException
    //   40	57	166	finally
    //   68	87	166	finally
    //   91	108	166	finally
    //   108	132	166	finally
    //   132	161	166	finally
  }
  
  void onSetButtonDrawable() {
    if (this.mSkipNextApply) {
      this.mSkipNextApply = false;
      return;
    } 
    this.mSkipNextApply = true;
    applyButtonTint();
  }
  
  void setSupportButtonTintList(ColorStateList paramColorStateList) {
    this.mButtonTintList = paramColorStateList;
    this.mHasButtonTint = true;
    applyButtonTint();
  }
  
  void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    this.mButtonTintMode = paramMode;
    this.mHasButtonTintMode = true;
    applyButtonTint();
  }
  
  static interface DirectSetButtonDrawableInterface {
    void setButtonDrawable(Drawable param1Drawable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\androidx\appcompat\widget\AppCompatCompoundButtonHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */