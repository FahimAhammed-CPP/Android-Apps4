package PtG.psJpCSi8_h7NzZZ1vbR.psJpCSi8_h7NzZZ1vbR;

import android.util.Log;

public class psJpCSi8_h7NzZZ1vbR {
  protected static boolean Ap4G4fS9phs;
  
  protected static long MxwALnHp3MNCI;
  
  private static byte hhkWV822WvWIJ6d;
  
  protected static float hzEmy;
  
  protected static int psJpCSi8_h7NzZZ1vbR;
  
  protected static boolean rG8A403wjTaYB6V;
  
  protected static boolean wqn;
  
  public byte BIRpv;
  
  protected int D89UfNGBvLPp16h;
  
  protected float D_K6ibTZHL_tOOY3;
  
  protected int GUkgqR9XjHnivS;
  
  public byte LEIMjJ;
  
  protected double LEwT0cz2WRRZ;
  
  public short Q_;
  
  public char UptK2mZMIFJk1ivmXYH;
  
  public char X9K8CXVSxZWf;
  
  protected long XV2I8z;
  
  private long aqqnPTeV;
  
  private int fc4RJByVvAciR;
  
  private char jlrPm;
  
  protected long oq9TzoD0;
  
  public byte qY;
  
  public float wktp1mvgWsB4SzZr;
  
  private static void psJpCSi8_h7NzZZ1vbR() {
    Log.i("JkUTHYmgPSwnDYzZPJETDDEZAIgHrPtqcXyBJKJXV", "JUaIFJaQGzBTEnvwDrFDFnIuhxwGIgwxPoUIBfxEG");
    Log.e("UcLGGsRuiqnvrzlDJnvanPEGCcGbqnxTNnmPVZCOH", "tjHifFMIvJcaNZvFJAhvGIWhoajYFHTnMBVBGBTuK");
    Log.i("UMzyPr", "GbHrImH");
    Log.v("gpfCACUFzQLDpfYvcmqJFrFHImKHZrO", "ytdIYDWFKFByfCHZJIXpWAn");
    Log.i("CCAzhfNkAyDuAl", "QviuQHQbaRjHVhRyulgIoPlGFEdtqCqEXFEHjUKCp");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Recreational Wrestle-dex2jar.jar!\PtG\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR\psJpCSi8_h7NzZZ1vbR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */