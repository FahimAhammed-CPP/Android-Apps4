package androidx.constraintlayout.widget;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130903040;
    
    public static final int actionBarItemBackground = 2130903041;
    
    public static final int actionBarPopupTheme = 2130903042;
    
    public static final int actionBarSize = 2130903043;
    
    public static final int actionBarSplitStyle = 2130903044;
    
    public static final int actionBarStyle = 2130903045;
    
    public static final int actionBarTabBarStyle = 2130903046;
    
    public static final int actionBarTabStyle = 2130903047;
    
    public static final int actionBarTabTextStyle = 2130903048;
    
    public static final int actionBarTheme = 2130903049;
    
    public static final int actionBarWidgetTheme = 2130903050;
    
    public static final int actionButtonStyle = 2130903051;
    
    public static final int actionDropDownStyle = 2130903052;
    
    public static final int actionLayout = 2130903053;
    
    public static final int actionMenuTextAppearance = 2130903054;
    
    public static final int actionMenuTextColor = 2130903055;
    
    public static final int actionModeBackground = 2130903056;
    
    public static final int actionModeCloseButtonStyle = 2130903057;
    
    public static final int actionModeCloseDrawable = 2130903059;
    
    public static final int actionModeCopyDrawable = 2130903060;
    
    public static final int actionModeCutDrawable = 2130903061;
    
    public static final int actionModeFindDrawable = 2130903062;
    
    public static final int actionModePasteDrawable = 2130903063;
    
    public static final int actionModePopupWindowStyle = 2130903064;
    
    public static final int actionModeSelectAllDrawable = 2130903065;
    
    public static final int actionModeShareDrawable = 2130903066;
    
    public static final int actionModeSplitBackground = 2130903067;
    
    public static final int actionModeStyle = 2130903068;
    
    public static final int actionModeWebSearchDrawable = 2130903070;
    
    public static final int actionOverflowButtonStyle = 2130903071;
    
    public static final int actionOverflowMenuStyle = 2130903072;
    
    public static final int actionProviderClass = 2130903073;
    
    public static final int actionViewClass = 2130903075;
    
    public static final int activityChooserViewStyle = 2130903076;
    
    public static final int alertDialogButtonGroupStyle = 2130903080;
    
    public static final int alertDialogCenterButtons = 2130903081;
    
    public static final int alertDialogStyle = 2130903082;
    
    public static final int alertDialogTheme = 2130903083;
    
    public static final int allowStacking = 2130903084;
    
    public static final int alpha = 2130903085;
    
    public static final int alphabeticModifiers = 2130903086;
    
    public static final int altSrc = 2130903087;
    
    public static final int animate_relativeTo = 2130903088;
    
    public static final int applyMotionScene = 2130903091;
    
    public static final int arcMode = 2130903092;
    
    public static final int arrowHeadLength = 2130903093;
    
    public static final int arrowShaftLength = 2130903094;
    
    public static final int attributeName = 2130903095;
    
    public static final int autoCompleteTextViewStyle = 2130903096;
    
    public static final int autoSizeMaxTextSize = 2130903097;
    
    public static final int autoSizeMinTextSize = 2130903098;
    
    public static final int autoSizePresetSizes = 2130903099;
    
    public static final int autoSizeStepGranularity = 2130903100;
    
    public static final int autoSizeTextType = 2130903101;
    
    public static final int autoTransition = 2130903102;
    
    public static final int background = 2130903103;
    
    public static final int backgroundSplit = 2130903110;
    
    public static final int backgroundStacked = 2130903111;
    
    public static final int backgroundTint = 2130903112;
    
    public static final int backgroundTintMode = 2130903113;
    
    public static final int barLength = 2130903117;
    
    public static final int barrierAllowsGoneWidgets = 2130903118;
    
    public static final int barrierDirection = 2130903119;
    
    public static final int barrierMargin = 2130903120;
    
    public static final int borderlessButtonStyle = 2130903133;
    
    public static final int brightness = 2130903149;
    
    public static final int buttonBarButtonStyle = 2130903150;
    
    public static final int buttonBarNegativeButtonStyle = 2130903151;
    
    public static final int buttonBarNeutralButtonStyle = 2130903152;
    
    public static final int buttonBarPositiveButtonStyle = 2130903153;
    
    public static final int buttonBarStyle = 2130903154;
    
    public static final int buttonCompat = 2130903155;
    
    public static final int buttonGravity = 2130903156;
    
    public static final int buttonIconDimen = 2130903157;
    
    public static final int buttonPanelSideLayout = 2130903158;
    
    public static final int buttonStyle = 2130903159;
    
    public static final int buttonStyleSmall = 2130903160;
    
    public static final int buttonTint = 2130903161;
    
    public static final int buttonTintMode = 2130903162;
    
    public static final int chainUseRtl = 2130903171;
    
    public static final int checkboxStyle = 2130903172;
    
    public static final int checkedTextViewStyle = 2130903181;
    
    public static final int circleRadius = 2130903202;
    
    public static final int clickAction = 2130903204;
    
    public static final int closeIcon = 2130903209;
    
    public static final int closeItemLayout = 2130903216;
    
    public static final int collapseContentDescription = 2130903217;
    
    public static final int collapseIcon = 2130903218;
    
    public static final int color = 2130903223;
    
    public static final int colorAccent = 2130903224;
    
    public static final int colorBackgroundFloating = 2130903225;
    
    public static final int colorButtonNormal = 2130903226;
    
    public static final int colorControlActivated = 2130903227;
    
    public static final int colorControlHighlight = 2130903228;
    
    public static final int colorControlNormal = 2130903229;
    
    public static final int colorError = 2130903230;
    
    public static final int colorPrimary = 2130903237;
    
    public static final int colorPrimaryDark = 2130903238;
    
    public static final int colorSwitchThumbNormal = 2130903244;
    
    public static final int commitIcon = 2130903245;
    
    public static final int constraintSet = 2130903246;
    
    public static final int constraintSetEnd = 2130903247;
    
    public static final int constraintSetStart = 2130903248;
    
    public static final int constraint_referenced_ids = 2130903249;
    
    public static final int constraints = 2130903250;
    
    public static final int content = 2130903251;
    
    public static final int contentDescription = 2130903252;
    
    public static final int contentInsetEnd = 2130903253;
    
    public static final int contentInsetEndWithActions = 2130903254;
    
    public static final int contentInsetLeft = 2130903255;
    
    public static final int contentInsetRight = 2130903256;
    
    public static final int contentInsetStart = 2130903257;
    
    public static final int contentInsetStartWithNavigation = 2130903258;
    
    public static final int contrast = 2130903267;
    
    public static final int controlBackground = 2130903268;
    
    public static final int crossfade = 2130903287;
    
    public static final int currentState = 2130903288;
    
    public static final int curveFit = 2130903289;
    
    public static final int customBoolean = 2130903290;
    
    public static final int customColorDrawableValue = 2130903291;
    
    public static final int customColorValue = 2130903292;
    
    public static final int customDimension = 2130903293;
    
    public static final int customFloatValue = 2130903294;
    
    public static final int customIntegerValue = 2130903295;
    
    public static final int customNavigationLayout = 2130903296;
    
    public static final int customPixelDimension = 2130903297;
    
    public static final int customStringValue = 2130903298;
    
    public static final int defaultDuration = 2130903303;
    
    public static final int defaultQueryHint = 2130903304;
    
    public static final int defaultState = 2130903305;
    
    public static final int deltaPolarAngle = 2130903306;
    
    public static final int deltaPolarRadius = 2130903307;
    
    public static final int deriveConstraintsFrom = 2130903308;
    
    public static final int dialogCornerRadius = 2130903309;
    
    public static final int dialogPreferredPadding = 2130903310;
    
    public static final int dialogTheme = 2130903311;
    
    public static final int displayOptions = 2130903312;
    
    public static final int divider = 2130903313;
    
    public static final int dividerHorizontal = 2130903314;
    
    public static final int dividerPadding = 2130903315;
    
    public static final int dividerVertical = 2130903316;
    
    public static final int dragDirection = 2130903317;
    
    public static final int dragScale = 2130903318;
    
    public static final int dragThreshold = 2130903319;
    
    public static final int drawPath = 2130903320;
    
    public static final int drawableBottomCompat = 2130903321;
    
    public static final int drawableEndCompat = 2130903322;
    
    public static final int drawableLeftCompat = 2130903323;
    
    public static final int drawableRightCompat = 2130903324;
    
    public static final int drawableSize = 2130903325;
    
    public static final int drawableStartCompat = 2130903326;
    
    public static final int drawableTint = 2130903327;
    
    public static final int drawableTintMode = 2130903328;
    
    public static final int drawableTopCompat = 2130903329;
    
    public static final int drawerArrowStyle = 2130903330;
    
    public static final int dropDownListViewStyle = 2130903331;
    
    public static final int dropdownListPreferredItemHeight = 2130903332;
    
    public static final int duration = 2130903333;
    
    public static final int editTextBackground = 2130903334;
    
    public static final int editTextColor = 2130903335;
    
    public static final int editTextStyle = 2130903336;
    
    public static final int elevation = 2130903337;
    
    public static final int expandActivityOverflowButtonDrawable = 2130903357;
    
    public static final int firstBaselineToTopHeight = 2130903382;
    
    public static final int flow_firstHorizontalBias = 2130903384;
    
    public static final int flow_firstHorizontalStyle = 2130903385;
    
    public static final int flow_firstVerticalBias = 2130903386;
    
    public static final int flow_firstVerticalStyle = 2130903387;
    
    public static final int flow_horizontalAlign = 2130903388;
    
    public static final int flow_horizontalBias = 2130903389;
    
    public static final int flow_horizontalGap = 2130903390;
    
    public static final int flow_horizontalStyle = 2130903391;
    
    public static final int flow_lastHorizontalBias = 2130903392;
    
    public static final int flow_lastHorizontalStyle = 2130903393;
    
    public static final int flow_lastVerticalBias = 2130903394;
    
    public static final int flow_lastVerticalStyle = 2130903395;
    
    public static final int flow_maxElementsWrap = 2130903396;
    
    public static final int flow_padding = 2130903397;
    
    public static final int flow_verticalAlign = 2130903398;
    
    public static final int flow_verticalBias = 2130903399;
    
    public static final int flow_verticalGap = 2130903400;
    
    public static final int flow_verticalStyle = 2130903401;
    
    public static final int flow_wrapMode = 2130903402;
    
    public static final int font = 2130903403;
    
    public static final int fontFamily = 2130903404;
    
    public static final int fontProviderAuthority = 2130903405;
    
    public static final int fontProviderCerts = 2130903406;
    
    public static final int fontProviderFetchStrategy = 2130903407;
    
    public static final int fontProviderFetchTimeout = 2130903408;
    
    public static final int fontProviderPackage = 2130903409;
    
    public static final int fontProviderQuery = 2130903410;
    
    public static final int fontStyle = 2130903412;
    
    public static final int fontVariationSettings = 2130903413;
    
    public static final int fontWeight = 2130903414;
    
    public static final int framePosition = 2130903417;
    
    public static final int gapBetweenBars = 2130903418;
    
    public static final int goIcon = 2130903420;
    
    public static final int height = 2130903424;
    
    public static final int hideOnContentScroll = 2130903431;
    
    public static final int homeAsUpIndicator = 2130903437;
    
    public static final int homeLayout = 2130903438;
    
    public static final int icon = 2130903441;
    
    public static final int iconTint = 2130903447;
    
    public static final int iconTintMode = 2130903448;
    
    public static final int iconifiedByDefault = 2130903449;
    
    public static final int imageButtonStyle = 2130903450;
    
    public static final int indeterminateProgressStyle = 2130903452;
    
    public static final int initialActivityCount = 2130903458;
    
    public static final int isLightTheme = 2130903460;
    
    public static final int itemPadding = 2130903470;
    
    public static final int keyPositionType = 2130903486;
    
    public static final int lastBaselineToBottomHeight = 2130903492;
    
    public static final int layout = 2130903493;
    
    public static final int layoutDescription = 2130903494;
    
    public static final int layoutDuringTransition = 2130903495;
    
    public static final int layout_constrainedHeight = 2130903502;
    
    public static final int layout_constrainedWidth = 2130903503;
    
    public static final int layout_constraintBaseline_creator = 2130903504;
    
    public static final int layout_constraintBaseline_toBaselineOf = 2130903505;
    
    public static final int layout_constraintBottom_creator = 2130903506;
    
    public static final int layout_constraintBottom_toBottomOf = 2130903507;
    
    public static final int layout_constraintBottom_toTopOf = 2130903508;
    
    public static final int layout_constraintCircle = 2130903509;
    
    public static final int layout_constraintCircleAngle = 2130903510;
    
    public static final int layout_constraintCircleRadius = 2130903511;
    
    public static final int layout_constraintDimensionRatio = 2130903512;
    
    public static final int layout_constraintEnd_toEndOf = 2130903513;
    
    public static final int layout_constraintEnd_toStartOf = 2130903514;
    
    public static final int layout_constraintGuide_begin = 2130903515;
    
    public static final int layout_constraintGuide_end = 2130903516;
    
    public static final int layout_constraintGuide_percent = 2130903517;
    
    public static final int layout_constraintHeight_default = 2130903518;
    
    public static final int layout_constraintHeight_max = 2130903519;
    
    public static final int layout_constraintHeight_min = 2130903520;
    
    public static final int layout_constraintHeight_percent = 2130903521;
    
    public static final int layout_constraintHorizontal_bias = 2130903522;
    
    public static final int layout_constraintHorizontal_chainStyle = 2130903523;
    
    public static final int layout_constraintHorizontal_weight = 2130903524;
    
    public static final int layout_constraintLeft_creator = 2130903525;
    
    public static final int layout_constraintLeft_toLeftOf = 2130903526;
    
    public static final int layout_constraintLeft_toRightOf = 2130903527;
    
    public static final int layout_constraintRight_creator = 2130903528;
    
    public static final int layout_constraintRight_toLeftOf = 2130903529;
    
    public static final int layout_constraintRight_toRightOf = 2130903530;
    
    public static final int layout_constraintStart_toEndOf = 2130903531;
    
    public static final int layout_constraintStart_toStartOf = 2130903532;
    
    public static final int layout_constraintTag = 2130903533;
    
    public static final int layout_constraintTop_creator = 2130903534;
    
    public static final int layout_constraintTop_toBottomOf = 2130903535;
    
    public static final int layout_constraintTop_toTopOf = 2130903536;
    
    public static final int layout_constraintVertical_bias = 2130903537;
    
    public static final int layout_constraintVertical_chainStyle = 2130903538;
    
    public static final int layout_constraintVertical_weight = 2130903539;
    
    public static final int layout_constraintWidth_default = 2130903540;
    
    public static final int layout_constraintWidth_max = 2130903541;
    
    public static final int layout_constraintWidth_min = 2130903542;
    
    public static final int layout_constraintWidth_percent = 2130903543;
    
    public static final int layout_editor_absoluteX = 2130903545;
    
    public static final int layout_editor_absoluteY = 2130903546;
    
    public static final int layout_goneMarginBottom = 2130903547;
    
    public static final int layout_goneMarginEnd = 2130903548;
    
    public static final int layout_goneMarginLeft = 2130903549;
    
    public static final int layout_goneMarginRight = 2130903550;
    
    public static final int layout_goneMarginStart = 2130903551;
    
    public static final int layout_goneMarginTop = 2130903552;
    
    public static final int layout_optimizationLevel = 2130903555;
    
    public static final int limitBoundsTo = 2130903560;
    
    public static final int lineHeight = 2130903561;
    
    public static final int listChoiceBackgroundIndicator = 2130903564;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130903565;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130903566;
    
    public static final int listDividerAlertDialog = 2130903567;
    
    public static final int listItemLayout = 2130903568;
    
    public static final int listLayout = 2130903569;
    
    public static final int listMenuViewStyle = 2130903570;
    
    public static final int listPopupWindowStyle = 2130903571;
    
    public static final int listPreferredItemHeight = 2130903572;
    
    public static final int listPreferredItemHeightLarge = 2130903573;
    
    public static final int listPreferredItemHeightSmall = 2130903574;
    
    public static final int listPreferredItemPaddingEnd = 2130903575;
    
    public static final int listPreferredItemPaddingLeft = 2130903576;
    
    public static final int listPreferredItemPaddingRight = 2130903577;
    
    public static final int listPreferredItemPaddingStart = 2130903578;
    
    public static final int logo = 2130903579;
    
    public static final int logoDescription = 2130903580;
    
    public static final int maxAcceleration = 2130903609;
    
    public static final int maxButtonHeight = 2130903611;
    
    public static final int maxHeight = 2130903613;
    
    public static final int maxVelocity = 2130903616;
    
    public static final int maxWidth = 2130903617;
    
    public static final int measureWithLargestChild = 2130903618;
    
    public static final int menu = 2130903619;
    
    public static final int minHeight = 2130903621;
    
    public static final int minWidth = 2130903625;
    
    public static final int mock_diagonalsColor = 2130903626;
    
    public static final int mock_label = 2130903627;
    
    public static final int mock_labelBackgroundColor = 2130903628;
    
    public static final int mock_labelColor = 2130903629;
    
    public static final int mock_showDiagonals = 2130903630;
    
    public static final int mock_showLabel = 2130903631;
    
    public static final int motionDebug = 2130903632;
    
    public static final int motionInterpolator = 2130903644;
    
    public static final int motionPathRotate = 2130903646;
    
    public static final int motionProgress = 2130903647;
    
    public static final int motionStagger = 2130903648;
    
    public static final int motionTarget = 2130903649;
    
    public static final int motion_postLayoutCollision = 2130903650;
    
    public static final int motion_triggerOnCollision = 2130903651;
    
    public static final int moveWhenScrollAtTop = 2130903652;
    
    public static final int multiChoiceItemLayout = 2130903653;
    
    public static final int navigationContentDescription = 2130903654;
    
    public static final int navigationIcon = 2130903655;
    
    public static final int navigationMode = 2130903657;
    
    public static final int nestedScrollFlags = 2130903660;
    
    public static final int numericModifiers = 2130903663;
    
    public static final int onCross = 2130903664;
    
    public static final int onHide = 2130903665;
    
    public static final int onNegativeCross = 2130903666;
    
    public static final int onPositiveCross = 2130903667;
    
    public static final int onShow = 2130903668;
    
    public static final int onTouchUp = 2130903669;
    
    public static final int overlapAnchor = 2130903670;
    
    public static final int overlay = 2130903671;
    
    public static final int paddingBottomNoButtons = 2130903672;
    
    public static final int paddingEnd = 2130903674;
    
    public static final int paddingStart = 2130903677;
    
    public static final int paddingTopNoTitle = 2130903678;
    
    public static final int panelBackground = 2130903680;
    
    public static final int panelMenuListTheme = 2130903681;
    
    public static final int panelMenuListWidth = 2130903682;
    
    public static final int pathMotionArc = 2130903688;
    
    public static final int path_percent = 2130903689;
    
    public static final int percentHeight = 2130903690;
    
    public static final int percentWidth = 2130903691;
    
    public static final int percentX = 2130903692;
    
    public static final int percentY = 2130903693;
    
    public static final int perpendicularPath_percent = 2130903694;
    
    public static final int pivotAnchor = 2130903695;
    
    public static final int placeholder_emptyVisibility = 2130903699;
    
    public static final int popupMenuStyle = 2130903701;
    
    public static final int popupTheme = 2130903702;
    
    public static final int popupWindowStyle = 2130903703;
    
    public static final int preserveIconSpacing = 2130903707;
    
    public static final int progressBarPadding = 2130903709;
    
    public static final int progressBarStyle = 2130903710;
    
    public static final int queryBackground = 2130903711;
    
    public static final int queryHint = 2130903712;
    
    public static final int radioButtonStyle = 2130903713;
    
    public static final int ratingBarStyle = 2130903715;
    
    public static final int ratingBarStyleIndicator = 2130903716;
    
    public static final int ratingBarStyleSmall = 2130903717;
    
    public static final int region_heightLessThan = 2130903719;
    
    public static final int region_heightMoreThan = 2130903720;
    
    public static final int region_widthLessThan = 2130903721;
    
    public static final int region_widthMoreThan = 2130903722;
    
    public static final int round = 2130903725;
    
    public static final int roundPercent = 2130903726;
    
    public static final int saturation = 2130903727;
    
    public static final int searchHintIcon = 2130903731;
    
    public static final int searchIcon = 2130903732;
    
    public static final int searchViewStyle = 2130903733;
    
    public static final int seekBarStyle = 2130903734;
    
    public static final int selectableItemBackground = 2130903735;
    
    public static final int selectableItemBackgroundBorderless = 2130903736;
    
    public static final int showAsAction = 2130903745;
    
    public static final int showDividers = 2130903747;
    
    public static final int showPaths = 2130903749;
    
    public static final int showText = 2130903750;
    
    public static final int showTitle = 2130903751;
    
    public static final int singleChoiceItemLayout = 2130903753;
    
    public static final int sizePercent = 2130903756;
    
    public static final int spinBars = 2130903762;
    
    public static final int spinnerDropDownItemStyle = 2130903763;
    
    public static final int spinnerStyle = 2130903764;
    
    public static final int splitTrack = 2130903765;
    
    public static final int srcCompat = 2130903766;
    
    public static final int staggered = 2130903768;
    
    public static final int state_above_anchor = 2130903774;
    
    public static final int subMenuArrow = 2130903785;
    
    public static final int submitBackground = 2130903786;
    
    public static final int subtitle = 2130903787;
    
    public static final int subtitleTextAppearance = 2130903789;
    
    public static final int subtitleTextColor = 2130903790;
    
    public static final int subtitleTextStyle = 2130903791;
    
    public static final int suggestionRowLayout = 2130903795;
    
    public static final int switchMinWidth = 2130903796;
    
    public static final int switchPadding = 2130903797;
    
    public static final int switchStyle = 2130903798;
    
    public static final int switchTextAppearance = 2130903799;
    
    public static final int targetId = 2130903827;
    
    public static final int telltales_tailColor = 2130903828;
    
    public static final int telltales_tailScale = 2130903829;
    
    public static final int telltales_velocityMode = 2130903830;
    
    public static final int textAllCaps = 2130903831;
    
    public static final int textAppearanceLargePopupMenu = 2130903842;
    
    public static final int textAppearanceListItem = 2130903844;
    
    public static final int textAppearanceListItemSecondary = 2130903845;
    
    public static final int textAppearanceListItemSmall = 2130903846;
    
    public static final int textAppearancePopupMenuHeader = 2130903848;
    
    public static final int textAppearanceSearchResultSubtitle = 2130903849;
    
    public static final int textAppearanceSearchResultTitle = 2130903850;
    
    public static final int textAppearanceSmallPopupMenu = 2130903851;
    
    public static final int textColorAlertDialogListItem = 2130903854;
    
    public static final int textColorSearchUrl = 2130903855;
    
    public static final int textLocale = 2130903859;
    
    public static final int theme = 2130903861;
    
    public static final int thickness = 2130903863;
    
    public static final int thumbTextPadding = 2130903869;
    
    public static final int thumbTint = 2130903870;
    
    public static final int thumbTintMode = 2130903871;
    
    public static final int tickMark = 2130903875;
    
    public static final int tickMarkTint = 2130903876;
    
    public static final int tickMarkTintMode = 2130903877;
    
    public static final int tint = 2130903879;
    
    public static final int tintMode = 2130903880;
    
    public static final int title = 2130903881;
    
    public static final int titleMargin = 2130903885;
    
    public static final int titleMarginBottom = 2130903886;
    
    public static final int titleMarginEnd = 2130903887;
    
    public static final int titleMarginStart = 2130903888;
    
    public static final int titleMarginTop = 2130903889;
    
    public static final int titleMargins = 2130903890;
    
    public static final int titleTextAppearance = 2130903891;
    
    public static final int titleTextColor = 2130903892;
    
    public static final int titleTextStyle = 2130903893;
    
    public static final int toolbarNavigationButtonStyle = 2130903895;
    
    public static final int toolbarStyle = 2130903896;
    
    public static final int tooltipForegroundColor = 2130903897;
    
    public static final int tooltipFrameBackground = 2130903898;
    
    public static final int tooltipText = 2130903900;
    
    public static final int touchAnchorId = 2130903901;
    
    public static final int touchAnchorSide = 2130903902;
    
    public static final int touchRegionId = 2130903903;
    
    public static final int track = 2130903904;
    
    public static final int trackTint = 2130903911;
    
    public static final int trackTintMode = 2130903912;
    
    public static final int transitionDisable = 2130903913;
    
    public static final int transitionEasing = 2130903914;
    
    public static final int transitionFlags = 2130903915;
    
    public static final int transitionPathRotate = 2130903916;
    
    public static final int triggerId = 2130903918;
    
    public static final int triggerReceiver = 2130903919;
    
    public static final int triggerSlack = 2130903920;
    
    public static final int ttcIndex = 2130903921;
    
    public static final int viewInflaterClass = 2130903926;
    
    public static final int visibilityMode = 2130903927;
    
    public static final int voiceIcon = 2130903928;
    
    public static final int warmth = 2130903929;
    
    public static final int waveDecay = 2130903930;
    
    public static final int waveOffset = 2130903931;
    
    public static final int wavePeriod = 2130903932;
    
    public static final int waveShape = 2130903933;
    
    public static final int waveVariesBy = 2130903934;
    
    public static final int windowActionBar = 2130903935;
    
    public static final int windowActionBarOverlay = 2130903936;
    
    public static final int windowActionModeOverlay = 2130903937;
    
    public static final int windowFixedHeightMajor = 2130903938;
    
    public static final int windowFixedHeightMinor = 2130903939;
    
    public static final int windowFixedWidthMajor = 2130903940;
    
    public static final int windowFixedWidthMinor = 2130903941;
    
    public static final int windowMinWidthMajor = 2130903942;
    
    public static final int windowMinWidthMinor = 2130903943;
    
    public static final int windowNoTitle = 2130903944;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2130968576;
    
    public static final int abc_config_actionMenuItemAllCaps = 2130968577;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131034112;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131034113;
    
    public static final int abc_btn_colored_borderless_text_material = 2131034114;
    
    public static final int abc_btn_colored_text_material = 2131034115;
    
    public static final int abc_color_highlight_material = 2131034116;
    
    public static final int abc_decor_view_status_guard = 2131034117;
    
    public static final int abc_decor_view_status_guard_light = 2131034118;
    
    public static final int abc_hint_foreground_material_dark = 2131034119;
    
    public static final int abc_hint_foreground_material_light = 2131034120;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131034121;
    
    public static final int abc_primary_text_disable_only_material_light = 2131034122;
    
    public static final int abc_primary_text_material_dark = 2131034123;
    
    public static final int abc_primary_text_material_light = 2131034124;
    
    public static final int abc_search_url_text = 2131034125;
    
    public static final int abc_search_url_text_normal = 2131034126;
    
    public static final int abc_search_url_text_pressed = 2131034127;
    
    public static final int abc_search_url_text_selected = 2131034128;
    
    public static final int abc_secondary_text_material_dark = 2131034129;
    
    public static final int abc_secondary_text_material_light = 2131034130;
    
    public static final int abc_tint_btn_checkable = 2131034131;
    
    public static final int abc_tint_default = 2131034132;
    
    public static final int abc_tint_edittext = 2131034133;
    
    public static final int abc_tint_seek_thumb = 2131034134;
    
    public static final int abc_tint_spinner = 2131034135;
    
    public static final int abc_tint_switch_track = 2131034136;
    
    public static final int accent_material_dark = 2131034137;
    
    public static final int accent_material_light = 2131034138;
    
    public static final int androidx_core_ripple_material_light = 2131034139;
    
    public static final int androidx_core_secondary_text_default_material_light = 2131034140;
    
    public static final int background_floating_material_dark = 2131034141;
    
    public static final int background_floating_material_light = 2131034142;
    
    public static final int background_material_dark = 2131034143;
    
    public static final int background_material_light = 2131034144;
    
    public static final int bright_foreground_disabled_material_dark = 2131034146;
    
    public static final int bright_foreground_disabled_material_light = 2131034147;
    
    public static final int bright_foreground_inverse_material_dark = 2131034148;
    
    public static final int bright_foreground_inverse_material_light = 2131034149;
    
    public static final int bright_foreground_material_dark = 2131034150;
    
    public static final int bright_foreground_material_light = 2131034151;
    
    public static final int button_material_dark = 2131034156;
    
    public static final int button_material_light = 2131034157;
    
    public static final int dim_foreground_disabled_material_dark = 2131034201;
    
    public static final int dim_foreground_disabled_material_light = 2131034202;
    
    public static final int dim_foreground_material_dark = 2131034203;
    
    public static final int dim_foreground_material_light = 2131034204;
    
    public static final int error_color_material_dark = 2131034205;
    
    public static final int error_color_material_light = 2131034206;
    
    public static final int foreground_material_dark = 2131034207;
    
    public static final int foreground_material_light = 2131034208;
    
    public static final int highlighted_text_material_dark = 2131034209;
    
    public static final int highlighted_text_material_light = 2131034210;
    
    public static final int material_blue_grey_800 = 2131034211;
    
    public static final int material_blue_grey_900 = 2131034212;
    
    public static final int material_blue_grey_950 = 2131034213;
    
    public static final int material_deep_teal_200 = 2131034215;
    
    public static final int material_deep_teal_500 = 2131034216;
    
    public static final int material_grey_100 = 2131034217;
    
    public static final int material_grey_300 = 2131034218;
    
    public static final int material_grey_50 = 2131034219;
    
    public static final int material_grey_600 = 2131034220;
    
    public static final int material_grey_800 = 2131034221;
    
    public static final int material_grey_850 = 2131034222;
    
    public static final int material_grey_900 = 2131034223;
    
    public static final int notification_action_color_filter = 2131034296;
    
    public static final int notification_icon_bg_color = 2131034297;
    
    public static final int primary_dark_material_dark = 2131034298;
    
    public static final int primary_dark_material_light = 2131034299;
    
    public static final int primary_material_dark = 2131034300;
    
    public static final int primary_material_light = 2131034301;
    
    public static final int primary_text_default_material_dark = 2131034302;
    
    public static final int primary_text_default_material_light = 2131034303;
    
    public static final int primary_text_disabled_material_dark = 2131034304;
    
    public static final int primary_text_disabled_material_light = 2131034305;
    
    public static final int ripple_material_dark = 2131034310;
    
    public static final int ripple_material_light = 2131034311;
    
    public static final int secondary_text_default_material_dark = 2131034312;
    
    public static final int secondary_text_default_material_light = 2131034313;
    
    public static final int secondary_text_disabled_material_dark = 2131034314;
    
    public static final int secondary_text_disabled_material_light = 2131034315;
    
    public static final int switch_thumb_disabled_material_dark = 2131034316;
    
    public static final int switch_thumb_disabled_material_light = 2131034317;
    
    public static final int switch_thumb_material_dark = 2131034318;
    
    public static final int switch_thumb_material_light = 2131034319;
    
    public static final int switch_thumb_normal_material_dark = 2131034320;
    
    public static final int switch_thumb_normal_material_light = 2131034321;
    
    public static final int tooltip_background_dark = 2131034326;
    
    public static final int tooltip_background_light = 2131034327;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131099648;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131099649;
    
    public static final int abc_action_bar_default_height_material = 2131099650;
    
    public static final int abc_action_bar_default_padding_end_material = 2131099651;
    
    public static final int abc_action_bar_default_padding_start_material = 2131099652;
    
    public static final int abc_action_bar_elevation_material = 2131099653;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131099655;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131099656;
    
    public static final int abc_action_bar_stacked_max_height = 2131099657;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131099658;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;
    
    public static final int abc_action_button_min_height_material = 2131099661;
    
    public static final int abc_action_button_min_width_material = 2131099662;
    
    public static final int abc_action_button_min_width_overflow_material = 2131099663;
    
    public static final int abc_alert_dialog_button_bar_height = 2131099664;
    
    public static final int abc_alert_dialog_button_dimen = 2131099665;
    
    public static final int abc_button_inset_horizontal_material = 2131099666;
    
    public static final int abc_button_inset_vertical_material = 2131099667;
    
    public static final int abc_button_padding_horizontal_material = 2131099668;
    
    public static final int abc_button_padding_vertical_material = 2131099669;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131099670;
    
    public static final int abc_config_prefDialogWidth = 2131099671;
    
    public static final int abc_control_corner_material = 2131099672;
    
    public static final int abc_control_inset_material = 2131099673;
    
    public static final int abc_control_padding_material = 2131099674;
    
    public static final int abc_dialog_corner_radius_material = 2131099675;
    
    public static final int abc_dialog_fixed_height_major = 2131099676;
    
    public static final int abc_dialog_fixed_height_minor = 2131099677;
    
    public static final int abc_dialog_fixed_width_major = 2131099678;
    
    public static final int abc_dialog_fixed_width_minor = 2131099679;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131099681;
    
    public static final int abc_dialog_min_width_major = 2131099682;
    
    public static final int abc_dialog_min_width_minor = 2131099683;
    
    public static final int abc_dialog_padding_material = 2131099684;
    
    public static final int abc_dialog_padding_top_material = 2131099685;
    
    public static final int abc_dialog_title_divider_material = 2131099686;
    
    public static final int abc_disabled_alpha_material_dark = 2131099687;
    
    public static final int abc_disabled_alpha_material_light = 2131099688;
    
    public static final int abc_dropdownitem_icon_width = 2131099689;
    
    public static final int abc_dropdownitem_text_padding_left = 2131099690;
    
    public static final int abc_dropdownitem_text_padding_right = 2131099691;
    
    public static final int abc_edit_text_inset_bottom_material = 2131099692;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131099693;
    
    public static final int abc_edit_text_inset_top_material = 2131099694;
    
    public static final int abc_floating_window_z = 2131099695;
    
    public static final int abc_list_item_height_large_material = 2131099696;
    
    public static final int abc_list_item_height_material = 2131099697;
    
    public static final int abc_list_item_height_small_material = 2131099698;
    
    public static final int abc_list_item_padding_horizontal_material = 2131099699;
    
    public static final int abc_panel_menu_list_width = 2131099700;
    
    public static final int abc_progress_bar_height_material = 2131099701;
    
    public static final int abc_search_view_preferred_height = 2131099702;
    
    public static final int abc_search_view_preferred_width = 2131099703;
    
    public static final int abc_seekbar_track_background_height_material = 2131099704;
    
    public static final int abc_seekbar_track_progress_height_material = 2131099705;
    
    public static final int abc_select_dialog_padding_start_material = 2131099706;
    
    public static final int abc_switch_padding = 2131099710;
    
    public static final int abc_text_size_body_1_material = 2131099711;
    
    public static final int abc_text_size_body_2_material = 2131099712;
    
    public static final int abc_text_size_button_material = 2131099713;
    
    public static final int abc_text_size_caption_material = 2131099714;
    
    public static final int abc_text_size_display_1_material = 2131099715;
    
    public static final int abc_text_size_display_2_material = 2131099716;
    
    public static final int abc_text_size_display_3_material = 2131099717;
    
    public static final int abc_text_size_display_4_material = 2131099718;
    
    public static final int abc_text_size_headline_material = 2131099719;
    
    public static final int abc_text_size_large_material = 2131099720;
    
    public static final int abc_text_size_medium_material = 2131099721;
    
    public static final int abc_text_size_menu_header_material = 2131099722;
    
    public static final int abc_text_size_menu_material = 2131099723;
    
    public static final int abc_text_size_small_material = 2131099724;
    
    public static final int abc_text_size_subhead_material = 2131099725;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131099726;
    
    public static final int abc_text_size_title_material = 2131099727;
    
    public static final int abc_text_size_title_material_toolbar = 2131099728;
    
    public static final int compat_button_inset_horizontal_material = 2131099739;
    
    public static final int compat_button_inset_vertical_material = 2131099740;
    
    public static final int compat_button_padding_horizontal_material = 2131099741;
    
    public static final int compat_button_padding_vertical_material = 2131099742;
    
    public static final int compat_control_corner_material = 2131099743;
    
    public static final int compat_notification_large_icon_max_height = 2131099744;
    
    public static final int compat_notification_large_icon_max_width = 2131099745;
    
    public static final int disabled_alpha_material_dark = 2131099794;
    
    public static final int disabled_alpha_material_light = 2131099795;
    
    public static final int highlight_alpha_material_colored = 2131099799;
    
    public static final int highlight_alpha_material_dark = 2131099800;
    
    public static final int highlight_alpha_material_light = 2131099801;
    
    public static final int hint_alpha_material_dark = 2131099802;
    
    public static final int hint_alpha_material_light = 2131099803;
    
    public static final int hint_pressed_alpha_material_dark = 2131099804;
    
    public static final int hint_pressed_alpha_material_light = 2131099805;
    
    public static final int notification_action_icon_size = 2131100039;
    
    public static final int notification_action_text_size = 2131100040;
    
    public static final int notification_big_circle_margin = 2131100041;
    
    public static final int notification_content_margin_start = 2131100042;
    
    public static final int notification_large_icon_height = 2131100043;
    
    public static final int notification_large_icon_width = 2131100044;
    
    public static final int notification_main_column_padding_top = 2131100045;
    
    public static final int notification_media_narrow_margin = 2131100046;
    
    public static final int notification_right_icon_size = 2131100047;
    
    public static final int notification_right_side_padding_top = 2131100048;
    
    public static final int notification_small_icon_background_padding = 2131100049;
    
    public static final int notification_small_icon_size_as_large = 2131100050;
    
    public static final int notification_subtext_size = 2131100051;
    
    public static final int notification_top_pad = 2131100052;
    
    public static final int notification_top_pad_large_text = 2131100053;
    
    public static final int tooltip_corner_radius = 2131100066;
    
    public static final int tooltip_horizontal_padding = 2131100067;
    
    public static final int tooltip_margin = 2131100068;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131100069;
    
    public static final int tooltip_precise_anchor_threshold = 2131100070;
    
    public static final int tooltip_vertical_padding = 2131100071;
    
    public static final int tooltip_y_offset_non_touch = 2131100072;
    
    public static final int tooltip_y_offset_touch = 2131100073;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131165191;
    
    public static final int abc_action_bar_item_background_material = 2131165192;
    
    public static final int abc_btn_borderless_material = 2131165193;
    
    public static final int abc_btn_check_material = 2131165194;
    
    public static final int abc_btn_check_material_anim = 2131165195;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131165196;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131165197;
    
    public static final int abc_btn_colored_material = 2131165198;
    
    public static final int abc_btn_default_mtrl_shape = 2131165199;
    
    public static final int abc_btn_radio_material = 2131165200;
    
    public static final int abc_btn_radio_material_anim = 2131165201;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131165202;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131165203;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131165204;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131165205;
    
    public static final int abc_cab_background_internal_bg = 2131165206;
    
    public static final int abc_cab_background_top_material = 2131165207;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131165208;
    
    public static final int abc_control_background_material = 2131165209;
    
    public static final int abc_dialog_material_background = 2131165210;
    
    public static final int abc_edit_text_material = 2131165211;
    
    public static final int abc_ic_ab_back_material = 2131165212;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131165213;
    
    public static final int abc_ic_clear_material = 2131165214;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131165215;
    
    public static final int abc_ic_go_search_api_material = 2131165216;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165217;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131165218;
    
    public static final int abc_ic_menu_overflow_material = 2131165219;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165220;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165221;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131165222;
    
    public static final int abc_ic_search_api_material = 2131165223;
    
    public static final int abc_ic_voice_search_api_material = 2131165224;
    
    public static final int abc_item_background_holo_dark = 2131165225;
    
    public static final int abc_item_background_holo_light = 2131165226;
    
    public static final int abc_list_divider_material = 2131165227;
    
    public static final int abc_list_divider_mtrl_alpha = 2131165228;
    
    public static final int abc_list_focused_holo = 2131165229;
    
    public static final int abc_list_longpressed_holo = 2131165230;
    
    public static final int abc_list_pressed_holo_dark = 2131165231;
    
    public static final int abc_list_pressed_holo_light = 2131165232;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131165233;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131165234;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131165235;
    
    public static final int abc_list_selector_disabled_holo_light = 2131165236;
    
    public static final int abc_list_selector_holo_dark = 2131165237;
    
    public static final int abc_list_selector_holo_light = 2131165238;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131165239;
    
    public static final int abc_popup_background_mtrl_mult = 2131165240;
    
    public static final int abc_ratingbar_indicator_material = 2131165241;
    
    public static final int abc_ratingbar_material = 2131165242;
    
    public static final int abc_ratingbar_small_material = 2131165243;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131165244;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131165245;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131165246;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131165247;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131165248;
    
    public static final int abc_seekbar_thumb_material = 2131165249;
    
    public static final int abc_seekbar_tick_mark_material = 2131165250;
    
    public static final int abc_seekbar_track_material = 2131165251;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131165252;
    
    public static final int abc_spinner_textfield_background_material = 2131165253;
    
    public static final int abc_switch_thumb_material = 2131165256;
    
    public static final int abc_switch_track_mtrl_alpha = 2131165257;
    
    public static final int abc_tab_indicator_material = 2131165258;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131165259;
    
    public static final int abc_text_cursor_material = 2131165260;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131165264;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131165265;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131165266;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131165267;
    
    public static final int abc_textfield_search_material = 2131165268;
    
    public static final int abc_vector_test = 2131165269;
    
    public static final int btn_checkbox_checked_mtrl = 2131165272;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131165273;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131165274;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131165275;
    
    public static final int btn_radio_off_mtrl = 2131165276;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131165277;
    
    public static final int btn_radio_on_mtrl = 2131165278;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131165279;
    
    public static final int notification_action_background = 2131165315;
    
    public static final int notification_bg = 2131165316;
    
    public static final int notification_bg_low = 2131165317;
    
    public static final int notification_bg_low_normal = 2131165318;
    
    public static final int notification_bg_low_pressed = 2131165319;
    
    public static final int notification_bg_normal = 2131165320;
    
    public static final int notification_bg_normal_pressed = 2131165321;
    
    public static final int notification_icon_background = 2131165322;
    
    public static final int notification_template_icon_bg = 2131165323;
    
    public static final int notification_template_icon_low_bg = 2131165324;
    
    public static final int notification_tile_bg = 2131165325;
    
    public static final int notify_panel_notification_icon_bg = 2131165326;
    
    public static final int tooltip_frame_dark = 2131165330;
    
    public static final int tooltip_frame_light = 2131165331;
  }
  
  public static final class id {
    public static final int NO_DEBUG = 2131230726;
    
    public static final int SHOW_ALL = 2131230728;
    
    public static final int SHOW_PATH = 2131230729;
    
    public static final int SHOW_PROGRESS = 2131230730;
    
    public static final int accelerate = 2131230734;
    
    public static final int accessibility_action_clickable_span = 2131230735;
    
    public static final int accessibility_custom_action_0 = 2131230736;
    
    public static final int accessibility_custom_action_1 = 2131230737;
    
    public static final int accessibility_custom_action_10 = 2131230738;
    
    public static final int accessibility_custom_action_11 = 2131230739;
    
    public static final int accessibility_custom_action_12 = 2131230740;
    
    public static final int accessibility_custom_action_13 = 2131230741;
    
    public static final int accessibility_custom_action_14 = 2131230742;
    
    public static final int accessibility_custom_action_15 = 2131230743;
    
    public static final int accessibility_custom_action_16 = 2131230744;
    
    public static final int accessibility_custom_action_17 = 2131230745;
    
    public static final int accessibility_custom_action_18 = 2131230746;
    
    public static final int accessibility_custom_action_19 = 2131230747;
    
    public static final int accessibility_custom_action_2 = 2131230748;
    
    public static final int accessibility_custom_action_20 = 2131230749;
    
    public static final int accessibility_custom_action_21 = 2131230750;
    
    public static final int accessibility_custom_action_22 = 2131230751;
    
    public static final int accessibility_custom_action_23 = 2131230752;
    
    public static final int accessibility_custom_action_24 = 2131230753;
    
    public static final int accessibility_custom_action_25 = 2131230754;
    
    public static final int accessibility_custom_action_26 = 2131230755;
    
    public static final int accessibility_custom_action_27 = 2131230756;
    
    public static final int accessibility_custom_action_28 = 2131230757;
    
    public static final int accessibility_custom_action_29 = 2131230758;
    
    public static final int accessibility_custom_action_3 = 2131230759;
    
    public static final int accessibility_custom_action_30 = 2131230760;
    
    public static final int accessibility_custom_action_31 = 2131230761;
    
    public static final int accessibility_custom_action_4 = 2131230762;
    
    public static final int accessibility_custom_action_5 = 2131230763;
    
    public static final int accessibility_custom_action_6 = 2131230764;
    
    public static final int accessibility_custom_action_7 = 2131230765;
    
    public static final int accessibility_custom_action_8 = 2131230766;
    
    public static final int accessibility_custom_action_9 = 2131230767;
    
    public static final int action_bar = 2131230768;
    
    public static final int action_bar_activity_content = 2131230769;
    
    public static final int action_bar_container = 2131230770;
    
    public static final int action_bar_root = 2131230771;
    
    public static final int action_bar_spinner = 2131230772;
    
    public static final int action_bar_subtitle = 2131230773;
    
    public static final int action_bar_title = 2131230774;
    
    public static final int action_container = 2131230775;
    
    public static final int action_context_bar = 2131230776;
    
    public static final int action_divider = 2131230777;
    
    public static final int action_image = 2131230778;
    
    public static final int action_menu_divider = 2131230779;
    
    public static final int action_menu_presenter = 2131230780;
    
    public static final int action_mode_bar = 2131230781;
    
    public static final int action_mode_bar_stub = 2131230782;
    
    public static final int action_mode_close_button = 2131230783;
    
    public static final int action_text = 2131230784;
    
    public static final int actions = 2131230785;
    
    public static final int activity_chooser_view_content = 2131230786;
    
    public static final int add = 2131230788;
    
    public static final int alertTitle = 2131230789;
    
    public static final int aligned = 2131230790;
    
    public static final int animateToEnd = 2131230793;
    
    public static final int animateToStart = 2131230794;
    
    public static final int asConfigured = 2131230796;
    
    public static final int async = 2131230797;
    
    public static final int autoComplete = 2131230799;
    
    public static final int autoCompleteToEnd = 2131230800;
    
    public static final int autoCompleteToStart = 2131230801;
    
    public static final int baseline = 2131230803;
    
    public static final int blocking = 2131230806;
    
    public static final int bottom = 2131230807;
    
    public static final int bounce = 2131230808;
    
    public static final int buttonPanel = 2131230814;
    
    public static final int center = 2131230816;
    
    public static final int chain = 2131230819;
    
    public static final int checkbox = 2131230821;
    
    public static final int checked = 2131230822;
    
    public static final int chronometer = 2131230828;
    
    public static final int content = 2131230837;
    
    public static final int contentPanel = 2131230838;
    
    public static final int cos = 2131230841;
    
    public static final int custom = 2131230843;
    
    public static final int customPanel = 2131230844;
    
    public static final int decelerate = 2131230847;
    
    public static final int decelerateAndComplete = 2131230848;
    
    public static final int decor_content_parent = 2131230849;
    
    public static final int default_activity_button = 2131230850;
    
    public static final int deltaRelative = 2131230851;
    
    public static final int dialog_button = 2131230857;
    
    public static final int dragDown = 2131230864;
    
    public static final int dragEnd = 2131230865;
    
    public static final int dragLeft = 2131230866;
    
    public static final int dragRight = 2131230867;
    
    public static final int dragStart = 2131230868;
    
    public static final int dragUp = 2131230869;
    
    public static final int easeIn = 2131230871;
    
    public static final int easeInOut = 2131230872;
    
    public static final int easeOut = 2131230873;
    
    public static final int edit_query = 2131230874;
    
    public static final int end = 2131230876;
    
    public static final int expand_activities_button = 2131230881;
    
    public static final int expanded_menu = 2131230882;
    
    public static final int flip = 2131230890;
    
    public static final int forever = 2131230892;
    
    public static final int gone = 2131230896;
    
    public static final int group_divider = 2131230899;
    
    public static final int home = 2131230904;
    
    public static final int honorRequest = 2131230906;
    
    public static final int icon = 2131230907;
    
    public static final int icon_group = 2131230908;
    
    public static final int ignore = 2131230910;
    
    public static final int ignoreRequest = 2131230911;
    
    public static final int image = 2131230912;
    
    public static final int info = 2131230915;
    
    public static final int invisible = 2131230916;
    
    public static final int italic = 2131230918;
    
    public static final int jumpToEnd = 2131230920;
    
    public static final int jumpToStart = 2131230921;
    
    public static final int layout = 2131230923;
    
    public static final int left = 2131230924;
    
    public static final int line1 = 2131230926;
    
    public static final int line3 = 2131230927;
    
    public static final int linear = 2131230928;
    
    public static final int listMode = 2131230929;
    
    public static final int list_item = 2131230930;
    
    public static final int message = 2131230951;
    
    public static final int middle = 2131230952;
    
    public static final int motion_base = 2131230960;
    
    public static final int multiply = 2131230984;
    
    public static final int none = 2131230993;
    
    public static final int normal = 2131230994;
    
    public static final int notification_background = 2131230995;
    
    public static final int notification_main_column = 2131230996;
    
    public static final int notification_main_column_container = 2131230997;
    
    public static final int off = 2131230998;
    
    public static final int on = 2131230999;
    
    public static final int packed = 2131231002;
    
    public static final int parent = 2131231004;
    
    public static final int parentPanel = 2131231005;
    
    public static final int parentRelative = 2131231006;
    
    public static final int path = 2131231009;
    
    public static final int pathRelative = 2131231010;
    
    public static final int percent = 2131231012;
    
    public static final int position = 2131231014;
    
    public static final int postLayout = 2131231015;
    
    public static final int progress_circular = 2131231016;
    
    public static final int progress_horizontal = 2131231017;
    
    public static final int radio = 2131231018;
    
    public static final int rectangles = 2131231020;
    
    public static final int reverseSawtooth = 2131231021;
    
    public static final int right = 2131231022;
    
    public static final int right_icon = 2131231024;
    
    public static final int right_side = 2131231025;
    
    public static final int sawtooth = 2131231030;
    
    public static final int screen = 2131231032;
    
    public static final int scrollIndicatorDown = 2131231034;
    
    public static final int scrollIndicatorUp = 2131231035;
    
    public static final int scrollView = 2131231036;
    
    public static final int search_badge = 2131231038;
    
    public static final int search_bar = 2131231039;
    
    public static final int search_button = 2131231040;
    
    public static final int search_close_btn = 2131231041;
    
    public static final int search_edit_frame = 2131231042;
    
    public static final int search_go_btn = 2131231043;
    
    public static final int search_mag_icon = 2131231044;
    
    public static final int search_plate = 2131231045;
    
    public static final int search_src_text = 2131231046;
    
    public static final int search_voice_btn = 2131231047;
    
    public static final int select_dialog_listview = 2131231048;
    
    public static final int shortcut = 2131231051;
    
    public static final int sin = 2131231055;
    
    public static final int spacer = 2131231062;
    
    public static final int spline = 2131231064;
    
    public static final int split_action_bar = 2131231065;
    
    public static final int spread = 2131231066;
    
    public static final int spread_inside = 2131231067;
    
    public static final int square = 2131231068;
    
    public static final int src_atop = 2131231069;
    
    public static final int src_in = 2131231070;
    
    public static final int src_over = 2131231071;
    
    public static final int standard = 2131231072;
    
    public static final int start = 2131231073;
    
    public static final int startHorizontal = 2131231074;
    
    public static final int startVertical = 2131231076;
    
    public static final int staticLayout = 2131231077;
    
    public static final int staticPostLayout = 2131231078;
    
    public static final int stop = 2131231079;
    
    public static final int submenuarrow = 2131231081;
    
    public static final int submit_area = 2131231082;
    
    public static final int tabMode = 2131231083;
    
    public static final int tag_accessibility_actions = 2131231084;
    
    public static final int tag_accessibility_clickable_spans = 2131231085;
    
    public static final int tag_accessibility_heading = 2131231086;
    
    public static final int tag_accessibility_pane_title = 2131231087;
    
    public static final int tag_screen_reader_focusable = 2131231091;
    
    public static final int tag_transition_group = 2131231093;
    
    public static final int tag_unhandled_key_event_manager = 2131231094;
    
    public static final int tag_unhandled_key_listeners = 2131231095;
    
    public static final int text = 2131231101;
    
    public static final int text2 = 2131231102;
    
    public static final int textSpacerNoButtons = 2131231104;
    
    public static final int textSpacerNoTitle = 2131231105;
    
    public static final int time = 2131231118;
    
    public static final int title = 2131231119;
    
    public static final int titleDividerNoCustom = 2131231120;
    
    public static final int title_template = 2131231121;
    
    public static final int top = 2131231123;
    
    public static final int topPanel = 2131231124;
    
    public static final int triangle = 2131231133;
    
    public static final int unchecked = 2131231134;
    
    public static final int uniform = 2131231135;
    
    public static final int up = 2131231137;
    
    public static final int visible = 2131231144;
    
    public static final int wrap = 2131231148;
    
    public static final int wrap_content = 2131231149;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131296256;
    
    public static final int abc_config_activityShortDur = 2131296257;
    
    public static final int cancel_button_image_alpha = 2131296260;
    
    public static final int config_tooltipAnimTime = 2131296261;
    
    public static final int status_bar_notification_info_maxnum = 2131296284;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131361792;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131361793;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131361794;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131361795;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131361796;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131361797;
    
    public static final int fast_out_slow_in = 2131361798;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131427328;
    
    public static final int abc_action_bar_up_container = 2131427329;
    
    public static final int abc_action_menu_item_layout = 2131427330;
    
    public static final int abc_action_menu_layout = 2131427331;
    
    public static final int abc_action_mode_bar = 2131427332;
    
    public static final int abc_action_mode_close_item_material = 2131427333;
    
    public static final int abc_activity_chooser_view = 2131427334;
    
    public static final int abc_activity_chooser_view_list_item = 2131427335;
    
    public static final int abc_alert_dialog_button_bar_material = 2131427336;
    
    public static final int abc_alert_dialog_material = 2131427337;
    
    public static final int abc_alert_dialog_title_material = 2131427338;
    
    public static final int abc_cascading_menu_item_layout = 2131427339;
    
    public static final int abc_dialog_title_material = 2131427340;
    
    public static final int abc_expanded_menu_layout = 2131427341;
    
    public static final int abc_list_menu_item_checkbox = 2131427342;
    
    public static final int abc_list_menu_item_icon = 2131427343;
    
    public static final int abc_list_menu_item_layout = 2131427344;
    
    public static final int abc_list_menu_item_radio = 2131427345;
    
    public static final int abc_popup_menu_header_item_layout = 2131427346;
    
    public static final int abc_popup_menu_item_layout = 2131427347;
    
    public static final int abc_screen_content_include = 2131427348;
    
    public static final int abc_screen_simple = 2131427349;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131427350;
    
    public static final int abc_screen_toolbar = 2131427351;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131427352;
    
    public static final int abc_search_view = 2131427353;
    
    public static final int abc_select_dialog_material = 2131427354;
    
    public static final int abc_tooltip = 2131427355;
    
    public static final int custom_dialog = 2131427359;
    
    public static final int notification_action = 2131427418;
    
    public static final int notification_action_tombstone = 2131427419;
    
    public static final int notification_template_custom_big = 2131427420;
    
    public static final int notification_template_icon_group = 2131427421;
    
    public static final int notification_template_part_chronometer = 2131427422;
    
    public static final int notification_template_part_time = 2131427423;
    
    public static final int select_dialog_item_material = 2131427424;
    
    public static final int select_dialog_multichoice_material = 2131427425;
    
    public static final int select_dialog_singlechoice_material = 2131427426;
    
    public static final int support_simple_spinner_dropdown_item = 2131427427;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131623937;
    
    public static final int abc_action_bar_up_description = 2131623938;
    
    public static final int abc_action_menu_overflow_description = 2131623939;
    
    public static final int abc_action_mode_done = 2131623940;
    
    public static final int abc_activity_chooser_view_see_all = 2131623941;
    
    public static final int abc_activitychooserview_choose_application = 2131623942;
    
    public static final int abc_capital_off = 2131623943;
    
    public static final int abc_capital_on = 2131623944;
    
    public static final int abc_menu_alt_shortcut_label = 2131623945;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131623946;
    
    public static final int abc_menu_delete_shortcut_label = 2131623947;
    
    public static final int abc_menu_enter_shortcut_label = 2131623948;
    
    public static final int abc_menu_function_shortcut_label = 2131623949;
    
    public static final int abc_menu_meta_shortcut_label = 2131623950;
    
    public static final int abc_menu_shift_shortcut_label = 2131623951;
    
    public static final int abc_menu_space_shortcut_label = 2131623952;
    
    public static final int abc_menu_sym_shortcut_label = 2131623953;
    
    public static final int abc_prepend_shortcut_label = 2131623954;
    
    public static final int abc_search_hint = 2131623955;
    
    public static final int abc_searchview_description_clear = 2131623956;
    
    public static final int abc_searchview_description_query = 2131623957;
    
    public static final int abc_searchview_description_search = 2131623958;
    
    public static final int abc_searchview_description_submit = 2131623959;
    
    public static final int abc_searchview_description_voice = 2131623960;
    
    public static final int abc_shareactionprovider_share_with = 2131623961;
    
    public static final int abc_shareactionprovider_share_with_application = 2131623962;
    
    public static final int abc_toolbar_collapse_description = 2131623963;
    
    public static final int search_menu_title = 2131624063;
    
    public static final int status_bar_notification_info_overflow = 2131624064;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2131689472;
    
    public static final int AlertDialog_AppCompat_Light = 2131689473;
    
    public static final int Animation_AppCompat_Dialog = 2131689475;
    
    public static final int Animation_AppCompat_DropDownUp = 2131689476;
    
    public static final int Animation_AppCompat_Tooltip = 2131689477;
    
    public static final int Base_AlertDialog_AppCompat = 2131689480;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131689481;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131689482;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131689483;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2131689484;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131689487;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131689486;
    
    public static final int Base_TextAppearance_AppCompat = 2131689491;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131689492;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131689493;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131689494;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131689495;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131689496;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131689497;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131689498;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131689499;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131689500;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131689501;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131689502;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131689503;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131689504;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131689505;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131689506;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131689507;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131689508;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131689509;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131689510;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131689511;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131689512;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131689513;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131689514;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131689515;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131689516;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131689517;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2131689518;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131689519;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131689520;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131689521;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131689522;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131689523;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131689524;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131689525;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131689526;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131689527;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131689528;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131689529;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131689530;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131689531;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131689532;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131689533;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131689534;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131689535;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131689540;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131689541;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131689542;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131689576;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131689577;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131689578;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131689579;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131689580;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131689581;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131689582;
    
    public static final int Base_Theme_AppCompat = 2131689543;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131689544;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131689545;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131689549;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131689546;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131689547;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131689548;
    
    public static final int Base_Theme_AppCompat_Light = 2131689550;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131689551;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131689552;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131689556;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131689553;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131689554;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131689555;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131689609;
    
    public static final int Base_V21_Theme_AppCompat = 2131689601;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131689602;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131689603;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131689604;
    
    public static final int Base_V22_Theme_AppCompat = 2131689611;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131689612;
    
    public static final int Base_V23_Theme_AppCompat = 2131689613;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131689614;
    
    public static final int Base_V26_Theme_AppCompat = 2131689615;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2131689616;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2131689617;
    
    public static final int Base_V28_Theme_AppCompat = 2131689618;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2131689619;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131689624;
    
    public static final int Base_V7_Theme_AppCompat = 2131689620;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131689621;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131689622;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131689623;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131689625;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131689626;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2131689627;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131689628;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131689629;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131689630;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131689631;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131689632;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131689633;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131689634;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131689635;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131689636;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131689637;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131689638;
    
    public static final int Base_Widget_AppCompat_Button = 2131689639;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131689645;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131689646;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131689640;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131689641;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131689642;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131689643;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131689644;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131689647;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131689648;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131689649;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131689650;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131689651;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131689652;
    
    public static final int Base_Widget_AppCompat_EditText = 2131689653;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131689654;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131689655;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131689656;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131689657;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131689658;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131689659;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131689660;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131689661;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131689662;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2131689663;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131689664;
    
    public static final int Base_Widget_AppCompat_ListView = 2131689665;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131689666;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131689667;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131689668;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131689669;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131689670;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131689671;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131689672;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131689673;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131689674;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131689675;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131689676;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131689677;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131689678;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131689679;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131689680;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131689681;
    
    public static final int Base_Widget_AppCompat_TextView = 2131689682;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131689683;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131689684;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131689685;
    
    public static final int Platform_AppCompat = 2131689714;
    
    public static final int Platform_AppCompat_Light = 2131689715;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131689720;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131689721;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131689722;
    
    public static final int Platform_V21_AppCompat = 2131689723;
    
    public static final int Platform_V21_AppCompat_Light = 2131689724;
    
    public static final int Platform_V25_AppCompat = 2131689725;
    
    public static final int Platform_V25_AppCompat_Light = 2131689726;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131689727;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131689728;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131689729;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131689730;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131689731;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131689732;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131689733;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131689734;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131689735;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131689736;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131689742;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131689737;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131689738;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131689739;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131689740;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131689741;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131689743;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131689744;
    
    public static final int TextAppearance_AppCompat = 2131689777;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131689778;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131689779;
    
    public static final int TextAppearance_AppCompat_Button = 2131689780;
    
    public static final int TextAppearance_AppCompat_Caption = 2131689781;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131689782;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131689783;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131689784;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131689785;
    
    public static final int TextAppearance_AppCompat_Headline = 2131689786;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131689787;
    
    public static final int TextAppearance_AppCompat_Large = 2131689788;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131689789;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131689790;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131689791;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131689792;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131689793;
    
    public static final int TextAppearance_AppCompat_Medium = 2131689794;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131689795;
    
    public static final int TextAppearance_AppCompat_Menu = 2131689796;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131689797;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131689798;
    
    public static final int TextAppearance_AppCompat_Small = 2131689799;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131689800;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131689801;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131689802;
    
    public static final int TextAppearance_AppCompat_Title = 2131689803;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131689804;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2131689805;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131689806;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131689807;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131689808;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131689809;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131689810;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131689811;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131689812;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131689813;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131689814;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131689815;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131689816;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131689817;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131689818;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131689819;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131689820;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131689821;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131689822;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131689823;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131689824;
    
    public static final int TextAppearance_Compat_Notification = 2131689825;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131689826;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131689827;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131689828;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131689829;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131689858;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131689859;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131689860;
    
    public static final int ThemeOverlay_AppCompat = 2131689940;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131689941;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131689942;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131689943;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2131689944;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131689945;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2131689946;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131689947;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131689948;
    
    public static final int Theme_AppCompat = 2131689861;
    
    public static final int Theme_AppCompat_CompactMenu = 2131689862;
    
    public static final int Theme_AppCompat_DayNight = 2131689863;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131689864;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131689865;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131689868;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131689866;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131689867;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131689869;
    
    public static final int Theme_AppCompat_Dialog = 2131689870;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131689873;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131689871;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131689872;
    
    public static final int Theme_AppCompat_Empty = 2131689874;
    
    public static final int Theme_AppCompat_Light = 2131689875;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131689876;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131689877;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131689880;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131689878;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131689879;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131689881;
    
    public static final int Theme_AppCompat_NoActionBar = 2131689882;
    
    public static final int Widget_AppCompat_ActionBar = 2131689989;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131689990;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131689991;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131689992;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131689993;
    
    public static final int Widget_AppCompat_ActionButton = 2131689994;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131689995;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131689996;
    
    public static final int Widget_AppCompat_ActionMode = 2131689997;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131689998;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131689999;
    
    public static final int Widget_AppCompat_Button = 2131690000;
    
    public static final int Widget_AppCompat_ButtonBar = 2131690006;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131690007;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131690001;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131690002;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131690003;
    
    public static final int Widget_AppCompat_Button_Colored = 2131690004;
    
    public static final int Widget_AppCompat_Button_Small = 2131690005;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131690008;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131690009;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131690010;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131690011;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131690012;
    
    public static final int Widget_AppCompat_EditText = 2131690013;
    
    public static final int Widget_AppCompat_ImageButton = 2131690014;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131690015;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131690016;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131690017;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131690018;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131690019;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131690020;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131690021;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131690022;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131690023;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131690024;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131690025;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131690026;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131690027;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131690028;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131690029;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131690030;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131690031;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131690032;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131690033;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131690034;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131690035;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131690036;
    
    public static final int Widget_AppCompat_ListMenuView = 2131690037;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131690038;
    
    public static final int Widget_AppCompat_ListView = 2131690039;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131690040;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131690041;
    
    public static final int Widget_AppCompat_PopupMenu = 2131690042;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131690043;
    
    public static final int Widget_AppCompat_PopupWindow = 2131690044;
    
    public static final int Widget_AppCompat_ProgressBar = 2131690045;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131690046;
    
    public static final int Widget_AppCompat_RatingBar = 2131690047;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131690048;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131690049;
    
    public static final int Widget_AppCompat_SearchView = 2131690050;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131690051;
    
    public static final int Widget_AppCompat_SeekBar = 2131690052;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2131690053;
    
    public static final int Widget_AppCompat_Spinner = 2131690054;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131690055;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131690056;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131690057;
    
    public static final int Widget_AppCompat_TextView = 2131690058;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131690059;
    
    public static final int Widget_AppCompat_Toolbar = 2131690060;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131690061;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131690062;
    
    public static final int Widget_Compat_NotificationActionText = 2131690063;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130903103, 2130903110, 2130903111, 2130903253, 2130903254, 2130903255, 2130903256, 2130903257, 2130903258, 2130903296, 
        2130903312, 2130903313, 2130903337, 2130903424, 2130903431, 2130903437, 2130903438, 2130903441, 2130903452, 2130903470, 
        2130903579, 2130903657, 2130903702, 2130903709, 2130903710, 2130903787, 2130903791, 2130903881, 2130903893 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMode = new int[] { 2130903103, 2130903110, 2130903216, 2130903424, 2130903791, 2130903893 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130903357, 2130903458 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130903157, 2130903158, 2130903568, 2130903569, 2130903653, 2130903751, 2130903753 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130903766, 2130903879, 2130903880 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130903875, 2130903876, 2130903877 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130903097, 2130903098, 2130903099, 2130903100, 2130903101, 2130903321, 2130903322, 2130903323, 2130903324, 
        2130903326, 2130903327, 2130903328, 2130903329, 2130903382, 2130903404, 2130903413, 2130903492, 2130903561, 2130903831, 
        2130903859 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 14;
    
    public static final int AppCompatTextView_fontFamily = 15;
    
    public static final int AppCompatTextView_fontVariationSettings = 16;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 17;
    
    public static final int AppCompatTextView_lineHeight = 18;
    
    public static final int AppCompatTextView_textAllCaps = 19;
    
    public static final int AppCompatTextView_textLocale = 20;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130903040, 2130903041, 2130903042, 2130903043, 2130903044, 2130903045, 2130903046, 2130903047, 
        2130903048, 2130903049, 2130903050, 2130903051, 2130903052, 2130903054, 2130903055, 2130903056, 2130903057, 2130903058, 
        2130903059, 2130903060, 2130903061, 2130903062, 2130903063, 2130903064, 2130903065, 2130903066, 2130903067, 2130903068, 
        2130903069, 2130903070, 2130903071, 2130903072, 2130903076, 2130903080, 2130903081, 2130903082, 2130903083, 2130903096, 
        2130903133, 2130903150, 2130903151, 2130903152, 2130903153, 2130903154, 2130903159, 2130903160, 2130903172, 2130903181, 
        2130903224, 2130903225, 2130903226, 2130903227, 2130903228, 2130903229, 2130903230, 2130903237, 2130903238, 2130903244, 
        2130903268, 2130903309, 2130903310, 2130903311, 2130903314, 2130903316, 2130903331, 2130903332, 2130903334, 2130903335, 
        2130903336, 2130903437, 2130903450, 2130903564, 2130903565, 2130903566, 2130903567, 2130903570, 2130903571, 2130903572, 
        2130903573, 2130903574, 2130903575, 2130903576, 2130903577, 2130903578, 2130903680, 2130903681, 2130903682, 2130903701, 
        2130903703, 2130903713, 2130903715, 2130903716, 2130903717, 2130903733, 2130903734, 2130903735, 2130903736, 2130903763, 
        2130903764, 2130903798, 2130903842, 2130903844, 2130903845, 2130903846, 2130903848, 2130903849, 2130903850, 2130903851, 
        2130903854, 2130903855, 2130903895, 2130903896, 2130903897, 2130903898, 2130903926, 2130903935, 2130903936, 2130903937, 
        2130903938, 2130903939, 2130903940, 2130903941, 2130903942, 2130903943, 2130903944 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseContentDescription = 19;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 21;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 22;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 23;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 24;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 25;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 26;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 27;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 28;
    
    public static final int AppCompatTheme_actionModeStyle = 29;
    
    public static final int AppCompatTheme_actionModeTheme = 30;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 31;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 32;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 33;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 34;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 35;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 36;
    
    public static final int AppCompatTheme_alertDialogStyle = 37;
    
    public static final int AppCompatTheme_alertDialogTheme = 38;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 39;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 43;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 44;
    
    public static final int AppCompatTheme_buttonBarStyle = 45;
    
    public static final int AppCompatTheme_buttonStyle = 46;
    
    public static final int AppCompatTheme_buttonStyleSmall = 47;
    
    public static final int AppCompatTheme_checkboxStyle = 48;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 49;
    
    public static final int AppCompatTheme_colorAccent = 50;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 51;
    
    public static final int AppCompatTheme_colorButtonNormal = 52;
    
    public static final int AppCompatTheme_colorControlActivated = 53;
    
    public static final int AppCompatTheme_colorControlHighlight = 54;
    
    public static final int AppCompatTheme_colorControlNormal = 55;
    
    public static final int AppCompatTheme_colorError = 56;
    
    public static final int AppCompatTheme_colorPrimary = 57;
    
    public static final int AppCompatTheme_colorPrimaryDark = 58;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 59;
    
    public static final int AppCompatTheme_controlBackground = 60;
    
    public static final int AppCompatTheme_dialogCornerRadius = 61;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 62;
    
    public static final int AppCompatTheme_dialogTheme = 63;
    
    public static final int AppCompatTheme_dividerHorizontal = 64;
    
    public static final int AppCompatTheme_dividerVertical = 65;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 66;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 67;
    
    public static final int AppCompatTheme_editTextBackground = 68;
    
    public static final int AppCompatTheme_editTextColor = 69;
    
    public static final int AppCompatTheme_editTextStyle = 70;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 71;
    
    public static final int AppCompatTheme_imageButtonStyle = 72;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 73;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 74;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 75;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 76;
    
    public static final int AppCompatTheme_listMenuViewStyle = 77;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 79;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 80;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 83;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 84;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 85;
    
    public static final int AppCompatTheme_panelBackground = 86;
    
    public static final int AppCompatTheme_panelMenuListTheme = 87;
    
    public static final int AppCompatTheme_panelMenuListWidth = 88;
    
    public static final int AppCompatTheme_popupMenuStyle = 89;
    
    public static final int AppCompatTheme_popupWindowStyle = 90;
    
    public static final int AppCompatTheme_radioButtonStyle = 91;
    
    public static final int AppCompatTheme_ratingBarStyle = 92;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 93;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 94;
    
    public static final int AppCompatTheme_searchViewStyle = 95;
    
    public static final int AppCompatTheme_seekBarStyle = 96;
    
    public static final int AppCompatTheme_selectableItemBackground = 97;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 98;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 99;
    
    public static final int AppCompatTheme_spinnerStyle = 100;
    
    public static final int AppCompatTheme_switchStyle = 101;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 102;
    
    public static final int AppCompatTheme_textAppearanceListItem = 103;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 104;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 105;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 106;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 107;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 108;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 109;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 110;
    
    public static final int AppCompatTheme_textColorSearchUrl = 111;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 112;
    
    public static final int AppCompatTheme_toolbarStyle = 113;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 114;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 115;
    
    public static final int AppCompatTheme_viewInflaterClass = 116;
    
    public static final int AppCompatTheme_windowActionBar = 117;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 118;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 119;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 120;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 121;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 122;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 123;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 124;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 125;
    
    public static final int AppCompatTheme_windowNoTitle = 126;
    
    public static final int[] ButtonBarLayout = new int[] { 2130903084 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130903085 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130903155, 2130903161, 2130903162 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] Constraint = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
        16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130903088, 2130903118, 2130903119, 
        2130903120, 2130903171, 2130903249, 2130903320, 2130903384, 2130903385, 2130903386, 2130903387, 2130903388, 2130903389, 
        2130903390, 2130903391, 2130903392, 2130903393, 2130903394, 2130903395, 2130903396, 2130903398, 2130903399, 2130903400, 
        2130903401, 2130903402, 2130903502, 2130903503, 2130903504, 2130903505, 2130903506, 2130903507, 2130903508, 2130903509, 
        2130903510, 2130903511, 2130903512, 2130903513, 2130903514, 2130903515, 2130903516, 2130903517, 2130903518, 2130903519, 
        2130903520, 2130903521, 2130903522, 2130903523, 2130903524, 2130903525, 2130903526, 2130903527, 2130903528, 2130903529, 
        2130903530, 2130903531, 2130903532, 2130903533, 2130903534, 2130903535, 2130903536, 2130903537, 2130903538, 2130903539, 
        2130903540, 2130903541, 2130903542, 2130903543, 2130903545, 2130903546, 2130903547, 2130903548, 2130903549, 2130903550, 
        2130903551, 2130903552, 2130903647, 2130903648, 2130903688, 2130903695, 2130903914, 2130903916, 2130903927 };
    
    public static final int[] ConstraintLayout_Layout = new int[] { 
        16842948, 16842965, 16842966, 16842967, 16842968, 16842969, 16842972, 16843039, 16843040, 16843071, 
        16843072, 16843699, 16843700, 16843840, 2130903118, 2130903119, 2130903120, 2130903171, 2130903246, 2130903249, 
        2130903384, 2130903385, 2130903386, 2130903387, 2130903388, 2130903389, 2130903390, 2130903391, 2130903392, 2130903393, 
        2130903394, 2130903395, 2130903396, 2130903398, 2130903399, 2130903400, 2130903401, 2130903402, 2130903494, 2130903502, 
        2130903503, 2130903504, 2130903505, 2130903506, 2130903507, 2130903508, 2130903509, 2130903510, 2130903511, 2130903512, 
        2130903513, 2130903514, 2130903515, 2130903516, 2130903517, 2130903518, 2130903519, 2130903520, 2130903521, 2130903522, 
        2130903523, 2130903524, 2130903525, 2130903526, 2130903527, 2130903528, 2130903529, 2130903530, 2130903531, 2130903532, 
        2130903533, 2130903534, 2130903535, 2130903536, 2130903537, 2130903538, 2130903539, 2130903540, 2130903541, 2130903542, 
        2130903543, 2130903545, 2130903546, 2130903547, 2130903548, 2130903549, 2130903550, 2130903551, 2130903552, 2130903555 };
    
    public static final int ConstraintLayout_Layout_android_elevation = 13;
    
    public static final int ConstraintLayout_Layout_android_maxHeight = 8;
    
    public static final int ConstraintLayout_Layout_android_maxWidth = 7;
    
    public static final int ConstraintLayout_Layout_android_minHeight = 10;
    
    public static final int ConstraintLayout_Layout_android_minWidth = 9;
    
    public static final int ConstraintLayout_Layout_android_orientation = 0;
    
    public static final int ConstraintLayout_Layout_android_padding = 1;
    
    public static final int ConstraintLayout_Layout_android_paddingBottom = 5;
    
    public static final int ConstraintLayout_Layout_android_paddingEnd = 12;
    
    public static final int ConstraintLayout_Layout_android_paddingLeft = 2;
    
    public static final int ConstraintLayout_Layout_android_paddingRight = 4;
    
    public static final int ConstraintLayout_Layout_android_paddingStart = 11;
    
    public static final int ConstraintLayout_Layout_android_paddingTop = 3;
    
    public static final int ConstraintLayout_Layout_android_visibility = 6;
    
    public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 14;
    
    public static final int ConstraintLayout_Layout_barrierDirection = 15;
    
    public static final int ConstraintLayout_Layout_barrierMargin = 16;
    
    public static final int ConstraintLayout_Layout_chainUseRtl = 17;
    
    public static final int ConstraintLayout_Layout_constraintSet = 18;
    
    public static final int ConstraintLayout_Layout_constraint_referenced_ids = 19;
    
    public static final int ConstraintLayout_Layout_flow_firstHorizontalBias = 20;
    
    public static final int ConstraintLayout_Layout_flow_firstHorizontalStyle = 21;
    
    public static final int ConstraintLayout_Layout_flow_firstVerticalBias = 22;
    
    public static final int ConstraintLayout_Layout_flow_firstVerticalStyle = 23;
    
    public static final int ConstraintLayout_Layout_flow_horizontalAlign = 24;
    
    public static final int ConstraintLayout_Layout_flow_horizontalBias = 25;
    
    public static final int ConstraintLayout_Layout_flow_horizontalGap = 26;
    
    public static final int ConstraintLayout_Layout_flow_horizontalStyle = 27;
    
    public static final int ConstraintLayout_Layout_flow_lastHorizontalBias = 28;
    
    public static final int ConstraintLayout_Layout_flow_lastHorizontalStyle = 29;
    
    public static final int ConstraintLayout_Layout_flow_lastVerticalBias = 30;
    
    public static final int ConstraintLayout_Layout_flow_lastVerticalStyle = 31;
    
    public static final int ConstraintLayout_Layout_flow_maxElementsWrap = 32;
    
    public static final int ConstraintLayout_Layout_flow_verticalAlign = 33;
    
    public static final int ConstraintLayout_Layout_flow_verticalBias = 34;
    
    public static final int ConstraintLayout_Layout_flow_verticalGap = 35;
    
    public static final int ConstraintLayout_Layout_flow_verticalStyle = 36;
    
    public static final int ConstraintLayout_Layout_flow_wrapMode = 37;
    
    public static final int ConstraintLayout_Layout_layoutDescription = 38;
    
    public static final int ConstraintLayout_Layout_layout_constrainedHeight = 39;
    
    public static final int ConstraintLayout_Layout_layout_constrainedWidth = 40;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 41;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 42;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 43;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 44;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 45;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircle = 46;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 47;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 48;
    
    public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 49;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 50;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 51;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 52;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 53;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 54;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 55;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 56;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 57;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 58;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 59;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 60;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 61;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 62;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 63;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 64;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 65;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 66;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 67;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 68;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 69;
    
    public static final int ConstraintLayout_Layout_layout_constraintTag = 70;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 71;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 72;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 73;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 74;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 75;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 76;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 77;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 78;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 79;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 80;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 81;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 82;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 83;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 84;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 85;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginRight = 86;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginStart = 87;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginTop = 88;
    
    public static final int ConstraintLayout_Layout_layout_optimizationLevel = 89;
    
    public static final int[] ConstraintLayout_placeholder = new int[] { 2130903251, 2130903699 };
    
    public static final int ConstraintLayout_placeholder_content = 0;
    
    public static final int ConstraintLayout_placeholder_placeholder_emptyVisibility = 1;
    
    public static final int[] ConstraintSet = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843189, 16843190, 16843551, 16843552, 16843553, 16843554, 16843555, 
        16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130903088, 
        2130903118, 2130903119, 2130903120, 2130903171, 2130903249, 2130903308, 2130903320, 2130903384, 2130903385, 2130903386, 
        2130903387, 2130903388, 2130903389, 2130903390, 2130903391, 2130903392, 2130903393, 2130903394, 2130903395, 2130903396, 
        2130903398, 2130903399, 2130903400, 2130903401, 2130903402, 2130903502, 2130903503, 2130903504, 2130903505, 2130903506, 
        2130903507, 2130903508, 2130903509, 2130903510, 2130903511, 2130903512, 2130903513, 2130903514, 2130903515, 2130903516, 
        2130903517, 2130903518, 2130903519, 2130903520, 2130903521, 2130903522, 2130903523, 2130903524, 2130903525, 2130903526, 
        2130903527, 2130903528, 2130903529, 2130903530, 2130903531, 2130903532, 2130903533, 2130903534, 2130903535, 2130903536, 
        2130903537, 2130903538, 2130903539, 2130903540, 2130903541, 2130903542, 2130903543, 2130903545, 2130903546, 2130903547, 
        2130903548, 2130903549, 2130903550, 2130903551, 2130903552, 2130903647, 2130903648, 2130903688, 2130903695, 2130903914, 
        2130903916 };
    
    public static final int ConstraintSet_android_alpha = 15;
    
    public static final int ConstraintSet_android_elevation = 28;
    
    public static final int ConstraintSet_android_id = 1;
    
    public static final int ConstraintSet_android_layout_height = 4;
    
    public static final int ConstraintSet_android_layout_marginBottom = 8;
    
    public static final int ConstraintSet_android_layout_marginEnd = 26;
    
    public static final int ConstraintSet_android_layout_marginLeft = 5;
    
    public static final int ConstraintSet_android_layout_marginRight = 7;
    
    public static final int ConstraintSet_android_layout_marginStart = 25;
    
    public static final int ConstraintSet_android_layout_marginTop = 6;
    
    public static final int ConstraintSet_android_layout_width = 3;
    
    public static final int ConstraintSet_android_maxHeight = 10;
    
    public static final int ConstraintSet_android_maxWidth = 9;
    
    public static final int ConstraintSet_android_minHeight = 12;
    
    public static final int ConstraintSet_android_minWidth = 11;
    
    public static final int ConstraintSet_android_orientation = 0;
    
    public static final int ConstraintSet_android_pivotX = 13;
    
    public static final int ConstraintSet_android_pivotY = 14;
    
    public static final int ConstraintSet_android_rotation = 22;
    
    public static final int ConstraintSet_android_rotationX = 23;
    
    public static final int ConstraintSet_android_rotationY = 24;
    
    public static final int ConstraintSet_android_scaleX = 20;
    
    public static final int ConstraintSet_android_scaleY = 21;
    
    public static final int ConstraintSet_android_transformPivotX = 16;
    
    public static final int ConstraintSet_android_transformPivotY = 17;
    
    public static final int ConstraintSet_android_translationX = 18;
    
    public static final int ConstraintSet_android_translationY = 19;
    
    public static final int ConstraintSet_android_translationZ = 27;
    
    public static final int ConstraintSet_android_visibility = 2;
    
    public static final int ConstraintSet_animate_relativeTo = 29;
    
    public static final int ConstraintSet_barrierAllowsGoneWidgets = 30;
    
    public static final int ConstraintSet_barrierDirection = 31;
    
    public static final int ConstraintSet_barrierMargin = 32;
    
    public static final int ConstraintSet_chainUseRtl = 33;
    
    public static final int ConstraintSet_constraint_referenced_ids = 34;
    
    public static final int ConstraintSet_deriveConstraintsFrom = 35;
    
    public static final int ConstraintSet_drawPath = 36;
    
    public static final int ConstraintSet_flow_firstHorizontalBias = 37;
    
    public static final int ConstraintSet_flow_firstHorizontalStyle = 38;
    
    public static final int ConstraintSet_flow_firstVerticalBias = 39;
    
    public static final int ConstraintSet_flow_firstVerticalStyle = 40;
    
    public static final int ConstraintSet_flow_horizontalAlign = 41;
    
    public static final int ConstraintSet_flow_horizontalBias = 42;
    
    public static final int ConstraintSet_flow_horizontalGap = 43;
    
    public static final int ConstraintSet_flow_horizontalStyle = 44;
    
    public static final int ConstraintSet_flow_lastHorizontalBias = 45;
    
    public static final int ConstraintSet_flow_lastHorizontalStyle = 46;
    
    public static final int ConstraintSet_flow_lastVerticalBias = 47;
    
    public static final int ConstraintSet_flow_lastVerticalStyle = 48;
    
    public static final int ConstraintSet_flow_maxElementsWrap = 49;
    
    public static final int ConstraintSet_flow_verticalAlign = 50;
    
    public static final int ConstraintSet_flow_verticalBias = 51;
    
    public static final int ConstraintSet_flow_verticalGap = 52;
    
    public static final int ConstraintSet_flow_verticalStyle = 53;
    
    public static final int ConstraintSet_flow_wrapMode = 54;
    
    public static final int ConstraintSet_layout_constrainedHeight = 55;
    
    public static final int ConstraintSet_layout_constrainedWidth = 56;
    
    public static final int ConstraintSet_layout_constraintBaseline_creator = 57;
    
    public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 58;
    
    public static final int ConstraintSet_layout_constraintBottom_creator = 59;
    
    public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 60;
    
    public static final int ConstraintSet_layout_constraintBottom_toTopOf = 61;
    
    public static final int ConstraintSet_layout_constraintCircle = 62;
    
    public static final int ConstraintSet_layout_constraintCircleAngle = 63;
    
    public static final int ConstraintSet_layout_constraintCircleRadius = 64;
    
    public static final int ConstraintSet_layout_constraintDimensionRatio = 65;
    
    public static final int ConstraintSet_layout_constraintEnd_toEndOf = 66;
    
    public static final int ConstraintSet_layout_constraintEnd_toStartOf = 67;
    
    public static final int ConstraintSet_layout_constraintGuide_begin = 68;
    
    public static final int ConstraintSet_layout_constraintGuide_end = 69;
    
    public static final int ConstraintSet_layout_constraintGuide_percent = 70;
    
    public static final int ConstraintSet_layout_constraintHeight_default = 71;
    
    public static final int ConstraintSet_layout_constraintHeight_max = 72;
    
    public static final int ConstraintSet_layout_constraintHeight_min = 73;
    
    public static final int ConstraintSet_layout_constraintHeight_percent = 74;
    
    public static final int ConstraintSet_layout_constraintHorizontal_bias = 75;
    
    public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 76;
    
    public static final int ConstraintSet_layout_constraintHorizontal_weight = 77;
    
    public static final int ConstraintSet_layout_constraintLeft_creator = 78;
    
    public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 79;
    
    public static final int ConstraintSet_layout_constraintLeft_toRightOf = 80;
    
    public static final int ConstraintSet_layout_constraintRight_creator = 81;
    
    public static final int ConstraintSet_layout_constraintRight_toLeftOf = 82;
    
    public static final int ConstraintSet_layout_constraintRight_toRightOf = 83;
    
    public static final int ConstraintSet_layout_constraintStart_toEndOf = 84;
    
    public static final int ConstraintSet_layout_constraintStart_toStartOf = 85;
    
    public static final int ConstraintSet_layout_constraintTag = 86;
    
    public static final int ConstraintSet_layout_constraintTop_creator = 87;
    
    public static final int ConstraintSet_layout_constraintTop_toBottomOf = 88;
    
    public static final int ConstraintSet_layout_constraintTop_toTopOf = 89;
    
    public static final int ConstraintSet_layout_constraintVertical_bias = 90;
    
    public static final int ConstraintSet_layout_constraintVertical_chainStyle = 91;
    
    public static final int ConstraintSet_layout_constraintVertical_weight = 92;
    
    public static final int ConstraintSet_layout_constraintWidth_default = 93;
    
    public static final int ConstraintSet_layout_constraintWidth_max = 94;
    
    public static final int ConstraintSet_layout_constraintWidth_min = 95;
    
    public static final int ConstraintSet_layout_constraintWidth_percent = 96;
    
    public static final int ConstraintSet_layout_editor_absoluteX = 97;
    
    public static final int ConstraintSet_layout_editor_absoluteY = 98;
    
    public static final int ConstraintSet_layout_goneMarginBottom = 99;
    
    public static final int ConstraintSet_layout_goneMarginEnd = 100;
    
    public static final int ConstraintSet_layout_goneMarginLeft = 101;
    
    public static final int ConstraintSet_layout_goneMarginRight = 102;
    
    public static final int ConstraintSet_layout_goneMarginStart = 103;
    
    public static final int ConstraintSet_layout_goneMarginTop = 104;
    
    public static final int ConstraintSet_motionProgress = 105;
    
    public static final int ConstraintSet_motionStagger = 106;
    
    public static final int ConstraintSet_pathMotionArc = 107;
    
    public static final int ConstraintSet_pivotAnchor = 108;
    
    public static final int ConstraintSet_transitionEasing = 109;
    
    public static final int ConstraintSet_transitionPathRotate = 110;
    
    public static final int Constraint_android_alpha = 13;
    
    public static final int Constraint_android_elevation = 26;
    
    public static final int Constraint_android_id = 1;
    
    public static final int Constraint_android_layout_height = 4;
    
    public static final int Constraint_android_layout_marginBottom = 8;
    
    public static final int Constraint_android_layout_marginEnd = 24;
    
    public static final int Constraint_android_layout_marginLeft = 5;
    
    public static final int Constraint_android_layout_marginRight = 7;
    
    public static final int Constraint_android_layout_marginStart = 23;
    
    public static final int Constraint_android_layout_marginTop = 6;
    
    public static final int Constraint_android_layout_width = 3;
    
    public static final int Constraint_android_maxHeight = 10;
    
    public static final int Constraint_android_maxWidth = 9;
    
    public static final int Constraint_android_minHeight = 12;
    
    public static final int Constraint_android_minWidth = 11;
    
    public static final int Constraint_android_orientation = 0;
    
    public static final int Constraint_android_rotation = 20;
    
    public static final int Constraint_android_rotationX = 21;
    
    public static final int Constraint_android_rotationY = 22;
    
    public static final int Constraint_android_scaleX = 18;
    
    public static final int Constraint_android_scaleY = 19;
    
    public static final int Constraint_android_transformPivotX = 14;
    
    public static final int Constraint_android_transformPivotY = 15;
    
    public static final int Constraint_android_translationX = 16;
    
    public static final int Constraint_android_translationY = 17;
    
    public static final int Constraint_android_translationZ = 25;
    
    public static final int Constraint_android_visibility = 2;
    
    public static final int Constraint_animate_relativeTo = 27;
    
    public static final int Constraint_barrierAllowsGoneWidgets = 28;
    
    public static final int Constraint_barrierDirection = 29;
    
    public static final int Constraint_barrierMargin = 30;
    
    public static final int Constraint_chainUseRtl = 31;
    
    public static final int Constraint_constraint_referenced_ids = 32;
    
    public static final int Constraint_drawPath = 33;
    
    public static final int Constraint_flow_firstHorizontalBias = 34;
    
    public static final int Constraint_flow_firstHorizontalStyle = 35;
    
    public static final int Constraint_flow_firstVerticalBias = 36;
    
    public static final int Constraint_flow_firstVerticalStyle = 37;
    
    public static final int Constraint_flow_horizontalAlign = 38;
    
    public static final int Constraint_flow_horizontalBias = 39;
    
    public static final int Constraint_flow_horizontalGap = 40;
    
    public static final int Constraint_flow_horizontalStyle = 41;
    
    public static final int Constraint_flow_lastHorizontalBias = 42;
    
    public static final int Constraint_flow_lastHorizontalStyle = 43;
    
    public static final int Constraint_flow_lastVerticalBias = 44;
    
    public static final int Constraint_flow_lastVerticalStyle = 45;
    
    public static final int Constraint_flow_maxElementsWrap = 46;
    
    public static final int Constraint_flow_verticalAlign = 47;
    
    public static final int Constraint_flow_verticalBias = 48;
    
    public static final int Constraint_flow_verticalGap = 49;
    
    public static final int Constraint_flow_verticalStyle = 50;
    
    public static final int Constraint_flow_wrapMode = 51;
    
    public static final int Constraint_layout_constrainedHeight = 52;
    
    public static final int Constraint_layout_constrainedWidth = 53;
    
    public static final int Constraint_layout_constraintBaseline_creator = 54;
    
    public static final int Constraint_layout_constraintBaseline_toBaselineOf = 55;
    
    public static final int Constraint_layout_constraintBottom_creator = 56;
    
    public static final int Constraint_layout_constraintBottom_toBottomOf = 57;
    
    public static final int Constraint_layout_constraintBottom_toTopOf = 58;
    
    public static final int Constraint_layout_constraintCircle = 59;
    
    public static final int Constraint_layout_constraintCircleAngle = 60;
    
    public static final int Constraint_layout_constraintCircleRadius = 61;
    
    public static final int Constraint_layout_constraintDimensionRatio = 62;
    
    public static final int Constraint_layout_constraintEnd_toEndOf = 63;
    
    public static final int Constraint_layout_constraintEnd_toStartOf = 64;
    
    public static final int Constraint_layout_constraintGuide_begin = 65;
    
    public static final int Constraint_layout_constraintGuide_end = 66;
    
    public static final int Constraint_layout_constraintGuide_percent = 67;
    
    public static final int Constraint_layout_constraintHeight_default = 68;
    
    public static final int Constraint_layout_constraintHeight_max = 69;
    
    public static final int Constraint_layout_constraintHeight_min = 70;
    
    public static final int Constraint_layout_constraintHeight_percent = 71;
    
    public static final int Constraint_layout_constraintHorizontal_bias = 72;
    
    public static final int Constraint_layout_constraintHorizontal_chainStyle = 73;
    
    public static final int Constraint_layout_constraintHorizontal_weight = 74;
    
    public static final int Constraint_layout_constraintLeft_creator = 75;
    
    public static final int Constraint_layout_constraintLeft_toLeftOf = 76;
    
    public static final int Constraint_layout_constraintLeft_toRightOf = 77;
    
    public static final int Constraint_layout_constraintRight_creator = 78;
    
    public static final int Constraint_layout_constraintRight_toLeftOf = 79;
    
    public static final int Constraint_layout_constraintRight_toRightOf = 80;
    
    public static final int Constraint_layout_constraintStart_toEndOf = 81;
    
    public static final int Constraint_layout_constraintStart_toStartOf = 82;
    
    public static final int Constraint_layout_constraintTag = 83;
    
    public static final int Constraint_layout_constraintTop_creator = 84;
    
    public static final int Constraint_layout_constraintTop_toBottomOf = 85;
    
    public static final int Constraint_layout_constraintTop_toTopOf = 86;
    
    public static final int Constraint_layout_constraintVertical_bias = 87;
    
    public static final int Constraint_layout_constraintVertical_chainStyle = 88;
    
    public static final int Constraint_layout_constraintVertical_weight = 89;
    
    public static final int Constraint_layout_constraintWidth_default = 90;
    
    public static final int Constraint_layout_constraintWidth_max = 91;
    
    public static final int Constraint_layout_constraintWidth_min = 92;
    
    public static final int Constraint_layout_constraintWidth_percent = 93;
    
    public static final int Constraint_layout_editor_absoluteX = 94;
    
    public static final int Constraint_layout_editor_absoluteY = 95;
    
    public static final int Constraint_layout_goneMarginBottom = 96;
    
    public static final int Constraint_layout_goneMarginEnd = 97;
    
    public static final int Constraint_layout_goneMarginLeft = 98;
    
    public static final int Constraint_layout_goneMarginRight = 99;
    
    public static final int Constraint_layout_goneMarginStart = 100;
    
    public static final int Constraint_layout_goneMarginTop = 101;
    
    public static final int Constraint_motionProgress = 102;
    
    public static final int Constraint_motionStagger = 103;
    
    public static final int Constraint_pathMotionArc = 104;
    
    public static final int Constraint_pivotAnchor = 105;
    
    public static final int Constraint_transitionEasing = 106;
    
    public static final int Constraint_transitionPathRotate = 107;
    
    public static final int Constraint_visibilityMode = 108;
    
    public static final int[] CustomAttribute = new int[] { 2130903095, 2130903290, 2130903291, 2130903292, 2130903293, 2130903294, 2130903295, 2130903297, 2130903298 };
    
    public static final int CustomAttribute_attributeName = 0;
    
    public static final int CustomAttribute_customBoolean = 1;
    
    public static final int CustomAttribute_customColorDrawableValue = 2;
    
    public static final int CustomAttribute_customColorValue = 3;
    
    public static final int CustomAttribute_customDimension = 4;
    
    public static final int CustomAttribute_customFloatValue = 5;
    
    public static final int CustomAttribute_customIntegerValue = 6;
    
    public static final int CustomAttribute_customPixelDimension = 7;
    
    public static final int CustomAttribute_customStringValue = 8;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130903093, 2130903094, 2130903117, 2130903223, 2130903325, 2130903418, 2130903762, 2130903863 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130903405, 2130903406, 2130903407, 2130903408, 2130903409, 2130903410, 2130903411 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903403, 2130903412, 2130903413, 2130903414, 2130903921 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] ImageFilterView = new int[] { 2130903087, 2130903149, 2130903267, 2130903287, 2130903671, 2130903725, 2130903726, 2130903727, 2130903929 };
    
    public static final int ImageFilterView_altSrc = 0;
    
    public static final int ImageFilterView_brightness = 1;
    
    public static final int ImageFilterView_contrast = 2;
    
    public static final int ImageFilterView_crossfade = 3;
    
    public static final int ImageFilterView_overlay = 4;
    
    public static final int ImageFilterView_round = 5;
    
    public static final int ImageFilterView_roundPercent = 6;
    
    public static final int ImageFilterView_saturation = 7;
    
    public static final int ImageFilterView_warmth = 8;
    
    public static final int[] KeyAttribute = new int[] { 
        16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 
        16843770, 16843840, 2130903289, 2130903417, 2130903647, 2130903649, 2130903914, 2130903916 };
    
    public static final int KeyAttribute_android_alpha = 0;
    
    public static final int KeyAttribute_android_elevation = 11;
    
    public static final int KeyAttribute_android_rotation = 7;
    
    public static final int KeyAttribute_android_rotationX = 8;
    
    public static final int KeyAttribute_android_rotationY = 9;
    
    public static final int KeyAttribute_android_scaleX = 5;
    
    public static final int KeyAttribute_android_scaleY = 6;
    
    public static final int KeyAttribute_android_transformPivotX = 1;
    
    public static final int KeyAttribute_android_transformPivotY = 2;
    
    public static final int KeyAttribute_android_translationX = 3;
    
    public static final int KeyAttribute_android_translationY = 4;
    
    public static final int KeyAttribute_android_translationZ = 10;
    
    public static final int KeyAttribute_curveFit = 12;
    
    public static final int KeyAttribute_framePosition = 13;
    
    public static final int KeyAttribute_motionProgress = 14;
    
    public static final int KeyAttribute_motionTarget = 15;
    
    public static final int KeyAttribute_transitionEasing = 16;
    
    public static final int KeyAttribute_transitionPathRotate = 17;
    
    public static final int[] KeyCycle = new int[] { 
        16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, 
        2130903289, 2130903417, 2130903647, 2130903649, 2130903914, 2130903916, 2130903931, 2130903932, 2130903933, 2130903934 };
    
    public static final int KeyCycle_android_alpha = 0;
    
    public static final int KeyCycle_android_elevation = 9;
    
    public static final int KeyCycle_android_rotation = 5;
    
    public static final int KeyCycle_android_rotationX = 6;
    
    public static final int KeyCycle_android_rotationY = 7;
    
    public static final int KeyCycle_android_scaleX = 3;
    
    public static final int KeyCycle_android_scaleY = 4;
    
    public static final int KeyCycle_android_translationX = 1;
    
    public static final int KeyCycle_android_translationY = 2;
    
    public static final int KeyCycle_android_translationZ = 8;
    
    public static final int KeyCycle_curveFit = 10;
    
    public static final int KeyCycle_framePosition = 11;
    
    public static final int KeyCycle_motionProgress = 12;
    
    public static final int KeyCycle_motionTarget = 13;
    
    public static final int KeyCycle_transitionEasing = 14;
    
    public static final int KeyCycle_transitionPathRotate = 15;
    
    public static final int KeyCycle_waveOffset = 16;
    
    public static final int KeyCycle_wavePeriod = 17;
    
    public static final int KeyCycle_waveShape = 18;
    
    public static final int KeyCycle_waveVariesBy = 19;
    
    public static final int[] KeyPosition = new int[] { 
        2130903289, 2130903320, 2130903417, 2130903486, 2130903649, 2130903688, 2130903690, 2130903691, 2130903692, 2130903693, 
        2130903756, 2130903914 };
    
    public static final int KeyPosition_curveFit = 0;
    
    public static final int KeyPosition_drawPath = 1;
    
    public static final int KeyPosition_framePosition = 2;
    
    public static final int KeyPosition_keyPositionType = 3;
    
    public static final int KeyPosition_motionTarget = 4;
    
    public static final int KeyPosition_pathMotionArc = 5;
    
    public static final int KeyPosition_percentHeight = 6;
    
    public static final int KeyPosition_percentWidth = 7;
    
    public static final int KeyPosition_percentX = 8;
    
    public static final int KeyPosition_percentY = 9;
    
    public static final int KeyPosition_sizePercent = 10;
    
    public static final int KeyPosition_transitionEasing = 11;
    
    public static final int[] KeyTimeCycle = new int[] { 
        16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, 
        2130903289, 2130903417, 2130903647, 2130903649, 2130903914, 2130903916, 2130903930, 2130903931, 2130903932, 2130903933 };
    
    public static final int KeyTimeCycle_android_alpha = 0;
    
    public static final int KeyTimeCycle_android_elevation = 9;
    
    public static final int KeyTimeCycle_android_rotation = 5;
    
    public static final int KeyTimeCycle_android_rotationX = 6;
    
    public static final int KeyTimeCycle_android_rotationY = 7;
    
    public static final int KeyTimeCycle_android_scaleX = 3;
    
    public static final int KeyTimeCycle_android_scaleY = 4;
    
    public static final int KeyTimeCycle_android_translationX = 1;
    
    public static final int KeyTimeCycle_android_translationY = 2;
    
    public static final int KeyTimeCycle_android_translationZ = 8;
    
    public static final int KeyTimeCycle_curveFit = 10;
    
    public static final int KeyTimeCycle_framePosition = 11;
    
    public static final int KeyTimeCycle_motionProgress = 12;
    
    public static final int KeyTimeCycle_motionTarget = 13;
    
    public static final int KeyTimeCycle_transitionEasing = 14;
    
    public static final int KeyTimeCycle_transitionPathRotate = 15;
    
    public static final int KeyTimeCycle_waveDecay = 16;
    
    public static final int KeyTimeCycle_waveOffset = 17;
    
    public static final int KeyTimeCycle_wavePeriod = 18;
    
    public static final int KeyTimeCycle_waveShape = 19;
    
    public static final int[] KeyTrigger = new int[] { 2130903417, 2130903649, 2130903650, 2130903651, 2130903664, 2130903666, 2130903667, 2130903918, 2130903919, 2130903920 };
    
    public static final int KeyTrigger_framePosition = 0;
    
    public static final int KeyTrigger_motionTarget = 1;
    
    public static final int KeyTrigger_motion_postLayoutCollision = 2;
    
    public static final int KeyTrigger_motion_triggerOnCollision = 3;
    
    public static final int KeyTrigger_onCross = 4;
    
    public static final int KeyTrigger_onNegativeCross = 5;
    
    public static final int KeyTrigger_onPositiveCross = 6;
    
    public static final int KeyTrigger_triggerId = 7;
    
    public static final int KeyTrigger_triggerReceiver = 8;
    
    public static final int KeyTrigger_triggerSlack = 9;
    
    public static final int[] Layout = new int[] { 
        16842948, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843701, 16843702, 2130903118, 
        2130903119, 2130903120, 2130903171, 2130903249, 2130903502, 2130903503, 2130903504, 2130903505, 2130903506, 2130903507, 
        2130903508, 2130903509, 2130903510, 2130903511, 2130903512, 2130903513, 2130903514, 2130903515, 2130903516, 2130903517, 
        2130903518, 2130903519, 2130903520, 2130903521, 2130903522, 2130903523, 2130903524, 2130903525, 2130903526, 2130903527, 
        2130903528, 2130903529, 2130903530, 2130903531, 2130903532, 2130903534, 2130903535, 2130903536, 2130903537, 2130903538, 
        2130903539, 2130903540, 2130903541, 2130903542, 2130903543, 2130903545, 2130903546, 2130903547, 2130903548, 2130903549, 
        2130903550, 2130903551, 2130903552, 2130903613, 2130903617, 2130903621, 2130903625 };
    
    public static final int Layout_android_layout_height = 2;
    
    public static final int Layout_android_layout_marginBottom = 6;
    
    public static final int Layout_android_layout_marginEnd = 8;
    
    public static final int Layout_android_layout_marginLeft = 3;
    
    public static final int Layout_android_layout_marginRight = 5;
    
    public static final int Layout_android_layout_marginStart = 7;
    
    public static final int Layout_android_layout_marginTop = 4;
    
    public static final int Layout_android_layout_width = 1;
    
    public static final int Layout_android_orientation = 0;
    
    public static final int Layout_barrierAllowsGoneWidgets = 9;
    
    public static final int Layout_barrierDirection = 10;
    
    public static final int Layout_barrierMargin = 11;
    
    public static final int Layout_chainUseRtl = 12;
    
    public static final int Layout_constraint_referenced_ids = 13;
    
    public static final int Layout_layout_constrainedHeight = 14;
    
    public static final int Layout_layout_constrainedWidth = 15;
    
    public static final int Layout_layout_constraintBaseline_creator = 16;
    
    public static final int Layout_layout_constraintBaseline_toBaselineOf = 17;
    
    public static final int Layout_layout_constraintBottom_creator = 18;
    
    public static final int Layout_layout_constraintBottom_toBottomOf = 19;
    
    public static final int Layout_layout_constraintBottom_toTopOf = 20;
    
    public static final int Layout_layout_constraintCircle = 21;
    
    public static final int Layout_layout_constraintCircleAngle = 22;
    
    public static final int Layout_layout_constraintCircleRadius = 23;
    
    public static final int Layout_layout_constraintDimensionRatio = 24;
    
    public static final int Layout_layout_constraintEnd_toEndOf = 25;
    
    public static final int Layout_layout_constraintEnd_toStartOf = 26;
    
    public static final int Layout_layout_constraintGuide_begin = 27;
    
    public static final int Layout_layout_constraintGuide_end = 28;
    
    public static final int Layout_layout_constraintGuide_percent = 29;
    
    public static final int Layout_layout_constraintHeight_default = 30;
    
    public static final int Layout_layout_constraintHeight_max = 31;
    
    public static final int Layout_layout_constraintHeight_min = 32;
    
    public static final int Layout_layout_constraintHeight_percent = 33;
    
    public static final int Layout_layout_constraintHorizontal_bias = 34;
    
    public static final int Layout_layout_constraintHorizontal_chainStyle = 35;
    
    public static final int Layout_layout_constraintHorizontal_weight = 36;
    
    public static final int Layout_layout_constraintLeft_creator = 37;
    
    public static final int Layout_layout_constraintLeft_toLeftOf = 38;
    
    public static final int Layout_layout_constraintLeft_toRightOf = 39;
    
    public static final int Layout_layout_constraintRight_creator = 40;
    
    public static final int Layout_layout_constraintRight_toLeftOf = 41;
    
    public static final int Layout_layout_constraintRight_toRightOf = 42;
    
    public static final int Layout_layout_constraintStart_toEndOf = 43;
    
    public static final int Layout_layout_constraintStart_toStartOf = 44;
    
    public static final int Layout_layout_constraintTop_creator = 45;
    
    public static final int Layout_layout_constraintTop_toBottomOf = 46;
    
    public static final int Layout_layout_constraintTop_toTopOf = 47;
    
    public static final int Layout_layout_constraintVertical_bias = 48;
    
    public static final int Layout_layout_constraintVertical_chainStyle = 49;
    
    public static final int Layout_layout_constraintVertical_weight = 50;
    
    public static final int Layout_layout_constraintWidth_default = 51;
    
    public static final int Layout_layout_constraintWidth_max = 52;
    
    public static final int Layout_layout_constraintWidth_min = 53;
    
    public static final int Layout_layout_constraintWidth_percent = 54;
    
    public static final int Layout_layout_editor_absoluteX = 55;
    
    public static final int Layout_layout_editor_absoluteY = 56;
    
    public static final int Layout_layout_goneMarginBottom = 57;
    
    public static final int Layout_layout_goneMarginEnd = 58;
    
    public static final int Layout_layout_goneMarginLeft = 59;
    
    public static final int Layout_layout_goneMarginRight = 60;
    
    public static final int Layout_layout_goneMarginStart = 61;
    
    public static final int Layout_layout_goneMarginTop = 62;
    
    public static final int Layout_maxHeight = 63;
    
    public static final int Layout_maxWidth = 64;
    
    public static final int Layout_minHeight = 65;
    
    public static final int Layout_minWidth = 66;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130903313, 2130903315, 2130903618, 2130903747 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130903053, 2130903073, 2130903075, 2130903086, 2130903252, 2130903447, 2130903448, 
        2130903663, 2130903745, 2130903900 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130903707, 2130903785 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] MockView = new int[] { 2130903626, 2130903627, 2130903628, 2130903629, 2130903630, 2130903631 };
    
    public static final int MockView_mock_diagonalsColor = 0;
    
    public static final int MockView_mock_label = 1;
    
    public static final int MockView_mock_labelBackgroundColor = 2;
    
    public static final int MockView_mock_labelColor = 3;
    
    public static final int MockView_mock_showDiagonals = 4;
    
    public static final int MockView_mock_showLabel = 5;
    
    public static final int[] Motion = new int[] { 2130903088, 2130903320, 2130903646, 2130903648, 2130903688, 2130903914 };
    
    public static final int[] MotionHelper = new int[] { 2130903665, 2130903668 };
    
    public static final int MotionHelper_onHide = 0;
    
    public static final int MotionHelper_onShow = 1;
    
    public static final int[] MotionLayout = new int[] { 2130903091, 2130903288, 2130903494, 2130903632, 2130903647, 2130903749 };
    
    public static final int MotionLayout_applyMotionScene = 0;
    
    public static final int MotionLayout_currentState = 1;
    
    public static final int MotionLayout_layoutDescription = 2;
    
    public static final int MotionLayout_motionDebug = 3;
    
    public static final int MotionLayout_motionProgress = 4;
    
    public static final int MotionLayout_showPaths = 5;
    
    public static final int[] MotionScene = new int[] { 2130903303, 2130903495 };
    
    public static final int MotionScene_defaultDuration = 0;
    
    public static final int MotionScene_layoutDuringTransition = 1;
    
    public static final int[] MotionTelltales = new int[] { 2130903828, 2130903829, 2130903830 };
    
    public static final int MotionTelltales_telltales_tailColor = 0;
    
    public static final int MotionTelltales_telltales_tailScale = 1;
    
    public static final int MotionTelltales_telltales_velocityMode = 2;
    
    public static final int Motion_animate_relativeTo = 0;
    
    public static final int Motion_drawPath = 1;
    
    public static final int Motion_motionPathRotate = 2;
    
    public static final int Motion_motionStagger = 3;
    
    public static final int Motion_pathMotionArc = 4;
    
    public static final int Motion_transitionEasing = 5;
    
    public static final int[] OnClick = new int[] { 2130903204, 2130903827 };
    
    public static final int OnClick_clickAction = 0;
    
    public static final int OnClick_targetId = 1;
    
    public static final int[] OnSwipe = new int[] { 
        2130903317, 2130903318, 2130903319, 2130903560, 2130903609, 2130903616, 2130903652, 2130903660, 2130903669, 2130903901, 
        2130903902, 2130903903 };
    
    public static final int OnSwipe_dragDirection = 0;
    
    public static final int OnSwipe_dragScale = 1;
    
    public static final int OnSwipe_dragThreshold = 2;
    
    public static final int OnSwipe_limitBoundsTo = 3;
    
    public static final int OnSwipe_maxAcceleration = 4;
    
    public static final int OnSwipe_maxVelocity = 5;
    
    public static final int OnSwipe_moveWhenScrollAtTop = 6;
    
    public static final int OnSwipe_nestedScrollFlags = 7;
    
    public static final int OnSwipe_onTouchUp = 8;
    
    public static final int OnSwipe_touchAnchorId = 9;
    
    public static final int OnSwipe_touchAnchorSide = 10;
    
    public static final int OnSwipe_touchRegionId = 11;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130903670 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130903774 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] PropertySet = new int[] { 16842972, 16843551, 2130903533, 2130903647, 2130903927 };
    
    public static final int PropertySet_android_alpha = 1;
    
    public static final int PropertySet_android_visibility = 0;
    
    public static final int PropertySet_layout_constraintTag = 2;
    
    public static final int PropertySet_motionProgress = 3;
    
    public static final int PropertySet_visibilityMode = 4;
    
    public static final int[] RecycleListView = new int[] { 2130903672, 2130903678 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130903209, 2130903245, 2130903304, 2130903420, 2130903449, 2130903493, 
        2130903711, 2130903712, 2130903731, 2130903732, 2130903786, 2130903795, 2130903928 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130903702 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] State = new int[] { 16842960, 2130903250 };
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] StateSet = new int[] { 2130903305 };
    
    public static final int StateSet_defaultState = 0;
    
    public static final int State_android_id = 0;
    
    public static final int State_constraints = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130903750, 2130903765, 2130903796, 2130903797, 2130903799, 2130903869, 2130903870, 
        2130903871, 2130903904, 2130903911, 2130903912 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130903404, 2130903413, 2130903831, 2130903859 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130903156, 2130903217, 2130903218, 2130903253, 2130903254, 2130903255, 2130903256, 2130903257, 
        2130903258, 2130903579, 2130903580, 2130903611, 2130903619, 2130903654, 2130903655, 2130903702, 2130903787, 2130903789, 
        2130903790, 2130903881, 2130903885, 2130903886, 2130903887, 2130903888, 2130903889, 2130903890, 2130903891, 2130903892 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] Transform = new int[] { 
        16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 
        16843840 };
    
    public static final int Transform_android_elevation = 10;
    
    public static final int Transform_android_rotation = 6;
    
    public static final int Transform_android_rotationX = 7;
    
    public static final int Transform_android_rotationY = 8;
    
    public static final int Transform_android_scaleX = 4;
    
    public static final int Transform_android_scaleY = 5;
    
    public static final int Transform_android_transformPivotX = 0;
    
    public static final int Transform_android_transformPivotY = 1;
    
    public static final int Transform_android_translationX = 2;
    
    public static final int Transform_android_translationY = 3;
    
    public static final int Transform_android_translationZ = 9;
    
    public static final int[] Transition = new int[] { 
        16842960, 2130903102, 2130903247, 2130903248, 2130903333, 2130903495, 2130903644, 2130903688, 2130903768, 2130903913, 
        2130903915 };
    
    public static final int Transition_android_id = 0;
    
    public static final int Transition_autoTransition = 1;
    
    public static final int Transition_constraintSetEnd = 2;
    
    public static final int Transition_constraintSetStart = 3;
    
    public static final int Transition_duration = 4;
    
    public static final int Transition_layoutDuringTransition = 5;
    
    public static final int Transition_motionInterpolator = 6;
    
    public static final int Transition_pathMotionArc = 7;
    
    public static final int Transition_staggered = 8;
    
    public static final int Transition_transitionDisable = 9;
    
    public static final int Transition_transitionFlags = 10;
    
    public static final int[] Variant = new int[] { 2130903250, 2130903719, 2130903720, 2130903721, 2130903722 };
    
    public static final int Variant_constraints = 0;
    
    public static final int Variant_region_heightLessThan = 1;
    
    public static final int Variant_region_heightMoreThan = 2;
    
    public static final int Variant_region_widthLessThan = 3;
    
    public static final int Variant_region_widthMoreThan = 4;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130903674, 2130903677, 2130903861 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130903112, 2130903113 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket-dex2jar.jar!\androidx\constraintlayout\widget\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */