package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Guideline;
import androidx.constraintlayout.solver.widgets.analyzer.BasicMeasure;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUG_DRAW_CONSTRAINTS = false;
  
  public static final int DESIGN_INFO_ID = 0;
  
  private static final boolean MEASURE = false;
  
  private static final String TAG = "ConstraintLayout";
  
  private static final boolean USE_CONSTRAINTS_HELPER = true;
  
  public static final String VERSION = "ConstraintLayout-2.0.1";
  
  SparseArray<View> mChildrenByIds = new SparseArray();
  
  private ArrayList<ConstraintHelper> mConstraintHelpers = new ArrayList<ConstraintHelper>(4);
  
  protected ConstraintLayoutStates mConstraintLayoutSpec = null;
  
  private ConstraintSet mConstraintSet = null;
  
  private int mConstraintSetId = -1;
  
  private ConstraintsChangedListener mConstraintsChangedListener;
  
  private HashMap<String, Integer> mDesignIds = new HashMap<String, Integer>();
  
  protected boolean mDirtyHierarchy = true;
  
  private int mLastMeasureHeight = -1;
  
  int mLastMeasureHeightMode = 0;
  
  int mLastMeasureHeightSize = -1;
  
  private int mLastMeasureWidth = -1;
  
  int mLastMeasureWidthMode = 0;
  
  int mLastMeasureWidthSize = -1;
  
  protected ConstraintWidgetContainer mLayoutWidget = new ConstraintWidgetContainer();
  
  private int mMaxHeight = Integer.MAX_VALUE;
  
  private int mMaxWidth = Integer.MAX_VALUE;
  
  Measurer mMeasurer = new Measurer(this);
  
  private Metrics mMetrics;
  
  private int mMinHeight = 0;
  
  private int mMinWidth = 0;
  
  private int mOnMeasureHeightMeasureSpec = 0;
  
  private int mOnMeasureWidthMeasureSpec = 0;
  
  private int mOptimizationLevel = 263;
  
  private SparseArray<ConstraintWidget> mTempMapIdToWidget = new SparseArray();
  
  public ConstraintLayout(Context paramContext) {
    super(paramContext);
    init((AttributeSet)null, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet, paramInt, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    init(paramAttributeSet, paramInt1, paramInt2);
  }
  
  private int getPaddingWidth() {
    int j = getPaddingLeft();
    int i = 0;
    j = Math.max(0, j) + Math.max(0, getPaddingRight());
    if (Build.VERSION.SDK_INT >= 17) {
      i = Math.max(0, getPaddingStart());
      i = Math.max(0, getPaddingEnd()) + i;
    } 
    if (i > 0)
      j = i; 
    return j;
  }
  
  private final ConstraintWidget getTargetWidget(int paramInt) {
    if (paramInt == 0)
      return (ConstraintWidget)this.mLayoutWidget; 
    View view2 = (View)this.mChildrenByIds.get(paramInt);
    View view1 = view2;
    if (view2 == null) {
      view2 = findViewById(paramInt);
      view1 = view2;
      if (view2 != null) {
        view1 = view2;
        if (view2 != this) {
          view1 = view2;
          if (view2.getParent() == this) {
            onViewAdded(view2);
            view1 = view2;
          } 
        } 
      } 
    } 
    return (ConstraintWidget)((view1 == this) ? this.mLayoutWidget : ((view1 == null) ? null : ((LayoutParams)view1.getLayoutParams()).widget));
  }
  
  private void init(AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.mLayoutWidget.setCompanionWidget(this);
    this.mLayoutWidget.setMeasurer(this.mMeasurer);
    this.mChildrenByIds.put(getId(), this);
    this.mConstraintSet = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.ConstraintLayout_Layout, paramInt1, paramInt2);
      paramInt2 = typedArray.getIndexCount();
      paramInt1 = 0;
      while (true) {
        if (paramInt1 < paramInt2) {
          int i = typedArray.getIndex(paramInt1);
          if (i == R.styleable.ConstraintLayout_Layout_android_minWidth) {
            this.mMinWidth = typedArray.getDimensionPixelOffset(i, this.mMinWidth);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_minHeight) {
            this.mMinHeight = typedArray.getDimensionPixelOffset(i, this.mMinHeight);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_maxWidth) {
            this.mMaxWidth = typedArray.getDimensionPixelOffset(i, this.mMaxWidth);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_maxHeight) {
            this.mMaxHeight = typedArray.getDimensionPixelOffset(i, this.mMaxHeight);
          } else if (i == R.styleable.ConstraintLayout_Layout_layout_optimizationLevel) {
            this.mOptimizationLevel = typedArray.getInt(i, this.mOptimizationLevel);
          } else if (i == R.styleable.ConstraintLayout_Layout_layoutDescription) {
            i = typedArray.getResourceId(i, 0);
            if (i != 0)
              try {
                parseLayoutDescription(i);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                this.mConstraintLayoutSpec = null;
              }  
          } else if (i == R.styleable.ConstraintLayout_Layout_constraintSet) {
            i = typedArray.getResourceId(i, 0);
            try {
              ConstraintSet constraintSet = new ConstraintSet();
              this.mConstraintSet = constraintSet;
              constraintSet.load(getContext(), i);
            } catch (android.content.res.Resources.NotFoundException notFoundException) {
              this.mConstraintSet = null;
            } 
            this.mConstraintSetId = i;
          } 
          paramInt1++;
          continue;
        } 
        typedArray.recycle();
        this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
        return;
      } 
    } 
    this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
  }
  
  private void markHierarchyDirty() {
    this.mDirtyHierarchy = true;
    this.mLastMeasureWidth = -1;
    this.mLastMeasureHeight = -1;
    this.mLastMeasureWidthSize = -1;
    this.mLastMeasureHeightSize = -1;
    this.mLastMeasureWidthMode = 0;
    this.mLastMeasureHeightMode = 0;
  }
  
  private void setChildrenConstraints() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getChildCount : ()I
    //   10: istore_2
    //   11: iconst_0
    //   12: istore_1
    //   13: iload_1
    //   14: iload_2
    //   15: if_icmpge -> 49
    //   18: aload_0
    //   19: aload_0
    //   20: iload_1
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   27: astore #5
    //   29: aload #5
    //   31: ifnonnull -> 37
    //   34: goto -> 42
    //   37: aload #5
    //   39: invokevirtual reset : ()V
    //   42: iload_1
    //   43: iconst_1
    //   44: iadd
    //   45: istore_1
    //   46: goto -> 13
    //   49: iload #4
    //   51: ifeq -> 145
    //   54: iconst_0
    //   55: istore_1
    //   56: iload_1
    //   57: iload_2
    //   58: if_icmpge -> 145
    //   61: aload_0
    //   62: iload_1
    //   63: invokevirtual getChildAt : (I)Landroid/view/View;
    //   66: astore #7
    //   68: aload_0
    //   69: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   72: aload #7
    //   74: invokevirtual getId : ()I
    //   77: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   80: astore #6
    //   82: aload_0
    //   83: iconst_0
    //   84: aload #6
    //   86: aload #7
    //   88: invokevirtual getId : ()I
    //   91: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   94: invokevirtual setDesignInformation : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   97: aload #6
    //   99: bipush #47
    //   101: invokevirtual indexOf : (I)I
    //   104: istore_3
    //   105: aload #6
    //   107: astore #5
    //   109: iload_3
    //   110: iconst_m1
    //   111: if_icmpeq -> 124
    //   114: aload #6
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: invokevirtual substring : (I)Ljava/lang/String;
    //   122: astore #5
    //   124: aload_0
    //   125: aload #7
    //   127: invokevirtual getId : ()I
    //   130: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   133: aload #5
    //   135: invokevirtual setDebugName : (Ljava/lang/String;)V
    //   138: iload_1
    //   139: iconst_1
    //   140: iadd
    //   141: istore_1
    //   142: goto -> 56
    //   145: aload_0
    //   146: getfield mConstraintSetId : I
    //   149: iconst_m1
    //   150: if_icmpeq -> 206
    //   153: iconst_0
    //   154: istore_1
    //   155: iload_1
    //   156: iload_2
    //   157: if_icmpge -> 206
    //   160: aload_0
    //   161: iload_1
    //   162: invokevirtual getChildAt : (I)Landroid/view/View;
    //   165: astore #5
    //   167: aload #5
    //   169: invokevirtual getId : ()I
    //   172: aload_0
    //   173: getfield mConstraintSetId : I
    //   176: if_icmpne -> 199
    //   179: aload #5
    //   181: instanceof androidx/constraintlayout/widget/Constraints
    //   184: ifeq -> 199
    //   187: aload_0
    //   188: aload #5
    //   190: checkcast androidx/constraintlayout/widget/Constraints
    //   193: invokevirtual getConstraintSet : ()Landroidx/constraintlayout/widget/ConstraintSet;
    //   196: putfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   199: iload_1
    //   200: iconst_1
    //   201: iadd
    //   202: istore_1
    //   203: goto -> 155
    //   206: aload_0
    //   207: getfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   210: astore #5
    //   212: aload #5
    //   214: ifnull -> 224
    //   217: aload #5
    //   219: aload_0
    //   220: iconst_1
    //   221: invokevirtual applyToInternal : (Landroidx/constraintlayout/widget/ConstraintLayout;Z)V
    //   224: aload_0
    //   225: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   228: invokevirtual removeAllChildren : ()V
    //   231: aload_0
    //   232: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   235: invokevirtual size : ()I
    //   238: istore_3
    //   239: iload_3
    //   240: ifle -> 272
    //   243: iconst_0
    //   244: istore_1
    //   245: iload_1
    //   246: iload_3
    //   247: if_icmpge -> 272
    //   250: aload_0
    //   251: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   254: iload_1
    //   255: invokevirtual get : (I)Ljava/lang/Object;
    //   258: checkcast androidx/constraintlayout/widget/ConstraintHelper
    //   261: aload_0
    //   262: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   265: iload_1
    //   266: iconst_1
    //   267: iadd
    //   268: istore_1
    //   269: goto -> 245
    //   272: iconst_0
    //   273: istore_1
    //   274: iload_1
    //   275: iload_2
    //   276: if_icmpge -> 310
    //   279: aload_0
    //   280: iload_1
    //   281: invokevirtual getChildAt : (I)Landroid/view/View;
    //   284: astore #5
    //   286: aload #5
    //   288: instanceof androidx/constraintlayout/widget/Placeholder
    //   291: ifeq -> 303
    //   294: aload #5
    //   296: checkcast androidx/constraintlayout/widget/Placeholder
    //   299: aload_0
    //   300: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   303: iload_1
    //   304: iconst_1
    //   305: iadd
    //   306: istore_1
    //   307: goto -> 274
    //   310: aload_0
    //   311: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   314: invokevirtual clear : ()V
    //   317: aload_0
    //   318: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   321: iconst_0
    //   322: aload_0
    //   323: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   326: invokevirtual put : (ILjava/lang/Object;)V
    //   329: aload_0
    //   330: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   333: aload_0
    //   334: invokevirtual getId : ()I
    //   337: aload_0
    //   338: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   341: invokevirtual put : (ILjava/lang/Object;)V
    //   344: iconst_0
    //   345: istore_1
    //   346: iload_1
    //   347: iload_2
    //   348: if_icmpge -> 387
    //   351: aload_0
    //   352: iload_1
    //   353: invokevirtual getChildAt : (I)Landroid/view/View;
    //   356: astore #5
    //   358: aload_0
    //   359: aload #5
    //   361: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   364: astore #6
    //   366: aload_0
    //   367: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   370: aload #5
    //   372: invokevirtual getId : ()I
    //   375: aload #6
    //   377: invokevirtual put : (ILjava/lang/Object;)V
    //   380: iload_1
    //   381: iconst_1
    //   382: iadd
    //   383: istore_1
    //   384: goto -> 346
    //   387: iconst_0
    //   388: istore_1
    //   389: iload_1
    //   390: iload_2
    //   391: if_icmpge -> 459
    //   394: aload_0
    //   395: iload_1
    //   396: invokevirtual getChildAt : (I)Landroid/view/View;
    //   399: astore #5
    //   401: aload_0
    //   402: aload #5
    //   404: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   407: astore #6
    //   409: aload #6
    //   411: ifnonnull -> 417
    //   414: goto -> 452
    //   417: aload #5
    //   419: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   422: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   425: astore #7
    //   427: aload_0
    //   428: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   431: aload #6
    //   433: invokevirtual add : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   436: aload_0
    //   437: iload #4
    //   439: aload #5
    //   441: aload #6
    //   443: aload #7
    //   445: aload_0
    //   446: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   449: invokevirtual applyConstraintsFromLayoutParams : (ZLandroid/view/View;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;Landroid/util/SparseArray;)V
    //   452: iload_1
    //   453: iconst_1
    //   454: iadd
    //   455: istore_1
    //   456: goto -> 389
    //   459: return
    //   460: astore #5
    //   462: goto -> 138
    // Exception table:
    //   from	to	target	type
    //   68	105	460	android/content/res/Resources$NotFoundException
    //   114	124	460	android/content/res/Resources$NotFoundException
    //   124	138	460	android/content/res/Resources$NotFoundException
  }
  
  private boolean updateHierarchy() {
    boolean bool1;
    int j = getChildCount();
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < j) {
        if (getChildAt(i).isLayoutRequested()) {
          bool1 = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    if (bool1)
      setChildrenConstraints(); 
    return bool1;
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (Build.VERSION.SDK_INT < 14)
      onViewAdded(paramView); 
  }
  
  protected void applyConstraintsFromLayoutParams(boolean paramBoolean, View paramView, ConstraintWidget paramConstraintWidget, LayoutParams paramLayoutParams, SparseArray<ConstraintWidget> paramSparseArray) {
    paramLayoutParams.validate();
    paramLayoutParams.helped = false;
    paramConstraintWidget.setVisibility(paramView.getVisibility());
    if (paramLayoutParams.isInPlaceholder) {
      paramConstraintWidget.setInPlaceholder(true);
      paramConstraintWidget.setVisibility(8);
    } 
    paramConstraintWidget.setCompanionWidget(paramView);
    if (paramView instanceof ConstraintHelper)
      ((ConstraintHelper)paramView).resolveRtl(paramConstraintWidget, this.mLayoutWidget.isRtl()); 
    if (paramLayoutParams.isGuideline) {
      Guideline guideline = (Guideline)paramConstraintWidget;
      int i = paramLayoutParams.resolvedGuideBegin;
      int j = paramLayoutParams.resolvedGuideEnd;
      float f = paramLayoutParams.resolvedGuidePercent;
      if (Build.VERSION.SDK_INT < 17) {
        i = paramLayoutParams.guideBegin;
        j = paramLayoutParams.guideEnd;
        f = paramLayoutParams.guidePercent;
      } 
      if (f != -1.0F) {
        guideline.setGuidePercent(f);
        return;
      } 
      if (i != -1) {
        guideline.setGuideBegin(i);
        return;
      } 
      if (j != -1) {
        guideline.setGuideEnd(j);
        return;
      } 
    } else {
      int i = paramLayoutParams.resolvedLeftToLeft;
      int j = paramLayoutParams.resolvedLeftToRight;
      int m = paramLayoutParams.resolvedRightToLeft;
      int k = paramLayoutParams.resolvedRightToRight;
      int i1 = paramLayoutParams.resolveGoneLeftMargin;
      int n = paramLayoutParams.resolveGoneRightMargin;
      float f = paramLayoutParams.resolvedHorizontalBias;
      if (Build.VERSION.SDK_INT < 17) {
        k = paramLayoutParams.leftToLeft;
        m = paramLayoutParams.leftToRight;
        int i2 = paramLayoutParams.rightToLeft;
        int i3 = paramLayoutParams.rightToRight;
        i1 = paramLayoutParams.goneLeftMargin;
        n = paramLayoutParams.goneRightMargin;
        f = paramLayoutParams.horizontalBias;
        i = k;
        j = m;
        if (k == -1) {
          i = k;
          j = m;
          if (m == -1)
            if (paramLayoutParams.startToStart != -1) {
              i = paramLayoutParams.startToStart;
              j = m;
            } else {
              i = k;
              j = m;
              if (paramLayoutParams.startToEnd != -1) {
                j = paramLayoutParams.startToEnd;
                i = k;
              } 
            }  
        } 
        m = i2;
        k = i3;
        if (i2 == -1) {
          m = i2;
          k = i3;
          if (i3 == -1)
            if (paramLayoutParams.endToStart != -1) {
              m = paramLayoutParams.endToStart;
              k = i3;
            } else {
              m = i2;
              k = i3;
              if (paramLayoutParams.endToEnd != -1) {
                k = paramLayoutParams.endToEnd;
                m = i2;
              } 
            }  
        } 
      } 
      if (paramLayoutParams.circleConstraint != -1) {
        ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.circleConstraint);
        if (constraintWidget != null)
          paramConstraintWidget.connectCircularConstraint(constraintWidget, paramLayoutParams.circleAngle, paramLayoutParams.circleRadius); 
      } else {
        if (i != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(i);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.LEFT, constraintWidget, ConstraintAnchor.Type.LEFT, paramLayoutParams.leftMargin, i1); 
        } else if (j != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(j);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.LEFT, constraintWidget, ConstraintAnchor.Type.RIGHT, paramLayoutParams.leftMargin, i1); 
        } 
        if (m != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(m);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.RIGHT, constraintWidget, ConstraintAnchor.Type.LEFT, paramLayoutParams.rightMargin, n); 
        } else if (k != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(k);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.RIGHT, constraintWidget, ConstraintAnchor.Type.RIGHT, paramLayoutParams.rightMargin, n); 
        } 
        if (paramLayoutParams.topToTop != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.topToTop);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.TOP, constraintWidget, ConstraintAnchor.Type.TOP, paramLayoutParams.topMargin, paramLayoutParams.goneTopMargin); 
        } else if (paramLayoutParams.topToBottom != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.topToBottom);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.TOP, constraintWidget, ConstraintAnchor.Type.BOTTOM, paramLayoutParams.topMargin, paramLayoutParams.goneTopMargin); 
        } 
        if (paramLayoutParams.bottomToTop != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.bottomToTop);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.BOTTOM, constraintWidget, ConstraintAnchor.Type.TOP, paramLayoutParams.bottomMargin, paramLayoutParams.goneBottomMargin); 
        } else if (paramLayoutParams.bottomToBottom != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.bottomToBottom);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.BOTTOM, constraintWidget, ConstraintAnchor.Type.BOTTOM, paramLayoutParams.bottomMargin, paramLayoutParams.goneBottomMargin); 
        } 
        if (paramLayoutParams.baselineToBaseline != -1) {
          paramView = (View)this.mChildrenByIds.get(paramLayoutParams.baselineToBaseline);
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.baselineToBaseline);
          if (constraintWidget != null && paramView != null && paramView.getLayoutParams() instanceof LayoutParams) {
            LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
            paramLayoutParams.needsBaseline = true;
            layoutParams.needsBaseline = true;
            paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BASELINE).connect(constraintWidget.getAnchor(ConstraintAnchor.Type.BASELINE), 0, -1, true);
            paramConstraintWidget.setHasBaseline(true);
            layoutParams.widget.setHasBaseline(true);
            paramConstraintWidget.getAnchor(ConstraintAnchor.Type.TOP).reset();
            paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).reset();
          } 
        } 
        if (f >= 0.0F)
          paramConstraintWidget.setHorizontalBiasPercent(f); 
        if (paramLayoutParams.verticalBias >= 0.0F)
          paramConstraintWidget.setVerticalBiasPercent(paramLayoutParams.verticalBias); 
      } 
      if (paramBoolean && (paramLayoutParams.editorAbsoluteX != -1 || paramLayoutParams.editorAbsoluteY != -1))
        paramConstraintWidget.setOrigin(paramLayoutParams.editorAbsoluteX, paramLayoutParams.editorAbsoluteY); 
      if (!paramLayoutParams.horizontalDimensionFixed) {
        if (paramLayoutParams.width == -1) {
          if (paramLayoutParams.constrainedWidth) {
            paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          } else {
            paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
          } 
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.LEFT)).mMargin = paramLayoutParams.leftMargin;
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT)).mMargin = paramLayoutParams.rightMargin;
        } else {
          paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          paramConstraintWidget.setWidth(0);
        } 
      } else {
        paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        paramConstraintWidget.setWidth(paramLayoutParams.width);
        if (paramLayoutParams.width == -2)
          paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT); 
      } 
      if (!paramLayoutParams.verticalDimensionFixed) {
        if (paramLayoutParams.height == -1) {
          if (paramLayoutParams.constrainedHeight) {
            paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          } else {
            paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
          } 
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.TOP)).mMargin = paramLayoutParams.topMargin;
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM)).mMargin = paramLayoutParams.bottomMargin;
        } else {
          paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          paramConstraintWidget.setHeight(0);
        } 
      } else {
        paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        paramConstraintWidget.setHeight(paramLayoutParams.height);
        if (paramLayoutParams.height == -2)
          paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT); 
      } 
      paramConstraintWidget.setDimensionRatio(paramLayoutParams.dimensionRatio);
      paramConstraintWidget.setHorizontalWeight(paramLayoutParams.horizontalWeight);
      paramConstraintWidget.setVerticalWeight(paramLayoutParams.verticalWeight);
      paramConstraintWidget.setHorizontalChainStyle(paramLayoutParams.horizontalChainStyle);
      paramConstraintWidget.setVerticalChainStyle(paramLayoutParams.verticalChainStyle);
      paramConstraintWidget.setHorizontalMatchStyle(paramLayoutParams.matchConstraintDefaultWidth, paramLayoutParams.matchConstraintMinWidth, paramLayoutParams.matchConstraintMaxWidth, paramLayoutParams.matchConstraintPercentWidth);
      paramConstraintWidget.setVerticalMatchStyle(paramLayoutParams.matchConstraintDefaultHeight, paramLayoutParams.matchConstraintMinHeight, paramLayoutParams.matchConstraintMaxHeight, paramLayoutParams.matchConstraintPercentHeight);
    } 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList<ConstraintHelper> arrayList = this.mConstraintHelpers;
    if (arrayList != null) {
      int i = arrayList.size();
      if (i > 0) {
        int j;
        for (j = 0; j < i; j++)
          ((ConstraintHelper)this.mConstraintHelpers.get(j)).updatePreDraw(this); 
      } 
    } 
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      int j = getChildCount();
      float f1 = getWidth();
      float f2 = getHeight();
      int i;
      for (i = 0; i < j; i++) {
        View view = getChildAt(i);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(",");
            if (object.length == 4) {
              int m = Integer.parseInt((String)object[0]);
              int i1 = Integer.parseInt((String)object[1]);
              int n = Integer.parseInt((String)object[2]);
              int k = Integer.parseInt((String)object[3]);
              m = (int)(m / 1080.0F * f1);
              i1 = (int)(i1 / 1920.0F * f2);
              n = (int)(n / 1080.0F * f1);
              k = (int)(k / 1920.0F * f2);
              object = new Paint();
              object.setColor(-65536);
              float f3 = m;
              float f4 = i1;
              float f5 = (m + n);
              paramCanvas.drawLine(f3, f4, f5, f4, (Paint)object);
              float f6 = (i1 + k);
              paramCanvas.drawLine(f5, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f5, f6, f3, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f3, f4, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(f3, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f5, f4, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mLayoutWidget.fillMetrics(paramMetrics);
  }
  
  public void forceLayout() {
    markHierarchyDirty();
    super.forceLayout();
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-2, -2);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new LayoutParams(paramLayoutParams);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  public Object getDesignInformation(int paramInt, Object paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      paramObject = paramObject;
      HashMap<String, Integer> hashMap = this.mDesignIds;
      if (hashMap != null && hashMap.containsKey(paramObject))
        return this.mDesignIds.get(paramObject); 
    } 
    return null;
  }
  
  public int getMaxHeight() {
    return this.mMaxHeight;
  }
  
  public int getMaxWidth() {
    return this.mMaxWidth;
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public int getOptimizationLevel() {
    return this.mLayoutWidget.getOptimizationLevel();
  }
  
  public View getViewById(int paramInt) {
    return (View)this.mChildrenByIds.get(paramInt);
  }
  
  public final ConstraintWidget getViewWidget(View paramView) {
    return (ConstraintWidget)((paramView == this) ? this.mLayoutWidget : ((paramView == null) ? null : ((LayoutParams)paramView.getLayoutParams()).widget));
  }
  
  protected boolean isRtl() {
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i >= 17) {
      if (((getContext().getApplicationInfo()).flags & 0x400000) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      bool1 = bool2;
      if (i != 0) {
        bool1 = bool2;
        if (1 == getLayoutDirection())
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public void loadLayoutDescription(int paramInt) {
    if (paramInt != 0)
      try {
        this.mConstraintLayoutSpec = new ConstraintLayoutStates(getContext(), this, paramInt);
        return;
      } catch (android.content.res.Resources.NotFoundException notFoundException) {
        this.mConstraintLayoutSpec = null;
        return;
      }  
    this.mConstraintLayoutSpec = null;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt2 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      ConstraintWidget constraintWidget = layoutParams.widget;
      if ((view.getVisibility() != 8 || layoutParams.isGuideline || layoutParams.isHelper || layoutParams.isVirtualGroup || paramBoolean) && !layoutParams.isInPlaceholder) {
        paramInt4 = constraintWidget.getX();
        int i = constraintWidget.getY();
        int j = constraintWidget.getWidth() + paramInt4;
        int k = constraintWidget.getHeight() + i;
        view.layout(paramInt4, i, j, k);
        if (view instanceof Placeholder) {
          view = ((Placeholder)view).getContent();
          if (view != null) {
            view.setVisibility(0);
            view.layout(paramInt4, i, j, k);
          } 
        } 
      } 
    } 
    paramInt3 = this.mConstraintHelpers.size();
    if (paramInt3 > 0)
      for (paramInt1 = paramInt2; paramInt1 < paramInt3; paramInt1++)
        ((ConstraintHelper)this.mConstraintHelpers.get(paramInt1)).updatePostLayout(this);  
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    this.mOnMeasureWidthMeasureSpec = paramInt1;
    this.mOnMeasureHeightMeasureSpec = paramInt2;
    this.mLayoutWidget.setRtl(isRtl());
    if (this.mDirtyHierarchy) {
      this.mDirtyHierarchy = false;
      if (updateHierarchy())
        this.mLayoutWidget.updateHierarchy(); 
    } 
    resolveSystem(this.mLayoutWidget, this.mOptimizationLevel, paramInt1, paramInt2);
    resolveMeasuredDimension(paramInt1, paramInt2, this.mLayoutWidget.getWidth(), this.mLayoutWidget.getHeight(), this.mLayoutWidget.isWidthMeasuredTooSmall(), this.mLayoutWidget.isHeightMeasuredTooSmall());
  }
  
  public void onViewAdded(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewAdded(paramView); 
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    if (paramView instanceof Guideline && !(constraintWidget instanceof Guideline)) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      layoutParams.widget = (ConstraintWidget)new Guideline();
      layoutParams.isGuideline = true;
      ((Guideline)layoutParams.widget).setOrientation(layoutParams.orientation);
    } 
    if (paramView instanceof ConstraintHelper) {
      ConstraintHelper constraintHelper = (ConstraintHelper)paramView;
      constraintHelper.validateParams();
      ((LayoutParams)paramView.getLayoutParams()).isHelper = true;
      if (!this.mConstraintHelpers.contains(constraintHelper))
        this.mConstraintHelpers.add(constraintHelper); 
    } 
    this.mChildrenByIds.put(paramView.getId(), paramView);
    this.mDirtyHierarchy = true;
  }
  
  public void onViewRemoved(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewRemoved(paramView); 
    this.mChildrenByIds.remove(paramView.getId());
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    this.mLayoutWidget.remove(constraintWidget);
    this.mConstraintHelpers.remove(paramView);
    this.mDirtyHierarchy = true;
  }
  
  protected void parseLayoutDescription(int paramInt) {
    this.mConstraintLayoutSpec = new ConstraintLayoutStates(getContext(), this, paramInt);
  }
  
  public void removeView(View paramView) {
    super.removeView(paramView);
    if (Build.VERSION.SDK_INT < 14)
      onViewRemoved(paramView); 
  }
  
  public void requestLayout() {
    markHierarchyDirty();
    super.requestLayout();
  }
  
  protected void resolveMeasuredDimension(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2) {
    int i = this.mMeasurer.paddingHeight;
    paramInt3 += this.mMeasurer.paddingWidth;
    paramInt4 += i;
    if (Build.VERSION.SDK_INT >= 11) {
      paramInt1 = resolveSizeAndState(paramInt3, paramInt1, 0);
      paramInt3 = resolveSizeAndState(paramInt4, paramInt2, 0);
      paramInt2 = Math.min(this.mMaxWidth, paramInt1 & 0xFFFFFF);
      paramInt3 = Math.min(this.mMaxHeight, paramInt3 & 0xFFFFFF);
      paramInt1 = paramInt2;
      if (paramBoolean1)
        paramInt1 = paramInt2 | 0x1000000; 
      paramInt2 = paramInt3;
      if (paramBoolean2)
        paramInt2 = paramInt3 | 0x1000000; 
      setMeasuredDimension(paramInt1, paramInt2);
      this.mLastMeasureWidth = paramInt1;
      this.mLastMeasureHeight = paramInt2;
      return;
    } 
    setMeasuredDimension(paramInt3, paramInt4);
    this.mLastMeasureWidth = paramInt3;
    this.mLastMeasureHeight = paramInt4;
  }
  
  protected void resolveSystem(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3) {
    int i = View.MeasureSpec.getMode(paramInt2);
    int i1 = View.MeasureSpec.getSize(paramInt2);
    int j = View.MeasureSpec.getMode(paramInt3);
    int m = View.MeasureSpec.getSize(paramInt3);
    int k = Math.max(0, getPaddingTop());
    int i3 = Math.max(0, getPaddingBottom());
    int n = k + i3;
    int i2 = getPaddingWidth();
    this.mMeasurer.captureLayoutInfos(paramInt2, paramInt3, k, i3, i2, n);
    if (Build.VERSION.SDK_INT >= 17) {
      paramInt2 = Math.max(0, getPaddingStart());
      paramInt3 = Math.max(0, getPaddingEnd());
      if (paramInt2 > 0 || paramInt3 > 0) {
        if (isRtl())
          paramInt2 = paramInt3; 
      } else {
        paramInt2 = Math.max(0, getPaddingLeft());
      } 
    } else {
      paramInt2 = Math.max(0, getPaddingLeft());
    } 
    paramInt3 = i1 - i2;
    m -= n;
    setSelfDimensionBehaviour(paramConstraintWidgetContainer, i, paramInt3, j, m);
    paramConstraintWidgetContainer.measure(paramInt1, i, paramInt3, j, m, this.mLastMeasureWidth, this.mLastMeasureHeight, paramInt2, k);
  }
  
  public void setConstraintSet(ConstraintSet paramConstraintSet) {
    this.mConstraintSet = paramConstraintSet;
  }
  
  public void setDesignInformation(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.mDesignIds == null)
        this.mDesignIds = new HashMap<String, Integer>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramInt = ((Integer)paramObject2).intValue();
      this.mDesignIds.put(paramObject1, Integer.valueOf(paramInt));
    } 
  }
  
  public void setId(int paramInt) {
    this.mChildrenByIds.remove(getId());
    super.setId(paramInt);
    this.mChildrenByIds.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.mMaxHeight)
      return; 
    this.mMaxHeight = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.mMaxWidth)
      return; 
    this.mMaxWidth = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.mMinHeight)
      return; 
    this.mMinHeight = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.mMinWidth)
      return; 
    this.mMinWidth = paramInt;
    requestLayout();
  }
  
  public void setOnConstraintsChanged(ConstraintsChangedListener paramConstraintsChangedListener) {
    this.mConstraintsChangedListener = paramConstraintsChangedListener;
    ConstraintLayoutStates constraintLayoutStates = this.mConstraintLayoutSpec;
    if (constraintLayoutStates != null)
      constraintLayoutStates.setOnConstraintsChanged(paramConstraintsChangedListener); 
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    this.mLayoutWidget.setOptimizationLevel(paramInt);
  }
  
  protected void setSelfDimensionBehaviour(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMeasurer : Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;
    //   4: getfield paddingHeight : I
    //   7: istore #6
    //   9: aload_0
    //   10: getfield mMeasurer : Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;
    //   13: getfield paddingWidth : I
    //   16: istore #7
    //   18: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   21: astore #9
    //   23: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   26: astore #10
    //   28: aload_0
    //   29: invokevirtual getChildCount : ()I
    //   32: istore #8
    //   34: iload_2
    //   35: ldc_w -2147483648
    //   38: if_icmpeq -> 102
    //   41: iload_2
    //   42: ifeq -> 72
    //   45: iload_2
    //   46: ldc_w 1073741824
    //   49: if_icmpeq -> 57
    //   52: iconst_0
    //   53: istore_3
    //   54: goto -> 129
    //   57: aload_0
    //   58: getfield mMaxWidth : I
    //   61: iload #7
    //   63: isub
    //   64: iload_3
    //   65: invokestatic min : (II)I
    //   68: istore_3
    //   69: goto -> 129
    //   72: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   75: astore #11
    //   77: aload #11
    //   79: astore #9
    //   81: iload #8
    //   83: ifne -> 52
    //   86: iconst_0
    //   87: aload_0
    //   88: getfield mMinWidth : I
    //   91: invokestatic max : (II)I
    //   94: istore_3
    //   95: aload #11
    //   97: astore #9
    //   99: goto -> 129
    //   102: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   105: astore #11
    //   107: aload #11
    //   109: astore #9
    //   111: iload #8
    //   113: ifne -> 129
    //   116: iconst_0
    //   117: aload_0
    //   118: getfield mMinWidth : I
    //   121: invokestatic max : (II)I
    //   124: istore_3
    //   125: aload #11
    //   127: astore #9
    //   129: iload #4
    //   131: ldc_w -2147483648
    //   134: if_icmpeq -> 204
    //   137: iload #4
    //   139: ifeq -> 173
    //   142: iload #4
    //   144: ldc_w 1073741824
    //   147: if_icmpeq -> 156
    //   150: iconst_0
    //   151: istore #5
    //   153: goto -> 232
    //   156: aload_0
    //   157: getfield mMaxHeight : I
    //   160: iload #6
    //   162: isub
    //   163: iload #5
    //   165: invokestatic min : (II)I
    //   168: istore #5
    //   170: goto -> 232
    //   173: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   176: astore #11
    //   178: aload #11
    //   180: astore #10
    //   182: iload #8
    //   184: ifne -> 150
    //   187: iconst_0
    //   188: aload_0
    //   189: getfield mMinHeight : I
    //   192: invokestatic max : (II)I
    //   195: istore #5
    //   197: aload #11
    //   199: astore #10
    //   201: goto -> 232
    //   204: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   207: astore #11
    //   209: aload #11
    //   211: astore #10
    //   213: iload #8
    //   215: ifne -> 232
    //   218: iconst_0
    //   219: aload_0
    //   220: getfield mMinHeight : I
    //   223: invokestatic max : (II)I
    //   226: istore #5
    //   228: aload #11
    //   230: astore #10
    //   232: iload_3
    //   233: aload_1
    //   234: invokevirtual getWidth : ()I
    //   237: if_icmpne -> 249
    //   240: iload #5
    //   242: aload_1
    //   243: invokevirtual getHeight : ()I
    //   246: if_icmpeq -> 253
    //   249: aload_1
    //   250: invokevirtual invalidateMeasures : ()V
    //   253: aload_1
    //   254: iconst_0
    //   255: invokevirtual setX : (I)V
    //   258: aload_1
    //   259: iconst_0
    //   260: invokevirtual setY : (I)V
    //   263: aload_1
    //   264: aload_0
    //   265: getfield mMaxWidth : I
    //   268: iload #7
    //   270: isub
    //   271: invokevirtual setMaxWidth : (I)V
    //   274: aload_1
    //   275: aload_0
    //   276: getfield mMaxHeight : I
    //   279: iload #6
    //   281: isub
    //   282: invokevirtual setMaxHeight : (I)V
    //   285: aload_1
    //   286: iconst_0
    //   287: invokevirtual setMinWidth : (I)V
    //   290: aload_1
    //   291: iconst_0
    //   292: invokevirtual setMinHeight : (I)V
    //   295: aload_1
    //   296: aload #9
    //   298: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   301: aload_1
    //   302: iload_3
    //   303: invokevirtual setWidth : (I)V
    //   306: aload_1
    //   307: aload #10
    //   309: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   312: aload_1
    //   313: iload #5
    //   315: invokevirtual setHeight : (I)V
    //   318: aload_1
    //   319: aload_0
    //   320: getfield mMinWidth : I
    //   323: iload #7
    //   325: isub
    //   326: invokevirtual setMinWidth : (I)V
    //   329: aload_1
    //   330: aload_0
    //   331: getfield mMinHeight : I
    //   334: iload #6
    //   336: isub
    //   337: invokevirtual setMinHeight : (I)V
    //   340: return
  }
  
  public void setState(int paramInt1, int paramInt2, int paramInt3) {
    ConstraintLayoutStates constraintLayoutStates = this.mConstraintLayoutSpec;
    if (constraintLayoutStates != null)
      constraintLayoutStates.updateConstraints(paramInt1, paramInt2, paramInt3); 
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public static final int BASELINE = 5;
    
    public static final int BOTTOM = 4;
    
    public static final int CHAIN_PACKED = 2;
    
    public static final int CHAIN_SPREAD = 0;
    
    public static final int CHAIN_SPREAD_INSIDE = 1;
    
    public static final int END = 7;
    
    public static final int HORIZONTAL = 0;
    
    public static final int LEFT = 1;
    
    public static final int MATCH_CONSTRAINT = 0;
    
    public static final int MATCH_CONSTRAINT_PERCENT = 2;
    
    public static final int MATCH_CONSTRAINT_SPREAD = 0;
    
    public static final int MATCH_CONSTRAINT_WRAP = 1;
    
    public static final int PARENT_ID = 0;
    
    public static final int RIGHT = 2;
    
    public static final int START = 6;
    
    public static final int TOP = 3;
    
    public static final int UNSET = -1;
    
    public static final int VERTICAL = 1;
    
    public int baselineToBaseline = -1;
    
    public int bottomToBottom = -1;
    
    public int bottomToTop = -1;
    
    public float circleAngle = 0.0F;
    
    public int circleConstraint = -1;
    
    public int circleRadius = 0;
    
    public boolean constrainedHeight = false;
    
    public boolean constrainedWidth = false;
    
    public String constraintTag = null;
    
    public String dimensionRatio = null;
    
    int dimensionRatioSide = 1;
    
    float dimensionRatioValue = 0.0F;
    
    public int editorAbsoluteX = -1;
    
    public int editorAbsoluteY = -1;
    
    public int endToEnd = -1;
    
    public int endToStart = -1;
    
    public int goneBottomMargin = -1;
    
    public int goneEndMargin = -1;
    
    public int goneLeftMargin = -1;
    
    public int goneRightMargin = -1;
    
    public int goneStartMargin = -1;
    
    public int goneTopMargin = -1;
    
    public int guideBegin = -1;
    
    public int guideEnd = -1;
    
    public float guidePercent = -1.0F;
    
    public boolean helped = false;
    
    public float horizontalBias = 0.5F;
    
    public int horizontalChainStyle = 0;
    
    boolean horizontalDimensionFixed = true;
    
    public float horizontalWeight = -1.0F;
    
    boolean isGuideline = false;
    
    boolean isHelper = false;
    
    boolean isInPlaceholder = false;
    
    boolean isVirtualGroup = false;
    
    public int leftToLeft = -1;
    
    public int leftToRight = -1;
    
    public int matchConstraintDefaultHeight = 0;
    
    public int matchConstraintDefaultWidth = 0;
    
    public int matchConstraintMaxHeight = 0;
    
    public int matchConstraintMaxWidth = 0;
    
    public int matchConstraintMinHeight = 0;
    
    public int matchConstraintMinWidth = 0;
    
    public float matchConstraintPercentHeight = 1.0F;
    
    public float matchConstraintPercentWidth = 1.0F;
    
    boolean needsBaseline = false;
    
    public int orientation = -1;
    
    int resolveGoneLeftMargin = -1;
    
    int resolveGoneRightMargin = -1;
    
    int resolvedGuideBegin;
    
    int resolvedGuideEnd;
    
    float resolvedGuidePercent;
    
    float resolvedHorizontalBias = 0.5F;
    
    int resolvedLeftToLeft = -1;
    
    int resolvedLeftToRight = -1;
    
    int resolvedRightToLeft = -1;
    
    int resolvedRightToRight = -1;
    
    public int rightToLeft = -1;
    
    public int rightToRight = -1;
    
    public int startToEnd = -1;
    
    public int startToStart = -1;
    
    public int topToBottom = -1;
    
    public int topToTop = -1;
    
    public float verticalBias = 0.5F;
    
    public int verticalChainStyle = 0;
    
    boolean verticalDimensionFixed = true;
    
    public float verticalWeight = -1.0F;
    
    ConstraintWidget widget = new ConstraintWidget();
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_m1
      //   8: putfield guideBegin : I
      //   11: aload_0
      //   12: iconst_m1
      //   13: putfield guideEnd : I
      //   16: aload_0
      //   17: ldc -1.0
      //   19: putfield guidePercent : F
      //   22: aload_0
      //   23: iconst_m1
      //   24: putfield leftToLeft : I
      //   27: aload_0
      //   28: iconst_m1
      //   29: putfield leftToRight : I
      //   32: aload_0
      //   33: iconst_m1
      //   34: putfield rightToLeft : I
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield rightToRight : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield topToTop : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield topToBottom : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield bottomToTop : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield bottomToBottom : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield baselineToBaseline : I
      //   67: aload_0
      //   68: iconst_m1
      //   69: putfield circleConstraint : I
      //   72: aload_0
      //   73: iconst_0
      //   74: putfield circleRadius : I
      //   77: aload_0
      //   78: fconst_0
      //   79: putfield circleAngle : F
      //   82: aload_0
      //   83: iconst_m1
      //   84: putfield startToEnd : I
      //   87: aload_0
      //   88: iconst_m1
      //   89: putfield startToStart : I
      //   92: aload_0
      //   93: iconst_m1
      //   94: putfield endToStart : I
      //   97: aload_0
      //   98: iconst_m1
      //   99: putfield endToEnd : I
      //   102: aload_0
      //   103: iconst_m1
      //   104: putfield goneLeftMargin : I
      //   107: aload_0
      //   108: iconst_m1
      //   109: putfield goneTopMargin : I
      //   112: aload_0
      //   113: iconst_m1
      //   114: putfield goneRightMargin : I
      //   117: aload_0
      //   118: iconst_m1
      //   119: putfield goneBottomMargin : I
      //   122: aload_0
      //   123: iconst_m1
      //   124: putfield goneStartMargin : I
      //   127: aload_0
      //   128: iconst_m1
      //   129: putfield goneEndMargin : I
      //   132: aload_0
      //   133: ldc 0.5
      //   135: putfield horizontalBias : F
      //   138: aload_0
      //   139: ldc 0.5
      //   141: putfield verticalBias : F
      //   144: aload_0
      //   145: aconst_null
      //   146: putfield dimensionRatio : Ljava/lang/String;
      //   149: aload_0
      //   150: fconst_0
      //   151: putfield dimensionRatioValue : F
      //   154: aload_0
      //   155: iconst_1
      //   156: putfield dimensionRatioSide : I
      //   159: aload_0
      //   160: ldc -1.0
      //   162: putfield horizontalWeight : F
      //   165: aload_0
      //   166: ldc -1.0
      //   168: putfield verticalWeight : F
      //   171: aload_0
      //   172: iconst_0
      //   173: putfield horizontalChainStyle : I
      //   176: aload_0
      //   177: iconst_0
      //   178: putfield verticalChainStyle : I
      //   181: aload_0
      //   182: iconst_0
      //   183: putfield matchConstraintDefaultWidth : I
      //   186: aload_0
      //   187: iconst_0
      //   188: putfield matchConstraintDefaultHeight : I
      //   191: aload_0
      //   192: iconst_0
      //   193: putfield matchConstraintMinWidth : I
      //   196: aload_0
      //   197: iconst_0
      //   198: putfield matchConstraintMinHeight : I
      //   201: aload_0
      //   202: iconst_0
      //   203: putfield matchConstraintMaxWidth : I
      //   206: aload_0
      //   207: iconst_0
      //   208: putfield matchConstraintMaxHeight : I
      //   211: aload_0
      //   212: fconst_1
      //   213: putfield matchConstraintPercentWidth : F
      //   216: aload_0
      //   217: fconst_1
      //   218: putfield matchConstraintPercentHeight : F
      //   221: aload_0
      //   222: iconst_m1
      //   223: putfield editorAbsoluteX : I
      //   226: aload_0
      //   227: iconst_m1
      //   228: putfield editorAbsoluteY : I
      //   231: aload_0
      //   232: iconst_m1
      //   233: putfield orientation : I
      //   236: aload_0
      //   237: iconst_0
      //   238: putfield constrainedWidth : Z
      //   241: aload_0
      //   242: iconst_0
      //   243: putfield constrainedHeight : Z
      //   246: aload_0
      //   247: aconst_null
      //   248: putfield constraintTag : Ljava/lang/String;
      //   251: aload_0
      //   252: iconst_1
      //   253: putfield horizontalDimensionFixed : Z
      //   256: aload_0
      //   257: iconst_1
      //   258: putfield verticalDimensionFixed : Z
      //   261: aload_0
      //   262: iconst_0
      //   263: putfield needsBaseline : Z
      //   266: aload_0
      //   267: iconst_0
      //   268: putfield isGuideline : Z
      //   271: aload_0
      //   272: iconst_0
      //   273: putfield isHelper : Z
      //   276: aload_0
      //   277: iconst_0
      //   278: putfield isInPlaceholder : Z
      //   281: aload_0
      //   282: iconst_0
      //   283: putfield isVirtualGroup : Z
      //   286: aload_0
      //   287: iconst_m1
      //   288: putfield resolvedLeftToLeft : I
      //   291: aload_0
      //   292: iconst_m1
      //   293: putfield resolvedLeftToRight : I
      //   296: aload_0
      //   297: iconst_m1
      //   298: putfield resolvedRightToLeft : I
      //   301: aload_0
      //   302: iconst_m1
      //   303: putfield resolvedRightToRight : I
      //   306: aload_0
      //   307: iconst_m1
      //   308: putfield resolveGoneLeftMargin : I
      //   311: aload_0
      //   312: iconst_m1
      //   313: putfield resolveGoneRightMargin : I
      //   316: aload_0
      //   317: ldc 0.5
      //   319: putfield resolvedHorizontalBias : F
      //   322: aload_0
      //   323: new androidx/constraintlayout/solver/widgets/ConstraintWidget
      //   326: dup
      //   327: invokespecial <init> : ()V
      //   330: putfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   333: aload_0
      //   334: iconst_0
      //   335: putfield helped : Z
      //   338: aload_1
      //   339: aload_2
      //   340: getstatic androidx/constraintlayout/widget/R$styleable.ConstraintLayout_Layout : [I
      //   343: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   346: astore_1
      //   347: aload_1
      //   348: invokevirtual getIndexCount : ()I
      //   351: istore #7
      //   353: iconst_0
      //   354: istore #5
      //   356: iload #5
      //   358: iload #7
      //   360: if_icmpge -> 2096
      //   363: aload_1
      //   364: iload #5
      //   366: invokevirtual getIndex : (I)I
      //   369: istore #6
      //   371: getstatic androidx/constraintlayout/widget/ConstraintLayout$LayoutParams$Table.map : Landroid/util/SparseIntArray;
      //   374: iload #6
      //   376: invokevirtual get : (I)I
      //   379: istore #8
      //   381: iload #8
      //   383: tableswitch default -> 548, 1 -> 2073, 2 -> 2035, 3 -> 2018, 4 -> 1976, 5 -> 1959, 6 -> 1942, 7 -> 1925, 8 -> 1887, 9 -> 1849, 10 -> 1811, 11 -> 1773, 12 -> 1735, 13 -> 1697, 14 -> 1659, 15 -> 1621, 16 -> 1583, 17 -> 1545, 18 -> 1507, 19 -> 1469, 20 -> 1431, 21 -> 1414, 22 -> 1397, 23 -> 1380, 24 -> 1363, 25 -> 1346, 26 -> 1329, 27 -> 1312, 28 -> 1295, 29 -> 1278, 30 -> 1261, 31 -> 1227, 32 -> 1193, 33 -> 1152, 34 -> 1111, 35 -> 1085, 36 -> 1044, 37 -> 1003, 38 -> 977
      //   548: iload #8
      //   550: tableswitch default -> 596, 44 -> 708, 45 -> 691, 46 -> 674, 47 -> 660, 48 -> 646, 49 -> 629, 50 -> 612, 51 -> 599
      //   596: goto -> 2087
      //   599: aload_0
      //   600: aload_1
      //   601: iload #6
      //   603: invokevirtual getString : (I)Ljava/lang/String;
      //   606: putfield constraintTag : Ljava/lang/String;
      //   609: goto -> 2087
      //   612: aload_0
      //   613: aload_1
      //   614: iload #6
      //   616: aload_0
      //   617: getfield editorAbsoluteY : I
      //   620: invokevirtual getDimensionPixelOffset : (II)I
      //   623: putfield editorAbsoluteY : I
      //   626: goto -> 2087
      //   629: aload_0
      //   630: aload_1
      //   631: iload #6
      //   633: aload_0
      //   634: getfield editorAbsoluteX : I
      //   637: invokevirtual getDimensionPixelOffset : (II)I
      //   640: putfield editorAbsoluteX : I
      //   643: goto -> 2087
      //   646: aload_0
      //   647: aload_1
      //   648: iload #6
      //   650: iconst_0
      //   651: invokevirtual getInt : (II)I
      //   654: putfield verticalChainStyle : I
      //   657: goto -> 2087
      //   660: aload_0
      //   661: aload_1
      //   662: iload #6
      //   664: iconst_0
      //   665: invokevirtual getInt : (II)I
      //   668: putfield horizontalChainStyle : I
      //   671: goto -> 2087
      //   674: aload_0
      //   675: aload_1
      //   676: iload #6
      //   678: aload_0
      //   679: getfield verticalWeight : F
      //   682: invokevirtual getFloat : (IF)F
      //   685: putfield verticalWeight : F
      //   688: goto -> 2087
      //   691: aload_0
      //   692: aload_1
      //   693: iload #6
      //   695: aload_0
      //   696: getfield horizontalWeight : F
      //   699: invokevirtual getFloat : (IF)F
      //   702: putfield horizontalWeight : F
      //   705: goto -> 2087
      //   708: aload_1
      //   709: iload #6
      //   711: invokevirtual getString : (I)Ljava/lang/String;
      //   714: astore_2
      //   715: aload_0
      //   716: aload_2
      //   717: putfield dimensionRatio : Ljava/lang/String;
      //   720: aload_0
      //   721: ldc_w NaN
      //   724: putfield dimensionRatioValue : F
      //   727: aload_0
      //   728: iconst_m1
      //   729: putfield dimensionRatioSide : I
      //   732: aload_2
      //   733: ifnull -> 2087
      //   736: aload_2
      //   737: invokevirtual length : ()I
      //   740: istore #8
      //   742: aload_0
      //   743: getfield dimensionRatio : Ljava/lang/String;
      //   746: bipush #44
      //   748: invokevirtual indexOf : (I)I
      //   751: istore #6
      //   753: iload #6
      //   755: ifle -> 820
      //   758: iload #6
      //   760: iload #8
      //   762: iconst_1
      //   763: isub
      //   764: if_icmpge -> 820
      //   767: aload_0
      //   768: getfield dimensionRatio : Ljava/lang/String;
      //   771: iconst_0
      //   772: iload #6
      //   774: invokevirtual substring : (II)Ljava/lang/String;
      //   777: astore_2
      //   778: aload_2
      //   779: ldc_w 'W'
      //   782: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   785: ifeq -> 796
      //   788: aload_0
      //   789: iconst_0
      //   790: putfield dimensionRatioSide : I
      //   793: goto -> 811
      //   796: aload_2
      //   797: ldc_w 'H'
      //   800: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   803: ifeq -> 811
      //   806: aload_0
      //   807: iconst_1
      //   808: putfield dimensionRatioSide : I
      //   811: iload #6
      //   813: iconst_1
      //   814: iadd
      //   815: istore #6
      //   817: goto -> 823
      //   820: iconst_0
      //   821: istore #6
      //   823: aload_0
      //   824: getfield dimensionRatio : Ljava/lang/String;
      //   827: bipush #58
      //   829: invokevirtual indexOf : (I)I
      //   832: istore #9
      //   834: iload #9
      //   836: iflt -> 949
      //   839: iload #9
      //   841: iload #8
      //   843: iconst_1
      //   844: isub
      //   845: if_icmpge -> 949
      //   848: aload_0
      //   849: getfield dimensionRatio : Ljava/lang/String;
      //   852: iload #6
      //   854: iload #9
      //   856: invokevirtual substring : (II)Ljava/lang/String;
      //   859: astore_2
      //   860: aload_0
      //   861: getfield dimensionRatio : Ljava/lang/String;
      //   864: iload #9
      //   866: iconst_1
      //   867: iadd
      //   868: invokevirtual substring : (I)Ljava/lang/String;
      //   871: astore #10
      //   873: aload_2
      //   874: invokevirtual length : ()I
      //   877: ifle -> 2087
      //   880: aload #10
      //   882: invokevirtual length : ()I
      //   885: ifle -> 2087
      //   888: aload_2
      //   889: invokestatic parseFloat : (Ljava/lang/String;)F
      //   892: fstore_3
      //   893: aload #10
      //   895: invokestatic parseFloat : (Ljava/lang/String;)F
      //   898: fstore #4
      //   900: fload_3
      //   901: fconst_0
      //   902: fcmpl
      //   903: ifle -> 2087
      //   906: fload #4
      //   908: fconst_0
      //   909: fcmpl
      //   910: ifle -> 2087
      //   913: aload_0
      //   914: getfield dimensionRatioSide : I
      //   917: iconst_1
      //   918: if_icmpne -> 935
      //   921: aload_0
      //   922: fload #4
      //   924: fload_3
      //   925: fdiv
      //   926: invokestatic abs : (F)F
      //   929: putfield dimensionRatioValue : F
      //   932: goto -> 2087
      //   935: aload_0
      //   936: fload_3
      //   937: fload #4
      //   939: fdiv
      //   940: invokestatic abs : (F)F
      //   943: putfield dimensionRatioValue : F
      //   946: goto -> 2087
      //   949: aload_0
      //   950: getfield dimensionRatio : Ljava/lang/String;
      //   953: iload #6
      //   955: invokevirtual substring : (I)Ljava/lang/String;
      //   958: astore_2
      //   959: aload_2
      //   960: invokevirtual length : ()I
      //   963: ifle -> 2087
      //   966: aload_0
      //   967: aload_2
      //   968: invokestatic parseFloat : (Ljava/lang/String;)F
      //   971: putfield dimensionRatioValue : F
      //   974: goto -> 2087
      //   977: aload_0
      //   978: fconst_0
      //   979: aload_1
      //   980: iload #6
      //   982: aload_0
      //   983: getfield matchConstraintPercentHeight : F
      //   986: invokevirtual getFloat : (IF)F
      //   989: invokestatic max : (FF)F
      //   992: putfield matchConstraintPercentHeight : F
      //   995: aload_0
      //   996: iconst_2
      //   997: putfield matchConstraintDefaultHeight : I
      //   1000: goto -> 2087
      //   1003: aload_0
      //   1004: aload_1
      //   1005: iload #6
      //   1007: aload_0
      //   1008: getfield matchConstraintMaxHeight : I
      //   1011: invokevirtual getDimensionPixelSize : (II)I
      //   1014: putfield matchConstraintMaxHeight : I
      //   1017: goto -> 2087
      //   1020: aload_1
      //   1021: iload #6
      //   1023: aload_0
      //   1024: getfield matchConstraintMaxHeight : I
      //   1027: invokevirtual getInt : (II)I
      //   1030: bipush #-2
      //   1032: if_icmpne -> 2087
      //   1035: aload_0
      //   1036: bipush #-2
      //   1038: putfield matchConstraintMaxHeight : I
      //   1041: goto -> 2087
      //   1044: aload_0
      //   1045: aload_1
      //   1046: iload #6
      //   1048: aload_0
      //   1049: getfield matchConstraintMinHeight : I
      //   1052: invokevirtual getDimensionPixelSize : (II)I
      //   1055: putfield matchConstraintMinHeight : I
      //   1058: goto -> 2087
      //   1061: aload_1
      //   1062: iload #6
      //   1064: aload_0
      //   1065: getfield matchConstraintMinHeight : I
      //   1068: invokevirtual getInt : (II)I
      //   1071: bipush #-2
      //   1073: if_icmpne -> 2087
      //   1076: aload_0
      //   1077: bipush #-2
      //   1079: putfield matchConstraintMinHeight : I
      //   1082: goto -> 2087
      //   1085: aload_0
      //   1086: fconst_0
      //   1087: aload_1
      //   1088: iload #6
      //   1090: aload_0
      //   1091: getfield matchConstraintPercentWidth : F
      //   1094: invokevirtual getFloat : (IF)F
      //   1097: invokestatic max : (FF)F
      //   1100: putfield matchConstraintPercentWidth : F
      //   1103: aload_0
      //   1104: iconst_2
      //   1105: putfield matchConstraintDefaultWidth : I
      //   1108: goto -> 2087
      //   1111: aload_0
      //   1112: aload_1
      //   1113: iload #6
      //   1115: aload_0
      //   1116: getfield matchConstraintMaxWidth : I
      //   1119: invokevirtual getDimensionPixelSize : (II)I
      //   1122: putfield matchConstraintMaxWidth : I
      //   1125: goto -> 2087
      //   1128: aload_1
      //   1129: iload #6
      //   1131: aload_0
      //   1132: getfield matchConstraintMaxWidth : I
      //   1135: invokevirtual getInt : (II)I
      //   1138: bipush #-2
      //   1140: if_icmpne -> 2087
      //   1143: aload_0
      //   1144: bipush #-2
      //   1146: putfield matchConstraintMaxWidth : I
      //   1149: goto -> 2087
      //   1152: aload_0
      //   1153: aload_1
      //   1154: iload #6
      //   1156: aload_0
      //   1157: getfield matchConstraintMinWidth : I
      //   1160: invokevirtual getDimensionPixelSize : (II)I
      //   1163: putfield matchConstraintMinWidth : I
      //   1166: goto -> 2087
      //   1169: aload_1
      //   1170: iload #6
      //   1172: aload_0
      //   1173: getfield matchConstraintMinWidth : I
      //   1176: invokevirtual getInt : (II)I
      //   1179: bipush #-2
      //   1181: if_icmpne -> 2087
      //   1184: aload_0
      //   1185: bipush #-2
      //   1187: putfield matchConstraintMinWidth : I
      //   1190: goto -> 2087
      //   1193: aload_1
      //   1194: iload #6
      //   1196: iconst_0
      //   1197: invokevirtual getInt : (II)I
      //   1200: istore #6
      //   1202: aload_0
      //   1203: iload #6
      //   1205: putfield matchConstraintDefaultHeight : I
      //   1208: iload #6
      //   1210: iconst_1
      //   1211: if_icmpne -> 2087
      //   1214: ldc_w 'ConstraintLayout'
      //   1217: ldc_w 'layout_constraintHeight_default="wrap" is deprecated.\\nUse layout_height="WRAP_CONTENT" and layout_constrainedHeight="true" instead.'
      //   1220: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1223: pop
      //   1224: goto -> 2087
      //   1227: aload_1
      //   1228: iload #6
      //   1230: iconst_0
      //   1231: invokevirtual getInt : (II)I
      //   1234: istore #6
      //   1236: aload_0
      //   1237: iload #6
      //   1239: putfield matchConstraintDefaultWidth : I
      //   1242: iload #6
      //   1244: iconst_1
      //   1245: if_icmpne -> 2087
      //   1248: ldc_w 'ConstraintLayout'
      //   1251: ldc_w 'layout_constraintWidth_default="wrap" is deprecated.\\nUse layout_width="WRAP_CONTENT" and layout_constrainedWidth="true" instead.'
      //   1254: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1257: pop
      //   1258: goto -> 2087
      //   1261: aload_0
      //   1262: aload_1
      //   1263: iload #6
      //   1265: aload_0
      //   1266: getfield verticalBias : F
      //   1269: invokevirtual getFloat : (IF)F
      //   1272: putfield verticalBias : F
      //   1275: goto -> 2087
      //   1278: aload_0
      //   1279: aload_1
      //   1280: iload #6
      //   1282: aload_0
      //   1283: getfield horizontalBias : F
      //   1286: invokevirtual getFloat : (IF)F
      //   1289: putfield horizontalBias : F
      //   1292: goto -> 2087
      //   1295: aload_0
      //   1296: aload_1
      //   1297: iload #6
      //   1299: aload_0
      //   1300: getfield constrainedHeight : Z
      //   1303: invokevirtual getBoolean : (IZ)Z
      //   1306: putfield constrainedHeight : Z
      //   1309: goto -> 2087
      //   1312: aload_0
      //   1313: aload_1
      //   1314: iload #6
      //   1316: aload_0
      //   1317: getfield constrainedWidth : Z
      //   1320: invokevirtual getBoolean : (IZ)Z
      //   1323: putfield constrainedWidth : Z
      //   1326: goto -> 2087
      //   1329: aload_0
      //   1330: aload_1
      //   1331: iload #6
      //   1333: aload_0
      //   1334: getfield goneEndMargin : I
      //   1337: invokevirtual getDimensionPixelSize : (II)I
      //   1340: putfield goneEndMargin : I
      //   1343: goto -> 2087
      //   1346: aload_0
      //   1347: aload_1
      //   1348: iload #6
      //   1350: aload_0
      //   1351: getfield goneStartMargin : I
      //   1354: invokevirtual getDimensionPixelSize : (II)I
      //   1357: putfield goneStartMargin : I
      //   1360: goto -> 2087
      //   1363: aload_0
      //   1364: aload_1
      //   1365: iload #6
      //   1367: aload_0
      //   1368: getfield goneBottomMargin : I
      //   1371: invokevirtual getDimensionPixelSize : (II)I
      //   1374: putfield goneBottomMargin : I
      //   1377: goto -> 2087
      //   1380: aload_0
      //   1381: aload_1
      //   1382: iload #6
      //   1384: aload_0
      //   1385: getfield goneRightMargin : I
      //   1388: invokevirtual getDimensionPixelSize : (II)I
      //   1391: putfield goneRightMargin : I
      //   1394: goto -> 2087
      //   1397: aload_0
      //   1398: aload_1
      //   1399: iload #6
      //   1401: aload_0
      //   1402: getfield goneTopMargin : I
      //   1405: invokevirtual getDimensionPixelSize : (II)I
      //   1408: putfield goneTopMargin : I
      //   1411: goto -> 2087
      //   1414: aload_0
      //   1415: aload_1
      //   1416: iload #6
      //   1418: aload_0
      //   1419: getfield goneLeftMargin : I
      //   1422: invokevirtual getDimensionPixelSize : (II)I
      //   1425: putfield goneLeftMargin : I
      //   1428: goto -> 2087
      //   1431: aload_1
      //   1432: iload #6
      //   1434: aload_0
      //   1435: getfield endToEnd : I
      //   1438: invokevirtual getResourceId : (II)I
      //   1441: istore #8
      //   1443: aload_0
      //   1444: iload #8
      //   1446: putfield endToEnd : I
      //   1449: iload #8
      //   1451: iconst_m1
      //   1452: if_icmpne -> 2087
      //   1455: aload_0
      //   1456: aload_1
      //   1457: iload #6
      //   1459: iconst_m1
      //   1460: invokevirtual getInt : (II)I
      //   1463: putfield endToEnd : I
      //   1466: goto -> 2087
      //   1469: aload_1
      //   1470: iload #6
      //   1472: aload_0
      //   1473: getfield endToStart : I
      //   1476: invokevirtual getResourceId : (II)I
      //   1479: istore #8
      //   1481: aload_0
      //   1482: iload #8
      //   1484: putfield endToStart : I
      //   1487: iload #8
      //   1489: iconst_m1
      //   1490: if_icmpne -> 2087
      //   1493: aload_0
      //   1494: aload_1
      //   1495: iload #6
      //   1497: iconst_m1
      //   1498: invokevirtual getInt : (II)I
      //   1501: putfield endToStart : I
      //   1504: goto -> 2087
      //   1507: aload_1
      //   1508: iload #6
      //   1510: aload_0
      //   1511: getfield startToStart : I
      //   1514: invokevirtual getResourceId : (II)I
      //   1517: istore #8
      //   1519: aload_0
      //   1520: iload #8
      //   1522: putfield startToStart : I
      //   1525: iload #8
      //   1527: iconst_m1
      //   1528: if_icmpne -> 2087
      //   1531: aload_0
      //   1532: aload_1
      //   1533: iload #6
      //   1535: iconst_m1
      //   1536: invokevirtual getInt : (II)I
      //   1539: putfield startToStart : I
      //   1542: goto -> 2087
      //   1545: aload_1
      //   1546: iload #6
      //   1548: aload_0
      //   1549: getfield startToEnd : I
      //   1552: invokevirtual getResourceId : (II)I
      //   1555: istore #8
      //   1557: aload_0
      //   1558: iload #8
      //   1560: putfield startToEnd : I
      //   1563: iload #8
      //   1565: iconst_m1
      //   1566: if_icmpne -> 2087
      //   1569: aload_0
      //   1570: aload_1
      //   1571: iload #6
      //   1573: iconst_m1
      //   1574: invokevirtual getInt : (II)I
      //   1577: putfield startToEnd : I
      //   1580: goto -> 2087
      //   1583: aload_1
      //   1584: iload #6
      //   1586: aload_0
      //   1587: getfield baselineToBaseline : I
      //   1590: invokevirtual getResourceId : (II)I
      //   1593: istore #8
      //   1595: aload_0
      //   1596: iload #8
      //   1598: putfield baselineToBaseline : I
      //   1601: iload #8
      //   1603: iconst_m1
      //   1604: if_icmpne -> 2087
      //   1607: aload_0
      //   1608: aload_1
      //   1609: iload #6
      //   1611: iconst_m1
      //   1612: invokevirtual getInt : (II)I
      //   1615: putfield baselineToBaseline : I
      //   1618: goto -> 2087
      //   1621: aload_1
      //   1622: iload #6
      //   1624: aload_0
      //   1625: getfield bottomToBottom : I
      //   1628: invokevirtual getResourceId : (II)I
      //   1631: istore #8
      //   1633: aload_0
      //   1634: iload #8
      //   1636: putfield bottomToBottom : I
      //   1639: iload #8
      //   1641: iconst_m1
      //   1642: if_icmpne -> 2087
      //   1645: aload_0
      //   1646: aload_1
      //   1647: iload #6
      //   1649: iconst_m1
      //   1650: invokevirtual getInt : (II)I
      //   1653: putfield bottomToBottom : I
      //   1656: goto -> 2087
      //   1659: aload_1
      //   1660: iload #6
      //   1662: aload_0
      //   1663: getfield bottomToTop : I
      //   1666: invokevirtual getResourceId : (II)I
      //   1669: istore #8
      //   1671: aload_0
      //   1672: iload #8
      //   1674: putfield bottomToTop : I
      //   1677: iload #8
      //   1679: iconst_m1
      //   1680: if_icmpne -> 2087
      //   1683: aload_0
      //   1684: aload_1
      //   1685: iload #6
      //   1687: iconst_m1
      //   1688: invokevirtual getInt : (II)I
      //   1691: putfield bottomToTop : I
      //   1694: goto -> 2087
      //   1697: aload_1
      //   1698: iload #6
      //   1700: aload_0
      //   1701: getfield topToBottom : I
      //   1704: invokevirtual getResourceId : (II)I
      //   1707: istore #8
      //   1709: aload_0
      //   1710: iload #8
      //   1712: putfield topToBottom : I
      //   1715: iload #8
      //   1717: iconst_m1
      //   1718: if_icmpne -> 2087
      //   1721: aload_0
      //   1722: aload_1
      //   1723: iload #6
      //   1725: iconst_m1
      //   1726: invokevirtual getInt : (II)I
      //   1729: putfield topToBottom : I
      //   1732: goto -> 2087
      //   1735: aload_1
      //   1736: iload #6
      //   1738: aload_0
      //   1739: getfield topToTop : I
      //   1742: invokevirtual getResourceId : (II)I
      //   1745: istore #8
      //   1747: aload_0
      //   1748: iload #8
      //   1750: putfield topToTop : I
      //   1753: iload #8
      //   1755: iconst_m1
      //   1756: if_icmpne -> 2087
      //   1759: aload_0
      //   1760: aload_1
      //   1761: iload #6
      //   1763: iconst_m1
      //   1764: invokevirtual getInt : (II)I
      //   1767: putfield topToTop : I
      //   1770: goto -> 2087
      //   1773: aload_1
      //   1774: iload #6
      //   1776: aload_0
      //   1777: getfield rightToRight : I
      //   1780: invokevirtual getResourceId : (II)I
      //   1783: istore #8
      //   1785: aload_0
      //   1786: iload #8
      //   1788: putfield rightToRight : I
      //   1791: iload #8
      //   1793: iconst_m1
      //   1794: if_icmpne -> 2087
      //   1797: aload_0
      //   1798: aload_1
      //   1799: iload #6
      //   1801: iconst_m1
      //   1802: invokevirtual getInt : (II)I
      //   1805: putfield rightToRight : I
      //   1808: goto -> 2087
      //   1811: aload_1
      //   1812: iload #6
      //   1814: aload_0
      //   1815: getfield rightToLeft : I
      //   1818: invokevirtual getResourceId : (II)I
      //   1821: istore #8
      //   1823: aload_0
      //   1824: iload #8
      //   1826: putfield rightToLeft : I
      //   1829: iload #8
      //   1831: iconst_m1
      //   1832: if_icmpne -> 2087
      //   1835: aload_0
      //   1836: aload_1
      //   1837: iload #6
      //   1839: iconst_m1
      //   1840: invokevirtual getInt : (II)I
      //   1843: putfield rightToLeft : I
      //   1846: goto -> 2087
      //   1849: aload_1
      //   1850: iload #6
      //   1852: aload_0
      //   1853: getfield leftToRight : I
      //   1856: invokevirtual getResourceId : (II)I
      //   1859: istore #8
      //   1861: aload_0
      //   1862: iload #8
      //   1864: putfield leftToRight : I
      //   1867: iload #8
      //   1869: iconst_m1
      //   1870: if_icmpne -> 2087
      //   1873: aload_0
      //   1874: aload_1
      //   1875: iload #6
      //   1877: iconst_m1
      //   1878: invokevirtual getInt : (II)I
      //   1881: putfield leftToRight : I
      //   1884: goto -> 2087
      //   1887: aload_1
      //   1888: iload #6
      //   1890: aload_0
      //   1891: getfield leftToLeft : I
      //   1894: invokevirtual getResourceId : (II)I
      //   1897: istore #8
      //   1899: aload_0
      //   1900: iload #8
      //   1902: putfield leftToLeft : I
      //   1905: iload #8
      //   1907: iconst_m1
      //   1908: if_icmpne -> 2087
      //   1911: aload_0
      //   1912: aload_1
      //   1913: iload #6
      //   1915: iconst_m1
      //   1916: invokevirtual getInt : (II)I
      //   1919: putfield leftToLeft : I
      //   1922: goto -> 2087
      //   1925: aload_0
      //   1926: aload_1
      //   1927: iload #6
      //   1929: aload_0
      //   1930: getfield guidePercent : F
      //   1933: invokevirtual getFloat : (IF)F
      //   1936: putfield guidePercent : F
      //   1939: goto -> 2087
      //   1942: aload_0
      //   1943: aload_1
      //   1944: iload #6
      //   1946: aload_0
      //   1947: getfield guideEnd : I
      //   1950: invokevirtual getDimensionPixelOffset : (II)I
      //   1953: putfield guideEnd : I
      //   1956: goto -> 2087
      //   1959: aload_0
      //   1960: aload_1
      //   1961: iload #6
      //   1963: aload_0
      //   1964: getfield guideBegin : I
      //   1967: invokevirtual getDimensionPixelOffset : (II)I
      //   1970: putfield guideBegin : I
      //   1973: goto -> 2087
      //   1976: aload_1
      //   1977: iload #6
      //   1979: aload_0
      //   1980: getfield circleAngle : F
      //   1983: invokevirtual getFloat : (IF)F
      //   1986: ldc_w 360.0
      //   1989: frem
      //   1990: fstore_3
      //   1991: aload_0
      //   1992: fload_3
      //   1993: putfield circleAngle : F
      //   1996: fload_3
      //   1997: fconst_0
      //   1998: fcmpg
      //   1999: ifge -> 2087
      //   2002: aload_0
      //   2003: ldc_w 360.0
      //   2006: fload_3
      //   2007: fsub
      //   2008: ldc_w 360.0
      //   2011: frem
      //   2012: putfield circleAngle : F
      //   2015: goto -> 2087
      //   2018: aload_0
      //   2019: aload_1
      //   2020: iload #6
      //   2022: aload_0
      //   2023: getfield circleRadius : I
      //   2026: invokevirtual getDimensionPixelSize : (II)I
      //   2029: putfield circleRadius : I
      //   2032: goto -> 2087
      //   2035: aload_1
      //   2036: iload #6
      //   2038: aload_0
      //   2039: getfield circleConstraint : I
      //   2042: invokevirtual getResourceId : (II)I
      //   2045: istore #8
      //   2047: aload_0
      //   2048: iload #8
      //   2050: putfield circleConstraint : I
      //   2053: iload #8
      //   2055: iconst_m1
      //   2056: if_icmpne -> 2087
      //   2059: aload_0
      //   2060: aload_1
      //   2061: iload #6
      //   2063: iconst_m1
      //   2064: invokevirtual getInt : (II)I
      //   2067: putfield circleConstraint : I
      //   2070: goto -> 2087
      //   2073: aload_0
      //   2074: aload_1
      //   2075: iload #6
      //   2077: aload_0
      //   2078: getfield orientation : I
      //   2081: invokevirtual getInt : (II)I
      //   2084: putfield orientation : I
      //   2087: iload #5
      //   2089: iconst_1
      //   2090: iadd
      //   2091: istore #5
      //   2093: goto -> 356
      //   2096: aload_1
      //   2097: invokevirtual recycle : ()V
      //   2100: aload_0
      //   2101: invokevirtual validate : ()V
      //   2104: return
      //   2105: astore_2
      //   2106: goto -> 2087
      //   2109: astore_2
      //   2110: goto -> 1020
      //   2113: astore_2
      //   2114: goto -> 1061
      //   2117: astore_2
      //   2118: goto -> 1128
      //   2121: astore_2
      //   2122: goto -> 1169
      // Exception table:
      //   from	to	target	type
      //   888	900	2105	java/lang/NumberFormatException
      //   913	932	2105	java/lang/NumberFormatException
      //   935	946	2105	java/lang/NumberFormatException
      //   966	974	2105	java/lang/NumberFormatException
      //   1003	1017	2109	java/lang/Exception
      //   1044	1058	2113	java/lang/Exception
      //   1111	1125	2117	java/lang/Exception
      //   1152	1166	2121	java/lang/Exception
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.guideBegin = param1LayoutParams.guideBegin;
      this.guideEnd = param1LayoutParams.guideEnd;
      this.guidePercent = param1LayoutParams.guidePercent;
      this.leftToLeft = param1LayoutParams.leftToLeft;
      this.leftToRight = param1LayoutParams.leftToRight;
      this.rightToLeft = param1LayoutParams.rightToLeft;
      this.rightToRight = param1LayoutParams.rightToRight;
      this.topToTop = param1LayoutParams.topToTop;
      this.topToBottom = param1LayoutParams.topToBottom;
      this.bottomToTop = param1LayoutParams.bottomToTop;
      this.bottomToBottom = param1LayoutParams.bottomToBottom;
      this.baselineToBaseline = param1LayoutParams.baselineToBaseline;
      this.circleConstraint = param1LayoutParams.circleConstraint;
      this.circleRadius = param1LayoutParams.circleRadius;
      this.circleAngle = param1LayoutParams.circleAngle;
      this.startToEnd = param1LayoutParams.startToEnd;
      this.startToStart = param1LayoutParams.startToStart;
      this.endToStart = param1LayoutParams.endToStart;
      this.endToEnd = param1LayoutParams.endToEnd;
      this.goneLeftMargin = param1LayoutParams.goneLeftMargin;
      this.goneTopMargin = param1LayoutParams.goneTopMargin;
      this.goneRightMargin = param1LayoutParams.goneRightMargin;
      this.goneBottomMargin = param1LayoutParams.goneBottomMargin;
      this.goneStartMargin = param1LayoutParams.goneStartMargin;
      this.goneEndMargin = param1LayoutParams.goneEndMargin;
      this.horizontalBias = param1LayoutParams.horizontalBias;
      this.verticalBias = param1LayoutParams.verticalBias;
      this.dimensionRatio = param1LayoutParams.dimensionRatio;
      this.dimensionRatioValue = param1LayoutParams.dimensionRatioValue;
      this.dimensionRatioSide = param1LayoutParams.dimensionRatioSide;
      this.horizontalWeight = param1LayoutParams.horizontalWeight;
      this.verticalWeight = param1LayoutParams.verticalWeight;
      this.horizontalChainStyle = param1LayoutParams.horizontalChainStyle;
      this.verticalChainStyle = param1LayoutParams.verticalChainStyle;
      this.constrainedWidth = param1LayoutParams.constrainedWidth;
      this.constrainedHeight = param1LayoutParams.constrainedHeight;
      this.matchConstraintDefaultWidth = param1LayoutParams.matchConstraintDefaultWidth;
      this.matchConstraintDefaultHeight = param1LayoutParams.matchConstraintDefaultHeight;
      this.matchConstraintMinWidth = param1LayoutParams.matchConstraintMinWidth;
      this.matchConstraintMaxWidth = param1LayoutParams.matchConstraintMaxWidth;
      this.matchConstraintMinHeight = param1LayoutParams.matchConstraintMinHeight;
      this.matchConstraintMaxHeight = param1LayoutParams.matchConstraintMaxHeight;
      this.matchConstraintPercentWidth = param1LayoutParams.matchConstraintPercentWidth;
      this.matchConstraintPercentHeight = param1LayoutParams.matchConstraintPercentHeight;
      this.editorAbsoluteX = param1LayoutParams.editorAbsoluteX;
      this.editorAbsoluteY = param1LayoutParams.editorAbsoluteY;
      this.orientation = param1LayoutParams.orientation;
      this.horizontalDimensionFixed = param1LayoutParams.horizontalDimensionFixed;
      this.verticalDimensionFixed = param1LayoutParams.verticalDimensionFixed;
      this.needsBaseline = param1LayoutParams.needsBaseline;
      this.isGuideline = param1LayoutParams.isGuideline;
      this.resolvedLeftToLeft = param1LayoutParams.resolvedLeftToLeft;
      this.resolvedLeftToRight = param1LayoutParams.resolvedLeftToRight;
      this.resolvedRightToLeft = param1LayoutParams.resolvedRightToLeft;
      this.resolvedRightToRight = param1LayoutParams.resolvedRightToRight;
      this.resolveGoneLeftMargin = param1LayoutParams.resolveGoneLeftMargin;
      this.resolveGoneRightMargin = param1LayoutParams.resolveGoneRightMargin;
      this.resolvedHorizontalBias = param1LayoutParams.resolvedHorizontalBias;
      this.constraintTag = param1LayoutParams.constraintTag;
      this.widget = param1LayoutParams.widget;
    }
    
    public String getConstraintTag() {
      return this.constraintTag;
    }
    
    public ConstraintWidget getConstraintWidget() {
      return this.widget;
    }
    
    public void reset() {
      ConstraintWidget constraintWidget = this.widget;
      if (constraintWidget != null)
        constraintWidget.reset(); 
    }
    
    public void resolveLayoutDirection(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield leftMargin : I
      //   4: istore #5
      //   6: aload_0
      //   7: getfield rightMargin : I
      //   10: istore #6
      //   12: getstatic android/os/Build$VERSION.SDK_INT : I
      //   15: istore #7
      //   17: iconst_0
      //   18: istore #4
      //   20: iload #7
      //   22: bipush #17
      //   24: if_icmplt -> 45
      //   27: aload_0
      //   28: iload_1
      //   29: invokespecial resolveLayoutDirection : (I)V
      //   32: iconst_1
      //   33: aload_0
      //   34: invokevirtual getLayoutDirection : ()I
      //   37: if_icmpne -> 45
      //   40: iconst_1
      //   41: istore_1
      //   42: goto -> 47
      //   45: iconst_0
      //   46: istore_1
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield resolvedRightToLeft : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield resolvedRightToRight : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield resolvedLeftToLeft : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield resolvedLeftToRight : I
      //   67: aload_0
      //   68: iconst_m1
      //   69: putfield resolveGoneLeftMargin : I
      //   72: aload_0
      //   73: iconst_m1
      //   74: putfield resolveGoneRightMargin : I
      //   77: aload_0
      //   78: aload_0
      //   79: getfield goneLeftMargin : I
      //   82: putfield resolveGoneLeftMargin : I
      //   85: aload_0
      //   86: aload_0
      //   87: getfield goneRightMargin : I
      //   90: putfield resolveGoneRightMargin : I
      //   93: aload_0
      //   94: getfield horizontalBias : F
      //   97: fstore_2
      //   98: aload_0
      //   99: fload_2
      //   100: putfield resolvedHorizontalBias : F
      //   103: aload_0
      //   104: getfield guideBegin : I
      //   107: istore #7
      //   109: aload_0
      //   110: iload #7
      //   112: putfield resolvedGuideBegin : I
      //   115: aload_0
      //   116: getfield guideEnd : I
      //   119: istore #8
      //   121: aload_0
      //   122: iload #8
      //   124: putfield resolvedGuideEnd : I
      //   127: aload_0
      //   128: getfield guidePercent : F
      //   131: fstore_3
      //   132: aload_0
      //   133: fload_3
      //   134: putfield resolvedGuidePercent : F
      //   137: iload_1
      //   138: ifeq -> 366
      //   141: aload_0
      //   142: getfield startToEnd : I
      //   145: istore_1
      //   146: iload_1
      //   147: iconst_m1
      //   148: if_icmpeq -> 161
      //   151: aload_0
      //   152: iload_1
      //   153: putfield resolvedRightToLeft : I
      //   156: iconst_1
      //   157: istore_1
      //   158: goto -> 185
      //   161: aload_0
      //   162: getfield startToStart : I
      //   165: istore #9
      //   167: iload #4
      //   169: istore_1
      //   170: iload #9
      //   172: iconst_m1
      //   173: if_icmpeq -> 185
      //   176: aload_0
      //   177: iload #9
      //   179: putfield resolvedRightToRight : I
      //   182: goto -> 156
      //   185: aload_0
      //   186: getfield endToStart : I
      //   189: istore #4
      //   191: iload #4
      //   193: iconst_m1
      //   194: if_icmpeq -> 205
      //   197: aload_0
      //   198: iload #4
      //   200: putfield resolvedLeftToRight : I
      //   203: iconst_1
      //   204: istore_1
      //   205: aload_0
      //   206: getfield endToEnd : I
      //   209: istore #4
      //   211: iload #4
      //   213: iconst_m1
      //   214: if_icmpeq -> 225
      //   217: aload_0
      //   218: iload #4
      //   220: putfield resolvedLeftToLeft : I
      //   223: iconst_1
      //   224: istore_1
      //   225: aload_0
      //   226: getfield goneStartMargin : I
      //   229: istore #4
      //   231: iload #4
      //   233: iconst_m1
      //   234: if_icmpeq -> 243
      //   237: aload_0
      //   238: iload #4
      //   240: putfield resolveGoneRightMargin : I
      //   243: aload_0
      //   244: getfield goneEndMargin : I
      //   247: istore #4
      //   249: iload #4
      //   251: iconst_m1
      //   252: if_icmpeq -> 261
      //   255: aload_0
      //   256: iload #4
      //   258: putfield resolveGoneLeftMargin : I
      //   261: iload_1
      //   262: ifeq -> 272
      //   265: aload_0
      //   266: fconst_1
      //   267: fload_2
      //   268: fsub
      //   269: putfield resolvedHorizontalBias : F
      //   272: aload_0
      //   273: getfield isGuideline : Z
      //   276: ifeq -> 456
      //   279: aload_0
      //   280: getfield orientation : I
      //   283: iconst_1
      //   284: if_icmpne -> 456
      //   287: fload_3
      //   288: ldc -1.0
      //   290: fcmpl
      //   291: ifeq -> 314
      //   294: aload_0
      //   295: fconst_1
      //   296: fload_3
      //   297: fsub
      //   298: putfield resolvedGuidePercent : F
      //   301: aload_0
      //   302: iconst_m1
      //   303: putfield resolvedGuideBegin : I
      //   306: aload_0
      //   307: iconst_m1
      //   308: putfield resolvedGuideEnd : I
      //   311: goto -> 456
      //   314: iload #7
      //   316: iconst_m1
      //   317: if_icmpeq -> 340
      //   320: aload_0
      //   321: iload #7
      //   323: putfield resolvedGuideEnd : I
      //   326: aload_0
      //   327: iconst_m1
      //   328: putfield resolvedGuideBegin : I
      //   331: aload_0
      //   332: ldc -1.0
      //   334: putfield resolvedGuidePercent : F
      //   337: goto -> 456
      //   340: iload #8
      //   342: iconst_m1
      //   343: if_icmpeq -> 456
      //   346: aload_0
      //   347: iload #8
      //   349: putfield resolvedGuideBegin : I
      //   352: aload_0
      //   353: iconst_m1
      //   354: putfield resolvedGuideEnd : I
      //   357: aload_0
      //   358: ldc -1.0
      //   360: putfield resolvedGuidePercent : F
      //   363: goto -> 456
      //   366: aload_0
      //   367: getfield startToEnd : I
      //   370: istore_1
      //   371: iload_1
      //   372: iconst_m1
      //   373: if_icmpeq -> 381
      //   376: aload_0
      //   377: iload_1
      //   378: putfield resolvedLeftToRight : I
      //   381: aload_0
      //   382: getfield startToStart : I
      //   385: istore_1
      //   386: iload_1
      //   387: iconst_m1
      //   388: if_icmpeq -> 396
      //   391: aload_0
      //   392: iload_1
      //   393: putfield resolvedLeftToLeft : I
      //   396: aload_0
      //   397: getfield endToStart : I
      //   400: istore_1
      //   401: iload_1
      //   402: iconst_m1
      //   403: if_icmpeq -> 411
      //   406: aload_0
      //   407: iload_1
      //   408: putfield resolvedRightToLeft : I
      //   411: aload_0
      //   412: getfield endToEnd : I
      //   415: istore_1
      //   416: iload_1
      //   417: iconst_m1
      //   418: if_icmpeq -> 426
      //   421: aload_0
      //   422: iload_1
      //   423: putfield resolvedRightToRight : I
      //   426: aload_0
      //   427: getfield goneStartMargin : I
      //   430: istore_1
      //   431: iload_1
      //   432: iconst_m1
      //   433: if_icmpeq -> 441
      //   436: aload_0
      //   437: iload_1
      //   438: putfield resolveGoneLeftMargin : I
      //   441: aload_0
      //   442: getfield goneEndMargin : I
      //   445: istore_1
      //   446: iload_1
      //   447: iconst_m1
      //   448: if_icmpeq -> 456
      //   451: aload_0
      //   452: iload_1
      //   453: putfield resolveGoneRightMargin : I
      //   456: aload_0
      //   457: getfield endToStart : I
      //   460: iconst_m1
      //   461: if_icmpne -> 624
      //   464: aload_0
      //   465: getfield endToEnd : I
      //   468: iconst_m1
      //   469: if_icmpne -> 624
      //   472: aload_0
      //   473: getfield startToStart : I
      //   476: iconst_m1
      //   477: if_icmpne -> 624
      //   480: aload_0
      //   481: getfield startToEnd : I
      //   484: iconst_m1
      //   485: if_icmpne -> 624
      //   488: aload_0
      //   489: getfield rightToLeft : I
      //   492: istore_1
      //   493: iload_1
      //   494: iconst_m1
      //   495: if_icmpeq -> 524
      //   498: aload_0
      //   499: iload_1
      //   500: putfield resolvedRightToLeft : I
      //   503: aload_0
      //   504: getfield rightMargin : I
      //   507: ifgt -> 557
      //   510: iload #6
      //   512: ifle -> 557
      //   515: aload_0
      //   516: iload #6
      //   518: putfield rightMargin : I
      //   521: goto -> 557
      //   524: aload_0
      //   525: getfield rightToRight : I
      //   528: istore_1
      //   529: iload_1
      //   530: iconst_m1
      //   531: if_icmpeq -> 557
      //   534: aload_0
      //   535: iload_1
      //   536: putfield resolvedRightToRight : I
      //   539: aload_0
      //   540: getfield rightMargin : I
      //   543: ifgt -> 557
      //   546: iload #6
      //   548: ifle -> 557
      //   551: aload_0
      //   552: iload #6
      //   554: putfield rightMargin : I
      //   557: aload_0
      //   558: getfield leftToLeft : I
      //   561: istore_1
      //   562: iload_1
      //   563: iconst_m1
      //   564: if_icmpeq -> 591
      //   567: aload_0
      //   568: iload_1
      //   569: putfield resolvedLeftToLeft : I
      //   572: aload_0
      //   573: getfield leftMargin : I
      //   576: ifgt -> 624
      //   579: iload #5
      //   581: ifle -> 624
      //   584: aload_0
      //   585: iload #5
      //   587: putfield leftMargin : I
      //   590: return
      //   591: aload_0
      //   592: getfield leftToRight : I
      //   595: istore_1
      //   596: iload_1
      //   597: iconst_m1
      //   598: if_icmpeq -> 624
      //   601: aload_0
      //   602: iload_1
      //   603: putfield resolvedLeftToRight : I
      //   606: aload_0
      //   607: getfield leftMargin : I
      //   610: ifgt -> 624
      //   613: iload #5
      //   615: ifle -> 624
      //   618: aload_0
      //   619: iload #5
      //   621: putfield leftMargin : I
      //   624: return
    }
    
    public void setWidgetDebugName(String param1String) {
      this.widget.setDebugName(param1String);
    }
    
    public void validate() {
      this.isGuideline = false;
      this.horizontalDimensionFixed = true;
      this.verticalDimensionFixed = true;
      if (this.width == -2 && this.constrainedWidth) {
        this.horizontalDimensionFixed = false;
        if (this.matchConstraintDefaultWidth == 0)
          this.matchConstraintDefaultWidth = 1; 
      } 
      if (this.height == -2 && this.constrainedHeight) {
        this.verticalDimensionFixed = false;
        if (this.matchConstraintDefaultHeight == 0)
          this.matchConstraintDefaultHeight = 1; 
      } 
      if (this.width == 0 || this.width == -1) {
        this.horizontalDimensionFixed = false;
        if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
          this.width = -2;
          this.constrainedWidth = true;
        } 
      } 
      if (this.height == 0 || this.height == -1) {
        this.verticalDimensionFixed = false;
        if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
          this.height = -2;
          this.constrainedHeight = true;
        } 
      } 
      if (this.guidePercent != -1.0F || this.guideBegin != -1 || this.guideEnd != -1) {
        this.isGuideline = true;
        this.horizontalDimensionFixed = true;
        this.verticalDimensionFixed = true;
        if (!(this.widget instanceof Guideline))
          this.widget = (ConstraintWidget)new Guideline(); 
        ((Guideline)this.widget).setOrientation(this.orientation);
      } 
    }
    
    private static class Table {
      public static final int ANDROID_ORIENTATION = 1;
      
      public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
      
      public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
      
      public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
      
      public static final int LAYOUT_CONSTRAINT_TAG = 51;
      
      public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
      
      public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
      
      public static final int LAYOUT_GONE_MARGIN_END = 26;
      
      public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
      
      public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
      
      public static final int LAYOUT_GONE_MARGIN_START = 25;
      
      public static final int LAYOUT_GONE_MARGIN_TOP = 22;
      
      public static final int UNUSED = 0;
      
      public static final SparseIntArray map;
      
      static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        map = sparseIntArray;
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTag, 51);
      }
    }
  }
  
  private static class Table {
    public static final int ANDROID_ORIENTATION = 1;
    
    public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
    
    public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
    
    public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
    
    public static final int LAYOUT_CONSTRAINT_TAG = 51;
    
    public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
    
    public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
    
    public static final int LAYOUT_GONE_MARGIN_END = 26;
    
    public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
    
    public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
    
    public static final int LAYOUT_GONE_MARGIN_START = 25;
    
    public static final int LAYOUT_GONE_MARGIN_TOP = 22;
    
    public static final int UNUSED = 0;
    
    public static final SparseIntArray map;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      map = sparseIntArray;
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintTag, 51);
    }
  }
  
  class Measurer implements BasicMeasure.Measurer {
    ConstraintLayout layout;
    
    int layoutHeightSpec;
    
    int layoutWidthSpec;
    
    int paddingBottom;
    
    int paddingHeight;
    
    int paddingTop;
    
    int paddingWidth;
    
    public Measurer(ConstraintLayout param1ConstraintLayout1) {
      this.layout = param1ConstraintLayout1;
    }
    
    public void captureLayoutInfos(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.paddingTop = param1Int3;
      this.paddingBottom = param1Int4;
      this.paddingWidth = param1Int5;
      this.paddingHeight = param1Int6;
      this.layoutWidthSpec = param1Int1;
      this.layoutHeightSpec = param1Int2;
    }
    
    public final void didMeasures() {
      int j = this.layout.getChildCount();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++) {
        View view = this.layout.getChildAt(i);
        if (view instanceof Placeholder)
          ((Placeholder)view).updatePostMeasure(this.layout); 
      } 
      j = this.layout.mConstraintHelpers.size();
      if (j > 0)
        for (i = bool; i < j; i++)
          ((ConstraintHelper)this.layout.mConstraintHelpers.get(i)).updatePostMeasure(this.layout);  
    }
    
    public final void measure(ConstraintWidget param1ConstraintWidget, BasicMeasure.Measure param1Measure) {
      // Byte code:
      //   0: aload_1
      //   1: ifnonnull -> 5
      //   4: return
      //   5: aload_1
      //   6: invokevirtual getVisibility : ()I
      //   9: bipush #8
      //   11: if_icmpne -> 37
      //   14: aload_1
      //   15: invokevirtual isInPlaceholder : ()Z
      //   18: ifne -> 37
      //   21: aload_2
      //   22: iconst_0
      //   23: putfield measuredWidth : I
      //   26: aload_2
      //   27: iconst_0
      //   28: putfield measuredHeight : I
      //   31: aload_2
      //   32: iconst_0
      //   33: putfield measuredBaseline : I
      //   36: return
      //   37: aload_2
      //   38: getfield horizontalBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   41: astore #19
      //   43: aload_2
      //   44: getfield verticalBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   47: astore #20
      //   49: aload_2
      //   50: getfield horizontalDimension : I
      //   53: istore #5
      //   55: aload_2
      //   56: getfield verticalDimension : I
      //   59: istore #8
      //   61: aload_0
      //   62: getfield paddingTop : I
      //   65: aload_0
      //   66: getfield paddingBottom : I
      //   69: iadd
      //   70: istore #9
      //   72: aload_0
      //   73: getfield paddingWidth : I
      //   76: istore #4
      //   78: aload_1
      //   79: invokevirtual getCompanionWidget : ()Ljava/lang/Object;
      //   82: checkcast android/view/View
      //   85: astore #18
      //   87: getstatic androidx/constraintlayout/widget/ConstraintLayout$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintWidget$DimensionBehaviour : [I
      //   90: aload #19
      //   92: invokevirtual ordinal : ()I
      //   95: iaload
      //   96: istore #6
      //   98: iload #6
      //   100: iconst_1
      //   101: if_icmpeq -> 309
      //   104: iload #6
      //   106: iconst_2
      //   107: if_icmpeq -> 282
      //   110: iload #6
      //   112: iconst_3
      //   113: if_icmpeq -> 255
      //   116: iload #6
      //   118: iconst_4
      //   119: if_icmpeq -> 135
      //   122: iconst_0
      //   123: istore #4
      //   125: iconst_0
      //   126: istore #7
      //   128: iload #4
      //   130: istore #5
      //   132: goto -> 329
      //   135: aload_0
      //   136: getfield layoutWidthSpec : I
      //   139: iload #4
      //   141: bipush #-2
      //   143: invokestatic getChildMeasureSpec : (III)I
      //   146: istore #7
      //   148: aload_1
      //   149: getfield mMatchConstraintDefaultWidth : I
      //   152: iconst_1
      //   153: if_icmpne -> 162
      //   156: iconst_1
      //   157: istore #4
      //   159: goto -> 165
      //   162: iconst_0
      //   163: istore #4
      //   165: aload_1
      //   166: getfield wrapMeasure : [I
      //   169: iconst_2
      //   170: iconst_0
      //   171: iastore
      //   172: iload #7
      //   174: istore #5
      //   176: aload_2
      //   177: getfield useCurrentDimensions : Z
      //   180: ifeq -> 303
      //   183: iload #4
      //   185: ifeq -> 210
      //   188: aload_1
      //   189: getfield wrapMeasure : [I
      //   192: iconst_3
      //   193: iaload
      //   194: ifeq -> 210
      //   197: aload_1
      //   198: getfield wrapMeasure : [I
      //   201: iconst_0
      //   202: iaload
      //   203: aload_1
      //   204: invokevirtual getWidth : ()I
      //   207: if_icmpne -> 218
      //   210: aload #18
      //   212: instanceof androidx/constraintlayout/widget/Placeholder
      //   215: ifeq -> 224
      //   218: iconst_1
      //   219: istore #6
      //   221: goto -> 227
      //   224: iconst_0
      //   225: istore #6
      //   227: iload #4
      //   229: ifeq -> 241
      //   232: iload #7
      //   234: istore #5
      //   236: iload #6
      //   238: ifeq -> 303
      //   241: aload_1
      //   242: invokevirtual getWidth : ()I
      //   245: ldc 1073741824
      //   247: invokestatic makeMeasureSpec : (II)I
      //   250: istore #4
      //   252: goto -> 125
      //   255: aload_0
      //   256: getfield layoutWidthSpec : I
      //   259: iload #4
      //   261: aload_1
      //   262: invokevirtual getHorizontalMargin : ()I
      //   265: iadd
      //   266: iconst_m1
      //   267: invokestatic getChildMeasureSpec : (III)I
      //   270: istore #4
      //   272: aload_1
      //   273: getfield wrapMeasure : [I
      //   276: iconst_2
      //   277: iconst_m1
      //   278: iastore
      //   279: goto -> 125
      //   282: aload_0
      //   283: getfield layoutWidthSpec : I
      //   286: iload #4
      //   288: bipush #-2
      //   290: invokestatic getChildMeasureSpec : (III)I
      //   293: istore #5
      //   295: aload_1
      //   296: getfield wrapMeasure : [I
      //   299: iconst_2
      //   300: bipush #-2
      //   302: iastore
      //   303: iconst_1
      //   304: istore #7
      //   306: goto -> 329
      //   309: iload #5
      //   311: ldc 1073741824
      //   313: invokestatic makeMeasureSpec : (II)I
      //   316: istore #4
      //   318: aload_1
      //   319: getfield wrapMeasure : [I
      //   322: iconst_2
      //   323: iload #5
      //   325: iastore
      //   326: goto -> 125
      //   329: getstatic androidx/constraintlayout/widget/ConstraintLayout$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintWidget$DimensionBehaviour : [I
      //   332: aload #20
      //   334: invokevirtual ordinal : ()I
      //   337: iaload
      //   338: istore #4
      //   340: iload #4
      //   342: iconst_1
      //   343: if_icmpeq -> 547
      //   346: iload #4
      //   348: iconst_2
      //   349: if_icmpeq -> 520
      //   352: iload #4
      //   354: iconst_3
      //   355: if_icmpeq -> 493
      //   358: iload #4
      //   360: iconst_4
      //   361: if_icmpeq -> 373
      //   364: iconst_0
      //   365: istore #6
      //   367: iconst_0
      //   368: istore #4
      //   370: goto -> 567
      //   373: aload_0
      //   374: getfield layoutHeightSpec : I
      //   377: iload #9
      //   379: bipush #-2
      //   381: invokestatic getChildMeasureSpec : (III)I
      //   384: istore #9
      //   386: aload_1
      //   387: getfield mMatchConstraintDefaultHeight : I
      //   390: iconst_1
      //   391: if_icmpne -> 400
      //   394: iconst_1
      //   395: istore #6
      //   397: goto -> 403
      //   400: iconst_0
      //   401: istore #6
      //   403: aload_1
      //   404: getfield wrapMeasure : [I
      //   407: iconst_3
      //   408: iconst_0
      //   409: iastore
      //   410: iload #9
      //   412: istore #4
      //   414: aload_2
      //   415: getfield useCurrentDimensions : Z
      //   418: ifeq -> 541
      //   421: iload #6
      //   423: ifeq -> 448
      //   426: aload_1
      //   427: getfield wrapMeasure : [I
      //   430: iconst_2
      //   431: iaload
      //   432: ifeq -> 448
      //   435: aload_1
      //   436: getfield wrapMeasure : [I
      //   439: iconst_1
      //   440: iaload
      //   441: aload_1
      //   442: invokevirtual getHeight : ()I
      //   445: if_icmpne -> 456
      //   448: aload #18
      //   450: instanceof androidx/constraintlayout/widget/Placeholder
      //   453: ifeq -> 462
      //   456: iconst_1
      //   457: istore #8
      //   459: goto -> 465
      //   462: iconst_0
      //   463: istore #8
      //   465: iload #6
      //   467: ifeq -> 479
      //   470: iload #9
      //   472: istore #4
      //   474: iload #8
      //   476: ifeq -> 541
      //   479: aload_1
      //   480: invokevirtual getHeight : ()I
      //   483: ldc 1073741824
      //   485: invokestatic makeMeasureSpec : (II)I
      //   488: istore #4
      //   490: goto -> 517
      //   493: aload_0
      //   494: getfield layoutHeightSpec : I
      //   497: iload #9
      //   499: aload_1
      //   500: invokevirtual getVerticalMargin : ()I
      //   503: iadd
      //   504: iconst_m1
      //   505: invokestatic getChildMeasureSpec : (III)I
      //   508: istore #4
      //   510: aload_1
      //   511: getfield wrapMeasure : [I
      //   514: iconst_3
      //   515: iconst_m1
      //   516: iastore
      //   517: goto -> 564
      //   520: aload_0
      //   521: getfield layoutHeightSpec : I
      //   524: iload #9
      //   526: bipush #-2
      //   528: invokestatic getChildMeasureSpec : (III)I
      //   531: istore #4
      //   533: aload_1
      //   534: getfield wrapMeasure : [I
      //   537: iconst_3
      //   538: bipush #-2
      //   540: iastore
      //   541: iconst_1
      //   542: istore #6
      //   544: goto -> 567
      //   547: iload #8
      //   549: ldc 1073741824
      //   551: invokestatic makeMeasureSpec : (II)I
      //   554: istore #4
      //   556: aload_1
      //   557: getfield wrapMeasure : [I
      //   560: iconst_3
      //   561: iload #8
      //   563: iastore
      //   564: iconst_0
      //   565: istore #6
      //   567: aload #19
      //   569: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   572: if_acmpne -> 581
      //   575: iconst_1
      //   576: istore #8
      //   578: goto -> 584
      //   581: iconst_0
      //   582: istore #8
      //   584: aload #20
      //   586: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   589: if_acmpne -> 598
      //   592: iconst_1
      //   593: istore #13
      //   595: goto -> 601
      //   598: iconst_0
      //   599: istore #13
      //   601: aload #20
      //   603: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   606: if_acmpeq -> 626
      //   609: aload #20
      //   611: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   614: if_acmpne -> 620
      //   617: goto -> 626
      //   620: iconst_0
      //   621: istore #9
      //   623: goto -> 629
      //   626: iconst_1
      //   627: istore #9
      //   629: aload #19
      //   631: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   634: if_acmpeq -> 654
      //   637: aload #19
      //   639: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
      //   642: if_acmpne -> 648
      //   645: goto -> 654
      //   648: iconst_0
      //   649: istore #10
      //   651: goto -> 657
      //   654: iconst_1
      //   655: istore #10
      //   657: iload #8
      //   659: ifeq -> 677
      //   662: aload_1
      //   663: getfield mDimensionRatio : F
      //   666: fconst_0
      //   667: fcmpl
      //   668: ifle -> 677
      //   671: iconst_1
      //   672: istore #11
      //   674: goto -> 680
      //   677: iconst_0
      //   678: istore #11
      //   680: iload #13
      //   682: ifeq -> 700
      //   685: aload_1
      //   686: getfield mDimensionRatio : F
      //   689: fconst_0
      //   690: fcmpl
      //   691: ifle -> 700
      //   694: iconst_1
      //   695: istore #12
      //   697: goto -> 703
      //   700: iconst_0
      //   701: istore #12
      //   703: aload #18
      //   705: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   708: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
      //   711: astore #19
      //   713: aload_2
      //   714: getfield useCurrentDimensions : Z
      //   717: ifne -> 759
      //   720: iload #8
      //   722: ifeq -> 759
      //   725: aload_1
      //   726: getfield mMatchConstraintDefaultWidth : I
      //   729: ifne -> 759
      //   732: iload #13
      //   734: ifeq -> 759
      //   737: aload_1
      //   738: getfield mMatchConstraintDefaultHeight : I
      //   741: ifeq -> 747
      //   744: goto -> 759
      //   747: iconst_0
      //   748: istore #6
      //   750: iconst_0
      //   751: istore #5
      //   753: iconst_0
      //   754: istore #4
      //   756: goto -> 1173
      //   759: aload #18
      //   761: instanceof androidx/constraintlayout/widget/VirtualLayout
      //   764: ifeq -> 797
      //   767: aload_1
      //   768: instanceof androidx/constraintlayout/solver/widgets/VirtualLayout
      //   771: ifeq -> 797
      //   774: aload_1
      //   775: checkcast androidx/constraintlayout/solver/widgets/VirtualLayout
      //   778: astore #20
      //   780: aload #18
      //   782: checkcast androidx/constraintlayout/widget/VirtualLayout
      //   785: aload #20
      //   787: iload #5
      //   789: iload #4
      //   791: invokevirtual onMeasure : (Landroidx/constraintlayout/solver/widgets/VirtualLayout;II)V
      //   794: goto -> 806
      //   797: aload #18
      //   799: iload #5
      //   801: iload #4
      //   803: invokevirtual measure : (II)V
      //   806: aload #18
      //   808: invokevirtual getMeasuredWidth : ()I
      //   811: istore #15
      //   813: aload #18
      //   815: invokevirtual getMeasuredHeight : ()I
      //   818: istore #13
      //   820: aload #18
      //   822: invokevirtual getBaseline : ()I
      //   825: istore #14
      //   827: iload #7
      //   829: ifeq -> 851
      //   832: aload_1
      //   833: getfield wrapMeasure : [I
      //   836: iconst_0
      //   837: iload #15
      //   839: iastore
      //   840: aload_1
      //   841: getfield wrapMeasure : [I
      //   844: iconst_2
      //   845: iload #13
      //   847: iastore
      //   848: goto -> 865
      //   851: aload_1
      //   852: getfield wrapMeasure : [I
      //   855: iconst_0
      //   856: iconst_0
      //   857: iastore
      //   858: aload_1
      //   859: getfield wrapMeasure : [I
      //   862: iconst_2
      //   863: iconst_0
      //   864: iastore
      //   865: iload #6
      //   867: ifeq -> 889
      //   870: aload_1
      //   871: getfield wrapMeasure : [I
      //   874: iconst_1
      //   875: iload #13
      //   877: iastore
      //   878: aload_1
      //   879: getfield wrapMeasure : [I
      //   882: iconst_3
      //   883: iload #15
      //   885: iastore
      //   886: goto -> 903
      //   889: aload_1
      //   890: getfield wrapMeasure : [I
      //   893: iconst_1
      //   894: iconst_0
      //   895: iastore
      //   896: aload_1
      //   897: getfield wrapMeasure : [I
      //   900: iconst_3
      //   901: iconst_0
      //   902: iastore
      //   903: aload_1
      //   904: getfield mMatchConstraintMinWidth : I
      //   907: ifle -> 924
      //   910: aload_1
      //   911: getfield mMatchConstraintMinWidth : I
      //   914: iload #15
      //   916: invokestatic max : (II)I
      //   919: istore #7
      //   921: goto -> 928
      //   924: iload #15
      //   926: istore #7
      //   928: iload #7
      //   930: istore #6
      //   932: aload_1
      //   933: getfield mMatchConstraintMaxWidth : I
      //   936: ifle -> 950
      //   939: aload_1
      //   940: getfield mMatchConstraintMaxWidth : I
      //   943: iload #7
      //   945: invokestatic min : (II)I
      //   948: istore #6
      //   950: aload_1
      //   951: getfield mMatchConstraintMinHeight : I
      //   954: ifle -> 971
      //   957: aload_1
      //   958: getfield mMatchConstraintMinHeight : I
      //   961: iload #13
      //   963: invokestatic max : (II)I
      //   966: istore #8
      //   968: goto -> 975
      //   971: iload #13
      //   973: istore #8
      //   975: iload #8
      //   977: istore #7
      //   979: aload_1
      //   980: getfield mMatchConstraintMaxHeight : I
      //   983: ifle -> 997
      //   986: aload_1
      //   987: getfield mMatchConstraintMaxHeight : I
      //   990: iload #8
      //   992: invokestatic min : (II)I
      //   995: istore #7
      //   997: iload #11
      //   999: ifeq -> 1030
      //   1002: iload #9
      //   1004: ifeq -> 1030
      //   1007: aload_1
      //   1008: getfield mDimensionRatio : F
      //   1011: fstore_3
      //   1012: iload #7
      //   1014: i2f
      //   1015: fload_3
      //   1016: fmul
      //   1017: ldc 0.5
      //   1019: fadd
      //   1020: f2i
      //   1021: istore #9
      //   1023: iload #7
      //   1025: istore #8
      //   1027: goto -> 1076
      //   1030: iload #6
      //   1032: istore #9
      //   1034: iload #7
      //   1036: istore #8
      //   1038: iload #12
      //   1040: ifeq -> 1076
      //   1043: iload #6
      //   1045: istore #9
      //   1047: iload #7
      //   1049: istore #8
      //   1051: iload #10
      //   1053: ifeq -> 1076
      //   1056: aload_1
      //   1057: getfield mDimensionRatio : F
      //   1060: fstore_3
      //   1061: iload #6
      //   1063: i2f
      //   1064: fload_3
      //   1065: fdiv
      //   1066: ldc 0.5
      //   1068: fadd
      //   1069: f2i
      //   1070: istore #8
      //   1072: iload #6
      //   1074: istore #9
      //   1076: iload #15
      //   1078: iload #9
      //   1080: if_icmpne -> 1108
      //   1083: iload #13
      //   1085: iload #8
      //   1087: if_icmpeq -> 1093
      //   1090: goto -> 1108
      //   1093: iload #9
      //   1095: istore #6
      //   1097: iload #8
      //   1099: istore #5
      //   1101: iload #14
      //   1103: istore #4
      //   1105: goto -> 1173
      //   1108: iload #15
      //   1110: iload #9
      //   1112: if_icmpeq -> 1124
      //   1115: iload #9
      //   1117: ldc 1073741824
      //   1119: invokestatic makeMeasureSpec : (II)I
      //   1122: istore #5
      //   1124: iload #13
      //   1126: iload #8
      //   1128: if_icmpeq -> 1140
      //   1131: iload #8
      //   1133: ldc 1073741824
      //   1135: invokestatic makeMeasureSpec : (II)I
      //   1138: istore #4
      //   1140: aload #18
      //   1142: iload #5
      //   1144: iload #4
      //   1146: invokevirtual measure : (II)V
      //   1149: aload #18
      //   1151: invokevirtual getMeasuredWidth : ()I
      //   1154: istore #6
      //   1156: aload #18
      //   1158: invokevirtual getMeasuredHeight : ()I
      //   1161: istore #5
      //   1163: aload #18
      //   1165: invokevirtual getBaseline : ()I
      //   1168: istore #4
      //   1170: goto -> 1105
      //   1173: iload #4
      //   1175: iconst_m1
      //   1176: if_icmpeq -> 1185
      //   1179: iconst_1
      //   1180: istore #16
      //   1182: goto -> 1188
      //   1185: iconst_0
      //   1186: istore #16
      //   1188: iload #6
      //   1190: aload_2
      //   1191: getfield horizontalDimension : I
      //   1194: if_icmpne -> 1215
      //   1197: iload #5
      //   1199: aload_2
      //   1200: getfield verticalDimension : I
      //   1203: if_icmpeq -> 1209
      //   1206: goto -> 1215
      //   1209: iconst_0
      //   1210: istore #17
      //   1212: goto -> 1218
      //   1215: iconst_1
      //   1216: istore #17
      //   1218: aload_2
      //   1219: iload #17
      //   1221: putfield measuredNeedsSolverPass : Z
      //   1224: aload #19
      //   1226: getfield needsBaseline : Z
      //   1229: ifeq -> 1238
      //   1232: iconst_1
      //   1233: istore #16
      //   1235: goto -> 1238
      //   1238: iload #16
      //   1240: ifeq -> 1263
      //   1243: iload #4
      //   1245: iconst_m1
      //   1246: if_icmpeq -> 1263
      //   1249: aload_1
      //   1250: invokevirtual getBaselineDistance : ()I
      //   1253: iload #4
      //   1255: if_icmpeq -> 1263
      //   1258: aload_2
      //   1259: iconst_1
      //   1260: putfield measuredNeedsSolverPass : Z
      //   1263: aload_2
      //   1264: iload #6
      //   1266: putfield measuredWidth : I
      //   1269: aload_2
      //   1270: iload #5
      //   1272: putfield measuredHeight : I
      //   1275: aload_2
      //   1276: iload #16
      //   1278: putfield measuredHasBaseline : Z
      //   1281: aload_2
      //   1282: iload #4
      //   1284: putfield measuredBaseline : I
      //   1287: return
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */