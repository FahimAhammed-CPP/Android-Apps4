package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.Cache;
import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.SolverVariable;
import androidx.constraintlayout.solver.widgets.analyzer.ChainRun;
import androidx.constraintlayout.solver.widgets.analyzer.HorizontalWidgetRun;
import androidx.constraintlayout.solver.widgets.analyzer.VerticalWidgetRun;
import androidx.constraintlayout.solver.widgets.analyzer.WidgetRun;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class ConstraintWidget {
  public static final int ANCHOR_BASELINE = 4;
  
  public static final int ANCHOR_BOTTOM = 3;
  
  public static final int ANCHOR_LEFT = 0;
  
  public static final int ANCHOR_RIGHT = 1;
  
  public static final int ANCHOR_TOP = 2;
  
  private static final boolean AUTOTAG_CENTER = false;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static float DEFAULT_BIAS = 0.5F;
  
  static final int DIMENSION_HORIZONTAL = 0;
  
  static final int DIMENSION_VERTICAL = 1;
  
  protected static final int DIRECT = 2;
  
  public static final int GONE = 8;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVISIBLE = 4;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_RATIO = 3;
  
  public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  protected static final int SOLVER = 1;
  
  public static final int UNKNOWN = -1;
  
  private static final boolean USE_WRAP_DIMENSION_FOR_SPREAD = false;
  
  public static final int VERTICAL = 1;
  
  public static final int VISIBLE = 0;
  
  private static final int WRAP = -2;
  
  private boolean hasBaseline = false;
  
  public ChainRun horizontalChainRun;
  
  public HorizontalWidgetRun horizontalRun = new HorizontalWidgetRun(this);
  
  private boolean inPlaceholder;
  
  public boolean[] isTerminalWidget = new boolean[] { true, true };
  
  protected ArrayList<ConstraintAnchor> mAnchors;
  
  ConstraintAnchor mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
  
  int mBaselineDistance;
  
  public ConstraintAnchor mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
  
  boolean mBottomHasCentered;
  
  ConstraintAnchor mCenter;
  
  ConstraintAnchor mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
  
  ConstraintAnchor mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
  
  private float mCircleConstraintAngle = 0.0F;
  
  private Object mCompanionWidget;
  
  private int mContainerItemSkip;
  
  private String mDebugName;
  
  public float mDimensionRatio;
  
  protected int mDimensionRatioSide;
  
  int mDistToBottom;
  
  int mDistToLeft;
  
  int mDistToRight;
  
  int mDistToTop;
  
  boolean mGroupsToSolver;
  
  int mHeight;
  
  float mHorizontalBiasPercent;
  
  boolean mHorizontalChainFixedPosition;
  
  int mHorizontalChainStyle;
  
  ConstraintWidget mHorizontalNextWidget;
  
  public int mHorizontalResolution = -1;
  
  boolean mHorizontalWrapVisited;
  
  private boolean mInVirtuaLayout = false;
  
  public boolean mIsHeightWrapContent;
  
  private boolean[] mIsInBarrier;
  
  public boolean mIsWidthWrapContent;
  
  public ConstraintAnchor mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
  
  boolean mLeftHasCentered;
  
  public ConstraintAnchor[] mListAnchors;
  
  public DimensionBehaviour[] mListDimensionBehaviors;
  
  protected ConstraintWidget[] mListNextMatchConstraintsWidget;
  
  public int mMatchConstraintDefaultHeight = 0;
  
  public int mMatchConstraintDefaultWidth = 0;
  
  public int mMatchConstraintMaxHeight = 0;
  
  public int mMatchConstraintMaxWidth = 0;
  
  public int mMatchConstraintMinHeight = 0;
  
  public int mMatchConstraintMinWidth = 0;
  
  public float mMatchConstraintPercentHeight = 1.0F;
  
  public float mMatchConstraintPercentWidth = 1.0F;
  
  private int[] mMaxDimension = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  protected int mMinHeight;
  
  protected int mMinWidth;
  
  protected ConstraintWidget[] mNextChainWidget;
  
  protected int mOffsetX;
  
  protected int mOffsetY;
  
  boolean mOptimizerMeasurable;
  
  public ConstraintWidget mParent;
  
  int mRelX;
  
  int mRelY;
  
  float mResolvedDimensionRatio = 1.0F;
  
  int mResolvedDimensionRatioSide = -1;
  
  boolean mResolvedHasRatio = false;
  
  public int[] mResolvedMatchConstraintDefault = new int[2];
  
  public ConstraintAnchor mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
  
  boolean mRightHasCentered;
  
  public ConstraintAnchor mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
  
  boolean mTopHasCentered;
  
  private String mType;
  
  float mVerticalBiasPercent;
  
  boolean mVerticalChainFixedPosition;
  
  int mVerticalChainStyle;
  
  ConstraintWidget mVerticalNextWidget;
  
  public int mVerticalResolution = -1;
  
  boolean mVerticalWrapVisited;
  
  private int mVisibility;
  
  public float[] mWeight;
  
  int mWidth;
  
  protected int mX;
  
  protected int mY;
  
  public boolean measured = false;
  
  public WidgetRun[] run = new WidgetRun[2];
  
  public ChainRun verticalChainRun;
  
  public VerticalWidgetRun verticalRun = new VerticalWidgetRun(this);
  
  public int[] wrapMeasure = new int[] { 0, 0, 0, 0 };
  
  public ConstraintWidget() {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mOptimizerMeasurable = false;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    addAnchors();
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mOptimizerMeasurable = false;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.mX = paramInt1;
    this.mY = paramInt2;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    addAnchors();
  }
  
  private void addAnchors() {
    this.mAnchors.add(this.mLeft);
    this.mAnchors.add(this.mTop);
    this.mAnchors.add(this.mRight);
    this.mAnchors.add(this.mBottom);
    this.mAnchors.add(this.mCenterX);
    this.mAnchors.add(this.mCenterY);
    this.mAnchors.add(this.mCenter);
    this.mAnchors.add(this.mBaseline);
  }
  
  private void applyConstraints(LinearSystem paramLinearSystem, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean5, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, int paramInt5, int paramInt6, int paramInt7, int paramInt8, float paramFloat2, boolean paramBoolean10) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private boolean isChainHead(int paramInt) {
    paramInt *= 2;
    if ((this.mListAnchors[paramInt]).mTarget != null) {
      ConstraintAnchor constraintAnchor = (this.mListAnchors[paramInt]).mTarget.mTarget;
      ConstraintAnchor[] arrayOfConstraintAnchor = this.mListAnchors;
      if (constraintAnchor != arrayOfConstraintAnchor[paramInt])
        if ((arrayOfConstraintAnchor[++paramInt]).mTarget != null && (this.mListAnchors[paramInt]).mTarget.mTarget == this.mListAnchors[paramInt])
          return true;  
    } 
    return false;
  }
  
  boolean addFirst() {
    return (this instanceof VirtualLayout || this instanceof Guideline);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem) {
    // Byte code:
    //   0: aload_0
    //   1: astore #22
    //   3: aload_1
    //   4: aload #22
    //   6: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   9: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   12: astore #24
    //   14: aload_1
    //   15: aload #22
    //   17: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   20: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   23: astore #26
    //   25: aload_1
    //   26: aload #22
    //   28: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   31: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   34: astore #27
    //   36: aload_1
    //   37: aload #22
    //   39: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   42: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   45: astore #25
    //   47: aload_1
    //   48: aload #22
    //   50: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   53: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   56: astore #20
    //   58: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   61: ifnull -> 81
    //   64: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   67: astore #19
    //   69: aload #19
    //   71: aload #19
    //   73: getfield widgets : J
    //   76: lconst_1
    //   77: ladd
    //   78: putfield widgets : J
    //   81: aload #22
    //   83: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   86: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   89: getfield resolved : Z
    //   92: ifeq -> 402
    //   95: aload #22
    //   97: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   100: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   103: getfield resolved : Z
    //   106: ifeq -> 402
    //   109: aload #22
    //   111: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   114: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   117: getfield resolved : Z
    //   120: ifeq -> 402
    //   123: aload #22
    //   125: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   128: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   131: getfield resolved : Z
    //   134: ifeq -> 402
    //   137: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   140: ifnull -> 160
    //   143: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   146: astore #19
    //   148: aload #19
    //   150: aload #19
    //   152: getfield graphSolved : J
    //   155: lconst_1
    //   156: ladd
    //   157: putfield graphSolved : J
    //   160: aload_1
    //   161: aload #24
    //   163: aload #22
    //   165: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   168: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   171: getfield value : I
    //   174: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   177: aload_1
    //   178: aload #26
    //   180: aload #22
    //   182: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   185: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   188: getfield value : I
    //   191: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   194: aload_1
    //   195: aload #27
    //   197: aload #22
    //   199: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   202: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   205: getfield value : I
    //   208: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   211: aload_1
    //   212: aload #25
    //   214: aload #22
    //   216: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   219: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   222: getfield value : I
    //   225: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   228: aload_1
    //   229: aload #20
    //   231: aload #22
    //   233: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   236: getfield baseline : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   239: getfield value : I
    //   242: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   245: aload #22
    //   247: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   250: astore #19
    //   252: aload #19
    //   254: ifnull -> 401
    //   257: aload #19
    //   259: ifnull -> 280
    //   262: aload #19
    //   264: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   267: iconst_0
    //   268: aaload
    //   269: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   272: if_acmpne -> 280
    //   275: iconst_1
    //   276: istore_3
    //   277: goto -> 282
    //   280: iconst_0
    //   281: istore_3
    //   282: aload #22
    //   284: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   287: astore #19
    //   289: aload #19
    //   291: ifnull -> 313
    //   294: aload #19
    //   296: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   299: iconst_1
    //   300: aaload
    //   301: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   304: if_acmpne -> 313
    //   307: iconst_1
    //   308: istore #4
    //   310: goto -> 316
    //   313: iconst_0
    //   314: istore #4
    //   316: iload_3
    //   317: ifeq -> 358
    //   320: aload #22
    //   322: getfield isTerminalWidget : [Z
    //   325: iconst_0
    //   326: baload
    //   327: ifeq -> 358
    //   330: aload_0
    //   331: invokevirtual isInHorizontalChain : ()Z
    //   334: ifne -> 358
    //   337: aload_1
    //   338: aload_1
    //   339: aload #22
    //   341: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   344: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   347: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   350: aload #26
    //   352: iconst_0
    //   353: bipush #8
    //   355: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   358: iload #4
    //   360: ifeq -> 401
    //   363: aload #22
    //   365: getfield isTerminalWidget : [Z
    //   368: iconst_1
    //   369: baload
    //   370: ifeq -> 401
    //   373: aload_0
    //   374: invokevirtual isInVerticalChain : ()Z
    //   377: ifne -> 401
    //   380: aload_1
    //   381: aload_1
    //   382: aload #22
    //   384: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   387: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   390: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   393: aload #25
    //   395: iconst_0
    //   396: bipush #8
    //   398: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   401: return
    //   402: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   405: ifnull -> 425
    //   408: getstatic androidx/constraintlayout/solver/LinearSystem.sMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   411: astore #19
    //   413: aload #19
    //   415: aload #19
    //   417: getfield linearSolved : J
    //   420: lconst_1
    //   421: ladd
    //   422: putfield linearSolved : J
    //   425: aload #22
    //   427: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   430: astore #19
    //   432: aload #19
    //   434: ifnull -> 711
    //   437: aload #19
    //   439: ifnull -> 461
    //   442: aload #19
    //   444: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   447: iconst_0
    //   448: aaload
    //   449: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   452: if_acmpne -> 461
    //   455: iconst_1
    //   456: istore #9
    //   458: goto -> 464
    //   461: iconst_0
    //   462: istore #9
    //   464: aload #22
    //   466: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   469: astore #19
    //   471: aload #19
    //   473: ifnull -> 495
    //   476: aload #19
    //   478: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   481: iconst_1
    //   482: aaload
    //   483: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   486: if_acmpne -> 495
    //   489: iconst_1
    //   490: istore #10
    //   492: goto -> 498
    //   495: iconst_0
    //   496: istore #10
    //   498: aload #22
    //   500: iconst_0
    //   501: invokespecial isChainHead : (I)Z
    //   504: ifeq -> 527
    //   507: aload #22
    //   509: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   512: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   515: aload #22
    //   517: iconst_0
    //   518: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   521: iconst_1
    //   522: istore #11
    //   524: goto -> 533
    //   527: aload_0
    //   528: invokevirtual isInHorizontalChain : ()Z
    //   531: istore #11
    //   533: aload #22
    //   535: iconst_1
    //   536: invokespecial isChainHead : (I)Z
    //   539: ifeq -> 562
    //   542: aload #22
    //   544: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   547: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   550: aload #22
    //   552: iconst_1
    //   553: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   556: iconst_1
    //   557: istore #12
    //   559: goto -> 568
    //   562: aload_0
    //   563: invokevirtual isInVerticalChain : ()Z
    //   566: istore #12
    //   568: iload #11
    //   570: ifne -> 630
    //   573: iload #9
    //   575: ifeq -> 630
    //   578: aload #22
    //   580: getfield mVisibility : I
    //   583: bipush #8
    //   585: if_icmpeq -> 630
    //   588: aload #22
    //   590: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   593: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   596: ifnonnull -> 630
    //   599: aload #22
    //   601: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   604: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   607: ifnonnull -> 630
    //   610: aload_1
    //   611: aload_1
    //   612: aload #22
    //   614: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   617: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   620: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   623: aload #26
    //   625: iconst_0
    //   626: iconst_1
    //   627: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   630: iload #12
    //   632: ifne -> 700
    //   635: iload #10
    //   637: ifeq -> 700
    //   640: aload #22
    //   642: getfield mVisibility : I
    //   645: bipush #8
    //   647: if_icmpeq -> 700
    //   650: aload #22
    //   652: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   655: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   658: ifnonnull -> 700
    //   661: aload #22
    //   663: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   666: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   669: ifnonnull -> 700
    //   672: aload #22
    //   674: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   677: ifnonnull -> 700
    //   680: aload_1
    //   681: aload_1
    //   682: aload #22
    //   684: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   687: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   690: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   693: aload #25
    //   695: iconst_0
    //   696: iconst_1
    //   697: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   700: iload #11
    //   702: istore #13
    //   704: iload #9
    //   706: istore #11
    //   708: goto -> 723
    //   711: iconst_0
    //   712: istore #10
    //   714: iconst_0
    //   715: istore #11
    //   717: iconst_0
    //   718: istore #12
    //   720: iconst_0
    //   721: istore #13
    //   723: aload #22
    //   725: getfield mWidth : I
    //   728: istore #4
    //   730: aload #22
    //   732: getfield mMinWidth : I
    //   735: istore #5
    //   737: iload #4
    //   739: istore_3
    //   740: iload #4
    //   742: iload #5
    //   744: if_icmpge -> 750
    //   747: iload #5
    //   749: istore_3
    //   750: aload #22
    //   752: getfield mHeight : I
    //   755: istore #5
    //   757: aload #22
    //   759: getfield mMinHeight : I
    //   762: istore #6
    //   764: iload #5
    //   766: istore #4
    //   768: iload #5
    //   770: iload #6
    //   772: if_icmpge -> 779
    //   775: iload #6
    //   777: istore #4
    //   779: aload #22
    //   781: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   784: iconst_0
    //   785: aaload
    //   786: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   789: if_acmpeq -> 798
    //   792: iconst_1
    //   793: istore #9
    //   795: goto -> 801
    //   798: iconst_0
    //   799: istore #9
    //   801: aload #22
    //   803: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   806: iconst_1
    //   807: aaload
    //   808: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   811: if_acmpeq -> 820
    //   814: iconst_1
    //   815: istore #14
    //   817: goto -> 823
    //   820: iconst_0
    //   821: istore #14
    //   823: aload #22
    //   825: aload #22
    //   827: getfield mDimensionRatioSide : I
    //   830: putfield mResolvedDimensionRatioSide : I
    //   833: aload #22
    //   835: getfield mDimensionRatio : F
    //   838: fstore_2
    //   839: aload #22
    //   841: fload_2
    //   842: putfield mResolvedDimensionRatio : F
    //   845: aload #22
    //   847: getfield mMatchConstraintDefaultWidth : I
    //   850: istore #6
    //   852: aload #22
    //   854: getfield mMatchConstraintDefaultHeight : I
    //   857: istore #7
    //   859: fload_2
    //   860: fconst_0
    //   861: fcmpl
    //   862: ifle -> 1216
    //   865: aload #22
    //   867: getfield mVisibility : I
    //   870: bipush #8
    //   872: if_icmpeq -> 1216
    //   875: iload #6
    //   877: istore #5
    //   879: aload #22
    //   881: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   884: iconst_0
    //   885: aaload
    //   886: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   889: if_acmpne -> 904
    //   892: iload #6
    //   894: istore #5
    //   896: iload #6
    //   898: ifne -> 904
    //   901: iconst_3
    //   902: istore #5
    //   904: iload #7
    //   906: istore #6
    //   908: aload #22
    //   910: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   913: iconst_1
    //   914: aaload
    //   915: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   918: if_acmpne -> 933
    //   921: iload #7
    //   923: istore #6
    //   925: iload #7
    //   927: ifne -> 933
    //   930: iconst_3
    //   931: istore #6
    //   933: aload #22
    //   935: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   938: iconst_0
    //   939: aaload
    //   940: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   943: if_acmpne -> 991
    //   946: aload #22
    //   948: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   951: iconst_1
    //   952: aaload
    //   953: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   956: if_acmpne -> 991
    //   959: iload #5
    //   961: iconst_3
    //   962: if_icmpne -> 991
    //   965: iload #6
    //   967: iconst_3
    //   968: if_icmpne -> 991
    //   971: aload #22
    //   973: iload #11
    //   975: iload #10
    //   977: iload #9
    //   979: iload #14
    //   981: invokevirtual setupDimensionRatio : (ZZZZ)V
    //   984: iload #4
    //   986: istore #7
    //   988: goto -> 1192
    //   991: aload #22
    //   993: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   996: iconst_0
    //   997: aaload
    //   998: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1001: if_acmpne -> 1083
    //   1004: iload #5
    //   1006: iconst_3
    //   1007: if_icmpne -> 1083
    //   1010: aload #22
    //   1012: iconst_0
    //   1013: putfield mResolvedDimensionRatioSide : I
    //   1016: aload #22
    //   1018: getfield mResolvedDimensionRatio : F
    //   1021: aload #22
    //   1023: getfield mHeight : I
    //   1026: i2f
    //   1027: fmul
    //   1028: f2i
    //   1029: istore #8
    //   1031: aload #22
    //   1033: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1036: iconst_1
    //   1037: aaload
    //   1038: astore #19
    //   1040: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1043: astore #21
    //   1045: iload #4
    //   1047: istore_3
    //   1048: iload #6
    //   1050: istore #7
    //   1052: aload #19
    //   1054: aload #21
    //   1056: if_acmpeq -> 1076
    //   1059: iconst_0
    //   1060: istore #9
    //   1062: iconst_4
    //   1063: istore #6
    //   1065: iload #8
    //   1067: istore #4
    //   1069: iload #7
    //   1071: istore #5
    //   1073: goto -> 1233
    //   1076: iload #8
    //   1078: istore #4
    //   1080: goto -> 1198
    //   1083: iload #4
    //   1085: istore #7
    //   1087: aload #22
    //   1089: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1092: iconst_1
    //   1093: aaload
    //   1094: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1097: if_acmpne -> 1192
    //   1100: iload #4
    //   1102: istore #7
    //   1104: iload #6
    //   1106: iconst_3
    //   1107: if_icmpne -> 1192
    //   1110: aload #22
    //   1112: iconst_1
    //   1113: putfield mResolvedDimensionRatioSide : I
    //   1116: aload #22
    //   1118: getfield mDimensionRatioSide : I
    //   1121: iconst_m1
    //   1122: if_icmpne -> 1137
    //   1125: aload #22
    //   1127: fconst_1
    //   1128: aload #22
    //   1130: getfield mResolvedDimensionRatio : F
    //   1133: fdiv
    //   1134: putfield mResolvedDimensionRatio : F
    //   1137: aload #22
    //   1139: getfield mResolvedDimensionRatio : F
    //   1142: aload #22
    //   1144: getfield mWidth : I
    //   1147: i2f
    //   1148: fmul
    //   1149: f2i
    //   1150: istore #4
    //   1152: iload #4
    //   1154: istore #7
    //   1156: aload #22
    //   1158: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1161: iconst_0
    //   1162: aaload
    //   1163: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1166: if_acmpeq -> 1192
    //   1169: iload #4
    //   1171: istore #7
    //   1173: iload #5
    //   1175: istore #6
    //   1177: iconst_0
    //   1178: istore #9
    //   1180: iconst_4
    //   1181: istore #5
    //   1183: iload_3
    //   1184: istore #4
    //   1186: iload #7
    //   1188: istore_3
    //   1189: goto -> 1233
    //   1192: iload_3
    //   1193: istore #4
    //   1195: iload #7
    //   1197: istore_3
    //   1198: iload #5
    //   1200: istore #7
    //   1202: iload #6
    //   1204: istore #5
    //   1206: iconst_1
    //   1207: istore #9
    //   1209: iload #7
    //   1211: istore #6
    //   1213: goto -> 1233
    //   1216: iload #7
    //   1218: istore #5
    //   1220: iload_3
    //   1221: istore #7
    //   1223: iconst_0
    //   1224: istore #9
    //   1226: iload #4
    //   1228: istore_3
    //   1229: iload #7
    //   1231: istore #4
    //   1233: aload #22
    //   1235: getfield mResolvedMatchConstraintDefault : [I
    //   1238: astore #19
    //   1240: aload #19
    //   1242: iconst_0
    //   1243: iload #6
    //   1245: iastore
    //   1246: aload #19
    //   1248: iconst_1
    //   1249: iload #5
    //   1251: iastore
    //   1252: aload #22
    //   1254: iload #9
    //   1256: putfield mResolvedHasRatio : Z
    //   1259: iload #9
    //   1261: ifeq -> 1288
    //   1264: aload #22
    //   1266: getfield mResolvedDimensionRatioSide : I
    //   1269: istore #7
    //   1271: iload #7
    //   1273: ifeq -> 1282
    //   1276: iload #7
    //   1278: iconst_m1
    //   1279: if_icmpne -> 1288
    //   1282: iconst_1
    //   1283: istore #14
    //   1285: goto -> 1291
    //   1288: iconst_0
    //   1289: istore #14
    //   1291: aload #22
    //   1293: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1296: iconst_0
    //   1297: aaload
    //   1298: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1301: if_acmpne -> 1318
    //   1304: aload #22
    //   1306: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   1309: ifeq -> 1318
    //   1312: iconst_1
    //   1313: istore #15
    //   1315: goto -> 1321
    //   1318: iconst_0
    //   1319: istore #15
    //   1321: iload #15
    //   1323: ifeq -> 1332
    //   1326: iconst_0
    //   1327: istore #4
    //   1329: goto -> 1332
    //   1332: aload #22
    //   1334: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1337: invokevirtual isConnected : ()Z
    //   1340: iconst_1
    //   1341: ixor
    //   1342: istore #16
    //   1344: aload #22
    //   1346: getfield mIsInBarrier : [Z
    //   1349: astore #19
    //   1351: aload #19
    //   1353: iconst_0
    //   1354: baload
    //   1355: istore #17
    //   1357: aload #19
    //   1359: iconst_1
    //   1360: baload
    //   1361: istore #18
    //   1363: aload #22
    //   1365: getfield mHorizontalResolution : I
    //   1368: istore #7
    //   1370: aconst_null
    //   1371: astore #23
    //   1373: iload #7
    //   1375: iconst_2
    //   1376: if_icmpeq -> 1652
    //   1379: aload #22
    //   1381: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1384: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1387: getfield resolved : Z
    //   1390: ifeq -> 1498
    //   1393: aload #22
    //   1395: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1398: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1401: getfield resolved : Z
    //   1404: ifne -> 1410
    //   1407: goto -> 1498
    //   1410: aload_1
    //   1411: aload #24
    //   1413: aload #22
    //   1415: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1418: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1421: getfield value : I
    //   1424: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1427: aload_1
    //   1428: aload #26
    //   1430: aload #22
    //   1432: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   1435: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1438: getfield value : I
    //   1441: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1444: aload #22
    //   1446: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1449: ifnull -> 1495
    //   1452: iload #11
    //   1454: ifeq -> 1495
    //   1457: aload #22
    //   1459: getfield isTerminalWidget : [Z
    //   1462: iconst_0
    //   1463: baload
    //   1464: ifeq -> 1495
    //   1467: aload_0
    //   1468: invokevirtual isInHorizontalChain : ()Z
    //   1471: ifne -> 1495
    //   1474: aload_1
    //   1475: aload_1
    //   1476: aload #22
    //   1478: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1481: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1484: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1487: aload #26
    //   1489: iconst_0
    //   1490: bipush #8
    //   1492: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1495: goto -> 1652
    //   1498: aload #22
    //   1500: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1503: astore #19
    //   1505: aload #19
    //   1507: ifnull -> 1524
    //   1510: aload_1
    //   1511: aload #19
    //   1513: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1516: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1519: astore #19
    //   1521: goto -> 1527
    //   1524: aconst_null
    //   1525: astore #19
    //   1527: aload #22
    //   1529: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1532: astore #21
    //   1534: aload #21
    //   1536: ifnull -> 1553
    //   1539: aload_1
    //   1540: aload #21
    //   1542: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1545: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1548: astore #21
    //   1550: goto -> 1556
    //   1553: aconst_null
    //   1554: astore #21
    //   1556: aload_0
    //   1557: aload_1
    //   1558: iconst_1
    //   1559: iload #11
    //   1561: iload #10
    //   1563: aload #22
    //   1565: getfield isTerminalWidget : [Z
    //   1568: iconst_0
    //   1569: baload
    //   1570: aload #21
    //   1572: aload #19
    //   1574: aload #22
    //   1576: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1579: iconst_0
    //   1580: aaload
    //   1581: iload #15
    //   1583: aload #22
    //   1585: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1588: aload #22
    //   1590: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1593: aload #22
    //   1595: getfield mX : I
    //   1598: iload #4
    //   1600: aload #22
    //   1602: getfield mMinWidth : I
    //   1605: aload #22
    //   1607: getfield mMaxDimension : [I
    //   1610: iconst_0
    //   1611: iaload
    //   1612: aload #22
    //   1614: getfield mHorizontalBiasPercent : F
    //   1617: iload #14
    //   1619: iload #13
    //   1621: iload #12
    //   1623: iload #17
    //   1625: iload #6
    //   1627: iload #5
    //   1629: aload #22
    //   1631: getfield mMatchConstraintMinWidth : I
    //   1634: aload #22
    //   1636: getfield mMatchConstraintMaxWidth : I
    //   1639: aload #22
    //   1641: getfield mMatchConstraintPercentWidth : F
    //   1644: iload #16
    //   1646: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZZZZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZZZIIIIFZ)V
    //   1649: goto -> 1652
    //   1652: aload #27
    //   1654: astore #22
    //   1656: aload #25
    //   1658: astore #19
    //   1660: iload #9
    //   1662: istore #15
    //   1664: aload #20
    //   1666: astore #21
    //   1668: iload #10
    //   1670: istore #17
    //   1672: aload_0
    //   1673: astore #25
    //   1675: aload #25
    //   1677: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1680: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1683: getfield resolved : Z
    //   1686: ifeq -> 1836
    //   1689: aload #25
    //   1691: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1694: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1697: getfield resolved : Z
    //   1700: ifeq -> 1836
    //   1703: aload #25
    //   1705: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1708: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1711: getfield value : I
    //   1714: istore #4
    //   1716: aload_1
    //   1717: astore #20
    //   1719: aload #20
    //   1721: aload #22
    //   1723: iload #4
    //   1725: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1728: aload #25
    //   1730: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1733: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1736: getfield value : I
    //   1739: istore #4
    //   1741: aload #19
    //   1743: astore #27
    //   1745: aload #20
    //   1747: aload #27
    //   1749: iload #4
    //   1751: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1754: aload #20
    //   1756: aload #21
    //   1758: aload #25
    //   1760: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   1763: getfield baseline : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1766: getfield value : I
    //   1769: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   1772: aload #25
    //   1774: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1777: astore #28
    //   1779: aload #28
    //   1781: ifnull -> 1830
    //   1784: iload #12
    //   1786: ifne -> 1830
    //   1789: iload #17
    //   1791: ifeq -> 1830
    //   1794: aload #25
    //   1796: getfield isTerminalWidget : [Z
    //   1799: iconst_1
    //   1800: baload
    //   1801: ifeq -> 1827
    //   1804: aload #20
    //   1806: aload #20
    //   1808: aload #28
    //   1810: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1813: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1816: aload #27
    //   1818: iconst_0
    //   1819: bipush #8
    //   1821: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1824: goto -> 1830
    //   1827: goto -> 1830
    //   1830: iconst_0
    //   1831: istore #4
    //   1833: goto -> 1839
    //   1836: iconst_1
    //   1837: istore #4
    //   1839: aload_1
    //   1840: astore #27
    //   1842: aload #22
    //   1844: astore #20
    //   1846: aload #21
    //   1848: astore #28
    //   1850: aload #25
    //   1852: getfield mVerticalResolution : I
    //   1855: iconst_2
    //   1856: if_icmpne -> 1865
    //   1859: iconst_0
    //   1860: istore #4
    //   1862: goto -> 1865
    //   1865: iload #4
    //   1867: ifeq -> 2219
    //   1870: aload #25
    //   1872: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1875: iconst_1
    //   1876: aaload
    //   1877: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1880: if_acmpne -> 1897
    //   1883: aload #25
    //   1885: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   1888: ifeq -> 1897
    //   1891: iconst_1
    //   1892: istore #9
    //   1894: goto -> 1900
    //   1897: iconst_0
    //   1898: istore #9
    //   1900: iload #9
    //   1902: ifeq -> 1907
    //   1905: iconst_0
    //   1906: istore_3
    //   1907: iload #15
    //   1909: ifeq -> 1937
    //   1912: aload #25
    //   1914: getfield mResolvedDimensionRatioSide : I
    //   1917: istore #4
    //   1919: iload #4
    //   1921: iconst_1
    //   1922: if_icmpeq -> 1931
    //   1925: iload #4
    //   1927: iconst_m1
    //   1928: if_icmpne -> 1937
    //   1931: iconst_1
    //   1932: istore #10
    //   1934: goto -> 1940
    //   1937: iconst_0
    //   1938: istore #10
    //   1940: aload #25
    //   1942: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1945: astore #21
    //   1947: aload #21
    //   1949: ifnull -> 1967
    //   1952: aload #27
    //   1954: aload #21
    //   1956: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1959: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1962: astore #21
    //   1964: goto -> 1970
    //   1967: aconst_null
    //   1968: astore #21
    //   1970: aload #25
    //   1972: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1975: astore #29
    //   1977: aload #23
    //   1979: astore #22
    //   1981: aload #29
    //   1983: ifnull -> 1998
    //   1986: aload #27
    //   1988: aload #29
    //   1990: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1993: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1996: astore #22
    //   1998: aload #25
    //   2000: getfield mBaselineDistance : I
    //   2003: ifgt -> 2016
    //   2006: aload #25
    //   2008: getfield mVisibility : I
    //   2011: bipush #8
    //   2013: if_icmpne -> 2120
    //   2016: aload #27
    //   2018: aload #28
    //   2020: aload #20
    //   2022: aload_0
    //   2023: invokevirtual getBaselineDistance : ()I
    //   2026: bipush #8
    //   2028: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2031: pop
    //   2032: aload #25
    //   2034: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2037: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2040: ifnull -> 2097
    //   2043: aload #27
    //   2045: aload #28
    //   2047: aload #27
    //   2049: aload #25
    //   2051: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2054: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2057: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2060: iconst_0
    //   2061: bipush #8
    //   2063: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2066: pop
    //   2067: iload #17
    //   2069: ifeq -> 2091
    //   2072: aload #27
    //   2074: aload #21
    //   2076: aload #27
    //   2078: aload #25
    //   2080: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2083: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   2086: iconst_0
    //   2087: iconst_5
    //   2088: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2091: iconst_0
    //   2092: istore #14
    //   2094: goto -> 2124
    //   2097: aload #25
    //   2099: getfield mVisibility : I
    //   2102: bipush #8
    //   2104: if_icmpne -> 2120
    //   2107: aload #27
    //   2109: aload #28
    //   2111: aload #20
    //   2113: iconst_0
    //   2114: bipush #8
    //   2116: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2119: pop
    //   2120: iload #16
    //   2122: istore #14
    //   2124: aload_0
    //   2125: aload_1
    //   2126: iconst_0
    //   2127: iload #17
    //   2129: iload #11
    //   2131: aload #25
    //   2133: getfield isTerminalWidget : [Z
    //   2136: iconst_1
    //   2137: baload
    //   2138: aload #22
    //   2140: aload #21
    //   2142: aload #25
    //   2144: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2147: iconst_1
    //   2148: aaload
    //   2149: iload #9
    //   2151: aload #25
    //   2153: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2156: aload #25
    //   2158: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2161: aload #25
    //   2163: getfield mY : I
    //   2166: iload_3
    //   2167: aload #25
    //   2169: getfield mMinHeight : I
    //   2172: aload #25
    //   2174: getfield mMaxDimension : [I
    //   2177: iconst_1
    //   2178: iaload
    //   2179: aload #25
    //   2181: getfield mVerticalBiasPercent : F
    //   2184: iload #10
    //   2186: iload #12
    //   2188: iload #13
    //   2190: iload #18
    //   2192: iload #5
    //   2194: iload #6
    //   2196: aload #25
    //   2198: getfield mMatchConstraintMinHeight : I
    //   2201: aload #25
    //   2203: getfield mMatchConstraintMaxHeight : I
    //   2206: aload #25
    //   2208: getfield mMatchConstraintPercentHeight : F
    //   2211: iload #14
    //   2213: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZZZZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZZZIIIIFZ)V
    //   2216: goto -> 2219
    //   2219: iload #15
    //   2221: ifeq -> 2280
    //   2224: aload_0
    //   2225: astore #21
    //   2227: aload #21
    //   2229: getfield mResolvedDimensionRatioSide : I
    //   2232: iconst_1
    //   2233: if_icmpne -> 2258
    //   2236: aload_1
    //   2237: aload #19
    //   2239: aload #20
    //   2241: aload #26
    //   2243: aload #24
    //   2245: aload #21
    //   2247: getfield mResolvedDimensionRatio : F
    //   2250: bipush #8
    //   2252: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   2255: goto -> 2280
    //   2258: aload_1
    //   2259: aload #26
    //   2261: aload #24
    //   2263: aload #19
    //   2265: aload #20
    //   2267: aload #21
    //   2269: getfield mResolvedDimensionRatio : F
    //   2272: bipush #8
    //   2274: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   2277: goto -> 2280
    //   2280: aload_0
    //   2281: astore #19
    //   2283: aload #19
    //   2285: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2288: invokevirtual isConnected : ()Z
    //   2291: ifeq -> 2333
    //   2294: aload_1
    //   2295: aload #19
    //   2297: aload #19
    //   2299: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2302: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2305: invokevirtual getOwner : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2308: aload #19
    //   2310: getfield mCircleConstraintAngle : F
    //   2313: ldc_w 90.0
    //   2316: fadd
    //   2317: f2d
    //   2318: invokestatic toRadians : (D)D
    //   2321: d2f
    //   2322: aload #19
    //   2324: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2327: invokevirtual getMargin : ()I
    //   2330: invokevirtual addCenterPoint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;FI)V
    //   2333: return
  }
  
  public boolean allowedInBarrier() {
    return (this.mVisibility != 8);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2) {
    connect(paramType1, paramConstraintWidget, paramType2, 0);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   4: if_acmpne -> 351
    //   7: aload_3
    //   8: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   11: if_acmpne -> 242
    //   14: aload_0
    //   15: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   18: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   21: astore_1
    //   22: aload_0
    //   23: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   26: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   29: astore_3
    //   30: aload_0
    //   31: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   34: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   37: astore #6
    //   39: aload_0
    //   40: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   43: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   46: astore #7
    //   48: iconst_1
    //   49: istore #5
    //   51: aload_1
    //   52: ifnull -> 62
    //   55: aload_1
    //   56: invokevirtual isConnected : ()Z
    //   59: ifne -> 73
    //   62: aload_3
    //   63: ifnull -> 79
    //   66: aload_3
    //   67: invokevirtual isConnected : ()Z
    //   70: ifeq -> 79
    //   73: iconst_0
    //   74: istore #4
    //   76: goto -> 106
    //   79: aload_0
    //   80: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   83: aload_2
    //   84: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   87: iconst_0
    //   88: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   91: aload_0
    //   92: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   95: aload_2
    //   96: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   99: iconst_0
    //   100: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   103: iconst_1
    //   104: istore #4
    //   106: aload #6
    //   108: ifnull -> 119
    //   111: aload #6
    //   113: invokevirtual isConnected : ()Z
    //   116: ifne -> 132
    //   119: aload #7
    //   121: ifnull -> 138
    //   124: aload #7
    //   126: invokevirtual isConnected : ()Z
    //   129: ifeq -> 138
    //   132: iconst_0
    //   133: istore #5
    //   135: goto -> 162
    //   138: aload_0
    //   139: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   142: aload_2
    //   143: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   146: iconst_0
    //   147: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   150: aload_0
    //   151: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   154: aload_2
    //   155: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   158: iconst_0
    //   159: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   162: iload #4
    //   164: ifeq -> 192
    //   167: iload #5
    //   169: ifeq -> 192
    //   172: aload_0
    //   173: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   176: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   179: aload_2
    //   180: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   183: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   186: iconst_0
    //   187: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   190: pop
    //   191: return
    //   192: iload #4
    //   194: ifeq -> 217
    //   197: aload_0
    //   198: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   201: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   204: aload_2
    //   205: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   208: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   211: iconst_0
    //   212: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   215: pop
    //   216: return
    //   217: iload #5
    //   219: ifeq -> 879
    //   222: aload_0
    //   223: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   226: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   229: aload_2
    //   230: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   233: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   236: iconst_0
    //   237: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   240: pop
    //   241: return
    //   242: aload_3
    //   243: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   246: if_acmpeq -> 311
    //   249: aload_3
    //   250: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   253: if_acmpne -> 259
    //   256: goto -> 311
    //   259: aload_3
    //   260: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   263: if_acmpeq -> 273
    //   266: aload_3
    //   267: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   270: if_acmpne -> 879
    //   273: aload_0
    //   274: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   277: aload_2
    //   278: aload_3
    //   279: iconst_0
    //   280: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   283: aload_0
    //   284: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   287: aload_2
    //   288: aload_3
    //   289: iconst_0
    //   290: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   293: aload_0
    //   294: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   297: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   300: aload_2
    //   301: aload_3
    //   302: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   305: iconst_0
    //   306: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   309: pop
    //   310: return
    //   311: aload_0
    //   312: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   315: aload_2
    //   316: aload_3
    //   317: iconst_0
    //   318: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   321: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   324: astore_1
    //   325: aload_0
    //   326: aload_1
    //   327: aload_2
    //   328: aload_3
    //   329: iconst_0
    //   330: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;I)V
    //   333: aload_0
    //   334: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   337: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   340: aload_2
    //   341: aload_3
    //   342: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   345: iconst_0
    //   346: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   349: pop
    //   350: return
    //   351: aload_1
    //   352: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   355: if_acmpne -> 422
    //   358: aload_3
    //   359: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   362: if_acmpeq -> 372
    //   365: aload_3
    //   366: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   369: if_acmpne -> 422
    //   372: aload_0
    //   373: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   376: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   379: astore_1
    //   380: aload_2
    //   381: aload_3
    //   382: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   385: astore_2
    //   386: aload_0
    //   387: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   390: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   393: astore_3
    //   394: aload_1
    //   395: aload_2
    //   396: iconst_0
    //   397: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   400: pop
    //   401: aload_3
    //   402: aload_2
    //   403: iconst_0
    //   404: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   407: pop
    //   408: aload_0
    //   409: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   412: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   415: aload_2
    //   416: iconst_0
    //   417: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   420: pop
    //   421: return
    //   422: aload_1
    //   423: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   426: if_acmpne -> 489
    //   429: aload_3
    //   430: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   433: if_acmpeq -> 443
    //   436: aload_3
    //   437: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   440: if_acmpne -> 489
    //   443: aload_2
    //   444: aload_3
    //   445: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   448: astore_1
    //   449: aload_0
    //   450: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   453: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   456: aload_1
    //   457: iconst_0
    //   458: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   461: pop
    //   462: aload_0
    //   463: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   466: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   469: aload_1
    //   470: iconst_0
    //   471: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   474: pop
    //   475: aload_0
    //   476: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   479: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   482: aload_1
    //   483: iconst_0
    //   484: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   487: pop
    //   488: return
    //   489: aload_1
    //   490: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   493: if_acmpne -> 559
    //   496: aload_3
    //   497: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   500: if_acmpne -> 559
    //   503: aload_0
    //   504: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   507: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   510: aload_2
    //   511: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   514: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   517: iconst_0
    //   518: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   521: pop
    //   522: aload_0
    //   523: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   526: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   529: aload_2
    //   530: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   533: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   536: iconst_0
    //   537: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   540: pop
    //   541: aload_0
    //   542: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   545: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   548: aload_2
    //   549: aload_3
    //   550: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   553: iconst_0
    //   554: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   557: pop
    //   558: return
    //   559: aload_1
    //   560: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   563: if_acmpne -> 629
    //   566: aload_3
    //   567: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   570: if_acmpne -> 629
    //   573: aload_0
    //   574: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   577: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   580: aload_2
    //   581: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   584: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   587: iconst_0
    //   588: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   591: pop
    //   592: aload_0
    //   593: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   596: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   599: aload_2
    //   600: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   603: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   606: iconst_0
    //   607: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   610: pop
    //   611: aload_0
    //   612: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   615: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   618: aload_2
    //   619: aload_3
    //   620: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   623: iconst_0
    //   624: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   627: pop
    //   628: return
    //   629: aload_0
    //   630: aload_1
    //   631: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   634: astore #6
    //   636: aload_2
    //   637: aload_3
    //   638: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   641: astore_2
    //   642: aload #6
    //   644: aload_2
    //   645: invokevirtual isValidConnection : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)Z
    //   648: ifeq -> 879
    //   651: aload_1
    //   652: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   655: if_acmpne -> 696
    //   658: aload_0
    //   659: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   662: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   665: astore_1
    //   666: aload_0
    //   667: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   670: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   673: astore_3
    //   674: aload_1
    //   675: ifnull -> 682
    //   678: aload_1
    //   679: invokevirtual reset : ()V
    //   682: aload_3
    //   683: ifnull -> 690
    //   686: aload_3
    //   687: invokevirtual reset : ()V
    //   690: iconst_0
    //   691: istore #5
    //   693: goto -> 870
    //   696: aload_1
    //   697: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   700: if_acmpeq -> 794
    //   703: aload_1
    //   704: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   707: if_acmpne -> 713
    //   710: goto -> 794
    //   713: aload_1
    //   714: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   717: if_acmpeq -> 731
    //   720: iload #4
    //   722: istore #5
    //   724: aload_1
    //   725: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   728: if_acmpne -> 870
    //   731: aload_0
    //   732: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   735: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   738: astore_3
    //   739: aload_3
    //   740: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   743: aload_2
    //   744: if_acmpeq -> 751
    //   747: aload_3
    //   748: invokevirtual reset : ()V
    //   751: aload_0
    //   752: aload_1
    //   753: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   756: invokevirtual getOpposite : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   759: astore_1
    //   760: aload_0
    //   761: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   764: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   767: astore_3
    //   768: iload #4
    //   770: istore #5
    //   772: aload_3
    //   773: invokevirtual isConnected : ()Z
    //   776: ifeq -> 870
    //   779: aload_1
    //   780: invokevirtual reset : ()V
    //   783: aload_3
    //   784: invokevirtual reset : ()V
    //   787: iload #4
    //   789: istore #5
    //   791: goto -> 870
    //   794: aload_0
    //   795: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   798: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   801: astore_3
    //   802: aload_3
    //   803: ifnull -> 810
    //   806: aload_3
    //   807: invokevirtual reset : ()V
    //   810: aload_0
    //   811: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   814: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   817: astore_3
    //   818: aload_3
    //   819: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   822: aload_2
    //   823: if_acmpeq -> 830
    //   826: aload_3
    //   827: invokevirtual reset : ()V
    //   830: aload_0
    //   831: aload_1
    //   832: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   835: invokevirtual getOpposite : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   838: astore_1
    //   839: aload_0
    //   840: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   843: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   846: astore_3
    //   847: iload #4
    //   849: istore #5
    //   851: aload_3
    //   852: invokevirtual isConnected : ()Z
    //   855: ifeq -> 870
    //   858: aload_1
    //   859: invokevirtual reset : ()V
    //   862: aload_3
    //   863: invokevirtual reset : ()V
    //   866: iload #4
    //   868: istore #5
    //   870: aload #6
    //   872: aload_2
    //   873: iload #5
    //   875: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
    //   878: pop
    //   879: return
    //   880: astore_1
    //   881: aload_1
    //   882: athrow
    // Exception table:
    //   from	to	target	type
    //   325	333	880	finally
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    if (paramConstraintAnchor1.getOwner() == this)
      connect(paramConstraintAnchor1.getType(), paramConstraintAnchor2.getOwner(), paramConstraintAnchor2.getType(), paramInt); 
  }
  
  public void connectCircularConstraint(ConstraintWidget paramConstraintWidget, float paramFloat, int paramInt) {
    immediateConnect(ConstraintAnchor.Type.CENTER, paramConstraintWidget, ConstraintAnchor.Type.CENTER, paramInt, 0);
    this.mCircleConstraintAngle = paramFloat;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    int[] arrayOfInt1;
    ConstraintWidget constraintWidget1;
    this.mHorizontalResolution = paramConstraintWidget.mHorizontalResolution;
    this.mVerticalResolution = paramConstraintWidget.mVerticalResolution;
    this.mMatchConstraintDefaultWidth = paramConstraintWidget.mMatchConstraintDefaultWidth;
    this.mMatchConstraintDefaultHeight = paramConstraintWidget.mMatchConstraintDefaultHeight;
    int[] arrayOfInt2 = this.mResolvedMatchConstraintDefault;
    int[] arrayOfInt3 = paramConstraintWidget.mResolvedMatchConstraintDefault;
    arrayOfInt2[0] = arrayOfInt3[0];
    arrayOfInt2[1] = arrayOfInt3[1];
    this.mMatchConstraintMinWidth = paramConstraintWidget.mMatchConstraintMinWidth;
    this.mMatchConstraintMaxWidth = paramConstraintWidget.mMatchConstraintMaxWidth;
    this.mMatchConstraintMinHeight = paramConstraintWidget.mMatchConstraintMinHeight;
    this.mMatchConstraintMaxHeight = paramConstraintWidget.mMatchConstraintMaxHeight;
    this.mMatchConstraintPercentHeight = paramConstraintWidget.mMatchConstraintPercentHeight;
    this.mIsWidthWrapContent = paramConstraintWidget.mIsWidthWrapContent;
    this.mIsHeightWrapContent = paramConstraintWidget.mIsHeightWrapContent;
    this.mResolvedDimensionRatioSide = paramConstraintWidget.mResolvedDimensionRatioSide;
    this.mResolvedDimensionRatio = paramConstraintWidget.mResolvedDimensionRatio;
    arrayOfInt2 = paramConstraintWidget.mMaxDimension;
    this.mMaxDimension = Arrays.copyOf(arrayOfInt2, arrayOfInt2.length);
    this.mCircleConstraintAngle = paramConstraintWidget.mCircleConstraintAngle;
    this.hasBaseline = paramConstraintWidget.hasBaseline;
    this.inPlaceholder = paramConstraintWidget.inPlaceholder;
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mListDimensionBehaviors = Arrays.<DimensionBehaviour>copyOf(this.mListDimensionBehaviors, 2);
    ConstraintWidget constraintWidget3 = this.mParent;
    arrayOfInt3 = null;
    if (constraintWidget3 == null) {
      constraintWidget3 = null;
    } else {
      constraintWidget3 = paramHashMap.get(paramConstraintWidget.mParent);
    } 
    this.mParent = constraintWidget3;
    this.mWidth = paramConstraintWidget.mWidth;
    this.mHeight = paramConstraintWidget.mHeight;
    this.mDimensionRatio = paramConstraintWidget.mDimensionRatio;
    this.mDimensionRatioSide = paramConstraintWidget.mDimensionRatioSide;
    this.mX = paramConstraintWidget.mX;
    this.mY = paramConstraintWidget.mY;
    this.mRelX = paramConstraintWidget.mRelX;
    this.mRelY = paramConstraintWidget.mRelY;
    this.mOffsetX = paramConstraintWidget.mOffsetX;
    this.mOffsetY = paramConstraintWidget.mOffsetY;
    this.mBaselineDistance = paramConstraintWidget.mBaselineDistance;
    this.mMinWidth = paramConstraintWidget.mMinWidth;
    this.mMinHeight = paramConstraintWidget.mMinHeight;
    this.mHorizontalBiasPercent = paramConstraintWidget.mHorizontalBiasPercent;
    this.mVerticalBiasPercent = paramConstraintWidget.mVerticalBiasPercent;
    this.mCompanionWidget = paramConstraintWidget.mCompanionWidget;
    this.mContainerItemSkip = paramConstraintWidget.mContainerItemSkip;
    this.mVisibility = paramConstraintWidget.mVisibility;
    this.mDebugName = paramConstraintWidget.mDebugName;
    this.mType = paramConstraintWidget.mType;
    this.mDistToTop = paramConstraintWidget.mDistToTop;
    this.mDistToLeft = paramConstraintWidget.mDistToLeft;
    this.mDistToRight = paramConstraintWidget.mDistToRight;
    this.mDistToBottom = paramConstraintWidget.mDistToBottom;
    this.mLeftHasCentered = paramConstraintWidget.mLeftHasCentered;
    this.mRightHasCentered = paramConstraintWidget.mRightHasCentered;
    this.mTopHasCentered = paramConstraintWidget.mTopHasCentered;
    this.mBottomHasCentered = paramConstraintWidget.mBottomHasCentered;
    this.mHorizontalWrapVisited = paramConstraintWidget.mHorizontalWrapVisited;
    this.mVerticalWrapVisited = paramConstraintWidget.mVerticalWrapVisited;
    this.mOptimizerMeasurable = paramConstraintWidget.mOptimizerMeasurable;
    this.mGroupsToSolver = paramConstraintWidget.mGroupsToSolver;
    this.mHorizontalChainStyle = paramConstraintWidget.mHorizontalChainStyle;
    this.mVerticalChainStyle = paramConstraintWidget.mVerticalChainStyle;
    this.mHorizontalChainFixedPosition = paramConstraintWidget.mHorizontalChainFixedPosition;
    this.mVerticalChainFixedPosition = paramConstraintWidget.mVerticalChainFixedPosition;
    float[] arrayOfFloat1 = this.mWeight;
    float[] arrayOfFloat2 = paramConstraintWidget.mWeight;
    arrayOfFloat1[0] = arrayOfFloat2[0];
    arrayOfFloat1[1] = arrayOfFloat2[1];
    ConstraintWidget[] arrayOfConstraintWidget1 = this.mListNextMatchConstraintsWidget;
    ConstraintWidget[] arrayOfConstraintWidget2 = paramConstraintWidget.mListNextMatchConstraintsWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    arrayOfConstraintWidget1 = this.mNextChainWidget;
    arrayOfConstraintWidget2 = paramConstraintWidget.mNextChainWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    ConstraintWidget constraintWidget2 = paramConstraintWidget.mHorizontalNextWidget;
    if (constraintWidget2 == null) {
      constraintWidget2 = null;
    } else {
      constraintWidget2 = paramHashMap.get(constraintWidget2);
    } 
    this.mHorizontalNextWidget = constraintWidget2;
    paramConstraintWidget = paramConstraintWidget.mVerticalNextWidget;
    if (paramConstraintWidget == null) {
      arrayOfInt1 = arrayOfInt3;
    } else {
      constraintWidget1 = paramHashMap.get(arrayOfInt1);
    } 
    this.mVerticalNextWidget = constraintWidget1;
  }
  
  public void createObjectVariables(LinearSystem paramLinearSystem) {
    paramLinearSystem.createObjectVariable(this.mLeft);
    paramLinearSystem.createObjectVariable(this.mTop);
    paramLinearSystem.createObjectVariable(this.mRight);
    paramLinearSystem.createObjectVariable(this.mBottom);
    if (this.mBaselineDistance > 0)
      paramLinearSystem.createObjectVariable(this.mBaseline); 
  }
  
  public ConstraintAnchor getAnchor(ConstraintAnchor.Type paramType) {
    switch (paramType) {
      default:
        throw new AssertionError(paramType.name());
      case null:
        return null;
      case null:
        return this.mCenterY;
      case null:
        return this.mCenterX;
      case null:
        return this.mCenter;
      case null:
        return this.mBaseline;
      case null:
        return this.mBottom;
      case null:
        return this.mRight;
      case null:
        return this.mTop;
      case null:
        break;
    } 
    return this.mLeft;
  }
  
  public ArrayList<ConstraintAnchor> getAnchors() {
    return this.mAnchors;
  }
  
  public int getBaselineDistance() {
    return this.mBaselineDistance;
  }
  
  public float getBiasPercent(int paramInt) {
    return (paramInt == 0) ? this.mHorizontalBiasPercent : ((paramInt == 1) ? this.mVerticalBiasPercent : -1.0F);
  }
  
  public int getBottom() {
    return getY() + this.mHeight;
  }
  
  public Object getCompanionWidget() {
    return this.mCompanionWidget;
  }
  
  public int getContainerItemSkip() {
    return this.mContainerItemSkip;
  }
  
  public String getDebugName() {
    return this.mDebugName;
  }
  
  public DimensionBehaviour getDimensionBehaviour(int paramInt) {
    return (paramInt == 0) ? getHorizontalDimensionBehaviour() : ((paramInt == 1) ? getVerticalDimensionBehaviour() : null);
  }
  
  public float getDimensionRatio() {
    return this.mDimensionRatio;
  }
  
  public int getDimensionRatioSide() {
    return this.mDimensionRatioSide;
  }
  
  public boolean getHasBaseline() {
    return this.hasBaseline;
  }
  
  public int getHeight() {
    return (this.mVisibility == 8) ? 0 : this.mHeight;
  }
  
  public float getHorizontalBiasPercent() {
    return this.mHorizontalBiasPercent;
  }
  
  public ConstraintWidget getHorizontalChainControlWidget() {
    boolean bool = isInHorizontalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.LEFT);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getHorizontalChainStyle() {
    return this.mHorizontalChainStyle;
  }
  
  public DimensionBehaviour getHorizontalDimensionBehaviour() {
    return this.mListDimensionBehaviors[0];
  }
  
  public int getHorizontalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + constraintAnchor.mMargin; 
    constraintAnchor = this.mRight;
    int j = i;
    if (constraintAnchor != null)
      j = i + constraintAnchor.mMargin; 
    return j;
  }
  
  public int getLeft() {
    return getX();
  }
  
  public int getLength(int paramInt) {
    return (paramInt == 0) ? getWidth() : ((paramInt == 1) ? getHeight() : 0);
  }
  
  public int getMaxHeight() {
    return this.mMaxDimension[1];
  }
  
  public int getMaxWidth() {
    return this.mMaxDimension[0];
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public ConstraintWidget getNextChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mRight.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mRight.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mRight;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mBottom.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mBottom.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mBottom;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  public int getOptimizerWrapHeight() {
    int i = this.mHeight;
    int j = i;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultHeight == 1) {
        i = Math.max(this.mMatchConstraintMinHeight, i);
      } else {
        i = this.mMatchConstraintMinHeight;
        if (i > 0) {
          this.mHeight = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxHeight;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public int getOptimizerWrapWidth() {
    int i = this.mWidth;
    int j = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultWidth == 1) {
        i = Math.max(this.mMatchConstraintMinWidth, i);
      } else {
        i = this.mMatchConstraintMinWidth;
        if (i > 0) {
          this.mWidth = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxWidth;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public ConstraintWidget getParent() {
    return this.mParent;
  }
  
  public ConstraintWidget getPreviousChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mLeft.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mLeft;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mTop.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mTop.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  int getRelativePositioning(int paramInt) {
    return (paramInt == 0) ? this.mRelX : ((paramInt == 1) ? this.mRelY : 0);
  }
  
  public int getRight() {
    return getX() + this.mWidth;
  }
  
  protected int getRootX() {
    return this.mX + this.mOffsetX;
  }
  
  protected int getRootY() {
    return this.mY + this.mOffsetY;
  }
  
  public WidgetRun getRun(int paramInt) {
    return (WidgetRun)((paramInt == 0) ? this.horizontalRun : ((paramInt == 1) ? this.verticalRun : null));
  }
  
  public int getTop() {
    return getY();
  }
  
  public String getType() {
    return this.mType;
  }
  
  public float getVerticalBiasPercent() {
    return this.mVerticalBiasPercent;
  }
  
  public ConstraintWidget getVerticalChainControlWidget() {
    boolean bool = isInVerticalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.TOP);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getVerticalChainStyle() {
    return this.mVerticalChainStyle;
  }
  
  public DimensionBehaviour getVerticalDimensionBehaviour() {
    return this.mListDimensionBehaviors[1];
  }
  
  public int getVerticalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + this.mTop.mMargin; 
    int j = i;
    if (this.mRight != null)
      j = i + this.mBottom.mMargin; 
    return j;
  }
  
  public int getVisibility() {
    return this.mVisibility;
  }
  
  public int getWidth() {
    return (this.mVisibility == 8) ? 0 : this.mWidth;
  }
  
  public int getX() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingLeft + this.mX) : this.mX;
  }
  
  public int getY() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingTop + this.mY) : this.mY;
  }
  
  public boolean hasBaseline() {
    return this.hasBaseline;
  }
  
  public void immediateConnect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, int paramInt2) {
    getAnchor(paramType1).connect(paramConstraintWidget.getAnchor(paramType2), paramInt1, paramInt2, true);
  }
  
  public boolean isHeightWrapContent() {
    return this.mIsHeightWrapContent;
  }
  
  public boolean isInHorizontalChain() {
    return ((this.mLeft.mTarget != null && this.mLeft.mTarget.mTarget == this.mLeft) || (this.mRight.mTarget != null && this.mRight.mTarget.mTarget == this.mRight));
  }
  
  public boolean isInPlaceholder() {
    return this.inPlaceholder;
  }
  
  public boolean isInVerticalChain() {
    return ((this.mTop.mTarget != null && this.mTop.mTarget.mTarget == this.mTop) || (this.mBottom.mTarget != null && this.mBottom.mTarget.mTarget == this.mBottom));
  }
  
  public boolean isInVirtualLayout() {
    return this.mInVirtuaLayout;
  }
  
  public boolean isRoot() {
    return (this.mParent == null);
  }
  
  public boolean isSpreadHeight() {
    return (this.mMatchConstraintDefaultHeight == 0 && this.mDimensionRatio == 0.0F && this.mMatchConstraintMinHeight == 0 && this.mMatchConstraintMaxHeight == 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean isSpreadWidth() {
    int i = this.mMatchConstraintDefaultWidth;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.mDimensionRatio == 0.0F) {
        bool1 = bool2;
        if (this.mMatchConstraintMinWidth == 0) {
          bool1 = bool2;
          if (this.mMatchConstraintMaxWidth == 0) {
            bool1 = bool2;
            if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public boolean isWidthWrapContent() {
    return this.mIsWidthWrapContent;
  }
  
  public void reset() {
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mParent = null;
    this.mCircleConstraintAngle = 0.0F;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    this.mMinWidth = 0;
    this.mMinHeight = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors[1] = DimensionBehaviour.FIXED;
    this.mCompanionWidget = null;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mType = null;
    this.mHorizontalWrapVisited = false;
    this.mVerticalWrapVisited = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mHorizontalChainFixedPosition = false;
    this.mVerticalChainFixedPosition = false;
    float[] arrayOfFloat = this.mWeight;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.mHorizontalResolution = -1;
    this.mVerticalResolution = -1;
    int[] arrayOfInt = this.mMaxDimension;
    arrayOfInt[0] = Integer.MAX_VALUE;
    arrayOfInt[1] = Integer.MAX_VALUE;
    this.mMatchConstraintDefaultWidth = 0;
    this.mMatchConstraintDefaultHeight = 0;
    this.mMatchConstraintPercentWidth = 1.0F;
    this.mMatchConstraintPercentHeight = 1.0F;
    this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
    this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
    this.mMatchConstraintMinWidth = 0;
    this.mMatchConstraintMinHeight = 0;
    this.mResolvedHasRatio = false;
    this.mResolvedDimensionRatioSide = -1;
    this.mResolvedDimensionRatio = 1.0F;
    this.mOptimizerMeasurable = false;
    this.mGroupsToSolver = false;
    boolean[] arrayOfBoolean = this.isTerminalWidget;
    arrayOfBoolean[0] = true;
    arrayOfBoolean[1] = true;
    this.mInVirtuaLayout = false;
    arrayOfBoolean = this.mIsInBarrier;
    arrayOfBoolean[0] = false;
    arrayOfBoolean[1] = false;
  }
  
  public void resetAllConstraints() {
    resetAnchors();
    setVerticalBiasPercent(DEFAULT_BIAS);
    setHorizontalBiasPercent(DEFAULT_BIAS);
  }
  
  public void resetAnchor(ConstraintAnchor paramConstraintAnchor) {
    if (getParent() != null && getParent() instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
    ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor constraintAnchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
    ConstraintAnchor constraintAnchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor constraintAnchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
    if (paramConstraintAnchor == constraintAnchor5) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor6) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget().getOwner() == constraintAnchor2.getTarget().getOwner()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor7) {
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget().getOwner() == constraintAnchor4.getTarget().getOwner()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor1 || paramConstraintAnchor == constraintAnchor2) {
      if (constraintAnchor1.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget())
        constraintAnchor5.reset(); 
    } else if ((paramConstraintAnchor == constraintAnchor3 || paramConstraintAnchor == constraintAnchor4) && constraintAnchor3.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
      constraintAnchor5.reset();
    } 
    paramConstraintAnchor.reset();
  }
  
  public void resetAnchors() {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    int i = 0;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).reset();
      i++;
    } 
  }
  
  public void resetSolverVariables(Cache paramCache) {
    this.mLeft.resetSolverVariable(paramCache);
    this.mTop.resetSolverVariable(paramCache);
    this.mRight.resetSolverVariable(paramCache);
    this.mBottom.resetSolverVariable(paramCache);
    this.mBaseline.resetSolverVariable(paramCache);
    this.mCenter.resetSolverVariable(paramCache);
    this.mCenterX.resetSolverVariable(paramCache);
    this.mCenterY.resetSolverVariable(paramCache);
  }
  
  public void setBaselineDistance(int paramInt) {
    boolean bool;
    this.mBaselineDistance = paramInt;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.hasBaseline = bool;
  }
  
  public void setCompanionWidget(Object paramObject) {
    this.mCompanionWidget = paramObject;
  }
  
  public void setContainerItemSkip(int paramInt) {
    if (paramInt >= 0) {
      this.mContainerItemSkip = paramInt;
      return;
    } 
    this.mContainerItemSkip = 0;
  }
  
  public void setDebugName(String paramString) {
    this.mDebugName = paramString;
  }
  
  public void setDebugSolverName(LinearSystem paramLinearSystem, String paramString) {
    this.mDebugName = paramString;
    SolverVariable solverVariable4 = paramLinearSystem.createObjectVariable(this.mLeft);
    SolverVariable solverVariable3 = paramLinearSystem.createObjectVariable(this.mTop);
    SolverVariable solverVariable2 = paramLinearSystem.createObjectVariable(this.mRight);
    SolverVariable solverVariable1 = paramLinearSystem.createObjectVariable(this.mBottom);
    StringBuilder stringBuilder4 = new StringBuilder();
    stringBuilder4.append(paramString);
    stringBuilder4.append(".left");
    solverVariable4.setName(stringBuilder4.toString());
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".top");
    solverVariable3.setName(stringBuilder3.toString());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(".right");
    solverVariable2.setName(stringBuilder2.toString());
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append(".bottom");
    solverVariable1.setName(stringBuilder1.toString());
    if (this.mBaselineDistance > 0) {
      SolverVariable solverVariable = paramLinearSystem.createObjectVariable(this.mBaseline);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append(".baseline");
      solverVariable.setName(stringBuilder.toString());
    } 
  }
  
  public void setDimension(int paramInt1, int paramInt2) {
    this.mWidth = paramInt1;
    int i = this.mMinWidth;
    if (paramInt1 < i)
      this.mWidth = i; 
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
  }
  
  public void setDimensionRatio(float paramFloat, int paramInt) {
    this.mDimensionRatio = paramFloat;
    this.mDimensionRatioSide = paramInt;
  }
  
  public void setDimensionRatio(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 261
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: ifne -> 14
    //   11: goto -> 261
    //   14: iconst_m1
    //   15: istore #6
    //   17: aload_1
    //   18: invokevirtual length : ()I
    //   21: istore #8
    //   23: aload_1
    //   24: bipush #44
    //   26: invokevirtual indexOf : (I)I
    //   29: istore #9
    //   31: iconst_0
    //   32: istore #7
    //   34: iload #6
    //   36: istore #4
    //   38: iload #7
    //   40: istore #5
    //   42: iload #9
    //   44: ifle -> 114
    //   47: iload #6
    //   49: istore #4
    //   51: iload #7
    //   53: istore #5
    //   55: iload #9
    //   57: iload #8
    //   59: iconst_1
    //   60: isub
    //   61: if_icmpge -> 114
    //   64: aload_1
    //   65: iconst_0
    //   66: iload #9
    //   68: invokevirtual substring : (II)Ljava/lang/String;
    //   71: astore #10
    //   73: aload #10
    //   75: ldc_w 'W'
    //   78: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   81: ifeq -> 90
    //   84: iconst_0
    //   85: istore #4
    //   87: goto -> 108
    //   90: iload #6
    //   92: istore #4
    //   94: aload #10
    //   96: ldc_w 'H'
    //   99: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   102: ifeq -> 108
    //   105: iconst_1
    //   106: istore #4
    //   108: iload #9
    //   110: iconst_1
    //   111: iadd
    //   112: istore #5
    //   114: aload_1
    //   115: bipush #58
    //   117: invokevirtual indexOf : (I)I
    //   120: istore #6
    //   122: iload #6
    //   124: iflt -> 219
    //   127: iload #6
    //   129: iload #8
    //   131: iconst_1
    //   132: isub
    //   133: if_icmpge -> 219
    //   136: aload_1
    //   137: iload #5
    //   139: iload #6
    //   141: invokevirtual substring : (II)Ljava/lang/String;
    //   144: astore #10
    //   146: aload_1
    //   147: iload #6
    //   149: iconst_1
    //   150: iadd
    //   151: invokevirtual substring : (I)Ljava/lang/String;
    //   154: astore_1
    //   155: aload #10
    //   157: invokevirtual length : ()I
    //   160: ifle -> 241
    //   163: aload_1
    //   164: invokevirtual length : ()I
    //   167: ifle -> 241
    //   170: aload #10
    //   172: invokestatic parseFloat : (Ljava/lang/String;)F
    //   175: fstore_2
    //   176: aload_1
    //   177: invokestatic parseFloat : (Ljava/lang/String;)F
    //   180: fstore_3
    //   181: fload_2
    //   182: fconst_0
    //   183: fcmpl
    //   184: ifle -> 241
    //   187: fload_3
    //   188: fconst_0
    //   189: fcmpl
    //   190: ifle -> 241
    //   193: iload #4
    //   195: iconst_1
    //   196: if_icmpne -> 209
    //   199: fload_3
    //   200: fload_2
    //   201: fdiv
    //   202: invokestatic abs : (F)F
    //   205: fstore_2
    //   206: goto -> 243
    //   209: fload_2
    //   210: fload_3
    //   211: fdiv
    //   212: invokestatic abs : (F)F
    //   215: fstore_2
    //   216: goto -> 243
    //   219: aload_1
    //   220: iload #5
    //   222: invokevirtual substring : (I)Ljava/lang/String;
    //   225: astore_1
    //   226: aload_1
    //   227: invokevirtual length : ()I
    //   230: ifle -> 241
    //   233: aload_1
    //   234: invokestatic parseFloat : (Ljava/lang/String;)F
    //   237: fstore_2
    //   238: goto -> 243
    //   241: fconst_0
    //   242: fstore_2
    //   243: fload_2
    //   244: fconst_0
    //   245: fcmpl
    //   246: ifle -> 260
    //   249: aload_0
    //   250: fload_2
    //   251: putfield mDimensionRatio : F
    //   254: aload_0
    //   255: iload #4
    //   257: putfield mDimensionRatioSide : I
    //   260: return
    //   261: aload_0
    //   262: fconst_0
    //   263: putfield mDimensionRatio : F
    //   266: return
    //   267: astore_1
    //   268: goto -> 241
    // Exception table:
    //   from	to	target	type
    //   170	181	267	java/lang/NumberFormatException
    //   199	206	267	java/lang/NumberFormatException
    //   209	216	267	java/lang/NumberFormatException
    //   233	238	267	java/lang/NumberFormatException
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      setHorizontalDimension(paramInt1, paramInt2);
      return;
    } 
    if (paramInt3 == 1)
      setVerticalDimension(paramInt1, paramInt2); 
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    this.mX = paramInt1;
    this.mY = paramInt2;
    if (this.mVisibility == 8) {
      this.mWidth = 0;
      this.mHeight = 0;
      return;
    } 
    paramInt1 = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.FIXED) {
      paramInt2 = this.mWidth;
      paramInt1 = i;
      if (i < paramInt2)
        paramInt1 = paramInt2; 
    } 
    paramInt2 = paramInt3;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.FIXED) {
      paramInt4 = this.mHeight;
      paramInt2 = paramInt3;
      if (paramInt3 < paramInt4)
        paramInt2 = paramInt4; 
    } 
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
    paramInt3 = this.mMinHeight;
    if (paramInt2 < paramInt3)
      this.mHeight = paramInt3; 
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setGoneMargin(ConstraintAnchor.Type paramType, int paramInt) {
    int i = null.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintAnchor$Type[paramType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4)
            return; 
          this.mBottom.mGoneMargin = paramInt;
          return;
        } 
        this.mRight.mGoneMargin = paramInt;
        return;
      } 
      this.mTop.mGoneMargin = paramInt;
      return;
    } 
    this.mLeft.mGoneMargin = paramInt;
  }
  
  public void setHasBaseline(boolean paramBoolean) {
    this.hasBaseline = paramBoolean;
  }
  
  public void setHeight(int paramInt) {
    this.mHeight = paramInt;
    int i = this.mMinHeight;
    if (paramInt < i)
      this.mHeight = i; 
  }
  
  public void setHeightWrapContent(boolean paramBoolean) {
    this.mIsHeightWrapContent = paramBoolean;
  }
  
  public void setHorizontalBiasPercent(float paramFloat) {
    this.mHorizontalBiasPercent = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt) {
    this.mHorizontalChainStyle = paramInt;
  }
  
  public void setHorizontalDimension(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mWidth = paramInt1;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setHorizontalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[0] = paramDimensionBehaviour;
  }
  
  public void setHorizontalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultWidth = paramInt1;
    this.mMatchConstraintMinWidth = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxWidth = paramInt2;
    this.mMatchConstraintPercentWidth = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultWidth = 2; 
  }
  
  public void setHorizontalWeight(float paramFloat) {
    this.mWeight[0] = paramFloat;
  }
  
  protected void setInBarrier(int paramInt, boolean paramBoolean) {
    this.mIsInBarrier[paramInt] = paramBoolean;
  }
  
  public void setInPlaceholder(boolean paramBoolean) {
    this.inPlaceholder = paramBoolean;
  }
  
  public void setInVirtualLayout(boolean paramBoolean) {
    this.mInVirtuaLayout = paramBoolean;
  }
  
  public void setLength(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      setWidth(paramInt1);
      return;
    } 
    if (paramInt2 == 1)
      setHeight(paramInt1); 
  }
  
  public void setMaxHeight(int paramInt) {
    this.mMaxDimension[1] = paramInt;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxDimension[0] = paramInt;
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt < 0) {
      this.mMinHeight = 0;
      return;
    } 
    this.mMinHeight = paramInt;
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt < 0) {
      this.mMinWidth = 0;
      return;
    } 
    this.mMinWidth = paramInt;
  }
  
  public void setOffset(int paramInt1, int paramInt2) {
    this.mOffsetX = paramInt1;
    this.mOffsetY = paramInt2;
  }
  
  public void setOrigin(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setParent(ConstraintWidget paramConstraintWidget) {
    this.mParent = paramConstraintWidget;
  }
  
  void setRelativePositioning(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      this.mRelX = paramInt1;
      return;
    } 
    if (paramInt2 == 1)
      this.mRelY = paramInt1; 
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setVerticalBiasPercent(float paramFloat) {
    this.mVerticalBiasPercent = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt) {
    this.mVerticalChainStyle = paramInt;
  }
  
  public void setVerticalDimension(int paramInt1, int paramInt2) {
    this.mY = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mHeight = paramInt1;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setVerticalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[1] = paramDimensionBehaviour;
  }
  
  public void setVerticalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultHeight = paramInt1;
    this.mMatchConstraintMinHeight = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxHeight = paramInt2;
    this.mMatchConstraintPercentHeight = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultHeight = 2; 
  }
  
  public void setVerticalWeight(float paramFloat) {
    this.mWeight[1] = paramFloat;
  }
  
  public void setVisibility(int paramInt) {
    this.mVisibility = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.mWidth = paramInt;
    int i = this.mMinWidth;
    if (paramInt < i)
      this.mWidth = i; 
  }
  
  public void setWidthWrapContent(boolean paramBoolean) {
    this.mIsWidthWrapContent = paramBoolean;
  }
  
  public void setX(int paramInt) {
    this.mX = paramInt;
  }
  
  public void setY(int paramInt) {
    this.mY = paramInt;
  }
  
  public void setupDimensionRatio(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.mResolvedDimensionRatioSide = 1;
        if (this.mDimensionRatioSide == -1)
          this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio; 
      }  
    if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
      this.mResolvedDimensionRatioSide = 1;
    } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
      this.mResolvedDimensionRatioSide = 0;
    } 
    if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected()))
      if (this.mTop.isConnected() && this.mBottom.isConnected()) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1) {
      int i = this.mMatchConstraintMinWidth;
      if (i > 0 && this.mMatchConstraintMinHeight == 0) {
        this.mResolvedDimensionRatioSide = 0;
        return;
      } 
      if (i == 0 && this.mMatchConstraintMinHeight > 0) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.mType;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("type: ");
      stringBuilder1.append(this.mType);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.mDebugName != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("id: ");
      stringBuilder1.append(this.mDebugName);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.mX);
    stringBuilder.append(", ");
    stringBuilder.append(this.mY);
    stringBuilder.append(") - (");
    stringBuilder.append(this.mWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mHeight);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   5: invokevirtual isResolved : ()Z
    //   8: iand
    //   9: istore #9
    //   11: iload_2
    //   12: aload_0
    //   13: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   16: invokevirtual isResolved : ()Z
    //   19: iand
    //   20: istore #8
    //   22: aload_0
    //   23: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   26: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   29: getfield value : I
    //   32: istore_3
    //   33: aload_0
    //   34: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   37: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   40: getfield value : I
    //   43: istore #4
    //   45: aload_0
    //   46: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   49: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   52: getfield value : I
    //   55: istore #6
    //   57: aload_0
    //   58: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   61: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   64: getfield value : I
    //   67: istore #7
    //   69: iload #6
    //   71: iload_3
    //   72: isub
    //   73: iflt -> 146
    //   76: iload #7
    //   78: iload #4
    //   80: isub
    //   81: iflt -> 146
    //   84: iload_3
    //   85: ldc_w -2147483648
    //   88: if_icmpeq -> 146
    //   91: iload_3
    //   92: ldc 2147483647
    //   94: if_icmpeq -> 146
    //   97: iload #4
    //   99: ldc_w -2147483648
    //   102: if_icmpeq -> 146
    //   105: iload #4
    //   107: ldc 2147483647
    //   109: if_icmpeq -> 146
    //   112: iload #6
    //   114: ldc_w -2147483648
    //   117: if_icmpeq -> 146
    //   120: iload #6
    //   122: ldc 2147483647
    //   124: if_icmpeq -> 146
    //   127: iload #7
    //   129: ldc_w -2147483648
    //   132: if_icmpeq -> 146
    //   135: iload #7
    //   137: istore #5
    //   139: iload #7
    //   141: ldc 2147483647
    //   143: if_icmpne -> 157
    //   146: iconst_0
    //   147: istore_3
    //   148: iconst_0
    //   149: istore #4
    //   151: iconst_0
    //   152: istore #6
    //   154: iconst_0
    //   155: istore #5
    //   157: iload #6
    //   159: iload_3
    //   160: isub
    //   161: istore #6
    //   163: iload #5
    //   165: iload #4
    //   167: isub
    //   168: istore #5
    //   170: iload #9
    //   172: ifeq -> 180
    //   175: aload_0
    //   176: iload_3
    //   177: putfield mX : I
    //   180: iload #8
    //   182: ifeq -> 191
    //   185: aload_0
    //   186: iload #4
    //   188: putfield mY : I
    //   191: aload_0
    //   192: getfield mVisibility : I
    //   195: bipush #8
    //   197: if_icmpne -> 211
    //   200: aload_0
    //   201: iconst_0
    //   202: putfield mWidth : I
    //   205: aload_0
    //   206: iconst_0
    //   207: putfield mHeight : I
    //   210: return
    //   211: iload #9
    //   213: ifeq -> 273
    //   216: iload #6
    //   218: istore_3
    //   219: aload_0
    //   220: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   223: iconst_0
    //   224: aaload
    //   225: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   228: if_acmpne -> 250
    //   231: aload_0
    //   232: getfield mWidth : I
    //   235: istore #4
    //   237: iload #6
    //   239: istore_3
    //   240: iload #6
    //   242: iload #4
    //   244: if_icmpge -> 250
    //   247: iload #4
    //   249: istore_3
    //   250: aload_0
    //   251: iload_3
    //   252: putfield mWidth : I
    //   255: aload_0
    //   256: getfield mMinWidth : I
    //   259: istore #4
    //   261: iload_3
    //   262: iload #4
    //   264: if_icmpge -> 273
    //   267: aload_0
    //   268: iload #4
    //   270: putfield mWidth : I
    //   273: iload #8
    //   275: ifeq -> 335
    //   278: iload #5
    //   280: istore_3
    //   281: aload_0
    //   282: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   285: iconst_1
    //   286: aaload
    //   287: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   290: if_acmpne -> 312
    //   293: aload_0
    //   294: getfield mHeight : I
    //   297: istore #4
    //   299: iload #5
    //   301: istore_3
    //   302: iload #5
    //   304: iload #4
    //   306: if_icmpge -> 312
    //   309: iload #4
    //   311: istore_3
    //   312: aload_0
    //   313: iload_3
    //   314: putfield mHeight : I
    //   317: aload_0
    //   318: getfield mMinHeight : I
    //   321: istore #4
    //   323: iload_3
    //   324: iload #4
    //   326: if_icmpge -> 335
    //   329: aload_0
    //   330: iload #4
    //   332: putfield mHeight : I
    //   335: return
  }
  
  public void updateFromSolver(LinearSystem paramLinearSystem) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   8: istore_3
    //   9: aload_1
    //   10: aload_0
    //   11: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   14: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   17: istore #6
    //   19: aload_1
    //   20: aload_0
    //   21: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   24: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   27: istore #5
    //   29: aload_1
    //   30: aload_0
    //   31: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   34: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   37: istore #7
    //   39: iload_3
    //   40: istore #4
    //   42: iload #5
    //   44: istore_2
    //   45: aload_0
    //   46: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   49: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   52: getfield resolved : Z
    //   55: ifeq -> 100
    //   58: iload_3
    //   59: istore #4
    //   61: iload #5
    //   63: istore_2
    //   64: aload_0
    //   65: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   68: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   71: getfield resolved : Z
    //   74: ifeq -> 100
    //   77: aload_0
    //   78: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   81: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   84: getfield value : I
    //   87: istore #4
    //   89: aload_0
    //   90: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   93: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   96: getfield value : I
    //   99: istore_2
    //   100: iload #6
    //   102: istore #5
    //   104: iload #7
    //   106: istore_3
    //   107: aload_0
    //   108: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   111: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   114: getfield resolved : Z
    //   117: ifeq -> 163
    //   120: iload #6
    //   122: istore #5
    //   124: iload #7
    //   126: istore_3
    //   127: aload_0
    //   128: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   131: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   134: getfield resolved : Z
    //   137: ifeq -> 163
    //   140: aload_0
    //   141: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   144: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   147: getfield value : I
    //   150: istore #5
    //   152: aload_0
    //   153: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   156: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   159: getfield value : I
    //   162: istore_3
    //   163: iload_2
    //   164: iload #4
    //   166: isub
    //   167: iflt -> 238
    //   170: iload_3
    //   171: iload #5
    //   173: isub
    //   174: iflt -> 238
    //   177: iload #4
    //   179: ldc_w -2147483648
    //   182: if_icmpeq -> 238
    //   185: iload #4
    //   187: ldc 2147483647
    //   189: if_icmpeq -> 238
    //   192: iload #5
    //   194: ldc_w -2147483648
    //   197: if_icmpeq -> 238
    //   200: iload #5
    //   202: ldc 2147483647
    //   204: if_icmpeq -> 238
    //   207: iload_2
    //   208: ldc_w -2147483648
    //   211: if_icmpeq -> 238
    //   214: iload_2
    //   215: ldc 2147483647
    //   217: if_icmpeq -> 238
    //   220: iload_3
    //   221: ldc_w -2147483648
    //   224: if_icmpeq -> 238
    //   227: iload_2
    //   228: istore #6
    //   230: iload_3
    //   231: istore_2
    //   232: iload_3
    //   233: ldc 2147483647
    //   235: if_icmpne -> 249
    //   238: iconst_0
    //   239: istore_2
    //   240: iconst_0
    //   241: istore #4
    //   243: iconst_0
    //   244: istore #5
    //   246: iconst_0
    //   247: istore #6
    //   249: aload_0
    //   250: iload #4
    //   252: iload #5
    //   254: iload #6
    //   256: iload_2
    //   257: invokevirtual setFrame : (IIII)V
    //   260: return
  }
  
  public enum DimensionBehaviour {
    FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
    
    static {
      DimensionBehaviour dimensionBehaviour1 = new DimensionBehaviour("FIXED", 0);
      FIXED = dimensionBehaviour1;
      DimensionBehaviour dimensionBehaviour2 = new DimensionBehaviour("WRAP_CONTENT", 1);
      WRAP_CONTENT = dimensionBehaviour2;
      DimensionBehaviour dimensionBehaviour3 = new DimensionBehaviour("MATCH_CONSTRAINT", 2);
      MATCH_CONSTRAINT = dimensionBehaviour3;
      DimensionBehaviour dimensionBehaviour4 = new DimensionBehaviour("MATCH_PARENT", 3);
      MATCH_PARENT = dimensionBehaviour4;
      $VALUES = new DimensionBehaviour[] { dimensionBehaviour1, dimensionBehaviour2, dimensionBehaviour3, dimensionBehaviour4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket-dex2jar.jar!\androidx\constraintlayout\solver\widgets\ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */