package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;
import java.util.HashMap;

public class Barrier extends HelperWidget {
  public static final int BOTTOM = 3;
  
  public static final int LEFT = 0;
  
  public static final int RIGHT = 1;
  
  public static final int TOP = 2;
  
  private boolean mAllowsGoneWidget = true;
  
  private int mBarrierType = 0;
  
  private int mMargin = 0;
  
  public void addToSolver(LinearSystem paramLinearSystem) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   4: iconst_0
    //   5: aload_0
    //   6: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   9: aastore
    //   10: aload_0
    //   11: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   14: iconst_2
    //   15: aload_0
    //   16: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   19: aastore
    //   20: aload_0
    //   21: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   24: iconst_1
    //   25: aload_0
    //   26: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   29: aastore
    //   30: aload_0
    //   31: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   34: iconst_3
    //   35: aload_0
    //   36: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   39: aastore
    //   40: iconst_0
    //   41: istore_2
    //   42: iload_2
    //   43: aload_0
    //   44: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   47: arraylength
    //   48: if_icmpge -> 77
    //   51: aload_0
    //   52: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   55: iload_2
    //   56: aaload
    //   57: aload_1
    //   58: aload_0
    //   59: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   62: iload_2
    //   63: aaload
    //   64: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   67: putfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   70: iload_2
    //   71: iconst_1
    //   72: iadd
    //   73: istore_2
    //   74: goto -> 42
    //   77: aload_0
    //   78: getfield mBarrierType : I
    //   81: istore_2
    //   82: iload_2
    //   83: iflt -> 900
    //   86: iload_2
    //   87: iconst_4
    //   88: if_icmpge -> 900
    //   91: aload_0
    //   92: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   95: aload_0
    //   96: getfield mBarrierType : I
    //   99: aaload
    //   100: astore #7
    //   102: iconst_0
    //   103: istore_2
    //   104: iload_2
    //   105: aload_0
    //   106: getfield mWidgetsCount : I
    //   109: if_icmpge -> 249
    //   112: aload_0
    //   113: getfield mWidgets : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   116: iload_2
    //   117: aaload
    //   118: astore #8
    //   120: aload_0
    //   121: getfield mAllowsGoneWidget : Z
    //   124: ifne -> 138
    //   127: aload #8
    //   129: invokevirtual allowedInBarrier : ()Z
    //   132: ifne -> 138
    //   135: goto -> 242
    //   138: aload_0
    //   139: getfield mBarrierType : I
    //   142: istore_3
    //   143: iload_3
    //   144: ifeq -> 152
    //   147: iload_3
    //   148: iconst_1
    //   149: if_icmpne -> 191
    //   152: aload #8
    //   154: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   157: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   160: if_acmpne -> 191
    //   163: aload #8
    //   165: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   168: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   171: ifnull -> 191
    //   174: aload #8
    //   176: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   179: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   182: ifnull -> 191
    //   185: iconst_1
    //   186: istore #6
    //   188: goto -> 252
    //   191: aload_0
    //   192: getfield mBarrierType : I
    //   195: istore_3
    //   196: iload_3
    //   197: iconst_2
    //   198: if_icmpeq -> 206
    //   201: iload_3
    //   202: iconst_3
    //   203: if_icmpne -> 242
    //   206: aload #8
    //   208: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   211: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   214: if_acmpne -> 242
    //   217: aload #8
    //   219: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   222: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   225: ifnull -> 242
    //   228: aload #8
    //   230: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   233: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   236: ifnull -> 242
    //   239: goto -> 185
    //   242: iload_2
    //   243: iconst_1
    //   244: iadd
    //   245: istore_2
    //   246: goto -> 104
    //   249: iconst_0
    //   250: istore #6
    //   252: aload_0
    //   253: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   256: invokevirtual hasCenteredDependents : ()Z
    //   259: ifne -> 280
    //   262: aload_0
    //   263: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   266: invokevirtual hasCenteredDependents : ()Z
    //   269: ifeq -> 275
    //   272: goto -> 280
    //   275: iconst_0
    //   276: istore_2
    //   277: goto -> 282
    //   280: iconst_1
    //   281: istore_2
    //   282: aload_0
    //   283: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   286: invokevirtual hasCenteredDependents : ()Z
    //   289: ifne -> 310
    //   292: aload_0
    //   293: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   296: invokevirtual hasCenteredDependents : ()Z
    //   299: ifeq -> 305
    //   302: goto -> 310
    //   305: iconst_0
    //   306: istore_3
    //   307: goto -> 312
    //   310: iconst_1
    //   311: istore_3
    //   312: iload #6
    //   314: ifne -> 367
    //   317: aload_0
    //   318: getfield mBarrierType : I
    //   321: istore #4
    //   323: iload #4
    //   325: ifne -> 332
    //   328: iload_2
    //   329: ifne -> 362
    //   332: iload #4
    //   334: iconst_2
    //   335: if_icmpne -> 342
    //   338: iload_3
    //   339: ifne -> 362
    //   342: iload #4
    //   344: iconst_1
    //   345: if_icmpne -> 352
    //   348: iload_2
    //   349: ifne -> 362
    //   352: iload #4
    //   354: iconst_3
    //   355: if_icmpne -> 367
    //   358: iload_3
    //   359: ifeq -> 367
    //   362: iconst_1
    //   363: istore_3
    //   364: goto -> 369
    //   367: iconst_0
    //   368: istore_3
    //   369: iconst_5
    //   370: istore_2
    //   371: iload_3
    //   372: ifne -> 377
    //   375: iconst_4
    //   376: istore_2
    //   377: iconst_0
    //   378: istore_3
    //   379: iload_3
    //   380: aload_0
    //   381: getfield mWidgetsCount : I
    //   384: if_icmpge -> 593
    //   387: aload_0
    //   388: getfield mWidgets : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   391: iload_3
    //   392: aaload
    //   393: astore #8
    //   395: aload_0
    //   396: getfield mAllowsGoneWidget : Z
    //   399: ifne -> 413
    //   402: aload #8
    //   404: invokevirtual allowedInBarrier : ()Z
    //   407: ifne -> 413
    //   410: goto -> 586
    //   413: aload_1
    //   414: aload #8
    //   416: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   419: aload_0
    //   420: getfield mBarrierType : I
    //   423: aaload
    //   424: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   427: astore #9
    //   429: aload #8
    //   431: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   434: aload_0
    //   435: getfield mBarrierType : I
    //   438: aaload
    //   439: aload #9
    //   441: putfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   444: aload #8
    //   446: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   449: aload_0
    //   450: getfield mBarrierType : I
    //   453: aaload
    //   454: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   457: ifnull -> 500
    //   460: aload #8
    //   462: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   465: aload_0
    //   466: getfield mBarrierType : I
    //   469: aaload
    //   470: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   473: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   476: aload_0
    //   477: if_acmpne -> 500
    //   480: aload #8
    //   482: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   485: aload_0
    //   486: getfield mBarrierType : I
    //   489: aaload
    //   490: getfield mMargin : I
    //   493: iconst_0
    //   494: iadd
    //   495: istore #4
    //   497: goto -> 503
    //   500: iconst_0
    //   501: istore #4
    //   503: aload_0
    //   504: getfield mBarrierType : I
    //   507: istore #5
    //   509: iload #5
    //   511: ifeq -> 546
    //   514: iload #5
    //   516: iconst_2
    //   517: if_icmpne -> 523
    //   520: goto -> 546
    //   523: aload_1
    //   524: aload #7
    //   526: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   529: aload #9
    //   531: aload_0
    //   532: getfield mMargin : I
    //   535: iload #4
    //   537: iadd
    //   538: iload #6
    //   540: invokevirtual addGreaterBarrier : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IZ)V
    //   543: goto -> 566
    //   546: aload_1
    //   547: aload #7
    //   549: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   552: aload #9
    //   554: aload_0
    //   555: getfield mMargin : I
    //   558: iload #4
    //   560: isub
    //   561: iload #6
    //   563: invokevirtual addLowerBarrier : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IZ)V
    //   566: aload_1
    //   567: aload #7
    //   569: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   572: aload #9
    //   574: aload_0
    //   575: getfield mMargin : I
    //   578: iload #4
    //   580: iadd
    //   581: iload_2
    //   582: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   585: pop
    //   586: iload_3
    //   587: iconst_1
    //   588: iadd
    //   589: istore_3
    //   590: goto -> 379
    //   593: aload_0
    //   594: getfield mBarrierType : I
    //   597: istore_2
    //   598: iload_2
    //   599: ifne -> 673
    //   602: aload_1
    //   603: aload_0
    //   604: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   607: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   610: aload_0
    //   611: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   614: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   617: iconst_0
    //   618: bipush #8
    //   620: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   623: pop
    //   624: aload_1
    //   625: aload_0
    //   626: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   629: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   632: aload_0
    //   633: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   636: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   639: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   642: iconst_0
    //   643: iconst_4
    //   644: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   647: pop
    //   648: aload_1
    //   649: aload_0
    //   650: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   653: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   656: aload_0
    //   657: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   660: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   663: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   666: iconst_0
    //   667: iconst_0
    //   668: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   671: pop
    //   672: return
    //   673: iload_2
    //   674: iconst_1
    //   675: if_icmpne -> 749
    //   678: aload_1
    //   679: aload_0
    //   680: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   683: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   686: aload_0
    //   687: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   690: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   693: iconst_0
    //   694: bipush #8
    //   696: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   699: pop
    //   700: aload_1
    //   701: aload_0
    //   702: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   705: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   708: aload_0
    //   709: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   712: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   715: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   718: iconst_0
    //   719: iconst_4
    //   720: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   723: pop
    //   724: aload_1
    //   725: aload_0
    //   726: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   729: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   732: aload_0
    //   733: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   736: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   739: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   742: iconst_0
    //   743: iconst_0
    //   744: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   747: pop
    //   748: return
    //   749: iload_2
    //   750: iconst_2
    //   751: if_icmpne -> 825
    //   754: aload_1
    //   755: aload_0
    //   756: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   759: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   762: aload_0
    //   763: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   766: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   769: iconst_0
    //   770: bipush #8
    //   772: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   775: pop
    //   776: aload_1
    //   777: aload_0
    //   778: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   781: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   784: aload_0
    //   785: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   788: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   791: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   794: iconst_0
    //   795: iconst_4
    //   796: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   799: pop
    //   800: aload_1
    //   801: aload_0
    //   802: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   805: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   808: aload_0
    //   809: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   812: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   815: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   818: iconst_0
    //   819: iconst_0
    //   820: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   823: pop
    //   824: return
    //   825: iload_2
    //   826: iconst_3
    //   827: if_icmpne -> 900
    //   830: aload_1
    //   831: aload_0
    //   832: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   835: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   838: aload_0
    //   839: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   842: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   845: iconst_0
    //   846: bipush #8
    //   848: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   851: pop
    //   852: aload_1
    //   853: aload_0
    //   854: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   857: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   860: aload_0
    //   861: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   864: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   867: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   870: iconst_0
    //   871: iconst_4
    //   872: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   875: pop
    //   876: aload_1
    //   877: aload_0
    //   878: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   881: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   884: aload_0
    //   885: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   888: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   891: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   894: iconst_0
    //   895: iconst_0
    //   896: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   899: pop
    //   900: return
  }
  
  public boolean allowedInBarrier() {
    return true;
  }
  
  public boolean allowsGoneWidget() {
    return this.mAllowsGoneWidget;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    this.mBarrierType = ((Barrier)paramConstraintWidget).mBarrierType;
    this.mAllowsGoneWidget = ((Barrier)paramConstraintWidget).mAllowsGoneWidget;
    this.mMargin = ((Barrier)paramConstraintWidget).mMargin;
  }
  
  public int getBarrierType() {
    return this.mBarrierType;
  }
  
  public int getMargin() {
    return this.mMargin;
  }
  
  protected void markWidgets() {
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      int j = this.mBarrierType;
      if (j == 0 || j == 1) {
        constraintWidget.setInBarrier(0, true);
      } else if (j == 2 || j == 3) {
        constraintWidget.setInBarrier(1, true);
      } 
    } 
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.mAllowsGoneWidget = paramBoolean;
  }
  
  public void setBarrierType(int paramInt) {
    this.mBarrierType = paramInt;
  }
  
  public void setMargin(int paramInt) {
    this.mMargin = paramInt;
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("[Barrier] ");
    stringBuilder1.append(getDebugName());
    stringBuilder1.append(" {");
    String str = stringBuilder1.toString();
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      String str1 = str;
      if (i > 0) {
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append(", ");
        str1 = stringBuilder3.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append(constraintWidget.getDebugName());
      str = stringBuilder.toString();
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str);
    stringBuilder2.append("}");
    return stringBuilder2.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket-dex2jar.jar!\androidx\constraintlayout\solver\widgets\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */