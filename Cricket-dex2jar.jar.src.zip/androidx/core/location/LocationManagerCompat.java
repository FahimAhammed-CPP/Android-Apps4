package androidx.core.location;

import android.location.GnssStatus;
import android.location.GpsStatus;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.collection.SimpleArrayMap;
import androidx.core.os.ExecutorCompat;
import androidx.core.util.Preconditions;
import java.lang.reflect.Field;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

public final class LocationManagerCompat {
  private static final long PRE_N_LOOPER_TIMEOUT_S = 4L;
  
  private static Field sContextField;
  
  private static final SimpleArrayMap<Object, Object> sGnssStatusListeners = new SimpleArrayMap();
  
  public static boolean isLocationEnabled(LocationManager paramLocationManager) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #28
    //   5: if_icmplt -> 13
    //   8: aload_0
    //   9: invokestatic isLocationEnabled : (Landroid/location/LocationManager;)Z
    //   12: ireturn
    //   13: getstatic android/os/Build$VERSION.SDK_INT : I
    //   16: istore_1
    //   17: iconst_0
    //   18: istore_2
    //   19: iload_1
    //   20: bipush #19
    //   22: if_icmpgt -> 102
    //   25: getstatic androidx/core/location/LocationManagerCompat.sContextField : Ljava/lang/reflect/Field;
    //   28: ifnonnull -> 41
    //   31: ldc android/location/LocationManager
    //   33: ldc 'mContext'
    //   35: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   38: putstatic androidx/core/location/LocationManagerCompat.sContextField : Ljava/lang/reflect/Field;
    //   41: getstatic androidx/core/location/LocationManagerCompat.sContextField : Ljava/lang/reflect/Field;
    //   44: iconst_1
    //   45: invokevirtual setAccessible : (Z)V
    //   48: getstatic androidx/core/location/LocationManagerCompat.sContextField : Ljava/lang/reflect/Field;
    //   51: aload_0
    //   52: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   55: checkcast android/content/Context
    //   58: astore #4
    //   60: getstatic android/os/Build$VERSION.SDK_INT : I
    //   63: bipush #19
    //   65: if_icmpne -> 84
    //   68: aload #4
    //   70: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   73: ldc 'location_mode'
    //   75: iconst_0
    //   76: invokestatic getInt : (Landroid/content/ContentResolver;Ljava/lang/String;I)I
    //   79: ifeq -> 129
    //   82: iconst_1
    //   83: ireturn
    //   84: aload #4
    //   86: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   89: ldc 'location_providers_allowed'
    //   91: invokestatic getString : (Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   94: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   97: istore_3
    //   98: iload_3
    //   99: iconst_1
    //   100: ixor
    //   101: ireturn
    //   102: aload_0
    //   103: ldc 'network'
    //   105: invokevirtual isProviderEnabled : (Ljava/lang/String;)Z
    //   108: ifne -> 120
    //   111: aload_0
    //   112: ldc 'gps'
    //   114: invokevirtual isProviderEnabled : (Ljava/lang/String;)Z
    //   117: ifeq -> 122
    //   120: iconst_1
    //   121: istore_2
    //   122: iload_2
    //   123: ireturn
    //   124: astore #4
    //   126: goto -> 102
    //   129: iconst_0
    //   130: ireturn
    // Exception table:
    //   from	to	target	type
    //   25	41	124	java/lang/ClassCastException
    //   25	41	124	java/lang/SecurityException
    //   25	41	124	java/lang/NoSuchFieldException
    //   25	41	124	java/lang/IllegalAccessException
    //   41	82	124	java/lang/ClassCastException
    //   41	82	124	java/lang/SecurityException
    //   41	82	124	java/lang/NoSuchFieldException
    //   41	82	124	java/lang/IllegalAccessException
    //   84	98	124	java/lang/ClassCastException
    //   84	98	124	java/lang/SecurityException
    //   84	98	124	java/lang/NoSuchFieldException
    //   84	98	124	java/lang/IllegalAccessException
  }
  
  private static boolean registerGnssStatusCallback(LocationManager paramLocationManager, Handler paramHandler, Executor paramExecutor, GnssStatusCompat.Callback paramCallback) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: istore #4
    //   5: iconst_1
    //   6: istore #6
    //   8: iconst_1
    //   9: istore #7
    //   11: iconst_1
    //   12: istore #5
    //   14: iload #4
    //   16: bipush #30
    //   18: if_icmplt -> 90
    //   21: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   24: astore #16
    //   26: aload #16
    //   28: monitorenter
    //   29: aload #16
    //   31: aload_3
    //   32: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   35: checkcast androidx/core/location/LocationManagerCompat$GnssStatusTransport
    //   38: astore #15
    //   40: aload #15
    //   42: astore_1
    //   43: aload #15
    //   45: ifnonnull -> 57
    //   48: new androidx/core/location/LocationManagerCompat$GnssStatusTransport
    //   51: dup
    //   52: aload_3
    //   53: invokespecial <init> : (Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   56: astore_1
    //   57: aload_0
    //   58: aload_2
    //   59: aload_1
    //   60: invokevirtual registerGnssStatusCallback : (Ljava/util/concurrent/Executor;Landroid/location/GnssStatus$Callback;)Z
    //   63: ifeq -> 79
    //   66: aload #16
    //   68: aload_3
    //   69: aload_1
    //   70: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   73: pop
    //   74: aload #16
    //   76: monitorexit
    //   77: iconst_1
    //   78: ireturn
    //   79: aload #16
    //   81: monitorexit
    //   82: iconst_0
    //   83: ireturn
    //   84: astore_0
    //   85: aload #16
    //   87: monitorexit
    //   88: aload_0
    //   89: athrow
    //   90: getstatic android/os/Build$VERSION.SDK_INT : I
    //   93: bipush #24
    //   95: if_icmplt -> 199
    //   98: aload_1
    //   99: ifnull -> 108
    //   102: iconst_1
    //   103: istore #8
    //   105: goto -> 111
    //   108: iconst_0
    //   109: istore #8
    //   111: iload #8
    //   113: invokestatic checkArgument : (Z)V
    //   116: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   119: astore #16
    //   121: aload #16
    //   123: monitorenter
    //   124: aload #16
    //   126: aload_3
    //   127: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   130: checkcast androidx/core/location/LocationManagerCompat$PreRGnssStatusTransport
    //   133: astore #15
    //   135: aload #15
    //   137: ifnonnull -> 153
    //   140: new androidx/core/location/LocationManagerCompat$PreRGnssStatusTransport
    //   143: dup
    //   144: aload_3
    //   145: invokespecial <init> : (Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   148: astore #15
    //   150: goto -> 158
    //   153: aload #15
    //   155: invokevirtual unregister : ()V
    //   158: aload #15
    //   160: aload_2
    //   161: invokevirtual register : (Ljava/util/concurrent/Executor;)V
    //   164: aload_0
    //   165: aload #15
    //   167: aload_1
    //   168: invokevirtual registerGnssStatusCallback : (Landroid/location/GnssStatus$Callback;Landroid/os/Handler;)Z
    //   171: ifeq -> 188
    //   174: aload #16
    //   176: aload_3
    //   177: aload #15
    //   179: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   182: pop
    //   183: aload #16
    //   185: monitorexit
    //   186: iconst_1
    //   187: ireturn
    //   188: aload #16
    //   190: monitorexit
    //   191: iconst_0
    //   192: ireturn
    //   193: astore_0
    //   194: aload #16
    //   196: monitorexit
    //   197: aload_0
    //   198: athrow
    //   199: aload_1
    //   200: ifnull -> 209
    //   203: iconst_1
    //   204: istore #8
    //   206: goto -> 212
    //   209: iconst_0
    //   210: istore #8
    //   212: iload #8
    //   214: invokestatic checkArgument : (Z)V
    //   217: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   220: astore #16
    //   222: aload #16
    //   224: monitorenter
    //   225: aload #16
    //   227: aload_3
    //   228: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   231: checkcast androidx/core/location/LocationManagerCompat$GpsStatusTransport
    //   234: astore #15
    //   236: aload #15
    //   238: ifnonnull -> 255
    //   241: new androidx/core/location/LocationManagerCompat$GpsStatusTransport
    //   244: dup
    //   245: aload_0
    //   246: aload_3
    //   247: invokespecial <init> : (Landroid/location/LocationManager;Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   250: astore #15
    //   252: goto -> 260
    //   255: aload #15
    //   257: invokevirtual unregister : ()V
    //   260: aload #15
    //   262: aload_2
    //   263: invokevirtual register : (Ljava/util/concurrent/Executor;)V
    //   266: new java/util/concurrent/FutureTask
    //   269: dup
    //   270: new androidx/core/location/LocationManagerCompat$1
    //   273: dup
    //   274: aload_0
    //   275: aload #15
    //   277: invokespecial <init> : (Landroid/location/LocationManager;Landroidx/core/location/LocationManagerCompat$GpsStatusTransport;)V
    //   280: invokespecial <init> : (Ljava/util/concurrent/Callable;)V
    //   283: astore_0
    //   284: invokestatic myLooper : ()Landroid/os/Looper;
    //   287: aload_1
    //   288: invokevirtual getLooper : ()Landroid/os/Looper;
    //   291: if_acmpne -> 301
    //   294: aload_0
    //   295: invokevirtual run : ()V
    //   298: goto -> 313
    //   301: aload_1
    //   302: aload_0
    //   303: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   306: istore #8
    //   308: iload #8
    //   310: ifeq -> 593
    //   313: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   316: ldc2_w 4
    //   319: invokevirtual toNanos : (J)J
    //   322: lstore #11
    //   324: invokestatic nanoTime : ()J
    //   327: lstore #13
    //   329: iconst_0
    //   330: istore #4
    //   332: lload #11
    //   334: lstore #9
    //   336: aload_0
    //   337: lload #9
    //   339: getstatic java/util/concurrent/TimeUnit.NANOSECONDS : Ljava/util/concurrent/TimeUnit;
    //   342: invokevirtual get : (JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    //   345: checkcast java/lang/Boolean
    //   348: invokevirtual booleanValue : ()Z
    //   351: ifeq -> 380
    //   354: getstatic androidx/core/location/LocationManagerCompat.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   357: aload_3
    //   358: aload #15
    //   360: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   363: pop
    //   364: iload #4
    //   366: ifeq -> 375
    //   369: invokestatic currentThread : ()Ljava/lang/Thread;
    //   372: invokevirtual interrupt : ()V
    //   375: aload #16
    //   377: monitorexit
    //   378: iconst_1
    //   379: ireturn
    //   380: iload #4
    //   382: ifeq -> 391
    //   385: invokestatic currentThread : ()Ljava/lang/Thread;
    //   388: invokevirtual interrupt : ()V
    //   391: aload #16
    //   393: monitorexit
    //   394: iconst_0
    //   395: ireturn
    //   396: astore_0
    //   397: goto -> 580
    //   400: astore_0
    //   401: iload #4
    //   403: istore #5
    //   405: goto -> 464
    //   408: astore_0
    //   409: iload #4
    //   411: istore #5
    //   413: goto -> 514
    //   416: iload #7
    //   418: istore #4
    //   420: invokestatic nanoTime : ()J
    //   423: lstore #9
    //   425: lload #13
    //   427: lload #11
    //   429: ladd
    //   430: lload #9
    //   432: lsub
    //   433: lstore #9
    //   435: iconst_1
    //   436: istore #4
    //   438: goto -> 336
    //   441: astore_0
    //   442: goto -> 464
    //   445: astore_0
    //   446: iload #6
    //   448: istore #5
    //   450: goto -> 514
    //   453: astore_0
    //   454: iconst_0
    //   455: istore #4
    //   457: goto -> 580
    //   460: astore_0
    //   461: iconst_0
    //   462: istore #5
    //   464: iload #5
    //   466: istore #4
    //   468: new java/lang/StringBuilder
    //   471: dup
    //   472: invokespecial <init> : ()V
    //   475: astore_2
    //   476: iload #5
    //   478: istore #4
    //   480: aload_2
    //   481: aload_1
    //   482: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   485: pop
    //   486: iload #5
    //   488: istore #4
    //   490: aload_2
    //   491: ldc ' appears to be blocked, please run registerGnssStatusCallback() directly on a Looper thread or ensure the main Looper is not blocked by this thread'
    //   493: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   496: pop
    //   497: iload #5
    //   499: istore #4
    //   501: new java/lang/IllegalStateException
    //   504: dup
    //   505: aload_2
    //   506: invokevirtual toString : ()Ljava/lang/String;
    //   509: aload_0
    //   510: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   513: athrow
    //   514: iload #5
    //   516: istore #4
    //   518: aload_0
    //   519: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   522: instanceof java/lang/RuntimeException
    //   525: ifne -> 567
    //   528: iload #5
    //   530: istore #4
    //   532: aload_0
    //   533: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   536: instanceof java/lang/Error
    //   539: ifeq -> 554
    //   542: iload #5
    //   544: istore #4
    //   546: aload_0
    //   547: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   550: checkcast java/lang/Error
    //   553: athrow
    //   554: iload #5
    //   556: istore #4
    //   558: new java/lang/IllegalStateException
    //   561: dup
    //   562: aload_0
    //   563: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   566: athrow
    //   567: iload #5
    //   569: istore #4
    //   571: aload_0
    //   572: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   575: checkcast java/lang/RuntimeException
    //   578: athrow
    //   579: astore_0
    //   580: iload #4
    //   582: ifeq -> 591
    //   585: invokestatic currentThread : ()Ljava/lang/Thread;
    //   588: invokevirtual interrupt : ()V
    //   591: aload_0
    //   592: athrow
    //   593: new java/lang/StringBuilder
    //   596: dup
    //   597: invokespecial <init> : ()V
    //   600: astore_0
    //   601: aload_0
    //   602: aload_1
    //   603: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   606: pop
    //   607: aload_0
    //   608: ldc_w ' is shutting down'
    //   611: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   614: pop
    //   615: new java/lang/IllegalStateException
    //   618: dup
    //   619: aload_0
    //   620: invokevirtual toString : ()Ljava/lang/String;
    //   623: invokespecial <init> : (Ljava/lang/String;)V
    //   626: athrow
    //   627: astore_0
    //   628: aload #16
    //   630: monitorexit
    //   631: aload_0
    //   632: athrow
    //   633: astore_2
    //   634: goto -> 416
    //   637: astore_0
    //   638: iconst_0
    //   639: istore #5
    //   641: goto -> 514
    // Exception table:
    //   from	to	target	type
    //   29	40	84	finally
    //   48	57	84	finally
    //   57	77	84	finally
    //   79	82	84	finally
    //   85	88	84	finally
    //   124	135	193	finally
    //   140	150	193	finally
    //   153	158	193	finally
    //   158	186	193	finally
    //   188	191	193	finally
    //   194	197	193	finally
    //   225	236	627	finally
    //   241	252	627	finally
    //   255	260	627	finally
    //   260	298	627	finally
    //   301	308	627	finally
    //   313	329	637	java/util/concurrent/ExecutionException
    //   313	329	460	java/util/concurrent/TimeoutException
    //   313	329	453	finally
    //   336	364	633	java/lang/InterruptedException
    //   336	364	408	java/util/concurrent/ExecutionException
    //   336	364	400	java/util/concurrent/TimeoutException
    //   336	364	396	finally
    //   369	375	627	finally
    //   375	378	627	finally
    //   385	391	627	finally
    //   391	394	627	finally
    //   420	425	445	java/util/concurrent/ExecutionException
    //   420	425	441	java/util/concurrent/TimeoutException
    //   420	425	579	finally
    //   468	476	579	finally
    //   480	486	579	finally
    //   490	497	579	finally
    //   501	514	579	finally
    //   518	528	579	finally
    //   532	542	579	finally
    //   546	554	579	finally
    //   558	567	579	finally
    //   571	579	579	finally
    //   585	591	627	finally
    //   591	593	627	finally
    //   593	627	627	finally
    //   628	631	627	finally
  }
  
  public static boolean registerGnssStatusCallback(LocationManager paramLocationManager, GnssStatusCompat.Callback paramCallback, Handler paramHandler) {
    return (Build.VERSION.SDK_INT >= 30) ? registerGnssStatusCallback(paramLocationManager, ExecutorCompat.create(paramHandler), paramCallback) : registerGnssStatusCallback(paramLocationManager, new InlineHandlerExecutor(paramHandler), paramCallback);
  }
  
  public static boolean registerGnssStatusCallback(LocationManager paramLocationManager, Executor paramExecutor, GnssStatusCompat.Callback paramCallback) {
    if (Build.VERSION.SDK_INT >= 30)
      return registerGnssStatusCallback(paramLocationManager, null, paramExecutor, paramCallback); 
    Looper looper2 = Looper.myLooper();
    Looper looper1 = looper2;
    if (looper2 == null)
      looper1 = Looper.getMainLooper(); 
    return registerGnssStatusCallback(paramLocationManager, new Handler(looper1), paramExecutor, paramCallback);
  }
  
  public static void unregisterGnssStatusCallback(LocationManager paramLocationManager, GnssStatusCompat.Callback paramCallback) {
    GnssStatusTransport gnssStatusTransport;
    PreRGnssStatusTransport preRGnssStatusTransport;
    if (Build.VERSION.SDK_INT >= 30)
      synchronized (sGnssStatusListeners) {
        gnssStatusTransport = (GnssStatusTransport)null.remove(paramCallback);
        if (gnssStatusTransport != null)
          paramLocationManager.unregisterGnssStatusCallback(gnssStatusTransport); 
        return;
      }  
    if (Build.VERSION.SDK_INT >= 24)
      synchronized (sGnssStatusListeners) {
        preRGnssStatusTransport = (PreRGnssStatusTransport)null.remove(gnssStatusTransport);
        if (preRGnssStatusTransport != null) {
          preRGnssStatusTransport.unregister();
          paramLocationManager.unregisterGnssStatusCallback(preRGnssStatusTransport);
        } 
        return;
      }  
    synchronized (sGnssStatusListeners) {
      GpsStatusTransport gpsStatusTransport = (GpsStatusTransport)null.remove(preRGnssStatusTransport);
      if (gpsStatusTransport != null) {
        gpsStatusTransport.unregister();
        paramLocationManager.removeGpsStatusListener(gpsStatusTransport);
      } 
      return;
    } 
  }
  
  private static class Api28Impl {
    public static boolean isLocationEnabled(LocationManager param1LocationManager) {
      return param1LocationManager.isLocationEnabled();
    }
  }
  
  private static class GnssStatusTransport extends GnssStatus.Callback {
    final GnssStatusCompat.Callback mCallback;
    
    GnssStatusTransport(GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mCallback = param1Callback;
    }
    
    public void onFirstFix(int param1Int) {
      this.mCallback.onFirstFix(param1Int);
    }
    
    public void onSatelliteStatusChanged(GnssStatus param1GnssStatus) {
      this.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(param1GnssStatus));
    }
    
    public void onStarted() {
      this.mCallback.onStarted();
    }
    
    public void onStopped() {
      this.mCallback.onStopped();
    }
  }
  
  private static class GpsStatusTransport implements GpsStatus.Listener {
    final GnssStatusCompat.Callback mCallback;
    
    volatile Executor mExecutor;
    
    private final LocationManager mLocationManager;
    
    GpsStatusTransport(LocationManager param1LocationManager, GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mLocationManager = param1LocationManager;
      this.mCallback = param1Callback;
    }
    
    public void onGpsStatusChanged(int param1Int) {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 3) {
            if (param1Int != 4)
              return; 
            GpsStatus gpsStatus = this.mLocationManager.getGpsStatus(null);
            if (gpsStatus != null) {
              executor.execute(new Runnable() {
                    public void run() {
                      if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                        return; 
                      LocationManagerCompat.GpsStatusTransport.this.mCallback.onSatelliteStatusChanged(gnssStatus);
                    }
                  });
              return;
            } 
          } else {
            GpsStatus gpsStatus = this.mLocationManager.getGpsStatus(null);
            if (gpsStatus != null) {
              executor.execute(new Runnable() {
                    public void run() {
                      if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                        return; 
                      LocationManagerCompat.GpsStatusTransport.this.mCallback.onFirstFix(ttff);
                    }
                  });
              return;
            } 
          } 
        } else {
          executor.execute(new Runnable() {
                public void run() {
                  if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                    return; 
                  LocationManagerCompat.GpsStatusTransport.this.mCallback.onStopped();
                }
              });
          return;
        } 
      } else {
        executor.execute(new Runnable() {
              public void run() {
                if (LocationManagerCompat.GpsStatusTransport.this.mExecutor != executor)
                  return; 
                LocationManagerCompat.GpsStatusTransport.this.mCallback.onStarted();
              }
            });
      } 
    }
    
    public void register(Executor param1Executor) {
      boolean bool;
      if (this.mExecutor == null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkState(bool);
      this.mExecutor = param1Executor;
    }
    
    public void unregister() {
      this.mExecutor = null;
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStarted();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStopped();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onFirstFix(ttff);
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onSatelliteStatusChanged(gnssStatus);
    }
  }
  
  private static class InlineHandlerExecutor implements Executor {
    private final Handler mHandler;
    
    InlineHandlerExecutor(Handler param1Handler) {
      this.mHandler = (Handler)Preconditions.checkNotNull(param1Handler);
    }
    
    public void execute(Runnable param1Runnable) {
      if (Looper.myLooper() == this.mHandler.getLooper()) {
        param1Runnable.run();
        return;
      } 
      if (this.mHandler.post((Runnable)Preconditions.checkNotNull(param1Runnable)))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.mHandler);
      stringBuilder.append(" is shutting down");
      throw new RejectedExecutionException(stringBuilder.toString());
    }
  }
  
  private static class PreRGnssStatusTransport extends GnssStatus.Callback {
    final GnssStatusCompat.Callback mCallback;
    
    volatile Executor mExecutor;
    
    PreRGnssStatusTransport(GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mCallback = param1Callback;
    }
    
    public void onFirstFix(final int ttffMillis) {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onFirstFix(ttffMillis);
            }
          });
    }
    
    public void onSatelliteStatusChanged(final GnssStatus status) {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(status));
            }
          });
    }
    
    public void onStarted() {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onStarted();
            }
          });
    }
    
    public void onStopped() {
      final Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new Runnable() {
            public void run() {
              if (LocationManagerCompat.PreRGnssStatusTransport.this.mExecutor != executor)
                return; 
              LocationManagerCompat.PreRGnssStatusTransport.this.mCallback.onStopped();
            }
          });
    }
    
    public void register(Executor param1Executor) {
      boolean bool1;
      boolean bool2 = true;
      if (param1Executor != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      Preconditions.checkArgument(bool1, "invalid null executor");
      if (this.mExecutor == null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      Preconditions.checkState(bool1);
      this.mExecutor = param1Executor;
    }
    
    public void unregister() {
      this.mExecutor = null;
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStarted();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onStopped();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onFirstFix(ttffMillis);
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$0.mExecutor != executor)
        return; 
      this.this$0.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(status));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket-dex2jar.jar!\androidx\core\location\LocationManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */