package androidx.core.provider;

import android.graphics.Typeface;
import android.os.Handler;

class CallbackWithHandler {
  private final FontsContractCompat.FontRequestCallback mCallback;
  
  private final Handler mCallbackHandler;
  
  CallbackWithHandler(FontsContractCompat.FontRequestCallback paramFontRequestCallback) {
    this.mCallback = paramFontRequestCallback;
    this.mCallbackHandler = CalleeHandler.create();
  }
  
  CallbackWithHandler(FontsContractCompat.FontRequestCallback paramFontRequestCallback, Handler paramHandler) {
    this.mCallback = paramFontRequestCallback;
    this.mCallbackHandler = paramHandler;
  }
  
  private void onTypefaceRequestFailed(final int reason) {
    final FontsContractCompat.FontRequestCallback callback = this.mCallback;
    this.mCallbackHandler.post(new Runnable() {
          public void run() {
            callback.onTypefaceRequestFailed(reason);
          }
        });
  }
  
  private void onTypefaceRetrieved(final Typeface typeface) {
    final FontsContractCompat.FontRequestCallback callback = this.mCallback;
    this.mCallbackHandler.post(new Runnable() {
          public void run() {
            callback.onTypefaceRetrieved(typeface);
          }
        });
  }
  
  void onTypefaceResult(FontRequestWorker.TypefaceResult paramTypefaceResult) {
    if (paramTypefaceResult.isSuccess()) {
      onTypefaceRetrieved(paramTypefaceResult.mTypeface);
      return;
    } 
    onTypefaceRequestFailed(paramTypefaceResult.mResult);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket-dex2jar.jar!\androidx\core\provider\CallbackWithHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */