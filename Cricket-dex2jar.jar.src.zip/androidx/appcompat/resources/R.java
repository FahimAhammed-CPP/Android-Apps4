package androidx.appcompat.resources;

public final class R {
  public static final class attr {
    public static final int alpha = 2130903085;
    
    public static final int font = 2130903403;
    
    public static final int fontProviderAuthority = 2130903405;
    
    public static final int fontProviderCerts = 2130903406;
    
    public static final int fontProviderFetchStrategy = 2130903407;
    
    public static final int fontProviderFetchTimeout = 2130903408;
    
    public static final int fontProviderPackage = 2130903409;
    
    public static final int fontProviderQuery = 2130903410;
    
    public static final int fontStyle = 2130903412;
    
    public static final int fontVariationSettings = 2130903413;
    
    public static final int fontWeight = 2130903414;
    
    public static final int ttcIndex = 2130903921;
  }
  
  public static final class color {
    public static final int notification_action_color_filter = 2131034296;
    
    public static final int notification_icon_bg_color = 2131034297;
    
    public static final int ripple_material_light = 2131034311;
    
    public static final int secondary_text_default_material_light = 2131034313;
  }
  
  public static final class dimen {
    public static final int compat_button_inset_horizontal_material = 2131099739;
    
    public static final int compat_button_inset_vertical_material = 2131099740;
    
    public static final int compat_button_padding_horizontal_material = 2131099741;
    
    public static final int compat_button_padding_vertical_material = 2131099742;
    
    public static final int compat_control_corner_material = 2131099743;
    
    public static final int compat_notification_large_icon_max_height = 2131099744;
    
    public static final int compat_notification_large_icon_max_width = 2131099745;
    
    public static final int notification_action_icon_size = 2131100039;
    
    public static final int notification_action_text_size = 2131100040;
    
    public static final int notification_big_circle_margin = 2131100041;
    
    public static final int notification_content_margin_start = 2131100042;
    
    public static final int notification_large_icon_height = 2131100043;
    
    public static final int notification_large_icon_width = 2131100044;
    
    public static final int notification_main_column_padding_top = 2131100045;
    
    public static final int notification_media_narrow_margin = 2131100046;
    
    public static final int notification_right_icon_size = 2131100047;
    
    public static final int notification_right_side_padding_top = 2131100048;
    
    public static final int notification_small_icon_background_padding = 2131100049;
    
    public static final int notification_small_icon_size_as_large = 2131100050;
    
    public static final int notification_subtext_size = 2131100051;
    
    public static final int notification_top_pad = 2131100052;
    
    public static final int notification_top_pad_large_text = 2131100053;
  }
  
  public static final class drawable {
    public static final int abc_vector_test = 2131165269;
    
    public static final int notification_action_background = 2131165315;
    
    public static final int notification_bg = 2131165316;
    
    public static final int notification_bg_low = 2131165317;
    
    public static final int notification_bg_low_normal = 2131165318;
    
    public static final int notification_bg_low_pressed = 2131165319;
    
    public static final int notification_bg_normal = 2131165320;
    
    public static final int notification_bg_normal_pressed = 2131165321;
    
    public static final int notification_icon_background = 2131165322;
    
    public static final int notification_template_icon_bg = 2131165323;
    
    public static final int notification_template_icon_low_bg = 2131165324;
    
    public static final int notification_tile_bg = 2131165325;
    
    public static final int notify_panel_notification_icon_bg = 2131165326;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131230735;
    
    public static final int accessibility_custom_action_0 = 2131230736;
    
    public static final int accessibility_custom_action_1 = 2131230737;
    
    public static final int accessibility_custom_action_10 = 2131230738;
    
    public static final int accessibility_custom_action_11 = 2131230739;
    
    public static final int accessibility_custom_action_12 = 2131230740;
    
    public static final int accessibility_custom_action_13 = 2131230741;
    
    public static final int accessibility_custom_action_14 = 2131230742;
    
    public static final int accessibility_custom_action_15 = 2131230743;
    
    public static final int accessibility_custom_action_16 = 2131230744;
    
    public static final int accessibility_custom_action_17 = 2131230745;
    
    public static final int accessibility_custom_action_18 = 2131230746;
    
    public static final int accessibility_custom_action_19 = 2131230747;
    
    public static final int accessibility_custom_action_2 = 2131230748;
    
    public static final int accessibility_custom_action_20 = 2131230749;
    
    public static final int accessibility_custom_action_21 = 2131230750;
    
    public static final int accessibility_custom_action_22 = 2131230751;
    
    public static final int accessibility_custom_action_23 = 2131230752;
    
    public static final int accessibility_custom_action_24 = 2131230753;
    
    public static final int accessibility_custom_action_25 = 2131230754;
    
    public static final int accessibility_custom_action_26 = 2131230755;
    
    public static final int accessibility_custom_action_27 = 2131230756;
    
    public static final int accessibility_custom_action_28 = 2131230757;
    
    public static final int accessibility_custom_action_29 = 2131230758;
    
    public static final int accessibility_custom_action_3 = 2131230759;
    
    public static final int accessibility_custom_action_30 = 2131230760;
    
    public static final int accessibility_custom_action_31 = 2131230761;
    
    public static final int accessibility_custom_action_4 = 2131230762;
    
    public static final int accessibility_custom_action_5 = 2131230763;
    
    public static final int accessibility_custom_action_6 = 2131230764;
    
    public static final int accessibility_custom_action_7 = 2131230765;
    
    public static final int accessibility_custom_action_8 = 2131230766;
    
    public static final int accessibility_custom_action_9 = 2131230767;
    
    public static final int action_container = 2131230775;
    
    public static final int action_divider = 2131230777;
    
    public static final int action_image = 2131230778;
    
    public static final int action_text = 2131230784;
    
    public static final int actions = 2131230785;
    
    public static final int async = 2131230797;
    
    public static final int blocking = 2131230806;
    
    public static final int chronometer = 2131230828;
    
    public static final int dialog_button = 2131230857;
    
    public static final int forever = 2131230892;
    
    public static final int icon = 2131230907;
    
    public static final int icon_group = 2131230908;
    
    public static final int info = 2131230915;
    
    public static final int italic = 2131230918;
    
    public static final int line1 = 2131230926;
    
    public static final int line3 = 2131230927;
    
    public static final int normal = 2131230994;
    
    public static final int notification_background = 2131230995;
    
    public static final int notification_main_column = 2131230996;
    
    public static final int notification_main_column_container = 2131230997;
    
    public static final int right_icon = 2131231024;
    
    public static final int right_side = 2131231025;
    
    public static final int tag_accessibility_actions = 2131231084;
    
    public static final int tag_accessibility_clickable_spans = 2131231085;
    
    public static final int tag_accessibility_heading = 2131231086;
    
    public static final int tag_accessibility_pane_title = 2131231087;
    
    public static final int tag_screen_reader_focusable = 2131231091;
    
    public static final int tag_transition_group = 2131231093;
    
    public static final int tag_unhandled_key_event_manager = 2131231094;
    
    public static final int tag_unhandled_key_listeners = 2131231095;
    
    public static final int text = 2131231101;
    
    public static final int text2 = 2131231102;
    
    public static final int time = 2131231118;
    
    public static final int title = 2131231119;
  }
  
  public static final class integer {
    public static final int status_bar_notification_info_maxnum = 2131296284;
  }
  
  public static final class layout {
    public static final int custom_dialog = 2131427359;
    
    public static final int notification_action = 2131427418;
    
    public static final int notification_action_tombstone = 2131427419;
    
    public static final int notification_template_custom_big = 2131427420;
    
    public static final int notification_template_icon_group = 2131427421;
    
    public static final int notification_template_part_chronometer = 2131427422;
    
    public static final int notification_template_part_time = 2131427423;
  }
  
  public static final class string {
    public static final int status_bar_notification_info_overflow = 2131624064;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131689825;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131689826;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131689827;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131689828;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131689829;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131690062;
    
    public static final int Widget_Compat_NotificationActionText = 2131690063;
  }
  
  public static final class styleable {
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130903085 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] FontFamily = new int[] { 2130903405, 2130903406, 2130903407, 2130903408, 2130903409, 2130903410, 2130903411 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903403, 2130903412, 2130903413, 2130903414, 2130903921 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket-dex2jar.jar!\androidx\appcompat\resources\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */