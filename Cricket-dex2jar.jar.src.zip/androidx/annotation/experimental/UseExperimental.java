package androidx.annotation.experimental;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PACKAGE})
public @interface UseExperimental {
  Class<?> markerClass();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket-dex2jar.jar!\androidx\annotation\experimental\UseExperimental.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */