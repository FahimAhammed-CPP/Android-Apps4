package androidx.annotation.experimental;

public final class R {}


/* Location:              C:\soft\dex2jar-2.0\Cricket-dex2jar.jar!\androidx\annotation\experimental\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */