package b5;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class a {
  public static MessageDigest a(String paramString) {
    int i = 0;
    while (true) {
      if (i < 2) {
        try {
          MessageDigest messageDigest = MessageDigest.getInstance(paramString);
          if (messageDigest != null)
            return messageDigest; 
        } catch (NoSuchAlgorithmException noSuchAlgorithmException) {}
        i++;
        continue;
      } 
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */