package b5;

import java.util.HashSet;
import java.util.Set;

public final class c {
  public static <T> Set<T> a(int paramInt, boolean paramBoolean) {
    float f;
    char c1;
    if (true != paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.75F;
    } 
    if (true != paramBoolean) {
      c1 = 'Ā';
    } else {
      c1 = '';
    } 
    return (Set<T>)((paramInt <= c1) ? new s.c(paramInt) : new HashSet<T>(paramInt, f));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */