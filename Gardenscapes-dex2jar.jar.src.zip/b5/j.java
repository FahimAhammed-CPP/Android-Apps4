package b5;

import android.os.Build;

public final class j {
  public static boolean a() {
    return (Build.VERSION.SDK_INT >= 21);
  }
  
  public static boolean b() {
    return (Build.VERSION.SDK_INT >= 26);
  }
  
  public static boolean c() {
    return (Build.VERSION.SDK_INT >= 28);
  }
  
  public static boolean d() {
    return (Build.VERSION.SDK_INT >= 30);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b5\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */