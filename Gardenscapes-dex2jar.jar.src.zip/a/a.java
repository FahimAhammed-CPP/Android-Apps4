package a;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface a extends IInterface {
  public static abstract class a extends Binder implements a {
    public a() {
      attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      Bundle bundle;
      if (param1Int1 != 2) {
        if (param1Int1 != 3) {
          if (param1Int1 != 4) {
            if (param1Int1 != 5) {
              if (param1Int1 != 6) {
                if (param1Int1 != 1598968902)
                  return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
                param1Parcel2.writeString("android.support.customtabs.ICustomTabsCallback");
                return true;
              } 
              param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
              param1Parcel1.readInt();
              if (param1Parcel1.readInt() != 0)
                Uri uri = (Uri)Uri.CREATOR.createFromParcel(param1Parcel1); 
              param1Parcel1.readInt();
              if (param1Parcel1.readInt() != 0)
                bundle = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
              param1Parcel2.writeNoException();
              return true;
            } 
            bundle.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            bundle.readString();
            if (bundle.readInt() != 0)
              bundle = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle); 
            param1Parcel2.writeNoException();
            return true;
          } 
          bundle.enforceInterface("android.support.customtabs.ICustomTabsCallback");
          if (bundle.readInt() != 0)
            bundle = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle); 
          param1Parcel2.writeNoException();
          return true;
        } 
        bundle.enforceInterface("android.support.customtabs.ICustomTabsCallback");
        bundle.readString();
        if (bundle.readInt() != 0)
          bundle = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle); 
        param1Parcel2.writeNoException();
        return true;
      } 
      bundle.enforceInterface("android.support.customtabs.ICustomTabsCallback");
      bundle.readInt();
      if (bundle.readInt() != 0)
        bundle = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle); 
      param1Parcel2.writeNoException();
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */