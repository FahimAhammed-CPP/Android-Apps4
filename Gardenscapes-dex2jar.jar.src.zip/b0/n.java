package b0;

import android.app.Notification;
import java.util.ArrayList;
import java.util.Iterator;

public class n extends o {
  public ArrayList<CharSequence> e = new ArrayList<CharSequence>();
  
  public void b(i parami) {
    Notification.InboxStyle inboxStyle = (new Notification.InboxStyle(((p)parami).b)).setBigContentTitle(this.b);
    if (this.d)
      inboxStyle.setSummaryText(this.c); 
    Iterator<CharSequence> iterator = this.e.iterator();
    while (iterator.hasNext())
      inboxStyle.addLine(iterator.next()); 
  }
  
  public String c() {
    return "androidx.core.app.NotificationCompat$InboxStyle";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */