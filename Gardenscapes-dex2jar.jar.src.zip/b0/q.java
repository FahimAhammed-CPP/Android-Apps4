package b0;

import android.os.Bundle;
import android.util.SparseArray;
import java.util.List;
import java.util.Objects;

public class q {
  public static final Object a = new Object();
  
  public static SparseArray<Bundle> a(List<Bundle> paramList) {
    int j = paramList.size();
    SparseArray<Bundle> sparseArray = null;
    int i = 0;
    while (i < j) {
      Bundle bundle = paramList.get(i);
      SparseArray<Bundle> sparseArray1 = sparseArray;
      if (bundle != null) {
        sparseArray1 = sparseArray;
        if (sparseArray == null)
          sparseArray1 = new SparseArray(); 
        sparseArray1.put(i, bundle);
      } 
      i++;
      sparseArray = sparseArray1;
    } 
    return sparseArray;
  }
  
  public static Bundle[] b(t[] paramArrayOft) {
    if (paramArrayOft == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOft.length];
    for (int i = 0; i < paramArrayOft.length; i++) {
      t t1 = paramArrayOft[i];
      Bundle bundle = new Bundle();
      Objects.requireNonNull(t1);
      bundle.putString("resultKey", null);
      bundle.putCharSequence("label", null);
      bundle.putCharSequenceArray("choices", null);
      bundle.putBoolean("allowFreeFormInput", false);
      bundle.putBundle("extras", null);
      arrayOfBundle[i] = bundle;
    } 
    return arrayOfBundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */