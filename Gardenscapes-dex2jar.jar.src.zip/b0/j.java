package b0;

import android.app.PendingIntent;
import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;

public class j {
  public final Bundle a;
  
  public IconCompat b;
  
  public final t[] c;
  
  public final t[] d;
  
  public boolean e;
  
  public boolean f = true;
  
  public final int g;
  
  public final boolean h;
  
  @Deprecated
  public int i;
  
  public CharSequence j;
  
  public PendingIntent k;
  
  public j(IconCompat paramIconCompat, CharSequence paramCharSequence, PendingIntent paramPendingIntent, Bundle paramBundle, t[] paramArrayOft1, t[] paramArrayOft2, boolean paramBoolean1, int paramInt, boolean paramBoolean2, boolean paramBoolean3) {
    this.b = paramIconCompat;
    if (paramIconCompat != null && paramIconCompat.d() == 2)
      this.i = paramIconCompat.c(); 
    this.j = m.c(paramCharSequence);
    this.k = paramPendingIntent;
    if (paramBundle == null)
      paramBundle = new Bundle(); 
    this.a = paramBundle;
    this.c = paramArrayOft1;
    this.d = paramArrayOft2;
    this.e = paramBoolean1;
    this.g = paramInt;
    this.f = paramBoolean2;
    this.h = paramBoolean3;
  }
  
  public IconCompat a() {
    if (this.b == null) {
      int i = this.i;
      if (i != 0)
        this.b = IconCompat.b(null, "", i); 
    } 
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */