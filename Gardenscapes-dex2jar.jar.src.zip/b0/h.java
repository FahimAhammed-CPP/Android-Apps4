package b0;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

public final class h {
  public static Intent a(Activity paramActivity) {
    Intent intent = paramActivity.getParentActivityIntent();
    if (intent != null)
      return intent; 
    try {
      String str = c((Context)paramActivity, paramActivity.getComponentName());
      if (str == null)
        return null; 
      ComponentName componentName = new ComponentName((Context)paramActivity, str);
      try {
        return (c((Context)paramActivity, componentName) == null) ? Intent.makeMainActivity(componentName) : (new Intent()).setComponent(componentName);
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getParentActivityIntent: bad parentActivityName '");
      stringBuilder.append(str);
      stringBuilder.append("' in manifest");
      Log.e("NavUtils", stringBuilder.toString());
      return null;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new IllegalArgumentException(nameNotFoundException);
    } 
  }
  
  public static Intent b(Context paramContext, ComponentName paramComponentName) {
    String str = c(paramContext, paramComponentName);
    if (str == null)
      return null; 
    paramComponentName = new ComponentName(paramComponentName.getPackageName(), str);
    return (c(paramContext, paramComponentName) == null) ? Intent.makeMainActivity(paramComponentName) : (new Intent()).setComponent(paramComponentName);
  }
  
  public static String c(Context paramContext, ComponentName paramComponentName) {
    PackageManager packageManager = paramContext.getPackageManager();
    int j = Build.VERSION.SDK_INT;
    int i = 640;
    if (j >= 29) {
      i = 269222528;
    } else if (j >= 24) {
      i = 787072;
    } 
    ActivityInfo activityInfo = packageManager.getActivityInfo(paramComponentName, i);
    String str2 = activityInfo.parentActivityName;
    if (str2 != null)
      return str2; 
    Bundle bundle = activityInfo.metaData;
    if (bundle == null)
      return null; 
    str2 = bundle.getString("android.support.PARENT_ACTIVITY");
    if (str2 == null)
      return null; 
    String str1 = str2;
    if (str2.charAt(0) == '.') {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramContext.getPackageName());
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } 
    return str1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */