package b0;

import android.app.AppOpsManager;
import android.content.Context;
import android.os.Build;

public final class f {
  public static int a(Context paramContext, String paramString1, String paramString2) {
    return (Build.VERSION.SDK_INT >= 23) ? ((AppOpsManager)paramContext.getSystemService(AppOpsManager.class)).noteProxyOpNoThrow(paramString1, paramString2) : 1;
  }
  
  public static class a {
    public static int a(AppOpsManager param1AppOpsManager, String param1String1, int param1Int, String param1String2) {
      return (param1AppOpsManager == null) ? 1 : param1AppOpsManager.checkOpNoThrow(param1String1, param1Int, param1String2);
    }
    
    public static String b(Context param1Context) {
      return param1Context.getOpPackageName();
    }
    
    public static AppOpsManager c(Context param1Context) {
      return (AppOpsManager)param1Context.getSystemService(AppOpsManager.class);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */