package b0;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.s;
import m0.e;
import s.h;

public class g extends Activity implements j, e.a {
  private h<Class<? extends a>, a> mExtraDataMap = new h();
  
  private k mLifecycleRegistry = new k(this);
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && e.a(view, paramKeyEvent)) ? true : e.b(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && e.a(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  @Deprecated
  public <T extends a> T getExtraData(Class<T> paramClass) {
    return (T)this.mExtraDataMap.getOrDefault(paramClass, null);
  }
  
  public Lifecycle getLifecycle() {
    throw null;
  }
  
  @SuppressLint({"RestrictedApi"})
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    s.c(this);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    k k1 = this.mLifecycleRegistry;
    Lifecycle.State state = Lifecycle.State.h;
    k1.d("markState");
    k1.d("setCurrentState");
    k1.g(state);
    super.onSaveInstanceState(paramBundle);
  }
  
  @Deprecated
  public void putExtraData(a parama) {
    this.mExtraDataMap.put(parama.getClass(), parama);
  }
  
  public boolean superDispatchKeyEvent(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  @Deprecated
  public static class a {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */