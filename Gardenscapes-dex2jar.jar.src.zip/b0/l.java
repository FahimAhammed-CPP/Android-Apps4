package b0;

import android.app.Notification;
import android.os.Build;
import android.os.Bundle;

public class l extends o {
  public CharSequence e;
  
  public void a(Bundle paramBundle) {
    super.a(paramBundle);
    if (Build.VERSION.SDK_INT < 21)
      paramBundle.putCharSequence("android.bigText", this.e); 
  }
  
  public void b(i parami) {
    Notification.BigTextStyle bigTextStyle = (new Notification.BigTextStyle(((p)parami).b)).setBigContentTitle(this.b).bigText(this.e);
    if (this.d)
      bigTextStyle.setSummaryText(this.c); 
  }
  
  public String c() {
    return "androidx.core.app.NotificationCompat$BigTextStyle";
  }
  
  public l d(CharSequence paramCharSequence) {
    this.e = m.c(paramCharSequence);
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b0\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */