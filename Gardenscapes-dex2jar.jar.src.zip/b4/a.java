package b4;

import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.ads.initialization.AdapterStatus;
import java.util.Map;

public interface a {
  @RecentlyNonNull
  Map<String, AdapterStatus> d();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */