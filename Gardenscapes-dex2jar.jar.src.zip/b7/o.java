package b7;

import com.google.android.material.textfield.TextInputLayout;

public class o extends k {
  public o(TextInputLayout paramTextInputLayout) {
    super(paramTextInputLayout, 0);
  }
  
  public void a() {
    this.a.setEndIconOnClickListener(null);
    this.a.setEndIconDrawable(null);
    this.a.setEndIconContentDescription(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */