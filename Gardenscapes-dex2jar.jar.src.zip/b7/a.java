package b7;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

public class a extends AnimatorListenerAdapter {
  public a(com.google.android.material.textfield.a parama) {}
  
  public void onAnimationStart(Animator paramAnimator) {
    ((k)this.a).a.setEndIconVisible(true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */