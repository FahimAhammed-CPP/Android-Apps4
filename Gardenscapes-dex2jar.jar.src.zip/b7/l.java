package b7;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import m0.y;
import u2.t;
import v6.c;

public final class l {
  public final Context a;
  
  public final TextInputLayout b;
  
  public LinearLayout c;
  
  public int d;
  
  public FrameLayout e;
  
  public Animator f;
  
  public final float g;
  
  public int h;
  
  public int i;
  
  public CharSequence j;
  
  public boolean k;
  
  public TextView l;
  
  public CharSequence m;
  
  public int n;
  
  public ColorStateList o;
  
  public CharSequence p;
  
  public boolean q;
  
  public TextView r;
  
  public int s;
  
  public ColorStateList t;
  
  public Typeface u;
  
  public l(TextInputLayout paramTextInputLayout) {
    Context context = paramTextInputLayout.getContext();
    this.a = context;
    this.b = paramTextInputLayout;
    this.g = context.getResources().getDimensionPixelSize(2131099809);
  }
  
  public void a(TextView paramTextView, int paramInt) {
    if (this.c == null && this.e == null) {
      LinearLayout linearLayout = new LinearLayout(this.a);
      this.c = linearLayout;
      linearLayout.setOrientation(0);
      this.b.addView((View)this.c, -1, -2);
      this.e = new FrameLayout(this.a);
      LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0F);
      this.c.addView((View)this.e, (ViewGroup.LayoutParams)layoutParams);
      if (this.b.getEditText() != null)
        b(); 
    } 
    if (paramInt == 0 || paramInt == 1) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (paramInt != 0) {
      this.e.setVisibility(0);
      this.e.addView((View)paramTextView);
    } else {
      LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
      this.c.addView((View)paramTextView, (ViewGroup.LayoutParams)layoutParams);
    } 
    this.c.setVisibility(0);
    this.d++;
  }
  
  public void b() {
    boolean bool;
    if (this.c != null && this.b.getEditText() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      EditText editText = this.b.getEditText();
      boolean bool1 = c.d(this.a);
      LinearLayout linearLayout = this.c;
      WeakHashMap weakHashMap = y.a;
      y.e.k((View)linearLayout, h(bool1, 2131100007, y.e.f((View)editText)), h(bool1, 2131100008, this.a.getResources().getDimensionPixelSize(2131100006)), h(bool1, 2131100007, y.e.e((View)editText)), 0);
    } 
  }
  
  public void c() {
    Animator animator = this.f;
    if (animator != null)
      animator.cancel(); 
  }
  
  public final void d(List<Animator> paramList, boolean paramBoolean, TextView paramTextView, int paramInt1, int paramInt2, int paramInt3) {
    if (paramTextView != null) {
      if (!paramBoolean)
        return; 
      if (paramInt1 == paramInt3 || paramInt1 == paramInt2) {
        float f;
        if (paramInt3 == paramInt1) {
          paramInt2 = 1;
        } else {
          paramInt2 = 0;
        } 
        if (paramInt2 != 0) {
          f = 1.0F;
        } else {
          f = 0.0F;
        } 
        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(paramTextView, View.ALPHA, new float[] { f });
        objectAnimator.setDuration(167L);
        objectAnimator.setInterpolator(c6.a.a);
        paramList.add(objectAnimator);
        if (paramInt3 == paramInt1) {
          ObjectAnimator objectAnimator1 = ObjectAnimator.ofFloat(paramTextView, View.TRANSLATION_Y, new float[] { -this.g, 0.0F });
          objectAnimator1.setDuration(217L);
          objectAnimator1.setInterpolator(c6.a.d);
          paramList.add(objectAnimator1);
        } 
      } 
    } 
  }
  
  public boolean e() {
    return (this.i == 1 && this.l != null && !TextUtils.isEmpty(this.j));
  }
  
  public final TextView f(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? null : this.r) : this.l;
  }
  
  public int g() {
    TextView textView = this.l;
    return (textView != null) ? textView.getCurrentTextColor() : -1;
  }
  
  public final int h(boolean paramBoolean, int paramInt1, int paramInt2) {
    if (paramBoolean)
      paramInt2 = this.a.getResources().getDimensionPixelSize(paramInt1); 
    return paramInt2;
  }
  
  public void i() {
    this.j = null;
    c();
    if (this.h == 1)
      if (this.q && !TextUtils.isEmpty(this.p)) {
        this.i = 2;
      } else {
        this.i = 0;
      }  
    l(this.h, this.i, k(this.l, null));
  }
  
  public void j(TextView paramTextView, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroid/widget/LinearLayout;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnonnull -> 10
    //   9: return
    //   10: iload_2
    //   11: ifeq -> 27
    //   14: iload_2
    //   15: iconst_1
    //   16: if_icmpne -> 22
    //   19: goto -> 27
    //   22: iconst_0
    //   23: istore_2
    //   24: goto -> 29
    //   27: iconst_1
    //   28: istore_2
    //   29: iload_2
    //   30: ifeq -> 53
    //   33: aload_0
    //   34: getfield e : Landroid/widget/FrameLayout;
    //   37: astore #4
    //   39: aload #4
    //   41: ifnull -> 53
    //   44: aload #4
    //   46: aload_1
    //   47: invokevirtual removeView : (Landroid/view/View;)V
    //   50: goto -> 58
    //   53: aload_3
    //   54: aload_1
    //   55: invokevirtual removeView : (Landroid/view/View;)V
    //   58: aload_0
    //   59: getfield d : I
    //   62: iconst_1
    //   63: isub
    //   64: istore_2
    //   65: aload_0
    //   66: iload_2
    //   67: putfield d : I
    //   70: aload_0
    //   71: getfield c : Landroid/widget/LinearLayout;
    //   74: astore_1
    //   75: iload_2
    //   76: ifne -> 85
    //   79: aload_1
    //   80: bipush #8
    //   82: invokevirtual setVisibility : (I)V
    //   85: return
  }
  
  public final boolean k(TextView paramTextView, CharSequence paramCharSequence) {
    TextInputLayout textInputLayout = this.b;
    WeakHashMap weakHashMap = y.a;
    return (y.g.c((View)textInputLayout) && this.b.isEnabled() && (this.i != this.h || paramTextView == null || !TextUtils.equals(paramTextView.getText(), paramCharSequence)));
  }
  
  public final void l(int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramInt1 == paramInt2)
      return; 
    if (paramBoolean) {
      AnimatorSet animatorSet = new AnimatorSet();
      this.f = (Animator)animatorSet;
      ArrayList<Animator> arrayList = new ArrayList();
      d(arrayList, this.q, this.r, 2, paramInt1, paramInt2);
      d(arrayList, this.k, this.l, 1, paramInt1, paramInt2);
      t.b(animatorSet, arrayList);
      animatorSet.addListener((Animator.AnimatorListener)new a(this, paramInt2, f(paramInt1), paramInt1, f(paramInt2)));
      animatorSet.start();
    } else if (paramInt1 != paramInt2) {
      if (paramInt2 != 0) {
        TextView textView = f(paramInt2);
        if (textView != null) {
          textView.setVisibility(0);
          textView.setAlpha(1.0F);
        } 
      } 
      if (paramInt1 != 0) {
        TextView textView = f(paramInt1);
        if (textView != null) {
          textView.setVisibility(4);
          if (paramInt1 == 1)
            textView.setText(null); 
        } 
      } 
      this.h = paramInt2;
    } 
    this.b.y();
    this.b.A(paramBoolean, false);
    this.b.H();
  }
  
  public class a extends AnimatorListenerAdapter {
    public a(l this$0, int param1Int1, TextView param1TextView1, int param1Int2, TextView param1TextView2) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      l l1 = this.e;
      l1.h = this.a;
      l1.f = null;
      TextView textView = this.b;
      if (textView != null) {
        textView.setVisibility(4);
        if (this.c == 1) {
          textView = this.e.l;
          if (textView != null)
            textView.setText(null); 
        } 
      } 
      textView = this.d;
      if (textView != null) {
        textView.setTranslationY(0.0F);
        this.d.setAlpha(1.0F);
      } 
    }
    
    public void onAnimationStart(Animator param1Animator) {
      TextView textView = this.d;
      if (textView != null)
        textView.setVisibility(0); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */