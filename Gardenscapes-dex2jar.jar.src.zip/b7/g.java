package b7;

import android.animation.ValueAnimator;
import com.google.android.material.textfield.b;

public class g implements ValueAnimator.AnimatorUpdateListener {
  public g(b paramb) {}
  
  public void onAnimationUpdate(ValueAnimator paramValueAnimator) {
    float f = ((Float)paramValueAnimator.getAnimatedValue()).floatValue();
    ((k)this.a).c.setAlpha(f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */