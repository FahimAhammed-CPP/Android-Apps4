package b7;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.google.android.material.textfield.a;

public class b extends AnimatorListenerAdapter {
  public b(a parama) {}
  
  public void onAnimationEnd(Animator paramAnimator) {
    ((k)this.a).a.setEndIconVisible(false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */