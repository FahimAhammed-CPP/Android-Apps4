package b7;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Xfermode;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import y6.f;
import y6.i;

public class f extends f {
  public final Paint E;
  
  public final RectF F;
  
  public int G;
  
  public f() {
    this(null);
  }
  
  public f(i parami) {
    super(parami);
    Paint paint = new Paint(1);
    this.E = paint;
    paint.setStyle(Paint.Style.FILL_AND_STROKE);
    paint.setColor(-1);
    paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
    this.F = new RectF();
  }
  
  public void draw(Canvas paramCanvas) {
    Drawable.Callback callback = getCallback();
    if (callback instanceof View) {
      View view = (View)callback;
      if (view.getLayerType() != 2)
        view.setLayerType(2, null); 
    } else if (Build.VERSION.SDK_INT >= 21) {
      this.G = paramCanvas.saveLayer(0.0F, 0.0F, paramCanvas.getWidth(), paramCanvas.getHeight(), null);
    } else {
      this.G = paramCanvas.saveLayer(0.0F, 0.0F, paramCanvas.getWidth(), paramCanvas.getHeight(), null, 31);
    } 
    super.draw(paramCanvas);
    if (!(getCallback() instanceof View))
      paramCanvas.restoreToCount(this.G); 
  }
  
  public void h(Canvas paramCanvas) {
    if (this.F.isEmpty()) {
      super.h(paramCanvas);
      return;
    } 
    Bitmap bitmap = Bitmap.createBitmap(paramCanvas.getWidth(), paramCanvas.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    super.h(canvas);
    canvas.drawRect(this.F, this.E);
    paramCanvas.drawBitmap(bitmap, 0.0F, 0.0F, null);
  }
  
  public void y(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    RectF rectF = this.F;
    if (paramFloat1 != rectF.left || paramFloat2 != rectF.top || paramFloat3 != rectF.right || paramFloat4 != rectF.bottom) {
      rectF.set(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
      invalidateSelf();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */