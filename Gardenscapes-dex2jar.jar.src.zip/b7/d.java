package b7;

import android.animation.ValueAnimator;
import com.google.android.material.textfield.a;

public class d implements ValueAnimator.AnimatorUpdateListener {
  public d(a parama) {}
  
  public void onAnimationUpdate(ValueAnimator paramValueAnimator) {
    float f = ((Float)paramValueAnimator.getAnimatedValue()).floatValue();
    ((k)this.a).c.setScaleX(f);
    ((k)this.a).c.setScaleY(f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b7\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */