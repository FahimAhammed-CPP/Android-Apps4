package c4;

import android.content.Context;
import android.view.View;
import com.google.android.gms.internal.ads.d1;
import com.google.android.gms.internal.ads.d5;
import com.google.android.gms.internal.ads.e5;
import com.google.android.gms.internal.ads.n1;
import com.google.android.gms.internal.ads.z4;
import com.google.android.gms.internal.ads.zzdul;
import e7.a1;
import e7.g0;
import e7.m;
import e7.r1;
import e7.s0;
import f1.d;
import h5.aj0;
import h5.bj;
import h5.cj0;
import h5.dk;
import h5.fj0;
import h5.g3;
import h5.ij0;
import h5.lo0;
import h5.m2;
import h5.mi;
import h5.mo0;
import h5.mu;
import h5.q2;
import h5.re1;
import h5.v8;
import h5.vt;
import h5.wt;
import h5.wx;
import h5.ya1;
import h5.yy;
import h7.b0;
import h7.c0;
import h7.z;
import java.io.File;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import k4.e;
import k4.f;
import org.json.JSONException;
import org.json.JSONObject;
import u2.t0;
import u2.w0;

public final class a implements d, c0 {
  public Object f;
  
  public final Object g;
  
  public Object h;
  
  public Object i;
  
  public Object j;
  
  public Object k;
  
  public a(dk paramdk, bj parambj, v8 paramv8, ya1 paramya1, v4.a parama, g3 paramg3) {
    this.h = paramdk;
    this.f = parambj;
    this.i = paramv8;
    this.g = paramya1;
    this.j = parama;
    this.k = paramg3;
  }
  
  public a(fj0 paramfj0, Object paramObject, String paramString, lo0 paramlo01, List paramList, lo0 paramlo02) {
    this.f = paramObject;
    this.g = paramString;
    this.h = paramlo01;
    this.i = paramList;
    this.j = paramlo02;
  }
  
  public a(wt paramwt, mu parammu, wx paramwx, n1 paramn1, d1 paramd1) {
    this.k = new AtomicBoolean(false);
    this.f = paramwt;
    this.g = parammu;
    this.h = paramwx;
    this.i = paramn1;
    this.j = paramd1;
  }
  
  public a(c0 paramc01, c0 paramc02, c0 paramc03, c0 paramc04, c0 paramc05, c0 paramc06) {
    this.f = paramc01;
    this.g = paramc02;
    this.h = paramc03;
    this.i = paramc04;
    this.j = paramc05;
    this.k = paramc06;
  }
  
  public static String a(a parama) {
    m2 m2 = q2.z5;
    String str2 = (String)re1.j.f.a(m2);
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.putOpt("objectId", parama.f);
      jSONObject.put("eventCategory", parama.g);
      jSONObject.putOpt("event", parama.h);
      jSONObject.putOpt("errorCode", parama.i);
      jSONObject.putOpt("rewardType", parama.j);
      jSONObject.putOpt("rewardAmount", parama.k);
    } catch (JSONException jSONException) {
      q.a.i("Could not convert parameters to JSON.");
    } 
    String str1 = jSONObject.toString();
    return d.a(new StringBuilder(String.valueOf(str2).length() + 16 + String.valueOf(str1).length()), str2, "(\"h5adsEvent\",", str1, ");");
  }
  
  public <O2> a b(aj0<O, O2> paramaj0) {
    return e((z4)new e(paramaj0), (Executor)((fj0)this.k).a);
  }
  
  public <O2> a d(z4<O, O2> paramz4) {
    return e(paramz4, (Executor)((fj0)this.k).a);
  }
  
  public <O2> a e(z4<O, O2> paramz4, Executor paramExecutor) {
    return new a((fj0)this.k, this.f, (String)this.g, (lo0)this.h, (List)this.i, e5.s((lo0)this.j, paramz4, paramExecutor));
  }
  
  public void f(View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield k : Ljava/lang/Object;
    //   6: checkcast java/util/concurrent/atomic/AtomicBoolean
    //   9: iconst_0
    //   10: iconst_1
    //   11: invokevirtual compareAndSet : (ZZ)Z
    //   14: istore_2
    //   15: iload_2
    //   16: ifne -> 22
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_0
    //   23: getfield j : Ljava/lang/Object;
    //   26: checkcast com/google/android/gms/internal/ads/d1
    //   29: invokevirtual g : ()V
    //   32: aload_0
    //   33: getfield i : Ljava/lang/Object;
    //   36: checkcast com/google/android/gms/internal/ads/n1
    //   39: aload_1
    //   40: invokevirtual M : (Landroid/view/View;)V
    //   43: aload_0
    //   44: monitorexit
    //   45: return
    //   46: astore_1
    //   47: aload_0
    //   48: monitorexit
    //   49: aload_1
    //   50: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	46	finally
    //   22	43	46	finally
  }
  
  public <O2> a g(lo0<O2> paramlo0) {
    return e((z4)new f(paramlo0), (Executor)mi.f);
  }
  
  public <T extends Throwable> a h(Class<T> paramClass, z4<T, O> paramz4) {
    fj0 fj0 = (fj0)this.k;
    return new a(fj0, this.f, (String)this.g, (lo0)this.h, (List)this.i, e5.q((lo0)this.j, paramClass, paramz4, (Executor)fj0.a));
  }
  
  public a i(long paramLong, TimeUnit paramTimeUnit) {
    fj0 fj0 = (fj0)this.k;
    return new a(fj0, this.f, (String)this.g, (lo0)this.h, (List)this.i, e5.r((lo0)this.j, paramLong, paramTimeUnit, fj0.b));
  }
  
  public cj0 j() {
    Object object = this.f;
    String str2 = (String)this.g;
    String str1 = str2;
    if (str2 == null) {
      Objects.requireNonNull((ij0)this.k);
      str1 = ((zzdul)object).b();
    } 
    cj0 cj0 = new cj0(object, str1, (lo0)this.j);
    ((fj0)this.k).c.G(cj0);
    lo0 lo0 = (lo0)this.h;
    object = new w0(this, cj0);
    mo0 mo0 = mi.f;
    lo0.b((Runnable)object, (Executor)mo0);
    cj0.b((Runnable)new t0((Future)cj0, (d5)new yy(this, cj0)), (Executor)mo0);
    return cj0;
  }
  
  public void zzb() {
    if (((AtomicBoolean)this.k).get())
      ((wt)this.f).L(vt.f); 
  }
  
  public void zzc() {
    if (((AtomicBoolean)this.k).get()) {
      ((mu)this.g).zza();
      ((wx)this.h).zza();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */