package c4;

import android.content.Context;
import h5.qx0;
import h5.uz;
import i8.d;
import v5.m4;
import v5.x3;
import v5.x4;

public final class e implements Runnable {
  public final boolean g;
  
  public final Object h;
  
  public e(f paramf, boolean paramBoolean) {}
  
  public e(uz paramuz, boolean paramBoolean) {
    this.h = paramuz;
    this.g = paramBoolean;
  }
  
  public e(x3 paramx3, boolean paramBoolean) {}
  
  public e(x4 paramx4, boolean paramBoolean) {}
  
  public final void run() {
    long l;
    uz uz;
    switch (this.f) {
      case 2:
        ((x3)this.h).a.t();
        return;
      case 1:
        uz = (uz)this.h;
        bool1 = this.g;
        uz.k.q(uz.t.x0(), uz.t.zzj(), uz.t.zzk(), bool1);
        return;
      case 0:
        l = System.currentTimeMillis();
        try {
          Object object = this.h;
          String str = ((f)object).p.f;
          object = ((f)object).n;
          Context context = object.getApplicationContext();
          if (context != null)
            object = context; 
          qx0.h(str, (Context)object, this.g).j();
          return;
        } catch (NullPointerException nullPointerException) {
          ((f)this.h).l.c(2027, System.currentTimeMillis() - l, nullPointerException);
          return;
        } 
    } 
    boolean bool1 = ((m4)((d)this.h).g).f();
    boolean bool2 = ((m4)((d)this.h).g).y();
    ((m4)((d)this.h).g).F = Boolean.valueOf(this.g);
    if (bool2 == this.g)
      (((m4)((d)this.h).g).a()).u.d("Default data collection state already set to", Boolean.valueOf(this.g)); 
    if (((m4)((d)this.h).g).f() == bool1 || ((m4)((d)this.h).g).f() != ((m4)((d)this.h).g).y())
      (((m4)((d)this.h).g).a()).r.e("Default data collection is different than actual status", Boolean.valueOf(this.g), Boolean.valueOf(bool1)); 
    ((x4)this.h).R();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */