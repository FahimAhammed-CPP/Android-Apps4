package c4;

import a0.a;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.webkit.WebView;
import com.google.android.gms.ads.internal.c;
import com.google.android.gms.internal.ads.zzfh;
import h5.j3;
import h5.n11;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import q.a;

public final class m extends AsyncTask<Void, Void, String> {
  public final Object doInBackground(Object[] paramArrayOfObject) {
    Void[] arrayOfVoid = (Void[])paramArrayOfObject;
    try {
      c c2 = this.a;
      c2.m = c2.h.get(1000L, TimeUnit.MILLISECONDS);
    } catch (InterruptedException interruptedException) {
      a.j("", interruptedException);
    } catch (ExecutionException executionException) {
    
    } catch (TimeoutException timeoutException) {
      a.j("", timeoutException);
    } 
    c c1 = this.a;
    Objects.requireNonNull(c1);
    Uri.Builder builder = new Uri.Builder();
    builder.scheme("https://").appendEncodedPath((String)j3.d.e());
    builder.appendQueryParameter("query", (String)c1.j.i);
    builder.appendQueryParameter("pubId", (String)c1.j.g);
    Map<String, String> map = c1.j.h;
    for (String str : map.keySet())
      builder.appendQueryParameter(str, map.get(str)); 
    Uri uri2 = builder.build();
    n11 n11 = c1.m;
    Uri uri1 = uri2;
    if (n11 != null)
      try {
        Context context = c1.i;
        Uri uri = n11.c(uri2, n11.b.c(context));
      } catch (zzfh zzfh) {
        a.j("Unable to process ad data", (Throwable)zzfh);
        uri1 = uri2;
      }  
    String str2 = c1.k4();
    String str1 = uri1.getEncodedQuery();
    return a.a(new StringBuilder(String.valueOf(str2).length() + 1 + String.valueOf(str1).length()), str2, "#", str1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */