package c4;

public interface i {
  void e();
  
  void g();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */