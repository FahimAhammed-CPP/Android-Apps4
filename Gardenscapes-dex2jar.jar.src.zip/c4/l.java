package c4;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.webkit.CookieManager;
import com.google.android.gms.ads.internal.c;
import h5.dn;
import h5.m11;
import h5.m2;
import h5.mc0;
import h5.n11;
import h5.q2;
import h5.re1;
import h5.sz0;
import h5.ze0;
import java.util.concurrent.Callable;
import org.json.JSONObject;
import u2.z;

public final class l implements Callable<n11> {
  public final Object g;
  
  public l(CookieManager paramCookieManager) {
    this.g = paramCookieManager;
  }
  
  public l(c paramc) {}
  
  public l(dn paramdn) {
    this.g = paramdn;
  }
  
  public l(mc0 parammc0) {
    this.g = parammc0;
  }
  
  public final Object call() {
    Context context;
    CookieManager cookieManager;
    PackageInfo packageInfo;
    m2 m2;
    switch (this.f) {
      default:
        context = (Context)((dn)this.g).a;
        packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        return z.c(context, context.getPackageName(), Integer.toString(packageInfo.versionCode));
      case 2:
        return new ze0(new JSONObject());
      case 1:
        cookieManager = (CookieManager)this.g;
        if (cookieManager == null)
          return ""; 
        m2 = q2.v0;
        return cookieManager.getCookie((String)re1.j.f.a(m2));
      case 0:
        break;
    } 
    c c = (c)this.g;
    return new n11((sz0)m11.r(c.f.f, c.i, false, 1));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */