package c4;

import android.app.Activity;
import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import com.google.android.gms.internal.ads.zzho;
import d5.a;
import h5.d31;
import h5.hi;
import h5.im0;
import h5.m11;
import h5.m2;
import h5.q2;
import h5.qx0;
import h5.re1;
import h5.rl0;
import h5.sz0;
import h5.ym0;
import java.io.File;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;
import q.a;
import q1.a;

public final class f implements Runnable, sz0 {
  public final List<Object[]> f = new Vector();
  
  public final AtomicReference<sz0> g = new AtomicReference<sz0>();
  
  public final AtomicReference<sz0> h = new AtomicReference<sz0>();
  
  public final boolean i;
  
  public final boolean j;
  
  public final Executor k;
  
  public final rl0 l;
  
  public Context m;
  
  public final Context n;
  
  public hi o;
  
  public final hi p;
  
  public final CountDownLatch q;
  
  public int r;
  
  public f(Context paramContext, hi paramhi) {
    boolean bool = true;
    this.q = new CountDownLatch(1);
    this.m = paramContext;
    this.n = paramContext;
    this.o = paramhi;
    this.p = paramhi;
    ExecutorService executorService = Executors.newCachedThreadPool();
    this.k = executorService;
    rl0 rl01 = rl0.a(paramContext, executorService);
    this.l = rl01;
    m2 m22 = q2.j1;
    null = re1.j;
    this.j = ((Boolean)null.f.a(m22)).booleanValue();
    m22 = q2.l1;
    if (((Boolean)null.f.a(m22)).booleanValue()) {
      this.r = 2;
    } else {
      this.r = 1;
    } 
    Context context2 = this.m;
    a a = new a(this);
    Context context1 = this.m;
    zzho zzho = a.g(context2, rl01);
    m2 m23 = q2.k1;
    ym0 ym0 = new ym0(context1, zzho, (im0)a, ((Boolean)null.f.a(m23)).booleanValue());
    long l = System.currentTimeMillis();
    synchronized (ym0.f) {
      d31 d31 = ym0.h(1);
      if (d31 == null) {
        ym0.g(4025, l);
      } else {
        File file = ym0.c(d31.v());
        if (!(new File(file, "pcam.jar")).exists()) {
          ym0.g(4026, l);
        } else if (!(new File(file, "pcbc")).exists()) {
          ym0.g(4027, l);
        } else {
          ym0.g(5019, l);
          this.i = bool;
          null = q2.z1;
        } 
      } 
    } 
    bool = false;
    this.i = bool;
    m2 m21 = q2.z1;
  }
  
  public static final Context j(Context paramContext) {
    Context context = paramContext.getApplicationContext();
    return (context == null) ? paramContext : context;
  }
  
  public final String a(Context paramContext, String paramString, View paramView) {
    return b(paramContext, paramString, paramView, null);
  }
  
  public final String b(Context paramContext, String paramString, View paramView, Activity paramActivity) {
    boolean bool;
    try {
      this.q.await();
      bool = true;
    } catch (InterruptedException interruptedException) {
      a.j("Interrupted during GADSignals creation.", interruptedException);
      bool = false;
    } 
    if (bool) {
      sz0 sz01 = i();
      if (sz01 != null) {
        h();
        Context context = paramContext.getApplicationContext();
        if (context != null)
          paramContext = context; 
        return sz01.b(paramContext, paramString, paramView, paramActivity);
      } 
    } 
    return "";
  }
  
  public final String c(Context paramContext) {
    boolean bool;
    try {
      this.q.await();
      bool = true;
    } catch (InterruptedException interruptedException) {
      a.j("Interrupted during GADSignals creation.", interruptedException);
      bool = false;
    } 
    if (bool) {
      sz0 sz01 = i();
      if (sz01 != null) {
        h();
        Context context = paramContext.getApplicationContext();
        if (context != null)
          paramContext = context; 
        return sz01.c(paramContext);
      } 
    } 
    return "";
  }
  
  public final void d(int paramInt1, int paramInt2, int paramInt3) {
    sz0 sz01 = i();
    if (sz01 != null) {
      h();
      sz01.d(paramInt1, paramInt2, paramInt3);
      return;
    } 
    this.f.add(new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) });
  }
  
  public final void e(View paramView) {
    sz0 sz01 = i();
    if (sz01 != null)
      sz01.e(paramView); 
  }
  
  public final String f(Context paramContext, View paramView, Activity paramActivity) {
    sz0 sz01 = i();
    return (sz01 != null) ? sz01.f(paramContext, paramView, null) : "";
  }
  
  public final void g(MotionEvent paramMotionEvent) {
    sz0 sz01 = i();
    if (sz01 != null) {
      h();
      sz01.g(paramMotionEvent);
      return;
    } 
    this.f.add(new Object[] { paramMotionEvent });
  }
  
  public final void h() {
    sz0 sz01 = i();
    if (!this.f.isEmpty()) {
      if (sz01 == null)
        return; 
      for (Object[] arrayOfObject : this.f) {
        int i = arrayOfObject.length;
        if (i == 1) {
          sz01.g((MotionEvent)arrayOfObject[0]);
          continue;
        } 
        if (i == 3)
          sz01.d(((Integer)arrayOfObject[0]).intValue(), ((Integer)arrayOfObject[1]).intValue(), ((Integer)arrayOfObject[2]).intValue()); 
      } 
      this.f.clear();
    } 
  }
  
  public final sz0 i() {
    int i;
    if (this.j && !this.i) {
      i = 1;
    } else {
      i = this.r;
    } 
    return (i == 2) ? this.h.get() : this.g.get();
  }
  
  public final void run() {
    try {
      int i;
      boolean bool3 = this.o.i;
      m2 m2 = q2.C0;
      boolean bool4 = ((Boolean)re1.j.f.a(m2)).booleanValue();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (!bool4) {
        bool1 = bool2;
        if (bool3)
          bool1 = true; 
      } 
      if (this.j && !this.i) {
        i = 1;
      } else {
        i = this.r;
      } 
      if (i == 1) {
        m11 m11 = m11.r(this.o.f, j(this.m), bool1, this.r);
        this.g.set(m11);
        if (this.r == 2)
          this.k.execute(new e(this, bool1)); 
      } else {
        long l = System.currentTimeMillis();
        try {
          qx0 qx0 = qx0.h(this.o.f, j(this.m), bool1);
          this.h.set(qx0);
        } catch (NullPointerException nullPointerException) {
          this.r = 1;
          m11 m11 = m11.r(this.o.f, j(this.m), bool1, this.r);
          this.g.set(m11);
          this.l.c(2031, System.currentTimeMillis() - l, nullPointerException);
        } 
      } 
      return;
    } finally {
      this.q.countDown();
      this.m = null;
      this.o = null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */