package c4;

import android.content.Intent;
import android.net.Uri;
import android.os.RemoteException;
import android.text.TextUtils;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.ads.internal.c;
import com.google.android.gms.internal.ads.zzfh;
import h5.bi;
import h5.g;
import h5.re1;
import java.util.Objects;
import q.a;
import w0.c;

public final class j extends WebViewClient {
  public j(c paramc) {}
  
  public final void onReceivedError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, WebResourceError paramWebResourceError) {
    g g = this.a.l;
    if (g != null)
      try {
        g.N(c.l(1, null, null));
      } catch (RemoteException remoteException) {
        a.l("#007 Could not call remote method.", (Throwable)remoteException);
      }  
    g = this.a.l;
    if (g != null)
      try {
        g.x(0);
        return;
      } catch (RemoteException remoteException) {
        a.l("#007 Could not call remote method.", (Throwable)remoteException);
      }  
  }
  
  public final boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString) {
    boolean bool = paramString.startsWith(this.a.k4());
    byte b = 0;
    if (bool)
      return false; 
    if (paramString.startsWith("gmsg://noAdLoaded")) {
      g g1 = this.a.l;
      if (g1 != null)
        try {
          g1.N(c.l(3, null, null));
        } catch (RemoteException remoteException) {
          a.l("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      g1 = this.a.l;
      if (g1 != null)
        try {
          g1.x(3);
        } catch (RemoteException remoteException) {
          a.l("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      this.a.j4(0);
      return true;
    } 
    if (paramString.startsWith("gmsg://scriptLoadFailed")) {
      g g1 = this.a.l;
      if (g1 != null)
        try {
          g1.N(c.l(1, null, null));
        } catch (RemoteException remoteException) {
          a.l("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      g1 = this.a.l;
      if (g1 != null)
        try {
          g1.x(0);
        } catch (RemoteException remoteException) {
          a.l("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      this.a.j4(0);
      return true;
    } 
    if (paramString.startsWith("gmsg://adResized")) {
      g g1 = this.a.l;
      if (g1 != null)
        try {
          g1.zzf();
        } catch (RemoteException remoteException) {
          a.l("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      c c3 = this.a;
      Objects.requireNonNull(c3);
      paramString = Uri.parse(paramString).getQueryParameter("height");
      int i = b;
      if (!TextUtils.isEmpty(paramString))
        try {
          bi bi = re1.j.a;
          i = bi.k(c3.i, Integer.parseInt(paramString));
        } catch (NumberFormatException numberFormatException) {
          i = b;
        }  
      this.a.j4(i);
      return true;
    } 
    if (paramString.startsWith("gmsg://"))
      return true; 
    g g = this.a.l;
    if (g != null)
      try {
        g.zze();
      } catch (RemoteException remoteException) {
        a.l("#007 Could not call remote method.", (Throwable)remoteException);
      }  
    c c2 = this.a;
    if (c2.m != null) {
      Uri uri = Uri.parse(paramString);
      try {
        Uri uri1 = c2.m.b(uri, c2.i, null, null);
        uri = uri1;
      } catch (zzfh zzfh) {
        a.j("Unable to process ad data", (Throwable)zzfh);
      } 
      paramString = uri.toString();
    } 
    c c1 = this.a;
    Intent intent = new Intent("android.intent.action.VIEW");
    intent.setData(Uri.parse(paramString));
    c1.i.startActivity(intent);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */