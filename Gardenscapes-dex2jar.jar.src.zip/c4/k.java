package c4;

import android.view.MotionEvent;
import android.view.View;
import com.google.android.gms.ads.internal.c;
import h5.n11;

public final class k implements View.OnTouchListener {
  public k(c paramc) {}
  
  public final boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    n11 n11 = this.f.m;
    if (n11 != null)
      n11.b.g(paramMotionEvent); 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c4\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */