package c1;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import androidx.activity.result.d;
import androidx.multidex.MultiDexExtractor;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public final class a {
  public static final Set<File> a;
  
  public static final boolean b;
  
  static {
    // Byte code:
    //   0: new java/util/HashSet
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: putstatic c1/a.a : Ljava/util/Set;
    //   10: ldc 'java.vm.version'
    //   12: invokestatic getProperty : (Ljava/lang/String;)Ljava/lang/String;
    //   15: astore #4
    //   17: iconst_0
    //   18: istore_3
    //   19: iload_3
    //   20: istore_2
    //   21: aload #4
    //   23: ifnull -> 92
    //   26: ldc '(\d+)\.(\d+)(\.\d+)?'
    //   28: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   31: aload #4
    //   33: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   36: astore #5
    //   38: iload_3
    //   39: istore_2
    //   40: aload #5
    //   42: invokevirtual matches : ()Z
    //   45: ifeq -> 92
    //   48: aload #5
    //   50: iconst_1
    //   51: invokevirtual group : (I)Ljava/lang/String;
    //   54: invokestatic parseInt : (Ljava/lang/String;)I
    //   57: istore_0
    //   58: aload #5
    //   60: iconst_2
    //   61: invokevirtual group : (I)Ljava/lang/String;
    //   64: invokestatic parseInt : (Ljava/lang/String;)I
    //   67: istore_1
    //   68: iload_0
    //   69: iconst_2
    //   70: if_icmpgt -> 87
    //   73: iload_3
    //   74: istore_2
    //   75: iload_0
    //   76: iconst_2
    //   77: if_icmpne -> 92
    //   80: iload_3
    //   81: istore_2
    //   82: iload_1
    //   83: iconst_1
    //   84: if_icmplt -> 92
    //   87: iconst_1
    //   88: istore_2
    //   89: goto -> 92
    //   92: ldc 'VM with version '
    //   94: aload #4
    //   96: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: astore #5
    //   101: iload_2
    //   102: ifeq -> 112
    //   105: ldc ' has multidex support'
    //   107: astore #4
    //   109: goto -> 116
    //   112: ldc ' does not have multidex support'
    //   114: astore #4
    //   116: aload #5
    //   118: aload #4
    //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: pop
    //   124: ldc 'MultiDex'
    //   126: aload #5
    //   128: invokevirtual toString : ()Ljava/lang/String;
    //   131: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   134: pop
    //   135: iload_2
    //   136: putstatic c1/a.b : Z
    //   139: return
    //   140: astore #5
    //   142: iload_3
    //   143: istore_2
    //   144: goto -> 92
    // Exception table:
    //   from	to	target	type
    //   48	68	140	java/lang/NumberFormatException
  }
  
  public static void a(Object paramObject, String paramString, Object[] paramArrayOfObject) {
    Field field = d(paramObject, paramString);
    Object[] arrayOfObject1 = (Object[])field.get(paramObject);
    Object[] arrayOfObject2 = (Object[])Array.newInstance(arrayOfObject1.getClass().getComponentType(), arrayOfObject1.length + paramArrayOfObject.length);
    System.arraycopy(arrayOfObject1, 0, arrayOfObject2, 0, arrayOfObject1.length);
    System.arraycopy(paramArrayOfObject, 0, arrayOfObject2, arrayOfObject1.length, paramArrayOfObject.length);
    field.set(paramObject, arrayOfObject2);
  }
  
  public static void b(Context paramContext) {
    File file = new File(paramContext.getFilesDir(), "secondary-dexes");
    if (file.isDirectory()) {
      StringBuilder stringBuilder2 = android.support.v4.media.a.a("Clearing old secondary dex dir (");
      stringBuilder2.append(file.getPath());
      stringBuilder2.append(").");
      Log.i("MultiDex", stringBuilder2.toString());
      File[] arrayOfFile = file.listFiles();
      if (arrayOfFile == null) {
        stringBuilder1 = android.support.v4.media.a.a("Failed to list secondary dex dir content (");
        stringBuilder1.append(file.getPath());
        stringBuilder1.append(").");
        Log.w("MultiDex", stringBuilder1.toString());
        return;
      } 
      int j = stringBuilder1.length;
      for (int i = 0; i < j; i++) {
        StringBuilder stringBuilder3 = stringBuilder1[i];
        StringBuilder stringBuilder4 = android.support.v4.media.a.a("Trying to delete old file ");
        stringBuilder4.append(stringBuilder3.getPath());
        stringBuilder4.append(" of size ");
        stringBuilder4.append(stringBuilder3.length());
        Log.i("MultiDex", stringBuilder4.toString());
        if (!stringBuilder3.delete()) {
          stringBuilder4 = android.support.v4.media.a.a("Failed to delete old file ");
          stringBuilder4.append(stringBuilder3.getPath());
          Log.w("MultiDex", stringBuilder4.toString());
        } else {
          stringBuilder4 = android.support.v4.media.a.a("Deleted old file ");
          stringBuilder4.append(stringBuilder3.getPath());
          Log.i("MultiDex", stringBuilder4.toString());
        } 
      } 
      if (!file.delete()) {
        stringBuilder1 = android.support.v4.media.a.a("Failed to delete secondary dex dir ");
        stringBuilder1.append(file.getPath());
        Log.w("MultiDex", stringBuilder1.toString());
        return;
      } 
      StringBuilder stringBuilder1 = android.support.v4.media.a.a("Deleted old secondary dex dir ");
      stringBuilder1.append(file.getPath());
      Log.i("MultiDex", stringBuilder1.toString());
    } 
  }
  
  public static void c(Context paramContext, File paramFile1, File paramFile2, String paramString1, String paramString2, boolean paramBoolean) {
    synchronized (a) {
      if (null.contains(paramFile1))
        return; 
      null.add(paramFile1);
      int i = Build.VERSION.SDK_INT;
      if (i > 20) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MultiDex is not guaranteed to work in SDK version ");
        stringBuilder.append(i);
        stringBuilder.append(": SDK version higher than ");
        stringBuilder.append(20);
        stringBuilder.append(" should be backed by ");
        stringBuilder.append("runtime with built-in multidex capabilty but it's not the ");
        stringBuilder.append("case here: java.vm.version=\"");
        stringBuilder.append(System.getProperty("java.vm.version"));
        stringBuilder.append("\"");
        Log.w("MultiDex", stringBuilder.toString());
      } 
      try {
        ClassLoader classLoader = paramContext.getClassLoader();
        if (classLoader == null) {
          Log.e("MultiDex", "Context class loader is null. Must be running in test mode. Skip patching.");
          return;
        } 
        try {
          b(paramContext);
        } finally {
          Exception exception = null;
        } 
        try {
          f(paramFile2);
        } catch (IOException iOException) {
          file = new File(paramContext.getFilesDir(), "code_cache");
          f(file);
        } 
        File file = new File(file, paramString1);
        f(file);
        MultiDexExtractor multiDexExtractor = new MultiDexExtractor(paramFile1, file);
        paramFile1 = null;
        try {
          List<? extends File> list = multiDexExtractor.i(paramContext, paramString2, false);
          try {
            e(classLoader, file, list);
          } catch (IOException iOException1) {
            if (paramBoolean) {
              Log.w("MultiDex", "Failed to install extracted secondary dex files, retrying with forced extraction", iOException1);
              e(classLoader, file, multiDexExtractor.i(paramContext, paramString2, true));
            } else {
              throw iOException1;
            } 
          } 
          try {
            multiDexExtractor.close();
            File file1 = paramFile1;
          } catch (IOException iOException) {}
          if (iOException == null)
            return; 
          throw iOException;
        } finally {
          try {
            multiDexExtractor.close();
          } catch (IOException iOException) {}
        } 
      } catch (RuntimeException runtimeException) {
        Log.w("MultiDex", "Failure while trying to obtain Context class loader. Must be running in test mode. Skip patching.", runtimeException);
        return;
      } 
    } 
  }
  
  public static Field d(Object paramObject, String paramString) {
    Class<?> clazz = paramObject.getClass();
    while (true) {
      if (clazz != null)
        try {
          Field field = clazz.getDeclaredField(paramString);
          if (!field.isAccessible())
            field.setAccessible(true); 
          return field;
        } catch (NoSuchFieldException noSuchFieldException) {
          clazz = clazz.getSuperclass();
          continue;
        }  
      StringBuilder stringBuilder = d.a("Field ", paramString, " not found in ");
      stringBuilder.append(paramObject.getClass());
      paramObject = new NoSuchFieldException(stringBuilder.toString());
      throw paramObject;
    } 
  }
  
  public static void e(ClassLoader paramClassLoader, File paramFile, List<? extends File> paramList) {
    if (!paramList.isEmpty()) {
      Object object = d(paramClassLoader, "pathList").get(paramClassLoader);
      ArrayList<Throwable> arrayList = new ArrayList();
      ArrayList<File> arrayList1 = new ArrayList<File>(paramList);
      Class[] arrayOfClass = new Class[3];
      arrayOfClass[0] = ArrayList.class;
      arrayOfClass[1] = File.class;
      arrayOfClass[2] = ArrayList.class;
      Class<?> clazz = object.getClass();
      while (true) {
        IOException[] arrayOfIOException;
        if (clazz != null) {
          IOException iOException;
          try {
            Method method = clazz.getDeclaredMethod("makeDexElements", arrayOfClass);
            if (!method.isAccessible())
              method.setAccessible(true); 
            a(object, "dexElements", (Object[])method.invoke(object, new Object[] { arrayList1, paramFile, arrayList }));
            if (arrayList.size() > 0) {
              IOException[] arrayOfIOException1;
              Iterator<IOException> iterator = arrayList.iterator();
              while (iterator.hasNext())
                Log.w("MultiDex", "Exception in makeDexElement", iterator.next()); 
              Field field = d(object, "dexElementsSuppressedExceptions");
              arrayOfIOException = (IOException[])field.get(object);
              if (arrayOfIOException == null) {
                arrayOfIOException1 = (IOException[])arrayList.toArray((Object[])new IOException[arrayList.size()]);
              } else {
                arrayOfIOException1 = new IOException[arrayList.size() + arrayOfIOException.length];
                arrayList.toArray((Object[])arrayOfIOException1);
                System.arraycopy(arrayOfIOException, 0, arrayOfIOException1, arrayList.size(), arrayOfIOException.length);
              } 
              field.set(object, arrayOfIOException1);
              iOException = new IOException("I/O exception during makeDexElement");
              iOException.initCause(arrayList.get(0));
              throw iOException;
            } 
            return;
          } catch (NoSuchMethodException noSuchMethodException) {
            Class clazz1 = iOException.getSuperclass();
            continue;
          } 
        } 
        StringBuilder stringBuilder = d.a("Method ", "makeDexElements", " with parameters ");
        stringBuilder.append(Arrays.asList(arrayOfIOException));
        stringBuilder.append(" not found in ");
        stringBuilder.append(object.getClass());
        throw new NoSuchMethodException(stringBuilder.toString());
      } 
    } 
  }
  
  public static void f(File paramFile) {
    paramFile.mkdir();
    if (!paramFile.isDirectory()) {
      File file = paramFile.getParentFile();
      if (file == null) {
        stringBuilder = android.support.v4.media.a.a("Failed to create dir ");
        stringBuilder.append(paramFile.getPath());
        stringBuilder.append(". Parent file is null.");
        Log.e("MultiDex", stringBuilder.toString());
      } else {
        StringBuilder stringBuilder1 = android.support.v4.media.a.a("Failed to create dir ");
        stringBuilder1.append(paramFile.getPath());
        stringBuilder1.append(". parent file is a dir ");
        stringBuilder1.append(stringBuilder.isDirectory());
        stringBuilder1.append(", a file ");
        stringBuilder1.append(stringBuilder.isFile());
        stringBuilder1.append(", exists ");
        stringBuilder1.append(stringBuilder.exists());
        stringBuilder1.append(", readable ");
        stringBuilder1.append(stringBuilder.canRead());
        stringBuilder1.append(", writable ");
        stringBuilder1.append(stringBuilder.canWrite());
        Log.e("MultiDex", stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = android.support.v4.media.a.a("Failed to create directory ");
      stringBuilder.append(paramFile.getPath());
      throw new IOException(stringBuilder.toString());
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */