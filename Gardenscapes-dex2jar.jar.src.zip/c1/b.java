package c1;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import java.io.File;
import java.util.Set;

public class b extends Application {
  public void attachBaseContext(Context paramContext) {
    super.attachBaseContext(paramContext);
    Set<File> set = a.a;
    Log.i("MultiDex", "Installing application");
    if (a.b) {
      Log.i("MultiDex", "VM has multidex support, MultiDex support library is disabled.");
      return;
    } 
    try {
      ApplicationInfo applicationInfo = getApplicationInfo();
    } catch (RuntimeException null) {
      Log.w("MultiDex", "Failure while trying to obtain ApplicationInfo from Context. Must be running in test mode. Skip patching.", exception);
      exception = null;
    } catch (Exception exception) {}
    if (exception == null) {
      Log.i("MultiDex", "No ApplicationInfo available, i.e. running on a test Context: MultiDex support library is disabled.");
      return;
    } 
    a.c((Context)this, new File(((ApplicationInfo)exception).sourceDir), new File(((ApplicationInfo)exception).dataDir), "secondary-dexes", "", true);
    Log.i("MultiDex", "install done");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */