package c;

import android.content.Context;

public interface b {
  void a(Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\c\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */