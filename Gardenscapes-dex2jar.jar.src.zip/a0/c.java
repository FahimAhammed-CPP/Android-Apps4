package a0;

import android.util.Base64;
import androidx.appcompat.widget.d;
import java.util.Arrays;

public class c {
  public static String a(String paramString1, String paramString2) {
    return a.a(new StringBuilder(paramString1.length() + 1 + String.valueOf(paramString2).length()), paramString1, ":", paramString2);
  }
  
  public static String b(String paramString1, String paramString2, String paramString3) {
    StringBuilder stringBuilder = new StringBuilder(d.a(paramString1.length(), 2, String.valueOf(paramString2).length(), String.valueOf(paramString3).length()));
    b.a(stringBuilder, paramString1, ":", paramString2, ":");
    stringBuilder.append(paramString3);
    return stringBuilder.toString();
  }
  
  public static String c(byte[] paramArrayOfbyte, boolean paramBoolean) {
    byte b;
    if (true != paramBoolean) {
      b = 2;
    } else {
      b = 11;
    } 
    return Base64.encodeToString(paramArrayOfbyte, b);
  }
  
  public static byte[] d(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte.length == 16) {
      byte[] arrayOfByte = new byte[16];
      int i;
      for (i = 0; i < 16; i++) {
        byte b2 = paramArrayOfbyte[i];
        byte b1 = (byte)(b2 + b2 & 0xFE);
        arrayOfByte[i] = b1;
        if (i < 15)
          arrayOfByte[i] = (byte)(paramArrayOfbyte[i + 1] >> 7 & 0x1 | b1); 
      } 
      i = arrayOfByte[15];
      arrayOfByte[15] = (byte)((byte)(paramArrayOfbyte[0] >> 7 & 0x87) ^ i);
      return arrayOfByte;
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("value must be a block.");
    throw illegalArgumentException;
  }
  
  public static byte[] e(String paramString, boolean paramBoolean) {
    byte b;
    if (true != paramBoolean) {
      b = 2;
    } else {
      b = 11;
    } 
    byte[] arrayOfByte = Base64.decode(paramString, b);
    if (arrayOfByte.length == 0 && paramString.length() > 0) {
      if (paramString.length() != 0) {
        paramString = "Unable to decode ".concat(paramString);
      } else {
        paramString = new String("Unable to decode ");
      } 
      throw new IllegalArgumentException(paramString);
    } 
    return arrayOfByte;
  }
  
  public static byte[] f(byte[] paramArrayOfbyte) {
    int i = paramArrayOfbyte.length;
    if (i < 16) {
      paramArrayOfbyte = Arrays.copyOf(paramArrayOfbyte, 16);
      paramArrayOfbyte[i] = Byte.MIN_VALUE;
      return paramArrayOfbyte;
    } 
    throw new IllegalArgumentException("x must be smaller than a block.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */