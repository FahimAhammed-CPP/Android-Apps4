package a0;

import android.os.RemoteException;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.common.api.Status;
import h5.fg0;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.util.concurrent.atomic.AtomicReference;
import q.a;

public class d {
  public static ApiException a(Status paramStatus) {
    boolean bool;
    if (paramStatus.i != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return (ApiException)(bool ? new ResolvableApiException(paramStatus) : new ApiException(paramStatus));
  }
  
  public static <T> void b(AtomicReference<T> paramAtomicReference, fg0<T> paramfg0) {
    paramAtomicReference = (AtomicReference<T>)paramAtomicReference.get();
    if (paramAtomicReference == null)
      return; 
    try {
      paramfg0.b(paramAtomicReference);
      return;
    } catch (RemoteException remoteException) {
      a.l("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } catch (NullPointerException nullPointerException) {
      a.j("NullPointerException occurs when invoking a method from a delegating listener.", nullPointerException);
      return;
    } 
  }
  
  public static byte[] c(byte[]... paramVarArgs) {
    int k = paramVarArgs.length;
    int i = 0;
    int j = 0;
    while (i < k) {
      int m = (paramVarArgs[i]).length;
      if (j <= Integer.MAX_VALUE - m) {
        j += m;
        i++;
        continue;
      } 
      throw new GeneralSecurityException("exceeded size limit");
    } 
    byte[] arrayOfByte = new byte[j];
    k = paramVarArgs.length;
    i = 0;
    j = 0;
    while (i < k) {
      byte[] arrayOfByte1 = paramVarArgs[i];
      int m = arrayOfByte1.length;
      System.arraycopy(arrayOfByte1, 0, arrayOfByte, j, m);
      j += m;
      i++;
    } 
    return arrayOfByte;
  }
  
  public static final byte[] d(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3) {
    if (paramArrayOfbyte1.length - paramInt3 >= paramInt1 && paramArrayOfbyte2.length - paramInt3 >= paramInt2) {
      byte[] arrayOfByte = new byte[paramInt3];
      int i;
      for (i = 0; i < paramInt3; i++)
        arrayOfByte[i] = (byte)(paramArrayOfbyte1[i + paramInt1] ^ paramArrayOfbyte2[i + paramInt2]); 
      return arrayOfByte;
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("That combination of buffers, offsets and length to xor result in out-of-bond accesses.");
    throw illegalArgumentException;
  }
  
  public static final void e(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2, ByteBuffer paramByteBuffer3, int paramInt) {
    if (paramInt >= 0 && paramByteBuffer2.remaining() >= paramInt && paramByteBuffer3.remaining() >= paramInt && paramByteBuffer1.remaining() >= paramInt) {
      int i;
      for (i = 0; i < paramInt; i++)
        paramByteBuffer1.put((byte)(paramByteBuffer2.get() ^ paramByteBuffer3.get())); 
      return;
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("That combination of buffers, offsets and length to xor result in out-of-bond accesses.");
    throw illegalArgumentException;
  }
  
  public static final byte[] f(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    int i = paramArrayOfbyte1.length;
    if (i == paramArrayOfbyte2.length)
      return d(paramArrayOfbyte1, 0, paramArrayOfbyte2, 0, i); 
    throw new IllegalArgumentException("The lengths of x and y should match.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */