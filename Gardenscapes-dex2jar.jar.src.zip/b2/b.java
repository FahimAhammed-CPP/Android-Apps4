package b2;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;
import z1.j;

public class b implements a {
  public final j a;
  
  public final Handler b = new Handler(Looper.getMainLooper());
  
  public final Executor c = new a(this);
  
  public b(Executor paramExecutor) {
    this.a = new j(paramExecutor);
  }
  
  public class a implements Executor {
    public a(b this$0) {}
    
    public void execute(Runnable param1Runnable) {
      this.f.b.post(param1Runnable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */