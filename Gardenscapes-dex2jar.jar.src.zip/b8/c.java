package b8;

import a6.g;
import com.google.firebase.installations.b;

public interface c {
  g<b> a(boolean paramBoolean);
  
  g<String> getId();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b8\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */