package b8;

import a6.h;
import com.google.firebase.installations.b;
import com.google.firebase.installations.local.b;
import j.f;
import java.util.Objects;

public class e implements h {
  public final i a;
  
  public final h<b> b;
  
  public e(i parami, h<b> paramh) {
    this.a = parami;
    this.b = paramh;
  }
  
  public boolean a(b paramb) {
    if (paramb.j() && !this.a.d(paramb)) {
      h<b> h1 = this.b;
      String str3 = paramb.a();
      Objects.requireNonNull(str3, "Null token");
      Long long_1 = Long.valueOf(paramb.b());
      Long long_2 = Long.valueOf(paramb.g());
      String str1 = "";
      if (long_1 == null)
        str1 = f.a("", " tokenExpirationTimestamp"); 
      String str2 = str1;
      if (long_2 == null)
        str2 = f.a(str1, " tokenCreationTimestamp"); 
      if (str2.isEmpty()) {
        a a = new a(str3, long_1.longValue(), long_2.longValue(), null);
        h1.a.s(a);
        return true;
      } 
      throw new IllegalStateException(f.a("Missing required properties:", str2));
    } 
    return false;
  }
  
  public boolean onException(Exception paramException) {
    this.b.a(paramException);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b8\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */