package b8;

import android.util.Base64;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.UUID;

public class g {
  public static final byte a = Byte.parseByte("01110000", 2);
  
  public static final byte b = Byte.parseByte("00001111", 2);
  
  public String a() {
    UUID uUID = UUID.randomUUID();
    ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[17]);
    byteBuffer.putLong(uUID.getMostSignificantBits());
    byteBuffer.putLong(uUID.getLeastSignificantBits());
    byte[] arrayOfByte = byteBuffer.array();
    arrayOfByte[16] = arrayOfByte[0];
    arrayOfByte[0] = (byte)(b & arrayOfByte[0] | a);
    return (new String(Base64.encode(arrayOfByte, 11), Charset.defaultCharset())).substring(0, 22);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b8\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */