package b8;

import android.text.TextUtils;
import com.google.firebase.installations.local.b;
import h5.de;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public final class i {
  public static final long b = TimeUnit.HOURS.toSeconds(1L);
  
  public static final Pattern c = Pattern.compile("\\AA[\\w-]{38}\\z");
  
  public static i d;
  
  public final de a;
  
  public i(de paramde) {
    this.a = paramde;
  }
  
  public static i c() {
    if (de.f == null)
      de.f = new de(5); 
    de de1 = de.f;
    if (d == null)
      d = new i(de1); 
    return d;
  }
  
  public long a() {
    Objects.requireNonNull(this.a);
    return System.currentTimeMillis();
  }
  
  public long b() {
    return TimeUnit.MILLISECONDS.toSeconds(a());
  }
  
  public boolean d(b paramb) {
    if (TextUtils.isEmpty(paramb.a()))
      return true; 
    long l = paramb.g();
    return (paramb.b() + l < b() + b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b8\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */