package b8;

import com.google.firebase.installations.local.b;

public interface h {
  boolean a(b paramb);
  
  boolean onException(Exception paramException);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\b8\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */