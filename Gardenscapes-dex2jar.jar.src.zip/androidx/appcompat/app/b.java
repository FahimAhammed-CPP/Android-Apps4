package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import f.c;
import f.d;
import f.e;
import f.f;
import f.p;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.y;

public class b extends p {
  public final AlertController h = new AlertController(getContext(), this, getWindow());
  
  public b(Context paramContext, int paramInt) {
    super(paramContext, c(paramContext, paramInt));
  }
  
  public static int c(Context paramContext, int paramInt) {
    if ((paramInt >>> 24 & 0xFF) >= 1)
      return paramInt; 
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(2130903083, typedValue, true);
    return typedValue.resourceId;
  }
  
  public void onCreate(Bundle paramBundle) {
    int i;
    int j;
    boolean bool1;
    super.onCreate(paramBundle);
    AlertController alertController = this.h;
    if (alertController.K == 0) {
      i = alertController.J;
    } else {
      i = alertController.J;
    } 
    alertController.b.setContentView(i);
    View view1 = alertController.c.findViewById(2131231065);
    View view4 = view1.findViewById(2131231198);
    View view3 = view1.findViewById(2131230862);
    View view2 = view1.findViewById(2131230823);
    ViewGroup viewGroup2 = (ViewGroup)view1.findViewById(2131230868);
    view1 = alertController.h;
    boolean bool2 = false;
    if (view1 == null)
      if (alertController.i != 0) {
        view1 = LayoutInflater.from(alertController.a).inflate(alertController.i, viewGroup2, false);
      } else {
        view1 = null;
      }  
    if (view1 != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 0 || !AlertController.a(view1))
      alertController.c.setFlags(131072, 131072); 
    if (i != 0) {
      FrameLayout frameLayout = (FrameLayout)alertController.c.findViewById(2131230867);
      frameLayout.addView(view1, new ViewGroup.LayoutParams(-1, -1));
      if (alertController.n)
        frameLayout.setPadding(alertController.j, alertController.k, alertController.l, alertController.m); 
      if (alertController.g != null)
        ((LinearLayout.LayoutParams)viewGroup2.getLayoutParams()).weight = 0.0F; 
    } else {
      viewGroup2.setVisibility(8);
    } 
    view1 = viewGroup2.findViewById(2131231198);
    View view6 = viewGroup2.findViewById(2131230862);
    View view5 = viewGroup2.findViewById(2131230823);
    ViewGroup viewGroup1 = alertController.d(view1, view4);
    ViewGroup viewGroup4 = alertController.d(view6, view3);
    ViewGroup viewGroup3 = alertController.d(view5, view2);
    NestedScrollView nestedScrollView = (NestedScrollView)alertController.c.findViewById(2131231099);
    alertController.A = nestedScrollView;
    nestedScrollView.setFocusable(false);
    alertController.A.setNestedScrollingEnabled(false);
    TextView textView = (TextView)viewGroup4.findViewById(16908299);
    alertController.F = textView;
    if (textView != null) {
      CharSequence charSequence = alertController.f;
      if (charSequence != null) {
        textView.setText(charSequence);
      } else {
        textView.setVisibility(8);
        alertController.A.removeView((View)alertController.F);
        if (alertController.g != null) {
          ViewGroup viewGroup = (ViewGroup)alertController.A.getParent();
          i = viewGroup.indexOfChild((View)alertController.A);
          viewGroup.removeViewAt(i);
          viewGroup.addView((View)alertController.g, i, new ViewGroup.LayoutParams(-1, -1));
        } else {
          viewGroup4.setVisibility(8);
        } 
      } 
    } 
    Button button = (Button)viewGroup3.findViewById(16908313);
    alertController.o = button;
    button.setOnClickListener(alertController.R);
    if (TextUtils.isEmpty(alertController.p) && alertController.r == null) {
      alertController.o.setVisibility(8);
      i = 0;
    } else {
      alertController.o.setText(alertController.p);
      Drawable drawable = alertController.r;
      if (drawable != null) {
        i = alertController.d;
        drawable.setBounds(0, 0, i, i);
        alertController.o.setCompoundDrawables(alertController.r, null, null, null);
      } 
      alertController.o.setVisibility(0);
      i = 1;
    } 
    button = (Button)viewGroup3.findViewById(16908314);
    alertController.s = button;
    button.setOnClickListener(alertController.R);
    if (TextUtils.isEmpty(alertController.t) && alertController.v == null) {
      alertController.s.setVisibility(8);
    } else {
      alertController.s.setText(alertController.t);
      Drawable drawable = alertController.v;
      if (drawable != null) {
        j = alertController.d;
        drawable.setBounds(0, 0, j, j);
        alertController.s.setCompoundDrawables(alertController.v, null, null, null);
      } 
      alertController.s.setVisibility(0);
      i |= 0x2;
    } 
    button = (Button)viewGroup3.findViewById(16908315);
    alertController.w = button;
    button.setOnClickListener(alertController.R);
    if (TextUtils.isEmpty(alertController.x) && alertController.z == null) {
      alertController.w.setVisibility(8);
    } else {
      alertController.w.setText(alertController.x);
      Drawable drawable = alertController.z;
      if (drawable != null) {
        j = alertController.d;
        drawable.setBounds(0, 0, j, j);
        alertController.w.setCompoundDrawables(alertController.z, null, null, null);
      } 
      alertController.w.setVisibility(0);
      i |= 0x4;
    } 
    Context context = alertController.a;
    TypedValue typedValue = new TypedValue();
    context.getTheme().resolveAttribute(2130903081, typedValue, true);
    if (typedValue.data != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j)
      if (i == 1) {
        alertController.b(alertController.o);
      } else if (i == 2) {
        alertController.b(alertController.s);
      } else if (i == 4) {
        alertController.b(alertController.w);
      }  
    if (i != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 0)
      viewGroup3.setVisibility(8); 
    if (alertController.G != null) {
      ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -2);
      viewGroup1.addView(alertController.G, 0, layoutParams);
      alertController.c.findViewById(2131231195).setVisibility(8);
    } else {
      alertController.D = (ImageView)alertController.c.findViewById(16908294);
      if ((TextUtils.isEmpty(alertController.e) ^ true) != 0 && alertController.P) {
        TextView textView1 = (TextView)alertController.c.findViewById(2131230791);
        alertController.E = textView1;
        textView1.setText(alertController.e);
        i = alertController.B;
        if (i != 0) {
          alertController.D.setImageResource(i);
        } else {
          Drawable drawable = alertController.C;
          if (drawable != null) {
            alertController.D.setImageDrawable(drawable);
          } else {
            alertController.E.setPadding(alertController.D.getPaddingLeft(), alertController.D.getPaddingTop(), alertController.D.getPaddingRight(), alertController.D.getPaddingBottom());
            alertController.D.setVisibility(8);
          } 
        } 
      } else {
        alertController.c.findViewById(2131231195).setVisibility(8);
        alertController.D.setVisibility(8);
        viewGroup1.setVisibility(8);
      } 
    } 
    if (viewGroup2.getVisibility() != 8) {
      i = 1;
    } else {
      i = 0;
    } 
    if (viewGroup1 != null && viewGroup1.getVisibility() != 8) {
      j = 1;
    } else {
      j = 0;
    } 
    if (viewGroup3.getVisibility() != 8) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (!bool1) {
      View view = viewGroup4.findViewById(2131231178);
      if (view != null)
        view.setVisibility(0); 
    } 
    if (j) {
      NestedScrollView nestedScrollView1 = alertController.A;
      if (nestedScrollView1 != null)
        nestedScrollView1.setClipToPadding(true); 
      if (alertController.f != null || alertController.g != null) {
        View view = viewGroup1.findViewById(2131231194);
      } else {
        viewGroup1 = null;
      } 
      if (viewGroup1 != null)
        viewGroup1.setVisibility(0); 
    } else {
      View view = viewGroup4.findViewById(2131231179);
      if (view != null)
        view.setVisibility(0); 
    } 
    ListView listView = alertController.g;
    if (listView instanceof AlertController.RecycleListView) {
      listView = listView;
      Objects.requireNonNull(listView);
      if (!bool1 || !j) {
        int k;
        int m;
        int n = listView.getPaddingLeft();
        if (j) {
          k = listView.getPaddingTop();
        } else {
          k = ((AlertController.RecycleListView)listView).f;
        } 
        int i1 = listView.getPaddingRight();
        if (bool1) {
          m = listView.getPaddingBottom();
        } else {
          m = ((AlertController.RecycleListView)listView).g;
        } 
        listView.setPadding(n, k, i1, m);
      } 
    } 
    if (i == 0) {
      NestedScrollView nestedScrollView1;
      listView = alertController.g;
      if (listView == null)
        nestedScrollView1 = alertController.A; 
      if (nestedScrollView1 != null) {
        i = bool2;
        if (bool1)
          i = 2; 
        i = j | i;
        View view8 = alertController.c.findViewById(2131231098);
        View view7 = alertController.c.findViewById(2131231097);
        j = Build.VERSION.SDK_INT;
        if (j >= 23) {
          WeakHashMap weakHashMap = y.a;
          if (j >= 23)
            y.j.d((View)nestedScrollView1, i, 3); 
          if (view8 != null)
            viewGroup4.removeView(view8); 
          if (view7 != null)
            viewGroup4.removeView(view7); 
        } else {
          View view = view8;
          if (view8 != null) {
            view = view8;
            if ((i & 0x1) == 0) {
              viewGroup4.removeView(view8);
              view = null;
            } 
          } 
          if (view7 != null && (i & 0x2) == 0) {
            viewGroup4.removeView(view7);
            view7 = null;
          } 
          if (view != null || view7 != null)
            if (alertController.f != null) {
              alertController.A.setOnScrollChangeListener((NestedScrollView.b)new c(alertController, view, view7));
              alertController.A.post((Runnable)new d(alertController, view, view7));
            } else {
              ListView listView1 = alertController.g;
              if (listView1 != null) {
                listView1.setOnScrollListener((AbsListView.OnScrollListener)new e(alertController, view, view7));
                alertController.g.post((Runnable)new f(alertController, view, view7));
              } else {
                if (view != null)
                  viewGroup4.removeView(view); 
                if (view7 != null)
                  viewGroup4.removeView(view7); 
              } 
            }  
        } 
      } 
    } 
    listView = alertController.g;
    if (listView != null) {
      ListAdapter listAdapter = alertController.H;
      if (listAdapter != null) {
        listView.setAdapter(listAdapter);
        i = alertController.I;
        if (i > -1) {
          listView.setItemChecked(i, true);
          listView.setSelection(i);
        } 
      } 
    } 
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.h.A;
    if (nestedScrollView != null && nestedScrollView.g(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.h.A;
    if (nestedScrollView != null && nestedScrollView.g(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? true : super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    AlertController alertController = this.h;
    alertController.e = paramCharSequence;
    TextView textView = alertController.E;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public static class a {
    public final AlertController.b a;
    
    public final int b;
    
    public a(Context param1Context) {
      this.a = new AlertController.b((Context)new ContextThemeWrapper(param1Context, b.c(param1Context, i)));
      this.b = i;
    }
    
    public b a() {
      b b1 = new b(this.a.a, this.b);
      AlertController.b b2 = this.a;
      AlertController alertController = b1.h;
      View view = b2.e;
      if (view != null) {
        alertController.G = view;
      } else {
        CharSequence charSequence = b2.d;
        if (charSequence != null) {
          alertController.e = charSequence;
          TextView textView = alertController.E;
          if (textView != null)
            textView.setText(charSequence); 
        } 
        Drawable drawable = b2.c;
        if (drawable != null) {
          alertController.C = drawable;
          alertController.B = 0;
          ImageView imageView = alertController.D;
          if (imageView != null) {
            imageView.setVisibility(0);
            alertController.D.setImageDrawable(drawable);
          } 
        } 
      } 
      if (b2.g != null) {
        int i;
        AlertController.d d;
        AlertController.RecycleListView recycleListView = (AlertController.RecycleListView)b2.b.inflate(alertController.L, null);
        if (b2.i) {
          i = alertController.N;
        } else {
          i = alertController.O;
        } 
        ListAdapter listAdapter = b2.g;
        if (listAdapter == null)
          d = new AlertController.d(b2.a, i, 16908308, null); 
        alertController.H = (ListAdapter)d;
        alertController.I = b2.j;
        if (b2.h != null)
          recycleListView.setOnItemClickListener(new a(b2, alertController)); 
        if (b2.i)
          recycleListView.setChoiceMode(1); 
        alertController.g = recycleListView;
      } 
      Objects.requireNonNull(this.a);
      b1.setCancelable(true);
      Objects.requireNonNull(this.a);
      b1.setCanceledOnTouchOutside(true);
      Objects.requireNonNull(this.a);
      b1.setOnCancelListener(null);
      Objects.requireNonNull(this.a);
      b1.setOnDismissListener(null);
      DialogInterface.OnKeyListener onKeyListener = this.a.f;
      if (onKeyListener != null)
        b1.setOnKeyListener(onKeyListener); 
      return b1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */