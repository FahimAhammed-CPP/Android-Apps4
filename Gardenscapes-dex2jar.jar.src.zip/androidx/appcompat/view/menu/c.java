package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.b;
import java.util.ArrayList;
import java.util.Objects;

public class c implements i, AdapterView.OnItemClickListener {
  public Context f;
  
  public LayoutInflater g;
  
  public e h;
  
  public ExpandedMenuView i;
  
  public i.a j;
  
  public a k;
  
  public c(Context paramContext, int paramInt) {
    this.f = paramContext;
    this.g = LayoutInflater.from(paramContext);
  }
  
  public void a(e parame, boolean paramBoolean) {
    i.a a1 = this.j;
    if (a1 != null)
      a1.a(parame, paramBoolean); 
  }
  
  public void b(Context paramContext, e parame) {
    if (this.f != null) {
      this.f = paramContext;
      if (this.g == null)
        this.g = LayoutInflater.from(paramContext); 
    } 
    this.h = parame;
    a a1 = this.k;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public ListAdapter c() {
    if (this.k == null)
      this.k = new a(this); 
    return (ListAdapter)this.k;
  }
  
  public boolean d(l paraml) {
    if (!paraml.hasVisibleItems())
      return false; 
    f f = new f(paraml);
    b.a a2 = new b.a(paraml.a);
    c c1 = new c(a2.a.a, 2131427344);
    f.h = c1;
    c1.j = f;
    e e1 = f.f;
    e1.b(c1, e1.a);
    ListAdapter listAdapter = f.h.c();
    AlertController.b b1 = a2.a;
    b1.g = listAdapter;
    b1.h = f;
    View view = paraml.o;
    if (view != null) {
      b1.e = view;
    } else {
      b1.c = paraml.n;
      b1.d = paraml.m;
    } 
    b1.f = f;
    b b = a2.a();
    f.g = b;
    b.setOnDismissListener(f);
    WindowManager.LayoutParams layoutParams = f.g.getWindow().getAttributes();
    layoutParams.type = 1003;
    layoutParams.flags |= 0x20000;
    f.g.show();
    i.a a1 = this.j;
    if (a1 != null)
      a1.b(paraml); 
    return true;
  }
  
  public void e(boolean paramBoolean) {
    a a1 = this.k;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean g() {
    return false;
  }
  
  public boolean h(e parame, g paramg) {
    return false;
  }
  
  public boolean i(e parame, g paramg) {
    return false;
  }
  
  public void j(i.a parama) {
    this.j = parama;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.h.r((MenuItem)this.k.b(paramInt), this, 0);
  }
  
  public class a extends BaseAdapter {
    public int f = -1;
    
    public a(c this$0) {
      a();
    }
    
    public void a() {
      e e = this.g.h;
      g g = e.v;
      if (g != null) {
        e.i();
        ArrayList<g> arrayList = e.j;
        int j = arrayList.size();
        for (int i = 0; i < j; i++) {
          if ((g)arrayList.get(i) == g) {
            this.f = i;
            return;
          } 
        } 
      } 
      this.f = -1;
    }
    
    public g b(int param1Int) {
      e e = this.g.h;
      e.i();
      ArrayList<g> arrayList = e.j;
      Objects.requireNonNull(this.g);
      int i = param1Int + 0;
      int j = this.f;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      e e = this.g.h;
      e.i();
      int i = e.j.size();
      Objects.requireNonNull(this.g);
      i += 0;
      return (this.f < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null)
        view = this.g.g.inflate(2131427344, param1ViewGroup, false); 
      ((j.a)view).d(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */