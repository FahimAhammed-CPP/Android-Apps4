package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.widget.p0;
import androidx.appcompat.widget.q0;
import androidx.appcompat.widget.r0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.WeakHashMap;
import k.d;
import m0.y;

public final class b extends d implements View.OnKeyListener, PopupWindow.OnDismissListener {
  public boolean A;
  
  public boolean B;
  
  public i.a C;
  
  public ViewTreeObserver D;
  
  public PopupWindow.OnDismissListener E;
  
  public boolean F;
  
  public final Context g;
  
  public final int h;
  
  public final int i;
  
  public final int j;
  
  public final boolean k;
  
  public final Handler l;
  
  public final List<e> m = new ArrayList<e>();
  
  public final List<d> n = new ArrayList<d>();
  
  public final ViewTreeObserver.OnGlobalLayoutListener o = new a(this);
  
  public final View.OnAttachStateChangeListener p = new b(this);
  
  public final q0 q = new c(this);
  
  public int r;
  
  public int s;
  
  public View t;
  
  public View u;
  
  public int v;
  
  public boolean w;
  
  public boolean x;
  
  public int y;
  
  public int z;
  
  public b(Context paramContext, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    boolean bool = false;
    this.r = 0;
    this.s = 0;
    this.g = paramContext;
    this.t = paramView;
    this.i = paramInt1;
    this.j = paramInt2;
    this.k = paramBoolean;
    this.A = false;
    WeakHashMap weakHashMap = y.a;
    if (y.e.d(paramView) == 1) {
      paramInt1 = bool;
    } else {
      paramInt1 = 1;
    } 
    this.v = paramInt1;
    Resources resources = paramContext.getResources();
    this.h = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(2131099671));
    this.l = new Handler();
  }
  
  public void a(e parame, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield n : Ljava/util/List;
    //   4: invokeinterface size : ()I
    //   9: istore #4
    //   11: iconst_0
    //   12: istore_3
    //   13: iload_3
    //   14: iload #4
    //   16: if_icmpge -> 49
    //   19: aload_1
    //   20: aload_0
    //   21: getfield n : Ljava/util/List;
    //   24: iload_3
    //   25: invokeinterface get : (I)Ljava/lang/Object;
    //   30: checkcast androidx/appcompat/view/menu/b$d
    //   33: getfield b : Landroidx/appcompat/view/menu/e;
    //   36: if_acmpne -> 42
    //   39: goto -> 51
    //   42: iload_3
    //   43: iconst_1
    //   44: iadd
    //   45: istore_3
    //   46: goto -> 13
    //   49: iconst_m1
    //   50: istore_3
    //   51: iload_3
    //   52: ifge -> 56
    //   55: return
    //   56: iload_3
    //   57: iconst_1
    //   58: iadd
    //   59: istore #4
    //   61: iload #4
    //   63: aload_0
    //   64: getfield n : Ljava/util/List;
    //   67: invokeinterface size : ()I
    //   72: if_icmpge -> 96
    //   75: aload_0
    //   76: getfield n : Ljava/util/List;
    //   79: iload #4
    //   81: invokeinterface get : (I)Ljava/lang/Object;
    //   86: checkcast androidx/appcompat/view/menu/b$d
    //   89: getfield b : Landroidx/appcompat/view/menu/e;
    //   92: iconst_0
    //   93: invokevirtual c : (Z)V
    //   96: aload_0
    //   97: getfield n : Ljava/util/List;
    //   100: iload_3
    //   101: invokeinterface remove : (I)Ljava/lang/Object;
    //   106: checkcast androidx/appcompat/view/menu/b$d
    //   109: astore #5
    //   111: aload #5
    //   113: getfield b : Landroidx/appcompat/view/menu/e;
    //   116: aload_0
    //   117: invokevirtual t : (Landroidx/appcompat/view/menu/i;)V
    //   120: aload_0
    //   121: getfield F : Z
    //   124: ifeq -> 169
    //   127: aload #5
    //   129: getfield a : Landroidx/appcompat/widget/r0;
    //   132: astore #6
    //   134: aload #6
    //   136: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   139: pop
    //   140: getstatic android/os/Build$VERSION.SDK_INT : I
    //   143: bipush #23
    //   145: if_icmplt -> 157
    //   148: aload #6
    //   150: getfield D : Landroid/widget/PopupWindow;
    //   153: aconst_null
    //   154: invokevirtual setExitTransition : (Landroid/transition/Transition;)V
    //   157: aload #5
    //   159: getfield a : Landroidx/appcompat/widget/r0;
    //   162: getfield D : Landroid/widget/PopupWindow;
    //   165: iconst_0
    //   166: invokevirtual setAnimationStyle : (I)V
    //   169: aload #5
    //   171: getfield a : Landroidx/appcompat/widget/r0;
    //   174: invokevirtual dismiss : ()V
    //   177: aload_0
    //   178: getfield n : Ljava/util/List;
    //   181: invokeinterface size : ()I
    //   186: istore #4
    //   188: iload #4
    //   190: ifle -> 219
    //   193: aload_0
    //   194: aload_0
    //   195: getfield n : Ljava/util/List;
    //   198: iload #4
    //   200: iconst_1
    //   201: isub
    //   202: invokeinterface get : (I)Ljava/lang/Object;
    //   207: checkcast androidx/appcompat/view/menu/b$d
    //   210: getfield c : I
    //   213: putfield v : I
    //   216: goto -> 251
    //   219: aload_0
    //   220: getfield t : Landroid/view/View;
    //   223: astore #5
    //   225: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   228: astore #6
    //   230: aload #5
    //   232: invokestatic d : (Landroid/view/View;)I
    //   235: iconst_1
    //   236: if_icmpne -> 244
    //   239: iconst_0
    //   240: istore_3
    //   241: goto -> 246
    //   244: iconst_1
    //   245: istore_3
    //   246: aload_0
    //   247: iload_3
    //   248: putfield v : I
    //   251: iload #4
    //   253: ifne -> 333
    //   256: aload_0
    //   257: invokevirtual dismiss : ()V
    //   260: aload_0
    //   261: getfield C : Landroidx/appcompat/view/menu/i$a;
    //   264: astore #5
    //   266: aload #5
    //   268: ifnull -> 280
    //   271: aload #5
    //   273: aload_1
    //   274: iconst_1
    //   275: invokeinterface a : (Landroidx/appcompat/view/menu/e;Z)V
    //   280: aload_0
    //   281: getfield D : Landroid/view/ViewTreeObserver;
    //   284: astore_1
    //   285: aload_1
    //   286: ifnull -> 312
    //   289: aload_1
    //   290: invokevirtual isAlive : ()Z
    //   293: ifeq -> 307
    //   296: aload_0
    //   297: getfield D : Landroid/view/ViewTreeObserver;
    //   300: aload_0
    //   301: getfield o : Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
    //   304: invokevirtual removeGlobalOnLayoutListener : (Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    //   307: aload_0
    //   308: aconst_null
    //   309: putfield D : Landroid/view/ViewTreeObserver;
    //   312: aload_0
    //   313: getfield u : Landroid/view/View;
    //   316: aload_0
    //   317: getfield p : Landroid/view/View$OnAttachStateChangeListener;
    //   320: invokevirtual removeOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
    //   323: aload_0
    //   324: getfield E : Landroid/widget/PopupWindow$OnDismissListener;
    //   327: invokeinterface onDismiss : ()V
    //   332: return
    //   333: iload_2
    //   334: ifeq -> 357
    //   337: aload_0
    //   338: getfield n : Ljava/util/List;
    //   341: iconst_0
    //   342: invokeinterface get : (I)Ljava/lang/Object;
    //   347: checkcast androidx/appcompat/view/menu/b$d
    //   350: getfield b : Landroidx/appcompat/view/menu/e;
    //   353: iconst_0
    //   354: invokevirtual c : (Z)V
    //   357: return
  }
  
  public void c() {
    if (isShowing())
      return; 
    Iterator<e> iterator = this.m.iterator();
    while (iterator.hasNext())
      u(iterator.next()); 
    this.m.clear();
    View view = this.t;
    this.u = view;
    if (view != null) {
      boolean bool;
      if (this.D == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.D = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.o); 
      this.u.addOnAttachStateChangeListener(this.p);
    } 
  }
  
  public boolean d(l paraml) {
    for (d d1 : this.n) {
      if (paraml == d1.b) {
        ((p0)d1.a).h.requestFocus();
        return true;
      } 
    } 
    if (paraml.hasVisibleItems()) {
      paraml.b((i)this, this.g);
      if (isShowing()) {
        u(paraml);
      } else {
        this.m.add(paraml);
      } 
      i.a a1 = this.C;
      if (a1 != null)
        a1.b(paraml); 
      return true;
    } 
    return false;
  }
  
  public void dismiss() {
    int i = this.n.size();
    if (i > 0) {
      d[] arrayOfD = this.n.<d>toArray(new d[i]);
      while (--i >= 0) {
        d d1 = arrayOfD[i];
        if (d1.a.isShowing())
          d1.a.dismiss(); 
        i--;
      } 
    } 
  }
  
  public void e(boolean paramBoolean) {
    Iterator<d> iterator = this.n.iterator();
    while (iterator.hasNext()) {
      d d1;
      ListAdapter listAdapter = ((p0)((d)iterator.next()).a).h.getAdapter();
      if (listAdapter instanceof HeaderViewListAdapter) {
        d1 = (d)((HeaderViewListAdapter)listAdapter).getWrappedAdapter();
      } else {
        d1 = d1;
      } 
      d1.notifyDataSetChanged();
    } 
  }
  
  public ListView f() {
    if (this.n.isEmpty())
      return null; 
    List<d> list = this.n;
    return (ListView)((p0)((d)list.get(list.size() - 1)).a).h;
  }
  
  public boolean g() {
    return false;
  }
  
  public boolean isShowing() {
    int i = this.n.size();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      bool1 = bool2;
      if (((d)this.n.get(0)).a.isShowing())
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void j(i.a parama) {
    this.C = parama;
  }
  
  public void k(e parame) {
    parame.b((i)this, this.g);
    if (isShowing()) {
      u(parame);
      return;
    } 
    this.m.add(parame);
  }
  
  public void m(View paramView) {
    if (this.t != paramView) {
      this.t = paramView;
      int i = this.r;
      WeakHashMap weakHashMap = y.a;
      this.s = Gravity.getAbsoluteGravity(i, y.e.d(paramView));
    } 
  }
  
  public void n(boolean paramBoolean) {
    this.A = paramBoolean;
  }
  
  public void o(int paramInt) {
    if (this.r != paramInt) {
      this.r = paramInt;
      View view = this.t;
      WeakHashMap weakHashMap = y.a;
      this.s = Gravity.getAbsoluteGravity(paramInt, y.e.d(view));
    } 
  }
  
  public void onDismiss() {
    // Byte code:
    //   0: aload_0
    //   1: getfield n : Ljava/util/List;
    //   4: invokeinterface size : ()I
    //   9: istore_2
    //   10: iconst_0
    //   11: istore_1
    //   12: iload_1
    //   13: iload_2
    //   14: if_icmpge -> 51
    //   17: aload_0
    //   18: getfield n : Ljava/util/List;
    //   21: iload_1
    //   22: invokeinterface get : (I)Ljava/lang/Object;
    //   27: checkcast androidx/appcompat/view/menu/b$d
    //   30: astore_3
    //   31: aload_3
    //   32: getfield a : Landroidx/appcompat/widget/r0;
    //   35: invokevirtual isShowing : ()Z
    //   38: ifne -> 44
    //   41: goto -> 53
    //   44: iload_1
    //   45: iconst_1
    //   46: iadd
    //   47: istore_1
    //   48: goto -> 12
    //   51: aconst_null
    //   52: astore_3
    //   53: aload_3
    //   54: ifnull -> 65
    //   57: aload_3
    //   58: getfield b : Landroidx/appcompat/view/menu/e;
    //   61: iconst_0
    //   62: invokevirtual c : (Z)V
    //   65: return
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void p(int paramInt) {
    this.w = true;
    this.y = paramInt;
  }
  
  public void q(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.E = paramOnDismissListener;
  }
  
  public void r(boolean paramBoolean) {
    this.B = paramBoolean;
  }
  
  public void s(int paramInt) {
    this.x = true;
    this.z = paramInt;
  }
  
  public final void u(e parame) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Landroid/content/Context;
    //   4: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   7: astore #10
    //   9: new androidx/appcompat/view/menu/d
    //   12: dup
    //   13: aload_1
    //   14: aload #10
    //   16: aload_0
    //   17: getfield k : Z
    //   20: ldc_w 2131427339
    //   23: invokespecial <init> : (Landroidx/appcompat/view/menu/e;Landroid/view/LayoutInflater;ZI)V
    //   26: astore #6
    //   28: aload_0
    //   29: invokevirtual isShowing : ()Z
    //   32: ifne -> 51
    //   35: aload_0
    //   36: getfield A : Z
    //   39: ifeq -> 51
    //   42: aload #6
    //   44: iconst_1
    //   45: putfield h : Z
    //   48: goto -> 67
    //   51: aload_0
    //   52: invokevirtual isShowing : ()Z
    //   55: ifeq -> 67
    //   58: aload #6
    //   60: aload_1
    //   61: invokestatic t : (Landroidx/appcompat/view/menu/e;)Z
    //   64: putfield h : Z
    //   67: aload_0
    //   68: getfield g : Landroid/content/Context;
    //   71: astore #7
    //   73: aload_0
    //   74: getfield h : I
    //   77: istore_2
    //   78: aconst_null
    //   79: astore #8
    //   81: aload #6
    //   83: aconst_null
    //   84: aload #7
    //   86: iload_2
    //   87: invokestatic l : (Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I
    //   90: istore_3
    //   91: new androidx/appcompat/widget/r0
    //   94: dup
    //   95: aload_0
    //   96: getfield g : Landroid/content/Context;
    //   99: aconst_null
    //   100: aload_0
    //   101: getfield i : I
    //   104: aload_0
    //   105: getfield j : I
    //   108: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;II)V
    //   111: astore #9
    //   113: aload #9
    //   115: aload_0
    //   116: getfield q : Landroidx/appcompat/widget/q0;
    //   119: putfield H : Landroidx/appcompat/widget/q0;
    //   122: aload #9
    //   124: aload_0
    //   125: putfield u : Landroid/widget/AdapterView$OnItemClickListener;
    //   128: aload #9
    //   130: getfield D : Landroid/widget/PopupWindow;
    //   133: aload_0
    //   134: invokevirtual setOnDismissListener : (Landroid/widget/PopupWindow$OnDismissListener;)V
    //   137: aload #9
    //   139: aload_0
    //   140: getfield t : Landroid/view/View;
    //   143: putfield t : Landroid/view/View;
    //   146: aload #9
    //   148: aload_0
    //   149: getfield s : I
    //   152: putfield q : I
    //   155: aload #9
    //   157: iconst_1
    //   158: invokevirtual r : (Z)V
    //   161: aload #9
    //   163: getfield D : Landroid/widget/PopupWindow;
    //   166: iconst_2
    //   167: invokevirtual setInputMethodMode : (I)V
    //   170: aload #9
    //   172: aload #6
    //   174: invokevirtual o : (Landroid/widget/ListAdapter;)V
    //   177: aload #9
    //   179: iload_3
    //   180: invokevirtual q : (I)V
    //   183: aload #9
    //   185: aload_0
    //   186: getfield s : I
    //   189: putfield q : I
    //   192: aload_0
    //   193: getfield n : Ljava/util/List;
    //   196: invokeinterface size : ()I
    //   201: ifle -> 477
    //   204: aload_0
    //   205: getfield n : Ljava/util/List;
    //   208: astore #6
    //   210: aload #6
    //   212: aload #6
    //   214: invokeinterface size : ()I
    //   219: iconst_1
    //   220: isub
    //   221: invokeinterface get : (I)Ljava/lang/Object;
    //   226: checkcast androidx/appcompat/view/menu/b$d
    //   229: astore #6
    //   231: aload #6
    //   233: getfield b : Landroidx/appcompat/view/menu/e;
    //   236: astore #11
    //   238: aload #11
    //   240: invokevirtual size : ()I
    //   243: istore #4
    //   245: iconst_0
    //   246: istore_2
    //   247: iload_2
    //   248: iload #4
    //   250: if_icmpge -> 292
    //   253: aload #11
    //   255: iload_2
    //   256: invokevirtual getItem : (I)Landroid/view/MenuItem;
    //   259: astore #7
    //   261: aload #7
    //   263: invokeinterface hasSubMenu : ()Z
    //   268: ifeq -> 285
    //   271: aload_1
    //   272: aload #7
    //   274: invokeinterface getSubMenu : ()Landroid/view/SubMenu;
    //   279: if_acmpne -> 285
    //   282: goto -> 295
    //   285: iload_2
    //   286: iconst_1
    //   287: iadd
    //   288: istore_2
    //   289: goto -> 247
    //   292: aconst_null
    //   293: astore #7
    //   295: aload #7
    //   297: ifnonnull -> 311
    //   300: aload #6
    //   302: astore #7
    //   304: aload #8
    //   306: astore #6
    //   308: goto -> 483
    //   311: aload #6
    //   313: getfield a : Landroidx/appcompat/widget/r0;
    //   316: getfield h : Landroidx/appcompat/widget/k0;
    //   319: astore #11
    //   321: aload #11
    //   323: invokevirtual getAdapter : ()Landroid/widget/ListAdapter;
    //   326: astore #8
    //   328: aload #8
    //   330: instanceof android/widget/HeaderViewListAdapter
    //   333: ifeq -> 363
    //   336: aload #8
    //   338: checkcast android/widget/HeaderViewListAdapter
    //   341: astore #8
    //   343: aload #8
    //   345: invokevirtual getHeadersCount : ()I
    //   348: istore #4
    //   350: aload #8
    //   352: invokevirtual getWrappedAdapter : ()Landroid/widget/ListAdapter;
    //   355: checkcast androidx/appcompat/view/menu/d
    //   358: astore #8
    //   360: goto -> 373
    //   363: aload #8
    //   365: checkcast androidx/appcompat/view/menu/d
    //   368: astore #8
    //   370: iconst_0
    //   371: istore #4
    //   373: aload #8
    //   375: invokevirtual getCount : ()I
    //   378: istore #5
    //   380: iconst_0
    //   381: istore_2
    //   382: iload_2
    //   383: iload #5
    //   385: if_icmpge -> 409
    //   388: aload #7
    //   390: aload #8
    //   392: iload_2
    //   393: invokevirtual b : (I)Landroidx/appcompat/view/menu/g;
    //   396: if_acmpne -> 402
    //   399: goto -> 411
    //   402: iload_2
    //   403: iconst_1
    //   404: iadd
    //   405: istore_2
    //   406: goto -> 382
    //   409: iconst_m1
    //   410: istore_2
    //   411: iload_2
    //   412: iconst_m1
    //   413: if_icmpne -> 423
    //   416: aload #6
    //   418: astore #7
    //   420: goto -> 480
    //   423: iload_2
    //   424: iload #4
    //   426: iadd
    //   427: aload #11
    //   429: invokevirtual getFirstVisiblePosition : ()I
    //   432: isub
    //   433: istore_2
    //   434: aload #6
    //   436: astore #7
    //   438: iload_2
    //   439: iflt -> 480
    //   442: iload_2
    //   443: aload #11
    //   445: invokevirtual getChildCount : ()I
    //   448: if_icmplt -> 458
    //   451: aload #6
    //   453: astore #7
    //   455: goto -> 480
    //   458: aload #11
    //   460: iload_2
    //   461: invokevirtual getChildAt : (I)Landroid/view/View;
    //   464: astore #8
    //   466: aload #6
    //   468: astore #7
    //   470: aload #8
    //   472: astore #6
    //   474: goto -> 483
    //   477: aconst_null
    //   478: astore #7
    //   480: aconst_null
    //   481: astore #6
    //   483: aload #6
    //   485: ifnull -> 903
    //   488: getstatic android/os/Build$VERSION.SDK_INT : I
    //   491: bipush #28
    //   493: if_icmpgt -> 543
    //   496: getstatic androidx/appcompat/widget/r0.I : Ljava/lang/reflect/Method;
    //   499: astore #8
    //   501: aload #8
    //   503: ifnull -> 552
    //   506: aload #8
    //   508: aload #9
    //   510: getfield D : Landroid/widget/PopupWindow;
    //   513: iconst_1
    //   514: anewarray java/lang/Object
    //   517: dup
    //   518: iconst_0
    //   519: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   522: aastore
    //   523: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   526: pop
    //   527: goto -> 552
    //   530: ldc_w 'MenuPopupWindow'
    //   533: ldc_w 'Could not invoke setTouchModal() on PopupWindow. Oh well.'
    //   536: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   539: pop
    //   540: goto -> 552
    //   543: aload #9
    //   545: getfield D : Landroid/widget/PopupWindow;
    //   548: iconst_0
    //   549: invokevirtual setTouchModal : (Z)V
    //   552: getstatic android/os/Build$VERSION.SDK_INT : I
    //   555: istore #5
    //   557: iload #5
    //   559: bipush #23
    //   561: if_icmplt -> 573
    //   564: aload #9
    //   566: getfield D : Landroid/widget/PopupWindow;
    //   569: aconst_null
    //   570: invokevirtual setEnterTransition : (Landroid/transition/Transition;)V
    //   573: aload_0
    //   574: getfield n : Ljava/util/List;
    //   577: astore #8
    //   579: aload #8
    //   581: aload #8
    //   583: invokeinterface size : ()I
    //   588: iconst_1
    //   589: isub
    //   590: invokeinterface get : (I)Ljava/lang/Object;
    //   595: checkcast androidx/appcompat/view/menu/b$d
    //   598: getfield a : Landroidx/appcompat/widget/r0;
    //   601: getfield h : Landroidx/appcompat/widget/k0;
    //   604: astore #8
    //   606: iconst_2
    //   607: newarray int
    //   609: astore #11
    //   611: aload #8
    //   613: aload #11
    //   615: invokevirtual getLocationOnScreen : ([I)V
    //   618: new android/graphics/Rect
    //   621: dup
    //   622: invokespecial <init> : ()V
    //   625: astore #12
    //   627: aload_0
    //   628: getfield u : Landroid/view/View;
    //   631: aload #12
    //   633: invokevirtual getWindowVisibleDisplayFrame : (Landroid/graphics/Rect;)V
    //   636: aload_0
    //   637: getfield v : I
    //   640: iconst_1
    //   641: if_icmpne -> 669
    //   644: aload #11
    //   646: iconst_0
    //   647: iaload
    //   648: istore_2
    //   649: aload #8
    //   651: invokevirtual getWidth : ()I
    //   654: iload_2
    //   655: iadd
    //   656: iload_3
    //   657: iadd
    //   658: aload #12
    //   660: getfield right : I
    //   663: if_icmple -> 678
    //   666: goto -> 684
    //   669: aload #11
    //   671: iconst_0
    //   672: iaload
    //   673: iload_3
    //   674: isub
    //   675: ifge -> 684
    //   678: iconst_1
    //   679: istore #4
    //   681: goto -> 687
    //   684: iconst_0
    //   685: istore #4
    //   687: iload #4
    //   689: iconst_1
    //   690: if_icmpne -> 698
    //   693: iconst_1
    //   694: istore_2
    //   695: goto -> 700
    //   698: iconst_0
    //   699: istore_2
    //   700: aload_0
    //   701: iload #4
    //   703: putfield v : I
    //   706: iload #5
    //   708: bipush #26
    //   710: if_icmplt -> 729
    //   713: aload #9
    //   715: aload #6
    //   717: putfield t : Landroid/view/View;
    //   720: iconst_0
    //   721: istore #4
    //   723: iconst_0
    //   724: istore #5
    //   726: goto -> 826
    //   729: iconst_2
    //   730: newarray int
    //   732: astore #8
    //   734: aload_0
    //   735: getfield t : Landroid/view/View;
    //   738: aload #8
    //   740: invokevirtual getLocationOnScreen : ([I)V
    //   743: iconst_2
    //   744: newarray int
    //   746: astore #11
    //   748: aload #6
    //   750: aload #11
    //   752: invokevirtual getLocationOnScreen : ([I)V
    //   755: aload_0
    //   756: getfield s : I
    //   759: bipush #7
    //   761: iand
    //   762: iconst_5
    //   763: if_icmpne -> 804
    //   766: aload #8
    //   768: iconst_0
    //   769: iaload
    //   770: istore #4
    //   772: aload #8
    //   774: iconst_0
    //   775: aload_0
    //   776: getfield t : Landroid/view/View;
    //   779: invokevirtual getWidth : ()I
    //   782: iload #4
    //   784: iadd
    //   785: iastore
    //   786: aload #11
    //   788: iconst_0
    //   789: iaload
    //   790: istore #4
    //   792: aload #11
    //   794: iconst_0
    //   795: aload #6
    //   797: invokevirtual getWidth : ()I
    //   800: iload #4
    //   802: iadd
    //   803: iastore
    //   804: aload #11
    //   806: iconst_0
    //   807: iaload
    //   808: aload #8
    //   810: iconst_0
    //   811: iaload
    //   812: isub
    //   813: istore #5
    //   815: aload #11
    //   817: iconst_1
    //   818: iaload
    //   819: aload #8
    //   821: iconst_1
    //   822: iaload
    //   823: isub
    //   824: istore #4
    //   826: aload_0
    //   827: getfield s : I
    //   830: iconst_5
    //   831: iand
    //   832: iconst_5
    //   833: if_icmpne -> 852
    //   836: iload_2
    //   837: ifeq -> 843
    //   840: goto -> 862
    //   843: aload #6
    //   845: invokevirtual getWidth : ()I
    //   848: istore_3
    //   849: goto -> 870
    //   852: iload_2
    //   853: ifeq -> 870
    //   856: aload #6
    //   858: invokevirtual getWidth : ()I
    //   861: istore_3
    //   862: iload #5
    //   864: iload_3
    //   865: iadd
    //   866: istore_2
    //   867: goto -> 875
    //   870: iload #5
    //   872: iload_3
    //   873: isub
    //   874: istore_2
    //   875: aload #9
    //   877: iload_2
    //   878: putfield k : I
    //   881: aload #9
    //   883: iconst_1
    //   884: putfield p : Z
    //   887: aload #9
    //   889: iconst_1
    //   890: putfield o : Z
    //   893: aload #9
    //   895: iload #4
    //   897: invokevirtual i : (I)V
    //   900: goto -> 970
    //   903: aload_0
    //   904: getfield w : Z
    //   907: ifeq -> 919
    //   910: aload #9
    //   912: aload_0
    //   913: getfield y : I
    //   916: putfield k : I
    //   919: aload_0
    //   920: getfield x : Z
    //   923: ifeq -> 935
    //   926: aload #9
    //   928: aload_0
    //   929: getfield z : I
    //   932: invokevirtual i : (I)V
    //   935: aload_0
    //   936: getfield f : Landroid/graphics/Rect;
    //   939: astore #6
    //   941: aload #6
    //   943: ifnull -> 960
    //   946: new android/graphics/Rect
    //   949: dup
    //   950: aload #6
    //   952: invokespecial <init> : (Landroid/graphics/Rect;)V
    //   955: astore #6
    //   957: goto -> 963
    //   960: aconst_null
    //   961: astore #6
    //   963: aload #9
    //   965: aload #6
    //   967: putfield B : Landroid/graphics/Rect;
    //   970: new androidx/appcompat/view/menu/b$d
    //   973: dup
    //   974: aload #9
    //   976: aload_1
    //   977: aload_0
    //   978: getfield v : I
    //   981: invokespecial <init> : (Landroidx/appcompat/widget/r0;Landroidx/appcompat/view/menu/e;I)V
    //   984: astore #6
    //   986: aload_0
    //   987: getfield n : Ljava/util/List;
    //   990: aload #6
    //   992: invokeinterface add : (Ljava/lang/Object;)Z
    //   997: pop
    //   998: aload #9
    //   1000: invokevirtual c : ()V
    //   1003: aload #9
    //   1005: getfield h : Landroidx/appcompat/widget/k0;
    //   1008: astore #6
    //   1010: aload #6
    //   1012: aload_0
    //   1013: invokevirtual setOnKeyListener : (Landroid/view/View$OnKeyListener;)V
    //   1016: aload #7
    //   1018: ifnonnull -> 1093
    //   1021: aload_0
    //   1022: getfield B : Z
    //   1025: ifeq -> 1093
    //   1028: aload_1
    //   1029: getfield m : Ljava/lang/CharSequence;
    //   1032: ifnull -> 1093
    //   1035: aload #10
    //   1037: ldc_w 2131427346
    //   1040: aload #6
    //   1042: iconst_0
    //   1043: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
    //   1046: checkcast android/widget/FrameLayout
    //   1049: astore #7
    //   1051: aload #7
    //   1053: ldc_w 16908310
    //   1056: invokevirtual findViewById : (I)Landroid/view/View;
    //   1059: checkcast android/widget/TextView
    //   1062: astore #8
    //   1064: aload #7
    //   1066: iconst_0
    //   1067: invokevirtual setEnabled : (Z)V
    //   1070: aload #8
    //   1072: aload_1
    //   1073: getfield m : Ljava/lang/CharSequence;
    //   1076: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   1079: aload #6
    //   1081: aload #7
    //   1083: aconst_null
    //   1084: iconst_0
    //   1085: invokevirtual addHeaderView : (Landroid/view/View;Ljava/lang/Object;Z)V
    //   1088: aload #9
    //   1090: invokevirtual c : ()V
    //   1093: return
    //   1094: astore #8
    //   1096: goto -> 530
    // Exception table:
    //   from	to	target	type
    //   506	527	1094	java/lang/Exception
  }
  
  public class a implements ViewTreeObserver.OnGlobalLayoutListener {
    public a(b this$0) {}
    
    public void onGlobalLayout() {
      if (this.f.isShowing() && this.f.n.size() > 0 && !((p0)((b.d)this.f.n.get(0)).a).C) {
        View view = this.f.u;
        if (view == null || !view.isShown()) {
          this.f.dismiss();
          return;
        } 
        Iterator<b.d> iterator = this.f.n.iterator();
        while (iterator.hasNext())
          ((b.d)iterator.next()).a.c(); 
      } 
    }
  }
  
  public class b implements View.OnAttachStateChangeListener {
    public b(b this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.f.D;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.f.D = param1View.getViewTreeObserver(); 
        b b1 = this.f;
        b1.D.removeGlobalOnLayoutListener(b1.o);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
  
  public class c implements q0 {
    public c(b this$0) {}
    
    public void b(e param1e, MenuItem param1MenuItem) {
      // Byte code:
      //   0: aload_0
      //   1: getfield f : Landroidx/appcompat/view/menu/b;
      //   4: getfield l : Landroid/os/Handler;
      //   7: astore #8
      //   9: aconst_null
      //   10: astore #7
      //   12: aload #8
      //   14: aconst_null
      //   15: invokevirtual removeCallbacksAndMessages : (Ljava/lang/Object;)V
      //   18: aload_0
      //   19: getfield f : Landroidx/appcompat/view/menu/b;
      //   22: getfield n : Ljava/util/List;
      //   25: invokeinterface size : ()I
      //   30: istore #4
      //   32: iconst_0
      //   33: istore_3
      //   34: iload_3
      //   35: iload #4
      //   37: if_icmpge -> 73
      //   40: aload_1
      //   41: aload_0
      //   42: getfield f : Landroidx/appcompat/view/menu/b;
      //   45: getfield n : Ljava/util/List;
      //   48: iload_3
      //   49: invokeinterface get : (I)Ljava/lang/Object;
      //   54: checkcast androidx/appcompat/view/menu/b$d
      //   57: getfield b : Landroidx/appcompat/view/menu/e;
      //   60: if_acmpne -> 66
      //   63: goto -> 75
      //   66: iload_3
      //   67: iconst_1
      //   68: iadd
      //   69: istore_3
      //   70: goto -> 34
      //   73: iconst_m1
      //   74: istore_3
      //   75: iload_3
      //   76: iconst_m1
      //   77: if_icmpne -> 81
      //   80: return
      //   81: iload_3
      //   82: iconst_1
      //   83: iadd
      //   84: istore_3
      //   85: iload_3
      //   86: aload_0
      //   87: getfield f : Landroidx/appcompat/view/menu/b;
      //   90: getfield n : Ljava/util/List;
      //   93: invokeinterface size : ()I
      //   98: if_icmpge -> 119
      //   101: aload_0
      //   102: getfield f : Landroidx/appcompat/view/menu/b;
      //   105: getfield n : Ljava/util/List;
      //   108: iload_3
      //   109: invokeinterface get : (I)Ljava/lang/Object;
      //   114: checkcast androidx/appcompat/view/menu/b$d
      //   117: astore #7
      //   119: new androidx/appcompat/view/menu/b$c$a
      //   122: dup
      //   123: aload_0
      //   124: aload #7
      //   126: aload_2
      //   127: aload_1
      //   128: invokespecial <init> : (Landroidx/appcompat/view/menu/b$c;Landroidx/appcompat/view/menu/b$d;Landroid/view/MenuItem;Landroidx/appcompat/view/menu/e;)V
      //   131: astore_2
      //   132: invokestatic uptimeMillis : ()J
      //   135: lstore #5
      //   137: aload_0
      //   138: getfield f : Landroidx/appcompat/view/menu/b;
      //   141: getfield l : Landroid/os/Handler;
      //   144: aload_2
      //   145: aload_1
      //   146: lload #5
      //   148: ldc2_w 200
      //   151: ladd
      //   152: invokevirtual postAtTime : (Ljava/lang/Runnable;Ljava/lang/Object;J)Z
      //   155: pop
      //   156: return
    }
    
    public void d(e param1e, MenuItem param1MenuItem) {
      this.f.l.removeCallbacksAndMessages(param1e);
    }
    
    public class a implements Runnable {
      public a(b.c this$0, b.d param2d, MenuItem param2MenuItem, e param2e) {}
      
      public void run() {
        b.d d1 = this.f;
        if (d1 != null) {
          this.i.f.F = true;
          d1.b.c(false);
          this.i.f.F = false;
        } 
        if (this.g.isEnabled() && this.g.hasSubMenu())
          this.h.q(this.g, 4); 
      }
    }
  }
  
  public class a implements Runnable {
    public a(b this$0, b.d param1d, MenuItem param1MenuItem, e param1e) {}
    
    public void run() {
      b.d d1 = this.f;
      if (d1 != null) {
        this.i.f.F = true;
        d1.b.c(false);
        this.i.f.F = false;
      } 
      if (this.g.isEnabled() && this.g.hasSubMenu())
        this.h.q(this.g, 4); 
    }
  }
  
  public static class d {
    public final r0 a;
    
    public final e b;
    
    public final int c;
    
    public d(r0 param1r0, e param1e, int param1Int) {
      this.a = param1r0;
      this.b = param1e;
      this.c = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */