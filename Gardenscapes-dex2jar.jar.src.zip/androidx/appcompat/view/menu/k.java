package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.k0;
import androidx.appcompat.widget.p0;
import androidx.appcompat.widget.r0;
import java.util.Objects;
import k.d;

public final class k extends d implements PopupWindow.OnDismissListener, View.OnKeyListener {
  public final Context g;
  
  public final e h;
  
  public final d i;
  
  public final boolean j;
  
  public final int k;
  
  public final int l;
  
  public final int m;
  
  public final r0 n;
  
  public final ViewTreeObserver.OnGlobalLayoutListener o = new a(this);
  
  public final View.OnAttachStateChangeListener p = new b(this);
  
  public PopupWindow.OnDismissListener q;
  
  public View r;
  
  public View s;
  
  public i.a t;
  
  public ViewTreeObserver u;
  
  public boolean v;
  
  public boolean w;
  
  public int x;
  
  public int y = 0;
  
  public boolean z;
  
  public k(Context paramContext, e parame, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.g = paramContext;
    this.h = parame;
    this.j = paramBoolean;
    this.i = new d(parame, LayoutInflater.from(paramContext), paramBoolean, 2131427347);
    this.l = paramInt1;
    this.m = paramInt2;
    Resources resources = paramContext.getResources();
    this.k = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(2131099671));
    this.r = paramView;
    this.n = new r0(paramContext, null, paramInt1, paramInt2);
    parame.b((i)this, paramContext);
  }
  
  public void a(e parame, boolean paramBoolean) {
    if (parame != this.h)
      return; 
    dismiss();
    i.a a1 = this.t;
    if (a1 != null)
      a1.a(parame, paramBoolean); 
  }
  
  public void c() {
    boolean bool = isShowing();
    boolean bool2 = false;
    if (!bool) {
      boolean bool3 = bool2;
      if (!this.v) {
        View view = this.r;
        if (view == null) {
          bool3 = bool2;
        } else {
          this.s = view;
          ((p0)this.n).D.setOnDismissListener(this);
          r0 r01 = this.n;
          ((p0)r01).u = (AdapterView.OnItemClickListener)this;
          r01.r(true);
          View view1 = this.s;
          if (this.u == null) {
            bool3 = true;
          } else {
            bool3 = false;
          } 
          ViewTreeObserver viewTreeObserver = view1.getViewTreeObserver();
          this.u = viewTreeObserver;
          if (bool3)
            viewTreeObserver.addOnGlobalLayoutListener(this.o); 
          view1.addOnAttachStateChangeListener(this.p);
          r0 r02 = this.n;
          ((p0)r02).t = view1;
          ((p0)r02).q = this.y;
          if (!this.w) {
            this.x = d.l((ListAdapter)this.i, null, this.g, this.k);
            this.w = true;
          } 
          this.n.q(this.x);
          ((p0)this.n).D.setInputMethodMode(2);
          r02 = this.n;
          Rect rect = this.f;
          Objects.requireNonNull(r02);
          if (rect != null) {
            rect = new Rect(rect);
          } else {
            rect = null;
          } 
          ((p0)r02).B = rect;
          this.n.c();
          k0 k0 = ((p0)this.n).h;
          k0.setOnKeyListener(this);
          if (this.z && this.h.m != null) {
            FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.g).inflate(2131427346, (ViewGroup)k0, false);
            TextView textView = (TextView)frameLayout.findViewById(16908310);
            if (textView != null)
              textView.setText(this.h.m); 
            frameLayout.setEnabled(false);
            k0.addHeaderView((View)frameLayout, null, false);
          } 
          this.n.o((ListAdapter)this.i);
          this.n.c();
          bool3 = true;
        } 
      } 
      if (bool3)
        return; 
      IllegalStateException illegalStateException = new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
      throw illegalStateException;
    } 
    boolean bool1 = true;
  }
  
  public boolean d(l paraml) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual hasVisibleItems : ()Z
    //   4: ifeq -> 241
    //   7: new androidx/appcompat/view/menu/h
    //   10: dup
    //   11: aload_0
    //   12: getfield g : Landroid/content/Context;
    //   15: aload_1
    //   16: aload_0
    //   17: getfield s : Landroid/view/View;
    //   20: aload_0
    //   21: getfield j : Z
    //   24: aload_0
    //   25: getfield l : I
    //   28: aload_0
    //   29: getfield m : I
    //   32: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/view/menu/e;Landroid/view/View;ZII)V
    //   35: astore #7
    //   37: aload #7
    //   39: aload_0
    //   40: getfield t : Landroidx/appcompat/view/menu/i$a;
    //   43: invokevirtual d : (Landroidx/appcompat/view/menu/i$a;)V
    //   46: aload_1
    //   47: invokestatic t : (Landroidx/appcompat/view/menu/e;)Z
    //   50: istore #6
    //   52: aload #7
    //   54: iload #6
    //   56: putfield h : Z
    //   59: aload #7
    //   61: getfield j : Lk/d;
    //   64: astore #8
    //   66: aload #8
    //   68: ifnull -> 78
    //   71: aload #8
    //   73: iload #6
    //   75: invokevirtual n : (Z)V
    //   78: aload #7
    //   80: aload_0
    //   81: getfield q : Landroid/widget/PopupWindow$OnDismissListener;
    //   84: putfield k : Landroid/widget/PopupWindow$OnDismissListener;
    //   87: aload_0
    //   88: aconst_null
    //   89: putfield q : Landroid/widget/PopupWindow$OnDismissListener;
    //   92: aload_0
    //   93: getfield h : Landroidx/appcompat/view/menu/e;
    //   96: iconst_0
    //   97: invokevirtual c : (Z)V
    //   100: aload_0
    //   101: getfield n : Landroidx/appcompat/widget/r0;
    //   104: astore #8
    //   106: aload #8
    //   108: getfield k : I
    //   111: istore #4
    //   113: aload #8
    //   115: getfield n : Z
    //   118: ifne -> 126
    //   121: iconst_0
    //   122: istore_2
    //   123: goto -> 132
    //   126: aload #8
    //   128: getfield l : I
    //   131: istore_2
    //   132: aload_0
    //   133: getfield y : I
    //   136: istore #5
    //   138: aload_0
    //   139: getfield r : Landroid/view/View;
    //   142: astore #8
    //   144: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   147: astore #9
    //   149: iload #4
    //   151: istore_3
    //   152: iload #5
    //   154: aload #8
    //   156: invokestatic d : (Landroid/view/View;)I
    //   159: invokestatic getAbsoluteGravity : (II)I
    //   162: bipush #7
    //   164: iand
    //   165: iconst_5
    //   166: if_icmpne -> 180
    //   169: iload #4
    //   171: aload_0
    //   172: getfield r : Landroid/view/View;
    //   175: invokevirtual getWidth : ()I
    //   178: iadd
    //   179: istore_3
    //   180: aload #7
    //   182: invokevirtual b : ()Z
    //   185: ifeq -> 191
    //   188: goto -> 213
    //   191: aload #7
    //   193: getfield f : Landroid/view/View;
    //   196: ifnonnull -> 204
    //   199: iconst_0
    //   200: istore_2
    //   201: goto -> 215
    //   204: aload #7
    //   206: iload_3
    //   207: iload_2
    //   208: iconst_1
    //   209: iconst_1
    //   210: invokevirtual e : (IIZZ)V
    //   213: iconst_1
    //   214: istore_2
    //   215: iload_2
    //   216: ifeq -> 241
    //   219: aload_0
    //   220: getfield t : Landroidx/appcompat/view/menu/i$a;
    //   223: astore #7
    //   225: aload #7
    //   227: ifnull -> 239
    //   230: aload #7
    //   232: aload_1
    //   233: invokeinterface b : (Landroidx/appcompat/view/menu/e;)Z
    //   238: pop
    //   239: iconst_1
    //   240: ireturn
    //   241: iconst_0
    //   242: ireturn
  }
  
  public void dismiss() {
    if (isShowing())
      this.n.dismiss(); 
  }
  
  public void e(boolean paramBoolean) {
    this.w = false;
    d d1 = this.i;
    if (d1 != null)
      d1.notifyDataSetChanged(); 
  }
  
  public ListView f() {
    return (ListView)((p0)this.n).h;
  }
  
  public boolean g() {
    return false;
  }
  
  public boolean isShowing() {
    return (!this.v && this.n.isShowing());
  }
  
  public void j(i.a parama) {
    this.t = parama;
  }
  
  public void k(e parame) {}
  
  public void m(View paramView) {
    this.r = paramView;
  }
  
  public void n(boolean paramBoolean) {
    this.i.h = paramBoolean;
  }
  
  public void o(int paramInt) {
    this.y = paramInt;
  }
  
  public void onDismiss() {
    this.v = true;
    this.h.c(true);
    ViewTreeObserver viewTreeObserver = this.u;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.u = this.s.getViewTreeObserver(); 
      this.u.removeGlobalOnLayoutListener(this.o);
      this.u = null;
    } 
    this.s.removeOnAttachStateChangeListener(this.p);
    PopupWindow.OnDismissListener onDismissListener = this.q;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void p(int paramInt) {
    ((p0)this.n).k = paramInt;
  }
  
  public void q(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.q = paramOnDismissListener;
  }
  
  public void r(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public void s(int paramInt) {
    r0 r01 = this.n;
    ((p0)r01).l = paramInt;
    ((p0)r01).n = true;
  }
  
  public class a implements ViewTreeObserver.OnGlobalLayoutListener {
    public a(k this$0) {}
    
    public void onGlobalLayout() {
      if (this.f.isShowing()) {
        k k1 = this.f;
        if (!((p0)k1.n).C) {
          View view = k1.s;
          if (view == null || !view.isShown()) {
            this.f.dismiss();
            return;
          } 
          this.f.n.c();
          return;
        } 
      } 
    }
  }
  
  public class b implements View.OnAttachStateChangeListener {
    public b(k this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.f.u;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.f.u = param1View.getViewTreeObserver(); 
        k k1 = this.f;
        k1.u.removeGlobalOnLayoutListener(k1.o);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */