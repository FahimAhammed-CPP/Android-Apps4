package androidx.appcompat.view.menu;

import android.content.Context;

public interface i {
  void a(e parame, boolean paramBoolean);
  
  void b(Context paramContext, e parame);
  
  boolean d(l paraml);
  
  void e(boolean paramBoolean);
  
  boolean g();
  
  boolean h(e parame, g paramg);
  
  boolean i(e parame, g paramg);
  
  void j(a parama);
  
  public static interface a {
    void a(e param1e, boolean param1Boolean);
    
    boolean b(e param1e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */