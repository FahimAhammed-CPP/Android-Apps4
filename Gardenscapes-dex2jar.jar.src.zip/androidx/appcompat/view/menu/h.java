package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import java.util.WeakHashMap;
import k.d;
import m0.y;

public class h {
  public final Context a;
  
  public final e b;
  
  public final boolean c;
  
  public final int d;
  
  public final int e;
  
  public View f;
  
  public int g = 8388611;
  
  public boolean h;
  
  public i.a i;
  
  public d j;
  
  public PopupWindow.OnDismissListener k;
  
  public final PopupWindow.OnDismissListener l = new a(this);
  
  public h(Context paramContext, e parame, View paramView, boolean paramBoolean, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.b = parame;
    this.f = paramView;
    this.c = paramBoolean;
    this.d = paramInt1;
    this.e = paramInt2;
  }
  
  public d a() {
    if (this.j == null) {
      boolean bool;
      k k;
      Display display = ((WindowManager)this.a.getSystemService("window")).getDefaultDisplay();
      Point point = new Point();
      display.getRealSize(point);
      if (Math.min(point.x, point.y) >= this.a.getResources().getDimensionPixelSize(2131099670)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        b b = new b(this.a, this.f, this.d, this.e, this.c);
      } else {
        k = new k(this.a, this.b, this.f, this.d, this.e, this.c);
      } 
      k.k(this.b);
      k.q(this.l);
      k.m(this.f);
      k.j(this.i);
      k.n(this.h);
      k.o(this.g);
      this.j = k;
    } 
    return this.j;
  }
  
  public boolean b() {
    d d1 = this.j;
    return (d1 != null && d1.isShowing());
  }
  
  public void c() {
    this.j = null;
    PopupWindow.OnDismissListener onDismissListener = this.k;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public void d(i.a parama) {
    this.i = parama;
    d d1 = this.j;
    if (d1 != null)
      d1.j(parama); 
  }
  
  public final void e(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    d d1 = a();
    d1.r(paramBoolean2);
    if (paramBoolean1) {
      int j = this.g;
      View view = this.f;
      WeakHashMap weakHashMap = y.a;
      int i = paramInt1;
      if ((Gravity.getAbsoluteGravity(j, y.e.d(view)) & 0x7) == 5)
        i = paramInt1 - this.f.getWidth(); 
      d1.p(i);
      d1.s(paramInt2);
      paramInt1 = (int)((this.a.getResources().getDisplayMetrics()).density * 48.0F / 2.0F);
      d1.f = new Rect(i - paramInt1, paramInt2 - paramInt1, i + paramInt1, paramInt2 + paramInt1);
    } 
    d1.c();
  }
  
  public boolean f() {
    if (b())
      return true; 
    if (this.f == null)
      return false; 
    e(0, 0, false, false);
    return true;
  }
  
  public class a implements PopupWindow.OnDismissListener {
    public a(h this$0) {}
    
    public void onDismiss() {
      this.f.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */