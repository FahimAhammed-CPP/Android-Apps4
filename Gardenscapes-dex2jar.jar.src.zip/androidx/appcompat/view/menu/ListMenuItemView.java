package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.d1;
import e.i;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.y;

public class ListMenuItemView extends LinearLayout implements j.a, AbsListView.SelectionBoundsAdjuster {
  public g f;
  
  public ImageView g;
  
  public RadioButton h;
  
  public TextView i;
  
  public CheckBox j;
  
  public TextView k;
  
  public ImageView l;
  
  public ImageView m;
  
  public LinearLayout n;
  
  public Drawable o;
  
  public int p;
  
  public Context q;
  
  public boolean r;
  
  public Drawable s;
  
  public boolean t;
  
  public LayoutInflater u;
  
  public boolean v;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    d1 d1 = d1.q(getContext(), paramAttributeSet, i.r, 2130903653, 0);
    this.o = d1.g(5);
    this.p = d1.l(1, -1);
    this.r = d1.a(7, false);
    this.q = paramContext;
    this.s = d1.g(8);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(null, new int[] { 16843049 }, 2130903386, 0);
    this.t = typedArray.hasValue(0);
    d1.b.recycle();
    typedArray.recycle();
  }
  
  private LayoutInflater getInflater() {
    if (this.u == null)
      this.u = LayoutInflater.from(getContext()); 
    return this.u;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.l;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public final void a() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(2131427342, (ViewGroup)this, false);
    this.j = checkBox;
    LinearLayout linearLayout = this.n;
    if (linearLayout != null) {
      linearLayout.addView((View)checkBox, -1);
      return;
    } 
    addView((View)checkBox, -1);
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.m;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.m.getLayoutParams();
      int i = paramRect.top;
      paramRect.top = this.m.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + i;
    } 
  }
  
  public final void b() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(2131427345, (ViewGroup)this, false);
    this.h = radioButton;
    LinearLayout linearLayout = this.n;
    if (linearLayout != null) {
      linearLayout.addView((View)radioButton, -1);
      return;
    } 
    addView((View)radioButton, -1);
  }
  
  public void d(g paramg, int paramInt) {
    this.f = paramg;
    boolean bool = paramg.isVisible();
    int i = 0;
    if (bool) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(paramg.e);
    setCheckable(paramg.isCheckable());
    bool = paramg.m();
    paramg.e();
    if (bool && this.f.m()) {
      paramInt = i;
    } else {
      paramInt = 8;
    } 
    if (paramInt == 0) {
      String str;
      TextView textView = this.k;
      g g1 = this.f;
      char c = g1.e();
      if (c == '\000') {
        str = "";
      } else {
        Resources resources = ((g)str).n.a.getResources();
        StringBuilder stringBuilder = new StringBuilder();
        if (ViewConfiguration.get(((g)str).n.a).hasPermanentMenuKey())
          stringBuilder.append(resources.getString(2131755026)); 
        if (((g)str).n.n()) {
          i = ((g)str).k;
        } else {
          i = ((g)str).i;
        } 
        g.c(stringBuilder, i, 65536, resources.getString(2131755022));
        g.c(stringBuilder, i, 4096, resources.getString(2131755018));
        g.c(stringBuilder, i, 2, resources.getString(2131755017));
        g.c(stringBuilder, i, 1, resources.getString(2131755023));
        g.c(stringBuilder, i, 4, resources.getString(2131755025));
        g.c(stringBuilder, i, 8, resources.getString(2131755021));
        if (c != '\b') {
          if (c != '\n') {
            if (c != ' ') {
              stringBuilder.append(c);
            } else {
              stringBuilder.append(resources.getString(2131755024));
            } 
          } else {
            stringBuilder.append(resources.getString(2131755020));
          } 
        } else {
          stringBuilder.append(resources.getString(2131755019));
        } 
        str = stringBuilder.toString();
      } 
      textView.setText(str);
    } 
    if (this.k.getVisibility() != paramInt)
      this.k.setVisibility(paramInt); 
    setIcon(paramg.getIcon());
    setEnabled(paramg.isEnabled());
    setSubMenuArrowVisible(paramg.hasSubMenu());
    setContentDescription(paramg.q);
  }
  
  public g getItemData() {
    return this.f;
  }
  
  public void onFinishInflate() {
    super.onFinishInflate();
    Drawable drawable = this.o;
    WeakHashMap weakHashMap = y.a;
    y.d.q((View)this, drawable);
    TextView textView = (TextView)findViewById(2131231193);
    this.i = textView;
    int i = this.p;
    if (i != -1)
      textView.setTextAppearance(this.q, i); 
    this.k = (TextView)findViewById(2131231114);
    ImageView imageView = (ImageView)findViewById(2131231148);
    this.l = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.s); 
    this.m = (ImageView)findViewById(2131230929);
    this.n = (LinearLayout)findViewById(2131230861);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.g != null && this.r) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.g.getLayoutParams();
      int i = layoutParams.height;
      if (i > 0 && layoutParams1.width <= 0)
        layoutParams1.width = i; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.h == null && this.j == null)
      return; 
    if (this.f.h()) {
      if (this.h == null)
        b(); 
      RadioButton radioButton1 = this.h;
      CheckBox checkBox1 = this.j;
    } else {
      if (this.j == null)
        a(); 
      checkBox = this.j;
      radioButton = this.h;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.f.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.j;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.h;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.f.h()) {
      if (this.h == null)
        b(); 
      RadioButton radioButton = this.h;
    } else {
      if (this.j == null)
        a(); 
      checkBox = this.j;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.v = paramBoolean;
    this.r = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.m;
    if (imageView != null) {
      byte b;
      if (!this.t && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    Objects.requireNonNull(this.f.n);
    if (this.v) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.r)
      return; 
    ImageView imageView = this.g;
    if (imageView == null && paramDrawable == null && !this.r)
      return; 
    if (imageView == null) {
      imageView = (ImageView)getInflater().inflate(2131427343, (ViewGroup)this, false);
      this.g = imageView;
      LinearLayout linearLayout = this.n;
      if (linearLayout != null) {
        linearLayout.addView((View)imageView, 0);
      } else {
        addView((View)imageView, 0);
      } 
    } 
    if (paramDrawable != null || this.r) {
      imageView = this.g;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.g.getVisibility() != 0)
        this.g.setVisibility(0); 
      return;
    } 
    this.g.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.i.setText(paramCharSequence);
      if (this.i.getVisibility() != 0) {
        this.i.setVisibility(0);
        return;
      } 
    } else if (this.i.getVisibility() != 8) {
      this.i.setVisibility(8);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */