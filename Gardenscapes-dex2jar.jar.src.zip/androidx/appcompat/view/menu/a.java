package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;

public abstract class a implements i {
  public Context f;
  
  public Context g;
  
  public e h;
  
  public LayoutInflater i;
  
  public i.a j;
  
  public int k;
  
  public int l;
  
  public j m;
  
  public a(Context paramContext, int paramInt1, int paramInt2) {
    this.f = paramContext;
    this.i = LayoutInflater.from(paramContext);
    this.k = paramInt1;
    this.l = paramInt2;
  }
  
  public boolean h(e parame, g paramg) {
    return false;
  }
  
  public boolean i(e parame, g paramg) {
    return false;
  }
  
  public void j(i.a parama) {
    this.j = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */