package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class d extends BaseAdapter {
  public e f;
  
  public int g = -1;
  
  public boolean h;
  
  public final boolean i;
  
  public final LayoutInflater j;
  
  public final int k;
  
  public d(e parame, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.i = paramBoolean;
    this.j = paramLayoutInflater;
    this.f = parame;
    this.k = paramInt;
    a();
  }
  
  public void a() {
    e e1 = this.f;
    g g = e1.v;
    if (g != null) {
      e1.i();
      ArrayList<g> arrayList = e1.j;
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        if ((g)arrayList.get(i) == g) {
          this.g = i;
          return;
        } 
      } 
    } 
    this.g = -1;
  }
  
  public g b(int paramInt) {
    ArrayList<g> arrayList;
    if (this.i) {
      e e1 = this.f;
      e1.i();
      arrayList = e1.j;
    } else {
      arrayList = this.f.l();
    } 
    int j = this.g;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public int getCount() {
    ArrayList<g> arrayList;
    if (this.i) {
      e e1 = this.f;
      e1.i();
      arrayList = e1.j;
    } else {
      arrayList = this.f.l();
    } 
    return (this.g < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.j.inflate(this.k, paramViewGroup, false); 
    int j = (b(paramInt)).b;
    int i = paramInt - 1;
    if (i >= 0) {
      i = (b(i)).b;
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.f.m() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    j.a a = (j.a)view;
    if (this.h)
      listMenuItemView.setForceShowIcon(true); 
    a.d(b(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\view\menu\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */