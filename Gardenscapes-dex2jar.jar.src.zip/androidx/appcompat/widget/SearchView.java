package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import j.b;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.y;

public class SearchView extends n0 implements b {
  public static final n r0;
  
  public final ImageView A;
  
  public final ImageView B;
  
  public final View C;
  
  public p D;
  
  public Rect E = new Rect();
  
  public Rect F = new Rect();
  
  public int[] G = new int[2];
  
  public int[] H = new int[2];
  
  public final ImageView I;
  
  public final Drawable J;
  
  public final int K;
  
  public final int L;
  
  public final Intent M;
  
  public final Intent N;
  
  public final CharSequence O;
  
  public l P;
  
  public k Q;
  
  public View.OnFocusChangeListener R;
  
  public m S;
  
  public View.OnClickListener T;
  
  public boolean U;
  
  public boolean V;
  
  public r0.a W;
  
  public boolean a0;
  
  public CharSequence b0;
  
  public boolean c0;
  
  public boolean d0;
  
  public int e0;
  
  public boolean f0;
  
  public CharSequence g0;
  
  public CharSequence h0;
  
  public boolean i0;
  
  public int j0;
  
  public SearchableInfo k0;
  
  public Bundle l0;
  
  public final Runnable m0 = new b(this);
  
  public Runnable n0 = new c(this);
  
  public final WeakHashMap<String, Drawable.ConstantState> o0 = new WeakHashMap<String, Drawable.ConstantState>();
  
  public View.OnKeyListener p0;
  
  public TextWatcher q0;
  
  public final SearchAutoComplete u;
  
  public final View v;
  
  public final View w;
  
  public final View x;
  
  public final ImageView y;
  
  public final ImageView z;
  
  static {
    n n1;
    if (Build.VERSION.SDK_INT < 29) {
      n1 = new n();
    } else {
      n1 = null;
    } 
    r0 = n1;
  }
  
  public SearchView(Context paramContext) {
    this(paramContext, null);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130903829);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    f f = new f(this);
    this.p0 = new g(this);
    h h = new h(this);
    i i = new i(this);
    j j = new j(this);
    this.q0 = new a(this);
    int[] arrayOfInt = e.i.u;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt, paramInt, 0);
    d1 d1 = new d1(paramContext, typedArray);
    y.z((View)this, paramContext, arrayOfInt, paramAttributeSet, typedArray, paramInt, 0);
    LayoutInflater.from(paramContext).inflate(d1.l(9, 2131427353), this, true);
    SearchAutoComplete searchAutoComplete = (SearchAutoComplete)findViewById(2131231109);
    this.u = searchAutoComplete;
    searchAutoComplete.setSearchView(this);
    this.v = findViewById(2131231105);
    View view2 = findViewById(2131231108);
    this.w = view2;
    View view3 = findViewById(2131231149);
    this.x = view3;
    ImageView imageView1 = (ImageView)findViewById(2131231103);
    this.y = imageView1;
    ImageView imageView2 = (ImageView)findViewById(2131231106);
    this.z = imageView2;
    ImageView imageView3 = (ImageView)findViewById(2131231104);
    this.A = imageView3;
    ImageView imageView4 = (ImageView)findViewById(2131231110);
    this.B = imageView4;
    ImageView imageView5 = (ImageView)findViewById(2131231107);
    this.I = imageView5;
    y.d.q(view2, d1.g(10));
    y.d.q(view3, d1.g(14));
    imageView1.setImageDrawable(d1.g(13));
    imageView2.setImageDrawable(d1.g(7));
    imageView3.setImageDrawable(d1.g(4));
    imageView4.setImageDrawable(d1.g(16));
    imageView5.setImageDrawable(d1.g(13));
    this.J = d1.g(12);
    h1.a((View)imageView1, getResources().getString(2131755030));
    this.K = d1.l(15, 2131427352);
    this.L = d1.l(5, 0);
    imageView1.setOnClickListener(f);
    imageView3.setOnClickListener(f);
    imageView2.setOnClickListener(f);
    imageView4.setOnClickListener(f);
    searchAutoComplete.setOnClickListener(f);
    searchAutoComplete.addTextChangedListener(this.q0);
    searchAutoComplete.setOnEditorActionListener(h);
    searchAutoComplete.setOnItemClickListener(i);
    searchAutoComplete.setOnItemSelectedListener(j);
    searchAutoComplete.setOnKeyListener(this.p0);
    searchAutoComplete.setOnFocusChangeListener(new d(this));
    setIconifiedByDefault(d1.a(8, true));
    paramInt = d1.f(1, -1);
    if (paramInt != -1)
      setMaxWidth(paramInt); 
    this.O = d1.n(6);
    this.b0 = d1.n(11);
    paramInt = d1.j(3, -1);
    if (paramInt != -1)
      setImeOptions(paramInt); 
    paramInt = d1.j(2, -1);
    if (paramInt != -1)
      setInputType(paramInt); 
    setFocusable(d1.a(0, true));
    typedArray.recycle();
    Intent intent = new Intent("android.speech.action.WEB_SEARCH");
    this.M = intent;
    intent.addFlags(268435456);
    intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
    intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
    this.N = intent;
    intent.addFlags(268435456);
    View view1 = findViewById(searchAutoComplete.getDropDownAnchor());
    this.C = view1;
    if (view1 != null)
      view1.addOnLayoutChangeListener(new e(this)); 
    A(this.U);
    x();
  }
  
  private int getPreferredHeight() {
    return getContext().getResources().getDimensionPixelSize(2131099702);
  }
  
  private int getPreferredWidth() {
    return getContext().getResources().getDimensionPixelSize(2131099703);
  }
  
  private void setQuery(CharSequence paramCharSequence) {
    int i;
    this.u.setText(paramCharSequence);
    SearchAutoComplete searchAutoComplete = this.u;
    if (TextUtils.isEmpty(paramCharSequence)) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    searchAutoComplete.setSelection(i);
  }
  
  public final void A(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield V : Z
    //   5: iconst_0
    //   6: istore_3
    //   7: iload_1
    //   8: ifeq -> 16
    //   11: iconst_0
    //   12: istore_2
    //   13: goto -> 19
    //   16: bipush #8
    //   18: istore_2
    //   19: aload_0
    //   20: getfield u : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   23: invokevirtual getText : ()Landroid/text/Editable;
    //   26: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   29: iconst_1
    //   30: ixor
    //   31: istore #4
    //   33: aload_0
    //   34: getfield y : Landroid/widget/ImageView;
    //   37: iload_2
    //   38: invokevirtual setVisibility : (I)V
    //   41: aload_0
    //   42: iload #4
    //   44: invokevirtual z : (Z)V
    //   47: aload_0
    //   48: getfield v : Landroid/view/View;
    //   51: astore #5
    //   53: iload_1
    //   54: ifeq -> 63
    //   57: bipush #8
    //   59: istore_2
    //   60: goto -> 65
    //   63: iconst_0
    //   64: istore_2
    //   65: aload #5
    //   67: iload_2
    //   68: invokevirtual setVisibility : (I)V
    //   71: aload_0
    //   72: getfield I : Landroid/widget/ImageView;
    //   75: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
    //   78: ifnull -> 90
    //   81: iload_3
    //   82: istore_2
    //   83: aload_0
    //   84: getfield U : Z
    //   87: ifeq -> 93
    //   90: bipush #8
    //   92: istore_2
    //   93: aload_0
    //   94: getfield I : Landroid/widget/ImageView;
    //   97: iload_2
    //   98: invokevirtual setVisibility : (I)V
    //   101: aload_0
    //   102: invokevirtual v : ()V
    //   105: aload_0
    //   106: iload #4
    //   108: iconst_1
    //   109: ixor
    //   110: invokevirtual B : (Z)V
    //   113: aload_0
    //   114: invokevirtual y : ()V
    //   117: return
  }
  
  public final void B(boolean paramBoolean) {
    boolean bool = this.f0;
    byte b2 = 8;
    byte b1 = b2;
    if (bool) {
      b1 = b2;
      if (!this.V) {
        b1 = b2;
        if (paramBoolean) {
          this.z.setVisibility(8);
          b1 = 0;
        } 
      } 
    } 
    this.B.setVisibility(b1);
  }
  
  public void c() {
    if (this.i0)
      return; 
    this.i0 = true;
    int i = this.u.getImeOptions();
    this.j0 = i;
    this.u.setImeOptions(i | 0x2000000);
    this.u.setText("");
    setIconified(false);
  }
  
  public void clearFocus() {
    this.d0 = true;
    super.clearFocus();
    this.u.clearFocus();
    this.u.setImeVisibility(false);
    this.d0 = false;
  }
  
  public void e() {
    this.u.setText("");
    SearchAutoComplete searchAutoComplete = this.u;
    searchAutoComplete.setSelection(searchAutoComplete.length());
    this.h0 = "";
    clearFocus();
    A(true);
    this.u.setImeOptions(this.j0);
    this.i0 = false;
  }
  
  public int getImeOptions() {
    return this.u.getImeOptions();
  }
  
  public int getInputType() {
    return this.u.getInputType();
  }
  
  public int getMaxWidth() {
    return this.e0;
  }
  
  public CharSequence getQuery() {
    return (CharSequence)this.u.getText();
  }
  
  public CharSequence getQueryHint() {
    CharSequence charSequence = this.b0;
    if (charSequence != null)
      return charSequence; 
    SearchableInfo searchableInfo = this.k0;
    return (searchableInfo != null && searchableInfo.getHintId() != 0) ? getContext().getText(this.k0.getHintId()) : this.O;
  }
  
  public int getSuggestionCommitIconResId() {
    return this.L;
  }
  
  public int getSuggestionRowLayout() {
    return this.K;
  }
  
  public r0.a getSuggestionsAdapter() {
    return this.W;
  }
  
  public final Intent l(String paramString1, Uri paramUri, String paramString2, String paramString3, int paramInt, String paramString4) {
    Intent intent = new Intent(paramString1);
    intent.addFlags(268435456);
    if (paramUri != null)
      intent.setData(paramUri); 
    intent.putExtra("user_query", this.h0);
    if (paramString3 != null)
      intent.putExtra("query", paramString3); 
    if (paramString2 != null)
      intent.putExtra("intent_extra_data_key", paramString2); 
    Bundle bundle = this.l0;
    if (bundle != null)
      intent.putExtra("app_data", bundle); 
    if (paramInt != 0) {
      intent.putExtra("action_key", paramInt);
      intent.putExtra("action_msg", paramString4);
    } 
    intent.setComponent(this.k0.getSearchActivity());
    return intent;
  }
  
  public final Intent m(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str1;
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    Intent intent1 = new Intent("android.intent.action.SEARCH");
    intent1.setComponent(componentName);
    PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent1, 1107296256);
    Bundle bundle2 = new Bundle();
    Bundle bundle1 = this.l0;
    if (bundle1 != null)
      bundle2.putParcelable("app_data", (Parcelable)bundle1); 
    Intent intent2 = new Intent(paramIntent);
    int i = 1;
    Resources resources = getResources();
    if (paramSearchableInfo.getVoiceLanguageModeId() != 0) {
      str1 = resources.getString(paramSearchableInfo.getVoiceLanguageModeId());
    } else {
      str1 = "free_form";
    } 
    int j = paramSearchableInfo.getVoicePromptTextId();
    String str2 = null;
    if (j != 0) {
      String str = resources.getString(paramSearchableInfo.getVoicePromptTextId());
    } else {
      bundle1 = null;
    } 
    if (paramSearchableInfo.getVoiceLanguageId() != 0) {
      String str = resources.getString(paramSearchableInfo.getVoiceLanguageId());
    } else {
      resources = null;
    } 
    if (paramSearchableInfo.getVoiceMaxResults() != 0)
      i = paramSearchableInfo.getVoiceMaxResults(); 
    intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", str1);
    intent2.putExtra("android.speech.extra.PROMPT", (String)bundle1);
    intent2.putExtra("android.speech.extra.LANGUAGE", (String)resources);
    intent2.putExtra("android.speech.extra.MAX_RESULTS", i);
    if (componentName == null) {
      str1 = str2;
    } else {
      str1 = componentName.flattenToShortString();
    } 
    intent2.putExtra("calling_package", str1);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", (Parcelable)pendingIntent);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle2);
    return intent2;
  }
  
  public void n() {
    if (Build.VERSION.SDK_INT >= 29) {
      this.u.refreshAutoCompleteResults();
      return;
    } 
    n n2 = r0;
    SearchAutoComplete searchAutoComplete = this.u;
    Objects.requireNonNull(n2);
    n.a();
    Method method2 = n2.a;
    if (method2 != null)
      try {
        method2.invoke(searchAutoComplete, new Object[0]);
      } catch (Exception exception) {} 
    n n1 = r0;
    searchAutoComplete = this.u;
    Objects.requireNonNull(n1);
    n.a();
    Method method1 = n1.b;
    if (method1 != null)
      try {
        method1.invoke(searchAutoComplete, new Object[0]);
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public void o(int paramInt, String paramString1, String paramString2) {
    Intent intent = l("android.intent.action.SEARCH", null, null, paramString2, paramInt, null);
    getContext().startActivity(intent);
  }
  
  public void onDetachedFromWindow() {
    removeCallbacks(this.m0);
    post(this.n0);
    super.onDetachedFromWindow();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramBoolean) {
      SearchAutoComplete searchAutoComplete = this.u;
      Rect rect2 = this.E;
      searchAutoComplete.getLocationInWindow(this.G);
      getLocationInWindow(this.H);
      int[] arrayOfInt1 = this.G;
      paramInt1 = arrayOfInt1[1];
      int[] arrayOfInt2 = this.H;
      paramInt1 -= arrayOfInt2[1];
      paramInt3 = arrayOfInt1[0] - arrayOfInt2[0];
      rect2.set(paramInt3, paramInt1, searchAutoComplete.getWidth() + paramInt3, searchAutoComplete.getHeight() + paramInt1);
      Rect rect1 = this.F;
      rect2 = this.E;
      rect1.set(rect2.left, 0, rect2.right, paramInt4 - paramInt2);
      p p1 = this.D;
      if (p1 == null) {
        p1 = new p(this.F, this.E, (View)this.u);
        this.D = p1;
        setTouchDelegate(p1);
        return;
      } 
      p1.a(this.F, this.E);
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.V) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int j = View.MeasureSpec.getMode(paramInt1);
    int i = View.MeasureSpec.getSize(paramInt1);
    if (j != Integer.MIN_VALUE) {
      if (j != 0) {
        if (j != 1073741824) {
          paramInt1 = i;
        } else {
          j = this.e0;
          paramInt1 = i;
          if (j > 0)
            paramInt1 = Math.min(j, i); 
        } 
      } else {
        paramInt1 = this.e0;
        if (paramInt1 <= 0)
          paramInt1 = getPreferredWidth(); 
      } 
    } else {
      paramInt1 = this.e0;
      if (paramInt1 > 0) {
        paramInt1 = Math.min(paramInt1, i);
      } else {
        paramInt1 = Math.min(getPreferredWidth(), i);
      } 
    } 
    i = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (i != Integer.MIN_VALUE) {
      if (i == 0)
        paramInt2 = getPreferredHeight(); 
    } else {
      paramInt2 = Math.min(getPreferredHeight(), paramInt2);
    } 
    super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof o)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    o o = (o)paramParcelable;
    super.onRestoreInstanceState(o.f);
    A(o.h);
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    o o = new o(super.onSaveInstanceState());
    o.h = this.V;
    return (Parcelable)o;
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    post(this.m0);
  }
  
  public void p() {
    if (TextUtils.isEmpty((CharSequence)this.u.getText())) {
      if (this.U) {
        k k1 = this.Q;
        if (k1 == null || !k1.onClose()) {
          clearFocus();
          A(true);
          return;
        } 
      } 
    } else {
      this.u.setText("");
      this.u.requestFocus();
      this.u.setImeVisibility(true);
    } 
  }
  
  public boolean q(int paramInt) {
    Intent intent;
    m m1 = this.S;
    if (m1 == null || !m1.b(paramInt)) {
      Uri uri;
      String str2;
      Cursor cursor = this.W.h;
      if (cursor != null && cursor.moveToPosition(paramInt)) {
        RuntimeException runtimeException = null;
        try {
          paramInt = x0.D;
          str2 = x0.j(cursor, cursor.getColumnIndex("suggest_intent_action"));
          String str = str2;
          if (str2 == null)
            str = this.k0.getSuggestIntentAction(); 
        } catch (RuntimeException runtimeException1) {
          try {
            paramInt = cursor.getPosition();
          } catch (RuntimeException runtimeException3) {
            paramInt = -1;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Search suggestions cursor at row ");
          stringBuilder.append(paramInt);
          stringBuilder.append(" returned exception.");
          Log.w("SearchView", stringBuilder.toString(), runtimeException1);
          runtimeException1 = runtimeException;
          if (runtimeException1 != null)
            try {
              getContext().startActivity((Intent)runtimeException1);
            } catch (RuntimeException runtimeException3) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Failed launch activity: ");
              stringBuilder1.append(runtimeException1);
              Log.e("SearchView", stringBuilder1.toString(), runtimeException3);
            }  
          this.u.setImeVisibility(false);
          this.u.dismissDropDown();
          return true;
        } 
      } else {
        this.u.setImeVisibility(false);
        this.u.dismissDropDown();
        return true;
      } 
      RuntimeException runtimeException2 = runtimeException1;
      if (runtimeException1 == null)
        str2 = "android.intent.action.SEARCH"; 
      String str3 = x0.j(cursor, cursor.getColumnIndex("suggest_intent_data"));
      String str1 = str3;
      if (str3 == null)
        str1 = this.k0.getSuggestIntentData(); 
      str3 = str1;
      if (str1 != null) {
        String str = x0.j(cursor, cursor.getColumnIndex("suggest_intent_data_id"));
        str3 = str1;
        if (str != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("/");
          stringBuilder.append(Uri.encode(str));
          str3 = stringBuilder.toString();
        } 
      } 
      if (str3 == null) {
        str1 = null;
      } else {
        uri = Uri.parse(str3);
      } 
      str3 = x0.j(cursor, cursor.getColumnIndex("suggest_intent_query"));
      intent = l(str2, uri, x0.j(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), str3, 0, null);
    } else {
      return false;
    } 
    if (intent != null)
      try {
        getContext().startActivity(intent);
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed launch activity: ");
        stringBuilder.append(intent);
        Log.e("SearchView", stringBuilder.toString(), runtimeException);
      }  
    this.u.setImeVisibility(false);
    this.u.dismissDropDown();
    return true;
  }
  
  public boolean r(int paramInt) {
    m m1 = this.S;
    if (m1 == null || !m1.a(paramInt)) {
      Editable editable = this.u.getText();
      Cursor cursor = this.W.h;
      if (cursor != null)
        if (cursor.moveToPosition(paramInt)) {
          CharSequence charSequence = this.W.d(cursor);
          if (charSequence != null) {
            setQuery(charSequence);
          } else {
            setQuery((CharSequence)editable);
          } 
        } else {
          setQuery((CharSequence)editable);
        }  
      return true;
    } 
    return false;
  }
  
  public boolean requestFocus(int paramInt, Rect paramRect) {
    if (this.d0)
      return false; 
    if (!isFocusable())
      return false; 
    if (!this.V) {
      boolean bool = this.u.requestFocus(paramInt, paramRect);
      if (bool)
        A(false); 
      return bool;
    } 
    return super.requestFocus(paramInt, paramRect);
  }
  
  public void s(CharSequence paramCharSequence) {
    setQuery(paramCharSequence);
  }
  
  public void setAppSearchData(Bundle paramBundle) {
    this.l0 = paramBundle;
  }
  
  public void setIconified(boolean paramBoolean) {
    if (paramBoolean) {
      p();
      return;
    } 
    t();
  }
  
  public void setIconifiedByDefault(boolean paramBoolean) {
    if (this.U == paramBoolean)
      return; 
    this.U = paramBoolean;
    A(paramBoolean);
    x();
  }
  
  public void setImeOptions(int paramInt) {
    this.u.setImeOptions(paramInt);
  }
  
  public void setInputType(int paramInt) {
    this.u.setInputType(paramInt);
  }
  
  public void setMaxWidth(int paramInt) {
    this.e0 = paramInt;
    requestLayout();
  }
  
  public void setOnCloseListener(k paramk) {
    this.Q = paramk;
  }
  
  public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener paramOnFocusChangeListener) {
    this.R = paramOnFocusChangeListener;
  }
  
  public void setOnQueryTextListener(l paraml) {
    this.P = paraml;
  }
  
  public void setOnSearchClickListener(View.OnClickListener paramOnClickListener) {
    this.T = paramOnClickListener;
  }
  
  public void setOnSuggestionListener(m paramm) {
    this.S = paramm;
  }
  
  public void setQueryHint(CharSequence paramCharSequence) {
    this.b0 = paramCharSequence;
    x();
  }
  
  public void setQueryRefinementEnabled(boolean paramBoolean) {
    this.c0 = paramBoolean;
    r0.a a1 = this.W;
    if (a1 instanceof x0) {
      boolean bool;
      x0 x0 = (x0)a1;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = true;
      } 
      x0.v = bool;
    } 
  }
  
  public void setSearchableInfo(SearchableInfo paramSearchableInfo) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield k0 : Landroid/app/SearchableInfo;
    //   5: iconst_1
    //   6: istore #4
    //   8: aconst_null
    //   9: astore #5
    //   11: aload_1
    //   12: ifnull -> 183
    //   15: aload_0
    //   16: getfield u : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   19: aload_1
    //   20: invokevirtual getSuggestThreshold : ()I
    //   23: invokevirtual setThreshold : (I)V
    //   26: aload_0
    //   27: getfield u : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   30: aload_0
    //   31: getfield k0 : Landroid/app/SearchableInfo;
    //   34: invokevirtual getImeOptions : ()I
    //   37: invokevirtual setImeOptions : (I)V
    //   40: aload_0
    //   41: getfield k0 : Landroid/app/SearchableInfo;
    //   44: invokevirtual getInputType : ()I
    //   47: istore_3
    //   48: iload_3
    //   49: istore_2
    //   50: iload_3
    //   51: bipush #15
    //   53: iand
    //   54: iconst_1
    //   55: if_icmpne -> 86
    //   58: iload_3
    //   59: ldc_w -65537
    //   62: iand
    //   63: istore_3
    //   64: iload_3
    //   65: istore_2
    //   66: aload_0
    //   67: getfield k0 : Landroid/app/SearchableInfo;
    //   70: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   73: ifnull -> 86
    //   76: iload_3
    //   77: ldc_w 65536
    //   80: ior
    //   81: ldc_w 524288
    //   84: ior
    //   85: istore_2
    //   86: aload_0
    //   87: getfield u : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   90: iload_2
    //   91: invokevirtual setInputType : (I)V
    //   94: aload_0
    //   95: getfield W : Lr0/a;
    //   98: astore_1
    //   99: aload_1
    //   100: ifnull -> 108
    //   103: aload_1
    //   104: aconst_null
    //   105: invokevirtual c : (Landroid/database/Cursor;)V
    //   108: aload_0
    //   109: getfield k0 : Landroid/app/SearchableInfo;
    //   112: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   115: ifnull -> 179
    //   118: new androidx/appcompat/widget/x0
    //   121: dup
    //   122: aload_0
    //   123: invokevirtual getContext : ()Landroid/content/Context;
    //   126: aload_0
    //   127: aload_0
    //   128: getfield k0 : Landroid/app/SearchableInfo;
    //   131: aload_0
    //   132: getfield o0 : Ljava/util/WeakHashMap;
    //   135: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/SearchView;Landroid/app/SearchableInfo;Ljava/util/WeakHashMap;)V
    //   138: astore_1
    //   139: aload_0
    //   140: aload_1
    //   141: putfield W : Lr0/a;
    //   144: aload_0
    //   145: getfield u : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   148: aload_1
    //   149: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   152: aload_0
    //   153: getfield W : Lr0/a;
    //   156: checkcast androidx/appcompat/widget/x0
    //   159: astore_1
    //   160: aload_0
    //   161: getfield c0 : Z
    //   164: ifeq -> 172
    //   167: iconst_2
    //   168: istore_2
    //   169: goto -> 174
    //   172: iconst_1
    //   173: istore_2
    //   174: aload_1
    //   175: iload_2
    //   176: putfield v : I
    //   179: aload_0
    //   180: invokevirtual x : ()V
    //   183: aload_0
    //   184: getfield k0 : Landroid/app/SearchableInfo;
    //   187: astore_1
    //   188: aload_1
    //   189: ifnull -> 259
    //   192: aload_1
    //   193: invokevirtual getVoiceSearchEnabled : ()Z
    //   196: ifeq -> 259
    //   199: aload_0
    //   200: getfield k0 : Landroid/app/SearchableInfo;
    //   203: invokevirtual getVoiceSearchLaunchWebSearch : ()Z
    //   206: ifeq -> 217
    //   209: aload_0
    //   210: getfield M : Landroid/content/Intent;
    //   213: astore_1
    //   214: goto -> 235
    //   217: aload #5
    //   219: astore_1
    //   220: aload_0
    //   221: getfield k0 : Landroid/app/SearchableInfo;
    //   224: invokevirtual getVoiceSearchLaunchRecognizer : ()Z
    //   227: ifeq -> 235
    //   230: aload_0
    //   231: getfield N : Landroid/content/Intent;
    //   234: astore_1
    //   235: aload_1
    //   236: ifnull -> 259
    //   239: aload_0
    //   240: invokevirtual getContext : ()Landroid/content/Context;
    //   243: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   246: aload_1
    //   247: ldc_w 65536
    //   250: invokevirtual resolveActivity : (Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;
    //   253: ifnull -> 259
    //   256: goto -> 262
    //   259: iconst_0
    //   260: istore #4
    //   262: aload_0
    //   263: iload #4
    //   265: putfield f0 : Z
    //   268: iload #4
    //   270: ifeq -> 283
    //   273: aload_0
    //   274: getfield u : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   277: ldc_w 'nm'
    //   280: invokevirtual setPrivateImeOptions : (Ljava/lang/String;)V
    //   283: aload_0
    //   284: aload_0
    //   285: getfield V : Z
    //   288: invokevirtual A : (Z)V
    //   291: return
  }
  
  public void setSubmitButtonEnabled(boolean paramBoolean) {
    this.a0 = paramBoolean;
    A(this.V);
  }
  
  public void setSuggestionsAdapter(r0.a parama) {
    this.W = parama;
    this.u.setAdapter((ListAdapter)parama);
  }
  
  public void t() {
    A(false);
    this.u.requestFocus();
    this.u.setImeVisibility(true);
    View.OnClickListener onClickListener = this.T;
    if (onClickListener != null)
      onClickListener.onClick((View)this); 
  }
  
  public void u() {
    Editable editable = this.u.getText();
    if (editable != null && TextUtils.getTrimmedLength((CharSequence)editable) > 0) {
      l l1 = this.P;
      if (l1 == null || !l1.b(editable.toString())) {
        if (this.k0 != null)
          o(0, null, editable.toString()); 
        this.u.setImeVisibility(false);
        this.u.dismissDropDown();
      } 
    } 
  }
  
  public final void v() {
    boolean bool = TextUtils.isEmpty((CharSequence)this.u.getText());
    byte b3 = 1;
    int i = bool ^ true;
    byte b2 = 0;
    byte b1 = b3;
    if (i == 0)
      if (this.U && !this.i0) {
        b1 = b3;
      } else {
        b1 = 0;
      }  
    ImageView imageView = this.A;
    if (b1) {
      b1 = b2;
    } else {
      b1 = 8;
    } 
    imageView.setVisibility(b1);
    Drawable drawable = this.A.getDrawable();
    if (drawable != null) {
      int[] arrayOfInt;
      if (i != 0) {
        arrayOfInt = ViewGroup.ENABLED_STATE_SET;
      } else {
        arrayOfInt = ViewGroup.EMPTY_STATE_SET;
      } 
      drawable.setState(arrayOfInt);
    } 
  }
  
  public void w() {
    int[] arrayOfInt;
    if (this.u.hasFocus()) {
      arrayOfInt = ViewGroup.FOCUSED_STATE_SET;
    } else {
      arrayOfInt = ViewGroup.EMPTY_STATE_SET;
    } 
    Drawable drawable = this.w.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    drawable = this.x.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    invalidate();
  }
  
  public final void x() {
    SpannableStringBuilder spannableStringBuilder;
    CharSequence charSequence2 = getQueryHint();
    SearchAutoComplete searchAutoComplete = this.u;
    CharSequence charSequence1 = charSequence2;
    if (charSequence2 == null)
      charSequence1 = ""; 
    charSequence2 = charSequence1;
    if (this.U)
      if (this.J == null) {
        charSequence2 = charSequence1;
      } else {
        double d = searchAutoComplete.getTextSize();
        Double.isNaN(d);
        Double.isNaN(d);
        int i = (int)(d * 1.25D);
        this.J.setBounds(0, 0, i, i);
        spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(this.J), 1, 2, 33);
        spannableStringBuilder.append(charSequence1);
      }  
    searchAutoComplete.setHint((CharSequence)spannableStringBuilder);
  }
  
  public final void y() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a0 : Z
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_3
    //   8: ifne -> 18
    //   11: aload_0
    //   12: getfield f0 : Z
    //   15: ifeq -> 30
    //   18: aload_0
    //   19: getfield V : Z
    //   22: ifne -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 63
    //   36: iload_2
    //   37: istore_1
    //   38: aload_0
    //   39: getfield z : Landroid/widget/ImageView;
    //   42: invokevirtual getVisibility : ()I
    //   45: ifeq -> 66
    //   48: aload_0
    //   49: getfield B : Landroid/widget/ImageView;
    //   52: invokevirtual getVisibility : ()I
    //   55: ifne -> 63
    //   58: iload_2
    //   59: istore_1
    //   60: goto -> 66
    //   63: bipush #8
    //   65: istore_1
    //   66: aload_0
    //   67: getfield x : Landroid/view/View;
    //   70: iload_1
    //   71: invokevirtual setVisibility : (I)V
    //   74: return
  }
  
  public final void z(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a0 : Z
    //   4: istore #4
    //   6: iconst_0
    //   7: istore_3
    //   8: iload #4
    //   10: ifeq -> 68
    //   13: iload #4
    //   15: ifne -> 25
    //   18: aload_0
    //   19: getfield f0 : Z
    //   22: ifeq -> 37
    //   25: aload_0
    //   26: getfield V : Z
    //   29: ifne -> 37
    //   32: iconst_1
    //   33: istore_2
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_2
    //   39: iload_2
    //   40: ifeq -> 68
    //   43: aload_0
    //   44: invokevirtual hasFocus : ()Z
    //   47: ifeq -> 68
    //   50: iload_3
    //   51: istore_2
    //   52: iload_1
    //   53: ifne -> 71
    //   56: aload_0
    //   57: getfield f0 : Z
    //   60: ifne -> 68
    //   63: iload_3
    //   64: istore_2
    //   65: goto -> 71
    //   68: bipush #8
    //   70: istore_2
    //   71: aload_0
    //   72: getfield z : Landroid/widget/ImageView;
    //   75: iload_2
    //   76: invokevirtual setVisibility : (I)V
    //   79: return
  }
  
  public static class SearchAutoComplete extends e {
    public int j = getThreshold();
    
    public SearchView k;
    
    public boolean l;
    
    public final Runnable m = new a(this);
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet, 2130903096);
    }
    
    private int getSearchViewTextMinWidthDp() {
      Configuration configuration = getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      return (i >= 960 && j >= 720 && configuration.orientation == 2) ? 256 : ((i >= 600 || (i >= 640 && j >= 480)) ? 192 : 160);
    }
    
    public void a() {
      if (Build.VERSION.SDK_INT >= 29) {
        setInputMethodMode(1);
        if (enoughToFilter()) {
          showDropDown();
          return;
        } 
      } else {
        SearchView.n n = SearchView.r0;
        Objects.requireNonNull(n);
        SearchView.n.a();
        Method method = n.c;
        if (method != null)
          try {
            method.invoke(this, new Object[] { Boolean.TRUE });
            return;
          } catch (Exception exception) {
            return;
          }  
      } 
    }
    
    public boolean enoughToFilter() {
      return (this.j <= 0 || super.enoughToFilter());
    }
    
    public InputConnection onCreateInputConnection(EditorInfo param1EditorInfo) {
      InputConnection inputConnection = super.onCreateInputConnection(param1EditorInfo);
      if (this.l) {
        removeCallbacks(this.m);
        post(this.m);
      } 
      return inputConnection;
    }
    
    public void onFinishInflate() {
      super.onFinishInflate();
      DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
      setMinWidth((int)TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), displayMetrics));
    }
    
    public void onFocusChanged(boolean param1Boolean, int param1Int, Rect param1Rect) {
      super.onFocusChanged(param1Boolean, param1Int, param1Rect);
      SearchView searchView = this.k;
      searchView.A(searchView.V);
      searchView.post(searchView.m0);
      if (searchView.u.hasFocus())
        searchView.n(); 
    }
    
    public boolean onKeyPreIme(int param1Int, KeyEvent param1KeyEvent) {
      if (param1Int == 4) {
        if (param1KeyEvent.getAction() == 0 && param1KeyEvent.getRepeatCount() == 0) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.startTracking(param1KeyEvent, this); 
          return true;
        } 
        if (param1KeyEvent.getAction() == 1) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.handleUpEvent(param1KeyEvent); 
          if (param1KeyEvent.isTracking() && !param1KeyEvent.isCanceled()) {
            this.k.clearFocus();
            setImeVisibility(false);
            return true;
          } 
        } 
      } 
      return super.onKeyPreIme(param1Int, param1KeyEvent);
    }
    
    public void onWindowFocusChanged(boolean param1Boolean) {
      super.onWindowFocusChanged(param1Boolean);
      if (param1Boolean && this.k.hasFocus() && getVisibility() == 0) {
        boolean bool = true;
        this.l = true;
        Context context = getContext();
        SearchView.n n = SearchView.r0;
        if ((context.getResources().getConfiguration()).orientation != 2)
          bool = false; 
        if (bool)
          a(); 
      } 
    }
    
    public void performCompletion() {}
    
    public void replaceText(CharSequence param1CharSequence) {}
    
    public void setImeVisibility(boolean param1Boolean) {
      InputMethodManager inputMethodManager = (InputMethodManager)getContext().getSystemService("input_method");
      if (!param1Boolean) {
        this.l = false;
        removeCallbacks(this.m);
        inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        return;
      } 
      if (inputMethodManager.isActive((View)this)) {
        this.l = false;
        removeCallbacks(this.m);
        inputMethodManager.showSoftInput((View)this, 0);
        return;
      } 
      this.l = true;
    }
    
    public void setSearchView(SearchView param1SearchView) {
      this.k = param1SearchView;
    }
    
    public void setThreshold(int param1Int) {
      super.setThreshold(param1Int);
      this.j = param1Int;
    }
    
    public class a implements Runnable {
      public a(SearchView.SearchAutoComplete this$0) {}
      
      public void run() {
        SearchView.SearchAutoComplete searchAutoComplete = this.f;
        if (searchAutoComplete.l) {
          ((InputMethodManager)searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput((View)searchAutoComplete, 0);
          searchAutoComplete.l = false;
        } 
      }
    }
  }
  
  public class a implements Runnable {
    public a(SearchView this$0) {}
    
    public void run() {
      SearchView.SearchAutoComplete searchAutoComplete = this.f;
      if (searchAutoComplete.l) {
        ((InputMethodManager)searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput((View)searchAutoComplete, 0);
        searchAutoComplete.l = false;
      } 
    }
  }
  
  public class a implements TextWatcher {
    public a(SearchView this$0) {}
    
    public void afterTextChanged(Editable param1Editable) {}
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      SearchView searchView = this.f;
      Editable editable = searchView.u.getText();
      searchView.h0 = (CharSequence)editable;
      int i = TextUtils.isEmpty((CharSequence)editable) ^ true;
      searchView.z(i);
      searchView.B(i ^ 0x1);
      searchView.v();
      searchView.y();
      if (searchView.P != null && !TextUtils.equals(param1CharSequence, searchView.g0))
        searchView.P.a(param1CharSequence.toString()); 
      searchView.g0 = param1CharSequence.toString();
    }
  }
  
  public class b implements Runnable {
    public b(SearchView this$0) {}
    
    public void run() {
      this.f.w();
    }
  }
  
  public class c implements Runnable {
    public c(SearchView this$0) {}
    
    public void run() {
      r0.a a = this.f.W;
      if (a instanceof x0)
        a.c(null); 
    }
  }
  
  public class d implements View.OnFocusChangeListener {
    public d(SearchView this$0) {}
    
    public void onFocusChange(View param1View, boolean param1Boolean) {
      SearchView searchView = this.a;
      View.OnFocusChangeListener onFocusChangeListener = searchView.R;
      if (onFocusChangeListener != null)
        onFocusChangeListener.onFocusChange((View)searchView, param1Boolean); 
    }
  }
  
  public class e implements View.OnLayoutChangeListener {
    public e(SearchView this$0) {}
    
    public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      SearchView searchView = this.a;
      if (searchView.C.getWidth() > 1) {
        Resources resources = searchView.getContext().getResources();
        param1Int3 = searchView.w.getPaddingLeft();
        Rect rect = new Rect();
        boolean bool = l1.b((View)searchView);
        if (searchView.U) {
          param1Int1 = resources.getDimensionPixelSize(2131099689);
          param1Int1 = resources.getDimensionPixelSize(2131099690) + param1Int1;
        } else {
          param1Int1 = 0;
        } 
        searchView.u.getDropDownBackground().getPadding(rect);
        if (bool) {
          param1Int2 = -rect.left;
        } else {
          param1Int2 = param1Int3 - rect.left + param1Int1;
        } 
        searchView.u.setDropDownHorizontalOffset(param1Int2);
        param1Int2 = searchView.C.getWidth();
        param1Int4 = rect.left;
        param1Int5 = rect.right;
        searchView.u.setDropDownWidth(param1Int2 + param1Int4 + param1Int5 + param1Int1 - param1Int3);
      } 
    }
  }
  
  public class f implements View.OnClickListener {
    public f(SearchView this$0) {}
    
    public void onClick(View param1View) {
      SearchView searchView = this.f;
      if (param1View == searchView.y) {
        searchView.t();
        return;
      } 
      if (param1View == searchView.A) {
        searchView.p();
        return;
      } 
      if (param1View == searchView.z) {
        searchView.u();
        return;
      } 
      if (param1View == searchView.B) {
        SearchableInfo searchableInfo = searchView.k0;
        if (searchableInfo == null)
          return; 
        try {
          String str;
          if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
            Intent intent = new Intent(searchView.M);
            ComponentName componentName = searchableInfo.getSearchActivity();
            if (componentName == null) {
              componentName = null;
            } else {
              str = componentName.flattenToShortString();
            } 
            intent.putExtra("calling_package", str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          if (str.getVoiceSearchLaunchRecognizer()) {
            Intent intent = searchView.m(searchView.N, (SearchableInfo)str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          return;
        } catch (ActivityNotFoundException activityNotFoundException) {
          Log.w("SearchView", "Could not find voice search activity");
          return;
        } 
      } 
      if (activityNotFoundException == searchView.u)
        searchView.n(); 
    }
  }
  
  public class g implements View.OnKeyListener {
    public g(SearchView this$0) {}
    
    public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
      SearchView searchView1;
      boolean bool;
      SearchView searchView2 = this.f;
      SearchableInfo searchableInfo = searchView2.k0;
      boolean bool1 = false;
      if (searchableInfo == null)
        return false; 
      if (searchView2.u.isPopupShowing() && this.f.u.getListSelection() != -1) {
        searchView1 = this.f;
        if (searchView1.k0 == null)
          return false; 
        if (searchView1.W == null)
          return false; 
        boolean bool2 = bool1;
        if (param1KeyEvent.getAction() == 0) {
          bool2 = bool1;
          if (param1KeyEvent.hasNoModifiers()) {
            if (param1Int == 66 || param1Int == 84 || param1Int == 61)
              return searchView1.q(searchView1.u.getListSelection()); 
            if (param1Int == 21 || param1Int == 22) {
              if (param1Int == 21) {
                param1Int = 0;
              } else {
                param1Int = searchView1.u.length();
              } 
              searchView1.u.setSelection(param1Int);
              searchView1.u.setListSelection(0);
              searchView1.u.clearListSelection();
              searchView1.u.a();
              return true;
            } 
            bool2 = bool1;
            if (param1Int == 19) {
              searchView1.u.getListSelection();
              return false;
            } 
          } 
        } 
        return bool2;
      } 
      if (TextUtils.getTrimmedLength((CharSequence)this.f.u.getText()) == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool && param1KeyEvent.hasNoModifiers() && param1KeyEvent.getAction() == 1 && param1Int == 66) {
        searchView1.cancelLongPress();
        searchView1 = this.f;
        searchView1.o(0, null, searchView1.u.getText().toString());
        return true;
      } 
      return false;
    }
  }
  
  public class h implements TextView.OnEditorActionListener {
    public h(SearchView this$0) {}
    
    public boolean onEditorAction(TextView param1TextView, int param1Int, KeyEvent param1KeyEvent) {
      this.f.u();
      return true;
    }
  }
  
  public class i implements AdapterView.OnItemClickListener {
    public i(SearchView this$0) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.f.q(param1Int);
    }
  }
  
  public class j implements AdapterView.OnItemSelectedListener {
    public j(SearchView this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.f.r(param1Int);
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  public static interface k {
    boolean onClose();
  }
  
  public static interface l {
    boolean a(String param1String);
    
    boolean b(String param1String);
  }
  
  public static interface m {
    boolean a(int param1Int);
    
    boolean b(int param1Int);
  }
  
  public static class n {
    public Method a = null;
    
    public Method b = null;
    
    public Method c = null;
    
    @SuppressLint({"DiscouragedPrivateApi", "SoonBlockedPrivateApi"})
    public n() {
      a();
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
        this.a = method;
        method.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
        this.b = method;
        method.setAccessible(true);
        try {
          method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException) {}
      } catch (NoSuchMethodException noSuchMethodException) {
        try {
          Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException1) {}
      } 
    }
    
    public static void a() {
      if (Build.VERSION.SDK_INT < 29)
        return; 
      throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
    }
  }
  
  public static class o extends s0.a {
    public static final Parcelable.Creator<o> CREATOR = (Parcelable.Creator<o>)new a();
    
    public boolean h;
    
    public o(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.h = ((Boolean)param1Parcel.readValue(null)).booleanValue();
    }
    
    public o(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.a.a("SearchView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" isIconified=");
      stringBuilder.append(this.h);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeParcelable(this.f, param1Int);
      param1Parcel.writeValue(Boolean.valueOf(this.h));
    }
    
    public class a implements Parcelable.ClassLoaderCreator<o> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new SearchView.o(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new SearchView.o(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new SearchView.o[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.ClassLoaderCreator<o> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new SearchView.o(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new SearchView.o(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new SearchView.o[param1Int];
    }
  }
  
  public static class p extends TouchDelegate {
    public final View a;
    
    public final Rect b;
    
    public final Rect c;
    
    public final Rect d;
    
    public final int e;
    
    public boolean f;
    
    public p(Rect param1Rect1, Rect param1Rect2, View param1View) {
      super(param1Rect1, param1View);
      this.e = ViewConfiguration.get(param1View.getContext()).getScaledTouchSlop();
      this.b = new Rect();
      this.d = new Rect();
      this.c = new Rect();
      a(param1Rect1, param1Rect2);
      this.a = param1View;
    }
    
    public void a(Rect param1Rect1, Rect param1Rect2) {
      this.b.set(param1Rect1);
      this.d.set(param1Rect1);
      param1Rect1 = this.d;
      int i = this.e;
      param1Rect1.inset(-i, -i);
      this.c.set(param1Rect2);
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getX : ()F
      //   4: f2i
      //   5: istore_3
      //   6: aload_1
      //   7: invokevirtual getY : ()F
      //   10: f2i
      //   11: istore #4
      //   13: aload_1
      //   14: invokevirtual getAction : ()I
      //   17: istore_2
      //   18: iconst_1
      //   19: istore #5
      //   21: iconst_0
      //   22: istore #7
      //   24: iload_2
      //   25: ifeq -> 106
      //   28: iload_2
      //   29: iconst_1
      //   30: if_icmpeq -> 60
      //   33: iload_2
      //   34: iconst_2
      //   35: if_icmpeq -> 60
      //   38: iload_2
      //   39: iconst_3
      //   40: if_icmpeq -> 46
      //   43: goto -> 127
      //   46: aload_0
      //   47: getfield f : Z
      //   50: istore #5
      //   52: aload_0
      //   53: iconst_0
      //   54: putfield f : Z
      //   57: goto -> 101
      //   60: aload_0
      //   61: getfield f : Z
      //   64: istore #6
      //   66: iload #6
      //   68: istore #5
      //   70: iload #6
      //   72: ifeq -> 101
      //   75: iload #6
      //   77: istore #5
      //   79: aload_0
      //   80: getfield d : Landroid/graphics/Rect;
      //   83: iload_3
      //   84: iload #4
      //   86: invokevirtual contains : (II)Z
      //   89: ifne -> 101
      //   92: iload #6
      //   94: istore #5
      //   96: iconst_0
      //   97: istore_2
      //   98: goto -> 132
      //   101: iconst_1
      //   102: istore_2
      //   103: goto -> 132
      //   106: aload_0
      //   107: getfield b : Landroid/graphics/Rect;
      //   110: iload_3
      //   111: iload #4
      //   113: invokevirtual contains : (II)Z
      //   116: ifeq -> 127
      //   119: aload_0
      //   120: iconst_1
      //   121: putfield f : Z
      //   124: goto -> 101
      //   127: iconst_1
      //   128: istore_2
      //   129: iconst_0
      //   130: istore #5
      //   132: iload #7
      //   134: istore #6
      //   136: iload #5
      //   138: ifeq -> 222
      //   141: iload_2
      //   142: ifeq -> 185
      //   145: aload_0
      //   146: getfield c : Landroid/graphics/Rect;
      //   149: iload_3
      //   150: iload #4
      //   152: invokevirtual contains : (II)Z
      //   155: ifne -> 185
      //   158: aload_1
      //   159: aload_0
      //   160: getfield a : Landroid/view/View;
      //   163: invokevirtual getWidth : ()I
      //   166: iconst_2
      //   167: idiv
      //   168: i2f
      //   169: aload_0
      //   170: getfield a : Landroid/view/View;
      //   173: invokevirtual getHeight : ()I
      //   176: iconst_2
      //   177: idiv
      //   178: i2f
      //   179: invokevirtual setLocation : (FF)V
      //   182: goto -> 212
      //   185: aload_0
      //   186: getfield c : Landroid/graphics/Rect;
      //   189: astore #8
      //   191: aload_1
      //   192: iload_3
      //   193: aload #8
      //   195: getfield left : I
      //   198: isub
      //   199: i2f
      //   200: iload #4
      //   202: aload #8
      //   204: getfield top : I
      //   207: isub
      //   208: i2f
      //   209: invokevirtual setLocation : (FF)V
      //   212: aload_0
      //   213: getfield a : Landroid/view/View;
      //   216: aload_1
      //   217: invokevirtual dispatchTouchEvent : (Landroid/view/MotionEvent;)Z
      //   220: istore #6
      //   222: iload #6
      //   224: ireturn
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\SearchView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */