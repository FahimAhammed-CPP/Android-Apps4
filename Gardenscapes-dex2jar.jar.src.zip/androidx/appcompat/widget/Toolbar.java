package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.l;
import e.i;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.WeakHashMap;
import m0.h;
import m0.y;

public class Toolbar extends ViewGroup {
  public int A;
  
  public int B = 8388627;
  
  public CharSequence C;
  
  public CharSequence D;
  
  public ColorStateList E;
  
  public ColorStateList F;
  
  public boolean G;
  
  public boolean H;
  
  public final ArrayList<View> I = new ArrayList<View>();
  
  public final ArrayList<View> J = new ArrayList<View>();
  
  public final int[] K = new int[2];
  
  public final m0.g L = new m0.g(new e1(this));
  
  public ArrayList<MenuItem> M = new ArrayList<MenuItem>();
  
  public f N;
  
  public final ActionMenuView.e O = new a(this);
  
  public g1 P;
  
  public c Q;
  
  public d R;
  
  public i.a S;
  
  public androidx.appcompat.view.menu.e.a T;
  
  public boolean U;
  
  public final Runnable V = new b(this);
  
  public ActionMenuView f;
  
  public TextView g;
  
  public TextView h;
  
  public ImageButton i;
  
  public ImageView j;
  
  public Drawable k;
  
  public CharSequence l;
  
  public ImageButton m;
  
  public View n;
  
  public Context o;
  
  public int p;
  
  public int q;
  
  public int r;
  
  public int s;
  
  public int t;
  
  public int u;
  
  public int v;
  
  public int w;
  
  public int x;
  
  public u0 y;
  
  public int z;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130904020);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = i.x;
    d1 d1 = d1.q(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    y.z((View)this, paramContext, arrayOfInt, paramAttributeSet, d1.b, paramInt, 0);
    this.q = d1.l(28, 0);
    this.r = d1.l(19, 0);
    paramInt = this.B;
    this.B = d1.b.getInteger(0, paramInt);
    this.s = d1.b.getInteger(2, 48);
    int i = d1.e(22, 0);
    paramInt = i;
    if (d1.o(27))
      paramInt = d1.e(27, i); 
    this.x = paramInt;
    this.w = paramInt;
    this.v = paramInt;
    this.u = paramInt;
    paramInt = d1.e(25, -1);
    if (paramInt >= 0)
      this.u = paramInt; 
    paramInt = d1.e(24, -1);
    if (paramInt >= 0)
      this.v = paramInt; 
    paramInt = d1.e(26, -1);
    if (paramInt >= 0)
      this.w = paramInt; 
    paramInt = d1.e(23, -1);
    if (paramInt >= 0)
      this.x = paramInt; 
    this.t = d1.f(13, -1);
    paramInt = d1.e(9, -2147483648);
    i = d1.e(5, -2147483648);
    int j = d1.f(7, 0);
    int k = d1.f(8, 0);
    d();
    u0 u01 = this.y;
    u01.h = false;
    if (j != Integer.MIN_VALUE) {
      u01.e = j;
      u01.a = j;
    } 
    if (k != Integer.MIN_VALUE) {
      u01.f = k;
      u01.b = k;
    } 
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      u01.a(paramInt, i); 
    this.z = d1.e(10, -2147483648);
    this.A = d1.e(6, -2147483648);
    this.k = d1.g(4);
    this.l = d1.n(3);
    CharSequence charSequence3 = d1.n(21);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = d1.n(18);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.o = getContext();
    setPopupTheme(d1.l(17, 0));
    Drawable drawable2 = d1.g(16);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = d1.n(15);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = d1.g(11);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = d1.n(12);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    if (d1.o(29))
      setTitleTextColor(d1.c(29)); 
    if (d1.o(20))
      setSubtitleTextColor(d1.c(20)); 
    if (d1.o(14)) {
      paramInt = d1.l(14, 0);
      getMenuInflater().inflate(paramInt, getMenu());
    } 
    d1.b.recycle();
  }
  
  private ArrayList<MenuItem> getCurrentMenuItems() {
    ArrayList<MenuItem> arrayList = new ArrayList();
    Menu menu = getMenu();
    for (int i = 0; i < menu.size(); i++)
      arrayList.add(menu.getItem(i)); 
    return arrayList;
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new j.g(getContext());
  }
  
  public final void a(List<View> paramList, int paramInt) {
    WeakHashMap weakHashMap = y.a;
    int i = y.e.d((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = Gravity.getAbsoluteGravity(paramInt, y.e.d((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && v(view) && j(e1.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && v(view) && j(e1.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  public final void b(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = h();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = i((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.n != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.J.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  public void c() {
    if (this.m == null) {
      o o = new o(getContext(), null, 2130904019);
      this.m = o;
      o.setImageDrawable(this.k);
      this.m.setContentDescription(this.l);
      e e1 = h();
      e1.a = 0x800003 | this.s & 0x70;
      e1.b = 2;
      this.m.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.m.setOnClickListener(new c(this));
    } 
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public final void d() {
    if (this.y == null)
      this.y = new u0(); 
  }
  
  public final void e() {
    f();
    ActionMenuView actionMenuView = this.f;
    if (actionMenuView.u == null) {
      androidx.appcompat.view.menu.e e1 = (androidx.appcompat.view.menu.e)actionMenuView.getMenu();
      if (this.R == null)
        this.R = new d(this); 
      this.f.setExpandedActionViewsExclusive(true);
      e1.b(this.R, this.o);
    } 
  }
  
  public final void f() {
    if (this.f == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
      this.f = actionMenuView;
      actionMenuView.setPopupTheme(this.p);
      this.f.setOnMenuItemClickListener(this.O);
      actionMenuView = this.f;
      i.a a1 = this.S;
      androidx.appcompat.view.menu.e.a a2 = this.T;
      actionMenuView.z = a1;
      actionMenuView.A = a2;
      e e1 = h();
      e1.a = 0x800005 | this.s & 0x70;
      this.f.setLayoutParams((ViewGroup.LayoutParams)e1);
      b((View)this.f, false);
    } 
  }
  
  public final void g() {
    if (this.i == null) {
      this.i = new o(getContext(), null, 2130904019);
      e e1 = h();
      e1.a = 0x800003 | this.s & 0x70;
      this.i.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new e(getContext(), paramAttributeSet);
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.m;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.m;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    u0 u01 = this.y;
    return (u01 != null) ? (u01.g ? u01.a : u01.b) : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.A;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    u0 u01 = this.y;
    return (u01 != null) ? u01.a : 0;
  }
  
  public int getContentInsetRight() {
    u0 u01 = this.y;
    return (u01 != null) ? u01.b : 0;
  }
  
  public int getContentInsetStart() {
    u0 u01 = this.y;
    return (u01 != null) ? (u01.g ? u01.b : u01.a) : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.z;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: getfield u : Landroidx/appcompat/view/menu/e;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield A : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    WeakHashMap weakHashMap = y.a;
    return (y.e.d((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    WeakHashMap weakHashMap = y.a;
    return (y.e.d((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.z, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.j;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.j;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    e();
    return this.f.getMenu();
  }
  
  public View getNavButtonView() {
    return (View)this.i;
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.i;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.i;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public c getOuterActionMenuPresenter() {
    return this.Q;
  }
  
  public Drawable getOverflowIcon() {
    e();
    return this.f.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.o;
  }
  
  public int getPopupTheme() {
    return this.p;
  }
  
  public CharSequence getSubtitle() {
    return this.D;
  }
  
  public final TextView getSubtitleTextView() {
    return this.h;
  }
  
  public CharSequence getTitle() {
    return this.C;
  }
  
  public int getTitleMarginBottom() {
    return this.x;
  }
  
  public int getTitleMarginEnd() {
    return this.v;
  }
  
  public int getTitleMarginStart() {
    return this.u;
  }
  
  public int getTitleMarginTop() {
    return this.w;
  }
  
  public final TextView getTitleTextView() {
    return this.g;
  }
  
  public i0 getWrapper() {
    if (this.P == null)
      this.P = new g1(this, true); 
    return this.P;
  }
  
  public e h() {
    return new e(-2, -2);
  }
  
  public e i(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof f.a.a) ? new e((f.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  public final int j(int paramInt) {
    WeakHashMap weakHashMap = y.a;
    int i = y.e.d((View)this);
    int j = Gravity.getAbsoluteGravity(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  public final int k(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int k = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (k - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int j = e1.a & 0x70;
    int i = j;
    if (j != 16) {
      i = j;
      if (j != 48) {
        i = j;
        if (j != 80)
          i = this.B & 0x70; 
      } 
    } 
    if (i != 48) {
      if (i != 80) {
        j = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - j - m - k) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (i >= paramInt) {
          k = n - m - k - i - j;
          m = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (k < m)
            paramInt = Math.max(0, i - m - k); 
        } 
        return j + paramInt;
      } 
      return getHeight() - getPaddingBottom() - k - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  public final int l(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
  }
  
  public final int m(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  public void n(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public void o() {
    for (MenuItem menuItem : this.M)
      getMenu().removeItem(menuItem.getItemId()); 
    ArrayList<MenuItem> arrayList1 = getCurrentMenuItems();
    m0.g g2 = this.L;
    Menu menu = getMenu();
    MenuInflater menuInflater = getMenuInflater();
    Iterator<h> iterator = g2.a.iterator();
    while (iterator.hasNext())
      ((h)iterator.next()).b(menu, menuInflater); 
    ArrayList<MenuItem> arrayList2 = getCurrentMenuItems();
    arrayList2.removeAll(arrayList1);
    this.M = arrayList2;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.V);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.H = false; 
    if (!this.H) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.H = true; 
    } 
    if (i == 10 || i == 3)
      this.H = false; 
    return true;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    WeakHashMap weakHashMap = y.a;
    if (y.e.d((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    paramInt3 = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.K;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = y.d.d((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (v((View)this.i)) {
      if (k) {
        j = s((View)this.i, m, arrayOfInt, paramInt4);
        i = paramInt3;
      } else {
        i = r((View)this.i, paramInt3, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      i = paramInt3;
      j = m;
    } 
    paramInt1 = i;
    paramInt2 = j;
    if (v((View)this.m))
      if (k) {
        paramInt2 = s((View)this.m, j, arrayOfInt, paramInt4);
        paramInt1 = i;
      } else {
        paramInt1 = r((View)this.m, i, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    int j = paramInt1;
    int i = paramInt2;
    if (v((View)this.f))
      if (k) {
        j = r((View)this.f, paramInt1, arrayOfInt, paramInt4);
        i = paramInt2;
      } else {
        i = s((View)this.f, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - i);
    paramInt2 = Math.max(j, paramInt2);
    i = Math.min(i, m - paramInt1);
    paramInt1 = paramInt2;
    j = i;
    if (v(this.n))
      if (k) {
        j = s(this.n, i, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = r(this.n, paramInt2, arrayOfInt, paramInt4);
        j = i;
      }  
    paramInt2 = paramInt1;
    i = j;
    if (v((View)this.j))
      if (k) {
        i = s((View)this.j, j, arrayOfInt, paramInt4);
        paramInt2 = paramInt1;
      } else {
        paramInt2 = r((View)this.j, paramInt1, arrayOfInt, paramInt4);
        i = j;
      }  
    paramBoolean = v((View)this.g);
    boolean bool = v((View)this.h);
    if (paramBoolean) {
      e e1 = (e)this.g.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
      paramInt1 = this.g.getMeasuredHeight() + paramInt1 + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.h.getLayoutParams();
      j = ((ViewGroup.MarginLayoutParams)e1).topMargin;
      paramInt1 += this.h.getMeasuredHeight() + j + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.g;
      } else {
        textView1 = this.h;
      } 
      if (bool) {
        textView2 = this.h;
      } else {
        textView2 = this.g;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.g.getMeasuredWidth() > 0) || (bool && this.h.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.B & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i6 = this.w;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i5 = this.x;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.x - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.w;
      } 
      m = paramInt2;
      if (k) {
        if (j != 0) {
          paramInt2 = this.u;
        } else {
          paramInt2 = 0;
        } 
        k = paramInt2 - arrayOfInt[1];
        paramInt2 = i - Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.g.getLayoutParams();
          k = paramInt2 - this.g.getMeasuredWidth();
          i = this.g.getMeasuredHeight() + paramInt1;
          this.g.layout(k, paramInt1, paramInt2, i);
          paramInt1 = k - this.v;
          k = i + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          i = paramInt2;
          k = paramInt1;
          paramInt1 = i;
        } 
        if (bool) {
          i = k + ((ViewGroup.MarginLayoutParams)this.h.getLayoutParams()).topMargin;
          k = this.h.getMeasuredWidth();
          i2 = this.h.getMeasuredHeight();
          this.h.layout(paramInt2 - k, i, paramInt2, i2 + i);
          i = paramInt2 - this.v;
        } else {
          i = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, i); 
        paramInt1 = m;
        i = paramInt2;
      } else {
        if (j != 0) {
          paramInt2 = this.u;
        } else {
          paramInt2 = 0;
        } 
        k = paramInt2 - arrayOfInt[0];
        paramInt2 = Math.max(0, k) + m;
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.g.getLayoutParams();
          m = this.g.getMeasuredWidth() + paramInt2;
          k = this.g.getMeasuredHeight() + paramInt1;
          this.g.layout(paramInt2, paramInt1, m, k);
          paramInt1 = m + this.v;
          m = k + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = m + ((ViewGroup.MarginLayoutParams)this.h.getLayoutParams()).topMargin;
          m = this.h.getMeasuredWidth() + paramInt2;
          i2 = this.h.getMeasuredHeight();
          this.h.layout(paramInt2, k, m, i2 + k);
          k = m + this.v;
        } else {
          k = paramInt2;
        } 
        if (j != 0) {
          paramInt1 = Math.max(paramInt1, k);
        } else {
          paramInt1 = paramInt2;
        } 
      } 
    } else {
      paramInt1 = paramInt2;
    } 
    int k = paramInt4;
    m = paramInt3;
    a(this.I, 3);
    paramInt3 = this.I.size();
    for (paramInt2 = 0; paramInt2 < paramInt3; paramInt2++)
      paramInt1 = r(this.I.get(paramInt2), paramInt1, arrayOfInt, k); 
    a(this.I, 5);
    paramInt3 = this.I.size();
    for (paramInt2 = 0; paramInt2 < paramInt3; paramInt2++)
      i = s(this.I.get(paramInt2), i, arrayOfInt, k); 
    a(this.I, 1);
    ArrayList<View> arrayList = this.I;
    j = arrayOfInt[0];
    paramInt4 = arrayOfInt[1];
    i2 = arrayList.size();
    paramInt3 = 0;
    paramInt2 = 0;
    while (paramInt3 < i2) {
      View view = arrayList.get(paramInt3);
      e e1 = (e)view.getLayoutParams();
      j = ((ViewGroup.MarginLayoutParams)e1).leftMargin - j;
      paramInt4 = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramInt4;
      i3 = Math.max(0, j);
      i4 = Math.max(0, paramInt4);
      j = Math.max(0, -j);
      paramInt4 = Math.max(0, -paramInt4);
      paramInt2 += view.getMeasuredWidth() + i3 + i4;
      paramInt3++;
    } 
    paramInt3 = (n - m - i1) / 2 + m - paramInt2 / 2;
    paramInt2 += paramInt3;
    if (paramInt3 >= paramInt1)
      if (paramInt2 > i) {
        paramInt1 = paramInt3 - paramInt2 - i;
      } else {
        paramInt1 = paramInt3;
      }  
    paramInt3 = this.I.size();
    paramInt2 = paramInt1;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++)
      paramInt2 = r(this.I.get(paramInt1), paramInt2, arrayOfInt, k); 
    this.I.clear();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g2 = (g)paramParcelable;
    super.onRestoreInstanceState(g2.f);
    ActionMenuView actionMenuView = this.f;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.e e1 = actionMenuView.u;
    } else {
      actionMenuView = null;
    } 
    int i = g2.h;
    if (i != 0 && this.R != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g2.i) {
      removeCallbacks(this.V);
      post(this.V);
    } 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    d();
    u0 u01 = this.y;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    if (bool == u01.g)
      return; 
    u01.g = bool;
    if (u01.h) {
      if (bool) {
        paramInt = u01.d;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = u01.e; 
        u01.a = paramInt;
        paramInt = u01.c;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = u01.f; 
        u01.b = paramInt;
        return;
      } 
      paramInt = u01.c;
      if (paramInt == Integer.MIN_VALUE)
        paramInt = u01.e; 
      u01.a = paramInt;
      paramInt = u01.d;
      if (paramInt == Integer.MIN_VALUE)
        paramInt = u01.f; 
      u01.b = paramInt;
      return;
    } 
    u01.a = u01.e;
    u01.b = u01.f;
  }
  
  public Parcelable onSaveInstanceState() {
    g g2 = new g(super.onSaveInstanceState());
    d d1 = this.R;
    if (d1 != null) {
      androidx.appcompat.view.menu.g g3 = d1.g;
      if (g3 != null)
        g2.h = g3.a; 
    } 
    g2.i = q();
    return (Parcelable)g2;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.G = false; 
    if (!this.G) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.G = true; 
    } 
    if (i == 1 || i == 3)
      this.G = false; 
    return true;
  }
  
  public final boolean p(View paramView) {
    return (paramView.getParent() == this || this.J.contains(paramView));
  }
  
  public boolean q() {
    ActionMenuView actionMenuView = this.f;
    if (actionMenuView != null) {
      boolean bool;
      c c1 = actionMenuView.y;
      if (c1 != null && c1.m()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public final int r(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 = Math.max(0, i) + paramInt1;
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = k(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return i + ((ViewGroup.MarginLayoutParams)e1).rightMargin + paramInt1;
  }
  
  public final int s(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = k(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      c(); 
    ImageButton imageButton = this.m;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(g.a.b(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      c();
      this.m.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.m;
    if (imageButton != null)
      imageButton.setImageDrawable(this.k); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.U = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.A) {
      this.A = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.z) {
      this.z = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(g.a.b(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      if (this.j == null)
        this.j = new AppCompatImageView(getContext()); 
      if (!p((View)this.j))
        b((View)this.j, true); 
    } else {
      ImageView imageView1 = this.j;
      if (imageView1 != null && p((View)imageView1)) {
        removeView((View)this.j);
        this.J.remove(this.j);
      } 
    } 
    ImageView imageView = this.j;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence) && this.j == null)
      this.j = new AppCompatImageView(getContext()); 
    ImageView imageView = this.j;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.i;
    if (imageButton != null) {
      imageButton.setContentDescription(paramCharSequence);
      h1.a((View)this.i, paramCharSequence);
    } 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(g.a.b(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      if (!p((View)this.i))
        b((View)this.i, true); 
    } else {
      ImageButton imageButton1 = this.i;
      if (imageButton1 != null && p((View)imageButton1)) {
        removeView((View)this.i);
        this.J.remove(this.i);
      } 
    } 
    ImageButton imageButton = this.i;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    g();
    this.i.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.N = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    e();
    this.f.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.p != paramInt) {
      this.p = paramInt;
      if (paramInt == 0) {
        this.o = getContext();
        return;
      } 
      this.o = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.h == null) {
        Context context = getContext();
        e0 e0 = new e0(context, null);
        this.h = e0;
        e0.setSingleLine();
        this.h.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.r;
        if (i != 0)
          this.h.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.F;
        if (colorStateList != null)
          this.h.setTextColor(colorStateList); 
      } 
      if (!p((View)this.h))
        b((View)this.h, true); 
    } else {
      TextView textView1 = this.h;
      if (textView1 != null && p((View)textView1)) {
        removeView((View)this.h);
        this.J.remove(this.h);
      } 
    } 
    TextView textView = this.h;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.D = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.F = paramColorStateList;
    TextView textView = this.h;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.g == null) {
        Context context = getContext();
        e0 e0 = new e0(context, null);
        this.g = e0;
        e0.setSingleLine();
        this.g.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.q;
        if (i != 0)
          this.g.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.E;
        if (colorStateList != null)
          this.g.setTextColor(colorStateList); 
      } 
      if (!p((View)this.g))
        b((View)this.g, true); 
    } else {
      TextView textView1 = this.g;
      if (textView1 != null && p((View)textView1)) {
        removeView((View)this.g);
        this.J.remove(this.g);
      } 
    } 
    TextView textView = this.g;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.C = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.x = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.v = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.u = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.w = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.E = paramColorStateList;
    TextView textView = this.g;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public final int t(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int j = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int k = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int i = Math.max(0, j);
    i = Math.max(0, k) + i;
    paramArrayOfint[0] = Math.max(0, -j);
    paramArrayOfint[1] = Math.max(0, -k);
    j = getPaddingLeft();
    paramInt1 = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + j + i + paramInt2, marginLayoutParams.width);
    paramInt2 = getPaddingTop();
    paramView.measure(paramInt1, ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt2 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + i;
  }
  
  public final void u(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = getPaddingLeft();
    i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + i + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt1 = getPaddingTop();
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt1 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  public final boolean v(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  public boolean w() {
    ActionMenuView actionMenuView = this.f;
    if (actionMenuView != null) {
      boolean bool;
      c c1 = actionMenuView.y;
      if (c1 != null && c1.n()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public class a implements ActionMenuView.e {
    public a(Toolbar this$0) {}
  }
  
  public class b implements Runnable {
    public b(Toolbar this$0) {}
    
    public void run() {
      this.f.w();
    }
  }
  
  public class c implements View.OnClickListener {
    public c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      androidx.appcompat.view.menu.g g;
      Toolbar.d d = this.f.R;
      if (d == null) {
        d = null;
      } else {
        g = d.g;
      } 
      if (g != null)
        g.collapseActionView(); 
    }
  }
  
  public class d implements i {
    public androidx.appcompat.view.menu.e f;
    
    public androidx.appcompat.view.menu.g g;
    
    public d(Toolbar this$0) {}
    
    public void a(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {}
    
    public void b(Context param1Context, androidx.appcompat.view.menu.e param1e) {
      androidx.appcompat.view.menu.e e1 = this.f;
      if (e1 != null) {
        androidx.appcompat.view.menu.g g1 = this.g;
        if (g1 != null)
          e1.d(g1); 
      } 
      this.f = param1e;
    }
    
    public boolean d(l param1l) {
      return false;
    }
    
    public void e(boolean param1Boolean) {
      if (this.g != null) {
        androidx.appcompat.view.menu.e e1 = this.f;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (e1 != null) {
          int k = e1.size();
          int j = 0;
          while (true) {
            bool1 = bool2;
            if (j < k) {
              if (this.f.getItem(j) == this.g) {
                bool1 = true;
                break;
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          h(this.f, this.g); 
      } 
    }
    
    public boolean g() {
      return false;
    }
    
    public boolean h(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      View view = this.h.n;
      if (view instanceof j.b)
        ((j.b)view).e(); 
      Toolbar toolbar = this.h;
      toolbar.removeView(toolbar.n);
      toolbar = this.h;
      toolbar.removeView((View)toolbar.m);
      toolbar = this.h;
      toolbar.n = null;
      int j = toolbar.J.size();
      while (true) {
        if (--j >= 0) {
          toolbar.addView(toolbar.J.get(j));
          continue;
        } 
        toolbar.J.clear();
        this.g = null;
        this.h.requestLayout();
        param1g.C = false;
        param1g.n.p(false);
        return true;
      } 
    }
    
    public boolean i(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      this.h.c();
      ViewParent viewParent = this.h.m.getParent();
      Toolbar toolbar2 = this.h;
      if (viewParent != toolbar2) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar2.m); 
        Toolbar toolbar = this.h;
        toolbar.addView((View)toolbar.m);
      } 
      this.h.n = param1g.getActionView();
      this.g = param1g;
      viewParent = this.h.n.getParent();
      toolbar2 = this.h;
      if (viewParent != toolbar2) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar2.n); 
        Toolbar.e e1 = this.h.h();
        toolbar2 = this.h;
        e1.a = 0x800003 | toolbar2.s & 0x70;
        e1.b = 2;
        toolbar2.n.setLayoutParams((ViewGroup.LayoutParams)e1);
        Toolbar toolbar = this.h;
        toolbar.addView(toolbar.n);
      } 
      Toolbar toolbar1 = this.h;
      int j = toolbar1.getChildCount();
      while (true) {
        int k = j - 1;
        if (k >= 0) {
          View view1 = toolbar1.getChildAt(k);
          j = k;
          if (((Toolbar.e)view1.getLayoutParams()).b != 2) {
            j = k;
            if (view1 != toolbar1.f) {
              toolbar1.removeViewAt(k);
              toolbar1.J.add(view1);
              j = k;
            } 
          } 
          continue;
        } 
        this.h.requestLayout();
        param1g.C = true;
        param1g.n.p(false);
        View view = this.h.n;
        if (view instanceof j.b)
          ((j.b)view).c(); 
        return true;
      } 
    }
  }
  
  public static class e extends f.a.a {
    public int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    public e(f.a.a param1a) {
      super(param1a);
    }
  }
  
  public static interface f {}
  
  public static class g extends s0.a {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    public int h;
    
    public boolean i;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.h = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.i = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.ClassLoaderCreator<g> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new Toolbar.g(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.g(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new Toolbar.g[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.ClassLoaderCreator<g> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new Toolbar.g(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.g(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new Toolbar.g[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */