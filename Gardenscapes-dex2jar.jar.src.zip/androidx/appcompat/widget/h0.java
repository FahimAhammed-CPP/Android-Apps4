package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.i;

public interface h0 {
  void a(Menu paramMenu, i.a parama);
  
  boolean b();
  
  void c();
  
  boolean d();
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  void k(int paramInt);
  
  void l();
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */