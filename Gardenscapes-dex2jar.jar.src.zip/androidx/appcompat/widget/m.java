package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import e.i;
import java.util.Objects;
import v0.a;

public class m {
  public final EditText a;
  
  public final a b;
  
  public m(EditText paramEditText) {
    this.a = paramEditText;
    this.b = new a(paramEditText, false);
  }
  
  public KeyListener a(KeyListener paramKeyListener) {
    KeyListener keyListener = paramKeyListener;
    if ((paramKeyListener instanceof android.text.method.NumberKeyListener ^ true) != 0)
      keyListener = this.b.a.a(paramKeyListener); 
    return keyListener;
  }
  
  public void b(AttributeSet paramAttributeSet, int paramInt) {
    TypedArray typedArray = this.a.getContext().obtainStyledAttributes(paramAttributeSet, i.i, paramInt, 0);
    try {
      boolean bool2 = typedArray.hasValue(14);
      boolean bool1 = true;
      if (bool2)
        bool1 = typedArray.getBoolean(14, true); 
      typedArray.recycle();
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  public InputConnection c(InputConnection paramInputConnection, EditorInfo paramEditorInfo) {
    a a1 = this.b;
    Objects.requireNonNull(a1);
    return (paramInputConnection == null) ? null : a1.a.c(paramInputConnection, paramEditorInfo);
  }
  
  public void d(boolean paramBoolean) {
    this.b.a.d(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */