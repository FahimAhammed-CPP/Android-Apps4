package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.i;
import e.i;
import java.util.Objects;
import m0.c0;
import m0.d0;
import m0.e0;
import m0.y;

public class g1 implements i0 {
  public Toolbar a;
  
  public int b;
  
  public View c;
  
  public View d;
  
  public Drawable e;
  
  public Drawable f;
  
  public Drawable g;
  
  public boolean h;
  
  public CharSequence i;
  
  public CharSequence j;
  
  public CharSequence k;
  
  public Window.Callback l;
  
  public boolean m;
  
  public c n;
  
  public int o;
  
  public Drawable p;
  
  public g1(Toolbar paramToolbar, boolean paramBoolean) {
    boolean bool;
    this.o = 0;
    this.a = paramToolbar;
    this.i = paramToolbar.getTitle();
    this.j = paramToolbar.getSubtitle();
    if (this.i != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.h = bool;
    this.g = paramToolbar.getNavigationIcon();
    Context context = paramToolbar.getContext();
    int[] arrayOfInt = i.a;
    paramToolbar = null;
    d1 d1 = d1.q(context, null, arrayOfInt, 2130903045, 0);
    int i = 15;
    this.p = d1.g(15);
    if (paramBoolean) {
      CharSequence charSequence = d1.n(27);
      if (!TextUtils.isEmpty(charSequence)) {
        this.h = true;
        x(charSequence);
      } 
      charSequence = d1.n(25);
      if (!TextUtils.isEmpty(charSequence)) {
        this.j = charSequence;
        if ((this.b & 0x8) != 0)
          this.a.setSubtitle(charSequence); 
      } 
      Drawable drawable = d1.g(20);
      if (drawable != null) {
        this.f = drawable;
        A();
      } 
      drawable = d1.g(17);
      if (drawable != null) {
        this.e = drawable;
        A();
      } 
      if (this.g == null) {
        drawable = this.p;
        if (drawable != null) {
          this.g = drawable;
          z();
        } 
      } 
      o(d1.j(10, 0));
      i = d1.l(9, 0);
      if (i != 0) {
        View view1 = LayoutInflater.from(this.a.getContext()).inflate(i, this.a, false);
        View view2 = this.d;
        if (view2 != null && (this.b & 0x10) != 0)
          this.a.removeView(view2); 
        this.d = view1;
        if (view1 != null && (this.b & 0x10) != 0)
          this.a.addView(view1); 
        o(this.b | 0x10);
      } 
      i = d1.k(13, 0);
      if (i > 0) {
        ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
        layoutParams.height = i;
        this.a.setLayoutParams(layoutParams);
      } 
      int j = d1.e(7, -1);
      i = d1.e(3, -1);
      if (j >= 0 || i >= 0) {
        Toolbar toolbar = this.a;
        j = Math.max(j, 0);
        i = Math.max(i, 0);
        toolbar.d();
        toolbar.y.a(j, i);
      } 
      i = d1.l(28, 0);
      if (i != 0) {
        Toolbar toolbar = this.a;
        Context context1 = toolbar.getContext();
        toolbar.q = i;
        TextView textView = toolbar.g;
        if (textView != null)
          textView.setTextAppearance(context1, i); 
      } 
      i = d1.l(26, 0);
      if (i != 0) {
        Toolbar toolbar = this.a;
        Context context1 = toolbar.getContext();
        toolbar.r = i;
        TextView textView = toolbar.h;
        if (textView != null)
          textView.setTextAppearance(context1, i); 
      } 
      i = d1.l(22, 0);
      if (i != 0)
        this.a.setPopupTheme(i); 
    } else {
      if (this.a.getNavigationIcon() != null) {
        this.p = this.a.getNavigationIcon();
      } else {
        i = 11;
      } 
      this.b = i;
    } 
    d1.b.recycle();
    if (2131755010 != this.o) {
      this.o = 2131755010;
      if (TextUtils.isEmpty(this.a.getNavigationContentDescription())) {
        String str;
        i = this.o;
        if (i != 0)
          str = getContext().getString(i); 
        this.k = str;
        y();
      } 
    } 
    this.k = this.a.getNavigationContentDescription();
    this.a.setNavigationOnClickListener(new f1(this));
  }
  
  public final void A() {
    Drawable drawable;
    int i = this.b;
    if ((i & 0x2) != 0) {
      if ((i & 0x1) != 0) {
        drawable = this.f;
        if (drawable == null)
          drawable = this.e; 
      } else {
        drawable = this.e;
      } 
    } else {
      drawable = null;
    } 
    this.a.setLogo(drawable);
  }
  
  public void a(Menu paramMenu, i.a parama) {
    if (this.n == null) {
      c c2 = new c(this.a.getContext());
      this.n = c2;
      Objects.requireNonNull(c2);
    } 
    c c1 = this.n;
    c1.j = parama;
    Toolbar toolbar = this.a;
    e e1 = (e)paramMenu;
    if (e1 == null && toolbar.f == null)
      return; 
    toolbar.f();
    e e2 = toolbar.f.u;
    if (e2 == e1)
      return; 
    if (e2 != null) {
      e2.t((i)toolbar.Q);
      e2.t(toolbar.R);
    } 
    if (toolbar.R == null)
      toolbar.R = new Toolbar.d(toolbar); 
    c1.v = true;
    if (e1 != null) {
      e1.b((i)c1, toolbar.o);
      e1.b(toolbar.R, toolbar.o);
    } else {
      c1.b(toolbar.o, null);
      Toolbar.d d = toolbar.R;
      e2 = d.f;
      if (e2 != null) {
        g g = d.g;
        if (g != null)
          e2.d(g); 
      } 
      d.f = null;
      c1.e(true);
      toolbar.R.e(true);
    } 
    toolbar.f.setPopupTheme(toolbar.p);
    toolbar.f.setPresenter(c1);
    toolbar.Q = c1;
  }
  
  public boolean b() {
    return this.a.q();
  }
  
  public void c() {
    this.m = true;
  }
  
  public void collapseActionView() {
    g g;
    Toolbar.d d = this.a.R;
    if (d == null) {
      d = null;
    } else {
      g = d.g;
    } 
    if (g != null)
      g.collapseActionView(); 
  }
  
  public boolean d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/appcompat/widget/Toolbar;
    //   4: getfield f : Landroidx/appcompat/widget/ActionMenuView;
    //   7: astore #4
    //   9: iconst_0
    //   10: istore_3
    //   11: iload_3
    //   12: istore_2
    //   13: aload #4
    //   15: ifnull -> 75
    //   18: aload #4
    //   20: getfield y : Landroidx/appcompat/widget/c;
    //   23: astore #4
    //   25: aload #4
    //   27: ifnull -> 65
    //   30: aload #4
    //   32: getfield z : Landroidx/appcompat/widget/c$c;
    //   35: ifnonnull -> 54
    //   38: aload #4
    //   40: invokevirtual m : ()Z
    //   43: ifeq -> 49
    //   46: goto -> 54
    //   49: iconst_0
    //   50: istore_1
    //   51: goto -> 56
    //   54: iconst_1
    //   55: istore_1
    //   56: iload_1
    //   57: ifeq -> 65
    //   60: iconst_1
    //   61: istore_1
    //   62: goto -> 67
    //   65: iconst_0
    //   66: istore_1
    //   67: iload_3
    //   68: istore_2
    //   69: iload_1
    //   70: ifeq -> 75
    //   73: iconst_1
    //   74: istore_2
    //   75: iload_2
    //   76: ireturn
  }
  
  public boolean e() {
    ActionMenuView actionMenuView = this.a.f;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (actionMenuView != null) {
      boolean bool;
      c c1 = actionMenuView.y;
      if (c1 != null && c1.k()) {
        bool = true;
      } else {
        bool = false;
      } 
      bool1 = bool2;
      if (bool)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public boolean f() {
    return this.a.w();
  }
  
  public boolean g() {
    Toolbar toolbar = this.a;
    if (toolbar.getVisibility() == 0) {
      ActionMenuView actionMenuView = toolbar.f;
      if (actionMenuView != null && actionMenuView.x)
        return true; 
    } 
    return false;
  }
  
  public Context getContext() {
    return this.a.getContext();
  }
  
  public CharSequence getTitle() {
    return this.a.getTitle();
  }
  
  public void h() {
    ActionMenuView actionMenuView = this.a.f;
    if (actionMenuView != null) {
      c c1 = actionMenuView.y;
      if (c1 != null)
        c1.c(); 
    } 
  }
  
  public void i(i.a parama, e.a parama1) {
    Toolbar toolbar = this.a;
    toolbar.S = parama;
    toolbar.T = parama1;
    ActionMenuView actionMenuView = toolbar.f;
    if (actionMenuView != null) {
      actionMenuView.z = parama;
      actionMenuView.A = parama1;
    } 
  }
  
  public void j(int paramInt) {
    this.a.setVisibility(paramInt);
  }
  
  public void k(v0 paramv0) {
    View view = this.c;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      Toolbar toolbar = this.a;
      if (viewParent == toolbar)
        toolbar.removeView(this.c); 
    } 
    this.c = null;
  }
  
  public ViewGroup l() {
    return this.a;
  }
  
  public void m(boolean paramBoolean) {}
  
  public boolean n() {
    Toolbar.d d = this.a.R;
    return (d != null && d.g != null);
  }
  
  public void o(int paramInt) {
    int i = this.b ^ paramInt;
    this.b = paramInt;
    if (i != 0) {
      if ((i & 0x4) != 0) {
        if ((paramInt & 0x4) != 0)
          y(); 
        z();
      } 
      if ((i & 0x3) != 0)
        A(); 
      if ((i & 0x8) != 0)
        if ((paramInt & 0x8) != 0) {
          this.a.setTitle(this.i);
          this.a.setSubtitle(this.j);
        } else {
          this.a.setTitle((CharSequence)null);
          this.a.setSubtitle((CharSequence)null);
        }  
      if ((i & 0x10) != 0) {
        View view = this.d;
        if (view != null) {
          if ((paramInt & 0x10) != 0) {
            this.a.addView(view);
            return;
          } 
          this.a.removeView(view);
        } 
      } 
    } 
  }
  
  public int p() {
    return this.b;
  }
  
  public Menu q() {
    return this.a.getMenu();
  }
  
  public void r(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = g.a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    this.f = drawable;
    A();
  }
  
  public int s() {
    return 0;
  }
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = g.a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    this.e = drawable;
    A();
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.e = paramDrawable;
    A();
  }
  
  public void setWindowCallback(Window.Callback paramCallback) {
    this.l = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    if (!this.h)
      x(paramCharSequence); 
  }
  
  public c0 t(int paramInt, long paramLong) {
    float f;
    c0 c0 = y.b((View)this.a);
    if (paramInt == 0) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    c0.a(f);
    c0.c(paramLong);
    a a = new a(this, paramInt);
    View view = c0.a.get();
    if (view != null)
      c0.e(view, (d0)a); 
    return c0;
  }
  
  public void u() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void v() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void w(boolean paramBoolean) {
    this.a.setCollapsible(paramBoolean);
  }
  
  public final void x(CharSequence paramCharSequence) {
    this.i = paramCharSequence;
    if ((this.b & 0x8) != 0) {
      this.a.setTitle(paramCharSequence);
      if (this.h)
        y.B(this.a.getRootView(), paramCharSequence); 
    } 
  }
  
  public final void y() {
    if ((this.b & 0x4) != 0) {
      if (TextUtils.isEmpty(this.k)) {
        this.a.setNavigationContentDescription(this.o);
        return;
      } 
      this.a.setNavigationContentDescription(this.k);
    } 
  }
  
  public final void z() {
    if ((this.b & 0x4) != 0) {
      Toolbar toolbar = this.a;
      Drawable drawable = this.g;
      if (drawable == null)
        drawable = this.p; 
      toolbar.setNavigationIcon(drawable);
      return;
    } 
    this.a.setNavigationIcon((Drawable)null);
  }
  
  public class a extends e0 {
    public boolean a = false;
    
    public a(g1 this$0, int param1Int) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (!this.a)
        this.c.a.setVisibility(this.b); 
    }
    
    public void c(View param1View) {
      this.c.a.setVisibility(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */