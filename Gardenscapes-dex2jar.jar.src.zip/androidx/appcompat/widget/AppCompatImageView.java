package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import m0.t;
import q0.l;

public class AppCompatImageView extends ImageView implements t, l {
  private final f mBackgroundTintHelper;
  
  private boolean mHasLevel = false;
  
  private final p mImageHelper;
  
  public AppCompatImageView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatImageView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public AppCompatImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(a1.a(paramContext), paramAttributeSet, paramInt);
    y0.a((View)this, getContext());
    f f1 = new f((View)this);
    this.mBackgroundTintHelper = f1;
    f1.d(paramAttributeSet, paramInt);
    p p1 = new p(this);
    this.mImageHelper = p1;
    p1.c(paramAttributeSet, paramInt);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.a(); 
    p p1 = this.mImageHelper;
    if (p1 != null)
      p1.a(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.mBackgroundTintHelper;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.mBackgroundTintHelper;
    return (f1 != null) ? f1.c() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    p p1 = this.mImageHelper;
    if (p1 != null) {
      b1 b1 = p1.b;
      if (b1 != null)
        return b1.a; 
    } 
    return null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    p p1 = this.mImageHelper;
    if (p1 != null) {
      b1 b1 = p1.b;
      if (b1 != null)
        return b1.b; 
    } 
    return null;
  }
  
  public boolean hasOverlappingRendering() {
    return (this.mImageHelper.b() && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.f(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    p p1 = this.mImageHelper;
    if (p1 != null)
      p1.a(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    p p2 = this.mImageHelper;
    if (p2 != null && paramDrawable != null && !this.mHasLevel)
      p2.d = paramDrawable.getLevel(); 
    super.setImageDrawable(paramDrawable);
    p p1 = this.mImageHelper;
    if (p1 != null) {
      p1.a();
      if (!this.mHasLevel) {
        p1 = this.mImageHelper;
        if (p1.a.getDrawable() != null)
          p1.a.getDrawable().setLevel(p1.d); 
      } 
    } 
  }
  
  public void setImageLevel(int paramInt) {
    super.setImageLevel(paramInt);
    this.mHasLevel = true;
  }
  
  public void setImageResource(int paramInt) {
    p p1 = this.mImageHelper;
    if (p1 != null)
      p1.d(paramInt); 
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    p p1 = this.mImageHelper;
    if (p1 != null)
      p1.a(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.mBackgroundTintHelper;
    if (f1 != null)
      f1.i(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    p p1 = this.mImageHelper;
    if (p1 != null)
      p1.e(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    p p1 = this.mImageHelper;
    if (p1 != null)
      p1.f(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\AppCompatImageView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */