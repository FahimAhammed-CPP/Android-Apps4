package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import e7.t0;
import g.a;
import m0.t;

public class q extends MultiAutoCompleteTextView implements t {
  public static final int[] i = new int[] { 16843126 };
  
  public final f f;
  
  public final c0 g;
  
  public final m h;
  
  public q(Context paramContext, AttributeSet paramAttributeSet) {
    super(a1.a(paramContext), paramAttributeSet, 2130903096);
    y0.a((View)this, getContext());
    d1 d1 = d1.q(getContext(), paramAttributeSet, i, 2130903096, 0);
    if (d1.o(0))
      setDropDownBackgroundDrawable(d1.g(0)); 
    d1.b.recycle();
    f f1 = new f((View)this);
    this.f = f1;
    f1.d(paramAttributeSet, 2130903096);
    c0 c01 = new c0((TextView)this);
    this.g = c01;
    c01.e(paramAttributeSet, 2130903096);
    c01.b();
    m m1 = new m((EditText)this);
    this.h = m1;
    m1.b(paramAttributeSet, 2130903096);
    KeyListener keyListener = getKeyListener();
    if ((keyListener instanceof android.text.method.NumberKeyListener ^ true) != 0) {
      boolean bool = isFocusable();
      int i = getInputType();
      KeyListener keyListener1 = m1.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(i);
      setFocusable(bool);
    } 
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.f;
    if (f1 != null)
      f1.a(); 
    c0 c01 = this.g;
    if (c01 != null)
      c01.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.f;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.f;
    return (f1 != null) ? f1.c() : null;
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    t0.g(inputConnection, paramEditorInfo, (View)this);
    return this.h.c(inputConnection, paramEditorInfo);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.f;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.f;
    if (f1 != null)
      f1.f(paramInt); 
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(a.b(getContext(), paramInt));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.h.b.a.d(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.h.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.f;
    if (f1 != null)
      f1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.f;
    if (f1 != null)
      f1.i(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.g;
    if (c01 != null)
      c01.f(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */