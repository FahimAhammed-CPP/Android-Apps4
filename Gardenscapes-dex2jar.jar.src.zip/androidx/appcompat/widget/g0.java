package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;
import m0.t;

public class g0 extends ToggleButton implements t {
  public final f f;
  
  public final c0 g;
  
  public n h;
  
  public g0(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 16842827);
    y0.a((View)this, getContext());
    f f1 = new f((View)this);
    this.f = f1;
    f1.d(paramAttributeSet, 16842827);
    c0 c01 = new c0((TextView)this);
    this.g = c01;
    c01.e(paramAttributeSet, 16842827);
    getEmojiTextViewHelper().a(paramAttributeSet, 16842827);
  }
  
  private n getEmojiTextViewHelper() {
    if (this.h == null)
      this.h = new n((TextView)this); 
    return this.h;
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.f;
    if (f1 != null)
      f1.a(); 
    c0 c01 = this.g;
    if (c01 != null)
      c01.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.f;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.f;
    return (f1 != null) ? f1.c() : null;
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    (getEmojiTextViewHelper()).b.a.c(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.f;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.f;
    if (f1 != null)
      f1.f(paramInt); 
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    (getEmojiTextViewHelper()).b.a.d(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters((getEmojiTextViewHelper()).b.a.a(paramArrayOfInputFilter));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.f;
    if (f1 != null)
      f1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.f;
    if (f1 != null)
      f1.i(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */