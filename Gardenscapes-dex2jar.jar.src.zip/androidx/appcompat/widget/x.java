package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import e.i;
import f0.a;
import java.util.WeakHashMap;
import m0.y;

public class x extends s {
  public final SeekBar d;
  
  public Drawable e;
  
  public ColorStateList f = null;
  
  public PorterDuff.Mode g = null;
  
  public boolean h = false;
  
  public boolean i = false;
  
  public x(SeekBar paramSeekBar) {
    super((ProgressBar)paramSeekBar);
    this.d = paramSeekBar;
  }
  
  public void a(AttributeSet paramAttributeSet, int paramInt) {
    super.a(paramAttributeSet, paramInt);
    Context context = this.d.getContext();
    int[] arrayOfInt = i.g;
    d1 d1 = d1.q(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    SeekBar seekBar = this.d;
    y.z((View)seekBar, seekBar.getContext(), arrayOfInt, paramAttributeSet, d1.b, paramInt, 0);
    Drawable drawable1 = d1.h(0);
    if (drawable1 != null)
      this.d.setThumb(drawable1); 
    drawable1 = d1.g(1);
    Drawable drawable2 = this.e;
    if (drawable2 != null)
      drawable2.setCallback(null); 
    this.e = drawable1;
    if (drawable1 != null) {
      drawable1.setCallback((Drawable.Callback)this.d);
      SeekBar seekBar1 = this.d;
      WeakHashMap weakHashMap = y.a;
      a.g(drawable1, y.e.d((View)seekBar1));
      if (drawable1.isStateful())
        drawable1.setState(this.d.getDrawableState()); 
      c();
    } 
    this.d.invalidate();
    if (d1.o(3)) {
      this.g = j0.d(d1.j(3, -1), this.g);
      this.i = true;
    } 
    if (d1.o(2)) {
      this.f = d1.c(2);
      this.h = true;
    } 
    d1.b.recycle();
    c();
  }
  
  public final void c() {
    Drawable drawable = this.e;
    if (drawable != null && (this.h || this.i)) {
      drawable = a.k(drawable.mutate());
      this.e = drawable;
      if (this.h)
        a.i(drawable, this.f); 
      if (this.i)
        a.j(this.e, this.g); 
      if (this.e.isStateful())
        this.e.setState(this.d.getDrawableState()); 
    } 
  }
  
  public void d(Canvas paramCanvas) {
    if (this.e != null) {
      int j = this.d.getMax();
      int i = 1;
      if (j > 1) {
        int k = this.e.getIntrinsicWidth();
        int m = this.e.getIntrinsicHeight();
        if (k >= 0) {
          k /= 2;
        } else {
          k = 1;
        } 
        if (m >= 0)
          i = m / 2; 
        this.e.setBounds(-k, -i, k, i);
        float f = (this.d.getWidth() - this.d.getPaddingLeft() - this.d.getPaddingRight()) / j;
        i = paramCanvas.save();
        paramCanvas.translate(this.d.getPaddingLeft(), (this.d.getHeight() / 2));
        for (k = 0; k <= j; k++) {
          this.e.draw(paramCanvas);
          paramCanvas.translate(f, 0.0F);
        } 
        paramCanvas.restoreToCount(i);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */