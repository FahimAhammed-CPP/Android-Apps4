package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.j;
import java.util.WeakHashMap;
import m0.y;

public class ActionBarContextView extends a {
  public CharSequence n;
  
  public CharSequence o;
  
  public View p;
  
  public View q;
  
  public View r;
  
  public LinearLayout s;
  
  public TextView t;
  
  public TextView u;
  
  public int v;
  
  public int w;
  
  public boolean x;
  
  public int y;
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: ldc 2130903068
    //   5: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   8: aload_1
    //   9: aload_2
    //   10: getstatic e/i.d : [I
    //   13: ldc 2130903068
    //   15: iconst_0
    //   16: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   19: astore_2
    //   20: aload_2
    //   21: iconst_0
    //   22: invokevirtual hasValue : (I)Z
    //   25: ifeq -> 48
    //   28: aload_2
    //   29: iconst_0
    //   30: iconst_0
    //   31: invokevirtual getResourceId : (II)I
    //   34: istore_3
    //   35: iload_3
    //   36: ifeq -> 48
    //   39: aload_1
    //   40: iload_3
    //   41: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   44: astore_1
    //   45: goto -> 54
    //   48: aload_2
    //   49: iconst_0
    //   50: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   53: astore_1
    //   54: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   57: astore #4
    //   59: aload_0
    //   60: aload_1
    //   61: invokestatic q : (Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    //   64: aload_0
    //   65: aload_2
    //   66: iconst_5
    //   67: iconst_0
    //   68: invokevirtual getResourceId : (II)I
    //   71: putfield v : I
    //   74: aload_0
    //   75: aload_2
    //   76: iconst_4
    //   77: iconst_0
    //   78: invokevirtual getResourceId : (II)I
    //   81: putfield w : I
    //   84: aload_0
    //   85: aload_2
    //   86: iconst_3
    //   87: iconst_0
    //   88: invokevirtual getLayoutDimension : (II)I
    //   91: putfield j : I
    //   94: aload_0
    //   95: aload_2
    //   96: iconst_2
    //   97: ldc 2131427333
    //   99: invokevirtual getResourceId : (II)I
    //   102: putfield y : I
    //   105: aload_2
    //   106: invokevirtual recycle : ()V
    //   109: return
  }
  
  public void f(j.a parama) {
    View view = this.p;
    if (view == null) {
      view = LayoutInflater.from(getContext()).inflate(this.y, this, false);
      this.p = view;
      addView(view);
    } else if (view.getParent() == null) {
      addView(this.p);
    } 
    view = this.p.findViewById(2131230784);
    this.q = view;
    view.setOnClickListener(new a(this, parama));
    e e = (e)parama.e();
    c c1 = this.i;
    if (c1 != null)
      c1.c(); 
    c1 = new c(getContext());
    this.i = c1;
    c1.q = true;
    c1.r = true;
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
    e.b((i)this.i, this.g);
    c c2 = this.i;
    j j1 = c2.m;
    if (j1 == null) {
      j j = (j)c2.i.inflate(c2.k, this, false);
      c2.m = j;
      j.b(c2.h);
      c2.e(true);
    } 
    j j2 = c2.m;
    if (j1 != j2)
      ((ActionMenuView)j2).setPresenter(c2); 
    ActionMenuView actionMenuView = (ActionMenuView)j2;
    this.h = actionMenuView;
    WeakHashMap weakHashMap = y.a;
    y.d.q((View)actionMenuView, null);
    addView((View)this.h, layoutParams);
  }
  
  public final void g() {
    if (this.s == null) {
      LayoutInflater.from(getContext()).inflate(2131427328, this);
      LinearLayout linearLayout1 = (LinearLayout)getChildAt(getChildCount() - 1);
      this.s = linearLayout1;
      this.t = (TextView)linearLayout1.findViewById(2131230775);
      this.u = (TextView)this.s.findViewById(2131230774);
      if (this.v != 0)
        this.t.setTextAppearance(getContext(), this.v); 
      if (this.w != 0)
        this.u.setTextAppearance(getContext(), this.w); 
    } 
    this.t.setText(this.n);
    this.u.setText(this.o);
    boolean bool1 = TextUtils.isEmpty(this.n);
    int i = TextUtils.isEmpty(this.o) ^ true;
    TextView textView = this.u;
    boolean bool = false;
    if (i != 0) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    LinearLayout linearLayout = this.s;
    byte b = bool;
    if ((bool1 ^ true) == 0)
      if (i != 0) {
        b = bool;
      } else {
        b = 8;
      }  
    linearLayout.setVisibility(b);
    if (this.s.getParent() == null)
      addView((View)this.s); 
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-1, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }
  
  public CharSequence getSubtitle() {
    return this.o;
  }
  
  public CharSequence getTitle() {
    return this.n;
  }
  
  public void h() {
    removeAllViews();
    this.r = null;
    this.h = null;
    this.i = null;
    View view = this.q;
    if (view != null)
      view.setOnClickListener(null); 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    c c = this.i;
    if (c != null) {
      c.k();
      this.i.l();
    } 
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    paramBoolean = l1.b((View)this);
    if (paramBoolean) {
      i = paramInt3 - paramInt1 - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    View view2 = this.p;
    paramInt2 = i;
    if (view2 != null) {
      paramInt2 = i;
      if (view2.getVisibility() != 8) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.p.getLayoutParams();
        if (paramBoolean) {
          paramInt4 = marginLayoutParams.rightMargin;
        } else {
          paramInt4 = marginLayoutParams.leftMargin;
        } 
        if (paramBoolean) {
          paramInt2 = marginLayoutParams.leftMargin;
        } else {
          paramInt2 = marginLayoutParams.rightMargin;
        } 
        if (paramBoolean) {
          paramInt4 = i - paramInt4;
        } else {
          paramInt4 = i + paramInt4;
        } 
        paramInt4 += d(this.p, paramInt4, j, k, paramBoolean);
        if (paramBoolean) {
          paramInt2 = paramInt4 - paramInt2;
        } else {
          paramInt2 = paramInt4 + paramInt2;
        } 
      } 
    } 
    LinearLayout linearLayout = this.s;
    paramInt4 = paramInt2;
    if (linearLayout != null) {
      paramInt4 = paramInt2;
      if (this.r == null) {
        paramInt4 = paramInt2;
        if (linearLayout.getVisibility() != 8)
          paramInt4 = paramInt2 + d((View)this.s, paramInt2, j, k, paramBoolean); 
      } 
    } 
    View view1 = this.r;
    if (view1 != null)
      d(view1, paramInt4, j, k, paramBoolean); 
    if (paramBoolean) {
      paramInt1 = getPaddingLeft();
    } else {
      paramInt1 = paramInt3 - paramInt1 - getPaddingRight();
    } 
    ActionMenuView actionMenuView = this.h;
    if (actionMenuView != null)
      d((View)actionMenuView, paramInt1, j, k, paramBoolean ^ true); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = 1073741824;
    if (i == 1073741824) {
      if (View.MeasureSpec.getMode(paramInt2) != 0) {
        int n = View.MeasureSpec.getSize(paramInt1);
        i = this.j;
        if (i <= 0)
          i = View.MeasureSpec.getSize(paramInt2); 
        paramInt1 = getPaddingTop();
        int i1 = getPaddingBottom() + paramInt1;
        paramInt1 = n - getPaddingLeft() - getPaddingRight();
        int m = i - i1;
        int k = View.MeasureSpec.makeMeasureSpec(m, -2147483648);
        View view2 = this.p;
        boolean bool = false;
        paramInt2 = paramInt1;
        if (view2 != null) {
          paramInt1 = c(view2, paramInt1, k, 0);
          ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.p.getLayoutParams();
          paramInt2 = paramInt1 - marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
        } 
        ActionMenuView actionMenuView = this.h;
        paramInt1 = paramInt2;
        if (actionMenuView != null) {
          paramInt1 = paramInt2;
          if (actionMenuView.getParent() == this)
            paramInt1 = c((View)this.h, paramInt2, k, 0); 
        } 
        LinearLayout linearLayout = this.s;
        paramInt2 = paramInt1;
        if (linearLayout != null) {
          paramInt2 = paramInt1;
          if (this.r == null)
            if (this.x) {
              paramInt2 = View.MeasureSpec.makeMeasureSpec(0, 0);
              this.s.measure(paramInt2, k);
              int i2 = this.s.getMeasuredWidth();
              if (i2 <= paramInt1) {
                k = 1;
              } else {
                k = 0;
              } 
              paramInt2 = paramInt1;
              if (k != 0)
                paramInt2 = paramInt1 - i2; 
              linearLayout = this.s;
              if (k != 0) {
                paramInt1 = 0;
              } else {
                paramInt1 = 8;
              } 
              linearLayout.setVisibility(paramInt1);
            } else {
              paramInt2 = c((View)linearLayout, paramInt1, k, 0);
            }  
        } 
        View view1 = this.r;
        if (view1 != null) {
          ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
          int i2 = layoutParams.width;
          if (i2 != -2) {
            paramInt1 = 1073741824;
          } else {
            paramInt1 = Integer.MIN_VALUE;
          } 
          k = paramInt2;
          if (i2 >= 0)
            k = Math.min(i2, paramInt2); 
          i2 = layoutParams.height;
          if (i2 != -2) {
            paramInt2 = j;
          } else {
            paramInt2 = Integer.MIN_VALUE;
          } 
          j = m;
          if (i2 >= 0)
            j = Math.min(i2, m); 
          this.r.measure(View.MeasureSpec.makeMeasureSpec(k, paramInt1), View.MeasureSpec.makeMeasureSpec(j, paramInt2));
        } 
        if (this.j <= 0) {
          j = getChildCount();
          paramInt2 = 0;
          paramInt1 = bool;
          while (paramInt1 < j) {
            k = getChildAt(paramInt1).getMeasuredHeight() + i1;
            i = paramInt2;
            if (k > paramInt2)
              i = k; 
            paramInt1++;
            paramInt2 = i;
          } 
          setMeasuredDimension(n, paramInt2);
          return;
        } 
        setMeasuredDimension(n, i);
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getClass().getSimpleName());
      stringBuilder1.append(" can only be used with android:layout_height=\"wrap_content\"");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
    IllegalStateException illegalStateException = new IllegalStateException(stringBuilder.toString());
    throw illegalStateException;
  }
  
  public void setContentHeight(int paramInt) {
    this.j = paramInt;
  }
  
  public void setCustomView(View paramView) {
    View view = this.r;
    if (view != null)
      removeView(view); 
    this.r = paramView;
    if (paramView != null) {
      LinearLayout linearLayout = this.s;
      if (linearLayout != null) {
        removeView((View)linearLayout);
        this.s = null;
      } 
    } 
    if (paramView != null)
      addView(paramView); 
    requestLayout();
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.o = paramCharSequence;
    g();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.n = paramCharSequence;
    g();
    y.B((View)this, paramCharSequence);
  }
  
  public void setTitleOptional(boolean paramBoolean) {
    if (paramBoolean != this.x)
      requestLayout(); 
    this.x = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public class a implements View.OnClickListener {
    public a(ActionBarContextView this$0, j.a param1a) {}
    
    public void onClick(View param1View) {
      this.f.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\ActionBarContextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */