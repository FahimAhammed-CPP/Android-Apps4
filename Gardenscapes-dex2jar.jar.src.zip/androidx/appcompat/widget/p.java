package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import e.i;
import g.a;
import m0.y;
import q0.l;

public class p {
  public final ImageView a;
  
  public b1 b;
  
  public b1 c;
  
  public int d = 0;
  
  public p(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  public void a() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      j0.b(drawable); 
    if (drawable != null) {
      boolean bool1;
      int i = Build.VERSION.SDK_INT;
      boolean bool2 = true;
      if (i <= 21 && i == 21) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        ColorStateList colorStateList1;
        PorterDuff.Mode mode;
        if (this.c == null)
          this.c = new b1(); 
        b1 b12 = this.c;
        ColorStateList colorStateList2 = null;
        b12.a = null;
        b12.d = false;
        b12.b = null;
        b12.c = false;
        ImageView imageView1 = this.a;
        if (i >= 21) {
          colorStateList1 = imageView1.getImageTintList();
        } else if (colorStateList1 instanceof l) {
          colorStateList1 = ((l)colorStateList1).getSupportImageTintList();
        } else {
          colorStateList1 = null;
        } 
        if (colorStateList1 != null) {
          b12.d = true;
          b12.a = colorStateList1;
        } 
        ImageView imageView2 = this.a;
        if (i >= 21) {
          mode = imageView2.getImageTintMode();
        } else {
          colorStateList1 = colorStateList2;
          if (imageView2 instanceof l)
            mode = ((l)imageView2).getSupportImageTintMode(); 
        } 
        if (mode != null) {
          b12.c = true;
          b12.b = mode;
        } 
        if (b12.d || b12.c) {
          k.f(drawable, b12, this.a.getDrawableState());
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
        if (bool1)
          return; 
      } 
      b1 b11 = this.b;
      if (b11 != null)
        k.f(drawable, b11, this.a.getDrawableState()); 
    } 
  }
  
  public boolean b() {
    Drawable drawable = this.a.getBackground();
    return !(Build.VERSION.SDK_INT >= 21 && drawable instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void c(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = i.f;
    d1 d1 = d1.q(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    y.z((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, d1.b, paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = d1.l(1, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.b(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        j0.b(drawable1); 
      if (d1.o(2)) {
        Drawable drawable;
        ImageView imageView1 = this.a;
        ColorStateList colorStateList = d1.c(2);
        paramInt = Build.VERSION.SDK_INT;
        if (paramInt >= 21) {
          imageView1.setImageTintList(colorStateList);
          if (paramInt == 21) {
            drawable = imageView1.getDrawable();
            if (drawable != null && imageView1.getImageTintList() != null) {
              if (drawable.isStateful())
                drawable.setState(imageView1.getDrawableState()); 
              imageView1.setImageDrawable(drawable);
            } 
          } 
        } else if (imageView1 instanceof l) {
          ((l)imageView1).setSupportImageTintList((ColorStateList)drawable);
        } 
      } 
      if (d1.o(3)) {
        Drawable drawable;
        ImageView imageView1 = this.a;
        PorterDuff.Mode mode = j0.d(d1.j(3, -1), null);
        paramInt = Build.VERSION.SDK_INT;
        if (paramInt >= 21) {
          imageView1.setImageTintMode(mode);
          if (paramInt == 21) {
            drawable = imageView1.getDrawable();
            if (drawable != null && imageView1.getImageTintList() != null) {
              if (drawable.isStateful())
                drawable.setState(imageView1.getDrawableState()); 
              imageView1.setImageDrawable(drawable);
            } 
          } 
        } else if (imageView1 instanceof l) {
          ((l)imageView1).setSupportImageTintMode((PorterDuff.Mode)drawable);
        } 
      } 
      return;
    } finally {
      d1.b.recycle();
    } 
  }
  
  public void d(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.b(this.a.getContext(), paramInt);
      if (drawable != null)
        j0.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    a();
  }
  
  public void e(ColorStateList paramColorStateList) {
    if (this.b == null)
      this.b = new b1(); 
    b1 b11 = this.b;
    b11.a = paramColorStateList;
    b11.d = true;
    a();
  }
  
  public void f(PorterDuff.Mode paramMode) {
    if (this.b == null)
      this.b = new b1(); 
    b1 b11 = this.b;
    b11.b = paramMode;
    b11.c = true;
    a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */