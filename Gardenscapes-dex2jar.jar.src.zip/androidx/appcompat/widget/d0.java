package androidx.appcompat.widget;

import android.graphics.Typeface;
import android.widget.TextView;

public class d0 implements Runnable {
  public d0(c0 paramc0, TextView paramTextView, Typeface paramTypeface, int paramInt) {}
  
  public void run() {
    this.f.setTypeface(this.g, this.h);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */