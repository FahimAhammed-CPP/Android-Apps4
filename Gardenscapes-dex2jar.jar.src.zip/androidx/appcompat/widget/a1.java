package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Build;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class a1 extends ContextWrapper {
  public static final Object b = new Object();
  
  public static ArrayList<WeakReference<a1>> c;
  
  public final Resources a;
  
  public a1(Context paramContext) {
    super(paramContext);
    int i = k1.b;
    this.a = new c1((Context)this, paramContext.getResources());
  }
  
  public static Context a(Context paramContext) {
    boolean bool = paramContext instanceof a1;
    byte b = 0;
    int i = b;
    if (!bool) {
      i = b;
      if (!(paramContext.getResources() instanceof c1)) {
        paramContext.getResources();
        if (Build.VERSION.SDK_INT >= 21) {
          i = k1.b;
          i = b;
        } else {
          i = 1;
        } 
      } 
    } 
    if (i != 0)
      synchronized (b) {
        ArrayList<WeakReference<a1>> arrayList = c;
        if (arrayList == null) {
          c = new ArrayList<WeakReference<a1>>();
        } else {
          for (i = arrayList.size() - 1;; i--) {
            if (i >= 0) {
              WeakReference weakReference = c.get(i);
              if (weakReference == null || weakReference.get() == null)
                c.remove(i); 
            } else {
              for (i = c.size() - 1;; i--) {
                if (i >= 0) {
                  WeakReference<a1> weakReference = c.get(i);
                  if (weakReference != null) {
                    a1 a12 = weakReference.get();
                  } else {
                    weakReference = null;
                  } 
                  if (weakReference != null && weakReference.getBaseContext() == paramContext)
                    return (Context)weakReference; 
                } else {
                  a11 = new a1(paramContext);
                  c.add(new WeakReference<a1>(a11));
                  return (Context)a11;
                } 
              } 
            } 
          } 
          i--;
        } 
        a1 a11 = new a1((Context)a11);
        c.add(new WeakReference<a1>(a11));
        return (Context)a11;
      }  
    return paramContext;
  }
  
  public AssetManager getAssets() {
    return this.a.getAssets();
  }
  
  public Resources getResources() {
    return this.a;
  }
  
  public Resources.Theme getTheme() {
    return super.getTheme();
  }
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */