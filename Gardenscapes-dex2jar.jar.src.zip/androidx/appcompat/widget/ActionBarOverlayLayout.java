package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.appcompat.view.menu.i;
import f.w;
import j.h;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.g0;
import m0.l;
import m0.m;
import m0.n;
import m0.o;
import m0.y;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements h0, n, l, m {
  public static final int[] K = new int[] { 2130903043, 16842841 };
  
  public g0 A;
  
  public g0 B;
  
  public g0 C;
  
  public d D;
  
  public OverScroller E;
  
  public ViewPropertyAnimator F;
  
  public final AnimatorListenerAdapter G;
  
  public final Runnable H;
  
  public final Runnable I;
  
  public final o J;
  
  public int f;
  
  public int g = 0;
  
  public ContentFrameLayout h;
  
  public ActionBarContainer i;
  
  public i0 j;
  
  public Drawable k;
  
  public boolean l;
  
  public boolean m;
  
  public boolean n;
  
  public boolean o;
  
  public boolean p;
  
  public int q;
  
  public int r;
  
  public final Rect s = new Rect();
  
  public final Rect t = new Rect();
  
  public final Rect u = new Rect();
  
  public final Rect v = new Rect();
  
  public final Rect w = new Rect();
  
  public final Rect x = new Rect();
  
  public final Rect y = new Rect();
  
  public g0 z;
  
  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    g0 g01 = g0.b;
    this.z = g01;
    this.A = g01;
    this.B = g01;
    this.C = g01;
    this.G = new a(this);
    this.H = new b(this);
    this.I = new c(this);
    r(paramContext);
    this.J = new o(0);
  }
  
  public void a(Menu paramMenu, i.a parama) {
    s();
    this.j.a(paramMenu, parama);
  }
  
  public boolean b() {
    s();
    return this.j.b();
  }
  
  public void c() {
    s();
    this.j.c();
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof e;
  }
  
  public boolean d() {
    s();
    return this.j.d();
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.k != null && !this.l) {
      byte b;
      if (this.i.getVisibility() == 0) {
        float f = this.i.getBottom();
        b = (int)(this.i.getTranslationY() + f + 0.5F);
      } else {
        b = 0;
      } 
      this.k.setBounds(0, b, getWidth(), this.k.getIntrinsicHeight() + b);
      this.k.draw(paramCanvas);
    } 
  }
  
  public boolean e() {
    s();
    return this.j.e();
  }
  
  public boolean f() {
    s();
    return this.j.f();
  }
  
  public boolean fitSystemWindows(Rect paramRect) {
    if (Build.VERSION.SDK_INT >= 21)
      return super.fitSystemWindows(paramRect); 
    s();
    boolean bool = p((View)this.i, paramRect, true, true, false, true);
    this.v.set(paramRect);
    l1.a((View)this, this.v, this.s);
    if (!this.w.equals(this.v)) {
      this.w.set(this.v);
      bool = true;
    } 
    if (!this.t.equals(this.s)) {
      this.t.set(this.s);
      bool = true;
    } 
    if (bool)
      requestLayout(); 
    return true;
  }
  
  public boolean g() {
    s();
    return this.j.g();
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new e(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new e(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new e(paramLayoutParams);
  }
  
  public int getActionBarHideOffset() {
    ActionBarContainer actionBarContainer = this.i;
    return (actionBarContainer != null) ? -((int)actionBarContainer.getTranslationY()) : 0;
  }
  
  public int getNestedScrollAxes() {
    return this.J.a();
  }
  
  public CharSequence getTitle() {
    s();
    return this.j.getTitle();
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramInt2 == 0)
      onNestedScrollAccepted(paramView1, paramView2, paramInt1); 
  }
  
  public void i(View paramView, int paramInt) {
    if (paramInt == 0)
      onStopNestedScroll(paramView); 
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramInt3 == 0)
      onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint); 
  }
  
  public void k(int paramInt) {
    s();
    if (paramInt != 2) {
      if (paramInt != 5) {
        if (paramInt != 109)
          return; 
        setOverlayMode(true);
        return;
      } 
      this.j.v();
      return;
    } 
    this.j.u();
  }
  
  public void l() {
    s();
    this.j.h();
  }
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return (paramInt2 == 0 && onStartNestedScroll(paramView1, paramView2, paramInt1));
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    s();
    g0 g01 = g0.i(paramWindowInsets, (View)this);
    Rect rect = new Rect(g01.b(), g01.d(), g01.c(), g01.a());
    boolean bool1 = p((View)this.i, rect, true, true, false, true);
    rect = this.s;
    WeakHashMap weakHashMap = y.a;
    if (Build.VERSION.SDK_INT >= 21)
      y.i.b((View)this, g01, rect); 
    rect = this.s;
    int i = rect.left;
    int j = rect.top;
    int k = rect.right;
    int i1 = rect.bottom;
    g0 g02 = g01.a.i(i, j, k, i1);
    this.z = g02;
    boolean bool2 = this.A.equals(g02);
    boolean bool = true;
    if (!bool2) {
      this.A = this.z;
      bool1 = true;
    } 
    if (!this.t.equals(this.s)) {
      this.t.set(this.s);
      bool1 = bool;
    } 
    if (bool1)
      requestLayout(); 
    return ((g01.a.a()).a.c()).a.b().g();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    r(getContext());
    y.y((View)this);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    q();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = getChildCount();
    paramInt3 = getPaddingLeft();
    paramInt4 = getPaddingTop();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      View view = getChildAt(paramInt1);
      if (view.getVisibility() != 8) {
        e e = (e)view.getLayoutParams();
        int i = view.getMeasuredWidth();
        int j = view.getMeasuredHeight();
        int k = e.leftMargin + paramInt3;
        int i1 = e.topMargin + paramInt4;
        view.layout(k, i1, i + k, j + i1);
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    s();
    measureChildWithMargins((View)this.i, paramInt1, 0, paramInt2, 0);
    e e2 = (e)this.i.getLayoutParams();
    int i3 = Math.max(0, this.i.getMeasuredWidth() + e2.leftMargin + e2.rightMargin);
    int i2 = Math.max(0, this.i.getMeasuredHeight() + e2.topMargin + e2.bottomMargin);
    int i1 = View.combineMeasuredStates(0, this.i.getMeasuredState());
    WeakHashMap weakHashMap = y.a;
    if ((y.d.g((View)this) & 0x100) != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j) {
      int i4 = this.f;
      i = i4;
      if (this.n) {
        i = i4;
        if (this.i.getTabContainer() != null)
          i = i4 + this.f; 
      } 
    } else if (this.i.getVisibility() != 8) {
      i = this.i.getMeasuredHeight();
    } else {
      i = 0;
    } 
    this.u.set(this.s);
    int k = Build.VERSION.SDK_INT;
    if (k >= 21) {
      this.B = this.z;
    } else {
      this.x.set(this.v);
    } 
    if (!this.m && !j) {
      Rect rect = this.u;
      rect.top += i;
      rect.bottom += 0;
      if (k >= 21)
        this.B = this.B.a.i(0, i, 0, 0); 
    } else if (k >= 21) {
      g0.d d1;
      g0.e e;
      e0.b b = e0.b.a(this.B.b(), this.B.d() + i, this.B.c(), this.B.a() + 0);
      g0 g01 = this.B;
      if (k >= 30) {
        d1 = new g0.d(g01);
      } else {
        g0.c c;
        if (k >= 29) {
          c = new g0.c((g0)d1);
        } else {
          g0.b b1;
          if (k >= 20) {
            b1 = new g0.b((g0)c);
          } else {
            e = new g0.e((g0)b1);
          } 
        } 
      } 
      e.d(b);
      this.B = e.b();
    } else {
      Rect rect = this.x;
      rect.top += i;
      rect.bottom += 0;
    } 
    p((View)this.h, this.u, true, true, true, true);
    if (k >= 21 && !this.C.equals(this.B)) {
      g0 g01 = this.B;
      this.C = g01;
      y.e((View)this.h, g01);
    } else if (k < 21 && !this.y.equals(this.x)) {
      this.y.set(this.x);
      this.h.a(this.x);
    } 
    measureChildWithMargins((View)this.h, paramInt1, 0, paramInt2, 0);
    e e1 = (e)this.h.getLayoutParams();
    int i = Math.max(i3, this.h.getMeasuredWidth() + e1.leftMargin + e1.rightMargin);
    int j = Math.max(i2, this.h.getMeasuredHeight() + e1.topMargin + e1.bottomMargin);
    k = View.combineMeasuredStates(i1, this.h.getMeasuredState());
    i1 = getPaddingLeft();
    i2 = getPaddingRight();
    i3 = getPaddingTop();
    j = Math.max(getPaddingBottom() + i3 + j, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i2 + i1 + i, getSuggestedMinimumWidth()), paramInt1, k), View.resolveSizeAndState(j, paramInt2, k << 16));
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    boolean bool1 = this.o;
    boolean bool = false;
    if (bool1) {
      if (!paramBoolean)
        return false; 
      this.E.fling(0, 0, 0, (int)paramFloat2, 0, 0, -2147483648, 2147483647);
      if (this.E.getFinalY() > this.i.getHeight())
        bool = true; 
      if (bool) {
        q();
        this.I.run();
      } else {
        q();
        this.H.run();
      } 
      this.p = true;
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {}
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = this.q + paramInt2;
    this.q = paramInt1;
    setActionBarHideOffset(paramInt1);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.J.a = paramInt;
    this.q = getActionBarHideOffset();
    q();
    d d1 = this.D;
    if (d1 != null) {
      w w = (w)d1;
      h h = w.t;
      if (h != null) {
        h.a();
        w.t = null;
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) == 0 || this.i.getVisibility() != 0) ? false : this.o;
  }
  
  public void onStopNestedScroll(View paramView) {
    if (this.o && !this.p)
      if (this.q <= this.i.getHeight()) {
        q();
        postDelayed(this.H, 600L);
      } else {
        q();
        postDelayed(this.I, 600L);
      }  
    d d1 = this.D;
    if (d1 != null)
      Objects.requireNonNull(d1); 
  }
  
  @Deprecated
  public void onWindowSystemUiVisibilityChanged(int paramInt) {
    boolean bool1;
    boolean bool2;
    super.onWindowSystemUiVisibilityChanged(paramInt);
    s();
    int i = this.r;
    this.r = paramInt;
    if ((paramInt & 0x4) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((paramInt & 0x100) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    d d1 = this.D;
    if (d1 != null) {
      w w;
      ((w)d1).p = bool2 ^ true;
      if (bool1 || !bool2) {
        w = (w)d1;
        if (w.q) {
          w.q = false;
          w.s(true);
        } 
      } else {
        w = w;
        if (!w.q) {
          w.q = true;
          w.s(true);
        } 
      } 
    } 
    if (((i ^ paramInt) & 0x100) != 0 && this.D != null)
      y.y((View)this); 
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    this.g = paramInt;
    d d1 = this.D;
    if (d1 != null)
      ((w)d1).o = paramInt; 
  }
  
  public final boolean p(View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/appcompat/widget/ActionBarOverlayLayout$e
    //   7: astore_1
    //   8: iload_3
    //   9: ifeq -> 43
    //   12: aload_1
    //   13: getfield leftMargin : I
    //   16: istore #7
    //   18: aload_2
    //   19: getfield left : I
    //   22: istore #8
    //   24: iload #7
    //   26: iload #8
    //   28: if_icmpeq -> 43
    //   31: aload_1
    //   32: iload #8
    //   34: putfield leftMargin : I
    //   37: iconst_1
    //   38: istore #9
    //   40: goto -> 46
    //   43: iconst_0
    //   44: istore #9
    //   46: iload #9
    //   48: istore_3
    //   49: iload #4
    //   51: ifeq -> 84
    //   54: aload_1
    //   55: getfield topMargin : I
    //   58: istore #7
    //   60: aload_2
    //   61: getfield top : I
    //   64: istore #8
    //   66: iload #9
    //   68: istore_3
    //   69: iload #7
    //   71: iload #8
    //   73: if_icmpeq -> 84
    //   76: aload_1
    //   77: iload #8
    //   79: putfield topMargin : I
    //   82: iconst_1
    //   83: istore_3
    //   84: iload_3
    //   85: istore #4
    //   87: iload #6
    //   89: ifeq -> 123
    //   92: aload_1
    //   93: getfield rightMargin : I
    //   96: istore #7
    //   98: aload_2
    //   99: getfield right : I
    //   102: istore #8
    //   104: iload_3
    //   105: istore #4
    //   107: iload #7
    //   109: iload #8
    //   111: if_icmpeq -> 123
    //   114: aload_1
    //   115: iload #8
    //   117: putfield rightMargin : I
    //   120: iconst_1
    //   121: istore #4
    //   123: iload #5
    //   125: ifeq -> 155
    //   128: aload_1
    //   129: getfield bottomMargin : I
    //   132: istore #7
    //   134: aload_2
    //   135: getfield bottom : I
    //   138: istore #8
    //   140: iload #7
    //   142: iload #8
    //   144: if_icmpeq -> 155
    //   147: aload_1
    //   148: iload #8
    //   150: putfield bottomMargin : I
    //   153: iconst_1
    //   154: ireturn
    //   155: iload #4
    //   157: ireturn
  }
  
  public void q() {
    removeCallbacks(this.H);
    removeCallbacks(this.I);
    ViewPropertyAnimator viewPropertyAnimator = this.F;
    if (viewPropertyAnimator != null)
      viewPropertyAnimator.cancel(); 
  }
  
  public final void r(Context paramContext) {
    TypedArray typedArray = getContext().getTheme().obtainStyledAttributes(K);
    boolean bool2 = false;
    this.f = typedArray.getDimensionPixelSize(0, 0);
    Drawable drawable = typedArray.getDrawable(1);
    this.k = drawable;
    if (drawable == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    setWillNotDraw(bool1);
    typedArray.recycle();
    boolean bool1 = bool2;
    if ((paramContext.getApplicationInfo()).targetSdkVersion < 19)
      bool1 = true; 
    this.l = bool1;
    this.E = new OverScroller(paramContext);
  }
  
  public void s() {
    if (this.h == null) {
      i0 i01;
      this.h = (ContentFrameLayout)findViewById(2131230770);
      this.i = (ActionBarContainer)findViewById(2131230771);
      View view = findViewById(2131230769);
      if (view instanceof i0) {
        i01 = (i0)view;
      } else if (i01 instanceof Toolbar) {
        i01 = ((Toolbar)i01).getWrapper();
      } else {
        StringBuilder stringBuilder = android.support.v4.media.a.a("Can't make a decor toolbar out of ");
        stringBuilder.append(i01.getClass().getSimpleName());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      this.j = i01;
      return;
    } 
  }
  
  public void setActionBarHideOffset(int paramInt) {
    q();
    paramInt = Math.max(0, Math.min(paramInt, this.i.getHeight()));
    this.i.setTranslationY(-paramInt);
  }
  
  public void setActionBarVisibilityCallback(d paramd) {
    this.D = paramd;
    if (getWindowToken() != null) {
      paramd = this.D;
      int i = this.g;
      ((w)paramd).o = i;
      i = this.r;
      if (i != 0) {
        onWindowSystemUiVisibilityChanged(i);
        y.y((View)this);
      } 
    } 
  }
  
  public void setHasNonEmbeddedTabs(boolean paramBoolean) {
    this.n = paramBoolean;
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean) {
    if (paramBoolean != this.o) {
      this.o = paramBoolean;
      if (!paramBoolean) {
        q();
        setActionBarHideOffset(0);
      } 
    } 
  }
  
  public void setIcon(int paramInt) {
    s();
    this.j.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    s();
    this.j.setIcon(paramDrawable);
  }
  
  public void setLogo(int paramInt) {
    s();
    this.j.r(paramInt);
  }
  
  public void setOverlayMode(boolean paramBoolean) {
    this.m = paramBoolean;
    if (paramBoolean && (getContext().getApplicationInfo()).targetSdkVersion < 19) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.l = paramBoolean;
  }
  
  public void setShowingForActionMode(boolean paramBoolean) {}
  
  public void setUiOptions(int paramInt) {}
  
  public void setWindowCallback(Window.Callback paramCallback) {
    s();
    this.j.setWindowCallback(paramCallback);
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    s();
    this.j.setWindowTitle(paramCharSequence);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public class a extends AnimatorListenerAdapter {
    public a(ActionBarOverlayLayout this$0) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.F = null;
      actionBarOverlayLayout.p = false;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.F = null;
      actionBarOverlayLayout.p = false;
    }
  }
  
  public class b implements Runnable {
    public b(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.f.q();
      ActionBarOverlayLayout actionBarOverlayLayout = this.f;
      actionBarOverlayLayout.F = actionBarOverlayLayout.i.animate().translationY(0.0F).setListener((Animator.AnimatorListener)this.f.G);
    }
  }
  
  public class c implements Runnable {
    public c(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.f.q();
      ActionBarOverlayLayout actionBarOverlayLayout = this.f;
      actionBarOverlayLayout.F = actionBarOverlayLayout.i.animate().translationY(-this.f.i.getHeight()).setListener((Animator.AnimatorListener)this.f.G);
    }
  }
  
  public static interface d {}
  
  public static class e extends ViewGroup.MarginLayoutParams {
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\ActionBarOverlayLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */