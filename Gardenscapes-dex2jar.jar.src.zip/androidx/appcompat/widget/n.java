package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.TextView;
import e.i;
import v0.f;

public class n {
  public final TextView a;
  
  public final f b;
  
  public n(TextView paramTextView) {
    this.a = paramTextView;
    this.b = new f(paramTextView, false);
  }
  
  public void a(AttributeSet paramAttributeSet, int paramInt) {
    TypedArray typedArray = this.a.getContext().obtainStyledAttributes(paramAttributeSet, i.i, paramInt, 0);
    try {
      boolean bool2 = typedArray.hasValue(14);
      boolean bool1 = true;
      if (bool2)
        bool1 = typedArray.getBoolean(14, true); 
      typedArray.recycle();
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  public void b(boolean paramBoolean) {
    this.b.a.d(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */