package androidx.appcompat.widget;

import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import k.a;

public class f1 implements View.OnClickListener {
  public final a f;
  
  public f1(g1 paramg1) {
    this.f = new a(paramg1.a.getContext(), 0, 16908332, 0, paramg1.i);
  }
  
  public void onClick(View paramView) {
    g1 g11 = this.g;
    Window.Callback callback = g11.l;
    if (callback != null && g11.m)
      callback.onMenuItemSelected(0, (MenuItem)this.f); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */