package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.SeekBar;

public class w extends SeekBar {
  public final x f;
  
  public w(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903830);
    y0.a((View)this, getContext());
    x x1 = new x(this);
    this.f = x1;
    x1.a(paramAttributeSet, 2130903830);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    x x1 = this.f;
    Drawable drawable = x1.e;
    if (drawable != null && drawable.isStateful() && drawable.setState(x1.d.getDrawableState()))
      x1.d.invalidateDrawable(drawable); 
  }
  
  public void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    Drawable drawable = this.f.e;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
  }
  
  public void onDraw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokespecial onDraw : (Landroid/graphics/Canvas;)V
    //   7: aload_0
    //   8: getfield f : Landroidx/appcompat/widget/x;
    //   11: aload_1
    //   12: invokevirtual d : (Landroid/graphics/Canvas;)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */