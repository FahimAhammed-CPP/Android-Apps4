package androidx.appcompat.widget;

import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import m0.y;

public class l1 {
  public static Method a;
  
  static {
    try {
      Method method = View.class.getDeclaredMethod("computeFitSystemWindows", new Class[] { Rect.class, Rect.class });
      a = method;
      if (!method.isAccessible()) {
        a.setAccessible(true);
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.d("ViewUtils", "Could not find method computeFitSystemWindows. Oh well.");
    } 
  }
  
  public static void a(View paramView, Rect paramRect1, Rect paramRect2) {
    Method method = a;
    if (method != null)
      try {
        method.invoke(paramView, new Object[] { paramRect1, paramRect2 });
        return;
      } catch (Exception exception) {
        Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", exception);
      }  
  }
  
  public static boolean b(View paramView) {
    WeakHashMap weakHashMap = y.a;
    return (y.e.d(paramView) == 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\appcompat\widget\l1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */