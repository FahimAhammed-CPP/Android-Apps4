package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.util.Xml;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;
import x.d;

public class ConstraintAttribute {
  public String a;
  
  public AttributeType b;
  
  public int c;
  
  public float d;
  
  public String e;
  
  public boolean f;
  
  public int g;
  
  public ConstraintAttribute(ConstraintAttribute paramConstraintAttribute, Object paramObject) {
    this.a = paramConstraintAttribute.a;
    this.b = paramConstraintAttribute.b;
    b(paramObject);
  }
  
  public ConstraintAttribute(String paramString, AttributeType paramAttributeType, Object paramObject) {
    this.a = paramString;
    this.b = paramAttributeType;
    b(paramObject);
  }
  
  public static void a(Context paramContext, XmlPullParser paramXmlPullParser, HashMap<String, ConstraintAttribute> paramHashMap) {
    AttributeType attributeType = AttributeType.l;
    TypedArray typedArray = paramContext.obtainStyledAttributes(Xml.asAttributeSet(paramXmlPullParser), d.d);
    int j = typedArray.getIndexCount();
    Object object1 = null;
    XmlPullParser xmlPullParser = null;
    Object object2 = xmlPullParser;
    int i = 0;
    while (true) {
      if (i < j) {
        int k = typedArray.getIndex(i);
        if (k == 0) {
          object1 = typedArray.getString(k);
          Object object = object1;
          paramXmlPullParser = xmlPullParser;
          object4 = object2;
          if (object1 != null) {
            object = object1;
            paramXmlPullParser = xmlPullParser;
            object4 = object2;
            if (object1.length() > 0) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(Character.toUpperCase(object1.charAt(0)));
              stringBuilder.append(object1.substring(1));
              object = stringBuilder.toString();
              object3 = xmlPullParser;
              object4 = object2;
            } 
          } 
          continue;
        } 
        if (k == 1) {
          object3 = Boolean.valueOf(typedArray.getBoolean(k, false));
          object4 = AttributeType.k;
          Object object = object1;
          continue;
        } 
        if (k == 3) {
          object3 = AttributeType.h;
          object4 = Integer.valueOf(typedArray.getColor(k, 0));
        } else if (k == 2) {
          object3 = AttributeType.i;
          object4 = Integer.valueOf(typedArray.getColor(k, 0));
        } else {
          if (k == 7) {
            object3 = Float.valueOf(TypedValue.applyDimension(1, typedArray.getDimension(k, 0.0F), paramContext.getResources().getDisplayMetrics()));
          } else if (k == 4) {
            object3 = Float.valueOf(typedArray.getDimension(k, 0.0F));
          } else {
            AttributeType attributeType1;
            if (k == 5) {
              attributeType1 = AttributeType.g;
              object6 = Float.valueOf(typedArray.getFloat(k, Float.NaN));
            } else if (k == 6) {
              attributeType1 = AttributeType.f;
              object6 = Integer.valueOf(typedArray.getInteger(k, -1));
            } else {
              Object object8 = object1;
              paramXmlPullParser = xmlPullParser;
              object6 = object2;
              if (k == 8) {
                attributeType1 = AttributeType.j;
                object6 = typedArray.getString(k);
              } else {
                continue;
              } 
            } 
            Object object7 = object6;
            Object object6 = attributeType1;
            object3 = object7;
            object7 = object1;
          } 
          object4 = attributeType;
          Object object = object1;
          continue;
        } 
      } else {
        break;
      } 
      Object object5 = object4;
      Object object4 = object3;
      Object object3 = object5;
      object5 = object1;
      i++;
      object1 = SYNTHETIC_LOCAL_VARIABLE_7;
      xmlPullParser = paramXmlPullParser;
      object2 = SYNTHETIC_LOCAL_VARIABLE_6;
    } 
    if (object1 != null && xmlPullParser != null)
      paramHashMap.put(object1, new ConstraintAttribute((String)object1, (AttributeType)object2, xmlPullParser)); 
    typedArray.recycle();
  }
  
  public void b(Object paramObject) {
    switch (this.b.ordinal()) {
      default:
        return;
      case 6:
        this.d = ((Float)paramObject).floatValue();
        return;
      case 5:
        this.f = ((Boolean)paramObject).booleanValue();
        return;
      case 4:
        this.e = (String)paramObject;
        return;
      case 1:
        this.d = ((Float)paramObject).floatValue();
        return;
      case 0:
        this.c = ((Integer)paramObject).intValue();
        return;
      case 2:
      case 3:
        break;
    } 
    this.g = ((Integer)paramObject).intValue();
  }
  
  public enum AttributeType {
    f, g, h, i, j, k, l;
    
    static {
      AttributeType attributeType1 = new AttributeType("INT_TYPE", 0);
      f = attributeType1;
      AttributeType attributeType2 = new AttributeType("FLOAT_TYPE", 1);
      g = attributeType2;
      AttributeType attributeType3 = new AttributeType("COLOR_TYPE", 2);
      h = attributeType3;
      AttributeType attributeType4 = new AttributeType("COLOR_DRAWABLE_TYPE", 3);
      i = attributeType4;
      AttributeType attributeType5 = new AttributeType("STRING_TYPE", 4);
      j = attributeType5;
      AttributeType attributeType6 = new AttributeType("BOOLEAN_TYPE", 5);
      k = attributeType6;
      AttributeType attributeType7 = new AttributeType("DIMENSION_TYPE", 6);
      l = attributeType7;
      m = new AttributeType[] { attributeType1, attributeType2, attributeType3, attributeType4, attributeType5, attributeType6, attributeType7 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */