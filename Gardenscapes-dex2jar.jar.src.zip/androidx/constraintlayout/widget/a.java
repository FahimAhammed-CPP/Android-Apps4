package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import java.util.Arrays;
import java.util.HashMap;
import v.b;
import x.c;
import x.d;

public abstract class a extends View {
  public int[] f = new int[32];
  
  public int g;
  
  public Context h;
  
  public b i;
  
  public String j;
  
  public HashMap<Integer, String> k = new HashMap<Integer, String>();
  
  public a(Context paramContext) {
    super(paramContext);
    this.h = paramContext;
    e(null);
  }
  
  public a(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.h = paramContext;
    e(paramAttributeSet);
  }
  
  public final void a(String paramString) {
    if (paramString != null) {
      if (paramString.length() == 0)
        return; 
      if (this.h == null)
        return; 
      String str = paramString.trim();
      if (getParent() instanceof ConstraintLayout)
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent(); 
      if (getParent() instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent();
      } else {
        paramString = null;
      } 
      boolean bool = isInEditMode();
      int i = 0;
      int j = i;
      if (bool) {
        j = i;
        if (paramString != null) {
          Object object = paramString.c(0, str);
          j = i;
          if (object instanceof Integer)
            j = ((Integer)object).intValue(); 
        } 
      } 
      i = j;
      if (j == 0) {
        i = j;
        if (paramString != null)
          i = d((ConstraintLayout)paramString, str); 
      } 
      j = i;
      if (i == 0)
        try {
          j = c.class.getField(str).getInt(null);
        } catch (Exception exception) {
          j = i;
        }  
      i = j;
      if (j == 0)
        i = this.h.getResources().getIdentifier(str, "id", this.h.getPackageName()); 
      if (i != 0) {
        this.k.put(Integer.valueOf(i), str);
        b(i);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find id of \"");
      stringBuilder.append(str);
      stringBuilder.append("\"");
      Log.w("ConstraintHelper", stringBuilder.toString());
    } 
  }
  
  public final void b(int paramInt) {
    if (paramInt == getId())
      return; 
    int i = this.g;
    int[] arrayOfInt = this.f;
    if (i + 1 > arrayOfInt.length)
      this.f = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2); 
    arrayOfInt = this.f;
    i = this.g;
    arrayOfInt[i] = paramInt;
    this.g = i + 1;
  }
  
  public void c() {
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout) {
      float f;
      ConstraintLayout constraintLayout = (ConstraintLayout)viewParent;
      int j = getVisibility();
      if (Build.VERSION.SDK_INT >= 21) {
        f = getElevation();
      } else {
        f = 0.0F;
      } 
      for (int i = 0; i < this.g; i++) {
        View view = constraintLayout.d(this.f[i]);
        if (view != null) {
          view.setVisibility(j);
          if (f > 0.0F && Build.VERSION.SDK_INT >= 21)
            view.setTranslationZ(view.getTranslationZ() + f); 
        } 
      } 
    } 
  }
  
  public final int d(ConstraintLayout paramConstraintLayout, String paramString) {
    if (paramString != null) {
      Resources resources = this.h.getResources();
      if (resources == null)
        return 0; 
      int j = paramConstraintLayout.getChildCount();
      int i = 0;
      while (true) {
        if (i < j) {
          View view = paramConstraintLayout.getChildAt(i);
          if (view.getId() != -1) {
            String str = null;
            try {
              String str1 = resources.getResourceEntryName(view.getId());
              str = str1;
            } catch (android.content.res.Resources.NotFoundException notFoundException) {}
            if (paramString.equals(str))
              return view.getId(); 
          } 
          i++;
          continue;
        } 
        return 0;
      } 
    } 
    return 0;
  }
  
  public void e(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, d.b);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == 19) {
          String str = typedArray.getString(k);
          this.j = str;
          setIds(str);
        } 
      } 
    } 
  }
  
  public void f(ConstraintWidget paramConstraintWidget, boolean paramBoolean) {}
  
  public void g() {
    if (this.i == null)
      return; 
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.a)
      ((ConstraintLayout.a)layoutParams).l0 = (ConstraintWidget)this.i; 
  }
  
  public int[] getReferencedIds() {
    return Arrays.copyOf(this.f, this.g);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    String str = this.j;
    if (str != null)
      setIds(str); 
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  public void onMeasure(int paramInt1, int paramInt2) {
    setMeasuredDimension(0, 0);
  }
  
  public void setIds(String paramString) {
    this.j = paramString;
    if (paramString == null)
      return; 
    int i = 0;
    this.g = 0;
    while (true) {
      int j = paramString.indexOf(',', i);
      if (j == -1) {
        a(paramString.substring(i));
        return;
      } 
      a(paramString.substring(i, j));
      i = j + 1;
    } 
  }
  
  public void setReferencedIds(int[] paramArrayOfint) {
    this.j = null;
    int i = 0;
    this.g = 0;
    while (i < paramArrayOfint.length) {
      b(paramArrayOfint[i]);
      i++;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */