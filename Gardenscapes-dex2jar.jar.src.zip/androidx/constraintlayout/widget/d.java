package androidx.constraintlayout.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;

public class d extends View {
  public int f;
  
  public View g;
  
  public int h;
  
  public View getContent() {
    return this.g;
  }
  
  public int getEmptyVisibility() {
    return this.h;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (isInEditMode()) {
      paramCanvas.drawRGB(223, 223, 223);
      Paint paint = new Paint();
      paint.setARGB(255, 210, 210, 210);
      paint.setTextAlign(Paint.Align.CENTER);
      paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
      Rect rect = new Rect();
      paramCanvas.getClipBounds(rect);
      paint.setTextSize(rect.height());
      int i = rect.height();
      int j = rect.width();
      paint.setTextAlign(Paint.Align.LEFT);
      paint.getTextBounds("?", 0, 1, rect);
      float f1 = j / 2.0F;
      float f2 = rect.width() / 2.0F;
      float f3 = rect.left;
      float f4 = i / 2.0F;
      paramCanvas.drawText("?", f1 - f2 - f3, rect.height() / 2.0F + f4 - rect.bottom, paint);
    } 
  }
  
  public void setContentId(int paramInt) {
    if (this.f == paramInt)
      return; 
    View view = this.g;
    if (view != null) {
      view.setVisibility(0);
      ((ConstraintLayout.a)this.g.getLayoutParams()).a0 = false;
      this.g = null;
    } 
    this.f = paramInt;
    if (paramInt != -1) {
      view = ((View)getParent()).findViewById(paramInt);
      if (view != null)
        view.setVisibility(8); 
    } 
  }
  
  public void setEmptyVisibility(int paramInt) {
    this.h = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */