package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.View;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class b {
  public static final int[] d = new int[] { 0, 4, 8 };
  
  public static SparseIntArray e;
  
  public HashMap<String, ConstraintAttribute> a = new HashMap<String, ConstraintAttribute>();
  
  public boolean b = true;
  
  public HashMap<Integer, a> c = new HashMap<Integer, a>();
  
  static {
    SparseIntArray sparseIntArray = new SparseIntArray();
    e = sparseIntArray;
    sparseIntArray.append(76, 25);
    e.append(77, 26);
    e.append(79, 29);
    e.append(80, 30);
    e.append(86, 36);
    e.append(85, 35);
    e.append(58, 4);
    e.append(57, 3);
    e.append(55, 1);
    e.append(94, 6);
    e.append(95, 7);
    e.append(65, 17);
    e.append(66, 18);
    e.append(67, 19);
    e.append(0, 27);
    e.append(81, 32);
    e.append(82, 33);
    e.append(64, 10);
    e.append(63, 9);
    e.append(98, 13);
    e.append(101, 16);
    e.append(99, 14);
    e.append(96, 11);
    e.append(100, 15);
    e.append(97, 12);
    e.append(89, 40);
    e.append(74, 39);
    e.append(73, 41);
    e.append(88, 42);
    e.append(72, 20);
    e.append(87, 37);
    e.append(62, 5);
    e.append(75, 82);
    e.append(84, 82);
    e.append(78, 82);
    e.append(56, 82);
    e.append(54, 82);
    e.append(5, 24);
    e.append(7, 28);
    e.append(23, 31);
    e.append(24, 8);
    e.append(6, 34);
    e.append(8, 2);
    e.append(3, 23);
    e.append(4, 21);
    e.append(2, 22);
    e.append(13, 43);
    e.append(26, 44);
    e.append(21, 45);
    e.append(22, 46);
    e.append(20, 60);
    e.append(18, 47);
    e.append(19, 48);
    e.append(14, 49);
    e.append(15, 50);
    e.append(16, 51);
    e.append(17, 52);
    e.append(25, 53);
    e.append(90, 54);
    e.append(68, 55);
    e.append(91, 56);
    e.append(69, 57);
    e.append(92, 58);
    e.append(70, 59);
    e.append(59, 61);
    e.append(61, 62);
    e.append(60, 63);
    e.append(27, 64);
    e.append(106, 65);
    e.append(33, 66);
    e.append(107, 67);
    e.append(103, 79);
    e.append(1, 38);
    e.append(102, 68);
    e.append(93, 69);
    e.append(71, 70);
    e.append(31, 71);
    e.append(29, 72);
    e.append(30, 73);
    e.append(32, 74);
    e.append(28, 75);
    e.append(104, 76);
    e.append(83, 77);
    e.append(108, 78);
    e.append(53, 80);
    e.append(52, 81);
  }
  
  public void a(ConstraintLayout paramConstraintLayout, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getChildCount : ()I
    //   4: istore_3
    //   5: new java/util/HashSet
    //   8: dup
    //   9: aload_0
    //   10: getfield c : Ljava/util/HashMap;
    //   13: invokevirtual keySet : ()Ljava/util/Set;
    //   16: invokespecial <init> : (Ljava/util/Collection;)V
    //   19: astore #10
    //   21: iconst_0
    //   22: istore #5
    //   24: iload #5
    //   26: iload_3
    //   27: if_icmpge -> 1341
    //   30: aload_1
    //   31: iload #5
    //   33: invokevirtual getChildAt : (I)Landroid/view/View;
    //   36: astore #11
    //   38: aload #11
    //   40: invokevirtual getId : ()I
    //   43: istore #4
    //   45: aload_0
    //   46: getfield c : Ljava/util/HashMap;
    //   49: iload #4
    //   51: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   54: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   57: ifne -> 114
    //   60: ldc 'id unknown '
    //   62: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: astore #8
    //   67: aload #11
    //   69: invokevirtual getContext : ()Landroid/content/Context;
    //   72: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   75: aload #11
    //   77: invokevirtual getId : ()I
    //   80: invokevirtual getResourceEntryName : (I)Ljava/lang/String;
    //   83: astore #7
    //   85: goto -> 92
    //   88: ldc 'UNKNOWN'
    //   90: astore #7
    //   92: aload #8
    //   94: aload #7
    //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: pop
    //   100: ldc 'ConstraintSet'
    //   102: aload #8
    //   104: invokevirtual toString : ()Ljava/lang/String;
    //   107: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   110: pop
    //   111: goto -> 146
    //   114: aload_0
    //   115: getfield b : Z
    //   118: ifeq -> 140
    //   121: iload #4
    //   123: iconst_m1
    //   124: if_icmpeq -> 130
    //   127: goto -> 140
    //   130: new java/lang/RuntimeException
    //   133: dup
    //   134: ldc 'All children of ConstraintLayout must have ids to use ConstraintSet'
    //   136: invokespecial <init> : (Ljava/lang/String;)V
    //   139: athrow
    //   140: iload #4
    //   142: iconst_m1
    //   143: if_icmpne -> 149
    //   146: goto -> 1332
    //   149: aload_0
    //   150: getfield c : Ljava/util/HashMap;
    //   153: iload #4
    //   155: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   158: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   161: ifeq -> 1295
    //   164: aload #10
    //   166: iload #4
    //   168: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   171: invokevirtual remove : (Ljava/lang/Object;)Z
    //   174: pop
    //   175: aload_0
    //   176: getfield c : Ljava/util/HashMap;
    //   179: iload #4
    //   181: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   184: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   187: checkcast androidx/constraintlayout/widget/b$a
    //   190: astore #12
    //   192: aload #11
    //   194: instanceof androidx/constraintlayout/widget/Barrier
    //   197: ifeq -> 209
    //   200: aload #12
    //   202: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   205: iconst_1
    //   206: putfield d0 : I
    //   209: aload #12
    //   211: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   214: getfield d0 : I
    //   217: istore #6
    //   219: iload #6
    //   221: iconst_m1
    //   222: if_icmpeq -> 354
    //   225: iload #6
    //   227: iconst_1
    //   228: if_icmpeq -> 234
    //   231: goto -> 354
    //   234: aload #11
    //   236: checkcast androidx/constraintlayout/widget/Barrier
    //   239: astore #7
    //   241: aload #7
    //   243: iload #4
    //   245: invokevirtual setId : (I)V
    //   248: aload #7
    //   250: aload #12
    //   252: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   255: getfield b0 : I
    //   258: invokevirtual setType : (I)V
    //   261: aload #7
    //   263: aload #12
    //   265: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   268: getfield c0 : I
    //   271: invokevirtual setMargin : (I)V
    //   274: aload #7
    //   276: aload #12
    //   278: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   281: getfield j0 : Z
    //   284: invokevirtual setAllowsGoneWidget : (Z)V
    //   287: aload #12
    //   289: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   292: astore #8
    //   294: aload #8
    //   296: getfield e0 : [I
    //   299: astore #9
    //   301: aload #9
    //   303: ifnull -> 316
    //   306: aload #7
    //   308: aload #9
    //   310: invokevirtual setReferencedIds : ([I)V
    //   313: goto -> 354
    //   316: aload #8
    //   318: getfield f0 : Ljava/lang/String;
    //   321: astore #9
    //   323: aload #9
    //   325: ifnull -> 354
    //   328: aload #8
    //   330: aload_0
    //   331: aload #7
    //   333: aload #9
    //   335: invokevirtual c : (Landroid/view/View;Ljava/lang/String;)[I
    //   338: putfield e0 : [I
    //   341: aload #7
    //   343: aload #12
    //   345: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   348: getfield e0 : [I
    //   351: invokevirtual setReferencedIds : ([I)V
    //   354: aload #11
    //   356: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   359: checkcast androidx/constraintlayout/widget/ConstraintLayout$a
    //   362: astore #13
    //   364: aload #13
    //   366: invokevirtual a : ()V
    //   369: aload #12
    //   371: aload #13
    //   373: invokevirtual a : (Landroidx/constraintlayout/widget/ConstraintLayout$a;)V
    //   376: iload_3
    //   377: istore #4
    //   379: iload_2
    //   380: ifeq -> 1043
    //   383: aload #12
    //   385: getfield f : Ljava/util/HashMap;
    //   388: astore #8
    //   390: aload #11
    //   392: invokevirtual getClass : ()Ljava/lang/Class;
    //   395: astore #14
    //   397: aload #8
    //   399: invokevirtual keySet : ()Ljava/util/Set;
    //   402: invokeinterface iterator : ()Ljava/util/Iterator;
    //   407: astore #7
    //   409: iload_3
    //   410: istore #4
    //   412: aload #7
    //   414: invokeinterface hasNext : ()Z
    //   419: ifeq -> 1043
    //   422: aload #7
    //   424: invokeinterface next : ()Ljava/lang/Object;
    //   429: checkcast java/lang/String
    //   432: astore #15
    //   434: aload #8
    //   436: aload #15
    //   438: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   441: checkcast androidx/constraintlayout/widget/ConstraintAttribute
    //   444: astore #9
    //   446: ldc 'set'
    //   448: aload #15
    //   450: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   453: astore #16
    //   455: aload #9
    //   457: getfield b : Landroidx/constraintlayout/widget/ConstraintAttribute$AttributeType;
    //   460: invokevirtual ordinal : ()I
    //   463: istore #4
    //   465: iload #4
    //   467: tableswitch default -> 508, 0 -> 771, 1 -> 730, 2 -> 689, 3 -> 631, 4 -> 593, 5 -> 552, 6 -> 511
    //   508: goto -> 1040
    //   511: aload #14
    //   513: aload #16
    //   515: iconst_1
    //   516: anewarray java/lang/Class
    //   519: dup
    //   520: iconst_0
    //   521: getstatic java/lang/Float.TYPE : Ljava/lang/Class;
    //   524: aastore
    //   525: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   528: aload #11
    //   530: iconst_1
    //   531: anewarray java/lang/Object
    //   534: dup
    //   535: iconst_0
    //   536: aload #9
    //   538: getfield d : F
    //   541: invokestatic valueOf : (F)Ljava/lang/Float;
    //   544: aastore
    //   545: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   548: pop
    //   549: goto -> 1040
    //   552: aload #14
    //   554: aload #16
    //   556: iconst_1
    //   557: anewarray java/lang/Class
    //   560: dup
    //   561: iconst_0
    //   562: getstatic java/lang/Boolean.TYPE : Ljava/lang/Class;
    //   565: aastore
    //   566: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   569: aload #11
    //   571: iconst_1
    //   572: anewarray java/lang/Object
    //   575: dup
    //   576: iconst_0
    //   577: aload #9
    //   579: getfield f : Z
    //   582: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   585: aastore
    //   586: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   589: pop
    //   590: goto -> 1040
    //   593: aload #14
    //   595: aload #16
    //   597: iconst_1
    //   598: anewarray java/lang/Class
    //   601: dup
    //   602: iconst_0
    //   603: ldc_w java/lang/CharSequence
    //   606: aastore
    //   607: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   610: aload #11
    //   612: iconst_1
    //   613: anewarray java/lang/Object
    //   616: dup
    //   617: iconst_0
    //   618: aload #9
    //   620: getfield e : Ljava/lang/String;
    //   623: aastore
    //   624: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   627: pop
    //   628: goto -> 1040
    //   631: aload #14
    //   633: aload #16
    //   635: iconst_1
    //   636: anewarray java/lang/Class
    //   639: dup
    //   640: iconst_0
    //   641: ldc_w android/graphics/drawable/Drawable
    //   644: aastore
    //   645: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   648: astore #17
    //   650: new android/graphics/drawable/ColorDrawable
    //   653: dup
    //   654: invokespecial <init> : ()V
    //   657: astore #18
    //   659: aload #18
    //   661: aload #9
    //   663: getfield g : I
    //   666: invokevirtual setColor : (I)V
    //   669: aload #17
    //   671: aload #11
    //   673: iconst_1
    //   674: anewarray java/lang/Object
    //   677: dup
    //   678: iconst_0
    //   679: aload #18
    //   681: aastore
    //   682: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   685: pop
    //   686: goto -> 1040
    //   689: aload #14
    //   691: aload #16
    //   693: iconst_1
    //   694: anewarray java/lang/Class
    //   697: dup
    //   698: iconst_0
    //   699: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   702: aastore
    //   703: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   706: aload #11
    //   708: iconst_1
    //   709: anewarray java/lang/Object
    //   712: dup
    //   713: iconst_0
    //   714: aload #9
    //   716: getfield g : I
    //   719: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   722: aastore
    //   723: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   726: pop
    //   727: goto -> 1040
    //   730: aload #14
    //   732: aload #16
    //   734: iconst_1
    //   735: anewarray java/lang/Class
    //   738: dup
    //   739: iconst_0
    //   740: getstatic java/lang/Float.TYPE : Ljava/lang/Class;
    //   743: aastore
    //   744: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   747: aload #11
    //   749: iconst_1
    //   750: anewarray java/lang/Object
    //   753: dup
    //   754: iconst_0
    //   755: aload #9
    //   757: getfield d : F
    //   760: invokestatic valueOf : (F)Ljava/lang/Float;
    //   763: aastore
    //   764: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   767: pop
    //   768: goto -> 1040
    //   771: aload #14
    //   773: aload #16
    //   775: iconst_1
    //   776: anewarray java/lang/Class
    //   779: dup
    //   780: iconst_0
    //   781: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   784: aastore
    //   785: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   788: aload #11
    //   790: iconst_1
    //   791: anewarray java/lang/Object
    //   794: dup
    //   795: iconst_0
    //   796: aload #9
    //   798: getfield c : I
    //   801: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   804: aastore
    //   805: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   808: pop
    //   809: goto -> 1040
    //   812: astore #9
    //   814: goto -> 829
    //   817: astore #9
    //   819: goto -> 875
    //   822: astore #9
    //   824: goto -> 921
    //   827: astore #9
    //   829: ldc_w ' Custom Attribute "'
    //   832: aload #15
    //   834: ldc_w '" not found on '
    //   837: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   840: astore #15
    //   842: aload #15
    //   844: aload #14
    //   846: invokevirtual getName : ()Ljava/lang/String;
    //   849: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   852: pop
    //   853: ldc_w 'TransitionLayout'
    //   856: aload #15
    //   858: invokevirtual toString : ()Ljava/lang/String;
    //   861: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   864: pop
    //   865: aload #9
    //   867: invokevirtual printStackTrace : ()V
    //   870: goto -> 1040
    //   873: astore #9
    //   875: ldc_w ' Custom Attribute "'
    //   878: aload #15
    //   880: ldc_w '" not found on '
    //   883: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   886: astore #15
    //   888: aload #15
    //   890: aload #14
    //   892: invokevirtual getName : ()Ljava/lang/String;
    //   895: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   898: pop
    //   899: ldc_w 'TransitionLayout'
    //   902: aload #15
    //   904: invokevirtual toString : ()Ljava/lang/String;
    //   907: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   910: pop
    //   911: aload #9
    //   913: invokevirtual printStackTrace : ()V
    //   916: goto -> 1040
    //   919: astore #9
    //   921: ldc_w 'TransitionLayout'
    //   924: aload #9
    //   926: invokevirtual getMessage : ()Ljava/lang/String;
    //   929: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   932: pop
    //   933: new java/lang/StringBuilder
    //   936: dup
    //   937: invokespecial <init> : ()V
    //   940: astore #9
    //   942: aload #9
    //   944: ldc_w ' Custom Attribute "'
    //   947: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   950: pop
    //   951: aload #9
    //   953: aload #15
    //   955: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   958: pop
    //   959: aload #9
    //   961: ldc_w '" not found on '
    //   964: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   967: pop
    //   968: aload #9
    //   970: aload #14
    //   972: invokevirtual getName : ()Ljava/lang/String;
    //   975: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   978: pop
    //   979: ldc_w 'TransitionLayout'
    //   982: aload #9
    //   984: invokevirtual toString : ()Ljava/lang/String;
    //   987: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   990: pop
    //   991: new java/lang/StringBuilder
    //   994: dup
    //   995: invokespecial <init> : ()V
    //   998: astore #9
    //   1000: aload #9
    //   1002: aload #14
    //   1004: invokevirtual getName : ()Ljava/lang/String;
    //   1007: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1010: pop
    //   1011: aload #9
    //   1013: ldc_w ' must have a method '
    //   1016: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1019: pop
    //   1020: aload #9
    //   1022: aload #16
    //   1024: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1027: pop
    //   1028: ldc_w 'TransitionLayout'
    //   1031: aload #9
    //   1033: invokevirtual toString : ()Ljava/lang/String;
    //   1036: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1039: pop
    //   1040: goto -> 409
    //   1043: aload #11
    //   1045: aload #13
    //   1047: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
    //   1050: aload #12
    //   1052: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   1055: astore #7
    //   1057: aload #7
    //   1059: getfield c : I
    //   1062: ifne -> 1075
    //   1065: aload #11
    //   1067: aload #7
    //   1069: getfield b : I
    //   1072: invokevirtual setVisibility : (I)V
    //   1075: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1078: istore #6
    //   1080: aload #11
    //   1082: aload #12
    //   1084: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   1087: getfield d : F
    //   1090: invokevirtual setAlpha : (F)V
    //   1093: aload #11
    //   1095: aload #12
    //   1097: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1100: getfield b : F
    //   1103: invokevirtual setRotation : (F)V
    //   1106: aload #11
    //   1108: aload #12
    //   1110: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1113: getfield c : F
    //   1116: invokevirtual setRotationX : (F)V
    //   1119: aload #11
    //   1121: aload #12
    //   1123: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1126: getfield d : F
    //   1129: invokevirtual setRotationY : (F)V
    //   1132: aload #11
    //   1134: aload #12
    //   1136: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1139: getfield e : F
    //   1142: invokevirtual setScaleX : (F)V
    //   1145: aload #11
    //   1147: aload #12
    //   1149: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1152: getfield f : F
    //   1155: invokevirtual setScaleY : (F)V
    //   1158: aload #12
    //   1160: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1163: getfield g : F
    //   1166: invokestatic isNaN : (F)Z
    //   1169: ifne -> 1185
    //   1172: aload #11
    //   1174: aload #12
    //   1176: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1179: getfield g : F
    //   1182: invokevirtual setPivotX : (F)V
    //   1185: aload #12
    //   1187: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1190: getfield h : F
    //   1193: invokestatic isNaN : (F)Z
    //   1196: ifne -> 1212
    //   1199: aload #11
    //   1201: aload #12
    //   1203: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1206: getfield h : F
    //   1209: invokevirtual setPivotY : (F)V
    //   1212: aload #11
    //   1214: aload #12
    //   1216: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1219: getfield i : F
    //   1222: invokevirtual setTranslationX : (F)V
    //   1225: aload #11
    //   1227: aload #12
    //   1229: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1232: getfield j : F
    //   1235: invokevirtual setTranslationY : (F)V
    //   1238: iload #4
    //   1240: istore_3
    //   1241: iload #6
    //   1243: bipush #21
    //   1245: if_icmplt -> 1332
    //   1248: aload #11
    //   1250: aload #12
    //   1252: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1255: getfield k : F
    //   1258: invokevirtual setTranslationZ : (F)V
    //   1261: aload #12
    //   1263: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1266: astore #7
    //   1268: iload #4
    //   1270: istore_3
    //   1271: aload #7
    //   1273: getfield l : Z
    //   1276: ifeq -> 1332
    //   1279: aload #11
    //   1281: aload #7
    //   1283: getfield m : F
    //   1286: invokevirtual setElevation : (F)V
    //   1289: iload #4
    //   1291: istore_3
    //   1292: goto -> 1332
    //   1295: new java/lang/StringBuilder
    //   1298: dup
    //   1299: invokespecial <init> : ()V
    //   1302: astore #7
    //   1304: aload #7
    //   1306: ldc_w 'WARNING NO CONSTRAINTS for view '
    //   1309: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1312: pop
    //   1313: aload #7
    //   1315: iload #4
    //   1317: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1320: pop
    //   1321: ldc 'ConstraintSet'
    //   1323: aload #7
    //   1325: invokevirtual toString : ()Ljava/lang/String;
    //   1328: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1331: pop
    //   1332: iload #5
    //   1334: iconst_1
    //   1335: iadd
    //   1336: istore #5
    //   1338: goto -> 24
    //   1341: aload #10
    //   1343: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1346: astore #7
    //   1348: aload #7
    //   1350: invokeinterface hasNext : ()Z
    //   1355: ifeq -> 1606
    //   1358: aload #7
    //   1360: invokeinterface next : ()Ljava/lang/Object;
    //   1365: checkcast java/lang/Integer
    //   1368: astore #9
    //   1370: aload_0
    //   1371: getfield c : Ljava/util/HashMap;
    //   1374: aload #9
    //   1376: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1379: checkcast androidx/constraintlayout/widget/b$a
    //   1382: astore #8
    //   1384: aload #8
    //   1386: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1389: getfield d0 : I
    //   1392: istore_3
    //   1393: iload_3
    //   1394: iconst_m1
    //   1395: if_icmpeq -> 1548
    //   1398: iload_3
    //   1399: iconst_1
    //   1400: if_icmpeq -> 1406
    //   1403: goto -> 1548
    //   1406: new androidx/constraintlayout/widget/Barrier
    //   1409: dup
    //   1410: aload_1
    //   1411: invokevirtual getContext : ()Landroid/content/Context;
    //   1414: invokespecial <init> : (Landroid/content/Context;)V
    //   1417: astore #10
    //   1419: aload #10
    //   1421: aload #9
    //   1423: invokevirtual intValue : ()I
    //   1426: invokevirtual setId : (I)V
    //   1429: aload #8
    //   1431: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1434: astore #11
    //   1436: aload #11
    //   1438: getfield e0 : [I
    //   1441: astore #12
    //   1443: aload #12
    //   1445: ifnull -> 1458
    //   1448: aload #10
    //   1450: aload #12
    //   1452: invokevirtual setReferencedIds : ([I)V
    //   1455: goto -> 1496
    //   1458: aload #11
    //   1460: getfield f0 : Ljava/lang/String;
    //   1463: astore #12
    //   1465: aload #12
    //   1467: ifnull -> 1496
    //   1470: aload #11
    //   1472: aload_0
    //   1473: aload #10
    //   1475: aload #12
    //   1477: invokevirtual c : (Landroid/view/View;Ljava/lang/String;)[I
    //   1480: putfield e0 : [I
    //   1483: aload #10
    //   1485: aload #8
    //   1487: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1490: getfield e0 : [I
    //   1493: invokevirtual setReferencedIds : ([I)V
    //   1496: aload #10
    //   1498: aload #8
    //   1500: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1503: getfield b0 : I
    //   1506: invokevirtual setType : (I)V
    //   1509: aload #10
    //   1511: aload #8
    //   1513: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1516: getfield c0 : I
    //   1519: invokevirtual setMargin : (I)V
    //   1522: aload_1
    //   1523: invokevirtual b : ()Landroidx/constraintlayout/widget/ConstraintLayout$a;
    //   1526: astore #11
    //   1528: aload #10
    //   1530: invokevirtual g : ()V
    //   1533: aload #8
    //   1535: aload #11
    //   1537: invokevirtual a : (Landroidx/constraintlayout/widget/ConstraintLayout$a;)V
    //   1540: aload_1
    //   1541: aload #10
    //   1543: aload #11
    //   1545: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   1548: aload #8
    //   1550: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1553: getfield a : Z
    //   1556: ifeq -> 1348
    //   1559: new androidx/constraintlayout/widget/Guideline
    //   1562: dup
    //   1563: aload_1
    //   1564: invokevirtual getContext : ()Landroid/content/Context;
    //   1567: invokespecial <init> : (Landroid/content/Context;)V
    //   1570: astore #10
    //   1572: aload #10
    //   1574: aload #9
    //   1576: invokevirtual intValue : ()I
    //   1579: invokevirtual setId : (I)V
    //   1582: aload_1
    //   1583: invokevirtual b : ()Landroidx/constraintlayout/widget/ConstraintLayout$a;
    //   1586: astore #9
    //   1588: aload #8
    //   1590: aload #9
    //   1592: invokevirtual a : (Landroidx/constraintlayout/widget/ConstraintLayout$a;)V
    //   1595: aload_1
    //   1596: aload #10
    //   1598: aload #9
    //   1600: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   1603: goto -> 1348
    //   1606: return
    //   1607: astore #7
    //   1609: goto -> 88
    // Exception table:
    //   from	to	target	type
    //   67	85	1607	java/lang/Exception
    //   455	465	919	java/lang/NoSuchMethodException
    //   455	465	873	java/lang/IllegalAccessException
    //   455	465	827	java/lang/reflect/InvocationTargetException
    //   511	549	822	java/lang/NoSuchMethodException
    //   511	549	817	java/lang/IllegalAccessException
    //   511	549	812	java/lang/reflect/InvocationTargetException
    //   552	590	822	java/lang/NoSuchMethodException
    //   552	590	817	java/lang/IllegalAccessException
    //   552	590	812	java/lang/reflect/InvocationTargetException
    //   593	628	822	java/lang/NoSuchMethodException
    //   593	628	817	java/lang/IllegalAccessException
    //   593	628	812	java/lang/reflect/InvocationTargetException
    //   631	686	822	java/lang/NoSuchMethodException
    //   631	686	817	java/lang/IllegalAccessException
    //   631	686	812	java/lang/reflect/InvocationTargetException
    //   689	727	822	java/lang/NoSuchMethodException
    //   689	727	817	java/lang/IllegalAccessException
    //   689	727	812	java/lang/reflect/InvocationTargetException
    //   730	768	822	java/lang/NoSuchMethodException
    //   730	768	817	java/lang/IllegalAccessException
    //   730	768	812	java/lang/reflect/InvocationTargetException
    //   771	809	822	java/lang/NoSuchMethodException
    //   771	809	817	java/lang/IllegalAccessException
    //   771	809	812	java/lang/reflect/InvocationTargetException
  }
  
  public void b(ConstraintLayout paramConstraintLayout) {
    int j = paramConstraintLayout.getChildCount();
    this.c.clear();
    int i = 0;
    while (true) {
      b b1 = this;
      if (i < j) {
        View view = paramConstraintLayout.getChildAt(i);
        ConstraintLayout.a a = (ConstraintLayout.a)view.getLayoutParams();
        int k = view.getId();
        if (!b1.b || k != -1) {
          if (!b1.c.containsKey(Integer.valueOf(k)))
            b1.c.put(Integer.valueOf(k), new a()); 
          a a1 = b1.c.get(Integer.valueOf(k));
          HashMap<String, ConstraintAttribute> hashMap = b1.a;
          HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
          Class<?> clazz = view.getClass();
          for (String str : hashMap.keySet()) {
            ConstraintAttribute constraintAttribute = hashMap.get(str);
            try {
              if (str.equals("BackgroundColor")) {
                hashMap1.put(str, new ConstraintAttribute(constraintAttribute, Integer.valueOf(((ColorDrawable)view.getBackground()).getColor())));
                continue;
              } 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("getMap");
              stringBuilder.append(str);
              String str1 = stringBuilder.toString();
              try {
                hashMap1.put(str, new ConstraintAttribute(constraintAttribute, clazz.getMethod(str1, new Class[0]).invoke(view, new Object[0])));
                continue;
              } catch (NoSuchMethodException noSuchMethodException) {
              
              } catch (IllegalAccessException illegalAccessException) {
              
              } catch (InvocationTargetException null) {}
            } catch (NoSuchMethodException noSuchMethodException) {
            
            } catch (IllegalAccessException illegalAccessException) {
              illegalAccessException.printStackTrace();
              continue;
            } catch (InvocationTargetException invocationTargetException) {
              invocationTargetException.printStackTrace();
              continue;
            } 
            invocationTargetException.printStackTrace();
          } 
          a1.f = (HashMap)hashMap1;
          a1.b(k, a);
          a1.b.b = view.getVisibility();
          k = Build.VERSION.SDK_INT;
          a1.b.d = view.getAlpha();
          a1.e.b = view.getRotation();
          a1.e.c = view.getRotationX();
          a1.e.d = view.getRotationY();
          a1.e.e = view.getScaleX();
          a1.e.f = view.getScaleY();
          float f1 = view.getPivotX();
          float f2 = view.getPivotY();
          if (f1 != 0.0D || f2 != 0.0D) {
            e e = a1.e;
            e.g = f1;
            e.h = f2;
          } 
          a1.e.i = view.getTranslationX();
          a1.e.j = view.getTranslationY();
          if (k >= 21) {
            a1.e.k = view.getTranslationZ();
            e e = a1.e;
            if (e.l)
              e.m = view.getElevation(); 
          } 
          if (view instanceof Barrier) {
            Barrier barrier = (Barrier)view;
            b b2 = a1.d;
            b2.j0 = barrier.n.h0;
            b2.e0 = barrier.getReferencedIds();
            a1.d.b0 = barrier.getType();
            a1.d.c0 = barrier.getMargin();
          } 
          i++;
          continue;
        } 
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      } 
      break;
    } 
  }
  
  public final int[] c(View paramView, String paramString) {
    String[] arrayOfString = paramString.split(",");
    Context context = paramView.getContext();
    int[] arrayOfInt = new int[arrayOfString.length];
    int j = 0;
    int i = 0;
    while (true) {
      if (j < arrayOfString.length) {
        String str = arrayOfString[j].trim();
        try {
          m = x.c.class.getField(str).getInt(null);
        } catch (Exception exception) {
          m = 0;
        } 
        int k = m;
        if (!m)
          k = context.getResources().getIdentifier(str, "id", context.getPackageName()); 
        int m = k;
        if (k == 0) {
          m = k;
          if (paramView.isInEditMode()) {
            m = k;
            if (paramView.getParent() instanceof ConstraintLayout) {
              Object object = ((ConstraintLayout)paramView.getParent()).c(0, str);
              m = k;
              if (object != null) {
                m = k;
                if (object instanceof Integer)
                  m = ((Integer)object).intValue(); 
              } 
            } 
          } 
        } 
        arrayOfInt[i] = m;
        j++;
        i++;
        continue;
      } 
      int[] arrayOfInt1 = arrayOfInt;
      if (i != arrayOfString.length)
        arrayOfInt1 = Arrays.copyOf(arrayOfInt, i); 
      return arrayOfInt1;
    } 
  }
  
  public final a d(Context paramContext, AttributeSet paramAttributeSet) {
    a a = new a();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, x.d.a);
    int j = typedArray.getIndexCount();
    for (int i = 0; i < j; i++) {
      StringBuilder stringBuilder;
      b b6;
      c c3;
      d d4;
      c c2;
      b b5;
      d d3;
      c c1;
      b b4;
      e e2;
      b b3;
      e e1;
      d d2;
      b b2;
      d d1;
      b b1;
      int k;
      int m;
      int n = typedArray.getIndex(i);
      if (n != 1 && 23 != n && 24 != n) {
        a.c.a = true;
        a.d.b = true;
        a.b.a = true;
        a.e.a = true;
      } 
      switch (e.get(n)) {
        default:
          stringBuilder = android.support.v4.media.a.a("Unknown attribute 0x");
          stringBuilder.append(Integer.toHexString(n));
          stringBuilder.append("   ");
          stringBuilder.append(e.get(n));
          Log.w("ConstraintSet", stringBuilder.toString());
          break;
        case 82:
          stringBuilder = android.support.v4.media.a.a("unused attribute 0x");
          stringBuilder.append(Integer.toHexString(n));
          stringBuilder.append("   ");
          stringBuilder.append(e.get(n));
          Log.w("ConstraintSet", stringBuilder.toString());
          break;
        case 81:
          b6 = a.d;
          b6.i0 = typedArray.getBoolean(n, b6.i0);
          break;
        case 80:
          b6 = a.d;
          b6.h0 = typedArray.getBoolean(n, b6.h0);
          break;
        case 79:
          c3 = a.c;
          c3.f = typedArray.getFloat(n, c3.f);
          break;
        case 78:
          d4 = a.b;
          d4.c = typedArray.getInt(n, d4.c);
          break;
        case 77:
          a.d.g0 = typedArray.getString(n);
          break;
        case 76:
          c2 = a.c;
          c2.d = typedArray.getInt(n, c2.d);
          break;
        case 75:
          b5 = a.d;
          b5.j0 = typedArray.getBoolean(n, b5.j0);
          break;
        case 74:
          a.d.f0 = typedArray.getString(n);
          break;
        case 73:
          b5 = a.d;
          b5.c0 = typedArray.getDimensionPixelSize(n, b5.c0);
          break;
        case 72:
          b5 = a.d;
          b5.b0 = typedArray.getInt(n, b5.b0);
          break;
        case 71:
          Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
          break;
        case 70:
          a.d.a0 = typedArray.getFloat(n, 1.0F);
          break;
        case 69:
          a.d.Z = typedArray.getFloat(n, 1.0F);
          break;
        case 68:
          d3 = a.b;
          d3.e = typedArray.getFloat(n, d3.e);
          break;
        case 67:
          c1 = a.c;
          c1.g = typedArray.getFloat(n, c1.g);
          break;
        case 66:
          a.c.e = typedArray.getInt(n, 0);
          break;
        case 65:
          if ((typedArray.peekValue(n)).type == 3) {
            a.c.c = typedArray.getString(n);
            break;
          } 
          a.c.c = t.a.a[typedArray.getInteger(n, 0)];
          break;
        case 64:
          c1 = a.c;
          m = typedArray.getResourceId(n, c1.b);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          c1.b = k;
          break;
        case 63:
          b4 = a.d;
          b4.z = typedArray.getFloat(n, b4.z);
          break;
        case 62:
          b4 = a.d;
          b4.y = typedArray.getDimensionPixelSize(n, b4.y);
          break;
        case 61:
          b4 = a.d;
          m = typedArray.getResourceId(n, b4.x);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b4.x = k;
          break;
        case 60:
          e2 = a.e;
          e2.b = typedArray.getFloat(n, e2.b);
          break;
        case 59:
          b3 = a.d;
          b3.Y = typedArray.getDimensionPixelSize(n, b3.Y);
          break;
        case 58:
          b3 = a.d;
          b3.X = typedArray.getDimensionPixelSize(n, b3.X);
          break;
        case 57:
          b3 = a.d;
          b3.W = typedArray.getDimensionPixelSize(n, b3.W);
          break;
        case 56:
          b3 = a.d;
          b3.V = typedArray.getDimensionPixelSize(n, b3.V);
          break;
        case 55:
          b3 = a.d;
          b3.U = typedArray.getInt(n, b3.U);
          break;
        case 54:
          b3 = a.d;
          b3.T = typedArray.getInt(n, b3.T);
          break;
        case 53:
          if (Build.VERSION.SDK_INT >= 21) {
            e e = a.e;
            e.k = typedArray.getDimension(n, e.k);
          } 
          break;
        case 52:
          e1 = a.e;
          e1.j = typedArray.getDimension(n, e1.j);
          break;
        case 51:
          e1 = a.e;
          e1.i = typedArray.getDimension(n, e1.i);
          break;
        case 50:
          e1 = a.e;
          e1.h = typedArray.getDimension(n, e1.h);
          break;
        case 49:
          e1 = a.e;
          e1.g = typedArray.getDimension(n, e1.g);
          break;
        case 48:
          e1 = a.e;
          e1.f = typedArray.getFloat(n, e1.f);
          break;
        case 47:
          e1 = a.e;
          e1.e = typedArray.getFloat(n, e1.e);
          break;
        case 46:
          e1 = a.e;
          e1.d = typedArray.getFloat(n, e1.d);
          break;
        case 45:
          e1 = a.e;
          e1.c = typedArray.getFloat(n, e1.c);
          break;
        case 44:
          if (Build.VERSION.SDK_INT >= 21) {
            e1 = a.e;
            e1.l = true;
            e1.m = typedArray.getDimension(n, e1.m);
          } 
          break;
        case 43:
          d2 = a.b;
          d2.d = typedArray.getFloat(n, d2.d);
          break;
        case 42:
          b2 = a.d;
          b2.S = typedArray.getInt(n, b2.S);
          break;
        case 41:
          b2 = a.d;
          b2.R = typedArray.getInt(n, b2.R);
          break;
        case 40:
          b2 = a.d;
          b2.P = typedArray.getFloat(n, b2.P);
          break;
        case 39:
          b2 = a.d;
          b2.Q = typedArray.getFloat(n, b2.Q);
          break;
        case 38:
          a.a = typedArray.getResourceId(n, a.a);
          break;
        case 37:
          b2 = a.d;
          b2.v = typedArray.getFloat(n, b2.v);
          break;
        case 36:
          b2 = a.d;
          m = typedArray.getResourceId(n, b2.l);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b2.l = k;
          break;
        case 35:
          b2 = a.d;
          m = typedArray.getResourceId(n, b2.m);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b2.m = k;
          break;
        case 34:
          b2 = a.d;
          b2.F = typedArray.getDimensionPixelSize(n, b2.F);
          break;
        case 33:
          b2 = a.d;
          m = typedArray.getResourceId(n, b2.r);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b2.r = k;
          break;
        case 32:
          b2 = a.d;
          m = typedArray.getResourceId(n, b2.q);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b2.q = k;
          break;
        case 31:
          b2 = a.d;
          b2.I = typedArray.getDimensionPixelSize(n, b2.I);
          break;
        case 30:
          b2 = a.d;
          m = typedArray.getResourceId(n, b2.k);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b2.k = k;
          break;
        case 29:
          b2 = a.d;
          m = typedArray.getResourceId(n, b2.j);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b2.j = k;
          break;
        case 28:
          b2 = a.d;
          b2.E = typedArray.getDimensionPixelSize(n, b2.E);
          break;
        case 27:
          b2 = a.d;
          b2.C = typedArray.getInt(n, b2.C);
          break;
        case 26:
          b2 = a.d;
          m = typedArray.getResourceId(n, b2.i);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b2.i = k;
          break;
        case 25:
          b2 = a.d;
          m = typedArray.getResourceId(n, b2.h);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b2.h = k;
          break;
        case 24:
          b2 = a.d;
          b2.D = typedArray.getDimensionPixelSize(n, b2.D);
          break;
        case 23:
          b2 = a.d;
          b2.c = typedArray.getLayoutDimension(n, b2.c);
          break;
        case 22:
          d1 = a.b;
          d1.b = typedArray.getInt(n, d1.b);
          d1 = a.b;
          d1.b = d[d1.b];
          break;
        case 21:
          b1 = a.d;
          b1.d = typedArray.getLayoutDimension(n, b1.d);
          break;
        case 20:
          b1 = a.d;
          b1.u = typedArray.getFloat(n, b1.u);
          break;
        case 19:
          b1 = a.d;
          b1.g = typedArray.getFloat(n, b1.g);
          break;
        case 18:
          b1 = a.d;
          b1.f = typedArray.getDimensionPixelOffset(n, b1.f);
          break;
        case 17:
          b1 = a.d;
          b1.e = typedArray.getDimensionPixelOffset(n, b1.e);
          break;
        case 16:
          b1 = a.d;
          b1.K = typedArray.getDimensionPixelSize(n, b1.K);
          break;
        case 15:
          b1 = a.d;
          b1.O = typedArray.getDimensionPixelSize(n, b1.O);
          break;
        case 14:
          b1 = a.d;
          b1.L = typedArray.getDimensionPixelSize(n, b1.L);
          break;
        case 13:
          b1 = a.d;
          b1.J = typedArray.getDimensionPixelSize(n, b1.J);
          break;
        case 12:
          b1 = a.d;
          b1.N = typedArray.getDimensionPixelSize(n, b1.N);
          break;
        case 11:
          b1 = a.d;
          b1.M = typedArray.getDimensionPixelSize(n, b1.M);
          break;
        case 10:
          b1 = a.d;
          m = typedArray.getResourceId(n, b1.s);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b1.s = k;
          break;
        case 9:
          b1 = a.d;
          m = typedArray.getResourceId(n, b1.t);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b1.t = k;
          break;
        case 8:
          b1 = a.d;
          b1.H = typedArray.getDimensionPixelSize(n, b1.H);
          break;
        case 7:
          b1 = a.d;
          b1.B = typedArray.getDimensionPixelOffset(n, b1.B);
          break;
        case 6:
          b1 = a.d;
          b1.A = typedArray.getDimensionPixelOffset(n, b1.A);
          break;
        case 5:
          a.d.w = typedArray.getString(n);
          break;
        case 4:
          b1 = a.d;
          m = typedArray.getResourceId(n, b1.n);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b1.n = k;
          break;
        case 3:
          b1 = a.d;
          m = typedArray.getResourceId(n, b1.o);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b1.o = k;
          break;
        case 2:
          b1 = a.d;
          b1.G = typedArray.getDimensionPixelSize(n, b1.G);
          break;
        case 1:
          b1 = a.d;
          m = typedArray.getResourceId(n, b1.p);
          k = m;
          if (m == -1)
            k = typedArray.getInt(n, -1); 
          b1.p = k;
          break;
      } 
    } 
    typedArray.recycle();
    return a;
  }
  
  public void e(Context paramContext, int paramInt) {
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    try {
      paramInt = xmlResourceParser.getEventType();
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      if (paramInt != 1) {
        if (paramInt != 0) {
          if (paramInt == 2) {
            String str = xmlResourceParser.getName();
            a a = d((Context)iOException, Xml.asAttributeSet((XmlPullParser)xmlResourceParser));
            if (str.equalsIgnoreCase("Guideline"))
              a.d.a = true; 
            this.c.put(Integer.valueOf(a.a), a);
          } 
        } else {
          xmlResourceParser.getName();
        } 
        paramInt = xmlResourceParser.next();
        continue;
      } 
      return;
    } 
  }
  
  public static class a {
    public int a;
    
    public final b.d b = new b.d();
    
    public final b.c c = new b.c();
    
    public final b.b d = new b.b();
    
    public final b.e e = new b.e();
    
    public HashMap<String, ConstraintAttribute> f = new HashMap<String, ConstraintAttribute>();
    
    public void a(ConstraintLayout.a param1a) {
      b.b b1 = this.d;
      param1a.d = b1.h;
      param1a.e = b1.i;
      param1a.f = b1.j;
      param1a.g = b1.k;
      param1a.h = b1.l;
      param1a.i = b1.m;
      param1a.j = b1.n;
      param1a.k = b1.o;
      param1a.l = b1.p;
      param1a.p = b1.q;
      param1a.q = b1.r;
      param1a.r = b1.s;
      param1a.s = b1.t;
      param1a.leftMargin = b1.D;
      param1a.rightMargin = b1.E;
      param1a.topMargin = b1.F;
      param1a.bottomMargin = b1.G;
      param1a.x = b1.O;
      param1a.y = b1.N;
      param1a.u = b1.K;
      param1a.w = b1.M;
      param1a.z = b1.u;
      param1a.A = b1.v;
      param1a.m = b1.x;
      param1a.n = b1.y;
      param1a.o = b1.z;
      param1a.B = b1.w;
      param1a.P = b1.A;
      param1a.Q = b1.B;
      param1a.E = b1.P;
      param1a.D = b1.Q;
      param1a.G = b1.S;
      param1a.F = b1.R;
      param1a.S = b1.h0;
      param1a.T = b1.i0;
      param1a.H = b1.T;
      param1a.I = b1.U;
      param1a.L = b1.V;
      param1a.M = b1.W;
      param1a.J = b1.X;
      param1a.K = b1.Y;
      param1a.N = b1.Z;
      param1a.O = b1.a0;
      param1a.R = b1.C;
      param1a.c = b1.g;
      param1a.a = b1.e;
      param1a.b = b1.f;
      param1a.width = b1.c;
      param1a.height = b1.d;
      String str = b1.g0;
      if (str != null)
        param1a.U = str; 
      param1a.setMarginStart(b1.I);
      param1a.setMarginEnd(this.d.H);
      param1a.a();
    }
    
    public final void b(int param1Int, ConstraintLayout.a param1a) {
      this.a = param1Int;
      b.b b1 = this.d;
      b1.h = param1a.d;
      b1.i = param1a.e;
      b1.j = param1a.f;
      b1.k = param1a.g;
      b1.l = param1a.h;
      b1.m = param1a.i;
      b1.n = param1a.j;
      b1.o = param1a.k;
      b1.p = param1a.l;
      b1.q = param1a.p;
      b1.r = param1a.q;
      b1.s = param1a.r;
      b1.t = param1a.s;
      b1.u = param1a.z;
      b1.v = param1a.A;
      b1.w = param1a.B;
      b1.x = param1a.m;
      b1.y = param1a.n;
      b1.z = param1a.o;
      b1.A = param1a.P;
      b1.B = param1a.Q;
      b1.C = param1a.R;
      b1.g = param1a.c;
      b1.e = param1a.a;
      b1.f = param1a.b;
      b1.c = param1a.width;
      b1.d = param1a.height;
      b1.D = param1a.leftMargin;
      b1.E = param1a.rightMargin;
      b1.F = param1a.topMargin;
      b1.G = param1a.bottomMargin;
      b1.P = param1a.E;
      b1.Q = param1a.D;
      b1.S = param1a.G;
      b1.R = param1a.F;
      b1.h0 = param1a.S;
      b1.i0 = param1a.T;
      b1.T = param1a.H;
      b1.U = param1a.I;
      b1.V = param1a.L;
      b1.W = param1a.M;
      b1.X = param1a.J;
      b1.Y = param1a.K;
      b1.Z = param1a.N;
      b1.a0 = param1a.O;
      b1.g0 = param1a.U;
      b1.K = param1a.u;
      b1.M = param1a.w;
      b1.J = param1a.t;
      b1.L = param1a.v;
      b1.O = param1a.x;
      b1.N = param1a.y;
      b1.H = param1a.getMarginEnd();
      this.d.I = param1a.getMarginStart();
    }
    
    public final void c(int param1Int, c.a param1a) {
      b(param1Int, param1a);
      this.b.d = param1a.m0;
      b.e e1 = this.e;
      e1.b = param1a.p0;
      e1.c = param1a.q0;
      e1.d = param1a.r0;
      e1.e = param1a.s0;
      e1.f = param1a.t0;
      e1.g = param1a.u0;
      e1.h = param1a.v0;
      e1.i = param1a.w0;
      e1.j = param1a.x0;
      e1.k = param1a.y0;
      e1.m = param1a.o0;
      e1.l = param1a.n0;
    }
    
    public Object clone() {
      a a1 = new a();
      b.b b1 = a1.d;
      b.b b2 = this.d;
      Objects.requireNonNull(b1);
      b1.a = b2.a;
      b1.c = b2.c;
      b1.b = b2.b;
      b1.d = b2.d;
      b1.e = b2.e;
      b1.f = b2.f;
      b1.g = b2.g;
      b1.h = b2.h;
      b1.i = b2.i;
      b1.j = b2.j;
      b1.k = b2.k;
      b1.l = b2.l;
      b1.m = b2.m;
      b1.n = b2.n;
      b1.o = b2.o;
      b1.p = b2.p;
      b1.q = b2.q;
      b1.r = b2.r;
      b1.s = b2.s;
      b1.t = b2.t;
      b1.u = b2.u;
      b1.v = b2.v;
      b1.w = b2.w;
      b1.x = b2.x;
      b1.y = b2.y;
      b1.z = b2.z;
      b1.A = b2.A;
      b1.B = b2.B;
      b1.C = b2.C;
      b1.D = b2.D;
      b1.E = b2.E;
      b1.F = b2.F;
      b1.G = b2.G;
      b1.H = b2.H;
      b1.I = b2.I;
      b1.J = b2.J;
      b1.K = b2.K;
      b1.L = b2.L;
      b1.M = b2.M;
      b1.N = b2.N;
      b1.O = b2.O;
      b1.P = b2.P;
      b1.Q = b2.Q;
      b1.R = b2.R;
      b1.S = b2.S;
      b1.T = b2.T;
      b1.U = b2.U;
      b1.V = b2.V;
      b1.W = b2.W;
      b1.X = b2.X;
      b1.Y = b2.Y;
      b1.Z = b2.Z;
      b1.a0 = b2.a0;
      b1.b0 = b2.b0;
      b1.c0 = b2.c0;
      b1.d0 = b2.d0;
      b1.g0 = b2.g0;
      int[] arrayOfInt = b2.e0;
      if (arrayOfInt != null) {
        b1.e0 = Arrays.copyOf(arrayOfInt, arrayOfInt.length);
      } else {
        b1.e0 = null;
      } 
      b1.f0 = b2.f0;
      b1.h0 = b2.h0;
      b1.i0 = b2.i0;
      b1.j0 = b2.j0;
      b.c c1 = a1.c;
      b.c c2 = this.c;
      Objects.requireNonNull(c1);
      c1.a = c2.a;
      c1.b = c2.b;
      c1.c = c2.c;
      c1.d = c2.d;
      c1.e = c2.e;
      c1.g = c2.g;
      c1.f = c2.f;
      b.d d1 = a1.b;
      b.d d2 = this.b;
      Objects.requireNonNull(d1);
      d1.a = d2.a;
      d1.b = d2.b;
      d1.d = d2.d;
      d1.e = d2.e;
      d1.c = d2.c;
      b.e e1 = a1.e;
      b.e e2 = this.e;
      Objects.requireNonNull(e1);
      e1.a = e2.a;
      e1.b = e2.b;
      e1.c = e2.c;
      e1.d = e2.d;
      e1.e = e2.e;
      e1.f = e2.f;
      e1.g = e2.g;
      e1.h = e2.h;
      e1.i = e2.i;
      e1.j = e2.j;
      e1.k = e2.k;
      e1.l = e2.l;
      e1.m = e2.m;
      a1.a = this.a;
      return a1;
    }
  }
  
  public static class b {
    public static SparseIntArray k0;
    
    public int A = -1;
    
    public int B = -1;
    
    public int C = -1;
    
    public int D = -1;
    
    public int E = -1;
    
    public int F = -1;
    
    public int G = -1;
    
    public int H = -1;
    
    public int I = -1;
    
    public int J = -1;
    
    public int K = -1;
    
    public int L = -1;
    
    public int M = -1;
    
    public int N = -1;
    
    public int O = -1;
    
    public float P = -1.0F;
    
    public float Q = -1.0F;
    
    public int R = 0;
    
    public int S = 0;
    
    public int T = 0;
    
    public int U = 0;
    
    public int V = -1;
    
    public int W = -1;
    
    public int X = -1;
    
    public int Y = -1;
    
    public float Z = 1.0F;
    
    public boolean a = false;
    
    public float a0 = 1.0F;
    
    public boolean b = false;
    
    public int b0 = -1;
    
    public int c;
    
    public int c0 = 0;
    
    public int d;
    
    public int d0 = -1;
    
    public int e = -1;
    
    public int[] e0;
    
    public int f = -1;
    
    public String f0;
    
    public float g = -1.0F;
    
    public String g0;
    
    public int h = -1;
    
    public boolean h0 = false;
    
    public int i = -1;
    
    public boolean i0 = false;
    
    public int j = -1;
    
    public boolean j0 = true;
    
    public int k = -1;
    
    public int l = -1;
    
    public int m = -1;
    
    public int n = -1;
    
    public int o = -1;
    
    public int p = -1;
    
    public int q = -1;
    
    public int r = -1;
    
    public int s = -1;
    
    public int t = -1;
    
    public float u = 0.5F;
    
    public float v = 0.5F;
    
    public String w = null;
    
    public int x = -1;
    
    public int y = 0;
    
    public float z = 0.0F;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      k0 = sparseIntArray;
      sparseIntArray.append(38, 24);
      k0.append(39, 25);
      k0.append(41, 28);
      k0.append(42, 29);
      k0.append(47, 35);
      k0.append(46, 34);
      k0.append(20, 4);
      k0.append(19, 3);
      k0.append(17, 1);
      k0.append(55, 6);
      k0.append(56, 7);
      k0.append(27, 17);
      k0.append(28, 18);
      k0.append(29, 19);
      k0.append(0, 26);
      k0.append(43, 31);
      k0.append(44, 32);
      k0.append(26, 10);
      k0.append(25, 9);
      k0.append(59, 13);
      k0.append(62, 16);
      k0.append(60, 14);
      k0.append(57, 11);
      k0.append(61, 15);
      k0.append(58, 12);
      k0.append(50, 38);
      k0.append(36, 37);
      k0.append(35, 39);
      k0.append(49, 40);
      k0.append(34, 20);
      k0.append(48, 36);
      k0.append(24, 5);
      k0.append(37, 76);
      k0.append(45, 76);
      k0.append(40, 76);
      k0.append(18, 76);
      k0.append(16, 76);
      k0.append(3, 23);
      k0.append(5, 27);
      k0.append(7, 30);
      k0.append(8, 8);
      k0.append(4, 33);
      k0.append(6, 2);
      k0.append(1, 22);
      k0.append(2, 21);
      k0.append(21, 61);
      k0.append(23, 62);
      k0.append(22, 63);
      k0.append(54, 69);
      k0.append(33, 70);
      k0.append(12, 71);
      k0.append(10, 72);
      k0.append(11, 73);
      k0.append(13, 74);
      k0.append(9, 75);
    }
    
    public void a(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, x.d.e);
      this.b = true;
      int j = typedArray.getIndexCount();
      for (int i = 0;; i++) {
        if (i < j) {
          int m = typedArray.getIndex(i);
          int k = k0.get(m);
          if (k != 80) {
            if (k != 81) {
              StringBuilder stringBuilder;
              int[] arrayOfInt;
              int n;
              switch (k) {
                default:
                  switch (k) {
                    default:
                      switch (k) {
                        default:
                          switch (k) {
                            default:
                              stringBuilder = android.support.v4.media.a.a("Unknown attribute 0x");
                              stringBuilder.append(Integer.toHexString(m));
                              stringBuilder.append("   ");
                              stringBuilder.append(k0.get(m));
                              Log.w("ConstraintSet", stringBuilder.toString());
                              break;
                            case 77:
                              this.g0 = typedArray.getString(m);
                              break;
                            case 76:
                              stringBuilder = android.support.v4.media.a.a("unused attribute 0x");
                              stringBuilder.append(Integer.toHexString(m));
                              stringBuilder.append("   ");
                              stringBuilder.append(k0.get(m));
                              Log.w("ConstraintSet", stringBuilder.toString());
                              break;
                            case 75:
                              this.j0 = typedArray.getBoolean(m, this.j0);
                              break;
                            case 74:
                              this.f0 = typedArray.getString(m);
                              break;
                            case 73:
                              this.c0 = typedArray.getDimensionPixelSize(m, this.c0);
                              break;
                            case 72:
                              this.b0 = typedArray.getInt(m, this.b0);
                              break;
                            case 71:
                              Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                              break;
                            case 70:
                              this.a0 = typedArray.getFloat(m, 1.0F);
                              break;
                            case 69:
                              this.Z = typedArray.getFloat(m, 1.0F);
                              break;
                          } 
                          i++;
                          continue;
                        case 63:
                          this.z = typedArray.getFloat(m, this.z);
                          break;
                        case 62:
                          this.y = typedArray.getDimensionPixelSize(m, this.y);
                          break;
                        case 61:
                          k = this.x;
                          arrayOfInt = b.d;
                          n = typedArray.getResourceId(m, k);
                          k = n;
                          if (n == -1)
                            k = typedArray.getInt(m, -1); 
                          this.x = k;
                          break;
                      } 
                      i++;
                      continue;
                    case 59:
                      this.Y = typedArray.getDimensionPixelSize(m, this.Y);
                      break;
                    case 58:
                      this.X = typedArray.getDimensionPixelSize(m, this.X);
                      break;
                    case 57:
                      this.W = typedArray.getDimensionPixelSize(m, this.W);
                      break;
                    case 56:
                      this.V = typedArray.getDimensionPixelSize(m, this.V);
                      break;
                    case 55:
                      this.U = typedArray.getInt(m, this.U);
                      break;
                    case 54:
                      this.T = typedArray.getInt(m, this.T);
                      break;
                  } 
                  i++;
                  continue;
                case 40:
                  this.S = typedArray.getInt(m, this.S);
                  break;
                case 39:
                  this.R = typedArray.getInt(m, this.R);
                  break;
                case 38:
                  this.P = typedArray.getFloat(m, this.P);
                  break;
                case 37:
                  this.Q = typedArray.getFloat(m, this.Q);
                  break;
                case 36:
                  this.v = typedArray.getFloat(m, this.v);
                  break;
                case 35:
                  k = this.l;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.l = k;
                  break;
                case 34:
                  k = this.m;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.m = k;
                  break;
                case 33:
                  this.F = typedArray.getDimensionPixelSize(m, this.F);
                  break;
                case 32:
                  k = this.r;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.r = k;
                  break;
                case 31:
                  k = this.q;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.q = k;
                  break;
                case 30:
                  this.I = typedArray.getDimensionPixelSize(m, this.I);
                  break;
                case 29:
                  k = this.k;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.k = k;
                  break;
                case 28:
                  k = this.j;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.j = k;
                  break;
                case 27:
                  this.E = typedArray.getDimensionPixelSize(m, this.E);
                  break;
                case 26:
                  this.C = typedArray.getInt(m, this.C);
                  break;
                case 25:
                  k = this.i;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.i = k;
                  break;
                case 24:
                  k = this.h;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.h = k;
                  break;
                case 23:
                  this.D = typedArray.getDimensionPixelSize(m, this.D);
                  break;
                case 22:
                  this.c = typedArray.getLayoutDimension(m, this.c);
                  break;
                case 21:
                  this.d = typedArray.getLayoutDimension(m, this.d);
                  break;
                case 20:
                  this.u = typedArray.getFloat(m, this.u);
                  break;
                case 19:
                  this.g = typedArray.getFloat(m, this.g);
                  break;
                case 18:
                  this.f = typedArray.getDimensionPixelOffset(m, this.f);
                  break;
                case 17:
                  this.e = typedArray.getDimensionPixelOffset(m, this.e);
                  break;
                case 16:
                  this.K = typedArray.getDimensionPixelSize(m, this.K);
                  break;
                case 15:
                  this.O = typedArray.getDimensionPixelSize(m, this.O);
                  break;
                case 14:
                  this.L = typedArray.getDimensionPixelSize(m, this.L);
                  break;
                case 13:
                  this.J = typedArray.getDimensionPixelSize(m, this.J);
                  break;
                case 12:
                  this.N = typedArray.getDimensionPixelSize(m, this.N);
                  break;
                case 11:
                  this.M = typedArray.getDimensionPixelSize(m, this.M);
                  break;
                case 10:
                  k = this.s;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.s = k;
                  break;
                case 9:
                  k = this.t;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.t = k;
                  break;
                case 8:
                  this.H = typedArray.getDimensionPixelSize(m, this.H);
                  break;
                case 7:
                  this.B = typedArray.getDimensionPixelOffset(m, this.B);
                  break;
                case 6:
                  this.A = typedArray.getDimensionPixelOffset(m, this.A);
                  break;
                case 5:
                  this.w = typedArray.getString(m);
                  break;
                case 4:
                  k = this.n;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.n = k;
                  break;
                case 3:
                  k = this.o;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.o = k;
                  break;
                case 2:
                  this.G = typedArray.getDimensionPixelSize(m, this.G);
                  break;
                case 1:
                  k = this.p;
                  arrayOfInt = b.d;
                  n = typedArray.getResourceId(m, k);
                  k = n;
                  if (n == -1)
                    k = typedArray.getInt(m, -1); 
                  this.p = k;
                  break;
              } 
            } else {
              this.i0 = typedArray.getBoolean(m, this.i0);
            } 
          } else {
            this.h0 = typedArray.getBoolean(m, this.h0);
          } 
        } else {
          break;
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class c {
    public static SparseIntArray h;
    
    public boolean a = false;
    
    public int b = -1;
    
    public String c = null;
    
    public int d = -1;
    
    public int e = 0;
    
    public float f = Float.NaN;
    
    public float g = Float.NaN;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      h = sparseIntArray;
      sparseIntArray.append(2, 1);
      h.append(4, 2);
      h.append(5, 3);
      h.append(1, 4);
      h.append(0, 5);
      h.append(3, 6);
    }
    
    public void a(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, x.d.f);
      this.a = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int[] arrayOfInt;
        int k;
        int m;
        int n = typedArray.getIndex(i);
        switch (h.get(n)) {
          case 6:
            this.f = typedArray.getFloat(n, this.f);
            break;
          case 5:
            k = this.b;
            arrayOfInt = b.d;
            m = typedArray.getResourceId(n, k);
            k = m;
            if (m == -1)
              k = typedArray.getInt(n, -1); 
            this.b = k;
            break;
          case 4:
            this.e = typedArray.getInt(n, 0);
            break;
          case 3:
            if ((typedArray.peekValue(n)).type == 3) {
              this.c = typedArray.getString(n);
              break;
            } 
            this.c = t.a.a[typedArray.getInteger(n, 0)];
            break;
          case 2:
            this.d = typedArray.getInt(n, this.d);
            break;
          case 1:
            this.g = typedArray.getFloat(n, this.g);
            break;
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class d {
    public boolean a = false;
    
    public int b = 0;
    
    public int c = 0;
    
    public float d = 1.0F;
    
    public float e = Float.NaN;
    
    public void a(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, x.d.g);
      this.a = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == 1) {
          this.d = typedArray.getFloat(k, this.d);
        } else if (k == 0) {
          k = typedArray.getInt(k, this.b);
          this.b = k;
          int[] arrayOfInt = b.d;
          this.b = b.d[k];
        } else if (k == 4) {
          this.c = typedArray.getInt(k, this.c);
        } else if (k == 3) {
          this.e = typedArray.getFloat(k, this.e);
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class e {
    public static SparseIntArray n;
    
    public boolean a = false;
    
    public float b = 0.0F;
    
    public float c = 0.0F;
    
    public float d = 0.0F;
    
    public float e = 1.0F;
    
    public float f = 1.0F;
    
    public float g = Float.NaN;
    
    public float h = Float.NaN;
    
    public float i = 0.0F;
    
    public float j = 0.0F;
    
    public float k = 0.0F;
    
    public boolean l = false;
    
    public float m = 0.0F;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      n = sparseIntArray;
      sparseIntArray.append(6, 1);
      n.append(7, 2);
      n.append(8, 3);
      n.append(4, 4);
      n.append(5, 5);
      n.append(0, 6);
      n.append(1, 7);
      n.append(2, 8);
      n.append(3, 9);
      n.append(9, 10);
      n.append(10, 11);
    }
    
    public void a(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, x.d.i);
      this.a = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        switch (n.get(k)) {
          case 11:
            if (Build.VERSION.SDK_INT >= 21) {
              this.l = true;
              this.m = typedArray.getDimension(k, this.m);
            } 
            break;
          case 10:
            if (Build.VERSION.SDK_INT >= 21)
              this.k = typedArray.getDimension(k, this.k); 
            break;
          case 9:
            this.j = typedArray.getDimension(k, this.j);
            break;
          case 8:
            this.i = typedArray.getDimension(k, this.i);
            break;
          case 7:
            this.h = typedArray.getDimension(k, this.h);
            break;
          case 6:
            this.g = typedArray.getDimension(k, this.g);
            break;
          case 5:
            this.f = typedArray.getFloat(k, this.f);
            break;
          case 4:
            this.e = typedArray.getFloat(k, this.e);
            break;
          case 3:
            this.d = typedArray.getFloat(k, this.d);
            break;
          case 2:
            this.c = typedArray.getFloat(k, this.c);
            break;
          case 1:
            this.b = typedArray.getFloat(k, this.b);
            break;
        } 
      } 
      typedArray.recycle();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */