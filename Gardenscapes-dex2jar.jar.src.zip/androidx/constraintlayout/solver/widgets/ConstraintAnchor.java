package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.SolverVariable;
import java.util.HashSet;

public class ConstraintAnchor {
  public HashSet<ConstraintAnchor> a = null;
  
  public final ConstraintWidget b;
  
  public final Type c;
  
  public ConstraintAnchor d;
  
  public int e = 0;
  
  public int f = -1;
  
  public SolverVariable g;
  
  public ConstraintAnchor(ConstraintWidget paramConstraintWidget, Type paramType) {
    this.b = paramConstraintWidget;
    this.c = paramType;
  }
  
  public boolean a(ConstraintAnchor paramConstraintAnchor, int paramInt1, int paramInt2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 10
    //   4: aload_0
    //   5: invokevirtual e : ()V
    //   8: iconst_1
    //   9: ireturn
    //   10: iload #4
    //   12: ifne -> 304
    //   15: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.m : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   18: astore #7
    //   20: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.l : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   23: astore #8
    //   25: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.j : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   28: astore #9
    //   30: aload_1
    //   31: getfield c : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   34: astore #10
    //   36: aload_0
    //   37: getfield c : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   40: astore #11
    //   42: aload #10
    //   44: aload #11
    //   46: if_acmpne -> 79
    //   49: aload #11
    //   51: aload #9
    //   53: if_acmpne -> 172
    //   56: aload_1
    //   57: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   60: getfield w : Z
    //   63: ifeq -> 178
    //   66: aload_0
    //   67: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   70: getfield w : Z
    //   73: ifne -> 172
    //   76: goto -> 178
    //   79: aload #11
    //   81: invokevirtual ordinal : ()I
    //   84: tableswitch default -> 136, 0 -> 178, 1 -> 240, 2 -> 184, 3 -> 240, 4 -> 184, 5 -> 178, 6 -> 151, 7 -> 178, 8 -> 178
    //   136: new java/lang/AssertionError
    //   139: dup
    //   140: aload_0
    //   141: getfield c : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   144: invokevirtual name : ()Ljava/lang/String;
    //   147: invokespecial <init> : (Ljava/lang/Object;)V
    //   150: athrow
    //   151: aload #10
    //   153: aload #9
    //   155: if_acmpeq -> 178
    //   158: aload #10
    //   160: aload #8
    //   162: if_acmpeq -> 178
    //   165: aload #10
    //   167: aload #7
    //   169: if_acmpeq -> 178
    //   172: iconst_1
    //   173: istore #5
    //   175: goto -> 297
    //   178: iconst_0
    //   179: istore #5
    //   181: goto -> 297
    //   184: aload #10
    //   186: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.g : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   189: if_acmpeq -> 209
    //   192: aload #10
    //   194: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.i : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   197: if_acmpne -> 203
    //   200: goto -> 209
    //   203: iconst_0
    //   204: istore #5
    //   206: goto -> 212
    //   209: iconst_1
    //   210: istore #5
    //   212: aload_1
    //   213: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   216: instanceof androidx/constraintlayout/solver/widgets/e
    //   219: ifeq -> 237
    //   222: iload #5
    //   224: ifne -> 172
    //   227: aload #10
    //   229: aload #7
    //   231: if_acmpne -> 178
    //   234: goto -> 172
    //   237: goto -> 297
    //   240: aload #10
    //   242: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.f : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   245: if_acmpeq -> 265
    //   248: aload #10
    //   250: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.h : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   253: if_acmpne -> 259
    //   256: goto -> 265
    //   259: iconst_0
    //   260: istore #6
    //   262: goto -> 268
    //   265: iconst_1
    //   266: istore #6
    //   268: iload #6
    //   270: istore #5
    //   272: aload_1
    //   273: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   276: instanceof androidx/constraintlayout/solver/widgets/e
    //   279: ifeq -> 297
    //   282: iload #6
    //   284: ifne -> 172
    //   287: aload #10
    //   289: aload #8
    //   291: if_acmpne -> 178
    //   294: goto -> 172
    //   297: iload #5
    //   299: ifne -> 304
    //   302: iconst_0
    //   303: ireturn
    //   304: aload_0
    //   305: aload_1
    //   306: putfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   309: aload_1
    //   310: getfield a : Ljava/util/HashSet;
    //   313: ifnonnull -> 327
    //   316: aload_1
    //   317: new java/util/HashSet
    //   320: dup
    //   321: invokespecial <init> : ()V
    //   324: putfield a : Ljava/util/HashSet;
    //   327: aload_0
    //   328: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   331: getfield a : Ljava/util/HashSet;
    //   334: aload_0
    //   335: invokevirtual add : (Ljava/lang/Object;)Z
    //   338: pop
    //   339: iload_2
    //   340: ifle -> 351
    //   343: aload_0
    //   344: iload_2
    //   345: putfield e : I
    //   348: goto -> 356
    //   351: aload_0
    //   352: iconst_0
    //   353: putfield e : I
    //   356: aload_0
    //   357: iload_3
    //   358: putfield f : I
    //   361: iconst_1
    //   362: ireturn
  }
  
  public int b() {
    if (this.b.X == 8)
      return 0; 
    int i = this.f;
    if (i > -1) {
      ConstraintAnchor constraintAnchor = this.d;
      if (constraintAnchor != null && constraintAnchor.b.X == 8)
        return i; 
    } 
    return this.e;
  }
  
  public boolean c() {
    HashSet<ConstraintAnchor> hashSet = this.a;
    if (hashSet == null)
      return false; 
    for (ConstraintAnchor constraintAnchor : hashSet) {
      switch (constraintAnchor.c.ordinal()) {
        default:
          throw new AssertionError(constraintAnchor.c.name());
        case 4:
          constraintAnchor = constraintAnchor.b.z;
          break;
        case 3:
          constraintAnchor = constraintAnchor.b.y;
          break;
        case 2:
          constraintAnchor = constraintAnchor.b.B;
          break;
        case 1:
          constraintAnchor = constraintAnchor.b.A;
          break;
        case 0:
        case 5:
        case 6:
        case 7:
        case 8:
          constraintAnchor = null;
          break;
      } 
      if (constraintAnchor.d())
        return true; 
    } 
    return false;
  }
  
  public boolean d() {
    return (this.d != null);
  }
  
  public void e() {
    ConstraintAnchor constraintAnchor = this.d;
    if (constraintAnchor != null) {
      HashSet<ConstraintAnchor> hashSet = constraintAnchor.a;
      if (hashSet != null)
        hashSet.remove(this); 
    } 
    this.d = null;
    this.e = 0;
    this.f = -1;
  }
  
  public void f() {
    SolverVariable solverVariable = this.g;
    if (solverVariable == null) {
      this.g = new SolverVariable(SolverVariable.Type.f);
      return;
    } 
    solverVariable.c();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.b.Y);
    stringBuilder.append(":");
    stringBuilder.append(this.c.toString());
    return stringBuilder.toString();
  }
  
  public enum Type {
    f, g, h, i, j, k, l, m;
    
    static {
      Type type1 = new Type("NONE", 0);
      Type type2 = new Type("LEFT", 1);
      f = type2;
      Type type3 = new Type("TOP", 2);
      g = type3;
      Type type4 = new Type("RIGHT", 3);
      h = type4;
      Type type5 = new Type("BOTTOM", 4);
      i = type5;
      Type type6 = new Type("BASELINE", 5);
      j = type6;
      Type type7 = new Type("CENTER", 6);
      k = type7;
      Type type8 = new Type("CENTER_X", 7);
      l = type8;
      Type type9 = new Type("CENTER_Y", 8);
      m = type9;
      n = new Type[] { type1, type2, type3, type4, type5, type6, type7, type8, type9 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\ConstraintAnchor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */