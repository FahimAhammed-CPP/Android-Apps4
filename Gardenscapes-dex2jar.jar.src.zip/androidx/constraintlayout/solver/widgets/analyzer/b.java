package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.a;
import java.util.Iterator;
import v.c;
import w.d;

public class b extends WidgetRun {
  public b(ConstraintWidget paramConstraintWidget) {
    super(paramConstraintWidget);
  }
  
  public void a(d paramd) {
    Object object1;
    Object object2;
    a a = (a)this.b;
    int i = a.g0;
    byte b1 = 0;
    Iterator<DependencyNode> iterator = this.h.l.iterator();
    byte b2 = -1;
    while (true) {
      while (true)
        break; 
      if (b1 < SYNTHETIC_LOCAL_VARIABLE_4) {
        object1 = SYNTHETIC_LOCAL_VARIABLE_4;
        object2 = SYNTHETIC_LOCAL_VARIABLE_5;
      } 
    } 
    if (i == 0 || i == 2) {
      this.h.c(object2 + a.i0);
      return;
    } 
    this.h.c(object1 + a.i0);
  }
  
  public void d() {
    ConstraintWidget constraintWidget = this.b;
    if (constraintWidget instanceof a) {
      DependencyNode dependencyNode = this.h;
      dependencyNode.b = true;
      a a = (a)constraintWidget;
      int j = a.g0;
      boolean bool = a.h0;
      boolean bool1 = false;
      boolean bool2 = false;
      boolean bool3 = false;
      int i = 0;
      if (j != 0) {
        DependencyNode dependencyNode1;
        if (j != 1) {
          if (j != 2) {
            if (j != 3)
              return; 
            dependencyNode.e = DependencyNode.Type.l;
            while (i < ((c)a).f0) {
              ConstraintWidget constraintWidget1 = ((c)a).e0[i];
              if (bool || constraintWidget1.X != 8) {
                dependencyNode1 = constraintWidget1.e.i;
                dependencyNode1.k.add(this.h);
                this.h.l.add(dependencyNode1);
              } 
              i++;
            } 
            m(this.b.e.h);
            m(this.b.e.i);
            return;
          } 
          dependencyNode1.e = DependencyNode.Type.k;
          for (i = bool1; i < ((c)a).f0; i++) {
            ConstraintWidget constraintWidget1 = ((c)a).e0[i];
            if (bool || constraintWidget1.X != 8) {
              dependencyNode1 = constraintWidget1.e.h;
              dependencyNode1.k.add(this.h);
              this.h.l.add(dependencyNode1);
            } 
          } 
          m(this.b.e.h);
          m(this.b.e.i);
          return;
        } 
        dependencyNode1.e = DependencyNode.Type.j;
        for (i = bool2; i < ((c)a).f0; i++) {
          ConstraintWidget constraintWidget1 = ((c)a).e0[i];
          if (bool || constraintWidget1.X != 8) {
            dependencyNode = constraintWidget1.d.i;
            dependencyNode.k.add(this.h);
            this.h.l.add(dependencyNode);
          } 
        } 
        m(this.b.d.h);
        m(this.b.d.i);
        return;
      } 
      dependencyNode.e = DependencyNode.Type.i;
      for (i = bool3; i < ((c)a).f0; i++) {
        ConstraintWidget constraintWidget1 = ((c)a).e0[i];
        if (bool || constraintWidget1.X != 8) {
          DependencyNode dependencyNode1 = constraintWidget1.d.h;
          dependencyNode1.k.add(this.h);
          this.h.l.add(dependencyNode1);
        } 
      } 
      m(this.b.d.h);
      m(this.b.d.i);
    } 
  }
  
  public void e() {
    ConstraintWidget constraintWidget = this.b;
    if (constraintWidget instanceof a) {
      int i = ((a)constraintWidget).g0;
      if (i == 0 || i == 1) {
        constraintWidget.P = this.h.g;
        return;
      } 
      constraintWidget.Q = this.h.g;
      return;
    } 
  }
  
  public void f() {
    this.c = null;
    this.h.b();
  }
  
  public boolean k() {
    return false;
  }
  
  public final void m(DependencyNode paramDependencyNode) {
    this.h.k.add(paramDependencyNode);
    paramDependencyNode.l.add(this.h);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */