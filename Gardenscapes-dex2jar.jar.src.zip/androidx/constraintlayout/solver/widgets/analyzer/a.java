package androidx.constraintlayout.solver.widgets.analyzer;

import w.d;

public class a extends DependencyNode {
  public int m;
  
  public a(WidgetRun paramWidgetRun) {
    super(paramWidgetRun);
    if (paramWidgetRun instanceof c) {
      this.e = DependencyNode.Type.g;
      return;
    } 
    this.e = DependencyNode.Type.h;
  }
  
  public void c(int paramInt) {
    if (this.j)
      return; 
    this.j = true;
    this.g = paramInt;
    for (d d : this.k)
      d.a(d); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */