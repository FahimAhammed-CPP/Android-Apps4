package androidx.constraintlayout.solver.widgets.analyzer;

import android.support.v4.media.a;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import w.d;

public class c extends WidgetRun {
  public static int[] k = new int[2];
  
  public c(ConstraintWidget paramConstraintWidget) {
    super(paramConstraintWidget);
    this.h.e = DependencyNode.Type.i;
    this.i.e = DependencyNode.Type.j;
    this.f = 0;
  }
  
  public void a(d paramd) {
    ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.h;
    if (this.j.ordinal() != 3) {
      a a = this.e;
      if (!a.j && this.d == dimensionBehaviour) {
        DependencyNode dependencyNode1;
        DependencyNode dependencyNode2;
        ConstraintWidget constraintWidget = this.b;
        int i = constraintWidget.j;
        if (i != 2) {
          if (i == 3) {
            i = constraintWidget.k;
            if (i == 0 || i == 3) {
              int j;
              int k;
              int m;
              d d1 = constraintWidget.e;
              dependencyNode1 = d1.h;
              DependencyNode dependencyNode3 = d1.i;
              if (constraintWidget.y.d != null) {
                i = 1;
              } else {
                i = 0;
              } 
              if (constraintWidget.z.d != null) {
                j = 1;
              } else {
                j = 0;
              } 
              if (constraintWidget.A.d != null) {
                k = 1;
              } else {
                k = 0;
              } 
              if (constraintWidget.B.d != null) {
                m = 1;
              } else {
                m = 0;
              } 
              int n = constraintWidget.O;
              if (i != 0 && j && k && m) {
                float f = constraintWidget.N;
                if (dependencyNode1.j && dependencyNode3.j) {
                  DependencyNode dependencyNode4 = this.h;
                  if (dependencyNode4.c) {
                    if (!this.i.c)
                      return; 
                    i = ((DependencyNode)dependencyNode4.l.get(0)).g;
                    j = this.h.f;
                    k = ((DependencyNode)this.i.l.get(0)).g;
                    m = this.i.f;
                    int i1 = dependencyNode1.g;
                    int i2 = dependencyNode1.f;
                    int i3 = dependencyNode3.g;
                    int i4 = dependencyNode3.f;
                    int[] arrayOfInt = k;
                    m(arrayOfInt, i + j, k - m, i1 + i2, i3 - i4, f, n);
                    this.e.c(arrayOfInt[0]);
                    this.b.e.e.c(arrayOfInt[1]);
                  } 
                  return;
                } 
                dependencyNode2 = this.h;
                if (dependencyNode2.j) {
                  DependencyNode dependencyNode4 = this.i;
                  if (dependencyNode4.j)
                    if (dependencyNode1.c) {
                      if (!dependencyNode3.c)
                        return; 
                      i = dependencyNode2.g;
                      j = dependencyNode2.f;
                      k = dependencyNode4.g;
                      m = dependencyNode4.f;
                      int i1 = ((DependencyNode)dependencyNode1.l.get(0)).g;
                      int i2 = dependencyNode1.f;
                      int i3 = ((DependencyNode)dependencyNode3.l.get(0)).g;
                      int i4 = dependencyNode3.f;
                      int[] arrayOfInt = k;
                      m(arrayOfInt, i + j, k - m, i1 + i2, i3 - i4, f, n);
                      this.e.c(arrayOfInt[0]);
                      this.b.e.e.c(arrayOfInt[1]);
                    } else {
                      return;
                    }  
                } 
                dependencyNode2 = this.h;
                if (dependencyNode2.c && this.i.c && dependencyNode1.c) {
                  if (!dependencyNode3.c)
                    return; 
                  i = ((DependencyNode)dependencyNode2.l.get(0)).g;
                  j = this.h.f;
                  k = ((DependencyNode)this.i.l.get(0)).g;
                  m = this.i.f;
                  int i1 = ((DependencyNode)dependencyNode1.l.get(0)).g;
                  int i2 = dependencyNode1.f;
                  int i3 = ((DependencyNode)dependencyNode3.l.get(0)).g;
                  int i4 = dependencyNode3.f;
                  int[] arrayOfInt = k;
                  m(arrayOfInt, i + j, k - m, i1 + i2, i3 - i4, f, n);
                  this.e.c(arrayOfInt[0]);
                  this.b.e.e.c(arrayOfInt[1]);
                } else {
                  return;
                } 
              } else if (i != 0 && k != 0) {
                dependencyNode1 = this.h;
                if (dependencyNode1.c) {
                  if (!this.i.c)
                    return; 
                  float f = ((ConstraintWidget)dependencyNode2).N;
                  i = ((DependencyNode)dependencyNode1.l.get(0)).g + this.h.f;
                  j = ((DependencyNode)this.i.l.get(0)).g - this.i.f;
                  if (n != -1 && n != 0) {
                    if (n == 1) {
                      i = g(j - i, 0);
                      k = (int)(i / f + 0.5F);
                      j = g(k, 1);
                      if (k != j)
                        i = (int)(j * f + 0.5F); 
                      this.e.c(i);
                      this.b.e.e.c(j);
                    } 
                  } else {
                    i = g(j - i, 0);
                    k = (int)(i * f + 0.5F);
                    j = g(k, 1);
                    if (k != j)
                      i = (int)(j / f + 0.5F); 
                    this.e.c(i);
                    this.b.e.e.c(j);
                  } 
                } else {
                  return;
                } 
              } else if (j != 0 && m != 0) {
                if (dependencyNode1.c) {
                  if (!dependencyNode3.c)
                    return; 
                  float f = ((ConstraintWidget)dependencyNode2).N;
                  i = ((DependencyNode)dependencyNode1.l.get(0)).g + dependencyNode1.f;
                  j = ((DependencyNode)dependencyNode3.l.get(0)).g - dependencyNode3.f;
                  if (n != -1)
                    if (n != 0) {
                      if (n != 1)
                        dependencyNode1 = this.h; 
                    } else {
                      i = g(j - i, 1);
                      k = (int)(i * f + 0.5F);
                      j = g(k, 0);
                      if (k != j)
                        i = (int)(j / f + 0.5F); 
                      this.e.c(j);
                      this.b.e.e.c(i);
                      dependencyNode1 = this.h;
                    }  
                  i = g(j - i, 1);
                  k = (int)(i / f + 0.5F);
                  j = g(k, 0);
                  if (k != j)
                    i = (int)(j * f + 0.5F); 
                  this.e.c(j);
                  this.b.e.e.c(i);
                } else {
                  return;
                } 
              } 
            } else {
              i = ((ConstraintWidget)dependencyNode2).O;
              if (i != -1) {
                if (i != 0) {
                  if (i != 1) {
                    i = 0;
                  } else {
                    float f1 = ((ConstraintWidget)dependencyNode2).e.e.g;
                    float f2 = ((ConstraintWidget)dependencyNode2).N;
                    f1 *= f2;
                  } 
                } else {
                  float f = ((ConstraintWidget)dependencyNode2).e.e.g / ((ConstraintWidget)dependencyNode2).N;
                  i = (int)(f + 0.5F);
                } 
              } else {
                float f1 = ((ConstraintWidget)dependencyNode2).e.e.g;
                float f2 = ((ConstraintWidget)dependencyNode2).N;
                f1 *= f2;
              } 
              dependencyNode1.c(i);
            } 
          } 
        } else {
          ConstraintWidget constraintWidget1 = ((ConstraintWidget)dependencyNode2).K;
          if (constraintWidget1 != null) {
            a a1 = constraintWidget1.d.e;
            if (a1.j) {
              float f = ((ConstraintWidget)dependencyNode2).o;
              dependencyNode1.c((int)(a1.g * f + 0.5F));
            } 
          } 
        } 
      } 
    } else {
      ConstraintWidget constraintWidget = this.b;
      l(constraintWidget.y, constraintWidget.A, 0);
      return;
    } 
    DependencyNode dependencyNode = this.h;
  }
  
  public void d() {
    DependencyNode dependencyNode1;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.h;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.i;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.f;
    ConstraintWidget constraintWidget2 = this.b;
    if (constraintWidget2.a)
      this.e.c(constraintWidget2.o()); 
    if (!this.e.j) {
      ConstraintWidget.DimensionBehaviour dimensionBehaviour = this.b.j();
      this.d = dimensionBehaviour;
      if (dimensionBehaviour != dimensionBehaviour1) {
        if (dimensionBehaviour == dimensionBehaviour2) {
          ConstraintWidget constraintWidget = this.b.K;
          if ((constraintWidget != null && constraintWidget.j() == dimensionBehaviour3) || constraintWidget.j() == dimensionBehaviour2) {
            int i = constraintWidget.o();
            int j = this.b.y.b();
            int k = this.b.A.b();
            b(this.h, constraintWidget.d.h, this.b.y.b());
            b(this.i, constraintWidget.d.i, -this.b.A.b());
            this.e.c(i - j - k);
            return;
          } 
        } 
        if (this.d == dimensionBehaviour3)
          this.e.c(this.b.o()); 
      } 
    } else if (this.d == dimensionBehaviour2) {
      constraintWidget2 = this.b.K;
      if ((constraintWidget2 != null && constraintWidget2.j() == dimensionBehaviour3) || constraintWidget2.j() == dimensionBehaviour2) {
        b(this.h, constraintWidget2.d.h, this.b.y.b());
        b(this.i, constraintWidget2.d.i, -this.b.A.b());
        return;
      } 
    } 
    DependencyNode dependencyNode2 = this.e;
    if (dependencyNode2.j) {
      ConstraintWidget constraintWidget = this.b;
      if (constraintWidget.a) {
        DependencyNode dependencyNode;
        ConstraintAnchor[] arrayOfConstraintAnchor1 = constraintWidget.G;
        if ((arrayOfConstraintAnchor1[0]).d != null && (arrayOfConstraintAnchor1[1]).d != null) {
          if (constraintWidget.s()) {
            this.h.f = this.b.G[0].b();
            this.i.f = -this.b.G[1].b();
            return;
          } 
          dependencyNode = h(this.b.G[0]);
          if (dependencyNode != null) {
            dependencyNode1 = this.h;
            int i = this.b.G[0].b();
            dependencyNode1.l.add(dependencyNode);
            dependencyNode1.f = i;
            dependencyNode.k.add(dependencyNode1);
          } 
          dependencyNode = h(this.b.G[1]);
          if (dependencyNode != null) {
            dependencyNode1 = this.i;
            int i = -this.b.G[1].b();
            dependencyNode1.l.add(dependencyNode);
            dependencyNode1.f = i;
            dependencyNode.k.add(dependencyNode1);
          } 
          this.h.b = true;
          this.i.b = true;
          return;
        } 
        if (((ConstraintAnchor)dependencyNode[0]).d != null) {
          dependencyNode = h((ConstraintAnchor)dependencyNode[0]);
          if (dependencyNode != null) {
            dependencyNode1 = this.h;
            int i = this.b.G[0].b();
            dependencyNode1.l.add(dependencyNode);
            dependencyNode1.f = i;
            dependencyNode.k.add(dependencyNode1);
            b(this.i, this.h, this.e.g);
            return;
          } 
        } else if (((ConstraintAnchor)dependencyNode[1]).d != null) {
          dependencyNode = h((ConstraintAnchor)dependencyNode[1]);
          if (dependencyNode != null) {
            dependencyNode1 = this.i;
            int i = -this.b.G[1].b();
            dependencyNode1.l.add(dependencyNode);
            dependencyNode1.f = i;
            dependencyNode.k.add(dependencyNode1);
            b(this.h, this.i, -this.e.g);
            return;
          } 
        } else if (!(constraintWidget instanceof v.b) && constraintWidget.K != null && (constraintWidget.f(ConstraintAnchor.Type.k)).d == null) {
          constraintWidget1 = this.b;
          dependencyNode2 = constraintWidget1.K.d.h;
          b(this.h, dependencyNode2, constraintWidget1.p());
          b(this.i, this.h, this.e.g);
          return;
        } 
        return;
      } 
    } 
    if (this.d == constraintWidget1) {
      a a;
      constraintWidget1 = this.b;
      int i = constraintWidget1.j;
      if (i != 2) {
        if (i == 3) {
          d d;
          if (constraintWidget1.k == 3) {
            this.h.a = this;
            this.i.a = this;
            d d1 = constraintWidget1.e;
            d1.h.a = this;
            d1.i.a = this;
            dependencyNode2.a = this;
            if (constraintWidget1.t()) {
              this.e.l.add(this.b.e.e);
              this.b.e.e.k.add(this.e);
              d = this.b.e;
              d.e.a = this;
              this.e.l.add(d.h);
              this.e.l.add(this.b.e.i);
              this.b.e.h.k.add(this.e);
              this.b.e.i.k.add(this.e);
            } else if (this.b.s()) {
              this.b.e.e.l.add(this.e);
              this.e.k.add(this.b.e.e);
            } else {
              this.b.e.e.l.add(this.e);
            } 
          } else {
            a = ((ConstraintWidget)d).e.e;
            dependencyNode2.l.add(a);
            a.k.add(this.e);
            this.b.e.h.k.add(this.e);
            this.b.e.i.k.add(this.e);
            a = this.e;
            a.b = true;
            a.k.add(this.h);
            this.e.k.add(this.i);
            this.h.l.add(this.e);
            this.i.l.add(this.e);
          } 
        } 
      } else {
        ConstraintWidget constraintWidget = ((ConstraintWidget)a).K;
        if (constraintWidget != null) {
          a a1 = constraintWidget.e.e;
          dependencyNode2.l.add(a1);
          a1.k.add(this.e);
          a1 = this.e;
          a1.b = true;
          a1.k.add(this.h);
          this.e.k.add(this.i);
        } 
      } 
    } 
    ConstraintWidget constraintWidget1 = this.b;
    ConstraintAnchor[] arrayOfConstraintAnchor = constraintWidget1.G;
    if ((arrayOfConstraintAnchor[0]).d != null && (arrayOfConstraintAnchor[1]).d != null) {
      if (constraintWidget1.s()) {
        this.h.f = this.b.G[0].b();
        this.i.f = -this.b.G[1].b();
        return;
      } 
      DependencyNode dependencyNode = h(this.b.G[0]);
      dependencyNode1 = h(this.b.G[1]);
      dependencyNode.k.add(this);
      if (dependencyNode.j)
        a(this); 
      dependencyNode1.k.add(this);
      if (dependencyNode1.j)
        a(this); 
      this.j = WidgetRun.RunType.g;
      return;
    } 
    if (((ConstraintAnchor)dependencyNode1[0]).d != null) {
      DependencyNode dependencyNode = h((ConstraintAnchor)dependencyNode1[0]);
      if (dependencyNode != null) {
        dependencyNode1 = this.h;
        int i = this.b.G[0].b();
        dependencyNode1.l.add(dependencyNode);
        dependencyNode1.f = i;
        dependencyNode.k.add(dependencyNode1);
        c(this.i, this.h, 1, this.e);
        return;
      } 
    } else {
      DependencyNode dependencyNode;
      if (((ConstraintAnchor)dependencyNode1[1]).d != null) {
        dependencyNode = h((ConstraintAnchor)dependencyNode1[1]);
        if (dependencyNode != null) {
          dependencyNode1 = this.i;
          int i = -this.b.G[1].b();
          dependencyNode1.l.add(dependencyNode);
          dependencyNode1.f = i;
          dependencyNode.k.add(dependencyNode1);
          c(this.h, this.i, -1, this.e);
          return;
        } 
      } else if (!(dependencyNode instanceof v.b)) {
        ConstraintWidget constraintWidget = ((ConstraintWidget)dependencyNode).K;
        if (constraintWidget != null) {
          DependencyNode dependencyNode3 = constraintWidget.d.h;
          b(this.h, dependencyNode3, dependencyNode.p());
          c(this.i, this.h, 1, this.e);
        } 
      } 
    } 
  }
  
  public void e() {
    DependencyNode dependencyNode = this.h;
    if (dependencyNode.j)
      this.b.P = dependencyNode.g; 
  }
  
  public void f() {
    this.c = null;
    this.h.b();
    this.i.b();
    this.e.b();
    this.g = false;
  }
  
  public boolean k() {
    return (this.d == ConstraintWidget.DimensionBehaviour.h) ? ((this.b.j == 0)) : true;
  }
  
  public final void m(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
    paramInt1 = paramInt2 - paramInt1;
    paramInt2 = paramInt4 - paramInt3;
    if (paramInt5 != -1) {
      if (paramInt5 != 0) {
        if (paramInt5 != 1)
          return; 
        paramInt2 = (int)(paramInt1 * paramFloat + 0.5F);
        paramArrayOfint[0] = paramInt1;
        paramArrayOfint[1] = paramInt2;
        return;
      } 
      paramArrayOfint[0] = (int)(paramInt2 * paramFloat + 0.5F);
      paramArrayOfint[1] = paramInt2;
      return;
    } 
    paramInt3 = (int)(paramInt2 * paramFloat + 0.5F);
    paramInt4 = (int)(paramInt1 / paramFloat + 0.5F);
    if (paramInt3 <= paramInt1) {
      paramArrayOfint[0] = paramInt3;
      paramArrayOfint[1] = paramInt2;
      return;
    } 
    if (paramInt4 <= paramInt2) {
      paramArrayOfint[0] = paramInt1;
      paramArrayOfint[1] = paramInt4;
    } 
  }
  
  public void n() {
    this.g = false;
    this.h.b();
    this.h.j = false;
    this.i.b();
    this.i.j = false;
    this.e.j = false;
  }
  
  public String toString() {
    StringBuilder stringBuilder = a.a("HorizontalRun ");
    stringBuilder.append(this.b.Y);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */