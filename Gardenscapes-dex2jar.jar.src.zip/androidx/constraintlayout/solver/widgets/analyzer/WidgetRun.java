package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import w.d;
import w.h;

public abstract class WidgetRun implements d {
  public int a;
  
  public ConstraintWidget b;
  
  public h c;
  
  public ConstraintWidget.DimensionBehaviour d;
  
  public a e = new a(this);
  
  public int f = 0;
  
  public boolean g = false;
  
  public DependencyNode h = new DependencyNode(this);
  
  public DependencyNode i = new DependencyNode(this);
  
  public RunType j = RunType.f;
  
  public WidgetRun(ConstraintWidget paramConstraintWidget) {
    this.b = paramConstraintWidget;
  }
  
  public void a(d paramd) {}
  
  public final void b(DependencyNode paramDependencyNode1, DependencyNode paramDependencyNode2, int paramInt) {
    paramDependencyNode1.l.add(paramDependencyNode2);
    paramDependencyNode1.f = paramInt;
    paramDependencyNode2.k.add(paramDependencyNode1);
  }
  
  public final void c(DependencyNode paramDependencyNode1, DependencyNode paramDependencyNode2, int paramInt, a parama) {
    paramDependencyNode1.l.add(paramDependencyNode2);
    paramDependencyNode1.l.add(this.e);
    paramDependencyNode1.h = paramInt;
    paramDependencyNode1.i = parama;
    paramDependencyNode2.k.add(paramDependencyNode1);
    parama.k.add(paramDependencyNode1);
  }
  
  public abstract void d();
  
  public abstract void e();
  
  public abstract void f();
  
  public final int g(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      ConstraintWidget constraintWidget = this.b;
      int i = constraintWidget.n;
      paramInt2 = Math.max(constraintWidget.m, paramInt1);
      if (i > 0)
        paramInt2 = Math.min(i, paramInt1); 
      i = paramInt1;
      if (paramInt2 != paramInt1)
        return paramInt2; 
    } else {
      ConstraintWidget constraintWidget = this.b;
      int i = constraintWidget.q;
      paramInt2 = Math.max(constraintWidget.p, paramInt1);
      if (i > 0)
        paramInt2 = Math.min(i, paramInt1); 
      i = paramInt1;
      if (paramInt2 != paramInt1)
        return paramInt2; 
    } 
    return SYNTHETIC_LOCAL_VARIABLE_3;
  }
  
  public final DependencyNode h(ConstraintAnchor paramConstraintAnchor) {
    paramConstraintAnchor = paramConstraintAnchor.d;
    if (paramConstraintAnchor == null)
      return null; 
    ConstraintWidget constraintWidget = paramConstraintAnchor.b;
    int i = paramConstraintAnchor.c.ordinal();
    return (i != 1) ? ((i != 2) ? ((i != 3) ? ((i != 4) ? ((i != 5) ? null : constraintWidget.e.k) : constraintWidget.e.i) : constraintWidget.d.i) : constraintWidget.e.h) : constraintWidget.d.h;
  }
  
  public final DependencyNode i(ConstraintAnchor paramConstraintAnchor, int paramInt) {
    c c;
    d d1;
    ConstraintAnchor constraintAnchor = paramConstraintAnchor.d;
    if (constraintAnchor == null)
      return null; 
    ConstraintWidget constraintWidget = constraintAnchor.b;
    if (paramInt == 0) {
      c = constraintWidget.d;
    } else {
      d1 = ((ConstraintWidget)c).e;
    } 
    paramInt = constraintAnchor.c.ordinal();
    return (paramInt != 1 && paramInt != 2) ? ((paramInt != 3 && paramInt != 4) ? null : d1.i) : d1.h;
  }
  
  public long j() {
    a a1 = this.e;
    return a1.j ? a1.g : 0L;
  }
  
  public abstract boolean k();
  
  public void l(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual h : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   5: astore #11
    //   7: aload_0
    //   8: aload_2
    //   9: invokevirtual h : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;)Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   12: astore #12
    //   14: aload #11
    //   16: getfield j : Z
    //   19: ifeq -> 541
    //   22: aload #12
    //   24: getfield j : Z
    //   27: ifne -> 31
    //   30: return
    //   31: aload #11
    //   33: getfield g : I
    //   36: istore #6
    //   38: aload_1
    //   39: invokevirtual b : ()I
    //   42: iload #6
    //   44: iadd
    //   45: istore #7
    //   47: aload #12
    //   49: getfield g : I
    //   52: aload_2
    //   53: invokevirtual b : ()I
    //   56: isub
    //   57: istore #8
    //   59: iload #8
    //   61: iload #7
    //   63: isub
    //   64: istore #9
    //   66: aload_0
    //   67: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   70: astore_2
    //   71: aload_2
    //   72: getfield j : Z
    //   75: ifne -> 387
    //   78: aload_0
    //   79: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   82: astore_1
    //   83: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.h : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   86: astore #14
    //   88: aload_1
    //   89: aload #14
    //   91: if_acmpne -> 387
    //   94: aload_0
    //   95: getfield a : I
    //   98: istore #6
    //   100: iload #6
    //   102: ifeq -> 376
    //   105: iload #6
    //   107: iconst_1
    //   108: if_icmpeq -> 348
    //   111: iload #6
    //   113: iconst_2
    //   114: if_icmpeq -> 258
    //   117: iload #6
    //   119: iconst_3
    //   120: if_icmpeq -> 126
    //   123: goto -> 387
    //   126: aload_0
    //   127: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   130: astore #13
    //   132: aload #13
    //   134: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   137: astore_1
    //   138: aload_1
    //   139: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   142: aload #14
    //   144: if_acmpne -> 184
    //   147: aload_1
    //   148: getfield a : I
    //   151: iconst_3
    //   152: if_icmpne -> 184
    //   155: aload #13
    //   157: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   160: astore #15
    //   162: aload #15
    //   164: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   167: aload #14
    //   169: if_acmpne -> 184
    //   172: aload #15
    //   174: getfield a : I
    //   177: iconst_3
    //   178: if_icmpne -> 184
    //   181: goto -> 387
    //   184: iload_3
    //   185: ifne -> 194
    //   188: aload #13
    //   190: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   193: astore_1
    //   194: aload_1
    //   195: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   198: astore_1
    //   199: aload_1
    //   200: getfield j : Z
    //   203: ifeq -> 387
    //   206: aload #13
    //   208: getfield N : F
    //   211: fstore #4
    //   213: iload_3
    //   214: iconst_1
    //   215: if_icmpne -> 235
    //   218: aload_1
    //   219: getfield g : I
    //   222: i2f
    //   223: fload #4
    //   225: fdiv
    //   226: ldc 0.5
    //   228: fadd
    //   229: f2i
    //   230: istore #6
    //   232: goto -> 249
    //   235: fload #4
    //   237: aload_1
    //   238: getfield g : I
    //   241: i2f
    //   242: fmul
    //   243: ldc 0.5
    //   245: fadd
    //   246: f2i
    //   247: istore #6
    //   249: aload_2
    //   250: iload #6
    //   252: invokevirtual c : (I)V
    //   255: goto -> 387
    //   258: aload_0
    //   259: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   262: astore #13
    //   264: aload #13
    //   266: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   269: astore_1
    //   270: aload_1
    //   271: ifnull -> 387
    //   274: iload_3
    //   275: ifne -> 286
    //   278: aload_1
    //   279: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   282: astore_1
    //   283: goto -> 291
    //   286: aload_1
    //   287: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   290: astore_1
    //   291: aload_1
    //   292: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   295: astore_1
    //   296: aload_1
    //   297: getfield j : Z
    //   300: ifeq -> 387
    //   303: iload_3
    //   304: ifne -> 317
    //   307: aload #13
    //   309: getfield o : F
    //   312: fstore #4
    //   314: goto -> 324
    //   317: aload #13
    //   319: getfield r : F
    //   322: fstore #4
    //   324: aload_2
    //   325: aload_0
    //   326: aload_1
    //   327: getfield g : I
    //   330: i2f
    //   331: fload #4
    //   333: fmul
    //   334: ldc 0.5
    //   336: fadd
    //   337: f2i
    //   338: iload_3
    //   339: invokevirtual g : (II)I
    //   342: invokevirtual c : (I)V
    //   345: goto -> 387
    //   348: aload_0
    //   349: aload_2
    //   350: getfield m : I
    //   353: iload_3
    //   354: invokevirtual g : (II)I
    //   357: istore #6
    //   359: aload_0
    //   360: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   363: iload #6
    //   365: iload #9
    //   367: invokestatic min : (II)I
    //   370: invokevirtual c : (I)V
    //   373: goto -> 387
    //   376: aload_2
    //   377: aload_0
    //   378: iload #9
    //   380: iload_3
    //   381: invokevirtual g : (II)I
    //   384: invokevirtual c : (I)V
    //   387: aload_0
    //   388: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   391: astore_1
    //   392: aload_1
    //   393: getfield j : Z
    //   396: ifne -> 400
    //   399: return
    //   400: aload_1
    //   401: getfield g : I
    //   404: istore #10
    //   406: iload #10
    //   408: iload #9
    //   410: if_icmpne -> 432
    //   413: aload_0
    //   414: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   417: iload #7
    //   419: invokevirtual c : (I)V
    //   422: aload_0
    //   423: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   426: iload #8
    //   428: invokevirtual c : (I)V
    //   431: return
    //   432: aload_0
    //   433: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   436: astore_1
    //   437: iload_3
    //   438: ifne -> 450
    //   441: aload_1
    //   442: getfield U : F
    //   445: fstore #4
    //   447: goto -> 456
    //   450: aload_1
    //   451: getfield V : F
    //   454: fstore #4
    //   456: iload #8
    //   458: istore_3
    //   459: iload #7
    //   461: istore #6
    //   463: aload #11
    //   465: aload #12
    //   467: if_acmpne -> 487
    //   470: aload #11
    //   472: getfield g : I
    //   475: istore #6
    //   477: aload #12
    //   479: getfield g : I
    //   482: istore_3
    //   483: ldc 0.5
    //   485: fstore #4
    //   487: aload_0
    //   488: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   491: astore_1
    //   492: iload #6
    //   494: i2f
    //   495: fstore #5
    //   497: aload_1
    //   498: iload_3
    //   499: iload #6
    //   501: isub
    //   502: iload #10
    //   504: isub
    //   505: i2f
    //   506: fload #4
    //   508: fmul
    //   509: fload #5
    //   511: ldc 0.5
    //   513: fadd
    //   514: fadd
    //   515: f2i
    //   516: invokevirtual c : (I)V
    //   519: aload_0
    //   520: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   523: aload_0
    //   524: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   527: getfield g : I
    //   530: aload_0
    //   531: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   534: getfield g : I
    //   537: iadd
    //   538: invokevirtual c : (I)V
    //   541: return
  }
  
  public enum RunType {
    f, g;
    
    static {
      RunType runType1 = new RunType("NONE", 0);
      f = runType1;
      RunType runType2 = new RunType("START", 1);
      RunType runType3 = new RunType("END", 2);
      RunType runType4 = new RunType("CENTER", 3);
      g = runType4;
      h = new RunType[] { runType1, runType2, runType3, runType4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\WidgetRun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */