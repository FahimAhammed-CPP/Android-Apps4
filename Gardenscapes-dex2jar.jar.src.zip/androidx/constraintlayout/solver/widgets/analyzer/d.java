package androidx.constraintlayout.solver.widgets.analyzer;

import android.support.v4.media.a;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import w.a;

public class d extends WidgetRun {
  public DependencyNode k;
  
  public a l;
  
  public d(ConstraintWidget paramConstraintWidget) {
    super(paramConstraintWidget);
    DependencyNode dependencyNode = new DependencyNode(this);
    this.k = dependencyNode;
    this.l = null;
    this.h.e = DependencyNode.Type.k;
    this.i.e = DependencyNode.Type.l;
    dependencyNode.e = DependencyNode.Type.m;
    this.f = 1;
  }
  
  public void a(w.d paramd) {
    ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.h;
    if (this.j.ordinal() != 3) {
      a a1 = this.e;
      if (a1.c && !a1.j && this.d == dimensionBehaviour) {
        ConstraintWidget constraintWidget1 = this.b;
        int i = constraintWidget1.k;
        if (i != 2) {
          if (i == 3) {
            a a2 = constraintWidget1.d.e;
            if (a2.j) {
              i = constraintWidget1.O;
              if (i != -1) {
                if (i != 0) {
                  if (i != 1) {
                    i = 0;
                  } else {
                    float f1 = a2.g;
                    float f2 = constraintWidget1.N;
                    f1 /= f2;
                  } 
                } else {
                  float f = a2.g * constraintWidget1.N;
                  i = (int)(f + 0.5F);
                } 
              } else {
                float f1 = a2.g;
                float f2 = constraintWidget1.N;
                f1 /= f2;
              } 
              a1.c(i);
            } 
          } 
        } else {
          ConstraintWidget constraintWidget2 = constraintWidget1.K;
          if (constraintWidget2 != null) {
            a a2 = constraintWidget2.e.e;
            if (a2.j) {
              float f = constraintWidget1.r;
              a1.c((int)(a2.g * f + 0.5F));
            } 
          } 
        } 
      } 
      DependencyNode dependencyNode = this.h;
      if (dependencyNode.c) {
        DependencyNode dependencyNode1;
        DependencyNode dependencyNode2 = this.i;
        if (!dependencyNode2.c)
          return; 
        if (dependencyNode.j && dependencyNode2.j && this.e.j)
          return; 
        if (!this.e.j && this.d == dimensionBehaviour) {
          ConstraintWidget constraintWidget1 = this.b;
          if (constraintWidget1.j == 0 && !constraintWidget1.t()) {
            DependencyNode dependencyNode3 = this.h.l.get(0);
            dependencyNode1 = this.i.l.get(0);
            int i = dependencyNode3.g;
            dependencyNode3 = this.h;
            i += dependencyNode3.f;
            int j = dependencyNode1.g + this.i.f;
            dependencyNode3.c(i);
            this.i.c(j);
            this.e.c(j - i);
            return;
          } 
        } 
        if (!this.e.j && this.d == dependencyNode1 && this.a == 1 && this.h.l.size() > 0 && this.i.l.size() > 0) {
          dependencyNode1 = this.h.l.get(0);
          dependencyNode = this.i.l.get(0);
          int i = dependencyNode1.g;
          int j = this.h.f;
          i = dependencyNode.g + this.i.f - i + j;
          dependencyNode1 = this.e;
          j = ((a)dependencyNode1).m;
          if (i < j) {
            dependencyNode1.c(i);
          } else {
            dependencyNode1.c(j);
          } 
        } 
        if (!this.e.j)
          return; 
        if (this.h.l.size() > 0 && this.i.l.size() > 0) {
          dependencyNode1 = this.h.l.get(0);
          dependencyNode = this.i.l.get(0);
          int i = dependencyNode1.g;
          dependencyNode2 = this.h;
          int m = dependencyNode2.f;
          int j = dependencyNode.g;
          int k = this.i.f;
          float f1 = this.b.V;
          if (dependencyNode1 == dependencyNode) {
            f1 = 0.5F;
          } else {
            i = m + i;
            j = k + j;
          } 
          k = this.e.g;
          float f2 = i;
          dependencyNode2.c((int)((j - i - k) * f1 + f2 + 0.5F));
          this.i.c(this.h.g + this.e.g);
        } 
      } 
      return;
    } 
    ConstraintWidget constraintWidget = this.b;
    l(constraintWidget.z, constraintWidget.B, 1);
  }
  
  public void d() {
    ConstraintWidget constraintWidget1;
    DependencyNode dependencyNode;
    ConstraintWidget constraintWidget3;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.i;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.f;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.h;
    ConstraintWidget constraintWidget4 = this.b;
    if (constraintWidget4.a)
      this.e.c(constraintWidget4.i()); 
    if (!this.e.j) {
      this.d = this.b.n();
      if (this.b.w)
        this.l = (a)new a(this); 
      ConstraintWidget.DimensionBehaviour dimensionBehaviour = this.d;
      if (dimensionBehaviour != dimensionBehaviour1) {
        if (dimensionBehaviour == dimensionBehaviour3) {
          constraintWidget3 = this.b.K;
          if (constraintWidget3 != null && constraintWidget3.n() == dimensionBehaviour2) {
            int i = constraintWidget3.i();
            int j = this.b.z.b();
            int k = this.b.B.b();
            b(this.h, constraintWidget3.e.h, this.b.z.b());
            b(this.i, constraintWidget3.e.i, -this.b.B.b());
            this.e.c(i - j - k);
            return;
          } 
        } 
        if (this.d == dimensionBehaviour2)
          this.e.c(this.b.i()); 
      } 
    } else if (this.d == constraintWidget3) {
      constraintWidget3 = this.b.K;
      if (constraintWidget3 != null && constraintWidget3.n() == dimensionBehaviour2) {
        b(this.h, constraintWidget3.e.h, this.b.z.b());
        b(this.i, constraintWidget3.e.i, -this.b.B.b());
        return;
      } 
    } 
    a a1 = this.e;
    boolean bool = a1.j;
    if (bool) {
      constraintWidget3 = this.b;
      if (constraintWidget3.a) {
        ConstraintAnchor[] arrayOfConstraintAnchor1 = constraintWidget3.G;
        if ((arrayOfConstraintAnchor1[2]).d != null && (arrayOfConstraintAnchor1[3]).d != null) {
          if (constraintWidget3.t()) {
            this.h.f = this.b.G[2].b();
            this.i.f = -this.b.G[3].b();
          } else {
            dependencyNode = h(this.b.G[2]);
            if (dependencyNode != null) {
              DependencyNode dependencyNode1 = this.h;
              int i = this.b.G[2].b();
              dependencyNode1.l.add(dependencyNode);
              dependencyNode1.f = i;
              dependencyNode.k.add(dependencyNode1);
            } 
            dependencyNode = h(this.b.G[3]);
            if (dependencyNode != null) {
              DependencyNode dependencyNode1 = this.i;
              int i = -this.b.G[3].b();
              dependencyNode1.l.add(dependencyNode);
              dependencyNode1.f = i;
              dependencyNode.k.add(dependencyNode1);
            } 
            this.h.b = true;
            this.i.b = true;
          } 
          constraintWidget1 = this.b;
          if (constraintWidget1.w) {
            b(this.k, this.h, constraintWidget1.R);
            return;
          } 
        } else {
          ConstraintWidget constraintWidget;
          if (((ConstraintAnchor)constraintWidget1[2]).d != null) {
            dependencyNode = h((ConstraintAnchor)constraintWidget1[2]);
            if (dependencyNode != null) {
              DependencyNode dependencyNode1 = this.h;
              int i = this.b.G[2].b();
              dependencyNode1.l.add(dependencyNode);
              dependencyNode1.f = i;
              dependencyNode.k.add(dependencyNode1);
              b(this.i, this.h, this.e.g);
              constraintWidget = this.b;
              if (constraintWidget.w) {
                b(this.k, this.h, constraintWidget.R);
                return;
              } 
            } 
          } else if (((ConstraintAnchor)constraintWidget[3]).d != null) {
            dependencyNode = h((ConstraintAnchor)constraintWidget[3]);
            if (dependencyNode != null) {
              DependencyNode dependencyNode1 = this.i;
              int i = -this.b.G[3].b();
              dependencyNode1.l.add(dependencyNode);
              dependencyNode1.f = i;
              dependencyNode.k.add(dependencyNode1);
              b(this.h, this.i, -this.e.g);
            } 
            constraintWidget1 = this.b;
            if (constraintWidget1.w) {
              b(this.k, this.h, constraintWidget1.R);
              return;
            } 
          } else if (((ConstraintAnchor)constraintWidget1[4]).d != null) {
            dependencyNode = h((ConstraintAnchor)constraintWidget1[4]);
            if (dependencyNode != null) {
              DependencyNode dependencyNode1 = this.k;
              dependencyNode1.l.add(dependencyNode);
              dependencyNode1.f = 0;
              dependencyNode.k.add(dependencyNode1);
              b(this.h, this.k, -this.b.R);
              b(this.i, this.h, this.e.g);
              return;
            } 
          } else if (!(constraintWidget3 instanceof v.b) && constraintWidget3.K != null && (constraintWidget3.f(ConstraintAnchor.Type.k)).d == null) {
            constraintWidget1 = this.b;
            DependencyNode dependencyNode1 = constraintWidget1.K.e.h;
            b(this.h, dependencyNode1, constraintWidget1.q());
            b(this.i, this.h, this.e.g);
            constraintWidget1 = this.b;
            if (constraintWidget1.w) {
              b(this.k, this.h, constraintWidget1.R);
              return;
            } 
          } 
        } 
        return;
      } 
    } 
    if (!bool && this.d == constraintWidget1) {
      constraintWidget3 = this.b;
      int i = constraintWidget3.k;
      if (i != 2) {
        if (i == 3 && !constraintWidget3.t()) {
          ConstraintWidget constraintWidget = this.b;
          if (constraintWidget.j != 3) {
            a1 = constraintWidget.d.e;
            this.e.l.add(a1);
            a1.k.add(this.e);
            a1 = this.e;
            a1.b = true;
            a1.k.add(this.h);
            this.e.k.add(this.i);
          } 
        } 
      } else {
        constraintWidget3 = constraintWidget3.K;
        if (constraintWidget3 != null) {
          a a2 = constraintWidget3.e.e;
          a1.l.add(a2);
          a2.k.add(this.e);
          a1 = this.e;
          a1.b = true;
          a1.k.add(this.h);
          this.e.k.add(this.i);
        } 
      } 
    } else {
      a1.k.add(this);
      if (a1.j)
        a(this); 
    } 
    ConstraintWidget constraintWidget2 = this.b;
    ConstraintAnchor[] arrayOfConstraintAnchor = constraintWidget2.G;
    if ((arrayOfConstraintAnchor[2]).d != null && (arrayOfConstraintAnchor[3]).d != null) {
      if (constraintWidget2.t()) {
        this.h.f = this.b.G[2].b();
        this.i.f = -this.b.G[3].b();
      } else {
        dependencyNode = h(this.b.G[2]);
        DependencyNode dependencyNode1 = h(this.b.G[3]);
        dependencyNode.k.add(this);
        if (dependencyNode.j)
          a(this); 
        dependencyNode1.k.add(this);
        if (dependencyNode1.j)
          a(this); 
        this.j = WidgetRun.RunType.g;
      } 
      if (this.b.w)
        c(this.k, this.h, 1, this.l); 
    } else {
      DependencyNode dependencyNode1;
      if ((arrayOfConstraintAnchor[2]).d != null) {
        DependencyNode dependencyNode2 = h(arrayOfConstraintAnchor[2]);
        if (dependencyNode2 != null) {
          dependencyNode1 = this.h;
          int i = this.b.G[2].b();
          dependencyNode1.l.add(dependencyNode2);
          dependencyNode1.f = i;
          dependencyNode2.k.add(dependencyNode1);
          c(this.i, this.h, 1, this.e);
          if (this.b.w)
            c(this.k, this.h, 1, this.l); 
          if (this.d == dependencyNode) {
            ConstraintWidget constraintWidget = this.b;
            if (constraintWidget.N > 0.0F) {
              c c = constraintWidget.d;
              if (c.d == dependencyNode) {
                c.e.k.add(this.e);
                this.e.l.add(this.b.d.e);
                this.e.a = this;
              } 
            } 
          } 
        } 
      } else if (((ConstraintAnchor)dependencyNode1[3]).d != null) {
        dependencyNode = h((ConstraintAnchor)dependencyNode1[3]);
        if (dependencyNode != null) {
          DependencyNode dependencyNode2 = this.i;
          int i = -this.b.G[3].b();
          dependencyNode2.l.add(dependencyNode);
          dependencyNode2.f = i;
          dependencyNode.k.add(dependencyNode2);
          c(this.h, this.i, -1, this.e);
          if (this.b.w)
            c(this.k, this.h, 1, this.l); 
        } 
      } else {
        DependencyNode dependencyNode2;
        if (((ConstraintAnchor)dependencyNode1[4]).d != null) {
          dependencyNode = h((ConstraintAnchor)dependencyNode1[4]);
          if (dependencyNode != null) {
            dependencyNode2 = this.k;
            dependencyNode2.l.add(dependencyNode);
            dependencyNode2.f = 0;
            dependencyNode.k.add(dependencyNode2);
            c(this.h, this.k, -1, this.l);
            c(this.i, this.h, 1, this.e);
          } 
        } else if (!(dependencyNode2 instanceof v.b)) {
          ConstraintWidget constraintWidget = ((ConstraintWidget)dependencyNode2).K;
          if (constraintWidget != null) {
            DependencyNode dependencyNode3 = constraintWidget.e.h;
            b(this.h, dependencyNode3, dependencyNode2.q());
            c(this.i, this.h, 1, this.e);
            if (this.b.w)
              c(this.k, this.h, 1, this.l); 
            if (this.d == dependencyNode) {
              ConstraintWidget constraintWidget5 = this.b;
              if (constraintWidget5.N > 0.0F) {
                c c = constraintWidget5.d;
                if (c.d == dependencyNode) {
                  c.e.k.add(this.e);
                  this.e.l.add(this.b.d.e);
                  this.e.a = this;
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    if (this.e.l.size() == 0)
      this.e.c = true; 
  }
  
  public void e() {
    DependencyNode dependencyNode = this.h;
    if (dependencyNode.j)
      this.b.Q = dependencyNode.g; 
  }
  
  public void f() {
    this.c = null;
    this.h.b();
    this.i.b();
    this.k.b();
    this.e.b();
    this.g = false;
  }
  
  public boolean k() {
    return (this.d == ConstraintWidget.DimensionBehaviour.h) ? ((this.b.k == 0)) : true;
  }
  
  public void m() {
    this.g = false;
    this.h.b();
    this.h.j = false;
    this.i.b();
    this.i.j = false;
    this.k.b();
    this.k.j = false;
    this.e.j = false;
  }
  
  public String toString() {
    StringBuilder stringBuilder = a.a("VerticalRun ");
    stringBuilder.append(this.b.Y);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */