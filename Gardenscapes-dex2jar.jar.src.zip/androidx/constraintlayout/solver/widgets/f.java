package androidx.constraintlayout.solver.widgets;

public class f {
  public static boolean[] a = new boolean[3];
  
  public static final boolean a(int paramInt1, int paramInt2) {
    return ((paramInt1 & paramInt2) == paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */