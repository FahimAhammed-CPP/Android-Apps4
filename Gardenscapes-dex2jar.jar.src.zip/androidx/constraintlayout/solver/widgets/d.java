package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.c;
import java.util.Arrays;
import java.util.Objects;
import v.d;
import w.b;
import w.f;

public class d extends d {
  public b f0 = new b(this);
  
  public f g0 = new f(this);
  
  public b.b h0 = null;
  
  public boolean i0 = false;
  
  public c j0 = new c();
  
  public int k0;
  
  public int l0;
  
  public int m0 = 0;
  
  public int n0 = 0;
  
  public c[] o0 = new c[4];
  
  public c[] p0 = new c[4];
  
  public int q0 = 263;
  
  public boolean r0 = false;
  
  public boolean s0 = false;
  
  public void C(boolean paramBoolean1, boolean paramBoolean2) {
    super.C(paramBoolean1, paramBoolean2);
    int j = this.e0.size();
    for (int i = 0; i < j; i++)
      ((ConstraintWidget)this.e0.get(i)).C(paramBoolean1, paramBoolean2); 
  }
  
  public void E() {
    // Byte code:
    //   0: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.g : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   3: astore #13
    //   5: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.f : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   8: astore #14
    //   10: aload_0
    //   11: iconst_0
    //   12: putfield P : I
    //   15: aload_0
    //   16: iconst_0
    //   17: putfield Q : I
    //   20: iconst_0
    //   21: aload_0
    //   22: invokevirtual o : ()I
    //   25: invokestatic max : (II)I
    //   28: istore #9
    //   30: iconst_0
    //   31: aload_0
    //   32: invokevirtual i : ()I
    //   35: invokestatic max : (II)I
    //   38: istore #10
    //   40: aload_0
    //   41: iconst_0
    //   42: putfield r0 : Z
    //   45: aload_0
    //   46: iconst_0
    //   47: putfield s0 : Z
    //   50: aload_0
    //   51: getfield q0 : I
    //   54: istore_2
    //   55: iload_2
    //   56: bipush #64
    //   58: iand
    //   59: bipush #64
    //   61: if_icmpne -> 69
    //   64: iconst_1
    //   65: istore_1
    //   66: goto -> 71
    //   69: iconst_0
    //   70: istore_1
    //   71: iload_1
    //   72: ifne -> 105
    //   75: iload_2
    //   76: sipush #128
    //   79: iand
    //   80: sipush #128
    //   83: if_icmpne -> 91
    //   86: iconst_1
    //   87: istore_1
    //   88: goto -> 93
    //   91: iconst_0
    //   92: istore_1
    //   93: iload_1
    //   94: ifeq -> 100
    //   97: goto -> 105
    //   100: iconst_0
    //   101: istore_1
    //   102: goto -> 107
    //   105: iconst_1
    //   106: istore_1
    //   107: aload_0
    //   108: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   111: astore #12
    //   113: aload #12
    //   115: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   118: pop
    //   119: aload #12
    //   121: iconst_0
    //   122: putfield f : Z
    //   125: iload_2
    //   126: ifeq -> 139
    //   129: iload_1
    //   130: ifeq -> 139
    //   133: aload #12
    //   135: iconst_1
    //   136: putfield f : Z
    //   139: aload_0
    //   140: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   143: astore #12
    //   145: aload #12
    //   147: iconst_1
    //   148: aaload
    //   149: astore #15
    //   151: aload #12
    //   153: iconst_0
    //   154: aaload
    //   155: astore #16
    //   157: aload_0
    //   158: getfield e0 : Ljava/util/ArrayList;
    //   161: astore #17
    //   163: aload_0
    //   164: invokevirtual j : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   167: aload #13
    //   169: if_acmpeq -> 189
    //   172: aload_0
    //   173: invokevirtual n : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   176: aload #13
    //   178: if_acmpne -> 184
    //   181: goto -> 189
    //   184: iconst_0
    //   185: istore_2
    //   186: goto -> 191
    //   189: iconst_1
    //   190: istore_2
    //   191: aload_0
    //   192: iconst_0
    //   193: putfield m0 : I
    //   196: aload_0
    //   197: iconst_0
    //   198: putfield n0 : I
    //   201: aload_0
    //   202: getfield e0 : Ljava/util/ArrayList;
    //   205: invokevirtual size : ()I
    //   208: istore #11
    //   210: iconst_0
    //   211: istore_1
    //   212: iload_1
    //   213: iload #11
    //   215: if_icmpge -> 254
    //   218: aload_0
    //   219: getfield e0 : Ljava/util/ArrayList;
    //   222: iload_1
    //   223: invokevirtual get : (I)Ljava/lang/Object;
    //   226: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   229: astore #12
    //   231: aload #12
    //   233: instanceof v/d
    //   236: ifeq -> 247
    //   239: aload #12
    //   241: checkcast v/d
    //   244: invokevirtual E : ()V
    //   247: iload_1
    //   248: iconst_1
    //   249: iadd
    //   250: istore_1
    //   251: goto -> 212
    //   254: iconst_0
    //   255: istore #5
    //   257: iconst_1
    //   258: istore_3
    //   259: iconst_0
    //   260: istore_1
    //   261: iload_3
    //   262: ifeq -> 1082
    //   265: iload #5
    //   267: iconst_1
    //   268: iadd
    //   269: istore #8
    //   271: aload_0
    //   272: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   275: invokevirtual t : ()V
    //   278: aload_0
    //   279: iconst_0
    //   280: putfield m0 : I
    //   283: aload_0
    //   284: iconst_0
    //   285: putfield n0 : I
    //   288: aload_0
    //   289: aload_0
    //   290: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   293: invokevirtual e : (Landroidx/constraintlayout/solver/c;)V
    //   296: iconst_0
    //   297: istore #4
    //   299: iload #4
    //   301: iload #11
    //   303: if_icmpge -> 334
    //   306: aload_0
    //   307: getfield e0 : Ljava/util/ArrayList;
    //   310: iload #4
    //   312: invokevirtual get : (I)Ljava/lang/Object;
    //   315: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   318: aload_0
    //   319: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   322: invokevirtual e : (Landroidx/constraintlayout/solver/c;)V
    //   325: iload #4
    //   327: iconst_1
    //   328: iadd
    //   329: istore #4
    //   331: goto -> 299
    //   334: aload_0
    //   335: aload_0
    //   336: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   339: invokevirtual G : (Landroidx/constraintlayout/solver/c;)Z
    //   342: pop
    //   343: aload_0
    //   344: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   347: astore #12
    //   349: aload #12
    //   351: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   354: pop
    //   355: aload #12
    //   357: getfield f : Z
    //   360: ifeq -> 417
    //   363: iconst_0
    //   364: istore_3
    //   365: iload_3
    //   366: aload #12
    //   368: getfield i : I
    //   371: if_icmpge -> 1129
    //   374: aload #12
    //   376: getfield e : [Landroidx/constraintlayout/solver/b;
    //   379: iload_3
    //   380: aaload
    //   381: getfield e : Z
    //   384: ifne -> 1122
    //   387: iconst_0
    //   388: istore_3
    //   389: goto -> 392
    //   392: iload_3
    //   393: ifne -> 409
    //   396: aload #12
    //   398: aload #12
    //   400: getfield b : Landroidx/constraintlayout/solver/c$a;
    //   403: invokevirtual q : (Landroidx/constraintlayout/solver/c$a;)V
    //   406: goto -> 427
    //   409: aload #12
    //   411: invokevirtual j : ()V
    //   414: goto -> 427
    //   417: aload #12
    //   419: aload #12
    //   421: getfield b : Landroidx/constraintlayout/solver/c$a;
    //   424: invokevirtual q : (Landroidx/constraintlayout/solver/c$a;)V
    //   427: iconst_1
    //   428: istore_3
    //   429: goto -> 486
    //   432: astore #12
    //   434: iconst_1
    //   435: istore_3
    //   436: goto -> 441
    //   439: astore #12
    //   441: aload #12
    //   443: invokevirtual printStackTrace : ()V
    //   446: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   449: astore #18
    //   451: new java/lang/StringBuilder
    //   454: dup
    //   455: invokespecial <init> : ()V
    //   458: astore #19
    //   460: aload #19
    //   462: ldc 'EXCEPTION : '
    //   464: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   467: pop
    //   468: aload #19
    //   470: aload #12
    //   472: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   475: pop
    //   476: aload #18
    //   478: aload #19
    //   480: invokevirtual toString : ()Ljava/lang/String;
    //   483: invokevirtual println : (Ljava/lang/String;)V
    //   486: iload_3
    //   487: ifeq -> 548
    //   490: aload_0
    //   491: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   494: astore #12
    //   496: getstatic androidx/constraintlayout/solver/widgets/f.a : [Z
    //   499: iconst_2
    //   500: iconst_0
    //   501: bastore
    //   502: aload_0
    //   503: aload #12
    //   505: invokevirtual D : (Landroidx/constraintlayout/solver/c;)V
    //   508: aload_0
    //   509: getfield e0 : Ljava/util/ArrayList;
    //   512: invokevirtual size : ()I
    //   515: istore #4
    //   517: iconst_0
    //   518: istore_3
    //   519: iload_3
    //   520: iload #4
    //   522: if_icmpge -> 589
    //   525: aload_0
    //   526: getfield e0 : Ljava/util/ArrayList;
    //   529: iload_3
    //   530: invokevirtual get : (I)Ljava/lang/Object;
    //   533: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   536: aload #12
    //   538: invokevirtual D : (Landroidx/constraintlayout/solver/c;)V
    //   541: iload_3
    //   542: iconst_1
    //   543: iadd
    //   544: istore_3
    //   545: goto -> 519
    //   548: aload_0
    //   549: aload_0
    //   550: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   553: invokevirtual D : (Landroidx/constraintlayout/solver/c;)V
    //   556: iconst_0
    //   557: istore_3
    //   558: iload_3
    //   559: iload #11
    //   561: if_icmpge -> 589
    //   564: aload_0
    //   565: getfield e0 : Ljava/util/ArrayList;
    //   568: iload_3
    //   569: invokevirtual get : (I)Ljava/lang/Object;
    //   572: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   575: aload_0
    //   576: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   579: invokevirtual D : (Landroidx/constraintlayout/solver/c;)V
    //   582: iload_3
    //   583: iconst_1
    //   584: iadd
    //   585: istore_3
    //   586: goto -> 558
    //   589: iload_2
    //   590: ifeq -> 812
    //   593: iload #8
    //   595: bipush #8
    //   597: if_icmpge -> 812
    //   600: getstatic androidx/constraintlayout/solver/widgets/f.a : [Z
    //   603: iconst_2
    //   604: baload
    //   605: ifeq -> 812
    //   608: iconst_0
    //   609: istore #4
    //   611: iconst_0
    //   612: istore #5
    //   614: iconst_0
    //   615: istore_3
    //   616: iload #4
    //   618: iload #11
    //   620: if_icmpge -> 688
    //   623: aload_0
    //   624: getfield e0 : Ljava/util/ArrayList;
    //   627: iload #4
    //   629: invokevirtual get : (I)Ljava/lang/Object;
    //   632: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   635: astore #12
    //   637: aload #12
    //   639: getfield P : I
    //   642: istore #6
    //   644: iload #5
    //   646: aload #12
    //   648: invokevirtual o : ()I
    //   651: iload #6
    //   653: iadd
    //   654: invokestatic max : (II)I
    //   657: istore #5
    //   659: aload #12
    //   661: getfield Q : I
    //   664: istore #6
    //   666: iload_3
    //   667: aload #12
    //   669: invokevirtual i : ()I
    //   672: iload #6
    //   674: iadd
    //   675: invokestatic max : (II)I
    //   678: istore_3
    //   679: iload #4
    //   681: iconst_1
    //   682: iadd
    //   683: istore #4
    //   685: goto -> 616
    //   688: iload_2
    //   689: istore #6
    //   691: aload_0
    //   692: getfield S : I
    //   695: iload #5
    //   697: invokestatic max : (II)I
    //   700: istore_2
    //   701: aload_0
    //   702: getfield T : I
    //   705: iload_3
    //   706: invokestatic max : (II)I
    //   709: istore #7
    //   711: aload #16
    //   713: aload #13
    //   715: if_acmpne -> 748
    //   718: aload_0
    //   719: invokevirtual o : ()I
    //   722: iload_2
    //   723: if_icmpge -> 748
    //   726: aload_0
    //   727: iload_2
    //   728: invokevirtual B : (I)V
    //   731: aload_0
    //   732: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   735: iconst_0
    //   736: aload #13
    //   738: aastore
    //   739: iconst_1
    //   740: istore #4
    //   742: iconst_1
    //   743: istore #5
    //   745: goto -> 754
    //   748: iconst_0
    //   749: istore #4
    //   751: iload_1
    //   752: istore #5
    //   754: iload #4
    //   756: istore_2
    //   757: iload #5
    //   759: istore_1
    //   760: iload #6
    //   762: istore_3
    //   763: aload #15
    //   765: aload #13
    //   767: if_acmpne -> 820
    //   770: iload #4
    //   772: istore_2
    //   773: iload #5
    //   775: istore_1
    //   776: iload #6
    //   778: istore_3
    //   779: aload_0
    //   780: invokevirtual i : ()I
    //   783: iload #7
    //   785: if_icmpge -> 820
    //   788: aload_0
    //   789: iload #7
    //   791: invokevirtual w : (I)V
    //   794: aload_0
    //   795: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   798: iconst_1
    //   799: aload #13
    //   801: aastore
    //   802: iconst_1
    //   803: istore_2
    //   804: iconst_1
    //   805: istore_1
    //   806: iload #6
    //   808: istore_3
    //   809: goto -> 820
    //   812: iconst_0
    //   813: istore #4
    //   815: iload_2
    //   816: istore_3
    //   817: iload #4
    //   819: istore_2
    //   820: aload_0
    //   821: getfield S : I
    //   824: aload_0
    //   825: invokevirtual o : ()I
    //   828: invokestatic max : (II)I
    //   831: istore #5
    //   833: iload_2
    //   834: istore #4
    //   836: iload #5
    //   838: aload_0
    //   839: invokevirtual o : ()I
    //   842: if_icmple -> 864
    //   845: aload_0
    //   846: iload #5
    //   848: invokevirtual B : (I)V
    //   851: aload_0
    //   852: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   855: iconst_0
    //   856: aload #14
    //   858: aastore
    //   859: iconst_1
    //   860: istore #4
    //   862: iconst_1
    //   863: istore_1
    //   864: aload_0
    //   865: getfield T : I
    //   868: aload_0
    //   869: invokevirtual i : ()I
    //   872: invokestatic max : (II)I
    //   875: istore_2
    //   876: iload_2
    //   877: aload_0
    //   878: invokevirtual i : ()I
    //   881: if_icmple -> 904
    //   884: aload_0
    //   885: iload_2
    //   886: invokevirtual w : (I)V
    //   889: aload_0
    //   890: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   893: iconst_1
    //   894: aload #14
    //   896: aastore
    //   897: iconst_1
    //   898: istore_1
    //   899: iconst_1
    //   900: istore_2
    //   901: goto -> 909
    //   904: iload_1
    //   905: istore_2
    //   906: iload #4
    //   908: istore_1
    //   909: iload_1
    //   910: istore #7
    //   912: iload_2
    //   913: istore #5
    //   915: iload_2
    //   916: ifne -> 1063
    //   919: iload_1
    //   920: istore #6
    //   922: iload_2
    //   923: istore #4
    //   925: aload_0
    //   926: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   929: iconst_0
    //   930: aaload
    //   931: aload #13
    //   933: if_acmpne -> 987
    //   936: iload_1
    //   937: istore #6
    //   939: iload_2
    //   940: istore #4
    //   942: iload #9
    //   944: ifle -> 987
    //   947: iload_1
    //   948: istore #6
    //   950: iload_2
    //   951: istore #4
    //   953: aload_0
    //   954: invokevirtual o : ()I
    //   957: iload #9
    //   959: if_icmple -> 987
    //   962: aload_0
    //   963: iconst_1
    //   964: putfield r0 : Z
    //   967: aload_0
    //   968: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   971: iconst_0
    //   972: aload #14
    //   974: aastore
    //   975: aload_0
    //   976: iload #9
    //   978: invokevirtual B : (I)V
    //   981: iconst_1
    //   982: istore #6
    //   984: iconst_1
    //   985: istore #4
    //   987: iload #6
    //   989: istore #7
    //   991: iload #4
    //   993: istore #5
    //   995: aload_0
    //   996: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   999: iconst_1
    //   1000: aaload
    //   1001: aload #13
    //   1003: if_acmpne -> 1063
    //   1006: iload #6
    //   1008: istore #7
    //   1010: iload #4
    //   1012: istore #5
    //   1014: iload #10
    //   1016: ifle -> 1063
    //   1019: iload #6
    //   1021: istore #7
    //   1023: iload #4
    //   1025: istore #5
    //   1027: aload_0
    //   1028: invokevirtual i : ()I
    //   1031: iload #10
    //   1033: if_icmple -> 1063
    //   1036: aload_0
    //   1037: iconst_1
    //   1038: putfield s0 : Z
    //   1041: aload_0
    //   1042: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1045: iconst_1
    //   1046: aload #14
    //   1048: aastore
    //   1049: aload_0
    //   1050: iload #10
    //   1052: invokevirtual w : (I)V
    //   1055: iconst_1
    //   1056: istore #4
    //   1058: iconst_1
    //   1059: istore_1
    //   1060: goto -> 1070
    //   1063: iload #7
    //   1065: istore #4
    //   1067: iload #5
    //   1069: istore_1
    //   1070: iload #8
    //   1072: istore #5
    //   1074: iload_3
    //   1075: istore_2
    //   1076: iload #4
    //   1078: istore_3
    //   1079: goto -> 261
    //   1082: aload_0
    //   1083: aload #17
    //   1085: putfield e0 : Ljava/util/ArrayList;
    //   1088: iload_1
    //   1089: ifeq -> 1110
    //   1092: aload_0
    //   1093: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1096: astore #12
    //   1098: aload #12
    //   1100: iconst_0
    //   1101: aload #16
    //   1103: aastore
    //   1104: aload #12
    //   1106: iconst_1
    //   1107: aload #15
    //   1109: aastore
    //   1110: aload_0
    //   1111: aload_0
    //   1112: getfield j0 : Landroidx/constraintlayout/solver/c;
    //   1115: getfield k : Lh5/mt;
    //   1118: invokevirtual v : (Lh5/mt;)V
    //   1121: return
    //   1122: iload_3
    //   1123: iconst_1
    //   1124: iadd
    //   1125: istore_3
    //   1126: goto -> 365
    //   1129: iconst_1
    //   1130: istore_3
    //   1131: goto -> 392
    // Exception table:
    //   from	to	target	type
    //   271	296	439	java/lang/Exception
    //   306	325	439	java/lang/Exception
    //   334	343	439	java/lang/Exception
    //   343	363	432	java/lang/Exception
    //   365	387	432	java/lang/Exception
    //   396	406	432	java/lang/Exception
    //   409	414	432	java/lang/Exception
    //   417	427	432	java/lang/Exception
  }
  
  public void F(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramInt == 0) {
      paramInt = this.m0;
      c[] arrayOfC = this.p0;
      if (paramInt + 1 >= arrayOfC.length)
        this.p0 = Arrays.<c>copyOf(arrayOfC, arrayOfC.length * 2); 
      arrayOfC = this.p0;
      paramInt = this.m0;
      arrayOfC[paramInt] = new c(paramConstraintWidget, 0, this.i0);
      this.m0 = paramInt + 1;
      return;
    } 
    if (paramInt == 1) {
      paramInt = this.n0;
      c[] arrayOfC = this.o0;
      if (paramInt + 1 >= arrayOfC.length)
        this.o0 = Arrays.<c>copyOf(arrayOfC, arrayOfC.length * 2); 
      arrayOfC = this.o0;
      paramInt = this.n0;
      arrayOfC[paramInt] = new c(paramConstraintWidget, 1, this.i0);
      this.n0 = paramInt + 1;
    } 
  }
  
  public boolean G(c paramc) {
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.f;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.g;
    b(paramc);
    int k = this.e0.size();
    int i = 0;
    int j = 0;
    while (i < k) {
      ConstraintWidget constraintWidget = this.e0.get(i);
      boolean[] arrayOfBoolean = constraintWidget.I;
      arrayOfBoolean[0] = false;
      arrayOfBoolean[1] = false;
      if (constraintWidget instanceof a)
        j = 1; 
      i++;
    } 
    if (j)
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = this.e0.get(i);
        if (constraintWidget instanceof a) {
          a a = (a)constraintWidget;
          for (j = 0; j < a.f0; j++) {
            ConstraintWidget constraintWidget1 = a.e0[j];
            int m = a.g0;
            if (m == 0 || m == 1) {
              constraintWidget1.I[0] = true;
            } else if (m == 2 || m == 3) {
              constraintWidget1.I[1] = true;
            } 
          } 
        } 
      }  
    for (i = 0; i < k; i++) {
      ConstraintWidget constraintWidget = this.e0.get(i);
      Objects.requireNonNull(constraintWidget);
      if (constraintWidget instanceof g || constraintWidget instanceof e) {
        j = 1;
      } else {
        j = 0;
      } 
      if (j != 0)
        constraintWidget.b(paramc); 
    } 
    for (i = 0; i < k; i++) {
      ConstraintWidget constraintWidget = this.e0.get(i);
      if (constraintWidget instanceof d) {
        ConstraintWidget.DimensionBehaviour[] arrayOfDimensionBehaviour = constraintWidget.J;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = arrayOfDimensionBehaviour[0];
        ConstraintWidget.DimensionBehaviour dimensionBehaviour4 = arrayOfDimensionBehaviour[1];
        if (dimensionBehaviour3 == dimensionBehaviour2)
          arrayOfDimensionBehaviour[0] = dimensionBehaviour1; 
        if (dimensionBehaviour4 == dimensionBehaviour2)
          arrayOfDimensionBehaviour[1] = dimensionBehaviour1; 
        constraintWidget.b(paramc);
        if (dimensionBehaviour3 == dimensionBehaviour2)
          constraintWidget.x(dimensionBehaviour3); 
        if (dimensionBehaviour4 == dimensionBehaviour2)
          constraintWidget.A(dimensionBehaviour4); 
      } else {
        ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.i;
        constraintWidget.h = -1;
        constraintWidget.i = -1;
        if (((ConstraintWidget)this).J[0] != dimensionBehaviour2 && constraintWidget.J[0] == dimensionBehaviour) {
          j = constraintWidget.y.e;
          int m = o() - constraintWidget.A.e;
          ConstraintAnchor constraintAnchor = constraintWidget.y;
          constraintAnchor.g = paramc.l(constraintAnchor);
          constraintAnchor = constraintWidget.A;
          constraintAnchor.g = paramc.l(constraintAnchor);
          paramc.e(constraintWidget.y.g, j);
          paramc.e(constraintWidget.A.g, m);
          constraintWidget.h = 2;
          constraintWidget.P = j;
          j = m - j;
          constraintWidget.L = j;
          m = constraintWidget.S;
          if (j < m)
            constraintWidget.L = m; 
        } 
        if (((ConstraintWidget)this).J[1] != dimensionBehaviour2 && constraintWidget.J[1] == dimensionBehaviour) {
          j = constraintWidget.z.e;
          int m = i() - constraintWidget.B.e;
          ConstraintAnchor constraintAnchor = constraintWidget.z;
          constraintAnchor.g = paramc.l(constraintAnchor);
          constraintAnchor = constraintWidget.B;
          constraintAnchor.g = paramc.l(constraintAnchor);
          paramc.e(constraintWidget.z.g, j);
          paramc.e(constraintWidget.B.g, m);
          if (constraintWidget.R > 0 || constraintWidget.X == 8) {
            constraintAnchor = constraintWidget.C;
            constraintAnchor.g = paramc.l(constraintAnchor);
            paramc.e(constraintWidget.C.g, constraintWidget.R + j);
          } 
          constraintWidget.i = 2;
          constraintWidget.Q = j;
          j = m - j;
          constraintWidget.M = j;
          m = constraintWidget.T;
          if (j < m)
            constraintWidget.M = m; 
        } 
        if (constraintWidget instanceof g || constraintWidget instanceof e) {
          j = 1;
        } else {
          j = 0;
        } 
        if (j == 0)
          constraintWidget.b(paramc); 
      } 
    } 
    if (this.m0 > 0)
      b.a(this, paramc, 0); 
    if (this.n0 > 0)
      b.a(this, paramc, 1); 
    return true;
  }
  
  public boolean H(boolean paramBoolean, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g0 : Lw/f;
    //   4: astore #8
    //   6: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.i : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   9: astore #11
    //   11: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.g : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   14: astore #13
    //   16: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.f : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   19: astore #12
    //   21: iconst_1
    //   22: istore #7
    //   24: iload_1
    //   25: iconst_1
    //   26: iand
    //   27: istore #4
    //   29: aload #8
    //   31: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   34: iconst_0
    //   35: invokevirtual h : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   38: astore #9
    //   40: aload #8
    //   42: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   45: iconst_1
    //   46: invokevirtual h : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   49: astore #10
    //   51: aload #8
    //   53: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   56: invokevirtual p : ()I
    //   59: istore #5
    //   61: aload #8
    //   63: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   66: invokevirtual q : ()I
    //   69: istore #6
    //   71: iload #4
    //   73: ifeq -> 277
    //   76: aload #9
    //   78: aload #13
    //   80: if_acmpeq -> 90
    //   83: aload #10
    //   85: aload #13
    //   87: if_acmpne -> 277
    //   90: aload #8
    //   92: getfield e : Ljava/util/ArrayList;
    //   95: invokevirtual iterator : ()Ljava/util/Iterator;
    //   98: astore #14
    //   100: iload #4
    //   102: istore_3
    //   103: aload #14
    //   105: invokeinterface hasNext : ()Z
    //   110: ifeq -> 144
    //   113: aload #14
    //   115: invokeinterface next : ()Ljava/lang/Object;
    //   120: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   123: astore #15
    //   125: aload #15
    //   127: getfield f : I
    //   130: iload_2
    //   131: if_icmpne -> 100
    //   134: aload #15
    //   136: invokevirtual k : ()Z
    //   139: ifne -> 100
    //   142: iconst_0
    //   143: istore_3
    //   144: iload_2
    //   145: ifne -> 214
    //   148: iload_3
    //   149: ifeq -> 277
    //   152: aload #9
    //   154: aload #13
    //   156: if_acmpne -> 277
    //   159: aload #8
    //   161: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   164: astore #13
    //   166: aload #13
    //   168: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   171: iconst_0
    //   172: aload #12
    //   174: aastore
    //   175: aload #13
    //   177: aload #8
    //   179: aload #13
    //   181: iconst_0
    //   182: invokevirtual d : (Landroidx/constraintlayout/solver/widgets/d;I)I
    //   185: invokevirtual B : (I)V
    //   188: aload #8
    //   190: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   193: astore #13
    //   195: aload #13
    //   197: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   200: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   203: aload #13
    //   205: invokevirtual o : ()I
    //   208: invokevirtual c : (I)V
    //   211: goto -> 277
    //   214: iload_3
    //   215: ifeq -> 277
    //   218: aload #10
    //   220: aload #13
    //   222: if_acmpne -> 277
    //   225: aload #8
    //   227: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   230: astore #13
    //   232: aload #13
    //   234: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   237: iconst_1
    //   238: aload #12
    //   240: aastore
    //   241: aload #13
    //   243: aload #8
    //   245: aload #13
    //   247: iconst_1
    //   248: invokevirtual d : (Landroidx/constraintlayout/solver/widgets/d;I)I
    //   251: invokevirtual w : (I)V
    //   254: aload #8
    //   256: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   259: astore #13
    //   261: aload #13
    //   263: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   266: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   269: aload #13
    //   271: invokevirtual i : ()I
    //   274: invokevirtual c : (I)V
    //   277: iload_2
    //   278: ifne -> 358
    //   281: aload #8
    //   283: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   286: astore #13
    //   288: aload #13
    //   290: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   293: astore #14
    //   295: aload #14
    //   297: iconst_0
    //   298: aaload
    //   299: aload #12
    //   301: if_acmpeq -> 313
    //   304: aload #14
    //   306: iconst_0
    //   307: aaload
    //   308: aload #11
    //   310: if_acmpne -> 393
    //   313: aload #13
    //   315: invokevirtual o : ()I
    //   318: iload #5
    //   320: iadd
    //   321: istore_3
    //   322: aload #8
    //   324: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   327: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   330: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   333: iload_3
    //   334: invokevirtual c : (I)V
    //   337: aload #8
    //   339: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   342: getfield d : Landroidx/constraintlayout/solver/widgets/analyzer/c;
    //   345: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   348: iload_3
    //   349: iload #5
    //   351: isub
    //   352: invokevirtual c : (I)V
    //   355: goto -> 440
    //   358: aload #8
    //   360: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   363: astore #13
    //   365: aload #13
    //   367: getfield J : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   370: astore #14
    //   372: aload #14
    //   374: iconst_1
    //   375: aaload
    //   376: aload #12
    //   378: if_acmpeq -> 398
    //   381: aload #14
    //   383: iconst_1
    //   384: aaload
    //   385: aload #11
    //   387: if_acmpne -> 393
    //   390: goto -> 398
    //   393: iconst_0
    //   394: istore_3
    //   395: goto -> 442
    //   398: aload #13
    //   400: invokevirtual i : ()I
    //   403: iload #6
    //   405: iadd
    //   406: istore_3
    //   407: aload #8
    //   409: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   412: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   415: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   418: iload_3
    //   419: invokevirtual c : (I)V
    //   422: aload #8
    //   424: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   427: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/d;
    //   430: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   433: iload_3
    //   434: iload #6
    //   436: isub
    //   437: invokevirtual c : (I)V
    //   440: iconst_1
    //   441: istore_3
    //   442: aload #8
    //   444: invokevirtual g : ()V
    //   447: aload #8
    //   449: getfield e : Ljava/util/ArrayList;
    //   452: invokevirtual iterator : ()Ljava/util/Iterator;
    //   455: astore #11
    //   457: aload #11
    //   459: invokeinterface hasNext : ()Z
    //   464: ifeq -> 523
    //   467: aload #11
    //   469: invokeinterface next : ()Ljava/lang/Object;
    //   474: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   477: astore #12
    //   479: aload #12
    //   481: getfield f : I
    //   484: iload_2
    //   485: if_icmpeq -> 491
    //   488: goto -> 457
    //   491: aload #12
    //   493: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   496: aload #8
    //   498: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   501: if_acmpne -> 515
    //   504: aload #12
    //   506: getfield g : Z
    //   509: ifne -> 515
    //   512: goto -> 457
    //   515: aload #12
    //   517: invokevirtual e : ()V
    //   520: goto -> 457
    //   523: aload #8
    //   525: getfield e : Ljava/util/ArrayList;
    //   528: invokevirtual iterator : ()Ljava/util/Iterator;
    //   531: astore #11
    //   533: iload #7
    //   535: istore_1
    //   536: aload #11
    //   538: invokeinterface hasNext : ()Z
    //   543: ifeq -> 639
    //   546: aload #11
    //   548: invokeinterface next : ()Ljava/lang/Object;
    //   553: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   556: astore #12
    //   558: aload #12
    //   560: getfield f : I
    //   563: iload_2
    //   564: if_icmpeq -> 570
    //   567: goto -> 533
    //   570: iload_3
    //   571: ifne -> 590
    //   574: aload #12
    //   576: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   579: aload #8
    //   581: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   584: if_acmpne -> 590
    //   587: goto -> 533
    //   590: aload #12
    //   592: getfield h : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   595: getfield j : Z
    //   598: ifne -> 604
    //   601: goto -> 637
    //   604: aload #12
    //   606: getfield i : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   609: getfield j : Z
    //   612: ifne -> 618
    //   615: goto -> 637
    //   618: aload #12
    //   620: instanceof w/c
    //   623: ifne -> 533
    //   626: aload #12
    //   628: getfield e : Landroidx/constraintlayout/solver/widgets/analyzer/a;
    //   631: getfield j : Z
    //   634: ifne -> 533
    //   637: iconst_0
    //   638: istore_1
    //   639: aload #8
    //   641: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   644: aload #9
    //   646: invokevirtual x : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   649: aload #8
    //   651: getfield a : Landroidx/constraintlayout/solver/widgets/d;
    //   654: aload #10
    //   656: invokevirtual A : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   659: iload_1
    //   660: ireturn
  }
  
  public void I() {
    this.g0.b = true;
  }
  
  public void J(int paramInt) {
    this.q0 = paramInt;
    c.p = f.a(paramInt, 256);
  }
  
  public void u() {
    this.j0.t();
    this.k0 = 0;
    this.l0 = 0;
    super.u();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */