package androidx.constraintlayout.solver.widgets;

import java.util.ArrayList;

public class c {
  public ConstraintWidget a;
  
  public ConstraintWidget b;
  
  public ConstraintWidget c;
  
  public ConstraintWidget d;
  
  public ConstraintWidget e;
  
  public ConstraintWidget f;
  
  public ConstraintWidget g;
  
  public ArrayList<ConstraintWidget> h;
  
  public int i;
  
  public int j;
  
  public float k = 0.0F;
  
  public int l;
  
  public int m;
  
  public int n;
  
  public int o;
  
  public boolean p = false;
  
  public boolean q;
  
  public boolean r;
  
  public boolean s;
  
  public boolean t;
  
  public c(ConstraintWidget paramConstraintWidget, int paramInt, boolean paramBoolean) {
    this.a = paramConstraintWidget;
    this.o = paramInt;
    this.p = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */