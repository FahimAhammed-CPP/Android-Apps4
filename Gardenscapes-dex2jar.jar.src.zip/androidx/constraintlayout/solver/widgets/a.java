package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.c;
import j.f;
import v.c;

public class a extends c {
  public int g0 = 0;
  
  public boolean h0 = true;
  
  public int i0 = 0;
  
  public void b(c paramc) {
    // Byte code:
    //   0: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.h : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   3: astore #7
    //   5: aload_0
    //   6: getfield G : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   9: astore #6
    //   11: aload #6
    //   13: iconst_0
    //   14: aload_0
    //   15: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   18: aastore
    //   19: aload #6
    //   21: iconst_2
    //   22: aload_0
    //   23: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   26: aastore
    //   27: aload #6
    //   29: iconst_1
    //   30: aload_0
    //   31: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   34: aastore
    //   35: aload #6
    //   37: iconst_3
    //   38: aload_0
    //   39: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   42: aastore
    //   43: iconst_0
    //   44: istore_2
    //   45: aload_0
    //   46: getfield G : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   49: astore #6
    //   51: iload_2
    //   52: aload #6
    //   54: arraylength
    //   55: if_icmpge -> 80
    //   58: aload #6
    //   60: iload_2
    //   61: aaload
    //   62: aload_1
    //   63: aload #6
    //   65: iload_2
    //   66: aaload
    //   67: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   70: putfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   73: iload_2
    //   74: iconst_1
    //   75: iadd
    //   76: istore_2
    //   77: goto -> 45
    //   80: aload_0
    //   81: getfield g0 : I
    //   84: istore_2
    //   85: iload_2
    //   86: iflt -> 947
    //   89: iload_2
    //   90: iconst_4
    //   91: if_icmpge -> 947
    //   94: aload #6
    //   96: iload_2
    //   97: aaload
    //   98: astore #6
    //   100: iconst_0
    //   101: istore_2
    //   102: iload_2
    //   103: aload_0
    //   104: getfield f0 : I
    //   107: if_icmpge -> 244
    //   110: aload_0
    //   111: getfield e0 : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   114: iload_2
    //   115: aaload
    //   116: astore #8
    //   118: aload_0
    //   119: getfield h0 : Z
    //   122: ifne -> 136
    //   125: aload #8
    //   127: invokevirtual c : ()Z
    //   130: ifne -> 136
    //   133: goto -> 237
    //   136: aload_0
    //   137: getfield g0 : I
    //   140: istore_3
    //   141: iload_3
    //   142: ifeq -> 150
    //   145: iload_3
    //   146: iconst_1
    //   147: if_icmpne -> 185
    //   150: aload #8
    //   152: invokevirtual j : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   155: aload #7
    //   157: if_acmpne -> 185
    //   160: aload #8
    //   162: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   165: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   168: ifnull -> 185
    //   171: aload #8
    //   173: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   176: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   179: ifnull -> 185
    //   182: goto -> 232
    //   185: aload_0
    //   186: getfield g0 : I
    //   189: istore_3
    //   190: iload_3
    //   191: iconst_2
    //   192: if_icmpeq -> 200
    //   195: iload_3
    //   196: iconst_3
    //   197: if_icmpne -> 237
    //   200: aload #8
    //   202: invokevirtual n : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   205: aload #7
    //   207: if_acmpne -> 237
    //   210: aload #8
    //   212: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   215: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   218: ifnull -> 237
    //   221: aload #8
    //   223: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   226: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   229: ifnull -> 237
    //   232: iconst_1
    //   233: istore_2
    //   234: goto -> 246
    //   237: iload_2
    //   238: iconst_1
    //   239: iadd
    //   240: istore_2
    //   241: goto -> 102
    //   244: iconst_0
    //   245: istore_2
    //   246: aload_0
    //   247: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   250: invokevirtual c : ()Z
    //   253: ifne -> 274
    //   256: aload_0
    //   257: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   260: invokevirtual c : ()Z
    //   263: ifeq -> 269
    //   266: goto -> 274
    //   269: iconst_0
    //   270: istore_3
    //   271: goto -> 276
    //   274: iconst_1
    //   275: istore_3
    //   276: aload_0
    //   277: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   280: invokevirtual c : ()Z
    //   283: ifne -> 305
    //   286: aload_0
    //   287: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   290: invokevirtual c : ()Z
    //   293: ifeq -> 299
    //   296: goto -> 305
    //   299: iconst_0
    //   300: istore #4
    //   302: goto -> 308
    //   305: iconst_1
    //   306: istore #4
    //   308: iload_2
    //   309: ifne -> 359
    //   312: aload_0
    //   313: getfield g0 : I
    //   316: istore_2
    //   317: iload_2
    //   318: ifne -> 325
    //   321: iload_3
    //   322: ifne -> 354
    //   325: iload_2
    //   326: iconst_2
    //   327: if_icmpne -> 335
    //   330: iload #4
    //   332: ifne -> 354
    //   335: iload_2
    //   336: iconst_1
    //   337: if_icmpne -> 344
    //   340: iload_3
    //   341: ifne -> 354
    //   344: iload_2
    //   345: iconst_3
    //   346: if_icmpne -> 359
    //   349: iload #4
    //   351: ifeq -> 359
    //   354: iconst_1
    //   355: istore_3
    //   356: goto -> 361
    //   359: iconst_0
    //   360: istore_3
    //   361: iconst_5
    //   362: istore_2
    //   363: iload_3
    //   364: ifne -> 369
    //   367: iconst_4
    //   368: istore_2
    //   369: iconst_0
    //   370: istore_3
    //   371: iload_3
    //   372: aload_0
    //   373: getfield f0 : I
    //   376: if_icmpge -> 640
    //   379: aload_0
    //   380: getfield e0 : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   383: iload_3
    //   384: aaload
    //   385: astore #8
    //   387: aload_0
    //   388: getfield h0 : Z
    //   391: ifne -> 405
    //   394: aload #8
    //   396: invokevirtual c : ()Z
    //   399: ifne -> 405
    //   402: goto -> 633
    //   405: aload_1
    //   406: aload #8
    //   408: getfield G : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   411: aload_0
    //   412: getfield g0 : I
    //   415: aaload
    //   416: invokevirtual l : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   419: astore #7
    //   421: aload #8
    //   423: getfield G : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   426: astore #8
    //   428: aload_0
    //   429: getfield g0 : I
    //   432: istore #5
    //   434: aload #8
    //   436: iload #5
    //   438: aaload
    //   439: aload #7
    //   441: putfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   444: aload #8
    //   446: iload #5
    //   448: aaload
    //   449: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   452: ifnull -> 485
    //   455: aload #8
    //   457: iload #5
    //   459: aaload
    //   460: getfield d : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   463: getfield b : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   466: aload_0
    //   467: if_acmpne -> 485
    //   470: aload #8
    //   472: iload #5
    //   474: aaload
    //   475: getfield e : I
    //   478: iconst_0
    //   479: iadd
    //   480: istore #4
    //   482: goto -> 488
    //   485: iconst_0
    //   486: istore #4
    //   488: iload #5
    //   490: ifeq -> 559
    //   493: iload #5
    //   495: iconst_2
    //   496: if_icmpne -> 502
    //   499: goto -> 559
    //   502: aload #6
    //   504: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   507: astore #8
    //   509: aload_0
    //   510: getfield i0 : I
    //   513: istore #5
    //   515: aload_1
    //   516: invokevirtual m : ()Landroidx/constraintlayout/solver/b;
    //   519: astore #9
    //   521: aload_1
    //   522: invokevirtual n : ()Landroidx/constraintlayout/solver/SolverVariable;
    //   525: astore #10
    //   527: aload #10
    //   529: iconst_0
    //   530: putfield d : I
    //   533: aload #9
    //   535: aload #8
    //   537: aload #7
    //   539: aload #10
    //   541: iload #5
    //   543: iload #4
    //   545: iadd
    //   546: invokevirtual e : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;I)Landroidx/constraintlayout/solver/b;
    //   549: pop
    //   550: aload_1
    //   551: aload #9
    //   553: invokevirtual c : (Landroidx/constraintlayout/solver/b;)V
    //   556: goto -> 613
    //   559: aload #6
    //   561: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   564: astore #8
    //   566: aload_0
    //   567: getfield i0 : I
    //   570: istore #5
    //   572: aload_1
    //   573: invokevirtual m : ()Landroidx/constraintlayout/solver/b;
    //   576: astore #9
    //   578: aload_1
    //   579: invokevirtual n : ()Landroidx/constraintlayout/solver/SolverVariable;
    //   582: astore #10
    //   584: aload #10
    //   586: iconst_0
    //   587: putfield d : I
    //   590: aload #9
    //   592: aload #8
    //   594: aload #7
    //   596: aload #10
    //   598: iload #5
    //   600: iload #4
    //   602: isub
    //   603: invokevirtual f : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;I)Landroidx/constraintlayout/solver/b;
    //   606: pop
    //   607: aload_1
    //   608: aload #9
    //   610: invokevirtual c : (Landroidx/constraintlayout/solver/b;)V
    //   613: aload_1
    //   614: aload #6
    //   616: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   619: aload #7
    //   621: aload_0
    //   622: getfield i0 : I
    //   625: iload #4
    //   627: iadd
    //   628: iload_2
    //   629: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   632: pop
    //   633: iload_3
    //   634: iconst_1
    //   635: iadd
    //   636: istore_3
    //   637: goto -> 371
    //   640: aload_0
    //   641: getfield g0 : I
    //   644: istore_2
    //   645: iload_2
    //   646: ifne -> 720
    //   649: aload_1
    //   650: aload_0
    //   651: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   654: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   657: aload_0
    //   658: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   661: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   664: iconst_0
    //   665: bipush #8
    //   667: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   670: pop
    //   671: aload_1
    //   672: aload_0
    //   673: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   676: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   679: aload_0
    //   680: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   683: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   686: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   689: iconst_0
    //   690: iconst_4
    //   691: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   694: pop
    //   695: aload_1
    //   696: aload_0
    //   697: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   700: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   703: aload_0
    //   704: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   707: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   710: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   713: iconst_0
    //   714: iconst_0
    //   715: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   718: pop
    //   719: return
    //   720: iload_2
    //   721: iconst_1
    //   722: if_icmpne -> 796
    //   725: aload_1
    //   726: aload_0
    //   727: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   730: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   733: aload_0
    //   734: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   737: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   740: iconst_0
    //   741: bipush #8
    //   743: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   746: pop
    //   747: aload_1
    //   748: aload_0
    //   749: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   752: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   755: aload_0
    //   756: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   759: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   762: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   765: iconst_0
    //   766: iconst_4
    //   767: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   770: pop
    //   771: aload_1
    //   772: aload_0
    //   773: getfield y : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   776: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   779: aload_0
    //   780: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   783: getfield A : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   786: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   789: iconst_0
    //   790: iconst_0
    //   791: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   794: pop
    //   795: return
    //   796: iload_2
    //   797: iconst_2
    //   798: if_icmpne -> 872
    //   801: aload_1
    //   802: aload_0
    //   803: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   806: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   809: aload_0
    //   810: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   813: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   816: iconst_0
    //   817: bipush #8
    //   819: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   822: pop
    //   823: aload_1
    //   824: aload_0
    //   825: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   828: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   831: aload_0
    //   832: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   835: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   838: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   841: iconst_0
    //   842: iconst_4
    //   843: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   846: pop
    //   847: aload_1
    //   848: aload_0
    //   849: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   852: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   855: aload_0
    //   856: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   859: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   862: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   865: iconst_0
    //   866: iconst_0
    //   867: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   870: pop
    //   871: return
    //   872: iload_2
    //   873: iconst_3
    //   874: if_icmpne -> 947
    //   877: aload_1
    //   878: aload_0
    //   879: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   882: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   885: aload_0
    //   886: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   889: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   892: iconst_0
    //   893: bipush #8
    //   895: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   898: pop
    //   899: aload_1
    //   900: aload_0
    //   901: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   904: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   907: aload_0
    //   908: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   911: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   914: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   917: iconst_0
    //   918: iconst_4
    //   919: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   922: pop
    //   923: aload_1
    //   924: aload_0
    //   925: getfield z : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   928: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   931: aload_0
    //   932: getfield K : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   935: getfield B : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   938: getfield g : Landroidx/constraintlayout/solver/SolverVariable;
    //   941: iconst_0
    //   942: iconst_0
    //   943: invokevirtual d : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/b;
    //   946: pop
    //   947: return
  }
  
  public boolean c() {
    return true;
  }
  
  public String toString() {
    String str = v.a.a(android.support.v4.media.a.a("[Barrier] "), ((ConstraintWidget)this).Y, " {");
    for (int i = 0; i < this.f0; i++) {
      ConstraintWidget constraintWidget = this.e0[i];
      String str1 = str;
      if (i > 0)
        str1 = f.a(str, ", "); 
      StringBuilder stringBuilder = android.support.v4.media.a.a(str1);
      stringBuilder.append(constraintWidget.Y);
      str = stringBuilder.toString();
    } 
    return f.a(str, "}");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */