package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.SolverVariable;
import androidx.constraintlayout.solver.b;
import androidx.constraintlayout.solver.c;

public class e extends ConstraintWidget {
  public float e0 = -1.0F;
  
  public int f0 = -1;
  
  public int g0 = -1;
  
  public ConstraintAnchor h0 = this.z;
  
  public int i0;
  
  public e() {
    int i = 0;
    this.i0 = 0;
    this.H.clear();
    this.H.add(this.h0);
    int j = this.G.length;
    while (i < j) {
      this.G[i] = this.h0;
      i++;
    } 
  }
  
  public void D(c paramc) {
    if (this.K == null)
      return; 
    int i = paramc.o(this.h0);
    if (this.i0 == 1) {
      this.P = i;
      this.Q = 0;
      w(this.K.i());
      B(0);
      return;
    } 
    this.P = 0;
    this.Q = i;
    B(this.K.o());
    w(0);
  }
  
  public void E(int paramInt) {
    if (this.i0 == paramInt)
      return; 
    this.i0 = paramInt;
    this.H.clear();
    if (this.i0 == 1) {
      this.h0 = this.y;
    } else {
      this.h0 = this.z;
    } 
    this.H.add(this.h0);
    int i = this.G.length;
    for (paramInt = 0; paramInt < i; paramInt++)
      this.G[paramInt] = this.h0; 
  }
  
  public void b(c paramc) {
    boolean bool1;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.g;
    d d = (d)this.K;
    if (d == null)
      return; 
    ConstraintAnchor constraintAnchor1 = d.f(ConstraintAnchor.Type.f);
    ConstraintAnchor constraintAnchor2 = d.f(ConstraintAnchor.Type.h);
    ConstraintWidget constraintWidget = this.K;
    boolean bool2 = true;
    if (constraintWidget != null && constraintWidget.J[0] == dimensionBehaviour) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (this.i0 == 0) {
      constraintAnchor1 = d.f(ConstraintAnchor.Type.g);
      constraintAnchor2 = d.f(ConstraintAnchor.Type.i);
      ConstraintWidget constraintWidget1 = this.K;
      if (constraintWidget1 != null && constraintWidget1.J[1] == dimensionBehaviour) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
    } 
    if (this.f0 != -1) {
      SolverVariable solverVariable = paramc.l(this.h0);
      paramc.d(solverVariable, paramc.l(constraintAnchor1), this.f0, 8);
      if (bool1) {
        paramc.f(paramc.l(constraintAnchor2), solverVariable, 0, 5);
        return;
      } 
    } else {
      SolverVariable solverVariable;
      if (this.g0 != -1) {
        SolverVariable solverVariable1 = paramc.l(this.h0);
        solverVariable = paramc.l(constraintAnchor2);
        paramc.d(solverVariable1, solverVariable, -this.g0, 8);
        if (bool1) {
          paramc.f(solverVariable1, paramc.l(constraintAnchor1), 0, 5);
          paramc.f(solverVariable, solverVariable1, 0, 5);
          return;
        } 
      } else if (this.e0 != -1.0F) {
        SolverVariable solverVariable1 = paramc.l(this.h0);
        solverVariable = paramc.l(solverVariable);
        float f = this.e0;
        b b = paramc.m();
        b.d.g(solverVariable1, -1.0F);
        b.d.g(solverVariable, f);
        paramc.c(b);
      } 
    } 
  }
  
  public boolean c() {
    return true;
  }
  
  public ConstraintAnchor f(ConstraintAnchor.Type paramType) {
    switch (paramType.ordinal()) {
      default:
        throw new AssertionError(paramType.name());
      case 0:
      case 5:
      case 6:
      case 7:
      case 8:
        return null;
      case 2:
      case 4:
        if (this.i0 == 0)
          return this.h0; 
      case 1:
      case 3:
        break;
    } 
    if (this.i0 == 1)
      return this.h0; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\widgets\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */