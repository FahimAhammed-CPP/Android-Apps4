package androidx.constraintlayout.solver;

import h5.mt;
import j.f;
import java.util.Arrays;

public class a implements b.a {
  public int a = 0;
  
  public final b b;
  
  public final mt c;
  
  public int d = 8;
  
  public int[] e = new int[8];
  
  public int[] f = new int[8];
  
  public float[] g = new float[8];
  
  public int h = -1;
  
  public int i = -1;
  
  public boolean j = false;
  
  public a(b paramb, mt parammt) {
    this.b = paramb;
    this.c = parammt;
  }
  
  public float a(int paramInt) {
    int j = this.h;
    for (int i = 0; j != -1 && i < this.a; i++) {
      if (i == paramInt)
        return this.g[j]; 
      j = this.f[j];
    } 
    return 0.0F;
  }
  
  public void b(SolverVariable paramSolverVariable, float paramFloat, boolean paramBoolean) {
    if (paramFloat > -0.001F && paramFloat < 0.001F)
      return; 
    int i = this.h;
    if (i == -1) {
      this.h = 0;
      this.g[0] = paramFloat;
      this.e[0] = paramSolverVariable.b;
      this.f[0] = -1;
      paramSolverVariable.l++;
      paramSolverVariable.a(this.b);
      this.a++;
      if (!this.j) {
        i = this.i + 1;
        this.i = i;
        arrayOfInt1 = this.e;
        if (i >= arrayOfInt1.length) {
          this.j = true;
          this.i = arrayOfInt1.length - 1;
        } 
      } 
      return;
    } 
    int j = 0;
    int k = -1;
    while (i != -1 && j < this.a) {
      int[] arrayOfInt = this.e;
      int n = arrayOfInt[i];
      int m = ((SolverVariable)arrayOfInt1).b;
      if (n == m) {
        float[] arrayOfFloat = this.g;
        float f = arrayOfFloat[i] + paramFloat;
        paramFloat = f;
        if (f > -0.001F) {
          paramFloat = f;
          if (f < 0.001F)
            paramFloat = 0.0F; 
        } 
        arrayOfFloat[i] = paramFloat;
        if (paramFloat == 0.0F) {
          if (i == this.h) {
            this.h = this.f[i];
          } else {
            arrayOfInt = this.f;
            arrayOfInt[k] = arrayOfInt[i];
          } 
          if (paramBoolean)
            arrayOfInt1.b(this.b); 
          if (this.j)
            this.i = i; 
          ((SolverVariable)arrayOfInt1).l--;
          this.a--;
        } 
        return;
      } 
      if (arrayOfInt[i] < m)
        k = i; 
      i = this.f[i];
      j++;
    } 
    i = this.i;
    if (this.j) {
      int[] arrayOfInt = this.e;
      if (arrayOfInt[i] != -1)
        i = arrayOfInt.length; 
    } else {
      i++;
    } 
    int[] arrayOfInt2 = this.e;
    j = i;
    if (i >= arrayOfInt2.length) {
      j = i;
      if (this.a < arrayOfInt2.length) {
        int m = 0;
        while (true) {
          arrayOfInt2 = this.e;
          j = i;
          if (m < arrayOfInt2.length) {
            if (arrayOfInt2[m] == -1) {
              j = m;
              break;
            } 
            m++;
            continue;
          } 
          break;
        } 
      } 
    } 
    arrayOfInt2 = this.e;
    i = j;
    if (j >= arrayOfInt2.length) {
      i = arrayOfInt2.length;
      j = this.d * 2;
      this.d = j;
      this.j = false;
      this.i = i - 1;
      this.g = Arrays.copyOf(this.g, j);
      this.e = Arrays.copyOf(this.e, this.d);
      this.f = Arrays.copyOf(this.f, this.d);
    } 
    this.e[i] = ((SolverVariable)arrayOfInt1).b;
    this.g[i] = paramFloat;
    if (k != -1) {
      arrayOfInt2 = this.f;
      arrayOfInt2[i] = arrayOfInt2[k];
      arrayOfInt2[k] = i;
    } else {
      this.f[i] = this.h;
      this.h = i;
    } 
    ((SolverVariable)arrayOfInt1).l++;
    arrayOfInt1.a(this.b);
    this.a++;
    if (!this.j)
      this.i++; 
    i = this.i;
    int[] arrayOfInt1 = this.e;
    if (i >= arrayOfInt1.length) {
      this.j = true;
      this.i = arrayOfInt1.length - 1;
    } 
  }
  
  public final float c(SolverVariable paramSolverVariable) {
    int j = this.h;
    for (int i = 0; j != -1 && i < this.a; i++) {
      if (this.e[j] == paramSolverVariable.b)
        return this.g[j]; 
      j = this.f[j];
    } 
    return 0.0F;
  }
  
  public final void clear() {
    int j = this.h;
    for (int i = 0; j != -1 && i < this.a; i++) {
      SolverVariable solverVariable = ((SolverVariable[])this.c.j)[this.e[j]];
      if (solverVariable != null)
        solverVariable.b(this.b); 
      j = this.f[j];
    } 
    this.h = -1;
    this.i = -1;
    this.j = false;
    this.a = 0;
  }
  
  public boolean d(SolverVariable paramSolverVariable) {
    int j = this.h;
    if (j == -1)
      return false; 
    for (int i = 0; j != -1 && i < this.a; i++) {
      if (this.e[j] == paramSolverVariable.b)
        return true; 
      j = this.f[j];
    } 
    return false;
  }
  
  public int e() {
    return this.a;
  }
  
  public float f(b paramb, boolean paramBoolean) {
    float f = c(paramb.a);
    h(paramb.a, paramBoolean);
    b.a a1 = paramb.d;
    int j = a1.e();
    int i;
    for (i = 0; i < j; i++) {
      SolverVariable solverVariable = a1.i(i);
      b(solverVariable, a1.c(solverVariable) * f, paramBoolean);
    } 
    return f;
  }
  
  public final void g(SolverVariable paramSolverVariable, float paramFloat) {
    if (paramFloat == 0.0F) {
      h(paramSolverVariable, true);
      return;
    } 
    int i = this.h;
    if (i == -1) {
      this.h = 0;
      this.g[0] = paramFloat;
      this.e[0] = paramSolverVariable.b;
      this.f[0] = -1;
      paramSolverVariable.l++;
      paramSolverVariable.a(this.b);
      this.a++;
      if (!this.j) {
        i = this.i + 1;
        this.i = i;
        arrayOfInt1 = this.e;
        if (i >= arrayOfInt1.length) {
          this.j = true;
          this.i = arrayOfInt1.length - 1;
        } 
      } 
      return;
    } 
    int j = 0;
    int k = -1;
    while (i != -1 && j < this.a) {
      int[] arrayOfInt = this.e;
      int n = arrayOfInt[i];
      int m = ((SolverVariable)arrayOfInt1).b;
      if (n == m) {
        this.g[i] = paramFloat;
        return;
      } 
      if (arrayOfInt[i] < m)
        k = i; 
      i = this.f[i];
      j++;
    } 
    i = this.i;
    if (this.j) {
      int[] arrayOfInt = this.e;
      if (arrayOfInt[i] != -1)
        i = arrayOfInt.length; 
    } else {
      i++;
    } 
    int[] arrayOfInt2 = this.e;
    j = i;
    if (i >= arrayOfInt2.length) {
      j = i;
      if (this.a < arrayOfInt2.length) {
        int m = 0;
        while (true) {
          arrayOfInt2 = this.e;
          j = i;
          if (m < arrayOfInt2.length) {
            if (arrayOfInt2[m] == -1) {
              j = m;
              break;
            } 
            m++;
            continue;
          } 
          break;
        } 
      } 
    } 
    arrayOfInt2 = this.e;
    i = j;
    if (j >= arrayOfInt2.length) {
      i = arrayOfInt2.length;
      j = this.d * 2;
      this.d = j;
      this.j = false;
      this.i = i - 1;
      this.g = Arrays.copyOf(this.g, j);
      this.e = Arrays.copyOf(this.e, this.d);
      this.f = Arrays.copyOf(this.f, this.d);
    } 
    this.e[i] = ((SolverVariable)arrayOfInt1).b;
    this.g[i] = paramFloat;
    if (k != -1) {
      arrayOfInt2 = this.f;
      arrayOfInt2[i] = arrayOfInt2[k];
      arrayOfInt2[k] = i;
    } else {
      this.f[i] = this.h;
      this.h = i;
    } 
    ((SolverVariable)arrayOfInt1).l++;
    arrayOfInt1.a(this.b);
    i = this.a + 1;
    this.a = i;
    if (!this.j)
      this.i++; 
    int[] arrayOfInt1 = this.e;
    if (i >= arrayOfInt1.length)
      this.j = true; 
    if (this.i >= arrayOfInt1.length) {
      this.j = true;
      this.i = arrayOfInt1.length - 1;
    } 
  }
  
  public final float h(SolverVariable paramSolverVariable, boolean paramBoolean) {
    int i = this.h;
    if (i == -1)
      return 0.0F; 
    int j = 0;
    int k = -1;
    while (i != -1 && j < this.a) {
      if (this.e[i] == paramSolverVariable.b) {
        if (i == this.h) {
          this.h = this.f[i];
        } else {
          int[] arrayOfInt = this.f;
          arrayOfInt[k] = arrayOfInt[i];
        } 
        if (paramBoolean)
          paramSolverVariable.b(this.b); 
        paramSolverVariable.l--;
        this.a--;
        this.e[i] = -1;
        if (this.j)
          this.i = i; 
        return this.g[i];
      } 
      int m = this.f[i];
      j++;
      k = i;
      i = m;
    } 
    return 0.0F;
  }
  
  public SolverVariable i(int paramInt) {
    int j = this.h;
    for (int i = 0; j != -1 && i < this.a; i++) {
      if (i == paramInt)
        return ((SolverVariable[])this.c.j)[this.e[j]]; 
      j = this.f[j];
    } 
    return null;
  }
  
  public void j(float paramFloat) {
    int j = this.h;
    for (int i = 0; j != -1 && i < this.a; i++) {
      float[] arrayOfFloat = this.g;
      arrayOfFloat[j] = arrayOfFloat[j] / paramFloat;
      j = this.f[j];
    } 
  }
  
  public void k() {
    int j = this.h;
    for (int i = 0; j != -1 && i < this.a; i++) {
      float[] arrayOfFloat = this.g;
      arrayOfFloat[j] = arrayOfFloat[j] * -1.0F;
      j = this.f[j];
    } 
  }
  
  public String toString() {
    int j = this.h;
    String str = "";
    for (int i = 0; j != -1 && i < this.a; i++) {
      StringBuilder stringBuilder = android.support.v4.media.a.a(f.a(str, " -> "));
      stringBuilder.append(this.g[j]);
      stringBuilder.append(" : ");
      stringBuilder = android.support.v4.media.a.a(stringBuilder.toString());
      stringBuilder.append(((SolverVariable[])this.c.j)[this.e[j]]);
      str = stringBuilder.toString();
      j = this.f[j];
    } 
    return str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */