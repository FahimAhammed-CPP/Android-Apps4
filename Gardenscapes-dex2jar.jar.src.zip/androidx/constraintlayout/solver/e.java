package androidx.constraintlayout.solver;

import android.support.v4.media.a;
import h5.mt;
import j.f;

public class e implements b.a {
  public int a = 16;
  
  public int[] b = new int[16];
  
  public int[] c = new int[16];
  
  public int[] d = new int[16];
  
  public float[] e = new float[16];
  
  public int[] f = new int[16];
  
  public int[] g = new int[16];
  
  public int h = 0;
  
  public int i = -1;
  
  public final b j;
  
  public final mt k;
  
  public e(b paramb, mt parammt) {
    this.j = paramb;
    this.k = parammt;
    clear();
  }
  
  public float a(int paramInt) {
    int k = this.h;
    int j = this.i;
    for (int i = 0; i < k; i++) {
      if (i == paramInt)
        return this.e[j]; 
      j = this.g[j];
      if (j == -1)
        break; 
    } 
    return 0.0F;
  }
  
  public void b(SolverVariable paramSolverVariable, float paramFloat, boolean paramBoolean) {
    if (paramFloat > -0.001F && paramFloat < 0.001F)
      return; 
    int i = n(paramSolverVariable);
    if (i == -1) {
      g(paramSolverVariable, paramFloat);
      return;
    } 
    float[] arrayOfFloat = this.e;
    arrayOfFloat[i] = arrayOfFloat[i] + paramFloat;
    if (arrayOfFloat[i] > -0.001F && arrayOfFloat[i] < 0.001F) {
      arrayOfFloat[i] = 0.0F;
      h(paramSolverVariable, paramBoolean);
    } 
  }
  
  public float c(SolverVariable paramSolverVariable) {
    int i = n(paramSolverVariable);
    return (i != -1) ? this.e[i] : 0.0F;
  }
  
  public void clear() {
    int j = this.h;
    int i;
    for (i = 0; i < j; i++) {
      SolverVariable solverVariable = i(i);
      if (solverVariable != null)
        solverVariable.b(this.j); 
    } 
    for (i = 0; i < this.a; i++) {
      this.d[i] = -1;
      this.c[i] = -1;
    } 
    for (i = 0; i < 16; i++)
      this.b[i] = -1; 
    this.h = 0;
    this.i = -1;
  }
  
  public boolean d(SolverVariable paramSolverVariable) {
    return (n(paramSolverVariable) != -1);
  }
  
  public int e() {
    return this.h;
  }
  
  public float f(b paramb, boolean paramBoolean) {
    float f = c(paramb.a);
    h(paramb.a, paramBoolean);
    e e1 = (e)paramb.d;
    int k = e1.h;
    int j = 0;
    int i = 0;
    while (j < k) {
      int[] arrayOfInt = e1.d;
      int m = j;
      if (arrayOfInt[i] != -1) {
        float f1 = e1.e[i];
        b(((SolverVariable[])this.k.j)[arrayOfInt[i]], f1 * f, paramBoolean);
        m = j + 1;
      } 
      i++;
      j = m;
    } 
    return f;
  }
  
  public void g(SolverVariable paramSolverVariable, float paramFloat) {
    // Byte code:
    //   0: fload_2
    //   1: ldc -0.001
    //   3: fcmpl
    //   4: ifle -> 22
    //   7: fload_2
    //   8: ldc 0.001
    //   10: fcmpg
    //   11: ifge -> 22
    //   14: aload_0
    //   15: aload_1
    //   16: iconst_1
    //   17: invokevirtual h : (Landroidx/constraintlayout/solver/SolverVariable;Z)F
    //   20: pop
    //   21: return
    //   22: aload_0
    //   23: getfield h : I
    //   26: istore_3
    //   27: iconst_0
    //   28: istore #8
    //   30: iload_3
    //   31: ifne -> 53
    //   34: aload_0
    //   35: iconst_0
    //   36: aload_1
    //   37: fload_2
    //   38: invokevirtual m : (ILandroidx/constraintlayout/solver/SolverVariable;F)V
    //   41: aload_0
    //   42: aload_1
    //   43: iconst_0
    //   44: invokevirtual l : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   47: aload_0
    //   48: iconst_0
    //   49: putfield i : I
    //   52: return
    //   53: aload_0
    //   54: aload_1
    //   55: invokevirtual n : (Landroidx/constraintlayout/solver/SolverVariable;)I
    //   58: istore_3
    //   59: iload_3
    //   60: iconst_m1
    //   61: if_icmpeq -> 72
    //   64: aload_0
    //   65: getfield e : [F
    //   68: iload_3
    //   69: fload_2
    //   70: fastore
    //   71: return
    //   72: aload_0
    //   73: getfield h : I
    //   76: istore_3
    //   77: aload_0
    //   78: getfield a : I
    //   81: istore #4
    //   83: iload_3
    //   84: iconst_1
    //   85: iadd
    //   86: iload #4
    //   88: if_icmplt -> 200
    //   91: iload #4
    //   93: iconst_2
    //   94: imul
    //   95: istore #4
    //   97: aload_0
    //   98: aload_0
    //   99: getfield d : [I
    //   102: iload #4
    //   104: invokestatic copyOf : ([II)[I
    //   107: putfield d : [I
    //   110: aload_0
    //   111: aload_0
    //   112: getfield e : [F
    //   115: iload #4
    //   117: invokestatic copyOf : ([FI)[F
    //   120: putfield e : [F
    //   123: aload_0
    //   124: aload_0
    //   125: getfield f : [I
    //   128: iload #4
    //   130: invokestatic copyOf : ([II)[I
    //   133: putfield f : [I
    //   136: aload_0
    //   137: aload_0
    //   138: getfield g : [I
    //   141: iload #4
    //   143: invokestatic copyOf : ([II)[I
    //   146: putfield g : [I
    //   149: aload_0
    //   150: aload_0
    //   151: getfield c : [I
    //   154: iload #4
    //   156: invokestatic copyOf : ([II)[I
    //   159: putfield c : [I
    //   162: aload_0
    //   163: getfield a : I
    //   166: istore_3
    //   167: iload_3
    //   168: iload #4
    //   170: if_icmpge -> 194
    //   173: aload_0
    //   174: getfield d : [I
    //   177: iload_3
    //   178: iconst_m1
    //   179: iastore
    //   180: aload_0
    //   181: getfield c : [I
    //   184: iload_3
    //   185: iconst_m1
    //   186: iastore
    //   187: iload_3
    //   188: iconst_1
    //   189: iadd
    //   190: istore_3
    //   191: goto -> 167
    //   194: aload_0
    //   195: iload #4
    //   197: putfield a : I
    //   200: aload_0
    //   201: getfield h : I
    //   204: istore #9
    //   206: aload_0
    //   207: getfield i : I
    //   210: istore_3
    //   211: iconst_0
    //   212: istore #6
    //   214: iconst_m1
    //   215: istore #4
    //   217: iload #8
    //   219: istore #5
    //   221: iload #4
    //   223: istore #7
    //   225: iload #6
    //   227: iload #9
    //   229: if_icmpge -> 309
    //   232: aload_0
    //   233: getfield d : [I
    //   236: astore #10
    //   238: aload #10
    //   240: iload_3
    //   241: iaload
    //   242: istore #7
    //   244: aload_1
    //   245: getfield b : I
    //   248: istore #5
    //   250: iload #7
    //   252: iload #5
    //   254: if_icmpne -> 265
    //   257: aload_0
    //   258: getfield e : [F
    //   261: iload_3
    //   262: fload_2
    //   263: fastore
    //   264: return
    //   265: aload #10
    //   267: iload_3
    //   268: iaload
    //   269: iload #5
    //   271: if_icmpge -> 277
    //   274: iload_3
    //   275: istore #4
    //   277: aload_0
    //   278: getfield g : [I
    //   281: iload_3
    //   282: iaload
    //   283: istore_3
    //   284: iload_3
    //   285: iconst_m1
    //   286: if_icmpne -> 300
    //   289: iload #8
    //   291: istore #5
    //   293: iload #4
    //   295: istore #7
    //   297: goto -> 309
    //   300: iload #6
    //   302: iconst_1
    //   303: iadd
    //   304: istore #6
    //   306: goto -> 217
    //   309: iload #5
    //   311: aload_0
    //   312: getfield a : I
    //   315: if_icmpge -> 341
    //   318: aload_0
    //   319: getfield d : [I
    //   322: iload #5
    //   324: iaload
    //   325: iconst_m1
    //   326: if_icmpne -> 332
    //   329: goto -> 344
    //   332: iload #5
    //   334: iconst_1
    //   335: iadd
    //   336: istore #5
    //   338: goto -> 309
    //   341: iconst_m1
    //   342: istore #5
    //   344: aload_0
    //   345: iload #5
    //   347: aload_1
    //   348: fload_2
    //   349: invokevirtual m : (ILandroidx/constraintlayout/solver/SolverVariable;F)V
    //   352: iload #7
    //   354: iconst_m1
    //   355: if_icmpeq -> 393
    //   358: aload_0
    //   359: getfield f : [I
    //   362: iload #5
    //   364: iload #7
    //   366: iastore
    //   367: aload_0
    //   368: getfield g : [I
    //   371: astore #10
    //   373: aload #10
    //   375: iload #5
    //   377: aload #10
    //   379: iload #7
    //   381: iaload
    //   382: iastore
    //   383: aload #10
    //   385: iload #7
    //   387: iload #5
    //   389: iastore
    //   390: goto -> 436
    //   393: aload_0
    //   394: getfield f : [I
    //   397: iload #5
    //   399: iconst_m1
    //   400: iastore
    //   401: aload_0
    //   402: getfield h : I
    //   405: ifle -> 428
    //   408: aload_0
    //   409: getfield g : [I
    //   412: iload #5
    //   414: aload_0
    //   415: getfield i : I
    //   418: iastore
    //   419: aload_0
    //   420: iload #5
    //   422: putfield i : I
    //   425: goto -> 436
    //   428: aload_0
    //   429: getfield g : [I
    //   432: iload #5
    //   434: iconst_m1
    //   435: iastore
    //   436: aload_0
    //   437: getfield g : [I
    //   440: astore #10
    //   442: aload #10
    //   444: iload #5
    //   446: iaload
    //   447: iconst_m1
    //   448: if_icmpeq -> 463
    //   451: aload_0
    //   452: getfield f : [I
    //   455: aload #10
    //   457: iload #5
    //   459: iaload
    //   460: iload #5
    //   462: iastore
    //   463: aload_0
    //   464: aload_1
    //   465: iload #5
    //   467: invokevirtual l : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   470: return
  }
  
  public float h(SolverVariable paramSolverVariable, boolean paramBoolean) {
    int j = n(paramSolverVariable);
    if (j == -1)
      return 0.0F; 
    int k = paramSolverVariable.b;
    int m = k % 16;
    int[] arrayOfInt1 = this.b;
    int i = arrayOfInt1[m];
    if (i != -1) {
      int n = i;
      if (this.d[i] == k) {
        int[] arrayOfInt = this.c;
        arrayOfInt1[m] = arrayOfInt[i];
        arrayOfInt[i] = -1;
      } else {
        while (true) {
          arrayOfInt1 = this.c;
          if (arrayOfInt1[n] != -1 && this.d[arrayOfInt1[n]] != k) {
            n = arrayOfInt1[n];
            continue;
          } 
          break;
        } 
        i = arrayOfInt1[n];
        if (i != -1 && this.d[i] == k) {
          arrayOfInt1[n] = arrayOfInt1[i];
          arrayOfInt1[i] = -1;
        } 
      } 
    } 
    float f = this.e[j];
    if (this.i == j)
      this.i = this.g[j]; 
    this.d[j] = -1;
    arrayOfInt1 = this.f;
    if (arrayOfInt1[j] != -1) {
      int[] arrayOfInt = this.g;
      arrayOfInt[arrayOfInt1[j]] = arrayOfInt[j];
    } 
    int[] arrayOfInt2 = this.g;
    if (arrayOfInt2[j] != -1)
      arrayOfInt1[arrayOfInt2[j]] = arrayOfInt1[j]; 
    this.h--;
    paramSolverVariable.l--;
    if (paramBoolean)
      paramSolverVariable.b(this.j); 
    return f;
  }
  
  public SolverVariable i(int paramInt) {
    int k = this.h;
    if (k == 0)
      return null; 
    int j = this.i;
    for (int i = 0; i < k; i++) {
      if (i == paramInt && j != -1)
        return ((SolverVariable[])this.k.j)[this.d[j]]; 
      j = this.g[j];
      if (j == -1)
        return null; 
    } 
    return null;
  }
  
  public void j(float paramFloat) {
    int k = this.h;
    int j = this.i;
    for (int i = 0; i < k; i++) {
      float[] arrayOfFloat = this.e;
      arrayOfFloat[j] = arrayOfFloat[j] / paramFloat;
      j = this.g[j];
      if (j == -1)
        return; 
    } 
  }
  
  public void k() {
    int k = this.h;
    int j = this.i;
    for (int i = 0; i < k; i++) {
      float[] arrayOfFloat = this.e;
      arrayOfFloat[j] = arrayOfFloat[j] * -1.0F;
      j = this.g[j];
      if (j == -1)
        return; 
    } 
  }
  
  public final void l(SolverVariable paramSolverVariable, int paramInt) {
    int k = paramSolverVariable.b % 16;
    int[] arrayOfInt = this.b;
    int j = arrayOfInt[k];
    int i = j;
    if (j == -1) {
      arrayOfInt[k] = paramInt;
    } else {
      while (true) {
        arrayOfInt = this.c;
        if (arrayOfInt[i] != -1) {
          i = arrayOfInt[i];
          continue;
        } 
        arrayOfInt[i] = paramInt;
        this.c[paramInt] = -1;
        return;
      } 
    } 
    this.c[paramInt] = -1;
  }
  
  public final void m(int paramInt, SolverVariable paramSolverVariable, float paramFloat) {
    this.d[paramInt] = paramSolverVariable.b;
    this.e[paramInt] = paramFloat;
    this.f[paramInt] = -1;
    this.g[paramInt] = -1;
    paramSolverVariable.a(this.j);
    paramSolverVariable.l++;
    this.h++;
  }
  
  public int n(SolverVariable paramSolverVariable) {
    int[] arrayOfInt;
    if (this.h == 0)
      return -1; 
    int k = paramSolverVariable.b;
    int j = this.b[k % 16];
    if (j == -1)
      return -1; 
    int i = j;
    if (this.d[j] == k)
      return j; 
    while (true) {
      arrayOfInt = this.c;
      if (arrayOfInt[i] != -1 && this.d[arrayOfInt[i]] != k) {
        i = arrayOfInt[i];
        continue;
      } 
      break;
    } 
    return (arrayOfInt[i] == -1) ? -1 : ((this.d[arrayOfInt[i]] == k) ? arrayOfInt[i] : -1);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(hashCode());
    stringBuilder.append(" { ");
    String str = stringBuilder.toString();
    int j = this.h;
    for (int i = 0; i < j; i++) {
      SolverVariable solverVariable = i(i);
      if (solverVariable != null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str);
        stringBuilder1.append(solverVariable);
        stringBuilder1.append(" = ");
        stringBuilder1.append(a(i));
        stringBuilder1.append(" ");
        str = stringBuilder1.toString();
        int k = n(solverVariable);
        str = f.a(str, "[p: ");
        if (this.f[k] != -1) {
          StringBuilder stringBuilder2 = a.a(str);
          stringBuilder2.append(((SolverVariable[])this.k.j)[this.d[this.f[k]]]);
          str = stringBuilder2.toString();
        } else {
          str = f.a(str, "none");
        } 
        str = f.a(str, ", n: ");
        if (this.g[k] != -1) {
          StringBuilder stringBuilder2 = a.a(str);
          stringBuilder2.append(((SolverVariable[])this.k.j)[this.d[this.g[k]]]);
          str = stringBuilder2.toString();
        } else {
          str = f.a(str, "none");
        } 
        str = f.a(str, "]");
      } 
    } 
    return f.a(str, " }");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\constraintlayout\solver\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */