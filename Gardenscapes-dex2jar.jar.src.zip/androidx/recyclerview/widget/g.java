package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.Objects;

public class g extends AnimatorListenerAdapter {
  public g(k paramk, RecyclerView.z paramz, View paramView, ViewPropertyAnimator paramViewPropertyAnimator) {}
  
  public void onAnimationCancel(Animator paramAnimator) {
    this.b.setAlpha(1.0F);
  }
  
  public void onAnimationEnd(Animator paramAnimator) {
    this.c.setListener(null);
    this.d.c(this.a);
    this.d.o.remove(this.a);
    this.d.k();
  }
  
  public void onAnimationStart(Animator paramAnimator) {
    Objects.requireNonNull(this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */