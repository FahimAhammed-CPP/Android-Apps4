package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

public class o extends RecyclerView.v {
  public final LinearInterpolator i = new LinearInterpolator();
  
  public final DecelerateInterpolator j = new DecelerateInterpolator();
  
  public PointF k;
  
  public final DisplayMetrics l;
  
  public boolean m = false;
  
  public float n;
  
  public int o = 0;
  
  public int p = 0;
  
  public o(Context paramContext) {
    this.l = paramContext.getResources().getDisplayMetrics();
  }
  
  public void c(View paramView, RecyclerView.w paramw, RecyclerView.v.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: getfield k : Landroid/graphics/PointF;
    //   4: astore_2
    //   5: iconst_0
    //   6: istore #10
    //   8: aload_2
    //   9: ifnull -> 47
    //   12: aload_2
    //   13: getfield x : F
    //   16: fstore #6
    //   18: fload #6
    //   20: fconst_0
    //   21: fcmpl
    //   22: ifne -> 28
    //   25: goto -> 47
    //   28: fload #6
    //   30: fconst_0
    //   31: fcmpl
    //   32: ifle -> 41
    //   35: iconst_1
    //   36: istore #7
    //   38: goto -> 50
    //   41: iconst_m1
    //   42: istore #7
    //   44: goto -> 50
    //   47: iconst_0
    //   48: istore #7
    //   50: aload_0
    //   51: getfield c : Landroidx/recyclerview/widget/RecyclerView$l;
    //   54: astore_2
    //   55: aload_2
    //   56: ifnull -> 124
    //   59: aload_2
    //   60: invokevirtual e : ()Z
    //   63: ifne -> 69
    //   66: goto -> 124
    //   69: aload_1
    //   70: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   73: checkcast androidx/recyclerview/widget/RecyclerView$m
    //   76: astore #11
    //   78: aload_0
    //   79: aload_2
    //   80: aload_1
    //   81: invokevirtual C : (Landroid/view/View;)I
    //   84: aload #11
    //   86: getfield leftMargin : I
    //   89: isub
    //   90: aload_2
    //   91: aload_1
    //   92: invokevirtual F : (Landroid/view/View;)I
    //   95: aload #11
    //   97: getfield rightMargin : I
    //   100: iadd
    //   101: aload_2
    //   102: invokevirtual N : ()I
    //   105: aload_2
    //   106: getfield n : I
    //   109: aload_2
    //   110: invokevirtual O : ()I
    //   113: isub
    //   114: iload #7
    //   116: invokevirtual e : (IIIII)I
    //   119: istore #8
    //   121: goto -> 127
    //   124: iconst_0
    //   125: istore #8
    //   127: aload_0
    //   128: getfield k : Landroid/graphics/PointF;
    //   131: astore_2
    //   132: aload_2
    //   133: ifnull -> 171
    //   136: aload_2
    //   137: getfield y : F
    //   140: fstore #6
    //   142: fload #6
    //   144: fconst_0
    //   145: fcmpl
    //   146: ifne -> 152
    //   149: goto -> 171
    //   152: fload #6
    //   154: fconst_0
    //   155: fcmpl
    //   156: ifle -> 165
    //   159: iconst_1
    //   160: istore #7
    //   162: goto -> 174
    //   165: iconst_m1
    //   166: istore #7
    //   168: goto -> 174
    //   171: iconst_0
    //   172: istore #7
    //   174: aload_0
    //   175: getfield c : Landroidx/recyclerview/widget/RecyclerView$l;
    //   178: astore_2
    //   179: iload #10
    //   181: istore #9
    //   183: aload_2
    //   184: ifnull -> 253
    //   187: aload_2
    //   188: invokevirtual f : ()Z
    //   191: ifne -> 201
    //   194: iload #10
    //   196: istore #9
    //   198: goto -> 253
    //   201: aload_1
    //   202: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   205: checkcast androidx/recyclerview/widget/RecyclerView$m
    //   208: astore #11
    //   210: aload_0
    //   211: aload_2
    //   212: aload_1
    //   213: invokevirtual G : (Landroid/view/View;)I
    //   216: aload #11
    //   218: getfield topMargin : I
    //   221: isub
    //   222: aload_2
    //   223: aload_1
    //   224: invokevirtual A : (Landroid/view/View;)I
    //   227: aload #11
    //   229: getfield bottomMargin : I
    //   232: iadd
    //   233: aload_2
    //   234: invokevirtual P : ()I
    //   237: aload_2
    //   238: getfield o : I
    //   241: aload_2
    //   242: invokevirtual M : ()I
    //   245: isub
    //   246: iload #7
    //   248: invokevirtual e : (IIIII)I
    //   251: istore #9
    //   253: aload_0
    //   254: iload #9
    //   256: iload #9
    //   258: imul
    //   259: iload #8
    //   261: iload #8
    //   263: imul
    //   264: iadd
    //   265: i2d
    //   266: invokestatic sqrt : (D)D
    //   269: d2i
    //   270: invokevirtual g : (I)I
    //   273: i2d
    //   274: dstore #4
    //   276: dload #4
    //   278: invokestatic isNaN : (D)Z
    //   281: pop
    //   282: dload #4
    //   284: invokestatic isNaN : (D)Z
    //   287: pop
    //   288: dload #4
    //   290: invokestatic isNaN : (D)Z
    //   293: pop
    //   294: dload #4
    //   296: ldc2_w 0.3356
    //   299: ddiv
    //   300: invokestatic ceil : (D)D
    //   303: d2i
    //   304: istore #7
    //   306: iload #7
    //   308: ifle -> 327
    //   311: aload_3
    //   312: iload #8
    //   314: ineg
    //   315: iload #9
    //   317: ineg
    //   318: iload #7
    //   320: aload_0
    //   321: getfield j : Landroid/view/animation/DecelerateInterpolator;
    //   324: invokevirtual b : (IIILandroid/view/animation/Interpolator;)V
    //   327: return
  }
  
  public int e(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt5 != -1) {
      if (paramInt5 != 0) {
        if (paramInt5 == 1)
          return paramInt4 - paramInt2; 
        throw new IllegalArgumentException("snap preference should be one of the constants defined in SmoothScroller, starting with SNAP_");
      } 
      paramInt1 = paramInt3 - paramInt1;
      if (paramInt1 > 0)
        return paramInt1; 
      paramInt1 = paramInt4 - paramInt2;
      return (paramInt1 < 0) ? paramInt1 : 0;
    } 
    return paramInt3 - paramInt1;
  }
  
  public float f(DisplayMetrics paramDisplayMetrics) {
    return 25.0F / paramDisplayMetrics.densityDpi;
  }
  
  public int g(int paramInt) {
    float f = Math.abs(paramInt);
    if (!this.m) {
      this.n = f(this.l);
      this.m = true;
    } 
    return (int)Math.ceil((f * this.n));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */