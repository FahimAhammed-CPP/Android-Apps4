package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.view.MotionEvent;
import android.view.View;
import java.util.List;
import java.util.WeakHashMap;
import m0.y;

public class l extends RecyclerView.k implements RecyclerView.o {
  public static final int[] D = new int[] { 16842919 };
  
  public static final int[] E = new int[0];
  
  public int A;
  
  public final Runnable B;
  
  public final RecyclerView.p C;
  
  public final int a;
  
  public final int b;
  
  public final StateListDrawable c;
  
  public final Drawable d;
  
  public final int e;
  
  public final int f;
  
  public final StateListDrawable g;
  
  public final Drawable h;
  
  public final int i;
  
  public final int j;
  
  public int k;
  
  public int l;
  
  public float m;
  
  public int n;
  
  public int o;
  
  public float p;
  
  public int q;
  
  public int r;
  
  public RecyclerView s;
  
  public boolean t;
  
  public boolean u;
  
  public int v;
  
  public int w;
  
  public final int[] x;
  
  public final int[] y;
  
  public final ValueAnimator z;
  
  public l(RecyclerView paramRecyclerView, StateListDrawable paramStateListDrawable1, Drawable paramDrawable1, StateListDrawable paramStateListDrawable2, Drawable paramDrawable2, int paramInt1, int paramInt2, int paramInt3) {
    boolean bool = false;
    this.q = 0;
    this.r = 0;
    this.t = false;
    this.u = false;
    this.v = 0;
    this.w = 0;
    this.x = new int[2];
    this.y = new int[2];
    ValueAnimator valueAnimator = ValueAnimator.ofFloat(new float[] { 0.0F, 1.0F });
    this.z = valueAnimator;
    this.A = 0;
    this.B = new a(this);
    b b = new b(this);
    this.C = b;
    this.c = paramStateListDrawable1;
    this.d = paramDrawable1;
    this.g = paramStateListDrawable2;
    this.h = paramDrawable2;
    this.e = Math.max(paramInt1, paramStateListDrawable1.getIntrinsicWidth());
    this.f = Math.max(paramInt1, paramDrawable1.getIntrinsicWidth());
    this.i = Math.max(paramInt1, paramStateListDrawable2.getIntrinsicWidth());
    this.j = Math.max(paramInt1, paramDrawable2.getIntrinsicWidth());
    this.a = paramInt2;
    this.b = paramInt3;
    paramStateListDrawable1.setAlpha(255);
    paramDrawable1.setAlpha(255);
    valueAnimator.addListener((Animator.AnimatorListener)new c(this));
    valueAnimator.addUpdateListener(new d(this));
    RecyclerView recyclerView = this.s;
    if (recyclerView == paramRecyclerView)
      return; 
    if (recyclerView != null) {
      RecyclerView.l l1 = recyclerView.q;
      if (l1 != null)
        l1.d("Cannot remove item decoration during a scroll  or layout"); 
      recyclerView.s.remove(this);
      if (recyclerView.s.isEmpty()) {
        if (recyclerView.getOverScrollMode() == 2)
          bool = true; 
        recyclerView.setWillNotDraw(bool);
      } 
      recyclerView.Q();
      recyclerView.requestLayout();
      recyclerView = this.s;
      recyclerView.t.remove(this);
      if (recyclerView.u == this)
        recyclerView.u = null; 
      List<RecyclerView.p> list = this.s.k0;
      if (list != null)
        list.remove(b); 
      f();
    } 
    this.s = paramRecyclerView;
    paramRecyclerView.g(this);
    this.s.t.add(this);
    this.s.h(b);
  }
  
  public boolean a(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent) {
    int i = this.v;
    if (i == 1) {
      boolean bool1 = h(paramMotionEvent.getX(), paramMotionEvent.getY());
      boolean bool2 = g(paramMotionEvent.getX(), paramMotionEvent.getY());
      if (paramMotionEvent.getAction() == 0 && (bool1 || bool2)) {
        if (bool2) {
          this.w = 1;
          this.p = (int)paramMotionEvent.getX();
        } else if (bool1) {
          this.w = 2;
          this.m = (int)paramMotionEvent.getY();
        } 
        j(2);
        return true;
      } 
    } else if (i == 2) {
      return true;
    } 
    return false;
  }
  
  public void b(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent) {
    if (this.v == 0)
      return; 
    if (paramMotionEvent.getAction() == 0) {
      boolean bool1 = h(paramMotionEvent.getX(), paramMotionEvent.getY());
      boolean bool2 = g(paramMotionEvent.getX(), paramMotionEvent.getY());
      if (bool1 || bool2) {
        if (bool2) {
          this.w = 1;
          this.p = (int)paramMotionEvent.getX();
        } else if (bool1) {
          this.w = 2;
          this.m = (int)paramMotionEvent.getY();
        } 
        j(2);
        return;
      } 
    } else {
      if (paramMotionEvent.getAction() == 1 && this.v == 2) {
        this.m = 0.0F;
        this.p = 0.0F;
        j(1);
        this.w = 0;
        return;
      } 
      if (paramMotionEvent.getAction() == 2 && this.v == 2) {
        k();
        if (this.w == 1) {
          float f = paramMotionEvent.getX();
          int[] arrayOfInt = this.y;
          int i = this.b;
          arrayOfInt[0] = i;
          arrayOfInt[1] = this.q - i;
          f = Math.max(arrayOfInt[0], Math.min(arrayOfInt[1], f));
          if (Math.abs(this.o - f) >= 2.0F) {
            i = i(this.p, f, arrayOfInt, this.s.computeHorizontalScrollRange(), this.s.computeHorizontalScrollOffset(), this.q);
            if (i != 0)
              this.s.scrollBy(i, 0); 
            this.p = f;
          } 
        } 
        if (this.w == 2) {
          float f = paramMotionEvent.getY();
          int[] arrayOfInt = this.x;
          int i = this.b;
          arrayOfInt[0] = i;
          arrayOfInt[1] = this.r - i;
          f = Math.max(arrayOfInt[0], Math.min(arrayOfInt[1], f));
          if (Math.abs(this.l - f) < 2.0F)
            return; 
          i = i(this.m, f, arrayOfInt, this.s.computeVerticalScrollRange(), this.s.computeVerticalScrollOffset(), this.r);
          if (i != 0)
            this.s.scrollBy(0, i); 
          this.m = f;
        } 
      } 
    } 
  }
  
  public void c(boolean paramBoolean) {}
  
  public void e(Canvas paramCanvas, RecyclerView paramRecyclerView, RecyclerView.w paramw) {
    if (this.q != this.s.getWidth() || this.r != this.s.getHeight()) {
      this.q = this.s.getWidth();
      this.r = this.s.getHeight();
      j(0);
      return;
    } 
    if (this.A != 0) {
      if (this.t) {
        int j = this.q;
        int i = this.e;
        j -= i;
        int m = this.l;
        int n = this.k;
        m -= n / 2;
        this.c.setBounds(0, 0, i, n);
        this.d.setBounds(0, 0, this.f, this.r);
        paramRecyclerView = this.s;
        WeakHashMap weakHashMap = y.a;
        n = y.e.d((View)paramRecyclerView);
        i = 1;
        if (n != 1)
          i = 0; 
        if (i != 0) {
          this.d.draw(paramCanvas);
          paramCanvas.translate(this.e, m);
          paramCanvas.scale(-1.0F, 1.0F);
          this.c.draw(paramCanvas);
          paramCanvas.scale(1.0F, 1.0F);
          paramCanvas.translate(-this.e, -m);
        } else {
          paramCanvas.translate(j, 0.0F);
          this.d.draw(paramCanvas);
          paramCanvas.translate(0.0F, m);
          this.c.draw(paramCanvas);
          paramCanvas.translate(-j, -m);
        } 
      } 
      if (this.u) {
        int j = this.r;
        int i = this.i;
        j -= i;
        int n = this.o;
        int m = this.n;
        n -= m / 2;
        this.g.setBounds(0, 0, m, i);
        this.h.setBounds(0, 0, this.q, this.j);
        paramCanvas.translate(0.0F, j);
        this.h.draw(paramCanvas);
        paramCanvas.translate(n, 0.0F);
        this.g.draw(paramCanvas);
        paramCanvas.translate(-n, -j);
      } 
    } 
  }
  
  public final void f() {
    this.s.removeCallbacks(this.B);
  }
  
  public boolean g(float paramFloat1, float paramFloat2) {
    if (paramFloat2 >= (this.r - this.i)) {
      int i = this.o;
      int j = this.n;
      if (paramFloat1 >= (i - j / 2) && paramFloat1 <= (j / 2 + i))
        return true; 
    } 
    return false;
  }
  
  public boolean h(float paramFloat1, float paramFloat2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield s : Landroidx/recyclerview/widget/RecyclerView;
    //   4: astore #7
    //   6: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   9: astore #8
    //   11: aload #7
    //   13: invokestatic d : (Landroid/view/View;)I
    //   16: istore_3
    //   17: iconst_0
    //   18: istore #6
    //   20: iload_3
    //   21: iconst_1
    //   22: if_icmpne -> 30
    //   25: iconst_1
    //   26: istore_3
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_3
    //   32: iload_3
    //   33: ifeq -> 55
    //   36: iload #6
    //   38: istore #5
    //   40: fload_1
    //   41: aload_0
    //   42: getfield e : I
    //   45: iconst_2
    //   46: idiv
    //   47: i2f
    //   48: fcmpg
    //   49: ifgt -> 118
    //   52: goto -> 74
    //   55: iload #6
    //   57: istore #5
    //   59: fload_1
    //   60: aload_0
    //   61: getfield q : I
    //   64: aload_0
    //   65: getfield e : I
    //   68: isub
    //   69: i2f
    //   70: fcmpl
    //   71: iflt -> 118
    //   74: aload_0
    //   75: getfield l : I
    //   78: istore_3
    //   79: aload_0
    //   80: getfield k : I
    //   83: iconst_2
    //   84: idiv
    //   85: istore #4
    //   87: iload #6
    //   89: istore #5
    //   91: fload_2
    //   92: iload_3
    //   93: iload #4
    //   95: isub
    //   96: i2f
    //   97: fcmpl
    //   98: iflt -> 118
    //   101: iload #6
    //   103: istore #5
    //   105: fload_2
    //   106: iload #4
    //   108: iload_3
    //   109: iadd
    //   110: i2f
    //   111: fcmpg
    //   112: ifgt -> 118
    //   115: iconst_1
    //   116: istore #5
    //   118: iload #5
    //   120: ireturn
  }
  
  public final int i(float paramFloat1, float paramFloat2, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3) {
    int i = paramArrayOfint[1] - paramArrayOfint[0];
    if (i == 0)
      return 0; 
    paramFloat1 = (paramFloat2 - paramFloat1) / i;
    paramInt1 -= paramInt3;
    paramInt3 = (int)(paramFloat1 * paramInt1);
    paramInt2 += paramInt3;
    return (paramInt2 < paramInt1 && paramInt2 >= 0) ? paramInt3 : 0;
  }
  
  public void j(int paramInt) {
    if (paramInt == 2 && this.v != 2) {
      this.c.setState(D);
      f();
    } 
    if (paramInt == 0) {
      this.s.invalidate();
    } else {
      k();
    } 
    if (this.v == 2 && paramInt != 2) {
      this.c.setState(E);
      f();
      this.s.postDelayed(this.B, 1200L);
    } else if (paramInt == 1) {
      f();
      this.s.postDelayed(this.B, 1500L);
    } 
    this.v = paramInt;
  }
  
  public void k() {
    int i = this.A;
    if (i != 0) {
      if (i != 3)
        return; 
      this.z.cancel();
    } 
    this.A = 1;
    ValueAnimator valueAnimator = this.z;
    valueAnimator.setFloatValues(new float[] { ((Float)valueAnimator.getAnimatedValue()).floatValue(), 1.0F });
    this.z.setDuration(500L);
    this.z.setStartDelay(0L);
    this.z.start();
  }
  
  public class a implements Runnable {
    public a(l this$0) {}
    
    public void run() {
      l l1 = this.f;
      int i = l1.A;
      if (i != 1) {
        if (i != 2)
          return; 
      } else {
        l1.z.cancel();
      } 
      l1.A = 3;
      ValueAnimator valueAnimator = l1.z;
      valueAnimator.setFloatValues(new float[] { ((Float)valueAnimator.getAnimatedValue()).floatValue(), 0.0F });
      l1.z.setDuration(500L);
      l1.z.start();
    }
  }
  
  public class b extends RecyclerView.p {
    public b(l this$0) {}
    
    public void b(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {
      boolean bool;
      l l1 = this.a;
      param1Int1 = param1RecyclerView.computeHorizontalScrollOffset();
      param1Int2 = param1RecyclerView.computeVerticalScrollOffset();
      int i = l1.s.computeVerticalScrollRange();
      int j = l1.r;
      if (i - j > 0 && j >= l1.a) {
        bool = true;
      } else {
        bool = false;
      } 
      l1.t = bool;
      int k = l1.s.computeHorizontalScrollRange();
      int m = l1.q;
      if (k - m > 0 && m >= l1.a) {
        bool = true;
      } else {
        bool = false;
      } 
      l1.u = bool;
      boolean bool1 = l1.t;
      if (!bool1 && !bool) {
        if (l1.v != 0) {
          l1.j(0);
          return;
        } 
      } else {
        if (bool1) {
          float f1 = param1Int2;
          float f2 = j;
          l1.l = (int)((f2 / 2.0F + f1) * f2 / i);
          l1.k = Math.min(j, j * j / i);
        } 
        if (l1.u) {
          float f1 = param1Int1;
          float f2 = m;
          l1.o = (int)((f2 / 2.0F + f1) * f2 / k);
          l1.n = Math.min(m, m * m / k);
        } 
        param1Int1 = l1.v;
        if (param1Int1 == 0 || param1Int1 == 1)
          l1.j(1); 
      } 
    }
  }
  
  public class c extends AnimatorListenerAdapter {
    public boolean a = false;
    
    public c(l this$0) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.a = true;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      if (this.a) {
        this.a = false;
        return;
      } 
      if (((Float)this.b.z.getAnimatedValue()).floatValue() == 0.0F) {
        l l2 = this.b;
        l2.A = 0;
        l2.j(0);
        return;
      } 
      l l1 = this.b;
      l1.A = 2;
      l1.s.invalidate();
    }
  }
  
  public class d implements ValueAnimator.AnimatorUpdateListener {
    public d(l this$0) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      int i = (int)(((Float)param1ValueAnimator.getAnimatedValue()).floatValue() * 255.0F);
      this.a.c.setAlpha(i);
      this.a.d.setAlpha(i);
      this.a.s.invalidate();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */