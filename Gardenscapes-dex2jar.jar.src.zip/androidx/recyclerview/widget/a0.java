package androidx.recyclerview.widget;

import android.view.View;

public abstract class a0 extends RecyclerView.n {
  public RecyclerView a;
  
  public final RecyclerView.p b = new a(this);
  
  public abstract int[] a(RecyclerView.l paraml, View paramView);
  
  public void b() {
    View view;
    RecyclerView recyclerView = this.a;
    if (recyclerView == null)
      return; 
    RecyclerView.l l = recyclerView.getLayoutManager();
    if (l == null)
      return; 
    u u = (u)this;
    if (l.f()) {
      view = u.d(l, u.f(l));
    } else if (l.e()) {
      view = view.d(l, view.e(l));
    } else {
      view = null;
    } 
    if (view == null)
      return; 
    int[] arrayOfInt = a(l, view);
    if (arrayOfInt[0] != 0 || arrayOfInt[1] != 0)
      this.a.g0(arrayOfInt[0], arrayOfInt[1], null, -2147483648, false); 
  }
  
  public class a extends RecyclerView.p {
    public boolean a = false;
    
    public a(a0 this$0) {}
    
    public void a(RecyclerView param1RecyclerView, int param1Int) {
      if (param1Int == 0 && this.a) {
        this.a = false;
        this.b.b();
      } 
    }
    
    public void b(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {
      if (param1Int1 != 0 || param1Int2 != 0)
        this.a = true; 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */