package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.y;

public class b {
  public final b a;
  
  public final a b;
  
  public final List<View> c;
  
  public b(b paramb) {
    this.a = paramb;
    this.b = new a();
    this.c = new ArrayList<View>();
  }
  
  public void a(View paramView, int paramInt, boolean paramBoolean) {
    if (paramInt < 0) {
      paramInt = ((v)this.a).b();
    } else {
      paramInt = f(paramInt);
    } 
    this.b.e(paramInt, paramBoolean);
    if (paramBoolean)
      i(paramView); 
    v v = (v)this.a;
    v.a.addView(paramView, paramInt);
    Objects.requireNonNull(v.a);
    RecyclerView.K(paramView);
  }
  
  public void b(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    StringBuilder stringBuilder;
    if (paramInt < 0) {
      paramInt = ((v)this.a).b();
    } else {
      paramInt = f(paramInt);
    } 
    this.b.e(paramInt, paramBoolean);
    if (paramBoolean)
      i(paramView); 
    v v = (v)this.a;
    Objects.requireNonNull(v);
    RecyclerView.z z = RecyclerView.K(paramView);
    if (z != null)
      if (z.n() || z.t()) {
        z.j &= 0xFFFFFEFF;
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Called attach on a child which is not detached: ");
        stringBuilder.append(z);
        throw new IllegalArgumentException(e1.a.a(v.a, stringBuilder));
      }  
    RecyclerView.a(v.a, (View)stringBuilder, paramInt, paramLayoutParams);
  }
  
  public void c(int paramInt) {
    paramInt = f(paramInt);
    this.b.f(paramInt);
    v v = (v)this.a;
    View view = v.a.getChildAt(paramInt);
    if (view != null) {
      RecyclerView.z z = RecyclerView.K(view);
      if (z != null)
        if (!z.n() || z.t()) {
          z.b(256);
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("called detach on an already detached child ");
          stringBuilder.append(z);
          throw new IllegalArgumentException(e1.a.a(v.a, stringBuilder));
        }  
    } 
    RecyclerView.c(v.a, paramInt);
  }
  
  public View d(int paramInt) {
    paramInt = f(paramInt);
    return ((v)this.a).a(paramInt);
  }
  
  public int e() {
    return ((v)this.a).b() - this.c.size();
  }
  
  public final int f(int paramInt) {
    if (paramInt < 0)
      return -1; 
    int j = ((v)this.a).b();
    for (int i = paramInt; i < j; i += k) {
      int k = paramInt - i - this.b.b(i);
      if (k == 0) {
        while (this.b.d(i))
          i++; 
        return i;
      } 
    } 
    return -1;
  }
  
  public View g(int paramInt) {
    return ((v)this.a).a.getChildAt(paramInt);
  }
  
  public int h() {
    return ((v)this.a).b();
  }
  
  public final void i(View paramView) {
    this.c.add(paramView);
    v v = (v)this.a;
    Objects.requireNonNull(v);
    RecyclerView.z z = RecyclerView.K(paramView);
    if (z != null) {
      RecyclerView recyclerView = v.a;
      int i = z.q;
      if (i != -1) {
        z.p = i;
      } else {
        View view = z.a;
        WeakHashMap weakHashMap = y.a;
        z.p = y.d.c(view);
      } 
      recyclerView.f0(z, 4);
    } 
  }
  
  public int j(View paramView) {
    int i = ((v)this.a).a.indexOfChild(paramView);
    return (i == -1) ? -1 : (this.b.d(i) ? -1 : (i - this.b.b(i)));
  }
  
  public boolean k(View paramView) {
    return this.c.contains(paramView);
  }
  
  public final boolean l(View paramView) {
    if (this.c.remove(paramView)) {
      v v = (v)this.a;
      Objects.requireNonNull(v);
      RecyclerView.z z = RecyclerView.K(paramView);
      if (z != null) {
        v.a.f0(z, z.p);
        z.p = 0;
      } 
      return true;
    } 
    return false;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.b.toString());
    stringBuilder.append(", hidden list:");
    stringBuilder.append(this.c.size());
    return stringBuilder.toString();
  }
  
  public static class a {
    public long a = 0L;
    
    public a b;
    
    public void a(int param1Int) {
      if (param1Int >= 64) {
        a a1 = this.b;
        if (a1 != null) {
          a1.a(param1Int - 64);
          return;
        } 
      } else {
        this.a &= 1L << param1Int ^ 0xFFFFFFFFFFFFFFFFL;
      } 
    }
    
    public int b(int param1Int) {
      a a1 = this.b;
      if (a1 == null)
        return (param1Int >= 64) ? Long.bitCount(this.a) : Long.bitCount(this.a & (1L << param1Int) - 1L); 
      if (param1Int < 64)
        return Long.bitCount(this.a & (1L << param1Int) - 1L); 
      param1Int = a1.b(param1Int - 64);
      return Long.bitCount(this.a) + param1Int;
    }
    
    public final void c() {
      if (this.b == null)
        this.b = new a(); 
    }
    
    public boolean d(int param1Int) {
      if (param1Int >= 64) {
        c();
        return this.b.d(param1Int - 64);
      } 
      return ((this.a & 1L << param1Int) != 0L);
    }
    
    public void e(int param1Int, boolean param1Boolean) {
      boolean bool;
      if (param1Int >= 64) {
        c();
        this.b.e(param1Int - 64, param1Boolean);
        return;
      } 
      long l1 = this.a;
      if ((Long.MIN_VALUE & l1) != 0L) {
        bool = true;
      } else {
        bool = false;
      } 
      long l2 = (1L << param1Int) - 1L;
      this.a = (l1 & (l2 ^ 0xFFFFFFFFFFFFFFFFL)) << 1L | l1 & l2;
      if (param1Boolean) {
        h(param1Int);
      } else {
        a(param1Int);
      } 
      if (bool || this.b != null) {
        c();
        this.b.e(0, bool);
      } 
    }
    
    public boolean f(int param1Int) {
      boolean bool;
      if (param1Int >= 64) {
        c();
        return this.b.f(param1Int - 64);
      } 
      long l1 = 1L << param1Int;
      long l2 = this.a;
      if ((l2 & l1) != 0L) {
        bool = true;
      } else {
        bool = false;
      } 
      l2 &= l1 ^ 0xFFFFFFFFFFFFFFFFL;
      this.a = l2;
      l1--;
      this.a = l2 & l1 | Long.rotateRight((l1 ^ 0xFFFFFFFFFFFFFFFFL) & l2, 1);
      a a1 = this.b;
      if (a1 != null) {
        if (a1.d(0))
          h(63); 
        this.b.f(0);
      } 
      return bool;
    }
    
    public void g() {
      this.a = 0L;
      a a1 = this.b;
      if (a1 != null)
        a1.g(); 
    }
    
    public void h(int param1Int) {
      if (param1Int >= 64) {
        c();
        this.b.h(param1Int - 64);
        return;
      } 
      this.a |= 1L << param1Int;
    }
    
    public String toString() {
      if (this.b == null)
        return Long.toBinaryString(this.a); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.b.toString());
      stringBuilder.append("xx");
      stringBuilder.append(Long.toBinaryString(this.a));
      return stringBuilder.toString();
    }
  }
  
  public static interface b {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */