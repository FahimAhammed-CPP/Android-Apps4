package androidx.recyclerview.widget;

import android.animation.Animator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Objects;

public class e implements Runnable {
  public e(k paramk, ArrayList paramArrayList) {}
  
  public void run() {
    for (RecyclerView.z z : this.f) {
      k k1 = this.g;
      Objects.requireNonNull(k1);
      View view = z.a;
      ViewPropertyAnimator viewPropertyAnimator = view.animate();
      k1.o.add(z);
      viewPropertyAnimator.alpha(1.0F).setDuration(k1.c).setListener((Animator.AnimatorListener)new g(k1, z, view, viewPropertyAnimator)).start();
    } 
    this.f.clear();
    this.g.l.remove(this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */