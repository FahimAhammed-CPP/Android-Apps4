package androidx.recyclerview.widget;

import s.e;
import s.h;

public class c0 {
  public final h<RecyclerView.z, a> a = new h();
  
  public final e<RecyclerView.z> b = new e();
  
  public void a(RecyclerView.z paramz) {
    a a2 = (a)this.a.getOrDefault(paramz, null);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.a();
      this.a.put(paramz, a1);
    } 
    a1.a |= 0x1;
  }
  
  public void b(RecyclerView.z paramz, RecyclerView.i.c paramc) {
    a a2 = (a)this.a.getOrDefault(paramz, null);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.a();
      this.a.put(paramz, a1);
    } 
    a1.c = paramc;
    a1.a |= 0x8;
  }
  
  public void c(RecyclerView.z paramz, RecyclerView.i.c paramc) {
    a a2 = (a)this.a.getOrDefault(paramz, null);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.a();
      this.a.put(paramz, a1);
    } 
    a1.b = paramc;
    a1.a |= 0x4;
  }
  
  public boolean d(RecyclerView.z paramz) {
    a a = (a)this.a.getOrDefault(paramz, null);
    return (a != null && (a.a & 0x1) != 0);
  }
  
  public final RecyclerView.i.c e(RecyclerView.z paramz, int paramInt) {
    int i = this.a.e(paramz);
    if (i < 0)
      return null; 
    a a = (a)this.a.k(i);
    if (a != null) {
      int j = a.a;
      if ((j & paramInt) != 0) {
        RecyclerView.i.c c;
        j = (paramInt ^ 0xFFFFFFFF) & j;
        a.a = j;
        if (paramInt == 4) {
          c = a.b;
        } else if (paramInt == 8) {
          c = a.c;
        } else {
          throw new IllegalArgumentException("Must provide flag PRE or POST");
        } 
        if ((j & 0xC) == 0) {
          this.a.i(i);
          a.b(a);
        } 
        return c;
      } 
    } 
    return null;
  }
  
  public void f(RecyclerView.z paramz) {
    a a = (a)this.a.getOrDefault(paramz, null);
    if (a == null)
      return; 
    a.a &= 0xFFFFFFFE;
  }
  
  public void g(RecyclerView.z paramz) {
    for (int i = this.b.h() - 1; i >= 0; i--) {
      if (paramz == this.b.i(i)) {
        e<RecyclerView.z> e1 = this.b;
        Object[] arrayOfObject = e1.h;
        Object object1 = arrayOfObject[i];
        Object object2 = e.j;
        if (object1 != object2) {
          arrayOfObject[i] = object2;
          e1.f = true;
        } 
        break;
      } 
    } 
    a a = (a)this.a.remove(paramz);
    if (a != null)
      a.b(a); 
  }
  
  public static class a {
    public static u.a<a> d = new u.a(20, 1);
    
    public int a;
    
    public RecyclerView.i.c b;
    
    public RecyclerView.i.c c;
    
    public static a a() {
      a a2 = (a)d.a();
      a a1 = a2;
      if (a2 == null)
        a1 = new a(); 
      return a1;
    }
    
    public static void b(a param1a) {
      param1a.a = 0;
      param1a.b = null;
      param1a.c = null;
      d.c(param1a);
    }
  }
  
  public static interface b {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */