package androidx.recyclerview.widget;

import android.view.View;

public class y {
  public static int a(RecyclerView.w paramw, s params, View paramView1, View paramView2, RecyclerView.l paraml, boolean paramBoolean) {
    if (paraml.x() == 0 || paramw.b() == 0 || paramView1 == null || paramView2 == null)
      return 0; 
    if (!paramBoolean)
      return Math.abs(paraml.Q(paramView1) - paraml.Q(paramView2)) + 1; 
    int i = params.b(paramView2);
    int j = params.e(paramView1);
    return Math.min(params.l(), i - j);
  }
  
  public static int b(RecyclerView.w paramw, s params, View paramView1, View paramView2, RecyclerView.l paraml, boolean paramBoolean1, boolean paramBoolean2) {
    if (paraml.x() != 0 && paramw.b() != 0 && paramView1 != null) {
      if (paramView2 == null)
        return 0; 
      int i = Math.min(paraml.Q(paramView1), paraml.Q(paramView2));
      int j = Math.max(paraml.Q(paramView1), paraml.Q(paramView2));
      if (paramBoolean2) {
        i = Math.max(0, paramw.b() - j - 1);
      } else {
        i = Math.max(0, i);
      } 
      if (!paramBoolean1)
        return i; 
      j = Math.abs(params.b(paramView2) - params.e(paramView1));
      int k = Math.abs(paraml.Q(paramView1) - paraml.Q(paramView2));
      float f = j / (k + 1);
      return Math.round(i * f + (params.k() - params.e(paramView1)));
    } 
    return 0;
  }
  
  public static int c(RecyclerView.w paramw, s params, View paramView1, View paramView2, RecyclerView.l paraml, boolean paramBoolean) {
    if (paraml.x() == 0 || paramw.b() == 0 || paramView1 == null || paramView2 == null)
      return 0; 
    if (!paramBoolean)
      return paramw.b(); 
    int i = params.b(paramView2);
    int j = params.e(paramView1);
    int k = Math.abs(paraml.Q(paramView1) - paraml.Q(paramView2));
    return (int)((i - j) / (k + 1) * paramw.b());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */