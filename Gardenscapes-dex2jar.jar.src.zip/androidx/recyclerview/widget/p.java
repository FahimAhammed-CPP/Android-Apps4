package androidx.recyclerview.widget;

public class p {
  public final a a;
  
  public p(a parama) {
    this.a = parama;
  }
  
  public static interface a {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */