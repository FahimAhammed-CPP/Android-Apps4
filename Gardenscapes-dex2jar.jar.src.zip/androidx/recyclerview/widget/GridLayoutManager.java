package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.b0;
import java.util.Arrays;
import java.util.Objects;

public class GridLayoutManager extends LinearLayoutManager {
  public boolean E = false;
  
  public int F = -1;
  
  public int[] G;
  
  public View[] H;
  
  public final SparseIntArray I = new SparseIntArray();
  
  public final SparseIntArray J = new SparseIntArray();
  
  public c K = new a();
  
  public final Rect L = new Rect();
  
  public GridLayoutManager(Context paramContext, int paramInt1, int paramInt2, boolean paramBoolean) {
    super(paramInt2, paramBoolean);
    z1(paramInt1);
  }
  
  public GridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    z1((RecyclerView.l.R(paramContext, paramAttributeSet, paramInt1, paramInt2)).b);
  }
  
  public void A0(Rect paramRect, int paramInt1, int paramInt2) {
    int[] arrayOfInt;
    if (this.G == null)
      super.A0(paramRect, paramInt1, paramInt2); 
    int i = N();
    i = O() + i;
    int j = P();
    j = M() + j;
    if (this.p == 1) {
      paramInt2 = RecyclerView.l.h(paramInt2, paramRect.height() + j, K());
      arrayOfInt = this.G;
      i = RecyclerView.l.h(paramInt1, arrayOfInt[arrayOfInt.length - 1] + i, L());
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      paramInt1 = RecyclerView.l.h(paramInt1, arrayOfInt.width() + i, L());
      arrayOfInt = this.G;
      i = RecyclerView.l.h(paramInt2, arrayOfInt[arrayOfInt.length - 1] + j, K());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    RecyclerView.e(this.b, paramInt2, paramInt1);
  }
  
  public final void A1() {
    int i;
    int j;
    if (this.p == 1) {
      i = this.n - O();
      j = N();
    } else {
      i = this.o - M();
      j = P();
    } 
    r1(i - j);
  }
  
  public boolean I0() {
    return (this.z == null && !this.E);
  }
  
  public void K0(RecyclerView.w paramw, LinearLayoutManager.c paramc, RecyclerView.l.c paramc1) {
    int j = this.F;
    int i;
    for (i = 0; i < this.F && paramc.b(paramw) && j > 0; i++) {
      int k = paramc.d;
      int m = Math.max(0, paramc.g);
      ((m.b)paramc1).a(k, m);
      Objects.requireNonNull(this.K);
      j--;
      paramc.d += paramc.e;
    } 
  }
  
  public int S(RecyclerView.r paramr, RecyclerView.w paramw) {
    return (this.p == 0) ? this.F : ((paramw.b() < 1) ? 0 : (u1(paramr, paramw, paramw.b() - 1) + 1));
  }
  
  public View Z0(RecyclerView.r paramr, RecyclerView.w paramw, int paramInt1, int paramInt2, int paramInt3) {
    byte b;
    P0();
    int i = this.r.k();
    int j = this.r.g();
    if (paramInt2 > paramInt1) {
      b = 1;
    } else {
      b = -1;
    } 
    View view2 = null;
    View view1;
    for (view1 = null; paramInt1 != paramInt2; view1 = view4) {
      View view5 = w(paramInt1);
      int k = Q(view5);
      View view3 = view2;
      View view4 = view1;
      if (k >= 0) {
        view3 = view2;
        view4 = view1;
        if (k < paramInt3)
          if (v1(paramr, paramw, k) != 0) {
            view3 = view2;
            view4 = view1;
          } else if (((RecyclerView.m)view5.getLayoutParams()).c()) {
            view3 = view2;
            view4 = view1;
            if (view1 == null) {
              view4 = view5;
              view3 = view2;
            } 
          } else if (this.r.e(view5) >= j || this.r.b(view5) < i) {
            view3 = view2;
            view4 = view1;
            if (view2 == null) {
              view3 = view5;
              view4 = view1;
            } 
          } else {
            return view5;
          }  
      } 
      paramInt1 += b;
      view2 = view3;
    } 
    return (view2 != null) ? view2 : view1;
  }
  
  public View a0(View paramView, int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual r : (Landroid/view/View;)Landroid/view/View;
    //   5: astore #20
    //   7: aconst_null
    //   8: astore #21
    //   10: aload #20
    //   12: ifnonnull -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: aload #20
    //   19: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   22: checkcast androidx/recyclerview/widget/GridLayoutManager$b
    //   25: astore #22
    //   27: aload #22
    //   29: getfield e : I
    //   32: istore #15
    //   34: aload #22
    //   36: getfield f : I
    //   39: iload #15
    //   41: iadd
    //   42: istore #16
    //   44: aload_0
    //   45: aload_1
    //   46: iload_2
    //   47: aload_3
    //   48: aload #4
    //   50: invokespecial a0 : (Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;)Landroid/view/View;
    //   53: ifnonnull -> 58
    //   56: aconst_null
    //   57: areturn
    //   58: aload_0
    //   59: iload_2
    //   60: invokevirtual O0 : (I)I
    //   63: iconst_1
    //   64: if_icmpne -> 73
    //   67: iconst_1
    //   68: istore #19
    //   70: goto -> 76
    //   73: iconst_0
    //   74: istore #19
    //   76: iload #19
    //   78: aload_0
    //   79: getfield u : Z
    //   82: if_icmpeq -> 90
    //   85: iconst_1
    //   86: istore_2
    //   87: goto -> 92
    //   90: iconst_0
    //   91: istore_2
    //   92: iload_2
    //   93: ifeq -> 112
    //   96: aload_0
    //   97: invokevirtual x : ()I
    //   100: iconst_1
    //   101: isub
    //   102: istore #5
    //   104: iconst_m1
    //   105: istore_2
    //   106: iconst_m1
    //   107: istore #6
    //   109: goto -> 123
    //   112: aload_0
    //   113: invokevirtual x : ()I
    //   116: istore_2
    //   117: iconst_0
    //   118: istore #5
    //   120: iconst_1
    //   121: istore #6
    //   123: aload_0
    //   124: getfield p : I
    //   127: iconst_1
    //   128: if_icmpne -> 144
    //   131: aload_0
    //   132: invokevirtual e1 : ()Z
    //   135: ifeq -> 144
    //   138: iconst_1
    //   139: istore #7
    //   141: goto -> 147
    //   144: iconst_0
    //   145: istore #7
    //   147: aload_0
    //   148: aload_3
    //   149: aload #4
    //   151: iload #5
    //   153: invokevirtual u1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;I)I
    //   156: istore #8
    //   158: iconst_m1
    //   159: istore #13
    //   161: iconst_0
    //   162: istore #14
    //   164: iconst_0
    //   165: istore #12
    //   167: iconst_m1
    //   168: istore #11
    //   170: aconst_null
    //   171: astore_1
    //   172: iload_2
    //   173: istore #9
    //   175: iload #5
    //   177: istore #10
    //   179: iload #14
    //   181: istore_2
    //   182: iload #10
    //   184: iload #9
    //   186: if_icmpeq -> 580
    //   189: aload_0
    //   190: aload_3
    //   191: aload #4
    //   193: iload #10
    //   195: invokevirtual u1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;I)I
    //   198: istore #5
    //   200: aload_0
    //   201: iload #10
    //   203: invokevirtual w : (I)Landroid/view/View;
    //   206: astore #22
    //   208: aload #22
    //   210: aload #20
    //   212: if_acmpne -> 218
    //   215: goto -> 580
    //   218: aload #22
    //   220: invokevirtual hasFocusable : ()Z
    //   223: ifeq -> 244
    //   226: iload #5
    //   228: iload #8
    //   230: if_icmpeq -> 244
    //   233: aload #21
    //   235: ifnull -> 241
    //   238: goto -> 580
    //   241: goto -> 570
    //   244: aload #22
    //   246: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   249: checkcast androidx/recyclerview/widget/GridLayoutManager$b
    //   252: astore #23
    //   254: aload #23
    //   256: getfield e : I
    //   259: istore #14
    //   261: aload #23
    //   263: getfield f : I
    //   266: iload #14
    //   268: iadd
    //   269: istore #17
    //   271: aload #22
    //   273: invokevirtual hasFocusable : ()Z
    //   276: ifeq -> 296
    //   279: iload #14
    //   281: iload #15
    //   283: if_icmpne -> 296
    //   286: iload #17
    //   288: iload #16
    //   290: if_icmpne -> 296
    //   293: aload #22
    //   295: areturn
    //   296: aload #22
    //   298: invokevirtual hasFocusable : ()Z
    //   301: ifeq -> 309
    //   304: aload #21
    //   306: ifnull -> 321
    //   309: aload #22
    //   311: invokevirtual hasFocusable : ()Z
    //   314: ifne -> 324
    //   317: aload_1
    //   318: ifnonnull -> 324
    //   321: goto -> 391
    //   324: iload #14
    //   326: iload #15
    //   328: invokestatic max : (II)I
    //   331: istore #5
    //   333: iload #17
    //   335: iload #16
    //   337: invokestatic min : (II)I
    //   340: iload #5
    //   342: isub
    //   343: istore #18
    //   345: aload #22
    //   347: invokevirtual hasFocusable : ()Z
    //   350: ifeq -> 397
    //   353: iload #18
    //   355: iload_2
    //   356: if_icmple -> 362
    //   359: goto -> 391
    //   362: iload #18
    //   364: iload_2
    //   365: if_icmpne -> 494
    //   368: iload #14
    //   370: iload #11
    //   372: if_icmple -> 381
    //   375: iconst_1
    //   376: istore #5
    //   378: goto -> 384
    //   381: iconst_0
    //   382: istore #5
    //   384: iload #7
    //   386: iload #5
    //   388: if_icmpne -> 494
    //   391: iconst_1
    //   392: istore #5
    //   394: goto -> 497
    //   397: aload #21
    //   399: ifnonnull -> 494
    //   402: aload_0
    //   403: getfield c : Landroidx/recyclerview/widget/b0;
    //   406: aload #22
    //   408: sipush #24579
    //   411: invokevirtual b : (Landroid/view/View;I)Z
    //   414: ifeq -> 438
    //   417: aload_0
    //   418: getfield d : Landroidx/recyclerview/widget/b0;
    //   421: aload #22
    //   423: sipush #24579
    //   426: invokevirtual b : (Landroid/view/View;I)Z
    //   429: ifeq -> 438
    //   432: iconst_1
    //   433: istore #5
    //   435: goto -> 441
    //   438: iconst_0
    //   439: istore #5
    //   441: iload #5
    //   443: iconst_1
    //   444: ixor
    //   445: ifeq -> 494
    //   448: iload #18
    //   450: iload #12
    //   452: if_icmple -> 458
    //   455: goto -> 488
    //   458: iload #18
    //   460: iload #12
    //   462: if_icmpne -> 494
    //   465: iload #14
    //   467: iload #13
    //   469: if_icmple -> 478
    //   472: iconst_1
    //   473: istore #5
    //   475: goto -> 481
    //   478: iconst_0
    //   479: istore #5
    //   481: iload #7
    //   483: iload #5
    //   485: if_icmpne -> 494
    //   488: iconst_1
    //   489: istore #5
    //   491: goto -> 497
    //   494: iconst_0
    //   495: istore #5
    //   497: iload #5
    //   499: ifeq -> 570
    //   502: aload #22
    //   504: invokevirtual hasFocusable : ()Z
    //   507: ifeq -> 540
    //   510: aload #23
    //   512: getfield e : I
    //   515: istore #11
    //   517: iload #17
    //   519: iload #16
    //   521: invokestatic min : (II)I
    //   524: iload #14
    //   526: iload #15
    //   528: invokestatic max : (II)I
    //   531: isub
    //   532: istore_2
    //   533: aload #22
    //   535: astore #21
    //   537: goto -> 570
    //   540: aload #23
    //   542: getfield e : I
    //   545: istore #13
    //   547: iload #17
    //   549: iload #16
    //   551: invokestatic min : (II)I
    //   554: iload #14
    //   556: iload #15
    //   558: invokestatic max : (II)I
    //   561: isub
    //   562: istore #12
    //   564: aload #22
    //   566: astore_1
    //   567: goto -> 570
    //   570: iload #10
    //   572: iload #6
    //   574: iadd
    //   575: istore #10
    //   577: goto -> 182
    //   580: aload #21
    //   582: ifnull -> 588
    //   585: aload #21
    //   587: areturn
    //   588: aload_1
    //   589: areturn
  }
  
  public void d0(RecyclerView.r paramr, RecyclerView.w paramw, View paramView, n0.b paramb) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof b)) {
      c0(paramView, paramb);
      return;
    } 
    b b1 = (b)layoutParams;
    int i = u1(paramr, paramw, b1.a());
    if (this.p == 0) {
      paramb.j(n0.b.c.a(b1.e, b1.f, i, 1, false, false));
      return;
    } 
    paramb.j(n0.b.c.a(i, 1, b1.e, b1.f, false, false));
  }
  
  public void e0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.K.a.clear();
    this.K.b.clear();
  }
  
  public void f0(RecyclerView paramRecyclerView) {
    this.K.a.clear();
    this.K.b.clear();
  }
  
  public void f1(RecyclerView.r paramr, RecyclerView.w paramw, LinearLayoutManager.c paramc, LinearLayoutManager.b paramb) {
    StringBuilder stringBuilder;
    int m;
    int n;
    int i2;
    int i3;
    int i4 = this.r.j();
    if (i4 != 1073741824) {
      m = 1;
    } else {
      m = 0;
    } 
    if (x() > 0) {
      n = this.G[this.F];
    } else {
      n = 0;
    } 
    if (m)
      A1(); 
    if (paramc.e == 1) {
      i1 = 1;
    } else {
      i1 = 0;
    } 
    int i = this.F;
    if (!i1)
      i = v1(paramr, paramw, paramc.d) + w1(paramr, paramw, paramc.d); 
    int k = 0;
    while (k < this.F && paramc.b(paramw) && i > 0) {
      j = paramc.d;
      i2 = w1(paramr, paramw, j);
      if (i2 <= this.F) {
        i -= i2;
        if (i < 0)
          break; 
        View view = paramc.c(paramr);
        if (view == null)
          break; 
        this.H[k] = view;
        k++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Item at position ");
      stringBuilder.append(j);
      stringBuilder.append(" requires ");
      stringBuilder.append(i2);
      stringBuilder.append(" spans but GridLayoutManager has only ");
      stringBuilder.append(this.F);
      stringBuilder.append(" spans.");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (k == 0) {
      paramb.b = true;
      return;
    } 
    if (i1) {
      i2 = k;
      i = 0;
      j = 0;
      i3 = 1;
    } else {
      i = k - 1;
      i2 = -1;
      j = 0;
      i3 = -1;
    } 
    while (i != i2) {
      View view = this.H[i];
      b b1 = (b)view.getLayoutParams();
      int i5 = w1((RecyclerView.r)stringBuilder, paramw, Q(view));
      b1.f = i5;
      b1.e = j;
      j += i5;
      i += i3;
    } 
    float f = 0.0F;
    int j = 0;
    for (i = 0; j < k; i = i2) {
      View view = this.H[j];
      if (paramc.k == null) {
        if (i1) {
          b(view);
        } else {
          c(view, 0, false);
        } 
      } else if (i1) {
        c(view, -1, true);
      } else {
        c(view, 0, true);
      } 
      Rect rect = this.L;
      RecyclerView recyclerView = this.b;
      if (recyclerView == null) {
        rect.set(0, 0, 0, 0);
      } else {
        rect.set(recyclerView.L(view));
      } 
      x1(view, i4, false);
      i3 = this.r.c(view);
      i2 = i;
      if (i3 > i)
        i2 = i3; 
      b b1 = (b)view.getLayoutParams();
      float f2 = this.r.d(view) * 1.0F / b1.f;
      float f1 = f;
      if (f2 > f)
        f1 = f2; 
      j++;
      f = f1;
    } 
    j = i;
    if (m) {
      r1(Math.max(Math.round(f * this.F), n));
      m = 0;
      i = 0;
      while (true) {
        j = i;
        if (m < k) {
          View view = this.H[m];
          x1(view, 1073741824, true);
          n = this.r.c(view);
          j = i;
          if (n > i)
            j = n; 
          m++;
          i = j;
          continue;
        } 
        break;
      } 
    } 
    for (i = 0; i < k; i++) {
      View view = this.H[i];
      if (this.r.c(view) != j) {
        b b1 = (b)view.getLayoutParams();
        Rect rect = b1.b;
        n = rect.top + rect.bottom + b1.topMargin + b1.bottomMargin;
        m = rect.left + rect.right + b1.leftMargin + b1.rightMargin;
        i1 = t1(b1.e, b1.f);
        if (this.p == 1) {
          m = RecyclerView.l.y(i1, 1073741824, m, b1.width, false);
          n = View.MeasureSpec.makeMeasureSpec(j - n, 1073741824);
        } else {
          m = View.MeasureSpec.makeMeasureSpec(j - m, 1073741824);
          n = RecyclerView.l.y(i1, 1073741824, n, b1.height, false);
        } 
        y1(view, m, n, true);
      } 
    } 
    paramb.a = j;
    if (this.p == 1) {
      if (paramc.f == -1) {
        i = paramc.b;
        m = i - j;
        j = i;
        i = m;
      } else {
        i = paramc.b;
        j += i;
      } 
      m = 0;
      n = 0;
    } else {
      if (paramc.f == -1) {
        i = paramc.b;
        j = i - j;
      } else {
        i = paramc.b;
        m = j + i;
        j = i;
        i = m;
      } 
      i2 = 0;
      m = i;
      i1 = 0;
      n = j;
      i = i2;
      j = i1;
    } 
    int i1 = 0;
    while (true) {
      View view;
      if (i1 < k) {
        view = this.H[i1];
        b b1 = (b)view.getLayoutParams();
        if (this.p == 1) {
          if (e1()) {
            m = N() + this.G[this.F - b1.e];
            n = m - this.r.d(view);
          } else {
            m = N() + this.G[b1.e];
            n = this.r.d(view);
            i2 = m;
            m = n + m;
            n = j;
            j = i;
            i = i2;
            W(view, i, j, m, n);
          } 
        } else {
          i = P();
          i = this.G[b1.e] + i;
          j = this.r.d(view) + i;
        } 
        i2 = j;
        j = i;
        i = n;
        n = i2;
      } else {
        break;
      } 
      W(view, i, j, m, n);
    } 
    Arrays.fill((Object[])this.H, (Object)null);
  }
  
  public boolean g(RecyclerView.m paramm) {
    return paramm instanceof b;
  }
  
  public void g0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    this.K.a.clear();
    this.K.b.clear();
  }
  
  public void g1(RecyclerView.r paramr, RecyclerView.w paramw, LinearLayoutManager.a parama, int paramInt) {
    A1();
    if (paramw.b() > 0 && !paramw.g) {
      if (paramInt == 1) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      int i = v1(paramr, paramw, parama.b);
      if (paramInt != 0) {
        while (i > 0) {
          paramInt = parama.b;
          if (paramInt > 0) {
            parama.b = --paramInt;
            i = v1(paramr, paramw, paramInt);
          } 
        } 
      } else {
        int j = paramw.b();
        paramInt = parama.b;
        while (paramInt < j - 1) {
          int m = paramInt + 1;
          int k = v1(paramr, paramw, m);
          if (k > i) {
            paramInt = m;
            i = k;
          } 
        } 
        parama.b = paramInt;
      } 
    } 
    s1();
  }
  
  public void h0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.K.a.clear();
    this.K.b.clear();
  }
  
  public void i0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    this.K.a.clear();
    this.K.b.clear();
  }
  
  public void j0(RecyclerView.r paramr, RecyclerView.w paramw) {
    if (paramw.g) {
      int j = x();
      for (int i = 0; i < j; i++) {
        b b = (b)w(i).getLayoutParams();
        int k = b.a();
        this.I.put(k, b.f);
        this.J.put(k, b.e);
      } 
    } 
    super.j0(paramr, paramw);
    this.I.clear();
    this.J.clear();
  }
  
  public void k0(RecyclerView.w paramw) {
    this.z = null;
    this.x = -1;
    this.y = Integer.MIN_VALUE;
    this.A.d();
    this.E = false;
  }
  
  public int l(RecyclerView.w paramw) {
    return M0(paramw);
  }
  
  public int m(RecyclerView.w paramw) {
    return N0(paramw);
  }
  
  public void n1(boolean paramBoolean) {
    if (!paramBoolean) {
      d(null);
      if (!this.v)
        return; 
      this.v = false;
      u0();
      return;
    } 
    throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
  }
  
  public int o(RecyclerView.w paramw) {
    return M0(paramw);
  }
  
  public int p(RecyclerView.w paramw) {
    return N0(paramw);
  }
  
  public final void r1(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield G : [I
    //   4: astore #9
    //   6: aload_0
    //   7: getfield F : I
    //   10: istore #6
    //   12: iconst_1
    //   13: istore_3
    //   14: aload #9
    //   16: ifnull -> 45
    //   19: aload #9
    //   21: arraylength
    //   22: iload #6
    //   24: iconst_1
    //   25: iadd
    //   26: if_icmpne -> 45
    //   29: aload #9
    //   31: astore #8
    //   33: aload #9
    //   35: aload #9
    //   37: arraylength
    //   38: iconst_1
    //   39: isub
    //   40: iaload
    //   41: iload_1
    //   42: if_icmpeq -> 53
    //   45: iload #6
    //   47: iconst_1
    //   48: iadd
    //   49: newarray int
    //   51: astore #8
    //   53: iconst_0
    //   54: istore #4
    //   56: aload #8
    //   58: iconst_0
    //   59: iconst_0
    //   60: iastore
    //   61: iload_1
    //   62: iload #6
    //   64: idiv
    //   65: istore #5
    //   67: iload_1
    //   68: iload #6
    //   70: irem
    //   71: istore #7
    //   73: iconst_0
    //   74: istore_2
    //   75: iload #4
    //   77: istore_1
    //   78: iload_3
    //   79: iload #6
    //   81: if_icmpgt -> 137
    //   84: iload_1
    //   85: iload #7
    //   87: iadd
    //   88: istore_1
    //   89: iload_1
    //   90: ifle -> 116
    //   93: iload #6
    //   95: iload_1
    //   96: isub
    //   97: iload #7
    //   99: if_icmpge -> 116
    //   102: iload #5
    //   104: iconst_1
    //   105: iadd
    //   106: istore #4
    //   108: iload_1
    //   109: iload #6
    //   111: isub
    //   112: istore_1
    //   113: goto -> 120
    //   116: iload #5
    //   118: istore #4
    //   120: iload_2
    //   121: iload #4
    //   123: iadd
    //   124: istore_2
    //   125: aload #8
    //   127: iload_3
    //   128: iload_2
    //   129: iastore
    //   130: iload_3
    //   131: iconst_1
    //   132: iadd
    //   133: istore_3
    //   134: goto -> 78
    //   137: aload_0
    //   138: aload #8
    //   140: putfield G : [I
    //   143: return
  }
  
  public final void s1() {
    View[] arrayOfView = this.H;
    if (arrayOfView == null || arrayOfView.length != this.F)
      this.H = new View[this.F]; 
  }
  
  public RecyclerView.m t() {
    return (this.p == 0) ? new b(-2, -1) : new b(-1, -2);
  }
  
  public int t1(int paramInt1, int paramInt2) {
    if (this.p == 1 && e1()) {
      int[] arrayOfInt1 = this.G;
      int i = this.F;
      return arrayOfInt1[i - paramInt1] - arrayOfInt1[i - paramInt1 - paramInt2];
    } 
    int[] arrayOfInt = this.G;
    return arrayOfInt[paramInt2 + paramInt1] - arrayOfInt[paramInt1];
  }
  
  public RecyclerView.m u(Context paramContext, AttributeSet paramAttributeSet) {
    return new b(paramContext, paramAttributeSet);
  }
  
  public final int u1(RecyclerView.r paramr, RecyclerView.w paramw, int paramInt) {
    if (!paramw.g)
      return this.K.a(paramInt, this.F); 
    int i = paramr.c(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. ");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    return this.K.a(i, this.F);
  }
  
  public RecyclerView.m v(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new b((ViewGroup.MarginLayoutParams)paramLayoutParams) : new b(paramLayoutParams);
  }
  
  public int v0(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    A1();
    s1();
    return (this.p == 1) ? 0 : l1(paramInt, paramr, paramw);
  }
  
  public final int v1(RecyclerView.r paramr, RecyclerView.w paramw, int paramInt) {
    if (!paramw.g) {
      c1 = this.K;
      int j = this.F;
      Objects.requireNonNull(c1);
      return paramInt % j;
    } 
    int i = this.J.get(paramInt, -1);
    if (i != -1)
      return i; 
    i = c1.c(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    c c1 = this.K;
    paramInt = this.F;
    Objects.requireNonNull(c1);
    return i % paramInt;
  }
  
  public final int w1(RecyclerView.r paramr, RecyclerView.w paramw, int paramInt) {
    if (!paramw.g) {
      Objects.requireNonNull(this.K);
      return 1;
    } 
    int i = this.I.get(paramInt, -1);
    if (i != -1)
      return i; 
    if (paramr.c(paramInt) == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 1;
    } 
    Objects.requireNonNull(this.K);
    return 1;
  }
  
  public int x0(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    A1();
    s1();
    return (this.p == 0) ? 0 : l1(paramInt, paramr, paramw);
  }
  
  public final void x1(View paramView, int paramInt, boolean paramBoolean) {
    b b = (b)paramView.getLayoutParams();
    Rect rect = b.b;
    int j = rect.top + rect.bottom + b.topMargin + b.bottomMargin;
    int i = rect.left + rect.right + b.leftMargin + b.rightMargin;
    int k = t1(b.e, b.f);
    if (this.p == 1) {
      i = RecyclerView.l.y(k, paramInt, i, b.width, false);
      paramInt = RecyclerView.l.y(this.r.l(), this.m, j, b.height, true);
    } else {
      paramInt = RecyclerView.l.y(k, paramInt, j, b.height, false);
      i = RecyclerView.l.y(this.r.l(), this.l, i, b.width, true);
    } 
    y1(paramView, i, paramInt, paramBoolean);
  }
  
  public final void y1(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    if (paramBoolean) {
      paramBoolean = F0(paramView, paramInt1, paramInt2, m);
    } else {
      paramBoolean = D0(paramView, paramInt1, paramInt2, m);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public int z(RecyclerView.r paramr, RecyclerView.w paramw) {
    return (this.p == 1) ? this.F : ((paramw.b() < 1) ? 0 : (u1(paramr, paramw, paramw.b() - 1) + 1));
  }
  
  public void z1(int paramInt) {
    if (paramInt == this.F)
      return; 
    this.E = true;
    if (paramInt >= 1) {
      this.F = paramInt;
      this.K.a.clear();
      u0();
      return;
    } 
    throw new IllegalArgumentException(b0.a("Span count should be at least 1. Provided ", paramInt));
  }
  
  public static final class a extends c {}
  
  public static class b extends RecyclerView.m {
    public int e = -1;
    
    public int f = 0;
    
    public b(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public b(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public b(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public b(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static abstract class c {
    public final SparseIntArray a = new SparseIntArray();
    
    public final SparseIntArray b = new SparseIntArray();
    
    public int a(int param1Int1, int param1Int2) {
      int k = 0;
      int i = 0;
      int j;
      for (j = 0; k < param1Int1; j = m) {
        int m;
        int n = i + 1;
        if (n == param1Int2) {
          m = j + 1;
          i = 0;
        } else {
          i = n;
          m = j;
          if (n > param1Int2) {
            m = j + 1;
            i = 1;
          } 
        } 
        k++;
      } 
      param1Int1 = j;
      if (i + 1 > param1Int2)
        param1Int1 = j + 1; 
      return param1Int1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\GridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */