package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import java.util.Objects;

public class StaggeredGridLayoutManager extends RecyclerView.l implements RecyclerView.v.b {
  public int A;
  
  public d B;
  
  public int C;
  
  public boolean D;
  
  public boolean E;
  
  public e F;
  
  public final Rect G;
  
  public final b H;
  
  public boolean I;
  
  public int[] J;
  
  public final Runnable K;
  
  public int p = -1;
  
  public f[] q;
  
  public s r;
  
  public s s;
  
  public int t;
  
  public int u;
  
  public final n v;
  
  public boolean w;
  
  public boolean x;
  
  public BitSet y;
  
  public int z;
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    boolean bool = false;
    this.w = false;
    this.x = false;
    this.z = -1;
    this.A = Integer.MIN_VALUE;
    this.B = new d();
    this.C = 2;
    this.G = new Rect();
    this.H = new b(this);
    this.I = true;
    this.K = new a(this);
    RecyclerView.l.d d1 = RecyclerView.l.R(paramContext, paramAttributeSet, paramInt1, paramInt2);
    paramInt1 = d1.a;
    if (paramInt1 == 0 || paramInt1 == 1) {
      d(null);
      if (paramInt1 != this.t) {
        this.t = paramInt1;
        s s1 = this.r;
        this.r = this.s;
        this.s = s1;
        u0();
      } 
      paramInt1 = d1.b;
      d(null);
      if (paramInt1 != this.p) {
        this.B.a();
        u0();
        this.p = paramInt1;
        this.y = new BitSet(this.p);
        this.q = new f[this.p];
        for (paramInt1 = bool; paramInt1 < this.p; paramInt1++)
          this.q[paramInt1] = new f(this, paramInt1); 
        u0();
      } 
      boolean bool1 = d1.c;
      d(null);
      e e1 = this.F;
      if (e1 != null && e1.m != bool1)
        e1.m = bool1; 
      this.w = bool1;
      u0();
      this.v = new n();
      this.r = s.a(this, this.t);
      this.s = s.a(this, 1 - this.t);
      return;
    } 
    throw new IllegalArgumentException("invalid orientation.");
  }
  
  public void A0(Rect paramRect, int paramInt1, int paramInt2) {
    int i = N();
    i = O() + i;
    int j = P();
    j = M() + j;
    if (this.t == 1) {
      paramInt2 = RecyclerView.l.h(paramInt2, paramRect.height() + j, K());
      i = RecyclerView.l.h(paramInt1, this.u * this.p + i, L());
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      paramInt1 = RecyclerView.l.h(paramInt1, paramRect.width() + i, L());
      i = RecyclerView.l.h(paramInt2, this.u * this.p + j, K());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    RecyclerView.e(this.b, paramInt2, paramInt1);
  }
  
  public void G0(RecyclerView paramRecyclerView, RecyclerView.w paramw, int paramInt) {
    o o = new o(paramRecyclerView.getContext());
    o.a = paramInt;
    H0(o);
  }
  
  public boolean I0() {
    return (this.F == null);
  }
  
  public final int J0(int paramInt) {
    boolean bool;
    int i = x();
    byte b1 = -1;
    if (i == 0) {
      paramInt = b1;
      if (this.x)
        paramInt = 1; 
      return paramInt;
    } 
    if (paramInt < T0()) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool != this.x) ? -1 : 1;
  }
  
  public boolean K0() {
    if (x() != 0 && this.C != 0) {
      int i;
      if (!this.g)
        return false; 
      if (this.x) {
        i = U0();
        T0();
      } else {
        i = T0();
        U0();
      } 
      if (i == 0 && Y0() != null) {
        this.B.a();
        this.f = true;
        u0();
        return true;
      } 
    } 
    return false;
  }
  
  public final int L0(RecyclerView.w paramw) {
    return (x() == 0) ? 0 : y.a(paramw, this.r, Q0(this.I ^ true), P0(this.I ^ true), this, this.I);
  }
  
  public final int M0(RecyclerView.w paramw) {
    return (x() == 0) ? 0 : y.b(paramw, this.r, Q0(this.I ^ true), P0(this.I ^ true), this, this.I, this.x);
  }
  
  public final int N0(RecyclerView.w paramw) {
    return (x() == 0) ? 0 : y.c(paramw, this.r, Q0(this.I ^ true), P0(this.I ^ true), this, this.I);
  }
  
  public final int O0(RecyclerView.r paramr, n paramn, RecyclerView.w paramw) {
    int j;
    int k;
    this.y.set(0, this.p, true);
    if (this.v.i) {
      if (paramn.e == 1) {
        j = Integer.MAX_VALUE;
      } else {
        j = Integer.MIN_VALUE;
      } 
    } else {
      int m;
      if (paramn.e == 1) {
        m = paramn.g + paramn.b;
      } else {
        m = paramn.f - paramn.b;
      } 
      j = m;
    } 
    k1(paramn.e, j);
    if (this.x) {
      k = this.r.g();
    } else {
      k = this.r.k();
    } 
    int i = 0;
    while (true) {
      int m = paramn.c;
      if (m >= 0 && m < paramw.b()) {
        m = 1;
      } else {
        m = 0;
      } 
      if (m != 0 && (this.v.i || !this.y.isEmpty())) {
        int i1;
        int i2;
        f f1;
        View view = (paramr.k(paramn.c, false, Long.MAX_VALUE)).a;
        paramn.c += paramn.d;
        c c = (c)view.getLayoutParams();
        int i3 = c.a();
        int[] arrayOfInt = this.B.a;
        if (arrayOfInt == null || i3 >= arrayOfInt.length) {
          i = -1;
        } else {
          i = arrayOfInt[i3];
        } 
        if (i == -1) {
          m = 1;
        } else {
          m = 0;
        } 
        if (m != 0) {
          if (c1(paramn.e)) {
            i = this.p - 1;
            m = -1;
            i1 = -1;
          } else {
            m = this.p;
            i = 0;
            i1 = 1;
          } 
          i2 = paramn.e;
          int[] arrayOfInt1 = null;
          arrayOfInt = null;
          if (i2 == 1) {
            int i4 = this.r.k();
            i2 = Integer.MAX_VALUE;
            while (true) {
              arrayOfInt1 = arrayOfInt;
              if (i != m) {
                f1 = this.q[i];
                int i6 = f1.h(i4);
                int i5 = i2;
                if (i6 < i2) {
                  f f2 = f1;
                  i5 = i6;
                } 
                i += i1;
                i2 = i5;
                continue;
              } 
              break;
            } 
          } else {
            int i4 = this.r.g();
            i2 = Integer.MIN_VALUE;
            f f2 = f1;
            while (true) {
              f1 = f2;
              if (i != m) {
                f1 = this.q[i];
                int i6 = f1.k(i4);
                int i5 = i2;
                if (i6 > i2) {
                  f2 = f1;
                  i5 = i6;
                } 
                i += i1;
                i2 = i5;
                continue;
              } 
              break;
            } 
          } 
          d d1 = this.B;
          d1.b(i3);
          d1.a[i3] = f1.e;
        } else {
          f1 = this.q[i];
        } 
        c.e = f1;
        if (paramn.e == 1) {
          c(view, -1, false);
        } else {
          c(view, 0, false);
        } 
        if (this.t == 1) {
          i = RecyclerView.l.y(this.u, this.l, 0, c.width, false);
          m = this.o;
          i1 = this.m;
          i2 = P();
          a1(view, i, RecyclerView.l.y(m, i1, M() + i2, c.height, true), false);
        } else {
          i = this.n;
          m = this.l;
          i1 = N();
          a1(view, RecyclerView.l.y(i, m, O() + i1, c.width, true), RecyclerView.l.y(this.u, this.m, 0, c.height, false), false);
        } 
        if (paramn.e == 1) {
          m = f1.h(k);
          i1 = this.r.c(view);
          i = m;
          m = i1 + m;
        } else {
          i = f1.k(k);
          i1 = this.r.c(view);
          m = i;
          i -= i1;
        } 
        if (paramn.e == 1) {
          c.e.a(view);
        } else {
          c.e.n(view);
        } 
        if (Z0() && this.t == 1) {
          i1 = this.s.g() - (this.p - 1 - f1.e) * this.u;
          i2 = i1 - this.s.c(view);
        } else {
          i1 = f1.e;
          i2 = this.u;
          i2 = this.s.k() + i1 * i2;
          i1 = this.s.c(view) + i2;
        } 
        if (this.t == 1) {
          W(view, i2, i, i1, m);
        } else {
          W(view, i, i2, m, i1);
        } 
        m1(f1, this.v.e, j);
        e1(paramr, this.v);
        if (this.v.h && view.hasFocusable())
          this.y.set(f1.e, false); 
        i = 1;
        continue;
      } 
      break;
    } 
    if (i == 0)
      e1(paramr, this.v); 
    if (this.v.e == -1) {
      i = W0(this.r.k());
      i = this.r.k() - i;
    } else {
      i = V0(this.r.g()) - this.r.g();
    } 
    return (i > 0) ? Math.min(paramn.b, i) : 0;
  }
  
  public View P0(boolean paramBoolean) {
    int j = this.r.k();
    int k = this.r.g();
    int i = x() - 1;
    View view;
    for (view = null; i >= 0; view = view1) {
      View view2 = w(i);
      int m = this.r.e(view2);
      int i1 = this.r.b(view2);
      View view1 = view;
      if (i1 > j)
        if (m >= k) {
          view1 = view;
        } else if (i1 > k) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i--;
    } 
    return view;
  }
  
  public View Q0(boolean paramBoolean) {
    int j = this.r.k();
    int k = this.r.g();
    int m = x();
    View view = null;
    int i = 0;
    while (i < m) {
      View view2 = w(i);
      int i1 = this.r.e(view2);
      View view1 = view;
      if (this.r.b(view2) > j)
        if (i1 >= k) {
          view1 = view;
        } else if (i1 < j) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i++;
      view = view1;
    } 
    return view;
  }
  
  public final void R0(RecyclerView.r paramr, RecyclerView.w paramw, boolean paramBoolean) {
    int i = V0(-2147483648);
    if (i == Integer.MIN_VALUE)
      return; 
    i = this.r.g() - i;
    if (i > 0) {
      i -= -i1(-i, paramr, paramw);
      if (paramBoolean && i > 0)
        this.r.p(i); 
    } 
  }
  
  public int S(RecyclerView.r paramr, RecyclerView.w paramw) {
    return (this.t == 0) ? this.p : super.S(paramr, paramw);
  }
  
  public final void S0(RecyclerView.r paramr, RecyclerView.w paramw, boolean paramBoolean) {
    int i = W0(2147483647);
    if (i == Integer.MAX_VALUE)
      return; 
    i -= this.r.k();
    if (i > 0) {
      i -= i1(i, paramr, paramw);
      if (paramBoolean && i > 0)
        this.r.p(-i); 
    } 
  }
  
  public int T0() {
    return (x() == 0) ? 0 : Q(w(0));
  }
  
  public boolean U() {
    return (this.C != 0);
  }
  
  public int U0() {
    int i = x();
    return (i == 0) ? 0 : Q(w(i - 1));
  }
  
  public final int V0(int paramInt) {
    int j = this.q[0].h(paramInt);
    int i = 1;
    while (i < this.p) {
      int m = this.q[i].h(paramInt);
      int k = j;
      if (m > j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public final int W0(int paramInt) {
    int j = this.q[0].k(paramInt);
    int i = 1;
    while (i < this.p) {
      int m = this.q[i].k(paramInt);
      int k = j;
      if (m < j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public void X(int paramInt) {
    super.X(paramInt);
    for (int i = 0; i < this.p; i++) {
      f f1 = this.q[i];
      int j = f1.b;
      if (j != Integer.MIN_VALUE)
        f1.b = j + paramInt; 
      j = f1.c;
      if (j != Integer.MIN_VALUE)
        f1.c = j + paramInt; 
    } 
  }
  
  public final void X0(int paramInt1, int paramInt2, int paramInt3) {
    if (this.x) {
      int j = U0();
    } else {
      int j = T0();
    } 
    if (paramInt3 == 8) {
      if (paramInt1 < paramInt2) {
        int j = paramInt2 + 1;
      } else {
        int j = paramInt1 + 1;
        int k = paramInt2;
        this.B.d(k);
      } 
    } else {
      int j = paramInt1 + paramInt2;
    } 
    int i = paramInt1;
    this.B.d(i);
  }
  
  public void Y(int paramInt) {
    super.Y(paramInt);
    for (int i = 0; i < this.p; i++) {
      f f1 = this.q[i];
      int j = f1.b;
      if (j != Integer.MIN_VALUE)
        f1.b = j + paramInt; 
      j = f1.c;
      if (j != Integer.MIN_VALUE)
        f1.c = j + paramInt; 
    } 
  }
  
  public View Y0() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual x : ()I
    //   4: iconst_1
    //   5: isub
    //   6: istore_1
    //   7: new java/util/BitSet
    //   10: dup
    //   11: aload_0
    //   12: getfield p : I
    //   15: invokespecial <init> : (I)V
    //   18: astore #7
    //   20: aload #7
    //   22: iconst_0
    //   23: aload_0
    //   24: getfield p : I
    //   27: iconst_1
    //   28: invokevirtual set : (IIZ)V
    //   31: aload_0
    //   32: getfield t : I
    //   35: istore_2
    //   36: iconst_m1
    //   37: istore #5
    //   39: iload_2
    //   40: iconst_1
    //   41: if_icmpne -> 56
    //   44: aload_0
    //   45: invokevirtual Z0 : ()Z
    //   48: ifeq -> 56
    //   51: iconst_1
    //   52: istore_2
    //   53: goto -> 58
    //   56: iconst_m1
    //   57: istore_2
    //   58: aload_0
    //   59: getfield x : Z
    //   62: ifeq -> 70
    //   65: iconst_m1
    //   66: istore_3
    //   67: goto -> 76
    //   70: iload_1
    //   71: iconst_1
    //   72: iadd
    //   73: istore_3
    //   74: iconst_0
    //   75: istore_1
    //   76: iload_1
    //   77: istore #4
    //   79: iload_1
    //   80: iload_3
    //   81: if_icmpge -> 90
    //   84: iconst_1
    //   85: istore #5
    //   87: iload_1
    //   88: istore #4
    //   90: iload #4
    //   92: iload_3
    //   93: if_icmpeq -> 480
    //   96: aload_0
    //   97: iload #4
    //   99: invokevirtual w : (I)Landroid/view/View;
    //   102: astore #8
    //   104: aload #8
    //   106: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   109: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   112: astore #9
    //   114: aload #7
    //   116: aload #9
    //   118: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   121: getfield e : I
    //   124: invokevirtual get : (I)Z
    //   127: ifeq -> 300
    //   130: aload #9
    //   132: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   135: astore #10
    //   137: aload_0
    //   138: getfield x : Z
    //   141: ifeq -> 215
    //   144: aload #10
    //   146: getfield c : I
    //   149: istore_1
    //   150: iload_1
    //   151: ldc -2147483648
    //   153: if_icmpeq -> 159
    //   156: goto -> 170
    //   159: aload #10
    //   161: invokevirtual b : ()V
    //   164: aload #10
    //   166: getfield c : I
    //   169: istore_1
    //   170: iload_1
    //   171: aload_0
    //   172: getfield r : Landroidx/recyclerview/widget/s;
    //   175: invokevirtual g : ()I
    //   178: if_icmpge -> 278
    //   181: aload #10
    //   183: getfield a : Ljava/util/ArrayList;
    //   186: astore #11
    //   188: aload #10
    //   190: aload #11
    //   192: aload #11
    //   194: invokevirtual size : ()I
    //   197: iconst_1
    //   198: isub
    //   199: invokevirtual get : (I)Ljava/lang/Object;
    //   202: checkcast android/view/View
    //   205: invokevirtual j : (Landroid/view/View;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   208: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   211: pop
    //   212: goto -> 273
    //   215: aload #10
    //   217: getfield b : I
    //   220: istore_1
    //   221: iload_1
    //   222: ldc -2147483648
    //   224: if_icmpeq -> 230
    //   227: goto -> 241
    //   230: aload #10
    //   232: invokevirtual c : ()V
    //   235: aload #10
    //   237: getfield b : I
    //   240: istore_1
    //   241: iload_1
    //   242: aload_0
    //   243: getfield r : Landroidx/recyclerview/widget/s;
    //   246: invokevirtual k : ()I
    //   249: if_icmple -> 278
    //   252: aload #10
    //   254: aload #10
    //   256: getfield a : Ljava/util/ArrayList;
    //   259: iconst_0
    //   260: invokevirtual get : (I)Ljava/lang/Object;
    //   263: checkcast android/view/View
    //   266: invokevirtual j : (Landroid/view/View;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   269: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   272: pop
    //   273: iconst_1
    //   274: istore_1
    //   275: goto -> 280
    //   278: iconst_0
    //   279: istore_1
    //   280: iload_1
    //   281: ifeq -> 287
    //   284: aload #8
    //   286: areturn
    //   287: aload #7
    //   289: aload #9
    //   291: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   294: getfield e : I
    //   297: invokevirtual clear : (I)V
    //   300: iload #4
    //   302: iload #5
    //   304: iadd
    //   305: istore_1
    //   306: iload_1
    //   307: iload_3
    //   308: if_icmpeq -> 470
    //   311: aload_0
    //   312: iload_1
    //   313: invokevirtual w : (I)Landroid/view/View;
    //   316: astore #10
    //   318: aload_0
    //   319: getfield x : Z
    //   322: ifeq -> 364
    //   325: aload_0
    //   326: getfield r : Landroidx/recyclerview/widget/s;
    //   329: aload #8
    //   331: invokevirtual b : (Landroid/view/View;)I
    //   334: istore_1
    //   335: aload_0
    //   336: getfield r : Landroidx/recyclerview/widget/s;
    //   339: aload #10
    //   341: invokevirtual b : (Landroid/view/View;)I
    //   344: istore #6
    //   346: iload_1
    //   347: iload #6
    //   349: if_icmpge -> 355
    //   352: aload #8
    //   354: areturn
    //   355: iload_1
    //   356: iload #6
    //   358: if_icmpne -> 405
    //   361: goto -> 400
    //   364: aload_0
    //   365: getfield r : Landroidx/recyclerview/widget/s;
    //   368: aload #8
    //   370: invokevirtual e : (Landroid/view/View;)I
    //   373: istore_1
    //   374: aload_0
    //   375: getfield r : Landroidx/recyclerview/widget/s;
    //   378: aload #10
    //   380: invokevirtual e : (Landroid/view/View;)I
    //   383: istore #6
    //   385: iload_1
    //   386: iload #6
    //   388: if_icmple -> 394
    //   391: aload #8
    //   393: areturn
    //   394: iload_1
    //   395: iload #6
    //   397: if_icmpne -> 405
    //   400: iconst_1
    //   401: istore_1
    //   402: goto -> 407
    //   405: iconst_0
    //   406: istore_1
    //   407: iload_1
    //   408: ifeq -> 470
    //   411: aload #10
    //   413: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   416: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   419: astore #10
    //   421: aload #9
    //   423: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   426: getfield e : I
    //   429: aload #10
    //   431: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   434: getfield e : I
    //   437: isub
    //   438: ifge -> 446
    //   441: iconst_1
    //   442: istore_1
    //   443: goto -> 448
    //   446: iconst_0
    //   447: istore_1
    //   448: iload_2
    //   449: ifge -> 458
    //   452: iconst_1
    //   453: istore #6
    //   455: goto -> 461
    //   458: iconst_0
    //   459: istore #6
    //   461: iload_1
    //   462: iload #6
    //   464: if_icmpeq -> 470
    //   467: aload #8
    //   469: areturn
    //   470: iload #4
    //   472: iload #5
    //   474: iadd
    //   475: istore #4
    //   477: goto -> 90
    //   480: aconst_null
    //   481: areturn
  }
  
  public void Z(RecyclerView paramRecyclerView, RecyclerView.r paramr) {
    Runnable runnable = this.K;
    RecyclerView recyclerView = this.b;
    if (recyclerView != null)
      recyclerView.removeCallbacks(runnable); 
    for (int i = 0; i < this.p; i++)
      this.q[i].d(); 
    paramRecyclerView.requestLayout();
  }
  
  public boolean Z0() {
    return (J() == 1);
  }
  
  public PointF a(int paramInt) {
    paramInt = J0(paramInt);
    PointF pointF = new PointF();
    if (paramInt == 0)
      return null; 
    if (this.t == 0) {
      pointF.x = paramInt;
      pointF.y = 0.0F;
      return pointF;
    } 
    pointF.x = 0.0F;
    pointF.y = paramInt;
    return pointF;
  }
  
  public View a0(View paramView, int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual x : ()I
    //   4: ifne -> 9
    //   7: aconst_null
    //   8: areturn
    //   9: aload_0
    //   10: aload_1
    //   11: invokevirtual r : (Landroid/view/View;)Landroid/view/View;
    //   14: astore_1
    //   15: aload_1
    //   16: ifnonnull -> 21
    //   19: aconst_null
    //   20: areturn
    //   21: aload_0
    //   22: invokevirtual h1 : ()V
    //   25: iload_2
    //   26: iconst_1
    //   27: if_icmpeq -> 132
    //   30: iload_2
    //   31: iconst_2
    //   32: if_icmpeq -> 111
    //   35: iload_2
    //   36: bipush #17
    //   38: if_icmpeq -> 95
    //   41: iload_2
    //   42: bipush #33
    //   44: if_icmpeq -> 84
    //   47: iload_2
    //   48: bipush #66
    //   50: if_icmpeq -> 74
    //   53: iload_2
    //   54: sipush #130
    //   57: if_icmpeq -> 63
    //   60: goto -> 105
    //   63: aload_0
    //   64: getfield t : I
    //   67: iconst_1
    //   68: if_icmpne -> 105
    //   71: goto -> 150
    //   74: aload_0
    //   75: getfield t : I
    //   78: ifne -> 105
    //   81: goto -> 150
    //   84: aload_0
    //   85: getfield t : I
    //   88: iconst_1
    //   89: if_icmpne -> 105
    //   92: goto -> 155
    //   95: aload_0
    //   96: getfield t : I
    //   99: ifne -> 105
    //   102: goto -> 155
    //   105: ldc -2147483648
    //   107: istore_2
    //   108: goto -> 157
    //   111: aload_0
    //   112: getfield t : I
    //   115: iconst_1
    //   116: if_icmpne -> 122
    //   119: goto -> 150
    //   122: aload_0
    //   123: invokevirtual Z0 : ()Z
    //   126: ifeq -> 150
    //   129: goto -> 155
    //   132: aload_0
    //   133: getfield t : I
    //   136: iconst_1
    //   137: if_icmpne -> 143
    //   140: goto -> 155
    //   143: aload_0
    //   144: invokevirtual Z0 : ()Z
    //   147: ifeq -> 155
    //   150: iconst_1
    //   151: istore_2
    //   152: goto -> 157
    //   155: iconst_m1
    //   156: istore_2
    //   157: iload_2
    //   158: ldc -2147483648
    //   160: if_icmpne -> 165
    //   163: aconst_null
    //   164: areturn
    //   165: aload_1
    //   166: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   169: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   172: astore #9
    //   174: aload #9
    //   176: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   179: pop
    //   180: aload #9
    //   182: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   185: astore #9
    //   187: iload_2
    //   188: iconst_1
    //   189: if_icmpne -> 201
    //   192: aload_0
    //   193: invokevirtual U0 : ()I
    //   196: istore #5
    //   198: goto -> 207
    //   201: aload_0
    //   202: invokevirtual T0 : ()I
    //   205: istore #5
    //   207: aload_0
    //   208: iload #5
    //   210: aload #4
    //   212: invokevirtual l1 : (ILandroidx/recyclerview/widget/RecyclerView$w;)V
    //   215: aload_0
    //   216: iload_2
    //   217: invokevirtual j1 : (I)V
    //   220: aload_0
    //   221: getfield v : Landroidx/recyclerview/widget/n;
    //   224: astore #10
    //   226: aload #10
    //   228: aload #10
    //   230: getfield d : I
    //   233: iload #5
    //   235: iadd
    //   236: putfield c : I
    //   239: aload #10
    //   241: aload_0
    //   242: getfield r : Landroidx/recyclerview/widget/s;
    //   245: invokevirtual l : ()I
    //   248: i2f
    //   249: ldc_w 0.33333334
    //   252: fmul
    //   253: f2i
    //   254: putfield b : I
    //   257: aload_0
    //   258: getfield v : Landroidx/recyclerview/widget/n;
    //   261: astore #10
    //   263: aload #10
    //   265: iconst_1
    //   266: putfield h : Z
    //   269: iconst_0
    //   270: istore #7
    //   272: aload #10
    //   274: iconst_0
    //   275: putfield a : Z
    //   278: aload_0
    //   279: aload_3
    //   280: aload #10
    //   282: aload #4
    //   284: invokevirtual O0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/n;Landroidx/recyclerview/widget/RecyclerView$w;)I
    //   287: pop
    //   288: aload_0
    //   289: aload_0
    //   290: getfield x : Z
    //   293: putfield D : Z
    //   296: aload #9
    //   298: iload #5
    //   300: iload_2
    //   301: invokevirtual i : (II)Landroid/view/View;
    //   304: astore_3
    //   305: aload_3
    //   306: ifnull -> 316
    //   309: aload_3
    //   310: aload_1
    //   311: if_acmpeq -> 316
    //   314: aload_3
    //   315: areturn
    //   316: aload_0
    //   317: iload_2
    //   318: invokevirtual c1 : (I)Z
    //   321: ifeq -> 371
    //   324: aload_0
    //   325: getfield p : I
    //   328: iconst_1
    //   329: isub
    //   330: istore #6
    //   332: iload #6
    //   334: iflt -> 417
    //   337: aload_0
    //   338: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   341: iload #6
    //   343: aaload
    //   344: iload #5
    //   346: iload_2
    //   347: invokevirtual i : (II)Landroid/view/View;
    //   350: astore_3
    //   351: aload_3
    //   352: ifnull -> 362
    //   355: aload_3
    //   356: aload_1
    //   357: if_acmpeq -> 362
    //   360: aload_3
    //   361: areturn
    //   362: iload #6
    //   364: iconst_1
    //   365: isub
    //   366: istore #6
    //   368: goto -> 332
    //   371: iconst_0
    //   372: istore #6
    //   374: iload #6
    //   376: aload_0
    //   377: getfield p : I
    //   380: if_icmpge -> 417
    //   383: aload_0
    //   384: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   387: iload #6
    //   389: aaload
    //   390: iload #5
    //   392: iload_2
    //   393: invokevirtual i : (II)Landroid/view/View;
    //   396: astore_3
    //   397: aload_3
    //   398: ifnull -> 408
    //   401: aload_3
    //   402: aload_1
    //   403: if_acmpeq -> 408
    //   406: aload_3
    //   407: areturn
    //   408: iload #6
    //   410: iconst_1
    //   411: iadd
    //   412: istore #6
    //   414: goto -> 374
    //   417: aload_0
    //   418: getfield w : Z
    //   421: istore #8
    //   423: iload_2
    //   424: iconst_m1
    //   425: if_icmpne -> 434
    //   428: iconst_1
    //   429: istore #5
    //   431: goto -> 437
    //   434: iconst_0
    //   435: istore #5
    //   437: iload #8
    //   439: iconst_1
    //   440: ixor
    //   441: iload #5
    //   443: if_icmpne -> 452
    //   446: iconst_1
    //   447: istore #5
    //   449: goto -> 455
    //   452: iconst_0
    //   453: istore #5
    //   455: iload #5
    //   457: ifeq -> 470
    //   460: aload #9
    //   462: invokevirtual e : ()I
    //   465: istore #6
    //   467: goto -> 477
    //   470: aload #9
    //   472: invokevirtual f : ()I
    //   475: istore #6
    //   477: aload_0
    //   478: iload #6
    //   480: invokevirtual s : (I)Landroid/view/View;
    //   483: astore_3
    //   484: aload_3
    //   485: ifnull -> 495
    //   488: aload_3
    //   489: aload_1
    //   490: if_acmpeq -> 495
    //   493: aload_3
    //   494: areturn
    //   495: iload #7
    //   497: istore #6
    //   499: aload_0
    //   500: iload_2
    //   501: invokevirtual c1 : (I)Z
    //   504: ifeq -> 585
    //   507: aload_0
    //   508: getfield p : I
    //   511: iconst_1
    //   512: isub
    //   513: istore_2
    //   514: iload_2
    //   515: iflt -> 650
    //   518: iload_2
    //   519: aload #9
    //   521: getfield e : I
    //   524: if_icmpne -> 530
    //   527: goto -> 578
    //   530: iload #5
    //   532: ifeq -> 549
    //   535: aload_0
    //   536: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   539: iload_2
    //   540: aaload
    //   541: invokevirtual e : ()I
    //   544: istore #6
    //   546: goto -> 560
    //   549: aload_0
    //   550: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   553: iload_2
    //   554: aaload
    //   555: invokevirtual f : ()I
    //   558: istore #6
    //   560: aload_0
    //   561: iload #6
    //   563: invokevirtual s : (I)Landroid/view/View;
    //   566: astore_3
    //   567: aload_3
    //   568: ifnull -> 578
    //   571: aload_3
    //   572: aload_1
    //   573: if_acmpeq -> 578
    //   576: aload_3
    //   577: areturn
    //   578: iload_2
    //   579: iconst_1
    //   580: isub
    //   581: istore_2
    //   582: goto -> 514
    //   585: iload #6
    //   587: aload_0
    //   588: getfield p : I
    //   591: if_icmpge -> 650
    //   594: iload #5
    //   596: ifeq -> 613
    //   599: aload_0
    //   600: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   603: iload #6
    //   605: aaload
    //   606: invokevirtual e : ()I
    //   609: istore_2
    //   610: goto -> 624
    //   613: aload_0
    //   614: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   617: iload #6
    //   619: aaload
    //   620: invokevirtual f : ()I
    //   623: istore_2
    //   624: aload_0
    //   625: iload_2
    //   626: invokevirtual s : (I)Landroid/view/View;
    //   629: astore_3
    //   630: aload_3
    //   631: ifnull -> 641
    //   634: aload_3
    //   635: aload_1
    //   636: if_acmpeq -> 641
    //   639: aload_3
    //   640: areturn
    //   641: iload #6
    //   643: iconst_1
    //   644: iadd
    //   645: istore #6
    //   647: goto -> 585
    //   650: aconst_null
    //   651: areturn
  }
  
  public final void a1(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    Rect rect1 = this.G;
    RecyclerView recyclerView = this.b;
    if (recyclerView == null) {
      rect1.set(0, 0, 0, 0);
    } else {
      rect1.set(recyclerView.L(paramView));
    } 
    c c = (c)paramView.getLayoutParams();
    int i = c.leftMargin;
    Rect rect2 = this.G;
    paramInt1 = n1(paramInt1, i + rect2.left, c.rightMargin + rect2.right);
    i = c.topMargin;
    rect2 = this.G;
    paramInt2 = n1(paramInt2, i + rect2.top, c.bottomMargin + rect2.bottom);
    if (paramBoolean) {
      paramBoolean = F0(paramView, paramInt1, paramInt2, c);
    } else {
      paramBoolean = D0(paramView, paramInt1, paramInt2, c);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public void b0(AccessibilityEvent paramAccessibilityEvent) {
    super.b0(paramAccessibilityEvent);
    if (x() > 0) {
      View view1 = Q0(false);
      View view2 = P0(false);
      if (view1 != null) {
        if (view2 == null)
          return; 
        int i = Q(view1);
        int j = Q(view2);
        if (i < j) {
          paramAccessibilityEvent.setFromIndex(i);
          paramAccessibilityEvent.setToIndex(j);
          return;
        } 
        paramAccessibilityEvent.setFromIndex(j);
        paramAccessibilityEvent.setToIndex(i);
      } 
    } 
  }
  
  public final void b1(RecyclerView.r paramr, RecyclerView.w paramw, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   4: astore #13
    //   6: aload_0
    //   7: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   10: ifnonnull -> 21
    //   13: aload_0
    //   14: getfield z : I
    //   17: iconst_m1
    //   18: if_icmpeq -> 39
    //   21: aload_2
    //   22: invokevirtual b : ()I
    //   25: ifne -> 39
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual o0 : (Landroidx/recyclerview/widget/RecyclerView$r;)V
    //   33: aload #13
    //   35: invokevirtual b : ()V
    //   38: return
    //   39: aload #13
    //   41: getfield e : Z
    //   44: istore #12
    //   46: iconst_1
    //   47: istore #9
    //   49: iload #12
    //   51: ifeq -> 78
    //   54: aload_0
    //   55: getfield z : I
    //   58: iconst_m1
    //   59: if_icmpne -> 78
    //   62: aload_0
    //   63: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   66: ifnull -> 72
    //   69: goto -> 78
    //   72: iconst_0
    //   73: istore #7
    //   75: goto -> 81
    //   78: iconst_1
    //   79: istore #7
    //   81: iload #7
    //   83: ifeq -> 1092
    //   86: aload #13
    //   88: invokevirtual b : ()V
    //   91: aload_0
    //   92: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   95: astore #14
    //   97: aload #14
    //   99: ifnull -> 434
    //   102: aload #14
    //   104: getfield h : I
    //   107: istore #6
    //   109: iload #6
    //   111: ifle -> 280
    //   114: iload #6
    //   116: aload_0
    //   117: getfield p : I
    //   120: if_icmpne -> 240
    //   123: iconst_0
    //   124: istore #6
    //   126: iload #6
    //   128: aload_0
    //   129: getfield p : I
    //   132: if_icmpge -> 280
    //   135: aload_0
    //   136: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   139: iload #6
    //   141: aaload
    //   142: invokevirtual d : ()V
    //   145: aload_0
    //   146: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   149: astore #14
    //   151: aload #14
    //   153: getfield i : [I
    //   156: iload #6
    //   158: iaload
    //   159: istore #10
    //   161: iload #10
    //   163: istore #8
    //   165: iload #10
    //   167: ldc -2147483648
    //   169: if_icmpeq -> 208
    //   172: aload #14
    //   174: getfield n : Z
    //   177: ifeq -> 192
    //   180: aload_0
    //   181: getfield r : Landroidx/recyclerview/widget/s;
    //   184: invokevirtual g : ()I
    //   187: istore #8
    //   189: goto -> 201
    //   192: aload_0
    //   193: getfield r : Landroidx/recyclerview/widget/s;
    //   196: invokevirtual k : ()I
    //   199: istore #8
    //   201: iload #10
    //   203: iload #8
    //   205: iadd
    //   206: istore #8
    //   208: aload_0
    //   209: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   212: iload #6
    //   214: aaload
    //   215: astore #14
    //   217: aload #14
    //   219: iload #8
    //   221: putfield b : I
    //   224: aload #14
    //   226: iload #8
    //   228: putfield c : I
    //   231: iload #6
    //   233: iconst_1
    //   234: iadd
    //   235: istore #6
    //   237: goto -> 126
    //   240: aload #14
    //   242: aconst_null
    //   243: putfield i : [I
    //   246: aload #14
    //   248: iconst_0
    //   249: putfield h : I
    //   252: aload #14
    //   254: iconst_0
    //   255: putfield j : I
    //   258: aload #14
    //   260: aconst_null
    //   261: putfield k : [I
    //   264: aload #14
    //   266: aconst_null
    //   267: putfield l : Ljava/util/List;
    //   270: aload #14
    //   272: aload #14
    //   274: getfield g : I
    //   277: putfield f : I
    //   280: aload_0
    //   281: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   284: astore #14
    //   286: aload_0
    //   287: aload #14
    //   289: getfield o : Z
    //   292: putfield E : Z
    //   295: aload #14
    //   297: getfield m : Z
    //   300: istore #12
    //   302: aload_0
    //   303: aconst_null
    //   304: invokevirtual d : (Ljava/lang/String;)V
    //   307: aload_0
    //   308: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   311: astore #14
    //   313: aload #14
    //   315: ifnull -> 335
    //   318: aload #14
    //   320: getfield m : Z
    //   323: iload #12
    //   325: if_icmpeq -> 335
    //   328: aload #14
    //   330: iload #12
    //   332: putfield m : Z
    //   335: aload_0
    //   336: iload #12
    //   338: putfield w : Z
    //   341: aload_0
    //   342: invokevirtual u0 : ()V
    //   345: aload_0
    //   346: invokevirtual h1 : ()V
    //   349: aload_0
    //   350: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   353: astore #14
    //   355: aload #14
    //   357: getfield f : I
    //   360: istore #6
    //   362: iload #6
    //   364: iconst_m1
    //   365: if_icmpeq -> 387
    //   368: aload_0
    //   369: iload #6
    //   371: putfield z : I
    //   374: aload #13
    //   376: aload #14
    //   378: getfield n : Z
    //   381: putfield c : Z
    //   384: goto -> 396
    //   387: aload #13
    //   389: aload_0
    //   390: getfield x : Z
    //   393: putfield c : Z
    //   396: aload #14
    //   398: getfield j : I
    //   401: iconst_1
    //   402: if_icmple -> 447
    //   405: aload_0
    //   406: getfield B : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   409: astore #15
    //   411: aload #15
    //   413: aload #14
    //   415: getfield k : [I
    //   418: putfield a : [I
    //   421: aload #15
    //   423: aload #14
    //   425: getfield l : Ljava/util/List;
    //   428: putfield b : Ljava/util/List;
    //   431: goto -> 447
    //   434: aload_0
    //   435: invokevirtual h1 : ()V
    //   438: aload #13
    //   440: aload_0
    //   441: getfield x : Z
    //   444: putfield c : Z
    //   447: aload_2
    //   448: getfield g : Z
    //   451: ifne -> 927
    //   454: aload_0
    //   455: getfield z : I
    //   458: istore #6
    //   460: iload #6
    //   462: iconst_m1
    //   463: if_icmpne -> 469
    //   466: goto -> 927
    //   469: iload #6
    //   471: iflt -> 916
    //   474: iload #6
    //   476: aload_2
    //   477: invokevirtual b : ()I
    //   480: if_icmplt -> 486
    //   483: goto -> 916
    //   486: aload_0
    //   487: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   490: astore #14
    //   492: aload #14
    //   494: ifnull -> 537
    //   497: aload #14
    //   499: getfield f : I
    //   502: iconst_m1
    //   503: if_icmpeq -> 537
    //   506: aload #14
    //   508: getfield h : I
    //   511: iconst_1
    //   512: if_icmpge -> 518
    //   515: goto -> 537
    //   518: aload #13
    //   520: ldc -2147483648
    //   522: putfield b : I
    //   525: aload #13
    //   527: aload_0
    //   528: getfield z : I
    //   531: putfield a : I
    //   534: goto -> 910
    //   537: aload_0
    //   538: aload_0
    //   539: getfield z : I
    //   542: invokevirtual s : (I)Landroid/view/View;
    //   545: astore #14
    //   547: aload #14
    //   549: ifnull -> 795
    //   552: aload_0
    //   553: getfield x : Z
    //   556: ifeq -> 568
    //   559: aload_0
    //   560: invokevirtual U0 : ()I
    //   563: istore #6
    //   565: goto -> 574
    //   568: aload_0
    //   569: invokevirtual T0 : ()I
    //   572: istore #6
    //   574: aload #13
    //   576: iload #6
    //   578: putfield a : I
    //   581: aload_0
    //   582: getfield A : I
    //   585: ldc -2147483648
    //   587: if_icmpeq -> 658
    //   590: aload #13
    //   592: getfield c : Z
    //   595: ifeq -> 628
    //   598: aload #13
    //   600: aload_0
    //   601: getfield r : Landroidx/recyclerview/widget/s;
    //   604: invokevirtual g : ()I
    //   607: aload_0
    //   608: getfield A : I
    //   611: isub
    //   612: aload_0
    //   613: getfield r : Landroidx/recyclerview/widget/s;
    //   616: aload #14
    //   618: invokevirtual b : (Landroid/view/View;)I
    //   621: isub
    //   622: putfield b : I
    //   625: goto -> 910
    //   628: aload #13
    //   630: aload_0
    //   631: getfield r : Landroidx/recyclerview/widget/s;
    //   634: invokevirtual k : ()I
    //   637: aload_0
    //   638: getfield A : I
    //   641: iadd
    //   642: aload_0
    //   643: getfield r : Landroidx/recyclerview/widget/s;
    //   646: aload #14
    //   648: invokevirtual e : (Landroid/view/View;)I
    //   651: isub
    //   652: putfield b : I
    //   655: goto -> 910
    //   658: aload_0
    //   659: getfield r : Landroidx/recyclerview/widget/s;
    //   662: aload #14
    //   664: invokevirtual c : (Landroid/view/View;)I
    //   667: aload_0
    //   668: getfield r : Landroidx/recyclerview/widget/s;
    //   671: invokevirtual l : ()I
    //   674: if_icmple -> 716
    //   677: aload #13
    //   679: getfield c : Z
    //   682: ifeq -> 697
    //   685: aload_0
    //   686: getfield r : Landroidx/recyclerview/widget/s;
    //   689: invokevirtual g : ()I
    //   692: istore #6
    //   694: goto -> 706
    //   697: aload_0
    //   698: getfield r : Landroidx/recyclerview/widget/s;
    //   701: invokevirtual k : ()I
    //   704: istore #6
    //   706: aload #13
    //   708: iload #6
    //   710: putfield b : I
    //   713: goto -> 910
    //   716: aload_0
    //   717: getfield r : Landroidx/recyclerview/widget/s;
    //   720: aload #14
    //   722: invokevirtual e : (Landroid/view/View;)I
    //   725: aload_0
    //   726: getfield r : Landroidx/recyclerview/widget/s;
    //   729: invokevirtual k : ()I
    //   732: isub
    //   733: istore #6
    //   735: iload #6
    //   737: ifge -> 751
    //   740: aload #13
    //   742: iload #6
    //   744: ineg
    //   745: putfield b : I
    //   748: goto -> 910
    //   751: aload_0
    //   752: getfield r : Landroidx/recyclerview/widget/s;
    //   755: invokevirtual g : ()I
    //   758: aload_0
    //   759: getfield r : Landroidx/recyclerview/widget/s;
    //   762: aload #14
    //   764: invokevirtual b : (Landroid/view/View;)I
    //   767: isub
    //   768: istore #6
    //   770: iload #6
    //   772: ifge -> 785
    //   775: aload #13
    //   777: iload #6
    //   779: putfield b : I
    //   782: goto -> 910
    //   785: aload #13
    //   787: ldc -2147483648
    //   789: putfield b : I
    //   792: goto -> 910
    //   795: aload_0
    //   796: getfield z : I
    //   799: istore #6
    //   801: aload #13
    //   803: iload #6
    //   805: putfield a : I
    //   808: aload_0
    //   809: getfield A : I
    //   812: istore #8
    //   814: iload #8
    //   816: ldc -2147483648
    //   818: if_icmpne -> 855
    //   821: aload_0
    //   822: iload #6
    //   824: invokevirtual J0 : (I)I
    //   827: iconst_1
    //   828: if_icmpne -> 837
    //   831: iconst_1
    //   832: istore #12
    //   834: goto -> 840
    //   837: iconst_0
    //   838: istore #12
    //   840: aload #13
    //   842: iload #12
    //   844: putfield c : Z
    //   847: aload #13
    //   849: invokevirtual a : ()V
    //   852: goto -> 904
    //   855: aload #13
    //   857: getfield c : Z
    //   860: ifeq -> 885
    //   863: aload #13
    //   865: aload #13
    //   867: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   870: getfield r : Landroidx/recyclerview/widget/s;
    //   873: invokevirtual g : ()I
    //   876: iload #8
    //   878: isub
    //   879: putfield b : I
    //   882: goto -> 904
    //   885: aload #13
    //   887: aload #13
    //   889: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   892: getfield r : Landroidx/recyclerview/widget/s;
    //   895: invokevirtual k : ()I
    //   898: iload #8
    //   900: iadd
    //   901: putfield b : I
    //   904: aload #13
    //   906: iconst_1
    //   907: putfield d : Z
    //   910: iconst_1
    //   911: istore #6
    //   913: goto -> 930
    //   916: aload_0
    //   917: iconst_m1
    //   918: putfield z : I
    //   921: aload_0
    //   922: ldc -2147483648
    //   924: putfield A : I
    //   927: iconst_0
    //   928: istore #6
    //   930: iload #6
    //   932: ifeq -> 938
    //   935: goto -> 1086
    //   938: aload_0
    //   939: getfield D : Z
    //   942: ifeq -> 1007
    //   945: aload_2
    //   946: invokevirtual b : ()I
    //   949: istore #11
    //   951: aload_0
    //   952: invokevirtual x : ()I
    //   955: istore #6
    //   957: iload #6
    //   959: iconst_1
    //   960: isub
    //   961: istore #8
    //   963: iload #8
    //   965: iflt -> 1069
    //   968: aload_0
    //   969: aload_0
    //   970: iload #8
    //   972: invokevirtual w : (I)Landroid/view/View;
    //   975: invokevirtual Q : (Landroid/view/View;)I
    //   978: istore #10
    //   980: iload #8
    //   982: istore #6
    //   984: iload #10
    //   986: iflt -> 957
    //   989: iload #8
    //   991: istore #6
    //   993: iload #10
    //   995: iload #11
    //   997: if_icmpge -> 957
    //   1000: iload #10
    //   1002: istore #6
    //   1004: goto -> 1072
    //   1007: aload_2
    //   1008: invokevirtual b : ()I
    //   1011: istore #10
    //   1013: aload_0
    //   1014: invokevirtual x : ()I
    //   1017: istore #11
    //   1019: iconst_0
    //   1020: istore #6
    //   1022: iload #6
    //   1024: iload #11
    //   1026: if_icmpge -> 1069
    //   1029: aload_0
    //   1030: aload_0
    //   1031: iload #6
    //   1033: invokevirtual w : (I)Landroid/view/View;
    //   1036: invokevirtual Q : (Landroid/view/View;)I
    //   1039: istore #8
    //   1041: iload #8
    //   1043: iflt -> 1060
    //   1046: iload #8
    //   1048: iload #10
    //   1050: if_icmpge -> 1060
    //   1053: iload #8
    //   1055: istore #6
    //   1057: goto -> 1072
    //   1060: iload #6
    //   1062: iconst_1
    //   1063: iadd
    //   1064: istore #6
    //   1066: goto -> 1022
    //   1069: iconst_0
    //   1070: istore #6
    //   1072: aload #13
    //   1074: iload #6
    //   1076: putfield a : I
    //   1079: aload #13
    //   1081: ldc -2147483648
    //   1083: putfield b : I
    //   1086: aload #13
    //   1088: iconst_1
    //   1089: putfield e : Z
    //   1092: aload_0
    //   1093: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   1096: ifnonnull -> 1143
    //   1099: aload_0
    //   1100: getfield z : I
    //   1103: iconst_m1
    //   1104: if_icmpne -> 1143
    //   1107: aload #13
    //   1109: getfield c : Z
    //   1112: aload_0
    //   1113: getfield D : Z
    //   1116: if_icmpne -> 1130
    //   1119: aload_0
    //   1120: invokevirtual Z0 : ()Z
    //   1123: aload_0
    //   1124: getfield E : Z
    //   1127: if_icmpeq -> 1143
    //   1130: aload_0
    //   1131: getfield B : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   1134: invokevirtual a : ()V
    //   1137: aload #13
    //   1139: iconst_1
    //   1140: putfield d : Z
    //   1143: aload_0
    //   1144: invokevirtual x : ()I
    //   1147: ifle -> 1582
    //   1150: aload_0
    //   1151: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   1154: astore #14
    //   1156: aload #14
    //   1158: ifnull -> 1170
    //   1161: aload #14
    //   1163: getfield h : I
    //   1166: iconst_1
    //   1167: if_icmpge -> 1582
    //   1170: aload #13
    //   1172: getfield d : Z
    //   1175: ifeq -> 1246
    //   1178: iconst_0
    //   1179: istore #6
    //   1181: iload #6
    //   1183: aload_0
    //   1184: getfield p : I
    //   1187: if_icmpge -> 1582
    //   1190: aload_0
    //   1191: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1194: iload #6
    //   1196: aaload
    //   1197: invokevirtual d : ()V
    //   1200: aload #13
    //   1202: getfield b : I
    //   1205: istore #7
    //   1207: iload #7
    //   1209: ldc -2147483648
    //   1211: if_icmpeq -> 1237
    //   1214: aload_0
    //   1215: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1218: iload #6
    //   1220: aaload
    //   1221: astore #14
    //   1223: aload #14
    //   1225: iload #7
    //   1227: putfield b : I
    //   1230: aload #14
    //   1232: iload #7
    //   1234: putfield c : I
    //   1237: iload #6
    //   1239: iconst_1
    //   1240: iadd
    //   1241: istore #6
    //   1243: goto -> 1181
    //   1246: iload #7
    //   1248: ifne -> 1325
    //   1251: aload_0
    //   1252: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1255: getfield f : [I
    //   1258: ifnonnull -> 1264
    //   1261: goto -> 1325
    //   1264: iconst_0
    //   1265: istore #6
    //   1267: iload #6
    //   1269: aload_0
    //   1270: getfield p : I
    //   1273: if_icmpge -> 1582
    //   1276: aload_0
    //   1277: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1280: iload #6
    //   1282: aaload
    //   1283: astore #14
    //   1285: aload #14
    //   1287: invokevirtual d : ()V
    //   1290: aload_0
    //   1291: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1294: getfield f : [I
    //   1297: iload #6
    //   1299: iaload
    //   1300: istore #7
    //   1302: aload #14
    //   1304: iload #7
    //   1306: putfield b : I
    //   1309: aload #14
    //   1311: iload #7
    //   1313: putfield c : I
    //   1316: iload #6
    //   1318: iconst_1
    //   1319: iadd
    //   1320: istore #6
    //   1322: goto -> 1267
    //   1325: iconst_0
    //   1326: istore #7
    //   1328: iload #7
    //   1330: aload_0
    //   1331: getfield p : I
    //   1334: if_icmpge -> 1486
    //   1337: aload_0
    //   1338: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1341: iload #7
    //   1343: aaload
    //   1344: astore #14
    //   1346: aload_0
    //   1347: getfield x : Z
    //   1350: istore #12
    //   1352: aload #13
    //   1354: getfield b : I
    //   1357: istore #10
    //   1359: iload #12
    //   1361: ifeq -> 1376
    //   1364: aload #14
    //   1366: ldc -2147483648
    //   1368: invokevirtual h : (I)I
    //   1371: istore #6
    //   1373: goto -> 1385
    //   1376: aload #14
    //   1378: ldc -2147483648
    //   1380: invokevirtual k : (I)I
    //   1383: istore #6
    //   1385: aload #14
    //   1387: invokevirtual d : ()V
    //   1390: iload #6
    //   1392: ldc -2147483648
    //   1394: if_icmpne -> 1400
    //   1397: goto -> 1477
    //   1400: iload #12
    //   1402: ifeq -> 1421
    //   1405: iload #6
    //   1407: aload #14
    //   1409: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1412: getfield r : Landroidx/recyclerview/widget/s;
    //   1415: invokevirtual g : ()I
    //   1418: if_icmplt -> 1477
    //   1421: iload #12
    //   1423: ifne -> 1445
    //   1426: iload #6
    //   1428: aload #14
    //   1430: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1433: getfield r : Landroidx/recyclerview/widget/s;
    //   1436: invokevirtual k : ()I
    //   1439: if_icmple -> 1445
    //   1442: goto -> 1477
    //   1445: iload #6
    //   1447: istore #8
    //   1449: iload #10
    //   1451: ldc -2147483648
    //   1453: if_icmpeq -> 1463
    //   1456: iload #6
    //   1458: iload #10
    //   1460: iadd
    //   1461: istore #8
    //   1463: aload #14
    //   1465: iload #8
    //   1467: putfield c : I
    //   1470: aload #14
    //   1472: iload #8
    //   1474: putfield b : I
    //   1477: iload #7
    //   1479: iconst_1
    //   1480: iadd
    //   1481: istore #7
    //   1483: goto -> 1328
    //   1486: aload_0
    //   1487: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1490: astore #14
    //   1492: aload_0
    //   1493: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1496: astore #15
    //   1498: aload #14
    //   1500: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1503: pop
    //   1504: aload #15
    //   1506: arraylength
    //   1507: istore #7
    //   1509: aload #14
    //   1511: getfield f : [I
    //   1514: astore #16
    //   1516: aload #16
    //   1518: ifnull -> 1529
    //   1521: aload #16
    //   1523: arraylength
    //   1524: iload #7
    //   1526: if_icmpge -> 1545
    //   1529: aload #14
    //   1531: aload #14
    //   1533: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1536: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1539: arraylength
    //   1540: newarray int
    //   1542: putfield f : [I
    //   1545: iconst_0
    //   1546: istore #6
    //   1548: iload #6
    //   1550: iload #7
    //   1552: if_icmpge -> 1582
    //   1555: aload #14
    //   1557: getfield f : [I
    //   1560: iload #6
    //   1562: aload #15
    //   1564: iload #6
    //   1566: aaload
    //   1567: ldc -2147483648
    //   1569: invokevirtual k : (I)I
    //   1572: iastore
    //   1573: iload #6
    //   1575: iconst_1
    //   1576: iadd
    //   1577: istore #6
    //   1579: goto -> 1548
    //   1582: aload_0
    //   1583: aload_1
    //   1584: invokevirtual q : (Landroidx/recyclerview/widget/RecyclerView$r;)V
    //   1587: aload_0
    //   1588: getfield v : Landroidx/recyclerview/widget/n;
    //   1591: iconst_0
    //   1592: putfield a : Z
    //   1595: aload_0
    //   1596: getfield s : Landroidx/recyclerview/widget/s;
    //   1599: invokevirtual l : ()I
    //   1602: istore #6
    //   1604: aload_0
    //   1605: iload #6
    //   1607: aload_0
    //   1608: getfield p : I
    //   1611: idiv
    //   1612: putfield u : I
    //   1615: iload #6
    //   1617: aload_0
    //   1618: getfield s : Landroidx/recyclerview/widget/s;
    //   1621: invokevirtual i : ()I
    //   1624: invokestatic makeMeasureSpec : (II)I
    //   1627: pop
    //   1628: aload_0
    //   1629: aload #13
    //   1631: getfield a : I
    //   1634: aload_2
    //   1635: invokevirtual l1 : (ILandroidx/recyclerview/widget/RecyclerView$w;)V
    //   1638: aload #13
    //   1640: getfield c : Z
    //   1643: ifeq -> 1701
    //   1646: aload_0
    //   1647: iconst_m1
    //   1648: invokevirtual j1 : (I)V
    //   1651: aload_0
    //   1652: aload_1
    //   1653: aload_0
    //   1654: getfield v : Landroidx/recyclerview/widget/n;
    //   1657: aload_2
    //   1658: invokevirtual O0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/n;Landroidx/recyclerview/widget/RecyclerView$w;)I
    //   1661: pop
    //   1662: aload_0
    //   1663: iconst_1
    //   1664: invokevirtual j1 : (I)V
    //   1667: aload_0
    //   1668: getfield v : Landroidx/recyclerview/widget/n;
    //   1671: astore #14
    //   1673: aload #14
    //   1675: aload #13
    //   1677: getfield a : I
    //   1680: aload #14
    //   1682: getfield d : I
    //   1685: iadd
    //   1686: putfield c : I
    //   1689: aload_0
    //   1690: aload_1
    //   1691: aload #14
    //   1693: aload_2
    //   1694: invokevirtual O0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/n;Landroidx/recyclerview/widget/RecyclerView$w;)I
    //   1697: pop
    //   1698: goto -> 1753
    //   1701: aload_0
    //   1702: iconst_1
    //   1703: invokevirtual j1 : (I)V
    //   1706: aload_0
    //   1707: aload_1
    //   1708: aload_0
    //   1709: getfield v : Landroidx/recyclerview/widget/n;
    //   1712: aload_2
    //   1713: invokevirtual O0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/n;Landroidx/recyclerview/widget/RecyclerView$w;)I
    //   1716: pop
    //   1717: aload_0
    //   1718: iconst_m1
    //   1719: invokevirtual j1 : (I)V
    //   1722: aload_0
    //   1723: getfield v : Landroidx/recyclerview/widget/n;
    //   1726: astore #14
    //   1728: aload #14
    //   1730: aload #13
    //   1732: getfield a : I
    //   1735: aload #14
    //   1737: getfield d : I
    //   1740: iadd
    //   1741: putfield c : I
    //   1744: aload_0
    //   1745: aload_1
    //   1746: aload #14
    //   1748: aload_2
    //   1749: invokevirtual O0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/n;Landroidx/recyclerview/widget/RecyclerView$w;)I
    //   1752: pop
    //   1753: aload_0
    //   1754: getfield s : Landroidx/recyclerview/widget/s;
    //   1757: invokevirtual i : ()I
    //   1760: ldc_w 1073741824
    //   1763: if_icmpne -> 1769
    //   1766: goto -> 2098
    //   1769: fconst_0
    //   1770: fstore #4
    //   1772: aload_0
    //   1773: invokevirtual x : ()I
    //   1776: istore #8
    //   1778: iconst_0
    //   1779: istore #6
    //   1781: iload #6
    //   1783: iload #8
    //   1785: if_icmpge -> 1849
    //   1788: aload_0
    //   1789: iload #6
    //   1791: invokevirtual w : (I)Landroid/view/View;
    //   1794: astore #14
    //   1796: aload_0
    //   1797: getfield s : Landroidx/recyclerview/widget/s;
    //   1800: aload #14
    //   1802: invokevirtual c : (Landroid/view/View;)I
    //   1805: i2f
    //   1806: fstore #5
    //   1808: fload #5
    //   1810: fload #4
    //   1812: fcmpg
    //   1813: ifge -> 1819
    //   1816: goto -> 1840
    //   1819: aload #14
    //   1821: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1824: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   1827: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1830: pop
    //   1831: fload #4
    //   1833: fload #5
    //   1835: invokestatic max : (FF)F
    //   1838: fstore #4
    //   1840: iload #6
    //   1842: iconst_1
    //   1843: iadd
    //   1844: istore #6
    //   1846: goto -> 1781
    //   1849: aload_0
    //   1850: getfield u : I
    //   1853: istore #10
    //   1855: fload #4
    //   1857: aload_0
    //   1858: getfield p : I
    //   1861: i2f
    //   1862: fmul
    //   1863: invokestatic round : (F)I
    //   1866: istore #7
    //   1868: iload #7
    //   1870: istore #6
    //   1872: aload_0
    //   1873: getfield s : Landroidx/recyclerview/widget/s;
    //   1876: invokevirtual i : ()I
    //   1879: ldc -2147483648
    //   1881: if_icmpne -> 1898
    //   1884: iload #7
    //   1886: aload_0
    //   1887: getfield s : Landroidx/recyclerview/widget/s;
    //   1890: invokevirtual l : ()I
    //   1893: invokestatic min : (II)I
    //   1896: istore #6
    //   1898: aload_0
    //   1899: iload #6
    //   1901: aload_0
    //   1902: getfield p : I
    //   1905: idiv
    //   1906: putfield u : I
    //   1909: iload #6
    //   1911: aload_0
    //   1912: getfield s : Landroidx/recyclerview/widget/s;
    //   1915: invokevirtual i : ()I
    //   1918: invokestatic makeMeasureSpec : (II)I
    //   1921: pop
    //   1922: aload_0
    //   1923: getfield u : I
    //   1926: iload #10
    //   1928: if_icmpne -> 1934
    //   1931: goto -> 2098
    //   1934: iconst_0
    //   1935: istore #6
    //   1937: iload #6
    //   1939: iload #8
    //   1941: if_icmpge -> 2098
    //   1944: aload_0
    //   1945: iload #6
    //   1947: invokevirtual w : (I)Landroid/view/View;
    //   1950: astore #14
    //   1952: aload #14
    //   1954: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1957: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   1960: astore #15
    //   1962: aload #15
    //   1964: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1967: pop
    //   1968: aload_0
    //   1969: invokevirtual Z0 : ()Z
    //   1972: ifeq -> 2032
    //   1975: aload_0
    //   1976: getfield t : I
    //   1979: iconst_1
    //   1980: if_icmpne -> 2032
    //   1983: aload_0
    //   1984: getfield p : I
    //   1987: istore #7
    //   1989: aload #15
    //   1991: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1994: getfield e : I
    //   1997: istore #11
    //   1999: aload #14
    //   2001: iload #7
    //   2003: iconst_1
    //   2004: isub
    //   2005: iload #11
    //   2007: isub
    //   2008: ineg
    //   2009: aload_0
    //   2010: getfield u : I
    //   2013: imul
    //   2014: iload #7
    //   2016: iconst_1
    //   2017: isub
    //   2018: iload #11
    //   2020: isub
    //   2021: ineg
    //   2022: iload #10
    //   2024: imul
    //   2025: isub
    //   2026: invokevirtual offsetLeftAndRight : (I)V
    //   2029: goto -> 2089
    //   2032: aload #15
    //   2034: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   2037: getfield e : I
    //   2040: istore #11
    //   2042: aload_0
    //   2043: getfield u : I
    //   2046: iload #11
    //   2048: imul
    //   2049: istore #7
    //   2051: iload #11
    //   2053: iload #10
    //   2055: imul
    //   2056: istore #11
    //   2058: aload_0
    //   2059: getfield t : I
    //   2062: iconst_1
    //   2063: if_icmpne -> 2079
    //   2066: aload #14
    //   2068: iload #7
    //   2070: iload #11
    //   2072: isub
    //   2073: invokevirtual offsetLeftAndRight : (I)V
    //   2076: goto -> 2089
    //   2079: aload #14
    //   2081: iload #7
    //   2083: iload #11
    //   2085: isub
    //   2086: invokevirtual offsetTopAndBottom : (I)V
    //   2089: iload #6
    //   2091: iconst_1
    //   2092: iadd
    //   2093: istore #6
    //   2095: goto -> 1937
    //   2098: aload_0
    //   2099: invokevirtual x : ()I
    //   2102: ifle -> 2143
    //   2105: aload_0
    //   2106: getfield x : Z
    //   2109: ifeq -> 2129
    //   2112: aload_0
    //   2113: aload_1
    //   2114: aload_2
    //   2115: iconst_1
    //   2116: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   2119: aload_0
    //   2120: aload_1
    //   2121: aload_2
    //   2122: iconst_0
    //   2123: invokevirtual S0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   2126: goto -> 2143
    //   2129: aload_0
    //   2130: aload_1
    //   2131: aload_2
    //   2132: iconst_1
    //   2133: invokevirtual S0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   2136: aload_0
    //   2137: aload_1
    //   2138: aload_2
    //   2139: iconst_0
    //   2140: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   2143: iload_3
    //   2144: ifeq -> 2228
    //   2147: aload_2
    //   2148: getfield g : Z
    //   2151: ifne -> 2228
    //   2154: aload_0
    //   2155: getfield C : I
    //   2158: ifeq -> 2181
    //   2161: aload_0
    //   2162: invokevirtual x : ()I
    //   2165: ifle -> 2181
    //   2168: aload_0
    //   2169: invokevirtual Y0 : ()Landroid/view/View;
    //   2172: ifnull -> 2181
    //   2175: iconst_1
    //   2176: istore #6
    //   2178: goto -> 2184
    //   2181: iconst_0
    //   2182: istore #6
    //   2184: iload #6
    //   2186: ifeq -> 2228
    //   2189: aload_0
    //   2190: getfield K : Ljava/lang/Runnable;
    //   2193: astore #14
    //   2195: aload_0
    //   2196: getfield b : Landroidx/recyclerview/widget/RecyclerView;
    //   2199: astore #15
    //   2201: aload #15
    //   2203: ifnull -> 2214
    //   2206: aload #15
    //   2208: aload #14
    //   2210: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   2213: pop
    //   2214: aload_0
    //   2215: invokevirtual K0 : ()Z
    //   2218: ifeq -> 2228
    //   2221: iload #9
    //   2223: istore #6
    //   2225: goto -> 2231
    //   2228: iconst_0
    //   2229: istore #6
    //   2231: aload_2
    //   2232: getfield g : Z
    //   2235: ifeq -> 2245
    //   2238: aload_0
    //   2239: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   2242: invokevirtual b : ()V
    //   2245: aload_0
    //   2246: aload #13
    //   2248: getfield c : Z
    //   2251: putfield D : Z
    //   2254: aload_0
    //   2255: aload_0
    //   2256: invokevirtual Z0 : ()Z
    //   2259: putfield E : Z
    //   2262: iload #6
    //   2264: ifeq -> 2281
    //   2267: aload_0
    //   2268: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   2271: invokevirtual b : ()V
    //   2274: aload_0
    //   2275: aload_1
    //   2276: aload_2
    //   2277: iconst_0
    //   2278: invokevirtual b1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   2281: return
  }
  
  public final boolean c1(int paramInt) {
    boolean bool;
    if (this.t == 0) {
      if (paramInt == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return (bool != this.x);
    } 
    if (paramInt == -1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.x) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool == Z0());
  }
  
  public void d(String paramString) {
    if (this.F == null) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.i(paramString); 
    } 
  }
  
  public void d0(RecyclerView.r paramr, RecyclerView.w paramw, View paramView, n0.b paramb) {
    n0.b.c c2;
    int i;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof c)) {
      c0(paramView, paramb);
      return;
    } 
    c c = (c)layoutParams;
    if (this.t == 0) {
      f f2 = c.e;
      if (f2 == null) {
        i = -1;
      } else {
        i = f2.e;
      } 
      c2 = n0.b.c.a(i, 1, -1, -1, false, false);
      paramb.a.setCollectionItemInfo((AccessibilityNodeInfo.CollectionItemInfo)c2.a);
      return;
    } 
    f f1 = ((c)c2).e;
    if (f1 == null) {
      i = -1;
    } else {
      i = f1.e;
    } 
    n0.b.c c1 = n0.b.c.a(-1, -1, i, 1, false, false);
    paramb.a.setCollectionItemInfo((AccessibilityNodeInfo.CollectionItemInfo)c1.a);
  }
  
  public void d1(int paramInt, RecyclerView.w paramw) {
    int i;
    byte b1;
    if (paramInt > 0) {
      i = U0();
      b1 = 1;
    } else {
      i = T0();
      b1 = -1;
    } 
    this.v.a = true;
    l1(i, paramw);
    j1(b1);
    n n1 = this.v;
    n1.c = i + n1.d;
    n1.b = Math.abs(paramInt);
  }
  
  public boolean e() {
    return (this.t == 0);
  }
  
  public void e0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    X0(paramInt1, paramInt2, 1);
  }
  
  public final void e1(RecyclerView.r paramr, n paramn) {
    if (paramn.a) {
      if (paramn.i)
        return; 
      if (paramn.b == 0) {
        if (paramn.e == -1) {
          f1(paramr, paramn.g);
          return;
        } 
        g1(paramr, paramn.f);
        return;
      } 
      int k = paramn.e;
      int j = 1;
      int i = 1;
      if (k == -1) {
        int i1 = paramn.f;
        for (j = this.q[0].k(i1); i < this.p; j = k) {
          int i2 = this.q[i].k(i1);
          k = j;
          if (i2 > j)
            k = i2; 
          i++;
        } 
        i = i1 - j;
        if (i < 0) {
          i = paramn.g;
        } else {
          i = paramn.g - Math.min(i, paramn.b);
        } 
        f1(paramr, i);
        return;
      } 
      int m = paramn.g;
      k = this.q[0].h(m);
      i = j;
      for (j = k; i < this.p; j = k) {
        int i1 = this.q[i].h(m);
        k = j;
        if (i1 < j)
          k = i1; 
        i++;
      } 
      i = j - paramn.g;
      if (i < 0) {
        i = paramn.f;
      } else {
        j = paramn.f;
        i = Math.min(i, paramn.b) + j;
      } 
      g1(paramr, i);
    } 
  }
  
  public boolean f() {
    return (this.t == 1);
  }
  
  public void f0(RecyclerView paramRecyclerView) {
    this.B.a();
    u0();
  }
  
  public final void f1(RecyclerView.r paramr, int paramInt) {
    int i = x() - 1;
    while (i >= 0) {
      View view = w(i);
      if (this.r.e(view) >= paramInt && this.r.o(view) >= paramInt) {
        c c = (c)view.getLayoutParams();
        Objects.requireNonNull(c);
        if (c.e.a.size() == 1)
          return; 
        c.e.l();
        q0(view, paramr);
        i--;
      } 
    } 
  }
  
  public boolean g(RecyclerView.m paramm) {
    return paramm instanceof c;
  }
  
  public void g0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    X0(paramInt1, paramInt2, 8);
  }
  
  public final void g1(RecyclerView.r paramr, int paramInt) {
    while (x() > 0) {
      View view = w(0);
      if (this.r.b(view) <= paramInt && this.r.n(view) <= paramInt) {
        c c = (c)view.getLayoutParams();
        Objects.requireNonNull(c);
        if (c.e.a.size() == 1)
          return; 
        c.e.m();
        q0(view, paramr);
      } 
    } 
  }
  
  public void h0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    X0(paramInt1, paramInt2, 2);
  }
  
  public final void h1() {
    if (this.t == 1 || !Z0()) {
      this.x = this.w;
      return;
    } 
    this.x = this.w ^ true;
  }
  
  public void i(int paramInt1, int paramInt2, RecyclerView.w paramw, RecyclerView.l.c paramc) {
    if (this.t != 0)
      paramInt1 = paramInt2; 
    if (x() != 0) {
      if (paramInt1 == 0)
        return; 
      d1(paramInt1, paramw);
      int[] arrayOfInt = this.J;
      if (arrayOfInt == null || arrayOfInt.length < this.p)
        this.J = new int[this.p]; 
      paramInt2 = 0;
      for (paramInt1 = 0; paramInt2 < this.p; paramInt1 = i) {
        n n1 = this.v;
        if (n1.d == -1) {
          i = n1.f;
          j = this.q[paramInt2].k(i);
        } else {
          i = this.q[paramInt2].h(n1.g);
          j = this.v.g;
        } 
        int j = i - j;
        int i = paramInt1;
        if (j >= 0) {
          this.J[paramInt1] = j;
          i = paramInt1 + 1;
        } 
        paramInt2++;
      } 
      Arrays.sort(this.J, 0, paramInt1);
      paramInt2 = 0;
      while (paramInt2 < paramInt1) {
        int i = this.v.c;
        if (i >= 0 && i < paramw.b()) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i != 0) {
          i = this.v.c;
          int j = this.J[paramInt2];
          ((m.b)paramc).a(i, j);
          n n1 = this.v;
          n1.c += n1.d;
          paramInt2++;
        } 
      } 
    } 
  }
  
  public void i0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    X0(paramInt1, paramInt2, 4);
  }
  
  public int i1(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    if (x() != 0) {
      if (paramInt == 0)
        return 0; 
      d1(paramInt, paramw);
      int i = O0(paramr, this.v, paramw);
      if (this.v.b >= i)
        if (paramInt < 0) {
          paramInt = -i;
        } else {
          paramInt = i;
        }  
      this.r.p(-paramInt);
      this.D = this.x;
      n n1 = this.v;
      n1.b = 0;
      e1(paramr, n1);
      return paramInt;
    } 
    return 0;
  }
  
  public void j0(RecyclerView.r paramr, RecyclerView.w paramw) {
    b1(paramr, paramw, true);
  }
  
  public final void j1(int paramInt) {
    boolean bool1;
    n n1 = this.v;
    n1.e = paramInt;
    boolean bool2 = this.x;
    boolean bool = true;
    if (paramInt == -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 == bool1) {
      paramInt = bool;
    } else {
      paramInt = -1;
    } 
    n1.d = paramInt;
  }
  
  public int k(RecyclerView.w paramw) {
    return L0(paramw);
  }
  
  public void k0(RecyclerView.w paramw) {
    this.z = -1;
    this.A = Integer.MIN_VALUE;
    this.F = null;
    this.H.b();
  }
  
  public final void k1(int paramInt1, int paramInt2) {
    for (int i = 0; i < this.p; i++) {
      if (!(this.q[i]).a.isEmpty())
        m1(this.q[i], paramInt1, paramInt2); 
    } 
  }
  
  public int l(RecyclerView.w paramw) {
    return M0(paramw);
  }
  
  public void l0(Parcelable paramParcelable) {
    if (paramParcelable instanceof e) {
      this.F = (e)paramParcelable;
      u0();
    } 
  }
  
  public final void l1(int paramInt, RecyclerView.w paramw) {
    // Byte code:
    //   0: aload_0
    //   1: getfield v : Landroidx/recyclerview/widget/n;
    //   4: astore #8
    //   6: iconst_0
    //   7: istore #6
    //   9: aload #8
    //   11: iconst_0
    //   12: putfield b : I
    //   15: aload #8
    //   17: iload_1
    //   18: putfield c : I
    //   21: aload_0
    //   22: getfield e : Landroidx/recyclerview/widget/RecyclerView$v;
    //   25: astore #8
    //   27: aload #8
    //   29: ifnull -> 45
    //   32: aload #8
    //   34: getfield e : Z
    //   37: ifeq -> 45
    //   40: iconst_1
    //   41: istore_3
    //   42: goto -> 47
    //   45: iconst_0
    //   46: istore_3
    //   47: iload_3
    //   48: ifeq -> 112
    //   51: aload_2
    //   52: getfield a : I
    //   55: istore_3
    //   56: iload_3
    //   57: iconst_m1
    //   58: if_icmpeq -> 112
    //   61: aload_0
    //   62: getfield x : Z
    //   65: istore #7
    //   67: iload_3
    //   68: iload_1
    //   69: if_icmpge -> 78
    //   72: iconst_1
    //   73: istore #5
    //   75: goto -> 81
    //   78: iconst_0
    //   79: istore #5
    //   81: iload #7
    //   83: iload #5
    //   85: if_icmpne -> 99
    //   88: aload_0
    //   89: getfield r : Landroidx/recyclerview/widget/s;
    //   92: invokevirtual l : ()I
    //   95: istore_1
    //   96: goto -> 114
    //   99: aload_0
    //   100: getfield r : Landroidx/recyclerview/widget/s;
    //   103: invokevirtual l : ()I
    //   106: istore_3
    //   107: iconst_0
    //   108: istore_1
    //   109: goto -> 116
    //   112: iconst_0
    //   113: istore_1
    //   114: iconst_0
    //   115: istore_3
    //   116: aload_0
    //   117: getfield b : Landroidx/recyclerview/widget/RecyclerView;
    //   120: astore_2
    //   121: aload_2
    //   122: ifnull -> 138
    //   125: aload_2
    //   126: getfield l : Z
    //   129: ifeq -> 138
    //   132: iconst_1
    //   133: istore #4
    //   135: goto -> 141
    //   138: iconst_0
    //   139: istore #4
    //   141: iload #4
    //   143: ifeq -> 181
    //   146: aload_0
    //   147: getfield v : Landroidx/recyclerview/widget/n;
    //   150: aload_0
    //   151: getfield r : Landroidx/recyclerview/widget/s;
    //   154: invokevirtual k : ()I
    //   157: iload_3
    //   158: isub
    //   159: putfield f : I
    //   162: aload_0
    //   163: getfield v : Landroidx/recyclerview/widget/n;
    //   166: aload_0
    //   167: getfield r : Landroidx/recyclerview/widget/s;
    //   170: invokevirtual g : ()I
    //   173: iload_1
    //   174: iadd
    //   175: putfield g : I
    //   178: goto -> 206
    //   181: aload_0
    //   182: getfield v : Landroidx/recyclerview/widget/n;
    //   185: aload_0
    //   186: getfield r : Landroidx/recyclerview/widget/s;
    //   189: invokevirtual f : ()I
    //   192: iload_1
    //   193: iadd
    //   194: putfield g : I
    //   197: aload_0
    //   198: getfield v : Landroidx/recyclerview/widget/n;
    //   201: iload_3
    //   202: ineg
    //   203: putfield f : I
    //   206: aload_0
    //   207: getfield v : Landroidx/recyclerview/widget/n;
    //   210: astore_2
    //   211: aload_2
    //   212: iconst_0
    //   213: putfield h : Z
    //   216: aload_2
    //   217: iconst_1
    //   218: putfield a : Z
    //   221: iload #6
    //   223: istore #5
    //   225: aload_0
    //   226: getfield r : Landroidx/recyclerview/widget/s;
    //   229: invokevirtual i : ()I
    //   232: ifne -> 252
    //   235: iload #6
    //   237: istore #5
    //   239: aload_0
    //   240: getfield r : Landroidx/recyclerview/widget/s;
    //   243: invokevirtual f : ()I
    //   246: ifne -> 252
    //   249: iconst_1
    //   250: istore #5
    //   252: aload_2
    //   253: iload #5
    //   255: putfield i : Z
    //   258: return
  }
  
  public int m(RecyclerView.w paramw) {
    return N0(paramw);
  }
  
  public Parcelable m0() {
    // Byte code:
    //   0: aload_0
    //   1: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   14: dup
    //   15: aload #4
    //   17: invokespecial <init> : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;)V
    //   20: areturn
    //   21: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore #5
    //   30: aload #5
    //   32: aload_0
    //   33: getfield w : Z
    //   36: putfield m : Z
    //   39: aload #5
    //   41: aload_0
    //   42: getfield D : Z
    //   45: putfield n : Z
    //   48: aload #5
    //   50: aload_0
    //   51: getfield E : Z
    //   54: putfield o : Z
    //   57: aload_0
    //   58: getfield B : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   61: astore #4
    //   63: iconst_0
    //   64: istore_2
    //   65: aload #4
    //   67: ifnull -> 110
    //   70: aload #4
    //   72: getfield a : [I
    //   75: astore #6
    //   77: aload #6
    //   79: ifnull -> 110
    //   82: aload #5
    //   84: aload #6
    //   86: putfield k : [I
    //   89: aload #5
    //   91: aload #6
    //   93: arraylength
    //   94: putfield j : I
    //   97: aload #5
    //   99: aload #4
    //   101: getfield b : Ljava/util/List;
    //   104: putfield l : Ljava/util/List;
    //   107: goto -> 116
    //   110: aload #5
    //   112: iconst_0
    //   113: putfield j : I
    //   116: aload_0
    //   117: invokevirtual x : ()I
    //   120: istore_1
    //   121: iconst_m1
    //   122: istore_3
    //   123: iload_1
    //   124: ifle -> 312
    //   127: aload_0
    //   128: getfield D : Z
    //   131: ifeq -> 142
    //   134: aload_0
    //   135: invokevirtual U0 : ()I
    //   138: istore_1
    //   139: goto -> 147
    //   142: aload_0
    //   143: invokevirtual T0 : ()I
    //   146: istore_1
    //   147: aload #5
    //   149: iload_1
    //   150: putfield f : I
    //   153: aload_0
    //   154: getfield x : Z
    //   157: ifeq -> 170
    //   160: aload_0
    //   161: iconst_1
    //   162: invokevirtual P0 : (Z)Landroid/view/View;
    //   165: astore #4
    //   167: goto -> 177
    //   170: aload_0
    //   171: iconst_1
    //   172: invokevirtual Q0 : (Z)Landroid/view/View;
    //   175: astore #4
    //   177: aload #4
    //   179: ifnonnull -> 187
    //   182: iload_3
    //   183: istore_1
    //   184: goto -> 194
    //   187: aload_0
    //   188: aload #4
    //   190: invokevirtual Q : (Landroid/view/View;)I
    //   193: istore_1
    //   194: aload #5
    //   196: iload_1
    //   197: putfield g : I
    //   200: aload_0
    //   201: getfield p : I
    //   204: istore_1
    //   205: aload #5
    //   207: iload_1
    //   208: putfield h : I
    //   211: aload #5
    //   213: iload_1
    //   214: newarray int
    //   216: putfield i : [I
    //   219: iload_2
    //   220: aload_0
    //   221: getfield p : I
    //   224: if_icmpge -> 330
    //   227: aload_0
    //   228: getfield D : Z
    //   231: ifeq -> 265
    //   234: aload_0
    //   235: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   238: iload_2
    //   239: aaload
    //   240: ldc -2147483648
    //   242: invokevirtual h : (I)I
    //   245: istore_3
    //   246: iload_3
    //   247: istore_1
    //   248: iload_3
    //   249: ldc -2147483648
    //   251: if_icmpeq -> 297
    //   254: aload_0
    //   255: getfield r : Landroidx/recyclerview/widget/s;
    //   258: invokevirtual g : ()I
    //   261: istore_1
    //   262: goto -> 293
    //   265: aload_0
    //   266: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   269: iload_2
    //   270: aaload
    //   271: ldc -2147483648
    //   273: invokevirtual k : (I)I
    //   276: istore_3
    //   277: iload_3
    //   278: istore_1
    //   279: iload_3
    //   280: ldc -2147483648
    //   282: if_icmpeq -> 297
    //   285: aload_0
    //   286: getfield r : Landroidx/recyclerview/widget/s;
    //   289: invokevirtual k : ()I
    //   292: istore_1
    //   293: iload_3
    //   294: iload_1
    //   295: isub
    //   296: istore_1
    //   297: aload #5
    //   299: getfield i : [I
    //   302: iload_2
    //   303: iload_1
    //   304: iastore
    //   305: iload_2
    //   306: iconst_1
    //   307: iadd
    //   308: istore_2
    //   309: goto -> 219
    //   312: aload #5
    //   314: iconst_m1
    //   315: putfield f : I
    //   318: aload #5
    //   320: iconst_m1
    //   321: putfield g : I
    //   324: aload #5
    //   326: iconst_0
    //   327: putfield h : I
    //   330: aload #5
    //   332: areturn
  }
  
  public final void m1(f paramf, int paramInt1, int paramInt2) {
    int i = paramf.d;
    if (paramInt1 == -1) {
      paramInt1 = paramf.b;
      if (paramInt1 == Integer.MIN_VALUE) {
        paramf.c();
        paramInt1 = paramf.b;
      } 
      if (paramInt1 + i <= paramInt2) {
        this.y.set(paramf.e, false);
        return;
      } 
    } else {
      paramInt1 = paramf.c;
      if (paramInt1 == Integer.MIN_VALUE) {
        paramf.b();
        paramInt1 = paramf.c;
      } 
      if (paramInt1 - i >= paramInt2)
        this.y.set(paramf.e, false); 
    } 
  }
  
  public int n(RecyclerView.w paramw) {
    return L0(paramw);
  }
  
  public void n0(int paramInt) {
    if (paramInt == 0)
      K0(); 
  }
  
  public final int n1(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0 && paramInt3 == 0)
      return paramInt1; 
    int i = View.MeasureSpec.getMode(paramInt1);
    return (i == Integer.MIN_VALUE || i == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i) : paramInt1;
  }
  
  public int o(RecyclerView.w paramw) {
    return M0(paramw);
  }
  
  public int p(RecyclerView.w paramw) {
    return N0(paramw);
  }
  
  public RecyclerView.m t() {
    return (this.t == 0) ? new c(-2, -1) : new c(-1, -2);
  }
  
  public RecyclerView.m u(Context paramContext, AttributeSet paramAttributeSet) {
    return new c(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.m v(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new c((ViewGroup.MarginLayoutParams)paramLayoutParams) : new c(paramLayoutParams);
  }
  
  public int v0(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    return i1(paramInt, paramr, paramw);
  }
  
  public void w0(int paramInt) {
    e e1 = this.F;
    if (e1 != null && e1.f != paramInt) {
      e1.i = null;
      e1.h = 0;
      e1.f = -1;
      e1.g = -1;
    } 
    this.z = paramInt;
    this.A = Integer.MIN_VALUE;
    u0();
  }
  
  public int x0(int paramInt, RecyclerView.r paramr, RecyclerView.w paramw) {
    return i1(paramInt, paramr, paramw);
  }
  
  public int z(RecyclerView.r paramr, RecyclerView.w paramw) {
    return (this.t == 1) ? this.p : super.z(paramr, paramw);
  }
  
  public class a implements Runnable {
    public a(StaggeredGridLayoutManager this$0) {}
    
    public void run() {
      this.f.K0();
    }
  }
  
  public class b {
    public int a;
    
    public int b;
    
    public boolean c;
    
    public boolean d;
    
    public boolean e;
    
    public int[] f;
    
    public b(StaggeredGridLayoutManager this$0) {
      b();
    }
    
    public void a() {
      int i;
      if (this.c) {
        i = this.g.r.g();
      } else {
        i = this.g.r.k();
      } 
      this.b = i;
    }
    
    public void b() {
      this.a = -1;
      this.b = Integer.MIN_VALUE;
      this.c = false;
      this.d = false;
      this.e = false;
      int[] arrayOfInt = this.f;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
    }
  }
  
  public static class c extends RecyclerView.m {
    public StaggeredGridLayoutManager.f e;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static class d {
    public int[] a;
    
    public List<a> b;
    
    public void a() {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.b = null;
    }
    
    public void b(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null) {
        arrayOfInt = new int[Math.max(param1Int, 10) + 1];
        this.a = arrayOfInt;
        Arrays.fill(arrayOfInt, -1);
        return;
      } 
      if (param1Int >= arrayOfInt.length) {
        int i;
        for (i = arrayOfInt.length; i <= param1Int; i *= 2);
        int[] arrayOfInt1 = new int[i];
        this.a = arrayOfInt1;
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
        arrayOfInt1 = this.a;
        Arrays.fill(arrayOfInt1, arrayOfInt.length, arrayOfInt1.length, -1);
      } 
    }
    
    public a c(int param1Int) {
      List<a> list = this.b;
      if (list == null)
        return null; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        if (a.f == param1Int)
          return a; 
      } 
      return null;
    }
    
    public int d(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : [I
      //   4: astore #4
      //   6: aload #4
      //   8: ifnonnull -> 13
      //   11: iconst_m1
      //   12: ireturn
      //   13: iload_1
      //   14: aload #4
      //   16: arraylength
      //   17: if_icmplt -> 22
      //   20: iconst_m1
      //   21: ireturn
      //   22: aload_0
      //   23: getfield b : Ljava/util/List;
      //   26: ifnonnull -> 34
      //   29: iconst_m1
      //   30: istore_2
      //   31: goto -> 144
      //   34: aload_0
      //   35: iload_1
      //   36: invokevirtual c : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d$a;
      //   39: astore #4
      //   41: aload #4
      //   43: ifnull -> 58
      //   46: aload_0
      //   47: getfield b : Ljava/util/List;
      //   50: aload #4
      //   52: invokeinterface remove : (Ljava/lang/Object;)Z
      //   57: pop
      //   58: aload_0
      //   59: getfield b : Ljava/util/List;
      //   62: invokeinterface size : ()I
      //   67: istore_3
      //   68: iconst_0
      //   69: istore_2
      //   70: iload_2
      //   71: iload_3
      //   72: if_icmpge -> 105
      //   75: aload_0
      //   76: getfield b : Ljava/util/List;
      //   79: iload_2
      //   80: invokeinterface get : (I)Ljava/lang/Object;
      //   85: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   88: getfield f : I
      //   91: iload_1
      //   92: if_icmplt -> 98
      //   95: goto -> 107
      //   98: iload_2
      //   99: iconst_1
      //   100: iadd
      //   101: istore_2
      //   102: goto -> 70
      //   105: iconst_m1
      //   106: istore_2
      //   107: iload_2
      //   108: iconst_m1
      //   109: if_icmpeq -> 29
      //   112: aload_0
      //   113: getfield b : Ljava/util/List;
      //   116: iload_2
      //   117: invokeinterface get : (I)Ljava/lang/Object;
      //   122: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   125: astore #4
      //   127: aload_0
      //   128: getfield b : Ljava/util/List;
      //   131: iload_2
      //   132: invokeinterface remove : (I)Ljava/lang/Object;
      //   137: pop
      //   138: aload #4
      //   140: getfield f : I
      //   143: istore_2
      //   144: iload_2
      //   145: iconst_m1
      //   146: if_icmpne -> 171
      //   149: aload_0
      //   150: getfield a : [I
      //   153: astore #4
      //   155: aload #4
      //   157: iload_1
      //   158: aload #4
      //   160: arraylength
      //   161: iconst_m1
      //   162: invokestatic fill : ([IIII)V
      //   165: aload_0
      //   166: getfield a : [I
      //   169: arraylength
      //   170: ireturn
      //   171: aload_0
      //   172: getfield a : [I
      //   175: astore #4
      //   177: iload_2
      //   178: iconst_1
      //   179: iadd
      //   180: istore_2
      //   181: aload #4
      //   183: iload_1
      //   184: iload_2
      //   185: iconst_m1
      //   186: invokestatic fill : ([IIII)V
      //   189: iload_2
      //   190: ireturn
    }
    
    public void e(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int i = param1Int1 + param1Int2;
        b(i);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, param1Int1, arrayOfInt, i, arrayOfInt.length - param1Int1 - param1Int2);
        Arrays.fill(this.a, param1Int1, i, -1);
        List<a> list = this.b;
        if (list == null)
          return; 
        for (i = list.size() - 1; i >= 0; i--) {
          a a = this.b.get(i);
          int j = a.f;
          if (j >= param1Int1)
            a.f = j + param1Int2; 
        } 
      } 
    }
    
    public void f(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int j = param1Int1 + param1Int2;
        b(j);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, j, arrayOfInt, param1Int1, arrayOfInt.length - param1Int1 - param1Int2);
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, arrayOfInt.length - param1Int2, arrayOfInt.length, -1);
        List<a> list = this.b;
        if (list == null)
          return; 
        for (int i = list.size() - 1; i >= 0; i--) {
          a a = this.b.get(i);
          int k = a.f;
          if (k >= param1Int1)
            if (k < j) {
              this.b.remove(i);
            } else {
              a.f = k - param1Int2;
            }  
        } 
      } 
    }
    
    @SuppressLint({"BanParcelableUsage"})
    public static class a implements Parcelable {
      public static final Parcelable.Creator<a> CREATOR = new a();
      
      public int f;
      
      public int g;
      
      public int[] h;
      
      public boolean i;
      
      public a() {}
      
      public a(Parcel param2Parcel) {
        this.f = param2Parcel.readInt();
        this.g = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        this.i = bool;
        i = param2Parcel.readInt();
        if (i > 0) {
          int[] arrayOfInt = new int[i];
          this.h = arrayOfInt;
          param2Parcel.readIntArray(arrayOfInt);
        } 
      }
      
      public int describeContents() {
        return 0;
      }
      
      public String toString() {
        StringBuilder stringBuilder = android.support.v4.media.a.a("FullSpanItem{mPosition=");
        stringBuilder.append(this.f);
        stringBuilder.append(", mGapDir=");
        stringBuilder.append(this.g);
        stringBuilder.append(", mHasUnwantedGapAfter=");
        stringBuilder.append(this.i);
        stringBuilder.append(", mGapPerSpan=");
        stringBuilder.append(Arrays.toString(this.h));
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
      }
      
      public static final class a implements Parcelable.Creator<a> {
        public Object createFromParcel(Parcel param3Parcel) {
          return new StaggeredGridLayoutManager.d.a(param3Parcel);
        }
        
        public Object[] newArray(int param3Int) {
          return (Object[])new StaggeredGridLayoutManager.d.a[param3Int];
        }
      }
    }
    
    public static final class a implements Parcelable.Creator<a> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.d.a(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new StaggeredGridLayoutManager.d.a[param2Int];
      }
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new a();
    
    public int f;
    
    public int g;
    
    public int[] h;
    
    public boolean i;
    
    public a() {}
    
    public a(Parcel param1Parcel) {
      this.f = param1Parcel.readInt();
      this.g = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.i = bool;
      i = param1Parcel.readInt();
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.h = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.a.a("FullSpanItem{mPosition=");
      stringBuilder.append(this.f);
      stringBuilder.append(", mGapDir=");
      stringBuilder.append(this.g);
      stringBuilder.append(", mHasUnwantedGapAfter=");
      stringBuilder.append(this.i);
      stringBuilder.append(", mGapPerSpan=");
      stringBuilder.append(Arrays.toString(this.h));
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public static final class a implements Parcelable.Creator<a> {
      public Object createFromParcel(Parcel param3Parcel) {
        return new StaggeredGridLayoutManager.d.a(param3Parcel);
      }
      
      public Object[] newArray(int param3Int) {
        return (Object[])new StaggeredGridLayoutManager.d.a[param3Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<d.a> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.d.a(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new StaggeredGridLayoutManager.d.a[param1Int];
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class e implements Parcelable {
    public static final Parcelable.Creator<e> CREATOR = new a();
    
    public int f;
    
    public int g;
    
    public int h;
    
    public int[] i;
    
    public int j;
    
    public int[] k;
    
    public List<StaggeredGridLayoutManager.d.a> l;
    
    public boolean m;
    
    public boolean n;
    
    public boolean o;
    
    public e() {}
    
    public e(Parcel param1Parcel) {
      this.f = param1Parcel.readInt();
      this.g = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      this.h = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.i = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      this.j = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.k = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      boolean bool2 = false;
      if (i == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.m = bool1;
      if (param1Parcel.readInt() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.n = bool1;
      boolean bool1 = bool2;
      if (param1Parcel.readInt() == 1)
        bool1 = true; 
      this.o = bool1;
      this.l = param1Parcel.readArrayList(StaggeredGridLayoutManager.d.a.class.getClassLoader());
    }
    
    public e(e param1e) {
      this.h = param1e.h;
      this.f = param1e.f;
      this.g = param1e.g;
      this.i = param1e.i;
      this.j = param1e.j;
      this.k = param1e.k;
      this.m = param1e.m;
      this.n = param1e.n;
      this.o = param1e.o;
      this.l = param1e.l;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public static final class a implements Parcelable.Creator<e> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.e(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new StaggeredGridLayoutManager.e[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<e> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.e(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new StaggeredGridLayoutManager.e[param1Int];
    }
  }
  
  public class f {
    public ArrayList<View> a = new ArrayList<View>();
    
    public int b = Integer.MIN_VALUE;
    
    public int c = Integer.MIN_VALUE;
    
    public int d = 0;
    
    public final int e;
    
    public f(StaggeredGridLayoutManager this$0, int param1Int) {
      this.e = param1Int;
    }
    
    public void a(View param1View) {
      StaggeredGridLayoutManager.c c = j(param1View);
      c.e = this;
      this.a.add(param1View);
      this.c = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.b = Integer.MIN_VALUE; 
      if (c.c() || c.b()) {
        int i = this.d;
        this.d = this.f.r.c(param1View) + i;
      } 
    }
    
    public void b() {
      ArrayList<View> arrayList = this.a;
      View view = arrayList.get(arrayList.size() - 1);
      StaggeredGridLayoutManager.c c = j(view);
      this.c = this.f.r.b(view);
      Objects.requireNonNull(c);
    }
    
    public void c() {
      View view = this.a.get(0);
      StaggeredGridLayoutManager.c c = j(view);
      this.b = this.f.r.e(view);
      Objects.requireNonNull(c);
    }
    
    public void d() {
      this.a.clear();
      this.b = Integer.MIN_VALUE;
      this.c = Integer.MIN_VALUE;
      this.d = 0;
    }
    
    public int e() {
      return this.f.w ? g(this.a.size() - 1, -1, true) : g(0, this.a.size(), true);
    }
    
    public int f() {
      return this.f.w ? g(0, this.a.size(), true) : g(this.a.size() - 1, -1, true);
    }
    
    public int g(int param1Int1, int param1Int2, boolean param1Boolean) {
      byte b;
      int i = this.f.r.k();
      int j = this.f.r.g();
      if (param1Int2 > param1Int1) {
        b = 1;
      } else {
        b = -1;
      } 
      while (param1Int1 != param1Int2) {
        boolean bool1;
        View view = this.a.get(param1Int1);
        int k = this.f.r.e(view);
        int m = this.f.r.b(view);
        boolean bool2 = false;
        if (param1Boolean ? (k <= j) : (k < j)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1Boolean ? (m >= i) : (m > i))
          bool2 = true; 
        if (bool1 && bool2 && (k < i || m > j))
          return this.f.Q(view); 
        param1Int1 += b;
      } 
      return -1;
    }
    
    public int h(int param1Int) {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      b();
      return this.c;
    }
    
    public View i(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #5
      //   3: aconst_null
      //   4: astore #4
      //   6: iload_2
      //   7: iconst_m1
      //   8: if_icmpne -> 123
      //   11: aload_0
      //   12: getfield a : Ljava/util/ArrayList;
      //   15: invokevirtual size : ()I
      //   18: istore_3
      //   19: iconst_0
      //   20: istore_2
      //   21: aload #4
      //   23: astore #5
      //   25: iload_2
      //   26: iload_3
      //   27: if_icmpge -> 238
      //   30: aload_0
      //   31: getfield a : Ljava/util/ArrayList;
      //   34: iload_2
      //   35: invokevirtual get : (I)Ljava/lang/Object;
      //   38: checkcast android/view/View
      //   41: astore #6
      //   43: aload_0
      //   44: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   47: astore #7
      //   49: aload #7
      //   51: getfield w : Z
      //   54: ifeq -> 72
      //   57: aload #4
      //   59: astore #5
      //   61: aload #7
      //   63: aload #6
      //   65: invokevirtual Q : (Landroid/view/View;)I
      //   68: iload_1
      //   69: if_icmple -> 238
      //   72: aload_0
      //   73: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   76: astore #5
      //   78: aload #5
      //   80: getfield w : Z
      //   83: ifne -> 100
      //   86: aload #5
      //   88: aload #6
      //   90: invokevirtual Q : (Landroid/view/View;)I
      //   93: iload_1
      //   94: if_icmplt -> 100
      //   97: aload #4
      //   99: areturn
      //   100: aload #4
      //   102: astore #5
      //   104: aload #6
      //   106: invokevirtual hasFocusable : ()Z
      //   109: ifeq -> 238
      //   112: iload_2
      //   113: iconst_1
      //   114: iadd
      //   115: istore_2
      //   116: aload #6
      //   118: astore #4
      //   120: goto -> 21
      //   123: aload_0
      //   124: getfield a : Ljava/util/ArrayList;
      //   127: invokevirtual size : ()I
      //   130: iconst_1
      //   131: isub
      //   132: istore_2
      //   133: aload #5
      //   135: astore #4
      //   137: aload #4
      //   139: astore #5
      //   141: iload_2
      //   142: iflt -> 238
      //   145: aload_0
      //   146: getfield a : Ljava/util/ArrayList;
      //   149: iload_2
      //   150: invokevirtual get : (I)Ljava/lang/Object;
      //   153: checkcast android/view/View
      //   156: astore #6
      //   158: aload_0
      //   159: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   162: astore #7
      //   164: aload #7
      //   166: getfield w : Z
      //   169: ifeq -> 187
      //   172: aload #4
      //   174: astore #5
      //   176: aload #7
      //   178: aload #6
      //   180: invokevirtual Q : (Landroid/view/View;)I
      //   183: iload_1
      //   184: if_icmpge -> 238
      //   187: aload_0
      //   188: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   191: astore #5
      //   193: aload #5
      //   195: getfield w : Z
      //   198: ifne -> 215
      //   201: aload #5
      //   203: aload #6
      //   205: invokevirtual Q : (Landroid/view/View;)I
      //   208: iload_1
      //   209: if_icmpgt -> 215
      //   212: aload #4
      //   214: areturn
      //   215: aload #4
      //   217: astore #5
      //   219: aload #6
      //   221: invokevirtual hasFocusable : ()Z
      //   224: ifeq -> 238
      //   227: iload_2
      //   228: iconst_1
      //   229: isub
      //   230: istore_2
      //   231: aload #6
      //   233: astore #4
      //   235: goto -> 137
      //   238: aload #5
      //   240: areturn
    }
    
    public StaggeredGridLayoutManager.c j(View param1View) {
      return (StaggeredGridLayoutManager.c)param1View.getLayoutParams();
    }
    
    public int k(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      c();
      return this.b;
    }
    
    public void l() {
      int i = this.a.size();
      View view = this.a.remove(i - 1);
      StaggeredGridLayoutManager.c c = j(view);
      c.e = null;
      if (c.c() || c.b())
        this.d -= this.f.r.c(view); 
      if (i == 1)
        this.b = Integer.MIN_VALUE; 
      this.c = Integer.MIN_VALUE;
    }
    
    public void m() {
      View view = this.a.remove(0);
      StaggeredGridLayoutManager.c c = j(view);
      c.e = null;
      if (this.a.size() == 0)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b())
        this.d -= this.f.r.c(view); 
      this.b = Integer.MIN_VALUE;
    }
    
    public void n(View param1View) {
      StaggeredGridLayoutManager.c c = j(param1View);
      c.e = this;
      this.a.add(0, param1View);
      this.b = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b()) {
        int i = this.d;
        this.d = this.f.r.c(param1View) + i;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\StaggeredGridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */