package androidx.recyclerview.widget;

import android.view.View;

public final class r extends s {
  public r(RecyclerView.l paraml) {
    super(paraml, null);
  }
  
  public int b(View paramView) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    return this.a.A(paramView) + m.bottomMargin;
  }
  
  public int c(View paramView) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    return this.a.D(paramView) + m.topMargin + m.bottomMargin;
  }
  
  public int d(View paramView) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    return this.a.E(paramView) + m.leftMargin + m.rightMargin;
  }
  
  public int e(View paramView) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    return this.a.G(paramView) - m.topMargin;
  }
  
  public int f() {
    return this.a.o;
  }
  
  public int g() {
    RecyclerView.l l = this.a;
    return l.o - l.M();
  }
  
  public int h() {
    return this.a.M();
  }
  
  public int i() {
    return this.a.m;
  }
  
  public int j() {
    return this.a.l;
  }
  
  public int k() {
    return this.a.P();
  }
  
  public int l() {
    RecyclerView.l l = this.a;
    return l.o - l.P() - this.a.M();
  }
  
  public int n(View paramView) {
    this.a.T(paramView, true, this.c);
    return this.c.bottom;
  }
  
  public int o(View paramView) {
    this.a.T(paramView, true, this.c);
    return this.c.top;
  }
  
  public void p(int paramInt) {
    this.a.Y(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */