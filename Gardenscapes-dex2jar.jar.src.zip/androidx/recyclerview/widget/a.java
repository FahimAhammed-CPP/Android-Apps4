package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.List;

public class a implements p.a {
  public u.a a = new u.a(30, 1);
  
  public final ArrayList<b> b = new ArrayList<b>();
  
  public final ArrayList<b> c = new ArrayList<b>();
  
  public final a d;
  
  public final p e;
  
  public a(a parama) {
    this.d = parama;
    this.e = new p(this);
  }
  
  public final boolean a(int paramInt) {
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      b b = this.c.get(i);
      int k = b.a;
      if (k == 8) {
        if (f(b.d, i + 1) == paramInt)
          return true; 
      } else if (k == 1) {
        int m = b.b;
        int n = b.d;
        for (k = m; k < n + m; k++) {
          if (f(k, i + 1) == paramInt)
            return true; 
        } 
      } 
    } 
    return false;
  }
  
  public void b() {
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      a a1 = this.d;
      b b = this.c.get(i);
      ((w)a1).a(b);
    } 
    l(this.c);
  }
  
  public void c() {
    b();
    int j = this.b.size();
    for (int i = 0; i < j; i++) {
      Object object = this.b.get(i);
      int k = ((b)object).a;
      if (k != 1) {
        if (k != 2) {
          if (k != 4) {
            if (k == 8) {
              ((w)this.d).a((b)object);
              a a1 = this.d;
              k = ((b)object).b;
              int m = ((b)object).d;
              ((w)a1).e(k, m);
            } 
          } else {
            ((w)this.d).a((b)object);
            a a1 = this.d;
            k = ((b)object).b;
            int m = ((b)object).d;
            object = ((b)object).c;
            ((w)a1).c(k, m, object);
          } 
        } else {
          ((w)this.d).a((b)object);
          a a1 = this.d;
          k = ((b)object).b;
          int m = ((b)object).d;
          object = a1;
          ((w)object).a.R(k, m, true);
          object = ((w)object).a;
          ((RecyclerView)object).l0 = true;
          object = ((RecyclerView)object).i0;
          ((RecyclerView.w)object).c += m;
        } 
      } else {
        ((w)this.d).a((b)object);
        a a1 = this.d;
        k = ((b)object).b;
        int m = ((b)object).d;
        ((w)a1).d(k, m);
      } 
    } 
    l(this.b);
  }
  
  public final void d(b paramb) {
    int i = paramb.a;
    if (i != 1 && i != 8) {
      byte b1;
      int k = m(paramb.b, i);
      i = paramb.b;
      int j = paramb.a;
      if (j != 2) {
        if (j == 4) {
          b1 = 1;
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("op should be remove or update.");
          stringBuilder.append(paramb);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        b1 = 0;
      } 
      int m = 1;
      j = 1;
      while (m < paramb.d) {
        int n;
        int i1 = m(b1 * m + paramb.b, paramb.a);
        int i2 = paramb.a;
        if ((i2 != 2) ? (i2 == 4 && i1 == k + 1) : (i1 == k)) {
          n = 1;
        } else {
          n = 0;
        } 
        if (n) {
          j++;
        } else {
          b b2 = h(i2, k, j, paramb.c);
          e(b2, i);
          b2.c = null;
          this.a.c(b2);
          k = i;
          if (paramb.a == 4)
            k = i + j; 
          n = i1;
          j = 1;
          i = k;
          k = n;
        } 
        m++;
      } 
      Object object = paramb.c;
      paramb.c = null;
      this.a.c(paramb);
      if (j > 0) {
        paramb = h(paramb.a, k, j, object);
        e(paramb, i);
        paramb.c = null;
        this.a.c(paramb);
      } 
      return;
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("should not dispatch add or move for pre layout");
    throw illegalArgumentException;
  }
  
  public void e(b paramb, int paramInt) {
    ((w)this.d).a(paramb);
    int i = paramb.a;
    if (i != 2) {
      if (i == 4) {
        a a2 = this.d;
        i = paramb.d;
        object = paramb.c;
        ((w)a2).c(paramInt, i, object);
        return;
      } 
      throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
    } 
    a a1 = this.d;
    i = ((b)object).d;
    Object object = a1;
    ((w)object).a.R(paramInt, i, true);
    object = ((w)object).a;
    ((RecyclerView)object).l0 = true;
    object = ((RecyclerView)object).i0;
    ((RecyclerView.w)object).c += i;
  }
  
  public int f(int paramInt1, int paramInt2) {
    int j = this.c.size();
    int i = paramInt2;
    for (paramInt2 = paramInt1; i < j; paramInt2 = paramInt1) {
      b b = this.c.get(i);
      int k = b.a;
      if (k == 8) {
        paramInt1 = b.b;
        if (paramInt1 == paramInt2) {
          paramInt1 = b.d;
        } else {
          int m = paramInt2;
          if (paramInt1 < paramInt2)
            m = paramInt2 - 1; 
          paramInt1 = m;
          if (b.d <= m)
            paramInt1 = m + 1; 
        } 
      } else {
        int m = b.b;
        paramInt1 = paramInt2;
        if (m <= paramInt2)
          if (k == 2) {
            paramInt1 = b.d;
            if (paramInt2 < m + paramInt1)
              return -1; 
            paramInt1 = paramInt2 - paramInt1;
          } else {
            paramInt1 = paramInt2;
            if (k == 1)
              paramInt1 = paramInt2 + b.d; 
          }  
      } 
      i++;
    } 
    return paramInt2;
  }
  
  public boolean g() {
    return (this.b.size() > 0);
  }
  
  public b h(int paramInt1, int paramInt2, int paramInt3, Object paramObject) {
    b b = (b)this.a.a();
    if (b == null)
      return new b(paramInt1, paramInt2, paramInt3, paramObject); 
    b.a = paramInt1;
    b.b = paramInt2;
    b.d = paramInt3;
    b.c = paramObject;
    return b;
  }
  
  public final void i(b paramb) {
    Object object;
    this.c.add(paramb);
    int i = paramb.a;
    if (i != 1) {
      if (i != 2) {
        if (i != 4) {
          if (i == 8) {
            a a4 = this.d;
            i = paramb.b;
            int n = paramb.d;
            ((w)a4).e(i, n);
            return;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown update op type for ");
          stringBuilder.append(paramb);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        a a3 = this.d;
        i = paramb.b;
        int m = paramb.d;
        object = paramb.c;
        ((w)a3).c(i, m, object);
        return;
      } 
      a a2 = this.d;
      i = ((b)object).b;
      int k = ((b)object).d;
      object = a2;
      ((w)object).a.R(i, k, false);
      ((w)object).a.l0 = true;
      return;
    } 
    a a1 = this.d;
    i = ((b)object).b;
    int j = ((b)object).d;
    ((w)a1).d(i, j);
  }
  
  public void j() {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroidx/recyclerview/widget/p;
    //   4: astore #14
    //   6: aload_0
    //   7: getfield b : Ljava/util/ArrayList;
    //   10: astore #15
    //   12: aload #14
    //   14: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   17: pop
    //   18: aload #15
    //   20: invokeinterface size : ()I
    //   25: iconst_1
    //   26: isub
    //   27: istore_1
    //   28: iconst_0
    //   29: istore_2
    //   30: iload_1
    //   31: iflt -> 75
    //   34: aload #15
    //   36: iload_1
    //   37: invokeinterface get : (I)Ljava/lang/Object;
    //   42: checkcast androidx/recyclerview/widget/a$b
    //   45: getfield a : I
    //   48: bipush #8
    //   50: if_icmpne -> 64
    //   53: iload_2
    //   54: istore_3
    //   55: iload_2
    //   56: ifeq -> 66
    //   59: iload_1
    //   60: istore_3
    //   61: goto -> 77
    //   64: iconst_1
    //   65: istore_3
    //   66: iload_1
    //   67: iconst_1
    //   68: isub
    //   69: istore_1
    //   70: iload_3
    //   71: istore_2
    //   72: goto -> 30
    //   75: iconst_m1
    //   76: istore_3
    //   77: iload_3
    //   78: iconst_m1
    //   79: if_icmpeq -> 1225
    //   82: iload_3
    //   83: iconst_1
    //   84: iadd
    //   85: istore #4
    //   87: aload #15
    //   89: iload_3
    //   90: invokeinterface get : (I)Ljava/lang/Object;
    //   95: checkcast androidx/recyclerview/widget/a$b
    //   98: astore #17
    //   100: aload #15
    //   102: iload #4
    //   104: invokeinterface get : (I)Ljava/lang/Object;
    //   109: checkcast androidx/recyclerview/widget/a$b
    //   112: astore #16
    //   114: aload #16
    //   116: getfield a : I
    //   119: istore_1
    //   120: iload_1
    //   121: iconst_1
    //   122: if_icmpeq -> 1098
    //   125: iload_1
    //   126: iconst_2
    //   127: if_icmpeq -> 434
    //   130: iload_1
    //   131: iconst_4
    //   132: if_icmpeq -> 138
    //   135: goto -> 18
    //   138: aload #17
    //   140: getfield d : I
    //   143: istore_1
    //   144: aload #16
    //   146: getfield b : I
    //   149: istore_2
    //   150: iload_1
    //   151: iload_2
    //   152: if_icmpge -> 166
    //   155: aload #16
    //   157: iload_2
    //   158: iconst_1
    //   159: isub
    //   160: putfield b : I
    //   163: goto -> 228
    //   166: aload #16
    //   168: getfield d : I
    //   171: istore #5
    //   173: iload_1
    //   174: iload_2
    //   175: iload #5
    //   177: iadd
    //   178: if_icmpge -> 228
    //   181: aload #16
    //   183: iload #5
    //   185: iconst_1
    //   186: isub
    //   187: putfield d : I
    //   190: aload #14
    //   192: getfield a : Landroidx/recyclerview/widget/p$a;
    //   195: astore #12
    //   197: aload #17
    //   199: getfield b : I
    //   202: istore_1
    //   203: aload #16
    //   205: getfield c : Ljava/lang/Object;
    //   208: astore #13
    //   210: aload #12
    //   212: checkcast androidx/recyclerview/widget/a
    //   215: iconst_4
    //   216: iload_1
    //   217: iconst_1
    //   218: aload #13
    //   220: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   223: astore #12
    //   225: goto -> 231
    //   228: aconst_null
    //   229: astore #12
    //   231: aload #17
    //   233: getfield b : I
    //   236: istore_1
    //   237: aload #16
    //   239: getfield b : I
    //   242: istore_2
    //   243: iload_1
    //   244: iload_2
    //   245: if_icmpgt -> 259
    //   248: aload #16
    //   250: iload_2
    //   251: iconst_1
    //   252: iadd
    //   253: putfield b : I
    //   256: goto -> 322
    //   259: iload_2
    //   260: aload #16
    //   262: getfield d : I
    //   265: iadd
    //   266: istore_2
    //   267: iload_1
    //   268: iload_2
    //   269: if_icmpge -> 322
    //   272: iload_2
    //   273: iload_1
    //   274: isub
    //   275: istore_2
    //   276: aload #14
    //   278: getfield a : Landroidx/recyclerview/widget/p$a;
    //   281: astore #13
    //   283: aload #16
    //   285: getfield c : Ljava/lang/Object;
    //   288: astore #18
    //   290: aload #13
    //   292: checkcast androidx/recyclerview/widget/a
    //   295: iconst_4
    //   296: iload_1
    //   297: iconst_1
    //   298: iadd
    //   299: iload_2
    //   300: aload #18
    //   302: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   305: astore #13
    //   307: aload #16
    //   309: aload #16
    //   311: getfield d : I
    //   314: iload_2
    //   315: isub
    //   316: putfield d : I
    //   319: goto -> 325
    //   322: aconst_null
    //   323: astore #13
    //   325: aload #15
    //   327: iload #4
    //   329: aload #17
    //   331: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   336: pop
    //   337: aload #16
    //   339: getfield d : I
    //   342: ifle -> 359
    //   345: aload #15
    //   347: iload_3
    //   348: aload #16
    //   350: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   355: pop
    //   356: goto -> 401
    //   359: aload #15
    //   361: iload_3
    //   362: invokeinterface remove : (I)Ljava/lang/Object;
    //   367: pop
    //   368: aload #14
    //   370: getfield a : Landroidx/recyclerview/widget/p$a;
    //   373: checkcast androidx/recyclerview/widget/a
    //   376: astore #17
    //   378: aload #17
    //   380: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   383: pop
    //   384: aload #16
    //   386: aconst_null
    //   387: putfield c : Ljava/lang/Object;
    //   390: aload #17
    //   392: getfield a : Lu/a;
    //   395: aload #16
    //   397: invokevirtual c : (Ljava/lang/Object;)Z
    //   400: pop
    //   401: aload #12
    //   403: ifnull -> 416
    //   406: aload #15
    //   408: iload_3
    //   409: aload #12
    //   411: invokeinterface add : (ILjava/lang/Object;)V
    //   416: aload #13
    //   418: ifnull -> 18
    //   421: aload #15
    //   423: iload_3
    //   424: aload #13
    //   426: invokeinterface add : (ILjava/lang/Object;)V
    //   431: goto -> 18
    //   434: aload #17
    //   436: getfield b : I
    //   439: istore_1
    //   440: aload #17
    //   442: getfield d : I
    //   445: istore #5
    //   447: iload_1
    //   448: iload #5
    //   450: if_icmpge -> 486
    //   453: aload #16
    //   455: getfield b : I
    //   458: iload_1
    //   459: if_icmpne -> 479
    //   462: aload #16
    //   464: getfield d : I
    //   467: iload #5
    //   469: iload_1
    //   470: isub
    //   471: if_icmpne -> 479
    //   474: iconst_0
    //   475: istore_1
    //   476: goto -> 512
    //   479: iconst_0
    //   480: istore_1
    //   481: iconst_0
    //   482: istore_2
    //   483: goto -> 523
    //   486: aload #16
    //   488: getfield b : I
    //   491: iload #5
    //   493: iconst_1
    //   494: iadd
    //   495: if_icmpne -> 519
    //   498: aload #16
    //   500: getfield d : I
    //   503: iload_1
    //   504: iload #5
    //   506: isub
    //   507: if_icmpne -> 519
    //   510: iconst_1
    //   511: istore_1
    //   512: iload_1
    //   513: istore_2
    //   514: iconst_1
    //   515: istore_1
    //   516: goto -> 523
    //   519: iconst_0
    //   520: istore_1
    //   521: iconst_1
    //   522: istore_2
    //   523: aload #16
    //   525: getfield b : I
    //   528: istore #6
    //   530: iload #5
    //   532: iload #6
    //   534: if_icmpge -> 549
    //   537: aload #16
    //   539: iload #6
    //   541: iconst_1
    //   542: isub
    //   543: putfield b : I
    //   546: goto -> 641
    //   549: aload #16
    //   551: getfield d : I
    //   554: istore #7
    //   556: iload #5
    //   558: iload #6
    //   560: iload #7
    //   562: iadd
    //   563: if_icmpge -> 641
    //   566: aload #16
    //   568: iload #7
    //   570: iconst_1
    //   571: isub
    //   572: putfield d : I
    //   575: aload #17
    //   577: iconst_2
    //   578: putfield a : I
    //   581: aload #17
    //   583: iconst_1
    //   584: putfield d : I
    //   587: aload #16
    //   589: getfield d : I
    //   592: ifne -> 18
    //   595: aload #15
    //   597: iload #4
    //   599: invokeinterface remove : (I)Ljava/lang/Object;
    //   604: pop
    //   605: aload #14
    //   607: getfield a : Landroidx/recyclerview/widget/p$a;
    //   610: checkcast androidx/recyclerview/widget/a
    //   613: astore #12
    //   615: aload #12
    //   617: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   620: pop
    //   621: aload #16
    //   623: aconst_null
    //   624: putfield c : Ljava/lang/Object;
    //   627: aload #12
    //   629: getfield a : Lu/a;
    //   632: aload #16
    //   634: invokevirtual c : (Ljava/lang/Object;)Z
    //   637: pop
    //   638: goto -> 18
    //   641: aload #17
    //   643: getfield b : I
    //   646: istore #5
    //   648: aload #16
    //   650: getfield b : I
    //   653: istore #6
    //   655: iload #5
    //   657: iload #6
    //   659: if_icmpgt -> 674
    //   662: aload #16
    //   664: iload #6
    //   666: iconst_1
    //   667: iadd
    //   668: putfield b : I
    //   671: goto -> 734
    //   674: iload #6
    //   676: aload #16
    //   678: getfield d : I
    //   681: iadd
    //   682: istore #6
    //   684: iload #5
    //   686: iload #6
    //   688: if_icmpge -> 734
    //   691: aload #14
    //   693: getfield a : Landroidx/recyclerview/widget/p$a;
    //   696: checkcast androidx/recyclerview/widget/a
    //   699: iconst_2
    //   700: iload #5
    //   702: iconst_1
    //   703: iadd
    //   704: iload #6
    //   706: iload #5
    //   708: isub
    //   709: aconst_null
    //   710: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   713: astore #12
    //   715: aload #16
    //   717: aload #17
    //   719: getfield b : I
    //   722: aload #16
    //   724: getfield b : I
    //   727: isub
    //   728: putfield d : I
    //   731: goto -> 737
    //   734: aconst_null
    //   735: astore #12
    //   737: iload_1
    //   738: ifeq -> 798
    //   741: aload #15
    //   743: iload_3
    //   744: aload #16
    //   746: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   751: pop
    //   752: aload #15
    //   754: iload #4
    //   756: invokeinterface remove : (I)Ljava/lang/Object;
    //   761: pop
    //   762: aload #14
    //   764: getfield a : Landroidx/recyclerview/widget/p$a;
    //   767: checkcast androidx/recyclerview/widget/a
    //   770: astore #12
    //   772: aload #12
    //   774: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   777: pop
    //   778: aload #17
    //   780: aconst_null
    //   781: putfield c : Ljava/lang/Object;
    //   784: aload #12
    //   786: getfield a : Lu/a;
    //   789: aload #17
    //   791: invokevirtual c : (Ljava/lang/Object;)Z
    //   794: pop
    //   795: goto -> 18
    //   798: iload_2
    //   799: ifeq -> 918
    //   802: aload #12
    //   804: ifnull -> 861
    //   807: aload #17
    //   809: getfield b : I
    //   812: istore_1
    //   813: iload_1
    //   814: aload #12
    //   816: getfield b : I
    //   819: if_icmple -> 834
    //   822: aload #17
    //   824: iload_1
    //   825: aload #12
    //   827: getfield d : I
    //   830: isub
    //   831: putfield b : I
    //   834: aload #17
    //   836: getfield d : I
    //   839: istore_1
    //   840: iload_1
    //   841: aload #12
    //   843: getfield b : I
    //   846: if_icmple -> 861
    //   849: aload #17
    //   851: iload_1
    //   852: aload #12
    //   854: getfield d : I
    //   857: isub
    //   858: putfield d : I
    //   861: aload #17
    //   863: getfield b : I
    //   866: istore_1
    //   867: iload_1
    //   868: aload #16
    //   870: getfield b : I
    //   873: if_icmple -> 888
    //   876: aload #17
    //   878: iload_1
    //   879: aload #16
    //   881: getfield d : I
    //   884: isub
    //   885: putfield b : I
    //   888: aload #17
    //   890: getfield d : I
    //   893: istore_1
    //   894: iload_1
    //   895: aload #16
    //   897: getfield b : I
    //   900: if_icmple -> 1031
    //   903: aload #17
    //   905: iload_1
    //   906: aload #16
    //   908: getfield d : I
    //   911: isub
    //   912: putfield d : I
    //   915: goto -> 1031
    //   918: aload #12
    //   920: ifnull -> 977
    //   923: aload #17
    //   925: getfield b : I
    //   928: istore_1
    //   929: iload_1
    //   930: aload #12
    //   932: getfield b : I
    //   935: if_icmplt -> 950
    //   938: aload #17
    //   940: iload_1
    //   941: aload #12
    //   943: getfield d : I
    //   946: isub
    //   947: putfield b : I
    //   950: aload #17
    //   952: getfield d : I
    //   955: istore_1
    //   956: iload_1
    //   957: aload #12
    //   959: getfield b : I
    //   962: if_icmplt -> 977
    //   965: aload #17
    //   967: iload_1
    //   968: aload #12
    //   970: getfield d : I
    //   973: isub
    //   974: putfield d : I
    //   977: aload #17
    //   979: getfield b : I
    //   982: istore_1
    //   983: iload_1
    //   984: aload #16
    //   986: getfield b : I
    //   989: if_icmplt -> 1004
    //   992: aload #17
    //   994: iload_1
    //   995: aload #16
    //   997: getfield d : I
    //   1000: isub
    //   1001: putfield b : I
    //   1004: aload #17
    //   1006: getfield d : I
    //   1009: istore_1
    //   1010: iload_1
    //   1011: aload #16
    //   1013: getfield b : I
    //   1016: if_icmplt -> 1031
    //   1019: aload #17
    //   1021: iload_1
    //   1022: aload #16
    //   1024: getfield d : I
    //   1027: isub
    //   1028: putfield d : I
    //   1031: aload #15
    //   1033: iload_3
    //   1034: aload #16
    //   1036: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   1041: pop
    //   1042: aload #17
    //   1044: getfield b : I
    //   1047: aload #17
    //   1049: getfield d : I
    //   1052: if_icmpeq -> 1070
    //   1055: aload #15
    //   1057: iload #4
    //   1059: aload #17
    //   1061: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   1066: pop
    //   1067: goto -> 1080
    //   1070: aload #15
    //   1072: iload #4
    //   1074: invokeinterface remove : (I)Ljava/lang/Object;
    //   1079: pop
    //   1080: aload #12
    //   1082: ifnull -> 18
    //   1085: aload #15
    //   1087: iload_3
    //   1088: aload #12
    //   1090: invokeinterface add : (ILjava/lang/Object;)V
    //   1095: goto -> 18
    //   1098: aload #17
    //   1100: getfield d : I
    //   1103: istore #5
    //   1105: aload #16
    //   1107: getfield b : I
    //   1110: istore #6
    //   1112: iload #5
    //   1114: iload #6
    //   1116: if_icmpge -> 1124
    //   1119: iconst_m1
    //   1120: istore_1
    //   1121: goto -> 1126
    //   1124: iconst_0
    //   1125: istore_1
    //   1126: aload #17
    //   1128: getfield b : I
    //   1131: istore #7
    //   1133: iload_1
    //   1134: istore_2
    //   1135: iload #7
    //   1137: iload #6
    //   1139: if_icmpge -> 1146
    //   1142: iload_1
    //   1143: iconst_1
    //   1144: iadd
    //   1145: istore_2
    //   1146: iload #6
    //   1148: iload #7
    //   1150: if_icmpgt -> 1166
    //   1153: aload #17
    //   1155: iload #7
    //   1157: aload #16
    //   1159: getfield d : I
    //   1162: iadd
    //   1163: putfield b : I
    //   1166: aload #16
    //   1168: getfield b : I
    //   1171: istore_1
    //   1172: iload_1
    //   1173: iload #5
    //   1175: if_icmpgt -> 1191
    //   1178: aload #17
    //   1180: iload #5
    //   1182: aload #16
    //   1184: getfield d : I
    //   1187: iadd
    //   1188: putfield d : I
    //   1191: aload #16
    //   1193: iload_1
    //   1194: iload_2
    //   1195: iadd
    //   1196: putfield b : I
    //   1199: aload #15
    //   1201: iload_3
    //   1202: aload #16
    //   1204: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   1209: pop
    //   1210: aload #15
    //   1212: iload #4
    //   1214: aload #17
    //   1216: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   1221: pop
    //   1222: goto -> 18
    //   1225: aload_0
    //   1226: getfield b : Ljava/util/ArrayList;
    //   1229: invokevirtual size : ()I
    //   1232: istore #10
    //   1234: iconst_0
    //   1235: istore #7
    //   1237: iload #7
    //   1239: iload #10
    //   1241: if_icmpge -> 1765
    //   1244: aload_0
    //   1245: getfield b : Ljava/util/ArrayList;
    //   1248: iload #7
    //   1250: invokevirtual get : (I)Ljava/lang/Object;
    //   1253: checkcast androidx/recyclerview/widget/a$b
    //   1256: astore #12
    //   1258: aload #12
    //   1260: getfield a : I
    //   1263: istore_1
    //   1264: iload_1
    //   1265: iconst_1
    //   1266: if_icmpeq -> 1750
    //   1269: iload_1
    //   1270: iconst_2
    //   1271: if_icmpeq -> 1530
    //   1274: iload_1
    //   1275: iconst_4
    //   1276: if_icmpeq -> 1297
    //   1279: iload_1
    //   1280: bipush #8
    //   1282: if_icmpeq -> 1288
    //   1285: goto -> 1756
    //   1288: aload_0
    //   1289: aload #12
    //   1291: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1294: goto -> 1756
    //   1297: aload #12
    //   1299: getfield b : I
    //   1302: istore #8
    //   1304: aload #12
    //   1306: getfield d : I
    //   1309: istore #11
    //   1311: iload #8
    //   1313: istore_1
    //   1314: iconst_0
    //   1315: istore_2
    //   1316: iconst_m1
    //   1317: istore #9
    //   1319: iload #8
    //   1321: istore_3
    //   1322: iload_3
    //   1323: iload #11
    //   1325: iload #8
    //   1327: iadd
    //   1328: if_icmpge -> 1460
    //   1331: aload_0
    //   1332: getfield d : Landroidx/recyclerview/widget/a$a;
    //   1335: checkcast androidx/recyclerview/widget/w
    //   1338: iload_3
    //   1339: invokevirtual b : (I)Landroidx/recyclerview/widget/RecyclerView$z;
    //   1342: ifnonnull -> 1405
    //   1345: aload_0
    //   1346: iload_3
    //   1347: invokevirtual a : (I)Z
    //   1350: ifeq -> 1356
    //   1353: goto -> 1405
    //   1356: iload_1
    //   1357: istore #5
    //   1359: iload_2
    //   1360: istore #4
    //   1362: iload #9
    //   1364: iconst_1
    //   1365: if_icmpne -> 1390
    //   1368: aload_0
    //   1369: aload_0
    //   1370: iconst_4
    //   1371: iload_1
    //   1372: iload_2
    //   1373: aload #12
    //   1375: getfield c : Ljava/lang/Object;
    //   1378: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1381: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1384: iload_3
    //   1385: istore #5
    //   1387: iconst_0
    //   1388: istore #4
    //   1390: iconst_0
    //   1391: istore_2
    //   1392: iload #5
    //   1394: istore_1
    //   1395: iload #4
    //   1397: istore #6
    //   1399: iload_2
    //   1400: istore #4
    //   1402: goto -> 1444
    //   1405: iload_1
    //   1406: istore #5
    //   1408: iload_2
    //   1409: istore #6
    //   1411: iload #9
    //   1413: ifne -> 1438
    //   1416: aload_0
    //   1417: aload_0
    //   1418: iconst_4
    //   1419: iload_1
    //   1420: iload_2
    //   1421: aload #12
    //   1423: getfield c : Ljava/lang/Object;
    //   1426: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1429: invokevirtual d : (Landroidx/recyclerview/widget/a$b;)V
    //   1432: iload_3
    //   1433: istore #5
    //   1435: iconst_0
    //   1436: istore #6
    //   1438: iconst_1
    //   1439: istore #4
    //   1441: iload #5
    //   1443: istore_1
    //   1444: iload #6
    //   1446: iconst_1
    //   1447: iadd
    //   1448: istore_2
    //   1449: iload_3
    //   1450: iconst_1
    //   1451: iadd
    //   1452: istore_3
    //   1453: iload #4
    //   1455: istore #9
    //   1457: goto -> 1322
    //   1460: aload #12
    //   1462: astore #13
    //   1464: iload_2
    //   1465: aload #12
    //   1467: getfield d : I
    //   1470: if_icmpeq -> 1507
    //   1473: aload #12
    //   1475: getfield c : Ljava/lang/Object;
    //   1478: astore #13
    //   1480: aload #12
    //   1482: aconst_null
    //   1483: putfield c : Ljava/lang/Object;
    //   1486: aload_0
    //   1487: getfield a : Lu/a;
    //   1490: aload #12
    //   1492: invokevirtual c : (Ljava/lang/Object;)Z
    //   1495: pop
    //   1496: aload_0
    //   1497: iconst_4
    //   1498: iload_1
    //   1499: iload_2
    //   1500: aload #13
    //   1502: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1505: astore #13
    //   1507: iload #9
    //   1509: ifne -> 1521
    //   1512: aload_0
    //   1513: aload #13
    //   1515: invokevirtual d : (Landroidx/recyclerview/widget/a$b;)V
    //   1518: goto -> 1756
    //   1521: aload_0
    //   1522: aload #13
    //   1524: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1527: goto -> 1756
    //   1530: aload #12
    //   1532: getfield b : I
    //   1535: istore #6
    //   1537: aload #12
    //   1539: getfield d : I
    //   1542: iload #6
    //   1544: iadd
    //   1545: istore #4
    //   1547: iload #6
    //   1549: istore_1
    //   1550: iconst_0
    //   1551: istore #5
    //   1553: iconst_m1
    //   1554: istore_2
    //   1555: iload_1
    //   1556: iload #4
    //   1558: if_icmpge -> 1686
    //   1561: aload_0
    //   1562: getfield d : Landroidx/recyclerview/widget/a$a;
    //   1565: checkcast androidx/recyclerview/widget/w
    //   1568: iload_1
    //   1569: invokevirtual b : (I)Landroidx/recyclerview/widget/RecyclerView$z;
    //   1572: ifnonnull -> 1623
    //   1575: aload_0
    //   1576: iload_1
    //   1577: invokevirtual a : (I)Z
    //   1580: ifeq -> 1586
    //   1583: goto -> 1623
    //   1586: iload_2
    //   1587: iconst_1
    //   1588: if_icmpne -> 1610
    //   1591: aload_0
    //   1592: aload_0
    //   1593: iconst_2
    //   1594: iload #6
    //   1596: iload #5
    //   1598: aconst_null
    //   1599: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1602: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1605: iconst_1
    //   1606: istore_2
    //   1607: goto -> 1612
    //   1610: iconst_0
    //   1611: istore_2
    //   1612: iconst_0
    //   1613: istore #8
    //   1615: iload_2
    //   1616: istore_3
    //   1617: iload #8
    //   1619: istore_2
    //   1620: goto -> 1650
    //   1623: iload_2
    //   1624: ifne -> 1646
    //   1627: aload_0
    //   1628: aload_0
    //   1629: iconst_2
    //   1630: iload #6
    //   1632: iload #5
    //   1634: aconst_null
    //   1635: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1638: invokevirtual d : (Landroidx/recyclerview/widget/a$b;)V
    //   1641: iconst_1
    //   1642: istore_3
    //   1643: goto -> 1648
    //   1646: iconst_0
    //   1647: istore_3
    //   1648: iconst_1
    //   1649: istore_2
    //   1650: iload_3
    //   1651: ifeq -> 1671
    //   1654: iload_1
    //   1655: iload #5
    //   1657: isub
    //   1658: istore_1
    //   1659: iload #4
    //   1661: iload #5
    //   1663: isub
    //   1664: istore #4
    //   1666: iconst_1
    //   1667: istore_3
    //   1668: goto -> 1676
    //   1671: iload #5
    //   1673: iconst_1
    //   1674: iadd
    //   1675: istore_3
    //   1676: iload_1
    //   1677: iconst_1
    //   1678: iadd
    //   1679: istore_1
    //   1680: iload_3
    //   1681: istore #5
    //   1683: goto -> 1555
    //   1686: aload #12
    //   1688: astore #13
    //   1690: iload #5
    //   1692: aload #12
    //   1694: getfield d : I
    //   1697: if_icmpeq -> 1728
    //   1700: aload #12
    //   1702: aconst_null
    //   1703: putfield c : Ljava/lang/Object;
    //   1706: aload_0
    //   1707: getfield a : Lu/a;
    //   1710: aload #12
    //   1712: invokevirtual c : (Ljava/lang/Object;)Z
    //   1715: pop
    //   1716: aload_0
    //   1717: iconst_2
    //   1718: iload #6
    //   1720: iload #5
    //   1722: aconst_null
    //   1723: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1726: astore #13
    //   1728: iload_2
    //   1729: ifne -> 1741
    //   1732: aload_0
    //   1733: aload #13
    //   1735: invokevirtual d : (Landroidx/recyclerview/widget/a$b;)V
    //   1738: goto -> 1756
    //   1741: aload_0
    //   1742: aload #13
    //   1744: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1747: goto -> 1756
    //   1750: aload_0
    //   1751: aload #12
    //   1753: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1756: iload #7
    //   1758: iconst_1
    //   1759: iadd
    //   1760: istore #7
    //   1762: goto -> 1237
    //   1765: aload_0
    //   1766: getfield b : Ljava/util/ArrayList;
    //   1769: invokevirtual clear : ()V
    //   1772: return
  }
  
  public void k(b paramb) {
    paramb.c = null;
    this.a.c(paramb);
  }
  
  public void l(List<b> paramList) {
    int j = paramList.size();
    for (int i = 0; i < j; i++)
      k(paramList.get(i)); 
    paramList.clear();
  }
  
  public final int m(int paramInt1, int paramInt2) {
    int j = this.c.size() - 1;
    int i;
    for (i = paramInt1; j >= 0; i = paramInt1) {
      b b = this.c.get(j);
      int k = b.a;
      if (k == 8) {
        int n;
        int i1;
        k = b.b;
        int m = b.d;
        if (k < m) {
          n = k;
          paramInt1 = m;
          i1 = paramInt1;
        } else {
          i1 = k;
          paramInt1 = m;
          n = paramInt1;
        } 
        if (i >= n && i <= i1) {
          if (n == k) {
            if (paramInt2 == 1) {
              b.d = m + 1;
            } else if (paramInt2 == 2) {
              b.d = m - 1;
            } 
            paramInt1 = i + 1;
          } else {
            if (paramInt2 == 1) {
              b.b = k + 1;
            } else if (paramInt2 == 2) {
              b.b = k - 1;
            } 
            paramInt1 = i - 1;
          } 
        } else {
          paramInt1 = i;
          if (i < k)
            if (paramInt2 == 1) {
              b.b = k + 1;
              b.d = m + 1;
              paramInt1 = i;
            } else {
              paramInt1 = i;
              if (paramInt2 == 2) {
                b.b = k - 1;
                b.d = m - 1;
                paramInt1 = i;
              } 
            }  
        } 
      } else {
        int m = b.b;
        if (m <= i) {
          if (k == 1) {
            paramInt1 = i - b.d;
          } else {
            paramInt1 = i;
            if (k == 2)
              paramInt1 = i + b.d; 
          } 
        } else if (paramInt2 == 1) {
          b.b = m + 1;
          paramInt1 = i;
        } else {
          paramInt1 = i;
          if (paramInt2 == 2) {
            b.b = m - 1;
            paramInt1 = i;
          } 
        } 
      } 
      j--;
    } 
    for (paramInt1 = this.c.size() - 1; paramInt1 >= 0; paramInt1--) {
      b b = this.c.get(paramInt1);
      if (b.a == 8) {
        paramInt2 = b.d;
        if (paramInt2 == b.b || paramInt2 < 0) {
          this.c.remove(paramInt1);
          b.c = null;
          this.a.c(b);
        } 
      } else if (b.d <= 0) {
        this.c.remove(paramInt1);
        b.c = null;
        this.a.c(b);
      } 
    } 
    return i;
  }
  
  public static interface a {}
  
  public static class b {
    public int a;
    
    public int b;
    
    public Object c;
    
    public int d;
    
    public b(int param1Int1, int param1Int2, int param1Int3, Object param1Object) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.d = param1Int3;
      this.c = param1Object;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (b.class != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        int i = this.a;
        if (i != ((b)param1Object).a)
          return false; 
        if (i == 8 && Math.abs(this.d - this.b) == 1 && this.d == ((b)param1Object).b && this.b == ((b)param1Object).d)
          return true; 
        if (this.d != ((b)param1Object).d)
          return false; 
        if (this.b != ((b)param1Object).b)
          return false; 
        Object object = this.c;
        if (object != null) {
          if (!object.equals(((b)param1Object).c))
            return false; 
        } else if (((b)param1Object).c != null) {
          return false;
        } 
        return true;
      } 
      return false;
    }
    
    public int hashCode() {
      return (this.a * 31 + this.b) * 31 + this.d;
    }
    
    public String toString() {
      String str;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append("[");
      int i = this.a;
      if (i != 1) {
        if (i != 2) {
          if (i != 4) {
            if (i != 8) {
              str = "??";
            } else {
              str = "mv";
            } 
          } else {
            str = "up";
          } 
        } else {
          str = "rm";
        } 
      } else {
        str = "add";
      } 
      stringBuilder.append(str);
      stringBuilder.append(",s:");
      stringBuilder.append(this.b);
      stringBuilder.append("c:");
      stringBuilder.append(this.d);
      stringBuilder.append(",p:");
      stringBuilder.append(this.c);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\recyclerview\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */