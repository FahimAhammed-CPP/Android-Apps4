package androidx.savedstate;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.h;
import androidx.lifecycle.j;

class SavedStateRegistry$1 implements h {
  public SavedStateRegistry$1(a parama) {}
  
  public void a(j paramj, Lifecycle.Event paramEvent) {
    if (paramEvent == Lifecycle.Event.ON_START) {
      this.f.e = true;
      return;
    } 
    if (paramEvent == Lifecycle.Event.ON_STOP)
      this.f.e = false; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\savedstate\SavedStateRegistry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */