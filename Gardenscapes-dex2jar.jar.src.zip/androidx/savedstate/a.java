package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;

@SuppressLint({"RestrictedApi"})
public final class a {
  public m.b<String, b> a = new m.b();
  
  public Bundle b;
  
  public boolean c;
  
  public Recreator.a d;
  
  public boolean e = true;
  
  public Bundle a(String paramString) {
    if (this.c) {
      Bundle bundle = this.b;
      if (bundle != null) {
        bundle = bundle.getBundle(paramString);
        this.b.remove(paramString);
        if (this.b.isEmpty())
          this.b = null; 
        return bundle;
      } 
      return null;
    } 
    throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
  }
  
  public void b(String paramString, b paramb) {
    if ((b)this.a.h(paramString, paramb) == null)
      return; 
    throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
  }
  
  public void c(Class<? extends a> paramClass) {
    if (this.e) {
      String str;
      if (this.d == null)
        this.d = new Recreator.a(this); 
      try {
        paramClass.getDeclaredConstructor(new Class[0]);
        Recreator.a a1 = this.d;
        str = paramClass.getName();
        a1.a.add(str);
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = android.support.v4.media.a.a("Class");
        stringBuilder.append(str.getSimpleName());
        stringBuilder.append(" must have default constructor in order to be automatically recreated");
        throw new IllegalArgumentException(stringBuilder.toString(), noSuchMethodException);
      } 
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  public static interface a {
    void a(c param1c);
  }
  
  public static interface b {
    Bundle a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\savedstate\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */