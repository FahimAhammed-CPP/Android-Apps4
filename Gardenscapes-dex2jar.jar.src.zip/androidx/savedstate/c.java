package androidx.savedstate;

import androidx.lifecycle.j;

public interface c extends j {
  a getSavedStateRegistry();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\savedstate\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */