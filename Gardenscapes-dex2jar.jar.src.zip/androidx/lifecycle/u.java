package androidx.lifecycle;

import android.annotation.SuppressLint;
import android.app.Application;
import android.os.Bundle;
import androidx.savedstate.a;
import androidx.savedstate.c;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public final class u extends z {
  public static final Class<?>[] f = new Class[] { Application.class, t.class };
  
  public static final Class<?>[] g = new Class[] { t.class };
  
  public final Application a;
  
  public final y b;
  
  public final Bundle c;
  
  public final Lifecycle d;
  
  public final a e;
  
  @SuppressLint({"LambdaLast"})
  public u(Application paramApplication, c paramc, Bundle paramBundle) {
    a0 a0;
    this.e = paramc.getSavedStateRegistry();
    this.d = paramc.getLifecycle();
    this.c = paramBundle;
    this.a = paramApplication;
    if (paramApplication != null) {
      if (x.c == null)
        x.c = new x(paramApplication); 
      a0 = x.c;
    } else {
      if (a0.a == null)
        a0.a = new a0(); 
      a0 = a0.a;
    } 
    this.b = a0;
  }
  
  public static <T> Constructor<T> d(Class<T> paramClass, Class<?>[] paramArrayOfClass) {
    for (Constructor<T> constructor : paramClass.getConstructors()) {
      if (Arrays.equals((Object[])paramArrayOfClass, (Object[])constructor.getParameterTypes()))
        return constructor; 
    } 
    return null;
  }
  
  public <T extends w> T a(Class<T> paramClass) {
    String str = paramClass.getCanonicalName();
    if (str != null)
      return c(str, paramClass); 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public void b(w paramw) {
    SavedStateHandleController.b(paramw, this.e, this.d);
  }
  
  public <T extends w> T c(String paramString, Class<T> paramClass) {
    IllegalStateException illegalStateException;
    t t;
    StringBuilder stringBuilder;
    Constructor<T> constructor;
    boolean bool = a.class.isAssignableFrom(paramClass);
    if (bool && this.a != null) {
      constructor = d(paramClass, f);
    } else {
      constructor = d(paramClass, g);
    } 
    if (constructor == null)
      return this.b.a(paramClass); 
    a a1 = this.e;
    Lifecycle lifecycle = this.d;
    Bundle bundle2 = this.c;
    Bundle bundle1 = a1.a(paramString);
    Class[] arrayOfClass = t.e;
    if (bundle1 == null && bundle2 == null) {
      t = new t();
    } else {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      if (bundle2 != null)
        for (String str : bundle2.keySet())
          hashMap.put(str, bundle2.get(str));  
      if (t == null) {
        t = new t((Map)hashMap);
      } else {
        ArrayList<String> arrayList1 = t.getParcelableArrayList("keys");
        ArrayList arrayList = t.getParcelableArrayList("values");
        if (arrayList1 != null && arrayList != null && arrayList1.size() == arrayList.size()) {
          for (int i = 0; i < arrayList1.size(); i++)
            hashMap.put(arrayList1.get(i), arrayList.get(i)); 
          t = new t((Map)hashMap);
        } else {
          illegalStateException = new IllegalStateException("Invalid bundle passed as restored state");
          throw illegalStateException;
        } 
      } 
    } 
    SavedStateHandleController savedStateHandleController = new SavedStateHandleController((String)illegalStateException, t);
    savedStateHandleController.c(a1, lifecycle);
    SavedStateHandleController.d(a1, lifecycle);
    if (bool)
      try {
        Application application = this.a;
        if (application != null) {
          w w2 = (w)constructor.newInstance(new Object[] { application, t });
          w2.b("androidx.lifecycle.savedstate.vm.tag", savedStateHandleController);
          return (T)w2;
        } 
        w w1 = (w)constructor.newInstance(new Object[] { t });
        w1.b("androidx.lifecycle.savedstate.vm.tag", savedStateHandleController);
        return (T)w1;
      } catch (IllegalAccessException illegalAccessException) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to access ");
        stringBuilder.append(paramClass);
        throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
      } catch (InstantiationException instantiationException) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("A ");
        stringBuilder.append(paramClass);
        stringBuilder.append(" cannot be instantiated.");
        throw new RuntimeException(stringBuilder.toString(), instantiationException);
      } catch (InvocationTargetException invocationTargetException) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("An exception happened in constructor of ");
        stringBuilder.append(paramClass);
        throw new RuntimeException(stringBuilder.toString(), invocationTargetException.getCause());
      }  
    w w = (w)constructor.newInstance(new Object[] { stringBuilder });
    w.b("androidx.lifecycle.savedstate.vm.tag", savedStateHandleController);
    return (T)w;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycl\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */