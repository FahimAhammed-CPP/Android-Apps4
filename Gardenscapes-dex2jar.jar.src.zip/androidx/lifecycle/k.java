package androidx.lifecycle;

import android.annotation.SuppressLint;
import e.g;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import m.b;

public class k extends Lifecycle {
  public m.a<i, a> a = new m.a();
  
  public Lifecycle.State b;
  
  public final WeakReference<j> c;
  
  public int d = 0;
  
  public boolean e = false;
  
  public boolean f = false;
  
  public ArrayList<Lifecycle.State> g = new ArrayList<Lifecycle.State>();
  
  public final boolean h;
  
  public k(j paramj) {
    this.c = new WeakReference<j>(paramj);
    this.b = Lifecycle.State.g;
    this.h = true;
  }
  
  public static Lifecycle.State f(Lifecycle.State paramState1, Lifecycle.State paramState2) {
    Lifecycle.State state = paramState1;
    if (paramState2 != null) {
      state = paramState1;
      if (paramState2.compareTo(paramState1) < 0)
        state = paramState2; 
    } 
    return state;
  }
  
  public void a(i parami) {
    boolean bool;
    d("addObserver");
    Lifecycle.State state2 = this.b;
    Lifecycle.State state1 = Lifecycle.State.f;
    if (state2 != state1)
      state1 = Lifecycle.State.g; 
    a a1 = new a(parami, state1);
    if ((a)this.a.h(parami, a1) != null)
      return; 
    j j = this.c.get();
    if (j == null)
      return; 
    if (this.d != 0 || this.e) {
      bool = true;
    } else {
      bool = false;
    } 
    state1 = c(parami);
    this.d++;
    while (a1.a.compareTo(state1) < 0 && this.a.j.containsKey(parami)) {
      state1 = a1.a;
      this.g.add(state1);
      Lifecycle.Event event = Lifecycle.Event.e(a1.a);
      if (event != null) {
        a1.a(j, event);
        h();
        Lifecycle.State state = c(parami);
        continue;
      } 
      StringBuilder stringBuilder = android.support.v4.media.a.a("no event up from ");
      stringBuilder.append(a1.a);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    if (!bool)
      i(); 
    this.d--;
  }
  
  public void b(i parami) {
    d("removeObserver");
    this.a.j(parami);
  }
  
  public final Lifecycle.State c(i parami) {
    Lifecycle.State state;
    m.a<i, a> a1 = this.a;
    boolean bool = a1.j.containsKey(parami);
    ArrayList<Lifecycle.State> arrayList = null;
    if (bool) {
      b.c c = ((b.c)a1.j.get(parami)).i;
    } else {
      parami = null;
    } 
    if (parami != null) {
      Lifecycle.State state1 = ((a)((b.c)parami).g).a;
    } else {
      parami = null;
    } 
    if (!this.g.isEmpty()) {
      arrayList = this.g;
      state = arrayList.get(arrayList.size() - 1);
    } 
    return f(f(this.b, (Lifecycle.State)parami), state);
  }
  
  @SuppressLint({"RestrictedApi"})
  public final void d(String paramString) {
    if (this.h) {
      if (l.a.d().b())
        return; 
      throw new IllegalStateException(g.a("Method ", paramString, " must be called on the main thread"));
    } 
  }
  
  public void e(Lifecycle.Event paramEvent) {
    d("handleLifecycleEvent");
    g(paramEvent.b());
  }
  
  public final void g(Lifecycle.State paramState) {
    if (this.b == paramState)
      return; 
    this.b = paramState;
    if (this.e || this.d != 0) {
      this.f = true;
      return;
    } 
    this.e = true;
    i();
    this.e = false;
  }
  
  public final void h() {
    ArrayList<Lifecycle.State> arrayList = this.g;
    arrayList.remove(arrayList.size() - 1);
  }
  
  public final void i() {
    j j = this.c.get();
    if (j != null)
      while (true) {
        m.a<i, a> a1 = this.a;
        int m = ((b)a1).i;
        int i = 1;
        if (m != 0) {
          Lifecycle.State state1 = ((a)((b)a1).f.g).a;
          Lifecycle.State state2 = ((a)((b)a1).g.g).a;
          if (state1 != state2 || this.b != state2)
            i = 0; 
        } 
        if (!i) {
          this.f = false;
          if (this.b.compareTo(((a)((b)a1).f.g).a) < 0) {
            a1 = this.a;
            b.b b = new b.b(((b)a1).g, ((b)a1).f);
            ((b)a1).h.put(b, Boolean.FALSE);
            while (b.hasNext() && !this.f) {
              Map.Entry entry = (Map.Entry)b.next();
              a a2 = (a)entry.getValue();
              while (a2.a.compareTo(this.b) > 0 && !this.f && this.a.contains(entry.getKey())) {
                Lifecycle.Event event;
                i = a2.a.ordinal();
                if (i != 2) {
                  if (i != 3) {
                    if (i != 4) {
                      a1 = null;
                    } else {
                      event = Lifecycle.Event.ON_PAUSE;
                    } 
                  } else {
                    event = Lifecycle.Event.ON_STOP;
                  } 
                } else {
                  event = Lifecycle.Event.ON_DESTROY;
                } 
                if (event != null) {
                  Lifecycle.State state = event.b();
                  this.g.add(state);
                  a2.a(j, event);
                  h();
                  continue;
                } 
                StringBuilder stringBuilder = android.support.v4.media.a.a("no event down from ");
                stringBuilder.append(a2.a);
                throw new IllegalStateException(stringBuilder.toString());
              } 
            } 
          } 
          b.c c = ((b)this.a).g;
          if (!this.f && c != null && this.b.compareTo(((a)c.g).a) > 0) {
            b.d d = this.a.c();
            while (d.hasNext() && !this.f) {
              Map.Entry entry = (Map.Entry)d.next();
              a a2 = (a)entry.getValue();
              while (a2.a.compareTo(this.b) < 0 && !this.f && this.a.contains(entry.getKey())) {
                Lifecycle.State state = a2.a;
                this.g.add(state);
                Lifecycle.Event event = Lifecycle.Event.e(a2.a);
                if (event != null) {
                  a2.a(j, event);
                  h();
                  continue;
                } 
                StringBuilder stringBuilder = android.support.v4.media.a.a("no event up from ");
                stringBuilder.append(a2.a);
                throw new IllegalStateException(stringBuilder.toString());
              } 
            } 
          } 
          continue;
        } 
        this.f = false;
        return;
      }  
    IllegalStateException illegalStateException = new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
    throw illegalStateException;
  }
  
  public static class a {
    public Lifecycle.State a;
    
    public h b;
    
    public a(i param1i, Lifecycle.State param1State) {
      Map<Class<?>, Integer> map = n.a;
      boolean bool1 = param1i instanceof h;
      boolean bool2 = param1i instanceof e;
      if (bool1 && bool2) {
        param1i = new FullLifecycleObserverAdapter((e)param1i, (h)param1i);
      } else if (bool2) {
        param1i = new FullLifecycleObserverAdapter((e)param1i, null);
      } else if (bool1) {
        param1i = param1i;
      } else {
        Class<?> clazz = param1i.getClass();
        if (n.c(clazz) == 2) {
          List<Constructor<? extends f>> list = (List)((HashMap)n.b).get(clazz);
          int k = list.size();
          int j = 0;
          if (k == 1) {
            param1i = new SingleGeneratedAdapterObserver(n.a(list.get(0), param1i));
          } else {
            f[] arrayOfF = new f[list.size()];
            while (j < list.size()) {
              arrayOfF[j] = n.a(list.get(j), param1i);
              j++;
            } 
            param1i = new CompositeGeneratedAdaptersObserver(arrayOfF);
          } 
        } else {
          param1i = new ReflectiveGenericLifecycleObserver(param1i);
        } 
      } 
      this.b = (h)param1i;
      this.a = param1State;
    }
    
    public void a(j param1j, Lifecycle.Event param1Event) {
      Lifecycle.State state = param1Event.b();
      this.a = k.f(this.a, state);
      this.b.a(param1j, param1Event);
      this.a = state;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */