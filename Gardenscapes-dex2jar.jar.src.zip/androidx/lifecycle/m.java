package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class m extends Service implements j {
  public final v f = new v(this);
  
  public Lifecycle getLifecycle() {
    return this.f.a;
  }
  
  public IBinder onBind(Intent paramIntent) {
    this.f.a(Lifecycle.Event.ON_START);
    return null;
  }
  
  public void onCreate() {
    this.f.a(Lifecycle.Event.ON_CREATE);
    super.onCreate();
  }
  
  public void onDestroy() {
    v v1 = this.f;
    v1.a(Lifecycle.Event.ON_STOP);
    v1.a(Lifecycle.Event.ON_DESTROY);
    super.onDestroy();
  }
  
  public void onStart(Intent paramIntent, int paramInt) {
    this.f.a(Lifecycle.Event.ON_START);
    super.onStart(paramIntent, paramInt);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */