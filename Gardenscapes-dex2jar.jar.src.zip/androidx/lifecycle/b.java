package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Deprecated
public final class b {
  public static b c = new b();
  
  public final Map<Class<?>, a> a = new HashMap<Class<?>, a>();
  
  public final Map<Class<?>, Boolean> b = new HashMap<Class<?>, Boolean>();
  
  public final a a(Class<?> paramClass, Method[] paramArrayOfMethod) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getSuperclass : ()Ljava/lang/Class;
    //   4: astore #8
    //   6: new java/util/HashMap
    //   9: dup
    //   10: invokespecial <init> : ()V
    //   13: astore #7
    //   15: aload #8
    //   17: ifnull -> 43
    //   20: aload_0
    //   21: aload #8
    //   23: invokevirtual b : (Ljava/lang/Class;)Landroidx/lifecycle/b$a;
    //   26: astore #8
    //   28: aload #8
    //   30: ifnull -> 43
    //   33: aload #7
    //   35: aload #8
    //   37: getfield b : Ljava/util/Map;
    //   40: invokevirtual putAll : (Ljava/util/Map;)V
    //   43: aload_1
    //   44: invokevirtual getInterfaces : ()[Ljava/lang/Class;
    //   47: astore #8
    //   49: aload #8
    //   51: arraylength
    //   52: istore #4
    //   54: iconst_0
    //   55: istore_3
    //   56: iload_3
    //   57: iload #4
    //   59: if_icmpge -> 144
    //   62: aload_0
    //   63: aload #8
    //   65: iload_3
    //   66: aaload
    //   67: invokevirtual b : (Ljava/lang/Class;)Landroidx/lifecycle/b$a;
    //   70: getfield b : Ljava/util/Map;
    //   73: invokeinterface entrySet : ()Ljava/util/Set;
    //   78: invokeinterface iterator : ()Ljava/util/Iterator;
    //   83: astore #9
    //   85: aload #9
    //   87: invokeinterface hasNext : ()Z
    //   92: ifeq -> 137
    //   95: aload #9
    //   97: invokeinterface next : ()Ljava/lang/Object;
    //   102: checkcast java/util/Map$Entry
    //   105: astore #10
    //   107: aload_0
    //   108: aload #7
    //   110: aload #10
    //   112: invokeinterface getKey : ()Ljava/lang/Object;
    //   117: checkcast androidx/lifecycle/b$b
    //   120: aload #10
    //   122: invokeinterface getValue : ()Ljava/lang/Object;
    //   127: checkcast androidx/lifecycle/Lifecycle$Event
    //   130: aload_1
    //   131: invokevirtual c : (Ljava/util/Map;Landroidx/lifecycle/b$b;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Class;)V
    //   134: goto -> 85
    //   137: iload_3
    //   138: iconst_1
    //   139: iadd
    //   140: istore_3
    //   141: goto -> 56
    //   144: aload_2
    //   145: ifnull -> 151
    //   148: goto -> 156
    //   151: aload_1
    //   152: invokevirtual getDeclaredMethods : ()[Ljava/lang/reflect/Method;
    //   155: astore_2
    //   156: aload_2
    //   157: arraylength
    //   158: istore #5
    //   160: iconst_0
    //   161: istore #4
    //   163: iconst_0
    //   164: istore #6
    //   166: iload #4
    //   168: iload #5
    //   170: if_icmpge -> 350
    //   173: aload_2
    //   174: iload #4
    //   176: aaload
    //   177: astore #8
    //   179: aload #8
    //   181: ldc androidx/lifecycle/q
    //   183: invokevirtual getAnnotation : (Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    //   186: checkcast androidx/lifecycle/q
    //   189: astore #10
    //   191: aload #10
    //   193: ifnonnull -> 199
    //   196: goto -> 331
    //   199: aload #8
    //   201: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
    //   204: astore #9
    //   206: aload #9
    //   208: arraylength
    //   209: ifle -> 239
    //   212: aload #9
    //   214: iconst_0
    //   215: aaload
    //   216: ldc androidx/lifecycle/j
    //   218: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   221: ifeq -> 229
    //   224: iconst_1
    //   225: istore_3
    //   226: goto -> 241
    //   229: new java/lang/IllegalArgumentException
    //   232: dup
    //   233: ldc 'invalid parameter type. Must be one and instanceof LifecycleOwner'
    //   235: invokespecial <init> : (Ljava/lang/String;)V
    //   238: athrow
    //   239: iconst_0
    //   240: istore_3
    //   241: aload #10
    //   243: invokeinterface value : ()Landroidx/lifecycle/Lifecycle$Event;
    //   248: astore #10
    //   250: aload #9
    //   252: arraylength
    //   253: iconst_1
    //   254: if_icmple -> 302
    //   257: aload #9
    //   259: iconst_1
    //   260: aaload
    //   261: ldc androidx/lifecycle/Lifecycle$Event
    //   263: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   266: ifeq -> 292
    //   269: aload #10
    //   271: getstatic androidx/lifecycle/Lifecycle$Event.ON_ANY : Landroidx/lifecycle/Lifecycle$Event;
    //   274: if_acmpne -> 282
    //   277: iconst_2
    //   278: istore_3
    //   279: goto -> 302
    //   282: new java/lang/IllegalArgumentException
    //   285: dup
    //   286: ldc 'Second arg is supported only for ON_ANY value'
    //   288: invokespecial <init> : (Ljava/lang/String;)V
    //   291: athrow
    //   292: new java/lang/IllegalArgumentException
    //   295: dup
    //   296: ldc 'invalid parameter type. second arg must be an event'
    //   298: invokespecial <init> : (Ljava/lang/String;)V
    //   301: athrow
    //   302: aload #9
    //   304: arraylength
    //   305: iconst_2
    //   306: if_icmpgt -> 340
    //   309: aload_0
    //   310: aload #7
    //   312: new androidx/lifecycle/b$b
    //   315: dup
    //   316: iload_3
    //   317: aload #8
    //   319: invokespecial <init> : (ILjava/lang/reflect/Method;)V
    //   322: aload #10
    //   324: aload_1
    //   325: invokevirtual c : (Ljava/util/Map;Landroidx/lifecycle/b$b;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Class;)V
    //   328: iconst_1
    //   329: istore #6
    //   331: iload #4
    //   333: iconst_1
    //   334: iadd
    //   335: istore #4
    //   337: goto -> 166
    //   340: new java/lang/IllegalArgumentException
    //   343: dup
    //   344: ldc 'cannot have more than 2 params'
    //   346: invokespecial <init> : (Ljava/lang/String;)V
    //   349: athrow
    //   350: new androidx/lifecycle/b$a
    //   353: dup
    //   354: aload #7
    //   356: invokespecial <init> : (Ljava/util/Map;)V
    //   359: astore_2
    //   360: aload_0
    //   361: getfield a : Ljava/util/Map;
    //   364: aload_1
    //   365: aload_2
    //   366: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   371: pop
    //   372: aload_0
    //   373: getfield b : Ljava/util/Map;
    //   376: aload_1
    //   377: iload #6
    //   379: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   382: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   387: pop
    //   388: aload_2
    //   389: areturn
    //   390: astore_1
    //   391: new java/lang/IllegalArgumentException
    //   394: dup
    //   395: ldc 'The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.'
    //   397: aload_1
    //   398: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   401: astore_1
    //   402: goto -> 407
    //   405: aload_1
    //   406: athrow
    //   407: goto -> 405
    // Exception table:
    //   from	to	target	type
    //   151	156	390	java/lang/NoClassDefFoundError
  }
  
  public a b(Class<?> paramClass) {
    a a = this.a.get(paramClass);
    return (a != null) ? a : a(paramClass, null);
  }
  
  public final void c(Map<b, Lifecycle.Event> paramMap, b paramb, Lifecycle.Event paramEvent, Class<?> paramClass) {
    Lifecycle.Event event = paramMap.get(paramb);
    if (event == null || paramEvent == event) {
      if (event == null)
        paramMap.put(paramb, paramEvent); 
      return;
    } 
    Method method = paramb.b;
    StringBuilder stringBuilder = android.support.v4.media.a.a("Method ");
    stringBuilder.append(method.getName());
    stringBuilder.append(" in ");
    stringBuilder.append(paramClass.getName());
    stringBuilder.append(" already declared with different @OnLifecycleEvent value: previous value ");
    stringBuilder.append(event);
    stringBuilder.append(", new value ");
    stringBuilder.append(paramEvent);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  @Deprecated
  public static class a {
    public final Map<Lifecycle.Event, List<b.b>> a;
    
    public final Map<b.b, Lifecycle.Event> b;
    
    public a(Map<b.b, Lifecycle.Event> param1Map) {
      this.b = param1Map;
      this.a = new HashMap<Lifecycle.Event, List<b.b>>();
      for (Map.Entry<b.b, Lifecycle.Event> entry : param1Map.entrySet()) {
        Lifecycle.Event event = (Lifecycle.Event)entry.getValue();
        List<b.b> list2 = this.a.get(event);
        List<b.b> list1 = list2;
        if (list2 == null) {
          list1 = new ArrayList();
          this.a.put(event, list1);
        } 
        list1.add((b.b)entry.getKey());
      } 
    }
    
    public static void a(List<b.b> param1List, j param1j, Lifecycle.Event param1Event, Object param1Object) {
      if (param1List != null) {
        int i = param1List.size() - 1;
        while (i >= 0) {
          b.b b = param1List.get(i);
          Objects.requireNonNull(b);
          try {
            int k = b.a;
            if (k != 0) {
              if (k != 1) {
                if (k == 2)
                  b.b.invoke(param1Object, new Object[] { param1j, param1Event }); 
              } else {
                b.b.invoke(param1Object, new Object[] { param1j });
              } 
            } else {
              b.b.invoke(param1Object, new Object[0]);
            } 
            i--;
          } catch (InvocationTargetException invocationTargetException) {
            throw new RuntimeException("Failed to call observer method", invocationTargetException.getCause());
          } catch (IllegalAccessException illegalAccessException) {
            throw new RuntimeException(illegalAccessException);
          } 
        } 
      } 
    }
  }
  
  @Deprecated
  public static final class b {
    public final int a;
    
    public final Method b;
    
    public b(int param1Int, Method param1Method) {
      this.a = param1Int;
      this.b = param1Method;
      param1Method.setAccessible(true);
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof b))
        return false; 
      param1Object = param1Object;
      return (this.a == ((b)param1Object).a && this.b.getName().equals(((b)param1Object).b.getName()));
    }
    
    public int hashCode() {
      int i = this.a;
      return this.b.getName().hashCode() + i * 31;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */