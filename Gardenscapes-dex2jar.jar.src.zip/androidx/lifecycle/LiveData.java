package androidx.lifecycle;

import e.g;
import java.util.Map;

public abstract class LiveData<T> {
  public static final Object k = new Object();
  
  public final Object a = new Object();
  
  public m.b<p<? super T>, c> b = new m.b();
  
  public int c = 0;
  
  public boolean d;
  
  public volatile Object e;
  
  public volatile Object f;
  
  public int g;
  
  public boolean h;
  
  public boolean i;
  
  public final Runnable j;
  
  public LiveData() {
    Object object = k;
    this.f = object;
    this.j = new a(this);
    this.e = object;
    this.g = -1;
  }
  
  public static void a(String paramString) {
    if (l.a.d().b())
      return; 
    throw new IllegalStateException(g.a("Cannot invoke ", paramString, " on a background thread"));
  }
  
  public final void b(c paramc) {
    if (!paramc.g)
      return; 
    if (!paramc.e()) {
      paramc.b(false);
      return;
    } 
    int i = paramc.h;
    int j = this.g;
    if (i >= j)
      return; 
    paramc.h = j;
    paramc.f.a((T)this.e);
  }
  
  public void c(c paramc) {
    if (this.h) {
      this.i = true;
      return;
    } 
    this.h = true;
    while (true) {
      c c1;
      this.i = false;
      if (paramc != null) {
        b(paramc);
        c1 = null;
      } else {
        m.b.d d = this.b.c();
        while (true) {
          c1 = paramc;
          if (d.hasNext()) {
            b((c)((Map.Entry)d.next()).getValue());
            if (this.i) {
              c1 = paramc;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramc = c1;
      if (!this.i) {
        this.h = false;
        return;
      } 
    } 
  }
  
  public void d(j paramj, p<? super T> paramp) {
    a("observe");
    if (((k)paramj.getLifecycle()).b == Lifecycle.State.f)
      return; 
    LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(this, paramj, paramp);
    c c = (c)this.b.h(paramp, lifecycleBoundObserver);
    if (c == null || c.d(paramj)) {
      if (c != null)
        return; 
      paramj.getLifecycle().a(lifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void e(p<? super T> paramp) {
    a("observeForever");
    b b1 = new b(this, paramp);
    c c = (c)this.b.h(paramp, b1);
    if (!(c instanceof LifecycleBoundObserver)) {
      if (c != null)
        return; 
      b1.b(true);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void f() {}
  
  public void g() {}
  
  public void h(p<? super T> paramp) {
    a("removeObserver");
    c c = (c)this.b.j(paramp);
    if (c == null)
      return; 
    c.c();
    c.b(false);
  }
  
  public abstract void i(T paramT);
  
  public class LifecycleBoundObserver extends c implements h {
    public final j j;
    
    public LifecycleBoundObserver(LiveData this$0, j param1j, p<? super T> param1p) {
      super(this$0, param1p);
      this.j = param1j;
    }
    
    public void a(j param1j, Lifecycle.Event param1Event) {
      Lifecycle.State state = ((k)this.j.getLifecycle()).b;
      if (state == Lifecycle.State.f) {
        this.k.h(this.f);
        return;
      } 
      param1Event = null;
      while (param1Event != state) {
        b(e());
        Lifecycle.State state2 = ((k)this.j.getLifecycle()).b;
        Lifecycle.State state1 = state;
        state = state2;
      } 
    }
    
    public void c() {
      k k = (k)this.j.getLifecycle();
      k.d("removeObserver");
      k.a.j(this);
    }
    
    public boolean d(j param1j) {
      return (this.j == param1j);
    }
    
    public boolean e() {
      return (((k)this.j.getLifecycle()).b.compareTo(Lifecycle.State.i) >= 0);
    }
  }
  
  public class a implements Runnable {
    public a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.f.a) {
        Object object = this.f.f;
        this.f.f = LiveData.k;
        this.f.i(object);
        return;
      } 
    }
  }
  
  public class b extends c {
    public b(LiveData this$0, p<? super T> param1p) {
      super(this$0, param1p);
    }
    
    public boolean e() {
      return true;
    }
  }
  
  public abstract class c {
    public final p<? super T> f;
    
    public boolean g;
    
    public int h = -1;
    
    public c(LiveData this$0, p<? super T> param1p) {
      this.f = param1p;
    }
    
    public void b(boolean param1Boolean) {
      byte b;
      if (param1Boolean == this.g)
        return; 
      this.g = param1Boolean;
      LiveData liveData = this.i;
      if (param1Boolean) {
        b = 1;
      } else {
        b = -1;
      } 
      int i = liveData.c;
      liveData.c = b + i;
      if (!liveData.d) {
        liveData.d = true;
        while (true) {
          int j;
          try {
            j = liveData.c;
          } finally {
            liveData.d = false;
          } 
          if (i > 0 && j == 0) {
            i = 1;
          } else {
            i = 0;
          } 
          if (b != 0) {
            liveData.f();
          } else if (i != 0) {
            liveData.g();
          } 
          i = j;
        } 
      } 
      if (this.g)
        this.i.c(this); 
    }
    
    public void c() {}
    
    public boolean d(j param1j) {
      return false;
    }
    
    public abstract boolean e();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */