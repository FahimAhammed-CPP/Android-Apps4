package androidx.lifecycle;

class FullLifecycleObserverAdapter implements h {
  public final e f;
  
  public final h g;
  
  public FullLifecycleObserverAdapter(e parame, h paramh) {
    this.f = parame;
    this.g = paramh;
  }
  
  public void a(j paramj, Lifecycle.Event paramEvent) {
    switch (a.a[paramEvent.ordinal()]) {
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        this.f.onDestroy(paramj);
        break;
      case 5:
        this.f.onStop(paramj);
        break;
      case 4:
        this.f.onPause(paramj);
        break;
      case 3:
        this.f.onResume(paramj);
        break;
      case 2:
        this.f.onStart(paramj);
        break;
      case 1:
        this.f.onCreate(paramj);
        break;
    } 
    h h1 = this.g;
    if (h1 != null)
      h1.a(paramj, paramEvent); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */