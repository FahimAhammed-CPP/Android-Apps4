package androidx.lifecycle;

import android.app.Application;
import java.lang.reflect.InvocationTargetException;

public class x extends a0 {
  public static x c;
  
  public Application b;
  
  public x(Application paramApplication) {
    this.b = paramApplication;
  }
  
  public <T extends w> T a(Class<T> paramClass) {
    if (a.class.isAssignableFrom(paramClass))
      try {
        return (T)paramClass.getConstructor(new Class[] { Application.class }).newInstance(new Object[] { this.b });
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot create an instance of ");
        stringBuilder.append(paramClass);
        throw new RuntimeException(stringBuilder.toString(), noSuchMethodException);
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot create an instance of ");
        stringBuilder.append(paramClass);
        throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
      } catch (InstantiationException instantiationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot create an instance of ");
        stringBuilder.append(paramClass);
        throw new RuntimeException(stringBuilder.toString(), instantiationException);
      } catch (InvocationTargetException invocationTargetException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot create an instance of ");
        stringBuilder.append(paramClass);
        throw new RuntimeException(stringBuilder.toString(), invocationTargetException);
      }  
    return super.a(paramClass);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */