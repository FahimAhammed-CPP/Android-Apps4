package androidx.lifecycle;

public abstract class z extends b0 implements y {
  public <T extends w> T a(Class<T> paramClass) {
    throw new UnsupportedOperationException("create(String, Class<?>) must be called on implementaions of KeyedFactory");
  }
  
  public abstract <T extends w> T c(String paramString, Class<T> paramClass);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */