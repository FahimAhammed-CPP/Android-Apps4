package androidx.lifecycle;

import android.app.Activity;
import android.os.Bundle;
import java.util.concurrent.atomic.AtomicBoolean;

public class g {
  public static AtomicBoolean a = new AtomicBoolean(false);
  
  public static class a extends d {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      s.c(param1Activity);
    }
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStopped(Activity param1Activity) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */