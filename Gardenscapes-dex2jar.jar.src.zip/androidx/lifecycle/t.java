package androidx.lifecycle;

import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class t {
  public static final Class[] e;
  
  public final Map<String, Object> a = new HashMap<String, Object>();
  
  public final Map<String, androidx.savedstate.a.b> b = new HashMap<String, androidx.savedstate.a.b>();
  
  public final Map<String, Object> c = new HashMap<String, Object>();
  
  public final androidx.savedstate.a.b d = new a(this);
  
  static {
    Class<SizeF> clazz;
    Class<int> clazz3;
    Class<boolean> clazz4 = boolean.class;
    Class<double> clazz5 = double.class;
    Class<int> clazz2 = int.class;
    Class<long> clazz6 = long.class;
    Class<byte> clazz7 = byte.class;
    Class<char> clazz8 = char.class;
    Class<float> clazz9 = float.class;
    Class<short> clazz10 = short.class;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      Class<Size> clazz11 = Size.class;
    } else {
      clazz3 = clazz2;
    } 
    Class<int> clazz1 = clazz2;
    if (i >= 21)
      clazz = SizeF.class; 
    e = new Class[] { 
        clazz4, boolean[].class, clazz5, double[].class, clazz2, int[].class, clazz6, long[].class, String.class, String[].class, 
        Binder.class, Bundle.class, clazz7, byte[].class, clazz8, char[].class, CharSequence.class, CharSequence[].class, ArrayList.class, clazz9, 
        float[].class, Parcelable.class, Parcelable[].class, Serializable.class, clazz10, short[].class, SparseArray.class, clazz3, clazz };
  }
  
  public t() {}
  
  public t(Map<String, Object> paramMap) {}
  
  public class a implements androidx.savedstate.a.b {
    public a(t this$0) {}
    
    public Bundle a() {
      Iterator<Map.Entry> iterator = (new HashMap<Object, Object>(this.a.b)).entrySet().iterator();
      label27: while (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        Bundle bundle1 = ((androidx.savedstate.a.b)entry.getValue()).a();
        t t1 = this.a;
        String str = (String)entry.getKey();
        Objects.requireNonNull(t1);
        if (bundle1 == null)
          continue; 
        Class[] arrayOfClass = t.e;
        int j = arrayOfClass.length;
        for (int i = 0; i < j; i++) {
          if (arrayOfClass[i].isInstance(bundle1)) {
            o<Bundle> o = (o)t1.c.get(str);
            if (o != null) {
              o.i(bundle1);
              continue label27;
            } 
            t1.a.put(str, bundle1);
            continue label27;
          } 
        } 
        StringBuilder stringBuilder = android.support.v4.media.a.a("Can't put value with type ");
        stringBuilder.append(bundle1.getClass());
        stringBuilder.append(" into saved state");
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      Set<String> set = this.a.a.keySet();
      ArrayList<String> arrayList = new ArrayList(set.size());
      ArrayList arrayList1 = new ArrayList(arrayList.size());
      for (String str : set) {
        arrayList.add(str);
        arrayList1.add(this.a.a.get(str));
      } 
      Bundle bundle = new Bundle();
      bundle.putParcelableArrayList("keys", arrayList);
      bundle.putParcelableArrayList("values", arrayList1);
      return bundle;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */