package androidx.lifecycle;

public interface e extends i {
  void onCreate(j paramj);
  
  void onDestroy(j paramj);
  
  void onPause(j paramj);
  
  void onResume(j paramj);
  
  void onStart(j paramj);
  
  void onStop(j paramj);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */