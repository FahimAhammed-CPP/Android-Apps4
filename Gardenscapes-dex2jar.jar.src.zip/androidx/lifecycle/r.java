package androidx.lifecycle;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;

public class r extends d {
  public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT < 29) {
      int i = s.g;
      ((s)paramActivity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag")).f = ProcessLifecycleOwner.this.m;
    } 
  }
  
  public void onActivityPaused(Activity paramActivity) {
    ProcessLifecycleOwner processLifecycleOwner = ProcessLifecycleOwner.this;
    int i = processLifecycleOwner.g - 1;
    processLifecycleOwner.g = i;
    if (i == 0)
      processLifecycleOwner.j.postDelayed(processLifecycleOwner.l, 700L); 
  }
  
  public void onActivityPreCreated(Activity paramActivity, Bundle paramBundle) {
    paramActivity.registerActivityLifecycleCallbacks(new a());
  }
  
  public void onActivityStopped(Activity paramActivity) {
    ProcessLifecycleOwner processLifecycleOwner = ProcessLifecycleOwner.this;
    int i = processLifecycleOwner.f - 1;
    processLifecycleOwner.f = i;
    if (i == 0 && processLifecycleOwner.h) {
      processLifecycleOwner.k.e(Lifecycle.Event.ON_STOP);
      processLifecycleOwner.i = true;
    } 
  }
  
  public class a extends d {
    public void onActivityPostResumed(Activity param1Activity) {
      this.this$1.this$0.a();
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      this.this$1.this$0.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */