package androidx.lifecycle;

class Lifecycling$1 implements h {
  public void a(j paramj, Lifecycle.Event paramEvent) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\Lifecycling$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */