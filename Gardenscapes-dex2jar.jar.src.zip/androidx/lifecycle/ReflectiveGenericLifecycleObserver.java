package androidx.lifecycle;

@Deprecated
class ReflectiveGenericLifecycleObserver implements h {
  public final Object f;
  
  public final b.a g;
  
  public ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.f = paramObject;
    this.g = b.c.b(paramObject.getClass());
  }
  
  public void a(j paramj, Lifecycle.Event paramEvent) {
    b.a a1 = this.g;
    Object object = this.f;
    b.a.a(a1.a.get(paramEvent), paramj, paramEvent, object);
    b.a.a(a1.a.get(Lifecycle.Event.ON_ANY), paramj, paramEvent, object);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */