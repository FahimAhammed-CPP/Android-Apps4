package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;

public class s extends Fragment {
  public a f;
  
  public static void a(Activity paramActivity, Lifecycle.Event paramEvent) {
    k k;
    if (paramActivity instanceof l) {
      k = ((l)paramActivity).getLifecycle();
      k.d("handleLifecycleEvent");
      k.g(paramEvent.b());
      return;
    } 
    if (k instanceof j) {
      Lifecycle lifecycle = ((j)k).getLifecycle();
      if (lifecycle instanceof k) {
        lifecycle = lifecycle;
        lifecycle.d("handleLifecycleEvent");
        lifecycle.g(paramEvent.b());
      } 
    } 
  }
  
  public static void c(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 29)
      b.registerIn(paramActivity); 
    FragmentManager fragmentManager = paramActivity.getFragmentManager();
    if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
      fragmentManager.beginTransaction().add(new s(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
      fragmentManager.executePendingTransactions();
    } 
  }
  
  public final void b(Lifecycle.Event paramEvent) {
    if (Build.VERSION.SDK_INT < 29)
      a(getActivity(), paramEvent); 
  }
  
  public void onActivityCreated(Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
    b(Lifecycle.Event.ON_CREATE);
  }
  
  public void onDestroy() {
    super.onDestroy();
    b(Lifecycle.Event.ON_DESTROY);
    this.f = null;
  }
  
  public void onPause() {
    super.onPause();
    b(Lifecycle.Event.ON_PAUSE);
  }
  
  public void onResume() {
    super.onResume();
    a a1 = this.f;
    if (a1 != null)
      ((ProcessLifecycleOwner.b)a1).a.a(); 
    b(Lifecycle.Event.ON_RESUME);
  }
  
  public void onStart() {
    super.onStart();
    a a1 = this.f;
    if (a1 != null)
      ((ProcessLifecycleOwner.b)a1).a.b(); 
    b(Lifecycle.Event.ON_START);
  }
  
  public void onStop() {
    super.onStop();
    b(Lifecycle.Event.ON_STOP);
  }
  
  public static interface a {}
  
  public static class b implements Application.ActivityLifecycleCallbacks {
    public static void registerIn(Activity param1Activity) {
      param1Activity.registerActivityLifecycleCallbacks(new b());
    }
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityDestroyed(Activity param1Activity) {}
    
    public void onActivityPaused(Activity param1Activity) {}
    
    public void onActivityPostCreated(Activity param1Activity, Bundle param1Bundle) {
      s.a(param1Activity, Lifecycle.Event.ON_CREATE);
    }
    
    public void onActivityPostResumed(Activity param1Activity) {
      s.a(param1Activity, Lifecycle.Event.ON_RESUME);
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      s.a(param1Activity, Lifecycle.Event.ON_START);
    }
    
    public void onActivityPreDestroyed(Activity param1Activity) {
      s.a(param1Activity, Lifecycle.Event.ON_DESTROY);
    }
    
    public void onActivityPrePaused(Activity param1Activity) {
      s.a(param1Activity, Lifecycle.Event.ON_PAUSE);
    }
    
    public void onActivityPreStopped(Activity param1Activity) {
      s.a(param1Activity, Lifecycle.Event.ON_STOP);
    }
    
    public void onActivityResumed(Activity param1Activity) {}
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(Activity param1Activity) {}
    
    public void onActivityStopped(Activity param1Activity) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */