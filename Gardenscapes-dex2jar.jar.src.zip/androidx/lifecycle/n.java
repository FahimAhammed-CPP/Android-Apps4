package androidx.lifecycle;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class n {
  public static Map<Class<?>, Integer> a = new HashMap<Class<?>, Integer>();
  
  public static Map<Class<?>, List<Constructor<? extends f>>> b = new HashMap<Class<?>, List<Constructor<? extends f>>>();
  
  public static f a(Constructor<? extends f> paramConstructor, Object paramObject) {
    try {
      return paramConstructor.newInstance(new Object[] { paramObject });
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } catch (InstantiationException instantiationException) {
      throw new RuntimeException(instantiationException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } 
  }
  
  public static String b(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString.replace(".", "_"));
    stringBuilder.append("_LifecycleAdapter");
    return stringBuilder.toString();
  }
  
  public static int c(Class<?> paramClass) {
    // Byte code:
    //   0: getstatic androidx/lifecycle/n.a : Ljava/util/Map;
    //   3: checkcast java/util/HashMap
    //   6: aload_0
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast java/lang/Integer
    //   13: astore #6
    //   15: aload #6
    //   17: ifnull -> 26
    //   20: aload #6
    //   22: invokevirtual intValue : ()I
    //   25: ireturn
    //   26: aload_0
    //   27: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   30: astore #6
    //   32: iconst_1
    //   33: istore_3
    //   34: aload #6
    //   36: ifnonnull -> 44
    //   39: iload_3
    //   40: istore_1
    //   41: goto -> 584
    //   44: aconst_null
    //   45: astore #8
    //   47: aload_0
    //   48: invokevirtual getPackage : ()Ljava/lang/Package;
    //   51: astore #6
    //   53: aload_0
    //   54: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   57: astore #7
    //   59: aload #6
    //   61: ifnull -> 626
    //   64: aload #6
    //   66: invokevirtual getName : ()Ljava/lang/String;
    //   69: astore #6
    //   71: goto -> 74
    //   74: aload #6
    //   76: invokevirtual isEmpty : ()Z
    //   79: ifeq -> 85
    //   82: goto -> 99
    //   85: aload #7
    //   87: aload #6
    //   89: invokevirtual length : ()I
    //   92: iconst_1
    //   93: iadd
    //   94: invokevirtual substring : (I)Ljava/lang/String;
    //   97: astore #7
    //   99: aload #7
    //   101: invokestatic b : (Ljava/lang/String;)Ljava/lang/String;
    //   104: astore #7
    //   106: aload #6
    //   108: invokevirtual isEmpty : ()Z
    //   111: ifeq -> 121
    //   114: aload #7
    //   116: astore #6
    //   118: goto -> 161
    //   121: new java/lang/StringBuilder
    //   124: dup
    //   125: invokespecial <init> : ()V
    //   128: astore #9
    //   130: aload #9
    //   132: aload #6
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: pop
    //   138: aload #9
    //   140: ldc '.'
    //   142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: pop
    //   146: aload #9
    //   148: aload #7
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: pop
    //   154: aload #9
    //   156: invokevirtual toString : ()Ljava/lang/String;
    //   159: astore #6
    //   161: aload #6
    //   163: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   166: iconst_1
    //   167: anewarray java/lang/Class
    //   170: dup
    //   171: iconst_0
    //   172: aload_0
    //   173: aastore
    //   174: invokevirtual getDeclaredConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   177: astore #7
    //   179: aload #7
    //   181: astore #6
    //   183: aload #7
    //   185: invokevirtual isAccessible : ()Z
    //   188: ifne -> 217
    //   191: aload #7
    //   193: iconst_1
    //   194: invokevirtual setAccessible : (Z)V
    //   197: aload #7
    //   199: astore #6
    //   201: goto -> 217
    //   204: astore_0
    //   205: new java/lang/RuntimeException
    //   208: dup
    //   209: aload_0
    //   210: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   213: athrow
    //   214: aconst_null
    //   215: astore #6
    //   217: aload #6
    //   219: ifnull -> 251
    //   222: getstatic androidx/lifecycle/n.b : Ljava/util/Map;
    //   225: astore #7
    //   227: aload #6
    //   229: invokestatic singletonList : (Ljava/lang/Object;)Ljava/util/List;
    //   232: astore #6
    //   234: aload #7
    //   236: checkcast java/util/HashMap
    //   239: aload_0
    //   240: aload #6
    //   242: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   245: pop
    //   246: iconst_2
    //   247: istore_1
    //   248: goto -> 584
    //   251: getstatic androidx/lifecycle/b.c : Landroidx/lifecycle/b;
    //   254: astore #6
    //   256: aload #6
    //   258: getfield b : Ljava/util/Map;
    //   261: aload_0
    //   262: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   267: checkcast java/lang/Boolean
    //   270: astore #7
    //   272: aload #7
    //   274: ifnull -> 287
    //   277: aload #7
    //   279: invokevirtual booleanValue : ()Z
    //   282: istore #5
    //   284: goto -> 359
    //   287: aload_0
    //   288: invokevirtual getDeclaredMethods : ()[Ljava/lang/reflect/Method;
    //   291: astore #7
    //   293: aload #7
    //   295: arraylength
    //   296: istore_2
    //   297: iconst_0
    //   298: istore_1
    //   299: iload_1
    //   300: iload_2
    //   301: if_icmpge -> 341
    //   304: aload #7
    //   306: iload_1
    //   307: aaload
    //   308: ldc androidx/lifecycle/q
    //   310: invokevirtual getAnnotation : (Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    //   313: checkcast androidx/lifecycle/q
    //   316: ifnull -> 334
    //   319: aload #6
    //   321: aload_0
    //   322: aload #7
    //   324: invokevirtual a : (Ljava/lang/Class;[Ljava/lang/reflect/Method;)Landroidx/lifecycle/b$a;
    //   327: pop
    //   328: iconst_1
    //   329: istore #5
    //   331: goto -> 359
    //   334: iload_1
    //   335: iconst_1
    //   336: iadd
    //   337: istore_1
    //   338: goto -> 299
    //   341: aload #6
    //   343: getfield b : Ljava/util/Map;
    //   346: aload_0
    //   347: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   350: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   355: pop
    //   356: iconst_0
    //   357: istore #5
    //   359: iload #5
    //   361: ifeq -> 369
    //   364: iload_3
    //   365: istore_1
    //   366: goto -> 584
    //   369: aload_0
    //   370: invokevirtual getSuperclass : ()Ljava/lang/Class;
    //   373: astore #7
    //   375: aload #7
    //   377: ifnull -> 395
    //   380: ldc androidx/lifecycle/i
    //   382: aload #7
    //   384: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   387: ifeq -> 395
    //   390: iconst_1
    //   391: istore_1
    //   392: goto -> 397
    //   395: iconst_0
    //   396: istore_1
    //   397: aload #8
    //   399: astore #6
    //   401: iload_1
    //   402: ifeq -> 442
    //   405: aload #7
    //   407: invokestatic c : (Ljava/lang/Class;)I
    //   410: iconst_1
    //   411: if_icmpne -> 419
    //   414: iload_3
    //   415: istore_1
    //   416: goto -> 584
    //   419: new java/util/ArrayList
    //   422: dup
    //   423: getstatic androidx/lifecycle/n.b : Ljava/util/Map;
    //   426: checkcast java/util/HashMap
    //   429: aload #7
    //   431: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   434: checkcast java/util/Collection
    //   437: invokespecial <init> : (Ljava/util/Collection;)V
    //   440: astore #6
    //   442: aload_0
    //   443: invokevirtual getInterfaces : ()[Ljava/lang/Class;
    //   446: astore #8
    //   448: aload #8
    //   450: arraylength
    //   451: istore #4
    //   453: iconst_0
    //   454: istore_1
    //   455: iload_1
    //   456: iload #4
    //   458: if_icmpge -> 561
    //   461: aload #8
    //   463: iload_1
    //   464: aaload
    //   465: astore #9
    //   467: aload #9
    //   469: ifnull -> 487
    //   472: ldc androidx/lifecycle/i
    //   474: aload #9
    //   476: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   479: ifeq -> 487
    //   482: iconst_1
    //   483: istore_2
    //   484: goto -> 489
    //   487: iconst_0
    //   488: istore_2
    //   489: iload_2
    //   490: ifne -> 496
    //   493: goto -> 554
    //   496: aload #9
    //   498: invokestatic c : (Ljava/lang/Class;)I
    //   501: iconst_1
    //   502: if_icmpne -> 510
    //   505: iload_3
    //   506: istore_1
    //   507: goto -> 584
    //   510: aload #6
    //   512: astore #7
    //   514: aload #6
    //   516: ifnonnull -> 528
    //   519: new java/util/ArrayList
    //   522: dup
    //   523: invokespecial <init> : ()V
    //   526: astore #7
    //   528: aload #7
    //   530: getstatic androidx/lifecycle/n.b : Ljava/util/Map;
    //   533: checkcast java/util/HashMap
    //   536: aload #9
    //   538: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   541: checkcast java/util/Collection
    //   544: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   549: pop
    //   550: aload #7
    //   552: astore #6
    //   554: iload_1
    //   555: iconst_1
    //   556: iadd
    //   557: istore_1
    //   558: goto -> 455
    //   561: iload_3
    //   562: istore_1
    //   563: aload #6
    //   565: ifnull -> 584
    //   568: getstatic androidx/lifecycle/n.b : Ljava/util/Map;
    //   571: checkcast java/util/HashMap
    //   574: aload_0
    //   575: aload #6
    //   577: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   580: pop
    //   581: goto -> 246
    //   584: getstatic androidx/lifecycle/n.a : Ljava/util/Map;
    //   587: checkcast java/util/HashMap
    //   590: aload_0
    //   591: iload_1
    //   592: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   595: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   598: pop
    //   599: iload_1
    //   600: ireturn
    //   601: astore_0
    //   602: new java/lang/IllegalArgumentException
    //   605: dup
    //   606: ldc 'The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.'
    //   608: aload_0
    //   609: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   612: astore_0
    //   613: goto -> 618
    //   616: aload_0
    //   617: athrow
    //   618: goto -> 616
    //   621: astore #6
    //   623: goto -> 214
    //   626: ldc ''
    //   628: astore #6
    //   630: goto -> 74
    // Exception table:
    //   from	to	target	type
    //   47	59	621	java/lang/ClassNotFoundException
    //   47	59	204	java/lang/NoSuchMethodException
    //   64	71	621	java/lang/ClassNotFoundException
    //   64	71	204	java/lang/NoSuchMethodException
    //   74	82	621	java/lang/ClassNotFoundException
    //   74	82	204	java/lang/NoSuchMethodException
    //   85	99	621	java/lang/ClassNotFoundException
    //   85	99	204	java/lang/NoSuchMethodException
    //   99	114	621	java/lang/ClassNotFoundException
    //   99	114	204	java/lang/NoSuchMethodException
    //   121	161	621	java/lang/ClassNotFoundException
    //   121	161	204	java/lang/NoSuchMethodException
    //   161	179	621	java/lang/ClassNotFoundException
    //   161	179	204	java/lang/NoSuchMethodException
    //   183	197	621	java/lang/ClassNotFoundException
    //   183	197	204	java/lang/NoSuchMethodException
    //   287	293	601	java/lang/NoClassDefFoundError
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */