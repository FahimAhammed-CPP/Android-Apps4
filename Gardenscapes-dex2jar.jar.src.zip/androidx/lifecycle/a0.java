package androidx.lifecycle;

public class a0 implements y {
  public static a0 a;
  
  public <T extends w> T a(Class<T> paramClass) {
    try {
      return paramClass.newInstance();
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot create an instance of ");
      stringBuilder.append(paramClass);
      throw new RuntimeException(stringBuilder.toString(), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot create an instance of ");
      stringBuilder.append(paramClass);
      throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\lifecycle\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */