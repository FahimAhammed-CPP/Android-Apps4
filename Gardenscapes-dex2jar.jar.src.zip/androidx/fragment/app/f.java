package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;

public class f implements Animation.AnimationListener {
  public f(c paramc, ViewGroup paramViewGroup, View paramView, c.b paramb) {}
  
  public void onAnimationEnd(Animation paramAnimation) {
    this.a.post(new a(this));
  }
  
  public void onAnimationRepeat(Animation paramAnimation) {}
  
  public void onAnimationStart(Animation paramAnimation) {}
  
  public class a implements Runnable {
    public a(f this$0) {}
    
    public void run() {
      f f1 = this.f;
      f1.a.endViewTransition(f1.b);
      this.f.c.a();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */