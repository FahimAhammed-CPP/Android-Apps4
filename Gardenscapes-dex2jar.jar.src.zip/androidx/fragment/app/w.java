package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import l0.e;

public abstract class w<E> extends s {
  public final Activity f;
  
  public final Context g;
  
  public final Handler h;
  
  public final FragmentManager i = new z();
  
  public w(n paramn) {
    this.f = (Activity)paramn;
    e.d(paramn, "context == null");
    this.g = (Context)paramn;
    this.h = handler;
  }
  
  public abstract E d();
  
  public abstract LayoutInflater e();
  
  public abstract boolean f(Fragment paramFragment);
  
  public abstract boolean g(String paramString);
  
  public abstract void h();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */