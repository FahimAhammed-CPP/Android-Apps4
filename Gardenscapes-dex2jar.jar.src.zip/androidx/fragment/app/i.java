package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;

public class i implements Runnable {
  public i(c paramc, p0 paramp0, View paramView, Rect paramRect) {}
  
  public void run() {
    this.f.j(this.g, this.h);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */