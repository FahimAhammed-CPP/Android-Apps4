package androidx.fragment.app;

import android.content.Context;
import android.os.Build;
import android.util.SparseArray;
import android.view.View;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import m0.y;
import m1.d;
import s.g;
import s.h;

public class n0 {
  static {
    int i = Build.VERSION.SDK_INT;
    Exception exception2 = null;
    if (i >= 21) {
      p01 = new o0();
    } else {
      p01 = null;
    } 
    b = p01;
    try {
      p01 = d.class.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception1) {
      exception1 = exception2;
    } 
    c = (p0)exception1;
  }
  
  public static void a(ArrayList<View> paramArrayList, s.a<String, View> parama, Collection<String> paramCollection) {
    for (int i = ((h)parama).h - 1; i >= 0; i--) {
      View view = (View)parama.k(i);
      if (paramCollection.contains(y.p(view)))
        paramArrayList.add(view); 
    } 
  }
  
  public static void b(a parama, g0.a parama1, SparseArray<b> paramSparseArray, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_1
    //   1: getfield b : Landroidx/fragment/app/Fragment;
    //   4: astore #12
    //   6: aload #12
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload #12
    //   14: getfield mContainerId : I
    //   17: istore #9
    //   19: iload #9
    //   21: ifne -> 25
    //   24: return
    //   25: iload_3
    //   26: ifeq -> 42
    //   29: getstatic androidx/fragment/app/n0.a : [I
    //   32: aload_1
    //   33: getfield a : I
    //   36: iaload
    //   37: istore #5
    //   39: goto -> 48
    //   42: aload_1
    //   43: getfield a : I
    //   46: istore #5
    //   48: iconst_1
    //   49: istore #7
    //   51: iconst_1
    //   52: istore #6
    //   54: iconst_0
    //   55: istore #10
    //   57: iload #5
    //   59: iconst_1
    //   60: if_icmpeq -> 287
    //   63: iload #5
    //   65: iconst_3
    //   66: if_icmpeq -> 201
    //   69: iload #5
    //   71: iconst_4
    //   72: if_icmpeq -> 150
    //   75: iload #5
    //   77: iconst_5
    //   78: if_icmpeq -> 104
    //   81: iload #5
    //   83: bipush #6
    //   85: if_icmpeq -> 201
    //   88: iload #5
    //   90: bipush #7
    //   92: if_icmpeq -> 287
    //   95: iconst_0
    //   96: istore #10
    //   98: iconst_0
    //   99: istore #5
    //   101: goto -> 339
    //   104: iload #4
    //   106: ifeq -> 136
    //   109: aload #12
    //   111: getfield mHiddenChanged : Z
    //   114: ifeq -> 332
    //   117: aload #12
    //   119: getfield mHidden : Z
    //   122: ifne -> 332
    //   125: aload #12
    //   127: getfield mAdded : Z
    //   130: ifeq -> 332
    //   133: goto -> 322
    //   136: aload #12
    //   138: getfield mHidden : Z
    //   141: istore #10
    //   143: iload #6
    //   145: istore #5
    //   147: goto -> 339
    //   150: iload #4
    //   152: ifeq -> 182
    //   155: aload #12
    //   157: getfield mHiddenChanged : Z
    //   160: ifeq -> 266
    //   163: aload #12
    //   165: getfield mAdded : Z
    //   168: ifeq -> 266
    //   171: aload #12
    //   173: getfield mHidden : Z
    //   176: ifeq -> 266
    //   179: goto -> 260
    //   182: aload #12
    //   184: getfield mAdded : Z
    //   187: ifeq -> 266
    //   190: aload #12
    //   192: getfield mHidden : Z
    //   195: ifne -> 266
    //   198: goto -> 260
    //   201: iload #4
    //   203: ifeq -> 244
    //   206: aload #12
    //   208: getfield mAdded : Z
    //   211: ifne -> 266
    //   214: aload #12
    //   216: getfield mView : Landroid/view/View;
    //   219: astore_1
    //   220: aload_1
    //   221: ifnull -> 266
    //   224: aload_1
    //   225: invokevirtual getVisibility : ()I
    //   228: ifne -> 266
    //   231: aload #12
    //   233: getfield mPostponedAlpha : F
    //   236: fconst_0
    //   237: fcmpl
    //   238: iflt -> 266
    //   241: goto -> 260
    //   244: aload #12
    //   246: getfield mAdded : Z
    //   249: ifeq -> 266
    //   252: aload #12
    //   254: getfield mHidden : Z
    //   257: ifne -> 266
    //   260: iconst_1
    //   261: istore #5
    //   263: goto -> 269
    //   266: iconst_0
    //   267: istore #5
    //   269: iload #5
    //   271: istore #6
    //   273: iconst_0
    //   274: istore #8
    //   276: iload #7
    //   278: istore #5
    //   280: iload #8
    //   282: istore #7
    //   284: goto -> 353
    //   287: iload #4
    //   289: ifeq -> 306
    //   292: aload #12
    //   294: getfield mIsNewlyAdded : Z
    //   297: istore #10
    //   299: iload #6
    //   301: istore #5
    //   303: goto -> 339
    //   306: aload #12
    //   308: getfield mAdded : Z
    //   311: ifne -> 332
    //   314: aload #12
    //   316: getfield mHidden : Z
    //   319: ifne -> 332
    //   322: iconst_1
    //   323: istore #10
    //   325: iload #6
    //   327: istore #5
    //   329: goto -> 339
    //   332: iconst_0
    //   333: istore #10
    //   335: iload #6
    //   337: istore #5
    //   339: iconst_0
    //   340: istore #8
    //   342: iconst_0
    //   343: istore #6
    //   345: iload #5
    //   347: istore #7
    //   349: iload #8
    //   351: istore #5
    //   353: aload_2
    //   354: iload #9
    //   356: invokevirtual get : (I)Ljava/lang/Object;
    //   359: checkcast androidx/fragment/app/n0$b
    //   362: astore #11
    //   364: aload #11
    //   366: astore_1
    //   367: iload #10
    //   369: ifeq -> 411
    //   372: aload #11
    //   374: astore_1
    //   375: aload #11
    //   377: ifnonnull -> 395
    //   380: new androidx/fragment/app/n0$b
    //   383: dup
    //   384: invokespecial <init> : ()V
    //   387: astore_1
    //   388: aload_2
    //   389: iload #9
    //   391: aload_1
    //   392: invokevirtual put : (ILjava/lang/Object;)V
    //   395: aload_1
    //   396: aload #12
    //   398: putfield a : Landroidx/fragment/app/Fragment;
    //   401: aload_1
    //   402: iload_3
    //   403: putfield b : Z
    //   406: aload_1
    //   407: aload_0
    //   408: putfield c : Landroidx/fragment/app/a;
    //   411: iload #4
    //   413: ifne -> 483
    //   416: iload #7
    //   418: ifeq -> 483
    //   421: aload_1
    //   422: ifnull -> 439
    //   425: aload_1
    //   426: getfield d : Landroidx/fragment/app/Fragment;
    //   429: aload #12
    //   431: if_acmpne -> 439
    //   434: aload_1
    //   435: aconst_null
    //   436: putfield d : Landroidx/fragment/app/Fragment;
    //   439: aload_0
    //   440: getfield p : Z
    //   443: ifne -> 483
    //   446: aload_0
    //   447: getfield q : Landroidx/fragment/app/FragmentManager;
    //   450: astore #11
    //   452: aload #11
    //   454: aload #12
    //   456: invokevirtual h : (Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/e0;
    //   459: astore #13
    //   461: aload #11
    //   463: getfield c : Landroidx/fragment/app/f0;
    //   466: aload #13
    //   468: invokevirtual o : (Landroidx/fragment/app/e0;)V
    //   471: aload #11
    //   473: aload #12
    //   475: aload #11
    //   477: getfield q : I
    //   480: invokevirtual U : (Landroidx/fragment/app/Fragment;I)V
    //   483: aload_1
    //   484: astore #11
    //   486: iload #6
    //   488: ifeq -> 548
    //   491: aload_1
    //   492: ifnull -> 505
    //   495: aload_1
    //   496: astore #11
    //   498: aload_1
    //   499: getfield d : Landroidx/fragment/app/Fragment;
    //   502: ifnonnull -> 548
    //   505: aload_1
    //   506: astore #11
    //   508: aload_1
    //   509: ifnonnull -> 529
    //   512: new androidx/fragment/app/n0$b
    //   515: dup
    //   516: invokespecial <init> : ()V
    //   519: astore #11
    //   521: aload_2
    //   522: iload #9
    //   524: aload #11
    //   526: invokevirtual put : (ILjava/lang/Object;)V
    //   529: aload #11
    //   531: aload #12
    //   533: putfield d : Landroidx/fragment/app/Fragment;
    //   536: aload #11
    //   538: iload_3
    //   539: putfield e : Z
    //   542: aload #11
    //   544: aload_0
    //   545: putfield f : Landroidx/fragment/app/a;
    //   548: iload #4
    //   550: ifne -> 579
    //   553: iload #5
    //   555: ifeq -> 579
    //   558: aload #11
    //   560: ifnull -> 579
    //   563: aload #11
    //   565: getfield a : Landroidx/fragment/app/Fragment;
    //   568: aload #12
    //   570: if_acmpne -> 579
    //   573: aload #11
    //   575: aconst_null
    //   576: putfield a : Landroidx/fragment/app/Fragment;
    //   579: return
  }
  
  public static void c(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean1, s.a<String, View> parama, boolean paramBoolean2) {
    if (paramBoolean1) {
      paramFragment2.getEnterTransitionCallback();
      return;
    } 
    paramFragment1.getEnterTransitionCallback();
  }
  
  public static boolean d(p0 paramp0, List<Object> paramList) {
    int j = paramList.size();
    for (int i = 0; i < j; i++) {
      if (!paramp0.e(paramList.get(i)))
        return false; 
    } 
    return true;
  }
  
  public static s.a<String, View> e(p0 paramp0, s.a<String, String> parama, Object paramObject, b paramb) {
    ArrayList<String> arrayList;
    Fragment fragment = paramb.a;
    View view = fragment.getView();
    if (parama.isEmpty() || paramObject == null || view == null) {
      parama.clear();
      return null;
    } 
    paramObject = new s.a();
    paramp0.i((Map<String, View>)paramObject, view);
    a a1 = paramb.c;
    if (paramb.b) {
      fragment.getExitTransitionCallback();
      arrayList = a1.n;
    } else {
      fragment.getEnterTransitionCallback();
      arrayList = ((g0)arrayList).o;
    } 
    if (arrayList != null) {
      g.k((Map)paramObject, arrayList);
      g.k((Map)paramObject, parama.values());
    } 
    n(parama, (s.a<String, View>)paramObject);
    return (s.a<String, View>)paramObject;
  }
  
  public static s.a<String, View> f(p0 paramp0, s.a<String, String> parama, Object paramObject, b paramb) {
    ArrayList<String> arrayList;
    if (parama.isEmpty() || paramObject == null) {
      parama.clear();
      return null;
    } 
    Fragment fragment = paramb.d;
    paramObject = new s.a();
    paramp0.i((Map<String, View>)paramObject, fragment.requireView());
    a a1 = paramb.f;
    if (paramb.e) {
      fragment.getEnterTransitionCallback();
      arrayList = a1.o;
    } else {
      fragment.getExitTransitionCallback();
      arrayList = ((g0)arrayList).n;
    } 
    if (arrayList != null)
      g.k((Map)paramObject, arrayList); 
    g.k((Map)parama, paramObject.keySet());
    return (s.a<String, View>)paramObject;
  }
  
  public static p0 g(Fragment paramFragment1, Fragment paramFragment2) {
    ArrayList<Object> arrayList = new ArrayList();
    if (paramFragment1 != null) {
      Object object2 = paramFragment1.getExitTransition();
      if (object2 != null)
        arrayList.add(object2); 
      object2 = paramFragment1.getReturnTransition();
      if (object2 != null)
        arrayList.add(object2); 
      Object object1 = paramFragment1.getSharedElementReturnTransition();
      if (object1 != null)
        arrayList.add(object1); 
    } 
    if (paramFragment2 != null) {
      Object object = paramFragment2.getEnterTransition();
      if (object != null)
        arrayList.add(object); 
      object = paramFragment2.getReenterTransition();
      if (object != null)
        arrayList.add(object); 
      object = paramFragment2.getSharedElementEnterTransition();
      if (object != null)
        arrayList.add(object); 
    } 
    if (arrayList.isEmpty())
      return null; 
    p0 p01 = b;
    if (p01 != null && d(p01, arrayList))
      return p01; 
    p0 p02 = c;
    if (p02 != null && d(p02, arrayList))
      return p02; 
    if (p01 == null && p02 == null)
      return null; 
    throw new IllegalArgumentException("Invalid Transition types");
  }
  
  public static ArrayList<View> h(p0 paramp0, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList, View paramView) {
    if (paramObject != null) {
      ArrayList<View> arrayList2 = new ArrayList();
      View view = paramFragment.getView();
      if (view != null)
        paramp0.f(arrayList2, view); 
      if (paramArrayList != null)
        arrayList2.removeAll(paramArrayList); 
      ArrayList<View> arrayList1 = arrayList2;
      if (!arrayList2.isEmpty()) {
        arrayList2.add(paramView);
        paramp0.b(paramObject, arrayList2);
        return arrayList2;
      } 
    } else {
      paramFragment = null;
    } 
    return (ArrayList<View>)paramFragment;
  }
  
  public static Object i(p0 paramp0, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.getReenterTransition();
    } else {
      object = object.getEnterTransition();
    } 
    return paramp0.g(object);
  }
  
  public static Object j(p0 paramp0, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.getReturnTransition();
    } else {
      object = object.getExitTransition();
    } 
    return paramp0.g(object);
  }
  
  public static View k(s.a<String, View> parama, b paramb, Object<String> paramObject, boolean paramBoolean) {
    a a1 = paramb.c;
    if (paramObject != null && parama != null) {
      paramObject = (Object<String>)a1.n;
      if (paramObject != null && !paramObject.isEmpty()) {
        String str;
        if (paramBoolean) {
          str = a1.n.get(0);
        } else {
          str = ((g0)str).o.get(0);
        } 
        return (View)parama.get(str);
      } 
    } 
    return null;
  }
  
  public static Object l(p0 paramp0, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean) {
    Object object;
    if (paramBoolean) {
      object = paramFragment2.getSharedElementReturnTransition();
    } else {
      object = object.getSharedElementEnterTransition();
    } 
    return paramp0.y(paramp0.g(object));
  }
  
  public static Object m(p0 paramp0, Object paramObject1, Object paramObject2, Object paramObject3, Fragment paramFragment, boolean paramBoolean) {
    if (paramObject1 != null && paramObject2 != null && paramFragment != null) {
      if (paramBoolean) {
        paramBoolean = paramFragment.getAllowReturnTransitionOverlap();
      } else {
        paramBoolean = paramFragment.getAllowEnterTransitionOverlap();
      } 
    } else {
      paramBoolean = true;
    } 
    return paramBoolean ? paramp0.m(paramObject2, paramObject1, paramObject3) : paramp0.l(paramObject2, paramObject1, paramObject3);
  }
  
  public static void n(s.a<String, String> parama, s.a<String, View> parama1) {
    int i = ((h)parama).h;
    while (true) {
      int j = i - 1;
      if (j >= 0) {
        i = j;
        if (!parama1.containsKey(parama.k(j))) {
          parama.i(j);
          i = j;
        } 
        continue;
      } 
      break;
    } 
  }
  
  public static void o(p0 paramp0, Object paramObject1, Object paramObject2, s.a<String, View> parama, boolean paramBoolean, a parama1) {
    ArrayList<String> arrayList = parama1.n;
    if (arrayList != null && !arrayList.isEmpty()) {
      String str;
      if (paramBoolean) {
        str = parama1.o.get(0);
      } else {
        str = ((g0)str).n.get(0);
      } 
      View view = (View)parama.get(str);
      paramp0.t(paramObject1, view);
      if (paramObject2 != null)
        paramp0.t(paramObject2, view); 
    } 
  }
  
  public static void p(ArrayList<View> paramArrayList, int paramInt) {
    if (paramArrayList == null)
      return; 
    for (int i = paramArrayList.size() - 1; i >= 0; i--)
      ((View)paramArrayList.get(i)).setVisibility(paramInt); 
  }
  
  public static void q(Context paramContext, s params, ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, boolean paramBoolean, a parama) {
    boolean bool = paramBoolean;
    SparseArray<b> sparseArray = new SparseArray();
    int i;
    for (i = paramInt1; i < paramInt2; i++) {
      a a1 = paramArrayList.get(i);
      if (((Boolean)paramArrayList1.get(i)).booleanValue()) {
        if (a1.q.s.c()) {
          int j;
          for (j = a1.a.size() - 1; j >= 0; j--)
            b(a1, a1.a.get(j), sparseArray, true, bool); 
        } 
      } else {
        int k = a1.a.size();
        int j;
        for (j = 0; j < k; j++)
          b(a1, a1.a.get(j), sparseArray, false, bool); 
      } 
    } 
    if (sparseArray.size() != 0) {
      View view = new View(paramContext);
      i = sparseArray.size();
      int j = 0;
      while (j < i) {
        int m = sparseArray.keyAt(j);
        s.a a1 = new s.a();
        int k = paramInt2 - 1;
        while (true) {
          boolean bool1 = false;
          j++;
        } 
      } 
    } 
  }
  
  static {
    p0 p01;
  }
  
  public static final int[] a = new int[] { 
      0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 
      10 };
  
  public static final p0 b;
  
  public static final p0 c;
  
  public static interface a {}
  
  public static class b {
    public Fragment a;
    
    public boolean b;
    
    public a c;
    
    public Fragment d;
    
    public boolean e;
    
    public a f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */