package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.e;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.c0;
import androidx.lifecycle.d0;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import b0.a;
import b0.u;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class n extends ComponentActivity implements a.b, a.c {
  public static final String FRAGMENTS_TAG = "android:support:fragments";
  
  public boolean mCreated;
  
  public final k mFragmentLifecycleRegistry = new k((j)this);
  
  public final u mFragments = new u(new c(this));
  
  public boolean mResumed;
  
  public boolean mStopped = true;
  
  public n() {
    init();
  }
  
  public n(int paramInt) {
    super(paramInt);
    init();
  }
  
  private void init() {
    getSavedStateRegistry().b("android:support:fragments", new a(this));
    addOnContextAvailableListener(new b(this));
  }
  
  private static boolean markState(FragmentManager paramFragmentManager, Lifecycle.State paramState) {
    Lifecycle.State state = Lifecycle.State.i;
    Iterator<Fragment> iterator = paramFragmentManager.c.i().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      boolean bool1;
      Fragment fragment = iterator.next();
      if (fragment == null)
        continue; 
      boolean bool2 = bool;
      if (fragment.getHost() != null)
        bool2 = bool | markState(fragment.getChildFragmentManager(), paramState); 
      s0 s0 = fragment.mViewLifecycleOwner;
      bool = bool2;
      if (s0 != null) {
        s0.b();
        if (s0.g.b.compareTo(state) >= 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        bool = bool2;
        if (bool1) {
          k k1 = fragment.mViewLifecycleOwner.g;
          k1.d("setCurrentState");
          k1.g(paramState);
          bool = true;
        } 
      } 
      if (fragment.mLifecycleRegistry.b.compareTo(state) >= 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        k k1 = fragment.mLifecycleRegistry;
        k1.d("setCurrentState");
        k1.g(paramState);
        bool = true;
      } 
    } 
    return bool;
  }
  
  public final View dispatchFragmentsOnCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.mFragments.a.i.f.onCreateView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.mCreated);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.mResumed);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.mStopped);
    if (getApplication() != null)
      z0.a.b((j)this).a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.mFragments.a.i.y(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public FragmentManager getSupportFragmentManager() {
    return this.mFragments.a.i;
  }
  
  @Deprecated
  public z0.a getSupportLoaderManager() {
    return z0.a.b((j)this);
  }
  
  public void markFragmentsCreated() {
    do {
    
    } while (markState(getSupportFragmentManager(), Lifecycle.State.h));
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    this.mFragments.a();
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  @Deprecated
  public void onAttachFragment(Fragment paramFragment) {}
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.mFragments.a();
    super.onConfigurationChanged(paramConfiguration);
    this.mFragments.a.i.k(paramConfiguration);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.mFragmentLifecycleRegistry.e(Lifecycle.Event.ON_CREATE);
    this.mFragments.a.i.m();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      boolean bool = super.onCreatePanelMenu(paramInt, paramMenu);
      u u1 = this.mFragments;
      MenuInflater menuInflater = getMenuInflater();
      return bool | u1.a.i.n(paramMenu, menuInflater);
    } 
    return super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = dispatchFragmentsOnCreateView(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = dispatchFragmentsOnCreateView(null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.mFragments.a.i.o();
    this.mFragmentLifecycleRegistry.e(Lifecycle.Event.ON_DESTROY);
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.mFragments.a.i.p();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.mFragments.a.i.l(paramMenuItem)) : this.mFragments.a.i.r(paramMenuItem));
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    this.mFragments.a.i.q(paramBoolean);
  }
  
  public void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent paramIntent) {
    this.mFragments.a();
    super.onNewIntent(paramIntent);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.mFragments.a.i.s(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPause() {
    super.onPause();
    this.mResumed = false;
    this.mFragments.a.i.w(5);
    this.mFragmentLifecycleRegistry.e(Lifecycle.Event.ON_PAUSE);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    this.mFragments.a.i.u(paramBoolean);
  }
  
  public void onPostResume() {
    super.onPostResume();
    onResumeFragments();
  }
  
  @Deprecated
  public boolean onPrepareOptionsPanel(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0) ? (onPrepareOptionsPanel(paramView, paramMenu) | this.mFragments.a.i.v(paramMenu)) : super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.mFragments.a();
    super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint);
  }
  
  public void onResume() {
    this.mFragments.a();
    super.onResume();
    this.mResumed = true;
    this.mFragments.a.i.C(true);
  }
  
  public void onResumeFragments() {
    this.mFragmentLifecycleRegistry.e(Lifecycle.Event.ON_RESUME);
    FragmentManager fragmentManager = this.mFragments.a.i;
    fragmentManager.C = false;
    fragmentManager.D = false;
    fragmentManager.K.h = false;
    fragmentManager.w(7);
  }
  
  public void onStart() {
    this.mFragments.a();
    super.onStart();
    this.mStopped = false;
    if (!this.mCreated) {
      this.mCreated = true;
      FragmentManager fragmentManager1 = this.mFragments.a.i;
      fragmentManager1.C = false;
      fragmentManager1.D = false;
      fragmentManager1.K.h = false;
      fragmentManager1.w(4);
    } 
    this.mFragments.a.i.C(true);
    this.mFragmentLifecycleRegistry.e(Lifecycle.Event.ON_START);
    FragmentManager fragmentManager = this.mFragments.a.i;
    fragmentManager.C = false;
    fragmentManager.D = false;
    fragmentManager.K.h = false;
    fragmentManager.w(5);
  }
  
  public void onStateNotSaved() {
    this.mFragments.a();
  }
  
  public void onStop() {
    super.onStop();
    this.mStopped = true;
    markFragmentsCreated();
    FragmentManager fragmentManager = this.mFragments.a.i;
    fragmentManager.D = true;
    fragmentManager.K.h = true;
    fragmentManager.w(4);
    this.mFragmentLifecycleRegistry.e(Lifecycle.Event.ON_STOP);
  }
  
  public void setEnterSharedElementCallback(u paramu) {
    int i = a.c;
    if (Build.VERSION.SDK_INT >= 21)
      setEnterSharedElementCallback(null); 
  }
  
  public void setExitSharedElementCallback(u paramu) {
    int i = a.c;
    if (Build.VERSION.SDK_INT >= 21)
      setExitSharedElementCallback(null); 
  }
  
  public void startActivityFromFragment(Fragment paramFragment, @SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    startActivityFromFragment(paramFragment, paramIntent, paramInt, null);
  }
  
  public void startActivityFromFragment(Fragment paramFragment, @SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (paramInt == -1) {
      paramInt = a.c;
      startActivityForResult(paramIntent, -1, paramBundle);
      return;
    } 
    paramFragment.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderFromFragment(Fragment paramFragment, @SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    if (paramInt1 == -1) {
      int i = a.c;
      startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
      return;
    } 
    paramFragment.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public void supportFinishAfterTransition() {
    int i = a.c;
    if (Build.VERSION.SDK_INT >= 21) {
      finishAfterTransition();
      return;
    } 
    finish();
  }
  
  @Deprecated
  public void supportInvalidateOptionsMenu() {
    invalidateOptionsMenu();
  }
  
  public void supportPostponeEnterTransition() {
    int i = a.c;
    if (Build.VERSION.SDK_INT >= 21)
      postponeEnterTransition(); 
  }
  
  public void supportStartPostponedEnterTransition() {
    int i = a.c;
    if (Build.VERSION.SDK_INT >= 21)
      startPostponedEnterTransition(); 
  }
  
  @Deprecated
  public final void validateRequestPermissionsRequestCode(int paramInt) {}
  
  public class a implements androidx.savedstate.a.b {
    public a(n this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.markFragmentsCreated();
      this.a.mFragmentLifecycleRegistry.e(Lifecycle.Event.ON_STOP);
      Parcelable parcelable = this.a.mFragments.a.i.c0();
      if (parcelable != null)
        bundle.putParcelable("android:support:fragments", parcelable); 
      return bundle;
    }
  }
  
  public class b implements c.b {
    public b(n this$0) {}
    
    public void a(Context param1Context) {
      w<?> w = this.a.mFragments.a;
      w.i.b(w, w, null);
      Bundle bundle = this.a.getSavedStateRegistry().a("android:support:fragments");
      if (bundle != null) {
        Parcelable parcelable = bundle.getParcelable("android:support:fragments");
        w<?> w1 = this.a.mFragments.a;
        if (w1 instanceof d0) {
          w1.i.b0(parcelable);
          return;
        } 
        throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
      } 
    }
  }
  
  public class c extends w<n> implements d0, androidx.activity.c, e, c0 {
    public c(n this$0) {
      super(this$0);
    }
    
    public void a(FragmentManager param1FragmentManager, Fragment param1Fragment) {
      this.j.onAttachFragment(param1Fragment);
    }
    
    public View b(int param1Int) {
      return this.j.findViewById(param1Int);
    }
    
    public boolean c() {
      Window window = this.j.getWindow();
      return (window != null && window.peekDecorView() != null);
    }
    
    public Object d() {
      return this.j;
    }
    
    public LayoutInflater e() {
      return this.j.getLayoutInflater().cloneInContext((Context)this.j);
    }
    
    public boolean f(Fragment param1Fragment) {
      return this.j.isFinishing() ^ true;
    }
    
    public boolean g(String param1String) {
      n n1 = this.j;
      int i = a.c;
      return (Build.VERSION.SDK_INT >= 23) ? n1.shouldShowRequestPermissionRationale(param1String) : false;
    }
    
    public ActivityResultRegistry getActivityResultRegistry() {
      return this.j.getActivityResultRegistry();
    }
    
    public Lifecycle getLifecycle() {
      return (Lifecycle)this.j.mFragmentLifecycleRegistry;
    }
    
    public OnBackPressedDispatcher getOnBackPressedDispatcher() {
      return this.j.getOnBackPressedDispatcher();
    }
    
    public c0 getViewModelStore() {
      return this.j.getViewModelStore();
    }
    
    public void h() {
      this.j.supportInvalidateOptionsMenu();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */