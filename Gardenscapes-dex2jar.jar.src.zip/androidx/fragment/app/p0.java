package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import i0.b;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import m0.b0;
import m0.s;
import m0.y;
import s.h;

@SuppressLint({"UnknownNullness"})
public abstract class p0 {
  public static void d(List<View> paramList, View paramView) {
    int j = paramList.size();
    if (h(paramList, paramView, j))
      return; 
    if (y.p(paramView) != null)
      paramList.add(paramView); 
    for (int i = j; i < paramList.size(); i++) {
      paramView = paramList.get(i);
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int m = viewGroup.getChildCount();
        for (int k = 0; k < m; k++) {
          View view = viewGroup.getChildAt(k);
          if (!h(paramList, view, j) && y.p(view) != null)
            paramList.add(view); 
        } 
      } 
    } 
  }
  
  public static boolean h(List<View> paramList, View paramView, int paramInt) {
    for (int i = 0; i < paramInt; i++) {
      if (paramList.get(i) == paramView)
        return true; 
    } 
    return false;
  }
  
  public static boolean k(List paramList) {
    return (paramList == null || paramList.isEmpty());
  }
  
  public abstract void a(Object paramObject, View paramView);
  
  public abstract void b(Object paramObject, ArrayList<View> paramArrayList);
  
  public abstract void c(ViewGroup paramViewGroup, Object paramObject);
  
  public abstract boolean e(Object paramObject);
  
  public void f(ArrayList<View> paramArrayList, View paramView) {
    if (paramView.getVisibility() == 0) {
      ViewGroup viewGroup;
      if (paramView instanceof ViewGroup) {
        viewGroup = (ViewGroup)paramView;
        if (b0.a(viewGroup)) {
          paramArrayList.add(viewGroup);
          return;
        } 
        int j = viewGroup.getChildCount();
        for (int i = 0; i < j; i++)
          f(paramArrayList, viewGroup.getChildAt(i)); 
      } else {
        paramArrayList.add(viewGroup);
      } 
    } 
  }
  
  public abstract Object g(Object paramObject);
  
  public void i(Map<String, View> paramMap, View paramView) {
    if (paramView.getVisibility() == 0) {
      String str = y.p(paramView);
      if (str != null)
        paramMap.put(str, paramView); 
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int j = viewGroup.getChildCount();
        for (int i = 0; i < j; i++)
          i(paramMap, viewGroup.getChildAt(i)); 
      } 
    } 
  }
  
  public void j(View paramView, Rect paramRect) {
    WeakHashMap weakHashMap = y.a;
    if (!y.g.b(paramView))
      return; 
    RectF rectF = new RectF();
    rectF.set(0.0F, 0.0F, paramView.getWidth(), paramView.getHeight());
    paramView.getMatrix().mapRect(rectF);
    rectF.offset(paramView.getLeft(), paramView.getTop());
    ViewParent viewParent = paramView.getParent();
    while (viewParent instanceof View) {
      View view = (View)viewParent;
      rectF.offset(-view.getScrollX(), -view.getScrollY());
      view.getMatrix().mapRect(rectF);
      rectF.offset(view.getLeft(), view.getTop());
      ViewParent viewParent1 = view.getParent();
    } 
    int[] arrayOfInt = new int[2];
    paramView.getRootView().getLocationOnScreen(arrayOfInt);
    rectF.offset(arrayOfInt[0], arrayOfInt[1]);
    paramRect.set(Math.round(rectF.left), Math.round(rectF.top), Math.round(rectF.right), Math.round(rectF.bottom));
  }
  
  public abstract Object l(Object paramObject1, Object paramObject2, Object paramObject3);
  
  public abstract Object m(Object paramObject1, Object paramObject2, Object paramObject3);
  
  public ArrayList<String> n(ArrayList<View> paramArrayList) {
    ArrayList<String> arrayList = new ArrayList();
    int j = paramArrayList.size();
    for (int i = 0; i < j; i++) {
      View view = paramArrayList.get(i);
      arrayList.add(y.p(view));
      y.D(view, null);
    } 
    return arrayList;
  }
  
  public abstract void o(Object paramObject, View paramView);
  
  public abstract void p(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2);
  
  public abstract void q(Object paramObject, View paramView, ArrayList<View> paramArrayList);
  
  public abstract void r(Object paramObject1, Object paramObject2, ArrayList<View> paramArrayList1, Object paramObject3, ArrayList<View> paramArrayList2, Object paramObject4, ArrayList<View> paramArrayList3);
  
  public abstract void s(Object paramObject, Rect paramRect);
  
  public abstract void t(Object paramObject, View paramView);
  
  public void u(Fragment paramFragment, Object paramObject, b paramb, Runnable paramRunnable) {
    paramRunnable.run();
  }
  
  public void v(View paramView, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, ArrayList<String> paramArrayList, Map<String, String> paramMap) {
    int j = paramArrayList2.size();
    ArrayList<String> arrayList = new ArrayList();
    int i;
    for (i = 0; i < j; i++) {
      View view = paramArrayList1.get(i);
      String str = y.p(view);
      arrayList.add(str);
      if (str != null) {
        y.D(view, null);
        String str1 = (String)((h)paramMap).getOrDefault(str, null);
        int k;
        for (k = 0; k < j; k++) {
          if (str1.equals(paramArrayList.get(k))) {
            y.D(paramArrayList2.get(k), str);
            break;
          } 
        } 
      } 
    } 
    s.a(paramView, new a(this, j, paramArrayList2, paramArrayList, paramArrayList1, arrayList));
  }
  
  public abstract void w(Object paramObject, View paramView, ArrayList<View> paramArrayList);
  
  public abstract void x(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2);
  
  public abstract Object y(Object paramObject);
  
  public class a implements Runnable {
    public a(p0 this$0, int param1Int, ArrayList param1ArrayList1, ArrayList param1ArrayList2, ArrayList param1ArrayList3, ArrayList param1ArrayList4) {}
    
    public void run() {
      for (int i = 0; i < this.f; i++) {
        y.D(this.g.get(i), this.h.get(i));
        y.D(this.i.get(i), this.j.get(i));
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */