package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.b0;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import m0.y;

public abstract class SpecialEffectsController {
  public final ViewGroup a;
  
  public final ArrayList<Operation> b = new ArrayList<Operation>();
  
  public final ArrayList<Operation> c = new ArrayList<Operation>();
  
  public boolean d = false;
  
  public boolean e = false;
  
  public SpecialEffectsController(ViewGroup paramViewGroup) {
    this.a = paramViewGroup;
  }
  
  public static SpecialEffectsController f(ViewGroup paramViewGroup, FragmentManager paramFragmentManager) {
    return g(paramViewGroup, paramFragmentManager.M());
  }
  
  public static SpecialEffectsController g(ViewGroup paramViewGroup, u0 paramu0) {
    Object object = paramViewGroup.getTag(2131231127);
    if (object instanceof SpecialEffectsController)
      return (SpecialEffectsController)object; 
    Objects.requireNonNull((FragmentManager.f)paramu0);
    c c = new c(paramViewGroup);
    paramViewGroup.setTag(2131231127, c);
    return c;
  }
  
  public final void a(Operation.State paramState, Operation.LifecycleImpact paramLifecycleImpact, e0 parame0) {
    synchronized (this.b) {
      i0.b b1 = new i0.b();
      Operation operation = d(parame0.c);
      if (operation != null) {
        operation.c(paramState, paramLifecycleImpact);
        return;
      } 
      c c = new c(paramState, paramLifecycleImpact, parame0, b1);
      this.b.add(c);
      a a = new a(this, c);
      c.d.add(a);
      b b = new b(this, c);
      c.d.add(b);
      return;
    } 
  }
  
  public abstract void b(List<Operation> paramList, boolean paramBoolean);
  
  public void c() {
    if (this.e)
      return; 
    ViewGroup viewGroup = this.a;
    null = y.a;
    if (!y.g.b((View)viewGroup)) {
      e();
      this.d = false;
      return;
    } 
    synchronized (this.b) {
      if (!this.b.isEmpty()) {
        ArrayList<Operation> arrayList = new ArrayList<Operation>(this.c);
        this.c.clear();
        for (Operation operation : arrayList) {
          if (FragmentManager.O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Cancelling operation ");
            stringBuilder.append(operation);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          operation.a();
          if (!operation.g)
            this.c.add(operation); 
        } 
        i();
        arrayList = new ArrayList<Operation>(this.b);
        this.b.clear();
        this.c.addAll(arrayList);
        Iterator<Operation> iterator = arrayList.iterator();
        while (iterator.hasNext())
          ((Operation)iterator.next()).d(); 
        b(arrayList, this.d);
        this.d = false;
      } 
      return;
    } 
  }
  
  public final Operation d(Fragment paramFragment) {
    for (Operation operation : this.b) {
      if (operation.c.equals(paramFragment) && !operation.f)
        return operation; 
    } 
    return null;
  }
  
  public void e() {
    null = this.a;
    WeakHashMap weakHashMap = y.a;
    boolean bool = y.g.b((View)null);
    synchronized (this.b) {
      i();
      Iterator<Operation> iterator = this.b.iterator();
      while (iterator.hasNext())
        ((Operation)iterator.next()).d(); 
      for (Operation operation : new ArrayList(this.c)) {
        if (FragmentManager.O(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.a);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling running operation ");
          stringBuilder.append(operation);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        operation.a();
      } 
      for (Operation operation : new ArrayList(this.b)) {
        if (FragmentManager.O(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.a);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling pending operation ");
          stringBuilder.append(operation);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        operation.a();
      } 
      return;
    } 
  }
  
  public void h() {
    synchronized (this.b) {
      i();
      this.e = false;
      int i = this.b.size() - 1;
      while (true) {
        if (i >= 0) {
          Operation operation = this.b.get(i);
          Operation.State state1 = Operation.State.f(operation.c.mView);
          Operation.State state2 = operation.a;
          Operation.State state3 = Operation.State.g;
          if (state2 == state3 && state1 != state3) {
            this.e = operation.c.isPostponed();
          } else {
            i--;
            continue;
          } 
        } 
        return;
      } 
    } 
  }
  
  public final void i() {
    for (Operation operation : this.b) {
      if (operation.b == Operation.LifecycleImpact.g)
        operation.c(Operation.State.e(operation.c.requireView().getVisibility()), Operation.LifecycleImpact.f); 
    } 
  }
  
  public static class Operation {
    public State a;
    
    public LifecycleImpact b;
    
    public final Fragment c;
    
    public final List<Runnable> d = new ArrayList<Runnable>();
    
    public final HashSet<i0.b> e = new HashSet<i0.b>();
    
    public boolean f = false;
    
    public boolean g = false;
    
    public Operation(State param1State, LifecycleImpact param1LifecycleImpact, Fragment param1Fragment, i0.b param1b) {
      this.a = param1State;
      this.b = param1LifecycleImpact;
      this.c = param1Fragment;
      param1b.b(new a(this));
    }
    
    public final void a() {
      if (this.f)
        return; 
      this.f = true;
      if (this.e.isEmpty()) {
        b();
        return;
      } 
      Iterator<?> iterator = (new ArrayList(this.e)).iterator();
      while (iterator.hasNext())
        ((i0.b)iterator.next()).a(); 
    }
    
    public void b() {
      if (this.g)
        return; 
      if (FragmentManager.O(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SpecialEffectsController: ");
        stringBuilder.append(this);
        stringBuilder.append(" has called complete.");
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      this.g = true;
      Iterator<Runnable> iterator = this.d.iterator();
      while (iterator.hasNext())
        ((Runnable)iterator.next()).run(); 
    }
    
    public final void c(State param1State, LifecycleImpact param1LifecycleImpact) {
      StringBuilder stringBuilder;
      State state = State.f;
      int i = param1LifecycleImpact.ordinal();
      if (i != 0) {
        if (i != 1) {
          if (i != 2)
            return; 
          if (FragmentManager.O(2)) {
            stringBuilder = android.support.v4.media.a.a("SpecialEffectsController: For fragment ");
            stringBuilder.append(this.c);
            stringBuilder.append(" mFinalState = ");
            stringBuilder.append(this.a);
            stringBuilder.append(" -> REMOVED. mLifecycleImpact  = ");
            stringBuilder.append(this.b);
            stringBuilder.append(" to REMOVING.");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          this.a = state;
          this.b = LifecycleImpact.h;
          return;
        } 
        if (this.a == state) {
          if (FragmentManager.O(2)) {
            stringBuilder = android.support.v4.media.a.a("SpecialEffectsController: For fragment ");
            stringBuilder.append(this.c);
            stringBuilder.append(" mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = ");
            stringBuilder.append(this.b);
            stringBuilder.append(" to ADDING.");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          this.a = State.g;
          this.b = LifecycleImpact.g;
          return;
        } 
      } else if (this.a != state) {
        if (FragmentManager.O(2)) {
          StringBuilder stringBuilder1 = android.support.v4.media.a.a("SpecialEffectsController: For fragment ");
          stringBuilder1.append(this.c);
          stringBuilder1.append(" mFinalState = ");
          stringBuilder1.append(this.a);
          stringBuilder1.append(" -> ");
          stringBuilder1.append(stringBuilder);
          stringBuilder1.append(". ");
          Log.v("FragmentManager", stringBuilder1.toString());
        } 
        this.a = (State)stringBuilder;
      } 
    }
    
    public void d() {}
    
    public String toString() {
      StringBuilder stringBuilder = u.b.a("Operation ", "{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFinalState = ");
      stringBuilder.append(this.a);
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mLifecycleImpact = ");
      stringBuilder.append(this.b);
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFragment = ");
      stringBuilder.append(this.c);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public enum LifecycleImpact {
      f, g, h;
      
      static {
        LifecycleImpact lifecycleImpact1 = new LifecycleImpact("NONE", 0);
        f = lifecycleImpact1;
        LifecycleImpact lifecycleImpact2 = new LifecycleImpact("ADDING", 1);
        g = lifecycleImpact2;
        LifecycleImpact lifecycleImpact3 = new LifecycleImpact("REMOVING", 2);
        h = lifecycleImpact3;
        i = new LifecycleImpact[] { lifecycleImpact1, lifecycleImpact2, lifecycleImpact3 };
      }
    }
    
    public enum State {
      f, g, h, i;
      
      static {
        State state1 = new State("REMOVED", 0);
        f = state1;
        State state2 = new State("VISIBLE", 1);
        g = state2;
        State state3 = new State("GONE", 2);
        h = state3;
        State state4 = new State("INVISIBLE", 3);
        i = state4;
        j = new State[] { state1, state2, state3, state4 };
      }
      
      public static State e(int param2Int) {
        if (param2Int != 0) {
          if (param2Int != 4) {
            if (param2Int == 8)
              return h; 
            throw new IllegalArgumentException(b0.a("Unknown visibility ", param2Int));
          } 
          return i;
        } 
        return g;
      }
      
      public static State f(View param2View) {
        return (param2View.getAlpha() == 0.0F && param2View.getVisibility() == 0) ? i : e(param2View.getVisibility());
      }
      
      public void b(View param2View) {
        int i = ordinal();
        if (i != 0) {
          if (i != 1) {
            if (i != 2) {
              if (i != 3)
                return; 
              if (FragmentManager.O(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("SpecialEffectsController: Setting view ");
                stringBuilder.append(param2View);
                stringBuilder.append(" to INVISIBLE");
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              param2View.setVisibility(4);
              return;
            } 
            if (FragmentManager.O(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param2View);
              stringBuilder.append(" to GONE");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            param2View.setVisibility(8);
            return;
          } 
          if (FragmentManager.O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Setting view ");
            stringBuilder.append(param2View);
            stringBuilder.append(" to VISIBLE");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          param2View.setVisibility(0);
          return;
        } 
        ViewGroup viewGroup = (ViewGroup)param2View.getParent();
        if (viewGroup != null) {
          if (FragmentManager.O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Removing view ");
            stringBuilder.append(param2View);
            stringBuilder.append(" from container ");
            stringBuilder.append(viewGroup);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          viewGroup.removeView(param2View);
        } 
      }
    }
    
    public class a implements i0.b.a {
      public a(SpecialEffectsController.Operation this$0) {}
      
      public void onCancel() {
        this.a.a();
      }
    }
  }
  
  public enum LifecycleImpact {
    f, g, h;
    
    static {
      LifecycleImpact lifecycleImpact1 = new LifecycleImpact("NONE", 0);
      f = lifecycleImpact1;
      LifecycleImpact lifecycleImpact2 = new LifecycleImpact("ADDING", 1);
      g = lifecycleImpact2;
      LifecycleImpact lifecycleImpact3 = new LifecycleImpact("REMOVING", 2);
      h = lifecycleImpact3;
      i = new LifecycleImpact[] { lifecycleImpact1, lifecycleImpact2, lifecycleImpact3 };
    }
  }
  
  public enum State {
    f, g, h, i;
    
    static {
      State state1 = new State("REMOVED", 0);
      f = state1;
      State state2 = new State("VISIBLE", 1);
      g = state2;
      State state3 = new State("GONE", 2);
      h = state3;
      State state4 = new State("INVISIBLE", 3);
      i = state4;
      j = new State[] { state1, state2, state3, state4 };
    }
    
    public static State e(int param1Int) {
      if (param1Int != 0) {
        if (param1Int != 4) {
          if (param1Int == 8)
            return h; 
          throw new IllegalArgumentException(b0.a("Unknown visibility ", param1Int));
        } 
        return i;
      } 
      return g;
    }
    
    public static State f(View param1View) {
      return (param1View.getAlpha() == 0.0F && param1View.getVisibility() == 0) ? i : e(param1View.getVisibility());
    }
    
    public void b(View param1View) {
      int i = ordinal();
      if (i != 0) {
        if (i != 1) {
          if (i != 2) {
            if (i != 3)
              return; 
            if (FragmentManager.O(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param1View);
              stringBuilder.append(" to INVISIBLE");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            param1View.setVisibility(4);
            return;
          } 
          if (FragmentManager.O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Setting view ");
            stringBuilder.append(param1View);
            stringBuilder.append(" to GONE");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          param1View.setVisibility(8);
          return;
        } 
        if (FragmentManager.O(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: Setting view ");
          stringBuilder.append(param1View);
          stringBuilder.append(" to VISIBLE");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        param1View.setVisibility(0);
        return;
      } 
      ViewGroup viewGroup = (ViewGroup)param1View.getParent();
      if (viewGroup != null) {
        if (FragmentManager.O(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: Removing view ");
          stringBuilder.append(param1View);
          stringBuilder.append(" from container ");
          stringBuilder.append(viewGroup);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        viewGroup.removeView(param1View);
      } 
    }
  }
  
  public class a implements i0.b.a {
    public a(SpecialEffectsController this$0) {}
    
    public void onCancel() {
      this.a.a();
    }
  }
  
  public class a implements Runnable {
    public a(SpecialEffectsController this$0, SpecialEffectsController.c param1c) {}
    
    public void run() {
      if (this.g.b.contains(this.f)) {
        SpecialEffectsController.c c1 = this.f;
        c1.a.b(c1.c.mView);
      } 
    }
  }
  
  public class b implements Runnable {
    public b(SpecialEffectsController this$0, SpecialEffectsController.c param1c) {}
    
    public void run() {
      this.g.b.remove(this.f);
      this.g.c.remove(this.f);
    }
  }
  
  public static class c extends Operation {
    public final e0 h;
    
    public c(SpecialEffectsController.Operation.State param1State, SpecialEffectsController.Operation.LifecycleImpact param1LifecycleImpact, e0 param1e0, i0.b param1b) {
      super(param1State, param1LifecycleImpact, param1e0.c, param1b);
      this.h = param1e0;
    }
    
    public void b() {
      super.b();
      this.h.k();
    }
    
    public void d() {
      if (this.b == SpecialEffectsController.Operation.LifecycleImpact.g) {
        Fragment fragment = this.h.c;
        View view = fragment.mView.findFocus();
        if (view != null) {
          fragment.setFocusedView(view);
          if (FragmentManager.O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("requestFocus: Saved focused view ");
            stringBuilder.append(view);
            stringBuilder.append(" for Fragment ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
        } 
        view = this.c.requireView();
        if (view.getParent() == null) {
          this.h.b();
          view.setAlpha(0.0F);
        } 
        if (view.getAlpha() == 0.0F && view.getVisibility() == 0)
          view.setVisibility(4); 
        view.setAlpha(fragment.getPostOnViewCreatedAlpha());
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\SpecialEffectsController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */