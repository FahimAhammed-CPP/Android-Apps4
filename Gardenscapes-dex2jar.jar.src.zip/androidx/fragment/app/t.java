package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import e.g;
import j.f;
import java.util.ArrayList;
import m0.g0;
import m0.y;
import w0.d;

public final class t extends FrameLayout {
  public ArrayList<View> f;
  
  public ArrayList<View> g;
  
  public View.OnApplyWindowInsetsListener h;
  
  public boolean i = true;
  
  public t(Context paramContext, AttributeSet paramAttributeSet, FragmentManager paramFragmentManager) {
    super(paramContext, paramAttributeSet);
    String str2 = paramAttributeSet.getClassAttribute();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, d.b);
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(0); 
    str2 = typedArray.getString(1);
    typedArray.recycle();
    int i = getId();
    Fragment fragment = paramFragmentManager.H(i);
    if (str1 != null && fragment == null) {
      String str;
      if (i <= 0) {
        if (str2 != null) {
          str = f.a(" with tag ", str2);
        } else {
          str = "";
        } 
        throw new IllegalStateException(g.a("FragmentContainerView must have an android:id to add Fragment ", str1, str));
      } 
      Fragment fragment1 = paramFragmentManager.L().a(str.getClassLoader(), str1);
      fragment1.onInflate((Context)str, paramAttributeSet, (Bundle)null);
      a a = new a(paramFragmentManager);
      a.p = true;
      fragment1.mContainer = (ViewGroup)this;
      a.d(getId(), fragment1, str2, 1);
      if (!a.g) {
        a.h = false;
        a.q.D(a, true);
      } else {
        throw new IllegalStateException("This transaction is already being added to the back stack");
      } 
    } 
    for (e0 e0 : paramFragmentManager.c.f()) {
      Fragment fragment1 = e0.c;
      if (fragment1.mContainerId == getId()) {
        View view = fragment1.mView;
        if (view != null && view.getParent() == null) {
          fragment1.mContainer = (ViewGroup)this;
          e0.b();
        } 
      } 
    } 
  }
  
  public final void a(View paramView) {
    ArrayList<View> arrayList = this.g;
    if (arrayList != null && arrayList.contains(paramView)) {
      if (this.f == null)
        this.f = new ArrayList<View>(); 
      this.f.add(paramView);
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    Object object = paramView.getTag(2131230923);
    if (object instanceof Fragment) {
      object = object;
    } else {
      object = null;
    } 
    if (object != null) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public boolean addViewInLayout(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    Object object = paramView.getTag(2131230923);
    if (object instanceof Fragment) {
      object = object;
    } else {
      object = null;
    } 
    if (object != null)
      return super.addViewInLayout(paramView, paramInt, paramLayoutParams, paramBoolean); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public WindowInsets dispatchApplyWindowInsets(WindowInsets paramWindowInsets) {
    g0 g0 = g0.i(paramWindowInsets, null);
    View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.h;
    if (onApplyWindowInsetsListener != null) {
      g0 = g0.h(onApplyWindowInsetsListener.onApplyWindowInsets((View)this, paramWindowInsets));
    } else {
      g0 = y.t((View)this, g0);
    } 
    if (!g0.f()) {
      int j = getChildCount();
      for (int i = 0; i < j; i++)
        y.e(getChildAt(i), g0); 
    } 
    return paramWindowInsets;
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    if (this.i && this.f != null)
      for (int i = 0; i < this.f.size(); i++)
        super.drawChild(paramCanvas, this.f.get(i), getDrawingTime());  
    super.dispatchDraw(paramCanvas);
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    if (this.i) {
      ArrayList<View> arrayList = this.f;
      if (arrayList != null && arrayList.size() > 0 && this.f.contains(paramView))
        return false; 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void endViewTransition(View paramView) {
    ArrayList<View> arrayList = this.g;
    if (arrayList != null) {
      arrayList.remove(paramView);
      arrayList = this.f;
      if (arrayList != null && arrayList.remove(paramView))
        this.i = true; 
    } 
    super.endViewTransition(paramView);
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    return paramWindowInsets;
  }
  
  public void removeAllViewsInLayout() {
    for (int i = getChildCount() - 1; i >= 0; i--)
      a(getChildAt(i)); 
    super.removeAllViewsInLayout();
  }
  
  public void removeDetachedView(View paramView, boolean paramBoolean) {
    if (paramBoolean)
      a(paramView); 
    super.removeDetachedView(paramView, paramBoolean);
  }
  
  public void removeView(View paramView) {
    a(paramView);
    super.removeView(paramView);
  }
  
  public void removeViewAt(int paramInt) {
    a(getChildAt(paramInt));
    super.removeViewAt(paramInt);
  }
  
  public void removeViewInLayout(View paramView) {
    a(paramView);
    super.removeViewInLayout(paramView);
  }
  
  public void removeViews(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViews(paramInt1, paramInt2);
  }
  
  public void removeViewsInLayout(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViewsInLayout(paramInt1, paramInt2);
  }
  
  public void setDrawDisappearingViewsLast(boolean paramBoolean) {
    this.i = paramBoolean;
  }
  
  public void setLayoutTransition(LayoutTransition paramLayoutTransition) {
    throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
  }
  
  public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener) {
    this.h = paramOnApplyWindowInsetsListener;
  }
  
  public void startViewTransition(View paramView) {
    if (paramView.getParent() == this) {
      if (this.g == null)
        this.g = new ArrayList<View>(); 
      this.g.add(paramView);
    } 
    super.startViewTransition(paramView);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */