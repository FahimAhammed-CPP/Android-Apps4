package androidx.fragment.app;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.c0;
import androidx.lifecycle.d0;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.savedstate.a;
import androidx.savedstate.b;
import androidx.savedstate.c;

public class s0 implements c, d0 {
  public final c0 f;
  
  public k g = null;
  
  public b h = null;
  
  public s0(Fragment paramFragment, c0 paramc0) {
    this.f = paramc0;
  }
  
  public void a(Lifecycle.Event paramEvent) {
    k k1 = this.g;
    k1.d("handleLifecycleEvent");
    k1.g(paramEvent.b());
  }
  
  public void b() {
    if (this.g == null) {
      this.g = new k((j)this);
      this.h = new b(this);
    } 
  }
  
  public Lifecycle getLifecycle() {
    b();
    return (Lifecycle)this.g;
  }
  
  public a getSavedStateRegistry() {
    b();
    return this.h.b;
  }
  
  public c0 getViewModelStore() {
    b();
    return this.f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */