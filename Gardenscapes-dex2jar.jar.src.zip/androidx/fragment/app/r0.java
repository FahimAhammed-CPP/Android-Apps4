package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;
import java.util.Map;
import m0.y;

public class r0 implements Runnable {
  public r0(p0 paramp0, ArrayList paramArrayList, Map paramMap) {}
  
  public void run() {
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      View view = this.f.get(i);
      String str = y.p(view);
      y.D(view, (String)this.g.get(str));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */