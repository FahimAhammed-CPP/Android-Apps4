package androidx.fragment.app;

import java.util.ArrayList;

public class i0 implements Runnable {
  public i0(ArrayList paramArrayList) {}
  
  public void run() {
    n0.p(this.f, 4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */