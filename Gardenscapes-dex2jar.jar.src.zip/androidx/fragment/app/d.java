package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;

public class d extends AnimatorListenerAdapter {
  public d(c paramc, ViewGroup paramViewGroup, View paramView, boolean paramBoolean, SpecialEffectsController.Operation paramOperation, c.b paramb) {}
  
  public void onAnimationEnd(Animator paramAnimator) {
    this.a.endViewTransition(this.b);
    if (this.c)
      this.d.a.b(this.b); 
    this.e.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */