package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;
import java.util.ArrayList;
import s.a;

public class m0 implements Runnable {
  public m0(p0 paramp0, a parama, Object paramObject1, n0.b paramb, ArrayList paramArrayList1, View paramView, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean, ArrayList paramArrayList2, Object paramObject2, Rect paramRect) {}
  
  public void run() {
    a<String, View> a1 = n0.e(this.f, this.g, this.h, this.i);
    if (a1 != null) {
      this.j.addAll(a1.values());
      this.j.add(this.k);
    } 
    n0.c(this.l, this.m, this.n, a1, false);
    Object object = this.h;
    if (object != null) {
      this.f.x(object, this.o, this.j);
      View view = n0.k(a1, this.i, this.p, this.n);
      if (view != null)
        this.f.j(view, this.q); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */