package androidx.fragment.app;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import m0.b0;
import m0.y;
import s.g;

public class c extends SpecialEffectsController {
  public c(ViewGroup paramViewGroup) {
    super(paramViewGroup);
  }
  
  public void b(List<SpecialEffectsController.Operation> paramList, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: istore #7
    //   3: getstatic androidx/fragment/app/SpecialEffectsController$Operation$State.h : Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   6: astore #18
    //   8: getstatic androidx/fragment/app/SpecialEffectsController$Operation$State.g : Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   11: astore #17
    //   13: aload_1
    //   14: invokeinterface iterator : ()Ljava/util/Iterator;
    //   19: astore #11
    //   21: aconst_null
    //   22: astore #10
    //   24: aconst_null
    //   25: astore #8
    //   27: aload #11
    //   29: invokeinterface hasNext : ()Z
    //   34: ifeq -> 126
    //   37: aload #11
    //   39: invokeinterface next : ()Ljava/lang/Object;
    //   44: checkcast androidx/fragment/app/SpecialEffectsController$Operation
    //   47: astore #9
    //   49: aload #9
    //   51: getfield c : Landroidx/fragment/app/Fragment;
    //   54: getfield mView : Landroid/view/View;
    //   57: invokestatic f : (Landroid/view/View;)Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   60: astore #12
    //   62: aload #9
    //   64: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   67: invokevirtual ordinal : ()I
    //   70: istore_3
    //   71: iload_3
    //   72: ifeq -> 107
    //   75: iload_3
    //   76: iconst_1
    //   77: if_icmpeq -> 93
    //   80: iload_3
    //   81: iconst_2
    //   82: if_icmpeq -> 107
    //   85: iload_3
    //   86: iconst_3
    //   87: if_icmpeq -> 107
    //   90: goto -> 27
    //   93: aload #12
    //   95: aload #17
    //   97: if_acmpeq -> 27
    //   100: aload #9
    //   102: astore #8
    //   104: goto -> 27
    //   107: aload #12
    //   109: aload #17
    //   111: if_acmpne -> 27
    //   114: aload #10
    //   116: ifnonnull -> 27
    //   119: aload #9
    //   121: astore #10
    //   123: goto -> 27
    //   126: new java/util/ArrayList
    //   129: dup
    //   130: invokespecial <init> : ()V
    //   133: astore #28
    //   135: new java/util/ArrayList
    //   138: dup
    //   139: invokespecial <init> : ()V
    //   142: astore #23
    //   144: new java/util/ArrayList
    //   147: dup
    //   148: aload_1
    //   149: invokespecial <init> : (Ljava/util/Collection;)V
    //   152: astore #15
    //   154: aload_1
    //   155: invokeinterface iterator : ()Ljava/util/Iterator;
    //   160: astore_1
    //   161: aload_1
    //   162: invokeinterface hasNext : ()Z
    //   167: ifeq -> 332
    //   170: aload_1
    //   171: invokeinterface next : ()Ljava/lang/Object;
    //   176: checkcast androidx/fragment/app/SpecialEffectsController$Operation
    //   179: astore #9
    //   181: new i0/b
    //   184: dup
    //   185: invokespecial <init> : ()V
    //   188: astore #11
    //   190: aload #9
    //   192: invokevirtual d : ()V
    //   195: aload #9
    //   197: getfield e : Ljava/util/HashSet;
    //   200: aload #11
    //   202: invokevirtual add : (Ljava/lang/Object;)Z
    //   205: pop
    //   206: aload #28
    //   208: new androidx/fragment/app/c$b
    //   211: dup
    //   212: aload #9
    //   214: aload #11
    //   216: iload #7
    //   218: invokespecial <init> : (Landroidx/fragment/app/SpecialEffectsController$Operation;Li0/b;Z)V
    //   221: invokevirtual add : (Ljava/lang/Object;)Z
    //   224: pop
    //   225: new i0/b
    //   228: dup
    //   229: invokespecial <init> : ()V
    //   232: astore #11
    //   234: aload #9
    //   236: invokevirtual d : ()V
    //   239: aload #9
    //   241: getfield e : Ljava/util/HashSet;
    //   244: aload #11
    //   246: invokevirtual add : (Ljava/lang/Object;)Z
    //   249: pop
    //   250: iload #7
    //   252: ifeq -> 265
    //   255: aload #9
    //   257: aload #10
    //   259: if_acmpne -> 278
    //   262: goto -> 272
    //   265: aload #9
    //   267: aload #8
    //   269: if_acmpne -> 278
    //   272: iconst_1
    //   273: istore #6
    //   275: goto -> 281
    //   278: iconst_0
    //   279: istore #6
    //   281: aload #23
    //   283: new androidx/fragment/app/c$d
    //   286: dup
    //   287: aload #9
    //   289: aload #11
    //   291: iload #7
    //   293: iload #6
    //   295: invokespecial <init> : (Landroidx/fragment/app/SpecialEffectsController$Operation;Li0/b;ZZ)V
    //   298: invokevirtual add : (Ljava/lang/Object;)Z
    //   301: pop
    //   302: new androidx/fragment/app/c$a
    //   305: dup
    //   306: aload_0
    //   307: aload #15
    //   309: aload #9
    //   311: invokespecial <init> : (Landroidx/fragment/app/c;Ljava/util/List;Landroidx/fragment/app/SpecialEffectsController$Operation;)V
    //   314: astore #11
    //   316: aload #9
    //   318: getfield d : Ljava/util/List;
    //   321: aload #11
    //   323: invokeinterface add : (Ljava/lang/Object;)Z
    //   328: pop
    //   329: goto -> 161
    //   332: new java/util/HashMap
    //   335: dup
    //   336: invokespecial <init> : ()V
    //   339: astore #12
    //   341: aload #23
    //   343: invokevirtual iterator : ()Ljava/util/Iterator;
    //   346: astore #13
    //   348: aconst_null
    //   349: astore #11
    //   351: aload #13
    //   353: invokeinterface hasNext : ()Z
    //   358: ifeq -> 579
    //   361: aload #13
    //   363: invokeinterface next : ()Ljava/lang/Object;
    //   368: checkcast androidx/fragment/app/c$d
    //   371: astore #14
    //   373: aload #14
    //   375: invokevirtual b : ()Z
    //   378: ifeq -> 384
    //   381: goto -> 351
    //   384: aload #14
    //   386: aload #14
    //   388: getfield c : Ljava/lang/Object;
    //   391: invokevirtual c : (Ljava/lang/Object;)Landroidx/fragment/app/p0;
    //   394: astore_1
    //   395: aload #14
    //   397: aload #14
    //   399: getfield e : Ljava/lang/Object;
    //   402: invokevirtual c : (Ljava/lang/Object;)Landroidx/fragment/app/p0;
    //   405: astore #9
    //   407: aload_1
    //   408: ifnull -> 490
    //   411: aload #9
    //   413: ifnull -> 490
    //   416: aload_1
    //   417: aload #9
    //   419: if_acmpne -> 425
    //   422: goto -> 490
    //   425: ldc 'Mixing framework transitions and AndroidX transitions is not allowed. Fragment '
    //   427: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   430: astore_1
    //   431: aload_1
    //   432: aload #14
    //   434: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation;
    //   437: getfield c : Landroidx/fragment/app/Fragment;
    //   440: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   443: pop
    //   444: aload_1
    //   445: ldc ' returned Transition '
    //   447: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   450: pop
    //   451: aload_1
    //   452: aload #14
    //   454: getfield c : Ljava/lang/Object;
    //   457: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   460: pop
    //   461: aload_1
    //   462: ldc ' which uses a different Transition  type than its shared element transition '
    //   464: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   467: pop
    //   468: aload_1
    //   469: aload #14
    //   471: getfield e : Ljava/lang/Object;
    //   474: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   477: pop
    //   478: new java/lang/IllegalArgumentException
    //   481: dup
    //   482: aload_1
    //   483: invokevirtual toString : ()Ljava/lang/String;
    //   486: invokespecial <init> : (Ljava/lang/String;)V
    //   489: athrow
    //   490: aload_1
    //   491: ifnull -> 497
    //   494: goto -> 500
    //   497: aload #9
    //   499: astore_1
    //   500: aload #11
    //   502: ifnonnull -> 511
    //   505: aload_1
    //   506: astore #11
    //   508: goto -> 351
    //   511: aload_1
    //   512: ifnull -> 351
    //   515: aload #11
    //   517: aload_1
    //   518: if_acmpne -> 524
    //   521: goto -> 351
    //   524: ldc 'Mixing framework transitions and AndroidX transitions is not allowed. Fragment '
    //   526: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   529: astore_1
    //   530: aload_1
    //   531: aload #14
    //   533: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation;
    //   536: getfield c : Landroidx/fragment/app/Fragment;
    //   539: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   542: pop
    //   543: aload_1
    //   544: ldc ' returned Transition '
    //   546: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   549: pop
    //   550: aload_1
    //   551: aload #14
    //   553: getfield c : Ljava/lang/Object;
    //   556: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   559: pop
    //   560: aload_1
    //   561: ldc ' which uses a different Transition  type than other Fragments.'
    //   563: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   566: pop
    //   567: new java/lang/IllegalArgumentException
    //   570: dup
    //   571: aload_1
    //   572: invokevirtual toString : ()Ljava/lang/String;
    //   575: invokespecial <init> : (Ljava/lang/String;)V
    //   578: athrow
    //   579: aload #11
    //   581: ifnonnull -> 650
    //   584: aload #23
    //   586: invokevirtual iterator : ()Ljava/util/Iterator;
    //   589: astore_1
    //   590: aload_1
    //   591: invokeinterface hasNext : ()Z
    //   596: ifeq -> 632
    //   599: aload_1
    //   600: invokeinterface next : ()Ljava/lang/Object;
    //   605: checkcast androidx/fragment/app/c$d
    //   608: astore #8
    //   610: aload #12
    //   612: aload #8
    //   614: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation;
    //   617: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   620: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   623: pop
    //   624: aload #8
    //   626: invokevirtual a : ()V
    //   629: goto -> 590
    //   632: aload #18
    //   634: astore #8
    //   636: aload #15
    //   638: astore #9
    //   640: aload #12
    //   642: astore_1
    //   643: ldc 'FragmentManager'
    //   645: astore #10
    //   647: goto -> 2219
    //   650: new android/view/View
    //   653: dup
    //   654: aload_0
    //   655: getfield a : Landroid/view/ViewGroup;
    //   658: invokevirtual getContext : ()Landroid/content/Context;
    //   661: invokespecial <init> : (Landroid/content/Context;)V
    //   664: astore #16
    //   666: new android/graphics/Rect
    //   669: dup
    //   670: invokespecial <init> : ()V
    //   673: astore #24
    //   675: new java/util/ArrayList
    //   678: dup
    //   679: invokespecial <init> : ()V
    //   682: astore #26
    //   684: new java/util/ArrayList
    //   687: dup
    //   688: invokespecial <init> : ()V
    //   691: astore #25
    //   693: new s/a
    //   696: dup
    //   697: invokespecial <init> : ()V
    //   700: astore #22
    //   702: aload #23
    //   704: invokevirtual iterator : ()Ljava/util/Iterator;
    //   707: astore #27
    //   709: aconst_null
    //   710: astore #21
    //   712: aconst_null
    //   713: astore #9
    //   715: iconst_0
    //   716: istore_3
    //   717: ldc 'FragmentManager'
    //   719: astore #14
    //   721: aload #10
    //   723: astore #13
    //   725: aload #8
    //   727: astore #19
    //   729: aload #12
    //   731: astore_1
    //   732: aload #10
    //   734: astore #20
    //   736: aload #11
    //   738: astore #10
    //   740: aload #26
    //   742: astore #12
    //   744: aload #25
    //   746: astore #11
    //   748: iload_2
    //   749: istore #6
    //   751: aload #27
    //   753: invokeinterface hasNext : ()Z
    //   758: ifeq -> 1410
    //   761: aload #27
    //   763: invokeinterface next : ()Ljava/lang/Object;
    //   768: checkcast androidx/fragment/app/c$d
    //   771: getfield e : Ljava/lang/Object;
    //   774: astore #25
    //   776: aload #25
    //   778: ifnull -> 787
    //   781: iconst_1
    //   782: istore #4
    //   784: goto -> 790
    //   787: iconst_0
    //   788: istore #4
    //   790: iload #4
    //   792: ifeq -> 1407
    //   795: aload #13
    //   797: ifnull -> 1407
    //   800: aload #19
    //   802: ifnull -> 1407
    //   805: aload #10
    //   807: aload #10
    //   809: aload #25
    //   811: invokevirtual g : (Ljava/lang/Object;)Ljava/lang/Object;
    //   814: invokevirtual y : (Ljava/lang/Object;)Ljava/lang/Object;
    //   817: astore #25
    //   819: aload #19
    //   821: getfield c : Landroidx/fragment/app/Fragment;
    //   824: invokevirtual getSharedElementSourceNames : ()Ljava/util/ArrayList;
    //   827: astore #26
    //   829: aload #13
    //   831: getfield c : Landroidx/fragment/app/Fragment;
    //   834: invokevirtual getSharedElementSourceNames : ()Ljava/util/ArrayList;
    //   837: astore #29
    //   839: aload #13
    //   841: getfield c : Landroidx/fragment/app/Fragment;
    //   844: invokevirtual getSharedElementTargetNames : ()Ljava/util/ArrayList;
    //   847: astore #21
    //   849: iconst_0
    //   850: istore #4
    //   852: iload #4
    //   854: aload #21
    //   856: invokevirtual size : ()I
    //   859: if_icmpge -> 906
    //   862: aload #26
    //   864: aload #21
    //   866: iload #4
    //   868: invokevirtual get : (I)Ljava/lang/Object;
    //   871: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   874: istore #5
    //   876: iload #5
    //   878: iconst_m1
    //   879: if_icmpeq -> 897
    //   882: aload #26
    //   884: iload #5
    //   886: aload #29
    //   888: iload #4
    //   890: invokevirtual get : (I)Ljava/lang/Object;
    //   893: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   896: pop
    //   897: iload #4
    //   899: iconst_1
    //   900: iadd
    //   901: istore #4
    //   903: goto -> 852
    //   906: aload #19
    //   908: getfield c : Landroidx/fragment/app/Fragment;
    //   911: invokevirtual getSharedElementTargetNames : ()Ljava/util/ArrayList;
    //   914: astore #29
    //   916: iload #6
    //   918: ifne -> 942
    //   921: aload #13
    //   923: getfield c : Landroidx/fragment/app/Fragment;
    //   926: invokevirtual getExitTransitionCallback : ()Lb0/u;
    //   929: pop
    //   930: aload #19
    //   932: getfield c : Landroidx/fragment/app/Fragment;
    //   935: invokevirtual getEnterTransitionCallback : ()Lb0/u;
    //   938: pop
    //   939: goto -> 960
    //   942: aload #13
    //   944: getfield c : Landroidx/fragment/app/Fragment;
    //   947: invokevirtual getEnterTransitionCallback : ()Lb0/u;
    //   950: pop
    //   951: aload #19
    //   953: getfield c : Landroidx/fragment/app/Fragment;
    //   956: invokevirtual getExitTransitionCallback : ()Lb0/u;
    //   959: pop
    //   960: aload #26
    //   962: invokevirtual size : ()I
    //   965: istore #4
    //   967: iconst_0
    //   968: istore #5
    //   970: iload #5
    //   972: iload #4
    //   974: if_icmpge -> 1012
    //   977: aload #22
    //   979: aload #26
    //   981: iload #5
    //   983: invokevirtual get : (I)Ljava/lang/Object;
    //   986: checkcast java/lang/String
    //   989: aload #29
    //   991: iload #5
    //   993: invokevirtual get : (I)Ljava/lang/Object;
    //   996: checkcast java/lang/String
    //   999: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1002: pop
    //   1003: iload #5
    //   1005: iconst_1
    //   1006: iadd
    //   1007: istore #5
    //   1009: goto -> 970
    //   1012: new s/a
    //   1015: dup
    //   1016: invokespecial <init> : ()V
    //   1019: astore #31
    //   1021: aload_0
    //   1022: aload #31
    //   1024: aload #13
    //   1026: getfield c : Landroidx/fragment/app/Fragment;
    //   1029: getfield mView : Landroid/view/View;
    //   1032: invokevirtual k : (Ljava/util/Map;Landroid/view/View;)V
    //   1035: aload #31
    //   1037: aload #26
    //   1039: invokestatic k : (Ljava/util/Map;Ljava/util/Collection;)Z
    //   1042: pop
    //   1043: aload #22
    //   1045: aload #31
    //   1047: invokevirtual keySet : ()Ljava/util/Set;
    //   1050: invokestatic k : (Ljava/util/Map;Ljava/util/Collection;)Z
    //   1053: pop
    //   1054: new s/a
    //   1057: dup
    //   1058: invokespecial <init> : ()V
    //   1061: astore #30
    //   1063: aload_0
    //   1064: aload #30
    //   1066: aload #19
    //   1068: getfield c : Landroidx/fragment/app/Fragment;
    //   1071: getfield mView : Landroid/view/View;
    //   1074: invokevirtual k : (Ljava/util/Map;Landroid/view/View;)V
    //   1077: aload #30
    //   1079: aload #29
    //   1081: invokestatic k : (Ljava/util/Map;Ljava/util/Collection;)Z
    //   1084: pop
    //   1085: aload #30
    //   1087: aload #22
    //   1089: invokevirtual values : ()Ljava/util/Collection;
    //   1092: invokestatic k : (Ljava/util/Map;Ljava/util/Collection;)Z
    //   1095: pop
    //   1096: aload #22
    //   1098: aload #30
    //   1100: invokestatic n : (Ls/a;Ls/a;)V
    //   1103: aload_0
    //   1104: aload #31
    //   1106: aload #22
    //   1108: invokevirtual keySet : ()Ljava/util/Set;
    //   1111: invokevirtual l : (Ls/a;Ljava/util/Collection;)V
    //   1114: aload_0
    //   1115: aload #30
    //   1117: aload #22
    //   1119: invokevirtual values : ()Ljava/util/Collection;
    //   1122: invokevirtual l : (Ls/a;Ljava/util/Collection;)V
    //   1125: aload #22
    //   1127: invokevirtual isEmpty : ()Z
    //   1130: ifeq -> 1149
    //   1133: aload #12
    //   1135: invokevirtual clear : ()V
    //   1138: aload #11
    //   1140: invokevirtual clear : ()V
    //   1143: aconst_null
    //   1144: astore #21
    //   1146: goto -> 1407
    //   1149: aload #19
    //   1151: getfield c : Landroidx/fragment/app/Fragment;
    //   1154: aload #13
    //   1156: getfield c : Landroidx/fragment/app/Fragment;
    //   1159: iload #6
    //   1161: aload #31
    //   1163: iconst_1
    //   1164: invokestatic c : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/Fragment;ZLs/a;Z)V
    //   1167: aload_0
    //   1168: getfield a : Landroid/view/ViewGroup;
    //   1171: astore #32
    //   1173: aload #12
    //   1175: astore #13
    //   1177: aload #11
    //   1179: astore #19
    //   1181: aload #10
    //   1183: astore #21
    //   1185: aload #32
    //   1187: new androidx/fragment/app/h
    //   1190: dup
    //   1191: aload_0
    //   1192: aload #8
    //   1194: aload #20
    //   1196: iload_2
    //   1197: aload #30
    //   1199: invokespecial <init> : (Landroidx/fragment/app/c;Landroidx/fragment/app/SpecialEffectsController$Operation;Landroidx/fragment/app/SpecialEffectsController$Operation;ZLs/a;)V
    //   1202: invokestatic a : (Landroid/view/View;Ljava/lang/Runnable;)Lm0/s;
    //   1205: pop
    //   1206: aload #13
    //   1208: aload #31
    //   1210: invokevirtual values : ()Ljava/util/Collection;
    //   1213: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   1216: pop
    //   1217: aload #26
    //   1219: invokevirtual isEmpty : ()Z
    //   1222: ifne -> 1256
    //   1225: aload #31
    //   1227: aload #26
    //   1229: iconst_0
    //   1230: invokevirtual get : (I)Ljava/lang/Object;
    //   1233: checkcast java/lang/String
    //   1236: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1239: checkcast android/view/View
    //   1242: astore #9
    //   1244: aload #21
    //   1246: aload #25
    //   1248: aload #9
    //   1250: invokevirtual t : (Ljava/lang/Object;Landroid/view/View;)V
    //   1253: goto -> 1256
    //   1256: aload #19
    //   1258: aload #30
    //   1260: invokevirtual values : ()Ljava/util/Collection;
    //   1263: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   1266: pop
    //   1267: aload #29
    //   1269: invokevirtual isEmpty : ()Z
    //   1272: ifne -> 1326
    //   1275: aload #30
    //   1277: aload #29
    //   1279: iconst_0
    //   1280: invokevirtual get : (I)Ljava/lang/Object;
    //   1283: checkcast java/lang/String
    //   1286: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1289: checkcast android/view/View
    //   1292: astore #26
    //   1294: aload #26
    //   1296: ifnull -> 1326
    //   1299: aload_0
    //   1300: getfield a : Landroid/view/ViewGroup;
    //   1303: new androidx/fragment/app/i
    //   1306: dup
    //   1307: aload_0
    //   1308: aload #21
    //   1310: aload #26
    //   1312: aload #24
    //   1314: invokespecial <init> : (Landroidx/fragment/app/c;Landroidx/fragment/app/p0;Landroid/view/View;Landroid/graphics/Rect;)V
    //   1317: invokestatic a : (Landroid/view/View;Ljava/lang/Runnable;)Lm0/s;
    //   1320: pop
    //   1321: iconst_1
    //   1322: istore_3
    //   1323: goto -> 1326
    //   1326: aload #21
    //   1328: aload #25
    //   1330: aload #16
    //   1332: aload #13
    //   1334: invokevirtual w : (Ljava/lang/Object;Landroid/view/View;Ljava/util/ArrayList;)V
    //   1337: aload #21
    //   1339: aload #25
    //   1341: aconst_null
    //   1342: aconst_null
    //   1343: aconst_null
    //   1344: aconst_null
    //   1345: aload #25
    //   1347: aload #19
    //   1349: invokevirtual r : (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;)V
    //   1352: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   1355: astore #21
    //   1357: aload_1
    //   1358: astore #19
    //   1360: aload #19
    //   1362: aload #20
    //   1364: aload #21
    //   1366: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1369: pop
    //   1370: aload #8
    //   1372: astore #13
    //   1374: aload #19
    //   1376: aload #13
    //   1378: aload #21
    //   1380: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1383: pop
    //   1384: aload #25
    //   1386: astore #21
    //   1388: aload #20
    //   1390: astore #19
    //   1392: aload #13
    //   1394: astore #25
    //   1396: aload #19
    //   1398: astore #13
    //   1400: aload #25
    //   1402: astore #19
    //   1404: goto -> 1407
    //   1407: goto -> 748
    //   1410: aload #18
    //   1412: astore #25
    //   1414: aload #17
    //   1416: astore #26
    //   1418: aload #15
    //   1420: astore #17
    //   1422: aload_1
    //   1423: astore #18
    //   1425: aload #14
    //   1427: astore #20
    //   1429: aload #16
    //   1431: astore #27
    //   1433: new java/util/ArrayList
    //   1436: dup
    //   1437: invokespecial <init> : ()V
    //   1440: astore #29
    //   1442: aload #23
    //   1444: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1447: astore #16
    //   1449: aconst_null
    //   1450: astore_1
    //   1451: aconst_null
    //   1452: astore #15
    //   1454: aload #25
    //   1456: astore #14
    //   1458: aload #26
    //   1460: astore #25
    //   1462: aload #9
    //   1464: astore #26
    //   1466: aload #15
    //   1468: astore #9
    //   1470: aload #16
    //   1472: invokeinterface hasNext : ()Z
    //   1477: ifeq -> 1879
    //   1480: aload #16
    //   1482: invokeinterface next : ()Ljava/lang/Object;
    //   1487: checkcast androidx/fragment/app/c$d
    //   1490: astore #15
    //   1492: aload #15
    //   1494: invokevirtual b : ()Z
    //   1497: ifeq -> 1526
    //   1500: aload #18
    //   1502: aload #15
    //   1504: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation;
    //   1507: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   1510: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1513: pop
    //   1514: aload #15
    //   1516: invokevirtual a : ()V
    //   1519: aload #19
    //   1521: astore #15
    //   1523: goto -> 1872
    //   1526: aload #10
    //   1528: aload #15
    //   1530: getfield c : Ljava/lang/Object;
    //   1533: invokevirtual g : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1536: astore #30
    //   1538: aload #15
    //   1540: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation;
    //   1543: astore #31
    //   1545: aload #21
    //   1547: ifnull -> 1570
    //   1550: aload #31
    //   1552: aload #13
    //   1554: if_acmpeq -> 1564
    //   1557: aload #31
    //   1559: aload #19
    //   1561: if_acmpne -> 1570
    //   1564: iconst_1
    //   1565: istore #4
    //   1567: goto -> 1573
    //   1570: iconst_0
    //   1571: istore #4
    //   1573: aload #30
    //   1575: ifnonnull -> 1602
    //   1578: iload #4
    //   1580: ifne -> 1599
    //   1583: aload #18
    //   1585: aload #31
    //   1587: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   1590: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1593: pop
    //   1594: aload #15
    //   1596: invokevirtual a : ()V
    //   1599: goto -> 1868
    //   1602: new java/util/ArrayList
    //   1605: dup
    //   1606: invokespecial <init> : ()V
    //   1609: astore #19
    //   1611: aload_0
    //   1612: aload #19
    //   1614: aload #31
    //   1616: getfield c : Landroidx/fragment/app/Fragment;
    //   1619: getfield mView : Landroid/view/View;
    //   1622: invokevirtual j : (Ljava/util/ArrayList;Landroid/view/View;)V
    //   1625: iload #4
    //   1627: ifeq -> 1656
    //   1630: aload #31
    //   1632: aload #13
    //   1634: if_acmpne -> 1648
    //   1637: aload #19
    //   1639: aload #12
    //   1641: invokevirtual removeAll : (Ljava/util/Collection;)Z
    //   1644: pop
    //   1645: goto -> 1656
    //   1648: aload #19
    //   1650: aload #11
    //   1652: invokevirtual removeAll : (Ljava/util/Collection;)Z
    //   1655: pop
    //   1656: aload #19
    //   1658: invokevirtual isEmpty : ()Z
    //   1661: ifeq -> 1676
    //   1664: aload #10
    //   1666: aload #30
    //   1668: aload #27
    //   1670: invokevirtual a : (Ljava/lang/Object;Landroid/view/View;)V
    //   1673: goto -> 1781
    //   1676: aload #10
    //   1678: aload #30
    //   1680: aload #19
    //   1682: invokevirtual b : (Ljava/lang/Object;Ljava/util/ArrayList;)V
    //   1685: aload #10
    //   1687: aload #30
    //   1689: aload #30
    //   1691: aload #19
    //   1693: aconst_null
    //   1694: aconst_null
    //   1695: aconst_null
    //   1696: aconst_null
    //   1697: invokevirtual r : (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;)V
    //   1700: aload #31
    //   1702: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   1705: aload #14
    //   1707: if_acmpne -> 1781
    //   1710: aload #17
    //   1712: aload #31
    //   1714: invokevirtual remove : (Ljava/lang/Object;)Z
    //   1717: pop
    //   1718: new java/util/ArrayList
    //   1721: dup
    //   1722: aload #19
    //   1724: invokespecial <init> : (Ljava/util/Collection;)V
    //   1727: astore #32
    //   1729: aload #32
    //   1731: aload #31
    //   1733: getfield c : Landroidx/fragment/app/Fragment;
    //   1736: getfield mView : Landroid/view/View;
    //   1739: invokevirtual remove : (Ljava/lang/Object;)Z
    //   1742: pop
    //   1743: aload #10
    //   1745: aload #30
    //   1747: aload #31
    //   1749: getfield c : Landroidx/fragment/app/Fragment;
    //   1752: getfield mView : Landroid/view/View;
    //   1755: aload #32
    //   1757: invokevirtual q : (Ljava/lang/Object;Landroid/view/View;Ljava/util/ArrayList;)V
    //   1760: aload_0
    //   1761: getfield a : Landroid/view/ViewGroup;
    //   1764: new androidx/fragment/app/j
    //   1767: dup
    //   1768: aload_0
    //   1769: aload #19
    //   1771: invokespecial <init> : (Landroidx/fragment/app/c;Ljava/util/ArrayList;)V
    //   1774: invokestatic a : (Landroid/view/View;Ljava/lang/Runnable;)Lm0/s;
    //   1777: pop
    //   1778: goto -> 1781
    //   1781: aload #31
    //   1783: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   1786: aload #25
    //   1788: if_acmpne -> 1815
    //   1791: aload #29
    //   1793: aload #19
    //   1795: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   1798: pop
    //   1799: iload_3
    //   1800: ifeq -> 1812
    //   1803: aload #10
    //   1805: aload #30
    //   1807: aload #24
    //   1809: invokevirtual s : (Ljava/lang/Object;Landroid/graphics/Rect;)V
    //   1812: goto -> 1824
    //   1815: aload #10
    //   1817: aload #30
    //   1819: aload #26
    //   1821: invokevirtual t : (Ljava/lang/Object;Landroid/view/View;)V
    //   1824: aload #18
    //   1826: aload #31
    //   1828: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   1831: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1834: pop
    //   1835: aload #15
    //   1837: getfield d : Z
    //   1840: ifeq -> 1858
    //   1843: aload #10
    //   1845: aload #9
    //   1847: aload #30
    //   1849: aconst_null
    //   1850: invokevirtual m : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1853: astore #9
    //   1855: goto -> 1868
    //   1858: aload #10
    //   1860: aload_1
    //   1861: aload #30
    //   1863: aconst_null
    //   1864: invokevirtual m : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1867: astore_1
    //   1868: aload #8
    //   1870: astore #15
    //   1872: aload #15
    //   1874: astore #19
    //   1876: goto -> 1470
    //   1879: aload #8
    //   1881: astore #15
    //   1883: aload #14
    //   1885: astore #8
    //   1887: aload #10
    //   1889: aload #9
    //   1891: aload_1
    //   1892: aload #21
    //   1894: invokevirtual l : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1897: astore #14
    //   1899: aload #23
    //   1901: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1904: astore #16
    //   1906: aload #20
    //   1908: astore_1
    //   1909: aload #15
    //   1911: astore #9
    //   1913: aload #16
    //   1915: invokeinterface hasNext : ()Z
    //   1920: ifeq -> 2116
    //   1923: aload #16
    //   1925: invokeinterface next : ()Ljava/lang/Object;
    //   1930: checkcast androidx/fragment/app/c$d
    //   1933: astore #15
    //   1935: aload #15
    //   1937: invokevirtual b : ()Z
    //   1940: ifeq -> 1946
    //   1943: goto -> 1913
    //   1946: aload #15
    //   1948: getfield c : Ljava/lang/Object;
    //   1951: astore #20
    //   1953: aload #15
    //   1955: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation;
    //   1958: astore #19
    //   1960: aload #21
    //   1962: ifnull -> 1984
    //   1965: aload #19
    //   1967: aload #13
    //   1969: if_acmpeq -> 1979
    //   1972: aload #19
    //   1974: aload #9
    //   1976: if_acmpne -> 1984
    //   1979: iconst_1
    //   1980: istore_3
    //   1981: goto -> 1986
    //   1984: iconst_0
    //   1985: istore_3
    //   1986: aload #20
    //   1988: ifnonnull -> 2001
    //   1991: iload_3
    //   1992: ifeq -> 1998
    //   1995: goto -> 2001
    //   1998: goto -> 2080
    //   2001: aload_0
    //   2002: getfield a : Landroid/view/ViewGroup;
    //   2005: astore #20
    //   2007: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   2010: astore #23
    //   2012: aload #20
    //   2014: invokestatic c : (Landroid/view/View;)Z
    //   2017: ifne -> 2083
    //   2020: iconst_2
    //   2021: invokestatic O : (I)Z
    //   2024: ifeq -> 2075
    //   2027: ldc_w 'SpecialEffectsController: Container '
    //   2030: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2033: astore #20
    //   2035: aload #20
    //   2037: aload_0
    //   2038: getfield a : Landroid/view/ViewGroup;
    //   2041: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2044: pop
    //   2045: aload #20
    //   2047: ldc_w ' has not been laid out. Completing operation '
    //   2050: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2053: pop
    //   2054: aload #20
    //   2056: aload #19
    //   2058: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2061: pop
    //   2062: aload_1
    //   2063: aload #20
    //   2065: invokevirtual toString : ()Ljava/lang/String;
    //   2068: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2071: pop
    //   2072: goto -> 2075
    //   2075: aload #15
    //   2077: invokevirtual a : ()V
    //   2080: goto -> 2113
    //   2083: aload #10
    //   2085: aload #15
    //   2087: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation;
    //   2090: getfield c : Landroidx/fragment/app/Fragment;
    //   2093: aload #14
    //   2095: aload #15
    //   2097: getfield b : Li0/b;
    //   2100: new androidx/fragment/app/k
    //   2103: dup
    //   2104: aload_0
    //   2105: aload #15
    //   2107: invokespecial <init> : (Landroidx/fragment/app/c;Landroidx/fragment/app/c$d;)V
    //   2110: invokevirtual u : (Landroidx/fragment/app/Fragment;Ljava/lang/Object;Li0/b;Ljava/lang/Runnable;)V
    //   2113: goto -> 1913
    //   2116: aload_1
    //   2117: astore #13
    //   2119: aload_0
    //   2120: getfield a : Landroid/view/ViewGroup;
    //   2123: astore_1
    //   2124: getstatic m0/y.a : Ljava/util/WeakHashMap;
    //   2127: astore #9
    //   2129: aload_1
    //   2130: invokestatic c : (Landroid/view/View;)Z
    //   2133: ifne -> 2150
    //   2136: aload #18
    //   2138: astore_1
    //   2139: aload #13
    //   2141: astore #10
    //   2143: aload #17
    //   2145: astore #9
    //   2147: goto -> 2219
    //   2150: aload #29
    //   2152: iconst_4
    //   2153: invokestatic p : (Ljava/util/ArrayList;I)V
    //   2156: aload #10
    //   2158: aload #11
    //   2160: invokevirtual n : (Ljava/util/ArrayList;)Ljava/util/ArrayList;
    //   2163: astore_1
    //   2164: aload #10
    //   2166: aload_0
    //   2167: getfield a : Landroid/view/ViewGroup;
    //   2170: aload #14
    //   2172: invokevirtual c : (Landroid/view/ViewGroup;Ljava/lang/Object;)V
    //   2175: aload #10
    //   2177: aload_0
    //   2178: getfield a : Landroid/view/ViewGroup;
    //   2181: aload #12
    //   2183: aload #11
    //   2185: aload_1
    //   2186: aload #22
    //   2188: invokevirtual v : (Landroid/view/View;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/Map;)V
    //   2191: aload #29
    //   2193: iconst_0
    //   2194: invokestatic p : (Ljava/util/ArrayList;I)V
    //   2197: aload #10
    //   2199: aload #21
    //   2201: aload #12
    //   2203: aload #11
    //   2205: invokevirtual x : (Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    //   2208: aload #17
    //   2210: astore #9
    //   2212: aload #13
    //   2214: astore #10
    //   2216: aload #18
    //   2218: astore_1
    //   2219: aload_1
    //   2220: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   2223: invokevirtual containsValue : (Ljava/lang/Object;)Z
    //   2226: istore #6
    //   2228: aload_0
    //   2229: getfield a : Landroid/view/ViewGroup;
    //   2232: astore #11
    //   2234: aload #11
    //   2236: invokevirtual getContext : ()Landroid/content/Context;
    //   2239: astore #12
    //   2241: new java/util/ArrayList
    //   2244: dup
    //   2245: invokespecial <init> : ()V
    //   2248: astore #13
    //   2250: aload #28
    //   2252: invokevirtual iterator : ()Ljava/util/Iterator;
    //   2255: astore #14
    //   2257: iconst_0
    //   2258: istore_3
    //   2259: aload #14
    //   2261: invokeinterface hasNext : ()Z
    //   2266: ifeq -> 2532
    //   2269: aload #14
    //   2271: invokeinterface next : ()Ljava/lang/Object;
    //   2276: checkcast androidx/fragment/app/c$b
    //   2279: astore #15
    //   2281: aload #15
    //   2283: invokevirtual b : ()Z
    //   2286: ifeq -> 2297
    //   2289: aload #15
    //   2291: invokevirtual a : ()V
    //   2294: goto -> 2259
    //   2297: aload #15
    //   2299: aload #12
    //   2301: invokevirtual c : (Landroid/content/Context;)Landroidx/fragment/app/r$a;
    //   2304: astore #16
    //   2306: aload #16
    //   2308: ifnonnull -> 2319
    //   2311: aload #15
    //   2313: invokevirtual a : ()V
    //   2316: goto -> 2259
    //   2319: aload #16
    //   2321: getfield b : Landroid/animation/Animator;
    //   2324: astore #16
    //   2326: aload #16
    //   2328: ifnonnull -> 2342
    //   2331: aload #13
    //   2333: aload #15
    //   2335: invokevirtual add : (Ljava/lang/Object;)Z
    //   2338: pop
    //   2339: goto -> 2259
    //   2342: aload #15
    //   2344: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation;
    //   2347: astore #17
    //   2349: aload #17
    //   2351: getfield c : Landroidx/fragment/app/Fragment;
    //   2354: astore #18
    //   2356: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   2359: aload_1
    //   2360: aload #17
    //   2362: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2365: invokevirtual equals : (Ljava/lang/Object;)Z
    //   2368: ifeq -> 2432
    //   2371: iconst_2
    //   2372: invokestatic O : (I)Z
    //   2375: ifeq -> 2424
    //   2378: new java/lang/StringBuilder
    //   2381: dup
    //   2382: invokespecial <init> : ()V
    //   2385: astore #16
    //   2387: aload #16
    //   2389: ldc_w 'Ignoring Animator set on '
    //   2392: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2395: pop
    //   2396: aload #16
    //   2398: aload #18
    //   2400: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2403: pop
    //   2404: aload #16
    //   2406: ldc_w ' as this Fragment was involved in a Transition.'
    //   2409: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2412: pop
    //   2413: aload #10
    //   2415: aload #16
    //   2417: invokevirtual toString : ()Ljava/lang/String;
    //   2420: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2423: pop
    //   2424: aload #15
    //   2426: invokevirtual a : ()V
    //   2429: goto -> 2259
    //   2432: aload #17
    //   2434: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   2437: aload #8
    //   2439: if_acmpne -> 2447
    //   2442: iconst_1
    //   2443: istore_2
    //   2444: goto -> 2449
    //   2447: iconst_0
    //   2448: istore_2
    //   2449: iload_2
    //   2450: ifeq -> 2461
    //   2453: aload #9
    //   2455: aload #17
    //   2457: invokevirtual remove : (Ljava/lang/Object;)Z
    //   2460: pop
    //   2461: aload #18
    //   2463: getfield mView : Landroid/view/View;
    //   2466: astore #18
    //   2468: aload #11
    //   2470: aload #18
    //   2472: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   2475: aload #16
    //   2477: new androidx/fragment/app/d
    //   2480: dup
    //   2481: aload_0
    //   2482: aload #11
    //   2484: aload #18
    //   2486: iload_2
    //   2487: aload #17
    //   2489: aload #15
    //   2491: invokespecial <init> : (Landroidx/fragment/app/c;Landroid/view/ViewGroup;Landroid/view/View;ZLandroidx/fragment/app/SpecialEffectsController$Operation;Landroidx/fragment/app/c$b;)V
    //   2494: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   2497: aload #16
    //   2499: aload #18
    //   2501: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   2504: aload #16
    //   2506: invokevirtual start : ()V
    //   2509: aload #15
    //   2511: getfield b : Li0/b;
    //   2514: new androidx/fragment/app/e
    //   2517: dup
    //   2518: aload_0
    //   2519: aload #16
    //   2521: invokespecial <init> : (Landroidx/fragment/app/c;Landroid/animation/Animator;)V
    //   2524: invokevirtual b : (Li0/b$a;)V
    //   2527: iconst_1
    //   2528: istore_3
    //   2529: goto -> 2259
    //   2532: aload #13
    //   2534: invokevirtual iterator : ()Ljava/util/Iterator;
    //   2537: astore_1
    //   2538: aload_1
    //   2539: invokeinterface hasNext : ()Z
    //   2544: ifeq -> 2837
    //   2547: aload_1
    //   2548: invokeinterface next : ()Ljava/lang/Object;
    //   2553: checkcast androidx/fragment/app/c$b
    //   2556: astore #8
    //   2558: aload #8
    //   2560: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation;
    //   2563: astore #13
    //   2565: aload #13
    //   2567: getfield c : Landroidx/fragment/app/Fragment;
    //   2570: astore #14
    //   2572: iload #6
    //   2574: ifeq -> 2638
    //   2577: iconst_2
    //   2578: invokestatic O : (I)Z
    //   2581: ifeq -> 2630
    //   2584: new java/lang/StringBuilder
    //   2587: dup
    //   2588: invokespecial <init> : ()V
    //   2591: astore #13
    //   2593: aload #13
    //   2595: ldc_w 'Ignoring Animation set on '
    //   2598: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2601: pop
    //   2602: aload #13
    //   2604: aload #14
    //   2606: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2609: pop
    //   2610: aload #13
    //   2612: ldc_w ' as Animations cannot run alongside Transitions.'
    //   2615: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2618: pop
    //   2619: aload #10
    //   2621: aload #13
    //   2623: invokevirtual toString : ()Ljava/lang/String;
    //   2626: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2629: pop
    //   2630: aload #8
    //   2632: invokevirtual a : ()V
    //   2635: goto -> 2538
    //   2638: iload_3
    //   2639: ifeq -> 2703
    //   2642: iconst_2
    //   2643: invokestatic O : (I)Z
    //   2646: ifeq -> 2695
    //   2649: new java/lang/StringBuilder
    //   2652: dup
    //   2653: invokespecial <init> : ()V
    //   2656: astore #13
    //   2658: aload #13
    //   2660: ldc_w 'Ignoring Animation set on '
    //   2663: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2666: pop
    //   2667: aload #13
    //   2669: aload #14
    //   2671: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2674: pop
    //   2675: aload #13
    //   2677: ldc_w ' as Animations cannot run alongside Animators.'
    //   2680: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2683: pop
    //   2684: aload #10
    //   2686: aload #13
    //   2688: invokevirtual toString : ()Ljava/lang/String;
    //   2691: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2694: pop
    //   2695: aload #8
    //   2697: invokevirtual a : ()V
    //   2700: goto -> 2538
    //   2703: aload #14
    //   2705: getfield mView : Landroid/view/View;
    //   2708: astore #14
    //   2710: aload #8
    //   2712: aload #12
    //   2714: invokevirtual c : (Landroid/content/Context;)Landroidx/fragment/app/r$a;
    //   2717: astore #15
    //   2719: aload #15
    //   2721: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2724: pop
    //   2725: aload #15
    //   2727: getfield a : Landroid/view/animation/Animation;
    //   2730: astore #15
    //   2732: aload #15
    //   2734: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2737: pop
    //   2738: aload #13
    //   2740: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   2743: getstatic androidx/fragment/app/SpecialEffectsController$Operation$State.f : Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   2746: if_acmpeq -> 2764
    //   2749: aload #14
    //   2751: aload #15
    //   2753: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   2756: aload #8
    //   2758: invokevirtual a : ()V
    //   2761: goto -> 2812
    //   2764: aload #11
    //   2766: aload #14
    //   2768: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   2771: new androidx/fragment/app/r$b
    //   2774: dup
    //   2775: aload #15
    //   2777: aload #11
    //   2779: aload #14
    //   2781: invokespecial <init> : (Landroid/view/animation/Animation;Landroid/view/ViewGroup;Landroid/view/View;)V
    //   2784: astore #13
    //   2786: aload #13
    //   2788: new androidx/fragment/app/f
    //   2791: dup
    //   2792: aload_0
    //   2793: aload #11
    //   2795: aload #14
    //   2797: aload #8
    //   2799: invokespecial <init> : (Landroidx/fragment/app/c;Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/c$b;)V
    //   2802: invokevirtual setAnimationListener : (Landroid/view/animation/Animation$AnimationListener;)V
    //   2805: aload #14
    //   2807: aload #13
    //   2809: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   2812: aload #8
    //   2814: getfield b : Li0/b;
    //   2817: new androidx/fragment/app/g
    //   2820: dup
    //   2821: aload_0
    //   2822: aload #14
    //   2824: aload #11
    //   2826: aload #8
    //   2828: invokespecial <init> : (Landroidx/fragment/app/c;Landroid/view/View;Landroid/view/ViewGroup;Landroidx/fragment/app/c$b;)V
    //   2831: invokevirtual b : (Li0/b$a;)V
    //   2834: goto -> 2538
    //   2837: aload #9
    //   2839: invokevirtual iterator : ()Ljava/util/Iterator;
    //   2842: astore_1
    //   2843: aload_1
    //   2844: invokeinterface hasNext : ()Z
    //   2849: ifeq -> 2886
    //   2852: aload_1
    //   2853: invokeinterface next : ()Ljava/lang/Object;
    //   2858: checkcast androidx/fragment/app/SpecialEffectsController$Operation
    //   2861: astore #8
    //   2863: aload #8
    //   2865: getfield c : Landroidx/fragment/app/Fragment;
    //   2868: getfield mView : Landroid/view/View;
    //   2871: astore #10
    //   2873: aload #8
    //   2875: getfield a : Landroidx/fragment/app/SpecialEffectsController$Operation$State;
    //   2878: aload #10
    //   2880: invokevirtual b : (Landroid/view/View;)V
    //   2883: goto -> 2843
    //   2886: aload #9
    //   2888: invokevirtual clear : ()V
    //   2891: return
  }
  
  public void j(ArrayList<View> paramArrayList, View paramView) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      if (b0.a(viewGroup)) {
        if (!paramArrayList.contains(paramView)) {
          paramArrayList.add(viewGroup);
          return;
        } 
      } else {
        int j = viewGroup.getChildCount();
        for (int i = 0; i < j; i++) {
          paramView = viewGroup.getChildAt(i);
          if (paramView.getVisibility() == 0)
            j(paramArrayList, paramView); 
        } 
      } 
    } else if (!paramArrayList.contains(paramView)) {
      paramArrayList.add(paramView);
    } 
  }
  
  public void k(Map<String, View> paramMap, View paramView) {
    String str = y.p(paramView);
    if (str != null)
      paramMap.put(str, paramView); 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int j = viewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = viewGroup.getChildAt(i);
        if (view.getVisibility() == 0)
          k(paramMap, view); 
      } 
    } 
  }
  
  public void l(s.a<String, View> parama, Collection<String> paramCollection) {
    Iterator iterator = ((g.b)parama.entrySet()).iterator();
    while (true) {
      g.d d = (g.d)iterator;
      if (d.hasNext()) {
        d.next();
        if (!paramCollection.contains(y.p((View)((Map.Entry)d).getValue())))
          d.remove(); 
        continue;
      } 
      break;
    } 
  }
  
  public class a implements Runnable {
    public a(c this$0, List param1List, SpecialEffectsController.Operation param1Operation) {}
    
    public void run() {
      if (this.f.contains(this.g)) {
        this.f.remove(this.g);
        c c1 = this.h;
        SpecialEffectsController.Operation operation = this.g;
        Objects.requireNonNull(c1);
        View view = operation.c.mView;
        operation.a.b(view);
      } 
    }
  }
  
  public static class b extends c {
    public boolean c;
    
    public boolean d = false;
    
    public r.a e;
    
    public b(SpecialEffectsController.Operation param1Operation, i0.b param1b, boolean param1Boolean) {
      super(param1Operation, param1b);
      this.c = param1Boolean;
    }
    
    public r.a c(Context param1Context) {
      boolean bool;
      if (this.d)
        return this.e; 
      SpecialEffectsController.Operation operation = this.a;
      Fragment fragment = operation.c;
      if (operation.a == SpecialEffectsController.Operation.State.g) {
        bool = true;
      } else {
        bool = false;
      } 
      r.a a1 = r.a(param1Context, fragment, bool, this.c);
      this.e = a1;
      this.d = true;
      return a1;
    }
  }
  
  public static class c {
    public final SpecialEffectsController.Operation a;
    
    public final i0.b b;
    
    public c(SpecialEffectsController.Operation param1Operation, i0.b param1b) {
      this.a = param1Operation;
      this.b = param1b;
    }
    
    public void a() {
      SpecialEffectsController.Operation operation = this.a;
      i0.b b1 = this.b;
      if (operation.e.remove(b1) && operation.e.isEmpty())
        operation.b(); 
    }
    
    public boolean b() {
      SpecialEffectsController.Operation.State state1 = SpecialEffectsController.Operation.State.f(this.a.c.mView);
      SpecialEffectsController.Operation.State state2 = this.a.a;
      if (state1 != state2) {
        SpecialEffectsController.Operation.State state = SpecialEffectsController.Operation.State.g;
        if (state1 == state || state2 == state)
          return false; 
      } 
      return true;
    }
  }
  
  public static class d extends c {
    public final Object c;
    
    public final boolean d;
    
    public final Object e;
    
    public d(SpecialEffectsController.Operation param1Operation, i0.b param1b, boolean param1Boolean1, boolean param1Boolean2) {
      super(param1Operation, param1b);
      if (param1Operation.a == SpecialEffectsController.Operation.State.g) {
        Object object;
        boolean bool;
        if (param1Boolean1) {
          object = param1Operation.c.getReenterTransition();
        } else {
          object = param1Operation.c.getEnterTransition();
        } 
        this.c = object;
        if (param1Boolean1) {
          bool = param1Operation.c.getAllowReturnTransitionOverlap();
        } else {
          bool = param1Operation.c.getAllowEnterTransitionOverlap();
        } 
        this.d = bool;
      } else {
        Object object;
        if (param1Boolean1) {
          object = param1Operation.c.getReturnTransition();
        } else {
          object = param1Operation.c.getExitTransition();
        } 
        this.c = object;
        this.d = true;
      } 
      if (param1Boolean2) {
        if (param1Boolean1) {
          this.e = param1Operation.c.getSharedElementReturnTransition();
          return;
        } 
        this.e = param1Operation.c.getSharedElementEnterTransition();
        return;
      } 
      this.e = null;
    }
    
    public final p0 c(Object param1Object) {
      if (param1Object == null)
        return null; 
      p0 p0 = n0.b;
      if (p0 != null) {
        Objects.requireNonNull((o0)p0);
        if (param1Object instanceof android.transition.Transition)
          return p0; 
      } 
      p0 = n0.c;
      if (p0 != null && p0.e(param1Object))
        return p0; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Transition ");
      stringBuilder.append(param1Object);
      stringBuilder.append(" for fragment ");
      stringBuilder.append(this.a.c);
      stringBuilder.append(" is not a valid framework Transition or AndroidX Transition");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */