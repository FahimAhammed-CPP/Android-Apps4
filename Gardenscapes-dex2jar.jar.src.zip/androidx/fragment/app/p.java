package androidx.fragment.app;

import android.view.ViewGroup;
import android.view.animation.Animation;
import i0.b;

public class p implements Animation.AnimationListener {
  public p(ViewGroup paramViewGroup, Fragment paramFragment, n0.a parama, b paramb) {}
  
  public void onAnimationEnd(Animation paramAnimation) {
    this.a.post(new a(this));
  }
  
  public void onAnimationRepeat(Animation paramAnimation) {}
  
  public void onAnimationStart(Animation paramAnimation) {}
  
  public class a implements Runnable {
    public a(p this$0) {}
    
    public void run() {
      if (this.f.b.getAnimatingAway() != null) {
        this.f.b.setAnimatingAway(null);
        p p1 = this.f;
        n0.a a1 = p1.c;
        Fragment fragment = p1.b;
        b b = p1.d;
        ((FragmentManager.d)a1).a(fragment, b);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */