package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.appcompat.widget.w0;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.b0;
import androidx.lifecycle.c0;
import androidx.lifecycle.d0;
import androidx.lifecycle.w;
import androidx.lifecycle.y;
import androidx.lifecycle.z;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class FragmentManager {
  public ArrayDeque<k> A = new ArrayDeque<k>();
  
  public boolean B;
  
  public boolean C;
  
  public boolean D;
  
  public boolean E;
  
  public boolean F;
  
  public ArrayList<a> G;
  
  public ArrayList<Boolean> H;
  
  public ArrayList<Fragment> I;
  
  public ArrayList<o> J;
  
  public b0 K;
  
  public Runnable L = new g(this);
  
  public final ArrayList<m> a = new ArrayList<m>();
  
  public boolean b;
  
  public final f0 c = new f0(0);
  
  public ArrayList<a> d;
  
  public ArrayList<Fragment> e;
  
  public final x f = new x(this);
  
  public OnBackPressedDispatcher g;
  
  public final androidx.activity.b h = new c(this, false);
  
  public final AtomicInteger i = new AtomicInteger();
  
  public final Map<String, Bundle> j = Collections.synchronizedMap(new HashMap<String, Bundle>());
  
  public final Map<String, Object> k = Collections.synchronizedMap(new HashMap<String, Object>());
  
  public ArrayList<l> l;
  
  public Map<Fragment, HashSet<i0.b>> m = Collections.synchronizedMap(new HashMap<Fragment, HashSet<i0.b>>());
  
  public final n0.a n = new d(this);
  
  public final y o = new y(this);
  
  public final CopyOnWriteArrayList<c0> p = new CopyOnWriteArrayList<c0>();
  
  public int q = -1;
  
  public w<?> r;
  
  public s s;
  
  public Fragment t;
  
  public Fragment u;
  
  public v v = new e(this);
  
  public u0 w = new f(this);
  
  public androidx.activity.result.c<Intent> x;
  
  public androidx.activity.result.c<androidx.activity.result.f> y;
  
  public androidx.activity.result.c<String[]> z;
  
  public static boolean O(int paramInt) {
    return Log.isLoggable("FragmentManager", paramInt);
  }
  
  public void A(m paramm, boolean paramBoolean) {
    if (!paramBoolean) {
      if (this.r == null) {
        if (this.E)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      if (S())
        throw new IllegalStateException("Can not perform this action after onSaveInstanceState"); 
    } 
    synchronized (this.a) {
      if (this.r == null) {
        if (paramBoolean)
          return; 
        throw new IllegalStateException("Activity has been destroyed");
      } 
      this.a.add(paramm);
      d0();
      return;
    } 
  }
  
  public final void B(boolean paramBoolean) {
    if (!this.b) {
      if (this.r == null) {
        if (this.E)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      if (Looper.myLooper() == this.r.h.getLooper()) {
        if (paramBoolean || !S()) {
          if (this.G == null) {
            this.G = new ArrayList<a>();
            this.H = new ArrayList<Boolean>();
          } 
          this.b = true;
          try {
            F(null, null);
            return;
          } finally {
            this.b = false;
          } 
        } 
        throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
      } 
      throw new IllegalStateException("Must be called from main thread of fragment host");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  public boolean C(boolean paramBoolean) {
    B(paramBoolean);
    paramBoolean = false;
    while (true) {
      null = this.G;
      ArrayList<Boolean> arrayList = this.H;
      synchronized (this.a) {
        boolean bool;
        if (this.a.isEmpty()) {
          bool = false;
        } else {
          int j = this.a.size();
          int i = 0;
          bool = false;
          while (i < j) {
            bool |= ((m)this.a.get(i)).a(null, arrayList);
            i++;
          } 
          this.a.clear();
          this.r.h.removeCallbacks(this.L);
        } 
        if (bool) {
          this.b = true;
          try {
            a0(this.G, this.H);
            e();
          } finally {
            e();
          } 
          continue;
        } 
        k0();
        x();
        this.c.b();
        return paramBoolean;
      } 
    } 
  }
  
  public void D(m paramm, boolean paramBoolean) {
    if (paramBoolean && (this.r == null || this.E))
      return; 
    B(paramBoolean);
    ArrayList<a> arrayList = this.G;
    ArrayList<Boolean> arrayList1 = this.H;
    ((a)paramm).a(arrayList, arrayList1);
    this.b = true;
    try {
      a0(this.G, this.H);
      e();
      k0();
      x();
      return;
    } finally {
      e();
    } 
  }
  
  public final void E(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_1
    //   1: iload_3
    //   2: invokevirtual get : (I)Ljava/lang/Object;
    //   5: checkcast androidx/fragment/app/a
    //   8: getfield p : Z
    //   11: istore #11
    //   13: aload_0
    //   14: getfield I : Ljava/util/ArrayList;
    //   17: astore #12
    //   19: aload #12
    //   21: ifnonnull -> 38
    //   24: aload_0
    //   25: new java/util/ArrayList
    //   28: dup
    //   29: invokespecial <init> : ()V
    //   32: putfield I : Ljava/util/ArrayList;
    //   35: goto -> 43
    //   38: aload #12
    //   40: invokevirtual clear : ()V
    //   43: aload_0
    //   44: getfield I : Ljava/util/ArrayList;
    //   47: aload_0
    //   48: getfield c : Landroidx/fragment/app/f0;
    //   51: invokevirtual i : ()Ljava/util/List;
    //   54: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   57: pop
    //   58: aload_0
    //   59: getfield u : Landroidx/fragment/app/Fragment;
    //   62: astore #12
    //   64: iload_3
    //   65: istore #8
    //   67: iconst_0
    //   68: istore #7
    //   70: iload #8
    //   72: iload #4
    //   74: if_icmpge -> 780
    //   77: aload_1
    //   78: iload #8
    //   80: invokevirtual get : (I)Ljava/lang/Object;
    //   83: checkcast androidx/fragment/app/a
    //   86: astore #14
    //   88: aload_2
    //   89: iload #8
    //   91: invokevirtual get : (I)Ljava/lang/Object;
    //   94: checkcast java/lang/Boolean
    //   97: invokevirtual booleanValue : ()Z
    //   100: ifne -> 574
    //   103: aload_0
    //   104: getfield I : Ljava/util/ArrayList;
    //   107: astore #15
    //   109: iconst_0
    //   110: istore #5
    //   112: aload #12
    //   114: astore #13
    //   116: iload #5
    //   118: aload #14
    //   120: getfield a : Ljava/util/ArrayList;
    //   123: invokevirtual size : ()I
    //   126: if_icmpge -> 738
    //   129: aload #14
    //   131: getfield a : Ljava/util/ArrayList;
    //   134: iload #5
    //   136: invokevirtual get : (I)Ljava/lang/Object;
    //   139: checkcast androidx/fragment/app/g0$a
    //   142: astore #13
    //   144: aload #13
    //   146: getfield a : I
    //   149: istore #6
    //   151: iload #6
    //   153: iconst_1
    //   154: if_icmpeq -> 554
    //   157: iload #6
    //   159: iconst_2
    //   160: if_icmpeq -> 304
    //   163: iload #6
    //   165: iconst_3
    //   166: if_icmpeq -> 238
    //   169: iload #6
    //   171: bipush #6
    //   173: if_icmpeq -> 238
    //   176: iload #6
    //   178: bipush #7
    //   180: if_icmpeq -> 554
    //   183: iload #6
    //   185: bipush #8
    //   187: if_icmpeq -> 201
    //   190: aload #12
    //   192: astore #13
    //   194: iload #5
    //   196: istore #6
    //   198: goto -> 526
    //   201: aload #14
    //   203: getfield a : Ljava/util/ArrayList;
    //   206: iload #5
    //   208: new androidx/fragment/app/g0$a
    //   211: dup
    //   212: bipush #9
    //   214: aload #12
    //   216: invokespecial <init> : (ILandroidx/fragment/app/Fragment;)V
    //   219: invokevirtual add : (ILjava/lang/Object;)V
    //   222: iload #5
    //   224: iconst_1
    //   225: iadd
    //   226: istore #6
    //   228: aload #13
    //   230: getfield b : Landroidx/fragment/app/Fragment;
    //   233: astore #13
    //   235: goto -> 526
    //   238: aload #15
    //   240: aload #13
    //   242: getfield b : Landroidx/fragment/app/Fragment;
    //   245: invokevirtual remove : (Ljava/lang/Object;)Z
    //   248: pop
    //   249: aload #13
    //   251: getfield b : Landroidx/fragment/app/Fragment;
    //   254: astore #16
    //   256: aload #12
    //   258: astore #13
    //   260: iload #5
    //   262: istore #6
    //   264: aload #16
    //   266: aload #12
    //   268: if_acmpne -> 526
    //   271: aload #14
    //   273: getfield a : Ljava/util/ArrayList;
    //   276: iload #5
    //   278: new androidx/fragment/app/g0$a
    //   281: dup
    //   282: bipush #9
    //   284: aload #16
    //   286: invokespecial <init> : (ILandroidx/fragment/app/Fragment;)V
    //   289: invokevirtual add : (ILjava/lang/Object;)V
    //   292: iload #5
    //   294: iconst_1
    //   295: iadd
    //   296: istore #5
    //   298: aconst_null
    //   299: astore #12
    //   301: goto -> 565
    //   304: aload #13
    //   306: getfield b : Landroidx/fragment/app/Fragment;
    //   309: astore #16
    //   311: aload #16
    //   313: getfield mContainerId : I
    //   316: istore #6
    //   318: aload #15
    //   320: invokevirtual size : ()I
    //   323: iconst_1
    //   324: isub
    //   325: istore #9
    //   327: iconst_0
    //   328: istore #10
    //   330: iload #9
    //   332: iflt -> 500
    //   335: aload #15
    //   337: iload #9
    //   339: invokevirtual get : (I)Ljava/lang/Object;
    //   342: checkcast androidx/fragment/app/Fragment
    //   345: astore #17
    //   347: aload #17
    //   349: getfield mContainerId : I
    //   352: iload #6
    //   354: if_icmpne -> 491
    //   357: aload #17
    //   359: aload #16
    //   361: if_acmpne -> 370
    //   364: iconst_1
    //   365: istore #10
    //   367: goto -> 491
    //   370: aload #17
    //   372: aload #12
    //   374: if_acmpne -> 410
    //   377: aload #14
    //   379: getfield a : Ljava/util/ArrayList;
    //   382: iload #5
    //   384: new androidx/fragment/app/g0$a
    //   387: dup
    //   388: bipush #9
    //   390: aload #17
    //   392: invokespecial <init> : (ILandroidx/fragment/app/Fragment;)V
    //   395: invokevirtual add : (ILjava/lang/Object;)V
    //   398: iload #5
    //   400: iconst_1
    //   401: iadd
    //   402: istore #5
    //   404: aconst_null
    //   405: astore #12
    //   407: goto -> 410
    //   410: new androidx/fragment/app/g0$a
    //   413: dup
    //   414: iconst_3
    //   415: aload #17
    //   417: invokespecial <init> : (ILandroidx/fragment/app/Fragment;)V
    //   420: astore #18
    //   422: aload #18
    //   424: aload #13
    //   426: getfield c : I
    //   429: putfield c : I
    //   432: aload #18
    //   434: aload #13
    //   436: getfield e : I
    //   439: putfield e : I
    //   442: aload #18
    //   444: aload #13
    //   446: getfield d : I
    //   449: putfield d : I
    //   452: aload #18
    //   454: aload #13
    //   456: getfield f : I
    //   459: putfield f : I
    //   462: aload #14
    //   464: getfield a : Ljava/util/ArrayList;
    //   467: iload #5
    //   469: aload #18
    //   471: invokevirtual add : (ILjava/lang/Object;)V
    //   474: aload #15
    //   476: aload #17
    //   478: invokevirtual remove : (Ljava/lang/Object;)Z
    //   481: pop
    //   482: iload #5
    //   484: iconst_1
    //   485: iadd
    //   486: istore #5
    //   488: goto -> 491
    //   491: iload #9
    //   493: iconst_1
    //   494: isub
    //   495: istore #9
    //   497: goto -> 330
    //   500: iload #10
    //   502: ifeq -> 537
    //   505: aload #14
    //   507: getfield a : Ljava/util/ArrayList;
    //   510: iload #5
    //   512: invokevirtual remove : (I)Ljava/lang/Object;
    //   515: pop
    //   516: iload #5
    //   518: iconst_1
    //   519: isub
    //   520: istore #6
    //   522: aload #12
    //   524: astore #13
    //   526: aload #13
    //   528: astore #12
    //   530: iload #6
    //   532: istore #5
    //   534: goto -> 565
    //   537: aload #13
    //   539: iconst_1
    //   540: putfield a : I
    //   543: aload #15
    //   545: aload #16
    //   547: invokevirtual add : (Ljava/lang/Object;)Z
    //   550: pop
    //   551: goto -> 565
    //   554: aload #15
    //   556: aload #13
    //   558: getfield b : Landroidx/fragment/app/Fragment;
    //   561: invokevirtual add : (Ljava/lang/Object;)Z
    //   564: pop
    //   565: iload #5
    //   567: iconst_1
    //   568: iadd
    //   569: istore #5
    //   571: goto -> 112
    //   574: aload_0
    //   575: getfield I : Ljava/util/ArrayList;
    //   578: astore #15
    //   580: aload #14
    //   582: getfield a : Ljava/util/ArrayList;
    //   585: invokevirtual size : ()I
    //   588: iconst_1
    //   589: isub
    //   590: istore #5
    //   592: aload #12
    //   594: astore #13
    //   596: iload #5
    //   598: iflt -> 738
    //   601: aload #14
    //   603: getfield a : Ljava/util/ArrayList;
    //   606: iload #5
    //   608: invokevirtual get : (I)Ljava/lang/Object;
    //   611: checkcast androidx/fragment/app/g0$a
    //   614: astore #13
    //   616: aload #13
    //   618: getfield a : I
    //   621: istore #6
    //   623: iload #6
    //   625: iconst_1
    //   626: if_icmpeq -> 718
    //   629: iload #6
    //   631: iconst_3
    //   632: if_icmpeq -> 704
    //   635: iload #6
    //   637: tableswitch default -> 672, 6 -> 704, 7 -> 718, 8 -> 698, 9 -> 688, 10 -> 675
    //   672: goto -> 729
    //   675: aload #13
    //   677: aload #13
    //   679: getfield g : Landroidx/lifecycle/Lifecycle$State;
    //   682: putfield h : Landroidx/lifecycle/Lifecycle$State;
    //   685: goto -> 729
    //   688: aload #13
    //   690: getfield b : Landroidx/fragment/app/Fragment;
    //   693: astore #12
    //   695: goto -> 729
    //   698: aconst_null
    //   699: astore #12
    //   701: goto -> 729
    //   704: aload #15
    //   706: aload #13
    //   708: getfield b : Landroidx/fragment/app/Fragment;
    //   711: invokevirtual add : (Ljava/lang/Object;)Z
    //   714: pop
    //   715: goto -> 729
    //   718: aload #15
    //   720: aload #13
    //   722: getfield b : Landroidx/fragment/app/Fragment;
    //   725: invokevirtual remove : (Ljava/lang/Object;)Z
    //   728: pop
    //   729: iload #5
    //   731: iconst_1
    //   732: isub
    //   733: istore #5
    //   735: goto -> 592
    //   738: iload #7
    //   740: ifne -> 760
    //   743: aload #14
    //   745: getfield g : Z
    //   748: ifeq -> 754
    //   751: goto -> 760
    //   754: iconst_0
    //   755: istore #5
    //   757: goto -> 763
    //   760: iconst_1
    //   761: istore #5
    //   763: iload #8
    //   765: iconst_1
    //   766: iadd
    //   767: istore #8
    //   769: aload #13
    //   771: astore #12
    //   773: iload #5
    //   775: istore #7
    //   777: goto -> 70
    //   780: aload_0
    //   781: getfield I : Ljava/util/ArrayList;
    //   784: invokevirtual clear : ()V
    //   787: iload #11
    //   789: ifne -> 894
    //   792: aload_0
    //   793: getfield q : I
    //   796: iconst_1
    //   797: if_icmplt -> 894
    //   800: iload_3
    //   801: istore #5
    //   803: iload #5
    //   805: iload #4
    //   807: if_icmpge -> 894
    //   810: aload_1
    //   811: iload #5
    //   813: invokevirtual get : (I)Ljava/lang/Object;
    //   816: checkcast androidx/fragment/app/a
    //   819: getfield a : Ljava/util/ArrayList;
    //   822: invokevirtual iterator : ()Ljava/util/Iterator;
    //   825: astore #12
    //   827: aload #12
    //   829: invokeinterface hasNext : ()Z
    //   834: ifeq -> 885
    //   837: aload #12
    //   839: invokeinterface next : ()Ljava/lang/Object;
    //   844: checkcast androidx/fragment/app/g0$a
    //   847: getfield b : Landroidx/fragment/app/Fragment;
    //   850: astore #13
    //   852: aload #13
    //   854: ifnull -> 827
    //   857: aload #13
    //   859: getfield mFragmentManager : Landroidx/fragment/app/FragmentManager;
    //   862: ifnull -> 827
    //   865: aload_0
    //   866: aload #13
    //   868: invokevirtual h : (Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/e0;
    //   871: astore #13
    //   873: aload_0
    //   874: getfield c : Landroidx/fragment/app/f0;
    //   877: aload #13
    //   879: invokevirtual o : (Landroidx/fragment/app/e0;)V
    //   882: goto -> 827
    //   885: iload #5
    //   887: iconst_1
    //   888: iadd
    //   889: istore #5
    //   891: goto -> 803
    //   894: iload_3
    //   895: istore #5
    //   897: iload #5
    //   899: iload #4
    //   901: if_icmpge -> 984
    //   904: aload_1
    //   905: iload #5
    //   907: invokevirtual get : (I)Ljava/lang/Object;
    //   910: checkcast androidx/fragment/app/a
    //   913: astore #12
    //   915: aload_2
    //   916: iload #5
    //   918: invokevirtual get : (I)Ljava/lang/Object;
    //   921: checkcast java/lang/Boolean
    //   924: invokevirtual booleanValue : ()Z
    //   927: ifeq -> 964
    //   930: aload #12
    //   932: iconst_m1
    //   933: invokevirtual e : (I)V
    //   936: iload #5
    //   938: iload #4
    //   940: iconst_1
    //   941: isub
    //   942: if_icmpne -> 951
    //   945: iconst_1
    //   946: istore #11
    //   948: goto -> 954
    //   951: iconst_0
    //   952: istore #11
    //   954: aload #12
    //   956: iload #11
    //   958: invokevirtual k : (Z)V
    //   961: goto -> 975
    //   964: aload #12
    //   966: iconst_1
    //   967: invokevirtual e : (I)V
    //   970: aload #12
    //   972: invokevirtual j : ()V
    //   975: iload #5
    //   977: iconst_1
    //   978: iadd
    //   979: istore #5
    //   981: goto -> 897
    //   984: aload_2
    //   985: iload #4
    //   987: iconst_1
    //   988: isub
    //   989: invokevirtual get : (I)Ljava/lang/Object;
    //   992: checkcast java/lang/Boolean
    //   995: invokevirtual booleanValue : ()Z
    //   998: istore #11
    //   1000: iload_3
    //   1001: istore #5
    //   1003: iload #5
    //   1005: iload #4
    //   1007: if_icmpge -> 1145
    //   1010: aload_1
    //   1011: iload #5
    //   1013: invokevirtual get : (I)Ljava/lang/Object;
    //   1016: checkcast androidx/fragment/app/a
    //   1019: astore #12
    //   1021: iload #11
    //   1023: ifeq -> 1084
    //   1026: aload #12
    //   1028: getfield a : Ljava/util/ArrayList;
    //   1031: invokevirtual size : ()I
    //   1034: iconst_1
    //   1035: isub
    //   1036: istore #6
    //   1038: iload #6
    //   1040: iflt -> 1136
    //   1043: aload #12
    //   1045: getfield a : Ljava/util/ArrayList;
    //   1048: iload #6
    //   1050: invokevirtual get : (I)Ljava/lang/Object;
    //   1053: checkcast androidx/fragment/app/g0$a
    //   1056: getfield b : Landroidx/fragment/app/Fragment;
    //   1059: astore #13
    //   1061: aload #13
    //   1063: ifnull -> 1075
    //   1066: aload_0
    //   1067: aload #13
    //   1069: invokevirtual h : (Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/e0;
    //   1072: invokevirtual k : ()V
    //   1075: iload #6
    //   1077: iconst_1
    //   1078: isub
    //   1079: istore #6
    //   1081: goto -> 1038
    //   1084: aload #12
    //   1086: getfield a : Ljava/util/ArrayList;
    //   1089: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1092: astore #12
    //   1094: aload #12
    //   1096: invokeinterface hasNext : ()Z
    //   1101: ifeq -> 1136
    //   1104: aload #12
    //   1106: invokeinterface next : ()Ljava/lang/Object;
    //   1111: checkcast androidx/fragment/app/g0$a
    //   1114: getfield b : Landroidx/fragment/app/Fragment;
    //   1117: astore #13
    //   1119: aload #13
    //   1121: ifnull -> 1094
    //   1124: aload_0
    //   1125: aload #13
    //   1127: invokevirtual h : (Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/e0;
    //   1130: invokevirtual k : ()V
    //   1133: goto -> 1094
    //   1136: iload #5
    //   1138: iconst_1
    //   1139: iadd
    //   1140: istore #5
    //   1142: goto -> 1003
    //   1145: aload_0
    //   1146: aload_0
    //   1147: getfield q : I
    //   1150: iconst_1
    //   1151: invokevirtual T : (IZ)V
    //   1154: new java/util/HashSet
    //   1157: dup
    //   1158: invokespecial <init> : ()V
    //   1161: astore #12
    //   1163: iload_3
    //   1164: istore #5
    //   1166: iload #5
    //   1168: iload #4
    //   1170: if_icmpge -> 1259
    //   1173: aload_1
    //   1174: iload #5
    //   1176: invokevirtual get : (I)Ljava/lang/Object;
    //   1179: checkcast androidx/fragment/app/a
    //   1182: getfield a : Ljava/util/ArrayList;
    //   1185: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1188: astore #13
    //   1190: aload #13
    //   1192: invokeinterface hasNext : ()Z
    //   1197: ifeq -> 1250
    //   1200: aload #13
    //   1202: invokeinterface next : ()Ljava/lang/Object;
    //   1207: checkcast androidx/fragment/app/g0$a
    //   1210: getfield b : Landroidx/fragment/app/Fragment;
    //   1213: astore #14
    //   1215: aload #14
    //   1217: ifnull -> 1190
    //   1220: aload #14
    //   1222: getfield mContainer : Landroid/view/ViewGroup;
    //   1225: astore #14
    //   1227: aload #14
    //   1229: ifnull -> 1190
    //   1232: aload #12
    //   1234: aload #14
    //   1236: aload_0
    //   1237: invokevirtual M : ()Landroidx/fragment/app/u0;
    //   1240: invokestatic g : (Landroid/view/ViewGroup;Landroidx/fragment/app/u0;)Landroidx/fragment/app/SpecialEffectsController;
    //   1243: invokevirtual add : (Ljava/lang/Object;)Z
    //   1246: pop
    //   1247: goto -> 1190
    //   1250: iload #5
    //   1252: iconst_1
    //   1253: iadd
    //   1254: istore #5
    //   1256: goto -> 1166
    //   1259: aload #12
    //   1261: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1264: astore #12
    //   1266: aload #12
    //   1268: invokeinterface hasNext : ()Z
    //   1273: ifeq -> 1308
    //   1276: aload #12
    //   1278: invokeinterface next : ()Ljava/lang/Object;
    //   1283: checkcast androidx/fragment/app/SpecialEffectsController
    //   1286: astore #13
    //   1288: aload #13
    //   1290: iload #11
    //   1292: putfield d : Z
    //   1295: aload #13
    //   1297: invokevirtual h : ()V
    //   1300: aload #13
    //   1302: invokevirtual c : ()V
    //   1305: goto -> 1266
    //   1308: iload_3
    //   1309: iload #4
    //   1311: if_icmpge -> 1368
    //   1314: aload_1
    //   1315: iload_3
    //   1316: invokevirtual get : (I)Ljava/lang/Object;
    //   1319: checkcast androidx/fragment/app/a
    //   1322: astore #12
    //   1324: aload_2
    //   1325: iload_3
    //   1326: invokevirtual get : (I)Ljava/lang/Object;
    //   1329: checkcast java/lang/Boolean
    //   1332: invokevirtual booleanValue : ()Z
    //   1335: ifeq -> 1355
    //   1338: aload #12
    //   1340: getfield s : I
    //   1343: iflt -> 1355
    //   1346: aload #12
    //   1348: iconst_m1
    //   1349: putfield s : I
    //   1352: goto -> 1355
    //   1355: aload #12
    //   1357: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1360: pop
    //   1361: iload_3
    //   1362: iconst_1
    //   1363: iadd
    //   1364: istore_3
    //   1365: goto -> 1308
    //   1368: iload #7
    //   1370: ifeq -> 1416
    //   1373: aload_0
    //   1374: getfield l : Ljava/util/ArrayList;
    //   1377: ifnull -> 1416
    //   1380: iconst_0
    //   1381: istore_3
    //   1382: iload_3
    //   1383: aload_0
    //   1384: getfield l : Ljava/util/ArrayList;
    //   1387: invokevirtual size : ()I
    //   1390: if_icmpge -> 1416
    //   1393: aload_0
    //   1394: getfield l : Ljava/util/ArrayList;
    //   1397: iload_3
    //   1398: invokevirtual get : (I)Ljava/lang/Object;
    //   1401: checkcast androidx/fragment/app/FragmentManager$l
    //   1404: invokeinterface onBackStackChanged : ()V
    //   1409: iload_3
    //   1410: iconst_1
    //   1411: iadd
    //   1412: istore_3
    //   1413: goto -> 1382
    //   1416: return
  }
  
  public final void F(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield J : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 17
    //   11: iconst_0
    //   12: istore #4
    //   14: goto -> 24
    //   17: aload #7
    //   19: invokevirtual size : ()I
    //   22: istore #4
    //   24: iconst_0
    //   25: istore_3
    //   26: iload #4
    //   28: istore #6
    //   30: iload_3
    //   31: iload #6
    //   33: if_icmpge -> 310
    //   36: aload_0
    //   37: getfield J : Ljava/util/ArrayList;
    //   40: iload_3
    //   41: invokevirtual get : (I)Ljava/lang/Object;
    //   44: checkcast androidx/fragment/app/FragmentManager$o
    //   47: astore #7
    //   49: aload_1
    //   50: ifnull -> 144
    //   53: aload #7
    //   55: getfield a : Z
    //   58: ifne -> 144
    //   61: aload_1
    //   62: aload #7
    //   64: getfield b : Landroidx/fragment/app/a;
    //   67: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   70: istore #4
    //   72: iload #4
    //   74: iconst_m1
    //   75: if_icmpeq -> 144
    //   78: aload_2
    //   79: ifnull -> 144
    //   82: aload_2
    //   83: iload #4
    //   85: invokevirtual get : (I)Ljava/lang/Object;
    //   88: checkcast java/lang/Boolean
    //   91: invokevirtual booleanValue : ()Z
    //   94: ifeq -> 144
    //   97: aload_0
    //   98: getfield J : Ljava/util/ArrayList;
    //   101: iload_3
    //   102: invokevirtual remove : (I)Ljava/lang/Object;
    //   105: pop
    //   106: iload_3
    //   107: iconst_1
    //   108: isub
    //   109: istore #5
    //   111: iload #6
    //   113: iconst_1
    //   114: isub
    //   115: istore #4
    //   117: aload #7
    //   119: getfield b : Landroidx/fragment/app/a;
    //   122: astore #8
    //   124: aload #8
    //   126: getfield q : Landroidx/fragment/app/FragmentManager;
    //   129: aload #8
    //   131: aload #7
    //   133: getfield a : Z
    //   136: iconst_0
    //   137: iconst_0
    //   138: invokevirtual g : (Landroidx/fragment/app/a;ZZZ)V
    //   141: goto -> 298
    //   144: aload #7
    //   146: getfield c : I
    //   149: ifne -> 158
    //   152: iconst_1
    //   153: istore #4
    //   155: goto -> 161
    //   158: iconst_0
    //   159: istore #4
    //   161: iload #4
    //   163: ifne -> 201
    //   166: iload #6
    //   168: istore #4
    //   170: iload_3
    //   171: istore #5
    //   173: aload_1
    //   174: ifnull -> 298
    //   177: iload #6
    //   179: istore #4
    //   181: iload_3
    //   182: istore #5
    //   184: aload #7
    //   186: getfield b : Landroidx/fragment/app/a;
    //   189: aload_1
    //   190: iconst_0
    //   191: aload_1
    //   192: invokevirtual size : ()I
    //   195: invokevirtual m : (Ljava/util/ArrayList;II)Z
    //   198: ifeq -> 298
    //   201: aload_0
    //   202: getfield J : Ljava/util/ArrayList;
    //   205: iload_3
    //   206: invokevirtual remove : (I)Ljava/lang/Object;
    //   209: pop
    //   210: iload_3
    //   211: iconst_1
    //   212: isub
    //   213: istore #5
    //   215: iload #6
    //   217: iconst_1
    //   218: isub
    //   219: istore #4
    //   221: aload_1
    //   222: ifnull -> 293
    //   225: aload #7
    //   227: getfield a : Z
    //   230: ifne -> 293
    //   233: aload_1
    //   234: aload #7
    //   236: getfield b : Landroidx/fragment/app/a;
    //   239: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   242: istore_3
    //   243: iload_3
    //   244: iconst_m1
    //   245: if_icmpeq -> 293
    //   248: aload_2
    //   249: ifnull -> 293
    //   252: aload_2
    //   253: iload_3
    //   254: invokevirtual get : (I)Ljava/lang/Object;
    //   257: checkcast java/lang/Boolean
    //   260: invokevirtual booleanValue : ()Z
    //   263: ifeq -> 293
    //   266: aload #7
    //   268: getfield b : Landroidx/fragment/app/a;
    //   271: astore #8
    //   273: aload #8
    //   275: getfield q : Landroidx/fragment/app/FragmentManager;
    //   278: aload #8
    //   280: aload #7
    //   282: getfield a : Z
    //   285: iconst_0
    //   286: iconst_0
    //   287: invokevirtual g : (Landroidx/fragment/app/a;ZZZ)V
    //   290: goto -> 298
    //   293: aload #7
    //   295: invokevirtual a : ()V
    //   298: iload #5
    //   300: iconst_1
    //   301: iadd
    //   302: istore_3
    //   303: iload #4
    //   305: istore #6
    //   307: goto -> 30
    //   310: return
  }
  
  public Fragment G(String paramString) {
    return this.c.d(paramString);
  }
  
  public Fragment H(int paramInt) {
    f0 f01 = this.c;
    int i = f01.g.size();
    while (true) {
      int j = i - 1;
      if (j >= 0) {
        Fragment fragment = f01.g.get(j);
        i = j;
        if (fragment != null) {
          i = j;
          if (fragment.mFragmentId == paramInt)
            return fragment; 
        } 
        continue;
      } 
      for (e0 e0 : f01.h.values()) {
        if (e0 != null) {
          Fragment fragment = e0.c;
          if (fragment.mFragmentId == paramInt)
            return fragment; 
        } 
      } 
      return null;
    } 
  }
  
  public Fragment I(String paramString) {
    f0 f01 = this.c;
    Objects.requireNonNull(f01);
    int i = f01.g.size();
    while (true) {
      int j = i - 1;
      if (j >= 0) {
        Fragment fragment = f01.g.get(j);
        i = j;
        if (fragment != null) {
          i = j;
          if (paramString.equals(fragment.mTag))
            return fragment; 
        } 
        continue;
      } 
      for (e0 e0 : f01.h.values()) {
        if (e0 != null) {
          Fragment fragment = e0.c;
          if (paramString.equals(fragment.mTag))
            return fragment; 
        } 
      } 
      return null;
    } 
  }
  
  public int J() {
    ArrayList<a> arrayList = this.d;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  public final ViewGroup K(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    if (viewGroup != null)
      return viewGroup; 
    if (paramFragment.mContainerId <= 0)
      return null; 
    if (this.s.c()) {
      View view = this.s.b(paramFragment.mContainerId);
      if (view instanceof ViewGroup)
        return (ViewGroup)view; 
    } 
    return null;
  }
  
  public v L() {
    Fragment fragment = this.t;
    return (fragment != null) ? fragment.mFragmentManager.L() : this.v;
  }
  
  public u0 M() {
    Fragment fragment = this.t;
    return (fragment != null) ? fragment.mFragmentManager.M() : this.w;
  }
  
  public void N(Fragment paramFragment) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
      h0(paramFragment);
    } 
  }
  
  public final boolean P(Fragment paramFragment) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mHasMenu : Z
    //   4: istore #4
    //   6: iconst_1
    //   7: istore_3
    //   8: iload #4
    //   10: ifeq -> 20
    //   13: aload_1
    //   14: getfield mMenuVisible : Z
    //   17: ifne -> 103
    //   20: aload_1
    //   21: getfield mChildFragmentManager : Landroidx/fragment/app/FragmentManager;
    //   24: astore_1
    //   25: aload_1
    //   26: getfield c : Landroidx/fragment/app/f0;
    //   29: invokevirtual g : ()Ljava/util/List;
    //   32: checkcast java/util/ArrayList
    //   35: invokevirtual iterator : ()Ljava/util/Iterator;
    //   38: astore #5
    //   40: iconst_0
    //   41: istore_3
    //   42: aload #5
    //   44: invokeinterface hasNext : ()Z
    //   49: ifeq -> 93
    //   52: aload #5
    //   54: invokeinterface next : ()Ljava/lang/Object;
    //   59: checkcast androidx/fragment/app/Fragment
    //   62: astore #6
    //   64: iload_3
    //   65: istore #4
    //   67: aload #6
    //   69: ifnull -> 80
    //   72: aload_1
    //   73: aload #6
    //   75: invokevirtual P : (Landroidx/fragment/app/Fragment;)Z
    //   78: istore #4
    //   80: iload #4
    //   82: istore_3
    //   83: iload #4
    //   85: ifeq -> 42
    //   88: iconst_1
    //   89: istore_2
    //   90: goto -> 95
    //   93: iconst_0
    //   94: istore_2
    //   95: iload_2
    //   96: ifeq -> 101
    //   99: iconst_1
    //   100: ireturn
    //   101: iconst_0
    //   102: istore_3
    //   103: iload_3
    //   104: ireturn
  }
  
  public boolean Q(Fragment paramFragment) {
    return (paramFragment == null) ? true : paramFragment.isMenuVisible();
  }
  
  public boolean R(Fragment paramFragment) {
    if (paramFragment == null)
      return true; 
    FragmentManager fragmentManager = paramFragment.mFragmentManager;
    return (paramFragment.equals(fragmentManager.u) && R(fragmentManager.t));
  }
  
  public boolean S() {
    return (this.C || this.D);
  }
  
  public void T(int paramInt, boolean paramBoolean) {
    if (this.r != null || paramInt == -1) {
      if (!paramBoolean && paramInt == this.q)
        return; 
      this.q = paramInt;
      f0 f01 = this.c;
      for (Fragment fragment : f01.g) {
        e0 e0 = f01.h.get(fragment.mWho);
        if (e0 != null)
          e0.k(); 
      } 
      Iterator<e0> iterator = f01.h.values().iterator();
      while (true) {
        paramBoolean = iterator.hasNext();
        boolean bool = false;
        if (paramBoolean) {
          e0 e0 = iterator.next();
          if (e0 != null) {
            e0.k();
            Fragment fragment = e0.c;
            paramInt = bool;
            if (fragment.mRemoving) {
              paramInt = bool;
              if (!fragment.isInBackStack())
                paramInt = 1; 
            } 
            if (paramInt != 0)
              f01.p(e0); 
          } 
          continue;
        } 
        j0();
        if (this.B) {
          w<?> w1 = this.r;
          if (w1 != null && this.q == 7) {
            w1.h();
            this.B = false;
          } 
        } 
        return;
      } 
    } 
    throw new IllegalStateException("No activity");
  }
  
  public void U(Fragment paramFragment, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroidx/fragment/app/f0;
    //   4: aload_1
    //   5: getfield mWho : Ljava/lang/String;
    //   8: invokevirtual h : (Ljava/lang/String;)Landroidx/fragment/app/e0;
    //   11: astore #6
    //   13: aload #6
    //   15: astore #5
    //   17: aload #6
    //   19: ifnonnull -> 46
    //   22: new androidx/fragment/app/e0
    //   25: dup
    //   26: aload_0
    //   27: getfield o : Landroidx/fragment/app/y;
    //   30: aload_0
    //   31: getfield c : Landroidx/fragment/app/f0;
    //   34: aload_1
    //   35: invokespecial <init> : (Landroidx/fragment/app/y;Landroidx/fragment/app/f0;Landroidx/fragment/app/Fragment;)V
    //   38: astore #5
    //   40: aload #5
    //   42: iconst_1
    //   43: putfield e : I
    //   46: aload_1
    //   47: getfield mFromLayout : Z
    //   50: ifeq -> 77
    //   53: aload_1
    //   54: getfield mInLayout : Z
    //   57: ifeq -> 77
    //   60: aload_1
    //   61: getfield mState : I
    //   64: iconst_2
    //   65: if_icmpne -> 77
    //   68: iload_2
    //   69: iconst_2
    //   70: invokestatic max : (II)I
    //   73: istore_2
    //   74: goto -> 77
    //   77: iload_2
    //   78: aload #5
    //   80: invokevirtual d : ()I
    //   83: invokestatic min : (II)I
    //   86: istore_2
    //   87: aload_1
    //   88: getfield mState : I
    //   91: istore #4
    //   93: iload #4
    //   95: iload_2
    //   96: if_icmpgt -> 237
    //   99: iload #4
    //   101: iload_2
    //   102: if_icmpge -> 122
    //   105: aload_0
    //   106: getfield m : Ljava/util/Map;
    //   109: invokeinterface isEmpty : ()Z
    //   114: ifne -> 122
    //   117: aload_0
    //   118: aload_1
    //   119: invokevirtual d : (Landroidx/fragment/app/Fragment;)V
    //   122: aload_1
    //   123: getfield mState : I
    //   126: istore_3
    //   127: iload_3
    //   128: iconst_m1
    //   129: if_icmpeq -> 161
    //   132: iload_3
    //   133: ifeq -> 171
    //   136: iload_3
    //   137: iconst_1
    //   138: if_icmpeq -> 180
    //   141: iload_3
    //   142: iconst_2
    //   143: if_icmpeq -> 200
    //   146: iload_3
    //   147: iconst_4
    //   148: if_icmpeq -> 210
    //   151: iload_3
    //   152: iconst_5
    //   153: if_icmpeq -> 220
    //   156: iload_2
    //   157: istore_3
    //   158: goto -> 840
    //   161: iload_2
    //   162: iconst_m1
    //   163: if_icmple -> 171
    //   166: aload #5
    //   168: invokevirtual c : ()V
    //   171: iload_2
    //   172: ifle -> 180
    //   175: aload #5
    //   177: invokevirtual e : ()V
    //   180: iload_2
    //   181: iconst_m1
    //   182: if_icmple -> 190
    //   185: aload #5
    //   187: invokevirtual j : ()V
    //   190: iload_2
    //   191: iconst_1
    //   192: if_icmple -> 200
    //   195: aload #5
    //   197: invokevirtual f : ()V
    //   200: iload_2
    //   201: iconst_2
    //   202: if_icmple -> 210
    //   205: aload #5
    //   207: invokevirtual a : ()V
    //   210: iload_2
    //   211: iconst_4
    //   212: if_icmple -> 220
    //   215: aload #5
    //   217: invokevirtual p : ()V
    //   220: iload_2
    //   221: istore_3
    //   222: iload_2
    //   223: iconst_5
    //   224: if_icmple -> 840
    //   227: aload #5
    //   229: invokevirtual n : ()V
    //   232: iload_2
    //   233: istore_3
    //   234: goto -> 840
    //   237: iload_2
    //   238: istore_3
    //   239: iload #4
    //   241: iload_2
    //   242: if_icmple -> 840
    //   245: iload #4
    //   247: ifeq -> 829
    //   250: iload #4
    //   252: iconst_1
    //   253: if_icmpeq -> 801
    //   256: iload #4
    //   258: iconst_2
    //   259: if_icmpeq -> 385
    //   262: iload #4
    //   264: iconst_4
    //   265: if_icmpeq -> 307
    //   268: iload #4
    //   270: iconst_5
    //   271: if_icmpeq -> 297
    //   274: iload #4
    //   276: bipush #7
    //   278: if_icmpeq -> 286
    //   281: iload_2
    //   282: istore_3
    //   283: goto -> 840
    //   286: iload_2
    //   287: bipush #7
    //   289: if_icmpge -> 297
    //   292: aload #5
    //   294: invokevirtual l : ()V
    //   297: iload_2
    //   298: iconst_5
    //   299: if_icmpge -> 307
    //   302: aload #5
    //   304: invokevirtual q : ()V
    //   307: iload_2
    //   308: iconst_4
    //   309: if_icmpge -> 385
    //   312: iconst_3
    //   313: invokestatic O : (I)Z
    //   316: ifeq -> 355
    //   319: new java/lang/StringBuilder
    //   322: dup
    //   323: invokespecial <init> : ()V
    //   326: astore #6
    //   328: aload #6
    //   330: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   333: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   336: pop
    //   337: aload #6
    //   339: aload_1
    //   340: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   343: pop
    //   344: ldc 'FragmentManager'
    //   346: aload #6
    //   348: invokevirtual toString : ()Ljava/lang/String;
    //   351: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   354: pop
    //   355: aload_1
    //   356: getfield mView : Landroid/view/View;
    //   359: ifnull -> 385
    //   362: aload_0
    //   363: getfield r : Landroidx/fragment/app/w;
    //   366: aload_1
    //   367: invokevirtual f : (Landroidx/fragment/app/Fragment;)Z
    //   370: ifeq -> 385
    //   373: aload_1
    //   374: getfield mSavedViewState : Landroid/util/SparseArray;
    //   377: ifnonnull -> 385
    //   380: aload #5
    //   382: invokevirtual o : ()V
    //   385: iload_2
    //   386: iconst_2
    //   387: if_icmpge -> 801
    //   390: aconst_null
    //   391: astore #7
    //   393: aload_1
    //   394: getfield mView : Landroid/view/View;
    //   397: astore #6
    //   399: aload #6
    //   401: ifnull -> 783
    //   404: aload_1
    //   405: getfield mContainer : Landroid/view/ViewGroup;
    //   408: astore #8
    //   410: aload #8
    //   412: ifnull -> 783
    //   415: aload #8
    //   417: aload #6
    //   419: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   422: aload_1
    //   423: getfield mView : Landroid/view/View;
    //   426: invokevirtual clearAnimation : ()V
    //   429: aload_1
    //   430: invokevirtual isRemovingParent : ()Z
    //   433: ifne -> 783
    //   436: aload #7
    //   438: astore #6
    //   440: aload_0
    //   441: getfield q : I
    //   444: iconst_m1
    //   445: if_icmple -> 504
    //   448: aload #7
    //   450: astore #6
    //   452: aload_0
    //   453: getfield E : Z
    //   456: ifne -> 504
    //   459: aload #7
    //   461: astore #6
    //   463: aload_1
    //   464: getfield mView : Landroid/view/View;
    //   467: invokevirtual getVisibility : ()I
    //   470: ifne -> 504
    //   473: aload #7
    //   475: astore #6
    //   477: aload_1
    //   478: getfield mPostponedAlpha : F
    //   481: fconst_0
    //   482: fcmpl
    //   483: iflt -> 504
    //   486: aload_0
    //   487: getfield r : Landroidx/fragment/app/w;
    //   490: getfield g : Landroid/content/Context;
    //   493: aload_1
    //   494: iconst_0
    //   495: aload_1
    //   496: invokevirtual getPopDirection : ()Z
    //   499: invokestatic a : (Landroid/content/Context;Landroidx/fragment/app/Fragment;ZZ)Landroidx/fragment/app/r$a;
    //   502: astore #6
    //   504: aload_1
    //   505: fconst_0
    //   506: putfield mPostponedAlpha : F
    //   509: aload_1
    //   510: getfield mContainer : Landroid/view/ViewGroup;
    //   513: astore #7
    //   515: aload_1
    //   516: getfield mView : Landroid/view/View;
    //   519: astore #8
    //   521: aload #6
    //   523: ifnull -> 689
    //   526: aload_0
    //   527: getfield n : Landroidx/fragment/app/n0$a;
    //   530: astore #10
    //   532: aload #7
    //   534: aload #8
    //   536: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   539: new i0/b
    //   542: dup
    //   543: invokespecial <init> : ()V
    //   546: astore #9
    //   548: aload #9
    //   550: new androidx/fragment/app/o
    //   553: dup
    //   554: aload_1
    //   555: invokespecial <init> : (Landroidx/fragment/app/Fragment;)V
    //   558: invokevirtual b : (Li0/b$a;)V
    //   561: aload #10
    //   563: checkcast androidx/fragment/app/FragmentManager$d
    //   566: astore #10
    //   568: aload #10
    //   570: aload_1
    //   571: aload #9
    //   573: invokevirtual b : (Landroidx/fragment/app/Fragment;Li0/b;)V
    //   576: aload #6
    //   578: getfield a : Landroid/view/animation/Animation;
    //   581: ifnull -> 641
    //   584: new androidx/fragment/app/r$b
    //   587: dup
    //   588: aload #6
    //   590: getfield a : Landroid/view/animation/Animation;
    //   593: aload #7
    //   595: aload #8
    //   597: invokespecial <init> : (Landroid/view/animation/Animation;Landroid/view/ViewGroup;Landroid/view/View;)V
    //   600: astore #6
    //   602: aload_1
    //   603: aload_1
    //   604: getfield mView : Landroid/view/View;
    //   607: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   610: aload #6
    //   612: new androidx/fragment/app/p
    //   615: dup
    //   616: aload #7
    //   618: aload_1
    //   619: aload #10
    //   621: aload #9
    //   623: invokespecial <init> : (Landroid/view/ViewGroup;Landroidx/fragment/app/Fragment;Landroidx/fragment/app/n0$a;Li0/b;)V
    //   626: invokevirtual setAnimationListener : (Landroid/view/animation/Animation$AnimationListener;)V
    //   629: aload_1
    //   630: getfield mView : Landroid/view/View;
    //   633: aload #6
    //   635: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   638: goto -> 689
    //   641: aload #6
    //   643: getfield b : Landroid/animation/Animator;
    //   646: astore #6
    //   648: aload_1
    //   649: aload #6
    //   651: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   654: aload #6
    //   656: new androidx/fragment/app/q
    //   659: dup
    //   660: aload #7
    //   662: aload #8
    //   664: aload_1
    //   665: aload #10
    //   667: aload #9
    //   669: invokespecial <init> : (Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/Fragment;Landroidx/fragment/app/n0$a;Li0/b;)V
    //   672: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   675: aload #6
    //   677: aload_1
    //   678: getfield mView : Landroid/view/View;
    //   681: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   684: aload #6
    //   686: invokevirtual start : ()V
    //   689: aload #7
    //   691: aload #8
    //   693: invokevirtual removeView : (Landroid/view/View;)V
    //   696: iconst_2
    //   697: invokestatic O : (I)Z
    //   700: ifeq -> 773
    //   703: new java/lang/StringBuilder
    //   706: dup
    //   707: invokespecial <init> : ()V
    //   710: astore #6
    //   712: aload #6
    //   714: ldc_w 'Removing view '
    //   717: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   720: pop
    //   721: aload #6
    //   723: aload #8
    //   725: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   728: pop
    //   729: aload #6
    //   731: ldc_w ' for fragment '
    //   734: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   737: pop
    //   738: aload #6
    //   740: aload_1
    //   741: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   744: pop
    //   745: aload #6
    //   747: ldc_w ' from container '
    //   750: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   753: pop
    //   754: aload #6
    //   756: aload #7
    //   758: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   761: pop
    //   762: ldc 'FragmentManager'
    //   764: aload #6
    //   766: invokevirtual toString : ()Ljava/lang/String;
    //   769: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   772: pop
    //   773: aload #7
    //   775: aload_1
    //   776: getfield mContainer : Landroid/view/ViewGroup;
    //   779: if_acmpeq -> 783
    //   782: return
    //   783: aload_0
    //   784: getfield m : Ljava/util/Map;
    //   787: aload_1
    //   788: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   793: ifnonnull -> 801
    //   796: aload #5
    //   798: invokevirtual h : ()V
    //   801: iload_2
    //   802: iconst_1
    //   803: if_icmpge -> 829
    //   806: aload_0
    //   807: getfield m : Ljava/util/Map;
    //   810: aload_1
    //   811: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   816: ifnull -> 824
    //   819: iconst_1
    //   820: istore_2
    //   821: goto -> 829
    //   824: aload #5
    //   826: invokevirtual g : ()V
    //   829: iload_2
    //   830: ifge -> 838
    //   833: aload #5
    //   835: invokevirtual i : ()V
    //   838: iload_2
    //   839: istore_3
    //   840: aload_1
    //   841: getfield mState : I
    //   844: iload_3
    //   845: if_icmpeq -> 931
    //   848: iconst_3
    //   849: invokestatic O : (I)Z
    //   852: ifeq -> 926
    //   855: new java/lang/StringBuilder
    //   858: dup
    //   859: invokespecial <init> : ()V
    //   862: astore #5
    //   864: aload #5
    //   866: ldc_w 'moveToState: Fragment state for '
    //   869: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   872: pop
    //   873: aload #5
    //   875: aload_1
    //   876: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   879: pop
    //   880: aload #5
    //   882: ldc_w ' not updated inline; expected state '
    //   885: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   888: pop
    //   889: aload #5
    //   891: iload_3
    //   892: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   895: pop
    //   896: aload #5
    //   898: ldc_w ' found '
    //   901: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   904: pop
    //   905: aload #5
    //   907: aload_1
    //   908: getfield mState : I
    //   911: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   914: pop
    //   915: ldc 'FragmentManager'
    //   917: aload #5
    //   919: invokevirtual toString : ()Ljava/lang/String;
    //   922: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   925: pop
    //   926: aload_1
    //   927: iload_3
    //   928: putfield mState : I
    //   931: return
  }
  
  public void V() {
    if (this.r == null)
      return; 
    this.C = false;
    this.D = false;
    this.K.h = false;
    for (Fragment fragment : this.c.i()) {
      if (fragment != null)
        fragment.noteStateNotSaved(); 
    } 
  }
  
  public void W(e0 parame0) {
    Fragment fragment = parame0.c;
    if (fragment.mDeferStart) {
      if (this.b) {
        this.F = true;
        return;
      } 
      fragment.mDeferStart = false;
      parame0.k();
    } 
  }
  
  public boolean X() {
    C(false);
    B(true);
    Fragment fragment = this.u;
    if (fragment != null && fragment.getChildFragmentManager().X())
      return true; 
    boolean bool = Y(this.G, this.H, null, -1, 0);
    if (bool) {
      this.b = true;
      try {
        a0(this.G, this.H);
      } finally {
        e();
      } 
    } 
    k0();
    x();
    this.c.b();
    return bool;
  }
  
  public boolean Y(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 69
    //   17: iload #4
    //   19: ifge -> 69
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 69
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield d : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   63: invokevirtual add : (Ljava/lang/Object;)Z
    //   66: pop
    //   67: iconst_1
    //   68: ireturn
    //   69: iconst_m1
    //   70: istore #6
    //   72: aload_3
    //   73: ifnonnull -> 81
    //   76: iload #4
    //   78: iflt -> 256
    //   81: aload #8
    //   83: invokevirtual size : ()I
    //   86: iconst_1
    //   87: isub
    //   88: istore #6
    //   90: iload #6
    //   92: iflt -> 155
    //   95: aload_0
    //   96: getfield d : Ljava/util/ArrayList;
    //   99: iload #6
    //   101: invokevirtual get : (I)Ljava/lang/Object;
    //   104: checkcast androidx/fragment/app/a
    //   107: astore #8
    //   109: aload_3
    //   110: ifnull -> 128
    //   113: aload_3
    //   114: aload #8
    //   116: getfield i : Ljava/lang/String;
    //   119: invokevirtual equals : (Ljava/lang/Object;)Z
    //   122: ifeq -> 128
    //   125: goto -> 155
    //   128: iload #4
    //   130: iflt -> 146
    //   133: iload #4
    //   135: aload #8
    //   137: getfield s : I
    //   140: if_icmpne -> 146
    //   143: goto -> 155
    //   146: iload #6
    //   148: iconst_1
    //   149: isub
    //   150: istore #6
    //   152: goto -> 90
    //   155: iload #6
    //   157: ifge -> 162
    //   160: iconst_0
    //   161: ireturn
    //   162: iload #6
    //   164: istore #7
    //   166: iload #5
    //   168: iconst_1
    //   169: iand
    //   170: ifeq -> 252
    //   173: iload #6
    //   175: iconst_1
    //   176: isub
    //   177: istore #5
    //   179: iload #5
    //   181: istore #7
    //   183: iload #5
    //   185: iflt -> 252
    //   188: aload_0
    //   189: getfield d : Ljava/util/ArrayList;
    //   192: iload #5
    //   194: invokevirtual get : (I)Ljava/lang/Object;
    //   197: checkcast androidx/fragment/app/a
    //   200: astore #8
    //   202: aload_3
    //   203: ifnull -> 222
    //   206: iload #5
    //   208: istore #6
    //   210: aload_3
    //   211: aload #8
    //   213: getfield i : Ljava/lang/String;
    //   216: invokevirtual equals : (Ljava/lang/Object;)Z
    //   219: ifne -> 173
    //   222: iload #5
    //   224: istore #7
    //   226: iload #4
    //   228: iflt -> 252
    //   231: iload #5
    //   233: istore #7
    //   235: iload #4
    //   237: aload #8
    //   239: getfield s : I
    //   242: if_icmpne -> 252
    //   245: iload #5
    //   247: istore #6
    //   249: goto -> 173
    //   252: iload #7
    //   254: istore #6
    //   256: iload #6
    //   258: aload_0
    //   259: getfield d : Ljava/util/ArrayList;
    //   262: invokevirtual size : ()I
    //   265: iconst_1
    //   266: isub
    //   267: if_icmpne -> 272
    //   270: iconst_0
    //   271: ireturn
    //   272: aload_0
    //   273: getfield d : Ljava/util/ArrayList;
    //   276: invokevirtual size : ()I
    //   279: iconst_1
    //   280: isub
    //   281: istore #4
    //   283: iload #4
    //   285: iload #6
    //   287: if_icmple -> 321
    //   290: aload_1
    //   291: aload_0
    //   292: getfield d : Ljava/util/ArrayList;
    //   295: iload #4
    //   297: invokevirtual remove : (I)Ljava/lang/Object;
    //   300: invokevirtual add : (Ljava/lang/Object;)Z
    //   303: pop
    //   304: aload_2
    //   305: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   308: invokevirtual add : (Ljava/lang/Object;)Z
    //   311: pop
    //   312: iload #4
    //   314: iconst_1
    //   315: isub
    //   316: istore #4
    //   318: goto -> 283
    //   321: iconst_1
    //   322: ireturn
  }
  
  public void Z(Fragment paramFragment) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.isInBackStack();
    if (!paramFragment.mDetached || (bool ^ true) != 0) {
      this.c.q(paramFragment);
      if (P(paramFragment))
        this.B = true; 
      paramFragment.mRemoving = true;
      h0(paramFragment);
    } 
  }
  
  public e0 a(Fragment paramFragment) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    e0 e0 = h(paramFragment);
    paramFragment.mFragmentManager = this;
    this.c.o(e0);
    if (!paramFragment.mDetached) {
      this.c.a(paramFragment);
      paramFragment.mRemoving = false;
      if (paramFragment.mView == null)
        paramFragment.mHiddenChanged = false; 
      if (P(paramFragment))
        this.B = true; 
    } 
    return e0;
  }
  
  public final void a0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList.isEmpty())
      return; 
    if (paramArrayList.size() == paramArrayList1.size()) {
      F(paramArrayList, paramArrayList1);
      int k = paramArrayList.size();
      int i = 0;
      int j;
      for (j = 0; i < k; j = m) {
        int n = i;
        int m = j;
        if (!((a)paramArrayList.get(i)).p) {
          if (j != i)
            E(paramArrayList, paramArrayList1, j, i); 
          j = i + 1;
          m = j;
          if (((Boolean)paramArrayList1.get(i)).booleanValue())
            while (true) {
              m = j;
              if (j < k) {
                m = j;
                if (((Boolean)paramArrayList1.get(j)).booleanValue()) {
                  m = j;
                  if (!((a)paramArrayList.get(j)).p) {
                    j++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          E(paramArrayList, paramArrayList1, i, m);
          n = m - 1;
        } 
        i = n + 1;
      } 
      if (j != k)
        E(paramArrayList, paramArrayList1, j, k); 
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Internal error with the back stack records");
    throw illegalStateException;
  }
  
  @SuppressLint({"SyntheticAccessor"})
  public void b(w<?> paramw, s params, Fragment paramFragment) {
    if (this.r == null) {
      b0 b01;
      this.r = paramw;
      this.s = params;
      this.t = paramFragment;
      if (paramFragment != null) {
        h h = new h(this, paramFragment);
        this.p.add(h);
      } else if (paramw instanceof c0) {
        c0 c0 = (c0)paramw;
        this.p.add(c0);
      } 
      if (this.t != null)
        k0(); 
      if (paramw instanceof androidx.activity.c) {
        Fragment fragment;
        androidx.activity.c c1 = (androidx.activity.c)paramw;
        OnBackPressedDispatcher onBackPressedDispatcher = c1.getOnBackPressedDispatcher();
        this.g = onBackPressedDispatcher;
        if (paramFragment != null)
          fragment = paramFragment; 
        onBackPressedDispatcher.a(fragment, this.h);
      } 
      if (paramFragment != null) {
        b0 b03 = paramFragment.mFragmentManager.K;
        b0 b02 = b03.d.get(paramFragment.mWho);
        b01 = b02;
        if (b02 == null) {
          b01 = new b0(b03.f);
          b03.d.put(paramFragment.mWho, b01);
        } 
        this.K = b01;
      } else if (b01 instanceof d0) {
        c0 c0 = ((d0)b01).getViewModelStore();
        y y1 = b0.i;
        String str = b0.class.getCanonicalName();
        if (str != null) {
          w w3;
          String str1 = j.f.a("androidx.lifecycle.ViewModelProvider.DefaultKey:", str);
          w w2 = (w)c0.a.get(str1);
          if (b0.class.isInstance(w2)) {
            w3 = w2;
            if (y1 instanceof b0) {
              ((b0)y1).b(w2);
              w3 = w2;
            } 
          } else {
            if (y1 instanceof z) {
              w2 = ((z)y1).c(str1, b0.class);
            } else {
              w2 = ((b0.a)y1).a((Class)b0.class);
            } 
            w w4 = ((c0)w3).a.put(str1, w2);
            w3 = w2;
            if (w4 != null) {
              w4.a();
              w3 = w2;
            } 
          } 
          this.K = (b0)w3;
        } else {
          throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        } 
      } else {
        this.K = new b0(false);
      } 
      this.K.h = S();
      this.c.i = this.K;
      w<?> w1 = this.r;
      if (w1 instanceof androidx.activity.result.e) {
        ActivityResultRegistry activityResultRegistry = ((androidx.activity.result.e)w1).getActivityResultRegistry();
        if (paramFragment != null) {
          str = v.a.a(new StringBuilder(), paramFragment.mWho, ":");
        } else {
          str = "";
        } 
        String str = j.f.a("FragmentManager:", str);
        this.x = activityResultRegistry.d(j.f.a(str, "StartActivityForResult"), (d.a)new d.c(), new i(this));
        this.y = activityResultRegistry.d(j.f.a(str, "StartIntentSenderForResult"), new j(), new a(this));
        this.z = activityResultRegistry.d(j.f.a(str, "RequestPermissions"), (d.a)new d.b(), new b(this));
      } 
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public void b0(Parcelable paramParcelable) {
    if (paramParcelable == null)
      return; 
    a0 a0 = (a0)paramParcelable;
    if (a0.f == null)
      return; 
    this.c.h.clear();
    for (Parcelable paramParcelable : a0.f) {
      if (paramParcelable != null) {
        e0 e0;
        b0 b02 = this.K;
        String str1 = ((d0)paramParcelable).g;
        Fragment fragment = b02.c.get(str1);
        if (fragment != null) {
          if (O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreSaveState: re-attaching retained ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          e0 = new e0(this.o, this.c, fragment, (d0)paramParcelable);
        } else {
          e0 = new e0(this.o, this.c, this.r.g.getClassLoader(), L(), (d0)e0);
        } 
        fragment = e0.c;
        fragment.mFragmentManager = this;
        if (O(2)) {
          StringBuilder stringBuilder = android.support.v4.media.a.a("restoreSaveState: active (");
          stringBuilder.append(fragment.mWho);
          stringBuilder.append("): ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        e0.m(this.r.g.getClassLoader());
        this.c.o(e0);
        e0.e = this.q;
      } 
    } 
    b0 b01 = this.K;
    Objects.requireNonNull(b01);
    for (Fragment fragment : new ArrayList(b01.c.values())) {
      if (!this.c.c(fragment.mWho)) {
        if (O(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Discarding retained Fragment ");
          stringBuilder.append(fragment);
          stringBuilder.append(" that was not found in the set of active Fragments ");
          stringBuilder.append(a0.f);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.K.d(fragment);
        fragment.mFragmentManager = this;
        e0 e0 = new e0(this.o, this.c, fragment);
        e0.e = 1;
        e0.k();
        fragment.mRemoving = true;
        e0.k();
      } 
    } 
    f0 f01 = this.c;
    ArrayList<String> arrayList2 = a0.g;
    f01.g.clear();
    if (arrayList2 != null)
      for (String str1 : arrayList2) {
        Fragment fragment = f01.d(str1);
        if (fragment != null) {
          if (O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreSaveState: added (");
            stringBuilder.append(str1);
            stringBuilder.append("): ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          f01.a(fragment);
          continue;
        } 
        throw new IllegalStateException(e.g.a("No instantiated fragment for (", str1, ")"));
      }  
    b[] arrayOfB = a0.h;
    byte b1 = 0;
    if (arrayOfB != null) {
      this.d = new ArrayList<a>(a0.h.length);
      int i = 0;
      while (true) {
        arrayOfB = a0.h;
        if (i < arrayOfB.length) {
          b b2 = arrayOfB[i];
          Objects.requireNonNull(b2);
          a a1 = new a(this);
          int k = 0;
          int j = 0;
          while (true) {
            int[] arrayOfInt = b2.f;
            if (k < arrayOfInt.length) {
              g0.a a2 = new g0.a();
              int n = k + 1;
              a2.a = arrayOfInt[k];
              if (O(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Instantiate ");
                stringBuilder.append(a1);
                stringBuilder.append(" op #");
                stringBuilder.append(j);
                stringBuilder.append(" base fragment #");
                stringBuilder.append(b2.f[n]);
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              String str1 = b2.g.get(j);
              if (str1 != null) {
                a2.b = this.c.d(str1);
              } else {
                a2.b = null;
              } 
              a2.g = Lifecycle.State.values()[b2.h[j]];
              a2.h = Lifecycle.State.values()[b2.i[j]];
              int[] arrayOfInt1 = b2.f;
              int m = n + 1;
              k = arrayOfInt1[n];
              a2.c = k;
              int i1 = m + 1;
              n = arrayOfInt1[m];
              a2.d = n;
              m = i1 + 1;
              i1 = arrayOfInt1[i1];
              a2.e = i1;
              int i2 = arrayOfInt1[m];
              a2.f = i2;
              a1.b = k;
              a1.c = n;
              a1.d = i1;
              a1.e = i2;
              a1.b(a2);
              j++;
              k = m + 1;
              continue;
            } 
            a1.f = b2.j;
            a1.i = b2.k;
            a1.s = b2.l;
            a1.g = true;
            a1.j = b2.m;
            a1.k = b2.n;
            a1.l = b2.o;
            a1.m = b2.p;
            a1.n = b2.q;
            a1.o = b2.r;
            a1.p = b2.s;
            a1.e(1);
            if (O(2)) {
              StringBuilder stringBuilder = w0.a("restoreAllState: back stack #", i, " (index ");
              stringBuilder.append(a1.s);
              stringBuilder.append("): ");
              stringBuilder.append(a1);
              Log.v("FragmentManager", stringBuilder.toString());
              PrintWriter printWriter = new PrintWriter(new t0("FragmentManager"));
              a1.i("  ", printWriter, false);
              printWriter.close();
            } 
            break;
          } 
          this.d.add(a1);
          i++;
          continue;
        } 
        break;
      } 
    } else {
      this.d = null;
    } 
    this.i.set(a0.i);
    String str = a0.j;
    if (str != null) {
      Fragment fragment = G(str);
      this.u = fragment;
      t(fragment);
    } 
    ArrayList<String> arrayList1 = a0.k;
    if (arrayList1 != null)
      for (int i = b1; i < arrayList1.size(); i++) {
        Bundle bundle = a0.l.get(i);
        bundle.setClassLoader(this.r.g.getClassLoader());
        this.j.put(arrayList1.get(i), bundle);
      }  
    this.A = new ArrayDeque<k>(a0.m);
  }
  
  public void c(Fragment paramFragment) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded) {
        this.c.a(paramFragment);
        if (O(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("add from attach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (P(paramFragment))
          this.B = true; 
      } 
    } 
  }
  
  public Parcelable c0() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual f : ()Ljava/util/Set;
    //   4: checkcast java/util/HashSet
    //   7: invokevirtual iterator : ()Ljava/util/Iterator;
    //   10: astore #4
    //   12: aload #4
    //   14: invokeinterface hasNext : ()Z
    //   19: istore_3
    //   20: iconst_0
    //   21: istore_1
    //   22: iload_3
    //   23: ifeq -> 60
    //   26: aload #4
    //   28: invokeinterface next : ()Ljava/lang/Object;
    //   33: checkcast androidx/fragment/app/SpecialEffectsController
    //   36: astore #5
    //   38: aload #5
    //   40: getfield e : Z
    //   43: ifeq -> 12
    //   46: aload #5
    //   48: iconst_0
    //   49: putfield e : Z
    //   52: aload #5
    //   54: invokevirtual c : ()V
    //   57: goto -> 12
    //   60: aload_0
    //   61: invokevirtual z : ()V
    //   64: aload_0
    //   65: iconst_1
    //   66: invokevirtual C : (Z)Z
    //   69: pop
    //   70: aload_0
    //   71: iconst_1
    //   72: putfield C : Z
    //   75: aload_0
    //   76: getfield K : Landroidx/fragment/app/b0;
    //   79: iconst_1
    //   80: putfield h : Z
    //   83: aload_0
    //   84: getfield c : Landroidx/fragment/app/f0;
    //   87: astore #4
    //   89: aload #4
    //   91: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   94: pop
    //   95: new java/util/ArrayList
    //   98: dup
    //   99: aload #4
    //   101: getfield h : Ljava/lang/Object;
    //   104: checkcast java/util/HashMap
    //   107: invokevirtual size : ()I
    //   110: invokespecial <init> : (I)V
    //   113: astore #7
    //   115: aload #4
    //   117: getfield h : Ljava/lang/Object;
    //   120: checkcast java/util/HashMap
    //   123: invokevirtual values : ()Ljava/util/Collection;
    //   126: invokeinterface iterator : ()Ljava/util/Iterator;
    //   131: astore #8
    //   133: aload #8
    //   135: invokeinterface hasNext : ()Z
    //   140: istore_3
    //   141: aconst_null
    //   142: astore #6
    //   144: aconst_null
    //   145: astore #5
    //   147: iload_3
    //   148: ifeq -> 590
    //   151: aload #8
    //   153: invokeinterface next : ()Ljava/lang/Object;
    //   158: checkcast androidx/fragment/app/e0
    //   161: astore #10
    //   163: aload #10
    //   165: ifnull -> 133
    //   168: aload #10
    //   170: getfield c : Landroidx/fragment/app/Fragment;
    //   173: astore #6
    //   175: new androidx/fragment/app/d0
    //   178: dup
    //   179: aload #6
    //   181: invokespecial <init> : (Landroidx/fragment/app/Fragment;)V
    //   184: astore #9
    //   186: aload #10
    //   188: getfield c : Landroidx/fragment/app/Fragment;
    //   191: astore #4
    //   193: aload #4
    //   195: getfield mState : I
    //   198: iconst_m1
    //   199: if_icmple -> 505
    //   202: aload #9
    //   204: getfield r : Landroid/os/Bundle;
    //   207: ifnonnull -> 505
    //   210: new android/os/Bundle
    //   213: dup
    //   214: invokespecial <init> : ()V
    //   217: astore #4
    //   219: aload #10
    //   221: getfield c : Landroidx/fragment/app/Fragment;
    //   224: aload #4
    //   226: invokevirtual performSaveInstanceState : (Landroid/os/Bundle;)V
    //   229: aload #10
    //   231: getfield a : Landroidx/fragment/app/y;
    //   234: aload #10
    //   236: getfield c : Landroidx/fragment/app/Fragment;
    //   239: aload #4
    //   241: iconst_0
    //   242: invokevirtual j : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   245: aload #4
    //   247: invokevirtual isEmpty : ()Z
    //   250: ifeq -> 256
    //   253: goto -> 260
    //   256: aload #4
    //   258: astore #5
    //   260: aload #10
    //   262: getfield c : Landroidx/fragment/app/Fragment;
    //   265: getfield mView : Landroid/view/View;
    //   268: ifnull -> 276
    //   271: aload #10
    //   273: invokevirtual o : ()V
    //   276: aload #5
    //   278: astore #4
    //   280: aload #10
    //   282: getfield c : Landroidx/fragment/app/Fragment;
    //   285: getfield mSavedViewState : Landroid/util/SparseArray;
    //   288: ifnull -> 325
    //   291: aload #5
    //   293: astore #4
    //   295: aload #5
    //   297: ifnonnull -> 309
    //   300: new android/os/Bundle
    //   303: dup
    //   304: invokespecial <init> : ()V
    //   307: astore #4
    //   309: aload #4
    //   311: ldc_w 'android:view_state'
    //   314: aload #10
    //   316: getfield c : Landroidx/fragment/app/Fragment;
    //   319: getfield mSavedViewState : Landroid/util/SparseArray;
    //   322: invokevirtual putSparseParcelableArray : (Ljava/lang/String;Landroid/util/SparseArray;)V
    //   325: aload #4
    //   327: astore #5
    //   329: aload #10
    //   331: getfield c : Landroidx/fragment/app/Fragment;
    //   334: getfield mSavedViewRegistryState : Landroid/os/Bundle;
    //   337: ifnull -> 374
    //   340: aload #4
    //   342: astore #5
    //   344: aload #4
    //   346: ifnonnull -> 358
    //   349: new android/os/Bundle
    //   352: dup
    //   353: invokespecial <init> : ()V
    //   356: astore #5
    //   358: aload #5
    //   360: ldc_w 'android:view_registry_state'
    //   363: aload #10
    //   365: getfield c : Landroidx/fragment/app/Fragment;
    //   368: getfield mSavedViewRegistryState : Landroid/os/Bundle;
    //   371: invokevirtual putBundle : (Ljava/lang/String;Landroid/os/Bundle;)V
    //   374: aload #5
    //   376: astore #4
    //   378: aload #10
    //   380: getfield c : Landroidx/fragment/app/Fragment;
    //   383: getfield mUserVisibleHint : Z
    //   386: ifne -> 423
    //   389: aload #5
    //   391: astore #4
    //   393: aload #5
    //   395: ifnonnull -> 407
    //   398: new android/os/Bundle
    //   401: dup
    //   402: invokespecial <init> : ()V
    //   405: astore #4
    //   407: aload #4
    //   409: ldc_w 'android:user_visible_hint'
    //   412: aload #10
    //   414: getfield c : Landroidx/fragment/app/Fragment;
    //   417: getfield mUserVisibleHint : Z
    //   420: invokevirtual putBoolean : (Ljava/lang/String;Z)V
    //   423: aload #9
    //   425: aload #4
    //   427: putfield r : Landroid/os/Bundle;
    //   430: aload #10
    //   432: getfield c : Landroidx/fragment/app/Fragment;
    //   435: getfield mTargetWho : Ljava/lang/String;
    //   438: ifnull -> 515
    //   441: aload #4
    //   443: ifnonnull -> 458
    //   446: aload #9
    //   448: new android/os/Bundle
    //   451: dup
    //   452: invokespecial <init> : ()V
    //   455: putfield r : Landroid/os/Bundle;
    //   458: aload #9
    //   460: getfield r : Landroid/os/Bundle;
    //   463: ldc_w 'android:target_state'
    //   466: aload #10
    //   468: getfield c : Landroidx/fragment/app/Fragment;
    //   471: getfield mTargetWho : Ljava/lang/String;
    //   474: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   477: aload #10
    //   479: getfield c : Landroidx/fragment/app/Fragment;
    //   482: getfield mTargetRequestCode : I
    //   485: istore_2
    //   486: iload_2
    //   487: ifeq -> 515
    //   490: aload #9
    //   492: getfield r : Landroid/os/Bundle;
    //   495: ldc_w 'android:target_req_state'
    //   498: iload_2
    //   499: invokevirtual putInt : (Ljava/lang/String;I)V
    //   502: goto -> 515
    //   505: aload #9
    //   507: aload #4
    //   509: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   512: putfield r : Landroid/os/Bundle;
    //   515: aload #7
    //   517: aload #9
    //   519: invokevirtual add : (Ljava/lang/Object;)Z
    //   522: pop
    //   523: iconst_2
    //   524: invokestatic O : (I)Z
    //   527: ifeq -> 133
    //   530: new java/lang/StringBuilder
    //   533: dup
    //   534: invokespecial <init> : ()V
    //   537: astore #4
    //   539: aload #4
    //   541: ldc_w 'Saved state of '
    //   544: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   547: pop
    //   548: aload #4
    //   550: aload #6
    //   552: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   555: pop
    //   556: aload #4
    //   558: ldc_w ': '
    //   561: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   564: pop
    //   565: aload #4
    //   567: aload #9
    //   569: getfield r : Landroid/os/Bundle;
    //   572: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   575: pop
    //   576: ldc 'FragmentManager'
    //   578: aload #4
    //   580: invokevirtual toString : ()Ljava/lang/String;
    //   583: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   586: pop
    //   587: goto -> 133
    //   590: aload #7
    //   592: invokevirtual isEmpty : ()Z
    //   595: ifeq -> 616
    //   598: iconst_2
    //   599: invokestatic O : (I)Z
    //   602: ifeq -> 614
    //   605: ldc 'FragmentManager'
    //   607: ldc_w 'saveAllState: no fragments!'
    //   610: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   613: pop
    //   614: aconst_null
    //   615: areturn
    //   616: aload_0
    //   617: getfield c : Landroidx/fragment/app/f0;
    //   620: astore #8
    //   622: aload #8
    //   624: getfield g : Ljava/lang/Object;
    //   627: checkcast java/util/ArrayList
    //   630: astore #5
    //   632: aload #5
    //   634: monitorenter
    //   635: aload #8
    //   637: getfield g : Ljava/lang/Object;
    //   640: checkcast java/util/ArrayList
    //   643: invokevirtual isEmpty : ()Z
    //   646: ifeq -> 658
    //   649: aload #5
    //   651: monitorexit
    //   652: aconst_null
    //   653: astore #4
    //   655: goto -> 794
    //   658: new java/util/ArrayList
    //   661: dup
    //   662: aload #8
    //   664: getfield g : Ljava/lang/Object;
    //   667: checkcast java/util/ArrayList
    //   670: invokevirtual size : ()I
    //   673: invokespecial <init> : (I)V
    //   676: astore #4
    //   678: aload #8
    //   680: getfield g : Ljava/lang/Object;
    //   683: checkcast java/util/ArrayList
    //   686: invokevirtual iterator : ()Ljava/util/Iterator;
    //   689: astore #8
    //   691: aload #8
    //   693: invokeinterface hasNext : ()Z
    //   698: ifeq -> 791
    //   701: aload #8
    //   703: invokeinterface next : ()Ljava/lang/Object;
    //   708: checkcast androidx/fragment/app/Fragment
    //   711: astore #9
    //   713: aload #4
    //   715: aload #9
    //   717: getfield mWho : Ljava/lang/String;
    //   720: invokevirtual add : (Ljava/lang/Object;)Z
    //   723: pop
    //   724: iconst_2
    //   725: invokestatic O : (I)Z
    //   728: ifeq -> 691
    //   731: new java/lang/StringBuilder
    //   734: dup
    //   735: invokespecial <init> : ()V
    //   738: astore #10
    //   740: aload #10
    //   742: ldc_w 'saveAllState: adding fragment ('
    //   745: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   748: pop
    //   749: aload #10
    //   751: aload #9
    //   753: getfield mWho : Ljava/lang/String;
    //   756: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   759: pop
    //   760: aload #10
    //   762: ldc_w '): '
    //   765: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   768: pop
    //   769: aload #10
    //   771: aload #9
    //   773: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   776: pop
    //   777: ldc 'FragmentManager'
    //   779: aload #10
    //   781: invokevirtual toString : ()Ljava/lang/String;
    //   784: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   787: pop
    //   788: goto -> 691
    //   791: aload #5
    //   793: monitorexit
    //   794: aload_0
    //   795: getfield d : Ljava/util/ArrayList;
    //   798: astore #8
    //   800: aload #6
    //   802: astore #5
    //   804: aload #8
    //   806: ifnull -> 911
    //   809: aload #8
    //   811: invokevirtual size : ()I
    //   814: istore_2
    //   815: aload #6
    //   817: astore #5
    //   819: iload_2
    //   820: ifle -> 911
    //   823: iload_2
    //   824: anewarray androidx/fragment/app/b
    //   827: astore #6
    //   829: aload #6
    //   831: astore #5
    //   833: iload_1
    //   834: iload_2
    //   835: if_icmpge -> 911
    //   838: aload #6
    //   840: iload_1
    //   841: new androidx/fragment/app/b
    //   844: dup
    //   845: aload_0
    //   846: getfield d : Ljava/util/ArrayList;
    //   849: iload_1
    //   850: invokevirtual get : (I)Ljava/lang/Object;
    //   853: checkcast androidx/fragment/app/a
    //   856: invokespecial <init> : (Landroidx/fragment/app/a;)V
    //   859: aastore
    //   860: iconst_2
    //   861: invokestatic O : (I)Z
    //   864: ifeq -> 904
    //   867: ldc_w 'saveAllState: adding back stack #'
    //   870: iload_1
    //   871: ldc_w ': '
    //   874: invokestatic a : (Ljava/lang/String;ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   877: astore #5
    //   879: aload #5
    //   881: aload_0
    //   882: getfield d : Ljava/util/ArrayList;
    //   885: iload_1
    //   886: invokevirtual get : (I)Ljava/lang/Object;
    //   889: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   892: pop
    //   893: ldc 'FragmentManager'
    //   895: aload #5
    //   897: invokevirtual toString : ()Ljava/lang/String;
    //   900: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   903: pop
    //   904: iload_1
    //   905: iconst_1
    //   906: iadd
    //   907: istore_1
    //   908: goto -> 829
    //   911: new androidx/fragment/app/a0
    //   914: dup
    //   915: invokespecial <init> : ()V
    //   918: astore #6
    //   920: aload #6
    //   922: aload #7
    //   924: putfield f : Ljava/util/ArrayList;
    //   927: aload #6
    //   929: aload #4
    //   931: putfield g : Ljava/util/ArrayList;
    //   934: aload #6
    //   936: aload #5
    //   938: putfield h : [Landroidx/fragment/app/b;
    //   941: aload #6
    //   943: aload_0
    //   944: getfield i : Ljava/util/concurrent/atomic/AtomicInteger;
    //   947: invokevirtual get : ()I
    //   950: putfield i : I
    //   953: aload_0
    //   954: getfield u : Landroidx/fragment/app/Fragment;
    //   957: astore #4
    //   959: aload #4
    //   961: ifnull -> 974
    //   964: aload #6
    //   966: aload #4
    //   968: getfield mWho : Ljava/lang/String;
    //   971: putfield j : Ljava/lang/String;
    //   974: aload #6
    //   976: getfield k : Ljava/util/ArrayList;
    //   979: aload_0
    //   980: getfield j : Ljava/util/Map;
    //   983: invokeinterface keySet : ()Ljava/util/Set;
    //   988: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   991: pop
    //   992: aload #6
    //   994: getfield l : Ljava/util/ArrayList;
    //   997: aload_0
    //   998: getfield j : Ljava/util/Map;
    //   1001: invokeinterface values : ()Ljava/util/Collection;
    //   1006: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   1009: pop
    //   1010: aload #6
    //   1012: new java/util/ArrayList
    //   1015: dup
    //   1016: aload_0
    //   1017: getfield A : Ljava/util/ArrayDeque;
    //   1020: invokespecial <init> : (Ljava/util/Collection;)V
    //   1023: putfield m : Ljava/util/ArrayList;
    //   1026: aload #6
    //   1028: areturn
    //   1029: astore #4
    //   1031: aload #5
    //   1033: monitorexit
    //   1034: goto -> 1040
    //   1037: aload #4
    //   1039: athrow
    //   1040: goto -> 1037
    // Exception table:
    //   from	to	target	type
    //   635	652	1029	finally
    //   658	691	1029	finally
    //   691	788	1029	finally
    //   791	794	1029	finally
    //   1031	1034	1029	finally
  }
  
  public final void d(Fragment paramFragment) {
    HashSet hashSet = this.m.get(paramFragment);
    if (hashSet != null) {
      Iterator<i0.b> iterator = hashSet.iterator();
      while (iterator.hasNext())
        ((i0.b)iterator.next()).a(); 
      hashSet.clear();
      i(paramFragment);
      this.m.remove(paramFragment);
    } 
  }
  
  public void d0() {
    boolean bool1;
    boolean bool2;
    synchronized (this.a) {
      ArrayList<o> arrayList = this.J;
      bool2 = false;
      if (arrayList != null && !arrayList.isEmpty()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (this.a.size() == 1)
        bool2 = true; 
    } 
    if (bool1 || bool2) {
      this.r.h.removeCallbacks(this.L);
      this.r.h.post(this.L);
      k0();
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
  }
  
  public final void e() {
    this.b = false;
    this.H.clear();
    this.G.clear();
  }
  
  public void e0(Fragment paramFragment, boolean paramBoolean) {
    ViewGroup viewGroup = K(paramFragment);
    if (viewGroup != null && viewGroup instanceof t)
      ((t)viewGroup).setDrawDisappearingViewsLast(paramBoolean ^ true); 
  }
  
  public final Set<SpecialEffectsController> f() {
    HashSet<SpecialEffectsController> hashSet = new HashSet();
    Iterator iterator = ((ArrayList)this.c.f()).iterator();
    while (iterator.hasNext()) {
      ViewGroup viewGroup = ((e0)iterator.next()).c.mContainer;
      if (viewGroup != null)
        hashSet.add(SpecialEffectsController.g(viewGroup, M())); 
    } 
    return hashSet;
  }
  
  public void f0(Fragment paramFragment, Lifecycle.State paramState) {
    if (paramFragment.equals(G(paramFragment.mWho)) && (paramFragment.mHost == null || paramFragment.mFragmentManager == this)) {
      paramFragment.mMaxState = paramState;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void g(a parama, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      parama.k(paramBoolean3);
    } else {
      parama.j();
    } 
    ArrayList<a> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(parama);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2 && this.q >= 1)
      n0.q(this.r.g, this.s, arrayList, arrayList1, 0, 1, true, this.n); 
    if (paramBoolean3)
      T(this.q, true); 
    for (Fragment fragment : this.c.g()) {
      if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && parama.l(fragment.mContainerId)) {
        float f = fragment.mPostponedAlpha;
        if (f > 0.0F)
          fragment.mView.setAlpha(f); 
        if (paramBoolean3) {
          fragment.mPostponedAlpha = 0.0F;
          continue;
        } 
        fragment.mPostponedAlpha = -1.0F;
        fragment.mIsNewlyAdded = false;
      } 
    } 
  }
  
  public void g0(Fragment paramFragment) {
    if (paramFragment == null || (paramFragment.equals(G(paramFragment.mWho)) && (paramFragment.mHost == null || paramFragment.mFragmentManager == this))) {
      Fragment fragment = this.u;
      this.u = paramFragment;
      t(fragment);
      t(this.u);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public e0 h(Fragment paramFragment) {
    e0 e02 = this.c.h(paramFragment.mWho);
    if (e02 != null)
      return e02; 
    e0 e01 = new e0(this.o, this.c, paramFragment);
    e01.m(this.r.g.getClassLoader());
    e01.e = this.q;
    return e01;
  }
  
  public final void h0(Fragment paramFragment) {
    ViewGroup viewGroup = K(paramFragment);
    if (viewGroup != null) {
      int i = paramFragment.getEnterAnim();
      int j = paramFragment.getExitAnim();
      int k = paramFragment.getPopEnterAnim();
      if (paramFragment.getPopExitAnim() + k + j + i > 0) {
        if (viewGroup.getTag(2131231219) == null)
          viewGroup.setTag(2131231219, paramFragment); 
        ((Fragment)viewGroup.getTag(2131231219)).setPopDirection(paramFragment.getPopDirection());
      } 
    } 
  }
  
  public final void i(Fragment paramFragment) {
    paramFragment.performDestroyView();
    this.o.n(paramFragment, false);
    paramFragment.mContainer = null;
    paramFragment.mView = null;
    paramFragment.mViewLifecycleOwner = null;
    paramFragment.mViewLifecycleOwnerLiveData.i(null);
    paramFragment.mInLayout = false;
  }
  
  public void i0(Fragment paramFragment) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged ^= 0x1;
    } 
  }
  
  public void j(Fragment paramFragment) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (O(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.c.q(paramFragment);
        if (P(paramFragment))
          this.B = true; 
        h0(paramFragment);
      } 
    } 
  }
  
  public final void j0() {
    Iterator<e0> iterator = ((ArrayList)this.c.f()).iterator();
    while (iterator.hasNext())
      W(iterator.next()); 
  }
  
  public void k(Configuration paramConfiguration) {
    for (Fragment fragment : this.c.i()) {
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  public final void k0() {
    ArrayList<m> arrayList;
    androidx.activity.b b1;
    synchronized (this.a) {
      boolean bool1 = this.a.isEmpty();
      boolean bool = true;
      if (!bool1) {
        this.h.a = true;
        return;
      } 
      b1 = this.h;
      if (J() <= 0 || !R(this.t))
        bool = false; 
      b1.a = bool;
      return;
    } 
  }
  
  public boolean l(MenuItem paramMenuItem) {
    if (this.q < 1)
      return false; 
    for (Fragment fragment : this.c.i()) {
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void m() {
    this.C = false;
    this.D = false;
    this.K.h = false;
    w(1);
  }
  
  public boolean n(Menu paramMenu, MenuInflater paramMenuInflater) {
    int j = this.q;
    int i = 0;
    if (j < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    Iterator<Fragment> iterator = this.c.i().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment != null && Q(fragment) && fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
        ArrayList<Fragment> arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        arrayList1.add(fragment);
        bool = true;
        arrayList = arrayList1;
      } 
    } 
    if (this.e != null)
      while (i < this.e.size()) {
        Fragment fragment = this.e.get(i);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
        i++;
      }  
    this.e = arrayList;
    return bool;
  }
  
  public void o() {
    this.E = true;
    C(true);
    z();
    w(-1);
    this.r = null;
    this.s = null;
    this.t = null;
    if (this.g != null) {
      Iterator<androidx.activity.a> iterator = this.h.b.iterator();
      while (iterator.hasNext())
        ((androidx.activity.a)iterator.next()).cancel(); 
      this.g = null;
    } 
    androidx.activity.result.c<Intent> c1 = this.x;
    if (c1 != null) {
      c1.c();
      this.y.c();
      this.z.c();
    } 
  }
  
  public void p() {
    for (Fragment fragment : this.c.i()) {
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  public void q(boolean paramBoolean) {
    for (Fragment fragment : this.c.i()) {
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  public boolean r(MenuItem paramMenuItem) {
    if (this.q < 1)
      return false; 
    for (Fragment fragment : this.c.i()) {
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void s(Menu paramMenu) {
    if (this.q < 1)
      return; 
    for (Fragment fragment : this.c.i()) {
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  public final void t(Fragment paramFragment) {
    if (paramFragment != null && paramFragment.equals(G(paramFragment.mWho)))
      paramFragment.performPrimaryNavigationFragmentChanged(); 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.t;
    if (fragment != null) {
      stringBuilder.append(fragment.getClass().getSimpleName());
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this.t)));
      stringBuilder.append("}");
    } else {
      w<?> w1 = this.r;
      if (w1 != null) {
        stringBuilder.append(w1.getClass().getSimpleName());
        stringBuilder.append("{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this.r)));
        stringBuilder.append("}");
      } else {
        stringBuilder.append("null");
      } 
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void u(boolean paramBoolean) {
    for (Fragment fragment : this.c.i()) {
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  public boolean v(Menu paramMenu) {
    int i = this.q;
    boolean bool = false;
    if (i < 1)
      return false; 
    for (Fragment fragment : this.c.i()) {
      if (fragment != null && Q(fragment) && fragment.performPrepareOptionsMenu(paramMenu))
        bool = true; 
    } 
    return bool;
  }
  
  public final void w(int paramInt) {
    try {
      this.b = true;
      for (e0 e0 : this.c.h.values()) {
        if (e0 != null)
          e0.e = paramInt; 
      } 
      T(paramInt, false);
      Iterator<SpecialEffectsController> iterator = ((HashSet)f()).iterator();
      while (iterator.hasNext())
        ((SpecialEffectsController)iterator.next()).e(); 
      this.b = false;
      return;
    } finally {
      this.b = false;
    } 
  }
  
  public final void x() {
    if (this.F) {
      this.F = false;
      j0();
    } 
  }
  
  public void y(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    String str1 = j.f.a(paramString, "    ");
    f0 f01 = this.c;
    Objects.requireNonNull(f01);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("    ");
    String str2 = stringBuilder2.toString();
    if (!f01.h.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Active Fragments:");
      for (e0 e0 : f01.h.values()) {
        paramPrintWriter.print(paramString);
        if (e0 != null) {
          Fragment fragment = e0.c;
          paramPrintWriter.println(fragment);
          fragment.dump(str2, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          continue;
        } 
        paramPrintWriter.println("null");
      } 
    } 
    int i = f01.g.size();
    byte b1 = 0;
    if (i > 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Added Fragments:");
      int j;
      for (j = 0; j < i; j++) {
        Fragment fragment = f01.g.get(j);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  #");
        paramPrintWriter.print(j);
        paramPrintWriter.print(": ");
        paramPrintWriter.println(fragment.toString());
      } 
    } 
    ArrayList<Fragment> arrayList1 = this.e;
    if (arrayList1 != null) {
      i = arrayList1.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Fragments Created Menus:");
        int j;
        for (j = 0; j < i; j++) {
          Fragment fragment = this.e.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(fragment.toString());
        } 
      } 
    } 
    ArrayList<a> arrayList = this.d;
    if (arrayList != null) {
      i = arrayList.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Back Stack:");
        int j;
        for (j = 0; j < i; j++) {
          a a1 = this.d.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(a1.toString());
          a1.i(str1, paramPrintWriter, true);
        } 
      } 
    } 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Back Stack Index: ");
    stringBuilder1.append(this.i.get());
    paramPrintWriter.println(stringBuilder1.toString());
    synchronized (this.a) {
      i = this.a.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Pending Actions:");
        int j;
        for (j = b1; j < i; j++) {
          m m = this.a.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(m);
        } 
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("FragmentManager misc state:");
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mHost=");
      paramPrintWriter.println(this.r);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mContainer=");
      paramPrintWriter.println(this.s);
      if (this.t != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mParent=");
        paramPrintWriter.println(this.t);
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mCurState=");
      paramPrintWriter.print(this.q);
      paramPrintWriter.print(" mStateSaved=");
      paramPrintWriter.print(this.C);
      paramPrintWriter.print(" mStopped=");
      paramPrintWriter.print(this.D);
      paramPrintWriter.print(" mDestroyed=");
      paramPrintWriter.println(this.E);
      if (this.B) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mNeedMenuInvalidate=");
        paramPrintWriter.println(this.B);
      } 
      return;
    } 
  }
  
  public final void z() {
    Iterator<SpecialEffectsController> iterator = ((HashSet)f()).iterator();
    while (iterator.hasNext())
      ((SpecialEffectsController)iterator.next()).e(); 
  }
  
  public static abstract class FragmentLifecycleCallbacks {
    public abstract void a(FragmentManager param1FragmentManager, Fragment param1Fragment, Context param1Context);
    
    public abstract void b(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle);
    
    public abstract void c(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void d(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void e(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void f(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void g(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle);
    
    public abstract void h(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void i(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void j(FragmentManager param1FragmentManager, Fragment param1Fragment, View param1View, Bundle param1Bundle);
    
    public abstract void k(FragmentManager param1FragmentManager, Fragment param1Fragment);
  }
  
  public class a implements androidx.activity.result.b<androidx.activity.result.a> {
    public a(FragmentManager this$0) {}
    
    public void a(Object param1Object) {
      StringBuilder stringBuilder;
      androidx.activity.result.a a1 = (androidx.activity.result.a)param1Object;
      FragmentManager.k k = this.f.A.pollFirst();
      if (k == null) {
        param1Object = new StringBuilder();
        param1Object.append("No IntentSenders were started for ");
        param1Object.append(this);
        Log.w("FragmentManager", param1Object.toString());
        return;
      } 
      param1Object = k.f;
      int i = k.g;
      Fragment fragment = this.f.c.e((String)param1Object);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Intent Sender result delivered for unknown Fragment ");
        stringBuilder.append((String)param1Object);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.onActivityResult(i, ((androidx.activity.result.a)stringBuilder).f, ((androidx.activity.result.a)stringBuilder).g);
    }
  }
  
  public class b implements androidx.activity.result.b<Map<String, Boolean>> {
    public b(FragmentManager this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void a(Object param1Object) {
      Map map = (Map)param1Object;
      param1Object = map.keySet().toArray((Object[])new String[0]);
      ArrayList<Boolean> arrayList = new ArrayList(map.values());
      int[] arrayOfInt = new int[arrayList.size()];
      int i;
      for (i = 0; i < arrayList.size(); i++) {
        byte b1;
        if (((Boolean)arrayList.get(i)).booleanValue()) {
          b1 = 0;
        } else {
          b1 = -1;
        } 
        arrayOfInt[i] = b1;
      } 
      FragmentManager.k k = this.f.A.pollFirst();
      if (k == null) {
        param1Object = new StringBuilder();
        param1Object.append("No permissions were requested for ");
        param1Object.append(this);
        Log.w("FragmentManager", param1Object.toString());
        return;
      } 
      String str = k.f;
      i = k.g;
      Fragment fragment = this.f.c.e(str);
      if (fragment == null) {
        param1Object = new StringBuilder();
        param1Object.append("Permission request result delivered for unknown Fragment ");
        param1Object.append(str);
        Log.w("FragmentManager", param1Object.toString());
        return;
      } 
      fragment.onRequestPermissionsResult(i, (String[])param1Object, arrayOfInt);
    }
  }
  
  public class c extends androidx.activity.b {
    public c(FragmentManager this$0, boolean param1Boolean) {
      super(param1Boolean);
    }
    
    public void a() {
      FragmentManager fragmentManager = this.c;
      fragmentManager.C(true);
      if (fragmentManager.h.a) {
        fragmentManager.X();
        return;
      } 
      fragmentManager.g.b();
    }
  }
  
  public class d implements n0.a {
    public d(FragmentManager this$0) {}
    
    public void a(Fragment param1Fragment, i0.b param1b) {
      // Byte code:
      //   0: aload_2
      //   1: monitorenter
      //   2: aload_2
      //   3: getfield a : Z
      //   6: istore_3
      //   7: aload_2
      //   8: monitorexit
      //   9: iload_3
      //   10: ifne -> 94
      //   13: aload_0
      //   14: getfield a : Landroidx/fragment/app/FragmentManager;
      //   17: astore #4
      //   19: aload #4
      //   21: getfield m : Ljava/util/Map;
      //   24: aload_1
      //   25: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   30: checkcast java/util/HashSet
      //   33: astore #5
      //   35: aload #5
      //   37: ifnull -> 94
      //   40: aload #5
      //   42: aload_2
      //   43: invokevirtual remove : (Ljava/lang/Object;)Z
      //   46: ifeq -> 94
      //   49: aload #5
      //   51: invokevirtual isEmpty : ()Z
      //   54: ifeq -> 94
      //   57: aload #4
      //   59: getfield m : Ljava/util/Map;
      //   62: aload_1
      //   63: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   68: pop
      //   69: aload_1
      //   70: getfield mState : I
      //   73: iconst_5
      //   74: if_icmpge -> 94
      //   77: aload #4
      //   79: aload_1
      //   80: invokevirtual i : (Landroidx/fragment/app/Fragment;)V
      //   83: aload #4
      //   85: aload_1
      //   86: aload #4
      //   88: getfield q : I
      //   91: invokevirtual U : (Landroidx/fragment/app/Fragment;I)V
      //   94: return
      //   95: astore_1
      //   96: aload_2
      //   97: monitorexit
      //   98: aload_1
      //   99: athrow
      // Exception table:
      //   from	to	target	type
      //   2	9	95	finally
      //   96	98	95	finally
    }
    
    public void b(Fragment param1Fragment, i0.b param1b) {
      FragmentManager fragmentManager = this.a;
      if (fragmentManager.m.get(param1Fragment) == null)
        fragmentManager.m.put(param1Fragment, new HashSet<i0.b>()); 
      ((HashSet<i0.b>)fragmentManager.m.get(param1Fragment)).add(param1b);
    }
  }
  
  public class e extends v {
    public e(FragmentManager this$0) {}
    
    public Fragment a(ClassLoader param1ClassLoader, String param1String) {
      w<?> w = this.b.r;
      Context context = w.g;
      Objects.requireNonNull(w);
      return Fragment.instantiate(context, param1String, null);
    }
  }
  
  public class f implements u0 {
    public f(FragmentManager this$0) {}
  }
  
  public class g implements Runnable {
    public g(FragmentManager this$0) {}
    
    public void run() {
      this.f.C(true);
    }
  }
  
  public class h implements c0 {
    public h(FragmentManager this$0, Fragment param1Fragment) {}
    
    public void a(FragmentManager param1FragmentManager, Fragment param1Fragment) {
      this.f.onAttachFragment(param1Fragment);
    }
  }
  
  public class i implements androidx.activity.result.b<androidx.activity.result.a> {
    public i(FragmentManager this$0) {}
    
    public void a(Object param1Object) {
      StringBuilder stringBuilder;
      androidx.activity.result.a a = (androidx.activity.result.a)param1Object;
      FragmentManager.k k = this.f.A.pollFirst();
      if (k == null) {
        param1Object = new StringBuilder();
        param1Object.append("No Activities were started for result for ");
        param1Object.append(this);
        Log.w("FragmentManager", param1Object.toString());
        return;
      } 
      param1Object = k.f;
      int j = k.g;
      Fragment fragment = this.f.c.e((String)param1Object);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result delivered for unknown Fragment ");
        stringBuilder.append((String)param1Object);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.onActivityResult(j, ((androidx.activity.result.a)stringBuilder).f, ((androidx.activity.result.a)stringBuilder).g);
    }
  }
  
  public static class j extends d.a<androidx.activity.result.f, androidx.activity.result.a> {
    public Intent createIntent(Context param1Context, Object param1Object) {
      param1Object = param1Object;
      Intent intent1 = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
      Intent intent2 = ((androidx.activity.result.f)param1Object).g;
      Object object = param1Object;
      if (intent2 != null) {
        Bundle bundle = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        object = param1Object;
        if (bundle != null) {
          intent1.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
          intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
          object = param1Object;
          if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
            object = ((androidx.activity.result.f)param1Object).f;
            int i = ((androidx.activity.result.f)param1Object).i;
            object = new androidx.activity.result.f((IntentSender)object, null, ((androidx.activity.result.f)param1Object).h, i);
          } 
        } 
      } 
      intent1.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", (Parcelable)object);
      if (FragmentManager.O(2)) {
        object = new StringBuilder();
        object.append("CreateIntent created the following intent: ");
        object.append(intent1);
        Log.v("FragmentManager", object.toString());
      } 
      return intent1;
    }
    
    public Object parseResult(int param1Int, Intent param1Intent) {
      return new androidx.activity.result.a(param1Int, param1Intent);
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class k implements Parcelable {
    public static final Parcelable.Creator<k> CREATOR = new a();
    
    public String f;
    
    public int g;
    
    public k(Parcel param1Parcel) {
      this.f = param1Parcel.readString();
      this.g = param1Parcel.readInt();
    }
    
    public k(String param1String, int param1Int) {
      this.f = param1String;
      this.g = param1Int;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.f);
      param1Parcel.writeInt(this.g);
    }
    
    public class a implements Parcelable.Creator<k> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new FragmentManager.k(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new FragmentManager.k[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<k> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new FragmentManager.k(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new FragmentManager.k[param1Int];
    }
  }
  
  public static interface l {
    void onBackStackChanged();
  }
  
  public static interface m {
    boolean a(ArrayList<a> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  public class n implements m {
    public final int a;
    
    public final int b;
    
    public n(FragmentManager this$0, String param1String, int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
    
    public boolean a(ArrayList<a> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      Fragment fragment = this.c.u;
      return (fragment != null && this.a < 0 && fragment.getChildFragmentManager().X()) ? false : this.c.Y(param1ArrayList, param1ArrayList1, null, this.a, this.b);
    }
  }
  
  public static class o implements Fragment.k {
    public final boolean a;
    
    public final a b;
    
    public int c;
    
    public void a() {
      boolean bool;
      if (this.c > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      for (Fragment fragment : this.b.q.c.i()) {
        fragment.setOnStartEnterTransitionListener(null);
        if (bool && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
      } 
      a a1 = this.b;
      a1.q.g(a1, this.a, bool ^ true, true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\FragmentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */