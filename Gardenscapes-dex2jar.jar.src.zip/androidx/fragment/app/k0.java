package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;
import java.util.Collection;

public class k0 implements Runnable {
  public k0(Object paramObject1, p0 paramp0, View paramView, Fragment paramFragment, ArrayList paramArrayList1, ArrayList paramArrayList2, ArrayList paramArrayList3, Object paramObject2) {}
  
  public void run() {
    Object<View> object = (Object<View>)this.f;
    if (object != null) {
      this.g.o(object, this.h);
      object = (Object<View>)n0.h(this.g, this.f, this.i, this.j, this.h);
      this.k.addAll((Collection<? extends View>)object);
    } 
    if (this.l != null) {
      if (this.m != null) {
        object = (Object<View>)new ArrayList();
        object.add(this.h);
        this.g.p(this.m, this.l, (ArrayList<View>)object);
      } 
      this.l.clear();
      this.l.add(this.h);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\fragment\app\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */