package androidx.multidex;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v4.media.a;
import android.util.Log;
import c1.c;
import c1.d;
import j.f;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import v.a;

public final class MultiDexExtractor implements Closeable {
  public final File f;
  
  public final long g;
  
  public final File h;
  
  public final RandomAccessFile i;
  
  public final FileChannel j;
  
  public final FileLock k;
  
  public MultiDexExtractor(File paramFile1, File paramFile2) {
    StringBuilder stringBuilder = a.a("MultiDexExtractor(");
    stringBuilder.append(paramFile1.getPath());
    stringBuilder.append(", ");
    stringBuilder.append(paramFile2.getPath());
    stringBuilder.append(")");
    Log.i("MultiDex", stringBuilder.toString());
    this.f = paramFile1;
    this.h = paramFile2;
    this.g = g(paramFile1);
    paramFile1 = new File(paramFile2, "MultiDex.lock");
    RandomAccessFile randomAccessFile = new RandomAccessFile(paramFile1, "rw");
    this.i = randomAccessFile;
    try {
      FileChannel fileChannel = randomAccessFile.getChannel();
      this.j = fileChannel;
      try {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Blocking on lock ");
        stringBuilder.append(paramFile1.getPath());
        Log.i("MultiDex", stringBuilder.toString());
        this.k = fileChannel.lock();
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(paramFile1.getPath());
        stringBuilder1.append(" locked");
        Log.i("MultiDex", stringBuilder1.toString());
        return;
      } catch (IOException iOException) {
      
      } catch (RuntimeException runtimeException) {
      
      } catch (Error null) {}
    } catch (IOException iOException) {
    
    } catch (RuntimeException runtimeException) {
    
    } catch (Error error) {}
    a(this.i);
    throw error;
  }
  
  public static void a(Closeable paramCloseable) {
    try {
      paramCloseable.close();
      return;
    } catch (IOException iOException) {
      Log.w("MultiDex", "Failed to close resource", iOException);
      return;
    } 
  }
  
  public static void d(ZipFile paramZipFile, ZipEntry paramZipEntry, File paramFile, String paramString) {
    InputStream inputStream = paramZipFile.getInputStream(paramZipEntry);
    File file = File.createTempFile(f.a("tmp-", paramString), ".zip", paramFile.getParentFile());
    StringBuilder stringBuilder = a.a("Extracting ");
    stringBuilder.append(file.getPath());
    Log.i("MultiDex", stringBuilder.toString());
    try {
    
    } finally {
      a(inputStream);
      file.delete();
    } 
  }
  
  public static long f(File paramFile) {
    long l2 = paramFile.lastModified();
    long l1 = l2;
    if (l2 == -1L)
      l1 = l2 - 1L; 
    return l1;
  }
  
  public static long g(File paramFile) {
    RandomAccessFile randomAccessFile = new RandomAccessFile(paramFile, "r");
    try {
      d.a a = d.a(randomAccessFile);
      CRC32 cRC32 = new CRC32();
      long l1 = a.b;
      randomAccessFile.seek(a.a);
      int i = (int)Math.min(16384L, l1);
      byte[] arrayOfByte = new byte[16384];
      for (i = randomAccessFile.read(arrayOfByte, 0, i); i != -1; i = randomAccessFile.read(arrayOfByte, 0, (int)Math.min(16384L, l1))) {
        cRC32.update(arrayOfByte, 0, i);
        l1 -= i;
        if (l1 == 0L)
          break; 
      } 
      long l2 = cRC32.getValue();
      randomAccessFile.close();
      l1 = l2;
      return l1;
    } finally {
      randomAccessFile.close();
    } 
  }
  
  public static void q(Context paramContext, String paramString, long paramLong1, long paramLong2, List<ExtractedDex> paramList) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("multidex.version", 4).edit();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("timestamp");
    editor.putLong(stringBuilder.toString(), paramLong1);
    editor.putLong(a.a(new StringBuilder(), paramString, "crc"), paramLong2);
    stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("dex.number");
    editor.putInt(stringBuilder.toString(), paramList.size() + 1);
    Iterator<ExtractedDex> iterator = paramList.iterator();
    int i;
    for (i = 2; iterator.hasNext(); i++) {
      ExtractedDex extractedDex = iterator.next();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("dex.crc.");
      stringBuilder1.append(i);
      editor.putLong(stringBuilder1.toString(), extractedDex.crc);
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("dex.time.");
      stringBuilder1.append(i);
      editor.putLong(stringBuilder1.toString(), extractedDex.lastModified());
    } 
    editor.commit();
  }
  
  public void close() {
    this.k.release();
    this.j.close();
    this.i.close();
  }
  
  public List<? extends File> i(Context paramContext, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: ldc_w 'MultiDexExtractor.load('
    //   3: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   6: astore #7
    //   8: aload #7
    //   10: aload_0
    //   11: getfield f : Ljava/io/File;
    //   14: invokevirtual getPath : ()Ljava/lang/String;
    //   17: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   20: pop
    //   21: aload #7
    //   23: ldc ', '
    //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: pop
    //   29: aload #7
    //   31: iload_3
    //   32: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   35: pop
    //   36: aload #7
    //   38: ldc ', '
    //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   43: pop
    //   44: aload #7
    //   46: aload_2
    //   47: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: pop
    //   51: aload #7
    //   53: ldc ')'
    //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: pop
    //   59: ldc 'MultiDex'
    //   61: aload #7
    //   63: invokevirtual toString : ()Ljava/lang/String;
    //   66: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   69: pop
    //   70: aload_0
    //   71: getfield k : Ljava/nio/channels/FileLock;
    //   74: invokevirtual isValid : ()Z
    //   77: ifeq -> 365
    //   80: iload_3
    //   81: ifne -> 275
    //   84: aload_0
    //   85: getfield f : Ljava/io/File;
    //   88: astore #8
    //   90: aload_0
    //   91: getfield g : J
    //   94: lstore #5
    //   96: aload_1
    //   97: ldc_w 'multidex.version'
    //   100: iconst_4
    //   101: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   104: astore #7
    //   106: new java/lang/StringBuilder
    //   109: dup
    //   110: invokespecial <init> : ()V
    //   113: astore #9
    //   115: aload #9
    //   117: aload_2
    //   118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: pop
    //   122: aload #9
    //   124: ldc_w 'timestamp'
    //   127: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: pop
    //   131: aload #7
    //   133: aload #9
    //   135: invokevirtual toString : ()Ljava/lang/String;
    //   138: ldc2_w -1
    //   141: invokeinterface getLong : (Ljava/lang/String;J)J
    //   146: aload #8
    //   148: invokestatic f : (Ljava/io/File;)J
    //   151: lcmp
    //   152: ifne -> 210
    //   155: new java/lang/StringBuilder
    //   158: dup
    //   159: invokespecial <init> : ()V
    //   162: astore #8
    //   164: aload #8
    //   166: aload_2
    //   167: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: pop
    //   171: aload #8
    //   173: ldc_w 'crc'
    //   176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: pop
    //   180: aload #7
    //   182: aload #8
    //   184: invokevirtual toString : ()Ljava/lang/String;
    //   187: ldc2_w -1
    //   190: invokeinterface getLong : (Ljava/lang/String;J)J
    //   195: lload #5
    //   197: lcmp
    //   198: ifeq -> 204
    //   201: goto -> 210
    //   204: iconst_0
    //   205: istore #4
    //   207: goto -> 213
    //   210: iconst_1
    //   211: istore #4
    //   213: iload #4
    //   215: ifne -> 275
    //   218: aload_0
    //   219: aload_1
    //   220: aload_2
    //   221: invokevirtual k : (Landroid/content/Context;Ljava/lang/String;)Ljava/util/List;
    //   224: astore #7
    //   226: aload #7
    //   228: astore_1
    //   229: goto -> 327
    //   232: astore #7
    //   234: ldc 'MultiDex'
    //   236: ldc_w 'Failed to reload existing extracted secondary dex files, falling back to fresh extraction'
    //   239: aload #7
    //   241: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   244: pop
    //   245: aload_0
    //   246: invokevirtual l : ()Ljava/util/List;
    //   249: astore #7
    //   251: aload_1
    //   252: aload_2
    //   253: aload_0
    //   254: getfield f : Ljava/io/File;
    //   257: invokestatic f : (Ljava/io/File;)J
    //   260: aload_0
    //   261: getfield g : J
    //   264: aload #7
    //   266: invokestatic q : (Landroid/content/Context;Ljava/lang/String;JJLjava/util/List;)V
    //   269: aload #7
    //   271: astore_1
    //   272: goto -> 327
    //   275: iload_3
    //   276: ifeq -> 291
    //   279: ldc 'MultiDex'
    //   281: ldc_w 'Forced extraction must be performed.'
    //   284: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   287: pop
    //   288: goto -> 300
    //   291: ldc 'MultiDex'
    //   293: ldc_w 'Detected that extraction must be performed.'
    //   296: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   299: pop
    //   300: aload_0
    //   301: invokevirtual l : ()Ljava/util/List;
    //   304: astore #7
    //   306: aload_1
    //   307: aload_2
    //   308: aload_0
    //   309: getfield f : Ljava/io/File;
    //   312: invokestatic f : (Ljava/io/File;)J
    //   315: aload_0
    //   316: getfield g : J
    //   319: aload #7
    //   321: invokestatic q : (Landroid/content/Context;Ljava/lang/String;JJLjava/util/List;)V
    //   324: aload #7
    //   326: astore_1
    //   327: ldc_w 'load found '
    //   330: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   333: astore_2
    //   334: aload_2
    //   335: aload_1
    //   336: invokeinterface size : ()I
    //   341: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   344: pop
    //   345: aload_2
    //   346: ldc_w ' secondary dex files'
    //   349: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   352: pop
    //   353: ldc 'MultiDex'
    //   355: aload_2
    //   356: invokevirtual toString : ()Ljava/lang/String;
    //   359: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   362: pop
    //   363: aload_1
    //   364: areturn
    //   365: new java/lang/IllegalStateException
    //   368: dup
    //   369: ldc_w 'MultiDexExtractor was closed'
    //   372: invokespecial <init> : (Ljava/lang/String;)V
    //   375: athrow
    // Exception table:
    //   from	to	target	type
    //   218	226	232	java/io/IOException
  }
  
  public final List<ExtractedDex> k(Context paramContext, String paramString) {
    Log.i("MultiDex", "loading existing secondary dex files");
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(this.f.getName());
    stringBuilder2.append(".classes");
    String str2 = stringBuilder2.toString();
    SharedPreferences sharedPreferences = paramContext.getSharedPreferences("multidex.version", 4);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append("dex.number");
    int j = sharedPreferences.getInt(stringBuilder1.toString(), 1);
    ArrayList<ExtractedDex> arrayList = new ArrayList(j - 1);
    int i = 2;
    String str1 = str2;
    while (i <= j) {
      StringBuilder stringBuilder4 = new StringBuilder();
      stringBuilder4.append(str1);
      stringBuilder4.append(i);
      stringBuilder4.append(".zip");
      String str = stringBuilder4.toString();
      ExtractedDex extractedDex = new ExtractedDex(this.h, str);
      if (extractedDex.isFile()) {
        extractedDex.crc = g(extractedDex);
        StringBuilder stringBuilder6 = new StringBuilder();
        stringBuilder6.append(paramString);
        stringBuilder6.append("dex.crc.");
        stringBuilder6.append(i);
        long l1 = sharedPreferences.getLong(stringBuilder6.toString(), -1L);
        stringBuilder6 = new StringBuilder();
        stringBuilder6.append(paramString);
        stringBuilder6.append("dex.time.");
        stringBuilder6.append(i);
        long l2 = sharedPreferences.getLong(stringBuilder6.toString(), -1L);
        long l3 = extractedDex.lastModified();
        if (l2 == l3 && l1 == extractedDex.crc) {
          arrayList.add(extractedDex);
          i++;
          continue;
        } 
        StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append("Invalid extracted dex: ");
        stringBuilder5.append(extractedDex);
        stringBuilder5.append(" (key \"");
        stringBuilder5.append(paramString);
        stringBuilder5.append("\"), expected modification time: ");
        stringBuilder5.append(l2);
        stringBuilder5.append(", modification time: ");
        stringBuilder5.append(l3);
        stringBuilder5.append(", expected crc: ");
        stringBuilder5.append(l1);
        stringBuilder5.append(", file crc: ");
        stringBuilder5.append(extractedDex.crc);
        throw new IOException(stringBuilder5.toString());
      } 
      StringBuilder stringBuilder3 = a.a("Missing extracted secondary dex file '");
      stringBuilder3.append(extractedDex.getPath());
      stringBuilder3.append("'");
      throw new IOException(stringBuilder3.toString());
    } 
    return arrayList;
  }
  
  public final List<ExtractedDex> l() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.f.getName());
    stringBuilder.append(".classes");
    String str = stringBuilder.toString();
    File[] arrayOfFile = this.h.listFiles((FileFilter)new c(this));
    if (arrayOfFile == null) {
      null = a.a("Failed to list secondary dex dir content (");
      null.append(this.h.getPath());
      null.append(").");
      Log.w("MultiDex", null.toString());
    } else {
      int k = null.length;
      for (int j = 0; j < k; j++) {
        StringBuilder stringBuilder1 = null[j];
        StringBuilder stringBuilder2 = a.a("Trying to delete old file ");
        stringBuilder2.append(stringBuilder1.getPath());
        stringBuilder2.append(" of size ");
        stringBuilder2.append(stringBuilder1.length());
        Log.i("MultiDex", stringBuilder2.toString());
        if (!stringBuilder1.delete()) {
          stringBuilder2 = a.a("Failed to delete old file ");
          stringBuilder2.append(stringBuilder1.getPath());
          Log.w("MultiDex", stringBuilder2.toString());
        } else {
          stringBuilder2 = a.a("Deleted old file ");
          stringBuilder2.append(stringBuilder1.getPath());
          Log.i("MultiDex", stringBuilder2.toString());
        } 
      } 
    } 
    ArrayList<ExtractedDex> arrayList = new ArrayList();
    ZipFile zipFile = new ZipFile(this.f);
    int i = 2;
    try {
      ZipEntry zipEntry = zipFile.getEntry("classes2.dex");
      label59: while (true) {
        if (zipEntry != null) {
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append(str);
          stringBuilder2.append(i);
          stringBuilder2.append(".zip");
          String str1 = stringBuilder2.toString();
          ExtractedDex extractedDex = new ExtractedDex(this.h, str1);
          arrayList.add(extractedDex);
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Extraction is needed for file ");
          stringBuilder1.append(extractedDex);
          Log.i("MultiDex", stringBuilder1.toString());
          int j = 0;
          boolean bool = false;
          while (true) {
            if (j < 3 && !bool) {
              boolean bool1;
              String str2;
              int k = j + 1;
              d(zipFile, zipEntry, extractedDex, str);
              try {
                extractedDex.crc = g(extractedDex);
                bool1 = true;
              } catch (IOException iOException) {
                StringBuilder stringBuilder5 = new StringBuilder();
                stringBuilder5.append("Failed to read crc from ");
                stringBuilder5.append(extractedDex.getAbsolutePath());
                Log.w("MultiDex", stringBuilder5.toString(), iOException);
                bool1 = false;
              } 
              StringBuilder stringBuilder4 = new StringBuilder();
              stringBuilder4.append("Extraction ");
              if (bool1) {
                str2 = "succeeded";
              } else {
                str2 = "failed";
              } 
              stringBuilder4.append(str2);
              stringBuilder4.append(" '");
              stringBuilder4.append(extractedDex.getAbsolutePath());
              stringBuilder4.append("': length ");
              stringBuilder4.append(extractedDex.length());
              stringBuilder4.append(" - crc: ");
              stringBuilder4.append(extractedDex.crc);
              Log.i("MultiDex", stringBuilder4.toString());
              j = k;
              bool = bool1;
              if (!bool1) {
                extractedDex.delete();
                j = k;
                bool = bool1;
                if (extractedDex.exists()) {
                  StringBuilder stringBuilder5 = new StringBuilder();
                  stringBuilder5.append("Failed to delete corrupted secondary dex '");
                  stringBuilder5.append(extractedDex.getPath());
                  stringBuilder5.append("'");
                  Log.w("MultiDex", stringBuilder5.toString());
                  j = k;
                  bool = bool1;
                } 
              } 
              continue;
            } 
            if (bool) {
              i++;
              StringBuilder stringBuilder4 = new StringBuilder();
              stringBuilder4.append("classes");
              stringBuilder4.append(i);
              stringBuilder4.append(".dex");
              ZipEntry zipEntry1 = zipFile.getEntry(stringBuilder4.toString());
              continue label59;
            } 
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Could not create zip file ");
            stringBuilder3.append(extractedDex.getAbsolutePath());
            stringBuilder3.append(" for secondary dex (");
            stringBuilder3.append(i);
            stringBuilder3.append(")");
            throw new IOException(stringBuilder3.toString());
          } 
          break;
        } 
        try {
          return arrayList;
        } catch (IOException iOException) {
          return arrayList;
        } 
      } 
    } finally {
      try {
        zipFile.close();
      } catch (IOException iOException) {
        Log.w("MultiDex", "Failed to close resource", iOException);
      } 
    } 
  }
  
  public static class ExtractedDex extends File {
    public long crc = -1L;
    
    public ExtractedDex(File param1File, String param1String) {
      super(param1File, param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\multidex\MultiDexExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */