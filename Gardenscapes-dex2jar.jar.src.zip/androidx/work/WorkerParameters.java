package androidx.work;

import android.net.Network;
import android.net.Uri;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import p1.e;
import p1.l;
import p1.q;

public final class WorkerParameters {
  public UUID a;
  
  public b b;
  
  public Set<String> c;
  
  public a d;
  
  public int e;
  
  public Executor f;
  
  public b2.a g;
  
  public q h;
  
  public l i;
  
  public e j;
  
  public WorkerParameters(UUID paramUUID, b paramb, Collection<String> paramCollection, a parama, int paramInt, Executor paramExecutor, b2.a parama1, q paramq, l paraml, e parame) {
    this.a = paramUUID;
    this.b = paramb;
    this.c = new HashSet<String>(paramCollection);
    this.d = parama;
    this.e = paramInt;
    this.f = paramExecutor;
    this.g = parama1;
    this.h = paramq;
    this.i = paraml;
    this.j = parame;
  }
  
  public static class a {
    public List<String> a = Collections.emptyList();
    
    public List<Uri> b = Collections.emptyList();
    
    public Network c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\WorkerParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */