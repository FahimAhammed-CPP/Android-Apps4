package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import java.util.Collections;
import java.util.List;
import p1.i;
import q1.k;
import u1.c;
import u1.d;
import y1.p;
import y1.q;
import y1.r;

public class ConstraintTrackingWorker extends ListenableWorker implements c {
  public static final String k = i.e("ConstraintTrkngWrkr");
  
  public WorkerParameters f;
  
  public final Object g;
  
  public volatile boolean h;
  
  public a2.a<ListenableWorker.a> i;
  
  public ListenableWorker j;
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.f = paramWorkerParameters;
    this.g = new Object();
    this.h = false;
    this.i = new a2.a();
  }
  
  public void a() {
    this.i.k(new ListenableWorker.a.a());
  }
  
  public void b() {
    this.i.k(new ListenableWorker.a.b());
  }
  
  public void c(List<String> paramList) {
    i.c().a(k, String.format("Constraints changed for %s", new Object[] { paramList }), new Throwable[0]);
    synchronized (this.g) {
      this.h = true;
      return;
    } 
  }
  
  public void d(List<String> paramList) {}
  
  public b2.a getTaskExecutor() {
    return (k.b(getApplicationContext())).d;
  }
  
  public boolean isRunInForeground() {
    ListenableWorker listenableWorker = this.j;
    return (listenableWorker != null && listenableWorker.isRunInForeground());
  }
  
  public void onStopped() {
    super.onStopped();
    ListenableWorker listenableWorker = this.j;
    if (listenableWorker != null && !listenableWorker.isStopped())
      this.j.stop(); 
  }
  
  public m7.a<ListenableWorker.a> startWork() {
    getBackgroundExecutor().execute(new a(this));
    return (m7.a<ListenableWorker.a>)this.i;
  }
  
  public class a implements Runnable {
    public a(ConstraintTrackingWorker this$0) {}
    
    public void run() {
      ConstraintTrackingWorker constraintTrackingWorker = this.f;
      String str1 = constraintTrackingWorker.getInputData().c("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
      if (TextUtils.isEmpty(str1)) {
        i.c().b(ConstraintTrackingWorker.k, "No worker to delegate to.", new Throwable[0]);
        constraintTrackingWorker.a();
        return;
      } 
      ListenableWorker listenableWorker = constraintTrackingWorker.getWorkerFactory().a(constraintTrackingWorker.getApplicationContext(), str1, constraintTrackingWorker.f);
      constraintTrackingWorker.j = listenableWorker;
      if (listenableWorker == null) {
        i.c().a(ConstraintTrackingWorker.k, "No worker to delegate to.", new Throwable[0]);
        constraintTrackingWorker.a();
        return;
      } 
      q q = (k.b(constraintTrackingWorker.getApplicationContext())).c.q();
      String str2 = constraintTrackingWorker.getId().toString();
      p p = ((r)q).i(str2);
      if (p == null) {
        constraintTrackingWorker.a();
        return;
      } 
      d d = new d(constraintTrackingWorker.getApplicationContext(), constraintTrackingWorker.getTaskExecutor(), constraintTrackingWorker);
      d.b(Collections.singletonList(p));
      if (d.a(constraintTrackingWorker.getId().toString())) {
        i.c().a(ConstraintTrackingWorker.k, String.format("Constraints met for delegate %s", new Object[] { str1 }), new Throwable[0]);
        try {
          return;
        } finally {
          d = null;
          i i = i.c();
          String str = ConstraintTrackingWorker.k;
          i.a(str, String.format("Delegated worker %s threw exception in startWork.", new Object[] { str1 }), new Throwable[] { (Throwable)d });
        } 
      } 
      i.c().a(ConstraintTrackingWorker.k, String.format("Constraints not met for delegate %s. Requesting retry.", new Object[] { str1 }), new Throwable[0]);
      constraintTrackingWorker.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */