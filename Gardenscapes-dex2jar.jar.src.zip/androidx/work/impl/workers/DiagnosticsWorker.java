package androidx.work.impl.workers;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.b;
import androidx.work.impl.WorkDatabase;
import f1.f;
import h1.b;
import i.d;
import i1.d;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import p1.b;
import p1.i;
import q1.k;
import y1.g;
import y1.h;
import y1.i;
import y1.k;
import y1.l;
import y1.p;
import y1.q;
import y1.r;
import y1.t;
import y1.u;
import y1.v;

public class DiagnosticsWorker extends Worker {
  public static final String a = i.e("DiagnosticsWrkr");
  
  public DiagnosticsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public static String a(k paramk, t paramt, h paramh, List<p> paramList) {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    if (Build.VERSION.SDK_INT >= 23) {
      str = "Job Id";
    } else {
      str = "Alarm Id";
    } 
    stringBuilder.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", new Object[] { str }));
    for (p p : paramList) {
      String str2;
      String str1 = p.a;
      g g = ((i)paramh).a(str1);
      if (g != null) {
        Integer integer = Integer.valueOf(g.b);
      } else {
        g = null;
      } 
      String str3 = p.a;
      l l = (l)paramk;
      Objects.requireNonNull(l);
      f f = f.a("SELECT name FROM workname WHERE work_spec_id=?", 1);
      if (str3 == null) {
        f.i(1);
      } else {
        f.k(1, str3);
      } 
      l.a.b();
      Cursor cursor = b.a(l.a, (d)f, false, null);
      try {
        ArrayList<String> arrayList = new ArrayList(cursor.getCount());
        while (cursor.moveToNext())
          arrayList.add(cursor.getString(0)); 
        cursor.close();
        f.l();
        String str4 = p.a;
        List list = ((u)paramt).a(str4);
        String str5 = TextUtils.join(",", arrayList);
      } finally {
        cursor.close();
        str2.l();
      } 
    } 
    return stringBuilder.toString();
  }
  
  public ListenableWorker.a doWork() {
    List<p> list;
    String str;
    WorkDatabase workDatabase = (k.b(getApplicationContext())).c;
    q q = workDatabase.q();
    k k = workDatabase.o();
    t t = workDatabase.r();
    h h = workDatabase.n();
    long l1 = System.currentTimeMillis();
    long l2 = TimeUnit.DAYS.toMillis(1L);
    r r = (r)q;
    Objects.requireNonNull(r);
    f f = f.a("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC", 1);
    f.g(1, l1 - l2);
    r.a.b();
    Cursor cursor = b.a(r.a, (d)f, false, null);
    try {
      int m = d.b(cursor, "required_network_type");
      int i2 = d.b(cursor, "requires_charging");
      int i = d.b(cursor, "requires_device_idle");
      int i6 = d.b(cursor, "requires_battery_not_low");
      int i7 = d.b(cursor, "requires_storage_not_low");
      int i8 = d.b(cursor, "trigger_content_update_delay");
      int i9 = d.b(cursor, "trigger_max_content_delay");
      int i10 = d.b(cursor, "content_uri_triggers");
      int n = d.b(cursor, "id");
      int j = d.b(cursor, "state");
      int i3 = d.b(cursor, "worker_class_name");
      int i1 = d.b(cursor, "input_merger_class_name");
      int i4 = d.b(cursor, "input");
      int i5 = d.b(cursor, "output");
      try {
        int i17 = d.b(cursor, "initial_delay");
        int i18 = d.b(cursor, "interval_duration");
        int i21 = d.b(cursor, "flex_duration");
        int i16 = d.b(cursor, "run_attempt_count");
        int i11 = d.b(cursor, "backoff_policy");
        int i12 = d.b(cursor, "backoff_delay_duration");
        int i20 = d.b(cursor, "period_start_time");
        int i14 = d.b(cursor, "minimum_retention_duration");
        int i15 = d.b(cursor, "schedule_requested_at");
        int i13 = d.b(cursor, "run_in_foreground");
        int i19 = d.b(cursor, "out_of_quota_policy");
        ArrayList<p> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(n);
            String str2 = cursor.getString(i3);
            b b = new b();
            b.a = v.c(cursor.getInt(m));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            b.b = bool;
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            b.c = bool;
            if (cursor.getInt(i6) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            b.d = bool;
            if (cursor.getInt(i7) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            b.e = bool;
            b.f = cursor.getLong(i8);
            b.g = cursor.getLong(i9);
            b.h = v.a(cursor.getBlob(i10));
            p p = new p(str1, str2);
            p.b = v.e(cursor.getInt(j));
            p.d = cursor.getString(i1);
            p.e = b.a(cursor.getBlob(i4));
            p.f = b.a(cursor.getBlob(i5));
            p.g = cursor.getLong(i17);
            p.h = cursor.getLong(i18);
            p.i = cursor.getLong(i21);
            p.k = cursor.getInt(i16);
            p.l = v.b(cursor.getInt(i11));
            p.m = cursor.getLong(i12);
            p.n = cursor.getLong(i20);
            p.o = cursor.getLong(i14);
            p.p = cursor.getLong(i15);
            if (cursor.getInt(i13) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            p.q = bool;
            p.r = v.d(cursor.getInt(i19));
            p.j = b;
            arrayList.add(p);
            continue;
          } 
          cursor.close();
          f.l();
          r r1 = (r)q;
          List<p> list1 = r1.d();
          list = r1.b(200);
          if (!arrayList.isEmpty()) {
            i i22 = i.c();
            String str1 = a;
            i22.d(str1, "Recently completed work:\n\n", new Throwable[0]);
            i.c().d(str1, a(k, t, h, arrayList), new Throwable[0]);
          } 
          if (!((ArrayList)list1).isEmpty()) {
            i i22 = i.c();
            String str1 = a;
            i22.d(str1, "Running work:\n\n", new Throwable[0]);
            i.c().d(str1, a(k, t, h, list1), new Throwable[0]);
          } 
          if (!((ArrayList)list).isEmpty()) {
            i i22 = i.c();
            str = a;
            i22.d(str, "Enqueued work:\n\n", new Throwable[0]);
            i.c().d(str, a(k, t, h, list), new Throwable[0]);
          } 
          return (ListenableWorker.a)new ListenableWorker.a.c();
        } 
      } finally {}
    } finally {}
    str.close();
    list.l();
    throw k;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\workers\DiagnosticsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */