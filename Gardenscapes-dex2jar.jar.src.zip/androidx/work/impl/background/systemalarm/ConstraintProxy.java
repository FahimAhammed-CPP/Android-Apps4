package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import p1.i;

public abstract class ConstraintProxy extends BroadcastReceiver {
  public static final String a = i.e("ConstraintProxy");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    i.c().a(a, String.format("onReceive : %s", new Object[] { paramIntent }), new Throwable[0]);
    paramContext.startService(a.b(paramContext));
  }
  
  public static class BatteryChargingProxy extends ConstraintProxy {}
  
  public static class BatteryNotLowProxy extends ConstraintProxy {}
  
  public static class NetworkStateProxy extends ConstraintProxy {}
  
  public static class StorageNotLowProxy extends ConstraintProxy {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\background\systemalarm\ConstraintProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */