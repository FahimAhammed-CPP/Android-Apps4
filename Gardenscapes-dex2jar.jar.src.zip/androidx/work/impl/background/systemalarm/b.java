package androidx.work.impl.background.systemalarm;

import android.content.Context;
import p1.i;
import u1.d;

public class b {
  public static final String e = i.e("ConstraintsCmdHandler");
  
  public final Context a;
  
  public final int b;
  
  public final d c;
  
  public final d d;
  
  public b(Context paramContext, int paramInt, d paramd) {
    this.a = paramContext;
    this.b = paramInt;
    this.c = paramd;
    this.d = new d(paramContext, paramd.g, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\background\systemalarm\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */