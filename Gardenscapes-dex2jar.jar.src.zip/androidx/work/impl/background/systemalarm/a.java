package androidx.work.impl.background.systemalarm;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.work.NetworkType;
import androidx.work.impl.WorkDatabase;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import p1.b;
import p1.i;
import q1.b;
import q1.k;
import y1.g;
import y1.i;
import y1.p;
import y1.r;

public class a implements b {
  public static final String i = i.e("CommandHandler");
  
  public final Context f;
  
  public final Map<String, b> g;
  
  public final Object h;
  
  public a(Context paramContext) {
    this.f = paramContext;
    this.g = new HashMap<String, b>();
    this.h = new Object();
  }
  
  public static Intent b(Context paramContext) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_CONSTRAINTS_CHANGED");
    return intent;
  }
  
  public static Intent c(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_DELAY_MET");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent d(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_SCHEDULE_WORK");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public void a(String paramString, boolean paramBoolean) {
    synchronized (this.h) {
      b b1 = this.g.remove(paramString);
      if (b1 != null)
        b1.a(paramString, paramBoolean); 
      return;
    } 
  }
  
  public void e(Intent paramIntent, int paramInt, d paramd) {
    b b1;
    WorkDatabase workDatabase;
    String str1;
    Iterator<p> iterator;
    int i;
    d.b b2;
    String str2;
    Context context;
    String str3 = paramIntent.getAction();
    if ("ACTION_CONSTRAINTS_CHANGED".equals(str3)) {
      boolean bool4;
      int k;
      boolean bool5;
      boolean bool6;
      i.c().a(i, String.format("Handling constraints changed %s", new Object[] { paramIntent }), new Throwable[0]);
      context = this.f;
      b1 = new b(context, paramInt, paramd);
      List<p> list = ((r)paramd.j.c.q()).e();
      String str4 = ConstraintProxy.a;
      ArrayList arrayList = (ArrayList)list;
      Iterator iterator1 = arrayList.iterator();
      boolean bool3 = false;
      boolean bool2 = false;
      boolean bool1 = false;
      int j = 0;
      while (true) {
        bool4 = bool3;
        bool5 = bool2;
        bool6 = bool1;
        k = j;
        if (iterator1.hasNext()) {
          b b3 = ((p)iterator1.next()).j;
          bool4 = bool3 | b3.d;
          bool5 = bool2 | b3.b;
          bool6 = bool1 | b3.e;
          if (b3.a != NetworkType.f) {
            paramInt = 1;
          } else {
            paramInt = 0;
          } 
          k = j | paramInt;
          bool3 = bool4;
          bool2 = bool5;
          bool1 = bool6;
          j = k;
          if (bool4) {
            bool3 = bool4;
            bool2 = bool5;
            bool1 = bool6;
            j = k;
            if (bool5) {
              bool3 = bool4;
              bool2 = bool5;
              bool1 = bool6;
              j = k;
              if (bool6) {
                bool3 = bool4;
                bool2 = bool5;
                bool1 = bool6;
                j = k;
                if (k != 0)
                  break; 
              } 
            } 
          } 
          continue;
        } 
        break;
      } 
      String str5 = ConstraintProxyUpdateReceiver.a;
      Intent intent = new Intent("androidx.work.impl.background.systemalarm.UpdateProxies");
      intent.setComponent(new ComponentName(context, ConstraintProxyUpdateReceiver.class));
      intent.putExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", bool4).putExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", bool5).putExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", bool6).putExtra("KEY_NETWORK_STATE_PROXY_ENABLED", k);
      context.sendBroadcast(intent);
      b1.d.b(list);
      list = new ArrayList(arrayList.size());
      long l = System.currentTimeMillis();
      for (p p : arrayList) {
        String str = p.a;
        if (l >= p.a() && (!p.b() || b1.d.a(str)))
          list.add(p); 
      } 
      iterator = list.iterator();
      while (iterator.hasNext()) {
        String str = ((p)iterator.next()).a;
        Intent intent1 = c(b1.a, str);
        i.c().a(b.e, String.format("Creating a delay_met command for workSpec with id (%s)", new Object[] { str }), new Throwable[0]);
        d d1 = b1.c;
        b2 = new d.b(d1, intent1, b1.b);
        d1.l.post(b2);
      } 
      b1.d.c();
      return;
    } 
    if ("ACTION_RESCHEDULE".equals(b2)) {
      i.c().a(i, String.format("Handling reschedule %s, %s", new Object[] { b1, Integer.valueOf(paramInt) }), new Throwable[0]);
      ((d)iterator).j.e();
      return;
    } 
    Bundle bundle = b1.getExtras();
    if (bundle == null || bundle.isEmpty()) {
      i = 0;
    } else {
      for (i = 0; i < 1; i++) {
        (new String[1])[0] = "KEY_WORKSPEC_ID";
        if (bundle.get((new String[1])[i]) == null)
          // Byte code: goto -> 693 
      } 
      i = 1;
    } 
    if (i == 0) {
      i.c().b(i, String.format("Invalid request for %s, requires %s.", new Object[] { b2, "KEY_WORKSPEC_ID" }), new Throwable[0]);
      return;
    } 
    if ("ACTION_SCHEDULE_WORK".equals(b2)) {
      str2 = b1.getExtras().getString("KEY_WORKSPEC_ID");
      i i1 = i.c();
      String str = i;
      i1.a(str, String.format("Handling schedule work for %s", new Object[] { str2 }), new Throwable[0]);
      workDatabase = ((d)iterator).j.c;
      workDatabase.c();
      try {
        StringBuilder stringBuilder;
        p p = ((r)workDatabase.q()).i(str2);
        if (p == null) {
          i i2 = i.c();
          stringBuilder = new StringBuilder();
          stringBuilder.append("Skipping scheduling ");
          stringBuilder.append(str2);
          stringBuilder.append(" because it's no longer in the DB");
          i2.f(str, stringBuilder.toString(), new Throwable[0]);
        } else {
          i i2;
          if (((p)stringBuilder).b.b()) {
            i2 = i.c();
            stringBuilder = new StringBuilder();
            stringBuilder.append("Skipping scheduling ");
            stringBuilder.append(str2);
            stringBuilder.append("because it is finished.");
            i2.f(str, stringBuilder.toString(), new Throwable[0]);
          } else {
            long l = stringBuilder.a();
            if (!stringBuilder.b()) {
              i.c().a(str, String.format("Setting up Alarms for %s at %s", new Object[] { str2, Long.valueOf(l) }), new Throwable[0]);
              s1.a.b(this.f, ((d)i2).j, str2, l);
            } else {
              i.c().a(str, String.format("Opportunistically setting an alarm for %s at %s", new Object[] { str2, Long.valueOf(l) }), new Throwable[0]);
              s1.a.b(this.f, ((d)i2).j, str2, l);
              b2 = new d.b((d)i2, b(this.f), paramInt);
              ((d)i2).l.post(b2);
            } 
            workDatabase.k();
          } 
        } 
        return;
      } finally {
        workDatabase.g();
      } 
    } 
    if ("ACTION_DELAY_MET".equals(b2)) {
      Bundle bundle1 = workDatabase.getExtras();
      synchronized (this.h) {
        str2 = bundle1.getString("KEY_WORKSPEC_ID");
        i i1 = i.c();
        String str = i;
        i1.a(str, String.format("Handing delay met for %s", new Object[] { str2 }), new Throwable[0]);
        if (!this.g.containsKey(str2)) {
          c c = new c(this.f, paramInt, str2, (d)iterator);
          this.g.put(str2, c);
          c.f();
        } else {
          i.c().a(str, String.format("WorkSpec %s is already being handled for ACTION_DELAY_MET", new Object[] { str2 }), new Throwable[0]);
        } 
        return;
      } 
    } 
    if ("ACTION_STOP_WORK".equals(str2)) {
      str1 = workDatabase.getExtras().getString("KEY_WORKSPEC_ID");
      i.c().a(i, String.format("Handing stopWork work for %s", new Object[] { str1 }), new Throwable[0]);
      ((d)iterator).j.f(str1);
      context = this.f;
      k k = ((d)iterator).j;
      String str = s1.a.a;
      i i1 = (i)k.c.n();
      g g = i1.a(str1);
      if (g != null) {
        s1.a.a(context, str1, g.b);
        i.c().a(s1.a.a, String.format("Removing SystemIdInfo for workSpecId (%s)", new Object[] { str1 }), new Throwable[0]);
        i1.c(str1);
      } 
      iterator.a(str1, false);
      return;
    } 
    if ("ACTION_EXECUTION_COMPLETED".equals(context)) {
      Bundle bundle1 = str1.getExtras();
      String str = bundle1.getString("KEY_WORKSPEC_ID");
      boolean bool = bundle1.getBoolean("KEY_NEEDS_RESCHEDULE");
      i.c().a(i, String.format("Handling onExecutionCompleted %s, %s", new Object[] { str1, Integer.valueOf(paramInt) }), new Throwable[0]);
      a(str, bool);
      return;
    } 
    i.c().f(i, String.format("Ignoring intent %s", new Object[] { str1 }), new Throwable[0]);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\background\systemalarm\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */