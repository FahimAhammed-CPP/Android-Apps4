package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import b2.b;
import p1.i;
import q1.k;
import z1.g;

public class ConstraintProxyUpdateReceiver extends BroadcastReceiver {
  public static final String a = i.e("ConstrntProxyUpdtRecvr");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent != null) {
      a1 = (b2.a)paramIntent.getAction();
    } else {
      a1 = null;
    } 
    if (!"androidx.work.impl.background.systemalarm.UpdateProxies".equals(a1)) {
      i.c().a(a, String.format("Ignoring unknown action %s", new Object[] { a1 }), new Throwable[0]);
      return;
    } 
    BroadcastReceiver.PendingResult pendingResult = goAsync();
    b2.a a1 = (k.b(paramContext)).d;
    a a = new a(this, paramIntent, paramContext, pendingResult);
    ((b)a1).a.execute(a);
  }
  
  public class a implements Runnable {
    public a(ConstraintProxyUpdateReceiver this$0, Intent param1Intent, Context param1Context, BroadcastReceiver.PendingResult param1PendingResult) {}
    
    public void run() {
      try {
        boolean bool1 = this.f.getBooleanExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", false);
        boolean bool2 = this.f.getBooleanExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", false);
        boolean bool3 = this.f.getBooleanExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", false);
        boolean bool4 = this.f.getBooleanExtra("KEY_NETWORK_STATE_PROXY_ENABLED", false);
        i.c().a(ConstraintProxyUpdateReceiver.a, String.format("Updating proxies: BatteryNotLowProxy enabled (%s), BatteryChargingProxy enabled (%s), StorageNotLowProxy (%s), NetworkStateProxy enabled (%s)", new Object[] { Boolean.valueOf(bool1), Boolean.valueOf(bool2), Boolean.valueOf(bool3), Boolean.valueOf(bool4) }), new Throwable[0]);
        g.a(this.g, ConstraintProxy.BatteryNotLowProxy.class, bool1);
        g.a(this.g, ConstraintProxy.BatteryChargingProxy.class, bool2);
        g.a(this.g, ConstraintProxy.StorageNotLowProxy.class, bool3);
        g.a(this.g, ConstraintProxy.NetworkStateProxy.class, bool4);
        return;
      } finally {
        this.h.finish();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\impl\background\systemalarm\ConstraintProxyUpdateReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */