package androidx.work.impl.utils.futures;

import java.util.concurrent.Executor;

public enum DirectExecutor implements Executor {
  f;
  
  static {
    DirectExecutor directExecutor = new DirectExecutor("INSTANCE", 0);
    f = directExecutor;
    g = new DirectExecutor[] { directExecutor };
  }
  
  public void execute(Runnable paramRunnable) {
    paramRunnable.run();
  }
  
  public String toString() {
    return "DirectExecutor";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\imp\\utils\futures\DirectExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */