package androidx.work.impl.utils;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteTableLockedException;
import android.text.TextUtils;
import android.util.Log;
import androidx.work.a;
import i0.a;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import p1.i;
import q1.j;
import q1.k;
import z1.i;

public class ForceStopRunnable implements Runnable {
  public static final String i = i.e("ForceStopRunnable");
  
  public static final long j = TimeUnit.DAYS.toMillis(3650L);
  
  public final Context f;
  
  public final k g;
  
  public int h;
  
  public ForceStopRunnable(Context paramContext, k paramk) {
    this.f = paramContext.getApplicationContext();
    this.g = paramk;
    this.h = 0;
  }
  
  public static PendingIntent b(Context paramContext, int paramInt) {
    Intent intent = new Intent();
    intent.setComponent(new ComponentName(paramContext, BroadcastReceiver.class));
    intent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
    return PendingIntent.getBroadcast(paramContext, -1, intent, paramInt);
  }
  
  @SuppressLint({"ClassVerificationFailure"})
  public static void d(Context paramContext) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    if (a.a()) {
      i = 167772160;
    } else {
      i = 134217728;
    } 
    PendingIntent pendingIntent = b(paramContext, i);
    long l1 = System.currentTimeMillis();
    long l2 = j;
    if (alarmManager != null)
      alarmManager.setExact(0, l1 + l2, pendingIntent); 
  }
  
  public void a() {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: istore_1
    //   4: iconst_1
    //   5: istore_3
    //   6: iload_1
    //   7: bipush #23
    //   9: if_icmplt -> 438
    //   12: aload_0
    //   13: getfield f : Landroid/content/Context;
    //   16: astore #5
    //   18: aload_0
    //   19: getfield g : Lq1/k;
    //   22: astore #4
    //   24: getstatic t1/b.j : Ljava/lang/String;
    //   27: astore #6
    //   29: aload #5
    //   31: ldc 'jobscheduler'
    //   33: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   36: checkcast android/app/job/JobScheduler
    //   39: astore #6
    //   41: aload #5
    //   43: aload #6
    //   45: invokestatic d : (Landroid/content/Context;Landroid/app/job/JobScheduler;)Ljava/util/List;
    //   48: astore #8
    //   50: aload #4
    //   52: getfield c : Landroidx/work/impl/WorkDatabase;
    //   55: invokevirtual n : ()Ly1/h;
    //   58: checkcast y1/i
    //   61: astore #5
    //   63: aload #5
    //   65: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   68: pop
    //   69: ldc 'SELECT DISTINCT work_spec_id FROM SystemIdInfo'
    //   71: iconst_0
    //   72: invokestatic a : (Ljava/lang/String;I)Lf1/f;
    //   75: astore #7
    //   77: aload #5
    //   79: getfield a : Landroidx/room/RoomDatabase;
    //   82: invokevirtual b : ()V
    //   85: aload #5
    //   87: getfield a : Landroidx/room/RoomDatabase;
    //   90: aload #7
    //   92: iconst_0
    //   93: aconst_null
    //   94: invokestatic a : (Landroidx/room/RoomDatabase;Li1/d;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;
    //   97: astore #9
    //   99: new java/util/ArrayList
    //   102: dup
    //   103: aload #9
    //   105: invokeinterface getCount : ()I
    //   110: invokespecial <init> : (I)V
    //   113: astore #5
    //   115: aload #9
    //   117: invokeinterface moveToNext : ()Z
    //   122: ifeq -> 142
    //   125: aload #5
    //   127: aload #9
    //   129: iconst_0
    //   130: invokeinterface getString : (I)Ljava/lang/String;
    //   135: invokevirtual add : (Ljava/lang/Object;)Z
    //   138: pop
    //   139: goto -> 115
    //   142: aload #9
    //   144: invokeinterface close : ()V
    //   149: aload #7
    //   151: invokevirtual l : ()V
    //   154: aload #8
    //   156: ifnull -> 170
    //   159: aload #8
    //   161: invokeinterface size : ()I
    //   166: istore_1
    //   167: goto -> 172
    //   170: iconst_0
    //   171: istore_1
    //   172: new java/util/HashSet
    //   175: dup
    //   176: iload_1
    //   177: invokespecial <init> : (I)V
    //   180: astore #7
    //   182: aload #8
    //   184: ifnull -> 267
    //   187: aload #8
    //   189: invokeinterface isEmpty : ()Z
    //   194: ifne -> 267
    //   197: aload #8
    //   199: invokeinterface iterator : ()Ljava/util/Iterator;
    //   204: astore #8
    //   206: aload #8
    //   208: invokeinterface hasNext : ()Z
    //   213: ifeq -> 267
    //   216: aload #8
    //   218: invokeinterface next : ()Ljava/lang/Object;
    //   223: checkcast android/app/job/JobInfo
    //   226: astore #9
    //   228: aload #9
    //   230: invokestatic g : (Landroid/app/job/JobInfo;)Ljava/lang/String;
    //   233: astore #10
    //   235: aload #10
    //   237: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   240: ifne -> 254
    //   243: aload #7
    //   245: aload #10
    //   247: invokevirtual add : (Ljava/lang/Object;)Z
    //   250: pop
    //   251: goto -> 206
    //   254: aload #6
    //   256: aload #9
    //   258: invokevirtual getId : ()I
    //   261: invokestatic a : (Landroid/app/job/JobScheduler;I)V
    //   264: goto -> 206
    //   267: aload #5
    //   269: invokevirtual iterator : ()Ljava/util/Iterator;
    //   272: astore #6
    //   274: aload #6
    //   276: invokeinterface hasNext : ()Z
    //   281: ifeq -> 323
    //   284: aload #7
    //   286: aload #6
    //   288: invokeinterface next : ()Ljava/lang/Object;
    //   293: checkcast java/lang/String
    //   296: invokevirtual contains : (Ljava/lang/Object;)Z
    //   299: ifne -> 274
    //   302: invokestatic c : ()Lp1/i;
    //   305: getstatic t1/b.j : Ljava/lang/String;
    //   308: ldc_w 'Reconciling jobs'
    //   311: iconst_0
    //   312: anewarray java/lang/Throwable
    //   315: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   318: iconst_1
    //   319: istore_1
    //   320: goto -> 325
    //   323: iconst_0
    //   324: istore_1
    //   325: iload_1
    //   326: istore_2
    //   327: iload_1
    //   328: ifeq -> 440
    //   331: aload #4
    //   333: getfield c : Landroidx/work/impl/WorkDatabase;
    //   336: astore #4
    //   338: aload #4
    //   340: invokevirtual c : ()V
    //   343: aload #4
    //   345: invokevirtual q : ()Ly1/q;
    //   348: astore #6
    //   350: aload #5
    //   352: invokevirtual iterator : ()Ljava/util/Iterator;
    //   355: astore #5
    //   357: aload #5
    //   359: invokeinterface hasNext : ()Z
    //   364: ifeq -> 396
    //   367: aload #5
    //   369: invokeinterface next : ()Ljava/lang/Object;
    //   374: checkcast java/lang/String
    //   377: astore #7
    //   379: aload #6
    //   381: checkcast y1/r
    //   384: aload #7
    //   386: ldc2_w -1
    //   389: invokevirtual l : (Ljava/lang/String;J)I
    //   392: pop
    //   393: goto -> 357
    //   396: aload #4
    //   398: invokevirtual k : ()V
    //   401: aload #4
    //   403: invokevirtual g : ()V
    //   406: iload_1
    //   407: istore_2
    //   408: goto -> 440
    //   411: astore #5
    //   413: aload #4
    //   415: invokevirtual g : ()V
    //   418: aload #5
    //   420: athrow
    //   421: astore #4
    //   423: aload #9
    //   425: invokeinterface close : ()V
    //   430: aload #7
    //   432: invokevirtual l : ()V
    //   435: aload #4
    //   437: athrow
    //   438: iconst_0
    //   439: istore_2
    //   440: aload_0
    //   441: getfield g : Lq1/k;
    //   444: getfield c : Landroidx/work/impl/WorkDatabase;
    //   447: astore #4
    //   449: aload #4
    //   451: invokevirtual q : ()Ly1/q;
    //   454: astore #6
    //   456: aload #4
    //   458: invokevirtual p : ()Ly1/n;
    //   461: astore #5
    //   463: aload #4
    //   465: invokevirtual c : ()V
    //   468: aload #6
    //   470: checkcast y1/r
    //   473: astore #6
    //   475: aload #6
    //   477: invokevirtual d : ()Ljava/util/List;
    //   480: astore #7
    //   482: aload #7
    //   484: checkcast java/util/ArrayList
    //   487: invokevirtual isEmpty : ()Z
    //   490: iconst_1
    //   491: ixor
    //   492: istore_1
    //   493: iload_1
    //   494: ifeq -> 567
    //   497: aload #7
    //   499: checkcast java/util/ArrayList
    //   502: invokevirtual iterator : ()Ljava/util/Iterator;
    //   505: astore #7
    //   507: aload #7
    //   509: invokeinterface hasNext : ()Z
    //   514: ifeq -> 567
    //   517: aload #7
    //   519: invokeinterface next : ()Ljava/lang/Object;
    //   524: checkcast y1/p
    //   527: astore #8
    //   529: aload #6
    //   531: getstatic androidx/work/WorkInfo$State.f : Landroidx/work/WorkInfo$State;
    //   534: iconst_1
    //   535: anewarray java/lang/String
    //   538: dup
    //   539: iconst_0
    //   540: aload #8
    //   542: getfield a : Ljava/lang/String;
    //   545: aastore
    //   546: invokevirtual p : (Landroidx/work/WorkInfo$State;[Ljava/lang/String;)I
    //   549: pop
    //   550: aload #6
    //   552: aload #8
    //   554: getfield a : Ljava/lang/String;
    //   557: ldc2_w -1
    //   560: invokevirtual l : (Ljava/lang/String;J)I
    //   563: pop
    //   564: goto -> 507
    //   567: aload #5
    //   569: checkcast y1/o
    //   572: invokevirtual b : ()V
    //   575: aload #4
    //   577: invokevirtual k : ()V
    //   580: aload #4
    //   582: invokevirtual g : ()V
    //   585: iload_1
    //   586: ifne -> 601
    //   589: iload_2
    //   590: ifeq -> 596
    //   593: goto -> 601
    //   596: iconst_0
    //   597: istore_1
    //   598: goto -> 603
    //   601: iconst_1
    //   602: istore_1
    //   603: aload_0
    //   604: getfield g : Lq1/k;
    //   607: getfield g : Lz1/h;
    //   610: getfield a : Landroidx/work/impl/WorkDatabase;
    //   613: invokevirtual m : ()Ly1/e;
    //   616: checkcast y1/f
    //   619: ldc_w 'reschedule_needed'
    //   622: invokevirtual a : (Ljava/lang/String;)Ljava/lang/Long;
    //   625: astore #4
    //   627: aload #4
    //   629: ifnull -> 647
    //   632: aload #4
    //   634: invokevirtual longValue : ()J
    //   637: lconst_1
    //   638: lcmp
    //   639: ifne -> 647
    //   642: iconst_1
    //   643: istore_2
    //   644: goto -> 649
    //   647: iconst_0
    //   648: istore_2
    //   649: iload_2
    //   650: ifeq -> 721
    //   653: invokestatic c : ()Lp1/i;
    //   656: getstatic androidx/work/impl/utils/ForceStopRunnable.i : Ljava/lang/String;
    //   659: ldc_w 'Rescheduling Workers.'
    //   662: iconst_0
    //   663: anewarray java/lang/Throwable
    //   666: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   669: aload_0
    //   670: getfield g : Lq1/k;
    //   673: invokevirtual e : ()V
    //   676: aload_0
    //   677: getfield g : Lq1/k;
    //   680: getfield g : Lz1/h;
    //   683: astore #4
    //   685: aload #4
    //   687: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   690: pop
    //   691: new y1/d
    //   694: dup
    //   695: ldc_w 'reschedule_needed'
    //   698: iconst_0
    //   699: invokespecial <init> : (Ljava/lang/String;Z)V
    //   702: astore #5
    //   704: aload #4
    //   706: getfield a : Landroidx/work/impl/WorkDatabase;
    //   709: invokevirtual m : ()Ly1/e;
    //   712: checkcast y1/f
    //   715: aload #5
    //   717: invokevirtual b : (Ly1/d;)V
    //   720: return
    //   721: ldc_w 536870912
    //   724: istore_2
    //   725: invokestatic a : ()Z
    //   728: ifeq -> 735
    //   731: ldc_w 570425344
    //   734: istore_2
    //   735: aload_0
    //   736: getfield f : Landroid/content/Context;
    //   739: iload_2
    //   740: invokestatic b : (Landroid/content/Context;I)Landroid/app/PendingIntent;
    //   743: astore #4
    //   745: getstatic android/os/Build$VERSION.SDK_INT : I
    //   748: bipush #30
    //   750: if_icmplt -> 836
    //   753: aload #4
    //   755: ifnull -> 763
    //   758: aload #4
    //   760: invokevirtual cancel : ()V
    //   763: aload_0
    //   764: getfield f : Landroid/content/Context;
    //   767: ldc_w 'activity'
    //   770: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   773: checkcast android/app/ActivityManager
    //   776: aconst_null
    //   777: iconst_0
    //   778: iconst_0
    //   779: invokevirtual getHistoricalProcessExitReasons : (Ljava/lang/String;II)Ljava/util/List;
    //   782: astore #4
    //   784: aload #4
    //   786: ifnull -> 853
    //   789: aload #4
    //   791: invokeinterface isEmpty : ()Z
    //   796: ifne -> 853
    //   799: iconst_0
    //   800: istore_2
    //   801: iload_2
    //   802: aload #4
    //   804: invokeinterface size : ()I
    //   809: if_icmpge -> 853
    //   812: aload #4
    //   814: iload_2
    //   815: invokeinterface get : (I)Ljava/lang/Object;
    //   820: checkcast android/app/ApplicationExitInfo
    //   823: invokevirtual getReason : ()I
    //   826: bipush #10
    //   828: if_icmpne -> 977
    //   831: iload_3
    //   832: istore_2
    //   833: goto -> 888
    //   836: aload #4
    //   838: ifnonnull -> 853
    //   841: aload_0
    //   842: getfield f : Landroid/content/Context;
    //   845: invokestatic d : (Landroid/content/Context;)V
    //   848: iload_3
    //   849: istore_2
    //   850: goto -> 888
    //   853: iconst_0
    //   854: istore_2
    //   855: goto -> 888
    //   858: astore #4
    //   860: goto -> 865
    //   863: astore #4
    //   865: invokestatic c : ()Lp1/i;
    //   868: getstatic androidx/work/impl/utils/ForceStopRunnable.i : Ljava/lang/String;
    //   871: ldc_w 'Ignoring exception'
    //   874: iconst_1
    //   875: anewarray java/lang/Throwable
    //   878: dup
    //   879: iconst_0
    //   880: aload #4
    //   882: aastore
    //   883: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   886: iload_3
    //   887: istore_2
    //   888: iload_2
    //   889: ifeq -> 916
    //   892: invokestatic c : ()Lp1/i;
    //   895: getstatic androidx/work/impl/utils/ForceStopRunnable.i : Ljava/lang/String;
    //   898: ldc_w 'Application was force-stopped, rescheduling.'
    //   901: iconst_0
    //   902: anewarray java/lang/Throwable
    //   905: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   908: aload_0
    //   909: getfield g : Lq1/k;
    //   912: invokevirtual e : ()V
    //   915: return
    //   916: iload_1
    //   917: ifeq -> 960
    //   920: invokestatic c : ()Lp1/i;
    //   923: getstatic androidx/work/impl/utils/ForceStopRunnable.i : Ljava/lang/String;
    //   926: ldc_w 'Found unfinished work, scheduling it.'
    //   929: iconst_0
    //   930: anewarray java/lang/Throwable
    //   933: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   936: aload_0
    //   937: getfield g : Lq1/k;
    //   940: astore #4
    //   942: aload #4
    //   944: getfield b : Landroidx/work/a;
    //   947: aload #4
    //   949: getfield c : Landroidx/work/impl/WorkDatabase;
    //   952: aload #4
    //   954: getfield e : Ljava/util/List;
    //   957: invokestatic a : (Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V
    //   960: return
    //   961: astore #5
    //   963: aload #4
    //   965: invokevirtual g : ()V
    //   968: goto -> 974
    //   971: aload #5
    //   973: athrow
    //   974: goto -> 971
    //   977: iload_2
    //   978: iconst_1
    //   979: iadd
    //   980: istore_2
    //   981: goto -> 801
    // Exception table:
    //   from	to	target	type
    //   99	115	421	finally
    //   115	139	421	finally
    //   343	357	411	finally
    //   357	393	411	finally
    //   396	401	411	finally
    //   468	493	961	finally
    //   497	507	961	finally
    //   507	564	961	finally
    //   567	580	961	finally
    //   725	731	863	java/lang/SecurityException
    //   725	731	858	java/lang/IllegalArgumentException
    //   735	753	863	java/lang/SecurityException
    //   735	753	858	java/lang/IllegalArgumentException
    //   758	763	863	java/lang/SecurityException
    //   758	763	858	java/lang/IllegalArgumentException
    //   763	784	863	java/lang/SecurityException
    //   763	784	858	java/lang/IllegalArgumentException
    //   789	799	863	java/lang/SecurityException
    //   789	799	858	java/lang/IllegalArgumentException
    //   801	831	863	java/lang/SecurityException
    //   801	831	858	java/lang/IllegalArgumentException
    //   841	848	863	java/lang/SecurityException
    //   841	848	858	java/lang/IllegalArgumentException
  }
  
  public boolean c() {
    a a = this.g.b;
    Objects.requireNonNull(a);
    if (TextUtils.isEmpty(null)) {
      i.c().a(i, "The default process name was not specified.", new Throwable[0]);
      return true;
    } 
    boolean bool = i.a(this.f, a);
    i.c().a(i, String.format("Is default app process = %s", new Object[] { Boolean.valueOf(bool) }), new Throwable[0]);
    return bool;
  }
  
  public void run() {
    try {
      boolean bool = c();
      if (!bool)
        return; 
      while (true) {
        j.a(this.f);
        i.c().a(i, "Performing cleanup operations.", new Throwable[0]);
        try {
          a();
          return;
        } catch (SQLiteCantOpenDatabaseException sQLiteCantOpenDatabaseException) {
        
        } catch (SQLiteDatabaseCorruptException sQLiteDatabaseCorruptException) {
        
        } catch (SQLiteDatabaseLockedException sQLiteDatabaseLockedException) {
        
        } catch (SQLiteTableLockedException sQLiteTableLockedException) {
        
        } catch (SQLiteConstraintException sQLiteConstraintException) {
        
        } catch (SQLiteAccessPermException sQLiteAccessPermException) {}
        int i = this.h + 1;
        this.h = i;
        if (i < 3) {
          long l = i;
          i.c().a(i, String.format("Retrying after %s", new Object[] { Long.valueOf(l * 300L) }), new Throwable[] { (Throwable)sQLiteAccessPermException });
          i = this.h;
          l = i;
          try {
            Thread.sleep(l * 300L);
          } catch (InterruptedException interruptedException) {}
          continue;
        } 
        i.c().b(i, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", new Throwable[] { interruptedException });
        IllegalStateException illegalStateException = new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", interruptedException);
        Objects.requireNonNull(this.g.b);
        throw illegalStateException;
      } 
    } finally {
      this.g.d();
    } 
  }
  
  public static class BroadcastReceiver extends android.content.BroadcastReceiver {
    public static final String a = i.e("ForceStopRunnable$Rcvr");
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent != null && "ACTION_FORCE_STOP_RESCHEDULE".equals(param1Intent.getAction())) {
        i i = i.c();
        String str = a;
        if (((i.a)i).b <= 2)
          Log.v(str, "Rescheduling alarm that keeps track of force-stops."); 
        ForceStopRunnable.d(param1Context);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\imp\\utils\ForceStopRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */