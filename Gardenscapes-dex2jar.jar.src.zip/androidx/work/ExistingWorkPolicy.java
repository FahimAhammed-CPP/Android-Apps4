package androidx.work;

public enum ExistingWorkPolicy {
  f, g, h;
  
  static {
    ExistingWorkPolicy existingWorkPolicy1 = new ExistingWorkPolicy("REPLACE", 0);
    ExistingWorkPolicy existingWorkPolicy2 = new ExistingWorkPolicy("KEEP", 1);
    f = existingWorkPolicy2;
    ExistingWorkPolicy existingWorkPolicy3 = new ExistingWorkPolicy("APPEND", 2);
    g = existingWorkPolicy3;
    ExistingWorkPolicy existingWorkPolicy4 = new ExistingWorkPolicy("APPEND_OR_REPLACE", 3);
    h = existingWorkPolicy4;
    i = new ExistingWorkPolicy[] { existingWorkPolicy1, existingWorkPolicy2, existingWorkPolicy3, existingWorkPolicy4 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\ExistingWorkPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */