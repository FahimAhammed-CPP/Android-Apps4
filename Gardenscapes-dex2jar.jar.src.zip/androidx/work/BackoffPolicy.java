package androidx.work;

public enum BackoffPolicy {
  f, g;
  
  static {
    BackoffPolicy backoffPolicy1 = new BackoffPolicy("EXPONENTIAL", 0);
    f = backoffPolicy1;
    BackoffPolicy backoffPolicy2 = new BackoffPolicy("LINEAR", 1);
    g = backoffPolicy2;
    h = new BackoffPolicy[] { backoffPolicy1, backoffPolicy2 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\BackoffPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */