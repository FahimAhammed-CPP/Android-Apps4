package androidx.work;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import p1.f;

public final class ArrayCreatingInputMerger extends f {
  public b a(List<b> paramList) {
    b.a a = new b.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<b> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      for (Map.Entry<String, Object> entry : ((b)iterator.next()).b().entrySet()) {
        String str = (String)entry.getKey();
        entry = (Map.Entry<String, Object>)entry.getValue();
        Object object1 = entry.getClass();
        Object object2 = hashMap.get(str);
        if (object2 == null) {
          if (!object1.isArray()) {
            object1 = Array.newInstance(entry.getClass(), 1);
            Array.set(object1, 0, entry);
            entry = (Map.Entry<String, Object>)object1;
          } 
        } else {
          Class<?> clazz = object2.getClass();
          if (clazz.equals(object1)) {
            if (clazz.isArray()) {
              int i = Array.getLength(object2);
              int j = Array.getLength(entry);
              object1 = Array.newInstance(object2.getClass().getComponentType(), i + j);
              System.arraycopy(object2, 0, object1, 0, i);
              System.arraycopy(entry, 0, object1, i, j);
              entry = (Map.Entry<String, Object>)object1;
            } else {
              object1 = Array.newInstance(object2.getClass(), 2);
              Array.set(object1, 0, object2);
              Array.set(object1, 1, entry);
              entry = (Map.Entry<String, Object>)object1;
            } 
          } else if (clazz.isArray() && clazz.getComponentType().equals(object1)) {
            entry = (Map.Entry<String, Object>)b(object2, entry);
          } else if (object1.isArray() && object1.getComponentType().equals(clazz)) {
            entry = (Map.Entry<String, Object>)b(entry, object2);
          } else {
            throw new IllegalArgumentException();
          } 
        } 
        hashMap.put(str, entry);
      } 
    } 
    a.b((Map)hashMap);
    return a.a();
  }
  
  public final Object b(Object paramObject1, Object paramObject2) {
    int i = Array.getLength(paramObject1);
    Object object = Array.newInstance(paramObject2.getClass(), i + 1);
    System.arraycopy(paramObject1, 0, object, 0, i);
    Array.set(object, i, paramObject2);
    return object;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\ArrayCreatingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */