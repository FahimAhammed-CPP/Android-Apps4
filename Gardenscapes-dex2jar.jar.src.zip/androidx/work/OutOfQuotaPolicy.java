package androidx.work;

public enum OutOfQuotaPolicy {
  f, g;
  
  static {
    OutOfQuotaPolicy outOfQuotaPolicy1 = new OutOfQuotaPolicy("RUN_AS_NON_EXPEDITED_WORK_REQUEST", 0);
    f = outOfQuotaPolicy1;
    OutOfQuotaPolicy outOfQuotaPolicy2 = new OutOfQuotaPolicy("DROP_WORK_REQUEST", 1);
    g = outOfQuotaPolicy2;
    h = new OutOfQuotaPolicy[] { outOfQuotaPolicy1, outOfQuotaPolicy2 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\work\OutOfQuotaPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */