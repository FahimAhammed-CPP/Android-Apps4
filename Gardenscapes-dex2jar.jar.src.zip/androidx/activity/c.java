package androidx.activity;

import androidx.lifecycle.j;

public interface c extends j {
  OnBackPressedDispatcher getOnBackPressedDispatcher();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */