package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.b;
import androidx.activity.result.c;
import androidx.activity.result.e;
import androidx.activity.result.f;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.c0;
import androidx.lifecycle.d0;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.s;
import androidx.lifecycle.u;
import androidx.lifecycle.y;
import androidx.savedstate.c;
import b0.g;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class ComponentActivity extends g implements d0, c, c, e {
  private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
  
  private final ActivityResultRegistry mActivityResultRegistry = new b(this);
  
  private int mContentLayoutId;
  
  public final c.a mContextAwareHelper = new c.a();
  
  private y mDefaultFactory;
  
  private final k mLifecycleRegistry = new k(this);
  
  private final AtomicInteger mNextLocalRequestCode = new AtomicInteger();
  
  private final OnBackPressedDispatcher mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a(this));
  
  public final androidx.savedstate.b mSavedStateRegistryController = new androidx.savedstate.b(this);
  
  private c0 mViewModelStore;
  
  public ComponentActivity() {
    if (getLifecycle() != null) {
      int i = Build.VERSION.SDK_INT;
      getLifecycle().a((i)new h(this) {
            public void a(j param1j, Lifecycle.Event param1Event) {
              if (param1Event == Lifecycle.Event.ON_STOP) {
                Window window = this.f.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  window.cancelPendingInputEvents(); 
              } 
            }
          });
      getLifecycle().a((i)new h(this) {
            public void a(j param1j, Lifecycle.Event param1Event) {
              if (param1Event == Lifecycle.Event.ON_DESTROY) {
                this.f.mContextAwareHelper.b = null;
                if (!this.f.isChangingConfigurations())
                  this.f.getViewModelStore().a(); 
              } 
            }
          });
      getLifecycle().a((i)new h(this) {
            public void a(j param1j, Lifecycle.Event param1Event) {
              this.f.ensureViewModelStore();
              k k = (k)this.f.getLifecycle();
              k.d("removeObserver");
              k.a.j(this);
            }
          });
      if (i <= 23)
        getLifecycle().a((i)new ImmLeaksCleaner((Activity)this)); 
      getSavedStateRegistry().b("android:support:activity-result", new c(this));
      addOnContextAvailableListener(new d(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  public ComponentActivity(int paramInt) {
    this();
    this.mContentLayoutId = paramInt;
  }
  
  private void initViewTreeOwners() {
    getWindow().getDecorView().setTag(2131231215, this);
    getWindow().getDecorView().setTag(2131231217, this);
    getWindow().getDecorView().setTag(2131231216, this);
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public final void addOnContextAvailableListener(c.b paramb) {
    c.a a1 = this.mContextAwareHelper;
    if (a1.b != null)
      paramb.a(a1.b); 
    a1.a.add(paramb);
  }
  
  public void ensureViewModelStore() {
    if (this.mViewModelStore == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      if (e1 != null)
        this.mViewModelStore = e1.b; 
      if (this.mViewModelStore == null)
        this.mViewModelStore = new c0(); 
    } 
  }
  
  public final ActivityResultRegistry getActivityResultRegistry() {
    return this.mActivityResultRegistry;
  }
  
  public y getDefaultViewModelProviderFactory() {
    if (getApplication() != null) {
      if (this.mDefaultFactory == null) {
        Bundle bundle;
        Application application = getApplication();
        if (getIntent() != null) {
          bundle = getIntent().getExtras();
        } else {
          bundle = null;
        } 
        this.mDefaultFactory = (y)new u(application, this, bundle);
      } 
      return this.mDefaultFactory;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  @Deprecated
  public Object getLastCustomNonConfigurationInstance() {
    e e1 = (e)getLastNonConfigurationInstance();
    return (e1 != null) ? e1.a : null;
  }
  
  public Lifecycle getLifecycle() {
    return (Lifecycle)this.mLifecycleRegistry;
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.mOnBackPressedDispatcher;
  }
  
  public final androidx.savedstate.a getSavedStateRegistry() {
    return this.mSavedStateRegistryController.b;
  }
  
  public c0 getViewModelStore() {
    if (getApplication() != null) {
      ensureViewModelStore();
      return this.mViewModelStore;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  @Deprecated
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.mActivityResultRegistry.a(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.mOnBackPressedDispatcher.b();
  }
  
  public void onCreate(Bundle paramBundle) {
    this.mSavedStateRegistryController.a(paramBundle);
    c.a a1 = this.mContextAwareHelper;
    a1.b = (Context)this;
    Iterator<c.b> iterator = a1.a.iterator();
    while (iterator.hasNext())
      ((c.b)iterator.next()).a((Context)this); 
    super.onCreate(paramBundle);
    s.c((Activity)this);
    int i = this.mContentLayoutId;
    if (i != 0)
      setContentView(i); 
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.mActivityResultRegistry.a(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  @Deprecated
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = onRetainCustomNonConfigurationInstance();
    c0 c02 = this.mViewModelStore;
    c0 c01 = c02;
    if (c02 == null) {
      e e2 = (e)getLastNonConfigurationInstance();
      c01 = c02;
      if (e2 != null)
        c01 = e2.b; 
    } 
    if (c01 == null && object == null)
      return null; 
    e e1 = new e();
    e1.a = object;
    e1.b = c01;
    return e1;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    Lifecycle lifecycle = getLifecycle();
    if (lifecycle instanceof k) {
      k k1 = (k)lifecycle;
      Lifecycle.State state = Lifecycle.State.h;
      k1.d("setCurrentState");
      k1.g(state);
    } 
    super.onSaveInstanceState(paramBundle);
    this.mSavedStateRegistryController.b(paramBundle);
  }
  
  public Context peekAvailableContext() {
    return this.mContextAwareHelper.b;
  }
  
  public final <I, O> c<I> registerForActivityResult(d.a<I, O> parama, ActivityResultRegistry paramActivityResultRegistry, b<O> paramb) {
    StringBuilder stringBuilder = android.support.v4.media.a.a("activity_rq#");
    stringBuilder.append(this.mNextLocalRequestCode.getAndIncrement());
    return paramActivityResultRegistry.c(stringBuilder.toString(), this, parama, paramb);
  }
  
  public final <I, O> c<I> registerForActivityResult(d.a<I, O> parama, b<O> paramb) {
    return registerForActivityResult(parama, this.mActivityResultRegistry, paramb);
  }
  
  public final void removeOnContextAvailableListener(c.b paramb) {
    this.mContextAwareHelper.a.remove(paramb);
  }
  
  public void reportFullyDrawn() {
    try {
      if (l1.a.a()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("reportFullyDrawn() for ");
        stringBuilder.append(getComponentName());
        Trace.beginSection(stringBuilder.toString());
      } 
      int i = Build.VERSION.SDK_INT;
      if (i > 19) {
        super.reportFullyDrawn();
      } else if (i == 19 && c0.a.a((Context)this, "android.permission.UPDATE_DEVICE_STATS") == 0) {
        super.reportFullyDrawn();
      } 
      return;
    } finally {
      Trace.endSection();
    } 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    initViewTreeOwners();
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public class a implements Runnable {
    public a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        this.f.onBackPressed();
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  public class b extends ActivityResultRegistry {
    public b(ComponentActivity this$0) {}
    
    public <I, O> void b(int param1Int, d.a<I, O> param1a, I param1I, b0.c param1c) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      f f;
      ComponentActivity componentActivity = this.i;
      d.a.a a1 = param1a.getSynchronousResult((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.createIntent((Context)componentActivity, param1I);
      param1a = null;
      if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null)
        intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        b0.a.d((Activity)componentActivity, arrayOfString1, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayOfString2.getAction())) {
        f = (f)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          IntentSender intentSender = f.f;
          Intent intent1 = f.g;
          int j = f.h;
          int k = f.i;
          int m = b0.a.c;
          componentActivity.startIntentSenderForResult(intentSender, param1Int, intent1, j, k, 0, (Bundle)arrayOfString1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
          return;
        } 
      } 
      int i = b0.a.c;
      componentActivity.startActivityForResult((Intent)f, param1Int, (Bundle)sendIntentException);
    }
    
    public class a implements Runnable {
      public a(ComponentActivity.b this$0, int param2Int, d.a.a param2a) {}
      
      public void run() {
        ComponentActivity.b b1 = this.h;
        int i = this.f;
        Object object = this.g.a;
        String str = (String)b1.b.get(Integer.valueOf(i));
        if (str == null)
          return; 
        b1.e.remove(str);
        ActivityResultRegistry.c c = (ActivityResultRegistry.c)b1.f.get(str);
        if (c != null) {
          b b2 = c.a;
          if (b2 != null) {
            b2.a(object);
            return;
          } 
        } 
        b1.h.remove(str);
        b1.g.put(str, object);
      }
    }
    
    public class b implements Runnable {
      public b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.h.a(this.f, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.g));
      }
    }
  }
  
  public class a implements Runnable {
    public a(ComponentActivity this$0, int param1Int, d.a.a param1a) {}
    
    public void run() {
      ComponentActivity.b b1 = this.h;
      int i = this.f;
      Object object = this.g.a;
      String str = (String)b1.b.get(Integer.valueOf(i));
      if (str == null)
        return; 
      b1.e.remove(str);
      ActivityResultRegistry.c c = (ActivityResultRegistry.c)b1.f.get(str);
      if (c != null) {
        b b2 = c.a;
        if (b2 != null) {
          b2.a(object);
          return;
        } 
      } 
      b1.h.remove(str);
      b1.g.put(str, object);
    }
  }
  
  public class b implements Runnable {
    public b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.h.a(this.f, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.g));
    }
  }
  
  public class c implements androidx.savedstate.a.b {
    public c(ComponentActivity this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public Bundle a() {
      Bundle bundle = new Bundle();
      ActivityResultRegistry activityResultRegistry = this.a.mActivityResultRegistry;
      Objects.requireNonNull(activityResultRegistry);
      bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(activityResultRegistry.c.values()));
      bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(activityResultRegistry.c.keySet()));
      bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(activityResultRegistry.e));
      bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)activityResultRegistry.h.clone());
      bundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", activityResultRegistry.a);
      return bundle;
    }
  }
  
  public class d implements c.b {
    public d(ComponentActivity this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void a(Context param1Context) {
      Bundle bundle = this.a.getSavedStateRegistry().a("android:support:activity-result");
      if (bundle != null) {
        ActivityResultRegistry activityResultRegistry = this.a.mActivityResultRegistry;
        Objects.requireNonNull(activityResultRegistry);
        ArrayList<Integer> arrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
        ArrayList<String> arrayList1 = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
        if (arrayList1 != null) {
          if (arrayList == null)
            return; 
          activityResultRegistry.e = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
          activityResultRegistry.a = (Random)bundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
          activityResultRegistry.h.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
          for (int i = 0; i < arrayList1.size(); i++) {
            String str = arrayList1.get(i);
            if (activityResultRegistry.c.containsKey(str)) {
              Integer integer = (Integer)activityResultRegistry.c.remove(str);
              if (!activityResultRegistry.h.containsKey(str))
                activityResultRegistry.b.remove(integer); 
            } 
            int j = ((Integer)arrayList.get(i)).intValue();
            str = arrayList1.get(i);
            activityResultRegistry.b.put(Integer.valueOf(j), str);
            activityResultRegistry.c.put(str, Integer.valueOf(j));
          } 
        } 
      } 
    }
  }
  
  public static final class e {
    public Object a;
    
    public c0 b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */