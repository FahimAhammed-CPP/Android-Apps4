package androidx.activity;

import android.annotation.SuppressLint;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
  public final Runnable a;
  
  public final ArrayDeque<b> b = new ArrayDeque<b>();
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  @SuppressLint({"LambdaLast"})
  public void a(j paramj, b paramb) {
    Lifecycle lifecycle = paramj.getLifecycle();
    if (((k)lifecycle).b == Lifecycle.State.f)
      return; 
    LifecycleOnBackPressedCancellable lifecycleOnBackPressedCancellable = new LifecycleOnBackPressedCancellable(this, lifecycle, paramb);
    paramb.b.add(lifecycleOnBackPressedCancellable);
  }
  
  public void b() {
    Iterator<b> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      b b = iterator.next();
      if (b.a) {
        b.a();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  public class LifecycleOnBackPressedCancellable implements h, a {
    public final Lifecycle f;
    
    public final b g;
    
    public a h;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, Lifecycle param1Lifecycle, b param1b) {
      this.f = param1Lifecycle;
      this.g = param1b;
      param1Lifecycle.a((i)this);
    }
    
    public void a(j param1j, Lifecycle.Event param1Event) {
      OnBackPressedDispatcher.a a1;
      if (param1Event == Lifecycle.Event.ON_START) {
        OnBackPressedDispatcher onBackPressedDispatcher = this.i;
        b b1 = this.g;
        onBackPressedDispatcher.b.add(b1);
        a1 = new OnBackPressedDispatcher.a(onBackPressedDispatcher, b1);
        b1.b.add(a1);
        this.h = a1;
        return;
      } 
      if (a1 == Lifecycle.Event.ON_STOP) {
        a a2 = this.h;
        if (a2 != null) {
          a2.cancel();
          return;
        } 
      } else if (a1 == Lifecycle.Event.ON_DESTROY) {
        cancel();
      } 
    }
    
    public void cancel() {
      k k = (k)this.f;
      k.d("removeObserver");
      k.a.j(this);
      this.g.b.remove(this);
      a a1 = this.h;
      if (a1 != null) {
        a1.cancel();
        this.h = null;
      } 
    }
  }
  
  public class a implements a {
    public final b f;
    
    public a(OnBackPressedDispatcher this$0, b param1b) {
      this.f = param1b;
    }
    
    public void cancel() {
      this.g.b.remove(this.f);
      this.f.b.remove(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */