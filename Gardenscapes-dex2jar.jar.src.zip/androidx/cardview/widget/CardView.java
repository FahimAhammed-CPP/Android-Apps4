package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import q.d;
import r.b;
import r.d;
import r.e;

public class CardView extends FrameLayout {
  public static final int[] m = new int[] { 16842801 };
  
  public static final e n;
  
  public boolean f;
  
  public boolean g;
  
  public int h;
  
  public int i;
  
  public final Rect j;
  
  public final Rect k;
  
  public final d l;
  
  static {
    if (Build.VERSION.SDK_INT >= 21) {
      n = (e)new b();
    } else {
      n = (e)new r.a();
    } 
    n.i();
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903175);
    ColorStateList colorStateList;
    Rect rect = new Rect();
    this.j = rect;
    this.k = new Rect();
    a a = new a(this);
    this.l = a;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, d.a, 2130903175, 2131820817);
    if (typedArray.hasValue(2)) {
      colorStateList = typedArray.getColorStateList(2);
    } else {
      TypedArray typedArray1 = getContext().obtainStyledAttributes(m);
      int j = typedArray1.getColor(0, 0);
      typedArray1.recycle();
      float[] arrayOfFloat = new float[3];
      Color.colorToHSV(j, arrayOfFloat);
      if (arrayOfFloat[2] > 0.5F) {
        j = getResources().getColor(2131034158);
      } else {
        j = getResources().getColor(2131034157);
      } 
      colorStateList = ColorStateList.valueOf(j);
    } 
    float f3 = typedArray.getDimension(3, 0.0F);
    float f2 = typedArray.getDimension(4, 0.0F);
    float f1 = typedArray.getDimension(5, 0.0F);
    this.f = typedArray.getBoolean(7, false);
    this.g = typedArray.getBoolean(6, true);
    int i = typedArray.getDimensionPixelSize(8, 0);
    rect.left = typedArray.getDimensionPixelSize(10, i);
    rect.top = typedArray.getDimensionPixelSize(12, i);
    rect.right = typedArray.getDimensionPixelSize(11, i);
    rect.bottom = typedArray.getDimensionPixelSize(9, i);
    if (f2 > f1)
      f1 = f2; 
    this.h = typedArray.getDimensionPixelSize(0, 0);
    this.i = typedArray.getDimensionPixelSize(1, 0);
    typedArray.recycle();
    n.a(a, paramContext, colorStateList, f3, f2, f1);
  }
  
  public ColorStateList getCardBackgroundColor() {
    return n.e(this.l);
  }
  
  public float getCardElevation() {
    return n.g(this.l);
  }
  
  public int getContentPaddingBottom() {
    return this.j.bottom;
  }
  
  public int getContentPaddingLeft() {
    return this.j.left;
  }
  
  public int getContentPaddingRight() {
    return this.j.right;
  }
  
  public int getContentPaddingTop() {
    return this.j.top;
  }
  
  public float getMaxCardElevation() {
    return n.m(this.l);
  }
  
  public boolean getPreventCornerOverlap() {
    return this.g;
  }
  
  public float getRadius() {
    return n.h(this.l);
  }
  
  public boolean getUseCompatPadding() {
    return this.f;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    e e1 = n;
    if (!(e1 instanceof b)) {
      int i = View.MeasureSpec.getMode(paramInt1);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(e1.b(this.l)), View.MeasureSpec.getSize(paramInt1)), i); 
      i = View.MeasureSpec.getMode(paramInt2);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(e1.c(this.l)), View.MeasureSpec.getSize(paramInt2)), i); 
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCardBackgroundColor(int paramInt) {
    n.n(this.l, ColorStateList.valueOf(paramInt));
  }
  
  public void setCardBackgroundColor(ColorStateList paramColorStateList) {
    n.n(this.l, paramColorStateList);
  }
  
  public void setCardElevation(float paramFloat) {
    n.j(this.l, paramFloat);
  }
  
  public void setMaxCardElevation(float paramFloat) {
    n.l(this.l, paramFloat);
  }
  
  public void setMinimumHeight(int paramInt) {
    this.i = paramInt;
    super.setMinimumHeight(paramInt);
  }
  
  public void setMinimumWidth(int paramInt) {
    this.h = paramInt;
    super.setMinimumWidth(paramInt);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPaddingRelative(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPreventCornerOverlap(boolean paramBoolean) {
    if (paramBoolean != this.g) {
      this.g = paramBoolean;
      n.k(this.l);
    } 
  }
  
  public void setRadius(float paramFloat) {
    n.f(this.l, paramFloat);
  }
  
  public void setUseCompatPadding(boolean paramBoolean) {
    if (this.f != paramBoolean) {
      this.f = paramBoolean;
      n.d(this.l);
    } 
  }
  
  public class a implements d {
    public Drawable a;
    
    public a(CardView this$0) {}
    
    public boolean a() {
      return this.b.getPreventCornerOverlap();
    }
    
    public void b(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.b.k.set(param1Int1, param1Int2, param1Int3, param1Int4);
      CardView cardView = this.b;
      Rect rect = cardView.j;
      CardView.c(cardView, param1Int1 + rect.left, param1Int2 + rect.top, param1Int3 + rect.right, param1Int4 + rect.bottom);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\cardview\widget\CardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */