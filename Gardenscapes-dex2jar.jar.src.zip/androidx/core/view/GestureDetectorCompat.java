package androidx.core.view;

import android.content.Context;
import android.os.Handler;
import android.view.GestureDetector;

public final class GestureDetectorCompat {
  public final a a;
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener) {
    this(paramContext, paramOnGestureListener, null);
  }
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler) {
    this.a = new b(paramContext, paramOnGestureListener, paramHandler);
  }
  
  public static interface a {}
  
  public static class b implements a {
    public final GestureDetector a;
    
    public b(Context param1Context, GestureDetector.OnGestureListener param1OnGestureListener, Handler param1Handler) {
      this.a = new GestureDetector(param1Context, param1OnGestureListener, param1Handler);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\core\view\GestureDetectorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */