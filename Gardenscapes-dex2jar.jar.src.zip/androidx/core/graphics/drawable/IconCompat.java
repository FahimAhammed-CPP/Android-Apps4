package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.lang.reflect.InvocationTargetException;

public class IconCompat extends CustomVersionedParcelable {
  public static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;
  
  public int a = -1;
  
  public Object b;
  
  public byte[] c = null;
  
  public Parcelable d = null;
  
  public int e = 0;
  
  public int f = 0;
  
  public ColorStateList g = null;
  
  public PorterDuff.Mode h = k;
  
  public String i = null;
  
  public String j;
  
  public IconCompat() {}
  
  public IconCompat(int paramInt) {
    this.a = paramInt;
  }
  
  public static Bitmap a(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, tileMode, tileMode);
    Matrix matrix = new Matrix();
    matrix.setTranslate((-(paramBitmap.getWidth() - i) / 2), (-(paramBitmap.getHeight() - i) / 2));
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat b(Resources paramResources, String paramString, int paramInt) {
    if (paramInt != 0) {
      IconCompat iconCompat = new IconCompat(2);
      iconCompat.e = paramInt;
      iconCompat.b = paramString;
      iconCompat.j = paramString;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Drawable resource ID must not be 0");
  }
  
  public int c() {
    int i = this.a;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Icon icon = (Icon)this.b;
        if (j >= 28)
          return icon.getResId(); 
        try {
          return ((Integer)icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException illegalAccessException) {
          Log.e("IconCompat", "Unable to get icon resource", illegalAccessException);
        } catch (InvocationTargetException invocationTargetException) {
          Log.e("IconCompat", "Unable to get icon resource", invocationTargetException);
        } catch (NoSuchMethodException noSuchMethodException) {
          Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
        } 
        return 0;
      } 
    } 
    if (i == 2)
      return this.e; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int d() {
    int i = this.a;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Icon icon = (Icon)this.b;
        if (j >= 28)
          return icon.getType(); 
        try {
          return ((Integer)icon.getClass().getMethod("getType", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to get icon type ");
          stringBuilder.append(icon);
          Log.e("IconCompat", stringBuilder.toString(), illegalAccessException);
          return -1;
        } catch (InvocationTargetException invocationTargetException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to get icon type ");
          stringBuilder.append(icon);
          Log.e("IconCompat", stringBuilder.toString(), invocationTargetException);
          return -1;
        } catch (NoSuchMethodException noSuchMethodException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to get icon type ");
          stringBuilder.append(icon);
          Log.e("IconCompat", stringBuilder.toString(), noSuchMethodException);
          return -1;
        } 
      } 
    } 
    return i;
  }
  
  public Uri e() {
    int i = this.a;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Icon icon = (Icon)this.b;
        if (j >= 28)
          return icon.getUri(); 
        try {
          return (Uri)icon.getClass().getMethod("getUri", new Class[0]).invoke(icon, new Object[0]);
        } catch (IllegalAccessException illegalAccessException) {
          Log.e("IconCompat", "Unable to get icon uri", illegalAccessException);
        } catch (InvocationTargetException invocationTargetException) {
          Log.e("IconCompat", "Unable to get icon uri", invocationTargetException);
        } catch (NoSuchMethodException noSuchMethodException) {
          Log.e("IconCompat", "Unable to get icon uri", noSuchMethodException);
        } 
        return null;
      } 
    } 
    if (i == 4 || i == 6)
      return Uri.parse((String)this.b); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getUri() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  @Deprecated
  public Icon f() {
    return g(null);
  }
  
  public Icon g(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : I
    //   4: istore_2
    //   5: aconst_null
    //   6: astore #5
    //   8: aconst_null
    //   9: astore #4
    //   11: iload_2
    //   12: tableswitch default -> 60, -1 -> 681, 0 -> 60, 1 -> 629, 2 -> 426, 3 -> 404, 4 -> 390, 5 -> 350, 6 -> 70
    //   60: new java/lang/IllegalArgumentException
    //   63: dup
    //   64: ldc 'Unknown type'
    //   66: invokespecial <init> : (Ljava/lang/String;)V
    //   69: athrow
    //   70: getstatic android/os/Build$VERSION.SDK_INT : I
    //   73: bipush #30
    //   75: if_icmplt -> 89
    //   78: aload_0
    //   79: invokevirtual e : ()Landroid/net/Uri;
    //   82: invokestatic createWithAdaptiveBitmapContentUri : (Landroid/net/Uri;)Landroid/graphics/drawable/Icon;
    //   85: astore_1
    //   86: goto -> 640
    //   89: aload_1
    //   90: ifnull -> 322
    //   93: aload_0
    //   94: invokevirtual e : ()Landroid/net/Uri;
    //   97: astore #5
    //   99: aload #5
    //   101: invokevirtual getScheme : ()Ljava/lang/String;
    //   104: astore #6
    //   106: ldc_w 'content'
    //   109: aload #6
    //   111: invokevirtual equals : (Ljava/lang/Object;)Z
    //   114: ifne -> 201
    //   117: ldc_w 'file'
    //   120: aload #6
    //   122: invokevirtual equals : (Ljava/lang/Object;)Z
    //   125: ifeq -> 131
    //   128: goto -> 201
    //   131: new java/io/FileInputStream
    //   134: dup
    //   135: new java/io/File
    //   138: dup
    //   139: aload_0
    //   140: getfield b : Ljava/lang/Object;
    //   143: checkcast java/lang/String
    //   146: invokespecial <init> : (Ljava/lang/String;)V
    //   149: invokespecial <init> : (Ljava/io/File;)V
    //   152: astore_1
    //   153: goto -> 256
    //   156: astore_1
    //   157: new java/lang/StringBuilder
    //   160: dup
    //   161: invokespecial <init> : ()V
    //   164: astore #6
    //   166: aload #6
    //   168: ldc_w 'Unable to load image from path: '
    //   171: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   174: pop
    //   175: aload #6
    //   177: aload #5
    //   179: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   182: pop
    //   183: ldc 'IconCompat'
    //   185: aload #6
    //   187: invokevirtual toString : ()Ljava/lang/String;
    //   190: aload_1
    //   191: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   194: pop
    //   195: aload #4
    //   197: astore_1
    //   198: goto -> 256
    //   201: aload_1
    //   202: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   205: aload #5
    //   207: invokevirtual openInputStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   210: astore_1
    //   211: goto -> 256
    //   214: astore_1
    //   215: new java/lang/StringBuilder
    //   218: dup
    //   219: invokespecial <init> : ()V
    //   222: astore #6
    //   224: aload #6
    //   226: ldc_w 'Unable to load image from URI: '
    //   229: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: aload #6
    //   235: aload #5
    //   237: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   240: pop
    //   241: ldc 'IconCompat'
    //   243: aload #6
    //   245: invokevirtual toString : ()Ljava/lang/String;
    //   248: aload_1
    //   249: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   252: pop
    //   253: aload #4
    //   255: astore_1
    //   256: aload_1
    //   257: ifnull -> 294
    //   260: getstatic android/os/Build$VERSION.SDK_INT : I
    //   263: bipush #26
    //   265: if_icmplt -> 279
    //   268: aload_1
    //   269: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   272: invokestatic createWithAdaptiveBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   275: astore_1
    //   276: goto -> 640
    //   279: aload_1
    //   280: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   283: iconst_0
    //   284: invokestatic a : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
    //   287: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   290: astore_1
    //   291: goto -> 640
    //   294: ldc_w 'Cannot load adaptive icon from uri: '
    //   297: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: astore_1
    //   301: aload_1
    //   302: aload_0
    //   303: invokevirtual e : ()Landroid/net/Uri;
    //   306: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   309: pop
    //   310: new java/lang/IllegalStateException
    //   313: dup
    //   314: aload_1
    //   315: invokevirtual toString : ()Ljava/lang/String;
    //   318: invokespecial <init> : (Ljava/lang/String;)V
    //   321: athrow
    //   322: ldc_w 'Context is required to resolve the file uri of the icon: '
    //   325: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   328: astore_1
    //   329: aload_1
    //   330: aload_0
    //   331: invokevirtual e : ()Landroid/net/Uri;
    //   334: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   337: pop
    //   338: new java/lang/IllegalArgumentException
    //   341: dup
    //   342: aload_1
    //   343: invokevirtual toString : ()Ljava/lang/String;
    //   346: invokespecial <init> : (Ljava/lang/String;)V
    //   349: athrow
    //   350: getstatic android/os/Build$VERSION.SDK_INT : I
    //   353: bipush #26
    //   355: if_icmplt -> 372
    //   358: aload_0
    //   359: getfield b : Ljava/lang/Object;
    //   362: checkcast android/graphics/Bitmap
    //   365: invokestatic createWithAdaptiveBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   368: astore_1
    //   369: goto -> 640
    //   372: aload_0
    //   373: getfield b : Ljava/lang/Object;
    //   376: checkcast android/graphics/Bitmap
    //   379: iconst_0
    //   380: invokestatic a : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
    //   383: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   386: astore_1
    //   387: goto -> 640
    //   390: aload_0
    //   391: getfield b : Ljava/lang/Object;
    //   394: checkcast java/lang/String
    //   397: invokestatic createWithContentUri : (Ljava/lang/String;)Landroid/graphics/drawable/Icon;
    //   400: astore_1
    //   401: goto -> 640
    //   404: aload_0
    //   405: getfield b : Ljava/lang/Object;
    //   408: checkcast [B
    //   411: aload_0
    //   412: getfield e : I
    //   415: aload_0
    //   416: getfield f : I
    //   419: invokestatic createWithData : ([BII)Landroid/graphics/drawable/Icon;
    //   422: astore_1
    //   423: goto -> 640
    //   426: iload_2
    //   427: iconst_m1
    //   428: if_icmpne -> 543
    //   431: getstatic android/os/Build$VERSION.SDK_INT : I
    //   434: istore_3
    //   435: iload_3
    //   436: bipush #23
    //   438: if_icmplt -> 543
    //   441: aload_0
    //   442: getfield b : Ljava/lang/Object;
    //   445: checkcast android/graphics/drawable/Icon
    //   448: astore_1
    //   449: iload_3
    //   450: bipush #28
    //   452: if_icmplt -> 463
    //   455: aload_1
    //   456: invokevirtual getResPackage : ()Ljava/lang/String;
    //   459: astore_1
    //   460: goto -> 583
    //   463: aload_1
    //   464: invokevirtual getClass : ()Ljava/lang/Class;
    //   467: ldc_w 'getResPackage'
    //   470: iconst_0
    //   471: anewarray java/lang/Class
    //   474: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   477: aload_1
    //   478: iconst_0
    //   479: anewarray java/lang/Object
    //   482: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   485: checkcast java/lang/String
    //   488: astore_1
    //   489: goto -> 583
    //   492: astore_1
    //   493: ldc 'IconCompat'
    //   495: ldc_w 'Unable to get icon package'
    //   498: aload_1
    //   499: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   502: pop
    //   503: aload #5
    //   505: astore_1
    //   506: goto -> 583
    //   509: astore_1
    //   510: ldc 'IconCompat'
    //   512: ldc_w 'Unable to get icon package'
    //   515: aload_1
    //   516: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   519: pop
    //   520: aload #5
    //   522: astore_1
    //   523: goto -> 583
    //   526: astore_1
    //   527: ldc 'IconCompat'
    //   529: ldc_w 'Unable to get icon package'
    //   532: aload_1
    //   533: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   536: pop
    //   537: aload #5
    //   539: astore_1
    //   540: goto -> 583
    //   543: iload_2
    //   544: iconst_2
    //   545: if_icmpne -> 595
    //   548: aload_0
    //   549: getfield j : Ljava/lang/String;
    //   552: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   555: ifeq -> 578
    //   558: aload_0
    //   559: getfield b : Ljava/lang/Object;
    //   562: checkcast java/lang/String
    //   565: ldc_w ':'
    //   568: iconst_m1
    //   569: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   572: iconst_0
    //   573: aaload
    //   574: astore_1
    //   575: goto -> 583
    //   578: aload_0
    //   579: getfield j : Ljava/lang/String;
    //   582: astore_1
    //   583: aload_1
    //   584: aload_0
    //   585: getfield e : I
    //   588: invokestatic createWithResource : (Ljava/lang/String;I)Landroid/graphics/drawable/Icon;
    //   591: astore_1
    //   592: goto -> 640
    //   595: new java/lang/StringBuilder
    //   598: dup
    //   599: invokespecial <init> : ()V
    //   602: astore_1
    //   603: aload_1
    //   604: ldc_w 'called getResPackage() on '
    //   607: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   610: pop
    //   611: aload_1
    //   612: aload_0
    //   613: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   616: pop
    //   617: new java/lang/IllegalStateException
    //   620: dup
    //   621: aload_1
    //   622: invokevirtual toString : ()Ljava/lang/String;
    //   625: invokespecial <init> : (Ljava/lang/String;)V
    //   628: athrow
    //   629: aload_0
    //   630: getfield b : Ljava/lang/Object;
    //   633: checkcast android/graphics/Bitmap
    //   636: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   639: astore_1
    //   640: aload_0
    //   641: getfield g : Landroid/content/res/ColorStateList;
    //   644: astore #4
    //   646: aload #4
    //   648: ifnull -> 658
    //   651: aload_1
    //   652: aload #4
    //   654: invokevirtual setTintList : (Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Icon;
    //   657: pop
    //   658: aload_0
    //   659: getfield h : Landroid/graphics/PorterDuff$Mode;
    //   662: astore #4
    //   664: aload #4
    //   666: getstatic androidx/core/graphics/drawable/IconCompat.k : Landroid/graphics/PorterDuff$Mode;
    //   669: if_acmpeq -> 679
    //   672: aload_1
    //   673: aload #4
    //   675: invokevirtual setTintMode : (Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/drawable/Icon;
    //   678: pop
    //   679: aload_1
    //   680: areturn
    //   681: aload_0
    //   682: getfield b : Ljava/lang/Object;
    //   685: checkcast android/graphics/drawable/Icon
    //   688: areturn
    // Exception table:
    //   from	to	target	type
    //   131	153	156	java/io/FileNotFoundException
    //   201	211	214	java/lang/Exception
    //   463	489	526	java/lang/IllegalAccessException
    //   463	489	509	java/lang/reflect/InvocationTargetException
    //   463	489	492	java/lang/NoSuchMethodException
  }
  
  public String toString() {
    String str;
    if (this.a == -1)
      return String.valueOf(this.b); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    switch (this.a) {
      default:
        str = "UNKNOWN";
        break;
      case 6:
        str = "URI_MASKABLE";
        break;
      case 5:
        str = "BITMAP_MASKABLE";
        break;
      case 4:
        str = "URI";
        break;
      case 3:
        str = "DATA";
        break;
      case 2:
        str = "RESOURCE";
        break;
      case 1:
        str = "BITMAP";
        break;
    } 
    stringBuilder.append(str);
    switch (this.a) {
      case 4:
      case 6:
        stringBuilder.append(" uri=");
        stringBuilder.append(this.b);
        break;
      case 3:
        stringBuilder.append(" len=");
        stringBuilder.append(this.e);
        if (this.f != 0) {
          stringBuilder.append(" off=");
          stringBuilder.append(this.f);
        } 
        break;
      case 2:
        stringBuilder.append(" pkg=");
        stringBuilder.append(this.j);
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(c()) }));
        break;
      case 1:
      case 5:
        stringBuilder.append(" size=");
        stringBuilder.append(((Bitmap)this.b).getWidth());
        stringBuilder.append("x");
        stringBuilder.append(((Bitmap)this.b).getHeight());
        break;
    } 
    if (this.g != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.g);
    } 
    if (this.h != k) {
      stringBuilder.append(" mode=");
      stringBuilder.append(this.h);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */