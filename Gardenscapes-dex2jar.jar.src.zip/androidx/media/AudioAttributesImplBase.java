package androidx.media;

import androidx.appcompat.widget.b0;
import java.util.Arrays;

class AudioAttributesImplBase implements AudioAttributesImpl {
  public int a = 0;
  
  public int b = 0;
  
  public int c = 0;
  
  public int d = -1;
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof AudioAttributesImplBase;
    boolean bool1 = false;
    if (!bool)
      return false; 
    paramObject = paramObject;
    bool = bool1;
    if (this.b == ((AudioAttributesImplBase)paramObject).b) {
      int j;
      int n = this.c;
      int m = ((AudioAttributesImplBase)paramObject).c;
      int k = ((AudioAttributesImplBase)paramObject).d;
      int i = 4;
      if (k != -1) {
        i = k;
      } else {
        j = ((AudioAttributesImplBase)paramObject).a;
        int i1 = AudioAttributesCompat.b;
        if ((m & 0x1) == 1) {
          i = 7;
        } else if ((m & 0x4) == 4) {
          i = 6;
        } else {
          switch (j) {
            default:
              i = 3;
              break;
            case 13:
              i = 1;
              break;
            case 11:
              i = 10;
              break;
            case 6:
              i = 2;
              break;
            case 5:
            case 7:
            case 8:
            case 9:
            case 10:
              i = 5;
              break;
            case 3:
              i = 8;
              break;
            case 2:
              i = 0;
              break;
            case 4:
              break;
          } 
        } 
      } 
      if (i == 6) {
        j = m | 0x4;
      } else {
        j = m;
        if (i == 7)
          j = m | 0x1; 
      } 
      bool = bool1;
      if (n == (j & 0x111)) {
        bool = bool1;
        if (this.a == ((AudioAttributesImplBase)paramObject).a) {
          bool = bool1;
          if (this.d == k)
            bool = true; 
        } 
      } 
    } 
    return bool;
  }
  
  public int hashCode() {
    return Arrays.hashCode(new Object[] { Integer.valueOf(this.b), Integer.valueOf(this.c), Integer.valueOf(this.a), Integer.valueOf(this.d) });
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("AudioAttributesCompat:");
    if (this.d != -1) {
      stringBuilder.append(" stream=");
      stringBuilder.append(this.d);
      stringBuilder.append(" derived");
    } 
    stringBuilder.append(" usage=");
    int i = this.a;
    int j = AudioAttributesCompat.b;
    switch (i) {
      default:
        str = b0.a("unknown usage ", i);
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 16:
        str = "USAGE_ASSISTANT";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 14:
        str = "USAGE_GAME";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 13:
        str = "USAGE_ASSISTANCE_SONIFICATION";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 12:
        str = "USAGE_ASSISTANCE_NAVIGATION_GUIDANCE";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 11:
        str = "USAGE_ASSISTANCE_ACCESSIBILITY";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 10:
        str = "USAGE_NOTIFICATION_EVENT";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 9:
        str = "USAGE_NOTIFICATION_COMMUNICATION_DELAYED";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 8:
        str = "USAGE_NOTIFICATION_COMMUNICATION_INSTANT";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 7:
        str = "USAGE_NOTIFICATION_COMMUNICATION_REQUEST";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 6:
        str = "USAGE_NOTIFICATION_RINGTONE";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 5:
        str = "USAGE_NOTIFICATION";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 4:
        str = "USAGE_ALARM";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 3:
        str = "USAGE_VOICE_COMMUNICATION_SIGNALLING";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 2:
        str = "USAGE_VOICE_COMMUNICATION";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 1:
        str = "USAGE_MEDIA";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 0:
        break;
    } 
    String str = "USAGE_UNKNOWN";
    stringBuilder.append(str);
    stringBuilder.append(" content=");
    stringBuilder.append(this.b);
    stringBuilder.append(" flags=0x");
    stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\media\AudioAttributesImplBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */