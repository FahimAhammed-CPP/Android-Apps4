package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import java.util.Objects;
import o1.a;

public final class AudioAttributesImplApi21Parcelizer {
  public static AudioAttributesImplApi21 read(a parama) {
    AudioAttributesImplApi21 audioAttributesImplApi21 = new AudioAttributesImplApi21();
    audioAttributesImplApi21.a = (AudioAttributes)parama.m((Parcelable)audioAttributesImplApi21.a, 1);
    audioAttributesImplApi21.b = parama.k(audioAttributesImplApi21.b, 2);
    return audioAttributesImplApi21;
  }
  
  public static void write(AudioAttributesImplApi21 paramAudioAttributesImplApi21, a parama) {
    Objects.requireNonNull(parama);
    AudioAttributes audioAttributes = paramAudioAttributesImplApi21.a;
    parama.p(1);
    parama.u((Parcelable)audioAttributes);
    int i = paramAudioAttributesImplApi21.b;
    parama.p(2);
    parama.t(i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\media\AudioAttributesImplApi21Parcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */