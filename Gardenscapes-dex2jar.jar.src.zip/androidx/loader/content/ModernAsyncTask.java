package androidx.loader.content;

import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class ModernAsyncTask<Params, Progress, Result> {
  public static final Executor k;
  
  public static e l;
  
  public final f<Params, Result> f;
  
  public final FutureTask<Result> g;
  
  public volatile Status h = Status.f;
  
  public final AtomicBoolean i = new AtomicBoolean();
  
  public final AtomicBoolean j = new AtomicBoolean();
  
  static {
    a a = new a();
    LinkedBlockingQueue<Runnable> linkedBlockingQueue = new LinkedBlockingQueue(10);
    k = new ThreadPoolExecutor(5, 128, 1L, TimeUnit.SECONDS, linkedBlockingQueue, a);
  }
  
  public ModernAsyncTask() {
    b b = new b(this);
    this.f = b;
    this.g = new c(this, b);
  }
  
  public abstract Result a(Params... paramVarArgs);
  
  public void b(Result paramResult) {}
  
  public void c(Result paramResult) {}
  
  public Result d(Result paramResult) {
    // Byte code:
    //   0: ldc androidx/loader/content/ModernAsyncTask
    //   2: monitorenter
    //   3: getstatic androidx/loader/content/ModernAsyncTask.l : Landroidx/loader/content/ModernAsyncTask$e;
    //   6: ifnonnull -> 19
    //   9: new androidx/loader/content/ModernAsyncTask$e
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: putstatic androidx/loader/content/ModernAsyncTask.l : Landroidx/loader/content/ModernAsyncTask$e;
    //   19: getstatic androidx/loader/content/ModernAsyncTask.l : Landroidx/loader/content/ModernAsyncTask$e;
    //   22: astore_2
    //   23: ldc androidx/loader/content/ModernAsyncTask
    //   25: monitorexit
    //   26: aload_2
    //   27: iconst_1
    //   28: new androidx/loader/content/ModernAsyncTask$d
    //   31: dup
    //   32: aload_0
    //   33: iconst_1
    //   34: anewarray java/lang/Object
    //   37: dup
    //   38: iconst_0
    //   39: aload_1
    //   40: aastore
    //   41: invokespecial <init> : (Landroidx/loader/content/ModernAsyncTask;[Ljava/lang/Object;)V
    //   44: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   47: invokevirtual sendToTarget : ()V
    //   50: aload_1
    //   51: areturn
    //   52: astore_1
    //   53: ldc androidx/loader/content/ModernAsyncTask
    //   55: monitorexit
    //   56: aload_1
    //   57: athrow
    // Exception table:
    //   from	to	target	type
    //   3	19	52	finally
    //   19	26	52	finally
    //   53	56	52	finally
  }
  
  public enum Status {
    f, g, h;
    
    static {
      Status status1 = new Status("PENDING", 0);
      f = status1;
      Status status2 = new Status("RUNNING", 1);
      g = status2;
      Status status3 = new Status("FINISHED", 2);
      h = status3;
      i = new Status[] { status1, status2, status3 };
    }
  }
  
  public static final class a implements ThreadFactory {
    public final AtomicInteger a = new AtomicInteger(1);
    
    public Thread newThread(Runnable param1Runnable) {
      StringBuilder stringBuilder = android.support.v4.media.a.a("ModernAsyncTask #");
      stringBuilder.append(this.a.getAndIncrement());
      return new Thread(param1Runnable, stringBuilder.toString());
    }
  }
  
  public class b extends f<Params, Result> {
    public b(ModernAsyncTask this$0) {}
    
    public Result call() {
      this.g.j.set(true);
      Object object2 = null;
      Object object1 = object2;
      try {
        Process.setThreadPriority(10);
        object1 = object2;
        object2 = this.g.a((Object[])this.f);
        object1 = object2;
        Binder.flushPendingCommands();
        return (Result)object2;
      } finally {
        object2 = null;
      } 
    }
  }
  
  public class c extends FutureTask<Result> {
    public c(ModernAsyncTask this$0, Callable<Result> param1Callable) {
      super(param1Callable);
    }
    
    public void done() {
      try {
        V v = get();
        ModernAsyncTask modernAsyncTask = this.f;
      } catch (InterruptedException interruptedException) {
      
      } catch (ExecutionException executionException) {
        throw new RuntimeException("An error occurred while executing doInBackground()", executionException.getCause());
      } catch (CancellationException cancellationException) {
        ModernAsyncTask modernAsyncTask = this.f;
      } finally {
        Exception exception = null;
      } 
    }
  }
  
  public static class d<Data> {
    public final ModernAsyncTask a;
    
    public final Data[] b;
    
    public d(ModernAsyncTask param1ModernAsyncTask, Data... param1VarArgs) {
      this.a = param1ModernAsyncTask;
      this.b = param1VarArgs;
    }
  }
  
  public static class e extends Handler {
    public e() {
      super(Looper.getMainLooper());
    }
    
    public void handleMessage(Message param1Message) {
      ModernAsyncTask.d d = (ModernAsyncTask.d)param1Message.obj;
      int i = param1Message.what;
      if (i != 1) {
        if (i != 2)
          return; 
        Objects.requireNonNull(d.a);
        return;
      } 
      ModernAsyncTask modernAsyncTask = d.a;
      Data data = d.b[0];
      if (modernAsyncTask.i.get()) {
        modernAsyncTask.b(data);
      } else {
        modernAsyncTask.c(data);
      } 
      modernAsyncTask.h = ModernAsyncTask.Status.h;
    }
  }
  
  public static abstract class f<Params, Result> implements Callable<Result> {
    public Params[] f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\loader\content\ModernAsyncTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */