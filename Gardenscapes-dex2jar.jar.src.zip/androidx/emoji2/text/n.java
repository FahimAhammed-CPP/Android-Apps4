package androidx.emoji2.text;

import android.graphics.Typeface;
import android.util.SparseArray;
import l0.e;
import u0.b;

public final class n {
  public final b a;
  
  public final char[] b;
  
  public final a c;
  
  public final Typeface d;
  
  public n(Typeface paramTypeface, b paramb) {
    this.d = paramTypeface;
    this.a = paramb;
    this.c = new a(1024);
    int i = paramb.a(6);
    if (i != 0) {
      i = paramb.c(i);
    } else {
      i = 0;
    } 
    this.b = new char[i * 2];
    i = paramb.a(6);
    if (i != 0) {
      i = paramb.c(i);
    } else {
      i = 0;
    } 
    int j;
    for (j = 0; j < i; j++) {
      boolean bool;
      g g = new g(this, j);
      Character.toChars(g.d(), this.b, j * 2);
      if (g.b() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      e.a(bool, "invalid metadata codepoint length");
      this.c.a(g, 0, g.b() - 1);
    } 
  }
  
  public static class a {
    public final SparseArray<a> a = new SparseArray(1);
    
    public g b;
    
    public a() {}
    
    public a(int param1Int) {}
    
    public void a(g param1g, int param1Int1, int param1Int2) {
      a a1;
      int i = param1g.a(param1Int1);
      SparseArray<a> sparseArray = this.a;
      if (sparseArray == null) {
        sparseArray = null;
      } else {
        a1 = (a)sparseArray.get(i);
      } 
      a a2 = a1;
      if (a1 == null) {
        a2 = new a();
        this.a.put(param1g.a(param1Int1), a2);
      } 
      if (param1Int2 > param1Int1) {
        a2.a(param1g, param1Int1 + 1, param1Int2);
        return;
      } 
      a2.b = param1g;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */