package androidx.emoji2.text;

import java.nio.ByteBuffer;
import u0.a;
import u0.b;
import u0.c;

public class g {
  public static final ThreadLocal<a> d = new ThreadLocal<a>();
  
  public final int a;
  
  public final n b;
  
  public volatile int c = 0;
  
  public g(n paramn, int paramInt) {
    this.b = paramn;
    this.a = paramInt;
  }
  
  public int a(int paramInt) {
    a a = e();
    int i = a.a(16);
    if (i != 0) {
      ByteBuffer byteBuffer = (ByteBuffer)((c)a).b;
      i += ((c)a).a;
      return byteBuffer.getInt(paramInt * 4 + byteBuffer.getInt(i) + i + 4);
    } 
    return 0;
  }
  
  public int b() {
    a a = e();
    int i = a.a(16);
    return (i != 0) ? a.c(i) : 0;
  }
  
  public short c() {
    a a = e();
    int i = a.a(14);
    return (i != 0) ? ((ByteBuffer)((c)a).b).getShort(i + ((c)a).a) : 0;
  }
  
  public int d() {
    a a = e();
    int i = a.a(4);
    return (i != 0) ? ((ByteBuffer)((c)a).b).getInt(i + ((c)a).a) : 0;
  }
  
  public final a e() {
    ThreadLocal<a> threadLocal = d;
    a a2 = threadLocal.get();
    a a1 = a2;
    if (a2 == null) {
      a1 = new a();
      threadLocal.set(a1);
    } 
    b b = this.b.a;
    int i = this.a;
    int j = b.a(6);
    if (j != 0) {
      j += ((c)b).a;
      i = i * 4 + ((ByteBuffer)((c)b).b).getInt(j) + j + 4;
      a1.b(((ByteBuffer)((c)b).b).getInt(i) + i, (ByteBuffer)((c)b).b);
    } 
    return a1;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.toString());
    stringBuilder.append(", id:");
    stringBuilder.append(Integer.toHexString(d()));
    stringBuilder.append(", codepoints:");
    int j = b();
    for (int i = 0; i < j; i++) {
      stringBuilder.append(Integer.toHexString(a(i)));
      stringBuilder.append(" ");
    } 
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */