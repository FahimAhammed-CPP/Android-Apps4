package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import java.util.Objects;

public final class p extends i {
  public p(g paramg) {
    super(paramg);
  }
  
  public void draw(Canvas paramCanvas, @SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2, float paramFloat, int paramInt3, int paramInt4, int paramInt5, Paint paramPaint) {
    Objects.requireNonNull(d.a());
    g g = this.g;
    float f = paramInt4;
    Typeface typeface1 = g.b.d;
    Typeface typeface2 = paramPaint.getTypeface();
    paramPaint.setTypeface(typeface1);
    paramInt1 = g.a;
    paramCanvas.drawText(g.b.b, paramInt1 * 2, 2, paramFloat, f, paramPaint);
    paramPaint.setTypeface(typeface2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */