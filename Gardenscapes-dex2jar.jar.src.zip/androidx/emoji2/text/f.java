package androidx.emoji2.text;

import java.util.concurrent.ThreadPoolExecutor;

public class f extends d.h {
  public f(EmojiCompatInitializer.b paramb, d.h paramh, ThreadPoolExecutor paramThreadPoolExecutor) {}
  
  public void a(Throwable paramThrowable) {
    try {
      this.a.a(paramThrowable);
      return;
    } finally {
      this.b.shutdown();
    } 
  }
  
  public void b(n paramn) {
    try {
      this.a.b(paramn);
      return;
    } finally {
      this.b.shutdown();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */