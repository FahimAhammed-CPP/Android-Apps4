package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.graphics.Paint;
import android.text.style.ReplacementSpan;
import java.nio.ByteBuffer;
import l0.e;
import u0.a;
import u0.c;

public abstract class i extends ReplacementSpan {
  public final Paint.FontMetricsInt f = new Paint.FontMetricsInt();
  
  public final g g;
  
  public short h = -1;
  
  public float i = 1.0F;
  
  public i(g paramg) {
    e.d(paramg, "metadata cannot be null");
    this.g = paramg;
  }
  
  public int getSize(Paint paramPaint, @SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2, Paint.FontMetricsInt paramFontMetricsInt) {
    paramPaint.getFontMetricsInt(this.f);
    Paint.FontMetricsInt fontMetricsInt = this.f;
    this.i = Math.abs(fontMetricsInt.descent - fontMetricsInt.ascent) * 1.0F / this.g.c();
    this.g.c();
    a a = this.g.e();
    paramInt1 = a.a(12);
    if (paramInt1 != 0) {
      paramInt1 = ((ByteBuffer)((c)a).b).getShort(paramInt1 + ((c)a).a);
    } else {
      paramInt1 = 0;
    } 
    short s = (short)(int)(paramInt1 * this.i);
    this.h = s;
    if (paramFontMetricsInt != null) {
      Paint.FontMetricsInt fontMetricsInt1 = this.f;
      paramFontMetricsInt.ascent = fontMetricsInt1.ascent;
      paramFontMetricsInt.descent = fontMetricsInt1.descent;
      paramFontMetricsInt.top = fontMetricsInt1.top;
      paramFontMetricsInt.bottom = fontMetricsInt1.bottom;
    } 
    return s;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */