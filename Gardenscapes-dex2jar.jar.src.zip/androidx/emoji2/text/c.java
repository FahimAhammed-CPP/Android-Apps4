package androidx.emoji2.text;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import java.util.List;

public final class c {
  public static j a(Context paramContext) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #28
    //   5: if_icmplt -> 20
    //   8: new androidx/emoji2/text/c$c
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore #4
    //   17: goto -> 29
    //   20: new androidx/emoji2/text/c$b
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: astore #4
    //   29: aload_0
    //   30: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   33: astore #6
    //   35: aload #6
    //   37: ldc 'Package manager required to locate emoji font provider'
    //   39: invokestatic d : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   42: pop
    //   43: new android/content/Intent
    //   46: dup
    //   47: ldc 'androidx.content.action.LOAD_EMOJI_FONT'
    //   49: invokespecial <init> : (Ljava/lang/String;)V
    //   52: astore #5
    //   54: iconst_0
    //   55: istore_2
    //   56: aload #4
    //   58: aload #6
    //   60: aload #5
    //   62: iconst_0
    //   63: invokevirtual c : (Landroid/content/pm/PackageManager;Landroid/content/Intent;I)Ljava/util/List;
    //   66: invokeinterface iterator : ()Ljava/util/Iterator;
    //   71: astore #7
    //   73: aload #7
    //   75: invokeinterface hasNext : ()Z
    //   80: ifeq -> 142
    //   83: aload #4
    //   85: aload #7
    //   87: invokeinterface next : ()Ljava/lang/Object;
    //   92: checkcast android/content/pm/ResolveInfo
    //   95: invokevirtual a : (Landroid/content/pm/ResolveInfo;)Landroid/content/pm/ProviderInfo;
    //   98: astore #5
    //   100: iconst_1
    //   101: istore_1
    //   102: aload #5
    //   104: ifnull -> 133
    //   107: aload #5
    //   109: getfield applicationInfo : Landroid/content/pm/ApplicationInfo;
    //   112: astore #8
    //   114: aload #8
    //   116: ifnull -> 133
    //   119: aload #8
    //   121: getfield flags : I
    //   124: iconst_1
    //   125: iand
    //   126: iconst_1
    //   127: if_icmpne -> 133
    //   130: goto -> 135
    //   133: iconst_0
    //   134: istore_1
    //   135: iload_1
    //   136: ifeq -> 73
    //   139: goto -> 145
    //   142: aconst_null
    //   143: astore #5
    //   145: aload #5
    //   147: ifnonnull -> 153
    //   150: goto -> 251
    //   153: aload #5
    //   155: getfield authority : Ljava/lang/String;
    //   158: astore #7
    //   160: aload #5
    //   162: getfield packageName : Ljava/lang/String;
    //   165: astore #5
    //   167: aload #4
    //   169: aload #6
    //   171: aload #5
    //   173: invokevirtual b : (Landroid/content/pm/PackageManager;Ljava/lang/String;)[Landroid/content/pm/Signature;
    //   176: astore #4
    //   178: new java/util/ArrayList
    //   181: dup
    //   182: invokespecial <init> : ()V
    //   185: astore #6
    //   187: aload #4
    //   189: arraylength
    //   190: istore_3
    //   191: iload_2
    //   192: istore_1
    //   193: iload_1
    //   194: iload_3
    //   195: if_icmpge -> 218
    //   198: aload #6
    //   200: aload #4
    //   202: iload_1
    //   203: aaload
    //   204: invokevirtual toByteArray : ()[B
    //   207: invokevirtual add : (Ljava/lang/Object;)Z
    //   210: pop
    //   211: iload_1
    //   212: iconst_1
    //   213: iadd
    //   214: istore_1
    //   215: goto -> 193
    //   218: new j0/f
    //   221: dup
    //   222: aload #7
    //   224: aload #5
    //   226: ldc 'emojicompat-emoji-font'
    //   228: aload #6
    //   230: invokestatic singletonList : (Ljava/lang/Object;)Ljava/util/List;
    //   233: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    //   236: astore #4
    //   238: goto -> 254
    //   241: astore #4
    //   243: ldc 'emoji2.text.DefaultEmojiConfig'
    //   245: aload #4
    //   247: invokestatic wtf : (Ljava/lang/String;Ljava/lang/Throwable;)I
    //   250: pop
    //   251: aconst_null
    //   252: astore #4
    //   254: aload #4
    //   256: ifnonnull -> 261
    //   259: aconst_null
    //   260: areturn
    //   261: new androidx/emoji2/text/j
    //   264: dup
    //   265: aload_0
    //   266: aload #4
    //   268: invokespecial <init> : (Landroid/content/Context;Lj0/f;)V
    //   271: areturn
    // Exception table:
    //   from	to	target	type
    //   153	191	241	android/content/pm/PackageManager$NameNotFoundException
    //   198	211	241	android/content/pm/PackageManager$NameNotFoundException
    //   218	238	241	android/content/pm/PackageManager$NameNotFoundException
  }
  
  public static class a {
    public ProviderInfo a(ResolveInfo param1ResolveInfo) {
      throw null;
    }
    
    public Signature[] b(PackageManager param1PackageManager, String param1String) {
      return (param1PackageManager.getPackageInfo(param1String, 64)).signatures;
    }
    
    public List<ResolveInfo> c(PackageManager param1PackageManager, Intent param1Intent, int param1Int) {
      throw null;
    }
  }
  
  public static class b extends a {
    public ProviderInfo a(ResolveInfo param1ResolveInfo) {
      return param1ResolveInfo.providerInfo;
    }
    
    public List<ResolveInfo> c(PackageManager param1PackageManager, Intent param1Intent, int param1Int) {
      return param1PackageManager.queryIntentContentProviders(param1Intent, param1Int);
    }
  }
  
  public static class c extends b {
    public Signature[] b(PackageManager param1PackageManager, String param1String) {
      return (param1PackageManager.getPackageInfo(param1String, 64)).signatures;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */