package androidx.emoji2.text;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class b {
  public static ThreadPoolExecutor a(String paramString) {
    a a = new a(paramString);
    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque<Runnable>(), a);
    threadPoolExecutor.allowCoreThreadTimeOut(true);
    return threadPoolExecutor;
  }
  
  public static Handler b() {
    return (Build.VERSION.SDK_INT >= 28) ? a.a(Looper.getMainLooper()) : new Handler(Looper.getMainLooper());
  }
  
  public static class a {
    public static Handler a(Looper param1Looper) {
      return Handler.createAsync(param1Looper);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */