package androidx.emoji2.text;

import java.nio.ByteBuffer;
import u0.b;

public class m {
  public static b a(ByteBuffer paramByteBuffer) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual duplicate : ()Ljava/nio/ByteBuffer;
    //   4: astore_0
    //   5: aload_0
    //   6: getstatic java/nio/ByteOrder.BIG_ENDIAN : Ljava/nio/ByteOrder;
    //   9: invokevirtual order : (Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
    //   12: pop
    //   13: aload_0
    //   14: aload_0
    //   15: invokevirtual position : ()I
    //   18: iconst_4
    //   19: iadd
    //   20: invokevirtual position : (I)Ljava/nio/Buffer;
    //   23: pop
    //   24: aload_0
    //   25: invokevirtual getShort : ()S
    //   28: ldc 65535
    //   30: iand
    //   31: istore_3
    //   32: iload_3
    //   33: bipush #100
    //   35: if_icmpgt -> 288
    //   38: aload_0
    //   39: aload_0
    //   40: invokevirtual position : ()I
    //   43: bipush #6
    //   45: iadd
    //   46: invokevirtual position : (I)Ljava/nio/Buffer;
    //   49: pop
    //   50: iconst_0
    //   51: istore_2
    //   52: iconst_0
    //   53: istore_1
    //   54: iload_1
    //   55: iload_3
    //   56: if_icmpge -> 115
    //   59: aload_0
    //   60: invokevirtual getInt : ()I
    //   63: istore #4
    //   65: aload_0
    //   66: aload_0
    //   67: invokevirtual position : ()I
    //   70: iconst_4
    //   71: iadd
    //   72: invokevirtual position : (I)Ljava/nio/Buffer;
    //   75: pop
    //   76: aload_0
    //   77: invokevirtual getInt : ()I
    //   80: i2l
    //   81: ldc2_w 4294967295
    //   84: land
    //   85: lstore #5
    //   87: aload_0
    //   88: aload_0
    //   89: invokevirtual position : ()I
    //   92: iconst_4
    //   93: iadd
    //   94: invokevirtual position : (I)Ljava/nio/Buffer;
    //   97: pop
    //   98: ldc 1835365473
    //   100: iload #4
    //   102: if_icmpne -> 108
    //   105: goto -> 120
    //   108: iload_1
    //   109: iconst_1
    //   110: iadd
    //   111: istore_1
    //   112: goto -> 54
    //   115: ldc2_w -1
    //   118: lstore #5
    //   120: lload #5
    //   122: ldc2_w -1
    //   125: lcmp
    //   126: ifeq -> 278
    //   129: lload #5
    //   131: aload_0
    //   132: invokevirtual position : ()I
    //   135: i2l
    //   136: lsub
    //   137: l2i
    //   138: istore_1
    //   139: aload_0
    //   140: aload_0
    //   141: invokevirtual position : ()I
    //   144: iload_1
    //   145: iadd
    //   146: invokevirtual position : (I)Ljava/nio/Buffer;
    //   149: pop
    //   150: aload_0
    //   151: aload_0
    //   152: invokevirtual position : ()I
    //   155: bipush #12
    //   157: iadd
    //   158: invokevirtual position : (I)Ljava/nio/Buffer;
    //   161: pop
    //   162: aload_0
    //   163: invokevirtual getInt : ()I
    //   166: i2l
    //   167: lstore #7
    //   169: iload_2
    //   170: istore_1
    //   171: iload_1
    //   172: i2l
    //   173: lload #7
    //   175: ldc2_w 4294967295
    //   178: land
    //   179: lcmp
    //   180: ifge -> 278
    //   183: aload_0
    //   184: invokevirtual getInt : ()I
    //   187: istore_2
    //   188: aload_0
    //   189: invokevirtual getInt : ()I
    //   192: i2l
    //   193: lstore #9
    //   195: aload_0
    //   196: invokevirtual getInt : ()I
    //   199: pop
    //   200: ldc 1164798569
    //   202: iload_2
    //   203: if_icmpeq -> 222
    //   206: ldc 1701669481
    //   208: iload_2
    //   209: if_icmpne -> 215
    //   212: goto -> 222
    //   215: iload_1
    //   216: iconst_1
    //   217: iadd
    //   218: istore_1
    //   219: goto -> 171
    //   222: aload_0
    //   223: lload #9
    //   225: ldc2_w 4294967295
    //   228: land
    //   229: lload #5
    //   231: ladd
    //   232: l2i
    //   233: invokevirtual position : (I)Ljava/nio/Buffer;
    //   236: pop
    //   237: new u0/b
    //   240: dup
    //   241: invokespecial <init> : ()V
    //   244: astore #11
    //   246: aload_0
    //   247: getstatic java/nio/ByteOrder.LITTLE_ENDIAN : Ljava/nio/ByteOrder;
    //   250: invokevirtual order : (Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
    //   253: pop
    //   254: aload_0
    //   255: aload_0
    //   256: invokevirtual position : ()I
    //   259: invokevirtual getInt : (I)I
    //   262: istore_1
    //   263: aload #11
    //   265: aload_0
    //   266: invokevirtual position : ()I
    //   269: iload_1
    //   270: iadd
    //   271: aload_0
    //   272: invokevirtual b : (ILjava/nio/ByteBuffer;)V
    //   275: aload #11
    //   277: areturn
    //   278: new java/io/IOException
    //   281: dup
    //   282: ldc 'Cannot read metadata.'
    //   284: invokespecial <init> : (Ljava/lang/String;)V
    //   287: athrow
    //   288: new java/io/IOException
    //   291: dup
    //   292: ldc 'Cannot read metadata.'
    //   294: invokespecial <init> : (Ljava/lang/String;)V
    //   297: astore_0
    //   298: goto -> 303
    //   301: aload_0
    //   302: athrow
    //   303: goto -> 301
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */