package androidx.emoji2.text;

import android.text.Editable;
import android.text.Selection;
import android.text.TextPaint;
import android.view.KeyEvent;
import java.nio.ByteBuffer;
import u0.c;

public final class h {
  public final d.i a;
  
  public final n b;
  
  public d.d c;
  
  public h(n paramn, d.i parami, d.d paramd, boolean paramBoolean, int[] paramArrayOfint) {
    this.a = parami;
    this.b = paramn;
    this.c = paramd;
  }
  
  public static boolean a(Editable paramEditable, KeyEvent paramKeyEvent, boolean paramBoolean) {
    int j;
    if ((KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) ^ true) != 0)
      return false; 
    int k = Selection.getSelectionStart((CharSequence)paramEditable);
    int m = Selection.getSelectionEnd((CharSequence)paramEditable);
    if (k == -1 || m == -1 || k != m) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j)
      return false; 
    i[] arrayOfI = (i[])paramEditable.getSpans(k, m, i.class);
    if (arrayOfI != null && arrayOfI.length > 0) {
      m = arrayOfI.length;
      for (j = 0; j < m; j++) {
        i i3 = arrayOfI[j];
        int i1 = paramEditable.getSpanStart(i3);
        int i2 = paramEditable.getSpanEnd(i3);
        if ((paramBoolean && i1 == k) || (!paramBoolean && i2 == k) || (k > i1 && k < i2)) {
          paramEditable.delete(i1, i2);
          return true;
        } 
      } 
    } 
    return false;
  }
  
  public final boolean b(CharSequence paramCharSequence, int paramInt1, int paramInt2, g paramg) {
    // Byte code:
    //   0: aload #4
    //   2: getfield c : I
    //   5: istore #9
    //   7: iconst_0
    //   8: istore #12
    //   10: iload #9
    //   12: ifne -> 509
    //   15: aload_0
    //   16: getfield c : Landroidx/emoji2/text/d$d;
    //   19: astore #13
    //   21: aload #4
    //   23: invokevirtual e : ()Lu0/a;
    //   26: astore #14
    //   28: aload #14
    //   30: bipush #8
    //   32: invokevirtual a : (I)I
    //   35: istore #9
    //   37: iload #9
    //   39: ifeq -> 66
    //   42: aload #14
    //   44: getfield b : Ljava/lang/Object;
    //   47: checkcast java/nio/ByteBuffer
    //   50: iload #9
    //   52: aload #14
    //   54: getfield a : I
    //   57: iadd
    //   58: invokevirtual getShort : (I)S
    //   61: istore #9
    //   63: goto -> 69
    //   66: iconst_0
    //   67: istore #9
    //   69: aload #13
    //   71: checkcast androidx/emoji2/text/h$a
    //   74: astore #13
    //   76: aload #13
    //   78: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   81: pop
    //   82: getstatic android/os/Build$VERSION.SDK_INT : I
    //   85: istore #10
    //   87: iload #10
    //   89: bipush #23
    //   91: if_icmpge -> 104
    //   94: iload #9
    //   96: iload #10
    //   98: if_icmple -> 104
    //   101: goto -> 351
    //   104: getstatic androidx/emoji2/text/h$a.b : Ljava/lang/ThreadLocal;
    //   107: astore #14
    //   109: aload #14
    //   111: invokevirtual get : ()Ljava/lang/Object;
    //   114: ifnonnull -> 129
    //   117: aload #14
    //   119: new java/lang/StringBuilder
    //   122: dup
    //   123: invokespecial <init> : ()V
    //   126: invokevirtual set : (Ljava/lang/Object;)V
    //   129: aload #14
    //   131: invokevirtual get : ()Ljava/lang/Object;
    //   134: checkcast java/lang/StringBuilder
    //   137: astore #14
    //   139: aload #14
    //   141: iconst_0
    //   142: invokevirtual setLength : (I)V
    //   145: iload_2
    //   146: iload_3
    //   147: if_icmpge -> 170
    //   150: aload #14
    //   152: aload_1
    //   153: iload_2
    //   154: invokeinterface charAt : (I)C
    //   159: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   162: pop
    //   163: iload_2
    //   164: iconst_1
    //   165: iadd
    //   166: istore_2
    //   167: goto -> 145
    //   170: aload #13
    //   172: getfield a : Landroid/text/TextPaint;
    //   175: astore #13
    //   177: aload #14
    //   179: invokevirtual toString : ()Ljava/lang/String;
    //   182: astore #14
    //   184: getstatic e0/c.a : Ljava/lang/ThreadLocal;
    //   187: astore_1
    //   188: getstatic android/os/Build$VERSION.SDK_INT : I
    //   191: bipush #23
    //   193: if_icmplt -> 208
    //   196: aload #13
    //   198: aload #14
    //   200: invokevirtual hasGlyph : (Ljava/lang/String;)Z
    //   203: istore #11
    //   205: goto -> 491
    //   208: aload #14
    //   210: invokevirtual length : ()I
    //   213: istore #9
    //   215: iload #9
    //   217: iconst_1
    //   218: if_icmpne -> 236
    //   221: aload #14
    //   223: iconst_0
    //   224: invokevirtual charAt : (I)C
    //   227: invokestatic isWhitespace : (C)Z
    //   230: ifeq -> 236
    //   233: goto -> 365
    //   236: aload #13
    //   238: ldc '󟿽'
    //   240: invokevirtual measureText : (Ljava/lang/String;)F
    //   243: fstore #6
    //   245: aload #13
    //   247: ldc 'm'
    //   249: invokevirtual measureText : (Ljava/lang/String;)F
    //   252: fstore #8
    //   254: aload #13
    //   256: aload #14
    //   258: invokevirtual measureText : (Ljava/lang/String;)F
    //   261: fstore #7
    //   263: fconst_0
    //   264: fstore #5
    //   266: fload #7
    //   268: fconst_0
    //   269: fcmpl
    //   270: ifne -> 276
    //   273: goto -> 351
    //   276: aload #14
    //   278: iconst_0
    //   279: aload #14
    //   281: invokevirtual length : ()I
    //   284: invokevirtual codePointCount : (II)I
    //   287: iconst_1
    //   288: if_icmple -> 357
    //   291: fload #7
    //   293: fload #8
    //   295: fconst_2
    //   296: fmul
    //   297: fcmpl
    //   298: ifle -> 304
    //   301: goto -> 351
    //   304: iconst_0
    //   305: istore_2
    //   306: iload_2
    //   307: iload #9
    //   309: if_icmpge -> 343
    //   312: aload #14
    //   314: iload_2
    //   315: invokevirtual codePointAt : (I)I
    //   318: invokestatic charCount : (I)I
    //   321: iload_2
    //   322: iadd
    //   323: istore_3
    //   324: fload #5
    //   326: aload #13
    //   328: aload #14
    //   330: iload_2
    //   331: iload_3
    //   332: invokevirtual measureText : (Ljava/lang/String;II)F
    //   335: fadd
    //   336: fstore #5
    //   338: iload_3
    //   339: istore_2
    //   340: goto -> 306
    //   343: fload #7
    //   345: fload #5
    //   347: fcmpl
    //   348: iflt -> 357
    //   351: iconst_0
    //   352: istore #11
    //   354: goto -> 491
    //   357: fload #7
    //   359: fload #6
    //   361: fcmpl
    //   362: ifeq -> 371
    //   365: iconst_1
    //   366: istore #11
    //   368: goto -> 491
    //   371: getstatic e0/c.a : Ljava/lang/ThreadLocal;
    //   374: astore #15
    //   376: aload #15
    //   378: invokevirtual get : ()Ljava/lang/Object;
    //   381: checkcast l0/c
    //   384: astore_1
    //   385: aload_1
    //   386: ifnonnull -> 420
    //   389: new l0/c
    //   392: dup
    //   393: new android/graphics/Rect
    //   396: dup
    //   397: invokespecial <init> : ()V
    //   400: new android/graphics/Rect
    //   403: dup
    //   404: invokespecial <init> : ()V
    //   407: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   410: astore_1
    //   411: aload #15
    //   413: aload_1
    //   414: invokevirtual set : (Ljava/lang/Object;)V
    //   417: goto -> 440
    //   420: aload_1
    //   421: getfield a : Ljava/lang/Object;
    //   424: checkcast android/graphics/Rect
    //   427: invokevirtual setEmpty : ()V
    //   430: aload_1
    //   431: getfield b : Ljava/lang/Object;
    //   434: checkcast android/graphics/Rect
    //   437: invokevirtual setEmpty : ()V
    //   440: aload #13
    //   442: ldc '󟿽'
    //   444: iconst_0
    //   445: iconst_2
    //   446: aload_1
    //   447: getfield a : Ljava/lang/Object;
    //   450: checkcast android/graphics/Rect
    //   453: invokevirtual getTextBounds : (Ljava/lang/String;IILandroid/graphics/Rect;)V
    //   456: aload #13
    //   458: aload #14
    //   460: iconst_0
    //   461: iload #9
    //   463: aload_1
    //   464: getfield b : Ljava/lang/Object;
    //   467: checkcast android/graphics/Rect
    //   470: invokevirtual getTextBounds : (Ljava/lang/String;IILandroid/graphics/Rect;)V
    //   473: aload_1
    //   474: getfield a : Ljava/lang/Object;
    //   477: checkcast android/graphics/Rect
    //   480: aload_1
    //   481: getfield b : Ljava/lang/Object;
    //   484: invokevirtual equals : (Ljava/lang/Object;)Z
    //   487: iconst_1
    //   488: ixor
    //   489: istore #11
    //   491: iload #11
    //   493: ifeq -> 501
    //   496: iconst_2
    //   497: istore_2
    //   498: goto -> 503
    //   501: iconst_1
    //   502: istore_2
    //   503: aload #4
    //   505: iload_2
    //   506: putfield c : I
    //   509: iload #12
    //   511: istore #11
    //   513: aload #4
    //   515: getfield c : I
    //   518: iconst_2
    //   519: if_icmpne -> 525
    //   522: iconst_1
    //   523: istore #11
    //   525: iload #11
    //   527: ireturn
  }
  
  public static class a implements d.d {
    public static final ThreadLocal<StringBuilder> b = new ThreadLocal<StringBuilder>();
    
    public final TextPaint a;
    
    public a() {
      TextPaint textPaint = new TextPaint();
      this.a = textPaint;
      textPaint.setTextSize(10.0F);
    }
  }
  
  public static final class b {
    public int a = 1;
    
    public final n.a b;
    
    public n.a c;
    
    public n.a d;
    
    public int e;
    
    public int f;
    
    public b(n.a param1a, boolean param1Boolean, int[] param1ArrayOfint) {
      this.b = param1a;
      this.c = param1a;
    }
    
    public int a(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield c : Landroidx/emoji2/text/n$a;
      //   4: getfield a : Landroid/util/SparseArray;
      //   7: astore #5
      //   9: aload #5
      //   11: ifnonnull -> 20
      //   14: aconst_null
      //   15: astore #5
      //   17: goto -> 31
      //   20: aload #5
      //   22: iload_1
      //   23: invokevirtual get : (I)Ljava/lang/Object;
      //   26: checkcast androidx/emoji2/text/n$a
      //   29: astore #5
      //   31: aload_0
      //   32: getfield a : I
      //   35: istore_2
      //   36: iconst_3
      //   37: istore_3
      //   38: iload_2
      //   39: iconst_2
      //   40: if_icmpeq -> 75
      //   43: aload #5
      //   45: ifnonnull -> 56
      //   48: aload_0
      //   49: invokevirtual b : ()I
      //   52: pop
      //   53: goto -> 223
      //   56: aload_0
      //   57: iconst_2
      //   58: putfield a : I
      //   61: aload_0
      //   62: aload #5
      //   64: putfield c : Landroidx/emoji2/text/n$a;
      //   67: aload_0
      //   68: iconst_1
      //   69: putfield f : I
      //   72: goto -> 142
      //   75: aload #5
      //   77: ifnull -> 99
      //   80: aload_0
      //   81: aload #5
      //   83: putfield c : Landroidx/emoji2/text/n$a;
      //   86: aload_0
      //   87: aload_0
      //   88: getfield f : I
      //   91: iconst_1
      //   92: iadd
      //   93: putfield f : I
      //   96: goto -> 142
      //   99: iconst_0
      //   100: istore #4
      //   102: iload_1
      //   103: ldc 65038
      //   105: if_icmpne -> 113
      //   108: iconst_1
      //   109: istore_2
      //   110: goto -> 115
      //   113: iconst_0
      //   114: istore_2
      //   115: iload_2
      //   116: ifeq -> 127
      //   119: aload_0
      //   120: invokevirtual b : ()I
      //   123: pop
      //   124: goto -> 223
      //   127: iload #4
      //   129: istore_2
      //   130: iload_1
      //   131: ldc 65039
      //   133: if_icmpne -> 138
      //   136: iconst_1
      //   137: istore_2
      //   138: iload_2
      //   139: ifeq -> 147
      //   142: iconst_2
      //   143: istore_2
      //   144: goto -> 225
      //   147: aload_0
      //   148: getfield c : Landroidx/emoji2/text/n$a;
      //   151: astore #5
      //   153: aload #5
      //   155: getfield b : Landroidx/emoji2/text/g;
      //   158: ifnull -> 218
      //   161: aload_0
      //   162: getfield f : I
      //   165: iconst_1
      //   166: if_icmpne -> 202
      //   169: aload_0
      //   170: invokevirtual c : ()Z
      //   173: ifeq -> 194
      //   176: aload_0
      //   177: aload_0
      //   178: getfield c : Landroidx/emoji2/text/n$a;
      //   181: putfield d : Landroidx/emoji2/text/n$a;
      //   184: aload_0
      //   185: invokevirtual b : ()I
      //   188: pop
      //   189: iload_3
      //   190: istore_2
      //   191: goto -> 225
      //   194: aload_0
      //   195: invokevirtual b : ()I
      //   198: pop
      //   199: goto -> 223
      //   202: aload_0
      //   203: aload #5
      //   205: putfield d : Landroidx/emoji2/text/n$a;
      //   208: aload_0
      //   209: invokevirtual b : ()I
      //   212: pop
      //   213: iload_3
      //   214: istore_2
      //   215: goto -> 225
      //   218: aload_0
      //   219: invokevirtual b : ()I
      //   222: pop
      //   223: iconst_1
      //   224: istore_2
      //   225: aload_0
      //   226: iload_1
      //   227: putfield e : I
      //   230: iload_2
      //   231: ireturn
    }
    
    public final int b() {
      this.a = 1;
      this.c = this.b;
      this.f = 0;
      return 1;
    }
    
    public final boolean c() {
      u0.a a1 = this.c.b.e();
      int i = a1.a(6);
      if (i != 0 && ((ByteBuffer)((c)a1).b).get(i + ((c)a1).a) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0)
        return true; 
      if (this.e == 65039) {
        i = 1;
      } else {
        i = 0;
      } 
      return (i != 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */