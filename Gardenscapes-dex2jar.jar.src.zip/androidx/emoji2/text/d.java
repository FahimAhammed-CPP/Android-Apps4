package androidx.emoji2.text;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.inputmethod.EditorInfo;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class d {
  public static final Object j = new Object();
  
  public static volatile d k;
  
  public final ReadWriteLock a;
  
  public final Set<e> b;
  
  public volatile int c;
  
  public final Handler d;
  
  public final b e;
  
  public final g f;
  
  public final int g;
  
  public final int h;
  
  public final d i;
  
  public d(c paramc) {
    ReentrantReadWriteLock reentrantReadWriteLock = new ReentrantReadWriteLock();
    this.a = reentrantReadWriteLock;
    this.c = 3;
    Objects.requireNonNull(paramc);
    this.g = -16711936;
    this.f = paramc.a;
    int i = paramc.b;
    this.h = i;
    this.i = paramc.c;
    this.d = new Handler(Looper.getMainLooper());
    this.b = (Set<e>)new s.c(0);
    a a = new a(this);
    this.e = a;
    reentrantReadWriteLock.writeLock().lock();
    if (i == 0)
      try {
        this.c = 0;
      } finally {
        this.a.writeLock().unlock();
      }  
    reentrantReadWriteLock.writeLock().unlock();
    if (b() == 0)
      a.a(); 
  }
  
  public static d a() {
    synchronized (j) {
      d d1 = k;
      if (d1 != null) {
        boolean bool1 = true;
        l0.e.e(bool1, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
        return d1;
      } 
    } 
    boolean bool = false;
    l0.e.e(bool, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
    return (d)SYNTHETIC_LOCAL_VARIABLE_2;
  }
  
  public static boolean c() {
    return (k != null);
  }
  
  public int b() {
    this.a.readLock().lock();
    try {
      return this.c;
    } finally {
      this.a.readLock().unlock();
    } 
  }
  
  public final boolean d() {
    return (b() == 1);
  }
  
  public void e() {
    int i = this.h;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    l0.e.e(bool, "Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
    if (d())
      return; 
    this.a.writeLock().lock();
    try {
      i = this.c;
      if (i == 0)
        return; 
      this.c = 0;
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public void f(Throwable paramThrowable) {
    ArrayList<e> arrayList = new ArrayList();
    this.a.writeLock().lock();
    try {
      this.c = 2;
      arrayList.addAll(this.b);
      this.b.clear();
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public void g() {
    null = new ArrayList();
    this.a.writeLock().lock();
    try {
      this.c = 1;
      null.addAll(this.b);
      this.b.clear();
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public CharSequence h(CharSequence paramCharSequence) {
    int i;
    if (paramCharSequence == null) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    return i(paramCharSequence, 0, i, 2147483647, 0);
  }
  
  public CharSequence i(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    boolean bool;
    l0.e.e(d(), "Not initialized yet");
    l0.e.c(paramInt1, "start cannot be negative");
    l0.e.c(paramInt2, "end cannot be negative");
    l0.e.c(paramInt3, "maxEmojiCount cannot be negative");
    if (paramInt1 <= paramInt2) {
      bool = true;
    } else {
      bool = false;
    } 
    l0.e.a(bool, "start should be <= than end");
    if (paramCharSequence == null)
      return null; 
    if (paramInt1 <= paramCharSequence.length()) {
      bool = true;
    } else {
      bool = false;
    } 
    l0.e.a(bool, "start should be < than charSequence length");
    if (paramInt2 <= paramCharSequence.length()) {
      bool = true;
    } else {
      bool = false;
    } 
    l0.e.a(bool, "end should be < than charSequence length");
    CharSequence charSequence = paramCharSequence;
    if (paramCharSequence.length() != 0) {
      if (paramInt1 == paramInt2)
        return paramCharSequence; 
      if (paramInt4 != 1) {
        bool = false;
      } else {
        bool = true;
      } 
      charSequence = this.e.b(paramCharSequence, paramInt1, paramInt2, paramInt3, bool);
    } 
    return charSequence;
  }
  
  public void j(e parame) {
    l0.e.d(parame, "initCallback cannot be null");
    this.a.writeLock().lock();
    try {
      if (this.c == 1 || this.c == 2) {
        Handler handler = this.d;
        int i = this.c;
        l0.e.d(parame, "initCallback cannot be null");
        handler.post(new f(Arrays.asList(new e[] { parame }, ), i, null));
      } else {
        this.b.add(parame);
      } 
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public static final class a extends b {
    public volatile h b;
    
    public volatile n c;
    
    public a(d param1d) {
      super(param1d);
    }
    
    public void a() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.a.f(exception);
      } 
    }
    
    public CharSequence b(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      // Byte code:
      //   0: iload_2
      //   1: istore #6
      //   3: iload #4
      //   5: istore #7
      //   7: aload_0
      //   8: getfield b : Landroidx/emoji2/text/h;
      //   11: astore #14
      //   13: aload #14
      //   15: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   18: pop
      //   19: aload_1
      //   20: instanceof androidx/emoji2/text/o
      //   23: istore #11
      //   25: iload #11
      //   27: ifeq -> 37
      //   30: aload_1
      //   31: checkcast androidx/emoji2/text/o
      //   34: invokevirtual a : ()V
      //   37: iload #11
      //   39: ifne -> 94
      //   42: aload_1
      //   43: instanceof android/text/Spannable
      //   46: ifeq -> 52
      //   49: goto -> 94
      //   52: aload_1
      //   53: instanceof android/text/Spanned
      //   56: ifeq -> 760
      //   59: aload_1
      //   60: checkcast android/text/Spanned
      //   63: iload #6
      //   65: iconst_1
      //   66: isub
      //   67: iload_3
      //   68: iconst_1
      //   69: iadd
      //   70: ldc androidx/emoji2/text/i
      //   72: invokeinterface nextSpanTransition : (IILjava/lang/Class;)I
      //   77: iload_3
      //   78: if_icmpgt -> 760
      //   81: new android/text/SpannableString
      //   84: dup
      //   85: aload_1
      //   86: invokespecial <init> : (Ljava/lang/CharSequence;)V
      //   89: astore #12
      //   91: goto -> 100
      //   94: aload_1
      //   95: checkcast android/text/Spannable
      //   98: astore #12
      //   100: iload #6
      //   102: istore_2
      //   103: iload_3
      //   104: istore #4
      //   106: aload #12
      //   108: ifnull -> 239
      //   111: aload #12
      //   113: iload #6
      //   115: iload_3
      //   116: ldc androidx/emoji2/text/i
      //   118: invokeinterface getSpans : (IILjava/lang/Class;)[Ljava/lang/Object;
      //   123: checkcast [Landroidx/emoji2/text/i;
      //   126: astore #13
      //   128: iload #6
      //   130: istore_2
      //   131: iload_3
      //   132: istore #4
      //   134: aload #13
      //   136: ifnull -> 239
      //   139: iload #6
      //   141: istore_2
      //   142: iload_3
      //   143: istore #4
      //   145: aload #13
      //   147: arraylength
      //   148: ifle -> 239
      //   151: aload #13
      //   153: arraylength
      //   154: istore #9
      //   156: iconst_0
      //   157: istore #8
      //   159: iload #6
      //   161: istore_2
      //   162: iload_3
      //   163: istore #4
      //   165: iload #8
      //   167: iload #9
      //   169: if_icmpge -> 239
      //   172: aload #13
      //   174: iload #8
      //   176: aaload
      //   177: astore #15
      //   179: aload #12
      //   181: aload #15
      //   183: invokeinterface getSpanStart : (Ljava/lang/Object;)I
      //   188: istore #4
      //   190: aload #12
      //   192: aload #15
      //   194: invokeinterface getSpanEnd : (Ljava/lang/Object;)I
      //   199: istore_2
      //   200: iload #4
      //   202: iload_3
      //   203: if_icmpeq -> 215
      //   206: aload #12
      //   208: aload #15
      //   210: invokeinterface removeSpan : (Ljava/lang/Object;)V
      //   215: iload #4
      //   217: iload #6
      //   219: invokestatic min : (II)I
      //   222: istore #6
      //   224: iload_2
      //   225: iload_3
      //   226: invokestatic max : (II)I
      //   229: istore_3
      //   230: iload #8
      //   232: iconst_1
      //   233: iadd
      //   234: istore #8
      //   236: goto -> 159
      //   239: iload_2
      //   240: iload #4
      //   242: if_icmpeq -> 723
      //   245: iload_2
      //   246: aload_1
      //   247: invokeinterface length : ()I
      //   252: if_icmplt -> 258
      //   255: goto -> 723
      //   258: iload #7
      //   260: istore #6
      //   262: iload #7
      //   264: ldc 2147483647
      //   266: if_icmpeq -> 304
      //   269: iload #7
      //   271: istore #6
      //   273: aload #12
      //   275: ifnull -> 304
      //   278: iload #7
      //   280: aload #12
      //   282: iconst_0
      //   283: aload #12
      //   285: invokeinterface length : ()I
      //   290: ldc androidx/emoji2/text/i
      //   292: invokeinterface getSpans : (IILjava/lang/Class;)[Ljava/lang/Object;
      //   297: checkcast [Landroidx/emoji2/text/i;
      //   300: arraylength
      //   301: isub
      //   302: istore #6
      //   304: new androidx/emoji2/text/h$b
      //   307: dup
      //   308: aload #14
      //   310: getfield b : Landroidx/emoji2/text/n;
      //   313: getfield c : Landroidx/emoji2/text/n$a;
      //   316: iconst_0
      //   317: aconst_null
      //   318: invokespecial <init> : (Landroidx/emoji2/text/n$a;Z[I)V
      //   321: astore #15
      //   323: aload_1
      //   324: iload_2
      //   325: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
      //   328: istore_3
      //   329: iconst_0
      //   330: istore #7
      //   332: goto -> 766
      //   335: iload_3
      //   336: iload #4
      //   338: if_icmpge -> 549
      //   341: iload #7
      //   343: iload #6
      //   345: if_icmpge -> 549
      //   348: aload #15
      //   350: iload_2
      //   351: invokevirtual a : (I)I
      //   354: istore #9
      //   356: iload #9
      //   358: iconst_1
      //   359: if_icmpeq -> 521
      //   362: iload #9
      //   364: iconst_2
      //   365: if_icmpeq -> 482
      //   368: iload #9
      //   370: iconst_3
      //   371: if_icmpeq -> 381
      //   374: iload #8
      //   376: istore #9
      //   378: goto -> 802
      //   381: iload #5
      //   383: ifne -> 414
      //   386: aload #12
      //   388: astore #13
      //   390: iload #7
      //   392: istore #9
      //   394: aload #14
      //   396: aload_1
      //   397: iload #8
      //   399: iload_3
      //   400: aload #15
      //   402: getfield d : Landroidx/emoji2/text/n$a;
      //   405: getfield b : Landroidx/emoji2/text/g;
      //   408: invokevirtual b : (Ljava/lang/CharSequence;IILandroidx/emoji2/text/g;)Z
      //   411: ifne -> 780
      //   414: aload #12
      //   416: astore #13
      //   418: aload #12
      //   420: ifnonnull -> 433
      //   423: new android/text/SpannableString
      //   426: dup
      //   427: aload_1
      //   428: invokespecial <init> : (Ljava/lang/CharSequence;)V
      //   431: astore #13
      //   433: aload #15
      //   435: getfield d : Landroidx/emoji2/text/n$a;
      //   438: getfield b : Landroidx/emoji2/text/g;
      //   441: astore #12
      //   443: aload #14
      //   445: getfield a : Landroidx/emoji2/text/d$i;
      //   448: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   451: pop
      //   452: aload #13
      //   454: new androidx/emoji2/text/p
      //   457: dup
      //   458: aload #12
      //   460: invokespecial <init> : (Landroidx/emoji2/text/g;)V
      //   463: iload #8
      //   465: iload_3
      //   466: bipush #33
      //   468: invokeinterface setSpan : (Ljava/lang/Object;III)V
      //   473: iload #7
      //   475: iconst_1
      //   476: iadd
      //   477: istore #9
      //   479: goto -> 780
      //   482: iload_3
      //   483: iload_2
      //   484: invokestatic charCount : (I)I
      //   487: iadd
      //   488: istore #10
      //   490: iload #10
      //   492: istore_3
      //   493: iload #8
      //   495: istore #9
      //   497: iload #10
      //   499: iload #4
      //   501: if_icmpge -> 802
      //   504: aload_1
      //   505: iload #10
      //   507: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
      //   510: istore_2
      //   511: iload #10
      //   513: istore_3
      //   514: iload #8
      //   516: istore #9
      //   518: goto -> 802
      //   521: aload_1
      //   522: iload #8
      //   524: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
      //   527: invokestatic charCount : (I)I
      //   530: iload #8
      //   532: iadd
      //   533: istore_3
      //   534: iload_3
      //   535: iload #4
      //   537: if_icmpge -> 799
      //   540: aload_1
      //   541: iload_3
      //   542: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
      //   545: istore_2
      //   546: goto -> 799
      //   549: aload #15
      //   551: getfield a : I
      //   554: iconst_2
      //   555: if_icmpne -> 814
      //   558: aload #15
      //   560: getfield c : Landroidx/emoji2/text/n$a;
      //   563: getfield b : Landroidx/emoji2/text/g;
      //   566: ifnull -> 814
      //   569: aload #15
      //   571: getfield f : I
      //   574: iconst_1
      //   575: if_icmpgt -> 809
      //   578: aload #15
      //   580: invokevirtual c : ()Z
      //   583: ifeq -> 814
      //   586: goto -> 809
      //   589: aload #12
      //   591: astore #13
      //   593: iload_2
      //   594: ifeq -> 696
      //   597: aload #12
      //   599: astore #13
      //   601: iload #7
      //   603: iload #6
      //   605: if_icmpge -> 696
      //   608: iload #5
      //   610: ifne -> 637
      //   613: aload #12
      //   615: astore #13
      //   617: aload #14
      //   619: aload_1
      //   620: iload #8
      //   622: iload_3
      //   623: aload #15
      //   625: getfield c : Landroidx/emoji2/text/n$a;
      //   628: getfield b : Landroidx/emoji2/text/g;
      //   631: invokevirtual b : (Ljava/lang/CharSequence;IILandroidx/emoji2/text/g;)Z
      //   634: ifne -> 696
      //   637: aload #12
      //   639: astore #13
      //   641: aload #12
      //   643: ifnonnull -> 656
      //   646: new android/text/SpannableString
      //   649: dup
      //   650: aload_1
      //   651: invokespecial <init> : (Ljava/lang/CharSequence;)V
      //   654: astore #13
      //   656: aload #15
      //   658: getfield c : Landroidx/emoji2/text/n$a;
      //   661: getfield b : Landroidx/emoji2/text/g;
      //   664: astore #12
      //   666: aload #14
      //   668: getfield a : Landroidx/emoji2/text/d$i;
      //   671: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   674: pop
      //   675: aload #13
      //   677: new androidx/emoji2/text/p
      //   680: dup
      //   681: aload #12
      //   683: invokespecial <init> : (Landroidx/emoji2/text/g;)V
      //   686: iload #8
      //   688: iload_3
      //   689: bipush #33
      //   691: invokeinterface setSpan : (Ljava/lang/Object;III)V
      //   696: aload #13
      //   698: astore #12
      //   700: aload #13
      //   702: ifnonnull -> 708
      //   705: aload_1
      //   706: astore #12
      //   708: iload #11
      //   710: ifeq -> 720
      //   713: aload_1
      //   714: checkcast androidx/emoji2/text/o
      //   717: invokevirtual b : ()V
      //   720: aload #12
      //   722: areturn
      //   723: iload #11
      //   725: ifeq -> 735
      //   728: aload_1
      //   729: checkcast androidx/emoji2/text/o
      //   732: invokevirtual b : ()V
      //   735: aload_1
      //   736: areturn
      //   737: astore #12
      //   739: iload #11
      //   741: ifeq -> 751
      //   744: aload_1
      //   745: checkcast androidx/emoji2/text/o
      //   748: invokevirtual b : ()V
      //   751: goto -> 757
      //   754: aload #12
      //   756: athrow
      //   757: goto -> 754
      //   760: aconst_null
      //   761: astore #12
      //   763: goto -> 100
      //   766: iload_3
      //   767: istore #9
      //   769: iload_2
      //   770: istore #8
      //   772: iload_2
      //   773: istore_3
      //   774: iload #9
      //   776: istore_2
      //   777: goto -> 335
      //   780: iload_2
      //   781: istore #7
      //   783: iload_3
      //   784: istore_2
      //   785: iload #7
      //   787: istore_3
      //   788: aload #13
      //   790: astore #12
      //   792: iload #9
      //   794: istore #7
      //   796: goto -> 766
      //   799: iload_3
      //   800: istore #9
      //   802: iload #9
      //   804: istore #8
      //   806: goto -> 335
      //   809: iconst_1
      //   810: istore_2
      //   811: goto -> 589
      //   814: iconst_0
      //   815: istore_2
      //   816: goto -> 589
      // Exception table:
      //   from	to	target	type
      //   42	49	737	finally
      //   52	91	737	finally
      //   94	100	737	finally
      //   111	128	737	finally
      //   145	156	737	finally
      //   179	200	737	finally
      //   206	215	737	finally
      //   215	230	737	finally
      //   245	255	737	finally
      //   278	304	737	finally
      //   304	329	737	finally
      //   348	356	737	finally
      //   394	414	737	finally
      //   423	433	737	finally
      //   433	473	737	finally
      //   482	490	737	finally
      //   504	511	737	finally
      //   521	534	737	finally
      //   540	546	737	finally
      //   549	586	737	finally
      //   617	637	737	finally
      //   646	656	737	finally
      //   656	696	737	finally
    }
    
    public void c(EditorInfo param1EditorInfo) {
      Bundle bundle2 = param1EditorInfo.extras;
      u0.b b1 = this.c.a;
      int i = b1.a(4);
      if (i != 0) {
        i = ((ByteBuffer)((u0.c)b1).b).getInt(i + ((u0.c)b1).a);
      } else {
        i = 0;
      } 
      bundle2.putInt("android.support.text.emoji.emojiCompat_metadataVersion", i);
      Bundle bundle1 = param1EditorInfo.extras;
      Objects.requireNonNull(this.a);
      bundle1.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", false);
    }
    
    public class a extends d.h {
      public a(d.a this$0) {}
      
      public void a(Throwable param2Throwable) {
        this.a.a.f(param2Throwable);
      }
      
      public void b(n param2n) {
        d.a a1 = this.a;
        if (param2n == null) {
          a1.a.f(new IllegalArgumentException("metadataRepo cannot be null"));
          return;
        } 
        a1.c = param2n;
        param2n = a1.c;
        d.i i = new d.i();
        d d = a1.a;
        d.d d1 = d.i;
        Objects.requireNonNull(d);
        a1.b = new h(param2n, i, d1, false, null);
        a1.a.g();
      }
    }
  }
  
  public class a extends h {
    public a(d this$0) {}
    
    public void a(Throwable param1Throwable) {
      this.a.a.f(param1Throwable);
    }
    
    public void b(n param1n) {
      d.a a1 = this.a;
      if (param1n == null) {
        a1.a.f(new IllegalArgumentException("metadataRepo cannot be null"));
        return;
      } 
      a1.c = param1n;
      param1n = a1.c;
      d.i i = new d.i();
      d d = a1.a;
      d.d d1 = d.i;
      Objects.requireNonNull(d);
      a1.b = new h(param1n, i, d1, false, null);
      a1.a.g();
    }
  }
  
  public static class b {
    public final d a;
    
    public b(d param1d) {
      this.a = param1d;
    }
    
    public void a() {
      throw null;
    }
    
    public CharSequence b(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      throw null;
    }
    
    public void c(EditorInfo param1EditorInfo) {
      throw null;
    }
  }
  
  public static abstract class c {
    public final d.g a;
    
    public int b = 0;
    
    public d.d c = new h.a();
    
    public c(d.g param1g) {
      this.a = param1g;
    }
  }
  
  public static interface d {}
  
  public static abstract class e {
    public void a() {}
  }
  
  public static class f implements Runnable {
    public final List<d.e> f;
    
    public final int g;
    
    public f(Collection<d.e> param1Collection, int param1Int, Throwable param1Throwable) {
      l0.e.d(param1Collection, "initCallbacks cannot be null");
      this.f = new ArrayList<d.e>(param1Collection);
      this.g = param1Int;
    }
    
    public void run() {
      int j = this.f.size();
      int k = this.g;
      int i = 0;
      byte b = 0;
      if (k != 1) {
        for (i = b; i < j; i++)
          Objects.requireNonNull(this.f.get(i)); 
      } else {
        while (i < j) {
          ((d.e)this.f.get(i)).a();
          i++;
        } 
      } 
    }
  }
  
  public static interface g {
    void a(d.h param1h);
  }
  
  public static abstract class h {
    public abstract void a(Throwable param1Throwable);
    
    public abstract void b(n param1n);
  }
  
  public static class i {}
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\emoji2\text\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */