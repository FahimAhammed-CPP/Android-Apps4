package androidx.room;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.CancellationSignal;
import android.os.Looper;
import android.util.Log;
import androidx.room.migration.Migration;
import f1.e;
import i1.d;
import j1.f;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public abstract class RoomDatabase {
  @Deprecated
  public volatile i1.a a;
  
  public Executor b;
  
  public i1.b c;
  
  public final e d;
  
  public boolean e;
  
  public boolean f;
  
  @Deprecated
  public List<b> g;
  
  public final ReentrantReadWriteLock h = new ReentrantReadWriteLock();
  
  public final ThreadLocal<Integer> i = new ThreadLocal<Integer>();
  
  public RoomDatabase() {
    new ConcurrentHashMap<Object, Object>();
    this.d = e();
  }
  
  public void a() {
    boolean bool;
    if (this.e)
      return; 
    if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool)
      return; 
    throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
  }
  
  public void b() {
    if (!h()) {
      if (this.i.get() == null)
        return; 
      throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
    } 
  }
  
  @Deprecated
  public void c() {
    a();
    i1.a a1 = this.c.f0();
    this.d.d(a1);
    ((j1.a)a1).f.beginTransaction();
  }
  
  public f d(String paramString) {
    a();
    b();
    return new f(((j1.a)this.c.f0()).f.compileStatement(paramString));
  }
  
  public abstract e e();
  
  public abstract i1.b f(a parama);
  
  @Deprecated
  public void g() {
    ((j1.a)this.c.f0()).f.endTransaction();
    if (!h()) {
      e e1 = this.d;
      if (e1.e.compareAndSet(false, true))
        e1.d.b.execute(e1.j); 
    } 
  }
  
  public boolean h() {
    return ((j1.a)this.c.f0()).f.inTransaction();
  }
  
  public boolean i() {
    i1.a a1 = this.a;
    return (a1 != null && ((j1.a)a1).f.isOpen());
  }
  
  public Cursor j(d paramd, CancellationSignal paramCancellationSignal) {
    a();
    b();
    if (paramCancellationSignal != null) {
      j1.a a1 = (j1.a)this.c.f0();
      return a1.f.rawQueryWithFactory((SQLiteDatabase.CursorFactory)new j1.b(a1, paramd), paramd.f(), j1.a.g, null, paramCancellationSignal);
    } 
    return ((j1.a)this.c.f0()).d(paramd);
  }
  
  @Deprecated
  public void k() {
    ((j1.a)this.c.f0()).f.setTransactionSuccessful();
  }
  
  public enum JournalMode {
    f, g, h;
    
    static {
      JournalMode journalMode1 = new JournalMode("AUTOMATIC", 0);
      f = journalMode1;
      JournalMode journalMode2 = new JournalMode("TRUNCATE", 1);
      g = journalMode2;
      JournalMode journalMode3 = new JournalMode("WRITE_AHEAD_LOGGING", 2);
      h = journalMode3;
      i = new JournalMode[] { journalMode1, journalMode2, journalMode3 };
    }
  }
  
  public static class a<T extends RoomDatabase> {
    public final Class<T> a;
    
    public final String b;
    
    public final Context c;
    
    public ArrayList<RoomDatabase.b> d;
    
    public Executor e;
    
    public Executor f;
    
    public i1.b.c g;
    
    public boolean h;
    
    public boolean i;
    
    public boolean j;
    
    public final RoomDatabase.c k;
    
    public Set<Integer> l;
    
    public a(Context param1Context, Class<T> param1Class, String param1String) {
      this.c = param1Context;
      this.a = param1Class;
      this.b = param1String;
      this.i = true;
      this.k = new RoomDatabase.c();
    }
    
    public a<T> a(Migration... param1VarArgs) {
      if (this.l == null)
        this.l = new HashSet<Integer>(); 
      int k = param1VarArgs.length;
      int j = 0;
      int i;
      for (i = 0; i < k; i++) {
        Migration migration = param1VarArgs[i];
        this.l.add(Integer.valueOf(((g1.a)migration).a));
        this.l.add(Integer.valueOf(((g1.a)migration).b));
      } 
      RoomDatabase.c c1 = this.k;
      Objects.requireNonNull(c1);
      k = param1VarArgs.length;
      for (i = j; i < k; i++) {
        Migration migration = param1VarArgs[i];
        j = ((g1.a)migration).a;
        int m = ((g1.a)migration).b;
        TreeMap<Object, Object> treeMap2 = (TreeMap)c1.a.get(Integer.valueOf(j));
        TreeMap<Object, Object> treeMap1 = treeMap2;
        if (treeMap2 == null) {
          treeMap1 = new TreeMap<Object, Object>();
          c1.a.put(Integer.valueOf(j), treeMap1);
        } 
        g1.a a1 = (g1.a)treeMap1.get(Integer.valueOf(m));
        if (a1 != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Overriding migration ");
          stringBuilder.append(a1);
          stringBuilder.append(" with ");
          stringBuilder.append(migration);
          Log.w("ROOM", stringBuilder.toString());
        } 
        treeMap1.put(Integer.valueOf(m), migration);
      } 
      return this;
    }
  }
  
  public static abstract class b {
    public void a(i1.a param1a) {}
  }
  
  public static class c {
    public HashMap<Integer, TreeMap<Integer, g1.a>> a = new HashMap<Integer, TreeMap<Integer, g1.a>>();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\room\RoomDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */