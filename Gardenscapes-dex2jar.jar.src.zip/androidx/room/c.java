package androidx.room;

import i1.b;

public class c extends b.a {
  public a b;
  
  public final a c;
  
  public c(a parama, a parama1, String paramString1, String paramString2) {
    super(parama1.a);
    this.b = parama;
    this.c = parama1;
  }
  
  public void b(i1.a parama, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Landroidx/room/a;
    //   4: astore #10
    //   6: iconst_1
    //   7: istore #8
    //   9: iconst_0
    //   10: istore #7
    //   12: aload #10
    //   14: ifnull -> 520
    //   17: aload #10
    //   19: getfield d : Landroidx/room/RoomDatabase$c;
    //   22: astore #12
    //   24: aload #12
    //   26: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   29: pop
    //   30: iload_2
    //   31: iload_3
    //   32: if_icmpne -> 43
    //   35: invokestatic emptyList : ()Ljava/util/List;
    //   38: astore #10
    //   40: goto -> 266
    //   43: iload_3
    //   44: iload_2
    //   45: if_icmple -> 54
    //   48: iconst_1
    //   49: istore #5
    //   51: goto -> 57
    //   54: iconst_0
    //   55: istore #5
    //   57: new java/util/ArrayList
    //   60: dup
    //   61: invokespecial <init> : ()V
    //   64: astore #11
    //   66: iload_2
    //   67: istore #4
    //   69: iload #5
    //   71: ifeq -> 83
    //   74: iload #4
    //   76: iload_3
    //   77: if_icmpge -> 262
    //   80: goto -> 89
    //   83: iload #4
    //   85: iload_3
    //   86: if_icmple -> 262
    //   89: aload #12
    //   91: getfield a : Ljava/util/HashMap;
    //   94: iload #4
    //   96: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   99: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   102: checkcast java/util/TreeMap
    //   105: astore #13
    //   107: aload #13
    //   109: ifnonnull -> 115
    //   112: goto -> 253
    //   115: iload #5
    //   117: ifeq -> 130
    //   120: aload #13
    //   122: invokevirtual descendingKeySet : ()Ljava/util/NavigableSet;
    //   125: astore #10
    //   127: goto -> 137
    //   130: aload #13
    //   132: invokevirtual keySet : ()Ljava/util/Set;
    //   135: astore #10
    //   137: aload #10
    //   139: invokeinterface iterator : ()Ljava/util/Iterator;
    //   144: astore #10
    //   146: aload #10
    //   148: invokeinterface hasNext : ()Z
    //   153: ifeq -> 245
    //   156: aload #10
    //   158: invokeinterface next : ()Ljava/lang/Object;
    //   163: checkcast java/lang/Integer
    //   166: invokevirtual intValue : ()I
    //   169: istore #9
    //   171: iload #5
    //   173: ifeq -> 192
    //   176: iload #9
    //   178: iload_3
    //   179: if_icmpgt -> 211
    //   182: iload #9
    //   184: iload #4
    //   186: if_icmple -> 211
    //   189: goto -> 205
    //   192: iload #9
    //   194: iload_3
    //   195: if_icmplt -> 211
    //   198: iload #9
    //   200: iload #4
    //   202: if_icmpge -> 211
    //   205: iconst_1
    //   206: istore #6
    //   208: goto -> 214
    //   211: iconst_0
    //   212: istore #6
    //   214: iload #6
    //   216: ifeq -> 146
    //   219: aload #11
    //   221: aload #13
    //   223: iload #9
    //   225: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   228: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   231: invokevirtual add : (Ljava/lang/Object;)Z
    //   234: pop
    //   235: iconst_1
    //   236: istore #6
    //   238: iload #9
    //   240: istore #4
    //   242: goto -> 248
    //   245: iconst_0
    //   246: istore #6
    //   248: iload #6
    //   250: ifne -> 259
    //   253: aconst_null
    //   254: astore #10
    //   256: goto -> 266
    //   259: goto -> 69
    //   262: aload #11
    //   264: astore #10
    //   266: aload #10
    //   268: ifnull -> 520
    //   271: aload_0
    //   272: getfield c : Landroidx/room/c$a;
    //   275: checkcast androidx/work/impl/WorkDatabase_Impl$a
    //   278: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   281: pop
    //   282: new java/util/ArrayList
    //   285: dup
    //   286: invokespecial <init> : ()V
    //   289: astore #13
    //   291: aload_1
    //   292: checkcast j1/a
    //   295: astore #11
    //   297: aload #11
    //   299: new h5/yy
    //   302: dup
    //   303: ldc 'SELECT name FROM sqlite_master WHERE type = 'trigger''
    //   305: invokespecial <init> : (Ljava/lang/String;)V
    //   308: invokevirtual d : (Li1/d;)Landroid/database/Cursor;
    //   311: astore #12
    //   313: aload #12
    //   315: invokeinterface moveToNext : ()Z
    //   320: ifeq -> 340
    //   323: aload #13
    //   325: aload #12
    //   327: iconst_0
    //   328: invokeinterface getString : (I)Ljava/lang/String;
    //   333: invokevirtual add : (Ljava/lang/Object;)Z
    //   336: pop
    //   337: goto -> 313
    //   340: aload #12
    //   342: invokeinterface close : ()V
    //   347: aload #13
    //   349: invokevirtual iterator : ()Ljava/util/Iterator;
    //   352: astore #12
    //   354: aload #12
    //   356: invokeinterface hasNext : ()Z
    //   361: ifeq -> 408
    //   364: aload #12
    //   366: invokeinterface next : ()Ljava/lang/Object;
    //   371: checkcast java/lang/String
    //   374: astore #13
    //   376: aload #13
    //   378: ldc 'room_fts_content_sync_'
    //   380: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   383: ifeq -> 354
    //   386: ldc 'DROP TRIGGER IF EXISTS '
    //   388: aload #13
    //   390: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   393: astore #13
    //   395: aload #11
    //   397: getfield f : Landroid/database/sqlite/SQLiteDatabase;
    //   400: aload #13
    //   402: invokevirtual execSQL : (Ljava/lang/String;)V
    //   405: goto -> 354
    //   408: aload #10
    //   410: invokeinterface iterator : ()Ljava/util/Iterator;
    //   415: astore #10
    //   417: aload #10
    //   419: invokeinterface hasNext : ()Z
    //   424: ifeq -> 444
    //   427: aload #10
    //   429: invokeinterface next : ()Ljava/lang/Object;
    //   434: checkcast g1/a
    //   437: aload_1
    //   438: invokevirtual a : (Li1/a;)V
    //   441: goto -> 417
    //   444: aload_0
    //   445: getfield c : Landroidx/room/c$a;
    //   448: aload_1
    //   449: invokevirtual b : (Li1/a;)Landroidx/room/c$b;
    //   452: astore #10
    //   454: aload #10
    //   456: getfield a : Z
    //   459: ifeq -> 482
    //   462: aload_0
    //   463: getfield c : Landroidx/room/c$a;
    //   466: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   469: pop
    //   470: aload_0
    //   471: aload_1
    //   472: invokevirtual c : (Li1/a;)V
    //   475: iload #8
    //   477: istore #4
    //   479: goto -> 523
    //   482: ldc 'Migration didn't properly handle: '
    //   484: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   487: astore_1
    //   488: aload_1
    //   489: aload #10
    //   491: getfield b : Ljava/lang/String;
    //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: new java/lang/IllegalStateException
    //   501: dup
    //   502: aload_1
    //   503: invokevirtual toString : ()Ljava/lang/String;
    //   506: invokespecial <init> : (Ljava/lang/String;)V
    //   509: athrow
    //   510: astore_1
    //   511: aload #12
    //   513: invokeinterface close : ()V
    //   518: aload_1
    //   519: athrow
    //   520: iconst_0
    //   521: istore #4
    //   523: iload #4
    //   525: ifne -> 769
    //   528: aload_0
    //   529: getfield b : Landroidx/room/a;
    //   532: astore #10
    //   534: aload #10
    //   536: ifnull -> 716
    //   539: aload #10
    //   541: iload_2
    //   542: iload_3
    //   543: invokevirtual a : (II)Z
    //   546: ifne -> 716
    //   549: aload_0
    //   550: getfield c : Landroidx/room/c$a;
    //   553: checkcast androidx/work/impl/WorkDatabase_Impl$a
    //   556: astore #10
    //   558: aload #10
    //   560: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   563: pop
    //   564: aload_1
    //   565: checkcast j1/a
    //   568: astore #11
    //   570: aload #11
    //   572: getfield f : Landroid/database/sqlite/SQLiteDatabase;
    //   575: ldc 'DROP TABLE IF EXISTS `Dependency`'
    //   577: invokevirtual execSQL : (Ljava/lang/String;)V
    //   580: aload #11
    //   582: getfield f : Landroid/database/sqlite/SQLiteDatabase;
    //   585: ldc 'DROP TABLE IF EXISTS `WorkSpec`'
    //   587: invokevirtual execSQL : (Ljava/lang/String;)V
    //   590: aload #11
    //   592: getfield f : Landroid/database/sqlite/SQLiteDatabase;
    //   595: ldc 'DROP TABLE IF EXISTS `WorkTag`'
    //   597: invokevirtual execSQL : (Ljava/lang/String;)V
    //   600: aload #11
    //   602: getfield f : Landroid/database/sqlite/SQLiteDatabase;
    //   605: ldc 'DROP TABLE IF EXISTS `SystemIdInfo`'
    //   607: invokevirtual execSQL : (Ljava/lang/String;)V
    //   610: aload #11
    //   612: getfield f : Landroid/database/sqlite/SQLiteDatabase;
    //   615: ldc 'DROP TABLE IF EXISTS `WorkName`'
    //   617: invokevirtual execSQL : (Ljava/lang/String;)V
    //   620: aload #11
    //   622: getfield f : Landroid/database/sqlite/SQLiteDatabase;
    //   625: ldc 'DROP TABLE IF EXISTS `WorkProgress`'
    //   627: invokevirtual execSQL : (Ljava/lang/String;)V
    //   630: aload #11
    //   632: getfield f : Landroid/database/sqlite/SQLiteDatabase;
    //   635: ldc 'DROP TABLE IF EXISTS `Preference`'
    //   637: invokevirtual execSQL : (Ljava/lang/String;)V
    //   640: aload #10
    //   642: getfield b : Landroidx/work/impl/WorkDatabase_Impl;
    //   645: astore #11
    //   647: getstatic androidx/work/impl/WorkDatabase_Impl.s : I
    //   650: istore_2
    //   651: aload #11
    //   653: getfield g : Ljava/util/List;
    //   656: astore #11
    //   658: aload #11
    //   660: ifnull -> 707
    //   663: aload #11
    //   665: invokeinterface size : ()I
    //   670: istore_3
    //   671: iload #7
    //   673: istore_2
    //   674: iload_2
    //   675: iload_3
    //   676: if_icmpge -> 707
    //   679: aload #10
    //   681: getfield b : Landroidx/work/impl/WorkDatabase_Impl;
    //   684: getfield g : Ljava/util/List;
    //   687: iload_2
    //   688: invokeinterface get : (I)Ljava/lang/Object;
    //   693: checkcast androidx/room/RoomDatabase$b
    //   696: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   699: pop
    //   700: iload_2
    //   701: iconst_1
    //   702: iadd
    //   703: istore_2
    //   704: goto -> 674
    //   707: aload_0
    //   708: getfield c : Landroidx/room/c$a;
    //   711: aload_1
    //   712: invokevirtual a : (Li1/a;)V
    //   715: return
    //   716: new java/lang/StringBuilder
    //   719: dup
    //   720: invokespecial <init> : ()V
    //   723: astore_1
    //   724: aload_1
    //   725: ldc 'A migration from '
    //   727: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   730: pop
    //   731: aload_1
    //   732: iload_2
    //   733: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   736: pop
    //   737: aload_1
    //   738: ldc ' to '
    //   740: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   743: pop
    //   744: aload_1
    //   745: iload_3
    //   746: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   749: pop
    //   750: aload_1
    //   751: ldc ' was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.'
    //   753: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   756: pop
    //   757: new java/lang/IllegalStateException
    //   760: dup
    //   761: aload_1
    //   762: invokevirtual toString : ()Ljava/lang/String;
    //   765: invokespecial <init> : (Ljava/lang/String;)V
    //   768: athrow
    //   769: return
    // Exception table:
    //   from	to	target	type
    //   313	337	510	finally
  }
  
  public final void c(i1.a parama) {
    j1.a a1 = (j1.a)parama;
    a1.f.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
    a1.f.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'c103703e120ae8cc73c9248622f3cd1e')");
  }
  
  public static abstract class a {
    public final int a;
    
    public a(int param1Int) {
      this.a = param1Int;
    }
    
    public abstract void a(i1.a param1a);
    
    public abstract c.b b(i1.a param1a);
  }
  
  public static class b {
    public final boolean a;
    
    public final String b;
    
    public b(boolean param1Boolean, String param1String) {
      this.a = param1Boolean;
      this.b = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\room\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */