package androidx.room;

import android.content.Context;
import android.util.Log;
import androidx.compose.ui.geometry.Rect;
import androidx.compose.ui.layout.LayoutCoordinatesKt;
import androidx.compose.ui.node.LayoutNode;
import androidx.compose.ui.node.LayoutNodeLayoutDelegate;
import androidx.lifecycle.LiveData;
import io.sentry.SentryLevel;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.util.Set;
import m9.o;

public class b {
  public final Set<LiveData> a;
  
  public Object b;
  
  public b(FileChannel paramFileChannel, FileLock paramFileLock) {
    this.a = (Set<LiveData>)paramFileChannel;
    this.b = paramFileLock;
  }
  
  public b(o paramo) {
    this.b = null;
    this.a = (Set<LiveData>)paramo;
    try {
      Field field = Class.forName("androidx.compose.ui.node.LayoutNode").getDeclaredField("layoutDelegate");
      this.b = field;
      field.setAccessible(true);
      return;
    } catch (Exception exception) {
      paramo.a(SentryLevel.WARNING, "Could not find LayoutNode.layoutDelegate field", new Object[0]);
      return;
    } 
  }
  
  public static b a(Context paramContext, String paramString) {
    String str;
    try {
      FileChannel fileChannel = (new RandomAccessFile(new File(paramContext.getFilesDir(), paramString), "rw")).getChannel();
      try {
        FileLock fileLock = fileChannel.lock();
        try {
          return new b(fileChannel, fileLock);
        } catch (IOException iOException) {
        
        } catch (Error error) {
        
        } catch (OverlappingFileLockException null) {}
      } catch (IOException iOException) {
        paramString = null;
      } catch (Error error) {
      
      } catch (OverlappingFileLockException null) {}
    } catch (IOException iOException) {
      str = null;
      paramString = str;
    } catch (Error error) {
    
    } catch (OverlappingFileLockException overlappingFileLockException) {}
    Log.e("CrossProcessLock", "encountered error while creating and acquiring the lock, ignoring", overlappingFileLockException);
    if (paramString != null)
      try {
        paramString.release();
      } catch (IOException iOException) {} 
    if (str != null)
      try {
        str.close();
        return null;
      } catch (IOException iOException) {
        return null;
      }  
    return null;
  }
  
  public Rect b(LayoutNode paramLayoutNode) {
    Object object = this.b;
    if ((Field)object != null)
      try {
        return LayoutCoordinatesKt.boundsInWindow(((LayoutNodeLayoutDelegate)((Field)object).get(paramLayoutNode)).getOuterCoordinator().getCoordinates());
      } catch (Exception exception) {
        ((o)this.a).d(SentryLevel.WARNING, "Could not fetch position for LayoutNode", exception);
      }  
    return null;
  }
  
  public void c() {
    try {
      ((FileLock)this.b).release();
      ((FileChannel)this.a).close();
      return;
    } catch (IOException iOException) {
      Log.e("CrossProcessLock", "encountered error while releasing, ignoring", iOException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\room\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */