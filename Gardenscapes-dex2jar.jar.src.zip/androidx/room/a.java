package androidx.room;

import android.content.Context;
import i1.b;
import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

public class a {
  public final b.c a;
  
  public final Context b;
  
  public final String c;
  
  public final RoomDatabase.c d;
  
  public final List<RoomDatabase.b> e;
  
  public final boolean f;
  
  public final RoomDatabase.JournalMode g;
  
  public final Executor h;
  
  public final Executor i;
  
  public final boolean j;
  
  public final boolean k;
  
  public a(Context paramContext, String paramString1, b.c paramc, RoomDatabase.c paramc1, List<RoomDatabase.b> paramList, boolean paramBoolean1, RoomDatabase.JournalMode paramJournalMode, Executor paramExecutor1, Executor paramExecutor2, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, Set<Integer> paramSet, String paramString2, File paramFile) {
    this.a = paramc;
    this.b = paramContext;
    this.c = paramString1;
    this.d = paramc1;
    this.e = paramList;
    this.f = paramBoolean1;
    this.g = paramJournalMode;
    this.h = paramExecutor1;
    this.i = paramExecutor2;
    this.j = paramBoolean3;
    this.k = paramBoolean4;
  }
  
  public boolean a(int paramInt1, int paramInt2) {
    if (paramInt1 > paramInt2) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    return (paramInt1 != 0 && this.k) ? false : (this.j);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\androidx\room\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */