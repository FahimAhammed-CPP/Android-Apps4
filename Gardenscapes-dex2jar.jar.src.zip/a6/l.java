package a6;

public interface l<TResult> {
  void a(g<TResult> paramg);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a6\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */