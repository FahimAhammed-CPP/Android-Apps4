package a6;

import com.google.android.gms.common.internal.e;
import com.google.android.gms.tasks.f;
import java.util.Objects;

public class h<TResult> {
  public final f<TResult> a = new f();
  
  public boolean a(Exception paramException) {
    f<TResult> f1 = this.a;
    Objects.requireNonNull(f1);
    e.j(paramException, "Exception must not be null");
    synchronized (f1.a) {
      if (f1.c)
        return false; 
      f1.c = true;
      f1.f = paramException;
      f1.b.b((g)f1);
      return true;
    } 
  }
  
  public boolean b(TResult paramTResult) {
    f<TResult> f1 = this.a;
    synchronized (f1.a) {
      if (f1.c)
        return false; 
      f1.c = true;
      f1.e = paramTResult;
      f1.b.b((g)f1);
      return true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a6\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */