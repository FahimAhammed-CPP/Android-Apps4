package a6;

public interface d {
  void c(Exception paramException);
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a6\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */