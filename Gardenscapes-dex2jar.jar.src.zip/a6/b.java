package a6;

public interface b {
  void d();
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\a6\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */