package com.android.billingclient.api;

import android.text.TextUtils;
import com.google.android.gms.internal.play_billing.zzm;
import com.google.android.gms.internal.play_billing.zzu;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

public class BillingFlowParams {
  public static final String EXTRA_PARAM_KEY_ACCOUNT_ID = "accountId";
  
  private boolean zza;
  
  private String zzb;
  
  private String zzc;
  
  private SubscriptionUpdateParams zzd;
  
  private zzu zze;
  
  private ArrayList zzf;
  
  private boolean zzg;
  
  private BillingFlowParams() {}
  
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public final int zza() {
    return this.zzd.zza();
  }
  
  public final String zzb() {
    return this.zzb;
  }
  
  public final String zzc() {
    return this.zzc;
  }
  
  public final String zzd() {
    return this.zzd.zzc();
  }
  
  public final String zze() {
    return this.zzd.zzd();
  }
  
  public final ArrayList zzf() {
    ArrayList arrayList = new ArrayList();
    arrayList.addAll(this.zzf);
    return arrayList;
  }
  
  public final List zzg() {
    return (List)this.zze;
  }
  
  public final boolean zzo() {
    return this.zzg;
  }
  
  final boolean zzp() {
    return !(this.zzb == null && this.zzc == null && this.zzd.zzd() == null && this.zzd.zza() == 0 && !this.zza && !this.zzg);
  }
  
  public static class Builder {
    private String zza;
    
    private String zzb;
    
    private List zzc;
    
    private ArrayList zzd;
    
    private boolean zze;
    
    private BillingFlowParams.SubscriptionUpdateParams.Builder zzf;
    
    private Builder() {
      BillingFlowParams.SubscriptionUpdateParams.Builder builder = BillingFlowParams.SubscriptionUpdateParams.newBuilder();
      BillingFlowParams.SubscriptionUpdateParams.Builder.zza(builder);
      this.zzf = builder;
    }
    
    public BillingFlowParams build() {
      // Byte code:
      //   0: aload_0
      //   1: getfield zzd : Ljava/util/ArrayList;
      //   4: astore #7
      //   6: iconst_1
      //   7: istore #6
      //   9: aload #7
      //   11: ifnull -> 27
      //   14: aload #7
      //   16: invokevirtual isEmpty : ()Z
      //   19: ifne -> 27
      //   22: iconst_1
      //   23: istore_1
      //   24: goto -> 29
      //   27: iconst_0
      //   28: istore_1
      //   29: aload_0
      //   30: getfield zzc : Ljava/util/List;
      //   33: astore #7
      //   35: aload #7
      //   37: ifnull -> 55
      //   40: aload #7
      //   42: invokeinterface isEmpty : ()Z
      //   47: ifne -> 55
      //   50: iconst_1
      //   51: istore_2
      //   52: goto -> 57
      //   55: iconst_0
      //   56: istore_2
      //   57: iload_1
      //   58: ifne -> 78
      //   61: iload_2
      //   62: ifeq -> 68
      //   65: goto -> 78
      //   68: new java/lang/IllegalArgumentException
      //   71: dup
      //   72: ldc 'Details of the products must be provided.'
      //   74: invokespecial <init> : (Ljava/lang/String;)V
      //   77: athrow
      //   78: iload_1
      //   79: ifeq -> 99
      //   82: iload_2
      //   83: ifne -> 89
      //   86: goto -> 99
      //   89: new java/lang/IllegalArgumentException
      //   92: dup
      //   93: ldc 'Set SkuDetails or ProductDetailsParams, not both.'
      //   95: invokespecial <init> : (Ljava/lang/String;)V
      //   98: athrow
      //   99: iload_1
      //   100: ifeq -> 346
      //   103: aload_0
      //   104: getfield zzd : Ljava/util/ArrayList;
      //   107: aconst_null
      //   108: invokevirtual contains : (Ljava/lang/Object;)Z
      //   111: ifne -> 336
      //   114: aload_0
      //   115: getfield zzd : Ljava/util/ArrayList;
      //   118: invokevirtual size : ()I
      //   121: iconst_1
      //   122: if_icmple -> 572
      //   125: aload_0
      //   126: getfield zzd : Ljava/util/ArrayList;
      //   129: iconst_0
      //   130: invokevirtual get : (I)Ljava/lang/Object;
      //   133: checkcast com/android/billingclient/api/SkuDetails
      //   136: astore #8
      //   138: aload #8
      //   140: invokevirtual getType : ()Ljava/lang/String;
      //   143: astore #7
      //   145: aload_0
      //   146: getfield zzd : Ljava/util/ArrayList;
      //   149: astore #9
      //   151: aload #9
      //   153: invokeinterface size : ()I
      //   158: istore #4
      //   160: iconst_0
      //   161: istore_3
      //   162: iload_3
      //   163: iload #4
      //   165: if_icmpge -> 237
      //   168: aload #9
      //   170: iload_3
      //   171: invokeinterface get : (I)Ljava/lang/Object;
      //   176: checkcast com/android/billingclient/api/SkuDetails
      //   179: astore #10
      //   181: aload #7
      //   183: ldc 'play_pass_subs'
      //   185: invokevirtual equals : (Ljava/lang/Object;)Z
      //   188: ifne -> 230
      //   191: aload #10
      //   193: invokevirtual getType : ()Ljava/lang/String;
      //   196: ldc 'play_pass_subs'
      //   198: invokevirtual equals : (Ljava/lang/Object;)Z
      //   201: ifne -> 230
      //   204: aload #7
      //   206: aload #10
      //   208: invokevirtual getType : ()Ljava/lang/String;
      //   211: invokevirtual equals : (Ljava/lang/Object;)Z
      //   214: ifeq -> 220
      //   217: goto -> 230
      //   220: new java/lang/IllegalArgumentException
      //   223: dup
      //   224: ldc 'SKUs should have the same type.'
      //   226: invokespecial <init> : (Ljava/lang/String;)V
      //   229: athrow
      //   230: iload_3
      //   231: iconst_1
      //   232: iadd
      //   233: istore_3
      //   234: goto -> 162
      //   237: aload #8
      //   239: invokevirtual zzd : ()Ljava/lang/String;
      //   242: astore #8
      //   244: aload_0
      //   245: getfield zzd : Ljava/util/ArrayList;
      //   248: astore #9
      //   250: aload #9
      //   252: invokeinterface size : ()I
      //   257: istore #4
      //   259: iconst_0
      //   260: istore_3
      //   261: iload_3
      //   262: iload #4
      //   264: if_icmpge -> 572
      //   267: aload #9
      //   269: iload_3
      //   270: invokeinterface get : (I)Ljava/lang/Object;
      //   275: checkcast com/android/billingclient/api/SkuDetails
      //   278: astore #10
      //   280: aload #7
      //   282: ldc 'play_pass_subs'
      //   284: invokevirtual equals : (Ljava/lang/Object;)Z
      //   287: ifne -> 329
      //   290: aload #10
      //   292: invokevirtual getType : ()Ljava/lang/String;
      //   295: ldc 'play_pass_subs'
      //   297: invokevirtual equals : (Ljava/lang/Object;)Z
      //   300: ifne -> 329
      //   303: aload #8
      //   305: aload #10
      //   307: invokevirtual zzd : ()Ljava/lang/String;
      //   310: invokevirtual equals : (Ljava/lang/Object;)Z
      //   313: ifeq -> 319
      //   316: goto -> 329
      //   319: new java/lang/IllegalArgumentException
      //   322: dup
      //   323: ldc 'All SKUs must have the same package name.'
      //   325: invokespecial <init> : (Ljava/lang/String;)V
      //   328: athrow
      //   329: iload_3
      //   330: iconst_1
      //   331: iadd
      //   332: istore_3
      //   333: goto -> 261
      //   336: new java/lang/IllegalArgumentException
      //   339: dup
      //   340: ldc 'SKU cannot be null.'
      //   342: invokespecial <init> : (Ljava/lang/String;)V
      //   345: athrow
      //   346: aload_0
      //   347: getfield zzc : Ljava/util/List;
      //   350: iconst_0
      //   351: invokeinterface get : (I)Ljava/lang/Object;
      //   356: checkcast com/android/billingclient/api/BillingFlowParams$ProductDetailsParams
      //   359: astore #7
      //   361: iconst_0
      //   362: istore_3
      //   363: iload_3
      //   364: aload_0
      //   365: getfield zzc : Ljava/util/List;
      //   368: invokeinterface size : ()I
      //   373: if_icmpge -> 468
      //   376: aload_0
      //   377: getfield zzc : Ljava/util/List;
      //   380: iload_3
      //   381: invokeinterface get : (I)Ljava/lang/Object;
      //   386: checkcast com/android/billingclient/api/BillingFlowParams$ProductDetailsParams
      //   389: astore #8
      //   391: aload #8
      //   393: ifnull -> 458
      //   396: iload_3
      //   397: ifeq -> 451
      //   400: aload #8
      //   402: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   405: invokevirtual getProductType : ()Ljava/lang/String;
      //   408: aload #7
      //   410: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   413: invokevirtual getProductType : ()Ljava/lang/String;
      //   416: invokevirtual equals : (Ljava/lang/Object;)Z
      //   419: ifne -> 451
      //   422: aload #8
      //   424: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   427: invokevirtual getProductType : ()Ljava/lang/String;
      //   430: ldc 'play_pass_subs'
      //   432: invokevirtual equals : (Ljava/lang/Object;)Z
      //   435: ifeq -> 441
      //   438: goto -> 451
      //   441: new java/lang/IllegalArgumentException
      //   444: dup
      //   445: ldc 'All products should have same ProductType.'
      //   447: invokespecial <init> : (Ljava/lang/String;)V
      //   450: athrow
      //   451: iload_3
      //   452: iconst_1
      //   453: iadd
      //   454: istore_3
      //   455: goto -> 363
      //   458: new java/lang/IllegalArgumentException
      //   461: dup
      //   462: ldc 'ProductDetailsParams cannot be null.'
      //   464: invokespecial <init> : (Ljava/lang/String;)V
      //   467: athrow
      //   468: aload #7
      //   470: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   473: invokevirtual zza : ()Ljava/lang/String;
      //   476: astore #8
      //   478: aload_0
      //   479: getfield zzc : Ljava/util/List;
      //   482: invokeinterface iterator : ()Ljava/util/Iterator;
      //   487: astore #9
      //   489: aload #9
      //   491: invokeinterface hasNext : ()Z
      //   496: ifeq -> 572
      //   499: aload #9
      //   501: invokeinterface next : ()Ljava/lang/Object;
      //   506: checkcast com/android/billingclient/api/BillingFlowParams$ProductDetailsParams
      //   509: astore #10
      //   511: aload #7
      //   513: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   516: invokevirtual getProductType : ()Ljava/lang/String;
      //   519: ldc 'play_pass_subs'
      //   521: invokevirtual equals : (Ljava/lang/Object;)Z
      //   524: ifne -> 489
      //   527: aload #10
      //   529: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   532: invokevirtual getProductType : ()Ljava/lang/String;
      //   535: ldc 'play_pass_subs'
      //   537: invokevirtual equals : (Ljava/lang/Object;)Z
      //   540: ifne -> 489
      //   543: aload #8
      //   545: aload #10
      //   547: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   550: invokevirtual zza : ()Ljava/lang/String;
      //   553: invokevirtual equals : (Ljava/lang/Object;)Z
      //   556: ifeq -> 562
      //   559: goto -> 489
      //   562: new java/lang/IllegalArgumentException
      //   565: dup
      //   566: ldc 'All products must have the same package name.'
      //   568: invokespecial <init> : (Ljava/lang/String;)V
      //   571: athrow
      //   572: new com/android/billingclient/api/BillingFlowParams
      //   575: dup
      //   576: aconst_null
      //   577: invokespecial <init> : (Lcom/android/billingclient/api/zzaz;)V
      //   580: astore #8
      //   582: iload_1
      //   583: ifeq -> 610
      //   586: iload #6
      //   588: istore #5
      //   590: aload_0
      //   591: getfield zzd : Ljava/util/ArrayList;
      //   594: iconst_0
      //   595: invokevirtual get : (I)Ljava/lang/Object;
      //   598: checkcast com/android/billingclient/api/SkuDetails
      //   601: invokevirtual zzd : ()Ljava/lang/String;
      //   604: invokevirtual isEmpty : ()Z
      //   607: ifeq -> 649
      //   610: iload_2
      //   611: ifeq -> 646
      //   614: aload_0
      //   615: getfield zzc : Ljava/util/List;
      //   618: iconst_0
      //   619: invokeinterface get : (I)Ljava/lang/Object;
      //   624: checkcast com/android/billingclient/api/BillingFlowParams$ProductDetailsParams
      //   627: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   630: invokevirtual zza : ()Ljava/lang/String;
      //   633: invokevirtual isEmpty : ()Z
      //   636: ifne -> 646
      //   639: iload #6
      //   641: istore #5
      //   643: goto -> 649
      //   646: iconst_0
      //   647: istore #5
      //   649: aload #8
      //   651: iload #5
      //   653: invokestatic zzh : (Lcom/android/billingclient/api/BillingFlowParams;Z)V
      //   656: aload #8
      //   658: aload_0
      //   659: getfield zza : Ljava/lang/String;
      //   662: invokestatic zzj : (Lcom/android/billingclient/api/BillingFlowParams;Ljava/lang/String;)V
      //   665: aload #8
      //   667: aload_0
      //   668: getfield zzb : Ljava/lang/String;
      //   671: invokestatic zzk : (Lcom/android/billingclient/api/BillingFlowParams;Ljava/lang/String;)V
      //   674: aload #8
      //   676: aload_0
      //   677: getfield zzf : Lcom/android/billingclient/api/BillingFlowParams$SubscriptionUpdateParams$Builder;
      //   680: invokevirtual build : ()Lcom/android/billingclient/api/BillingFlowParams$SubscriptionUpdateParams;
      //   683: invokestatic zzn : (Lcom/android/billingclient/api/BillingFlowParams;Lcom/android/billingclient/api/BillingFlowParams$SubscriptionUpdateParams;)V
      //   686: aload_0
      //   687: getfield zzd : Ljava/util/ArrayList;
      //   690: astore #7
      //   692: aload #7
      //   694: ifnull -> 711
      //   697: new java/util/ArrayList
      //   700: dup
      //   701: aload #7
      //   703: invokespecial <init> : (Ljava/util/Collection;)V
      //   706: astore #7
      //   708: goto -> 720
      //   711: new java/util/ArrayList
      //   714: dup
      //   715: invokespecial <init> : ()V
      //   718: astore #7
      //   720: aload #8
      //   722: aload #7
      //   724: invokestatic zzm : (Lcom/android/billingclient/api/BillingFlowParams;Ljava/util/ArrayList;)V
      //   727: aload #8
      //   729: aload_0
      //   730: getfield zze : Z
      //   733: invokestatic zzi : (Lcom/android/billingclient/api/BillingFlowParams;Z)V
      //   736: aload_0
      //   737: getfield zzc : Ljava/util/List;
      //   740: astore #7
      //   742: aload #7
      //   744: ifnull -> 757
      //   747: aload #7
      //   749: invokestatic zzj : (Ljava/util/Collection;)Lcom/google/android/gms/internal/play_billing/zzu;
      //   752: astore #7
      //   754: goto -> 762
      //   757: invokestatic zzk : ()Lcom/google/android/gms/internal/play_billing/zzu;
      //   760: astore #7
      //   762: aload #8
      //   764: aload #7
      //   766: invokestatic zzl : (Lcom/android/billingclient/api/BillingFlowParams;Lcom/google/android/gms/internal/play_billing/zzu;)V
      //   769: aload #8
      //   771: areturn
    }
    
    public Builder setIsOfferPersonalized(boolean param1Boolean) {
      this.zze = param1Boolean;
      return this;
    }
    
    public Builder setObfuscatedAccountId(String param1String) {
      this.zza = param1String;
      return this;
    }
    
    public Builder setObfuscatedProfileId(String param1String) {
      this.zzb = param1String;
      return this;
    }
    
    public Builder setProductDetailsParamsList(List<BillingFlowParams.ProductDetailsParams> param1List) {
      this.zzc = new ArrayList<BillingFlowParams.ProductDetailsParams>(param1List);
      return this;
    }
    
    @Deprecated
    public Builder setSkuDetails(SkuDetails param1SkuDetails) {
      ArrayList<SkuDetails> arrayList = new ArrayList();
      arrayList.add(param1SkuDetails);
      this.zzd = arrayList;
      return this;
    }
    
    public Builder setSubscriptionUpdateParams(BillingFlowParams.SubscriptionUpdateParams param1SubscriptionUpdateParams) {
      this.zzf = BillingFlowParams.SubscriptionUpdateParams.zzb(param1SubscriptionUpdateParams);
      return this;
    }
  }
  
  public static final class ProductDetailsParams {
    private final ProductDetails zza;
    
    private final String zzb;
    
    public static Builder newBuilder() {
      return new Builder(null);
    }
    
    public final ProductDetails zza() {
      return this.zza;
    }
    
    public final String zzb() {
      return this.zzb;
    }
    
    public static class Builder {
      private ProductDetails zza;
      
      private String zzb;
      
      private Builder() {}
      
      public BillingFlowParams.ProductDetailsParams build() {
        zzm.zzc(this.zza, "ProductDetails is required for constructing ProductDetailsParams.");
        zzm.zzc(this.zzb, "offerToken is required for constructing ProductDetailsParams.");
        return new BillingFlowParams.ProductDetailsParams(this, null);
      }
      
      public Builder setOfferToken(String param2String) {
        this.zzb = param2String;
        return this;
      }
      
      public Builder setProductDetails(ProductDetails param2ProductDetails) {
        this.zza = param2ProductDetails;
        if (param2ProductDetails.getOneTimePurchaseOfferDetails() != null) {
          if (param2ProductDetails.getOneTimePurchaseOfferDetails() != null) {
            this.zzb = param2ProductDetails.getOneTimePurchaseOfferDetails().zza();
            return this;
          } 
          throw null;
        } 
        return this;
      }
    }
  }
  
  public static class Builder {
    private ProductDetails zza;
    
    private String zzb;
    
    private Builder() {}
    
    public BillingFlowParams.ProductDetailsParams build() {
      zzm.zzc(this.zza, "ProductDetails is required for constructing ProductDetailsParams.");
      zzm.zzc(this.zzb, "offerToken is required for constructing ProductDetailsParams.");
      return new BillingFlowParams.ProductDetailsParams(this, null);
    }
    
    public Builder setOfferToken(String param1String) {
      this.zzb = param1String;
      return this;
    }
    
    public Builder setProductDetails(ProductDetails param1ProductDetails) {
      this.zza = param1ProductDetails;
      if (param1ProductDetails.getOneTimePurchaseOfferDetails() != null) {
        if (param1ProductDetails.getOneTimePurchaseOfferDetails() != null) {
          this.zzb = param1ProductDetails.getOneTimePurchaseOfferDetails().zza();
          return this;
        } 
        throw null;
      } 
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ProrationMode {
    public static final int DEFERRED = 4;
    
    public static final int IMMEDIATE_AND_CHARGE_FULL_PRICE = 5;
    
    public static final int IMMEDIATE_AND_CHARGE_PRORATED_PRICE = 2;
    
    public static final int IMMEDIATE_WITHOUT_PRORATION = 3;
    
    public static final int IMMEDIATE_WITH_TIME_PRORATION = 1;
    
    public static final int UNKNOWN_SUBSCRIPTION_UPGRADE_DOWNGRADE_POLICY = 0;
  }
  
  public static class SubscriptionUpdateParams {
    private String zza;
    
    private String zzb;
    
    private int zzc = 0;
    
    private SubscriptionUpdateParams() {}
    
    public static Builder newBuilder() {
      return new Builder(null);
    }
    
    final int zza() {
      return this.zzc;
    }
    
    final String zzc() {
      return this.zza;
    }
    
    final String zzd() {
      return this.zzb;
    }
    
    public static class Builder {
      private String zza;
      
      private String zzb;
      
      private boolean zzc;
      
      private int zzd = 0;
      
      private Builder() {}
      
      public BillingFlowParams.SubscriptionUpdateParams build() {
        boolean bool;
        if (!TextUtils.isEmpty(this.zza) || !TextUtils.isEmpty(null)) {
          bool = true;
        } else {
          bool = false;
        } 
        int i = true ^ TextUtils.isEmpty(this.zzb);
        if (!bool || i == 0) {
          if (this.zzc || bool || i != 0) {
            BillingFlowParams.SubscriptionUpdateParams subscriptionUpdateParams = new BillingFlowParams.SubscriptionUpdateParams(null);
            BillingFlowParams.SubscriptionUpdateParams.zze(subscriptionUpdateParams, this.zza);
            BillingFlowParams.SubscriptionUpdateParams.zzg(subscriptionUpdateParams, this.zzd);
            BillingFlowParams.SubscriptionUpdateParams.zzf(subscriptionUpdateParams, this.zzb);
            return subscriptionUpdateParams;
          } 
          throw new IllegalArgumentException("Old SKU purchase information(token/id) or original external transaction id must be provided.");
        } 
        throw new IllegalArgumentException("Please provide Old SKU purchase information(token/id) or original external transaction id, not both.");
      }
      
      public Builder setOldPurchaseToken(String param2String) {
        this.zza = param2String;
        return this;
      }
      
      @Deprecated
      public Builder setOldSkuPurchaseToken(String param2String) {
        this.zza = param2String;
        return this;
      }
      
      public Builder setOriginalExternalTransactionId(String param2String) {
        this.zzb = param2String;
        return this;
      }
      
      public Builder setReplaceProrationMode(int param2Int) {
        this.zzd = param2Int;
        return this;
      }
      
      @Deprecated
      public Builder setReplaceSkusProrationMode(int param2Int) {
        this.zzd = param2Int;
        return this;
      }
    }
  }
  
  public static class Builder {
    private String zza;
    
    private String zzb;
    
    private boolean zzc;
    
    private int zzd = 0;
    
    private Builder() {}
    
    public BillingFlowParams.SubscriptionUpdateParams build() {
      boolean bool;
      if (!TextUtils.isEmpty(this.zza) || !TextUtils.isEmpty(null)) {
        bool = true;
      } else {
        bool = false;
      } 
      int i = true ^ TextUtils.isEmpty(this.zzb);
      if (!bool || i == 0) {
        if (this.zzc || bool || i != 0) {
          BillingFlowParams.SubscriptionUpdateParams subscriptionUpdateParams = new BillingFlowParams.SubscriptionUpdateParams(null);
          BillingFlowParams.SubscriptionUpdateParams.zze(subscriptionUpdateParams, this.zza);
          BillingFlowParams.SubscriptionUpdateParams.zzg(subscriptionUpdateParams, this.zzd);
          BillingFlowParams.SubscriptionUpdateParams.zzf(subscriptionUpdateParams, this.zzb);
          return subscriptionUpdateParams;
        } 
        throw new IllegalArgumentException("Old SKU purchase information(token/id) or original external transaction id must be provided.");
      } 
      throw new IllegalArgumentException("Please provide Old SKU purchase information(token/id) or original external transaction id, not both.");
    }
    
    public Builder setOldPurchaseToken(String param1String) {
      this.zza = param1String;
      return this;
    }
    
    @Deprecated
    public Builder setOldSkuPurchaseToken(String param1String) {
      this.zza = param1String;
      return this;
    }
    
    public Builder setOriginalExternalTransactionId(String param1String) {
      this.zzb = param1String;
      return this;
    }
    
    public Builder setReplaceProrationMode(int param1Int) {
      this.zzd = param1Int;
      return this;
    }
    
    @Deprecated
    public Builder setReplaceSkusProrationMode(int param1Int) {
      this.zzd = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\com\android\billingclient\api\BillingFlowParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */