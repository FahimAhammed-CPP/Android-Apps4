package com.android.billingclient.api;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.ResultReceiver;
import com.google.android.gms.internal.play_billing.zzb;

public class ProxyBillingActivity extends Activity {
  static final String KEY_IN_APP_MESSAGE_RESULT_RECEIVER = "in_app_message_result_receiver";
  
  static final String KEY_PRICE_CHANGE_RESULT_RECEIVER = "result_receiver";
  
  private static final String KEY_SEND_CANCELLED_BROADCAST_IF_FINISHED = "send_cancelled_broadcast_if_finished";
  
  private static final int REQUEST_CODE_FIRST_PARTY_PURCHASE_FLOW = 110;
  
  private static final int REQUEST_CODE_IN_APP_MESSAGE_FLOW = 101;
  
  private static final int REQUEST_CODE_LAUNCH_ACTIVITY = 100;
  
  private static final String TAG = "ProxyBillingActivity";
  
  private ResultReceiver inAppMessageResultReceiver;
  
  private boolean isFlowFromFirstPartyClient;
  
  private ResultReceiver priceChangeResultReceiver;
  
  private boolean sendCancelledBroadcastIfFinished;
  
  private Intent makeAlternativeBillingIntent(String paramString) {
    Intent intent = new Intent("com.android.vending.billing.ALTERNATIVE_BILLING");
    intent.setPackage(getApplicationContext().getPackageName());
    intent.putExtra("ALTERNATIVE_BILLING_USER_CHOICE_DATA", paramString);
    return intent;
  }
  
  private Intent makePurchasesUpdatedIntent() {
    Intent intent = new Intent("com.android.vending.billing.PURCHASES_UPDATED");
    intent.setPackage(getApplicationContext().getPackageName());
    return intent;
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    StringBuilder stringBuilder;
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    ResultReceiver resultReceiver1 = null;
    ResultReceiver resultReceiver3 = null;
    if (paramInt1 == 100 || paramInt1 == 110) {
      int j = zzb.zzd(paramIntent, "ProxyBillingActivity").getResponseCode();
      int i = paramInt2;
      if (paramInt2 == -1)
        if (j != 0) {
          i = -1;
        } else {
          paramInt2 = 0;
          resultReceiver3 = this.priceChangeResultReceiver;
        }  
      stringBuilder = new StringBuilder();
      stringBuilder.append("Activity finished with resultCode ");
      stringBuilder.append(i);
      stringBuilder.append(" and billing's responseCode: ");
      stringBuilder.append(j);
      zzb.zzj("ProxyBillingActivity", stringBuilder.toString());
      paramInt2 = j;
    } else {
      if (paramInt1 == 101) {
        paramInt1 = zzb.zza(paramIntent, "ProxyBillingActivity");
        resultReceiver1 = this.inAppMessageResultReceiver;
        if (resultReceiver1 != null) {
          StringBuilder stringBuilder1;
          Bundle bundle;
          if (paramIntent == null) {
            stringBuilder1 = stringBuilder;
          } else {
            bundle = stringBuilder1.getExtras();
          } 
          resultReceiver1.send(paramInt1, bundle);
        } 
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Got onActivityResult with wrong requestCode: ");
        stringBuilder1.append(paramInt1);
        stringBuilder1.append("; skipping...");
        zzb.zzj("ProxyBillingActivity", stringBuilder1.toString());
      } 
      this.sendCancelledBroadcastIfFinished = false;
      finish();
    } 
    ResultReceiver resultReceiver2 = this.priceChangeResultReceiver;
  }
  
  protected void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_1
    //   6: ifnonnull -> 313
    //   9: ldc 'ProxyBillingActivity'
    //   11: ldc 'Launching Play Store billing flow'
    //   13: invokestatic zzi : (Ljava/lang/String;Ljava/lang/String;)V
    //   16: aload_0
    //   17: invokevirtual getIntent : ()Landroid/content/Intent;
    //   20: ldc 'BUY_INTENT'
    //   22: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   25: ifeq -> 85
    //   28: aload_0
    //   29: invokevirtual getIntent : ()Landroid/content/Intent;
    //   32: ldc 'BUY_INTENT'
    //   34: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   37: checkcast android/app/PendingIntent
    //   40: astore_3
    //   41: aload_3
    //   42: astore_1
    //   43: aload_0
    //   44: invokevirtual getIntent : ()Landroid/content/Intent;
    //   47: ldc_w 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   50: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   53: ifeq -> 128
    //   56: aload_3
    //   57: astore_1
    //   58: aload_0
    //   59: invokevirtual getIntent : ()Landroid/content/Intent;
    //   62: ldc_w 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   65: iconst_0
    //   66: invokevirtual getBooleanExtra : (Ljava/lang/String;Z)Z
    //   69: ifeq -> 128
    //   72: aload_0
    //   73: iconst_1
    //   74: putfield isFlowFromFirstPartyClient : Z
    //   77: bipush #110
    //   79: istore_2
    //   80: aload_3
    //   81: astore_1
    //   82: goto -> 188
    //   85: aload_0
    //   86: invokevirtual getIntent : ()Landroid/content/Intent;
    //   89: ldc_w 'SUBS_MANAGEMENT_INTENT'
    //   92: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   95: ifeq -> 134
    //   98: aload_0
    //   99: invokevirtual getIntent : ()Landroid/content/Intent;
    //   102: ldc_w 'SUBS_MANAGEMENT_INTENT'
    //   105: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   108: checkcast android/app/PendingIntent
    //   111: astore_1
    //   112: aload_0
    //   113: aload_0
    //   114: invokevirtual getIntent : ()Landroid/content/Intent;
    //   117: ldc 'result_receiver'
    //   119: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   122: checkcast android/os/ResultReceiver
    //   125: putfield priceChangeResultReceiver : Landroid/os/ResultReceiver;
    //   128: bipush #100
    //   130: istore_2
    //   131: goto -> 188
    //   134: aload_0
    //   135: invokevirtual getIntent : ()Landroid/content/Intent;
    //   138: ldc_w 'IN_APP_MESSAGE_INTENT'
    //   141: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   144: ifeq -> 183
    //   147: aload_0
    //   148: invokevirtual getIntent : ()Landroid/content/Intent;
    //   151: ldc_w 'IN_APP_MESSAGE_INTENT'
    //   154: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   157: checkcast android/app/PendingIntent
    //   160: astore_1
    //   161: aload_0
    //   162: aload_0
    //   163: invokevirtual getIntent : ()Landroid/content/Intent;
    //   166: ldc 'in_app_message_result_receiver'
    //   168: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   171: checkcast android/os/ResultReceiver
    //   174: putfield inAppMessageResultReceiver : Landroid/os/ResultReceiver;
    //   177: bipush #101
    //   179: istore_2
    //   180: goto -> 188
    //   183: aconst_null
    //   184: astore_1
    //   185: goto -> 128
    //   188: aload_0
    //   189: iconst_1
    //   190: putfield sendCancelledBroadcastIfFinished : Z
    //   193: aload_0
    //   194: aload_1
    //   195: invokevirtual getIntentSender : ()Landroid/content/IntentSender;
    //   198: iload_2
    //   199: new android/content/Intent
    //   202: dup
    //   203: invokespecial <init> : ()V
    //   206: iconst_0
    //   207: iconst_0
    //   208: iconst_0
    //   209: invokevirtual startIntentSenderForResult : (Landroid/content/IntentSender;ILandroid/content/Intent;III)V
    //   212: return
    //   213: astore_1
    //   214: ldc 'ProxyBillingActivity'
    //   216: ldc_w 'Got exception while trying to start a purchase flow.'
    //   219: aload_1
    //   220: invokestatic zzk : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   223: aload_0
    //   224: getfield priceChangeResultReceiver : Landroid/os/ResultReceiver;
    //   227: astore_1
    //   228: aload_1
    //   229: ifnull -> 242
    //   232: aload_1
    //   233: bipush #6
    //   235: aconst_null
    //   236: invokevirtual send : (ILandroid/os/Bundle;)V
    //   239: goto -> 303
    //   242: aload_0
    //   243: getfield inAppMessageResultReceiver : Landroid/os/ResultReceiver;
    //   246: astore_1
    //   247: aload_1
    //   248: ifnull -> 260
    //   251: aload_1
    //   252: iconst_0
    //   253: aconst_null
    //   254: invokevirtual send : (ILandroid/os/Bundle;)V
    //   257: goto -> 303
    //   260: aload_0
    //   261: invokespecial makePurchasesUpdatedIntent : ()Landroid/content/Intent;
    //   264: astore_1
    //   265: aload_0
    //   266: getfield isFlowFromFirstPartyClient : Z
    //   269: ifeq -> 280
    //   272: aload_1
    //   273: ldc 'IS_FIRST_PARTY_PURCHASE'
    //   275: iconst_1
    //   276: invokevirtual putExtra : (Ljava/lang/String;Z)Landroid/content/Intent;
    //   279: pop
    //   280: aload_1
    //   281: ldc 'RESPONSE_CODE'
    //   283: bipush #6
    //   285: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   288: pop
    //   289: aload_1
    //   290: ldc 'DEBUG_MESSAGE'
    //   292: ldc 'An internal error occurred.'
    //   294: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   297: pop
    //   298: aload_0
    //   299: aload_1
    //   300: invokevirtual sendBroadcast : (Landroid/content/Intent;)V
    //   303: aload_0
    //   304: iconst_0
    //   305: putfield sendCancelledBroadcastIfFinished : Z
    //   308: aload_0
    //   309: invokevirtual finish : ()V
    //   312: return
    //   313: ldc 'ProxyBillingActivity'
    //   315: ldc_w 'Launching Play Store billing flow from savedInstanceState'
    //   318: invokestatic zzi : (Ljava/lang/String;Ljava/lang/String;)V
    //   321: aload_0
    //   322: aload_1
    //   323: ldc 'send_cancelled_broadcast_if_finished'
    //   325: iconst_0
    //   326: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   329: putfield sendCancelledBroadcastIfFinished : Z
    //   332: aload_1
    //   333: ldc 'result_receiver'
    //   335: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   338: ifeq -> 357
    //   341: aload_0
    //   342: aload_1
    //   343: ldc 'result_receiver'
    //   345: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   348: checkcast android/os/ResultReceiver
    //   351: putfield priceChangeResultReceiver : Landroid/os/ResultReceiver;
    //   354: goto -> 379
    //   357: aload_1
    //   358: ldc 'in_app_message_result_receiver'
    //   360: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   363: ifeq -> 379
    //   366: aload_0
    //   367: aload_1
    //   368: ldc 'in_app_message_result_receiver'
    //   370: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   373: checkcast android/os/ResultReceiver
    //   376: putfield inAppMessageResultReceiver : Landroid/os/ResultReceiver;
    //   379: aload_0
    //   380: aload_1
    //   381: ldc_w 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   384: iconst_0
    //   385: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   388: putfield isFlowFromFirstPartyClient : Z
    //   391: return
    // Exception table:
    //   from	to	target	type
    //   188	212	213	android/content/IntentSender$SendIntentException
  }
  
  protected void onDestroy() {
    super.onDestroy();
    if (!isFinishing())
      return; 
    if (!this.sendCancelledBroadcastIfFinished)
      return; 
    Intent intent = makePurchasesUpdatedIntent();
    intent.putExtra("RESPONSE_CODE", 1);
    intent.putExtra("DEBUG_MESSAGE", "Billing dialog closed.");
    sendBroadcast(intent);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    ResultReceiver resultReceiver = this.priceChangeResultReceiver;
    if (resultReceiver != null)
      paramBundle.putParcelable("result_receiver", (Parcelable)resultReceiver); 
    resultReceiver = this.inAppMessageResultReceiver;
    if (resultReceiver != null)
      paramBundle.putParcelable("in_app_message_result_receiver", (Parcelable)resultReceiver); 
    paramBundle.putBoolean("send_cancelled_broadcast_if_finished", this.sendCancelledBroadcastIfFinished);
    paramBundle.putBoolean("IS_FLOW_FROM_FIRST_PARTY_CLIENT", this.isFlowFromFirstPartyClient);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\com\android\billingclient\api\ProxyBillingActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */