package com.android.billingclient.api;

import org.json.JSONException;

@Deprecated
public class PriceChangeFlowParams {
  private SkuDetails skuDetails;
  
  public static Builder newBuilder() {
    return new Builder();
  }
  
  public SkuDetails getSkuDetails() {
    return this.skuDetails;
  }
  
  @Deprecated
  public static class Builder {
    private SkuDetails skuDetails;
    
    private Builder setSkuDetails(String param1String) {
      try {
        this.skuDetails = new SkuDetails(param1String);
        return this;
      } catch (JSONException jSONException) {
        throw new IllegalArgumentException("Incorrect skuDetails JSON object!", jSONException);
      } 
    }
    
    public PriceChangeFlowParams build() {
      SkuDetails skuDetails = this.skuDetails;
      if (skuDetails != null) {
        PriceChangeFlowParams priceChangeFlowParams = new PriceChangeFlowParams();
        PriceChangeFlowParams.-$$Nest$fputskuDetails(priceChangeFlowParams, skuDetails);
        return priceChangeFlowParams;
      } 
      throw new IllegalArgumentException("SkuDetails must be set");
    }
    
    public Builder setSkuDetails(SkuDetails param1SkuDetails) {
      this.skuDetails = param1SkuDetails;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\com\android\billingclient\api\PriceChangeFlowParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */