package com.android.billingclient.api;

public final class AcknowledgePurchaseParams {
  private String zza;
  
  private AcknowledgePurchaseParams() {}
  
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public String getPurchaseToken() {
    return this.zza;
  }
  
  public static final class Builder {
    private String zza;
    
    private Builder() {}
    
    public AcknowledgePurchaseParams build() {
      String str = this.zza;
      if (str != null) {
        AcknowledgePurchaseParams acknowledgePurchaseParams = new AcknowledgePurchaseParams(null);
        AcknowledgePurchaseParams.zza(acknowledgePurchaseParams, str);
        return acknowledgePurchaseParams;
      } 
      throw new IllegalArgumentException("Purchase token must be set");
    }
    
    public Builder setPurchaseToken(String param1String) {
      this.zza = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\com\android\billingclient\api\AcknowledgePurchaseParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */