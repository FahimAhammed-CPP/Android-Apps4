package com.android.billingclient.api;

public interface InAppMessageResponseListener {
  void onInAppMessageResponse(InAppMessageResult paramInAppMessageResult);
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\com\android\billingclient\api\InAppMessageResponseListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */