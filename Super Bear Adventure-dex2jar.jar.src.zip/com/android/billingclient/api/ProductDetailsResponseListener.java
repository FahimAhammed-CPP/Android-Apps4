package com.android.billingclient.api;

import java.util.List;

public interface ProductDetailsResponseListener {
  void onProductDetailsResponse(BillingResult paramBillingResult, List<ProductDetails> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\com\android\billingclient\api\ProductDetailsResponseListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */