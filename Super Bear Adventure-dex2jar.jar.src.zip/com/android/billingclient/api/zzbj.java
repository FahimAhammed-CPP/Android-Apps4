package com.android.billingclient.api;

import org.json.JSONException;
import org.json.JSONObject;

public final class zzbj {
  zzbj(JSONObject paramJSONObject) throws JSONException {
    paramJSONObject.getInt("maximumQuantity");
    paramJSONObject.getInt("remainingQuantity");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\com\android\billingclient\api\zzbj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */