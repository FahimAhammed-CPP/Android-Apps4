package com.android.billingclient.api;

import android.text.TextUtils;

public final class zzbw {
  private String zza;
  
  private zzbw() {}
  
  public final zzbw zza(String paramString) {
    this.zza = paramString;
    return this;
  }
  
  public final zzby zzb() {
    if (!TextUtils.isEmpty(this.zza))
      return new zzby(this.zza, null, null, 0, null); 
    throw new IllegalArgumentException("SKU must be set.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\com\android\billingclient\api\zzbw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */