package com.android.billingclient.api;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.text.TextUtils;
import android.view.View;
import androidx.core.app.BundleCompat;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zze;
import com.google.android.gms.internal.play_billing.zzfl;
import com.google.android.gms.internal.play_billing.zzfm;
import com.google.android.gms.internal.play_billing.zzg;
import com.google.android.gms.internal.play_billing.zzu;
import com.google.android.gms.internal.play_billing.zzz;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;

class BillingClientImpl extends BillingClient {
  private volatile int zza = 0;
  
  private final String zzb;
  
  private final Handler zzc = new Handler(Looper.getMainLooper());
  
  private volatile zzo zzd;
  
  private Context zze;
  
  private volatile zze zzf;
  
  private volatile zzap zzg;
  
  private boolean zzh;
  
  private boolean zzi;
  
  private int zzj = 0;
  
  private boolean zzk;
  
  private boolean zzl;
  
  private boolean zzm;
  
  private boolean zzn;
  
  private boolean zzo;
  
  private boolean zzp;
  
  private boolean zzq;
  
  private boolean zzr;
  
  private boolean zzs;
  
  private boolean zzt;
  
  private boolean zzu;
  
  private boolean zzv;
  
  private boolean zzw;
  
  private boolean zzx;
  
  private ExecutorService zzy;
  
  private zzbh zzz;
  
  private BillingClientImpl(Activity paramActivity, boolean paramBoolean1, boolean paramBoolean2, String paramString) {
    this(paramActivity.getApplicationContext(), paramBoolean1, paramBoolean2, new zzat(), paramString, null, null);
  }
  
  private BillingClientImpl(Context paramContext, boolean paramBoolean1, boolean paramBoolean2, PurchasesUpdatedListener paramPurchasesUpdatedListener, String paramString1, String paramString2, AlternativeBillingListener paramAlternativeBillingListener) {
    this.zzb = paramString1;
    initialize(paramContext, paramPurchasesUpdatedListener, paramBoolean1, paramBoolean2, paramAlternativeBillingListener, paramString1);
  }
  
  private BillingClientImpl(String paramString) {
    this.zzb = paramString;
  }
  
  BillingClientImpl(String paramString, boolean paramBoolean, Context paramContext, zzbf paramzzbf) {
    this.zzb = zzK();
    this.zze = paramContext.getApplicationContext();
    zzfl zzfl = zzfm.zzu();
    zzfl.zzj(zzK());
    zzfl.zzi(this.zze.getPackageName());
    zzfm zzfm = (zzfm)zzfl.zzc();
    this.zzz = new zzbh();
    zzb.zzj("BillingClient", "Billing client should have a valid listener but the provided is null.");
    this.zzd = new zzo(this.zze, null, this.zzz);
    this.zzv = paramBoolean;
  }
  
  BillingClientImpl(String paramString, boolean paramBoolean1, boolean paramBoolean2, Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, AlternativeBillingListener paramAlternativeBillingListener) {
    this(paramContext, paramBoolean1, false, paramPurchasesUpdatedListener, zzK(), null, paramAlternativeBillingListener);
  }
  
  private void initialize(Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, boolean paramBoolean1, boolean paramBoolean2, AlternativeBillingListener paramAlternativeBillingListener, String paramString) {
    this.zze = paramContext.getApplicationContext();
    zzfl zzfl = zzfm.zzu();
    zzfl.zzj(paramString);
    zzfl.zzi(this.zze.getPackageName());
    zzfm zzfm = (zzfm)zzfl.zzc();
    this.zzz = new zzbh();
    if (paramPurchasesUpdatedListener == null)
      zzb.zzj("BillingClient", "Billing client should have a valid listener but the provided is null."); 
    this.zzd = new zzo(this.zze, paramPurchasesUpdatedListener, paramAlternativeBillingListener, this.zzz);
    this.zzv = paramBoolean1;
    this.zzw = paramBoolean2;
    if (paramAlternativeBillingListener != null) {
      paramBoolean1 = true;
    } else {
      paramBoolean1 = false;
    } 
    this.zzx = paramBoolean1;
  }
  
  private int launchBillingFlowCpp(Activity paramActivity, BillingFlowParams paramBillingFlowParams) {
    return launchBillingFlow(paramActivity, paramBillingFlowParams).getResponseCode();
  }
  
  private void launchPriceChangeConfirmationFlow(Activity paramActivity, PriceChangeFlowParams paramPriceChangeFlowParams, long paramLong) {
    launchPriceChangeConfirmationFlow(paramActivity, paramPriceChangeFlowParams, new zzat(paramLong));
  }
  
  private void startConnection(long paramLong) {
    zzat zzat = new zzat(paramLong);
    if (isReady()) {
      zzb.zzi("BillingClient", "Service connection is valid. No need to re-initialize.");
      zzat.onBillingSetupFinished(zzbc.zzl);
      return;
    } 
    if (this.zza == 1) {
      zzb.zzj("BillingClient", "Client is already in the process of connecting to billing service.");
      zzat.onBillingSetupFinished(zzbc.zzd);
      return;
    } 
    if (this.zza == 3) {
      zzb.zzj("BillingClient", "Client was already closed and can't be reused. Please create another instance.");
      zzat.onBillingSetupFinished(zzbc.zzm);
      return;
    } 
    this.zza = 1;
    this.zzd.zze();
    zzb.zzi("BillingClient", "Starting in-app billing setup.");
    this.zzg = new zzap(this, zzat, null);
    Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
    intent.setPackage("com.android.vending");
    List<ResolveInfo> list = this.zze.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ResolveInfo resolveInfo = list.get(0);
      if (resolveInfo.serviceInfo != null) {
        String str1 = resolveInfo.serviceInfo.packageName;
        String str2 = resolveInfo.serviceInfo.name;
        if ("com.android.vending".equals(str1) && str2 != null) {
          ComponentName componentName = new ComponentName(str1, str2);
          intent = new Intent(intent);
          intent.setComponent(componentName);
          intent.putExtra("playBillingLibraryVersion", this.zzb);
          if (this.zze.bindService(intent, this.zzg, 1)) {
            zzb.zzi("BillingClient", "Service was bonded successfully.");
            return;
          } 
          zzb.zzj("BillingClient", "Connection to Billing service is blocked.");
        } else {
          zzb.zzj("BillingClient", "The device doesn't have valid Play Store.");
        } 
      } 
    } 
    this.zza = 0;
    zzb.zzi("BillingClient", "Billing service unavailable on device.");
    zzat.onBillingSetupFinished(zzbc.zzc);
  }
  
  private final Handler zzH() {
    return (Looper.myLooper() == null) ? this.zzc : new Handler(Looper.myLooper());
  }
  
  private final BillingResult zzI(BillingResult paramBillingResult) {
    if (Thread.interrupted())
      return paramBillingResult; 
    this.zzc.post(new zzag(this, paramBillingResult));
    return paramBillingResult;
  }
  
  private final BillingResult zzJ() {
    return (this.zza == 0 || this.zza == 3) ? zzbc.zzm : zzbc.zzj;
  }
  
  private static String zzK() {
    try {
      return (String)Class.forName("com.android.billingclient.ktx.BuildConfig").getField("VERSION_NAME").get(null);
    } catch (Exception exception) {
      return "5.2.1";
    } 
  }
  
  private final Future zzL(Callable<?> paramCallable, long paramLong, Runnable paramRunnable, Handler paramHandler) {
    if (this.zzy == null)
      this.zzy = Executors.newFixedThreadPool(zzb.zza, new zzal(this)); 
    try {
      Future<?> future = this.zzy.submit(paramCallable);
      double d = paramLong;
      paramHandler.postDelayed(new zzaf(future, paramRunnable), (long)(d * 0.95D));
      return future;
    } catch (Exception exception) {
      zzb.zzk("BillingClient", "Async task throws exception!", exception);
      return null;
    } 
  }
  
  private final void zzM(BillingResult paramBillingResult, PriceChangeConfirmationListener paramPriceChangeConfirmationListener) {
    if (Thread.interrupted())
      return; 
    this.zzc.post(new zzx(paramPriceChangeConfirmationListener, paramBillingResult));
  }
  
  private final void zzN(String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    if (!isReady()) {
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(zzbc.zzm, null);
      return;
    } 
    if (zzL(new zzaj(this, paramString, paramPurchaseHistoryResponseListener), 30000L, new zzw(paramPurchaseHistoryResponseListener), zzH()) == null)
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(zzJ(), null); 
  }
  
  private final void zzO(String paramString, PurchasesResponseListener paramPurchasesResponseListener) {
    if (!isReady()) {
      paramPurchasesResponseListener.onQueryPurchasesResponse(zzbc.zzm, (List<Purchase>)zzu.zzk());
      return;
    } 
    if (TextUtils.isEmpty(paramString)) {
      zzb.zzj("BillingClient", "Please provide a valid product type.");
      paramPurchasesResponseListener.onQueryPurchasesResponse(zzbc.zzg, (List<Purchase>)zzu.zzk());
      return;
    } 
    if (zzL(new zzai(this, paramString, paramPurchasesResponseListener), 30000L, new zzad(paramPurchasesResponseListener), zzH()) == null)
      paramPurchasesResponseListener.onQueryPurchasesResponse(zzJ(), (List<Purchase>)zzu.zzk()); 
  }
  
  private final boolean zzP() {
    return (this.zzu && this.zzw);
  }
  
  public final void acknowledgePurchase(AcknowledgePurchaseParams paramAcknowledgePurchaseParams, AcknowledgePurchaseResponseListener paramAcknowledgePurchaseResponseListener) {
    if (!isReady()) {
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzbc.zzm);
      return;
    } 
    if (TextUtils.isEmpty(paramAcknowledgePurchaseParams.getPurchaseToken())) {
      zzb.zzj("BillingClient", "Please provide a valid purchase token.");
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzbc.zzi);
      return;
    } 
    if (!this.zzm) {
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzbc.zzb);
      return;
    } 
    if (zzL(new zzz(this, paramAcknowledgePurchaseParams, paramAcknowledgePurchaseResponseListener), 30000L, new zzaa(paramAcknowledgePurchaseResponseListener), zzH()) == null)
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzJ()); 
  }
  
  public final void consumeAsync(ConsumeParams paramConsumeParams, ConsumeResponseListener paramConsumeResponseListener) {
    if (!isReady()) {
      paramConsumeResponseListener.onConsumeResponse(zzbc.zzm, paramConsumeParams.getPurchaseToken());
      return;
    } 
    if (zzL(new zzu(this, paramConsumeParams, paramConsumeResponseListener), 30000L, new zzv(paramConsumeResponseListener, paramConsumeParams), zzH()) == null)
      paramConsumeResponseListener.onConsumeResponse(zzJ(), paramConsumeParams.getPurchaseToken()); 
  }
  
  public final void endConnection() {
    Exception exception;
    try {
      this.zzd.zzd();
      if (this.zzg != null)
        this.zzg.zzc(); 
      if (this.zzg != null && this.zzf != null) {
        zzb.zzi("BillingClient", "Unbinding from service.");
        this.zze.unbindService(this.zzg);
        this.zzg = null;
      } 
      this.zzf = null;
      ExecutorService executorService = this.zzy;
      if (executorService != null) {
        executorService.shutdownNow();
        this.zzy = null;
      } 
      this.zza = 3;
      return;
    } catch (Exception null) {
      zzb.zzk("BillingClient", "There was an exception while ending connection!", exception);
      this.zza = 3;
      return;
    } finally {}
    this.zza = 3;
    throw exception;
  }
  
  public final int getConnectionState() {
    return this.zza;
  }
  
  public final BillingResult isFeatureSupported(String paramString) {
    byte b;
    if (!isReady())
      return zzbc.zzm; 
    switch (paramString.hashCode()) {
      default:
        b = -1;
        break;
      case 1987365622:
        if (paramString.equals("subscriptions")) {
          b = 0;
          break;
        } 
      case 207616302:
        if (paramString.equals("priceChangeConfirmation")) {
          b = 2;
          break;
        } 
      case 103272:
        if (paramString.equals("hhh")) {
          b = 10;
          break;
        } 
      case 102279:
        if (paramString.equals("ggg")) {
          b = 9;
          break;
        } 
      case 101286:
        if (paramString.equals("fff")) {
          b = 8;
          break;
        } 
      case 100293:
        if (paramString.equals("eee")) {
          b = 7;
          break;
        } 
      case 99300:
        if (paramString.equals("ddd")) {
          b = 5;
          break;
        } 
      case 98307:
        if (paramString.equals("ccc")) {
          b = 6;
          break;
        } 
      case 97314:
        if (paramString.equals("bbb")) {
          b = 3;
          break;
        } 
      case 96321:
        if (paramString.equals("aaa")) {
          b = 4;
          break;
        } 
      case -422092961:
        if (paramString.equals("subscriptionsUpdate")) {
          b = 1;
          break;
        } 
    } 
    switch (b) {
      default:
        zzb.zzj("BillingClient", "Unsupported feature: ".concat(String.valueOf(paramString)));
        return zzbc.zzy;
      case 10:
        return this.zzt ? zzbc.zzl : zzbc.zzA;
      case 9:
        return this.zzt ? zzbc.zzl : zzbc.zzz;
      case 8:
        return this.zzs ? zzbc.zzl : zzbc.zzv;
      case 6:
      case 7:
        return this.zzr ? zzbc.zzl : zzbc.zzt;
      case 5:
        return this.zzp ? zzbc.zzl : zzbc.zzu;
      case 4:
        return this.zzq ? zzbc.zzl : zzbc.zzs;
      case 3:
        return this.zzo ? zzbc.zzl : zzbc.zzw;
      case 2:
        return this.zzl ? zzbc.zzl : zzbc.zzr;
      case 1:
        return this.zzi ? zzbc.zzl : zzbc.zzp;
      case 0:
        break;
    } 
    return this.zzh ? zzbc.zzl : zzbc.zzo;
  }
  
  public final boolean isReady() {
    return (this.zza == 2 && this.zzf != null && this.zzg != null);
  }
  
  public final BillingResult launchBillingFlow(Activity paramActivity, BillingFlowParams paramBillingFlowParams) {
    String str1;
    String str2;
    BillingFlowParams.ProductDetailsParams productDetailsParams2;
    Bundle bundle;
    BillingClientImpl billingClientImpl = this;
    if (!isReady()) {
      zzba.zza(2, 2, zzbc.zzm);
      BillingResult billingResult = zzbc.zzm;
      billingClientImpl.zzI(billingResult);
      return billingResult;
    } 
    ArrayList<SkuDetails> arrayList = paramBillingFlowParams.zzf();
    List<BillingFlowParams.ProductDetailsParams> list = paramBillingFlowParams.zzg();
    SkuDetails skuDetails = (SkuDetails)zzz.zza(arrayList, null);
    BillingFlowParams.ProductDetailsParams productDetailsParams1 = (BillingFlowParams.ProductDetailsParams)zzz.zza(list, null);
    if (skuDetails != null) {
      str1 = skuDetails.getSku();
      str2 = skuDetails.getType();
    } else {
      str1 = productDetailsParams1.zza().getProductId();
      str2 = productDetailsParams1.zza().getProductType();
    } 
    if (!str2.equals("subs") || billingClientImpl.zzh) {
      if (!paramBillingFlowParams.zzp() || billingClientImpl.zzk) {
        if (arrayList.size() <= 1 || billingClientImpl.zzr) {
          if (list.isEmpty() || billingClientImpl.zzs) {
            if (billingClientImpl.zzk) {
              SkuDetails skuDetails1;
              boolean bool1 = billingClientImpl.zzm;
              boolean bool2 = billingClientImpl.zzu;
              boolean bool3 = billingClientImpl.zzv;
              boolean bool4 = billingClientImpl.zzw;
              boolean bool5 = billingClientImpl.zzx;
              String str = billingClientImpl.zzb;
              bundle = new Bundle();
              bundle.putString("playBillingLibraryVersion", str);
              if (paramBillingFlowParams.zza() != 0)
                bundle.putInt("prorationMode", paramBillingFlowParams.zza()); 
              if (!TextUtils.isEmpty(paramBillingFlowParams.zzb()))
                bundle.putString("accountId", paramBillingFlowParams.zzb()); 
              if (!TextUtils.isEmpty(paramBillingFlowParams.zzc()))
                bundle.putString("obfuscatedProfileId", paramBillingFlowParams.zzc()); 
              if (paramBillingFlowParams.zzo())
                bundle.putBoolean("isOfferPersonalizedByDeveloper", true); 
              if (!TextUtils.isEmpty(null))
                bundle.putStringArrayList("skusToReplace", new ArrayList(Arrays.asList((Object[])new String[] { null }))); 
              if (!TextUtils.isEmpty(paramBillingFlowParams.zzd()))
                bundle.putString("oldSkuPurchaseToken", paramBillingFlowParams.zzd()); 
              if (!TextUtils.isEmpty(null))
                bundle.putString("oldSkuPurchaseId", null); 
              if (!TextUtils.isEmpty(paramBillingFlowParams.zze()))
                bundle.putString("originalExternalTransactionId", paramBillingFlowParams.zze()); 
              if (!TextUtils.isEmpty(null))
                bundle.putString("paymentsPurchaseParams", null); 
              if (bool1 && bool3)
                bundle.putBoolean("enablePendingPurchases", true); 
              if (bool2 && bool4)
                bundle.putBoolean("enablePendingPurchaseForSubscriptions", true); 
              if (bool5)
                bundle.putBoolean("enableAlternativeBilling", true); 
              if (!arrayList.isEmpty()) {
                ArrayList<String> arrayList1 = new ArrayList();
                ArrayList<String> arrayList2 = new ArrayList();
                ArrayList<String> arrayList3 = new ArrayList();
                ArrayList<Integer> arrayList4 = new ArrayList();
                ArrayList<String> arrayList5 = new ArrayList();
                Iterator<SkuDetails> iterator = arrayList.iterator();
                int m = 0;
                int k = 0;
                int j = 0;
                int i = 0;
                while (iterator.hasNext()) {
                  SkuDetails skuDetails2 = iterator.next();
                  if (!skuDetails2.zzf().isEmpty())
                    arrayList1.add(skuDetails2.zzf()); 
                  String str3 = skuDetails2.zzc();
                  String str4 = skuDetails2.zzb();
                  int i1 = skuDetails2.zza();
                  String str5 = skuDetails2.zze();
                  arrayList2.add(str3);
                  m |= TextUtils.isEmpty(str3) ^ true;
                  arrayList3.add(str4);
                  int n = k | TextUtils.isEmpty(str4) ^ true;
                  arrayList4.add(Integer.valueOf(i1));
                  if (i1 != 0) {
                    k = 1;
                  } else {
                    k = 0;
                  } 
                  j |= k;
                  i |= TextUtils.isEmpty(str5) ^ true;
                  arrayList5.add(str5);
                  k = n;
                } 
                if (!arrayList1.isEmpty())
                  bundle.putStringArrayList("skuDetailsTokens", arrayList1); 
                if (m != 0)
                  bundle.putStringArrayList("SKU_OFFER_ID_TOKEN_LIST", arrayList2); 
                if (k != 0)
                  bundle.putStringArrayList("SKU_OFFER_ID_LIST", arrayList3); 
                if (j != 0)
                  bundle.putIntegerArrayList("SKU_OFFER_TYPE_LIST", arrayList4); 
                if (i != 0)
                  bundle.putStringArrayList("SKU_SERIALIZED_DOCID_LIST", arrayList5); 
                productDetailsParams2 = productDetailsParams1;
                skuDetails1 = skuDetails;
                if (arrayList.size() > 1) {
                  ArrayList<String> arrayList6 = new ArrayList(arrayList.size() - 1);
                  ArrayList<String> arrayList7 = new ArrayList(arrayList.size() - 1);
                  for (i = 1; i < arrayList.size(); i++) {
                    arrayList6.add(((SkuDetails)arrayList.get(i)).getSku());
                    arrayList7.add(((SkuDetails)arrayList.get(i)).getType());
                  } 
                  bundle.putStringArrayList("additionalSkus", arrayList6);
                  bundle.putStringArrayList("additionalSkuTypes", arrayList7);
                  BillingFlowParams.ProductDetailsParams productDetailsParams = productDetailsParams1;
                  SkuDetails skuDetails2 = skuDetails;
                } 
              } else {
                arrayList = new ArrayList<SkuDetails>(list.size() - 1);
                ArrayList<String> arrayList3 = new ArrayList(list.size() - 1);
                ArrayList<String> arrayList1 = new ArrayList();
                ArrayList<String> arrayList2 = new ArrayList();
                ArrayList<String> arrayList4 = new ArrayList();
                for (int i = 0; i < list.size(); i++) {
                  BillingFlowParams.ProductDetailsParams productDetailsParams = list.get(i);
                  ProductDetails productDetails = productDetailsParams.zza();
                  if (!productDetails.zzb().isEmpty())
                    arrayList1.add(productDetails.zzb()); 
                  arrayList2.add(productDetailsParams.zzb());
                  if (!TextUtils.isEmpty(productDetails.zzc()))
                    arrayList4.add(productDetails.zzc()); 
                  if (i > 0) {
                    arrayList.add(((BillingFlowParams.ProductDetailsParams)list.get(i)).zza().getProductId());
                    arrayList3.add(((BillingFlowParams.ProductDetailsParams)list.get(i)).zza().getProductType());
                  } 
                } 
                bundle.putStringArrayList("SKU_OFFER_ID_TOKEN_LIST", arrayList2);
                if (!arrayList1.isEmpty())
                  bundle.putStringArrayList("skuDetailsTokens", arrayList1); 
                if (!arrayList4.isEmpty())
                  bundle.putStringArrayList("SKU_SERIALIZED_DOCID_LIST", arrayList4); 
                productDetailsParams2 = productDetailsParams1;
                skuDetails1 = skuDetails;
                if (!arrayList.isEmpty()) {
                  bundle.putStringArrayList("additionalSkus", arrayList);
                  bundle.putStringArrayList("additionalSkuTypes", arrayList3);
                  skuDetails1 = skuDetails;
                  productDetailsParams2 = productDetailsParams1;
                } 
              } 
              bool1 = bundle.containsKey("SKU_OFFER_ID_TOKEN_LIST");
              BillingClientImpl billingClientImpl1 = this;
              if (!bool1 || billingClientImpl1.zzp) {
                if (skuDetails1 != null && !TextUtils.isEmpty(skuDetails1.zzd())) {
                  bundle.putString("skuPackageName", skuDetails1.zzd());
                } else if (productDetailsParams2 != null && !TextUtils.isEmpty(productDetailsParams2.zza().zza())) {
                  bundle.putString("skuPackageName", productDetailsParams2.zza().zza());
                } else {
                  boolean bool6 = false;
                  if (!TextUtils.isEmpty(null))
                    bundle.putString("accountName", null); 
                } 
                boolean bool = true;
              } else {
                zzba.zza(21, 2, zzbc.zzu);
                BillingResult billingResult = zzbc.zzu;
                billingClientImpl1.zzI(billingResult);
                return billingResult;
              } 
            } else {
              String str = "BillingClient";
              Future future = zzL(new zzac((BillingClientImpl)productDetailsParams2, str1, str2), 5000L, null, ((BillingClientImpl)productDetailsParams2).zzc);
              BillingClientImpl billingClientImpl1 = this;
            } 
          } else {
            zzb.zzj("BillingClient", "Current client doesn't support purchases with ProductDetails.");
            zzba.zza(20, 2, zzbc.zzv);
            BillingResult billingResult = zzbc.zzv;
            productDetailsParams2.zzI(billingResult);
            return billingResult;
          } 
        } else {
          zzb.zzj("BillingClient", "Current client doesn't support multi-item purchases.");
          zzba.zza(19, 2, zzbc.zzt);
          BillingResult billingResult = zzbc.zzt;
          productDetailsParams2.zzI(billingResult);
          return billingResult;
        } 
      } else {
        zzb.zzj("BillingClient", "Current client doesn't support extra params for buy intent.");
        zzba.zza(18, 2, zzbc.zzh);
        BillingResult billingResult = zzbc.zzh;
        productDetailsParams2.zzI(billingResult);
        return billingResult;
      } 
    } else {
      zzb.zzj("BillingClient", "Current client doesn't support subscriptions.");
      zzba.zza(9, 2, zzbc.zzo);
      BillingResult billingResult = zzbc.zzo;
      productDetailsParams2.zzI(billingResult);
      return billingResult;
    } 
    if (!TextUtils.isEmpty(null))
      bundle.putString("accountName", null); 
  }
  
  public void launchPriceChangeConfirmationFlow(Activity paramActivity, PriceChangeFlowParams paramPriceChangeFlowParams, PriceChangeConfirmationListener paramPriceChangeConfirmationListener) {
    if (!isReady()) {
      zzM(zzbc.zzm, paramPriceChangeConfirmationListener);
      return;
    } 
    if (paramPriceChangeFlowParams == null || paramPriceChangeFlowParams.getSkuDetails() == null) {
      zzb.zzj("BillingClient", "Please fix the input params. priceChangeFlowParams must contain valid sku.");
      zzM(zzbc.zzk, paramPriceChangeConfirmationListener);
      return;
    } 
    String str = paramPriceChangeFlowParams.getSkuDetails().getSku();
    if (str == null) {
      zzb.zzj("BillingClient", "Please fix the input params. priceChangeFlowParams must contain valid sku.");
      zzM(zzbc.zzk, paramPriceChangeConfirmationListener);
      return;
    } 
    if (!this.zzl) {
      zzb.zzj("BillingClient", "Current client doesn't support price change confirmation flow.");
      zzM(zzbc.zzr, paramPriceChangeConfirmationListener);
      return;
    } 
    Bundle bundle = new Bundle();
    bundle.putString("playBillingLibraryVersion", this.zzb);
    bundle.putBoolean("subs_price_change", true);
    Future<Bundle> future = zzL(new zzr(this, str, bundle), 5000L, null, this.zzc);
    try {
      StringBuilder stringBuilder1;
      Bundle bundle1 = future.get(5000L, TimeUnit.MILLISECONDS);
      int i = zzb.zzb(bundle1, "BillingClient");
      String str1 = zzb.zzf(bundle1, "BillingClient");
      BillingResult.Builder builder = BillingResult.newBuilder();
      builder.setResponseCode(i);
      builder.setDebugMessage(str1);
      BillingResult billingResult = builder.build();
      if (i != 0) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unable to launch price change flow, error response code: ");
        stringBuilder1.append(i);
        zzb.zzj("BillingClient", stringBuilder1.toString());
        zzM(billingResult, paramPriceChangeConfirmationListener);
        return;
      } 
      zzah zzah = new zzah(this, this.zzc, paramPriceChangeConfirmationListener);
      Intent intent = new Intent((Context)stringBuilder1, ProxyBillingActivity.class);
      intent.putExtra("SUBS_MANAGEMENT_INTENT", bundle1.getParcelable("SUBS_MANAGEMENT_INTENT"));
      intent.putExtra("result_receiver", (Parcelable)zzah);
      stringBuilder1.startActivity(intent);
      return;
    } catch (TimeoutException null) {
    
    } catch (CancellationException null) {
    
    } catch (Exception exception) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Exception caught while launching Price Change Flow for sku: ");
      stringBuilder1.append(str);
      stringBuilder1.append("; try to reconnect");
      zzb.zzk("BillingClient", stringBuilder1.toString(), exception);
      zzM(zzbc.zzm, paramPriceChangeConfirmationListener);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Time out while launching Price Change Flow for sku: ");
    stringBuilder.append(str);
    stringBuilder.append("; try to reconnect");
    zzb.zzk("BillingClient", stringBuilder.toString(), exception);
    zzM(zzbc.zzn, paramPriceChangeConfirmationListener);
  }
  
  public void queryProductDetailsAsync(QueryProductDetailsParams paramQueryProductDetailsParams, ProductDetailsResponseListener paramProductDetailsResponseListener) {
    if (!isReady()) {
      paramProductDetailsResponseListener.onProductDetailsResponse(zzbc.zzm, new ArrayList<ProductDetails>());
      return;
    } 
    if (!this.zzs) {
      zzb.zzj("BillingClient", "Querying product details is not supported.");
      paramProductDetailsResponseListener.onProductDetailsResponse(zzbc.zzv, new ArrayList<ProductDetails>());
      return;
    } 
    if (zzL(new zzs(this, paramQueryProductDetailsParams, paramProductDetailsResponseListener), 30000L, new zzt(paramProductDetailsResponseListener), zzH()) == null)
      paramProductDetailsResponseListener.onProductDetailsResponse(zzJ(), new ArrayList<ProductDetails>()); 
  }
  
  public void queryPurchaseHistoryAsync(QueryPurchaseHistoryParams paramQueryPurchaseHistoryParams, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    zzN(paramQueryPurchaseHistoryParams.zza(), paramPurchaseHistoryResponseListener);
  }
  
  public final void queryPurchaseHistoryAsync(String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    zzN(paramString, paramPurchaseHistoryResponseListener);
  }
  
  public void queryPurchasesAsync(QueryPurchasesParams paramQueryPurchasesParams, PurchasesResponseListener paramPurchasesResponseListener) {
    zzO(paramQueryPurchasesParams.zza(), paramPurchasesResponseListener);
  }
  
  public void queryPurchasesAsync(String paramString, PurchasesResponseListener paramPurchasesResponseListener) {
    zzO(paramString, paramPurchasesResponseListener);
  }
  
  public final void querySkuDetailsAsync(SkuDetailsParams paramSkuDetailsParams, SkuDetailsResponseListener paramSkuDetailsResponseListener) {
    if (!isReady()) {
      paramSkuDetailsResponseListener.onSkuDetailsResponse(zzbc.zzm, null);
      return;
    } 
    String str = paramSkuDetailsParams.getSkuType();
    List<String> list = paramSkuDetailsParams.getSkusList();
    if (TextUtils.isEmpty(str)) {
      zzb.zzj("BillingClient", "Please fix the input params. SKU type can't be empty.");
      paramSkuDetailsResponseListener.onSkuDetailsResponse(zzbc.zzf, null);
      return;
    } 
    if (list != null) {
      ArrayList<zzby> arrayList = new ArrayList();
      for (String str1 : list) {
        zzbw zzbw = new zzbw(null);
        zzbw.zza(str1);
        arrayList.add(zzbw.zzb());
      } 
      if (zzL(new zzq(this, str, arrayList, null, paramSkuDetailsResponseListener), 30000L, new zzy(paramSkuDetailsResponseListener), zzH()) == null)
        paramSkuDetailsResponseListener.onSkuDetailsResponse(zzJ(), null); 
      return;
    } 
    zzb.zzj("BillingClient", "Please fix the input params. The list of SKUs can't be empty - set SKU list or SkuWithOffer list.");
    paramSkuDetailsResponseListener.onSkuDetailsResponse(zzbc.zze, null);
  }
  
  public BillingResult showInAppMessages(Activity paramActivity, InAppMessageParams paramInAppMessageParams, InAppMessageResponseListener paramInAppMessageResponseListener) {
    if (!isReady()) {
      zzb.zzj("BillingClient", "Service disconnected.");
      return zzbc.zzm;
    } 
    if (!this.zzo) {
      zzb.zzj("BillingClient", "Current client doesn't support showing in-app messages.");
      return zzbc.zzw;
    } 
    View view = paramActivity.findViewById(16908290);
    IBinder iBinder = view.getWindowToken();
    Rect rect = new Rect();
    view.getGlobalVisibleRect(rect);
    Bundle bundle = new Bundle();
    BundleCompat.putBinder(bundle, "KEY_WINDOW_TOKEN", iBinder);
    bundle.putInt("KEY_DIMEN_LEFT", rect.left);
    bundle.putInt("KEY_DIMEN_TOP", rect.top);
    bundle.putInt("KEY_DIMEN_RIGHT", rect.right);
    bundle.putInt("KEY_DIMEN_BOTTOM", rect.bottom);
    bundle.putString("playBillingLibraryVersion", this.zzb);
    bundle.putIntegerArrayList("KEY_CATEGORY_IDS", paramInAppMessageParams.getInAppMessageCategoriesToShow());
    zzL(new zzae(this, bundle, paramActivity, new zzak(this, this.zzc, paramInAppMessageResponseListener)), 5000L, null, this.zzc);
    return zzbc.zzl;
  }
  
  public final void startConnection(BillingClientStateListener paramBillingClientStateListener) {
    if (isReady()) {
      zzb.zzi("BillingClient", "Service connection is valid. No need to re-initialize.");
      paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzl);
      return;
    } 
    if (this.zza == 1) {
      zzb.zzj("BillingClient", "Client is already in the process of connecting to billing service.");
      paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzd);
      return;
    } 
    if (this.zza == 3) {
      zzb.zzj("BillingClient", "Client was already closed and can't be reused. Please create another instance.");
      paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzm);
      return;
    } 
    this.zza = 1;
    this.zzd.zze();
    zzb.zzi("BillingClient", "Starting in-app billing setup.");
    this.zzg = new zzap(this, paramBillingClientStateListener, null);
    Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
    intent.setPackage("com.android.vending");
    List<ResolveInfo> list = this.zze.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ResolveInfo resolveInfo = list.get(0);
      if (resolveInfo.serviceInfo != null) {
        String str1 = resolveInfo.serviceInfo.packageName;
        String str2 = resolveInfo.serviceInfo.name;
        if ("com.android.vending".equals(str1) && str2 != null) {
          ComponentName componentName = new ComponentName(str1, str2);
          intent = new Intent(intent);
          intent.setComponent(componentName);
          intent.putExtra("playBillingLibraryVersion", this.zzb);
          if (this.zze.bindService(intent, this.zzg, 1)) {
            zzb.zzi("BillingClient", "Service was bonded successfully.");
            return;
          } 
          zzb.zzj("BillingClient", "Connection to Billing service is blocked.");
        } else {
          zzb.zzj("BillingClient", "The device doesn't have valid Play Store.");
        } 
      } 
    } 
    this.zza = 0;
    zzb.zzi("BillingClient", "Billing service unavailable on device.");
    paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzc);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\com\android\billingclient\api\BillingClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */