package androidx.fragment.app;

import android.util.AndroidRuntimeException;

final class SuperNotCalledException extends AndroidRuntimeException {
  public SuperNotCalledException(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\androidx\fragment\app\SuperNotCalledException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */