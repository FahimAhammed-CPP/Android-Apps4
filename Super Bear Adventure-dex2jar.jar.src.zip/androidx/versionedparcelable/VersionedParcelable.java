package androidx.versionedparcelable;

public interface VersionedParcelable {}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\androidx\versionedparcelable\VersionedParcelable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */