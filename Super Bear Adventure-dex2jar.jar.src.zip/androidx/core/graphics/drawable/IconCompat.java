package androidx.core.graphics.drawable;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.util.Preconditions;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {
  private static final float ADAPTIVE_ICON_INSET_FACTOR = 0.25F;
  
  private static final int AMBIENT_SHADOW_ALPHA = 30;
  
  private static final float BLUR_FACTOR = 0.010416667F;
  
  static final PorterDuff.Mode DEFAULT_TINT_MODE = PorterDuff.Mode.SRC_IN;
  
  private static final float DEFAULT_VIEW_PORT_SCALE = 0.6666667F;
  
  private static final String EXTRA_INT1 = "int1";
  
  private static final String EXTRA_INT2 = "int2";
  
  private static final String EXTRA_OBJ = "obj";
  
  private static final String EXTRA_TINT_LIST = "tint_list";
  
  private static final String EXTRA_TINT_MODE = "tint_mode";
  
  private static final String EXTRA_TYPE = "type";
  
  private static final float ICON_DIAMETER_FACTOR = 0.9166667F;
  
  private static final int KEY_SHADOW_ALPHA = 61;
  
  private static final float KEY_SHADOW_OFFSET_FACTOR = 0.020833334F;
  
  private static final String TAG = "IconCompat";
  
  public static final int TYPE_UNKNOWN = -1;
  
  public byte[] mData = null;
  
  public int mInt1 = 0;
  
  public int mInt2 = 0;
  
  Object mObj1;
  
  public Parcelable mParcelable = null;
  
  public ColorStateList mTintList = null;
  
  PorterDuff.Mode mTintMode = DEFAULT_TINT_MODE;
  
  public String mTintModeStr = null;
  
  public int mType = -1;
  
  public IconCompat() {}
  
  private IconCompat(int paramInt) {
    this.mType = paramInt;
  }
  
  public static IconCompat createFromBundle(Bundle paramBundle) {
    StringBuilder stringBuilder;
    int i = paramBundle.getInt("type");
    IconCompat iconCompat = new IconCompat(i);
    iconCompat.mInt1 = paramBundle.getInt("int1");
    iconCompat.mInt2 = paramBundle.getInt("int2");
    if (paramBundle.containsKey("tint_list"))
      iconCompat.mTintList = (ColorStateList)paramBundle.getParcelable("tint_list"); 
    if (paramBundle.containsKey("tint_mode"))
      iconCompat.mTintMode = PorterDuff.Mode.valueOf(paramBundle.getString("tint_mode")); 
    if (i != -1 && i != 1)
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("Unknown type ");
              stringBuilder.append(i);
              Log.w("IconCompat", stringBuilder.toString());
              return null;
            } 
          } else {
            iconCompat.mObj1 = stringBuilder.getString("obj");
            return iconCompat;
          } 
        } else {
          iconCompat.mObj1 = stringBuilder.getByteArray("obj");
          return iconCompat;
        } 
      } else {
        iconCompat.mObj1 = stringBuilder.getString("obj");
        return iconCompat;
      }  
    iconCompat.mObj1 = stringBuilder.getParcelable("obj");
    return iconCompat;
  }
  
  public static IconCompat createFromIcon(Context paramContext, Icon paramIcon) {
    IconCompat iconCompat;
    Preconditions.checkNotNull(paramIcon);
    int i = getType(paramIcon);
    if (i != 2) {
      if (i != 4) {
        iconCompat = new IconCompat(-1);
        iconCompat.mObj1 = paramIcon;
        return iconCompat;
      } 
      return createWithContentUri(getUri(paramIcon));
    } 
    String str = getResPackage(paramIcon);
    try {
      return createWithResource(getResources((Context)iconCompat, str), str, getResId(paramIcon));
    } catch (android.content.res.Resources.NotFoundException notFoundException) {
      throw new IllegalArgumentException("Icon resource cannot be found");
    } 
  }
  
  public static IconCompat createFromIcon(Icon paramIcon) {
    Preconditions.checkNotNull(paramIcon);
    int i = getType(paramIcon);
    if (i != 2) {
      if (i != 4) {
        IconCompat iconCompat = new IconCompat(-1);
        iconCompat.mObj1 = paramIcon;
        return iconCompat;
      } 
      return createWithContentUri(getUri(paramIcon));
    } 
    return createWithResource(null, getResPackage(paramIcon), getResId(paramIcon));
  }
  
  public static IconCompat createFromIconOrNullIfZeroResId(Icon paramIcon) {
    return (getType(paramIcon) == 2 && getResId(paramIcon) == 0) ? null : createFromIcon(paramIcon);
  }
  
  static Bitmap createLegacyIconFromAdaptiveIcon(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
    Matrix matrix = new Matrix();
    matrix.setTranslate((-(paramBitmap.getWidth() - i) / 2), (-(paramBitmap.getHeight() - i) / 2));
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat createWithAdaptiveBitmap(Bitmap paramBitmap) {
    if (paramBitmap != null) {
      IconCompat iconCompat = new IconCompat(5);
      iconCompat.mObj1 = paramBitmap;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Bitmap must not be null.");
  }
  
  public static IconCompat createWithBitmap(Bitmap paramBitmap) {
    if (paramBitmap != null) {
      IconCompat iconCompat = new IconCompat(1);
      iconCompat.mObj1 = paramBitmap;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Bitmap must not be null.");
  }
  
  public static IconCompat createWithContentUri(Uri paramUri) {
    if (paramUri != null)
      return createWithContentUri(paramUri.toString()); 
    throw new IllegalArgumentException("Uri must not be null.");
  }
  
  public static IconCompat createWithContentUri(String paramString) {
    if (paramString != null) {
      IconCompat iconCompat = new IconCompat(4);
      iconCompat.mObj1 = paramString;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Uri must not be null.");
  }
  
  public static IconCompat createWithData(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (paramArrayOfbyte != null) {
      IconCompat iconCompat = new IconCompat(3);
      iconCompat.mObj1 = paramArrayOfbyte;
      iconCompat.mInt1 = paramInt1;
      iconCompat.mInt2 = paramInt2;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Data must not be null.");
  }
  
  public static IconCompat createWithResource(Context paramContext, int paramInt) {
    if (paramContext != null)
      return createWithResource(paramContext.getResources(), paramContext.getPackageName(), paramInt); 
    throw new IllegalArgumentException("Context must not be null.");
  }
  
  public static IconCompat createWithResource(Resources paramResources, String paramString, int paramInt) {
    if (paramString != null) {
      if (paramInt != 0) {
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.mInt1 = paramInt;
        if (paramResources != null)
          try {
            iconCompat.mObj1 = paramResources.getResourceName(paramInt);
            return iconCompat;
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            throw new IllegalArgumentException("Icon resource cannot be found");
          }  
        iconCompat.mObj1 = paramString;
        return iconCompat;
      } 
      throw new IllegalArgumentException("Drawable resource ID must not be 0");
    } 
    throw new IllegalArgumentException("Package must not be null.");
  }
  
  private static int getResId(Icon paramIcon) {
    if (Build.VERSION.SDK_INT >= 28)
      return paramIcon.getResId(); 
    try {
      return ((Integer)paramIcon.getClass().getMethod("getResId", new Class[0]).invoke(paramIcon, new Object[0])).intValue();
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("IconCompat", "Unable to get icon resource", illegalAccessException);
      return 0;
    } catch (InvocationTargetException invocationTargetException) {
      Log.e("IconCompat", "Unable to get icon resource", invocationTargetException);
      return 0;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
      return 0;
    } 
  }
  
  private static String getResPackage(Icon paramIcon) {
    if (Build.VERSION.SDK_INT >= 28)
      return paramIcon.getResPackage(); 
    try {
      return (String)paramIcon.getClass().getMethod("getResPackage", new Class[0]).invoke(paramIcon, new Object[0]);
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("IconCompat", "Unable to get icon package", illegalAccessException);
      return null;
    } catch (InvocationTargetException invocationTargetException) {
      Log.e("IconCompat", "Unable to get icon package", invocationTargetException);
      return null;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.e("IconCompat", "Unable to get icon package", noSuchMethodException);
      return null;
    } 
  }
  
  private static Resources getResources(Context paramContext, String paramString) {
    if ("android".equals(paramString))
      return Resources.getSystem(); 
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      ApplicationInfo applicationInfo = packageManager.getApplicationInfo(paramString, 8192);
      return (applicationInfo != null) ? packageManager.getResourcesForApplication(applicationInfo) : null;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("IconCompat", String.format("Unable to find pkg=%s for icon", new Object[] { paramString }), (Throwable)nameNotFoundException);
      return null;
    } 
  }
  
  private static int getType(Icon paramIcon) {
    if (Build.VERSION.SDK_INT >= 28)
      return paramIcon.getType(); 
    try {
      return ((Integer)paramIcon.getClass().getMethod("getType", new Class[0]).invoke(paramIcon, new Object[0])).intValue();
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to get icon type ");
      stringBuilder.append(paramIcon);
      Log.e("IconCompat", stringBuilder.toString(), illegalAccessException);
      return -1;
    } catch (InvocationTargetException invocationTargetException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to get icon type ");
      stringBuilder.append(paramIcon);
      Log.e("IconCompat", stringBuilder.toString(), invocationTargetException);
      return -1;
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to get icon type ");
      stringBuilder.append(paramIcon);
      Log.e("IconCompat", stringBuilder.toString(), noSuchMethodException);
      return -1;
    } 
  }
  
  private static Uri getUri(Icon paramIcon) {
    if (Build.VERSION.SDK_INT >= 28)
      return paramIcon.getUri(); 
    try {
      return (Uri)paramIcon.getClass().getMethod("getUri", new Class[0]).invoke(paramIcon, new Object[0]);
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("IconCompat", "Unable to get icon uri", illegalAccessException);
      return null;
    } catch (InvocationTargetException invocationTargetException) {
      Log.e("IconCompat", "Unable to get icon uri", invocationTargetException);
      return null;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.e("IconCompat", "Unable to get icon uri", noSuchMethodException);
      return null;
    } 
  }
  
  private Drawable loadDrawableInner(Context paramContext) {
    int i = this.mType;
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4)
            return (Drawable)((i != 5) ? null : new BitmapDrawable(paramContext.getResources(), createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, false))); 
          Uri uri = Uri.parse((String)this.mObj1);
          String str = uri.getScheme();
          if ("content".equals(str) || "file".equals(str)) {
            try {
              InputStream inputStream = paramContext.getContentResolver().openInputStream(uri);
            } catch (Exception null) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unable to load image from URI: ");
              stringBuilder.append(uri);
              Log.w("IconCompat", stringBuilder.toString(), exception);
              exception = null;
            } 
          } else {
            try {
              FileInputStream fileInputStream = new FileInputStream(new File((String)this.mObj1));
            } catch (FileNotFoundException exception) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unable to load image from path: ");
              stringBuilder.append(uri);
              Log.w("IconCompat", stringBuilder.toString(), exception);
              exception = null;
            } 
          } 
          if (exception != null)
            return (Drawable)new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeStream((InputStream)exception)); 
        } else {
          return (Drawable)new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeByteArray((byte[])this.mObj1, this.mInt1, this.mInt2));
        } 
      } else {
        String str2 = getResPackage();
        String str1 = str2;
        if (TextUtils.isEmpty(str2))
          str1 = paramContext.getPackageName(); 
        Resources resources = getResources(paramContext, str1);
        try {
          return ResourcesCompat.getDrawable(resources, this.mInt1, paramContext.getTheme());
        } catch (RuntimeException runtimeException) {
          Log.e("IconCompat", String.format("Unable to load resource 0x%08x from pkg=%s", new Object[] { Integer.valueOf(this.mInt1), this.mObj1 }), runtimeException);
        } 
      } 
      return null;
    } 
    return (Drawable)new BitmapDrawable(runtimeException.getResources(), (Bitmap)this.mObj1);
  }
  
  private static String typeToString(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? "UNKNOWN" : "BITMAP_MASKABLE") : "URI") : "DATA") : "RESOURCE") : "BITMAP";
  }
  
  public void addToShortcutIntent(Intent paramIntent, Drawable paramDrawable, Context paramContext) {
    StringBuilder stringBuilder;
    Bitmap bitmap;
    checkResource(paramContext);
    int i = this.mType;
    if (i != 1) {
      if (i != 2) {
        if (i == 5) {
          bitmap = createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, true);
        } else {
          throw new IllegalArgumentException("Icon type not supported for intent shortcuts");
        } 
      } else {
        try {
          Bitmap bitmap1;
          Context context = bitmap.createPackageContext(getResPackage(), 0);
          if (paramDrawable == null) {
            paramIntent.putExtra("android.intent.extra.shortcut.ICON_RESOURCE", (Parcelable)Intent.ShortcutIconResource.fromContext(context, this.mInt1));
            return;
          } 
          Drawable drawable = ContextCompat.getDrawable(context, this.mInt1);
          if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            i = ((ActivityManager)context.getSystemService("activity")).getLauncherLargeIconSize();
            bitmap1 = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
          } else {
            bitmap1 = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
          } 
          drawable.setBounds(0, 0, bitmap1.getWidth(), bitmap1.getHeight());
          drawable.draw(new Canvas(bitmap1));
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Can't find package ");
          stringBuilder.append(this.mObj1);
          throw new IllegalArgumentException(stringBuilder.toString(), nameNotFoundException);
        } 
      } 
    } else {
      Bitmap bitmap1 = (Bitmap)this.mObj1;
      bitmap = bitmap1;
      if (stringBuilder != null)
        bitmap = bitmap1.copy(bitmap1.getConfig(), true); 
    } 
    if (stringBuilder != null) {
      i = bitmap.getWidth();
      int j = bitmap.getHeight();
      stringBuilder.setBounds(i / 2, j / 2, i, j);
      stringBuilder.draw(new Canvas(bitmap));
    } 
    nameNotFoundException.putExtra("android.intent.extra.shortcut.ICON", (Parcelable)bitmap);
  }
  
  public void checkResource(Context paramContext) {
    if (this.mType == 2) {
      String str3 = (String)this.mObj1;
      if (!str3.contains(":"))
        return; 
      String str2 = str3.split(":", -1)[1];
      String str1 = str2.split("/", -1)[0];
      str2 = str2.split("/", -1)[1];
      str3 = str3.split(":", -1)[0];
      int i = getResources(paramContext, str3).getIdentifier(str2, str1, str3);
      if (this.mInt1 != i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Id has changed for ");
        stringBuilder.append(str3);
        stringBuilder.append("/");
        stringBuilder.append(str2);
        Log.i("IconCompat", stringBuilder.toString());
        this.mInt1 = i;
      } 
    } 
  }
  
  public Bitmap getBitmap() {
    if (this.mType == -1 && Build.VERSION.SDK_INT >= 23) {
      Object object = this.mObj1;
      return (object instanceof Bitmap) ? (Bitmap)object : null;
    } 
    int i = this.mType;
    if (i == 1)
      return (Bitmap)this.mObj1; 
    if (i == 5)
      return createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, true); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getBitmap() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int getResId() {
    if (this.mType == -1 && Build.VERSION.SDK_INT >= 23)
      return getResId((Icon)this.mObj1); 
    if (this.mType == 2)
      return this.mInt1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String getResPackage() {
    if (this.mType == -1 && Build.VERSION.SDK_INT >= 23)
      return getResPackage((Icon)this.mObj1); 
    if (this.mType == 2)
      return ((String)this.mObj1).split(":", -1)[0]; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResPackage() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int getType() {
    return (this.mType == -1 && Build.VERSION.SDK_INT >= 23) ? getType((Icon)this.mObj1) : this.mType;
  }
  
  public Uri getUri() {
    return (this.mType == -1 && Build.VERSION.SDK_INT >= 23) ? getUri((Icon)this.mObj1) : Uri.parse((String)this.mObj1);
  }
  
  public Drawable loadDrawable(Context paramContext) {
    checkResource(paramContext);
    if (Build.VERSION.SDK_INT >= 23)
      return toIcon().loadDrawable(paramContext); 
    Drawable drawable = loadDrawableInner(paramContext);
    if (drawable != null && (this.mTintList != null || this.mTintMode != DEFAULT_TINT_MODE)) {
      drawable.mutate();
      DrawableCompat.setTintList(drawable, this.mTintList);
      DrawableCompat.setTintMode(drawable, this.mTintMode);
    } 
    return drawable;
  }
  
  public void onPostParceling() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield mTintModeStr : Ljava/lang/String;
    //   5: invokestatic valueOf : (Ljava/lang/String;)Landroid/graphics/PorterDuff$Mode;
    //   8: putfield mTintMode : Landroid/graphics/PorterDuff$Mode;
    //   11: aload_0
    //   12: getfield mType : I
    //   15: istore_1
    //   16: iload_1
    //   17: iconst_m1
    //   18: if_icmpeq -> 120
    //   21: iload_1
    //   22: iconst_1
    //   23: if_icmpeq -> 78
    //   26: iload_1
    //   27: iconst_2
    //   28: if_icmpeq -> 56
    //   31: iload_1
    //   32: iconst_3
    //   33: if_icmpeq -> 47
    //   36: iload_1
    //   37: iconst_4
    //   38: if_icmpeq -> 56
    //   41: iload_1
    //   42: iconst_5
    //   43: if_icmpeq -> 78
    //   46: return
    //   47: aload_0
    //   48: aload_0
    //   49: getfield mData : [B
    //   52: putfield mObj1 : Ljava/lang/Object;
    //   55: return
    //   56: aload_0
    //   57: new java/lang/String
    //   60: dup
    //   61: aload_0
    //   62: getfield mData : [B
    //   65: ldc_w 'UTF-16'
    //   68: invokestatic forName : (Ljava/lang/String;)Ljava/nio/charset/Charset;
    //   71: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   74: putfield mObj1 : Ljava/lang/Object;
    //   77: return
    //   78: aload_0
    //   79: getfield mParcelable : Landroid/os/Parcelable;
    //   82: astore_2
    //   83: aload_2
    //   84: ifnull -> 93
    //   87: aload_0
    //   88: aload_2
    //   89: putfield mObj1 : Ljava/lang/Object;
    //   92: return
    //   93: aload_0
    //   94: getfield mData : [B
    //   97: astore_2
    //   98: aload_0
    //   99: aload_2
    //   100: putfield mObj1 : Ljava/lang/Object;
    //   103: aload_0
    //   104: iconst_3
    //   105: putfield mType : I
    //   108: aload_0
    //   109: iconst_0
    //   110: putfield mInt1 : I
    //   113: aload_0
    //   114: aload_2
    //   115: arraylength
    //   116: putfield mInt2 : I
    //   119: return
    //   120: aload_0
    //   121: getfield mParcelable : Landroid/os/Parcelable;
    //   124: astore_2
    //   125: aload_2
    //   126: ifnull -> 135
    //   129: aload_0
    //   130: aload_2
    //   131: putfield mObj1 : Ljava/lang/Object;
    //   134: return
    //   135: new java/lang/IllegalArgumentException
    //   138: dup
    //   139: ldc_w 'Invalid icon'
    //   142: invokespecial <init> : (Ljava/lang/String;)V
    //   145: athrow
  }
  
  public void onPreParceling(boolean paramBoolean) {
    this.mTintModeStr = this.mTintMode.name();
    int i = this.mType;
    if (i != -1) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            if (i != 4) {
              if (i != 5)
                return; 
            } else {
              this.mData = this.mObj1.toString().getBytes(Charset.forName("UTF-16"));
              return;
            } 
          } else {
            this.mData = (byte[])this.mObj1;
            return;
          } 
        } else {
          this.mData = ((String)this.mObj1).getBytes(Charset.forName("UTF-16"));
          return;
        }  
      if (paramBoolean) {
        Bitmap bitmap = (Bitmap)this.mObj1;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
        this.mData = byteArrayOutputStream.toByteArray();
        return;
      } 
      this.mParcelable = (Parcelable)this.mObj1;
      return;
    } 
    if (!paramBoolean) {
      this.mParcelable = (Parcelable)this.mObj1;
      return;
    } 
    throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
  }
  
  public IconCompat setTint(int paramInt) {
    return setTintList(ColorStateList.valueOf(paramInt));
  }
  
  public IconCompat setTintList(ColorStateList paramColorStateList) {
    this.mTintList = paramColorStateList;
    return this;
  }
  
  public IconCompat setTintMode(PorterDuff.Mode paramMode) {
    this.mTintMode = paramMode;
    return this;
  }
  
  public Bundle toBundle() {
    // Byte code:
    //   0: new android/os/Bundle
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_0
    //   9: getfield mType : I
    //   12: istore_1
    //   13: iload_1
    //   14: iconst_m1
    //   15: if_icmpeq -> 108
    //   18: iload_1
    //   19: iconst_1
    //   20: if_icmpeq -> 92
    //   23: iload_1
    //   24: iconst_2
    //   25: if_icmpeq -> 76
    //   28: iload_1
    //   29: iconst_3
    //   30: if_icmpeq -> 57
    //   33: iload_1
    //   34: iconst_4
    //   35: if_icmpeq -> 76
    //   38: iload_1
    //   39: iconst_5
    //   40: if_icmpne -> 46
    //   43: goto -> 92
    //   46: new java/lang/IllegalArgumentException
    //   49: dup
    //   50: ldc_w 'Invalid icon'
    //   53: invokespecial <init> : (Ljava/lang/String;)V
    //   56: athrow
    //   57: aload_2
    //   58: ldc 'obj'
    //   60: aload_0
    //   61: getfield mObj1 : Ljava/lang/Object;
    //   64: checkcast [B
    //   67: checkcast [B
    //   70: invokevirtual putByteArray : (Ljava/lang/String;[B)V
    //   73: goto -> 121
    //   76: aload_2
    //   77: ldc 'obj'
    //   79: aload_0
    //   80: getfield mObj1 : Ljava/lang/Object;
    //   83: checkcast java/lang/String
    //   86: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   89: goto -> 121
    //   92: aload_2
    //   93: ldc 'obj'
    //   95: aload_0
    //   96: getfield mObj1 : Ljava/lang/Object;
    //   99: checkcast android/graphics/Bitmap
    //   102: invokevirtual putParcelable : (Ljava/lang/String;Landroid/os/Parcelable;)V
    //   105: goto -> 121
    //   108: aload_2
    //   109: ldc 'obj'
    //   111: aload_0
    //   112: getfield mObj1 : Ljava/lang/Object;
    //   115: checkcast android/os/Parcelable
    //   118: invokevirtual putParcelable : (Ljava/lang/String;Landroid/os/Parcelable;)V
    //   121: aload_2
    //   122: ldc 'type'
    //   124: aload_0
    //   125: getfield mType : I
    //   128: invokevirtual putInt : (Ljava/lang/String;I)V
    //   131: aload_2
    //   132: ldc 'int1'
    //   134: aload_0
    //   135: getfield mInt1 : I
    //   138: invokevirtual putInt : (Ljava/lang/String;I)V
    //   141: aload_2
    //   142: ldc 'int2'
    //   144: aload_0
    //   145: getfield mInt2 : I
    //   148: invokevirtual putInt : (Ljava/lang/String;I)V
    //   151: aload_0
    //   152: getfield mTintList : Landroid/content/res/ColorStateList;
    //   155: astore_3
    //   156: aload_3
    //   157: ifnull -> 167
    //   160: aload_2
    //   161: ldc 'tint_list'
    //   163: aload_3
    //   164: invokevirtual putParcelable : (Ljava/lang/String;Landroid/os/Parcelable;)V
    //   167: aload_0
    //   168: getfield mTintMode : Landroid/graphics/PorterDuff$Mode;
    //   171: astore_3
    //   172: aload_3
    //   173: getstatic androidx/core/graphics/drawable/IconCompat.DEFAULT_TINT_MODE : Landroid/graphics/PorterDuff$Mode;
    //   176: if_acmpeq -> 189
    //   179: aload_2
    //   180: ldc 'tint_mode'
    //   182: aload_3
    //   183: invokevirtual name : ()Ljava/lang/String;
    //   186: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   189: aload_2
    //   190: areturn
  }
  
  public Icon toIcon() {
    int i = this.mType;
    if (i != -1) {
      Icon icon;
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 4) {
              if (i == 5) {
                if (Build.VERSION.SDK_INT >= 26) {
                  icon = Icon.createWithAdaptiveBitmap((Bitmap)this.mObj1);
                } else {
                  icon = Icon.createWithBitmap(createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, false));
                } 
              } else {
                throw new IllegalArgumentException("Unknown type");
              } 
            } else {
              icon = Icon.createWithContentUri((String)this.mObj1);
            } 
          } else {
            icon = Icon.createWithData((byte[])this.mObj1, this.mInt1, this.mInt2);
          } 
        } else {
          icon = Icon.createWithResource(getResPackage(), this.mInt1);
        } 
      } else {
        icon = Icon.createWithBitmap((Bitmap)this.mObj1);
      } 
      ColorStateList colorStateList = this.mTintList;
      if (colorStateList != null)
        icon.setTintList(colorStateList); 
      PorterDuff.Mode mode = this.mTintMode;
      if (mode != DEFAULT_TINT_MODE)
        icon.setTintMode(mode); 
      return icon;
    } 
    return (Icon)this.mObj1;
  }
  
  public String toString() {
    if (this.mType == -1)
      return String.valueOf(this.mObj1); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    stringBuilder.append(typeToString(this.mType));
    int i = this.mType;
    if (i != 1)
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5)
              if (this.mTintList != null) {
                stringBuilder.append(" tint=");
                stringBuilder.append(this.mTintList);
              }  
          } else {
            stringBuilder.append(" uri=");
            stringBuilder.append(this.mObj1);
            if (this.mTintList != null) {
              stringBuilder.append(" tint=");
              stringBuilder.append(this.mTintList);
            } 
          } 
        } else {
          stringBuilder.append(" len=");
          stringBuilder.append(this.mInt1);
          if (this.mInt2 != 0) {
            stringBuilder.append(" off=");
            stringBuilder.append(this.mInt2);
          } 
          if (this.mTintList != null) {
            stringBuilder.append(" tint=");
            stringBuilder.append(this.mTintList);
          } 
        } 
      } else {
        stringBuilder.append(" pkg=");
        stringBuilder.append(getResPackage());
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(getResId()) }));
        if (this.mTintList != null) {
          stringBuilder.append(" tint=");
          stringBuilder.append(this.mTintList);
        } 
      }  
    stringBuilder.append(" size=");
    stringBuilder.append(((Bitmap)this.mObj1).getWidth());
    stringBuilder.append("x");
    stringBuilder.append(((Bitmap)this.mObj1).getHeight());
    if (this.mTintList != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.mTintList);
    } 
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface IconType {}
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */