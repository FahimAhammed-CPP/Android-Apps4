package androidx.lifecycle;

public interface LifecycleOwner {
  Lifecycle getLifecycle();
}


/* Location:              C:\soft\dex2jar-2.0\Super Bear Adventure-dex2jar.jar!\androidx\lifecycle\LifecycleOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */