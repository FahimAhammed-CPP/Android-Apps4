package a2;

import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.Map;
import kotlin.collections.l;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;

public final class c<K, V> {
  private int[] a;
  
  private Object[] b;
  
  private int c;
  
  public c() {
    this(0, 1, null);
  }
  
  public c(int paramInt) {
    if (paramInt == 0) {
      this.a = a.a;
      this.b = a.b;
    } else {
      this.a = new int[paramInt];
      this.b = new Object[paramInt << 1];
    } 
    this.c = 0;
  }
  
  public final boolean a(K paramK) {
    return (d(paramK) >= 0);
  }
  
  public final V b(K paramK) {
    int i = d(paramK);
    return (V)((i >= 0) ? this.b[(i << 1) + 1] : null);
  }
  
  protected final int c(Object paramObject, int paramInt) {
    q.j(paramObject, "key");
    int j = this.c;
    if (j == 0)
      return -1; 
    int k = a.a(this.a, j, paramInt);
    if (k < 0)
      return k; 
    if (q.e(paramObject, this.b[k << 1]))
      return k; 
    int i;
    for (i = k + 1; i < j && this.a[i] == paramInt; i++) {
      if (q.e(paramObject, this.b[i << 1]))
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.a[j] == paramInt; j--) {
      if (q.e(paramObject, this.b[j << 1]))
        return j; 
    } 
    return i;
  }
  
  public final int d(Object paramObject) {
    return (paramObject == null) ? e() : c(paramObject, paramObject.hashCode());
  }
  
  protected final int e() {
    int j = this.c;
    if (j == 0)
      return -1; 
    int k = a.a(this.a, j, 0);
    if (k < 0)
      return k; 
    if (this.b[k << 1] == null)
      return k; 
    int i;
    for (i = k + 1; i < j && this.a[i] == 0; i++) {
      if (this.b[i << 1] == null)
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.a[j] == 0; j--) {
      if (this.b[j << 1] == null)
        return j; 
    } 
    return i;
  }
  
  public boolean equals(Object paramObject) {
    int j;
    if (this == paramObject)
      return true; 
    try {
      if (paramObject instanceof c) {
        paramObject = paramObject;
        j = this.c;
        if (j != ((c)paramObject).c)
          return false; 
      } else {
        if (paramObject instanceof Map) {
          if (this.c != ((Map)paramObject).size())
            return false; 
          j = this.c;
          for (int k = 0; k < j; k++) {
            K k1 = g(k);
            V v = i(k);
            Object object = ((Map)paramObject).get(k1);
            if (v == null) {
              if (object == null) {
                if (!((Map)paramObject).containsKey(k1))
                  return false; 
              } else {
                return false;
              } 
            } else {
              boolean bool = q.e(v, object);
              if (!bool)
                return false; 
            } 
          } 
          return true;
        } 
        return false;
      } 
    } catch (NullPointerException|ClassCastException nullPointerException) {
      return false;
    } 
    for (int i = 0; i < j; i++) {
      K k = g(i);
      V v = i(i);
      Object object = nullPointerException.b(k);
      if (v == null) {
        if (object == null) {
          if (!nullPointerException.a(k))
            return false; 
        } else {
          return false;
        } 
      } else if (!q.e(v, object)) {
        return false;
      } 
    } 
    return true;
  }
  
  public final boolean f() {
    return (this.c <= 0);
  }
  
  public final K g(int paramInt) {
    return (K)this.b[paramInt << 1];
  }
  
  public final V h(K paramK, V paramV) {
    Object[] arrayOfObject;
    int j;
    int k = this.c;
    if (paramK == null) {
      i = e();
      j = 0;
    } else {
      j = paramK.hashCode();
      i = c(paramK, j);
    } 
    if (i >= 0) {
      i = (i << 1) + 1;
      arrayOfObject = this.b;
      Object object = arrayOfObject[i];
      arrayOfObject[i] = paramV;
      return (V)object;
    } 
    int m = i;
    int[] arrayOfInt = this.a;
    if (k >= arrayOfInt.length) {
      i = 8;
      if (k >= 8) {
        i = (k >> 1) + k;
      } else if (k < 4) {
        i = 4;
      } 
      arrayOfInt = Arrays.copyOf(arrayOfInt, i);
      q.i(arrayOfInt, "copyOf(this, newSize)");
      this.a = arrayOfInt;
      arrayOfInt = Arrays.copyOf((int[])this.b, i << 1);
      q.i(arrayOfInt, "copyOf(this, newSize)");
      this.b = (Object[])arrayOfInt;
      if (k != this.c)
        throw new ConcurrentModificationException(); 
    } 
    if (m < k) {
      arrayOfInt = this.a;
      i = m + 1;
      l.g(arrayOfInt, arrayOfInt, i, m, k);
      Object[] arrayOfObject1 = this.b;
      l.i(arrayOfObject1, arrayOfObject1, i << 1, m << 1, this.c << 1);
    } 
    int i = this.c;
    if (k == i) {
      arrayOfInt = this.a;
      if (m < arrayOfInt.length) {
        arrayOfInt[m] = j;
        Object[] arrayOfObject1 = this.b;
        j = m << 1;
        arrayOfObject1[j] = arrayOfObject;
        arrayOfObject1[j + 1] = paramV;
        this.c = i + 1;
        return null;
      } 
    } 
    throw new ConcurrentModificationException();
  }
  
  public int hashCode() {
    int[] arrayOfInt = this.a;
    Object[] arrayOfObject = this.b;
    int m = this.c;
    int i = 1;
    int j = 0;
    int k = 0;
    while (j < m) {
      int n;
      Object object = arrayOfObject[i];
      int i1 = arrayOfInt[j];
      if (object != null) {
        n = object.hashCode();
      } else {
        n = 0;
      } 
      k += n ^ i1;
      j++;
      i += 2;
    } 
    return k;
  }
  
  public final V i(int paramInt) {
    return (V)this.b[(paramInt << 1) + 1];
  }
  
  public String toString() {
    if (f())
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.c * 28);
    stringBuilder.append('{');
    int j = this.c;
    for (int i = 0; i < j; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      V v = (V)g(i);
      if (v != this) {
        stringBuilder.append(v);
      } else {
        stringBuilder.append("(this Map)");
      } 
      stringBuilder.append('=');
      v = i(i);
      if (v != this) {
        stringBuilder.append(v);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    String str = stringBuilder.toString();
    q.i(str, "buffer.toString()");
    return str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a2\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */