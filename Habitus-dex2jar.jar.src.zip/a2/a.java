package a2;

import kotlin.jvm.internal.q;

public final class a {
  public static final int[] a = new int[0];
  
  public static final Object[] b = new Object[0];
  
  public static final int a(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    q.j(paramArrayOfint, "<this>");
    paramInt1--;
    int i = 0;
    while (i <= paramInt1) {
      int j = i + paramInt1 >>> 1;
      int k = paramArrayOfint[j];
      if (k < paramInt2) {
        i = j + 1;
        continue;
      } 
      if (k > paramInt2) {
        paramInt1 = j - 1;
        continue;
      } 
      return j;
    } 
    return i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */