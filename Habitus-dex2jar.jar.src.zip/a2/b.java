package a2;

import e2.p;
import e2.q;
import java.util.HashMap;
import java.util.LinkedHashSet;
import kotlin.collections.r;
import kotlin.jvm.internal.m0;
import kotlin.jvm.internal.q;
import rj.v;

public class b<K, V> {
  private final q a;
  
  private final HashMap<K, V> b;
  
  private final LinkedHashSet<K> c;
  
  private int d;
  
  private int e;
  
  private int f;
  
  private int g;
  
  private int h;
  
  private int i;
  
  private int j;
  
  public b(int paramInt) {
    boolean bool;
    this.a = p.a();
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      this.e = paramInt;
      this.b = new HashMap<K, V>(0, 0.75F);
      this.c = new LinkedHashSet<K>();
      return;
    } 
    throw new IllegalArgumentException("maxSize <= 0".toString());
  }
  
  private final int g(K paramK, V paramV) {
    boolean bool;
    int i = i(paramK, paramV);
    if (i >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return i; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Negative size: ");
    stringBuilder.append(paramK);
    stringBuilder.append('=');
    stringBuilder.append(paramV);
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  protected V b(K paramK) {
    return null;
  }
  
  protected void c(boolean paramBoolean, K paramK, V paramV1, V paramV2) {}
  
  public final V d(K paramK) {
    q q1;
    v v;
    synchronized (this.a) {
      V v1 = this.b.get(paramK);
      if (v1 != null) {
        this.c.remove(paramK);
        this.c.add(paramK);
        this.i++;
        return v1;
      } 
      this.j++;
      V v2 = b(paramK);
      if (v2 == null)
        return null; 
      synchronized (this.a) {
        q q2;
        this.g++;
        q1 = (q)this.b.put(paramK, v2);
        this.c.remove(paramK);
        this.c.add(paramK);
        if (q1 != null) {
          this.b.put(paramK, (V)q1);
          q2 = q1;
        } else {
          this.d = h() + g(paramK, v2);
        } 
        v = v.a;
        if (q2 != null) {
          c(false, paramK, v2, (V)q2);
          return (V)q2;
        } 
        j(this.e);
        return v2;
      } 
    } 
  }
  
  public final V e(K paramK, V paramV) {
    if (paramK != null && paramV != null)
      synchronized (this.a) {
        this.f++;
        this.d = h() + g(paramK, paramV);
        V v = this.b.put(paramK, paramV);
        if (v != null)
          this.d = h() - g(paramK, v); 
        if (this.c.contains(paramK))
          this.c.remove(paramK); 
        this.c.add(paramK);
        if (v != null)
          c(false, paramK, v, paramV); 
        j(this.e);
        return v;
      }  
    throw null;
  }
  
  public final V f(K paramK) {
    paramK.getClass();
    synchronized (this.a) {
      V v = this.b.remove(paramK);
      this.c.remove(paramK);
      if (v != null)
        this.d = h() - g(paramK, v); 
      v v1 = v.a;
      if (v != null)
        c(false, paramK, v, null); 
      return v;
    } 
  }
  
  public final int h() {
    synchronized (a(this)) {
      return this.d;
    } 
  }
  
  protected int i(K paramK, V paramV) {
    return 1;
  }
  
  public void j(int paramInt) {
    while (true) {
      synchronized (this.a) {
        if (h() >= 0 && (!this.b.isEmpty() || h() == 0) && this.b.isEmpty() == this.c.isEmpty()) {
          K k1;
          K k2;
          if (h() > paramInt && !this.b.isEmpty()) {
            k1 = (K)r.b0(this.c);
            V v1 = this.b.get(k1);
            if (v1 != null) {
              m0.d(this.b).remove(k1);
              m0.a(this.c).remove(k1);
              int i = h();
              q.g(k1);
              q.g(v1);
              this.d = i - g(k1, v1);
              this.h++;
            } else {
              throw new IllegalStateException("inconsistent state");
            } 
          } else {
            k1 = null;
            k2 = k1;
          } 
          v v = v.a;
          if (k1 == null && k2 == null)
            return; 
          q.g(k1);
          q.g(k2);
          c(true, k1, (V)k2, null);
          continue;
        } 
        throw new IllegalStateException("map/keySet size inconsistency");
      } 
    } 
  }
  
  public String toString() {
    synchronized (this.a) {
      int i = this.i;
      int j = this.j + i;
      if (j != 0) {
        i = i * 100 / j;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("LruCache[maxSize=");
        stringBuilder1.append(this.e);
        stringBuilder1.append(",hits=");
        stringBuilder1.append(this.i);
        stringBuilder1.append(",misses=");
        stringBuilder1.append(this.j);
        stringBuilder1.append(",hitRate=");
        stringBuilder1.append(i);
        stringBuilder1.append("%]");
        return stringBuilder1.toString();
      } 
    } 
    boolean bool = false;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LruCache[maxSize=");
    stringBuilder.append(this.e);
    stringBuilder.append(",hits=");
    stringBuilder.append(this.i);
    stringBuilder.append(",misses=");
    stringBuilder.append(this.j);
    stringBuilder.append(",hitRate=");
    stringBuilder.append(bool);
    stringBuilder.append("%]");
    String str = stringBuilder.toString();
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
    return str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */