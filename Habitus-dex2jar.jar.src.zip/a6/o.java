package a6;

import android.util.SparseArray;
import com.google.auto.value.AutoValue;
import com.google.auto.value.AutoValue.Builder;

@AutoValue
public abstract class o {
  public static a a() {
    return new i.b();
  }
  
  public abstract b b();
  
  public abstract c c();
  
  @Builder
  public static abstract class a {
    public abstract o a();
    
    public abstract a b(o.b param1b);
    
    public abstract a c(o.c param1c);
  }
  
  public enum b {
    A0, B0, C0, D0, E0, F0, G0, H0, I0, J0, K0, L0, M0, N0, t0, u0, v0, w0, x0, y0, z0;
    
    private static final SparseArray<b> O0;
    
    private final int s0;
    
    static {
      b b1 = new b("UNKNOWN_MOBILE_SUBTYPE", 0, 0);
      t0 = b1;
      b b2 = new b("GPRS", 1, 1);
      u0 = b2;
      b b3 = new b("EDGE", 2, 2);
      v0 = b3;
      b b4 = new b("UMTS", 3, 3);
      w0 = b4;
      b b5 = new b("CDMA", 4, 4);
      x0 = b5;
      b b6 = new b("EVDO_0", 5, 5);
      y0 = b6;
      b b7 = new b("EVDO_A", 6, 6);
      z0 = b7;
      b b8 = new b("RTT", 7, 7);
      A0 = b8;
      b b9 = new b("HSDPA", 8, 8);
      B0 = b9;
      b b10 = new b("HSUPA", 9, 9);
      C0 = b10;
      b b11 = new b("HSPA", 10, 10);
      D0 = b11;
      b b12 = new b("IDEN", 11, 11);
      E0 = b12;
      b b13 = new b("EVDO_B", 12, 12);
      F0 = b13;
      b b14 = new b("LTE", 13, 13);
      G0 = b14;
      b b15 = new b("EHRPD", 14, 14);
      H0 = b15;
      b b16 = new b("HSPAP", 15, 15);
      I0 = b16;
      b b17 = new b("GSM", 16, 16);
      J0 = b17;
      b b18 = new b("TD_SCDMA", 17, 17);
      K0 = b18;
      b b19 = new b("IWLAN", 18, 18);
      L0 = b19;
      b b20 = new b("LTE_CA", 19, 19);
      M0 = b20;
      b b21 = new b("COMBINED", 20, 100);
      N0 = b21;
      P0 = new b[] { 
          b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, 
          b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, 
          b21 };
      SparseArray<b> sparseArray = new SparseArray();
      O0 = sparseArray;
      sparseArray.put(0, b1);
      sparseArray.put(1, b2);
      sparseArray.put(2, b3);
      sparseArray.put(3, b4);
      sparseArray.put(4, b5);
      sparseArray.put(5, b6);
      sparseArray.put(6, b7);
      sparseArray.put(7, b8);
      sparseArray.put(8, b9);
      sparseArray.put(9, b10);
      sparseArray.put(10, b11);
      sparseArray.put(11, b12);
      sparseArray.put(12, b13);
      sparseArray.put(13, b14);
      sparseArray.put(14, b15);
      sparseArray.put(15, b16);
      sparseArray.put(16, b17);
      sparseArray.put(17, b18);
      sparseArray.put(18, b19);
      sparseArray.put(19, b20);
    }
    
    b(int param1Int1) {
      this.s0 = param1Int1;
    }
    
    public static b a(int param1Int) {
      return (b)O0.get(param1Int);
    }
    
    public int d() {
      return this.s0;
    }
  }
  
  public enum c {
    A0, B0, C0, D0, E0, F0, G0, H0, I0, J0, K0, L0, t0, u0, v0, w0, x0, y0, z0;
    
    private static final SparseArray<c> M0;
    
    private final int s0;
    
    static {
      c c1 = new c("MOBILE", 0, 0);
      t0 = c1;
      c c2 = new c("WIFI", 1, 1);
      u0 = c2;
      c c3 = new c("MOBILE_MMS", 2, 2);
      v0 = c3;
      c c4 = new c("MOBILE_SUPL", 3, 3);
      w0 = c4;
      c c5 = new c("MOBILE_DUN", 4, 4);
      x0 = c5;
      c c6 = new c("MOBILE_HIPRI", 5, 5);
      y0 = c6;
      c c7 = new c("WIMAX", 6, 6);
      z0 = c7;
      c c8 = new c("BLUETOOTH", 7, 7);
      A0 = c8;
      c c9 = new c("DUMMY", 8, 8);
      B0 = c9;
      c c10 = new c("ETHERNET", 9, 9);
      C0 = c10;
      c c11 = new c("MOBILE_FOTA", 10, 10);
      D0 = c11;
      c c12 = new c("MOBILE_IMS", 11, 11);
      E0 = c12;
      c c13 = new c("MOBILE_CBS", 12, 12);
      F0 = c13;
      c c14 = new c("WIFI_P2P", 13, 13);
      G0 = c14;
      c c15 = new c("MOBILE_IA", 14, 14);
      H0 = c15;
      c c16 = new c("MOBILE_EMERGENCY", 15, 15);
      I0 = c16;
      c c17 = new c("PROXY", 16, 16);
      J0 = c17;
      c c18 = new c("VPN", 17, 17);
      K0 = c18;
      c c19 = new c("NONE", 18, -1);
      L0 = c19;
      N0 = new c[] { 
          c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, 
          c11, c12, c13, c14, c15, c16, c17, c18, c19 };
      SparseArray<c> sparseArray = new SparseArray();
      M0 = sparseArray;
      sparseArray.put(0, c1);
      sparseArray.put(1, c2);
      sparseArray.put(2, c3);
      sparseArray.put(3, c4);
      sparseArray.put(4, c5);
      sparseArray.put(5, c6);
      sparseArray.put(6, c7);
      sparseArray.put(7, c8);
      sparseArray.put(8, c9);
      sparseArray.put(9, c10);
      sparseArray.put(10, c11);
      sparseArray.put(11, c12);
      sparseArray.put(12, c13);
      sparseArray.put(13, c14);
      sparseArray.put(14, c15);
      sparseArray.put(15, c16);
      sparseArray.put(16, c17);
      sparseArray.put(17, c18);
      sparseArray.put(-1, c19);
    }
    
    c(int param1Int1) {
      this.s0 = param1Int1;
    }
    
    public static c a(int param1Int) {
      return (c)M0.get(param1Int);
    }
    
    public int d() {
      return this.s0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a6\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */