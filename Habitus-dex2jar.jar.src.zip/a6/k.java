package a6;

import com.google.auto.value.AutoValue;
import com.google.auto.value.AutoValue.Builder;

@AutoValue
public abstract class k {
  public static a a() {
    return new e.b();
  }
  
  public abstract a b();
  
  public abstract b c();
  
  @Builder
  public static abstract class a {
    public abstract k a();
    
    public abstract a b(a param1a);
    
    public abstract a c(k.b param1b);
  }
  
  public enum b {
    t0, u0;
    
    private final int s0;
    
    static {
      b b1 = new b("UNKNOWN", 0, 0);
      t0 = b1;
      b b2 = new b("ANDROID_FIREBASE", 1, 23);
      u0 = b2;
      v0 = new b[] { b1, b2 };
    }
    
    b(int param1Int1) {
      this.s0 = param1Int1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a6\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */