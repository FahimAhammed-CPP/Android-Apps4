package a6;

import android.util.SparseArray;

public enum p {
  t0, u0, v0, w0, x0, y0;
  
  private static final SparseArray<p> z0;
  
  private final int s0;
  
  static {
    p p1 = new p("DEFAULT", 0, 0);
    t0 = p1;
    p p2 = new p("UNMETERED_ONLY", 1, 1);
    u0 = p2;
    p p3 = new p("UNMETERED_OR_DAILY", 2, 2);
    v0 = p3;
    p p4 = new p("FAST_IF_RADIO_AWAKE", 3, 3);
    w0 = p4;
    p p5 = new p("NEVER", 4, 4);
    x0 = p5;
    p p6 = new p("UNRECOGNIZED", 5, -1);
    y0 = p6;
    A0 = new p[] { p1, p2, p3, p4, p5, p6 };
    SparseArray<p> sparseArray = new SparseArray();
    z0 = sparseArray;
    sparseArray.put(0, p1);
    sparseArray.put(1, p2);
    sparseArray.put(2, p3);
    sparseArray.put(3, p4);
    sparseArray.put(4, p5);
    sparseArray.put(-1, p6);
  }
  
  p(int paramInt1) {
    this.s0 = paramInt1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a6\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */