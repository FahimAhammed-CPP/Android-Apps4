package a6;

import com.google.firebase.encoders.FieldDescriptor;
import com.google.firebase.encoders.ObjectEncoder;
import com.google.firebase.encoders.ObjectEncoderContext;
import com.google.firebase.encoders.config.Configurator;
import com.google.firebase.encoders.config.EncoderConfig;
import java.io.IOException;

public final class b implements Configurator {
  public static final Configurator a = new b();
  
  public void configure(EncoderConfig<?> paramEncoderConfig) {
    b b1 = b.a;
    paramEncoderConfig.registerEncoder(j.class, b1);
    paramEncoderConfig.registerEncoder(d.class, b1);
    e e = e.a;
    paramEncoderConfig.registerEncoder(m.class, e);
    paramEncoderConfig.registerEncoder(g.class, e);
    c c = c.a;
    paramEncoderConfig.registerEncoder(k.class, c);
    paramEncoderConfig.registerEncoder(e.class, c);
    a a = a.a;
    paramEncoderConfig.registerEncoder(a.class, a);
    paramEncoderConfig.registerEncoder(c.class, a);
    d d = d.a;
    paramEncoderConfig.registerEncoder(l.class, d);
    paramEncoderConfig.registerEncoder(f.class, d);
    f f = f.a;
    paramEncoderConfig.registerEncoder(o.class, f);
    paramEncoderConfig.registerEncoder(i.class, f);
  }
  
  private static final class a implements ObjectEncoder<a> {
    static final a a = new a();
    
    private static final FieldDescriptor b = FieldDescriptor.of("sdkVersion");
    
    private static final FieldDescriptor c = FieldDescriptor.of("model");
    
    private static final FieldDescriptor d = FieldDescriptor.of("hardware");
    
    private static final FieldDescriptor e = FieldDescriptor.of("device");
    
    private static final FieldDescriptor f = FieldDescriptor.of("product");
    
    private static final FieldDescriptor g = FieldDescriptor.of("osBuild");
    
    private static final FieldDescriptor h = FieldDescriptor.of("manufacturer");
    
    private static final FieldDescriptor i = FieldDescriptor.of("fingerprint");
    
    private static final FieldDescriptor j = FieldDescriptor.of("locale");
    
    private static final FieldDescriptor k = FieldDescriptor.of("country");
    
    private static final FieldDescriptor l = FieldDescriptor.of("mccMnc");
    
    private static final FieldDescriptor m = FieldDescriptor.of("applicationBuild");
    
    public void a(a param1a, ObjectEncoderContext param1ObjectEncoderContext) throws IOException {
      param1ObjectEncoderContext.add(b, param1a.m());
      param1ObjectEncoderContext.add(c, param1a.j());
      param1ObjectEncoderContext.add(d, param1a.f());
      param1ObjectEncoderContext.add(e, param1a.d());
      param1ObjectEncoderContext.add(f, param1a.l());
      param1ObjectEncoderContext.add(g, param1a.k());
      param1ObjectEncoderContext.add(h, param1a.h());
      param1ObjectEncoderContext.add(i, param1a.e());
      param1ObjectEncoderContext.add(j, param1a.g());
      param1ObjectEncoderContext.add(k, param1a.c());
      param1ObjectEncoderContext.add(l, param1a.i());
      param1ObjectEncoderContext.add(m, param1a.b());
    }
  }
  
  private static final class b implements ObjectEncoder<j> {
    static final b a = new b();
    
    private static final FieldDescriptor b = FieldDescriptor.of("logRequest");
    
    public void a(j param1j, ObjectEncoderContext param1ObjectEncoderContext) throws IOException {
      param1ObjectEncoderContext.add(b, param1j.c());
    }
  }
  
  private static final class c implements ObjectEncoder<k> {
    static final c a = new c();
    
    private static final FieldDescriptor b = FieldDescriptor.of("clientType");
    
    private static final FieldDescriptor c = FieldDescriptor.of("androidClientInfo");
    
    public void a(k param1k, ObjectEncoderContext param1ObjectEncoderContext) throws IOException {
      param1ObjectEncoderContext.add(b, param1k.c());
      param1ObjectEncoderContext.add(c, param1k.b());
    }
  }
  
  private static final class d implements ObjectEncoder<l> {
    static final d a = new d();
    
    private static final FieldDescriptor b = FieldDescriptor.of("eventTimeMs");
    
    private static final FieldDescriptor c = FieldDescriptor.of("eventCode");
    
    private static final FieldDescriptor d = FieldDescriptor.of("eventUptimeMs");
    
    private static final FieldDescriptor e = FieldDescriptor.of("sourceExtension");
    
    private static final FieldDescriptor f = FieldDescriptor.of("sourceExtensionJsonProto3");
    
    private static final FieldDescriptor g = FieldDescriptor.of("timezoneOffsetSeconds");
    
    private static final FieldDescriptor h = FieldDescriptor.of("networkConnectionInfo");
    
    public void a(l param1l, ObjectEncoderContext param1ObjectEncoderContext) throws IOException {
      param1ObjectEncoderContext.add(b, param1l.c());
      param1ObjectEncoderContext.add(c, param1l.b());
      param1ObjectEncoderContext.add(d, param1l.d());
      param1ObjectEncoderContext.add(e, param1l.f());
      param1ObjectEncoderContext.add(f, param1l.g());
      param1ObjectEncoderContext.add(g, param1l.h());
      param1ObjectEncoderContext.add(h, param1l.e());
    }
  }
  
  private static final class e implements ObjectEncoder<m> {
    static final e a = new e();
    
    private static final FieldDescriptor b = FieldDescriptor.of("requestTimeMs");
    
    private static final FieldDescriptor c = FieldDescriptor.of("requestUptimeMs");
    
    private static final FieldDescriptor d = FieldDescriptor.of("clientInfo");
    
    private static final FieldDescriptor e = FieldDescriptor.of("logSource");
    
    private static final FieldDescriptor f = FieldDescriptor.of("logSourceName");
    
    private static final FieldDescriptor g = FieldDescriptor.of("logEvent");
    
    private static final FieldDescriptor h = FieldDescriptor.of("qosTier");
    
    public void a(m param1m, ObjectEncoderContext param1ObjectEncoderContext) throws IOException {
      param1ObjectEncoderContext.add(b, param1m.g());
      param1ObjectEncoderContext.add(c, param1m.h());
      param1ObjectEncoderContext.add(d, param1m.b());
      param1ObjectEncoderContext.add(e, param1m.d());
      param1ObjectEncoderContext.add(f, param1m.e());
      param1ObjectEncoderContext.add(g, param1m.c());
      param1ObjectEncoderContext.add(h, param1m.f());
    }
  }
  
  private static final class f implements ObjectEncoder<o> {
    static final f a = new f();
    
    private static final FieldDescriptor b = FieldDescriptor.of("networkType");
    
    private static final FieldDescriptor c = FieldDescriptor.of("mobileSubtype");
    
    public void a(o param1o, ObjectEncoderContext param1ObjectEncoderContext) throws IOException {
      param1ObjectEncoderContext.add(b, param1o.c());
      param1ObjectEncoderContext.add(c, param1o.b());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a6\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */