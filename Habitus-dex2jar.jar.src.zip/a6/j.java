package a6;

import com.google.auto.value.AutoValue;
import com.google.firebase.encoders.DataEncoder;
import com.google.firebase.encoders.annotations.Encodable;
import com.google.firebase.encoders.annotations.Encodable.Field;
import com.google.firebase.encoders.json.JsonDataEncoderBuilder;
import java.util.List;

@Encodable
@AutoValue
public abstract class j {
  public static j a(List<m> paramList) {
    return new d(paramList);
  }
  
  public static DataEncoder b() {
    return (new JsonDataEncoderBuilder()).configureWith(b.a).ignoreNullValues(true).build();
  }
  
  @Field(name = "logRequest")
  public abstract List<m> c();
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a6\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */