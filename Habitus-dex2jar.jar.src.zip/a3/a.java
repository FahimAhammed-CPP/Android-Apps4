package a3;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityRecord;
import androidx.collection.h;
import androidx.core.view.a;
import androidx.core.view.accessibility.n0;
import androidx.core.view.accessibility.q0;
import androidx.core.view.accessibility.r0;
import androidx.core.view.m0;
import java.util.ArrayList;
import java.util.List;

public abstract class a extends a {
  private static final Rect n = new Rect(2147483647, 2147483647, -2147483648, -2147483648);
  
  private static final b.a<n0> o = new a();
  
  private static final b.b<h<n0>, n0> p = new b();
  
  private final Rect d = new Rect();
  
  private final Rect e = new Rect();
  
  private final Rect f = new Rect();
  
  private final int[] g = new int[2];
  
  private final AccessibilityManager h;
  
  private final View i;
  
  private c j;
  
  int k = Integer.MIN_VALUE;
  
  int l = Integer.MIN_VALUE;
  
  private int m = Integer.MIN_VALUE;
  
  public a(View paramView) {
    if (paramView != null) {
      this.i = paramView;
      this.h = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
      paramView.setFocusable(true);
      if (m0.C(paramView) == 0)
        m0.D0(paramView, 1); 
      return;
    } 
    throw new IllegalArgumentException("View may not be null");
  }
  
  private static Rect D(View paramView, int paramInt, Rect paramRect) {
    int i = paramView.getWidth();
    int j = paramView.getHeight();
    if (paramInt != 17) {
      if (paramInt != 33) {
        if (paramInt != 66) {
          if (paramInt == 130) {
            paramRect.set(0, -1, i, -1);
            return paramRect;
          } 
          throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
        } 
        paramRect.set(-1, 0, -1, j);
        return paramRect;
      } 
      paramRect.set(0, j, i, j);
      return paramRect;
    } 
    paramRect.set(i, 0, i, j);
    return paramRect;
  }
  
  private boolean G(Rect paramRect) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramRect != null) {
      if (paramRect.isEmpty())
        return false; 
      if (this.i.getWindowVisibility() != 0)
        return false; 
      ViewParent viewParent = this.i.getParent();
      while (viewParent instanceof View) {
        View view = (View)viewParent;
        if (view.getAlpha() > 0.0F) {
          if (view.getVisibility() != 0)
            return false; 
          viewParent = view.getParent();
          continue;
        } 
        return false;
      } 
      bool1 = bool2;
      if (viewParent != null)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private static int H(int paramInt) {
    return (paramInt != 19) ? ((paramInt != 21) ? ((paramInt != 22) ? 130 : 66) : 17) : 33;
  }
  
  private boolean I(int paramInt, Rect paramRect) {
    n0 n01;
    n0 n02;
    h<n0> h = y();
    int j = this.l;
    int i = Integer.MIN_VALUE;
    if (j == Integer.MIN_VALUE) {
      n02 = null;
    } else {
      n02 = (n0)h.h(j);
    } 
    if (paramInt != 1 && paramInt != 2) {
      if (paramInt == 17 || paramInt == 33 || paramInt == 66 || paramInt == 130) {
        Rect rect = new Rect();
        j = this.l;
        if (j != Integer.MIN_VALUE) {
          z(j, rect);
        } else if (paramRect != null) {
          rect.set(paramRect);
        } else {
          D(this.i, paramInt, rect);
        } 
        n01 = b.<h<n0>, n0>c(h, p, o, n02, rect, paramInt);
      } else {
        throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD, FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
      } 
    } else {
      boolean bool;
      if (m0.E(this.i) == 1) {
        bool = true;
      } else {
        bool = false;
      } 
      n01 = b.<h<n0>, n0>d(h, p, o, n02, paramInt, bool, false);
    } 
    if (n01 == null) {
      paramInt = i;
    } else {
      paramInt = h.l(h.k(n01));
    } 
    return V(paramInt);
  }
  
  private boolean S(int paramInt1, int paramInt2, Bundle paramBundle) {
    return (paramInt2 != 1) ? ((paramInt2 != 2) ? ((paramInt2 != 64) ? ((paramInt2 != 128) ? L(paramInt1, paramInt2, paramBundle) : n(paramInt1)) : U(paramInt1)) : o(paramInt1)) : V(paramInt1);
  }
  
  private boolean T(int paramInt, Bundle paramBundle) {
    return m0.h0(this.i, paramInt, paramBundle);
  }
  
  private boolean U(int paramInt) {
    if (this.h.isEnabled()) {
      if (!this.h.isTouchExplorationEnabled())
        return false; 
      int i = this.k;
      if (i != paramInt) {
        if (i != Integer.MIN_VALUE)
          n(i); 
        this.k = paramInt;
        this.i.invalidate();
        W(paramInt, 32768);
        return true;
      } 
    } 
    return false;
  }
  
  private void X(int paramInt) {
    int i = this.m;
    if (i == paramInt)
      return; 
    this.m = paramInt;
    W(paramInt, 128);
    W(i, 256);
  }
  
  private boolean n(int paramInt) {
    if (this.k == paramInt) {
      this.k = Integer.MIN_VALUE;
      this.i.invalidate();
      W(paramInt, 65536);
      return true;
    } 
    return false;
  }
  
  private boolean p() {
    int i = this.l;
    return (i != Integer.MIN_VALUE && L(i, 16, null));
  }
  
  private AccessibilityEvent q(int paramInt1, int paramInt2) {
    return (paramInt1 != -1) ? r(paramInt1, paramInt2) : s(paramInt2);
  }
  
  private AccessibilityEvent r(int paramInt1, int paramInt2) {
    AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain(paramInt2);
    n0 n0 = J(paramInt1);
    accessibilityEvent.getText().add(n0.C());
    accessibilityEvent.setContentDescription(n0.t());
    accessibilityEvent.setScrollable(n0.V());
    accessibilityEvent.setPassword(n0.U());
    accessibilityEvent.setEnabled(n0.O());
    accessibilityEvent.setChecked(n0.L());
    N(paramInt1, accessibilityEvent);
    if (!accessibilityEvent.getText().isEmpty() || accessibilityEvent.getContentDescription() != null) {
      accessibilityEvent.setClassName(n0.q());
      r0.c((AccessibilityRecord)accessibilityEvent, this.i, paramInt1);
      accessibilityEvent.setPackageName(this.i.getContext().getPackageName());
      return accessibilityEvent;
    } 
    throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
  }
  
  private AccessibilityEvent s(int paramInt) {
    AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain(paramInt);
    this.i.onInitializeAccessibilityEvent(accessibilityEvent);
    return accessibilityEvent;
  }
  
  private n0 t(int paramInt) {
    n0 n0 = n0.a0();
    n0.v0(true);
    n0.x0(true);
    n0.n0("android.view.View");
    Rect rect = n;
    n0.j0(rect);
    n0.k0(rect);
    n0.J0(this.i);
    P(paramInt, n0);
    if (n0.C() != null || n0.t() != null) {
      n0.m(this.e);
      if (!this.e.equals(rect)) {
        int i = n0.k();
        if ((i & 0x40) == 0) {
          if ((i & 0x80) == 0) {
            boolean bool;
            n0.H0(this.i.getContext().getPackageName());
            n0.T0(this.i, paramInt);
            if (this.k == paramInt) {
              n0.h0(true);
              n0.a(128);
            } else {
              n0.h0(false);
              n0.a(64);
            } 
            if (this.l == paramInt) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool) {
              n0.a(2);
            } else if (n0.P()) {
              n0.a(1);
            } 
            n0.y0(bool);
            this.i.getLocationOnScreen(this.g);
            n0.n(this.d);
            if (this.d.equals(rect)) {
              n0.m(this.d);
              if (n0.b != -1) {
                n0 n01 = n0.a0();
                for (paramInt = n0.b; paramInt != -1; paramInt = n01.b) {
                  n01.K0(this.i, -1);
                  n01.j0(n);
                  P(paramInt, n01);
                  n01.m(this.e);
                  Rect rect1 = this.d;
                  Rect rect2 = this.e;
                  rect1.offset(rect2.left, rect2.top);
                } 
                n01.e0();
              } 
              this.d.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
            } 
            if (this.i.getLocalVisibleRect(this.f)) {
              this.f.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
              if (this.d.intersect(this.f)) {
                n0.k0(this.d);
                if (G(this.d))
                  n0.c1(true); 
              } 
            } 
            return n0;
          } 
          throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        } 
        throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
      } 
      throw new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
    } 
    throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
  }
  
  private n0 u() {
    n0 n0 = n0.b0(this.i);
    m0.f0(this.i, n0);
    ArrayList<Integer> arrayList = new ArrayList();
    C(arrayList);
    if (n0.p() <= 0 || arrayList.size() <= 0) {
      int j = arrayList.size();
      for (int i = 0; i < j; i++)
        n0.d(this.i, ((Integer)arrayList.get(i)).intValue()); 
      return n0;
    } 
    throw new RuntimeException("Views cannot have both real and virtual children");
  }
  
  private h<n0> y() {
    ArrayList<Integer> arrayList = new ArrayList();
    C(arrayList);
    h<n0> h = new h();
    for (int i = 0; i < arrayList.size(); i++) {
      n0 n0 = t(((Integer)arrayList.get(i)).intValue());
      h.m(((Integer)arrayList.get(i)).intValue(), n0);
    } 
    return h;
  }
  
  private void z(int paramInt, Rect paramRect) {
    J(paramInt).m(paramRect);
  }
  
  public final int A() {
    return this.l;
  }
  
  protected abstract int B(float paramFloat1, float paramFloat2);
  
  protected abstract void C(List<Integer> paramList);
  
  public final void E(int paramInt) {
    F(paramInt, 0);
  }
  
  public final void F(int paramInt1, int paramInt2) {
    if (paramInt1 != Integer.MIN_VALUE && this.h.isEnabled()) {
      ViewParent viewParent = this.i.getParent();
      if (viewParent != null) {
        AccessibilityEvent accessibilityEvent = q(paramInt1, 2048);
        androidx.core.view.accessibility.b.b(accessibilityEvent, paramInt2);
        viewParent.requestSendAccessibilityEvent(this.i, accessibilityEvent);
      } 
    } 
  }
  
  n0 J(int paramInt) {
    return (paramInt == -1) ? u() : t(paramInt);
  }
  
  public final void K(boolean paramBoolean, int paramInt, Rect paramRect) {
    int i = this.l;
    if (i != Integer.MIN_VALUE)
      o(i); 
    if (paramBoolean)
      I(paramInt, paramRect); 
  }
  
  protected abstract boolean L(int paramInt1, int paramInt2, Bundle paramBundle);
  
  protected void M(AccessibilityEvent paramAccessibilityEvent) {}
  
  protected void N(int paramInt, AccessibilityEvent paramAccessibilityEvent) {}
  
  protected void O(n0 paramn0) {}
  
  protected abstract void P(int paramInt, n0 paramn0);
  
  protected void Q(int paramInt, boolean paramBoolean) {}
  
  boolean R(int paramInt1, int paramInt2, Bundle paramBundle) {
    return (paramInt1 != -1) ? S(paramInt1, paramInt2, paramBundle) : T(paramInt2, paramBundle);
  }
  
  public final boolean V(int paramInt) {
    if (!this.i.isFocused() && !this.i.requestFocus())
      return false; 
    int i = this.l;
    if (i == paramInt)
      return false; 
    if (i != Integer.MIN_VALUE)
      o(i); 
    if (paramInt == Integer.MIN_VALUE)
      return false; 
    this.l = paramInt;
    Q(paramInt, true);
    W(paramInt, 8);
    return true;
  }
  
  public final boolean W(int paramInt1, int paramInt2) {
    if (paramInt1 != Integer.MIN_VALUE) {
      if (!this.h.isEnabled())
        return false; 
      ViewParent viewParent = this.i.getParent();
      if (viewParent == null)
        return false; 
      AccessibilityEvent accessibilityEvent = q(paramInt1, paramInt2);
      return viewParent.requestSendAccessibilityEvent(this.i, accessibilityEvent);
    } 
    return false;
  }
  
  public q0 b(View paramView) {
    if (this.j == null)
      this.j = new c(this); 
    return this.j;
  }
  
  public void f(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    super.f(paramView, paramAccessibilityEvent);
    M(paramAccessibilityEvent);
  }
  
  public void g(View paramView, n0 paramn0) {
    super.g(paramView, paramn0);
    O(paramn0);
  }
  
  public final boolean o(int paramInt) {
    if (this.l != paramInt)
      return false; 
    this.l = Integer.MIN_VALUE;
    Q(paramInt, false);
    W(paramInt, 8);
    return true;
  }
  
  public final boolean v(MotionEvent paramMotionEvent) {
    boolean bool = this.h.isEnabled();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      if (!this.h.isTouchExplorationEnabled())
        return false; 
      int i = paramMotionEvent.getAction();
      if (i != 7 && i != 9) {
        if (i != 10)
          return false; 
        if (this.m != Integer.MIN_VALUE) {
          X(-2147483648);
          return true;
        } 
        return false;
      } 
      i = B(paramMotionEvent.getX(), paramMotionEvent.getY());
      X(i);
      bool1 = bool2;
      if (i != Integer.MIN_VALUE)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public final boolean w(KeyEvent paramKeyEvent) {
    int j = paramKeyEvent.getAction();
    boolean bool2 = false;
    int i = 0;
    boolean bool1 = bool2;
    if (j != 1) {
      j = paramKeyEvent.getKeyCode();
      if (j != 61) {
        if (j != 66)
          switch (j) {
            default:
              return false;
            case 19:
            case 20:
            case 21:
            case 22:
              bool1 = bool2;
              if (paramKeyEvent.hasNoModifiers()) {
                j = H(j);
                int k = paramKeyEvent.getRepeatCount();
                for (bool1 = false; i < k + 1 && I(j, null); bool1 = true)
                  i++; 
                return bool1;
              } 
              return bool1;
            case 23:
              break;
          }  
        bool1 = bool2;
        if (paramKeyEvent.hasNoModifiers()) {
          bool1 = bool2;
          if (paramKeyEvent.getRepeatCount() == 0) {
            p();
            return true;
          } 
        } 
      } else {
        if (paramKeyEvent.hasNoModifiers())
          return I(2, null); 
        bool1 = bool2;
        if (paramKeyEvent.hasModifiers(1))
          bool1 = I(1, null); 
      } 
    } 
    return bool1;
  }
  
  public final int x() {
    return this.k;
  }
  
  class a implements b.a<n0> {
    public void b(n0 param1n0, Rect param1Rect) {
      param1n0.m(param1Rect);
    }
  }
  
  class b implements b.b<h<n0>, n0> {
    public n0 c(h<n0> param1h, int param1Int) {
      return (n0)param1h.r(param1Int);
    }
    
    public int d(h<n0> param1h) {
      return param1h.q();
    }
  }
  
  private class c extends q0 {
    c(a this$0) {}
    
    public n0 b(int param1Int) {
      return n0.c0(this.b.J(param1Int));
    }
    
    public n0 d(int param1Int) {
      if (param1Int == 2) {
        param1Int = this.b.k;
      } else {
        param1Int = this.b.l;
      } 
      return (param1Int == Integer.MIN_VALUE) ? null : b(param1Int);
    }
    
    public boolean f(int param1Int1, int param1Int2, Bundle param1Bundle) {
      return this.b.R(param1Int1, param1Int2, param1Bundle);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a3\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */