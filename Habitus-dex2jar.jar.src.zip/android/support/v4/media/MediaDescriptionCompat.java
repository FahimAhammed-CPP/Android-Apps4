package android.support.v4.media;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;

@SuppressLint({"BanParcelableUsage"})
public final class MediaDescriptionCompat implements Parcelable {
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
  
  private MediaDescription A0;
  
  private final String s0;
  
  private final CharSequence t0;
  
  private final CharSequence u0;
  
  private final CharSequence v0;
  
  private final Bitmap w0;
  
  private final Uri x0;
  
  private final Bundle y0;
  
  private final Uri z0;
  
  MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.s0 = paramString;
    this.t0 = paramCharSequence1;
    this.u0 = paramCharSequence2;
    this.v0 = paramCharSequence3;
    this.w0 = paramBitmap;
    this.x0 = paramUri1;
    this.y0 = paramBundle;
    this.z0 = paramUri2;
  }
  
  public static MediaDescriptionCompat a(Object paramObject) {
    MediaDescriptionCompat mediaDescriptionCompat;
    Bundle bundle = null;
    Object object = null;
    if (paramObject != null) {
      int i = Build.VERSION.SDK_INT;
      d d = new d();
      MediaDescription mediaDescription = (MediaDescription)paramObject;
      d.f(b.g(mediaDescription));
      d.i(b.i(mediaDescription));
      d.h(b.h(mediaDescription));
      d.b(b.c(mediaDescription));
      d.d(b.e(mediaDescription));
      d.e(b.f(mediaDescription));
      bundle = b.d(mediaDescription);
      paramObject = bundle;
      if (bundle != null)
        paramObject = MediaSessionCompat.m(bundle); 
      if (paramObject != null) {
        Uri uri = (Uri)paramObject.getParcelable("android.support.v4.media.description.MEDIA_URI");
      } else {
        bundle = null;
      } 
      if (bundle != null)
        if (paramObject.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") && paramObject.size() == 2) {
          paramObject = object;
        } else {
          paramObject.remove("android.support.v4.media.description.MEDIA_URI");
          paramObject.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
        }  
      d.c((Bundle)paramObject);
      if (bundle != null) {
        d.g((Uri)bundle);
      } else if (i >= 23) {
        d.g(c.a(mediaDescription));
      } 
      mediaDescriptionCompat = d.a();
      mediaDescriptionCompat.A0 = mediaDescription;
    } 
    return mediaDescriptionCompat;
  }
  
  public CharSequence b() {
    return this.v0;
  }
  
  public Bundle c() {
    return this.y0;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Bitmap f() {
    return this.w0;
  }
  
  public Uri g() {
    return this.x0;
  }
  
  public Object h() {
    MediaDescription mediaDescription2 = this.A0;
    MediaDescription mediaDescription1 = mediaDescription2;
    if (mediaDescription2 == null) {
      int i = Build.VERSION.SDK_INT;
      MediaDescription.Builder builder = b.b();
      b.n(builder, this.s0);
      b.p(builder, this.t0);
      b.o(builder, this.u0);
      b.j(builder, this.v0);
      b.l(builder, this.w0);
      b.m(builder, this.x0);
      if (i < 23 && this.z0 != null) {
        Bundle bundle;
        if (this.y0 == null) {
          bundle = new Bundle();
          bundle.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
        } else {
          bundle = new Bundle(this.y0);
        } 
        bundle.putParcelable("android.support.v4.media.description.MEDIA_URI", (Parcelable)this.z0);
        b.k(builder, bundle);
      } else {
        b.k(builder, this.y0);
      } 
      if (i >= 23)
        c.b(builder, this.z0); 
      mediaDescription1 = b.a(builder);
      this.A0 = mediaDescription1;
    } 
    return mediaDescription1;
  }
  
  public String i() {
    return this.s0;
  }
  
  public Uri n() {
    return this.z0;
  }
  
  public CharSequence o() {
    return this.u0;
  }
  
  public CharSequence p() {
    return this.t0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.t0);
    stringBuilder.append(", ");
    stringBuilder.append(this.u0);
    stringBuilder.append(", ");
    stringBuilder.append(this.v0);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ((MediaDescription)h()).writeToParcel(paramParcel, paramInt);
  }
  
  class a implements Parcelable.Creator<MediaDescriptionCompat> {
    public MediaDescriptionCompat a(Parcel param1Parcel) {
      return MediaDescriptionCompat.a(MediaDescription.CREATOR.createFromParcel(param1Parcel));
    }
    
    public MediaDescriptionCompat[] b(int param1Int) {
      return new MediaDescriptionCompat[param1Int];
    }
  }
  
  private static class b {
    static MediaDescription a(MediaDescription.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static MediaDescription.Builder b() {
      return new MediaDescription.Builder();
    }
    
    static CharSequence c(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getDescription();
    }
    
    static Bundle d(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getExtras();
    }
    
    static Bitmap e(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getIconBitmap();
    }
    
    static Uri f(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getIconUri();
    }
    
    static String g(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getMediaId();
    }
    
    static CharSequence h(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getSubtitle();
    }
    
    static CharSequence i(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getTitle();
    }
    
    static void j(MediaDescription.Builder param1Builder, CharSequence param1CharSequence) {
      param1Builder.setDescription(param1CharSequence);
    }
    
    static void k(MediaDescription.Builder param1Builder, Bundle param1Bundle) {
      param1Builder.setExtras(param1Bundle);
    }
    
    static void l(MediaDescription.Builder param1Builder, Bitmap param1Bitmap) {
      param1Builder.setIconBitmap(param1Bitmap);
    }
    
    static void m(MediaDescription.Builder param1Builder, Uri param1Uri) {
      param1Builder.setIconUri(param1Uri);
    }
    
    static void n(MediaDescription.Builder param1Builder, String param1String) {
      param1Builder.setMediaId(param1String);
    }
    
    static void o(MediaDescription.Builder param1Builder, CharSequence param1CharSequence) {
      param1Builder.setSubtitle(param1CharSequence);
    }
    
    static void p(MediaDescription.Builder param1Builder, CharSequence param1CharSequence) {
      param1Builder.setTitle(param1CharSequence);
    }
  }
  
  private static class c {
    static Uri a(MediaDescription param1MediaDescription) {
      return b.a(param1MediaDescription);
    }
    
    static void b(MediaDescription.Builder param1Builder, Uri param1Uri) {
      a.a(param1Builder, param1Uri);
    }
  }
  
  public static final class d {
    private String a;
    
    private CharSequence b;
    
    private CharSequence c;
    
    private CharSequence d;
    
    private Bitmap e;
    
    private Uri f;
    
    private Bundle g;
    
    private Uri h;
    
    public MediaDescriptionCompat a() {
      return new MediaDescriptionCompat(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
    }
    
    public d b(CharSequence param1CharSequence) {
      this.d = param1CharSequence;
      return this;
    }
    
    public d c(Bundle param1Bundle) {
      this.g = param1Bundle;
      return this;
    }
    
    public d d(Bitmap param1Bitmap) {
      this.e = param1Bitmap;
      return this;
    }
    
    public d e(Uri param1Uri) {
      this.f = param1Uri;
      return this;
    }
    
    public d f(String param1String) {
      this.a = param1String;
      return this;
    }
    
    public d g(Uri param1Uri) {
      this.h = param1Uri;
      return this;
    }
    
    public d h(CharSequence param1CharSequence) {
      this.c = param1CharSequence;
      return this;
    }
    
    public d i(CharSequence param1CharSequence) {
      this.b = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\android\support\v4\media\MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */