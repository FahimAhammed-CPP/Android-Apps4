package android.support.v4.media;

import android.annotation.SuppressLint;
import android.media.Rating;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

@SuppressLint({"BanParcelableUsage"})
public final class RatingCompat implements Parcelable {
  public static final Parcelable.Creator<RatingCompat> CREATOR = new a();
  
  private final int s0;
  
  private final float t0;
  
  private Object u0;
  
  RatingCompat(int paramInt, float paramFloat) {
    this.s0 = paramInt;
    this.t0 = paramFloat;
  }
  
  public static RatingCompat a(Object paramObject) {
    RatingCompat ratingCompat;
    Rating rating = null;
    if (paramObject != null) {
      rating = (Rating)paramObject;
      int i = b.b(rating);
      if (b.e(rating)) {
        switch (i) {
          default:
            return null;
          case 6:
            ratingCompat = p(b.a(rating));
            break;
          case 3:
          case 4:
          case 5:
            ratingCompat = q(i, b.c((Rating)ratingCompat));
            break;
          case 2:
            ratingCompat = r(b.f((Rating)ratingCompat));
            break;
          case 1:
            ratingCompat = o(b.d((Rating)ratingCompat));
            break;
        } 
      } else {
        ratingCompat = s(i);
      } 
      ratingCompat.u0 = paramObject;
    } 
    return ratingCompat;
  }
  
  public static RatingCompat o(boolean paramBoolean) {
    float f;
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return new RatingCompat(1, f);
  }
  
  public static RatingCompat p(float paramFloat) {
    if (paramFloat < 0.0F || paramFloat > 100.0F) {
      Log.e("Rating", "Invalid percentage-based rating value");
      return null;
    } 
    return new RatingCompat(6, paramFloat);
  }
  
  public static RatingCompat q(int paramInt, float paramFloat) {
    float f;
    if (paramInt != 3) {
      if (paramInt != 4) {
        if (paramInt != 5) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid rating style (");
          stringBuilder.append(paramInt);
          stringBuilder.append(") for a star rating");
          Log.e("Rating", stringBuilder.toString());
          return null;
        } 
        f = 5.0F;
      } else {
        f = 4.0F;
      } 
    } else {
      f = 3.0F;
    } 
    if (paramFloat < 0.0F || paramFloat > f) {
      Log.e("Rating", "Trying to set out of range star-based rating");
      return null;
    } 
    return new RatingCompat(paramInt, paramFloat);
  }
  
  public static RatingCompat r(boolean paramBoolean) {
    float f;
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return new RatingCompat(2, f);
  }
  
  public static RatingCompat s(int paramInt) {
    switch (paramInt) {
      default:
        return null;
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
        break;
    } 
    return new RatingCompat(paramInt, -1.0F);
  }
  
  public float b() {
    return (this.s0 != 6 || !i()) ? -1.0F : this.t0;
  }
  
  public Object c() {
    if (this.u0 == null)
      if (i()) {
        int i = this.s0;
        switch (i) {
          default:
            return null;
          case 6:
            this.u0 = b.h(b());
            return this.u0;
          case 3:
          case 4:
          case 5:
            this.u0 = b.i(i, g());
            return this.u0;
          case 2:
            this.u0 = b.j(n());
            return this.u0;
          case 1:
            break;
        } 
        this.u0 = b.g(h());
      } else {
        this.u0 = b.k(this.s0);
      }  
    return this.u0;
  }
  
  public int describeContents() {
    return this.s0;
  }
  
  public int f() {
    return this.s0;
  }
  
  public float g() {
    int i = this.s0;
    return ((i == 3 || i == 4 || i == 5) && i()) ? this.t0 : -1.0F;
  }
  
  public boolean h() {
    int i = this.s0;
    boolean bool = false;
    if (i != 1)
      return false; 
    if (this.t0 == 1.0F)
      bool = true; 
    return bool;
  }
  
  public boolean i() {
    return (this.t0 >= 0.0F);
  }
  
  public boolean n() {
    int i = this.s0;
    boolean bool = false;
    if (i != 2)
      return false; 
    if (this.t0 == 1.0F)
      bool = true; 
    return bool;
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Rating:style=");
    stringBuilder.append(this.s0);
    stringBuilder.append(" rating=");
    float f = this.t0;
    if (f < 0.0F) {
      str = "unrated";
    } else {
      str = String.valueOf(f);
    } 
    stringBuilder.append(str);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.s0);
    paramParcel.writeFloat(this.t0);
  }
  
  class a implements Parcelable.Creator<RatingCompat> {
    public RatingCompat a(Parcel param1Parcel) {
      return new RatingCompat(param1Parcel.readInt(), param1Parcel.readFloat());
    }
    
    public RatingCompat[] b(int param1Int) {
      return new RatingCompat[param1Int];
    }
  }
  
  private static class b {
    static float a(Rating param1Rating) {
      return param1Rating.getPercentRating();
    }
    
    static int b(Rating param1Rating) {
      return param1Rating.getRatingStyle();
    }
    
    static float c(Rating param1Rating) {
      return param1Rating.getStarRating();
    }
    
    static boolean d(Rating param1Rating) {
      return param1Rating.hasHeart();
    }
    
    static boolean e(Rating param1Rating) {
      return param1Rating.isRated();
    }
    
    static boolean f(Rating param1Rating) {
      return param1Rating.isThumbUp();
    }
    
    static Rating g(boolean param1Boolean) {
      return Rating.newHeartRating(param1Boolean);
    }
    
    static Rating h(float param1Float) {
      return Rating.newPercentageRating(param1Float);
    }
    
    static Rating i(int param1Int, float param1Float) {
      return Rating.newStarRating(param1Int, param1Float);
    }
    
    static Rating j(boolean param1Boolean) {
      return Rating.newThumbRating(param1Boolean);
    }
    
    static Rating k(int param1Int) {
      return Rating.newUnratedRating(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\android\support\v4\media\RatingCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */