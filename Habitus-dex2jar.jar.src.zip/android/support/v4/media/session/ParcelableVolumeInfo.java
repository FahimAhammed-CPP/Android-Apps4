package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
public class ParcelableVolumeInfo implements Parcelable {
  public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new a();
  
  public int s0;
  
  public int t0;
  
  public int u0;
  
  public int v0;
  
  public int w0;
  
  public ParcelableVolumeInfo(Parcel paramParcel) {
    this.s0 = paramParcel.readInt();
    this.u0 = paramParcel.readInt();
    this.v0 = paramParcel.readInt();
    this.w0 = paramParcel.readInt();
    this.t0 = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.s0);
    paramParcel.writeInt(this.u0);
    paramParcel.writeInt(this.v0);
    paramParcel.writeInt(this.w0);
    paramParcel.writeInt(this.t0);
  }
  
  class a implements Parcelable.Creator<ParcelableVolumeInfo> {
    public ParcelableVolumeInfo a(Parcel param1Parcel) {
      return new ParcelableVolumeInfo(param1Parcel);
    }
    
    public ParcelableVolumeInfo[] b(int param1Int) {
      return new ParcelableVolumeInfo[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\android\support\v4\media\session\ParcelableVolumeInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */