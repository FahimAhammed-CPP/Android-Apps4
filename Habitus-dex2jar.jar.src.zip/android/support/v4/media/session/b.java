package android.support.v4.media.session;

import android.app.PendingIntent;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.view.KeyEvent;
import java.util.List;

public interface b extends IInterface {
  boolean A0() throws RemoteException;
  
  void B0(MediaDescriptionCompat paramMediaDescriptionCompat) throws RemoteException;
  
  void C0(String paramString, Bundle paramBundle) throws RemoteException;
  
  void F(String paramString, Bundle paramBundle) throws RemoteException;
  
  Bundle G() throws RemoteException;
  
  CharSequence H0() throws RemoteException;
  
  void I0(a parama) throws RemoteException;
  
  void J(String paramString, Bundle paramBundle) throws RemoteException;
  
  void K(String paramString, Bundle paramBundle) throws RemoteException;
  
  void M(Uri paramUri, Bundle paramBundle) throws RemoteException;
  
  void M0() throws RemoteException;
  
  void O0(long paramLong) throws RemoteException;
  
  boolean R(KeyEvent paramKeyEvent) throws RemoteException;
  
  void S0(float paramFloat) throws RemoteException;
  
  void U(RatingCompat paramRatingCompat, Bundle paramBundle) throws RemoteException;
  
  void W(MediaDescriptionCompat paramMediaDescriptionCompat, int paramInt) throws RemoteException;
  
  void W0(int paramInt1, int paramInt2, String paramString) throws RemoteException;
  
  void Y0(boolean paramBoolean) throws RemoteException;
  
  int a0() throws RemoteException;
  
  String b() throws RemoteException;
  
  PlaybackStateCompat c() throws RemoteException;
  
  void c0(int paramInt) throws RemoteException;
  
  ParcelableVolumeInfo c1() throws RemoteException;
  
  boolean d0() throws RemoteException;
  
  void e() throws RemoteException;
  
  void f() throws RemoteException;
  
  void g(int paramInt) throws RemoteException;
  
  Bundle getExtras() throws RemoteException;
  
  MediaMetadataCompat getMetadata() throws RemoteException;
  
  String getPackageName() throws RemoteException;
  
  void h() throws RemoteException;
  
  void i(int paramInt) throws RemoteException;
  
  void j0(String paramString, Bundle paramBundle, MediaSessionCompat.ResultReceiverWrapper paramResultReceiverWrapper) throws RemoteException;
  
  List<MediaSessionCompat.QueueItem> k() throws RemoteException;
  
  long l() throws RemoteException;
  
  void l0(long paramLong) throws RemoteException;
  
  int m() throws RemoteException;
  
  void m0(boolean paramBoolean) throws RemoteException;
  
  void n(String paramString, Bundle paramBundle) throws RemoteException;
  
  void next() throws RemoteException;
  
  void pause() throws RemoteException;
  
  void previous() throws RemoteException;
  
  boolean q() throws RemoteException;
  
  void stop() throws RemoteException;
  
  void u(Uri paramUri, Bundle paramBundle) throws RemoteException;
  
  void u0(a parama) throws RemoteException;
  
  PendingIntent w() throws RemoteException;
  
  void w0(RatingCompat paramRatingCompat) throws RemoteException;
  
  void x0(int paramInt1, int paramInt2, String paramString) throws RemoteException;
  
  int y() throws RemoteException;
  
  void z0(MediaDescriptionCompat paramMediaDescriptionCompat) throws RemoteException;
  
  public static abstract class a extends Binder implements b {
    public a() {
      attachInterface(this, "android.support.v4.media.session.IMediaSession");
    }
    
    public static b i1(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.v4.media.session.IMediaSession");
      return (iInterface != null && iInterface instanceof b) ? (b)iInterface : new a(param1IBinder);
    }
    
    public static b j1() {
      return a.d;
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    private static class a implements b {
      public static b d;
      
      private IBinder c;
      
      a(IBinder param2IBinder) {
        this.c = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.c;
      }
      
      public PlaybackStateCompat c() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          PlaybackStateCompat playbackStateCompat;
          parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (!this.c.transact(28, parcel1, parcel2, 0) && b.a.j1() != null) {
            playbackStateCompat = b.a.j1().c();
            return playbackStateCompat;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0) {
            playbackStateCompat = (PlaybackStateCompat)PlaybackStateCompat.CREATOR.createFromParcel(parcel2);
          } else {
            playbackStateCompat = null;
          } 
          return playbackStateCompat;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public MediaMetadataCompat getMetadata() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          MediaMetadataCompat mediaMetadataCompat;
          parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (!this.c.transact(27, parcel1, parcel2, 0) && b.a.j1() != null) {
            mediaMetadataCompat = b.a.j1().getMetadata();
            return mediaMetadataCompat;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0) {
            mediaMetadataCompat = (MediaMetadataCompat)MediaMetadataCompat.CREATOR.createFromParcel(parcel2);
          } else {
            mediaMetadataCompat = null;
          } 
          return mediaMetadataCompat;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<MediaSessionCompat.QueueItem> k() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (!this.c.transact(29, parcel1, parcel2, 0) && b.a.j1() != null)
            return b.a.j1().k(); 
          parcel2.readException();
          return parcel2.createTypedArrayList(MediaSessionCompat.QueueItem.CREATOR);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void u0(a param2a) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          IBinder iBinder;
          parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (param2a != null) {
            iBinder = param2a.asBinder();
          } else {
            iBinder = null;
          } 
          parcel1.writeStrongBinder(iBinder);
          if (!this.c.transact(3, parcel1, parcel2, 0) && b.a.j1() != null) {
            b.a.j1().u0(param2a);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements b {
    public static b d;
    
    private IBinder c;
    
    a(IBinder param1IBinder) {
      this.c = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.c;
    }
    
    public PlaybackStateCompat c() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        PlaybackStateCompat playbackStateCompat;
        parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
        if (!this.c.transact(28, parcel1, parcel2, 0) && b.a.j1() != null) {
          playbackStateCompat = b.a.j1().c();
          return playbackStateCompat;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0) {
          playbackStateCompat = (PlaybackStateCompat)PlaybackStateCompat.CREATOR.createFromParcel(parcel2);
        } else {
          playbackStateCompat = null;
        } 
        return playbackStateCompat;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public MediaMetadataCompat getMetadata() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        MediaMetadataCompat mediaMetadataCompat;
        parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
        if (!this.c.transact(27, parcel1, parcel2, 0) && b.a.j1() != null) {
          mediaMetadataCompat = b.a.j1().getMetadata();
          return mediaMetadataCompat;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0) {
          mediaMetadataCompat = (MediaMetadataCompat)MediaMetadataCompat.CREATOR.createFromParcel(parcel2);
        } else {
          mediaMetadataCompat = null;
        } 
        return mediaMetadataCompat;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<MediaSessionCompat.QueueItem> k() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
        if (!this.c.transact(29, parcel1, parcel2, 0) && b.a.j1() != null)
          return b.a.j1().k(); 
        parcel2.readException();
        return parcel2.createTypedArrayList(MediaSessionCompat.QueueItem.CREATOR);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void u0(a param1a) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        IBinder iBinder;
        parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
        if (param1a != null) {
          iBinder = param1a.asBinder();
        } else {
          iBinder = null;
        } 
        parcel1.writeStrongBinder(iBinder);
        if (!this.c.transact(3, parcel1, parcel2, 0) && b.a.j1() != null) {
          b.a.j1().u0(param1a);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\android\support\v4\media\session\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */