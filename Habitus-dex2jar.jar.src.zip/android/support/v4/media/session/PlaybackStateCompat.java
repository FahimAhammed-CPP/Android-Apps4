package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@SuppressLint({"BanParcelableUsage"})
public final class PlaybackStateCompat implements Parcelable {
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
  
  List<CustomAction> A0;
  
  final long B0;
  
  final Bundle C0;
  
  private PlaybackState D0;
  
  final int s0;
  
  final long t0;
  
  final long u0;
  
  final float v0;
  
  final long w0;
  
  final int x0;
  
  final CharSequence y0;
  
  final long z0;
  
  PlaybackStateCompat(int paramInt1, long paramLong1, long paramLong2, float paramFloat, long paramLong3, int paramInt2, CharSequence paramCharSequence, long paramLong4, List<CustomAction> paramList, long paramLong5, Bundle paramBundle) {
    this.s0 = paramInt1;
    this.t0 = paramLong1;
    this.u0 = paramLong2;
    this.v0 = paramFloat;
    this.w0 = paramLong3;
    this.x0 = paramInt2;
    this.y0 = paramCharSequence;
    this.z0 = paramLong4;
    this.A0 = new ArrayList<CustomAction>(paramList);
    this.B0 = paramLong5;
    this.C0 = paramBundle;
  }
  
  PlaybackStateCompat(Parcel paramParcel) {
    this.s0 = paramParcel.readInt();
    this.t0 = paramParcel.readLong();
    this.v0 = paramParcel.readFloat();
    this.z0 = paramParcel.readLong();
    this.u0 = paramParcel.readLong();
    this.w0 = paramParcel.readLong();
    this.y0 = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.A0 = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.B0 = paramParcel.readLong();
    this.C0 = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
    this.x0 = paramParcel.readInt();
  }
  
  public static PlaybackStateCompat a(Object paramObject) {
    PlaybackStateCompat playbackStateCompat;
    List<PlaybackState.CustomAction> list = null;
    List list1 = null;
    if (paramObject != null) {
      Bundle bundle;
      PlaybackState playbackState = (PlaybackState)paramObject;
      list = b.j(playbackState);
      if (list != null) {
        paramObject = new ArrayList(list.size());
        Iterator<PlaybackState.CustomAction> iterator = list.iterator();
        while (iterator.hasNext())
          paramObject.add(CustomAction.a(iterator.next())); 
      } else {
        paramObject = null;
      } 
      list = list1;
      if (Build.VERSION.SDK_INT >= 22) {
        bundle = c.a(playbackState);
        MediaSessionCompat.a(bundle);
      } 
      playbackStateCompat = new PlaybackStateCompat(b.r(playbackState), b.q(playbackState), b.i(playbackState), b.p(playbackState), b.g(playbackState), 0, b.k(playbackState), b.n(playbackState), (List<CustomAction>)paramObject, b.h(playbackState), bundle);
      playbackStateCompat.D0 = playbackState;
    } 
    return playbackStateCompat;
  }
  
  public long b() {
    return this.w0;
  }
  
  public long c() {
    return this.B0;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public long f() {
    return this.z0;
  }
  
  public float g() {
    return this.v0;
  }
  
  public Object h() {
    if (this.D0 == null) {
      PlaybackState.Builder builder = b.d();
      b.x(builder, this.s0, this.t0, this.v0, this.z0);
      b.u(builder, this.u0);
      b.s(builder, this.w0);
      b.v(builder, this.y0);
      Iterator<CustomAction> iterator = this.A0.iterator();
      while (iterator.hasNext())
        b.a(builder, (PlaybackState.CustomAction)((CustomAction)iterator.next()).c()); 
      b.t(builder, this.B0);
      if (Build.VERSION.SDK_INT >= 22)
        c.b(builder, this.C0); 
      this.D0 = b.c(builder);
    } 
    return this.D0;
  }
  
  public long i() {
    return this.t0;
  }
  
  public int n() {
    return this.s0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=");
    stringBuilder.append(this.s0);
    stringBuilder.append(", position=");
    stringBuilder.append(this.t0);
    stringBuilder.append(", buffered position=");
    stringBuilder.append(this.u0);
    stringBuilder.append(", speed=");
    stringBuilder.append(this.v0);
    stringBuilder.append(", updated=");
    stringBuilder.append(this.z0);
    stringBuilder.append(", actions=");
    stringBuilder.append(this.w0);
    stringBuilder.append(", error code=");
    stringBuilder.append(this.x0);
    stringBuilder.append(", error message=");
    stringBuilder.append(this.y0);
    stringBuilder.append(", custom actions=");
    stringBuilder.append(this.A0);
    stringBuilder.append(", active item id=");
    stringBuilder.append(this.B0);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.s0);
    paramParcel.writeLong(this.t0);
    paramParcel.writeFloat(this.v0);
    paramParcel.writeLong(this.z0);
    paramParcel.writeLong(this.u0);
    paramParcel.writeLong(this.w0);
    TextUtils.writeToParcel(this.y0, paramParcel, paramInt);
    paramParcel.writeTypedList(this.A0);
    paramParcel.writeLong(this.B0);
    paramParcel.writeBundle(this.C0);
    paramParcel.writeInt(this.x0);
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new a();
    
    private final String s0;
    
    private final CharSequence t0;
    
    private final int u0;
    
    private final Bundle v0;
    
    private PlaybackState.CustomAction w0;
    
    CustomAction(Parcel param1Parcel) {
      this.s0 = param1Parcel.readString();
      this.t0 = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.u0 = param1Parcel.readInt();
      this.v0 = param1Parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }
    
    CustomAction(String param1String, CharSequence param1CharSequence, int param1Int, Bundle param1Bundle) {
      this.s0 = param1String;
      this.t0 = param1CharSequence;
      this.u0 = param1Int;
      this.v0 = param1Bundle;
    }
    
    public static CustomAction a(Object param1Object) {
      if (param1Object != null) {
        param1Object = param1Object;
        Bundle bundle = PlaybackStateCompat.b.l((PlaybackState.CustomAction)param1Object);
        MediaSessionCompat.a(bundle);
        CustomAction customAction = new CustomAction(PlaybackStateCompat.b.f((PlaybackState.CustomAction)param1Object), PlaybackStateCompat.b.o((PlaybackState.CustomAction)param1Object), PlaybackStateCompat.b.m((PlaybackState.CustomAction)param1Object), bundle);
        customAction.w0 = (PlaybackState.CustomAction)param1Object;
        return customAction;
      } 
      return null;
    }
    
    public String b() {
      return this.s0;
    }
    
    public Object c() {
      PlaybackState.CustomAction customAction2 = this.w0;
      PlaybackState.CustomAction customAction1 = customAction2;
      if (customAction2 == null) {
        PlaybackState.CustomAction.Builder builder = PlaybackStateCompat.b.e(this.s0, this.t0, this.u0);
        PlaybackStateCompat.b.w(builder, this.v0);
        customAction1 = PlaybackStateCompat.b.b(builder);
      } 
      return customAction1;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Action:mName='");
      stringBuilder.append(this.t0);
      stringBuilder.append(", mIcon=");
      stringBuilder.append(this.u0);
      stringBuilder.append(", mExtras=");
      stringBuilder.append(this.v0);
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.s0);
      TextUtils.writeToParcel(this.t0, param1Parcel, param1Int);
      param1Parcel.writeInt(this.u0);
      param1Parcel.writeBundle(this.v0);
    }
    
    class a implements Parcelable.Creator<CustomAction> {
      public PlaybackStateCompat.CustomAction a(Parcel param2Parcel) {
        return new PlaybackStateCompat.CustomAction(param2Parcel);
      }
      
      public PlaybackStateCompat.CustomAction[] b(int param2Int) {
        return new PlaybackStateCompat.CustomAction[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<CustomAction> {
    public PlaybackStateCompat.CustomAction a(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public PlaybackStateCompat.CustomAction[] b(int param1Int) {
      return new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  class a implements Parcelable.Creator<PlaybackStateCompat> {
    public PlaybackStateCompat a(Parcel param1Parcel) {
      return new PlaybackStateCompat(param1Parcel);
    }
    
    public PlaybackStateCompat[] b(int param1Int) {
      return new PlaybackStateCompat[param1Int];
    }
  }
  
  private static class b {
    static void a(PlaybackState.Builder param1Builder, PlaybackState.CustomAction param1CustomAction) {
      param1Builder.addCustomAction(param1CustomAction);
    }
    
    static PlaybackState.CustomAction b(PlaybackState.CustomAction.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static PlaybackState c(PlaybackState.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static PlaybackState.Builder d() {
      return new PlaybackState.Builder();
    }
    
    static PlaybackState.CustomAction.Builder e(String param1String, CharSequence param1CharSequence, int param1Int) {
      return new PlaybackState.CustomAction.Builder(param1String, param1CharSequence, param1Int);
    }
    
    static String f(PlaybackState.CustomAction param1CustomAction) {
      return param1CustomAction.getAction();
    }
    
    static long g(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getActions();
    }
    
    static long h(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getActiveQueueItemId();
    }
    
    static long i(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getBufferedPosition();
    }
    
    static List<PlaybackState.CustomAction> j(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getCustomActions();
    }
    
    static CharSequence k(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getErrorMessage();
    }
    
    static Bundle l(PlaybackState.CustomAction param1CustomAction) {
      return param1CustomAction.getExtras();
    }
    
    static int m(PlaybackState.CustomAction param1CustomAction) {
      return param1CustomAction.getIcon();
    }
    
    static long n(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getLastPositionUpdateTime();
    }
    
    static CharSequence o(PlaybackState.CustomAction param1CustomAction) {
      return param1CustomAction.getName();
    }
    
    static float p(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getPlaybackSpeed();
    }
    
    static long q(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getPosition();
    }
    
    static int r(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getState();
    }
    
    static void s(PlaybackState.Builder param1Builder, long param1Long) {
      param1Builder.setActions(param1Long);
    }
    
    static void t(PlaybackState.Builder param1Builder, long param1Long) {
      param1Builder.setActiveQueueItemId(param1Long);
    }
    
    static void u(PlaybackState.Builder param1Builder, long param1Long) {
      param1Builder.setBufferedPosition(param1Long);
    }
    
    static void v(PlaybackState.Builder param1Builder, CharSequence param1CharSequence) {
      param1Builder.setErrorMessage(param1CharSequence);
    }
    
    static void w(PlaybackState.CustomAction.Builder param1Builder, Bundle param1Bundle) {
      param1Builder.setExtras(param1Bundle);
    }
    
    static void x(PlaybackState.Builder param1Builder, int param1Int, long param1Long1, float param1Float, long param1Long2) {
      param1Builder.setState(param1Int, param1Long1, param1Float, param1Long2);
    }
  }
  
  private static class c {
    static Bundle a(PlaybackState param1PlaybackState) {
      return e.a(param1PlaybackState);
    }
    
    static void b(PlaybackState.Builder param1Builder, Bundle param1Bundle) {
      f.a(param1Builder, param1Bundle);
    }
  }
  
  public static final class d {
    private final List<PlaybackStateCompat.CustomAction> a;
    
    private int b;
    
    private long c;
    
    private long d;
    
    private float e;
    
    private long f;
    
    private int g;
    
    private CharSequence h;
    
    private long i;
    
    private long j;
    
    private Bundle k;
    
    public d() {
      this.a = new ArrayList<PlaybackStateCompat.CustomAction>();
      this.j = -1L;
    }
    
    public d(PlaybackStateCompat param1PlaybackStateCompat) {
      ArrayList<PlaybackStateCompat.CustomAction> arrayList = new ArrayList();
      this.a = arrayList;
      this.j = -1L;
      this.b = param1PlaybackStateCompat.s0;
      this.c = param1PlaybackStateCompat.t0;
      this.e = param1PlaybackStateCompat.v0;
      this.i = param1PlaybackStateCompat.z0;
      this.d = param1PlaybackStateCompat.u0;
      this.f = param1PlaybackStateCompat.w0;
      this.g = param1PlaybackStateCompat.x0;
      this.h = param1PlaybackStateCompat.y0;
      List<PlaybackStateCompat.CustomAction> list = param1PlaybackStateCompat.A0;
      if (list != null)
        arrayList.addAll(list); 
      this.j = param1PlaybackStateCompat.B0;
      this.k = param1PlaybackStateCompat.C0;
    }
    
    public d a(PlaybackStateCompat.CustomAction param1CustomAction) {
      if (param1CustomAction != null) {
        this.a.add(param1CustomAction);
        return this;
      } 
      throw new IllegalArgumentException("You may not add a null CustomAction to PlaybackStateCompat");
    }
    
    public PlaybackStateCompat b() {
      return new PlaybackStateCompat(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.a, this.j, this.k);
    }
    
    public d c(long param1Long) {
      this.f = param1Long;
      return this;
    }
    
    public d d(long param1Long) {
      this.j = param1Long;
      return this;
    }
    
    public d e(long param1Long) {
      this.d = param1Long;
      return this;
    }
    
    public d f(int param1Int, CharSequence param1CharSequence) {
      this.g = param1Int;
      this.h = param1CharSequence;
      return this;
    }
    
    public d g(Bundle param1Bundle) {
      this.k = param1Bundle;
      return this;
    }
    
    public d h(int param1Int, long param1Long1, float param1Float, long param1Long2) {
      this.b = param1Int;
      this.c = param1Long1;
      this.i = param1Long2;
      this.e = param1Float;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\android\support\v4\media\session\PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */