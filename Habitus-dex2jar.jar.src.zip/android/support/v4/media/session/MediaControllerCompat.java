package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.MediaMetadataCompat;
import android.util.Log;
import androidx.core.app.g;
import androidx.media.AudioAttributesCompat;
import j$.util.concurrent.ConcurrentHashMap;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public final class MediaControllerCompat {
  private final b a;
  
  private final MediaSessionCompat.Token b;
  
  @SuppressLint({"BanConcurrentHashMap"})
  private final ConcurrentHashMap<a, Boolean> c = new ConcurrentHashMap();
  
  public MediaControllerCompat(Context paramContext, MediaSessionCompat paramMediaSessionCompat) {
    if (paramMediaSessionCompat != null) {
      MediaSessionCompat.Token token = paramMediaSessionCompat.c();
      this.b = token;
      if (Build.VERSION.SDK_INT >= 29) {
        this.a = new c(paramContext, token);
        return;
      } 
      this.a = new MediaControllerImplApi21(paramContext, token);
      return;
    } 
    throw new IllegalArgumentException("session must not be null");
  }
  
  public MediaMetadataCompat a() {
    return this.a.getMetadata();
  }
  
  public PlaybackStateCompat b() {
    return this.a.c();
  }
  
  public List<MediaSessionCompat.QueueItem> c() {
    return this.a.k();
  }
  
  static class MediaControllerImplApi21 implements b {
    protected final MediaController a;
    
    final Object b = new Object();
    
    private final List<MediaControllerCompat.a> c = new ArrayList<MediaControllerCompat.a>();
    
    private HashMap<MediaControllerCompat.a, a> d = new HashMap<MediaControllerCompat.a, a>();
    
    final MediaSessionCompat.Token e;
    
    MediaControllerImplApi21(Context param1Context, MediaSessionCompat.Token param1Token) {
      this.e = param1Token;
      this.a = new MediaController(param1Context, (MediaSession.Token)param1Token.c());
      if (param1Token.a() == null)
        b(); 
    }
    
    private void b() {
      d("android.support.v4.media.session.command.GET_EXTRA_BINDER", null, new ExtraBinderRequestResultReceiver(this));
    }
    
    void a() {
      if (this.e.a() == null)
        return; 
      Iterator<MediaControllerCompat.a> iterator = this.c.iterator();
      while (iterator.hasNext()) {
        MediaControllerCompat.a a = iterator.next();
        a a1 = new a(a);
        this.d.put(a, a1);
        a.b = a1;
        try {
          this.e.a().u0(a1);
          a.i(13, null, null);
        } catch (RemoteException remoteException) {
          Log.e("MediaControllerCompat", "Dead object in registerCallback.", (Throwable)remoteException);
          break;
        } 
      } 
      this.c.clear();
    }
    
    public PlaybackStateCompat c() {
      if (this.e.a() != null)
        try {
          return this.e.a().c();
        } catch (RemoteException remoteException) {
          Log.e("MediaControllerCompat", "Dead object in getPlaybackState.", (Throwable)remoteException);
        }  
      PlaybackState playbackState = this.a.getPlaybackState();
      return (playbackState != null) ? PlaybackStateCompat.a(playbackState) : null;
    }
    
    public void d(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {
      this.a.sendCommand(param1String, param1Bundle, param1ResultReceiver);
    }
    
    public MediaMetadataCompat getMetadata() {
      MediaMetadata mediaMetadata = this.a.getMetadata();
      return (mediaMetadata != null) ? MediaMetadataCompat.b(mediaMetadata) : null;
    }
    
    public List<MediaSessionCompat.QueueItem> k() {
      List<?> list = this.a.getQueue();
      return (list != null) ? MediaSessionCompat.QueueItem.b(list) : null;
    }
    
    private static class ExtraBinderRequestResultReceiver extends ResultReceiver {
      private WeakReference<MediaControllerCompat.MediaControllerImplApi21> s0;
      
      ExtraBinderRequestResultReceiver(MediaControllerCompat.MediaControllerImplApi21 param2MediaControllerImplApi21) {
        super(null);
        this.s0 = new WeakReference<MediaControllerCompat.MediaControllerImplApi21>(param2MediaControllerImplApi21);
      }
      
      protected void onReceiveResult(int param2Int, Bundle param2Bundle) {
        MediaControllerCompat.MediaControllerImplApi21 mediaControllerImplApi21 = this.s0.get();
        if (mediaControllerImplApi21 != null) {
          if (param2Bundle == null)
            return; 
          synchronized (mediaControllerImplApi21.b) {
            mediaControllerImplApi21.e.f(b.a.i1(g.a(param2Bundle, "android.support.v4.media.session.EXTRA_BINDER")));
            mediaControllerImplApi21.e.g(l4.a.b(param2Bundle, "android.support.v4.media.session.SESSION_TOKEN2"));
            mediaControllerImplApi21.a();
            return;
          } 
        } 
      }
    }
    
    private static class a extends MediaControllerCompat.a.b {
      a(MediaControllerCompat.a param2a) {
        super(param2a);
      }
      
      public void E(List<MediaSessionCompat.QueueItem> param2List) throws RemoteException {
        throw new AssertionError();
      }
      
      public void G0(Bundle param2Bundle) throws RemoteException {
        throw new AssertionError();
      }
      
      public void V() throws RemoteException {
        throw new AssertionError();
      }
      
      public void V0(CharSequence param2CharSequence) throws RemoteException {
        throw new AssertionError();
      }
      
      public void X(MediaMetadataCompat param2MediaMetadataCompat) throws RemoteException {
        throw new AssertionError();
      }
      
      public void r0(ParcelableVolumeInfo param2ParcelableVolumeInfo) throws RemoteException {
        throw new AssertionError();
      }
    }
  }
  
  private static class ExtraBinderRequestResultReceiver extends ResultReceiver {
    private WeakReference<MediaControllerCompat.MediaControllerImplApi21> s0;
    
    ExtraBinderRequestResultReceiver(MediaControllerCompat.MediaControllerImplApi21 param1MediaControllerImplApi21) {
      super(null);
      this.s0 = new WeakReference<MediaControllerCompat.MediaControllerImplApi21>(param1MediaControllerImplApi21);
    }
    
    protected void onReceiveResult(int param1Int, Bundle param1Bundle) {
      MediaControllerCompat.MediaControllerImplApi21 mediaControllerImplApi21 = this.s0.get();
      if (mediaControllerImplApi21 != null) {
        if (param1Bundle == null)
          return; 
        synchronized (mediaControllerImplApi21.b) {
          mediaControllerImplApi21.e.f(b.a.i1(g.a(param1Bundle, "android.support.v4.media.session.EXTRA_BINDER")));
          mediaControllerImplApi21.e.g(l4.a.b(param1Bundle, "android.support.v4.media.session.SESSION_TOKEN2"));
          mediaControllerImplApi21.a();
          return;
        } 
      } 
    }
  }
  
  private static class a extends a.b {
    a(MediaControllerCompat.a param1a) {
      super(param1a);
    }
    
    public void E(List<MediaSessionCompat.QueueItem> param1List) throws RemoteException {
      throw new AssertionError();
    }
    
    public void G0(Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public void V() throws RemoteException {
      throw new AssertionError();
    }
    
    public void V0(CharSequence param1CharSequence) throws RemoteException {
      throw new AssertionError();
    }
    
    public void X(MediaMetadataCompat param1MediaMetadataCompat) throws RemoteException {
      throw new AssertionError();
    }
    
    public void r0(ParcelableVolumeInfo param1ParcelableVolumeInfo) throws RemoteException {
      throw new AssertionError();
    }
  }
  
  public static abstract class a implements IBinder.DeathRecipient {
    final MediaController.Callback a = new a(this);
    
    a b;
    
    public void a(MediaControllerCompat.d param1d) {}
    
    public void b(Bundle param1Bundle) {}
    
    public void binderDied() {
      i(8, null, null);
    }
    
    public void c(MediaMetadataCompat param1MediaMetadataCompat) {}
    
    public void d(PlaybackStateCompat param1PlaybackStateCompat) {}
    
    public void e(List<MediaSessionCompat.QueueItem> param1List) {}
    
    public void f(CharSequence param1CharSequence) {}
    
    public void g() {}
    
    public void h(String param1String, Bundle param1Bundle) {}
    
    void i(int param1Int, Object param1Object, Bundle param1Bundle) {}
    
    private static class a extends MediaController.Callback {
      private final WeakReference<MediaControllerCompat.a> a;
      
      a(MediaControllerCompat.a param2a) {
        this.a = new WeakReference<MediaControllerCompat.a>(param2a);
      }
      
      public void onAudioInfoChanged(MediaController.PlaybackInfo param2PlaybackInfo) {
        MediaControllerCompat.a a1 = this.a.get();
        if (a1 != null)
          a1.a(new MediaControllerCompat.d(param2PlaybackInfo.getPlaybackType(), AudioAttributesCompat.c(param2PlaybackInfo.getAudioAttributes()), param2PlaybackInfo.getVolumeControl(), param2PlaybackInfo.getMaxVolume(), param2PlaybackInfo.getCurrentVolume())); 
      }
      
      public void onExtrasChanged(Bundle param2Bundle) {
        MediaSessionCompat.a(param2Bundle);
        MediaControllerCompat.a a1 = this.a.get();
        if (a1 != null)
          a1.b(param2Bundle); 
      }
      
      public void onMetadataChanged(MediaMetadata param2MediaMetadata) {
        MediaControllerCompat.a a1 = this.a.get();
        if (a1 != null)
          a1.c(MediaMetadataCompat.b(param2MediaMetadata)); 
      }
      
      public void onPlaybackStateChanged(PlaybackState param2PlaybackState) {
        MediaControllerCompat.a a1 = this.a.get();
        if (a1 != null) {
          if (a1.b != null)
            return; 
          a1.d(PlaybackStateCompat.a(param2PlaybackState));
        } 
      }
      
      public void onQueueChanged(List<MediaSession.QueueItem> param2List) {
        MediaControllerCompat.a a1 = this.a.get();
        if (a1 != null)
          a1.e(MediaSessionCompat.QueueItem.b(param2List)); 
      }
      
      public void onQueueTitleChanged(CharSequence param2CharSequence) {
        MediaControllerCompat.a a1 = this.a.get();
        if (a1 != null)
          a1.f(param2CharSequence); 
      }
      
      public void onSessionDestroyed() {
        MediaControllerCompat.a a1 = this.a.get();
        if (a1 != null)
          a1.g(); 
      }
      
      public void onSessionEvent(String param2String, Bundle param2Bundle) {
        MediaSessionCompat.a(param2Bundle);
        MediaControllerCompat.a a1 = this.a.get();
        if (a1 != null) {
          if (a1.b != null && Build.VERSION.SDK_INT < 23)
            return; 
          a1.h(param2String, param2Bundle);
        } 
      }
    }
    
    private static class b extends a.a {
      private final WeakReference<MediaControllerCompat.a> c;
      
      b(MediaControllerCompat.a param2a) {
        this.c = new WeakReference<MediaControllerCompat.a>(param2a);
      }
      
      public void C() throws RemoteException {
        MediaControllerCompat.a a1 = this.c.get();
        if (a1 != null)
          a1.i(13, null, null); 
      }
      
      public void P0(boolean param2Boolean) throws RemoteException {
        MediaControllerCompat.a a1 = this.c.get();
        if (a1 != null)
          a1.i(11, Boolean.valueOf(param2Boolean), null); 
      }
      
      public void T0(boolean param2Boolean) throws RemoteException {}
      
      public void f0(int param2Int) throws RemoteException {
        MediaControllerCompat.a a1 = this.c.get();
        if (a1 != null)
          a1.i(12, Integer.valueOf(param2Int), null); 
      }
      
      public void h1(PlaybackStateCompat param2PlaybackStateCompat) throws RemoteException {
        MediaControllerCompat.a a1 = this.c.get();
        if (a1 != null)
          a1.i(2, param2PlaybackStateCompat, null); 
      }
      
      public void onEvent(String param2String, Bundle param2Bundle) throws RemoteException {
        MediaControllerCompat.a a1 = this.c.get();
        if (a1 != null)
          a1.i(1, param2String, param2Bundle); 
      }
      
      public void onRepeatModeChanged(int param2Int) throws RemoteException {
        MediaControllerCompat.a a1 = this.c.get();
        if (a1 != null)
          a1.i(9, Integer.valueOf(param2Int), null); 
      }
    }
  }
  
  private static class a extends MediaController.Callback {
    private final WeakReference<MediaControllerCompat.a> a;
    
    a(MediaControllerCompat.a param1a) {
      this.a = new WeakReference<MediaControllerCompat.a>(param1a);
    }
    
    public void onAudioInfoChanged(MediaController.PlaybackInfo param1PlaybackInfo) {
      MediaControllerCompat.a a1 = this.a.get();
      if (a1 != null)
        a1.a(new MediaControllerCompat.d(param1PlaybackInfo.getPlaybackType(), AudioAttributesCompat.c(param1PlaybackInfo.getAudioAttributes()), param1PlaybackInfo.getVolumeControl(), param1PlaybackInfo.getMaxVolume(), param1PlaybackInfo.getCurrentVolume())); 
    }
    
    public void onExtrasChanged(Bundle param1Bundle) {
      MediaSessionCompat.a(param1Bundle);
      MediaControllerCompat.a a1 = this.a.get();
      if (a1 != null)
        a1.b(param1Bundle); 
    }
    
    public void onMetadataChanged(MediaMetadata param1MediaMetadata) {
      MediaControllerCompat.a a1 = this.a.get();
      if (a1 != null)
        a1.c(MediaMetadataCompat.b(param1MediaMetadata)); 
    }
    
    public void onPlaybackStateChanged(PlaybackState param1PlaybackState) {
      MediaControllerCompat.a a1 = this.a.get();
      if (a1 != null) {
        if (a1.b != null)
          return; 
        a1.d(PlaybackStateCompat.a(param1PlaybackState));
      } 
    }
    
    public void onQueueChanged(List<MediaSession.QueueItem> param1List) {
      MediaControllerCompat.a a1 = this.a.get();
      if (a1 != null)
        a1.e(MediaSessionCompat.QueueItem.b(param1List)); 
    }
    
    public void onQueueTitleChanged(CharSequence param1CharSequence) {
      MediaControllerCompat.a a1 = this.a.get();
      if (a1 != null)
        a1.f(param1CharSequence); 
    }
    
    public void onSessionDestroyed() {
      MediaControllerCompat.a a1 = this.a.get();
      if (a1 != null)
        a1.g(); 
    }
    
    public void onSessionEvent(String param1String, Bundle param1Bundle) {
      MediaSessionCompat.a(param1Bundle);
      MediaControllerCompat.a a1 = this.a.get();
      if (a1 != null) {
        if (a1.b != null && Build.VERSION.SDK_INT < 23)
          return; 
        a1.h(param1String, param1Bundle);
      } 
    }
  }
  
  private static class b extends a.a {
    private final WeakReference<MediaControllerCompat.a> c;
    
    b(MediaControllerCompat.a param1a) {
      this.c = new WeakReference<MediaControllerCompat.a>(param1a);
    }
    
    public void C() throws RemoteException {
      MediaControllerCompat.a a1 = this.c.get();
      if (a1 != null)
        a1.i(13, null, null); 
    }
    
    public void P0(boolean param1Boolean) throws RemoteException {
      MediaControllerCompat.a a1 = this.c.get();
      if (a1 != null)
        a1.i(11, Boolean.valueOf(param1Boolean), null); 
    }
    
    public void T0(boolean param1Boolean) throws RemoteException {}
    
    public void f0(int param1Int) throws RemoteException {
      MediaControllerCompat.a a1 = this.c.get();
      if (a1 != null)
        a1.i(12, Integer.valueOf(param1Int), null); 
    }
    
    public void h1(PlaybackStateCompat param1PlaybackStateCompat) throws RemoteException {
      MediaControllerCompat.a a1 = this.c.get();
      if (a1 != null)
        a1.i(2, param1PlaybackStateCompat, null); 
    }
    
    public void onEvent(String param1String, Bundle param1Bundle) throws RemoteException {
      MediaControllerCompat.a a1 = this.c.get();
      if (a1 != null)
        a1.i(1, param1String, param1Bundle); 
    }
    
    public void onRepeatModeChanged(int param1Int) throws RemoteException {
      MediaControllerCompat.a a1 = this.c.get();
      if (a1 != null)
        a1.i(9, Integer.valueOf(param1Int), null); 
    }
  }
  
  static interface b {
    PlaybackStateCompat c();
    
    MediaMetadataCompat getMetadata();
    
    List<MediaSessionCompat.QueueItem> k();
  }
  
  static class c extends MediaControllerImplApi21 {
    c(Context param1Context, MediaSessionCompat.Token param1Token) {
      super(param1Context, param1Token);
    }
  }
  
  public static final class d {
    private final int a;
    
    private final AudioAttributesCompat b;
    
    private final int c;
    
    private final int d;
    
    private final int e;
    
    d(int param1Int1, AudioAttributesCompat param1AudioAttributesCompat, int param1Int2, int param1Int3, int param1Int4) {
      this.a = param1Int1;
      this.b = param1AudioAttributesCompat;
      this.c = param1Int2;
      this.d = param1Int3;
      this.e = param1Int4;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\android\support\v4\media\session\MediaControllerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */