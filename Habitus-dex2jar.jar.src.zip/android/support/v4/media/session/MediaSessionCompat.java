package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaDescription;
import android.media.MediaMetadata;
import android.media.Rating;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MediaSessionCompat {
  static int d;
  
  private final c a;
  
  private final MediaControllerCompat b;
  
  private final ArrayList<h> c = new ArrayList<h>();
  
  public MediaSessionCompat(Context paramContext, String paramString) {
    this(paramContext, paramString, null, null);
  }
  
  public MediaSessionCompat(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent) {
    this(paramContext, paramString, paramComponentName, paramPendingIntent, null);
  }
  
  public MediaSessionCompat(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent, Bundle paramBundle) {
    this(paramContext, paramString, paramComponentName, paramPendingIntent, paramBundle, null);
  }
  
  public MediaSessionCompat(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent, Bundle paramBundle, l4.b paramb) {
    if (paramContext != null) {
      if (!TextUtils.isEmpty(paramString)) {
        Looper looper;
        ComponentName componentName = paramComponentName;
        if (paramComponentName == null) {
          paramComponentName = v3.a.a(paramContext);
          componentName = paramComponentName;
          if (paramComponentName == null) {
            Log.w("MediaSessionCompat", "Couldn't find a unique registered media button receiver in the given context.");
            componentName = paramComponentName;
          } 
        } 
        PendingIntent pendingIntent = paramPendingIntent;
        if (componentName != null) {
          pendingIntent = paramPendingIntent;
          if (paramPendingIntent == null) {
            boolean bool;
            Intent intent = new Intent("android.intent.action.MEDIA_BUTTON");
            intent.setComponent(componentName);
            if (Build.VERSION.SDK_INT >= 31) {
              bool = true;
            } else {
              bool = false;
            } 
            pendingIntent = PendingIntent.getBroadcast(paramContext, 0, intent, bool);
          } 
        } 
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
          this.a = new g(paramContext, paramString, paramb, paramBundle);
        } else if (i >= 28) {
          this.a = new f(paramContext, paramString, paramb, paramBundle);
        } else if (i >= 22) {
          this.a = new e(paramContext, paramString, paramb, paramBundle);
        } else {
          this.a = new d(paramContext, paramString, paramb, paramBundle);
        } 
        if (Looper.myLooper() != null) {
          looper = Looper.myLooper();
        } else {
          looper = Looper.getMainLooper();
        } 
        Handler handler = new Handler(looper);
        g(new a(this), handler);
        this.a.l(pendingIntent);
        this.b = new MediaControllerCompat(paramContext, this);
        if (d == 0)
          d = (int)(TypedValue.applyDimension(1, 320.0F, paramContext.getResources().getDisplayMetrics()) + 0.5F); 
        return;
      } 
      throw new IllegalArgumentException("tag must not be null or empty");
    } 
    throw new IllegalArgumentException("context must not be null");
  }
  
  public static void a(Bundle paramBundle) {
    if (paramBundle != null)
      paramBundle.setClassLoader(MediaSessionCompat.class.getClassLoader()); 
  }
  
  static PlaybackStateCompat d(PlaybackStateCompat paramPlaybackStateCompat, MediaMetadataCompat paramMediaMetadataCompat) {
    // Byte code:
    //   0: aload_0
    //   1: astore #10
    //   3: aload_0
    //   4: ifnull -> 175
    //   7: aload_0
    //   8: invokevirtual i : ()J
    //   11: lstore_2
    //   12: ldc2_w -1
    //   15: lstore #4
    //   17: lload_2
    //   18: ldc2_w -1
    //   21: lcmp
    //   22: ifne -> 27
    //   25: aload_0
    //   26: areturn
    //   27: aload_0
    //   28: invokevirtual n : ()I
    //   31: iconst_3
    //   32: if_icmpeq -> 54
    //   35: aload_0
    //   36: invokevirtual n : ()I
    //   39: iconst_4
    //   40: if_icmpeq -> 54
    //   43: aload_0
    //   44: astore #10
    //   46: aload_0
    //   47: invokevirtual n : ()I
    //   50: iconst_5
    //   51: if_icmpne -> 175
    //   54: aload_0
    //   55: invokevirtual f : ()J
    //   58: lstore_2
    //   59: aload_0
    //   60: astore #10
    //   62: lload_2
    //   63: lconst_0
    //   64: lcmp
    //   65: ifle -> 175
    //   68: invokestatic elapsedRealtime : ()J
    //   71: lstore #8
    //   73: aload_0
    //   74: invokevirtual g : ()F
    //   77: lload #8
    //   79: lload_2
    //   80: lsub
    //   81: l2f
    //   82: fmul
    //   83: f2l
    //   84: aload_0
    //   85: invokevirtual i : ()J
    //   88: ladd
    //   89: lstore #6
    //   91: lload #4
    //   93: lstore_2
    //   94: aload_1
    //   95: ifnull -> 117
    //   98: lload #4
    //   100: lstore_2
    //   101: aload_1
    //   102: ldc 'android.media.metadata.DURATION'
    //   104: invokevirtual a : (Ljava/lang/String;)Z
    //   107: ifeq -> 117
    //   110: aload_1
    //   111: ldc 'android.media.metadata.DURATION'
    //   113: invokevirtual f : (Ljava/lang/String;)J
    //   116: lstore_2
    //   117: lload_2
    //   118: lconst_0
    //   119: lcmp
    //   120: iflt -> 133
    //   123: lload #6
    //   125: lload_2
    //   126: lcmp
    //   127: ifle -> 133
    //   130: goto -> 148
    //   133: lload #6
    //   135: lconst_0
    //   136: lcmp
    //   137: ifge -> 145
    //   140: lconst_0
    //   141: lstore_2
    //   142: goto -> 148
    //   145: lload #6
    //   147: lstore_2
    //   148: new android/support/v4/media/session/PlaybackStateCompat$d
    //   151: dup
    //   152: aload_0
    //   153: invokespecial <init> : (Landroid/support/v4/media/session/PlaybackStateCompat;)V
    //   156: aload_0
    //   157: invokevirtual n : ()I
    //   160: lload_2
    //   161: aload_0
    //   162: invokevirtual g : ()F
    //   165: lload #8
    //   167: invokevirtual h : (IJFJ)Landroid/support/v4/media/session/PlaybackStateCompat$d;
    //   170: invokevirtual b : ()Landroid/support/v4/media/session/PlaybackStateCompat;
    //   173: astore #10
    //   175: aload #10
    //   177: areturn
  }
  
  public static Bundle m(Bundle paramBundle) {
    if (paramBundle == null)
      return null; 
    a(paramBundle);
    try {
      paramBundle.isEmpty();
      return paramBundle;
    } catch (BadParcelableException badParcelableException) {
      Log.e("MediaSessionCompat", "Could not unparcel the data.");
      return null;
    } 
  }
  
  public MediaControllerCompat b() {
    return this.b;
  }
  
  public Token c() {
    return this.a.h();
  }
  
  public void e() {
    this.a.release();
  }
  
  public void f(boolean paramBoolean) {
    this.a.m(paramBoolean);
    Iterator<h> iterator = this.c.iterator();
    while (iterator.hasNext())
      ((h)iterator.next()).a(); 
  }
  
  public void g(b paramb, Handler paramHandler) {
    if (paramb == null) {
      this.a.b(null, null);
      return;
    } 
    c c1 = this.a;
    if (paramHandler == null)
      paramHandler = new Handler(); 
    c1.b(paramb, paramHandler);
  }
  
  public void h(int paramInt) {
    this.a.a(paramInt);
  }
  
  public void i(MediaMetadataCompat paramMediaMetadataCompat) {
    this.a.d(paramMediaMetadataCompat);
  }
  
  public void j(PlaybackStateCompat paramPlaybackStateCompat) {
    this.a.f(paramPlaybackStateCompat);
  }
  
  public void k(int paramInt) {
    this.a.g(paramInt);
  }
  
  public void l(int paramInt) {
    this.a.i(paramInt);
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static final class QueueItem implements Parcelable {
    public static final Parcelable.Creator<QueueItem> CREATOR = new a();
    
    private final MediaDescriptionCompat s0;
    
    private final long t0;
    
    private MediaSession.QueueItem u0;
    
    private QueueItem(MediaSession.QueueItem param1QueueItem, MediaDescriptionCompat param1MediaDescriptionCompat, long param1Long) {
      if (param1MediaDescriptionCompat != null) {
        if (param1Long != -1L) {
          this.s0 = param1MediaDescriptionCompat;
          this.t0 = param1Long;
          this.u0 = param1QueueItem;
          return;
        } 
        throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
      } 
      throw new IllegalArgumentException("Description cannot be null");
    }
    
    QueueItem(Parcel param1Parcel) {
      this.s0 = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
      this.t0 = param1Parcel.readLong();
    }
    
    public static QueueItem a(Object param1Object) {
      if (param1Object != null) {
        param1Object = param1Object;
        return new QueueItem((MediaSession.QueueItem)param1Object, MediaDescriptionCompat.a(b.b((MediaSession.QueueItem)param1Object)), b.c((MediaSession.QueueItem)param1Object));
      } 
      return null;
    }
    
    public static List<QueueItem> b(List<?> param1List) {
      if (param1List != null) {
        ArrayList<QueueItem> arrayList = new ArrayList(param1List.size());
        Iterator<?> iterator = param1List.iterator();
        while (iterator.hasNext())
          arrayList.add(a(iterator.next())); 
        return arrayList;
      } 
      return null;
    }
    
    public MediaDescriptionCompat c() {
      return this.s0;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public long f() {
      return this.t0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("MediaSession.QueueItem {Description=");
      stringBuilder.append(this.s0);
      stringBuilder.append(", Id=");
      stringBuilder.append(this.t0);
      stringBuilder.append(" }");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.s0.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeLong(this.t0);
    }
    
    class a implements Parcelable.Creator<QueueItem> {
      public MediaSessionCompat.QueueItem a(Parcel param2Parcel) {
        return new MediaSessionCompat.QueueItem(param2Parcel);
      }
      
      public MediaSessionCompat.QueueItem[] b(int param2Int) {
        return new MediaSessionCompat.QueueItem[param2Int];
      }
    }
    
    private static class b {
      static MediaSession.QueueItem a(MediaDescription param2MediaDescription, long param2Long) {
        return new MediaSession.QueueItem(param2MediaDescription, param2Long);
      }
      
      static MediaDescription b(MediaSession.QueueItem param2QueueItem) {
        return param2QueueItem.getDescription();
      }
      
      static long c(MediaSession.QueueItem param2QueueItem) {
        return param2QueueItem.getQueueId();
      }
    }
  }
  
  class a implements Parcelable.Creator<QueueItem> {
    public MediaSessionCompat.QueueItem a(Parcel param1Parcel) {
      return new MediaSessionCompat.QueueItem(param1Parcel);
    }
    
    public MediaSessionCompat.QueueItem[] b(int param1Int) {
      return new MediaSessionCompat.QueueItem[param1Int];
    }
  }
  
  private static class b {
    static MediaSession.QueueItem a(MediaDescription param1MediaDescription, long param1Long) {
      return new MediaSession.QueueItem(param1MediaDescription, param1Long);
    }
    
    static MediaDescription b(MediaSession.QueueItem param1QueueItem) {
      return param1QueueItem.getDescription();
    }
    
    static long c(MediaSession.QueueItem param1QueueItem) {
      return param1QueueItem.getQueueId();
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  static final class ResultReceiverWrapper implements Parcelable {
    public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new a();
    
    ResultReceiver s0;
    
    ResultReceiverWrapper(Parcel param1Parcel) {
      this.s0 = (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(param1Parcel);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.s0.writeToParcel(param1Parcel, param1Int);
    }
    
    class a implements Parcelable.Creator<ResultReceiverWrapper> {
      public MediaSessionCompat.ResultReceiverWrapper a(Parcel param2Parcel) {
        return new MediaSessionCompat.ResultReceiverWrapper(param2Parcel);
      }
      
      public MediaSessionCompat.ResultReceiverWrapper[] b(int param2Int) {
        return new MediaSessionCompat.ResultReceiverWrapper[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<ResultReceiverWrapper> {
    public MediaSessionCompat.ResultReceiverWrapper a(Parcel param1Parcel) {
      return new MediaSessionCompat.ResultReceiverWrapper(param1Parcel);
    }
    
    public MediaSessionCompat.ResultReceiverWrapper[] b(int param1Int) {
      return new MediaSessionCompat.ResultReceiverWrapper[param1Int];
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static final class Token implements Parcelable {
    public static final Parcelable.Creator<Token> CREATOR = new a();
    
    private final Object s0 = new Object();
    
    private final Object t0;
    
    private b u0;
    
    private l4.b v0;
    
    Token(Object param1Object) {
      this(param1Object, null, null);
    }
    
    Token(Object param1Object, b param1b, l4.b param1b1) {
      this.t0 = param1Object;
      this.u0 = param1b;
      this.v0 = param1b1;
    }
    
    public b a() {
      synchronized (this.s0) {
        return this.u0;
      } 
    }
    
    public l4.b b() {
      synchronized (this.s0) {
        return this.v0;
      } 
    }
    
    public Object c() {
      return this.t0;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Token))
        return false; 
      Token token = (Token)param1Object;
      param1Object = this.t0;
      if (param1Object == null)
        return (token.t0 == null); 
      Object object = token.t0;
      return (object == null) ? false : param1Object.equals(object);
    }
    
    public void f(b param1b) {
      synchronized (this.s0) {
        this.u0 = param1b;
        return;
      } 
    }
    
    public void g(l4.b param1b) {
      synchronized (this.s0) {
        this.v0 = param1b;
        return;
      } 
    }
    
    public int hashCode() {
      Object object = this.t0;
      return (object == null) ? 0 : object.hashCode();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeParcelable((Parcelable)this.t0, param1Int);
    }
    
    class a implements Parcelable.Creator<Token> {
      public MediaSessionCompat.Token a(Parcel param2Parcel) {
        return new MediaSessionCompat.Token(param2Parcel.readParcelable(null));
      }
      
      public MediaSessionCompat.Token[] b(int param2Int) {
        return new MediaSessionCompat.Token[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<Token> {
    public MediaSessionCompat.Token a(Parcel param1Parcel) {
      return new MediaSessionCompat.Token(param1Parcel.readParcelable(null));
    }
    
    public MediaSessionCompat.Token[] b(int param1Int) {
      return new MediaSessionCompat.Token[param1Int];
    }
  }
  
  class a extends b {
    a(MediaSessionCompat this$0) {}
  }
  
  public static abstract class b {
    final Object s0 = new Object();
    
    final MediaSession.Callback t0 = new b(this);
    
    private boolean u0;
    
    WeakReference<MediaSessionCompat.c> v0 = new WeakReference<MediaSessionCompat.c>(null);
    
    a w0;
    
    public boolean A(Intent param1Intent) {
      if (Build.VERSION.SDK_INT >= 27)
        return false; 
      synchronized (this.s0) {
        MediaSessionCompat.c c = this.v0.get();
        a a1 = this.w0;
        if (c != null) {
          if (a1 == null)
            return false; 
          KeyEvent keyEvent = (KeyEvent)param1Intent.getParcelableExtra("android.intent.extra.KEY_EVENT");
          if (keyEvent != null) {
            if (keyEvent.getAction() != 0)
              return false; 
            null = c.n();
            int i = keyEvent.getKeyCode();
            if (i != 79 && i != 85) {
              s(c, a1);
              return false;
            } 
            if (keyEvent.getRepeatCount() == 0) {
              if (this.u0) {
                long l;
                a1.removeMessages(1);
                this.u0 = false;
                PlaybackStateCompat playbackStateCompat = c.c();
                if (playbackStateCompat == null) {
                  l = 0L;
                } else {
                  l = playbackStateCompat.b();
                } 
                if ((l & 0x20L) != 0L) {
                  V();
                  return true;
                } 
              } else {
                this.u0 = true;
                a1.sendMessageDelayed(a1.obtainMessage(1, null), ViewConfiguration.getDoubleTapTimeout());
                return true;
              } 
            } else {
              s(c, a1);
            } 
            return true;
          } 
        } 
        return false;
      } 
    }
    
    public void B() {}
    
    public void C() {}
    
    public void F(String param1String, Bundle param1Bundle) {}
    
    public void G(String param1String, Bundle param1Bundle) {}
    
    public void H(Uri param1Uri, Bundle param1Bundle) {}
    
    public void I() {}
    
    public void J(String param1String, Bundle param1Bundle) {}
    
    public void K(String param1String, Bundle param1Bundle) {}
    
    public void L(Uri param1Uri, Bundle param1Bundle) {}
    
    public void M(MediaDescriptionCompat param1MediaDescriptionCompat) {}
    
    public void N() {}
    
    public void O(long param1Long) {}
    
    public void P(boolean param1Boolean) {}
    
    public void Q(float param1Float) {}
    
    public void R(RatingCompat param1RatingCompat) {}
    
    public void S(RatingCompat param1RatingCompat, Bundle param1Bundle) {}
    
    public void T(int param1Int) {}
    
    public void U(int param1Int) {}
    
    public void V() {}
    
    public void W() {}
    
    public void X(long param1Long) {}
    
    public void Y() {}
    
    void Z(MediaSessionCompat.c param1c, Handler param1Handler) {
      a a2;
      synchronized (this.s0) {
        this.v0 = new WeakReference<MediaSessionCompat.c>(param1c);
        a a3 = this.w0;
        a2 = null;
        if (a3 != null)
          a3.removeCallbacksAndMessages(null); 
      } 
      a a1 = a2;
      if (param1c != null)
        if (param1Handler == null) {
          a1 = a2;
        } else {
          a1 = new a(this, param1Handler.getLooper());
        }  
      this.w0 = a1;
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_5} */
    }
    
    void s(MediaSessionCompat.c param1c, Handler param1Handler) {
      boolean bool1;
      boolean bool2;
      long l;
      if (!this.u0)
        return; 
      boolean bool3 = false;
      this.u0 = false;
      param1Handler.removeMessages(1);
      PlaybackStateCompat playbackStateCompat = param1c.c();
      if (playbackStateCompat == null) {
        l = 0L;
      } else {
        l = playbackStateCompat.b();
      } 
      if (playbackStateCompat != null && playbackStateCompat.n() == 3) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((0x204L & l) != 0L) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if ((l & 0x202L) != 0L)
        bool3 = true; 
      if (bool1 && bool3) {
        B();
        return;
      } 
      if (!bool1 && bool2)
        C(); 
    }
    
    public void t(MediaDescriptionCompat param1MediaDescriptionCompat) {}
    
    public void u(MediaDescriptionCompat param1MediaDescriptionCompat, int param1Int) {}
    
    public void v(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {}
    
    public void x(String param1String, Bundle param1Bundle) {}
    
    public void z() {}
    
    private class a extends Handler {
      a(MediaSessionCompat.b this$0, Looper param2Looper) {
        super(param2Looper);
      }
      
      public void handleMessage(Message param2Message) {
        if (param2Message.what == 1)
          synchronized (this.a.s0) {
            MediaSessionCompat.c c = this.a.v0.get();
            MediaSessionCompat.b b1 = this.a;
            a a1 = b1.w0;
            if (c != null && b1 == c.k()) {
              if (a1 == null)
                return; 
              c.e((u3.a)param2Message.obj);
              this.a.s(c, a1);
              c.e(null);
              return;
            } 
            return;
          }  
      }
    }
    
    private class b extends MediaSession.Callback {
      b(MediaSessionCompat.b this$0) {}
      
      private void a(MediaSessionCompat.c param2c) {
        param2c.e(null);
      }
      
      private MediaSessionCompat.d b() {
        synchronized (this.a.s0) {
          MediaSessionCompat.d d = (MediaSessionCompat.d)this.a.v0.get();
          return (d != null && this.a == d.k()) ? d : null;
        } 
      }
      
      private void c(MediaSessionCompat.c param2c) {
        if (Build.VERSION.SDK_INT >= 28)
          return; 
        String str2 = param2c.j();
        String str1 = str2;
        if (TextUtils.isEmpty(str2))
          str1 = "android.media.session.MediaController"; 
        param2c.e(new u3.a(str1, -1, -1));
      }
      
      public void onCommand(String param2String, Bundle param2Bundle, ResultReceiver param2ResultReceiver) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        MediaSessionCompat.a(param2Bundle);
        c(d);
        try {
          IBinder iBinder;
          boolean bool = param2String.equals("android.support.v4.media.session.command.GET_EXTRA_BINDER");
          MediaSessionCompat.Token token = null;
          b b1 = null;
          if (bool) {
            param2Bundle = new Bundle();
            token = d.h();
            b b2 = token.a();
            if (b2 == null) {
              b2 = b1;
            } else {
              iBinder = b2.asBinder();
            } 
            androidx.core.app.g.b(param2Bundle, "android.support.v4.media.session.EXTRA_BINDER", iBinder);
            l4.a.c(param2Bundle, "android.support.v4.media.session.SESSION_TOKEN2", token.b());
            param2ResultReceiver.send(0, param2Bundle);
          } else {
            bool = iBinder.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM");
            if (bool) {
              this.a.t((MediaDescriptionCompat)param2Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
            } else {
              bool = iBinder.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM_AT");
              if (bool) {
                this.a.u((MediaDescriptionCompat)param2Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"), param2Bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX"));
              } else if (iBinder.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM")) {
                this.a.M((MediaDescriptionCompat)param2Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
              } else {
                MediaSessionCompat.QueueItem queueItem;
                if (iBinder.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM_AT")) {
                  if (d.h != null) {
                    int i = param2Bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX", -1);
                    MediaSessionCompat.Token token1 = token;
                    if (i >= 0) {
                      token1 = token;
                      if (i < d.h.size())
                        queueItem = d.h.get(i); 
                    } 
                    if (queueItem != null)
                      this.a.M(queueItem.c()); 
                  } 
                } else {
                  this.a.v((String)queueItem, param2Bundle, param2ResultReceiver);
                } 
              } 
            } 
          } 
        } catch (BadParcelableException badParcelableException) {
          Log.e("MediaSessionCompat", "Could not unparcel the extra data.");
        } 
        a(d);
      }
      
      public void onCustomAction(String param2String, Bundle param2Bundle) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        MediaSessionCompat.a(param2Bundle);
        c(d);
        try {
          Uri uri;
          boolean bool = param2String.equals("android.support.v4.media.session.action.PLAY_FROM_URI");
          if (bool) {
            uri = (Uri)param2Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
            param2Bundle = param2Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
            MediaSessionCompat.a(param2Bundle);
            this.a.H(uri, param2Bundle);
          } else if (uri.equals("android.support.v4.media.session.action.PREPARE")) {
            this.a.I();
          } else {
            String str;
            if (uri.equals("android.support.v4.media.session.action.PREPARE_FROM_MEDIA_ID")) {
              str = param2Bundle.getString("android.support.v4.media.session.action.ARGUMENT_MEDIA_ID");
              param2Bundle = param2Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
              MediaSessionCompat.a(param2Bundle);
              this.a.J(str, param2Bundle);
            } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_SEARCH")) {
              str = param2Bundle.getString("android.support.v4.media.session.action.ARGUMENT_QUERY");
              param2Bundle = param2Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
              MediaSessionCompat.a(param2Bundle);
              this.a.K(str, param2Bundle);
            } else {
              Uri uri1;
              if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_URI")) {
                uri1 = (Uri)param2Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
                param2Bundle = param2Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
                MediaSessionCompat.a(param2Bundle);
                this.a.L(uri1, param2Bundle);
              } else if (uri1.equals("android.support.v4.media.session.action.SET_CAPTIONING_ENABLED")) {
                bool = param2Bundle.getBoolean("android.support.v4.media.session.action.ARGUMENT_CAPTIONING_ENABLED");
                this.a.P(bool);
              } else if (uri1.equals("android.support.v4.media.session.action.SET_REPEAT_MODE")) {
                int i = param2Bundle.getInt("android.support.v4.media.session.action.ARGUMENT_REPEAT_MODE");
                this.a.T(i);
              } else if (uri1.equals("android.support.v4.media.session.action.SET_SHUFFLE_MODE")) {
                int i = param2Bundle.getInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE");
                this.a.U(i);
              } else {
                RatingCompat ratingCompat;
                if (uri1.equals("android.support.v4.media.session.action.SET_RATING")) {
                  ratingCompat = (RatingCompat)param2Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_RATING");
                  param2Bundle = param2Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
                  MediaSessionCompat.a(param2Bundle);
                  this.a.S(ratingCompat, param2Bundle);
                } else if (ratingCompat.equals("android.support.v4.media.session.action.SET_PLAYBACK_SPEED")) {
                  float f = param2Bundle.getFloat("android.support.v4.media.session.action.ARGUMENT_PLAYBACK_SPEED", 1.0F);
                  this.a.Q(f);
                } else {
                  this.a.x((String)ratingCompat, param2Bundle);
                } 
              } 
            } 
          } 
        } catch (BadParcelableException badParcelableException) {
          Log.e("MediaSessionCompat", "Could not unparcel the data.");
        } 
        a(d);
      }
      
      public void onFastForward() {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.z();
        a(d);
      }
      
      public boolean onMediaButtonEvent(Intent param2Intent) {
        MediaSessionCompat.d d = b();
        boolean bool = false;
        if (d == null)
          return false; 
        c(d);
        boolean bool1 = this.a.A(param2Intent);
        a(d);
        if (bool1 || super.onMediaButtonEvent(param2Intent))
          bool = true; 
        return bool;
      }
      
      public void onPause() {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.B();
        a(d);
      }
      
      public void onPlay() {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.C();
        a(d);
      }
      
      public void onPlayFromMediaId(String param2String, Bundle param2Bundle) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        MediaSessionCompat.a(param2Bundle);
        c(d);
        this.a.F(param2String, param2Bundle);
        a(d);
      }
      
      public void onPlayFromSearch(String param2String, Bundle param2Bundle) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        MediaSessionCompat.a(param2Bundle);
        c(d);
        this.a.G(param2String, param2Bundle);
        a(d);
      }
      
      public void onPlayFromUri(Uri param2Uri, Bundle param2Bundle) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        MediaSessionCompat.a(param2Bundle);
        c(d);
        this.a.H(param2Uri, param2Bundle);
        a(d);
      }
      
      public void onPrepare() {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.I();
        a(d);
      }
      
      public void onPrepareFromMediaId(String param2String, Bundle param2Bundle) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        MediaSessionCompat.a(param2Bundle);
        c(d);
        this.a.J(param2String, param2Bundle);
        a(d);
      }
      
      public void onPrepareFromSearch(String param2String, Bundle param2Bundle) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        MediaSessionCompat.a(param2Bundle);
        c(d);
        this.a.K(param2String, param2Bundle);
        a(d);
      }
      
      public void onPrepareFromUri(Uri param2Uri, Bundle param2Bundle) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        MediaSessionCompat.a(param2Bundle);
        c(d);
        this.a.L(param2Uri, param2Bundle);
        a(d);
      }
      
      public void onRewind() {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.N();
        a(d);
      }
      
      public void onSeekTo(long param2Long) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.O(param2Long);
        a(d);
      }
      
      public void onSetPlaybackSpeed(float param2Float) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.Q(param2Float);
        a(d);
      }
      
      public void onSetRating(Rating param2Rating) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.R(RatingCompat.a(param2Rating));
        a(d);
      }
      
      public void onSkipToNext() {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.V();
        a(d);
      }
      
      public void onSkipToPrevious() {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.W();
        a(d);
      }
      
      public void onSkipToQueueItem(long param2Long) {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.X(param2Long);
        a(d);
      }
      
      public void onStop() {
        MediaSessionCompat.d d = b();
        if (d == null)
          return; 
        c(d);
        this.a.Y();
        a(d);
      }
    }
  }
  
  private class a extends Handler {
    a(MediaSessionCompat this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      if (param1Message.what == 1)
        synchronized (this.a.s0) {
          MediaSessionCompat.c c = this.a.v0.get();
          MediaSessionCompat.b b1 = this.a;
          a a1 = b1.w0;
          if (c != null && b1 == c.k()) {
            if (a1 == null)
              return; 
            c.e((u3.a)param1Message.obj);
            this.a.s(c, a1);
            c.e(null);
            return;
          } 
          return;
        }  
    }
  }
  
  private class b extends MediaSession.Callback {
    b(MediaSessionCompat this$0) {}
    
    private void a(MediaSessionCompat.c param1c) {
      param1c.e(null);
    }
    
    private MediaSessionCompat.d b() {
      synchronized (this.a.s0) {
        MediaSessionCompat.d d = (MediaSessionCompat.d)this.a.v0.get();
        return (d != null && this.a == d.k()) ? d : null;
      } 
    }
    
    private void c(MediaSessionCompat.c param1c) {
      if (Build.VERSION.SDK_INT >= 28)
        return; 
      String str2 = param1c.j();
      String str1 = str2;
      if (TextUtils.isEmpty(str2))
        str1 = "android.media.session.MediaController"; 
      param1c.e(new u3.a(str1, -1, -1));
    }
    
    public void onCommand(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      MediaSessionCompat.a(param1Bundle);
      c(d);
      try {
        IBinder iBinder;
        boolean bool = param1String.equals("android.support.v4.media.session.command.GET_EXTRA_BINDER");
        MediaSessionCompat.Token token = null;
        b b1 = null;
        if (bool) {
          param1Bundle = new Bundle();
          token = d.h();
          b b2 = token.a();
          if (b2 == null) {
            b2 = b1;
          } else {
            iBinder = b2.asBinder();
          } 
          androidx.core.app.g.b(param1Bundle, "android.support.v4.media.session.EXTRA_BINDER", iBinder);
          l4.a.c(param1Bundle, "android.support.v4.media.session.SESSION_TOKEN2", token.b());
          param1ResultReceiver.send(0, param1Bundle);
        } else {
          bool = iBinder.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM");
          if (bool) {
            this.a.t((MediaDescriptionCompat)param1Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
          } else {
            bool = iBinder.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM_AT");
            if (bool) {
              this.a.u((MediaDescriptionCompat)param1Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"), param1Bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX"));
            } else if (iBinder.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM")) {
              this.a.M((MediaDescriptionCompat)param1Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
            } else {
              MediaSessionCompat.QueueItem queueItem;
              if (iBinder.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM_AT")) {
                if (d.h != null) {
                  int i = param1Bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX", -1);
                  MediaSessionCompat.Token token1 = token;
                  if (i >= 0) {
                    token1 = token;
                    if (i < d.h.size())
                      queueItem = d.h.get(i); 
                  } 
                  if (queueItem != null)
                    this.a.M(queueItem.c()); 
                } 
              } else {
                this.a.v((String)queueItem, param1Bundle, param1ResultReceiver);
              } 
            } 
          } 
        } 
      } catch (BadParcelableException badParcelableException) {
        Log.e("MediaSessionCompat", "Could not unparcel the extra data.");
      } 
      a(d);
    }
    
    public void onCustomAction(String param1String, Bundle param1Bundle) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      MediaSessionCompat.a(param1Bundle);
      c(d);
      try {
        Uri uri;
        boolean bool = param1String.equals("android.support.v4.media.session.action.PLAY_FROM_URI");
        if (bool) {
          uri = (Uri)param1Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
          param1Bundle = param1Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
          MediaSessionCompat.a(param1Bundle);
          this.a.H(uri, param1Bundle);
        } else if (uri.equals("android.support.v4.media.session.action.PREPARE")) {
          this.a.I();
        } else {
          String str;
          if (uri.equals("android.support.v4.media.session.action.PREPARE_FROM_MEDIA_ID")) {
            str = param1Bundle.getString("android.support.v4.media.session.action.ARGUMENT_MEDIA_ID");
            param1Bundle = param1Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
            MediaSessionCompat.a(param1Bundle);
            this.a.J(str, param1Bundle);
          } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_SEARCH")) {
            str = param1Bundle.getString("android.support.v4.media.session.action.ARGUMENT_QUERY");
            param1Bundle = param1Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
            MediaSessionCompat.a(param1Bundle);
            this.a.K(str, param1Bundle);
          } else {
            Uri uri1;
            if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_URI")) {
              uri1 = (Uri)param1Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
              param1Bundle = param1Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
              MediaSessionCompat.a(param1Bundle);
              this.a.L(uri1, param1Bundle);
            } else if (uri1.equals("android.support.v4.media.session.action.SET_CAPTIONING_ENABLED")) {
              bool = param1Bundle.getBoolean("android.support.v4.media.session.action.ARGUMENT_CAPTIONING_ENABLED");
              this.a.P(bool);
            } else if (uri1.equals("android.support.v4.media.session.action.SET_REPEAT_MODE")) {
              int i = param1Bundle.getInt("android.support.v4.media.session.action.ARGUMENT_REPEAT_MODE");
              this.a.T(i);
            } else if (uri1.equals("android.support.v4.media.session.action.SET_SHUFFLE_MODE")) {
              int i = param1Bundle.getInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE");
              this.a.U(i);
            } else {
              RatingCompat ratingCompat;
              if (uri1.equals("android.support.v4.media.session.action.SET_RATING")) {
                ratingCompat = (RatingCompat)param1Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_RATING");
                param1Bundle = param1Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
                MediaSessionCompat.a(param1Bundle);
                this.a.S(ratingCompat, param1Bundle);
              } else if (ratingCompat.equals("android.support.v4.media.session.action.SET_PLAYBACK_SPEED")) {
                float f = param1Bundle.getFloat("android.support.v4.media.session.action.ARGUMENT_PLAYBACK_SPEED", 1.0F);
                this.a.Q(f);
              } else {
                this.a.x((String)ratingCompat, param1Bundle);
              } 
            } 
          } 
        } 
      } catch (BadParcelableException badParcelableException) {
        Log.e("MediaSessionCompat", "Could not unparcel the data.");
      } 
      a(d);
    }
    
    public void onFastForward() {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.z();
      a(d);
    }
    
    public boolean onMediaButtonEvent(Intent param1Intent) {
      MediaSessionCompat.d d = b();
      boolean bool = false;
      if (d == null)
        return false; 
      c(d);
      boolean bool1 = this.a.A(param1Intent);
      a(d);
      if (bool1 || super.onMediaButtonEvent(param1Intent))
        bool = true; 
      return bool;
    }
    
    public void onPause() {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.B();
      a(d);
    }
    
    public void onPlay() {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.C();
      a(d);
    }
    
    public void onPlayFromMediaId(String param1String, Bundle param1Bundle) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      MediaSessionCompat.a(param1Bundle);
      c(d);
      this.a.F(param1String, param1Bundle);
      a(d);
    }
    
    public void onPlayFromSearch(String param1String, Bundle param1Bundle) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      MediaSessionCompat.a(param1Bundle);
      c(d);
      this.a.G(param1String, param1Bundle);
      a(d);
    }
    
    public void onPlayFromUri(Uri param1Uri, Bundle param1Bundle) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      MediaSessionCompat.a(param1Bundle);
      c(d);
      this.a.H(param1Uri, param1Bundle);
      a(d);
    }
    
    public void onPrepare() {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.I();
      a(d);
    }
    
    public void onPrepareFromMediaId(String param1String, Bundle param1Bundle) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      MediaSessionCompat.a(param1Bundle);
      c(d);
      this.a.J(param1String, param1Bundle);
      a(d);
    }
    
    public void onPrepareFromSearch(String param1String, Bundle param1Bundle) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      MediaSessionCompat.a(param1Bundle);
      c(d);
      this.a.K(param1String, param1Bundle);
      a(d);
    }
    
    public void onPrepareFromUri(Uri param1Uri, Bundle param1Bundle) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      MediaSessionCompat.a(param1Bundle);
      c(d);
      this.a.L(param1Uri, param1Bundle);
      a(d);
    }
    
    public void onRewind() {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.N();
      a(d);
    }
    
    public void onSeekTo(long param1Long) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.O(param1Long);
      a(d);
    }
    
    public void onSetPlaybackSpeed(float param1Float) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.Q(param1Float);
      a(d);
    }
    
    public void onSetRating(Rating param1Rating) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.R(RatingCompat.a(param1Rating));
      a(d);
    }
    
    public void onSkipToNext() {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.V();
      a(d);
    }
    
    public void onSkipToPrevious() {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.W();
      a(d);
    }
    
    public void onSkipToQueueItem(long param1Long) {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.X(param1Long);
      a(d);
    }
    
    public void onStop() {
      MediaSessionCompat.d d = b();
      if (d == null)
        return; 
      c(d);
      this.a.Y();
      a(d);
    }
  }
  
  static interface c {
    void a(int param1Int);
    
    void b(MediaSessionCompat.b param1b, Handler param1Handler);
    
    PlaybackStateCompat c();
    
    void d(MediaMetadataCompat param1MediaMetadataCompat);
    
    void e(u3.a param1a);
    
    void f(PlaybackStateCompat param1PlaybackStateCompat);
    
    void g(int param1Int);
    
    MediaSessionCompat.Token h();
    
    void i(int param1Int);
    
    String j();
    
    MediaSessionCompat.b k();
    
    void l(PendingIntent param1PendingIntent);
    
    void m(boolean param1Boolean);
    
    u3.a n();
    
    void release();
  }
  
  static class d implements c {
    final MediaSession a;
    
    final MediaSessionCompat.Token b;
    
    final Object c = new Object();
    
    Bundle d;
    
    boolean e = false;
    
    final RemoteCallbackList<a> f = new RemoteCallbackList();
    
    PlaybackStateCompat g;
    
    List<MediaSessionCompat.QueueItem> h;
    
    MediaMetadataCompat i;
    
    int j;
    
    boolean k;
    
    int l;
    
    int m;
    
    MediaSessionCompat.b n;
    
    u3.a o;
    
    d(Context param1Context, String param1String, l4.b param1b, Bundle param1Bundle) {
      MediaSession mediaSession = o(param1Context, param1String, param1Bundle);
      this.a = mediaSession;
      this.b = new MediaSessionCompat.Token(mediaSession.getSessionToken(), new a(this), param1b);
      this.d = param1Bundle;
      a(3);
    }
    
    @SuppressLint({"WrongConstant"})
    public void a(int param1Int) {
      this.a.setFlags(param1Int | 0x1 | 0x2);
    }
    
    public void b(MediaSessionCompat.b param1b, Handler param1Handler) {
      synchronized (this.c) {
        MediaSession.Callback callback;
        this.n = param1b;
        MediaSession mediaSession = this.a;
        if (param1b == null) {
          callback = null;
        } else {
          callback = param1b.t0;
        } 
        mediaSession.setCallback(callback, param1Handler);
        if (param1b != null)
          param1b.Z(this, param1Handler); 
        return;
      } 
    }
    
    public PlaybackStateCompat c() {
      return this.g;
    }
    
    public void d(MediaMetadataCompat param1MediaMetadataCompat) {
      MediaMetadata mediaMetadata;
      this.i = param1MediaMetadataCompat;
      MediaSession mediaSession = this.a;
      if (param1MediaMetadataCompat == null) {
        param1MediaMetadataCompat = null;
      } else {
        mediaMetadata = (MediaMetadata)param1MediaMetadataCompat.g();
      } 
      mediaSession.setMetadata(mediaMetadata);
    }
    
    public void e(u3.a param1a) {
      synchronized (this.c) {
        this.o = param1a;
        return;
      } 
    }
    
    public void f(PlaybackStateCompat param1PlaybackStateCompat) {
      this.g = param1PlaybackStateCompat;
      synchronized (this.c) {
        int i = this.f.beginBroadcast() - 1;
        while (true) {
          PlaybackState playbackState;
          if (i >= 0) {
            a a1 = (a)this.f.getBroadcastItem(i);
            try {
              a1.h1(param1PlaybackStateCompat);
            } catch (RemoteException remoteException) {}
            i--;
            continue;
          } 
          this.f.finishBroadcast();
          null = this.a;
          if (param1PlaybackStateCompat == null) {
            param1PlaybackStateCompat = null;
          } else {
            playbackState = (PlaybackState)param1PlaybackStateCompat.h();
          } 
          null.setPlaybackState(playbackState);
          return;
        } 
      } 
    }
    
    public void g(int param1Int) {
      if (this.l != param1Int) {
        this.l = param1Int;
        synchronized (this.c) {
          int i = this.f.beginBroadcast() - 1;
          while (true) {
            if (i >= 0) {
              a a1 = (a)this.f.getBroadcastItem(i);
              try {
                a1.onRepeatModeChanged(param1Int);
              } catch (RemoteException remoteException) {}
              i--;
              continue;
            } 
            this.f.finishBroadcast();
            return;
          } 
        } 
      } 
    }
    
    public MediaSessionCompat.Token h() {
      return this.b;
    }
    
    public void i(int param1Int) {
      if (this.m != param1Int) {
        this.m = param1Int;
        synchronized (this.c) {
          int i = this.f.beginBroadcast() - 1;
          while (true) {
            if (i >= 0) {
              a a1 = (a)this.f.getBroadcastItem(i);
              try {
                a1.f0(param1Int);
              } catch (RemoteException remoteException) {}
              i--;
              continue;
            } 
            this.f.finishBroadcast();
            return;
          } 
        } 
      } 
    }
    
    public String j() {
      if (Build.VERSION.SDK_INT < 24)
        return null; 
      try {
        return (String)this.a.getClass().getMethod("getCallingPackage", new Class[0]).invoke(this.a, new Object[0]);
      } catch (Exception exception) {
        Log.e("MediaSessionCompat", "Cannot execute MediaSession.getCallingPackage()", exception);
        return null;
      } 
    }
    
    public MediaSessionCompat.b k() {
      synchronized (this.c) {
        return this.n;
      } 
    }
    
    public void l(PendingIntent param1PendingIntent) {
      this.a.setMediaButtonReceiver(param1PendingIntent);
    }
    
    public void m(boolean param1Boolean) {
      this.a.setActive(param1Boolean);
    }
    
    public u3.a n() {
      synchronized (this.c) {
        return this.o;
      } 
    }
    
    public MediaSession o(Context param1Context, String param1String, Bundle param1Bundle) {
      return new MediaSession(param1Context, param1String);
    }
    
    public void release() {
      this.e = true;
      this.f.kill();
      if (Build.VERSION.SDK_INT == 27)
        try {
          Field field = this.a.getClass().getDeclaredField("mCallback");
          field.setAccessible(true);
          Handler handler = (Handler)field.get(this.a);
          if (handler != null)
            handler.removeCallbacksAndMessages(null); 
        } catch (Exception exception) {
          Log.w("MediaSessionCompat", "Exception happened while accessing MediaSession.mCallback.", exception);
        }  
      this.a.setCallback(null);
      this.a.release();
    }
    
    class a extends b.a {
      a(MediaSessionCompat.d this$0) {}
      
      public boolean A0() {
        throw new AssertionError();
      }
      
      public void B0(MediaDescriptionCompat param2MediaDescriptionCompat) {
        throw new AssertionError();
      }
      
      public void C0(String param2String, Bundle param2Bundle) throws RemoteException {
        throw new AssertionError();
      }
      
      public void F(String param2String, Bundle param2Bundle) throws RemoteException {
        throw new AssertionError();
      }
      
      public Bundle G() {
        return (this.c.d == null) ? null : new Bundle(this.c.d);
      }
      
      public CharSequence H0() {
        throw new AssertionError();
      }
      
      public void I0(a param2a) {
        this.c.f.unregister(param2a);
        Binder.getCallingPid();
        Binder.getCallingUid();
        synchronized (this.c.c) {
          this.c.getClass();
          return;
        } 
      }
      
      public void J(String param2String, Bundle param2Bundle) throws RemoteException {
        throw new AssertionError();
      }
      
      public void K(String param2String, Bundle param2Bundle) throws RemoteException {
        throw new AssertionError();
      }
      
      public void M(Uri param2Uri, Bundle param2Bundle) throws RemoteException {
        throw new AssertionError();
      }
      
      public void M0() throws RemoteException {
        throw new AssertionError();
      }
      
      public void O0(long param2Long) throws RemoteException {
        throw new AssertionError();
      }
      
      public boolean R(KeyEvent param2KeyEvent) {
        throw new AssertionError();
      }
      
      public void S0(float param2Float) throws RemoteException {
        throw new AssertionError();
      }
      
      public void U(RatingCompat param2RatingCompat, Bundle param2Bundle) throws RemoteException {
        throw new AssertionError();
      }
      
      public void W(MediaDescriptionCompat param2MediaDescriptionCompat, int param2Int) {
        throw new AssertionError();
      }
      
      public void W0(int param2Int1, int param2Int2, String param2String) {
        throw new AssertionError();
      }
      
      public void Y0(boolean param2Boolean) throws RemoteException {
        throw new AssertionError();
      }
      
      public int a0() {
        return this.c.m;
      }
      
      public String b() {
        throw new AssertionError();
      }
      
      public PlaybackStateCompat c() {
        MediaSessionCompat.d d1 = this.c;
        return MediaSessionCompat.d(d1.g, d1.i);
      }
      
      public void c0(int param2Int) {
        throw new AssertionError();
      }
      
      public ParcelableVolumeInfo c1() {
        throw new AssertionError();
      }
      
      public boolean d0() {
        return this.c.k;
      }
      
      public void e() throws RemoteException {
        throw new AssertionError();
      }
      
      public void f() throws RemoteException {
        throw new AssertionError();
      }
      
      public void g(int param2Int) throws RemoteException {
        throw new AssertionError();
      }
      
      public Bundle getExtras() {
        throw new AssertionError();
      }
      
      public MediaMetadataCompat getMetadata() {
        throw new AssertionError();
      }
      
      public String getPackageName() {
        throw new AssertionError();
      }
      
      public void h() throws RemoteException {
        throw new AssertionError();
      }
      
      public void i(int param2Int) throws RemoteException {
        throw new AssertionError();
      }
      
      public void j0(String param2String, Bundle param2Bundle, MediaSessionCompat.ResultReceiverWrapper param2ResultReceiverWrapper) {
        throw new AssertionError();
      }
      
      public List<MediaSessionCompat.QueueItem> k() {
        return null;
      }
      
      public long l() {
        throw new AssertionError();
      }
      
      public void l0(long param2Long) {
        throw new AssertionError();
      }
      
      public int m() {
        return this.c.l;
      }
      
      public void m0(boolean param2Boolean) throws RemoteException {}
      
      public void n(String param2String, Bundle param2Bundle) throws RemoteException {
        throw new AssertionError();
      }
      
      public void next() throws RemoteException {
        throw new AssertionError();
      }
      
      public void pause() throws RemoteException {
        throw new AssertionError();
      }
      
      public void previous() throws RemoteException {
        throw new AssertionError();
      }
      
      public boolean q() {
        return false;
      }
      
      public void stop() throws RemoteException {
        throw new AssertionError();
      }
      
      public void u(Uri param2Uri, Bundle param2Bundle) throws RemoteException {
        throw new AssertionError();
      }
      
      public void u0(a param2a) {
        if (this.c.e)
          return; 
        null = new u3.a("android.media.session.MediaController", Binder.getCallingPid(), Binder.getCallingUid());
        this.c.f.register(param2a, null);
        synchronized (this.c.c) {
          this.c.getClass();
          return;
        } 
      }
      
      public PendingIntent w() {
        throw new AssertionError();
      }
      
      public void w0(RatingCompat param2RatingCompat) throws RemoteException {
        throw new AssertionError();
      }
      
      public void x0(int param2Int1, int param2Int2, String param2String) {
        throw new AssertionError();
      }
      
      public int y() {
        return this.c.j;
      }
      
      public void z0(MediaDescriptionCompat param2MediaDescriptionCompat) {
        throw new AssertionError();
      }
    }
  }
  
  class a extends b.a {
    a(MediaSessionCompat this$0) {}
    
    public boolean A0() {
      throw new AssertionError();
    }
    
    public void B0(MediaDescriptionCompat param1MediaDescriptionCompat) {
      throw new AssertionError();
    }
    
    public void C0(String param1String, Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public void F(String param1String, Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public Bundle G() {
      return (this.c.d == null) ? null : new Bundle(this.c.d);
    }
    
    public CharSequence H0() {
      throw new AssertionError();
    }
    
    public void I0(a param1a) {
      this.c.f.unregister(param1a);
      Binder.getCallingPid();
      Binder.getCallingUid();
      synchronized (this.c.c) {
        this.c.getClass();
        return;
      } 
    }
    
    public void J(String param1String, Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public void K(String param1String, Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public void M(Uri param1Uri, Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public void M0() throws RemoteException {
      throw new AssertionError();
    }
    
    public void O0(long param1Long) throws RemoteException {
      throw new AssertionError();
    }
    
    public boolean R(KeyEvent param1KeyEvent) {
      throw new AssertionError();
    }
    
    public void S0(float param1Float) throws RemoteException {
      throw new AssertionError();
    }
    
    public void U(RatingCompat param1RatingCompat, Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public void W(MediaDescriptionCompat param1MediaDescriptionCompat, int param1Int) {
      throw new AssertionError();
    }
    
    public void W0(int param1Int1, int param1Int2, String param1String) {
      throw new AssertionError();
    }
    
    public void Y0(boolean param1Boolean) throws RemoteException {
      throw new AssertionError();
    }
    
    public int a0() {
      return this.c.m;
    }
    
    public String b() {
      throw new AssertionError();
    }
    
    public PlaybackStateCompat c() {
      MediaSessionCompat.d d1 = this.c;
      return MediaSessionCompat.d(d1.g, d1.i);
    }
    
    public void c0(int param1Int) {
      throw new AssertionError();
    }
    
    public ParcelableVolumeInfo c1() {
      throw new AssertionError();
    }
    
    public boolean d0() {
      return this.c.k;
    }
    
    public void e() throws RemoteException {
      throw new AssertionError();
    }
    
    public void f() throws RemoteException {
      throw new AssertionError();
    }
    
    public void g(int param1Int) throws RemoteException {
      throw new AssertionError();
    }
    
    public Bundle getExtras() {
      throw new AssertionError();
    }
    
    public MediaMetadataCompat getMetadata() {
      throw new AssertionError();
    }
    
    public String getPackageName() {
      throw new AssertionError();
    }
    
    public void h() throws RemoteException {
      throw new AssertionError();
    }
    
    public void i(int param1Int) throws RemoteException {
      throw new AssertionError();
    }
    
    public void j0(String param1String, Bundle param1Bundle, MediaSessionCompat.ResultReceiverWrapper param1ResultReceiverWrapper) {
      throw new AssertionError();
    }
    
    public List<MediaSessionCompat.QueueItem> k() {
      return null;
    }
    
    public long l() {
      throw new AssertionError();
    }
    
    public void l0(long param1Long) {
      throw new AssertionError();
    }
    
    public int m() {
      return this.c.l;
    }
    
    public void m0(boolean param1Boolean) throws RemoteException {}
    
    public void n(String param1String, Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public void next() throws RemoteException {
      throw new AssertionError();
    }
    
    public void pause() throws RemoteException {
      throw new AssertionError();
    }
    
    public void previous() throws RemoteException {
      throw new AssertionError();
    }
    
    public boolean q() {
      return false;
    }
    
    public void stop() throws RemoteException {
      throw new AssertionError();
    }
    
    public void u(Uri param1Uri, Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public void u0(a param1a) {
      if (this.c.e)
        return; 
      null = new u3.a("android.media.session.MediaController", Binder.getCallingPid(), Binder.getCallingUid());
      this.c.f.register(param1a, null);
      synchronized (this.c.c) {
        this.c.getClass();
        return;
      } 
    }
    
    public PendingIntent w() {
      throw new AssertionError();
    }
    
    public void w0(RatingCompat param1RatingCompat) throws RemoteException {
      throw new AssertionError();
    }
    
    public void x0(int param1Int1, int param1Int2, String param1String) {
      throw new AssertionError();
    }
    
    public int y() {
      return this.c.j;
    }
    
    public void z0(MediaDescriptionCompat param1MediaDescriptionCompat) {
      throw new AssertionError();
    }
  }
  
  static class e extends d {
    e(Context param1Context, String param1String, l4.b param1b, Bundle param1Bundle) {
      super(param1Context, param1String, param1b, param1Bundle);
    }
  }
  
  static class f extends e {
    f(Context param1Context, String param1String, l4.b param1b, Bundle param1Bundle) {
      super(param1Context, param1String, param1b, param1Bundle);
    }
    
    public void e(u3.a param1a) {}
    
    public final u3.a n() {
      return new u3.a(c.a(this.a));
    }
  }
  
  static class g extends f {
    g(Context param1Context, String param1String, l4.b param1b, Bundle param1Bundle) {
      super(param1Context, param1String, param1b, param1Bundle);
    }
    
    public MediaSession o(Context param1Context, String param1String, Bundle param1Bundle) {
      return d.a(param1Context, param1String, param1Bundle);
    }
  }
  
  public static interface h {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\android\support\v4\media\session\MediaSessionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */