package android.support.v4.media;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;
import java.util.Set;

@SuppressLint({"BanParcelableUsage"})
public final class MediaMetadataCompat implements Parcelable {
  public static final Parcelable.Creator<MediaMetadataCompat> CREATOR;
  
  static final androidx.collection.a<String, Integer> u0;
  
  private static final String[] v0 = new String[] { "android.media.metadata.TITLE", "android.media.metadata.ARTIST", "android.media.metadata.ALBUM", "android.media.metadata.ALBUM_ARTIST", "android.media.metadata.WRITER", "android.media.metadata.AUTHOR", "android.media.metadata.COMPOSER" };
  
  private static final String[] w0 = new String[] { "android.media.metadata.DISPLAY_ICON", "android.media.metadata.ART", "android.media.metadata.ALBUM_ART" };
  
  private static final String[] x0 = new String[] { "android.media.metadata.DISPLAY_ICON_URI", "android.media.metadata.ART_URI", "android.media.metadata.ALBUM_ART_URI" };
  
  final Bundle s0;
  
  private MediaMetadata t0;
  
  static {
    CREATOR = new a();
  }
  
  MediaMetadataCompat(Bundle paramBundle) {
    paramBundle = new Bundle(paramBundle);
    this.s0 = paramBundle;
    MediaSessionCompat.a(paramBundle);
  }
  
  MediaMetadataCompat(Parcel paramParcel) {
    this.s0 = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
  }
  
  public static MediaMetadataCompat b(Object paramObject) {
    if (paramObject != null) {
      Parcel parcel = Parcel.obtain();
      paramObject = paramObject;
      paramObject.writeToParcel(parcel, 0);
      parcel.setDataPosition(0);
      MediaMetadataCompat mediaMetadataCompat = (MediaMetadataCompat)CREATOR.createFromParcel(parcel);
      parcel.recycle();
      mediaMetadataCompat.t0 = (MediaMetadata)paramObject;
      return mediaMetadataCompat;
    } 
    return null;
  }
  
  public boolean a(String paramString) {
    return this.s0.containsKey(paramString);
  }
  
  public Bundle c() {
    return new Bundle(this.s0);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public long f(String paramString) {
    return this.s0.getLong(paramString, 0L);
  }
  
  public Object g() {
    if (this.t0 == null) {
      Parcel parcel = Parcel.obtain();
      writeToParcel(parcel, 0);
      parcel.setDataPosition(0);
      this.t0 = (MediaMetadata)MediaMetadata.CREATOR.createFromParcel(parcel);
      parcel.recycle();
    } 
    return this.t0;
  }
  
  public Set<String> h() {
    return this.s0.keySet();
  }
  
  public int i() {
    return this.s0.size();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeBundle(this.s0);
  }
  
  static {
    androidx.collection.a<String, Integer> a1 = new androidx.collection.a();
    u0 = a1;
    Integer integer1 = Integer.valueOf(1);
    a1.put("android.media.metadata.TITLE", integer1);
    a1.put("android.media.metadata.ARTIST", integer1);
    Integer integer2 = Integer.valueOf(0);
    a1.put("android.media.metadata.DURATION", integer2);
    a1.put("android.media.metadata.ALBUM", integer1);
    a1.put("android.media.metadata.AUTHOR", integer1);
    a1.put("android.media.metadata.WRITER", integer1);
    a1.put("android.media.metadata.COMPOSER", integer1);
    a1.put("android.media.metadata.COMPILATION", integer1);
    a1.put("android.media.metadata.DATE", integer1);
    a1.put("android.media.metadata.YEAR", integer2);
    a1.put("android.media.metadata.GENRE", integer1);
    a1.put("android.media.metadata.TRACK_NUMBER", integer2);
    a1.put("android.media.metadata.NUM_TRACKS", integer2);
    a1.put("android.media.metadata.DISC_NUMBER", integer2);
    a1.put("android.media.metadata.ALBUM_ARTIST", integer1);
    Integer integer3 = Integer.valueOf(2);
    a1.put("android.media.metadata.ART", integer3);
    a1.put("android.media.metadata.ART_URI", integer1);
    a1.put("android.media.metadata.ALBUM_ART", integer3);
    a1.put("android.media.metadata.ALBUM_ART_URI", integer1);
    Integer integer4 = Integer.valueOf(3);
    a1.put("android.media.metadata.USER_RATING", integer4);
    a1.put("android.media.metadata.RATING", integer4);
    a1.put("android.media.metadata.DISPLAY_TITLE", integer1);
    a1.put("android.media.metadata.DISPLAY_SUBTITLE", integer1);
    a1.put("android.media.metadata.DISPLAY_DESCRIPTION", integer1);
    a1.put("android.media.metadata.DISPLAY_ICON", integer3);
    a1.put("android.media.metadata.DISPLAY_ICON_URI", integer1);
    a1.put("android.media.metadata.MEDIA_ID", integer1);
    a1.put("android.media.metadata.BT_FOLDER_TYPE", integer2);
    a1.put("android.media.metadata.MEDIA_URI", integer1);
    a1.put("android.media.metadata.ADVERTISEMENT", integer2);
    a1.put("android.media.metadata.DOWNLOAD_STATUS", integer2);
  }
  
  class a implements Parcelable.Creator<MediaMetadataCompat> {
    public MediaMetadataCompat a(Parcel param1Parcel) {
      return new MediaMetadataCompat(param1Parcel);
    }
    
    public MediaMetadataCompat[] b(int param1Int) {
      return new MediaMetadataCompat[param1Int];
    }
  }
  
  public static final class b {
    private final Bundle a = new Bundle();
    
    public MediaMetadataCompat a() {
      return new MediaMetadataCompat(this.a);
    }
    
    public b b(String param1String, Bitmap param1Bitmap) {
      androidx.collection.a<String, Integer> a = MediaMetadataCompat.u0;
      if (!a.containsKey(param1String) || ((Integer)a.get(param1String)).intValue() == 2) {
        this.a.putParcelable(param1String, (Parcelable)param1Bitmap);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The ");
      stringBuilder.append(param1String);
      stringBuilder.append(" key cannot be used to put a Bitmap");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public b c(String param1String, long param1Long) {
      androidx.collection.a<String, Integer> a = MediaMetadataCompat.u0;
      if (!a.containsKey(param1String) || ((Integer)a.get(param1String)).intValue() == 0) {
        this.a.putLong(param1String, param1Long);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The ");
      stringBuilder.append(param1String);
      stringBuilder.append(" key cannot be used to put a long");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public b d(String param1String, RatingCompat param1RatingCompat) {
      androidx.collection.a<String, Integer> a = MediaMetadataCompat.u0;
      if (!a.containsKey(param1String) || ((Integer)a.get(param1String)).intValue() == 3) {
        this.a.putParcelable(param1String, (Parcelable)param1RatingCompat.c());
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The ");
      stringBuilder.append(param1String);
      stringBuilder.append(" key cannot be used to put a Rating");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public b e(String param1String1, String param1String2) {
      androidx.collection.a<String, Integer> a = MediaMetadataCompat.u0;
      if (!a.containsKey(param1String1) || ((Integer)a.get(param1String1)).intValue() == 1) {
        this.a.putCharSequence(param1String1, param1String2);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The ");
      stringBuilder.append(param1String1);
      stringBuilder.append(" key cannot be used to put a String");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public b f(String param1String, CharSequence param1CharSequence) {
      androidx.collection.a<String, Integer> a = MediaMetadataCompat.u0;
      if (!a.containsKey(param1String) || ((Integer)a.get(param1String)).intValue() == 1) {
        this.a.putCharSequence(param1String, param1CharSequence);
        return this;
      } 
      param1CharSequence = new StringBuilder();
      param1CharSequence.append("The ");
      param1CharSequence.append(param1String);
      param1CharSequence.append(" key cannot be used to put a CharSequence");
      throw new IllegalArgumentException(param1CharSequence.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\android\support\v4\media\MediaMetadataCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */