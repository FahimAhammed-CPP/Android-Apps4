package androidx.collection;

public class h<E> implements Cloneable {
  private static final Object w0 = new Object();
  
  private boolean s0 = false;
  
  private int[] t0;
  
  private Object[] u0;
  
  private int v0;
  
  public h() {
    this(10);
  }
  
  public h(int paramInt) {
    if (paramInt == 0) {
      this.t0 = c.a;
      this.u0 = c.c;
      return;
    } 
    paramInt = c.e(paramInt);
    this.t0 = new int[paramInt];
    this.u0 = new Object[paramInt];
  }
  
  private void g() {
    int k = this.v0;
    int[] arrayOfInt = this.t0;
    Object[] arrayOfObject = this.u0;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != w0) {
        if (i != j) {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    this.s0 = false;
    this.v0 = j;
  }
  
  public void b(int paramInt, E paramE) {
    int i = this.v0;
    if (i != 0 && paramInt <= this.t0[i - 1]) {
      m(paramInt, paramE);
      return;
    } 
    if (this.s0 && i >= this.t0.length)
      g(); 
    i = this.v0;
    if (i >= this.t0.length) {
      int j = c.e(i + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.t0;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.u0;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.t0 = arrayOfInt1;
      this.u0 = arrayOfObject1;
    } 
    this.t0[i] = paramInt;
    this.u0[i] = paramE;
    this.v0 = i + 1;
  }
  
  public void c() {
    int j = this.v0;
    Object[] arrayOfObject = this.u0;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.v0 = 0;
    this.s0 = false;
  }
  
  public h<E> d() {
    try {
      h<E> h1 = (h)super.clone();
      h1.t0 = (int[])this.t0.clone();
      h1.u0 = (Object[])this.u0.clone();
      return h1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public boolean e(int paramInt) {
    return (j(paramInt) >= 0);
  }
  
  public boolean f(E paramE) {
    return (k(paramE) >= 0);
  }
  
  public E h(int paramInt) {
    return i(paramInt, null);
  }
  
  public E i(int paramInt, E paramE) {
    paramInt = c.a(this.t0, this.v0, paramInt);
    if (paramInt >= 0) {
      Object object = this.u0[paramInt];
      return (E)((object == w0) ? (Object)paramE : object);
    } 
    return paramE;
  }
  
  public int j(int paramInt) {
    if (this.s0)
      g(); 
    return c.a(this.t0, this.v0, paramInt);
  }
  
  public int k(E paramE) {
    if (this.s0)
      g(); 
    for (int i = 0; i < this.v0; i++) {
      if (this.u0[i] == paramE)
        return i; 
    } 
    return -1;
  }
  
  public int l(int paramInt) {
    if (this.s0)
      g(); 
    return this.t0[paramInt];
  }
  
  public void m(int paramInt, E paramE) {
    int i = c.a(this.t0, this.v0, paramInt);
    if (i >= 0) {
      this.u0[i] = paramE;
      return;
    } 
    int j = i;
    int k = this.v0;
    if (j < k) {
      Object[] arrayOfObject = this.u0;
      if (arrayOfObject[j] == w0) {
        this.t0[j] = paramInt;
        arrayOfObject[j] = paramE;
        return;
      } 
    } 
    i = j;
    if (this.s0) {
      i = j;
      if (k >= this.t0.length) {
        g();
        i = c.a(this.t0, this.v0, paramInt);
      } 
    } 
    j = this.v0;
    if (j >= this.t0.length) {
      j = c.e(j + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.t0;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.u0;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.t0 = arrayOfInt1;
      this.u0 = arrayOfObject1;
    } 
    j = this.v0;
    if (j - i != 0) {
      int[] arrayOfInt = this.t0;
      k = i + 1;
      System.arraycopy(arrayOfInt, i, arrayOfInt, k, j - i);
      Object[] arrayOfObject = this.u0;
      System.arraycopy(arrayOfObject, i, arrayOfObject, k, this.v0 - i);
    } 
    this.t0[i] = paramInt;
    this.u0[i] = paramE;
    this.v0++;
  }
  
  public void o(int paramInt) {
    Object[] arrayOfObject = this.u0;
    Object object1 = arrayOfObject[paramInt];
    Object object2 = w0;
    if (object1 != object2) {
      arrayOfObject[paramInt] = object2;
      this.s0 = true;
    } 
  }
  
  public E p(int paramInt, E paramE) {
    paramInt = j(paramInt);
    if (paramInt >= 0) {
      Object[] arrayOfObject = this.u0;
      Object object = arrayOfObject[paramInt];
      arrayOfObject[paramInt] = paramE;
      return (E)object;
    } 
    return null;
  }
  
  public int q() {
    if (this.s0)
      g(); 
    return this.v0;
  }
  
  public E r(int paramInt) {
    if (this.s0)
      g(); 
    return (E)this.u0[paramInt];
  }
  
  public String toString() {
    if (q() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.v0 * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.v0; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(l(i));
      stringBuilder.append('=');
      E e = r(i);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\collection\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */