package androidx.collection;

import java.util.ConcurrentModificationException;
import java.util.Map;

public class g<K, V> {
  static Object[] v0;
  
  static int w0;
  
  static Object[] x0;
  
  static int y0;
  
  int[] s0;
  
  Object[] t0;
  
  int u0;
  
  public g() {
    this.s0 = c.a;
    this.t0 = c.c;
    this.u0 = 0;
  }
  
  public g(int paramInt) {
    if (paramInt == 0) {
      this.s0 = c.a;
      this.t0 = c.c;
    } else {
      a(paramInt);
    } 
    this.u0 = 0;
  }
  
  public g(g<K, V> paramg) {
    this();
    if (paramg != null)
      k(paramg); 
  }
  
  private void a(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: bipush #8
    //   3: if_icmpne -> 73
    //   6: ldc androidx/collection/g
    //   8: monitorenter
    //   9: getstatic androidx/collection/g.x0 : [Ljava/lang/Object;
    //   12: astore_2
    //   13: aload_2
    //   14: ifnull -> 61
    //   17: aload_0
    //   18: aload_2
    //   19: putfield t0 : [Ljava/lang/Object;
    //   22: aload_2
    //   23: iconst_0
    //   24: aaload
    //   25: checkcast [Ljava/lang/Object;
    //   28: putstatic androidx/collection/g.x0 : [Ljava/lang/Object;
    //   31: aload_0
    //   32: aload_2
    //   33: iconst_1
    //   34: aaload
    //   35: checkcast [I
    //   38: putfield s0 : [I
    //   41: aload_2
    //   42: iconst_1
    //   43: aconst_null
    //   44: aastore
    //   45: aload_2
    //   46: iconst_0
    //   47: aconst_null
    //   48: aastore
    //   49: getstatic androidx/collection/g.y0 : I
    //   52: iconst_1
    //   53: isub
    //   54: putstatic androidx/collection/g.y0 : I
    //   57: ldc androidx/collection/g
    //   59: monitorexit
    //   60: return
    //   61: ldc androidx/collection/g
    //   63: monitorexit
    //   64: goto -> 145
    //   67: astore_2
    //   68: ldc androidx/collection/g
    //   70: monitorexit
    //   71: aload_2
    //   72: athrow
    //   73: iload_1
    //   74: iconst_4
    //   75: if_icmpne -> 145
    //   78: ldc androidx/collection/g
    //   80: monitorenter
    //   81: getstatic androidx/collection/g.v0 : [Ljava/lang/Object;
    //   84: astore_2
    //   85: aload_2
    //   86: ifnull -> 133
    //   89: aload_0
    //   90: aload_2
    //   91: putfield t0 : [Ljava/lang/Object;
    //   94: aload_2
    //   95: iconst_0
    //   96: aaload
    //   97: checkcast [Ljava/lang/Object;
    //   100: putstatic androidx/collection/g.v0 : [Ljava/lang/Object;
    //   103: aload_0
    //   104: aload_2
    //   105: iconst_1
    //   106: aaload
    //   107: checkcast [I
    //   110: putfield s0 : [I
    //   113: aload_2
    //   114: iconst_1
    //   115: aconst_null
    //   116: aastore
    //   117: aload_2
    //   118: iconst_0
    //   119: aconst_null
    //   120: aastore
    //   121: getstatic androidx/collection/g.w0 : I
    //   124: iconst_1
    //   125: isub
    //   126: putstatic androidx/collection/g.w0 : I
    //   129: ldc androidx/collection/g
    //   131: monitorexit
    //   132: return
    //   133: ldc androidx/collection/g
    //   135: monitorexit
    //   136: goto -> 145
    //   139: astore_2
    //   140: ldc androidx/collection/g
    //   142: monitorexit
    //   143: aload_2
    //   144: athrow
    //   145: aload_0
    //   146: iload_1
    //   147: newarray int
    //   149: putfield s0 : [I
    //   152: aload_0
    //   153: iload_1
    //   154: iconst_1
    //   155: ishl
    //   156: anewarray java/lang/Object
    //   159: putfield t0 : [Ljava/lang/Object;
    //   162: return
    // Exception table:
    //   from	to	target	type
    //   9	13	67	finally
    //   17	41	67	finally
    //   49	60	67	finally
    //   61	64	67	finally
    //   68	71	67	finally
    //   81	85	139	finally
    //   89	113	139	finally
    //   121	132	139	finally
    //   133	136	139	finally
    //   140	143	139	finally
  }
  
  private static int b(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    try {
      return c.a(paramArrayOfint, paramInt1, paramInt2);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      throw new ConcurrentModificationException();
    } 
  }
  
  private static void d(int[] paramArrayOfint, Object[] paramArrayOfObject, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: bipush #8
    //   4: if_icmpne -> 59
    //   7: ldc androidx/collection/g
    //   9: monitorenter
    //   10: getstatic androidx/collection/g.y0 : I
    //   13: bipush #10
    //   15: if_icmpge -> 49
    //   18: aload_1
    //   19: iconst_0
    //   20: getstatic androidx/collection/g.x0 : [Ljava/lang/Object;
    //   23: aastore
    //   24: aload_1
    //   25: iconst_1
    //   26: aload_0
    //   27: aastore
    //   28: iload_2
    //   29: iconst_1
    //   30: ishl
    //   31: iconst_1
    //   32: isub
    //   33: istore_2
    //   34: goto -> 118
    //   37: aload_1
    //   38: putstatic androidx/collection/g.x0 : [Ljava/lang/Object;
    //   41: getstatic androidx/collection/g.y0 : I
    //   44: iconst_1
    //   45: iadd
    //   46: putstatic androidx/collection/g.y0 : I
    //   49: ldc androidx/collection/g
    //   51: monitorexit
    //   52: return
    //   53: astore_0
    //   54: ldc androidx/collection/g
    //   56: monitorexit
    //   57: aload_0
    //   58: athrow
    //   59: aload_0
    //   60: arraylength
    //   61: iconst_4
    //   62: if_icmpne -> 117
    //   65: ldc androidx/collection/g
    //   67: monitorenter
    //   68: getstatic androidx/collection/g.w0 : I
    //   71: bipush #10
    //   73: if_icmpge -> 107
    //   76: aload_1
    //   77: iconst_0
    //   78: getstatic androidx/collection/g.v0 : [Ljava/lang/Object;
    //   81: aastore
    //   82: aload_1
    //   83: iconst_1
    //   84: aload_0
    //   85: aastore
    //   86: iload_2
    //   87: iconst_1
    //   88: ishl
    //   89: iconst_1
    //   90: isub
    //   91: istore_2
    //   92: goto -> 134
    //   95: aload_1
    //   96: putstatic androidx/collection/g.v0 : [Ljava/lang/Object;
    //   99: getstatic androidx/collection/g.w0 : I
    //   102: iconst_1
    //   103: iadd
    //   104: putstatic androidx/collection/g.w0 : I
    //   107: ldc androidx/collection/g
    //   109: monitorexit
    //   110: return
    //   111: astore_0
    //   112: ldc androidx/collection/g
    //   114: monitorexit
    //   115: aload_0
    //   116: athrow
    //   117: return
    //   118: iload_2
    //   119: iconst_2
    //   120: if_icmplt -> 37
    //   123: aload_1
    //   124: iload_2
    //   125: aconst_null
    //   126: aastore
    //   127: iload_2
    //   128: iconst_1
    //   129: isub
    //   130: istore_2
    //   131: goto -> 118
    //   134: iload_2
    //   135: iconst_2
    //   136: if_icmplt -> 95
    //   139: aload_1
    //   140: iload_2
    //   141: aconst_null
    //   142: aastore
    //   143: iload_2
    //   144: iconst_1
    //   145: isub
    //   146: istore_2
    //   147: goto -> 134
    // Exception table:
    //   from	to	target	type
    //   10	24	53	finally
    //   37	49	53	finally
    //   49	52	53	finally
    //   54	57	53	finally
    //   68	82	111	finally
    //   95	107	111	finally
    //   107	110	111	finally
    //   112	115	111	finally
  }
  
  public void c(int paramInt) {
    int i = this.u0;
    int[] arrayOfInt = this.s0;
    if (arrayOfInt.length < paramInt) {
      Object[] arrayOfObject = this.t0;
      a(paramInt);
      if (this.u0 > 0) {
        System.arraycopy(arrayOfInt, 0, this.s0, 0, i);
        System.arraycopy(arrayOfObject, 0, this.t0, 0, i << 1);
      } 
      d(arrayOfInt, arrayOfObject, i);
    } 
    if (this.u0 == i)
      return; 
    throw new ConcurrentModificationException();
  }
  
  public void clear() {
    int i = this.u0;
    if (i > 0) {
      int[] arrayOfInt = this.s0;
      Object[] arrayOfObject = this.t0;
      this.s0 = c.a;
      this.t0 = c.c;
      this.u0 = 0;
      d(arrayOfInt, arrayOfObject, i);
    } 
    if (this.u0 <= 0)
      return; 
    throw new ConcurrentModificationException();
  }
  
  public boolean containsKey(Object paramObject) {
    return (f(paramObject) >= 0);
  }
  
  public boolean containsValue(Object paramObject) {
    return (i(paramObject) >= 0);
  }
  
  int e(Object paramObject, int paramInt) {
    int j = this.u0;
    if (j == 0)
      return -1; 
    int k = b(this.s0, j, paramInt);
    if (k < 0)
      return k; 
    if (paramObject.equals(this.t0[k << 1]))
      return k; 
    int i;
    for (i = k + 1; i < j && this.s0[i] == paramInt; i++) {
      if (paramObject.equals(this.t0[i << 1]))
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.s0[j] == paramInt; j--) {
      if (paramObject.equals(this.t0[j << 1]))
        return j; 
    } 
    return i;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof g) {
      paramObject = paramObject;
      if (size() != paramObject.size())
        return false; 
      int i = 0;
      try {
        while (i < this.u0) {
          K k = j(i);
          V v = n(i);
          Object object = paramObject.get(k);
          if (v == null) {
            if (object == null) {
              if (!paramObject.containsKey(k))
                return false; 
            } else {
              return false;
            } 
          } else {
            boolean bool = v.equals(object);
            if (!bool)
              return false; 
          } 
          i++;
        } 
        return true;
      } catch (NullPointerException|ClassCastException nullPointerException) {
        return false;
      } 
    } 
    if (nullPointerException instanceof Map) {
      Map map = (Map)nullPointerException;
      if (size() != map.size())
        return false; 
      int i = 0;
      try {
        while (i < this.u0) {
          K k = j(i);
          V v = n(i);
          Object object = map.get(k);
          if (v == null) {
            if (object == null) {
              if (!map.containsKey(k))
                return false; 
            } else {
              return false;
            } 
          } else {
            boolean bool = v.equals(object);
            if (!bool)
              return false; 
          } 
          i++;
        } 
        return true;
      } catch (NullPointerException|ClassCastException nullPointerException1) {
        return false;
      } 
    } 
    return false;
  }
  
  public int f(Object paramObject) {
    return (paramObject == null) ? g() : e(paramObject, paramObject.hashCode());
  }
  
  int g() {
    int j = this.u0;
    if (j == 0)
      return -1; 
    int k = b(this.s0, j, 0);
    if (k < 0)
      return k; 
    if (this.t0[k << 1] == null)
      return k; 
    int i;
    for (i = k + 1; i < j && this.s0[i] == 0; i++) {
      if (this.t0[i << 1] == null)
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.s0[j] == 0; j--) {
      if (this.t0[j << 1] == null)
        return j; 
    } 
    return i;
  }
  
  public V get(Object paramObject) {
    return getOrDefault(paramObject, null);
  }
  
  public V getOrDefault(Object paramObject, V paramV) {
    int i = f(paramObject);
    if (i >= 0)
      paramV = (V)this.t0[(i << 1) + 1]; 
    return paramV;
  }
  
  public int hashCode() {
    int[] arrayOfInt = this.s0;
    Object[] arrayOfObject = this.t0;
    int m = this.u0;
    int i = 1;
    int j = 0;
    int k = 0;
    while (j < m) {
      int n;
      Object object = arrayOfObject[i];
      int i1 = arrayOfInt[j];
      if (object == null) {
        n = 0;
      } else {
        n = object.hashCode();
      } 
      k += n ^ i1;
      j++;
      i += 2;
    } 
    return k;
  }
  
  int i(Object paramObject) {
    int i = this.u0 * 2;
    Object[] arrayOfObject = this.t0;
    if (paramObject == null) {
      for (int j = 1; j < i; j += 2) {
        if (arrayOfObject[j] == null)
          return j >> 1; 
      } 
    } else {
      for (int j = 1; j < i; j += 2) {
        if (paramObject.equals(arrayOfObject[j]))
          return j >> 1; 
      } 
    } 
    return -1;
  }
  
  public boolean isEmpty() {
    return (this.u0 <= 0);
  }
  
  public K j(int paramInt) {
    return (K)this.t0[paramInt << 1];
  }
  
  public void k(g<? extends K, ? extends V> paramg) {
    int j = paramg.u0;
    c(this.u0 + j);
    int k = this.u0;
    int i = 0;
    if (k == 0) {
      if (j > 0) {
        System.arraycopy(paramg.s0, 0, this.s0, 0, j);
        System.arraycopy(paramg.t0, 0, this.t0, 0, j << 1);
        this.u0 = j;
        return;
      } 
    } else {
      while (i < j) {
        put(paramg.j(i), paramg.n(i));
        i++;
      } 
    } 
  }
  
  public V l(int paramInt) {
    Object[] arrayOfObject = this.t0;
    int k = paramInt << 1;
    Object object = arrayOfObject[k + 1];
    int j = this.u0;
    int i = 0;
    if (j <= 1) {
      d(this.s0, arrayOfObject, j);
      this.s0 = c.a;
      this.t0 = c.c;
      paramInt = i;
    } else {
      int m = j - 1;
      int[] arrayOfInt = this.s0;
      int n = arrayOfInt.length;
      i = 8;
      if (n > 8 && j < arrayOfInt.length / 3) {
        if (j > 8)
          i = j + (j >> 1); 
        a(i);
        if (j == this.u0) {
          if (paramInt > 0) {
            System.arraycopy(arrayOfInt, 0, this.s0, 0, paramInt);
            System.arraycopy(arrayOfObject, 0, this.t0, 0, k);
          } 
          if (paramInt < m) {
            i = paramInt + 1;
            int[] arrayOfInt1 = this.s0;
            n = m - paramInt;
            System.arraycopy(arrayOfInt, i, arrayOfInt1, paramInt, n);
            System.arraycopy(arrayOfObject, i << 1, this.t0, k, n << 1);
          } 
        } else {
          throw new ConcurrentModificationException();
        } 
      } else {
        if (paramInt < m) {
          i = paramInt + 1;
          n = m - paramInt;
          System.arraycopy(arrayOfInt, i, arrayOfInt, paramInt, n);
          arrayOfObject = this.t0;
          System.arraycopy(arrayOfObject, i << 1, arrayOfObject, k, n << 1);
        } 
        arrayOfObject = this.t0;
        paramInt = m << 1;
        arrayOfObject[paramInt] = null;
        arrayOfObject[paramInt + 1] = null;
      } 
      paramInt = m;
    } 
    if (j == this.u0) {
      this.u0 = paramInt;
      return (V)object;
    } 
    throw new ConcurrentModificationException();
  }
  
  public V m(int paramInt, V paramV) {
    paramInt = (paramInt << 1) + 1;
    Object[] arrayOfObject = this.t0;
    Object object = arrayOfObject[paramInt];
    arrayOfObject[paramInt] = paramV;
    return (V)object;
  }
  
  public V n(int paramInt) {
    return (V)this.t0[(paramInt << 1) + 1];
  }
  
  public V put(K paramK, V paramV) {
    Object[] arrayOfObject;
    int j;
    int k = this.u0;
    if (paramK == null) {
      i = g();
      j = 0;
    } else {
      j = paramK.hashCode();
      i = e(paramK, j);
    } 
    if (i >= 0) {
      i = (i << 1) + 1;
      arrayOfObject = this.t0;
      Object object = arrayOfObject[i];
      arrayOfObject[i] = paramV;
      return (V)object;
    } 
    int m = i;
    int[] arrayOfInt = this.s0;
    if (k >= arrayOfInt.length) {
      i = 8;
      if (k >= 8) {
        i = (k >> 1) + k;
      } else if (k < 4) {
        i = 4;
      } 
      Object[] arrayOfObject1 = this.t0;
      a(i);
      if (k == this.u0) {
        int[] arrayOfInt1 = this.s0;
        if (arrayOfInt1.length > 0) {
          System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
          System.arraycopy(arrayOfObject1, 0, this.t0, 0, arrayOfObject1.length);
        } 
        d(arrayOfInt, arrayOfObject1, k);
      } else {
        throw new ConcurrentModificationException();
      } 
    } 
    if (m < k) {
      arrayOfInt = this.s0;
      i = m + 1;
      System.arraycopy(arrayOfInt, m, arrayOfInt, i, k - m);
      Object[] arrayOfObject1 = this.t0;
      System.arraycopy(arrayOfObject1, m << 1, arrayOfObject1, i << 1, this.u0 - m << 1);
    } 
    int i = this.u0;
    if (k == i) {
      arrayOfInt = this.s0;
      if (m < arrayOfInt.length) {
        arrayOfInt[m] = j;
        Object[] arrayOfObject1 = this.t0;
        j = m << 1;
        arrayOfObject1[j] = arrayOfObject;
        arrayOfObject1[j + 1] = paramV;
        this.u0 = i + 1;
        return null;
      } 
    } 
    throw new ConcurrentModificationException();
  }
  
  public V putIfAbsent(K paramK, V paramV) {
    V v2 = get(paramK);
    V v1 = v2;
    if (v2 == null)
      v1 = put(paramK, paramV); 
    return v1;
  }
  
  public V remove(Object paramObject) {
    int i = f(paramObject);
    return (i >= 0) ? l(i) : null;
  }
  
  public boolean remove(Object paramObject1, Object paramObject2) {
    int i = f(paramObject1);
    if (i >= 0) {
      paramObject1 = n(i);
      if (paramObject2 == paramObject1 || (paramObject2 != null && paramObject2.equals(paramObject1))) {
        l(i);
        return true;
      } 
    } 
    return false;
  }
  
  public V replace(K paramK, V paramV) {
    int i = f(paramK);
    return (i >= 0) ? m(i, paramV) : null;
  }
  
  public boolean replace(K paramK, V paramV1, V paramV2) {
    int i = f(paramK);
    if (i >= 0) {
      paramK = (K)n(i);
      if (paramK == paramV1 || (paramV1 != null && paramV1.equals(paramK))) {
        m(i, paramV2);
        return true;
      } 
    } 
    return false;
  }
  
  public int size() {
    return this.u0;
  }
  
  public String toString() {
    if (isEmpty())
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.u0 * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.u0; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      V v = (V)j(i);
      if (v != this) {
        stringBuilder.append(v);
      } else {
        stringBuilder.append("(this Map)");
      } 
      stringBuilder.append('=');
      v = n(i);
      if (v != this) {
        stringBuilder.append(v);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\collection\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */