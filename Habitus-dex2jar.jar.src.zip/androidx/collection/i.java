package androidx.collection;

import java.util.Iterator;
import kotlin.jvm.internal.q;

public final class i {
  public static final <T> Iterator<T> a(h<T> paramh) {
    q.k(paramh, "receiver$0");
    return new a(paramh);
  }
  
  public static final class a implements Iterator<T>, ek.a {
    private int s0;
    
    a(h<T> param1h) {}
    
    public boolean hasNext() {
      return (this.s0 < this.t0.q());
    }
    
    public T next() {
      h<T> h1 = this.t0;
      int i = this.s0;
      this.s0 = i + 1;
      return h1.r(i);
    }
    
    public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\collection\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */