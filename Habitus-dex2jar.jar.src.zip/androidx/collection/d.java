package androidx.collection;

public class d<E> implements Cloneable {
  private static final Object w0 = new Object();
  
  private boolean s0 = false;
  
  private long[] t0;
  
  private Object[] u0;
  
  private int v0;
  
  public d() {
    this(10);
  }
  
  public d(int paramInt) {
    if (paramInt == 0) {
      this.t0 = c.b;
      this.u0 = c.c;
      return;
    } 
    paramInt = c.f(paramInt);
    this.t0 = new long[paramInt];
    this.u0 = new Object[paramInt];
  }
  
  private void f() {
    int k = this.v0;
    long[] arrayOfLong = this.t0;
    Object[] arrayOfObject = this.u0;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != w0) {
        if (i != j) {
          arrayOfLong[j] = arrayOfLong[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    this.s0 = false;
    this.v0 = j;
  }
  
  public void b(long paramLong, E paramE) {
    int i = this.v0;
    if (i != 0 && paramLong <= this.t0[i - 1]) {
      l(paramLong, paramE);
      return;
    } 
    if (this.s0 && i >= this.t0.length)
      f(); 
    i = this.v0;
    if (i >= this.t0.length) {
      int j = c.f(i + 1);
      long[] arrayOfLong1 = new long[j];
      Object[] arrayOfObject1 = new Object[j];
      long[] arrayOfLong2 = this.t0;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.u0;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.t0 = arrayOfLong1;
      this.u0 = arrayOfObject1;
    } 
    this.t0[i] = paramLong;
    this.u0[i] = paramE;
    this.v0 = i + 1;
  }
  
  public void c() {
    int j = this.v0;
    Object[] arrayOfObject = this.u0;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.v0 = 0;
    this.s0 = false;
  }
  
  public d<E> d() {
    try {
      d<E> d1 = (d)super.clone();
      d1.t0 = (long[])this.t0.clone();
      d1.u0 = (Object[])this.u0.clone();
      return d1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public boolean e(long paramLong) {
    return (i(paramLong) >= 0);
  }
  
  public E g(long paramLong) {
    return h(paramLong, null);
  }
  
  public E h(long paramLong, E paramE) {
    int i = c.b(this.t0, this.v0, paramLong);
    if (i >= 0) {
      Object object = this.u0[i];
      return (E)((object == w0) ? (Object)paramE : object);
    } 
    return paramE;
  }
  
  public int i(long paramLong) {
    if (this.s0)
      f(); 
    return c.b(this.t0, this.v0, paramLong);
  }
  
  public boolean j() {
    return (p() == 0);
  }
  
  public long k(int paramInt) {
    if (this.s0)
      f(); 
    return this.t0[paramInt];
  }
  
  public void l(long paramLong, E paramE) {
    int i = c.b(this.t0, this.v0, paramLong);
    if (i >= 0) {
      this.u0[i] = paramE;
      return;
    } 
    int j = i;
    int k = this.v0;
    if (j < k) {
      Object[] arrayOfObject = this.u0;
      if (arrayOfObject[j] == w0) {
        this.t0[j] = paramLong;
        arrayOfObject[j] = paramE;
        return;
      } 
    } 
    i = j;
    if (this.s0) {
      i = j;
      if (k >= this.t0.length) {
        f();
        i = c.b(this.t0, this.v0, paramLong);
      } 
    } 
    j = this.v0;
    if (j >= this.t0.length) {
      j = c.f(j + 1);
      long[] arrayOfLong1 = new long[j];
      Object[] arrayOfObject1 = new Object[j];
      long[] arrayOfLong2 = this.t0;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.u0;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.t0 = arrayOfLong1;
      this.u0 = arrayOfObject1;
    } 
    j = this.v0;
    if (j - i != 0) {
      long[] arrayOfLong = this.t0;
      k = i + 1;
      System.arraycopy(arrayOfLong, i, arrayOfLong, k, j - i);
      Object[] arrayOfObject = this.u0;
      System.arraycopy(arrayOfObject, i, arrayOfObject, k, this.v0 - i);
    } 
    this.t0[i] = paramLong;
    this.u0[i] = paramE;
    this.v0++;
  }
  
  public void m(long paramLong) {
    int i = c.b(this.t0, this.v0, paramLong);
    if (i >= 0) {
      Object[] arrayOfObject = this.u0;
      Object object1 = arrayOfObject[i];
      Object object2 = w0;
      if (object1 != object2) {
        arrayOfObject[i] = object2;
        this.s0 = true;
      } 
    } 
  }
  
  public void o(int paramInt) {
    Object[] arrayOfObject = this.u0;
    Object object1 = arrayOfObject[paramInt];
    Object object2 = w0;
    if (object1 != object2) {
      arrayOfObject[paramInt] = object2;
      this.s0 = true;
    } 
  }
  
  public int p() {
    if (this.s0)
      f(); 
    return this.v0;
  }
  
  public E q(int paramInt) {
    if (this.s0)
      f(); 
    return (E)this.u0[paramInt];
  }
  
  public String toString() {
    if (p() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.v0 * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.v0; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(k(i));
      stringBuilder.append('=');
      E e = q(i);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\collection\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */