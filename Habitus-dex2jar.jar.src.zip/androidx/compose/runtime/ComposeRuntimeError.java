package androidx.compose.runtime;

public final class ComposeRuntimeError extends IllegalStateException {
  private final String s0;
  
  public ComposeRuntimeError(String paramString) {
    this.s0 = paramString;
  }
  
  public String getMessage() {
    return this.s0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\runtime\ComposeRuntimeError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */