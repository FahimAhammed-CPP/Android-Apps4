package androidx.compose.runtime.snapshots;

import dk.l;
import java.util.List;
import kotlin.KotlinNothingValueException;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;
import u0.b;
import u0.f;
import u0.g;
import u0.h;
import u0.j;
import u0.l;
import u0.u;

public final class a extends b {
  public a(int paramInt, j paramj) {}
  
  public h C() {
    throw new IllegalStateException("Cannot apply the global snapshot directly. Call Snapshot.advanceGlobalSnapshot".toString());
  }
  
  public b P(l<Object, v> paraml1, l<Object, v> paraml2) {
    return (b)l.v(new b(paraml1, paraml2));
  }
  
  public Void S(g paramg) {
    q.j(paramg, "snapshot");
    u.b();
    throw new KotlinNothingValueException();
  }
  
  public Void T(g paramg) {
    q.j(paramg, "snapshot");
    u.b();
    throw new KotlinNothingValueException();
  }
  
  public void d() {
    synchronized (l.G()) {
      q();
      v v = v.a;
      return;
    } 
  }
  
  public void o() {
    l.b();
  }
  
  public g x(l<Object, v> paraml) {
    return l.v(new c(paraml));
  }
  
  static final class a extends r implements l<Object, v> {
    a(List<l<Object, v>> param1List) {
      super(1);
    }
    
    public final void invoke(Object param1Object) {
      q.j(param1Object, "state");
      List<l<Object, v>> list = this.s0;
      int j = list.size();
      for (int i = 0; i < j; i++)
        ((l)list.get(i)).invoke(param1Object); 
    }
  }
  
  static final class b extends r implements l<j, b> {
    b(l<Object, v> param1l1, l<Object, v> param1l2) {
      super(1);
    }
    
    public final b a(j param1j) {
      q.j(param1j, "invalid");
      synchronized (l.G()) {
        int i = l.i();
        l.s(i + 1);
        return new b(i, param1j, this.s0, this.t0);
      } 
    }
  }
  
  static final class c extends r implements l<j, f> {
    c(l<Object, v> param1l) {
      super(1);
    }
    
    public final f a(j param1j) {
      q.j(param1j, "invalid");
      synchronized (l.G()) {
        int i = l.i();
        l.s(i + 1);
        return new f(i, param1j, this.s0);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\runtime\snapshots\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */