package androidx.compose.ui.layout;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import o1.s;
import q1.u0;
import rj.v;

final class OnGloballyPositionedElement extends u0<d> {
  private final l<s, v> c;
  
  public OnGloballyPositionedElement(l<? super s, v> paraml) {
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof OnGloballyPositionedElement) ? false : q.e(this.c, ((OnGloballyPositionedElement)paramObject).c));
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public d s() {
    return new d(this.c);
  }
  
  public void t(d paramd) {
    q.j(paramd, "node");
    paramd.A1(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\layout\OnGloballyPositionedElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */