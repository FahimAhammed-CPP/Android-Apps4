package androidx.compose.ui.layout;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import o1.s;
import rj.v;

public final class c {
  public static final e a(e parame, l<? super s, v> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "onGloballyPositioned");
    return parame.then((e)new OnGloballyPositionedElement(paraml));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\layout\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */