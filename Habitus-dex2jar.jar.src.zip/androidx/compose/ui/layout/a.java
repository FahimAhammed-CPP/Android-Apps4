package androidx.compose.ui.layout;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import o1.g0;

public final class a {
  public static final Object a(g0 paramg0) {
    q.j(paramg0, "<this>");
    Object object1 = paramg0.x();
    boolean bool = object1 instanceof o1.v;
    Object object2 = null;
    if (bool) {
      object1 = object1;
    } else {
      object1 = null;
    } 
    if (object1 != null)
      object2 = object1.getLayoutId(); 
    return object2;
  }
  
  public static final e b(e parame, Object paramObject) {
    q.j(parame, "<this>");
    q.j(paramObject, "layoutId");
    return parame.then((e)new LayoutIdElement(paramObject));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\layout\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */