package androidx.compose.ui.layout;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import o1.u;
import q1.u0;

final class LayoutIdElement extends u0<u> {
  private final Object c;
  
  public LayoutIdElement(Object paramObject) {
    this.c = paramObject;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof LayoutIdElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((LayoutIdElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public u s() {
    return new u(this.c);
  }
  
  public void t(u paramu) {
    q.j(paramu, "node");
    paramu.A1(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LayoutIdElement(layoutId=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\layout\LayoutIdElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */