package androidx.compose.ui.layout;

import androidx.compose.ui.e;
import dk.q;
import k2.b;
import kotlin.jvm.internal.q;
import o1.a0;
import o1.g0;
import o1.j0;
import o1.l0;
import q1.u0;

final class LayoutElement extends u0<a0> {
  private final q<l0, g0, b, j0> c;
  
  public LayoutElement(q<? super l0, ? super g0, ? super b, ? extends j0> paramq) {
    this.c = (q)paramq;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof LayoutElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((LayoutElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public a0 s() {
    return new a0(this.c);
  }
  
  public void t(a0 parama0) {
    q.j(parama0, "node");
    parama0.A1(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LayoutElement(measure=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\layout\LayoutElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */