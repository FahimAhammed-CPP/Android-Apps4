package androidx.compose.ui.layout;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import o1.s;
import q1.u;
import rj.v;

final class d extends e.c implements u {
  private l<? super s, v> F0;
  
  public d(l<? super s, v> paraml) {
    this.F0 = paraml;
  }
  
  public final void A1(l<? super s, v> paraml) {
    q.j(paraml, "<set-?>");
    this.F0 = paraml;
  }
  
  public void p(s params) {
    q.j(params, "coordinates");
    this.F0.invoke(params);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\layout\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */