package androidx.compose.ui.layout;

import androidx.compose.ui.e;
import dk.q;
import kotlin.jvm.internal.q;
import o1.g0;
import o1.j0;
import o1.l0;

public final class b {
  public static final e a(e parame, q<? super l0, ? super g0, ? super k2.b, ? extends j0> paramq) {
    q.j(parame, "<this>");
    q.j(paramq, "measure");
    return parame.then((e)new LayoutElement(paramq));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\layout\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */