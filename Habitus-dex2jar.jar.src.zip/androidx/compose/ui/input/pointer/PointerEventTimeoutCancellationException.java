package androidx.compose.ui.input.pointer;

import java.util.concurrent.CancellationException;

public final class PointerEventTimeoutCancellationException extends CancellationException {
  static {
  
  }
  
  public PointerEventTimeoutCancellationException(long paramLong) {
    super(stringBuilder.toString());
  }
  
  public Throwable fillInStackTrace() {
    setStackTrace(new StackTraceElement[0]);
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\input\pointer\PointerEventTimeoutCancellationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */