package androidx.compose.ui.input.pointer;

import androidx.compose.ui.e;
import dk.p;
import java.util.Arrays;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import l1.l0;
import l1.w0;
import q1.u0;
import rj.v;
import vj.d;

public final class SuspendPointerInputElement extends u0<w0> {
  private final Object c;
  
  private final Object d;
  
  private final Object[] e;
  
  private final p<l0, d<? super v>, Object> f;
  
  public SuspendPointerInputElement(Object paramObject1, Object paramObject2, Object[] paramArrayOfObject, p<? super l0, ? super d<? super v>, ? extends Object> paramp) {
    this.c = paramObject1;
    this.d = paramObject2;
    this.e = paramArrayOfObject;
    this.f = (p)paramp;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SuspendPointerInputElement))
      return false; 
    Object object = this.c;
    paramObject = paramObject;
    if (!q.e(object, ((SuspendPointerInputElement)paramObject).c))
      return false; 
    if (!q.e(this.d, ((SuspendPointerInputElement)paramObject).d))
      return false; 
    object = this.e;
    if (object != null) {
      paramObject = ((SuspendPointerInputElement)paramObject).e;
      if (paramObject == null)
        return false; 
      if (!Arrays.equals((Object[])object, (Object[])paramObject))
        return false; 
    } else if (((SuspendPointerInputElement)paramObject).e != null) {
      return false;
    } 
    return true;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    Object object = this.c;
    int i = 0;
    if (object != null) {
      b1 = object.hashCode();
    } else {
      b1 = 0;
    } 
    object = this.d;
    if (object != null) {
      b2 = object.hashCode();
    } else {
      b2 = 0;
    } 
    object = this.e;
    if (object != null)
      i = Arrays.hashCode((Object[])object); 
    return (b1 * 31 + b2) * 31 + i;
  }
  
  public w0 s() {
    return new w0(this.f);
  }
  
  public void t(w0 paramw0) {
    q.j(paramw0, "node");
    paramw0.F1(this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\input\pointer\SuspendPointerInputElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */