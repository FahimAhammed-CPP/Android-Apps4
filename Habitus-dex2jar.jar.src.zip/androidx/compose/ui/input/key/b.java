package androidx.compose.ui.input.key;

import android.view.KeyEvent;
import androidx.compose.ui.e;
import dk.l;
import j1.e;
import kotlin.jvm.internal.q;

final class b extends e.c implements e {
  private l<? super j1.b, Boolean> F0;
  
  private l<? super j1.b, Boolean> G0;
  
  public b(l<? super j1.b, Boolean> paraml1, l<? super j1.b, Boolean> paraml2) {
    this.F0 = paraml1;
    this.G0 = paraml2;
  }
  
  public final void A1(l<? super j1.b, Boolean> paraml) {
    this.F0 = paraml;
  }
  
  public final void B1(l<? super j1.b, Boolean> paraml) {
    this.G0 = paraml;
  }
  
  public boolean e0(KeyEvent paramKeyEvent) {
    q.j(paramKeyEvent, "event");
    l<? super j1.b, Boolean> l1 = this.G0;
    return (l1 != null) ? ((Boolean)l1.invoke(j1.b.a(paramKeyEvent))).booleanValue() : false;
  }
  
  public boolean p0(KeyEvent paramKeyEvent) {
    q.j(paramKeyEvent, "event");
    l<? super j1.b, Boolean> l1 = this.F0;
    return (l1 != null) ? ((Boolean)l1.invoke(j1.b.a(paramKeyEvent))).booleanValue() : false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\input\key\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */