package androidx.compose.ui.input.nestedscroll;

import androidx.compose.ui.e;
import k1.b;
import k1.c;
import k1.d;
import kotlin.jvm.internal.q;
import q1.u0;

final class NestedScrollElement extends u0<d> {
  private final b c;
  
  private final c d;
  
  public NestedScrollElement(b paramb, c paramc) {
    this.c = paramb;
    this.d = paramc;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof NestedScrollElement))
      return false; 
    paramObject = paramObject;
    return !q.e(((NestedScrollElement)paramObject).c, this.c) ? false : (!!q.e(((NestedScrollElement)paramObject).d, this.d));
  }
  
  public int hashCode() {
    byte b1;
    int i = this.c.hashCode();
    c c1 = this.d;
    if (c1 != null) {
      b1 = c1.hashCode();
    } else {
      b1 = 0;
    } 
    return i * 31 + b1;
  }
  
  public d s() {
    return new d(this.c, this.d);
  }
  
  public void t(d paramd) {
    q.j(paramd, "node");
    paramd.H1(this.c, this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\input\nestedscroll\NestedScrollElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */