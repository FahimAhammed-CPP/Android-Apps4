package androidx.compose.ui.input.nestedscroll;

import androidx.compose.ui.e;
import k1.b;
import k1.c;
import kotlin.jvm.internal.q;

public final class a {
  public static final e a(e parame, b paramb, c paramc) {
    q.j(parame, "<this>");
    q.j(paramb, "connection");
    return parame.then((e)new NestedScrollElement(paramb, paramc));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\input\nestedscroll\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */