package androidx.compose.ui.input.rotary;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import n1.b;

public final class a {
  public static final e a(e parame, l<? super b, Boolean> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "onRotaryScrollEvent");
    return parame.then((e)new RotaryInputElement(paraml, null));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\input\rotary\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */