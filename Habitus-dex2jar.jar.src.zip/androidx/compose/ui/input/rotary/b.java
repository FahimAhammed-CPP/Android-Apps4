package androidx.compose.ui.input.rotary;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import n1.a;

final class b extends e.c implements a {
  private l<? super n1.b, Boolean> F0;
  
  private l<? super n1.b, Boolean> G0;
  
  public b(l<? super n1.b, Boolean> paraml1, l<? super n1.b, Boolean> paraml2) {
    this.F0 = paraml1;
    this.G0 = paraml2;
  }
  
  public final void A1(l<? super n1.b, Boolean> paraml) {
    this.F0 = paraml;
  }
  
  public final void B1(l<? super n1.b, Boolean> paraml) {
    this.G0 = paraml;
  }
  
  public boolean D(n1.b paramb) {
    q.j(paramb, "event");
    l<? super n1.b, Boolean> l1 = this.F0;
    return (l1 != null) ? ((Boolean)l1.invoke(paramb)).booleanValue() : false;
  }
  
  public boolean k0(n1.b paramb) {
    q.j(paramb, "event");
    l<? super n1.b, Boolean> l1 = this.G0;
    return (l1 != null) ? ((Boolean)l1.invoke(paramb)).booleanValue() : false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\input\rotary\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */