package androidx.compose.ui.input.rotary;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import n1.b;
import q1.u0;

final class RotaryInputElement extends u0<b> {
  private final l<b, Boolean> c;
  
  private final l<b, Boolean> d;
  
  public RotaryInputElement(l<? super b, Boolean> paraml1, l<? super b, Boolean> paraml2) {
    this.c = (l)paraml1;
    this.d = (l)paraml2;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof RotaryInputElement))
      return false; 
    paramObject = paramObject;
    return !q.e(this.c, ((RotaryInputElement)paramObject).c) ? false : (!!q.e(this.d, ((RotaryInputElement)paramObject).d));
  }
  
  public int hashCode() {
    int i;
    l<b, Boolean> l1 = this.c;
    int j = 0;
    if (l1 == null) {
      i = 0;
    } else {
      i = l1.hashCode();
    } 
    l1 = this.d;
    if (l1 != null)
      j = l1.hashCode(); 
    return i * 31 + j;
  }
  
  public b s() {
    return new b(this.c, this.d);
  }
  
  public void t(b paramb) {
    q.j(paramb, "node");
    paramb.A1(this.c);
    paramb.B1(this.d);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RotaryInputElement(onRotaryScrollEvent=");
    stringBuilder.append(this.c);
    stringBuilder.append(", onPreRotaryScrollEvent=");
    stringBuilder.append(this.d);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\input\rotary\RotaryInputElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */