package androidx.compose.ui.graphics;

import androidx.compose.ui.e;
import b1.m4;
import b1.p1;
import b1.r4;
import dk.l;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q1.d0;
import q1.e0;
import q1.j;
import q1.k;
import q1.x0;
import q1.z0;
import rj.v;

final class f extends e.c implements e0 {
  private float F0;
  
  private float G0;
  
  private float H0;
  
  private float I0;
  
  private float J0;
  
  private float K0;
  
  private float L0;
  
  private float M0;
  
  private float N0;
  
  private float O0;
  
  private long P0;
  
  private r4 Q0;
  
  private boolean R0;
  
  private long S0;
  
  private long T0;
  
  private int U0;
  
  private l<? super d, v> V0;
  
  private f(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, long paramLong1, r4 paramr4, boolean paramBoolean, m4 paramm4, long paramLong2, long paramLong3, int paramInt) {
    this.F0 = paramFloat1;
    this.G0 = paramFloat2;
    this.H0 = paramFloat3;
    this.I0 = paramFloat4;
    this.J0 = paramFloat5;
    this.K0 = paramFloat6;
    this.L0 = paramFloat7;
    this.M0 = paramFloat8;
    this.N0 = paramFloat9;
    this.O0 = paramFloat10;
    this.P0 = paramLong1;
    this.Q0 = paramr4;
    this.R0 = paramBoolean;
    this.S0 = paramLong2;
    this.T0 = paramLong3;
    this.U0 = paramInt;
    this.V0 = new a(this);
  }
  
  public final float B1() {
    return this.H0;
  }
  
  public final long C1() {
    return this.S0;
  }
  
  public final float D0() {
    return this.J0;
  }
  
  public final boolean D1() {
    return this.R0;
  }
  
  public final int E1() {
    return this.U0;
  }
  
  public final float F() {
    return this.M0;
  }
  
  public final m4 F1() {
    return null;
  }
  
  public final float G1() {
    return this.K0;
  }
  
  public final float H() {
    return this.N0;
  }
  
  public final r4 H1() {
    return this.Q0;
  }
  
  public final long I1() {
    return this.T0;
  }
  
  public final float J0() {
    return this.I0;
  }
  
  public final void J1() {
    x0 x0 = k.h((j)this, z0.a(2)).R1();
    if (x0 != null)
      x0.B2(this.V0, true); 
  }
  
  public final float K0() {
    return this.L0;
  }
  
  public final void P(long paramLong) {
    this.S0 = paramLong;
  }
  
  public final float T() {
    return this.O0;
  }
  
  public final float U0() {
    return this.G0;
  }
  
  public final void V(boolean paramBoolean) {
    this.R0 = paramBoolean;
  }
  
  public final long W() {
    return this.P0;
  }
  
  public final void Z(long paramLong) {
    this.P0 = paramLong;
  }
  
  public final void a0(long paramLong) {
    this.T0 = paramLong;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    y0 y0 = paramg0.Q(paramLong);
    return k0.b(paraml0, y0.N0(), y0.p0(), null, new b(y0, this), 4, null);
  }
  
  public final float f0() {
    return this.F0;
  }
  
  public boolean f1() {
    return false;
  }
  
  public final void g(float paramFloat) {
    this.H0 = paramFloat;
  }
  
  public final void g0(float paramFloat) {
    this.K0 = paramFloat;
  }
  
  public final void h(float paramFloat) {
    this.J0 = paramFloat;
  }
  
  public final void i(int paramInt) {
    this.U0 = paramInt;
  }
  
  public final void k(float paramFloat) {
    this.F0 = paramFloat;
  }
  
  public final void l(float paramFloat) {
    this.O0 = paramFloat;
  }
  
  public final void m(m4 paramm4) {}
  
  public final void n(float paramFloat) {
    this.L0 = paramFloat;
  }
  
  public final void o0(r4 paramr4) {
    q.j(paramr4, "<set-?>");
    this.Q0 = paramr4;
  }
  
  public final void q(float paramFloat) {
    this.M0 = paramFloat;
  }
  
  public final void s(float paramFloat) {
    this.N0 = paramFloat;
  }
  
  public final void t(float paramFloat) {
    this.G0 = paramFloat;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SimpleGraphicsLayerModifier(scaleX=");
    stringBuilder.append(this.F0);
    stringBuilder.append(", scaleY=");
    stringBuilder.append(this.G0);
    stringBuilder.append(", alpha = ");
    stringBuilder.append(this.H0);
    stringBuilder.append(", translationX=");
    stringBuilder.append(this.I0);
    stringBuilder.append(", translationY=");
    stringBuilder.append(this.J0);
    stringBuilder.append(", shadowElevation=");
    stringBuilder.append(this.K0);
    stringBuilder.append(", rotationX=");
    stringBuilder.append(this.L0);
    stringBuilder.append(", rotationY=");
    stringBuilder.append(this.M0);
    stringBuilder.append(", rotationZ=");
    stringBuilder.append(this.N0);
    stringBuilder.append(", cameraDistance=");
    stringBuilder.append(this.O0);
    stringBuilder.append(", transformOrigin=");
    stringBuilder.append(g.i(this.P0));
    stringBuilder.append(", shape=");
    stringBuilder.append(this.Q0);
    stringBuilder.append(", clip=");
    stringBuilder.append(this.R0);
    stringBuilder.append(", renderEffect=");
    stringBuilder.append((Object)null);
    stringBuilder.append(", ambientShadowColor=");
    stringBuilder.append(p1.x(this.S0));
    stringBuilder.append(", spotShadowColor=");
    stringBuilder.append(p1.x(this.T0));
    stringBuilder.append(", compositingStrategy=");
    stringBuilder.append(b.g(this.U0));
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public final void y(float paramFloat) {
    this.I0 = paramFloat;
  }
  
  static final class a extends r implements l<d, v> {
    a(f param1f) {
      super(1);
    }
    
    public final void a(d param1d) {
      q.j(param1d, "$this$null");
      param1d.k(this.s0.f0());
      param1d.t(this.s0.U0());
      param1d.g(this.s0.B1());
      param1d.y(this.s0.J0());
      param1d.h(this.s0.D0());
      param1d.g0(this.s0.G1());
      param1d.n(this.s0.K0());
      param1d.q(this.s0.F());
      param1d.s(this.s0.H());
      param1d.l(this.s0.T());
      param1d.Z(this.s0.W());
      param1d.o0(this.s0.H1());
      param1d.V(this.s0.D1());
      this.s0.F1();
      param1d.m(null);
      param1d.P(this.s0.C1());
      param1d.a0(this.s0.I1());
      param1d.i(this.s0.E1());
    }
  }
  
  static final class b extends r implements l<y0.a, v> {
    b(y0 param1y0, f param1f) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      y0.a.z(param1a, this.s0, 0, 0, 0.0F, f.A1(this.t0), 4, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\graphics\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */