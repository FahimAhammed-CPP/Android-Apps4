package androidx.compose.ui.graphics;

import b1.y4;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.j;
import o.y;

public final class g {
  public static final a b = new a(null);
  
  private static final long c = y4.a(0.5F, 0.5F);
  
  private final long a;
  
  public static long c(long paramLong) {
    return paramLong;
  }
  
  public static boolean d(long paramLong, Object paramObject) {
    return !(paramObject instanceof g) ? false : (!(paramLong != ((g)paramObject).j()));
  }
  
  public static final boolean e(long paramLong1, long paramLong2) {
    return (paramLong1 == paramLong2);
  }
  
  public static final float f(long paramLong) {
    j j = j.a;
    return Float.intBitsToFloat((int)(paramLong >> 32L));
  }
  
  public static final float g(long paramLong) {
    j j = j.a;
    return Float.intBitsToFloat((int)(paramLong & 0xFFFFFFFFL));
  }
  
  public static int h(long paramLong) {
    return y.a(paramLong);
  }
  
  public static String i(long paramLong) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TransformOrigin(packedValue=");
    stringBuilder.append(paramLong);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public boolean equals(Object paramObject) {
    return d(this.a, paramObject);
  }
  
  public int hashCode() {
    return h(this.a);
  }
  
  public String toString() {
    return i(this.a);
  }
  
  public static final class a {
    private a() {}
    
    public final long a() {
      return g.a();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\graphics\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */