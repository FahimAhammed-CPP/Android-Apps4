package androidx.compose.ui.graphics;

import a1.l;
import b1.l4;
import b1.m4;
import b1.r4;
import b1.s3;
import k2.d;
import k2.g;
import kotlin.jvm.internal.q;

public final class e implements d {
  private float A0;
  
  private float B0;
  
  private float C0;
  
  private float D0 = 8.0F;
  
  private long E0 = g.b.a();
  
  private r4 F0 = l4.a();
  
  private boolean G0;
  
  private int H0 = b.a.a();
  
  private long I0 = l.b.a();
  
  private k2.e J0 = g.b(1.0F, 0.0F, 2, null);
  
  private float s0 = 1.0F;
  
  private float t0 = 1.0F;
  
  private float u0 = 1.0F;
  
  private float v0;
  
  private float w0;
  
  private float x0;
  
  private long y0 = s3.a();
  
  private long z0 = s3.a();
  
  public float C0() {
    return this.J0.C0();
  }
  
  public float D0() {
    return this.w0;
  }
  
  public float F() {
    return this.B0;
  }
  
  public float H() {
    return this.C0;
  }
  
  public float J0() {
    return this.v0;
  }
  
  public float K0() {
    return this.A0;
  }
  
  public void P(long paramLong) {
    this.y0 = paramLong;
  }
  
  public float T() {
    return this.D0;
  }
  
  public float U0() {
    return this.t0;
  }
  
  public void V(boolean paramBoolean) {
    this.G0 = paramBoolean;
  }
  
  public long W() {
    return this.E0;
  }
  
  public void Z(long paramLong) {
    this.E0 = paramLong;
  }
  
  public void a0(long paramLong) {
    this.z0 = paramLong;
  }
  
  public long b() {
    return this.I0;
  }
  
  public float c() {
    return this.u0;
  }
  
  public long d() {
    return this.y0;
  }
  
  public boolean e() {
    return this.G0;
  }
  
  public int f() {
    return this.H0;
  }
  
  public float f0() {
    return this.s0;
  }
  
  public void g(float paramFloat) {
    this.u0 = paramFloat;
  }
  
  public void g0(float paramFloat) {
    this.x0 = paramFloat;
  }
  
  public float getDensity() {
    return this.J0.getDensity();
  }
  
  public void h(float paramFloat) {
    this.w0 = paramFloat;
  }
  
  public void i(int paramInt) {
    this.H0 = paramInt;
  }
  
  public m4 j() {
    return null;
  }
  
  public void k(float paramFloat) {
    this.s0 = paramFloat;
  }
  
  public void l(float paramFloat) {
    this.D0 = paramFloat;
  }
  
  public void m(m4 paramm4) {}
  
  public void n(float paramFloat) {
    this.A0 = paramFloat;
  }
  
  public float o() {
    return this.x0;
  }
  
  public void o0(r4 paramr4) {
    q.j(paramr4, "<set-?>");
    this.F0 = paramr4;
  }
  
  public r4 p() {
    return this.F0;
  }
  
  public void q(float paramFloat) {
    this.B0 = paramFloat;
  }
  
  public long r() {
    return this.z0;
  }
  
  public void s(float paramFloat) {
    this.C0 = paramFloat;
  }
  
  public void t(float paramFloat) {
    this.t0 = paramFloat;
  }
  
  public final void u() {
    k(1.0F);
    t(1.0F);
    g(1.0F);
    y(0.0F);
    h(0.0F);
    g0(0.0F);
    P(s3.a());
    a0(s3.a());
    n(0.0F);
    q(0.0F);
    s(0.0F);
    l(8.0F);
    Z(g.b.a());
    o0(l4.a());
    V(false);
    m(null);
    i(b.a.a());
    x(l.b.a());
  }
  
  public final void w(k2.e parame) {
    q.j(parame, "<set-?>");
    this.J0 = parame;
  }
  
  public void x(long paramLong) {
    this.I0 = paramLong;
  }
  
  public void y(float paramFloat) {
    this.v0 = paramFloat;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\graphics\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */