package androidx.compose.ui.graphics;

import androidx.compose.ui.e;
import b1.m4;
import b1.p1;
import b1.r4;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q1.u0;

final class GraphicsLayerElement extends u0<f> {
  private final float c;
  
  private final float d;
  
  private final float e;
  
  private final float f;
  
  private final float g;
  
  private final float h;
  
  private final float i;
  
  private final float j;
  
  private final float k;
  
  private final float l;
  
  private final long m;
  
  private final r4 n;
  
  private final boolean o;
  
  private final long p;
  
  private final long q;
  
  private final int r;
  
  private GraphicsLayerElement(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, long paramLong1, r4 paramr4, boolean paramBoolean, m4 paramm4, long paramLong2, long paramLong3, int paramInt) {
    this.c = paramFloat1;
    this.d = paramFloat2;
    this.e = paramFloat3;
    this.f = paramFloat4;
    this.g = paramFloat5;
    this.h = paramFloat6;
    this.i = paramFloat7;
    this.j = paramFloat8;
    this.k = paramFloat9;
    this.l = paramFloat10;
    this.m = paramLong1;
    this.n = paramr4;
    this.o = paramBoolean;
    this.p = paramLong2;
    this.q = paramLong3;
    this.r = paramInt;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof GraphicsLayerElement))
      return false; 
    paramObject = paramObject;
    return (Float.compare(this.c, ((GraphicsLayerElement)paramObject).c) != 0) ? false : ((Float.compare(this.d, ((GraphicsLayerElement)paramObject).d) != 0) ? false : ((Float.compare(this.e, ((GraphicsLayerElement)paramObject).e) != 0) ? false : ((Float.compare(this.f, ((GraphicsLayerElement)paramObject).f) != 0) ? false : ((Float.compare(this.g, ((GraphicsLayerElement)paramObject).g) != 0) ? false : ((Float.compare(this.h, ((GraphicsLayerElement)paramObject).h) != 0) ? false : ((Float.compare(this.i, ((GraphicsLayerElement)paramObject).i) != 0) ? false : ((Float.compare(this.j, ((GraphicsLayerElement)paramObject).j) != 0) ? false : ((Float.compare(this.k, ((GraphicsLayerElement)paramObject).k) != 0) ? false : ((Float.compare(this.l, ((GraphicsLayerElement)paramObject).l) != 0) ? false : (!g.e(this.m, ((GraphicsLayerElement)paramObject).m) ? false : (!q.e(this.n, ((GraphicsLayerElement)paramObject).n) ? false : ((this.o != ((GraphicsLayerElement)paramObject).o) ? false : (!q.e(null, null) ? false : (!p1.q(this.p, ((GraphicsLayerElement)paramObject).p) ? false : (!p1.q(this.q, ((GraphicsLayerElement)paramObject).q) ? false : (!!b.e(this.r, ((GraphicsLayerElement)paramObject).r)))))))))))))))));
  }
  
  public int hashCode() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public f s() {
    return new f(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o, null, this.p, this.q, this.r, null);
  }
  
  public void t(f paramf) {
    q.j(paramf, "node");
    paramf.k(this.c);
    paramf.t(this.d);
    paramf.g(this.e);
    paramf.y(this.f);
    paramf.h(this.g);
    paramf.g0(this.h);
    paramf.n(this.i);
    paramf.q(this.j);
    paramf.s(this.k);
    paramf.l(this.l);
    paramf.Z(this.m);
    paramf.o0(this.n);
    paramf.V(this.o);
    paramf.m(null);
    paramf.P(this.p);
    paramf.a0(this.q);
    paramf.i(this.r);
    paramf.J1();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("GraphicsLayerElement(scaleX=");
    stringBuilder.append(this.c);
    stringBuilder.append(", scaleY=");
    stringBuilder.append(this.d);
    stringBuilder.append(", alpha=");
    stringBuilder.append(this.e);
    stringBuilder.append(", translationX=");
    stringBuilder.append(this.f);
    stringBuilder.append(", translationY=");
    stringBuilder.append(this.g);
    stringBuilder.append(", shadowElevation=");
    stringBuilder.append(this.h);
    stringBuilder.append(", rotationX=");
    stringBuilder.append(this.i);
    stringBuilder.append(", rotationY=");
    stringBuilder.append(this.j);
    stringBuilder.append(", rotationZ=");
    stringBuilder.append(this.k);
    stringBuilder.append(", cameraDistance=");
    stringBuilder.append(this.l);
    stringBuilder.append(", transformOrigin=");
    stringBuilder.append(g.i(this.m));
    stringBuilder.append(", shape=");
    stringBuilder.append(this.n);
    stringBuilder.append(", clip=");
    stringBuilder.append(this.o);
    stringBuilder.append(", renderEffect=");
    stringBuilder.append((Object)null);
    stringBuilder.append(", ambientShadowColor=");
    stringBuilder.append(p1.x(this.p));
    stringBuilder.append(", spotShadowColor=");
    stringBuilder.append(p1.x(this.q));
    stringBuilder.append(", compositingStrategy=");
    stringBuilder.append(b.g(this.r));
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\graphics\GraphicsLayerElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */