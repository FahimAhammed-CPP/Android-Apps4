package androidx.compose.ui.graphics;

import kotlin.jvm.internal.h;

public final class b {
  public static final a a = new a(null);
  
  private static final int b = d(0);
  
  private static final int c = d(1);
  
  private static final int d = d(2);
  
  public static int d(int paramInt) {
    return paramInt;
  }
  
  public static final boolean e(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  public static int f(int paramInt) {
    return paramInt;
  }
  
  public static String g(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CompositingStrategy(value=");
    stringBuilder.append(paramInt);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public static final class a {
    private a() {}
    
    public final int a() {
      return b.a();
    }
    
    public final int b() {
      return b.b();
    }
    
    public final int c() {
      return b.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\graphics\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */