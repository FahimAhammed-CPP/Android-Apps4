package androidx.compose.ui.graphics;

import b1.m4;
import b1.r4;
import k2.e;

public interface d extends e {
  float D0();
  
  float F();
  
  float H();
  
  float J0();
  
  float K0();
  
  void P(long paramLong);
  
  float T();
  
  float U0();
  
  void V(boolean paramBoolean);
  
  long W();
  
  void Z(long paramLong);
  
  void a0(long paramLong);
  
  long b();
  
  float f0();
  
  void g(float paramFloat);
  
  void g0(float paramFloat);
  
  void h(float paramFloat);
  
  void i(int paramInt);
  
  void k(float paramFloat);
  
  void l(float paramFloat);
  
  void m(m4 paramm4);
  
  void n(float paramFloat);
  
  void o0(r4 paramr4);
  
  void q(float paramFloat);
  
  void s(float paramFloat);
  
  void t(float paramFloat);
  
  void y(float paramFloat);
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\graphics\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */