package androidx.compose.ui.graphics;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q1.d0;
import q1.e0;
import q1.j;
import q1.k;
import q1.x0;
import q1.z0;
import rj.v;

final class a extends e.c implements e0 {
  private l<? super d, v> F0;
  
  public a(l<? super d, v> paraml) {
    this.F0 = paraml;
  }
  
  public final l<d, v> A1() {
    return (l)this.F0;
  }
  
  public final void B1() {
    x0 x0 = k.h((j)this, z0.a(2)).R1();
    if (x0 != null)
      x0.B2(this.F0, true); 
  }
  
  public final void C1(l<? super d, v> paraml) {
    q.j(paraml, "<set-?>");
    this.F0 = paraml;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    y0 y0 = paramg0.Q(paramLong);
    return k0.b(paraml0, y0.N0(), y0.p0(), null, new a(y0, this), 4, null);
  }
  
  public boolean f1() {
    return false;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("BlockGraphicsLayerModifier(block=");
    stringBuilder.append(this.F0);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(y0 param1y0, a param1a) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      y0.a.z(param1a, this.s0, 0, 0, 0.0F, this.t0.A1(), 4, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\graphics\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */