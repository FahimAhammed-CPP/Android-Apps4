package androidx.compose.ui.graphics;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import q1.u0;
import rj.v;

final class BlockGraphicsLayerElement extends u0<a> {
  private final l<d, v> c;
  
  public BlockGraphicsLayerElement(l<? super d, v> paraml) {
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof BlockGraphicsLayerElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((BlockGraphicsLayerElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public a s() {
    return new a(this.c);
  }
  
  public void t(a parama) {
    q.j(parama, "node");
    parama.C1(this.c);
    parama.B1();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("BlockGraphicsLayerElement(block=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\graphics\BlockGraphicsLayerElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */