package androidx.compose.ui.graphics;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.j1;
import b1.l4;
import b1.m4;
import b1.r4;
import b1.s3;
import dk.l;
import kotlin.jvm.internal.q;
import rj.v;

public final class c {
  public static final e a(e parame, l<? super d, v> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "block");
    return parame.then((e)new BlockGraphicsLayerElement(paraml));
  }
  
  public static final e b(e parame, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, long paramLong1, r4 paramr4, boolean paramBoolean, m4 paramm4, long paramLong2, long paramLong3, int paramInt) {
    q.j(parame, "$this$graphicsLayer");
    q.j(paramr4, "shape");
    return parame.then((e)new GraphicsLayerElement(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramLong1, paramr4, paramBoolean, paramm4, paramLong2, paramLong3, paramInt, null));
  }
  
  public static final e d(e parame) {
    q.j(parame, "<this>");
    e e1 = parame;
    if (j1.c())
      e1 = parame.then(c((e)e.a, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0L, null, false, null, 0L, 0L, 0, 131071, null)); 
    return e1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\graphics\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */