package androidx.compose.ui.node;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import m0.f;
import q1.a1;
import q1.c;
import q1.e0;
import q1.f0;
import q1.j0;
import q1.k;
import q1.o;
import q1.u0;
import q1.w0;
import q1.w1;
import q1.x;
import q1.x0;
import q1.z0;

public final class a {
  private final j0 a;
  
  private final x b;
  
  private x0 c;
  
  private final e.c d;
  
  private e.c e;
  
  private f<e.b> f;
  
  private f<e.b> g;
  
  private a h;
  
  public a(j0 paramj0) {
    this.a = paramj0;
    x x1 = new x(paramj0);
    this.b = x1;
    this.c = (x0)x1;
    w1 w1 = x1.G2();
    this.d = (e.c)w1;
    this.e = (e.c)w1;
  }
  
  private final void A(int paramInt, f<e.b> paramf1, f<e.b> paramf2, e.c paramc, boolean paramBoolean) {
    a a1 = j(paramc, paramInt, paramf1, paramf2, paramBoolean);
    w0.e(paramf1.s() - paramInt, paramf2.s() - paramInt, a1);
    B();
  }
  
  private final void B() {
    e.c c1 = this.d.e1();
    int i = 0;
    while (c1 != null && c1 != b.b()) {
      i |= c1.c1();
      c1.q1(i);
      c1 = c1.e1();
    } 
  }
  
  private final e.c D(e.c paramc) {
    boolean bool1;
    b.a a1 = b.b();
    boolean bool2 = true;
    if (paramc == a1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1) {
      e.c c1 = b.b().Y0();
      paramc = c1;
      if (c1 == null)
        paramc = this.d; 
      paramc.w1(null);
      b.b().s1(null);
      b.b().q1(-1);
      b.b().z1(null);
      if (paramc != b.b()) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      if (bool1)
        return paramc; 
      throw new IllegalStateException("trimChain did not update the head".toString());
    } 
    throw new IllegalStateException("trimChain called on already trimmed chain".toString());
  }
  
  private final void F(e.b paramb1, e.b paramb2, e.c paramc) {
    if (paramb1 instanceof u0 && paramb2 instanceof u0) {
      b.c((u0)paramb2, paramc);
      if (paramc.h1()) {
        a1.e(paramc);
        return;
      } 
      paramc.x1(true);
      return;
    } 
    if (paramc instanceof c) {
      ((c)paramc).F1(paramb2);
      if (paramc.h1()) {
        a1.e(paramc);
        return;
      } 
      paramc.x1(true);
      return;
    } 
    throw new IllegalStateException("Unknown Modifier.Node type".toString());
  }
  
  private final e.c g(e.b paramb, e.c paramc) {
    e.c c2;
    c c1;
    if (paramb instanceof u0) {
      c2 = ((u0)paramb).a();
      c2.u1(a1.h(c2));
    } else {
      c1 = new c((e.b)c2);
    } 
    if ((c1.h1() ^ true) != 0) {
      c1.t1(true);
      return r((e.c)c1, paramc);
    } 
    throw new IllegalStateException("A ModifierNodeElement cannot return an already attached node from create() ".toString());
  }
  
  private final e.c h(e.c paramc) {
    if (paramc.h1()) {
      a1.d(paramc);
      paramc.p1();
      paramc.j1();
    } 
    return w(paramc);
  }
  
  private final int i() {
    return this.e.X0();
  }
  
  private final a j(e.c paramc, int paramInt, f<e.b> paramf1, f<e.b> paramf2, boolean paramBoolean) {
    a a1;
    a a2 = this.h;
    if (a2 == null) {
      a1 = new a(this, paramc, paramInt, paramf1, paramf2, paramBoolean);
      this.h = a1;
      return a1;
    } 
    a2.g((e.c)a1);
    a2.h(paramInt);
    a2.f(paramf1);
    a2.e(paramf2);
    a2.i(paramBoolean);
    return a2;
  }
  
  private final e.c r(e.c paramc1, e.c paramc2) {
    e.c c1 = paramc2.Y0();
    if (c1 != null) {
      c1.w1(paramc1);
      paramc1.s1(c1);
    } 
    paramc2.s1(paramc1);
    paramc1.w1(paramc2);
    return paramc1;
  }
  
  private final e.c u() {
    boolean bool;
    if (this.e != b.b()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      e.c c1 = this.e;
      c1.w1(b.b());
      b.b().s1(c1);
      return b.b();
    } 
    throw new IllegalStateException("padChain called on already padded chain".toString());
  }
  
  private final void v(e.c paramc, x0 paramx0) {
    paramc = paramc.e1();
    while (paramc != null) {
      j0 j01;
      boolean bool;
      if (paramc == b.b()) {
        j01 = this.a.k0();
        if (j01 != null) {
          x0 x01 = j01.N();
        } else {
          j01 = null;
        } 
        paramx0.v2((x0)j01);
        this.c = paramx0;
        return;
      } 
      if ((z0.a(2) & j01.c1()) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        j01.z1(paramx0);
        e.c c1 = j01.e1();
      } 
    } 
  }
  
  private final e.c w(e.c paramc) {
    e.c c1 = paramc.Y0();
    e.c c2 = paramc.e1();
    if (c1 != null) {
      c1.w1(c2);
      paramc.s1(null);
    } 
    if (c2 != null) {
      c2.s1(c1);
      paramc.w1(null);
    } 
    q.g(c2);
    return c2;
  }
  
  public final void C() {
    f0 f0;
    x x1 = this.b;
    for (e.c c1 = this.d.e1(); c1 != null; c1 = c1.e1()) {
      e0 e0 = k.d(c1);
      if (e0 != null) {
        f0 f01;
        if (c1.Z0() != null) {
          x0 x01 = c1.Z0();
          q.h(x01, "null cannot be cast to non-null type androidx.compose.ui.node.LayoutModifierNodeCoordinator");
          f0 f02 = (f0)x01;
          e0 e01 = f02.I2();
          f02.K2(e0);
          f01 = f02;
          if (e01 != c1) {
            f02.h2();
            f01 = f02;
          } 
        } else {
          f01 = new f0(this.a, (e0)f01);
          c1.z1((x0)f01);
        } 
        x1.v2((x0)f01);
        f01.u2((x0)x1);
        f0 = f01;
      } else {
        c1.z1((x0)f0);
      } 
    } 
    j0 j01 = this.a.k0();
    if (j01 != null) {
      x0 x01 = j01.N();
    } else {
      j01 = null;
    } 
    f0.v2((x0)j01);
    this.c = (x0)f0;
  }
  
  public final void E(e parame) {
    // Byte code:
    //   0: aload_1
    //   1: ldc_w 'm'
    //   4: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   7: aload_0
    //   8: invokespecial u : ()Landroidx/compose/ui/e$c;
    //   11: astore #8
    //   13: aload_0
    //   14: getfield f : Lm0/f;
    //   17: astore #6
    //   19: iconst_0
    //   20: istore #4
    //   22: iconst_0
    //   23: istore_3
    //   24: aload #6
    //   26: ifnull -> 38
    //   29: aload #6
    //   31: invokevirtual s : ()I
    //   34: istore_2
    //   35: goto -> 40
    //   38: iconst_0
    //   39: istore_2
    //   40: aload_0
    //   41: getfield g : Lm0/f;
    //   44: astore #9
    //   46: aload #9
    //   48: astore #7
    //   50: aload #9
    //   52: ifnonnull -> 70
    //   55: new m0/f
    //   58: dup
    //   59: bipush #16
    //   61: anewarray androidx/compose/ui/e$b
    //   64: iconst_0
    //   65: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   68: astore #7
    //   70: aload_1
    //   71: aload #7
    //   73: invokestatic a : (Landroidx/compose/ui/e;Lm0/f;)Lm0/f;
    //   76: astore #10
    //   78: aload #10
    //   80: invokevirtual s : ()I
    //   83: istore #5
    //   85: aconst_null
    //   86: astore #9
    //   88: iload #5
    //   90: iload_2
    //   91: if_icmpne -> 283
    //   94: aload #8
    //   96: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   99: astore_1
    //   100: iconst_0
    //   101: istore_3
    //   102: aload_1
    //   103: astore #7
    //   105: aload_1
    //   106: ifnull -> 213
    //   109: aload_1
    //   110: astore #7
    //   112: iload_3
    //   113: iload_2
    //   114: if_icmpge -> 213
    //   117: aload #6
    //   119: ifnull -> 199
    //   122: aload #6
    //   124: invokevirtual r : ()[Ljava/lang/Object;
    //   127: iload_3
    //   128: aaload
    //   129: checkcast androidx/compose/ui/e$b
    //   132: astore #7
    //   134: aload #10
    //   136: invokevirtual r : ()[Ljava/lang/Object;
    //   139: iload_3
    //   140: aaload
    //   141: checkcast androidx/compose/ui/e$b
    //   144: astore #11
    //   146: aload #7
    //   148: aload #11
    //   150: invokestatic d : (Landroidx/compose/ui/e$b;Landroidx/compose/ui/e$b;)I
    //   153: istore #5
    //   155: iload #5
    //   157: ifeq -> 190
    //   160: iload #5
    //   162: iconst_1
    //   163: if_icmpeq -> 169
    //   166: goto -> 178
    //   169: aload_0
    //   170: aload #7
    //   172: aload #11
    //   174: aload_1
    //   175: invokespecial F : (Landroidx/compose/ui/e$b;Landroidx/compose/ui/e$b;Landroidx/compose/ui/e$c;)V
    //   178: aload_1
    //   179: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   182: astore_1
    //   183: iload_3
    //   184: iconst_1
    //   185: iadd
    //   186: istore_3
    //   187: goto -> 102
    //   190: aload_1
    //   191: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   194: astore #7
    //   196: goto -> 213
    //   199: new java/lang/IllegalStateException
    //   202: dup
    //   203: ldc_w 'expected prior modifier list to be non-empty'
    //   206: invokevirtual toString : ()Ljava/lang/String;
    //   209: invokespecial <init> : (Ljava/lang/String;)V
    //   212: athrow
    //   213: aload #6
    //   215: astore_1
    //   216: iload_3
    //   217: iload_2
    //   218: if_icmpge -> 498
    //   221: aload #6
    //   223: ifnull -> 269
    //   226: aload #7
    //   228: ifnull -> 255
    //   231: aload_0
    //   232: iload_3
    //   233: aload #6
    //   235: aload #10
    //   237: aload #7
    //   239: aload_0
    //   240: getfield a : Lq1/j0;
    //   243: invokevirtual H0 : ()Z
    //   246: invokespecial A : (ILm0/f;Lm0/f;Landroidx/compose/ui/e$c;Z)V
    //   249: aload #6
    //   251: astore_1
    //   252: goto -> 495
    //   255: new java/lang/IllegalStateException
    //   258: dup
    //   259: ldc_w 'structuralUpdate requires a non-null tail'
    //   262: invokevirtual toString : ()Ljava/lang/String;
    //   265: invokespecial <init> : (Ljava/lang/String;)V
    //   268: athrow
    //   269: new java/lang/IllegalStateException
    //   272: dup
    //   273: ldc_w 'expected prior modifier list to be non-empty'
    //   276: invokevirtual toString : ()Ljava/lang/String;
    //   279: invokespecial <init> : (Ljava/lang/String;)V
    //   282: athrow
    //   283: aload_0
    //   284: getfield a : Lq1/j0;
    //   287: invokevirtual H0 : ()Z
    //   290: ifne -> 344
    //   293: iload_2
    //   294: ifne -> 344
    //   297: aload #8
    //   299: astore_1
    //   300: iload_3
    //   301: istore_2
    //   302: iload_2
    //   303: aload #10
    //   305: invokevirtual s : ()I
    //   308: if_icmpge -> 334
    //   311: aload_0
    //   312: aload #10
    //   314: invokevirtual r : ()[Ljava/lang/Object;
    //   317: iload_2
    //   318: aaload
    //   319: checkcast androidx/compose/ui/e$b
    //   322: aload_1
    //   323: invokespecial g : (Landroidx/compose/ui/e$b;Landroidx/compose/ui/e$c;)Landroidx/compose/ui/e$c;
    //   326: astore_1
    //   327: iload_2
    //   328: iconst_1
    //   329: iadd
    //   330: istore_2
    //   331: goto -> 302
    //   334: aload_0
    //   335: invokespecial B : ()V
    //   338: aload #6
    //   340: astore_1
    //   341: goto -> 495
    //   344: aload #10
    //   346: invokevirtual s : ()I
    //   349: ifne -> 456
    //   352: aload #6
    //   354: ifnull -> 442
    //   357: aload #8
    //   359: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   362: astore_1
    //   363: iconst_0
    //   364: istore_2
    //   365: aload_1
    //   366: ifnull -> 394
    //   369: iload_2
    //   370: aload #6
    //   372: invokevirtual s : ()I
    //   375: if_icmpge -> 394
    //   378: aload_0
    //   379: aload_1
    //   380: invokespecial h : (Landroidx/compose/ui/e$c;)Landroidx/compose/ui/e$c;
    //   383: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   386: astore_1
    //   387: iload_2
    //   388: iconst_1
    //   389: iadd
    //   390: istore_2
    //   391: goto -> 365
    //   394: aload_0
    //   395: getfield b : Lq1/x;
    //   398: astore #7
    //   400: aload_0
    //   401: getfield a : Lq1/j0;
    //   404: invokevirtual k0 : ()Lq1/j0;
    //   407: astore_1
    //   408: aload_1
    //   409: ifnull -> 420
    //   412: aload_1
    //   413: invokevirtual N : ()Lq1/x0;
    //   416: astore_1
    //   417: goto -> 422
    //   420: aconst_null
    //   421: astore_1
    //   422: aload #7
    //   424: aload_1
    //   425: invokevirtual v2 : (Lq1/x0;)V
    //   428: aload_0
    //   429: aload_0
    //   430: getfield b : Lq1/x;
    //   433: putfield c : Lq1/x0;
    //   436: aload #6
    //   438: astore_1
    //   439: goto -> 498
    //   442: new java/lang/IllegalStateException
    //   445: dup
    //   446: ldc_w 'expected prior modifier list to be non-empty'
    //   449: invokevirtual toString : ()Ljava/lang/String;
    //   452: invokespecial <init> : (Ljava/lang/String;)V
    //   455: athrow
    //   456: aload #6
    //   458: astore_1
    //   459: aload #6
    //   461: ifnonnull -> 478
    //   464: new m0/f
    //   467: dup
    //   468: bipush #16
    //   470: anewarray androidx/compose/ui/e$b
    //   473: iconst_0
    //   474: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   477: astore_1
    //   478: aload_0
    //   479: iconst_0
    //   480: aload_1
    //   481: aload #10
    //   483: aload #8
    //   485: aload_0
    //   486: getfield a : Lq1/j0;
    //   489: invokevirtual H0 : ()Z
    //   492: invokespecial A : (ILm0/f;Lm0/f;Landroidx/compose/ui/e$c;Z)V
    //   495: iconst_1
    //   496: istore #4
    //   498: aload_0
    //   499: aload #10
    //   501: putfield f : Lm0/f;
    //   504: aload #9
    //   506: astore #6
    //   508: aload_1
    //   509: ifnull -> 519
    //   512: aload_1
    //   513: invokevirtual k : ()V
    //   516: aload_1
    //   517: astore #6
    //   519: aload_0
    //   520: aload #6
    //   522: putfield g : Lm0/f;
    //   525: aload_0
    //   526: aload_0
    //   527: aload #8
    //   529: invokespecial D : (Landroidx/compose/ui/e$c;)Landroidx/compose/ui/e$c;
    //   532: putfield e : Landroidx/compose/ui/e$c;
    //   535: iload #4
    //   537: ifeq -> 544
    //   540: aload_0
    //   541: invokevirtual C : ()V
    //   544: return
  }
  
  public final e.c k() {
    return this.e;
  }
  
  public final x l() {
    return this.b;
  }
  
  public final j0 m() {
    return this.a;
  }
  
  public final x0 n() {
    return this.c;
  }
  
  public final e.c o() {
    return this.d;
  }
  
  public final boolean p(int paramInt) {
    return ((paramInt & i()) != 0);
  }
  
  public final boolean q(int paramInt) {
    return ((paramInt & i()) != 0);
  }
  
  public final void s() {
    for (e.c c1 = k(); c1 != null; c1 = c1.Y0())
      c1.i1(); 
  }
  
  public final void t() {
    for (e.c c1 = o(); c1 != null; c1 = c1.e1()) {
      if (c1.h1())
        c1.j1(); 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    if (this.e == this.d) {
      stringBuilder.append("]");
    } else {
      for (e.c c1 = k(); c1 != null && c1 != o(); c1 = c1.Y0()) {
        stringBuilder.append(String.valueOf(c1));
        if (c1.Y0() == this.d) {
          stringBuilder.append("]");
          break;
        } 
        stringBuilder.append(",");
      } 
    } 
    String str = stringBuilder.toString();
    q.i(str, "StringBuilder().apply(builderAction).toString()");
    return str;
  }
  
  public final void x() {
    for (e.c c1 = o(); c1 != null; c1 = c1.e1()) {
      if (c1.h1())
        c1.n1(); 
    } 
    f<e.b> f1 = this.f;
    if (f1 != null) {
      int i = f1.s();
      if (i > 0) {
        int k;
        Object[] arrayOfObject = f1.r();
        int j = 0;
        do {
          e.b b = (e.b)arrayOfObject[j];
          if (b instanceof androidx.compose.ui.input.pointer.SuspendPointerInputElement)
            f1.E(j, new ForceUpdateElement((u0)b)); 
          k = j + 1;
          j = k;
        } while (k < i);
      } 
    } 
    z();
    t();
  }
  
  public final void y() {
    for (e.c c1 = k(); c1 != null; c1 = c1.Y0()) {
      c1.o1();
      if (c1.b1())
        a1.a(c1); 
      if (c1.g1())
        a1.e(c1); 
      c1.t1(false);
      c1.x1(false);
    } 
  }
  
  public final void z() {
    for (e.c c1 = o(); c1 != null; c1 = c1.e1()) {
      if (c1.h1())
        c1.p1(); 
    } 
  }
  
  private final class a implements o {
    private e.c a;
    
    private int b;
    
    private f<e.b> c;
    
    private f<e.b> d;
    
    private boolean e;
    
    public a(a this$0, e.c param1c, int param1Int, f<e.b> param1f1, f<e.b> param1f2, boolean param1Boolean) {
      this.a = param1c;
      this.b = param1Int;
      this.c = param1f1;
      this.d = param1f2;
      this.e = param1Boolean;
    }
    
    public void a(int param1Int1, int param1Int2) {
      e.c c1 = this.a.Y0();
      q.g(c1);
      a.d(this.f);
      if ((z0.a(2) & c1.c1()) != 0) {
        param1Int1 = 1;
      } else {
        param1Int1 = 0;
      } 
      if (param1Int1 != 0) {
        x0 x02 = c1.Z0();
        q.g(x02);
        x0 x01 = x02.S1();
        x02 = x02.R1();
        q.g(x02);
        if (x01 != null)
          x01.u2(x02); 
        x02.v2(x01);
        a.e(this.f, this.a, x02);
      } 
      this.a = a.b(this.f, c1);
    }
    
    public boolean b(int param1Int1, int param1Int2) {
      f<e.b> f1 = this.c;
      int i = this.b;
      e.b b = (e.b)f1.r()[i + param1Int1];
      f<e.b> f2 = this.d;
      param1Int1 = this.b;
      return (b.d(b, (e.b)f2.r()[param1Int1 + param1Int2]) != 0);
    }
    
    public void c(int param1Int) {
      int i = this.b;
      e.c c1 = this.a;
      this.a = a.a(this.f, (e.b)this.d.r()[i + param1Int], c1);
      a.d(this.f);
      if (this.e) {
        c1 = this.a.Y0();
        q.g(c1);
        x0 x0 = c1.Z0();
        q.g(x0);
        e0 e0 = k.d(this.a);
        if (e0 != null) {
          f0 f0 = new f0(this.f.m(), e0);
          this.a.z1((x0)f0);
          a.e(this.f, this.a, (x0)f0);
          f0.v2(x0.S1());
          f0.u2(x0);
          x0.v2((x0)f0);
        } else {
          this.a.z1(x0);
        } 
        this.a.i1();
        this.a.o1();
        a1.a(this.a);
        return;
      } 
      this.a.t1(true);
    }
    
    public void d(int param1Int1, int param1Int2) {
      e.c c1 = this.a.Y0();
      q.g(c1);
      this.a = c1;
      f<e.b> f1 = this.c;
      int i = this.b;
      e.b b1 = (e.b)f1.r()[i + param1Int1];
      f<e.b> f2 = this.d;
      param1Int1 = this.b;
      e.b b2 = (e.b)f2.r()[param1Int1 + param1Int2];
      if (!q.e(b1, b2)) {
        a.f(this.f, b1, b2, this.a);
        a.d(this.f);
        return;
      } 
      a.d(this.f);
    }
    
    public final void e(f<e.b> param1f) {
      q.j(param1f, "<set-?>");
      this.d = param1f;
    }
    
    public final void f(f<e.b> param1f) {
      q.j(param1f, "<set-?>");
      this.c = param1f;
    }
    
    public final void g(e.c param1c) {
      q.j(param1c, "<set-?>");
      this.a = param1c;
    }
    
    public final void h(int param1Int) {
      this.b = param1Int;
    }
    
    public final void i(boolean param1Boolean) {
      this.e = param1Boolean;
    }
  }
  
  public static interface b {}
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\node\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */