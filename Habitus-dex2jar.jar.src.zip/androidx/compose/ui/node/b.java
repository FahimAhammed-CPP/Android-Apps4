package androidx.compose.ui.node;

import androidx.compose.ui.e;
import dk.l;
import ik.j;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import m0.f;
import q1.u0;

public final class b {
  private static final a a;
  
  static {
    a a1 = new a();
    a1.q1(-1);
    a = a1;
  }
  
  public static final int d(e.b paramb1, e.b paramb2) {
    q.j(paramb1, "prev");
    q.j(paramb2, "next");
    return q.e(paramb1, paramb2) ? 2 : ((w0.a.a(paramb1, paramb2) || (paramb1 instanceof ForceUpdateElement && w0.a.a(((ForceUpdateElement)paramb1).s(), paramb2))) ? 1 : 0);
  }
  
  private static final f<e.b> e(e parame, f<e.b> paramf) {
    f f1 = new f((Object[])new e[j.d(paramf.s(), 16)], 0);
    f1.d(parame);
    while (f1.w()) {
      androidx.compose.ui.a a1;
      parame = (e)f1.B(f1.s() - 1);
      if (parame instanceof androidx.compose.ui.a) {
        a1 = (androidx.compose.ui.a)parame;
        f1.d(a1.a());
        f1.d(a1.b());
        continue;
      } 
      if (a1 instanceof e.b) {
        paramf.d(a1);
        continue;
      } 
      a1.all(new b(paramf));
    } 
    return paramf;
  }
  
  private static final <T extends e.c> void f(u0<T> paramu0, e.c paramc) {
    q.h(paramc, "null cannot be cast to non-null type T of androidx.compose.ui.node.NodeChainKt.updateUnsafe");
    paramu0.b(paramc);
  }
  
  public static final class a extends e.c {
    public String toString() {
      return "<Head>";
    }
  }
  
  static final class b extends r implements l<e.b, Boolean> {
    b(f<e.b> param1f) {
      super(1);
    }
    
    public final Boolean a(e.b param1b) {
      q.j(param1b, "it");
      this.s0.d(param1b);
      return Boolean.TRUE;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\node\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */