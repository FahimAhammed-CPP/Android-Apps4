package androidx.compose.ui.node;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q1.u0;

final class ForceUpdateElement extends u0<e.c> {
  private final u0<?> c;
  
  public ForceUpdateElement(u0<?> paramu0) {
    this.c = paramu0;
  }
  
  public e.c a() {
    throw new IllegalStateException("Shouldn't be called");
  }
  
  public void b(e.c paramc) {
    q.j(paramc, "node");
    throw new IllegalStateException("Shouldn't be called");
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof ForceUpdateElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((ForceUpdateElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public final u0<?> s() {
    return this.c;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ForceUpdateElement(original=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\node\ForceUpdateElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */