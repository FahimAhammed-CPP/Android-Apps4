package androidx.compose.ui.platform;

import android.view.PointerIcon;
import android.view.View;
import kotlin.jvm.internal.q;
import l1.b;
import l1.c;
import l1.w;

final class d0 {
  public static final d0 a = new d0();
  
  public final void a(View paramView, w paramw) {
    PointerIcon pointerIcon;
    q.j(paramView, "view");
    if (paramw instanceof b) {
      pointerIcon = ((b)paramw).a();
    } else if (pointerIcon instanceof c) {
      pointerIcon = a0.a(paramView.getContext(), ((c)pointerIcon).a());
      q.i(pointerIcon, "getSystemIcon(view.context, icon.type)");
    } else {
      pointerIcon = a0.a(paramView.getContext(), 1000);
      q.i(pointerIcon, "getSystemIcon(\n         …DEFAULT\n                )");
    } 
    if (!q.e(b0.a(paramView), pointerIcon))
      c0.a(paramView, pointerIcon); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */