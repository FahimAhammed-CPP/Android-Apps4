package androidx.compose.ui.platform;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Trace;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStructure;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.AnimationUtils;
import android.view.autofill.AutofillValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import androidx.compose.ui.focus.FocusOwnerImpl;
import androidx.compose.ui.semantics.EmptySemanticsElement;
import androidx.core.view.accessibility.n0;
import androidx.core.view.m0;
import androidx.core.view.o0;
import androidx.lifecycle.f;
import androidx.lifecycle.p;
import androidx.lifecycle.s0;
import b1.e0;
import b1.h1;
import b1.i1;
import b1.x3;
import b2.q;
import c2.a0;
import c2.b0;
import c2.c0;
import c2.d0;
import c2.e0;
import c2.m0;
import dk.p;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import k2.r;
import kotlin.jvm.internal.m0;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l0.c3;
import l0.j1;
import l0.k3;
import l1.e0;
import l1.g0;
import l1.p0;
import l1.r0;
import l1.s0;
import l1.w;
import l1.z;
import o1.c1;
import o1.i0;
import q1.g1;
import q1.h1;
import q1.i1;
import q1.j0;
import q1.k1;
import q1.l0;
import q1.r1;
import q1.t0;
import q1.z0;
import rj.s;
import rj.v;
import u1.r;
import x0.b0;
import x0.d0;

@SuppressLint({"ViewConstructor", "VisibleForTests"})
public final class AndroidComposeView extends ViewGroup implements i1, q4, r0, f {
  public static final a J1 = new a(null);
  
  private static Class<?> K1;
  
  private static Method L1;
  
  private final androidx.compose.ui.e A0;
  
  private final r4<g1> A1;
  
  private final i1 B0;
  
  private final m0.f<dk.a<v>> B1;
  
  private final j0 C0;
  
  private final l C1;
  
  private final r1 D0;
  
  private final Runnable D1;
  
  private final r E0;
  
  private boolean E1;
  
  private final w F0;
  
  private final dk.a<v> F1;
  
  private final d0 G0;
  
  private final s0 G1;
  
  private final List<g1> H0;
  
  private boolean H1;
  
  private List<g1> I0;
  
  private final z I1;
  
  private boolean J0;
  
  private final l1.k K0;
  
  private final g0 L0;
  
  private dk.l<? super Configuration, v> M0;
  
  private final x0.e N0;
  
  private boolean O0;
  
  private final l P0;
  
  private final k Q0;
  
  private final k1 R0;
  
  private boolean S0;
  
  private q0 T0;
  
  private d1 U0;
  
  private k2.b V0;
  
  private boolean W0;
  
  private final t0 X0;
  
  private final f4 Y0;
  
  private long Z0;
  
  private final int[] a1;
  
  private final float[] b1;
  
  private final float[] c1;
  
  private long d1;
  
  private boolean e1;
  
  private long f1;
  
  private boolean g1;
  
  private final j1 h1;
  
  private final k3 i1;
  
  private dk.l<? super b, v> j1;
  
  private final ViewTreeObserver.OnGlobalLayoutListener k1;
  
  private final ViewTreeObserver.OnScrollChangedListener l1;
  
  private final ViewTreeObserver.OnTouchModeChangeListener m1;
  
  private final e0 n1;
  
  private final m0 o1;
  
  private final b2.k.a p1;
  
  private final j1 q1;
  
  private int r1;
  
  private long s0;
  
  private final j1 s1;
  
  private boolean t0;
  
  private final h1.a t1;
  
  private final l0 u0;
  
  private final i1.c u1;
  
  private k2.e v0;
  
  private final p1.f v1;
  
  private final EmptySemanticsElement w0;
  
  private final v3 w1;
  
  private final z0.j x0;
  
  private final vj.g x1;
  
  private final t4 y0;
  
  private MotionEvent y1;
  
  private final androidx.compose.ui.e z0;
  
  private long z1;
  
  public AndroidComposeView(Context paramContext, vj.g paramg) {
    super(paramContext);
    t0 t01;
    a1.f.a a1 = a1.f.b;
    this.s0 = a1.b();
    this.t0 = true;
    this.u0 = new l0(null, 1, null);
    this.v0 = k2.a.a(paramContext);
    EmptySemanticsElement emptySemanticsElement = EmptySemanticsElement.c;
    this.w0 = emptySemanticsElement;
    this.x0 = (z0.j)new FocusOwnerImpl(new f(this));
    this.y0 = new t4();
    androidx.compose.ui.e.a a2 = androidx.compose.ui.e.a;
    androidx.compose.ui.e e1 = androidx.compose.ui.input.key.a.a((androidx.compose.ui.e)a2, new g(this));
    this.z0 = e1;
    androidx.compose.ui.e e2 = androidx.compose.ui.input.rotary.a.a((androidx.compose.ui.e)a2, m.s0);
    this.A0 = e2;
    this.B0 = new i1();
    j0 j01 = new j0(false, 0, 3, null);
    j01.d((i0)c1.b);
    j01.g(getDensity());
    j01.m(a2.then((androidx.compose.ui.e)emptySemanticsElement).then(e2).then(getFocusOwner().i()).then(e1));
    this.C0 = j01;
    this.D0 = this;
    this.E0 = new r(getRoot());
    w w1 = new w(this);
    this.F0 = w1;
    this.G0 = new d0();
    this.H0 = new ArrayList<g1>();
    this.K0 = new l1.k();
    this.L0 = new g0(getRoot());
    this.M0 = e.s0;
    if (O()) {
      x0.e e3 = new x0.e((View)this, getAutofillTree());
    } else {
      emptySemanticsElement = null;
    } 
    this.N0 = (x0.e)emptySemanticsElement;
    this.P0 = new l(paramContext);
    this.Q0 = new k(paramContext);
    this.R0 = new k1(new n(this));
    this.X0 = new t0(getRoot());
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    q.i(viewConfiguration, "get(context)");
    this.Y0 = new p0(viewConfiguration);
    this.Z0 = k2.m.a(2147483647, 2147483647);
    this.a1 = new int[] { 0, 0 };
    this.b1 = x3.c(null, 1, null);
    this.c1 = x3.c(null, 1, null);
    this.d1 = -1L;
    this.f1 = a1.a();
    this.g1 = true;
    this.h1 = c3.j(null, null, 2, null);
    this.i1 = c3.d(new o(this));
    this.k1 = new o(this);
    this.l1 = new p(this);
    this.m1 = new q(this);
    this.n1 = new e0(new h(this));
    this.o1 = ((c2.a.a)getPlatformTextInputPluginRegistry().e((c0)c2.a.a).a()).b();
    this.p1 = new j0(paramContext);
    this.q1 = c3.i(q.a(paramContext), c3.m());
    Configuration configuration2 = paramContext.getResources().getConfiguration();
    q.i(configuration2, "context.resources.configuration");
    this.r1 = W(configuration2);
    Configuration configuration1 = paramContext.getResources().getConfiguration();
    q.i(configuration1, "context.resources.configuration");
    this.s1 = c3.j(h0.d(configuration1), null, 2, null);
    this.t1 = (h1.a)new h1.c((View)this);
    if (isInTouchMode()) {
      i = i1.a.b.b();
    } else {
      i = i1.a.b.a();
    } 
    this.u1 = new i1.c(i, new c(this), null);
    this.v1 = new p1.f(this);
    this.w1 = new k0((View)this);
    this.x1 = paramg;
    this.A1 = new r4<g1>();
    this.B1 = new m0.f((Object[])new dk.a[16], 0);
    this.C1 = new l(this);
    this.D1 = new r(this);
    this.F1 = new k(this);
    int i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      v0 v0 = new v0();
    } else {
      t01 = new t0();
    } 
    this.G1 = t01;
    setWillNotDraw(false);
    setFocusable(true);
    if (i >= 26)
      g0.a.a((View)this, 1, false); 
    setFocusableInTouchMode(true);
    setClipChildren(false);
    m0.s0((View)this, w1);
    dk.l<q4, v> l1 = q4.b0.a();
    if (l1 != null)
      l1.invoke(this); 
    getRoot().t(this);
    if (i >= 29)
      z.a.a((View)this); 
    this.I1 = new i(this);
  }
  
  private final void N(int paramInt, AccessibilityNodeInfo paramAccessibilityNodeInfo, String paramString) {
    if (q.e(paramString, this.F0.S())) {
      Integer integer = this.F0.V().get(Integer.valueOf(paramInt));
      if (integer != null) {
        paramAccessibilityNodeInfo.getExtras().putInt(paramString, integer.intValue());
        return;
      } 
    } else if (q.e(paramString, this.F0.R())) {
      Integer integer = this.F0.U().get(Integer.valueOf(paramInt));
      if (integer != null)
        paramAccessibilityNodeInfo.getExtras().putInt(paramString, integer.intValue()); 
    } 
  }
  
  private final boolean O() {
    return (Build.VERSION.SDK_INT >= 26);
  }
  
  private final boolean Q(j0 paramj0) {
    boolean bool1 = this.W0;
    boolean bool = true;
    if (!bool1) {
      boolean bool2;
      paramj0 = paramj0.k0();
      if (paramj0 != null && !paramj0.L()) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (bool2)
        return true; 
      bool = false;
    } 
    return bool;
  }
  
  private final void R(ViewGroup paramViewGroup) {
    int m = paramViewGroup.getChildCount();
    for (int i = 0; i < m; i++) {
      View view = paramViewGroup.getChildAt(i);
      if (view instanceof AndroidComposeView) {
        ((AndroidComposeView)view).t();
      } else if (view instanceof ViewGroup) {
        R((ViewGroup)view);
      } 
    } 
  }
  
  private final long S(int paramInt) {
    int i = View.MeasureSpec.getMode(paramInt);
    paramInt = View.MeasureSpec.getSize(paramInt);
    if (i != Integer.MIN_VALUE) {
      if (i != 0) {
        if (i == 1073741824)
          return j0(paramInt, paramInt); 
        throw new IllegalStateException();
      } 
      return j0(0, 2147483647);
    } 
    return j0(0, paramInt);
  }
  
  private final View U(int paramInt, View paramView) {
    if (Build.VERSION.SDK_INT < 29) {
      int i = 0;
      Method method = View.class.getDeclaredMethod("getAccessibilityViewId", new Class[0]);
      method.setAccessible(true);
      if (q.e(method.invoke(paramView, new Object[0]), Integer.valueOf(paramInt)))
        return paramView; 
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int m = viewGroup.getChildCount();
        while (i < m) {
          View view = viewGroup.getChildAt(i);
          q.i(view, "currentView.getChildAt(i)");
          view = U(paramInt, view);
          if (view != null)
            return view; 
          i++;
        } 
      } 
    } 
    return null;
  }
  
  private final int W(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 31) ? n.a(paramConfiguration) : 0;
  }
  
  private static final void X(AndroidComposeView paramAndroidComposeView) {
    q.j(paramAndroidComposeView, "this$0");
    paramAndroidComposeView.z0();
  }
  
  private final int Y(MotionEvent paramMotionEvent) {
    removeCallbacks(this.C1);
    try {
      l0(paramMotionEvent);
      boolean bool = true;
      this.e1 = true;
      a(false);
      Trace.beginSection("AndroidOwner:onTouch");
    } finally {
      this.e1 = false;
    } 
  }
  
  private final boolean Z(MotionEvent paramMotionEvent) {
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    float f1 = -paramMotionEvent.getAxisValue(26);
    n1.b b1 = new n1.b(o0.e(viewConfiguration, getContext()) * f1, f1 * o0.c(viewConfiguration, getContext()), paramMotionEvent.getEventTime());
    return getFocusOwner().d(b1);
  }
  
  private final boolean a0(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2) {
    if (paramMotionEvent2.getSource() == paramMotionEvent1.getSource()) {
      boolean bool = false;
      return (paramMotionEvent2.getToolType(0) != paramMotionEvent1.getToolType(0)) ? true : bool;
    } 
    return true;
  }
  
  private final void c0(j0 paramj0) {
    paramj0.C0();
    m0.f f1 = paramj0.t0();
    int i = f1.s();
    if (i > 0) {
      int n;
      Object[] arrayOfObject = f1.r();
      int m = 0;
      do {
        c0((j0)arrayOfObject[m]);
        n = m + 1;
        m = n;
      } while (n < i);
    } 
  }
  
  private final void d0(j0 paramj0) {
    t0 t01 = this.X0;
    int i = 0;
    t0.F(t01, paramj0, false, 2, null);
    m0.f f1 = paramj0.t0();
    int m = f1.s();
    if (m > 0) {
      int n;
      Object[] arrayOfObject = f1.r();
      do {
        d0((j0)arrayOfObject[i]);
        n = i + 1;
        i = n;
      } while (n < m);
    } 
  }
  
  private final boolean e0(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getX : ()F
    //   4: fstore_2
    //   5: fload_2
    //   6: invokestatic isInfinite : (F)Z
    //   9: ifne -> 24
    //   12: fload_2
    //   13: invokestatic isNaN : (F)Z
    //   16: ifne -> 24
    //   19: iconst_1
    //   20: istore_3
    //   21: goto -> 26
    //   24: iconst_0
    //   25: istore_3
    //   26: iload_3
    //   27: ifeq -> 129
    //   30: aload_1
    //   31: invokevirtual getY : ()F
    //   34: fstore_2
    //   35: fload_2
    //   36: invokestatic isInfinite : (F)Z
    //   39: ifne -> 54
    //   42: fload_2
    //   43: invokestatic isNaN : (F)Z
    //   46: ifne -> 54
    //   49: iconst_1
    //   50: istore_3
    //   51: goto -> 56
    //   54: iconst_0
    //   55: istore_3
    //   56: iload_3
    //   57: ifeq -> 129
    //   60: aload_1
    //   61: invokevirtual getRawX : ()F
    //   64: fstore_2
    //   65: fload_2
    //   66: invokestatic isInfinite : (F)Z
    //   69: ifne -> 84
    //   72: fload_2
    //   73: invokestatic isNaN : (F)Z
    //   76: ifne -> 84
    //   79: iconst_1
    //   80: istore_3
    //   81: goto -> 86
    //   84: iconst_0
    //   85: istore_3
    //   86: iload_3
    //   87: ifeq -> 129
    //   90: aload_1
    //   91: invokevirtual getRawY : ()F
    //   94: fstore_2
    //   95: fload_2
    //   96: invokestatic isInfinite : (F)Z
    //   99: ifne -> 114
    //   102: fload_2
    //   103: invokestatic isNaN : (F)Z
    //   106: ifne -> 114
    //   109: iconst_1
    //   110: istore_3
    //   111: goto -> 116
    //   114: iconst_0
    //   115: istore_3
    //   116: iload_3
    //   117: ifne -> 123
    //   120: goto -> 129
    //   123: iconst_0
    //   124: istore #6
    //   126: goto -> 132
    //   129: iconst_1
    //   130: istore #6
    //   132: iload #6
    //   134: istore #7
    //   136: iload #6
    //   138: ifne -> 288
    //   141: aload_1
    //   142: invokevirtual getPointerCount : ()I
    //   145: istore #5
    //   147: iconst_1
    //   148: istore_3
    //   149: iload #6
    //   151: istore #7
    //   153: iload_3
    //   154: iload #5
    //   156: if_icmpge -> 288
    //   159: aload_1
    //   160: iload_3
    //   161: invokevirtual getX : (I)F
    //   164: fstore_2
    //   165: fload_2
    //   166: invokestatic isInfinite : (F)Z
    //   169: ifne -> 185
    //   172: fload_2
    //   173: invokestatic isNaN : (F)Z
    //   176: ifne -> 185
    //   179: iconst_1
    //   180: istore #4
    //   182: goto -> 188
    //   185: iconst_0
    //   186: istore #4
    //   188: iload #4
    //   190: ifeq -> 269
    //   193: aload_1
    //   194: iload_3
    //   195: invokevirtual getY : (I)F
    //   198: fstore_2
    //   199: fload_2
    //   200: invokestatic isInfinite : (F)Z
    //   203: ifne -> 219
    //   206: fload_2
    //   207: invokestatic isNaN : (F)Z
    //   210: ifne -> 219
    //   213: iconst_1
    //   214: istore #4
    //   216: goto -> 222
    //   219: iconst_0
    //   220: istore #4
    //   222: iload #4
    //   224: ifeq -> 269
    //   227: getstatic android/os/Build$VERSION.SDK_INT : I
    //   230: bipush #29
    //   232: if_icmplt -> 252
    //   235: getstatic androidx/compose/ui/platform/r1.a : Landroidx/compose/ui/platform/r1;
    //   238: aload_1
    //   239: iload_3
    //   240: invokevirtual a : (Landroid/view/MotionEvent;I)Z
    //   243: ifne -> 252
    //   246: iconst_1
    //   247: istore #4
    //   249: goto -> 255
    //   252: iconst_0
    //   253: istore #4
    //   255: iload #4
    //   257: ifeq -> 263
    //   260: goto -> 269
    //   263: iconst_0
    //   264: istore #6
    //   266: goto -> 272
    //   269: iconst_1
    //   270: istore #6
    //   272: iload #6
    //   274: istore #7
    //   276: iload #6
    //   278: ifne -> 288
    //   281: iload_3
    //   282: iconst_1
    //   283: iadd
    //   284: istore_3
    //   285: goto -> 149
    //   288: iload #7
    //   290: ireturn
  }
  
  private final boolean f0(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getButtonState();
    boolean bool2 = true;
    if (i != 0)
      return true; 
    i = paramMotionEvent.getActionMasked();
    boolean bool1 = bool2;
    if (i != 0) {
      bool1 = bool2;
      if (i != 2) {
        bool1 = bool2;
        if (i != 6)
          bool1 = false; 
      } 
    } 
    return bool1;
  }
  
  private final boolean g0(MotionEvent paramMotionEvent) {
    boolean bool;
    float f1 = paramMotionEvent.getX();
    float f2 = paramMotionEvent.getY();
    if (0.0F <= f1 && f1 <= getWidth()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (0.0F <= f2 && f2 <= getHeight()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  private final b get_viewTreeOwners() {
    return (b)this.h1.getValue();
  }
  
  private final boolean h0(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getPointerCount();
    boolean bool2 = true;
    if (i != 1)
      return true; 
    MotionEvent motionEvent = this.y1;
    boolean bool1 = bool2;
    if (motionEvent != null) {
      bool1 = bool2;
      if (motionEvent.getPointerCount() == paramMotionEvent.getPointerCount()) {
        if (paramMotionEvent.getRawX() == motionEvent.getRawX()) {
          i = 1;
        } else {
          i = 0;
        } 
        bool1 = bool2;
        if (i != 0) {
          if (paramMotionEvent.getRawY() == motionEvent.getRawY()) {
            i = 1;
          } else {
            i = 0;
          } 
          if (i == 0)
            return true; 
          bool1 = false;
        } 
      } 
    } 
    return bool1;
  }
  
  private final long j0(int paramInt1, int paramInt2) {
    long l1 = s.c(s.c(paramInt1) << 32L);
    return s.c(s.c(paramInt2) | l1);
  }
  
  private final void k0() {
    if (!this.e1) {
      long l1 = AnimationUtils.currentAnimationTimeMillis();
      if (l1 != this.d1) {
        View view;
        this.d1 = l1;
        m0();
        ViewParent viewParent = getParent();
        AndroidComposeView androidComposeView = this;
        while (viewParent instanceof ViewGroup) {
          view = (View)viewParent;
          viewParent = ((ViewGroup)view).getParent();
        } 
        view.getLocationOnScreen(this.a1);
        int[] arrayOfInt2 = this.a1;
        float f1 = arrayOfInt2[0];
        float f2 = arrayOfInt2[1];
        view.getLocationInWindow(arrayOfInt2);
        int[] arrayOfInt1 = this.a1;
        this.f1 = a1.g.a(f1 - arrayOfInt1[0], f2 - arrayOfInt1[1]);
      } 
    } 
  }
  
  private final void l0(MotionEvent paramMotionEvent) {
    this.d1 = AnimationUtils.currentAnimationTimeMillis();
    m0();
    long l1 = x3.f(this.b1, a1.g.a(paramMotionEvent.getX(), paramMotionEvent.getY()));
    this.f1 = a1.g.a(paramMotionEvent.getRawX() - a1.f.o(l1), paramMotionEvent.getRawY() - a1.f.p(l1));
  }
  
  private final void m0() {
    this.G1.a((View)this, this.b1);
    n1.a(this.b1, this.c1);
  }
  
  private final void q0(j0 paramj0) {
    if (!isLayoutRequested() && isAttachedToWindow()) {
      if (paramj0 != null) {
        while (paramj0 != null && paramj0.d0() == j0.g.s0 && Q(paramj0))
          paramj0 = paramj0.k0(); 
        if (paramj0 == getRoot()) {
          requestLayout();
          return;
        } 
      } 
      if (getWidth() == 0 || getHeight() == 0) {
        requestLayout();
        return;
      } 
      invalidate();
      return;
    } 
  }
  
  private static final void s0(AndroidComposeView paramAndroidComposeView) {
    q.j(paramAndroidComposeView, "this$0");
    paramAndroidComposeView.z0();
  }
  
  private void setFontFamilyResolver(b2.l.b paramb) {
    this.q1.setValue(paramb);
  }
  
  private void setLayoutDirection(r paramr) {
    this.s1.setValue(paramr);
  }
  
  private final void set_viewTreeOwners(b paramb) {
    this.h1.setValue(paramb);
  }
  
  private static final void t0(AndroidComposeView paramAndroidComposeView) {
    q.j(paramAndroidComposeView, "this$0");
    boolean bool = false;
    paramAndroidComposeView.E1 = false;
    MotionEvent motionEvent = paramAndroidComposeView.y1;
    q.g(motionEvent);
    if (motionEvent.getActionMasked() == 10)
      bool = true; 
    if (bool) {
      paramAndroidComposeView.u0(motionEvent);
      return;
    } 
    throw new IllegalStateException("The ACTION_HOVER_EXIT event was not cleared.".toString());
  }
  
  private final int u0(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield H1 : Z
    //   4: ifeq -> 26
    //   7: aload_0
    //   8: iconst_0
    //   9: putfield H1 : Z
    //   12: aload_0
    //   13: getfield y0 : Landroidx/compose/ui/platform/t4;
    //   16: aload_1
    //   17: invokevirtual getMetaState : ()I
    //   20: invokestatic b : (I)I
    //   23: invokevirtual a : (I)V
    //   26: aload_0
    //   27: getfield K0 : Ll1/k;
    //   30: aload_1
    //   31: aload_0
    //   32: invokevirtual c : (Landroid/view/MotionEvent;Ll1/r0;)Ll1/e0;
    //   35: astore #6
    //   37: aload #6
    //   39: ifnull -> 188
    //   42: aload #6
    //   44: invokevirtual b : ()Ljava/util/List;
    //   47: astore #7
    //   49: aload #7
    //   51: invokeinterface size : ()I
    //   56: iconst_1
    //   57: isub
    //   58: istore_2
    //   59: iload_2
    //   60: iflt -> 103
    //   63: iload_2
    //   64: iconst_1
    //   65: isub
    //   66: istore_3
    //   67: aload #7
    //   69: iload_2
    //   70: invokeinterface get : (I)Ljava/lang/Object;
    //   75: astore #5
    //   77: aload #5
    //   79: checkcast l1/f0
    //   82: invokevirtual a : ()Z
    //   85: ifeq -> 91
    //   88: goto -> 106
    //   91: iload_3
    //   92: ifge -> 98
    //   95: goto -> 103
    //   98: iload_3
    //   99: istore_2
    //   100: goto -> 63
    //   103: aconst_null
    //   104: astore #5
    //   106: aload #5
    //   108: checkcast l1/f0
    //   111: astore #5
    //   113: aload #5
    //   115: ifnull -> 127
    //   118: aload_0
    //   119: aload #5
    //   121: invokevirtual e : ()J
    //   124: putfield s0 : J
    //   127: aload_0
    //   128: getfield L0 : Ll1/g0;
    //   131: aload #6
    //   133: aload_0
    //   134: aload_0
    //   135: aload_1
    //   136: invokespecial g0 : (Landroid/view/MotionEvent;)Z
    //   139: invokevirtual a : (Ll1/e0;Ll1/r0;Z)I
    //   142: istore_3
    //   143: aload_1
    //   144: invokevirtual getActionMasked : ()I
    //   147: istore #4
    //   149: iload #4
    //   151: ifeq -> 162
    //   154: iload_3
    //   155: istore_2
    //   156: iload #4
    //   158: iconst_5
    //   159: if_icmpne -> 201
    //   162: iload_3
    //   163: istore_2
    //   164: iload_3
    //   165: invokestatic c : (I)Z
    //   168: ifne -> 201
    //   171: aload_0
    //   172: getfield K0 : Ll1/k;
    //   175: aload_1
    //   176: aload_1
    //   177: invokevirtual getActionIndex : ()I
    //   180: invokevirtual getPointerId : (I)I
    //   183: invokevirtual e : (I)V
    //   186: iload_3
    //   187: ireturn
    //   188: aload_0
    //   189: getfield L0 : Ll1/g0;
    //   192: invokevirtual b : ()V
    //   195: iconst_0
    //   196: iconst_0
    //   197: invokestatic a : (ZZ)I
    //   200: istore_2
    //   201: iload_2
    //   202: ireturn
  }
  
  private final void v0(MotionEvent paramMotionEvent, int paramInt, long paramLong, boolean paramBoolean) {
    long l1;
    int i = paramMotionEvent.getActionMasked();
    int m = -1;
    if (i != 1) {
      if (i != 6) {
        i = m;
      } else {
        i = paramMotionEvent.getActionIndex();
      } 
    } else {
      i = m;
      if (paramInt != 9) {
        i = m;
        if (paramInt != 10)
          i = 0; 
      } 
    } 
    int n = paramMotionEvent.getPointerCount();
    if (i >= 0) {
      m = 1;
    } else {
      m = 0;
    } 
    int i2 = n - m;
    if (i2 == 0)
      return; 
    MotionEvent.PointerProperties[] arrayOfPointerProperties = new MotionEvent.PointerProperties[i2];
    for (m = 0; m < i2; m++)
      arrayOfPointerProperties[m] = new MotionEvent.PointerProperties(); 
    MotionEvent.PointerCoords[] arrayOfPointerCoords = new MotionEvent.PointerCoords[i2];
    for (m = 0; m < i2; m++)
      arrayOfPointerCoords[m] = new MotionEvent.PointerCoords(); 
    for (m = 0; m < i2; m++) {
      if (i < 0 || m < i) {
        n = 0;
      } else {
        n = 1;
      } 
      n += m;
      paramMotionEvent.getPointerProperties(n, arrayOfPointerProperties[m]);
      MotionEvent.PointerCoords pointerCoords = arrayOfPointerCoords[m];
      paramMotionEvent.getPointerCoords(n, pointerCoords);
      l1 = r(a1.g.a(pointerCoords.x, pointerCoords.y));
      pointerCoords.x = a1.f.o(l1);
      pointerCoords.y = a1.f.p(l1);
    } 
    if (paramBoolean) {
      i = 0;
    } else {
      i = paramMotionEvent.getButtonState();
    } 
    if (paramMotionEvent.getDownTime() == paramMotionEvent.getEventTime()) {
      l1 = paramLong;
    } else {
      l1 = paramMotionEvent.getDownTime();
    } 
    paramMotionEvent = MotionEvent.obtain(l1, paramLong, paramInt, i2, arrayOfPointerProperties, arrayOfPointerCoords, paramMotionEvent.getMetaState(), i, paramMotionEvent.getXPrecision(), paramMotionEvent.getYPrecision(), paramMotionEvent.getDeviceId(), paramMotionEvent.getEdgeFlags(), paramMotionEvent.getSource(), paramMotionEvent.getFlags());
    l1.k k2 = this.K0;
    q.i(paramMotionEvent, "event");
    e0 e01 = k2.c(paramMotionEvent, this);
    q.g(e01);
    this.L0.a(e01, this, true);
    paramMotionEvent.recycle();
  }
  
  private static final void x0(AndroidComposeView paramAndroidComposeView, boolean paramBoolean) {
    int i;
    q.j(paramAndroidComposeView, "this$0");
    i1.c c1 = paramAndroidComposeView.u1;
    if (paramBoolean) {
      i = i1.a.b.b();
    } else {
      i = i1.a.b.a();
    } 
    c1.b(i);
  }
  
  private final void z0() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield a1 : [I
    //   5: invokevirtual getLocationOnScreen : ([I)V
    //   8: aload_0
    //   9: getfield Z0 : J
    //   12: lstore #4
    //   14: lload #4
    //   16: invokestatic c : (J)I
    //   19: istore_1
    //   20: lload #4
    //   22: invokestatic d : (J)I
    //   25: istore_2
    //   26: aload_0
    //   27: getfield a1 : [I
    //   30: astore #8
    //   32: iconst_0
    //   33: istore #7
    //   35: aload #8
    //   37: iconst_0
    //   38: iaload
    //   39: istore_3
    //   40: iload_1
    //   41: iload_3
    //   42: if_icmpne -> 57
    //   45: iload #7
    //   47: istore #6
    //   49: iload_2
    //   50: aload #8
    //   52: iconst_1
    //   53: iaload
    //   54: if_icmpeq -> 107
    //   57: aload_0
    //   58: iload_3
    //   59: aload #8
    //   61: iconst_1
    //   62: iaload
    //   63: invokestatic a : (II)J
    //   66: putfield Z0 : J
    //   69: iload #7
    //   71: istore #6
    //   73: iload_1
    //   74: ldc_w 2147483647
    //   77: if_icmpeq -> 107
    //   80: iload #7
    //   82: istore #6
    //   84: iload_2
    //   85: ldc_w 2147483647
    //   88: if_icmpeq -> 107
    //   91: aload_0
    //   92: invokevirtual getRoot : ()Lq1/j0;
    //   95: invokevirtual S : ()Lq1/o0;
    //   98: invokevirtual D : ()Lq1/o0$b;
    //   101: invokevirtual m1 : ()V
    //   104: iconst_1
    //   105: istore #6
    //   107: aload_0
    //   108: getfield X0 : Lq1/t0;
    //   111: iload #6
    //   113: invokevirtual d : (Z)V
    //   116: return
  }
  
  public final void M(androidx.compose.ui.viewinterop.a parama, j0 paramj0) {
    q.j(parama, "view");
    q.j(paramj0, "layoutNode");
    getAndroidViewsHandler$ui_release().getHolderToLayoutNode().put(parama, paramj0);
    getAndroidViewsHandler$ui_release().addView((View)parama);
    getAndroidViewsHandler$ui_release().getLayoutNodeToHolder().put(paramj0, parama);
    m0.D0((View)parama, 1);
    m0.s0((View)parama, new d(paramj0, this, this));
  }
  
  public final Object P(vj.d<? super v> paramd) {
    Object object = this.F0.A(paramd);
    return (object == wj.b.d()) ? object : v.a;
  }
  
  public final void T(androidx.compose.ui.viewinterop.a parama, Canvas paramCanvas) {
    q.j(parama, "view");
    q.j(paramCanvas, "canvas");
    getAndroidViewsHandler$ui_release().a(parama, paramCanvas);
  }
  
  public androidx.compose.ui.focus.d V(KeyEvent paramKeyEvent) {
    q.j(paramKeyEvent, "keyEvent");
    long l1 = j1.d.a(paramKeyEvent);
    j1.a.a a1 = j1.a.b;
    if (j1.a.n(l1, a1.j())) {
      int i;
      if (j1.d.f(paramKeyEvent)) {
        i = androidx.compose.ui.focus.d.b.f();
      } else {
        i = androidx.compose.ui.focus.d.b.e();
      } 
      return androidx.compose.ui.focus.d.i(i);
    } 
    if (j1.a.n(l1, a1.e()))
      return androidx.compose.ui.focus.d.i(androidx.compose.ui.focus.d.b.g()); 
    if (j1.a.n(l1, a1.d()))
      return androidx.compose.ui.focus.d.i(androidx.compose.ui.focus.d.b.d()); 
    if (j1.a.n(l1, a1.f()))
      return androidx.compose.ui.focus.d.i(androidx.compose.ui.focus.d.b.h()); 
    if (j1.a.n(l1, a1.c()))
      return androidx.compose.ui.focus.d.i(androidx.compose.ui.focus.d.b.a()); 
    boolean bool = j1.a.n(l1, a1.b());
    boolean bool1 = true;
    if (bool) {
      bool = true;
    } else {
      bool = j1.a.n(l1, a1.g());
    } 
    if (bool) {
      bool = true;
    } else {
      bool = j1.a.n(l1, a1.i());
    } 
    if (bool)
      return androidx.compose.ui.focus.d.i(androidx.compose.ui.focus.d.b.b()); 
    if (j1.a.n(l1, a1.a())) {
      bool = bool1;
    } else {
      bool = j1.a.n(l1, a1.h());
    } 
    return bool ? androidx.compose.ui.focus.d.i(androidx.compose.ui.focus.d.b.c()) : null;
  }
  
  public void a(boolean paramBoolean) {
    if (this.X0.k() || this.X0.l()) {
      Trace.beginSection("AndroidOwner:measureAndLayout");
      if (paramBoolean)
        try {
          dk.a<v> a2 = this.F1;
          if (this.X0.o(a2))
            requestLayout(); 
          t0.e(this.X0, false, 1, null);
          v v1 = v.a;
          return;
        } finally {
          Trace.endSection();
        }  
    } else {
      return;
    } 
    dk.a a1 = null;
    if (this.X0.o(a1))
      requestLayout(); 
    t0.e(this.X0, false, 1, null);
    v v = v.a;
    Trace.endSection();
  }
  
  public void autofill(SparseArray<AutofillValue> paramSparseArray) {
    q.j(paramSparseArray, "values");
    if (O()) {
      x0.e e1 = this.N0;
      if (e1 != null)
        x0.h.a(e1, paramSparseArray); 
    } 
  }
  
  public void b(j0 paramj0, boolean paramBoolean) {
    q.j(paramj0, "layoutNode");
    this.X0.h(paramj0, paramBoolean);
  }
  
  public void b0() {
    c0(getRoot());
  }
  
  public boolean canScrollHorizontally(int paramInt) {
    return this.F0.D(false, paramInt, this.s0);
  }
  
  public boolean canScrollVertically(int paramInt) {
    return this.F0.D(true, paramInt, this.s0);
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    q.j(paramCanvas, "canvas");
    if (!isAttachedToWindow())
      c0(getRoot()); 
    h1.b(this, false, 1, null);
    this.J0 = true;
    i1 i11 = this.B0;
    Canvas canvas = i11.a().v();
    i11.a().w(paramCanvas);
    e0 e01 = i11.a();
    getRoot().A((h1)e01);
    i11.a().w(canvas);
    if ((this.H0.isEmpty() ^ true) != 0) {
      int m = this.H0.size();
      for (int i = 0; i < m; i++)
        ((g1)this.H0.get(i)).h(); 
    } 
    if (g4.G0.b()) {
      int i = paramCanvas.save();
      paramCanvas.clipRect(0.0F, 0.0F, 0.0F, 0.0F);
      super.dispatchDraw(paramCanvas);
      paramCanvas.restoreToCount(i);
    } 
    this.H0.clear();
    this.J0 = false;
    List<g1> list = this.I0;
    if (list != null) {
      q.g(list);
      this.H0.addAll(list);
      list.clear();
    } 
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent) {
    q.j(paramMotionEvent, "event");
    return (paramMotionEvent.getActionMasked() == 8) ? (paramMotionEvent.isFromSource(4194304) ? Z(paramMotionEvent) : ((e0(paramMotionEvent) || !isAttachedToWindow()) ? super.dispatchGenericMotionEvent(paramMotionEvent) : s0.c(Y(paramMotionEvent)))) : super.dispatchGenericMotionEvent(paramMotionEvent);
  }
  
  public boolean dispatchHoverEvent(MotionEvent paramMotionEvent) {
    q.j(paramMotionEvent, "event");
    if (this.E1) {
      removeCallbacks(this.D1);
      this.D1.run();
    } 
    if (!e0(paramMotionEvent)) {
      if (!isAttachedToWindow())
        return false; 
      this.F0.K(paramMotionEvent);
      int i = paramMotionEvent.getActionMasked();
      if (i != 7) {
        if (i == 10 && g0(paramMotionEvent)) {
          if (paramMotionEvent.getToolType(0) != 3) {
            MotionEvent motionEvent = this.y1;
            if (motionEvent != null)
              motionEvent.recycle(); 
            this.y1 = MotionEvent.obtainNoHistory(paramMotionEvent);
            this.E1 = true;
            post(this.D1);
            return false;
          } 
          if (paramMotionEvent.getButtonState() != 0)
            return false; 
        } 
      } else if (!h0(paramMotionEvent)) {
        return false;
      } 
      return s0.c(Y(paramMotionEvent));
    } 
    return false;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    q.j(paramKeyEvent, "event");
    if (isFocused()) {
      this.y0.a(p0.b(paramKeyEvent.getMetaState()));
      return (getFocusOwner().n(j1.b.b(paramKeyEvent)) || super.dispatchKeyEvent(paramKeyEvent));
    } 
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean dispatchKeyEventPreIme(KeyEvent paramKeyEvent) {
    q.j(paramKeyEvent, "event");
    return ((isFocused() && getFocusOwner().g(j1.b.b(paramKeyEvent))) || super.dispatchKeyEventPreIme(paramKeyEvent));
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    q.j(paramMotionEvent, "motionEvent");
    if (this.E1) {
      removeCallbacks(this.D1);
      MotionEvent motionEvent = this.y1;
      q.g(motionEvent);
      if (paramMotionEvent.getActionMasked() != 0 || a0(paramMotionEvent, motionEvent)) {
        this.D1.run();
      } else {
        this.E1 = false;
      } 
    } 
    if (!e0(paramMotionEvent)) {
      if (!isAttachedToWindow())
        return false; 
      if (paramMotionEvent.getActionMasked() == 2 && !h0(paramMotionEvent))
        return false; 
      int i = Y(paramMotionEvent);
      if (s0.b(i))
        getParent().requestDisallowInterceptTouchEvent(true); 
      return s0.c(i);
    } 
    return false;
  }
  
  public long e(long paramLong) {
    k0();
    return x3.f(this.b1, paramLong);
  }
  
  public void f(j0 paramj0) {
    q.j(paramj0, "layoutNode");
    this.X0.B(paramj0);
    r0(this, null, 1, null);
  }
  
  public final View findViewByAccessibilityIdTraversal(int paramInt) {
    View view = null;
    try {
      if (Build.VERSION.SDK_INT >= 29) {
        Method method = View.class.getDeclaredMethod("findViewByAccessibilityIdTraversal", new Class[] { int.class });
        method.setAccessible(true);
        Object object = method.invoke(this, new Object[] { Integer.valueOf(paramInt) });
        if (object instanceof View)
          return (View)object; 
      } else {
        view = U(paramInt, (View)this);
      } 
      return view;
    } catch (NoSuchMethodException noSuchMethodException) {
      return null;
    } 
  }
  
  public void g(j0 paramj0) {
    q.j(paramj0, "node");
    this.X0.r(paramj0);
    p0();
  }
  
  public k getAccessibilityManager() {
    return this.Q0;
  }
  
  public final q0 getAndroidViewsHandler$ui_release() {
    if (this.T0 == null) {
      Context context = getContext();
      q.i(context, "context");
      q0 q02 = new q0(context);
      this.T0 = q02;
      addView((View)q02);
    } 
    q0 q01 = this.T0;
    q.g(q01);
    return q01;
  }
  
  public x0.i getAutofill() {
    return (x0.i)this.N0;
  }
  
  public d0 getAutofillTree() {
    return this.G0;
  }
  
  public l getClipboardManager() {
    return this.P0;
  }
  
  public final dk.l<Configuration, v> getConfigurationChangeObserver() {
    return (dk.l)this.M0;
  }
  
  public vj.g getCoroutineContext() {
    return this.x1;
  }
  
  public k2.e getDensity() {
    return this.v0;
  }
  
  public z0.j getFocusOwner() {
    return this.x0;
  }
  
  public void getFocusedRect(Rect paramRect) {
    q.j(paramRect, "rect");
    a1.h h = getFocusOwner().j();
    if (h != null) {
      paramRect.left = fk.a.d(h.i());
      paramRect.top = fk.a.d(h.l());
      paramRect.right = fk.a.d(h.j());
      paramRect.bottom = fk.a.d(h.e());
      v v = v.a;
    } else {
      h = null;
    } 
    if (h == null)
      super.getFocusedRect(paramRect); 
  }
  
  public b2.l.b getFontFamilyResolver() {
    return (b2.l.b)this.q1.getValue();
  }
  
  public b2.k.a getFontLoader() {
    return this.p1;
  }
  
  public h1.a getHapticFeedBack() {
    return this.t1;
  }
  
  public boolean getHasPendingMeasureOrLayout() {
    return this.X0.k();
  }
  
  public i1.b getInputModeManager() {
    return (i1.b)this.u1;
  }
  
  public final long getLastMatrixRecalculationAnimationTime$ui_release() {
    return this.d1;
  }
  
  public r getLayoutDirection() {
    return (r)this.s1.getValue();
  }
  
  public long getMeasureIteration() {
    return this.X0.n();
  }
  
  public p1.f getModifierLocalManager() {
    return this.v1;
  }
  
  public e0 getPlatformTextInputPluginRegistry() {
    return this.n1;
  }
  
  public z getPointerIconService() {
    return this.I1;
  }
  
  public j0 getRoot() {
    return this.C0;
  }
  
  public r1 getRootForTest() {
    return this.D0;
  }
  
  public r getSemanticsOwner() {
    return this.E0;
  }
  
  public l0 getSharedDrawScope() {
    return this.u0;
  }
  
  public boolean getShowLayoutBounds() {
    return this.S0;
  }
  
  public k1 getSnapshotObserver() {
    return this.R0;
  }
  
  public m0 getTextInputService() {
    return this.o1;
  }
  
  public v3 getTextToolbar() {
    return this.w1;
  }
  
  public View getView() {
    return (View)this;
  }
  
  public f4 getViewConfiguration() {
    return this.Y0;
  }
  
  public final b getViewTreeOwners() {
    return (b)this.i1.getValue();
  }
  
  public s4 getWindowInfo() {
    return this.y0;
  }
  
  public long h(long paramLong) {
    k0();
    float f1 = a1.f.o(paramLong);
    float f2 = a1.f.o(this.f1);
    float f3 = a1.f.p(paramLong);
    float f5 = a1.f.p(this.f1);
    return x3.f(this.c1, a1.g.a(f1 - f2, f3 - f5));
  }
  
  public void i(j0 paramj0) {
    q.j(paramj0, "layoutNode");
    this.F0.o0(paramj0);
  }
  
  public final void i0(g1 paramg1, boolean paramBoolean) {
    q.j(paramg1, "layer");
    if (!paramBoolean) {
      if (!this.J0) {
        this.H0.remove(paramg1);
        List<g1> list = this.I0;
        if (list != null) {
          list.remove(paramg1);
          return;
        } 
      } 
    } else {
      if (!this.J0) {
        this.H0.add(paramg1);
        return;
      } 
      List<g1> list2 = this.I0;
      List<g1> list1 = list2;
      if (list2 == null) {
        list1 = new ArrayList<g1>();
        this.I0 = list1;
      } 
      list1.add(paramg1);
    } 
  }
  
  public void j(j0 paramj0, boolean paramBoolean1, boolean paramBoolean2) {
    q.j(paramj0, "layoutNode");
    if (paramBoolean1) {
      if (this.X0.x(paramj0, paramBoolean2)) {
        r0(this, null, 1, null);
        return;
      } 
    } else if (this.X0.C(paramj0, paramBoolean2)) {
      r0(this, null, 1, null);
    } 
  }
  
  public void k(dk.a<v> parama) {
    q.j(parama, "listener");
    if (!this.B1.l(parama))
      this.B1.d(parama); 
  }
  
  public long l(long paramLong) {
    k0();
    return x3.f(this.c1, paramLong);
  }
  
  public void m(j0 paramj0, long paramLong) {
    q.j(paramj0, "layoutNode");
    Trace.beginSection("AndroidOwner:measureAndLayout");
    try {
      this.X0.p(paramj0, paramLong);
      if (!this.X0.k())
        t0.e(this.X0, false, 1, null); 
      v v = v.a;
      return;
    } finally {
      Trace.endSection();
    } 
  }
  
  public void n(p paramp) {
    q.j(paramp, "owner");
    setShowLayoutBounds(a.a(J1));
  }
  
  public final boolean n0(g1 paramg1) {
    boolean bool;
    q.j(paramg1, "layer");
    if (this.U0 == null || g4.G0.b() || Build.VERSION.SDK_INT >= 23 || this.A1.b() < 10) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      this.A1.d(paramg1); 
    return bool;
  }
  
  public final void o0(androidx.compose.ui.viewinterop.a parama) {
    q.j(parama, "view");
    k(new j(this, parama));
  }
  
  protected void onAttachedToWindow() {
    int i;
    super.onAttachedToWindow();
    d0(getRoot());
    c0(getRoot());
    getSnapshotObserver().j();
    if (O()) {
      x0.e e1 = this.N0;
      if (e1 != null)
        b0.a.a(e1); 
    } 
    p p = s0.a((View)this);
    d4.d d = d4.e.a((View)this);
    b b2 = getViewTreeOwners();
    if (b2 == null || (p != null && d != null && (p != b2.a() || d != b2.a()))) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i)
      if (p != null) {
        if (d != null) {
          if (b2 != null) {
            p p1 = b2.a();
            if (p1 != null) {
              androidx.lifecycle.j j2 = p1.getLifecycle();
              if (j2 != null)
                j2.d((androidx.lifecycle.o)this); 
            } 
          } 
          p.getLifecycle().a((androidx.lifecycle.o)this);
          b b3 = new b(p, d);
          set_viewTreeOwners(b3);
          dk.l<? super b, v> l1 = this.j1;
          if (l1 != null)
            l1.invoke(b3); 
          this.j1 = null;
        } else {
          throw new IllegalStateException("Composed into the View which doesn't propagateViewTreeSavedStateRegistryOwner!");
        } 
      } else {
        throw new IllegalStateException("Composed into the View which doesn't propagate ViewTreeLifecycleOwner!");
      }  
    i1.c c1 = this.u1;
    if (isInTouchMode()) {
      i = i1.a.b.b();
    } else {
      i = i1.a.b.a();
    } 
    c1.b(i);
    b b1 = getViewTreeOwners();
    q.g(b1);
    b1.a().getLifecycle().a((androidx.lifecycle.o)this);
    getViewTreeObserver().addOnGlobalLayoutListener(this.k1);
    getViewTreeObserver().addOnScrollChangedListener(this.l1);
    getViewTreeObserver().addOnTouchModeChangeListener(this.m1);
  }
  
  public boolean onCheckIsTextEditor() {
    return (getPlatformTextInputPluginRegistry().d() != null);
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    q.j(paramConfiguration, "newConfig");
    super.onConfigurationChanged(paramConfiguration);
    Context context = getContext();
    q.i(context, "context");
    this.v0 = k2.a.a(context);
    if (W(paramConfiguration) != this.r1) {
      this.r1 = W(paramConfiguration);
      context = getContext();
      q.i(context, "context");
      setFontFamilyResolver(q.a(context));
    } 
    this.M0.invoke(paramConfiguration);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    q.j(paramEditorInfo, "outAttrs");
    b0 b0 = getPlatformTextInputPluginRegistry().d();
    return (b0 != null) ? b0.a(paramEditorInfo) : null;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    getSnapshotObserver().k();
    b b1 = getViewTreeOwners();
    if (b1 != null) {
      p p = b1.a();
      if (p != null) {
        androidx.lifecycle.j j2 = p.getLifecycle();
        if (j2 != null)
          j2.d((androidx.lifecycle.o)this); 
      } 
    } 
    if (O()) {
      x0.e e1 = this.N0;
      if (e1 != null)
        b0.a.b(e1); 
    } 
    getViewTreeObserver().removeOnGlobalLayoutListener(this.k1);
    getViewTreeObserver().removeOnScrollChangedListener(this.l1);
    getViewTreeObserver().removeOnTouchModeChangeListener(this.m1);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    q.j(paramCanvas, "canvas");
  }
  
  protected void onFocusChanged(boolean paramBoolean, int paramInt, Rect paramRect) {
    super.onFocusChanged(paramBoolean, paramInt, paramRect);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Owner FocusChanged(");
    stringBuilder.append(paramBoolean);
    stringBuilder.append(')');
    if (paramBoolean) {
      getFocusOwner().b();
      return;
    } 
    getFocusOwner().k();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.X0.o(this.F1);
    this.V0 = null;
    z0();
    if (this.T0 != null)
      getAndroidViewsHandler$ui_release().layout(0, 0, paramInt3 - paramInt1, paramInt4 - paramInt2); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    Trace.beginSection("AndroidOwner:onMeasure");
    try {
      if (!isAttachedToWindow())
        d0(getRoot()); 
      long l1 = S(paramInt1);
      paramInt1 = (int)s.c(l1 >>> 32L);
      int i = (int)s.c(l1 & 0xFFFFFFFFL);
      l1 = S(paramInt2);
      l1 = k2.c.a(paramInt1, i, (int)s.c(l1 >>> 32L), (int)s.c(0xFFFFFFFFL & l1));
      k2.b b1 = this.V0;
      boolean bool = false;
      if (b1 == null) {
        this.V0 = k2.b.b(l1);
        this.W0 = false;
      } else {
        if (b1 != null)
          bool = k2.b.g(b1.s(), l1); 
        if (!bool)
          this.W0 = true; 
      } 
      this.X0.G(l1);
      this.X0.q();
      setMeasuredDimension(getRoot().q0(), getRoot().M());
      if (this.T0 != null)
        getAndroidViewsHandler$ui_release().measure(View.MeasureSpec.makeMeasureSpec(getRoot().q0(), 1073741824), View.MeasureSpec.makeMeasureSpec(getRoot().M(), 1073741824)); 
      v v = v.a;
      return;
    } finally {
      Trace.endSection();
    } 
  }
  
  public void onProvideAutofillVirtualStructure(ViewStructure paramViewStructure, int paramInt) {
    if (O() && paramViewStructure != null) {
      x0.e e1 = this.N0;
      if (e1 != null)
        x0.h.b(e1, paramViewStructure); 
    } 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    if (this.t0) {
      r r2 = h0.a(paramInt);
      setLayoutDirection(r2);
      getFocusOwner().a(r2);
    } 
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    this.y0.b(paramBoolean);
    this.H1 = true;
    super.onWindowFocusChanged(paramBoolean);
    if (paramBoolean) {
      paramBoolean = a.a(J1);
      if (getShowLayoutBounds() != paramBoolean) {
        setShowLayoutBounds(paramBoolean);
        b0();
      } 
    } 
  }
  
  public void p(j0 paramj0) {
    q.j(paramj0, "node");
  }
  
  public final void p0() {
    this.O0 = true;
  }
  
  public void q(i1.b paramb) {
    q.j(paramb, "listener");
    this.X0.t(paramb);
    r0(this, null, 1, null);
  }
  
  public long r(long paramLong) {
    k0();
    paramLong = x3.f(this.b1, paramLong);
    return a1.g.a(a1.f.o(paramLong) + a1.f.o(this.f1), a1.f.p(paramLong) + a1.f.p(this.f1));
  }
  
  public void s(j0 paramj0, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    q.j(paramj0, "layoutNode");
    if (paramBoolean1) {
      if (this.X0.z(paramj0, paramBoolean2) && paramBoolean3) {
        q0(paramj0);
        return;
      } 
    } else if (this.X0.E(paramj0, paramBoolean2) && paramBoolean3) {
      q0(paramj0);
    } 
  }
  
  public final void setConfigurationChangeObserver(dk.l<? super Configuration, v> paraml) {
    q.j(paraml, "<set-?>");
    this.M0 = paraml;
  }
  
  public final void setLastMatrixRecalculationAnimationTime$ui_release(long paramLong) {
    this.d1 = paramLong;
  }
  
  public final void setOnViewTreeOwnersAvailable(dk.l<? super b, v> paraml) {
    q.j(paraml, "callback");
    b b1 = getViewTreeOwners();
    if (b1 != null)
      paraml.invoke(b1); 
    if (!isAttachedToWindow())
      this.j1 = paraml; 
  }
  
  public void setShowLayoutBounds(boolean paramBoolean) {
    this.S0 = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public void t() {
    if (this.O0) {
      getSnapshotObserver().a();
      this.O0 = false;
    } 
    q0 q01 = this.T0;
    if (q01 != null)
      R(q01); 
    while (this.B1.w()) {
      int m = this.B1.s();
      for (int i = 0; i < m; i++) {
        dk.a a1 = (dk.a)this.B1.r()[i];
        this.B1.E(i, null);
        if (a1 != null)
          a1.invoke(); 
      } 
      this.B1.C(0, m);
    } 
  }
  
  public void u() {
    this.F0.p0();
  }
  
  public g1 v(dk.l<? super h1, v> paraml, dk.a<v> parama) {
    q.j(paraml, "drawBlock");
    q.j(parama, "invalidateParentLayer");
    g1 g1 = this.A1.c();
    if (g1 != null) {
      g1.a(paraml, parama);
      return g1;
    } 
    if (isHardwareAccelerated() && Build.VERSION.SDK_INT >= 23 && this.g1)
      try {
        return new o3(this, paraml, parama);
      } finally {
        g1 = null;
      }  
    if (this.U0 == null) {
      d1 d12;
      g4.c c1 = g4.G0;
      if (!c1.a())
        c1.d(new View(getContext())); 
      if (c1.b()) {
        Context context = getContext();
        q.i(context, "context");
        d12 = new d1(context);
      } else {
        Context context = getContext();
        q.i(context, "context");
        d12 = new i4(context);
      } 
      this.U0 = d12;
      addView((View)d12);
    } 
    d1 d11 = this.U0;
    q.g(d11);
    return new g4(this, d11, paraml, parama);
  }
  
  public static final class a {
    private a() {}
    
    @SuppressLint({"PrivateApi", "BanUncheckedReflection"})
    private final boolean b() {
      boolean bool = false;
      try {
        Class clazz = AndroidComposeView.G();
        Boolean bool1 = null;
        if (clazz == null) {
          AndroidComposeView.L(Class.forName("android.os.SystemProperties"));
          clazz = AndroidComposeView.G();
          if (clazz != null) {
            Method method1 = clazz.getDeclaredMethod("getBoolean", new Class[] { String.class, boolean.class });
          } else {
            clazz = null;
          } 
          AndroidComposeView.J((Method)clazz);
        } 
        Method method = AndroidComposeView.C();
        if (method != null) {
          Object object = method.invoke(null, new Object[] { "debug.layout", Boolean.FALSE });
        } else {
          method = null;
        } 
        if (method instanceof Boolean)
          bool1 = (Boolean)method; 
        if (bool1 != null)
          bool = bool1.booleanValue(); 
        return bool;
      } catch (Exception exception) {
        return false;
      } 
    }
  }
  
  public static final class b {
    private final p a;
    
    private final d4.d b;
    
    public b(p param1p, d4.d param1d) {
      this.a = param1p;
      this.b = param1d;
    }
    
    public final p a() {
      return this.a;
    }
    
    public final d4.d b() {
      return this.b;
    }
  }
  
  static final class c extends r implements dk.l<i1.a, Boolean> {
    c(AndroidComposeView param1AndroidComposeView) {
      super(1);
    }
    
    public final Boolean a(int param1Int) {
      boolean bool;
      i1.a.a a = i1.a.b;
      if (i1.a.f(param1Int, a.b())) {
        bool = this.s0.isInTouchMode();
      } else if (i1.a.f(param1Int, a.a())) {
        if (this.s0.isInTouchMode()) {
          bool = this.s0.requestFocusFromTouch();
        } else {
          bool = true;
        } 
      } else {
        bool = false;
      } 
      return Boolean.valueOf(bool);
    }
  }
  
  public static final class d extends androidx.core.view.a {
    d(j0 param1j0, AndroidComposeView param1AndroidComposeView1, AndroidComposeView param1AndroidComposeView2) {}
    
    public void g(View param1View, n0 param1n0) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'host'
      //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: aload_2
      //   7: ldc 'info'
      //   9: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
      //   12: aload_0
      //   13: aload_1
      //   14: aload_2
      //   15: invokespecial g : (Landroid/view/View;Landroidx/core/view/accessibility/n0;)V
      //   18: aload_0
      //   19: getfield d : Lq1/j0;
      //   22: getstatic androidx/compose/ui/platform/AndroidComposeView$d$a.s0 : Landroidx/compose/ui/platform/AndroidComposeView$d$a;
      //   25: invokestatic f : (Lq1/j0;Ldk/l;)Lq1/j0;
      //   28: astore_1
      //   29: aload_1
      //   30: ifnull -> 44
      //   33: aload_1
      //   34: invokevirtual n0 : ()I
      //   37: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   40: astore_1
      //   41: goto -> 46
      //   44: aconst_null
      //   45: astore_1
      //   46: aload_1
      //   47: ifnull -> 75
      //   50: aload_0
      //   51: getfield e : Landroidx/compose/ui/platform/AndroidComposeView;
      //   54: invokevirtual getSemanticsOwner : ()Lu1/r;
      //   57: invokevirtual a : ()Lu1/p;
      //   60: invokevirtual m : ()I
      //   63: istore_3
      //   64: aload_1
      //   65: astore #5
      //   67: aload_1
      //   68: invokevirtual intValue : ()I
      //   71: iload_3
      //   72: if_icmpne -> 81
      //   75: iconst_m1
      //   76: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   79: astore #5
      //   81: aload_2
      //   82: aload_0
      //   83: getfield f : Landroidx/compose/ui/platform/AndroidComposeView;
      //   86: aload #5
      //   88: invokevirtual intValue : ()I
      //   91: invokevirtual K0 : (Landroid/view/View;I)V
      //   94: aload_0
      //   95: getfield d : Lq1/j0;
      //   98: invokevirtual n0 : ()I
      //   101: istore_3
      //   102: aload_0
      //   103: getfield e : Landroidx/compose/ui/platform/AndroidComposeView;
      //   106: invokestatic B : (Landroidx/compose/ui/platform/AndroidComposeView;)Landroidx/compose/ui/platform/w;
      //   109: invokevirtual V : ()Ljava/util/HashMap;
      //   112: iload_3
      //   113: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   116: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   119: checkcast java/lang/Integer
      //   122: astore #6
      //   124: aload #6
      //   126: ifnull -> 210
      //   129: aload_0
      //   130: getfield e : Landroidx/compose/ui/platform/AndroidComposeView;
      //   133: astore_1
      //   134: aload_0
      //   135: getfield f : Landroidx/compose/ui/platform/AndroidComposeView;
      //   138: astore #5
      //   140: aload #6
      //   142: invokevirtual intValue : ()I
      //   145: istore #4
      //   147: aload_1
      //   148: invokevirtual getAndroidViewsHandler$ui_release : ()Landroidx/compose/ui/platform/q0;
      //   151: aload #6
      //   153: invokevirtual intValue : ()I
      //   156: invokestatic H : (Landroidx/compose/ui/platform/q0;I)Landroid/view/View;
      //   159: astore #6
      //   161: aload #6
      //   163: ifnull -> 175
      //   166: aload_2
      //   167: aload #6
      //   169: invokevirtual Z0 : (Landroid/view/View;)V
      //   172: goto -> 183
      //   175: aload_2
      //   176: aload #5
      //   178: iload #4
      //   180: invokevirtual a1 : (Landroid/view/View;I)V
      //   183: aload_2
      //   184: invokevirtual d1 : ()Landroid/view/accessibility/AccessibilityNodeInfo;
      //   187: astore #5
      //   189: aload #5
      //   191: ldc 'info.unwrap()'
      //   193: invokestatic i : (Ljava/lang/Object;Ljava/lang/String;)V
      //   196: aload_1
      //   197: iload_3
      //   198: aload #5
      //   200: aload_1
      //   201: invokestatic B : (Landroidx/compose/ui/platform/AndroidComposeView;)Landroidx/compose/ui/platform/w;
      //   204: invokevirtual S : ()Ljava/lang/String;
      //   207: invokestatic A : (Landroidx/compose/ui/platform/AndroidComposeView;ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)V
      //   210: aload_0
      //   211: getfield e : Landroidx/compose/ui/platform/AndroidComposeView;
      //   214: invokestatic B : (Landroidx/compose/ui/platform/AndroidComposeView;)Landroidx/compose/ui/platform/w;
      //   217: invokevirtual U : ()Ljava/util/HashMap;
      //   220: iload_3
      //   221: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   224: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   227: checkcast java/lang/Integer
      //   230: astore #6
      //   232: aload #6
      //   234: ifnull -> 315
      //   237: aload_0
      //   238: getfield e : Landroidx/compose/ui/platform/AndroidComposeView;
      //   241: astore_1
      //   242: aload_0
      //   243: getfield f : Landroidx/compose/ui/platform/AndroidComposeView;
      //   246: astore #5
      //   248: aload #6
      //   250: invokevirtual intValue : ()I
      //   253: istore #4
      //   255: aload_1
      //   256: invokevirtual getAndroidViewsHandler$ui_release : ()Landroidx/compose/ui/platform/q0;
      //   259: aload #6
      //   261: invokevirtual intValue : ()I
      //   264: invokestatic H : (Landroidx/compose/ui/platform/q0;I)Landroid/view/View;
      //   267: astore #6
      //   269: aload #6
      //   271: ifnull -> 283
      //   274: aload_2
      //   275: aload #6
      //   277: invokevirtual X0 : (Landroid/view/View;)V
      //   280: goto -> 291
      //   283: aload_2
      //   284: aload #5
      //   286: iload #4
      //   288: invokevirtual Y0 : (Landroid/view/View;I)V
      //   291: aload_2
      //   292: invokevirtual d1 : ()Landroid/view/accessibility/AccessibilityNodeInfo;
      //   295: astore_2
      //   296: aload_2
      //   297: ldc 'info.unwrap()'
      //   299: invokestatic i : (Ljava/lang/Object;Ljava/lang/String;)V
      //   302: aload_1
      //   303: iload_3
      //   304: aload_2
      //   305: aload_1
      //   306: invokestatic B : (Landroidx/compose/ui/platform/AndroidComposeView;)Landroidx/compose/ui/platform/w;
      //   309: invokevirtual R : ()Ljava/lang/String;
      //   312: invokestatic A : (Landroidx/compose/ui/platform/AndroidComposeView;ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)V
      //   315: return
    }
    
    static final class a extends r implements dk.l<j0, Boolean> {
      public static final a s0 = new a();
      
      a() {
        super(1);
      }
      
      public final Boolean a(j0 param2j0) {
        q.j(param2j0, "it");
        return Boolean.valueOf(param2j0.h0().q(z0.a(8)));
      }
    }
  }
  
  static final class a extends r implements dk.l<j0, Boolean> {
    public static final a s0 = new a();
    
    a() {
      super(1);
    }
    
    public final Boolean a(j0 param1j0) {
      q.j(param1j0, "it");
      return Boolean.valueOf(param1j0.h0().q(z0.a(8)));
    }
  }
  
  static final class e extends r implements dk.l<Configuration, v> {
    public static final e s0 = new e();
    
    e() {
      super(1);
    }
    
    public final void a(Configuration param1Configuration) {
      q.j(param1Configuration, "it");
    }
  }
  
  static final class f extends r implements dk.l<dk.a<? extends v>, v> {
    f(AndroidComposeView param1AndroidComposeView) {
      super(1);
    }
    
    public final void a(dk.a<v> param1a) {
      q.j(param1a, "it");
      this.s0.k(param1a);
    }
  }
  
  static final class g extends r implements dk.l<j1.b, Boolean> {
    g(AndroidComposeView param1AndroidComposeView) {
      super(1);
    }
    
    public final Boolean a(KeyEvent param1KeyEvent) {
      q.j(param1KeyEvent, "it");
      androidx.compose.ui.focus.d d = this.s0.V(param1KeyEvent);
      return (d == null || !j1.c.e(j1.d.b(param1KeyEvent), j1.c.a.a())) ? Boolean.FALSE : Boolean.valueOf(this.s0.getFocusOwner().f(d.o()));
    }
  }
  
  static final class h extends r implements p<c0<?>, a0, b0> {
    h(AndroidComposeView param1AndroidComposeView) {
      super(2);
    }
    
    public final b0 a(c0<?> param1c0, a0 param1a0) {
      q.j(param1c0, "factory");
      q.j(param1a0, "platformTextInput");
      return param1c0.a(param1a0, (View)this.s0);
    }
  }
  
  public static final class i implements z {
    private w a = w.b.a();
    
    i(AndroidComposeView param1AndroidComposeView) {}
    
    public void a(w param1w) {
      w w1 = param1w;
      if (param1w == null)
        w1 = w.b.a(); 
      this.a = w1;
      if (Build.VERSION.SDK_INT >= 24)
        d0.a.a((View)this.b, w1); 
    }
  }
  
  static final class j extends r implements dk.a<v> {
    j(AndroidComposeView param1AndroidComposeView, androidx.compose.ui.viewinterop.a param1a) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.getAndroidViewsHandler$ui_release().removeViewInLayout((View)this.t0);
      HashMap<j0, androidx.compose.ui.viewinterop.a> hashMap = this.s0.getAndroidViewsHandler$ui_release().getLayoutNodeToHolder();
      Object object = this.s0.getAndroidViewsHandler$ui_release().getHolderToLayoutNode().remove(this.t0);
      m0.d(hashMap).remove(object);
      m0.D0((View)this.t0, 0);
    }
  }
  
  static final class k extends r implements dk.a<v> {
    k(AndroidComposeView param1AndroidComposeView) {
      super(0);
    }
    
    public final void invoke() {
      MotionEvent motionEvent = AndroidComposeView.D(this.s0);
      if (motionEvent != null) {
        int i = motionEvent.getActionMasked();
        if (i != 7 && i != 9)
          return; 
        AndroidComposeView.K(this.s0, SystemClock.uptimeMillis());
        AndroidComposeView androidComposeView = this.s0;
        androidComposeView.post(AndroidComposeView.F(androidComposeView));
      } 
    }
  }
  
  public static final class l implements Runnable {
    l(AndroidComposeView param1AndroidComposeView) {}
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield s0 : Landroidx/compose/ui/platform/AndroidComposeView;
      //   4: aload_0
      //   5: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
      //   8: pop
      //   9: aload_0
      //   10: getfield s0 : Landroidx/compose/ui/platform/AndroidComposeView;
      //   13: invokestatic D : (Landroidx/compose/ui/platform/AndroidComposeView;)Landroid/view/MotionEvent;
      //   16: astore #4
      //   18: aload #4
      //   20: ifnull -> 123
      //   23: iconst_0
      //   24: istore_2
      //   25: aload #4
      //   27: iconst_0
      //   28: invokevirtual getToolType : (I)I
      //   31: iconst_3
      //   32: if_icmpne -> 40
      //   35: iconst_1
      //   36: istore_1
      //   37: goto -> 42
      //   40: iconst_0
      //   41: istore_1
      //   42: aload #4
      //   44: invokevirtual getActionMasked : ()I
      //   47: istore_3
      //   48: iload_1
      //   49: ifeq -> 70
      //   52: iload_2
      //   53: istore_1
      //   54: iload_3
      //   55: bipush #10
      //   57: if_icmpeq -> 79
      //   60: iload_2
      //   61: istore_1
      //   62: iload_3
      //   63: iconst_1
      //   64: if_icmpeq -> 79
      //   67: goto -> 77
      //   70: iload_2
      //   71: istore_1
      //   72: iload_3
      //   73: iconst_1
      //   74: if_icmpeq -> 79
      //   77: iconst_1
      //   78: istore_1
      //   79: iload_1
      //   80: ifeq -> 123
      //   83: iload_3
      //   84: bipush #7
      //   86: if_icmpeq -> 100
      //   89: iload_3
      //   90: bipush #9
      //   92: if_icmpeq -> 100
      //   95: iconst_2
      //   96: istore_1
      //   97: goto -> 103
      //   100: bipush #7
      //   102: istore_1
      //   103: aload_0
      //   104: getfield s0 : Landroidx/compose/ui/platform/AndroidComposeView;
      //   107: astore #5
      //   109: aload #5
      //   111: aload #4
      //   113: iload_1
      //   114: aload #5
      //   116: invokestatic E : (Landroidx/compose/ui/platform/AndroidComposeView;)J
      //   119: iconst_0
      //   120: invokestatic I : (Landroidx/compose/ui/platform/AndroidComposeView;Landroid/view/MotionEvent;IJZ)V
      //   123: return
    }
  }
  
  static final class m extends r implements dk.l<n1.b, Boolean> {
    public static final m s0 = new m();
    
    m() {
      super(1);
    }
    
    public final Boolean a(n1.b param1b) {
      q.j(param1b, "it");
      return Boolean.FALSE;
    }
  }
  
  static final class n extends r implements dk.l<dk.a<? extends v>, v> {
    n(AndroidComposeView param1AndroidComposeView) {
      super(1);
    }
    
    private static final void c(dk.a param1a) {
      q.j(param1a, "$tmp0");
      param1a.invoke();
    }
    
    public final void b(dk.a<v> param1a) {
      q.j(param1a, "command");
      Handler handler = this.s0.getHandler();
      if (handler != null) {
        Looper looper = handler.getLooper();
      } else {
        handler = null;
      } 
      if (handler == Looper.myLooper()) {
        param1a.invoke();
        return;
      } 
      handler = this.s0.getHandler();
      if (handler != null)
        handler.post(new s(param1a)); 
    }
  }
  
  static final class o extends r implements dk.a<b> {
    o(AndroidComposeView param1AndroidComposeView) {
      super(0);
    }
    
    public final AndroidComposeView.b d() {
      return AndroidComposeView.H(this.s0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\AndroidComposeView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */