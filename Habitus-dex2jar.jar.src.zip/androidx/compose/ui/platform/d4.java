package androidx.compose.ui.platform;

import android.view.View;
import androidx.lifecycle.p;
import androidx.lifecycle.s0;
import kotlin.jvm.internal.h0;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;

public interface d4 {
  public static final a a = a.a;
  
  dk.a<v> a(AbstractComposeView paramAbstractComposeView);
  
  public static final class a {
    public final d4 a() {
      return d4.b.b;
    }
  }
  
  public static final class b implements d4 {
    public static final b b = new b();
    
    public dk.a<v> a(AbstractComposeView param1AbstractComposeView) {
      q.j(param1AbstractComposeView, "view");
      b b1 = new b(param1AbstractComposeView);
      param1AbstractComposeView.addOnAttachStateChangeListener(b1);
      c c = new c(param1AbstractComposeView);
      y2.a.a((View)param1AbstractComposeView, c);
      return new a(param1AbstractComposeView, b1, c);
    }
    
    static final class a extends r implements dk.a<v> {
      a(AbstractComposeView param2AbstractComposeView, d4.b.b param2b, y2.b param2b1) {
        super(0);
      }
      
      public final void invoke() {
        this.s0.removeOnAttachStateChangeListener(this.t0);
        y2.a.g((View)this.s0, this.u0);
      }
    }
    
    public static final class b implements View.OnAttachStateChangeListener {
      b(AbstractComposeView param2AbstractComposeView) {}
      
      public void onViewAttachedToWindow(View param2View) {
        q.j(param2View, "v");
      }
      
      public void onViewDetachedFromWindow(View param2View) {
        q.j(param2View, "v");
        if (!y2.a.f((View)this.s0))
          this.s0.e(); 
      }
    }
    
    static final class c implements y2.b {
      c(AbstractComposeView param2AbstractComposeView) {}
      
      public final void b() {
        this.a.e();
      }
    }
  }
  
  static final class a extends r implements dk.a<v> {
    a(AbstractComposeView param1AbstractComposeView, d4.b.b param1b, y2.b param1b1) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.removeOnAttachStateChangeListener(this.t0);
      y2.a.g((View)this.s0, this.u0);
    }
  }
  
  public static final class b implements View.OnAttachStateChangeListener {
    b(AbstractComposeView param1AbstractComposeView) {}
    
    public void onViewAttachedToWindow(View param1View) {
      q.j(param1View, "v");
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      q.j(param1View, "v");
      if (!y2.a.f((View)this.s0))
        this.s0.e(); 
    }
  }
  
  static final class c implements y2.b {
    c(AbstractComposeView param1AbstractComposeView) {}
    
    public final void b() {
      this.a.e();
    }
  }
  
  public static final class c implements d4 {
    public static final c b = new c();
    
    public dk.a<v> a(AbstractComposeView param1AbstractComposeView) {
      q.j(param1AbstractComposeView, "view");
      if (param1AbstractComposeView.isAttachedToWindow()) {
        p p = s0.a((View)param1AbstractComposeView);
        if (p != null)
          return ViewCompositionStrategy_androidKt.a(param1AbstractComposeView, p.getLifecycle()); 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("View tree for ");
        stringBuilder.append(param1AbstractComposeView);
        stringBuilder.append(" has no ViewTreeLifecycleOwner");
        throw new IllegalStateException(stringBuilder.toString().toString());
      } 
      h0<dk.a<v>> h0 = new h0();
      c c1 = new c(param1AbstractComposeView, h0);
      param1AbstractComposeView.addOnAttachStateChangeListener(c1);
      h0.s0 = new a(param1AbstractComposeView, c1);
      return new b(h0);
    }
    
    static final class a extends r implements dk.a<v> {
      a(AbstractComposeView param2AbstractComposeView, d4.c.c param2c) {
        super(0);
      }
      
      public final void invoke() {
        this.s0.removeOnAttachStateChangeListener(this.t0);
      }
    }
    
    static final class b extends r implements dk.a<v> {
      b(h0<dk.a<v>> param2h0) {
        super(0);
      }
      
      public final void invoke() {
        ((dk.a)this.s0.s0).invoke();
      }
    }
    
    public static final class c implements View.OnAttachStateChangeListener {
      c(AbstractComposeView param2AbstractComposeView, h0<dk.a<v>> param2h0) {}
      
      public void onViewAttachedToWindow(View param2View) {
        q.j(param2View, "v");
        p p = s0.a((View)this.s0);
        AbstractComposeView abstractComposeView = this.s0;
        if (p != null) {
          this.t0.s0 = ViewCompositionStrategy_androidKt.a(abstractComposeView, p.getLifecycle());
          this.s0.removeOnAttachStateChangeListener(this);
          return;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("View tree for ");
        stringBuilder.append(abstractComposeView);
        stringBuilder.append(" has no ViewTreeLifecycleOwner");
        throw new IllegalStateException(stringBuilder.toString().toString());
      }
      
      public void onViewDetachedFromWindow(View param2View) {
        q.j(param2View, "v");
      }
    }
  }
  
  static final class a extends r implements dk.a<v> {
    a(AbstractComposeView param1AbstractComposeView, d4.c.c param1c) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.removeOnAttachStateChangeListener(this.t0);
    }
  }
  
  static final class b extends r implements dk.a<v> {
    b(h0<dk.a<v>> param1h0) {
      super(0);
    }
    
    public final void invoke() {
      ((dk.a)this.s0.s0).invoke();
    }
  }
  
  public static final class c implements View.OnAttachStateChangeListener {
    c(AbstractComposeView param1AbstractComposeView, h0<dk.a<v>> param1h0) {}
    
    public void onViewAttachedToWindow(View param1View) {
      q.j(param1View, "v");
      p p = s0.a((View)this.s0);
      AbstractComposeView abstractComposeView = this.s0;
      if (p != null) {
        this.t0.s0 = ViewCompositionStrategy_androidKt.a(abstractComposeView, p.getLifecycle());
        this.s0.removeOnAttachStateChangeListener(this);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("View tree for ");
      stringBuilder.append(abstractComposeView);
      stringBuilder.append(" has no ViewTreeLifecycleOwner");
      throw new IllegalStateException(stringBuilder.toString().toString());
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      q.j(param1View, "v");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\d4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */