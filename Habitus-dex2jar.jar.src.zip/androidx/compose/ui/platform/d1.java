package androidx.compose.ui.platform;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;
import android.view.ViewGroup;
import b1.f0;
import b1.h1;
import kotlin.jvm.internal.q;
import w0.h;

public class d1 extends ViewGroup {
  private boolean s0;
  
  public d1(Context paramContext) {
    super(paramContext);
    setClipChildren(false);
    setTag(h.hide_in_inspector_tag, Boolean.TRUE);
  }
  
  public final void a(h1 paramh1, View paramView, long paramLong) {
    q.j(paramh1, "canvas");
    q.j(paramView, "view");
    drawChild(f0.c(paramh1), paramView, paramLong);
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    q.j(paramCanvas, "canvas");
    int j = super.getChildCount();
    int i = 0;
    while (true) {
      if (i < j) {
        View view = getChildAt(i);
        q.h(view, "null cannot be cast to non-null type androidx.compose.ui.platform.ViewLayer");
        if (((g4)view).s()) {
          i = 1;
          break;
        } 
        i++;
        continue;
      } 
      i = 0;
      break;
    } 
    if (i != 0) {
      this.s0 = true;
      try {
        super.dispatchDraw(paramCanvas);
        return;
      } finally {
        this.s0 = false;
      } 
    } 
  }
  
  public int getChildCount() {
    return this.s0 ? super.getChildCount() : 0;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    setMeasuredDimension(0, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */