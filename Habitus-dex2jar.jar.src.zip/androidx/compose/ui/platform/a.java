package androidx.compose.ui.platform;

import kotlin.jvm.internal.q;

public abstract class a implements f {
  protected String a;
  
  private final int[] b = new int[2];
  
  protected final int[] c(int paramInt1, int paramInt2) {
    if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 == paramInt2)
      return null; 
    int[] arrayOfInt = this.b;
    arrayOfInt[0] = paramInt1;
    arrayOfInt[1] = paramInt2;
    return arrayOfInt;
  }
  
  protected final String d() {
    String str = this.a;
    if (str != null)
      return str; 
    q.B("text");
    return null;
  }
  
  public void e(String paramString) {
    q.j(paramString, "text");
    f(paramString);
  }
  
  protected final void f(String paramString) {
    q.j(paramString, "<set-?>");
    this.a = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */