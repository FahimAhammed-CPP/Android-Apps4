package androidx.compose.ui.platform;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Outline;
import b1.e4;
import b1.h1;
import b1.i1;
import b1.m4;
import dk.l;
import rj.v;

public interface a1 {
  int A();
  
  void B(i1 parami1, e4 parame4, l<? super h1, v> paraml);
  
  boolean C();
  
  boolean D(boolean paramBoolean);
  
  void E(Matrix paramMatrix);
  
  void F(int paramInt);
  
  int G();
  
  void H(float paramFloat);
  
  void I(float paramFloat);
  
  void J(Outline paramOutline);
  
  void K(int paramInt);
  
  void L(boolean paramBoolean);
  
  void M(int paramInt);
  
  float N();
  
  int b();
  
  int d();
  
  int e();
  
  float f();
  
  void g(float paramFloat);
  
  void h(float paramFloat);
  
  void i(int paramInt);
  
  int j();
  
  void k(float paramFloat);
  
  void l(float paramFloat);
  
  void m(m4 paramm4);
  
  void n(float paramFloat);
  
  void o(Canvas paramCanvas);
  
  void p(boolean paramBoolean);
  
  void q(float paramFloat);
  
  boolean r(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void s(float paramFloat);
  
  void t(float paramFloat);
  
  void u();
  
  void v(float paramFloat);
  
  void w(int paramInt);
  
  boolean x();
  
  void y(float paramFloat);
  
  boolean z();
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */