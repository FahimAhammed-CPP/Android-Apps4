package androidx.compose.ui.platform;

import java.text.BreakIterator;
import java.util.Locale;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;

public class b extends a {
  public static final a d = new a(null);
  
  public static final int e = 8;
  
  private static b f;
  
  private BreakIterator c;
  
  private b(Locale paramLocale) {
    i(paramLocale);
  }
  
  private final void i(Locale paramLocale) {
    BreakIterator breakIterator = BreakIterator.getCharacterInstance(paramLocale);
    q.i(breakIterator, "getCharacterInstance(locale)");
    this.c = breakIterator;
  }
  
  public int[] a(int paramInt) {
    int i = d().length();
    if (i <= 0)
      return null; 
    if (paramInt >= i)
      return null; 
    i = paramInt;
    if (paramInt < 0)
      i = 0; 
    while (true) {
      BreakIterator breakIterator2 = this.c;
      BreakIterator breakIterator1 = breakIterator2;
      if (breakIterator2 == null) {
        q.B("impl");
        breakIterator1 = null;
      } 
      if (!breakIterator1.isBoundary(i)) {
        breakIterator2 = this.c;
        breakIterator1 = breakIterator2;
        if (breakIterator2 == null) {
          q.B("impl");
          breakIterator1 = null;
        } 
        paramInt = breakIterator1.following(i);
        i = paramInt;
        if (paramInt == -1)
          return null; 
        continue;
      } 
      breakIterator2 = this.c;
      breakIterator1 = breakIterator2;
      if (breakIterator2 == null) {
        q.B("impl");
        breakIterator1 = null;
      } 
      paramInt = breakIterator1.following(i);
      return (paramInt == -1) ? null : c(i, paramInt);
    } 
  }
  
  public int[] b(int paramInt) {
    int j = d().length();
    if (j <= 0)
      return null; 
    if (paramInt <= 0)
      return null; 
    int i = paramInt;
    if (paramInt > j)
      i = j; 
    while (true) {
      BreakIterator breakIterator2 = this.c;
      BreakIterator breakIterator1 = breakIterator2;
      if (breakIterator2 == null) {
        q.B("impl");
        breakIterator1 = null;
      } 
      if (!breakIterator1.isBoundary(i)) {
        breakIterator2 = this.c;
        breakIterator1 = breakIterator2;
        if (breakIterator2 == null) {
          q.B("impl");
          breakIterator1 = null;
        } 
        paramInt = breakIterator1.preceding(i);
        i = paramInt;
        if (paramInt == -1)
          return null; 
        continue;
      } 
      breakIterator2 = this.c;
      breakIterator1 = breakIterator2;
      if (breakIterator2 == null) {
        q.B("impl");
        breakIterator1 = null;
      } 
      paramInt = breakIterator1.preceding(i);
      return (paramInt == -1) ? null : c(paramInt, i);
    } 
  }
  
  public void e(String paramString) {
    q.j(paramString, "text");
    super.e(paramString);
    BreakIterator breakIterator2 = this.c;
    BreakIterator breakIterator1 = breakIterator2;
    if (breakIterator2 == null) {
      q.B("impl");
      breakIterator1 = null;
    } 
    breakIterator1.setText(paramString);
  }
  
  public static final class a {
    private a() {}
    
    public final b a(Locale param1Locale) {
      q.j(param1Locale, "locale");
      if (b.g() == null)
        b.h(new b(param1Locale, null)); 
      b b = b.g();
      q.h(b, "null cannot be cast to non-null type androidx.compose.ui.platform.AccessibilityIterators.CharacterTextSegmentIterator");
      return b;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */