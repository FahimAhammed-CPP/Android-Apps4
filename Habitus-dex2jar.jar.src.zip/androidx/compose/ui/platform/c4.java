package androidx.compose.ui.platform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kk.g;
import kotlin.jvm.internal.q;

public final class c4 implements g<b4> {
  private final List<b4> a = new ArrayList<b4>();
  
  public final void b(String paramString, Object paramObject) {
    q.j(paramString, "name");
    this.a.add(new b4(paramString, paramObject));
  }
  
  public Iterator<b4> iterator() {
    return this.a.iterator();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\c4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */