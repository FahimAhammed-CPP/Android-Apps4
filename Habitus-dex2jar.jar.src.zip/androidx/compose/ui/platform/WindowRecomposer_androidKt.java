package androidx.compose.ui.platform;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.ViewParent;
import androidx.core.os.h;
import androidx.lifecycle.j;
import androidx.lifecycle.m;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import dk.p;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.KotlinNothingValueException;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.h0;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.channels.Channel;
import kotlinx.coroutines.channels.ChannelIterator;
import kotlinx.coroutines.channels.ChannelKt;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.SharingStarted;
import kotlinx.coroutines.flow.StateFlow;
import l0.f2;
import l0.p;
import l0.r1;
import rj.n;
import rj.v;
import vj.d;
import vj.g;
import vj.h;
import w0.h;

public final class WindowRecomposer_androidKt {
  private static final Map<Context, StateFlow<Float>> a = new LinkedHashMap<Context, StateFlow<Float>>();
  
  public static final f2 b(View paramView, g paramg, j paramj) {
    // Byte code:
    //   0: aload_0
    //   1: ldc '<this>'
    //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_1
    //   7: ldc 'coroutineContext'
    //   9: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: aload_1
    //   13: getstatic vj/e.q0 : Lvj/e$b;
    //   16: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
    //   21: ifnull -> 38
    //   24: aload_1
    //   25: astore_3
    //   26: aload_1
    //   27: getstatic l0/y0.m0 : Ll0/y0$b;
    //   30: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
    //   35: ifnonnull -> 51
    //   38: getstatic androidx/compose/ui/platform/l0.C0 : Landroidx/compose/ui/platform/l0$c;
    //   41: invokevirtual a : ()Lvj/g;
    //   44: aload_1
    //   45: invokeinterface plus : (Lvj/g;)Lvj/g;
    //   50: astore_3
    //   51: aload_3
    //   52: getstatic l0/y0.m0 : Ll0/y0$b;
    //   55: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
    //   60: checkcast l0/y0
    //   63: astore_1
    //   64: aload_1
    //   65: ifnull -> 84
    //   68: new l0/r1
    //   71: dup
    //   72: aload_1
    //   73: invokespecial <init> : (Ll0/y0;)V
    //   76: astore_1
    //   77: aload_1
    //   78: invokevirtual c : ()V
    //   81: goto -> 86
    //   84: aconst_null
    //   85: astore_1
    //   86: new kotlin/jvm/internal/h0
    //   89: dup
    //   90: invokespecial <init> : ()V
    //   93: astore #6
    //   95: aload_3
    //   96: getstatic w0/g.r0 : Lw0/g$b;
    //   99: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
    //   104: checkcast w0/g
    //   107: astore #5
    //   109: aload #5
    //   111: astore #4
    //   113: aload #5
    //   115: ifnonnull -> 134
    //   118: new androidx/compose/ui/platform/q1
    //   121: dup
    //   122: invokespecial <init> : ()V
    //   125: astore #4
    //   127: aload #6
    //   129: aload #4
    //   131: putfield s0 : Ljava/lang/Object;
    //   134: aload_1
    //   135: ifnull -> 144
    //   138: aload_1
    //   139: astore #5
    //   141: goto -> 149
    //   144: getstatic vj/h.s0 : Lvj/h;
    //   147: astore #5
    //   149: aload_3
    //   150: aload #5
    //   152: invokeinterface plus : (Lvj/g;)Lvj/g;
    //   157: aload #4
    //   159: invokeinterface plus : (Lvj/g;)Lvj/g;
    //   164: astore_3
    //   165: new l0/f2
    //   168: dup
    //   169: aload_3
    //   170: invokespecial <init> : (Lvj/g;)V
    //   173: astore #4
    //   175: aload #4
    //   177: invokevirtual g0 : ()V
    //   180: aload_3
    //   181: invokestatic CoroutineScope : (Lvj/g;)Lkotlinx/coroutines/CoroutineScope;
    //   184: astore #5
    //   186: aload_2
    //   187: astore_3
    //   188: aload_2
    //   189: ifnonnull -> 213
    //   192: aload_0
    //   193: invokestatic a : (Landroid/view/View;)Landroidx/lifecycle/p;
    //   196: astore_2
    //   197: aload_2
    //   198: ifnull -> 211
    //   201: aload_2
    //   202: invokeinterface getLifecycle : ()Landroidx/lifecycle/j;
    //   207: astore_3
    //   208: goto -> 213
    //   211: aconst_null
    //   212: astore_3
    //   213: aload_3
    //   214: ifnull -> 253
    //   217: aload_0
    //   218: new androidx/compose/ui/platform/WindowRecomposer_androidKt$a
    //   221: dup
    //   222: aload_0
    //   223: aload #4
    //   225: invokespecial <init> : (Landroid/view/View;Ll0/f2;)V
    //   228: invokevirtual addOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
    //   231: aload_3
    //   232: new androidx/compose/ui/platform/WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2
    //   235: dup
    //   236: aload #5
    //   238: aload_1
    //   239: aload #4
    //   241: aload #6
    //   243: aload_0
    //   244: invokespecial <init> : (Lkotlinx/coroutines/CoroutineScope;Ll0/r1;Ll0/f2;Lkotlin/jvm/internal/h0;Landroid/view/View;)V
    //   247: invokevirtual a : (Landroidx/lifecycle/o;)V
    //   250: aload #4
    //   252: areturn
    //   253: new java/lang/StringBuilder
    //   256: dup
    //   257: invokespecial <init> : ()V
    //   260: astore_1
    //   261: aload_1
    //   262: ldc 'ViewTreeLifecycleOwner not found from '
    //   264: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   267: pop
    //   268: aload_1
    //   269: aload_0
    //   270: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: new java/lang/IllegalStateException
    //   277: dup
    //   278: aload_1
    //   279: invokevirtual toString : ()Ljava/lang/String;
    //   282: invokevirtual toString : ()Ljava/lang/String;
    //   285: invokespecial <init> : (Ljava/lang/String;)V
    //   288: athrow
  }
  
  public static final p d(View paramView) {
    q.j(paramView, "<this>");
    p p = f(paramView);
    if (p != null)
      return p; 
    for (ViewParent viewParent = paramView.getParent(); p == null && viewParent instanceof View; viewParent = viewParent.getParent())
      p = f((View)viewParent); 
    return p;
  }
  
  private static final StateFlow<Float> e(Context paramContext) {
    synchronized (a) {
      StateFlow<Float> stateFlow;
      ContentResolver contentResolver2 = (ContentResolver)null.get(paramContext);
      ContentResolver contentResolver1 = contentResolver2;
      if (contentResolver2 == null) {
        contentResolver1 = paramContext.getContentResolver();
        Uri uri = Settings.Global.getUriFor("animator_duration_scale");
        Channel<v> channel = ChannelKt.Channel$default(-1, null, null, 6, null);
        stateFlow = FlowKt.stateIn(FlowKt.flow(new b(contentResolver1, uri, new c(channel, h.a(Looper.getMainLooper())), channel, paramContext, null)), CoroutineScopeKt.MainScope(), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.Companion, 0L, 0L, 3, null), Float.valueOf(Settings.Global.getFloat(paramContext.getContentResolver(), "animator_duration_scale", 1.0F)));
        null.put(paramContext, stateFlow);
      } 
      return stateFlow;
    } 
  }
  
  public static final p f(View paramView) {
    q.j(paramView, "<this>");
    Object object = paramView.getTag(h.androidx_compose_ui_view_composition_context);
    return (object instanceof p) ? (p)object : null;
  }
  
  private static final View g(View paramView) {
    ViewParent viewParent = paramView.getParent();
    while (viewParent instanceof View) {
      View view = (View)viewParent;
      if (view.getId() == 16908290)
        return paramView; 
      ViewParent viewParent2 = view.getParent();
      paramView = view;
      ViewParent viewParent1 = viewParent2;
    } 
    return paramView;
  }
  
  public static final f2 h(View paramView) {
    q.j(paramView, "<this>");
    if (paramView.isAttachedToWindow()) {
      paramView = g(paramView);
      p p = f(paramView);
      if (p == null)
        return v4.a.a(paramView); 
      if (p instanceof f2)
        return (f2)p; 
      throw new IllegalStateException("root viewTreeParentCompositionContext is not a Recomposer".toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot locate windowRecomposer; View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not attached to a window");
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public static final void i(View paramView, p paramp) {
    q.j(paramView, "<this>");
    paramView.setTag(h.androidx_compose_ui_view_composition_context, paramp);
  }
  
  public static final class a implements View.OnAttachStateChangeListener {
    a(View param1View, f2 param1f2) {}
    
    public void onViewAttachedToWindow(View param1View) {
      q.j(param1View, "v");
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      q.j(param1View, "v");
      this.s0.removeOnAttachStateChangeListener(this);
      this.t0.V();
    }
  }
  
  @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$getAnimationScaleFlowFor$1$1$1", f = "WindowRecomposer.android.kt", l = {115, 121}, m = "invokeSuspend")
  static final class b extends l implements p<FlowCollector<? super Float>, d<? super v>, Object> {
    Object s0;
    
    int t0;
    
    b(ContentResolver param1ContentResolver, Uri param1Uri, WindowRecomposer_androidKt.c param1c, Channel<v> param1Channel, Context param1Context, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      b b1 = new b(this.v0, this.w0, this.x0, this.y0, this.z0, (d)param1d);
      b1.u0 = param1Object;
      return (d<v>)b1;
    }
    
    public final Object invoke(FlowCollector<? super Float> param1FlowCollector, d<? super v> param1d) {
      return ((b)create(param1FlowCollector, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      b b1;
      Object object = wj.b.d();
      int i = this.t0;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            ChannelIterator channelIterator = (ChannelIterator)this.s0;
            FlowCollector flowCollector = (FlowCollector)this.u0;
            try {
              n.b(param1Object);
              param1Object = channelIterator;
              b1 = this;
            } finally {
              channelIterator = null;
            } 
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          ChannelIterator channelIterator = (ChannelIterator)this.s0;
          FlowCollector flowCollector = (FlowCollector)this.u0;
          n.b(param1Object);
          b1 = this;
          Object object1 = param1Object;
          param1Object = b1;
        } 
      } else {
        n.b(param1Object);
        FlowCollector flowCollector = (FlowCollector)this.u0;
        this.v0.registerContentObserver(this.w0, false, this.x0);
        param1Object = this.y0.iterator();
        b1 = this;
        Object object1 = param1Object;
      } 
      ((b)param1Object).v0.unregisterContentObserver(((b)param1Object).x0);
      throw b1;
    }
  }
  
  public static final class c extends ContentObserver {
    c(Channel<v> param1Channel, Handler param1Handler) {
      super(param1Handler);
    }
    
    public void onChange(boolean param1Boolean, Uri param1Uri) {
      this.a.trySend-JP2dKIU(v.a);
    }
  }
  
  public static final class WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2 implements m {
    WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2(CoroutineScope param1CoroutineScope, r1 param1r1, f2 param1f2, h0<q1> param1h0, View param1View) {}
    
    public void d(p param1p, j.a param1a) {
      r1 r11;
      q.j(param1p, "source");
      q.j(param1a, "event");
      int i = a.a[param1a.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 4)
              return; 
            this.u0.V();
            return;
          } 
          this.u0.g0();
          return;
        } 
        r11 = this.t0;
        if (r11 != null)
          r11.d(); 
        this.u0.r0();
        return;
      } 
      BuildersKt.launch$default(this.s0, null, CoroutineStart.UNDISPATCHED, new b(this.v0, this.u0, (p)r11, this, this.w0, null), 1, null);
    }
    
    @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1", f = "WindowRecomposer.android.kt", l = {394}, m = "invokeSuspend")
    static final class b extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      b(h0<q1> param1h0, f2 param1f2, p param1p, WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2 param1WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2, View param1View, d<? super b> param1d) {
        super(2, param1d);
      }
      
      public final d<v> create(Object param1Object, d<?> param1d) {
        b b1 = new b(this.u0, this.v0, this.w0, this.x0, this.y0, (d)param1d);
        b1.t0 = param1Object;
        return (d<v>)b1;
      }
      
      public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
        return ((b)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param1Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1) {
            object = this.t0;
            try {
            
            } finally {
              Exception exception = null;
              param1Object = object;
            } 
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param1Object);
          param1Object = this.t0;
          try {
            q1 q1 = (q1)this.u0.s0;
            if (q1 != null) {
              Context context = this.y0.getContext().getApplicationContext();
              q.i(context, "context.applicationContext");
              StateFlow<Float> stateFlow = WindowRecomposer_androidKt.a(context);
              q1.c(((Number)stateFlow.getValue()).floatValue());
              param1Object = BuildersKt.launch$default((CoroutineScope)param1Object, null, null, new a(stateFlow, q1, null), 3, null);
            } else {
              param1Object = null;
            } 
          } finally {
            object = null;
          } 
          if (param1Object != null)
            Job.DefaultImpls.cancel$default((Job)param1Object, null, 1, null); 
          this.w0.getLifecycle().d((o)this.x0);
          throw object;
        } 
        if (param1Object != null)
          Job.DefaultImpls.cancel$default((Job)param1Object, null, 1, null); 
        this.w0.getLifecycle().d((o)this.x0);
        return v.a;
      }
      
      @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1$1$1", f = "WindowRecomposer.android.kt", l = {389}, m = "invokeSuspend")
      static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
        int s0;
        
        a(StateFlow<Float> param2StateFlow, q1 param2q1, d<? super a> param2d) {
          super(2, param2d);
        }
        
        public final d<v> create(Object param2Object, d<?> param2d) {
          return (d<v>)new a(this.t0, this.u0, (d)param2d);
        }
        
        public final Object invoke(CoroutineScope param2CoroutineScope, d<? super v> param2d) {
          return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
        }
        
        public final Object invokeSuspend(Object<Float> param2Object) {
          Object object = wj.b.d();
          int i = this.s0;
          if (i != 0) {
            if (i != 1)
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
            n.b(param2Object);
          } else {
            n.b(param2Object);
            param2Object = (Object<Float>)this.t0;
            a a1 = new a(this.u0);
            this.s0 = 1;
            if (param2Object.collect(a1, (d)this) == object)
              return object; 
          } 
          throw new KotlinNothingValueException();
        }
        
        static final class a implements FlowCollector<Float> {
          a(q1 param3q1) {}
          
          public final Object a(float param3Float, d<? super v> param3d) {
            this.s0.c(param3Float);
            return v.a;
          }
        }
      }
      
      static final class a implements FlowCollector<Float> {
        a(q1 param2q1) {}
        
        public final Object a(float param2Float, d<? super v> param2d) {
          this.s0.c(param2Float);
          return v.a;
        }
      }
    }
    
    @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1$1$1", f = "WindowRecomposer.android.kt", l = {389}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      a(StateFlow<Float> param1StateFlow, q1 param1q1, d<? super a> param1d) {
        super(2, param1d);
      }
      
      public final d<v> create(Object param1Object, d<?> param1d) {
        return (d<v>)new a(this.t0, this.u0, (d)param1d);
      }
      
      public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
        return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object<Float> param1Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i != 1)
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
          n.b(param1Object);
        } else {
          n.b(param1Object);
          param1Object = (Object<Float>)this.t0;
          a a1 = new a(this.u0);
          this.s0 = 1;
          if (param1Object.collect(a1, (d)this) == object)
            return object; 
        } 
        throw new KotlinNothingValueException();
      }
      
      static final class a implements FlowCollector<Float> {
        a(q1 param3q1) {}
        
        public final Object a(float param3Float, d<? super v> param3d) {
          this.s0.c(param3Float);
          return v.a;
        }
      }
    }
    
    static final class a implements FlowCollector<Float> {
      a(q1 param1q1) {}
      
      public final Object a(float param1Float, d<? super v> param1d) {
        this.s0.c(param1Float);
        return v.a;
      }
    }
  }
  
  @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1", f = "WindowRecomposer.android.kt", l = {394}, m = "invokeSuspend")
  static final class b extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    b(h0<q1> param1h0, f2 param1f2, p param1p, WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2 param1WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2, View param1View, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      b b1 = new b(this.u0, this.v0, this.w0, this.x0, this.y0, (d)param1d);
      b1.t0 = param1Object;
      return (d<v>)b1;
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((b)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          object = this.t0;
          try {
          
          } finally {
            Exception exception = null;
            param1Object = object;
          } 
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0;
        try {
          q1 q1 = (q1)this.u0.s0;
          if (q1 != null) {
            Context context = this.y0.getContext().getApplicationContext();
            q.i(context, "context.applicationContext");
            StateFlow<Float> stateFlow = WindowRecomposer_androidKt.a(context);
            q1.c(((Number)stateFlow.getValue()).floatValue());
            param1Object = BuildersKt.launch$default((CoroutineScope)param1Object, null, null, new a(stateFlow, q1, null), 3, null);
          } else {
            param1Object = null;
          } 
        } finally {
          object = null;
        } 
        if (param1Object != null)
          Job.DefaultImpls.cancel$default((Job)param1Object, null, 1, null); 
        this.w0.getLifecycle().d((o)this.x0);
        throw object;
      } 
      if (param1Object != null)
        Job.DefaultImpls.cancel$default((Job)param1Object, null, 1, null); 
      this.w0.getLifecycle().d((o)this.x0);
      return v.a;
    }
    
    @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1$1$1", f = "WindowRecomposer.android.kt", l = {389}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      a(StateFlow<Float> param2StateFlow, q1 param2q1, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<v> create(Object param2Object, d<?> param2d) {
        return (d<v>)new a(this.t0, this.u0, (d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, d<? super v> param2d) {
        return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object<Float> param2Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i != 1)
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
          n.b(param2Object);
        } else {
          n.b(param2Object);
          param2Object = (Object<Float>)this.t0;
          a a1 = new a(this.u0);
          this.s0 = 1;
          if (param2Object.collect(a1, (d)this) == object)
            return object; 
        } 
        throw new KotlinNothingValueException();
      }
      
      static final class a implements FlowCollector<Float> {
        a(q1 param3q1) {}
        
        public final Object a(float param3Float, d<? super v> param3d) {
          this.s0.c(param3Float);
          return v.a;
        }
      }
    }
    
    static final class a implements FlowCollector<Float> {
      a(q1 param2q1) {}
      
      public final Object a(float param2Float, d<? super v> param2d) {
        this.s0.c(param2Float);
        return v.a;
      }
    }
  }
  
  @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1$1$1", f = "WindowRecomposer.android.kt", l = {389}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    a(StateFlow<Float> param1StateFlow, q1 param1q1, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      return (d<v>)new a(this.t0, this.u0, (d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object<Float> param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i != 1)
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
        n.b(param1Object);
      } else {
        n.b(param1Object);
        param1Object = (Object<Float>)this.t0;
        a a1 = new a(this.u0);
        this.s0 = 1;
        if (param1Object.collect(a1, (d)this) == object)
          return object; 
      } 
      throw new KotlinNothingValueException();
    }
    
    static final class a implements FlowCollector<Float> {
      a(q1 param3q1) {}
      
      public final Object a(float param3Float, d<? super v> param3d) {
        this.s0.c(param3Float);
        return v.a;
      }
    }
  }
  
  static final class a implements FlowCollector<Float> {
    a(q1 param1q1) {}
    
    public final Object a(float param1Float, d<? super v> param1d) {
      this.s0.c(param1Float);
      return v.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\WindowRecomposer_androidKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */