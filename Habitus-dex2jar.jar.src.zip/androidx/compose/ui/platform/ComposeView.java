package androidx.compose.ui.platform;

import android.content.Context;
import android.util.AttributeSet;
import dk.p;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l0.c3;
import l0.d2;
import l0.j1;
import l0.k2;
import l0.l;
import l0.n;
import rj.v;

public final class ComposeView extends AbstractComposeView {
  private final j1<p<l, Integer, v>> A0 = c3.j(null, null, 2, null);
  
  private boolean B0;
  
  public ComposeView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0, 4, null);
  }
  
  public ComposeView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public void a(l paraml, int paramInt) {
    paraml = paraml.i(420213850);
    if (n.K())
      n.V(420213850, paramInt, -1, "androidx.compose.ui.platform.ComposeView.Content (ComposeView.android.kt:426)"); 
    p p = (p)this.A0.getValue();
    if (p != null)
      p.invoke(paraml, Integer.valueOf(0)); 
    if (n.K())
      n.U(); 
    k2 k2 = paraml.l();
    if (k2 == null)
      return; 
    k2.a(new a(this, paramInt));
  }
  
  public CharSequence getAccessibilityClassName() {
    String str = ComposeView.class.getName();
    q.i(str, "javaClass.name");
    return str;
  }
  
  protected boolean getShouldCreateCompositionOnAttachedToWindow() {
    return this.B0;
  }
  
  public final void setContent(p<? super l, ? super Integer, v> paramp) {
    q.j(paramp, "content");
    this.B0 = true;
    this.A0.setValue(paramp);
    if (isAttachedToWindow())
      d(); 
  }
  
  static final class a extends r implements p<l, Integer, v> {
    a(ComposeView param1ComposeView, int param1Int) {
      super(2);
    }
    
    public final void invoke(l param1l, int param1Int) {
      this.s0.a(param1l, d2.a(this.t0 | 0x1));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\ComposeView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */