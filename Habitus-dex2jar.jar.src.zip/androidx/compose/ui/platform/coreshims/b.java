package androidx.compose.ui.platform.coreshims;

import android.view.autofill.AutofillId;

public class b {
  private final Object a;
  
  private b(AutofillId paramAutofillId) {
    this.a = paramAutofillId;
  }
  
  public static b b(AutofillId paramAutofillId) {
    return new b(paramAutofillId);
  }
  
  public AutofillId a() {
    return a.a(this.a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\coreshims\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */