package androidx.compose.ui.platform.coreshims;

import android.os.Build;
import android.view.View;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import java.util.concurrent.atomic.AtomicBoolean;

public final class g {
  private final c a;
  
  public g(View paramView) {
    if (Build.VERSION.SDK_INT >= 30) {
      this.a = new b(paramView);
      return;
    } 
    this.a = new a(paramView);
  }
  
  public void a() {
    this.a.a();
  }
  
  public void b() {
    this.a.b();
  }
  
  private static class a extends c {
    private final View a;
    
    a(View param1View) {
      this.a = param1View;
    }
    
    void a() {
      View view = this.a;
      if (view != null)
        ((InputMethodManager)view.getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.a.getWindowToken(), 0); 
    }
    
    void b() {
      View view1 = this.a;
      if (view1 == null)
        return; 
      if (view1.isInEditMode() || view1.onCheckIsTextEditor()) {
        view1.requestFocus();
      } else {
        view1 = view1.getRootView().findFocus();
      } 
      View view2 = view1;
      if (view1 == null)
        view2 = this.a.getRootView().findViewById(16908290); 
      if (view2 != null && view2.hasWindowFocus())
        view2.post(new f(view2)); 
    }
  }
  
  private static class b extends a {
    private View b;
    
    private WindowInsetsController c;
    
    b(View param1View) {
      super(param1View);
      this.b = param1View;
    }
    
    void a() {
      View view;
      WindowInsetsController windowInsetsController = this.c;
      if (windowInsetsController == null) {
        view = this.b;
        if (view != null) {
          WindowInsetsController windowInsetsController1 = h.a(view);
        } else {
          view = null;
        } 
      } 
      if (view != null) {
        AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        n n = new n(atomicBoolean);
        k.a((WindowInsetsController)view, n);
        if (!atomicBoolean.get()) {
          View view1 = this.b;
          if (view1 != null)
            ((InputMethodManager)view1.getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.b.getWindowToken(), 0); 
        } 
        l.a((WindowInsetsController)view, n);
        m.a((WindowInsetsController)view, i.a());
        return;
      } 
      super.a();
    }
    
    void b() {
      View view1;
      View view2 = this.b;
      if (view2 != null && Build.VERSION.SDK_INT < 33)
        ((InputMethodManager)view2.getContext().getSystemService("input_method")).isActive(); 
      WindowInsetsController windowInsetsController = this.c;
      if (windowInsetsController == null) {
        view1 = this.b;
        if (view1 != null) {
          WindowInsetsController windowInsetsController1 = h.a(view1);
        } else {
          view1 = null;
        } 
      } 
      if (view1 != null) {
        j.a((WindowInsetsController)view1, i.a());
        return;
      } 
      super.b();
    }
  }
  
  private static class c {
    void a() {
      throw null;
    }
    
    void b() {
      throw null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\coreshims\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */