package androidx.compose.ui.platform.coreshims;

import android.os.Build;
import android.view.View;
import android.view.autofill.AutofillId;
import android.view.contentcapture.ContentCaptureSession;

public class o {
  public static b a(View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? b.b(a.a(paramView)) : null;
  }
  
  public static e b(View paramView) {
    if (Build.VERSION.SDK_INT >= 29) {
      ContentCaptureSession contentCaptureSession = b.a(paramView);
      return (contentCaptureSession == null) ? null : e.f(contentCaptureSession, paramView);
    } 
    return null;
  }
  
  public static void c(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 30)
      c.a(paramView, paramInt); 
  }
  
  static class a {
    public static AutofillId a(View param1View) {
      return param1View.getAutofillId();
    }
  }
  
  private static class b {
    static ContentCaptureSession a(View param1View) {
      return param1View.getContentCaptureSession();
    }
  }
  
  private static class c {
    static void a(View param1View, int param1Int) {
      param1View.setImportantForContentCapture(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\coreshims\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */