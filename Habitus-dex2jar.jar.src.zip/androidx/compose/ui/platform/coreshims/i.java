package androidx.compose.ui.platform.coreshims;

import android.view.WindowInsets;



/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\coreshims\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */