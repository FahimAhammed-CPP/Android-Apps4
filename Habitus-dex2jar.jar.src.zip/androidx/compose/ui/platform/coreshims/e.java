package androidx.compose.ui.platform.coreshims;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewStructure;
import android.view.autofill.AutofillId;
import android.view.contentcapture.ContentCaptureSession;
import j$.util.Objects;
import java.util.List;

public class e {
  private final Object a;
  
  private final View b;
  
  private e(ContentCaptureSession paramContentCaptureSession, View paramView) {
    this.a = paramContentCaptureSession;
    this.b = paramView;
  }
  
  public static e f(ContentCaptureSession paramContentCaptureSession, View paramView) {
    return new e(paramContentCaptureSession, paramView);
  }
  
  public AutofillId a(long paramLong) {
    if (Build.VERSION.SDK_INT >= 29) {
      ContentCaptureSession contentCaptureSession = c.a(this.a);
      b b = o.a(this.b);
      Objects.requireNonNull(b);
      return b.a(contentCaptureSession, b.a(), paramLong);
    } 
    return null;
  }
  
  public p b(AutofillId paramAutofillId, long paramLong) {
    return (Build.VERSION.SDK_INT >= 29) ? p.f(b.c(c.a(this.a), paramAutofillId, paramLong)) : null;
  }
  
  public void c(AutofillId paramAutofillId, CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 29)
      b.e(c.a(this.a), paramAutofillId, paramCharSequence); 
  }
  
  public void d(List<ViewStructure> paramList) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 34) {
      c.a(c.a(this.a), paramList);
      return;
    } 
    if (i >= 29) {
      ViewStructure viewStructure2 = b.b(c.a(this.a), this.b);
      a.a(viewStructure2).putBoolean("TREAT_AS_VIEW_TREE_APPEARING", true);
      b.d(c.a(this.a), viewStructure2);
      for (i = 0; i < paramList.size(); i++)
        b.d(c.a(this.a), d.a(paramList.get(i))); 
      ViewStructure viewStructure1 = b.b(c.a(this.a), this.b);
      a.a(viewStructure1).putBoolean("TREAT_AS_VIEW_TREE_APPEARED", true);
      b.d(c.a(this.a), viewStructure1);
    } 
  }
  
  public void e(long[] paramArrayOflong) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 34) {
      ContentCaptureSession contentCaptureSession = c.a(this.a);
      b b = o.a(this.b);
      Objects.requireNonNull(b);
      b.f(contentCaptureSession, b.a(), paramArrayOflong);
      return;
    } 
    if (i >= 29) {
      ViewStructure viewStructure2 = b.b(c.a(this.a), this.b);
      a.a(viewStructure2).putBoolean("TREAT_AS_VIEW_TREE_APPEARING", true);
      b.d(c.a(this.a), viewStructure2);
      ContentCaptureSession contentCaptureSession = c.a(this.a);
      b b = o.a(this.b);
      Objects.requireNonNull(b);
      b.f(contentCaptureSession, b.a(), paramArrayOflong);
      ViewStructure viewStructure1 = b.b(c.a(this.a), this.b);
      a.a(viewStructure1).putBoolean("TREAT_AS_VIEW_TREE_APPEARED", true);
      b.d(c.a(this.a), viewStructure1);
    } 
  }
  
  private static class a {
    static Bundle a(ViewStructure param1ViewStructure) {
      return param1ViewStructure.getExtras();
    }
  }
  
  private static class b {
    static AutofillId a(ContentCaptureSession param1ContentCaptureSession, AutofillId param1AutofillId, long param1Long) {
      return param1ContentCaptureSession.newAutofillId(param1AutofillId, param1Long);
    }
    
    static ViewStructure b(ContentCaptureSession param1ContentCaptureSession, View param1View) {
      return param1ContentCaptureSession.newViewStructure(param1View);
    }
    
    static ViewStructure c(ContentCaptureSession param1ContentCaptureSession, AutofillId param1AutofillId, long param1Long) {
      return param1ContentCaptureSession.newVirtualViewStructure(param1AutofillId, param1Long);
    }
    
    static void d(ContentCaptureSession param1ContentCaptureSession, ViewStructure param1ViewStructure) {
      param1ContentCaptureSession.notifyViewAppeared(param1ViewStructure);
    }
    
    public static void e(ContentCaptureSession param1ContentCaptureSession, AutofillId param1AutofillId, CharSequence param1CharSequence) {
      param1ContentCaptureSession.notifyViewTextChanged(param1AutofillId, param1CharSequence);
    }
    
    static void f(ContentCaptureSession param1ContentCaptureSession, AutofillId param1AutofillId, long[] param1ArrayOflong) {
      param1ContentCaptureSession.notifyViewsDisappeared(param1AutofillId, param1ArrayOflong);
    }
  }
  
  private static class c {
    static void a(ContentCaptureSession param1ContentCaptureSession, List<ViewStructure> param1List) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\coreshims\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */