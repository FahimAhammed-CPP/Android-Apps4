package androidx.compose.ui.platform.coreshims;

import android.os.Build;
import android.view.ViewStructure;

public class p {
  private final Object a;
  
  private p(ViewStructure paramViewStructure) {
    this.a = paramViewStructure;
  }
  
  public static p f(ViewStructure paramViewStructure) {
    return new p(paramViewStructure);
  }
  
  public void a(String paramString) {
    if (Build.VERSION.SDK_INT >= 23)
      a.a(d.a(this.a), paramString); 
  }
  
  public void b(CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 23)
      a.b(d.a(this.a), paramCharSequence); 
  }
  
  public void c(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    if (Build.VERSION.SDK_INT >= 23)
      a.c(d.a(this.a), paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); 
  }
  
  public void d(CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 23)
      a.d(d.a(this.a), paramCharSequence); 
  }
  
  public ViewStructure e() {
    return d.a(this.a);
  }
  
  private static class a {
    static void a(ViewStructure param1ViewStructure, String param1String) {
      param1ViewStructure.setClassName(param1String);
    }
    
    static void b(ViewStructure param1ViewStructure, CharSequence param1CharSequence) {
      param1ViewStructure.setContentDescription(param1CharSequence);
    }
    
    static void c(ViewStructure param1ViewStructure, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      param1ViewStructure.setDimens(param1Int1, param1Int2, param1Int3, param1Int4, param1Int5, param1Int6);
    }
    
    static void d(ViewStructure param1ViewStructure, CharSequence param1CharSequence) {
      param1ViewStructure.setText(param1CharSequence);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\coreshims\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */