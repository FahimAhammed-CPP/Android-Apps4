package androidx.compose.ui.platform;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import dk.p;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.WeakHashMap;
import kotlin.jvm.internal.q;
import l0.f;
import l0.l;
import l0.o;
import l0.p;
import l0.s;
import q1.j0;
import q1.y1;
import rj.v;
import w0.h;

public final class a5 {
  private static final String a = "Wrapper";
  
  private static final ViewGroup.LayoutParams b = new ViewGroup.LayoutParams(-2, -2);
  
  public static final o a(j0 paramj0, p paramp) {
    q.j(paramj0, "container");
    q.j(paramp, "parent");
    return s.a((f)new y1(paramj0), paramp);
  }
  
  private static final o b(AndroidComposeView paramAndroidComposeView, p paramp, p<? super l, ? super Integer, v> paramp1) {
    if (d(paramAndroidComposeView)) {
      paramAndroidComposeView.setTag(h.inspection_slot_table_set, Collections.newSetFromMap(new WeakHashMap<Object, Boolean>()));
      c();
    } 
    o o = s.a((f)new y1(paramAndroidComposeView.getRoot()), paramp);
    Object object1 = paramAndroidComposeView.getView().getTag(h.wrapped_composition_tag);
    if (object1 instanceof WrappedComposition) {
      object1 = object1;
    } else {
      object1 = null;
    } 
    Object object2 = object1;
    if (object1 == null) {
      object2 = new WrappedComposition(paramAndroidComposeView, o);
      paramAndroidComposeView.getView().setTag(h.wrapped_composition_tag, object2);
    } 
    object2.e(paramp1);
    return (o)object2;
  }
  
  private static final void c() {
    if (!j1.c())
      try {
        Field field = j1.class.getDeclaredField("isDebugInspectorInfoEnabled");
        field.setAccessible(true);
        field.setBoolean(null, true);
        return;
      } catch (Exception exception) {
        Log.w(a, "Could not access isDebugInspectorInfoEnabled. Please set explicitly.");
      }  
  }
  
  private static final boolean d(AndroidComposeView paramAndroidComposeView) {
    return (Build.VERSION.SDK_INT >= 29 && (z4.a.a((View)paramAndroidComposeView).isEmpty() ^ true) != 0);
  }
  
  public static final o e(AbstractComposeView paramAbstractComposeView, p paramp, p<? super l, ? super Integer, v> paramp1) {
    q.j(paramAbstractComposeView, "<this>");
    q.j(paramp, "parent");
    q.j(paramp1, "content");
    f1.a.a();
    int i = paramAbstractComposeView.getChildCount();
    AndroidComposeView androidComposeView1 = null;
    if (i > 0) {
      View view = paramAbstractComposeView.getChildAt(0);
      if (view instanceof AndroidComposeView)
        androidComposeView1 = (AndroidComposeView)view; 
    } else {
      paramAbstractComposeView.removeAllViews();
    } 
    AndroidComposeView androidComposeView2 = androidComposeView1;
    if (androidComposeView1 == null) {
      Context context = paramAbstractComposeView.getContext();
      q.i(context, "context");
      androidComposeView2 = new AndroidComposeView(context, paramp.g());
      paramAbstractComposeView.addView(androidComposeView2.getView(), b);
    } 
    return b(androidComposeView2, paramp, paramp1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\a5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */