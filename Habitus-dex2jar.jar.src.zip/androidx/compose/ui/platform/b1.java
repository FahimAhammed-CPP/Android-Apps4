package androidx.compose.ui.platform;

import dk.a;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.q;
import rj.v;
import t0.f;

public final class b1 implements f {
  private final a<v> a;
  
  public b1(f paramf, a<v> parama) {
    this.a = parama;
    this.b = paramf;
  }
  
  public boolean a(Object paramObject) {
    q.j(paramObject, "value");
    return this.b.a(paramObject);
  }
  
  public f.a b(String paramString, a<? extends Object> parama) {
    q.j(paramString, "key");
    q.j(parama, "valueProvider");
    return this.b.b(paramString, parama);
  }
  
  public final void c() {
    this.a.invoke();
  }
  
  public Map<String, List<Object>> e() {
    return this.b.e();
  }
  
  public Object f(String paramString) {
    q.j(paramString, "key");
    return this.b.f(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */