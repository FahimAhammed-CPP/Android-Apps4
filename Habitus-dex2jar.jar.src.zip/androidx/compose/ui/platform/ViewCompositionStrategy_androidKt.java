package androidx.compose.ui.platform;

import androidx.lifecycle.j;
import androidx.lifecycle.m;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;

public final class ViewCompositionStrategy_androidKt {
  private static final dk.a<v> b(AbstractComposeView paramAbstractComposeView, j paramj) {
    ViewCompositionStrategy_androidKt$installForLifecycle$observer$1 viewCompositionStrategy_androidKt$installForLifecycle$observer$1;
    boolean bool;
    if (paramj.b().compareTo(j.b.s0) > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      viewCompositionStrategy_androidKt$installForLifecycle$observer$1 = new ViewCompositionStrategy_androidKt$installForLifecycle$observer$1(paramAbstractComposeView);
      paramj.a((o)viewCompositionStrategy_androidKt$installForLifecycle$observer$1);
      return new a(paramj, viewCompositionStrategy_androidKt$installForLifecycle$observer$1);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot configure ");
    stringBuilder.append(viewCompositionStrategy_androidKt$installForLifecycle$observer$1);
    stringBuilder.append(" to disposeComposition at Lifecycle ON_DESTROY: ");
    stringBuilder.append(paramj);
    stringBuilder.append("is already destroyed");
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  static final class a extends r implements dk.a<v> {
    a(j param1j, m param1m) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.d((o)this.t0);
    }
  }
  
  static final class ViewCompositionStrategy_androidKt$installForLifecycle$observer$1 implements m {
    ViewCompositionStrategy_androidKt$installForLifecycle$observer$1(AbstractComposeView param1AbstractComposeView) {}
    
    public final void d(p param1p, j.a param1a) {
      q.j(param1p, "<anonymous parameter 0>");
      q.j(param1a, "event");
      if (param1a == j.a.ON_DESTROY)
        this.s0.e(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\ViewCompositionStrategy_androidKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */