package androidx.compose.ui.platform;

import android.os.Binder;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewParent;
import d4.d;
import dk.l;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l0.c3;
import rj.v;
import t0.f;
import t0.h;
import w0.h;

public final class c1 {
  private static final Class<? extends Object>[] a = new Class[] { Serializable.class, Parcelable.class, String.class, SparseArray.class, Binder.class, Size.class, SizeF.class };
  
  public static final b1 a(View paramView, d paramd) {
    q.j(paramView, "view");
    q.j(paramd, "owner");
    ViewParent viewParent = paramView.getParent();
    q.h(viewParent, "null cannot be cast to non-null type android.view.View");
    View view = (View)viewParent;
    Object object1 = view.getTag(h.compose_view_saveable_id_tag);
    if (object1 instanceof String) {
      object1 = object1;
    } else {
      object1 = null;
    } 
    Object object2 = object1;
    if (object1 == null)
      object2 = String.valueOf(view.getId()); 
    return b((String)object2, paramd);
  }
  
  public static final b1 b(String paramString, d paramd) {
    boolean bool;
    q.j(paramString, "id");
    q.j(paramd, "savedStateRegistryOwner");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(f.class.getSimpleName());
    stringBuilder.append(':');
    stringBuilder.append(paramString);
    String str = stringBuilder.toString();
    androidx.savedstate.a a = paramd.getSavedStateRegistry();
    Bundle bundle = a.b(str);
    if (bundle != null) {
      Map<String, List<Object>> map = g(bundle);
    } else {
      bundle = null;
    } 
    f f = h.a((Map)bundle, c.s0);
    try {
      a.h(str, new b(f));
      bool = true;
    } catch (IllegalArgumentException illegalArgumentException) {
      bool = false;
    } 
    return new b1(f, new a(bool, a, str));
  }
  
  private static final boolean e(Object paramObject) {
    if (paramObject instanceof u0.q) {
      paramObject = paramObject;
      if (paramObject.c() == c3.k() || paramObject.c() == c3.p() || paramObject.c() == c3.m()) {
        paramObject = paramObject.getValue();
        return (paramObject == null) ? true : e(paramObject);
      } 
      return false;
    } 
    if (paramObject instanceof rj.c && paramObject instanceof Serializable)
      return false; 
    Class<? extends Object>[] arrayOfClass = a;
    int j = arrayOfClass.length;
    for (int i = 0; i < j; i++) {
      if (arrayOfClass[i].isInstance(paramObject))
        return true; 
    } 
    return false;
  }
  
  private static final Bundle f(Map<String, ? extends List<? extends Object>> paramMap) {
    Bundle bundle = new Bundle();
    for (Map.Entry<String, ? extends List<? extends Object>> entry : paramMap.entrySet()) {
      String str = (String)entry.getKey();
      List<?> list = (List)entry.getValue();
      if (list instanceof ArrayList) {
        list = list;
      } else {
        list = new ArrayList(list);
      } 
      bundle.putParcelableArrayList(str, (ArrayList)list);
    } 
    return bundle;
  }
  
  private static final Map<String, List<Object>> g(Bundle paramBundle) {
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<Object, Object>();
    Set set = paramBundle.keySet();
    q.i(set, "this.keySet()");
    for (String str : set) {
      ArrayList arrayList = paramBundle.getParcelableArrayList(str);
      q.h(arrayList, "null cannot be cast to non-null type java.util.ArrayList<kotlin.Any?>{ kotlin.collections.TypeAliasesKt.ArrayList<kotlin.Any?> }");
      q.i(str, "key");
      linkedHashMap.put(str, arrayList);
    } 
    return (Map)linkedHashMap;
  }
  
  static final class a extends r implements dk.a<v> {
    a(boolean param1Boolean, androidx.savedstate.a param1a, String param1String) {
      super(0);
    }
    
    public final void invoke() {
      if (this.s0)
        this.t0.j(this.u0); 
    }
  }
  
  static final class b implements androidx.savedstate.a.c {
    b(f param1f) {}
    
    public final Bundle saveState() {
      return c1.d(this.a.e());
    }
  }
  
  static final class c extends r implements l<Object, Boolean> {
    public static final c s0 = new c();
    
    c() {
      super(1);
    }
    
    public final Boolean a(Object param1Object) {
      q.j(param1Object, "it");
      return Boolean.valueOf(c1.c(param1Object));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */