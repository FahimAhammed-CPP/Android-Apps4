package androidx.compose.ui.platform;

import h2.i;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import w1.e0;

public final class c extends a {
  public static final a d = new a(null);
  
  public static final int e = 8;
  
  private static c f;
  
  private static final i g = i.t0;
  
  private static final i h = i.s0;
  
  private e0 c;
  
  private c() {}
  
  private final int i(int paramInt, i parami) {
    e0 e04 = this.c;
    e0 e03 = null;
    e0 e02 = e04;
    if (e04 == null) {
      q.B("layoutResult");
      e02 = null;
    } 
    int j = e02.t(paramInt);
    e04 = this.c;
    e02 = e04;
    if (e04 == null) {
      q.B("layoutResult");
      e02 = null;
    } 
    if (parami != e02.x(j)) {
      e0 e05 = this.c;
      if (e05 == null) {
        q.B("layoutResult");
        e05 = e03;
      } 
      return e05.t(paramInt);
    } 
    e02 = this.c;
    e0 e01 = e02;
    if (e02 == null) {
      q.B("layoutResult");
      e01 = null;
    } 
    return e0.o(e01, paramInt, false, 2, null) - 1;
  }
  
  public int[] a(int paramInt) {
    if (d().length() <= 0)
      return null; 
    if (paramInt >= d().length())
      return null; 
    if (paramInt < 0) {
      e0 e04 = this.c;
      e0 e03 = e04;
      if (e04 == null) {
        q.B("layoutResult");
        e03 = null;
      } 
      paramInt = e03.p(0);
    } else {
      e0 e04 = this.c;
      e0 e03 = e04;
      if (e04 == null) {
        q.B("layoutResult");
        e03 = null;
      } 
      int j = e03.p(paramInt);
      if (i(j, g) == paramInt) {
        paramInt = j;
      } else {
        paramInt = j + 1;
      } 
    } 
    e0 e02 = this.c;
    e0 e01 = e02;
    if (e02 == null) {
      q.B("layoutResult");
      e01 = null;
    } 
    return (paramInt >= e01.m()) ? null : c(i(paramInt, g), i(paramInt, h) + 1);
  }
  
  public int[] b(int paramInt) {
    if (d().length() <= 0)
      return null; 
    if (paramInt <= 0)
      return null; 
    if (paramInt > d().length()) {
      e0 e02 = this.c;
      e0 e01 = e02;
      if (e02 == null) {
        q.B("layoutResult");
        e01 = null;
      } 
      paramInt = e01.p(d().length());
    } else {
      e0 e02 = this.c;
      e0 e01 = e02;
      if (e02 == null) {
        q.B("layoutResult");
        e01 = null;
      } 
      int j = e01.p(paramInt);
      if (i(j, h) + 1 == paramInt) {
        paramInt = j;
      } else {
        paramInt = j - 1;
      } 
    } 
    return (paramInt < 0) ? null : c(i(paramInt, g), i(paramInt, h) + 1);
  }
  
  public final void j(String paramString, e0 parame0) {
    q.j(paramString, "text");
    q.j(parame0, "layoutResult");
    f(paramString);
    this.c = parame0;
  }
  
  public static final class a {
    private a() {}
    
    public final c a() {
      if (c.g() == null)
        c.h(new c(null)); 
      c c = c.g();
      q.h(c, "null cannot be cast to non-null type androidx.compose.ui.platform.AccessibilityIterators.LineTextSegmentIterator");
      return c;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */