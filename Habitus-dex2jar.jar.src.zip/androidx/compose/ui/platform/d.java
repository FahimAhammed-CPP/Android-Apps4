package androidx.compose.ui.platform;

import android.graphics.Rect;
import h2.i;
import ik.j;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import u1.p;
import w1.e0;

public final class d extends a {
  public static final a f = new a(null);
  
  public static final int g = 8;
  
  private static d h;
  
  private static final i i = i.t0;
  
  private static final i j = i.s0;
  
  private e0 c;
  
  private p d;
  
  private Rect e = new Rect();
  
  private d() {}
  
  private final int i(int paramInt, i parami) {
    e0 e04 = this.c;
    e0 e03 = null;
    e0 e02 = e04;
    if (e04 == null) {
      q.B("layoutResult");
      e02 = null;
    } 
    int j = e02.t(paramInt);
    e04 = this.c;
    e02 = e04;
    if (e04 == null) {
      q.B("layoutResult");
      e02 = null;
    } 
    if (parami != e02.x(j)) {
      e0 e05 = this.c;
      if (e05 == null) {
        q.B("layoutResult");
        e05 = e03;
      } 
      return e05.t(paramInt);
    } 
    e02 = this.c;
    e0 e01 = e02;
    if (e02 == null) {
      q.B("layoutResult");
      e01 = null;
    } 
    return e0.o(e01, paramInt, false, 2, null) - 1;
  }
  
  public int[] a(int paramInt) {
    int j = d().length();
    e0 e02 = null;
    e0 e01 = null;
    if (j <= 0)
      return null; 
    if (paramInt >= d().length())
      return null; 
    try {
      p p2 = this.d;
      p p1 = p2;
      if (p2 == null) {
        q.B("node");
        p1 = null;
      } 
      int k = fk.a.d(p1.h().h());
      j = j.d(0, paramInt);
      e0 e04 = this.c;
      e0 e03 = e04;
      if (e04 == null) {
        q.B("layoutResult");
        e03 = null;
      } 
      paramInt = e03.p(j);
      e04 = this.c;
      e03 = e04;
      if (e04 == null) {
        q.B("layoutResult");
        e03 = null;
      } 
      float f = e03.u(paramInt) + k;
      e04 = this.c;
      e03 = e04;
      if (e04 == null) {
        q.B("layoutResult");
        e03 = null;
      } 
      e0 e05 = this.c;
      e04 = e05;
      if (e05 == null) {
        q.B("layoutResult");
        e04 = null;
      } 
      if (f < e03.u(e04.m() - 1)) {
        e03 = this.c;
        if (e03 == null) {
          q.B("layoutResult");
          e03 = e01;
        } 
        paramInt = e03.q(f);
      } else {
        e03 = this.c;
        if (e03 == null) {
          q.B("layoutResult");
          e03 = e02;
        } 
        paramInt = e03.m();
      } 
      return c(j, i(paramInt - 1, j) + 1);
    } catch (IllegalStateException illegalStateException) {
      return null;
    } 
  }
  
  public int[] b(int paramInt) {
    int j = d().length();
    e0 e01 = null;
    if (j <= 0)
      return null; 
    if (paramInt <= 0)
      return null; 
    try {
      p p2 = this.d;
      p p1 = p2;
      if (p2 == null) {
        q.B("node");
        p1 = null;
      } 
      j = fk.a.d(p1.h().h());
      int k = j.g(d().length(), paramInt);
      e0 e03 = this.c;
      e0 e02 = e03;
      if (e03 == null) {
        q.B("layoutResult");
        e02 = null;
      } 
      int m = e02.p(k);
      e03 = this.c;
      e02 = e03;
      if (e03 == null) {
        q.B("layoutResult");
        e02 = null;
      } 
      float f = e02.u(m) - j;
      if (f > 0.0F) {
        e02 = this.c;
        if (e02 == null) {
          q.B("layoutResult");
          e02 = e01;
        } 
        paramInt = e02.q(f);
      } else {
        paramInt = 0;
      } 
      j = paramInt;
      if (k == d().length()) {
        j = paramInt;
        if (paramInt < m)
          j = paramInt + 1; 
      } 
      return c(i(j, i), k);
    } catch (IllegalStateException illegalStateException) {
      return null;
    } 
  }
  
  public final void j(String paramString, e0 parame0, p paramp) {
    q.j(paramString, "text");
    q.j(parame0, "layoutResult");
    q.j(paramp, "node");
    f(paramString);
    this.c = parame0;
    this.d = paramp;
  }
  
  public static final class a {
    private a() {}
    
    public final d a() {
      if (d.g() == null)
        d.h(new d(null)); 
      d d = d.g();
      q.h(d, "null cannot be cast to non-null type androidx.compose.ui.platform.AccessibilityIterators.PageTextSegmentIterator");
      return d;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */