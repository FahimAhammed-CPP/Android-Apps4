package androidx.compose.ui.platform;

import kotlin.jvm.internal.q;

public final class b4 {
  private final String a;
  
  private final Object b;
  
  public b4(String paramString, Object paramObject) {
    this.a = paramString;
    this.b = paramObject;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof b4))
      return false; 
    paramObject = paramObject;
    return !q.e(this.a, ((b4)paramObject).a) ? false : (!!q.e(this.b, ((b4)paramObject).b));
  }
  
  public int hashCode() {
    int i;
    int j = this.a.hashCode();
    Object object = this.b;
    if (object == null) {
      i = 0;
    } else {
      i = object.hashCode();
    } 
    return j * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ValueElement(name=");
    stringBuilder.append(this.a);
    stringBuilder.append(", value=");
    stringBuilder.append(this.b);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\b4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */