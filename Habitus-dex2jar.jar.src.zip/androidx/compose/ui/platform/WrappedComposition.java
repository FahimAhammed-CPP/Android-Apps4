package androidx.compose.ui.platform;

import androidx.lifecycle.j;
import androidx.lifecycle.m;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import dk.l;
import dk.p;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.m0;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import kotlinx.coroutines.CoroutineScope;
import l0.a2;
import l0.h0;
import l0.l;
import l0.n;
import l0.o;
import l0.u;
import rj.n;
import rj.v;
import s0.c;
import v0.c;
import vj.d;
import w0.h;

final class WrappedComposition implements o, m {
  private final AndroidComposeView s0;
  
  private final o t0;
  
  private boolean u0;
  
  private j v0;
  
  private p<? super l, ? super Integer, v> w0;
  
  public WrappedComposition(AndroidComposeView paramAndroidComposeView, o paramo) {
    this.s0 = paramAndroidComposeView;
    this.t0 = paramo;
    this.w0 = x0.a.a();
  }
  
  public final o A() {
    return this.t0;
  }
  
  public final AndroidComposeView B() {
    return this.s0;
  }
  
  public void d(p paramp, j.a parama) {
    q.j(paramp, "source");
    q.j(parama, "event");
    if (parama == j.a.ON_DESTROY) {
      dispose();
      return;
    } 
    if (parama == j.a.ON_CREATE && !this.u0)
      e(this.w0); 
  }
  
  public void dispose() {
    if (!this.u0) {
      this.u0 = true;
      this.s0.getView().setTag(h.wrapped_composition_tag, null);
      j j1 = this.v0;
      if (j1 != null)
        j1.d((o)this); 
    } 
    this.t0.dispose();
  }
  
  public void e(p<? super l, ? super Integer, v> paramp) {
    q.j(paramp, "content");
    this.s0.setOnViewTreeOwnersAvailable(new a(this, paramp));
  }
  
  public boolean g() {
    return this.t0.g();
  }
  
  public boolean r() {
    return this.t0.r();
  }
  
  static final class a extends r implements l<AndroidComposeView.b, v> {
    a(WrappedComposition param1WrappedComposition, p<? super l, ? super Integer, v> param1p) {
      super(1);
    }
    
    public final void a(AndroidComposeView.b param1b) {
      q.j(param1b, "it");
      if (!WrappedComposition.x(this.s0)) {
        j j = param1b.a().getLifecycle();
        WrappedComposition.z(this.s0, this.t0);
        if (WrappedComposition.w(this.s0) == null) {
          WrappedComposition.y(this.s0, j);
          j.a((o)this.s0);
          return;
        } 
        if (j.b().e(j.b.u0))
          this.s0.A().e((p)c.c(-2000640158, true, new a(this.s0, this.t0))); 
      } 
    }
    
    static final class a extends r implements p<l, Integer, v> {
      a(WrappedComposition param2WrappedComposition, p<? super l, ? super Integer, v> param2p) {
        super(2);
      }
      
      public final void invoke(l param2l, int param2Int) {
        if ((param2Int & 0xB) != 2 || !param2l.j()) {
          if (n.K())
            n.V(-2000640158, param2Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous> (Wrapper.android.kt:141)"); 
          Object object1 = this.s0.B().getTag(h.inspection_slot_table_set);
          if (m0.m(object1)) {
            object1 = object1;
          } else {
            object1 = null;
          } 
          Object object2 = object1;
          if (object1 == null) {
            object1 = this.s0.B().getParent();
            if (object1 instanceof android.view.View) {
              object1 = object1;
            } else {
              object1 = null;
            } 
            if (object1 != null) {
              object1 = object1.getTag(h.inspection_slot_table_set);
            } else {
              object1 = null;
            } 
            if (m0.m(object1)) {
              object2 = object1;
            } else {
              object2 = null;
            } 
          } 
          if (object2 != null) {
            object2.add(param2l.z());
            param2l.u();
          } 
          h0.c(this.s0.B(), new a(this.s0, null), param2l, 72);
          object1 = c.a().c(object2);
          object2 = c.b(param2l, -1193460702, true, new b(this.s0, this.t0));
          u.a(new a2[] { (a2)object1 }, (p)object2, param2l, 56);
          if (n.K())
            n.U(); 
          return;
        } 
        param2l.J();
      }
      
      @f(c = "androidx.compose.ui.platform.WrappedComposition$setContent$1$1$1", f = "Wrapper.android.kt", l = {155}, m = "invokeSuspend")
      static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
        int s0;
        
        a(WrappedComposition param3WrappedComposition, d<? super a> param3d) {
          super(2, param3d);
        }
        
        public final d<v> create(Object param3Object, d<?> param3d) {
          return (d<v>)new a(this.t0, (d)param3d);
        }
        
        public final Object invoke(CoroutineScope param3CoroutineScope, d<? super v> param3d) {
          return ((a)create(param3CoroutineScope, param3d)).invokeSuspend(v.a);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          Object object = wj.b.d();
          int i = this.s0;
          if (i != 0) {
            if (i == 1) {
              n.b(param3Object);
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            n.b(param3Object);
            param3Object = this.t0.B();
            this.s0 = 1;
            if (param3Object.P((d<? super v>)this) == object)
              return object; 
          } 
          return v.a;
        }
      }
      
      static final class b extends r implements p<l, Integer, v> {
        b(WrappedComposition param3WrappedComposition, p<? super l, ? super Integer, v> param3p) {
          super(2);
        }
        
        public final void invoke(l param3l, int param3Int) {
          if ((param3Int & 0xB) != 2 || !param3l.j()) {
            if (n.K())
              n.V(-1193460702, param3Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous>.<anonymous> (Wrapper.android.kt:156)"); 
            i0.a(this.s0.B(), this.t0, param3l, 8);
            if (n.K())
              n.U(); 
            return;
          } 
          param3l.J();
        }
      }
    }
    
    @f(c = "androidx.compose.ui.platform.WrappedComposition$setContent$1$1$1", f = "Wrapper.android.kt", l = {155}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      a(WrappedComposition param2WrappedComposition, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<v> create(Object param2Object, d<?> param2d) {
        return (d<v>)new a(this.t0, (d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, d<? super v> param2d) {
        return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1) {
            n.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param2Object);
          param2Object = this.t0.B();
          this.s0 = 1;
          if (param2Object.P((d<? super v>)this) == object)
            return object; 
        } 
        return v.a;
      }
    }
    
    static final class b extends r implements p<l, Integer, v> {
      b(WrappedComposition param2WrappedComposition, p<? super l, ? super Integer, v> param2p) {
        super(2);
      }
      
      public final void invoke(l param2l, int param2Int) {
        if ((param2Int & 0xB) != 2 || !param2l.j()) {
          if (n.K())
            n.V(-1193460702, param2Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous>.<anonymous> (Wrapper.android.kt:156)"); 
          i0.a(this.s0.B(), this.t0, param2l, 8);
          if (n.K())
            n.U(); 
          return;
        } 
        param2l.J();
      }
    }
  }
  
  static final class a extends r implements p<l, Integer, v> {
    a(WrappedComposition param1WrappedComposition, p<? super l, ? super Integer, v> param1p) {
      super(2);
    }
    
    public final void invoke(l param1l, int param1Int) {
      if ((param1Int & 0xB) != 2 || !param1l.j()) {
        if (n.K())
          n.V(-2000640158, param1Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous> (Wrapper.android.kt:141)"); 
        Object object1 = this.s0.B().getTag(h.inspection_slot_table_set);
        if (m0.m(object1)) {
          object1 = object1;
        } else {
          object1 = null;
        } 
        Object object2 = object1;
        if (object1 == null) {
          object1 = this.s0.B().getParent();
          if (object1 instanceof android.view.View) {
            object1 = object1;
          } else {
            object1 = null;
          } 
          if (object1 != null) {
            object1 = object1.getTag(h.inspection_slot_table_set);
          } else {
            object1 = null;
          } 
          if (m0.m(object1)) {
            object2 = object1;
          } else {
            object2 = null;
          } 
        } 
        if (object2 != null) {
          object2.add(param1l.z());
          param1l.u();
        } 
        h0.c(this.s0.B(), new a(this.s0, null), param1l, 72);
        object1 = c.a().c(object2);
        object2 = c.b(param1l, -1193460702, true, new b(this.s0, this.t0));
        u.a(new a2[] { (a2)object1 }, (p)object2, param1l, 56);
        if (n.K())
          n.U(); 
        return;
      } 
      param1l.J();
    }
    
    @f(c = "androidx.compose.ui.platform.WrappedComposition$setContent$1$1$1", f = "Wrapper.android.kt", l = {155}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      a(WrappedComposition param3WrappedComposition, d<? super a> param3d) {
        super(2, param3d);
      }
      
      public final d<v> create(Object param3Object, d<?> param3d) {
        return (d<v>)new a(this.t0, (d)param3d);
      }
      
      public final Object invoke(CoroutineScope param3CoroutineScope, d<? super v> param3d) {
        return ((a)create(param3CoroutineScope, param3d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1) {
            n.b(param3Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param3Object);
          param3Object = this.t0.B();
          this.s0 = 1;
          if (param3Object.P((d<? super v>)this) == object)
            return object; 
        } 
        return v.a;
      }
    }
    
    static final class b extends r implements p<l, Integer, v> {
      b(WrappedComposition param3WrappedComposition, p<? super l, ? super Integer, v> param3p) {
        super(2);
      }
      
      public final void invoke(l param3l, int param3Int) {
        if ((param3Int & 0xB) != 2 || !param3l.j()) {
          if (n.K())
            n.V(-1193460702, param3Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous>.<anonymous> (Wrapper.android.kt:156)"); 
          i0.a(this.s0.B(), this.t0, param3l, 8);
          if (n.K())
            n.U(); 
          return;
        } 
        param3l.J();
      }
    }
  }
  
  @f(c = "androidx.compose.ui.platform.WrappedComposition$setContent$1$1$1", f = "Wrapper.android.kt", l = {155}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    a(WrappedComposition param1WrappedComposition, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      return (d<v>)new a(this.t0, (d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0.B();
        this.s0 = 1;
        if (param1Object.P((d<? super v>)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
  
  static final class b extends r implements p<l, Integer, v> {
    b(WrappedComposition param1WrappedComposition, p<? super l, ? super Integer, v> param1p) {
      super(2);
    }
    
    public final void invoke(l param1l, int param1Int) {
      if ((param1Int & 0xB) != 2 || !param1l.j()) {
        if (n.K())
          n.V(-1193460702, param1Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous>.<anonymous> (Wrapper.android.kt:156)"); 
        i0.a(this.s0.B(), this.t0, param1l, 8);
        if (n.K())
          n.U(); 
        return;
      } 
      param1l.J();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\WrappedComposition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */