package androidx.compose.ui.platform;

import android.content.Context;
import android.os.IBinder;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import dk.p;
import java.lang.ref.WeakReference;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l0.f2;
import l0.l;
import l0.n;
import l0.o;
import l0.p;
import q1.i1;
import rj.v;
import s0.c;

public abstract class AbstractComposeView extends ViewGroup {
  private WeakReference<p> s0;
  
  private IBinder t0;
  
  private o u0;
  
  private p v0;
  
  private dk.a<v> w0;
  
  private boolean x0;
  
  private boolean y0;
  
  private boolean z0;
  
  public AbstractComposeView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0, 4, null);
  }
  
  public AbstractComposeView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setClipChildren(false);
    setClipToPadding(false);
    this.w0 = d4.a.a().a(this);
  }
  
  private final p b(p paramp) {
    p p1;
    if (i(paramp)) {
      p1 = paramp;
    } else {
      p1 = null;
    } 
    if (p1 != null)
      this.s0 = new WeakReference<p>(p1); 
    return paramp;
  }
  
  private final void c() {
    if (this.y0)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot add views to ");
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append("; only Compose content is supported");
    throw new UnsupportedOperationException(stringBuilder.toString());
  }
  
  private final void f() {
    if (this.u0 == null)
      try {
        this.y0 = true;
        this.u0 = a5.e(this, j(), (p<? super l, ? super Integer, v>)c.c(-656146368, true, new a(this)));
        return;
      } finally {
        this.y0 = false;
      }  
  }
  
  private final boolean i(p paramp) {
    return (!(paramp instanceof f2) || ((f2.d<f2.d>)((f2)paramp).Z().getValue()).compareTo(f2.d.t0) > 0);
  }
  
  private final p j() {
    p p2 = this.v0;
    p p1 = p2;
    if (p2 == null) {
      p1 = WindowRecomposer_androidKt.d((View)this);
      p p3 = null;
      if (p1 != null) {
        p2 = b(p1);
      } else {
        p2 = null;
      } 
      p1 = p2;
      if (p2 == null) {
        WeakReference<p> weakReference = this.s0;
        p1 = p3;
        if (weakReference != null) {
          p p5 = weakReference.get();
          p1 = p3;
          if (p5 != null) {
            p1 = p3;
            if (i(p5))
              p1 = p5; 
          } 
        } 
        p p4 = p1;
        p1 = p4;
        if (p4 == null)
          p1 = b((p)WindowRecomposer_androidKt.h((View)this)); 
      } 
    } 
    return p1;
  }
  
  private final void setParentContext(p paramp) {
    if (this.v0 != paramp) {
      this.v0 = paramp;
      if (paramp != null)
        this.s0 = null; 
      o o1 = this.u0;
      if (o1 != null) {
        o1.dispose();
        this.u0 = null;
        if (isAttachedToWindow())
          f(); 
      } 
    } 
  }
  
  private final void setPreviousAttachedWindowToken(IBinder paramIBinder) {
    if (this.t0 != paramIBinder) {
      this.t0 = paramIBinder;
      this.s0 = null;
    } 
  }
  
  public abstract void a(l paraml, int paramInt);
  
  public void addView(View paramView) {
    c();
    super.addView(paramView);
  }
  
  public void addView(View paramView, int paramInt) {
    c();
    super.addView(paramView, paramInt);
  }
  
  public void addView(View paramView, int paramInt1, int paramInt2) {
    c();
    super.addView(paramView, paramInt1, paramInt2);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    c();
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    c();
    super.addView(paramView, paramLayoutParams);
  }
  
  protected boolean addViewInLayout(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    c();
    return super.addViewInLayout(paramView, paramInt, paramLayoutParams);
  }
  
  protected boolean addViewInLayout(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    c();
    return super.addViewInLayout(paramView, paramInt, paramLayoutParams, paramBoolean);
  }
  
  public final void d() {
    boolean bool;
    if (this.v0 != null || isAttachedToWindow()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      f();
      return;
    } 
    throw new IllegalStateException("createComposition requires either a parent reference or the View to be attachedto a window. Attach the View or call setParentCompositionReference.".toString());
  }
  
  public final void e() {
    o o1 = this.u0;
    if (o1 != null)
      o1.dispose(); 
    this.u0 = null;
    requestLayout();
  }
  
  public void g(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = getChildAt(0);
    if (view != null)
      view.layout(getPaddingLeft(), getPaddingTop(), paramInt3 - paramInt1 - getPaddingRight(), paramInt4 - paramInt2 - getPaddingBottom()); 
  }
  
  public final boolean getHasComposition() {
    return (this.u0 != null);
  }
  
  protected boolean getShouldCreateCompositionOnAttachedToWindow() {
    return true;
  }
  
  public final boolean getShowLayoutBounds() {
    return this.x0;
  }
  
  public void h(int paramInt1, int paramInt2) {
    View view = getChildAt(0);
    if (view == null) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int i = Math.max(0, View.MeasureSpec.getSize(paramInt1) - getPaddingLeft() - getPaddingRight());
    int j = Math.max(0, View.MeasureSpec.getSize(paramInt2) - getPaddingTop() - getPaddingBottom());
    view.measure(View.MeasureSpec.makeMeasureSpec(i, View.MeasureSpec.getMode(paramInt1)), View.MeasureSpec.makeMeasureSpec(j, View.MeasureSpec.getMode(paramInt2)));
    setMeasuredDimension(view.getMeasuredWidth() + getPaddingLeft() + getPaddingRight(), view.getMeasuredHeight() + getPaddingTop() + getPaddingBottom());
  }
  
  public boolean isTransitionGroup() {
    return (!this.z0 || super.isTransitionGroup());
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    setPreviousAttachedWindowToken(getWindowToken());
    if (getShouldCreateCompositionOnAttachedToWindow())
      f(); 
  }
  
  protected final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    g(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected final void onMeasure(int paramInt1, int paramInt2) {
    f();
    h(paramInt1, paramInt2);
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    View view = getChildAt(0);
    if (view == null)
      return; 
    view.setLayoutDirection(paramInt);
  }
  
  public final void setParentCompositionContext(p paramp) {
    setParentContext(paramp);
  }
  
  public final void setShowLayoutBounds(boolean paramBoolean) {
    this.x0 = paramBoolean;
    View view = getChildAt(0);
    if (view != null)
      ((i1)view).setShowLayoutBounds(paramBoolean); 
  }
  
  public void setTransitionGroup(boolean paramBoolean) {
    super.setTransitionGroup(paramBoolean);
    this.z0 = true;
  }
  
  public final void setViewCompositionStrategy(d4 paramd4) {
    q.j(paramd4, "strategy");
    dk.a<v> a1 = this.w0;
    if (a1 != null)
      a1.invoke(); 
    this.w0 = paramd4.a(this);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  static final class a extends r implements p<l, Integer, v> {
    a(AbstractComposeView param1AbstractComposeView) {
      super(2);
    }
    
    public final void invoke(l param1l, int param1Int) {
      if ((param1Int & 0xB) != 2 || !param1l.j()) {
        if (n.K())
          n.V(-656146368, param1Int, -1, "androidx.compose.ui.platform.AbstractComposeView.ensureCompositionCreated.<anonymous> (ComposeView.android.kt:250)"); 
        this.s0.a(param1l, 8);
        if (n.K())
          n.U(); 
        return;
      } 
      param1l.J();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\platform\AbstractComposeView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */