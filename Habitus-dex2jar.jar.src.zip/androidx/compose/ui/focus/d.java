package androidx.compose.ui.focus;

import kotlin.jvm.internal.h;

public final class d {
  public static final a b = new a(null);
  
  private static final int c = j(1);
  
  private static final int d = j(2);
  
  private static final int e = j(3);
  
  private static final int f = j(4);
  
  private static final int g = j(5);
  
  private static final int h = j(6);
  
  private static final int i;
  
  private static final int j;
  
  private static final int k;
  
  private static final int l;
  
  private final int a;
  
  static {
    int i = j(7);
    i = i;
    int j = j(8);
    j = j;
    k = i;
    l = j;
  }
  
  public static int j(int paramInt) {
    return paramInt;
  }
  
  public static boolean k(int paramInt, Object paramObject) {
    return !(paramObject instanceof d) ? false : (!(paramInt != ((d)paramObject).o()));
  }
  
  public static final boolean l(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  public static int m(int paramInt) {
    return paramInt;
  }
  
  public static String n(int paramInt) {
    return l(paramInt, c) ? "Next" : (l(paramInt, d) ? "Previous" : (l(paramInt, e) ? "Left" : (l(paramInt, f) ? "Right" : (l(paramInt, g) ? "Up" : (l(paramInt, h) ? "Down" : (l(paramInt, i) ? "Enter" : (l(paramInt, j) ? "Exit" : "Invalid FocusDirection")))))));
  }
  
  public boolean equals(Object paramObject) {
    return k(this.a, paramObject);
  }
  
  public int hashCode() {
    return m(this.a);
  }
  
  public String toString() {
    return n(this.a);
  }
  
  public static final class a {
    private a() {}
    
    public final int a() {
      return d.a();
    }
    
    public final int b() {
      return d.b();
    }
    
    public final int c() {
      return d.c();
    }
    
    public final int d() {
      return d.d();
    }
    
    public final int e() {
      return d.e();
    }
    
    public final int f() {
      return d.f();
    }
    
    public final int g() {
      return d.g();
    }
    
    public final int h() {
      return d.h();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */