package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import rj.v;

public final class i {
  public static final e a(e parame, l<? super g, v> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "scope");
    return parame.then((e)new FocusPropertiesElement(paraml));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */