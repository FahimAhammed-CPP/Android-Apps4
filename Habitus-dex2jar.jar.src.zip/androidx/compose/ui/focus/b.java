package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import rj.v;
import z0.o;

public final class b {
  public static final e a(e parame, l<? super o, v> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "onFocusChanged");
    return parame.then((e)new FocusChangedElement(paraml));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */