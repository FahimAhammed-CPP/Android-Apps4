package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import m0.f;
import q1.k;
import q1.l;
import q1.z0;
import z0.n;

public final class m {
  public static final boolean a(n paramn) {
    FocusTargetNode focusTargetNode;
    q.j(paramn, "<this>");
    int i = z0.a(1024);
    e.c c2 = paramn.Q();
    e.c c1 = null;
    while (c2 != null) {
      int j;
      f f2;
      if (c2 instanceof FocusTargetNode) {
        focusTargetNode = (FocusTargetNode)c2;
        return focusTargetNode.E1().q() ? o.j(focusTargetNode) : s.k(focusTargetNode, d.b.b(), a.s0);
      } 
      if ((c2.c1() & i) != 0) {
        j = 1;
      } else {
        j = 0;
      } 
      e.c c = c1;
      if (j) {
        c = c1;
        if (c2 instanceof l) {
          f f;
          c = ((l)c2).B1();
          for (j = 0; c != null; j = k) {
            boolean bool;
            f f3;
            if ((c.c1() & i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            e.c c3 = c2;
            e.c c4 = c1;
            int k = j;
            if (bool) {
              k = j + 1;
              if (k == 1) {
                c3 = c;
                c4 = c1;
              } else {
                f f4;
                c3 = c1;
                if (c1 == null)
                  f4 = new f((Object[])new e.c[16], 0); 
                c1 = c2;
                if (c2 != null) {
                  f4.d(c2);
                  c1 = null;
                } 
                f4.d(c);
                f3 = f4;
                c3 = c1;
              } 
            } 
            c = c.Y0();
            c2 = c3;
            f = f3;
          } 
          f2 = f;
          if (j == 1)
            continue; 
        } 
      } 
      c2 = k.b(f2);
      f f1 = f2;
    } 
    if (focusTargetNode.Q().h1()) {
      f f = new f((Object[])new e.c[16], 0);
      c1 = focusTargetNode.Q().Y0();
      if (c1 == null) {
        k.a(f, focusTargetNode.Q());
      } else {
        f.d(c1);
      } 
      while (f.w()) {
        e.c c3 = (e.c)f.B(f.s() - 1);
        e.c c4 = c3;
        if ((c3.X0() & i) == 0) {
          k.a(f, c3);
          continue;
        } 
        while (c4 != null) {
          if ((c4.c1() & i) != 0) {
            c3 = null;
            while (c4 != null) {
              int j;
              f f2;
              if (c4 instanceof FocusTargetNode) {
                c3 = c4;
                return c3.E1().q() ? o.j((FocusTargetNode)c3) : s.k((FocusTargetNode)c3, d.b.b(), a.s0);
              } 
              if ((c4.c1() & i) != 0) {
                j = 1;
              } else {
                j = 0;
              } 
              c1 = c3;
              if (j) {
                c1 = c3;
                if (c4 instanceof l) {
                  f f3;
                  c1 = ((l)c4).B1();
                  j = 0;
                  while (c1 != null) {
                    boolean bool;
                    f f4;
                    if ((c1.c1() & i) != 0) {
                      bool = true;
                    } else {
                      bool = false;
                    } 
                    c2 = c3;
                    int k = j;
                    e.c c = c4;
                    if (bool) {
                      k = j + 1;
                      if (k == 1) {
                        c = c1;
                        c2 = c3;
                      } else {
                        c2 = c3;
                        if (c3 == null)
                          f4 = new f((Object[])new e.c[16], 0); 
                        c = c4;
                        if (c4 != null) {
                          f4.d(c4);
                          c = null;
                        } 
                        f4.d(c1);
                      } 
                    } 
                    c1 = c1.Y0();
                    f3 = f4;
                    j = k;
                    c4 = c;
                  } 
                  f2 = f3;
                  if (j == 1)
                    continue; 
                } 
              } 
              c4 = k.b(f2);
              f f1 = f2;
            } 
            break;
          } 
          c4 = c4.Y0();
        } 
      } 
      return false;
    } 
    throw new IllegalStateException("visitChildren called on an unattached node".toString());
  }
  
  static final class a extends r implements l<FocusTargetNode, Boolean> {
    public static final a s0 = new a();
    
    a() {
      super(1);
    }
    
    public final Boolean a(FocusTargetNode param1FocusTargetNode) {
      q.j(param1FocusTargetNode, "it");
      return Boolean.valueOf(o.j(param1FocusTargetNode));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */