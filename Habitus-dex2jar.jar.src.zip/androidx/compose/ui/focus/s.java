package androidx.compose.ui.focus;

import a1.h;
import androidx.compose.ui.e;
import dk.l;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import m0.f;
import o1.c;
import q1.j;
import q1.k;
import q1.l;
import q1.z0;
import z0.p;

public final class s {
  private static final FocusTargetNode b(FocusTargetNode paramFocusTargetNode) {
    boolean bool;
    if (paramFocusTargetNode.G1() == p.t0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      paramFocusTargetNode = p.b(paramFocusTargetNode);
      if (paramFocusTargetNode != null)
        return paramFocusTargetNode; 
      throw new IllegalStateException("ActiveParent must have a focusedChild".toString());
    } 
    throw new IllegalStateException("Check failed.".toString());
  }
  
  private static final boolean c(h paramh1, h paramh2, h paramh3, int paramInt) {
    if (!d(paramh3, paramInt, paramh1)) {
      if (!d(paramh2, paramInt, paramh1))
        return false; 
      if (!e(paramh3, paramInt, paramh1))
        return true; 
      d.a a = d.b;
      if (d.l(paramInt, a.d()) || d.l(paramInt, a.g()) || f(paramh2, paramInt, paramh1) < g(paramh3, paramInt, paramh1))
        return true; 
    } 
    return false;
  }
  
  private static final boolean d(h paramh1, int paramInt, h paramh2) {
    boolean bool;
    d.a a = d.b;
    if (d.l(paramInt, a.d())) {
      bool = true;
    } else {
      bool = d.l(paramInt, a.g());
    } 
    if (bool)
      return (paramh1.e() > paramh2.l() && paramh1.l() < paramh2.e()); 
    if (d.l(paramInt, a.h())) {
      bool = true;
    } else {
      bool = d.l(paramInt, a.a());
    } 
    if (bool)
      return (paramh1.j() > paramh2.i() && paramh1.i() < paramh2.j()); 
    throw new IllegalStateException("This function should only be used for 2-D focus search".toString());
  }
  
  private static final boolean e(h paramh1, int paramInt, h paramh2) {
    d.a a = d.b;
    if (d.l(paramInt, a.d()))
      return (paramh2.i() >= paramh1.j()); 
    if (d.l(paramInt, a.g()))
      return (paramh2.j() <= paramh1.i()); 
    if (d.l(paramInt, a.h()))
      return (paramh2.l() >= paramh1.e()); 
    if (d.l(paramInt, a.a()))
      return (paramh2.e() <= paramh1.l()); 
    throw new IllegalStateException("This function should only be used for 2-D focus search".toString());
  }
  
  private static final float f(h paramh1, int paramInt, h paramh2) {
    float f2;
    d.a a = d.b;
    if (d.l(paramInt, a.d())) {
      f2 = paramh2.i();
      f1 = paramh1.j();
    } else {
      if (d.l(paramInt, a.g())) {
        f1 = paramh1.i();
        f2 = paramh2.j();
      } else {
        if (d.l(paramInt, a.h())) {
          f2 = paramh2.l();
          f1 = paramh1.e();
        } else {
          if (d.l(paramInt, a.a())) {
            f1 = paramh1.l();
            f2 = paramh2.e();
          } else {
            throw new IllegalStateException("This function should only be used for 2-D focus search".toString());
          } 
          f1 -= f2;
        } 
        f1 = f2 - f1;
      } 
      f1 -= f2;
    } 
    float f1 = f2 - f1;
  }
  
  private static final float g(h paramh1, int paramInt, h paramh2) {
    float f2;
    d.a a = d.b;
    if (d.l(paramInt, a.d())) {
      f2 = paramh2.i();
      f1 = paramh1.i();
    } else {
      if (d.l(paramInt, a.g())) {
        f1 = paramh1.j();
        f2 = paramh2.j();
      } else {
        if (d.l(paramInt, a.h())) {
          f2 = paramh2.l();
          f1 = paramh1.l();
        } else {
          if (d.l(paramInt, a.a())) {
            f1 = paramh1.e();
            f2 = paramh2.e();
          } else {
            throw new IllegalStateException("This function should only be used for 2-D focus search".toString());
          } 
          f1 -= f2;
        } 
        f1 = f2 - f1;
      } 
      f1 -= f2;
    } 
    float f1 = f2 - f1;
  }
  
  private static final h h(h paramh) {
    return new h(paramh.j(), paramh.e(), paramh.j(), paramh.e());
  }
  
  private static final void i(j paramj, f<FocusTargetNode> paramf) {
    int i = z0.a(1024);
    if (paramj.Q().h1()) {
      f f1 = new f((Object[])new e.c[16], 0);
      e.c c = paramj.Q().Y0();
      if (c == null) {
        k.a(f1, paramj.Q());
      } else {
        f1.d(c);
      } 
      while (f1.w()) {
        e.c c1 = (e.c)f1.B(f1.s() - 1);
        e.c c2 = c1;
        if ((c1.X0() & i) == 0) {
          k.a(f1, c1);
          continue;
        } 
        while (c2 != null) {
          if ((c2.c1() & i) != 0) {
            c1 = null;
            while (c2 != null) {
              f f3;
              if (c2 instanceof FocusTargetNode) {
                c2 = c2;
                c = c1;
                if (c2.h1())
                  if (c2.E1().q()) {
                    paramf.d(c2);
                    c = c1;
                  } else {
                    i((j)c2, paramf);
                    c = c1;
                  }  
              } else {
                int k;
                if ((c2.c1() & i) != 0) {
                  k = 1;
                } else {
                  k = 0;
                } 
                c = c1;
                if (k) {
                  c = c1;
                  if (c2 instanceof l) {
                    f f4;
                    c = ((l)c2).B1();
                    k = 0;
                    while (c != null) {
                      boolean bool;
                      f f5;
                      if ((c.c1() & i) != 0) {
                        bool = true;
                      } else {
                        bool = false;
                      } 
                      e.c c3 = c1;
                      int m = k;
                      e.c c4 = c2;
                      if (bool) {
                        m = k + 1;
                        if (m == 1) {
                          c4 = c;
                          c3 = c1;
                        } else {
                          c3 = c1;
                          if (c1 == null)
                            f5 = new f((Object[])new e.c[16], 0); 
                          c4 = c2;
                          if (c2 != null) {
                            f5.d(c2);
                            c4 = null;
                          } 
                          f5.d(c);
                        } 
                      } 
                      c = c.Y0();
                      f4 = f5;
                      k = m;
                      c2 = c4;
                    } 
                    f3 = f4;
                    if (k == 1)
                      continue; 
                  } 
                } 
              } 
              c2 = k.b(f3);
              f f2 = f3;
            } 
            break;
          } 
          c2 = c2.Y0();
        } 
      } 
      return;
    } 
    throw new IllegalStateException("visitChildren called on an unattached node".toString());
  }
  
  private static final FocusTargetNode j(f<FocusTargetNode> paramf, h paramh, int paramInt) {
    h h1;
    FocusTargetNode focusTargetNode;
    d.a a = d.b;
    if (d.l(paramInt, a.d())) {
      h1 = paramh.q(paramh.n() + true, 0.0F);
    } else if (d.l(paramInt, h1.g())) {
      h1 = paramh.q(-(paramh.n() + true), 0.0F);
    } else if (d.l(paramInt, h1.h())) {
      h1 = paramh.q(0.0F, paramh.h() + true);
    } else if (d.l(paramInt, h1.a())) {
      h1 = paramh.q(0.0F, -(paramh.h() + true));
    } else {
      throw new IllegalStateException("This function should only be used for 2-D focus search".toString());
    } 
    int i = paramf.s();
    h h2 = null;
    h h3 = null;
    if (i > 0) {
      Object[] arrayOfObject = paramf.r();
      int j = 0;
      h2 = h3;
      while (true) {
        FocusTargetNode focusTargetNode1;
        FocusTargetNode focusTargetNode2 = (FocusTargetNode)arrayOfObject[j];
        h3 = h1;
        h h4 = h2;
        if (p.g(focusTargetNode2)) {
          h h5 = p.d(focusTargetNode2);
          h3 = h1;
          h4 = h2;
          if (m(h5, h1, paramh, paramInt)) {
            focusTargetNode1 = focusTargetNode2;
            h3 = h5;
          } 
        } 
        int k = j + 1;
        h1 = h3;
        focusTargetNode = focusTargetNode1;
        j = k;
        if (k >= i) {
          focusTargetNode = focusTargetNode1;
          break;
        } 
      } 
    } 
    return focusTargetNode;
  }
  
  public static final boolean k(FocusTargetNode paramFocusTargetNode, int paramInt, l<? super FocusTargetNode, Boolean> paraml) {
    q.j(paramFocusTargetNode, "$this$findChildCorrespondingToFocusEnter");
    q.j(paraml, "onFound");
    FocusTargetNode[] arrayOfFocusTargetNode = new FocusTargetNode[16];
    boolean bool1 = false;
    boolean bool = false;
    f<FocusTargetNode> f = new f((Object[])arrayOfFocusTargetNode, 0);
    i((j)paramFocusTargetNode, f);
    int i = f.s();
    boolean bool2 = true;
    if (i <= 1) {
      if (f.v()) {
        paramFocusTargetNode = null;
      } else {
        object = f.r()[0];
      } 
      object = object;
      if (object != null)
        bool = ((Boolean)paraml.invoke(object)).booleanValue(); 
      return bool;
    } 
    d.a a = d.b;
    i = paramInt;
    if (d.l(paramInt, a.b()))
      i = a.g(); 
    if (d.l(i, a.g())) {
      bool = true;
    } else {
      bool = d.l(i, a.a());
    } 
    if (bool) {
      object = s(p.d((FocusTargetNode)object));
    } else {
      if (d.l(i, a.d())) {
        bool = bool2;
      } else {
        bool = d.l(i, a.h());
      } 
      if (bool) {
        object = h(p.d((FocusTargetNode)object));
      } else {
        throw new IllegalStateException("This function should only be used for 2-D focus search".toString());
      } 
    } 
    Object object = j(f, (h)object, i);
    bool = bool1;
    if (object != null)
      bool = ((Boolean)paraml.invoke(object)).booleanValue(); 
    return bool;
  }
  
  private static final boolean l(FocusTargetNode paramFocusTargetNode1, FocusTargetNode paramFocusTargetNode2, int paramInt, l<? super FocusTargetNode, Boolean> paraml) {
    if (r(paramFocusTargetNode1, paramFocusTargetNode2, paramInt, paraml))
      return true; 
    Boolean bool = a.<Boolean>a(paramFocusTargetNode1, paramInt, new b(paramFocusTargetNode1, paramFocusTargetNode2, paramInt, paraml));
    return (bool != null) ? bool.booleanValue() : false;
  }
  
  private static final boolean m(h paramh1, h paramh2, h paramh3, int paramInt) {
    if (!n(paramh1, paramInt, paramh3))
      return false; 
    if (n(paramh2, paramInt, paramh3) && !c(paramh3, paramh1, paramh2, paramInt)) {
      if (c(paramh3, paramh2, paramh1, paramInt))
        return false; 
      if (q(paramInt, paramh3, paramh1) >= q(paramInt, paramh3, paramh2))
        return false; 
    } 
    return true;
  }
  
  private static final boolean n(h paramh1, int paramInt, h paramh2) {
    d.a a = d.b;
    if (d.l(paramInt, a.d()))
      return ((paramh2.j() > paramh1.j() || paramh2.i() >= paramh1.j()) && paramh2.i() > paramh1.i()); 
    if (d.l(paramInt, a.g()))
      return ((paramh2.i() < paramh1.i() || paramh2.j() <= paramh1.i()) && paramh2.j() < paramh1.j()); 
    if (d.l(paramInt, a.h()))
      return ((paramh2.e() > paramh1.e() || paramh2.l() >= paramh1.e()) && paramh2.l() > paramh1.l()); 
    if (d.l(paramInt, a.a()))
      return ((paramh2.l() < paramh1.l() || paramh2.e() <= paramh1.l()) && paramh2.e() < paramh1.e()); 
    throw new IllegalStateException("This function should only be used for 2-D focus search".toString());
  }
  
  private static final float o(h paramh1, int paramInt, h paramh2) {
    float f2;
    d.a a = d.b;
    if (d.l(paramInt, a.d())) {
      f2 = paramh2.i();
      f1 = paramh1.j();
    } else {
      if (d.l(paramInt, a.g())) {
        f1 = paramh1.i();
        f2 = paramh2.j();
      } else {
        if (d.l(paramInt, a.h())) {
          f2 = paramh2.l();
          f1 = paramh1.e();
        } else {
          if (d.l(paramInt, a.a())) {
            f1 = paramh1.l();
            f2 = paramh2.e();
          } else {
            throw new IllegalStateException("This function should only be used for 2-D focus search".toString());
          } 
          f1 -= f2;
        } 
        f1 = f2 - f1;
      } 
      f1 -= f2;
    } 
    float f1 = f2 - f1;
  }
  
  private static final float p(h paramh1, int paramInt, h paramh2) {
    d.a a = d.b;
    boolean bool = d.l(paramInt, a.d());
    boolean bool1 = true;
    if (bool) {
      bool = true;
    } else {
      bool = d.l(paramInt, a.g());
    } 
    if (bool) {
      float f2 = paramh2.l();
      float f3 = paramh2.h();
      float f1 = 2;
      f3 = f2 + f3 / f1;
      float f4 = paramh1.l();
      f2 = paramh1.h();
      return f3 - f4 + f2 / f1;
    } 
    if (d.l(paramInt, a.h())) {
      bool = bool1;
    } else {
      bool = d.l(paramInt, a.a());
    } 
    if (bool) {
      float f2 = paramh2.i();
      float f3 = paramh2.n();
      float f1 = 2;
      f3 = f2 + f3 / f1;
      float f4 = paramh1.i();
      f2 = paramh1.n();
      return f3 - f4 + f2 / f1;
    } 
    throw new IllegalStateException("This function should only be used for 2-D focus search".toString());
  }
  
  private static final long q(int paramInt, h paramh1, h paramh2) {
    long l1 = (long)Math.abs(o(paramh2, paramInt, paramh1));
    long l2 = (long)Math.abs(p(paramh2, paramInt, paramh1));
    return 13L * l1 * l1 + l2 * l2;
  }
  
  private static final boolean r(FocusTargetNode paramFocusTargetNode1, FocusTargetNode paramFocusTargetNode2, int paramInt, l<? super FocusTargetNode, Boolean> paraml) {
    f<FocusTargetNode> f = new f((Object[])new FocusTargetNode[16], 0);
    int i = z0.a(1024);
    if (paramFocusTargetNode1.Q().h1()) {
      f f1 = new f((Object[])new e.c[16], 0);
      e.c c = paramFocusTargetNode1.Q().Y0();
      if (c == null) {
        k.a(f1, paramFocusTargetNode1.Q());
      } else {
        f1.d(c);
      } 
      while (f1.w()) {
        e.c c1 = (e.c)f1.B(f1.s() - 1);
        e.c c2 = c1;
        if ((c1.X0() & i) == 0) {
          k.a(f1, c1);
          continue;
        } 
        while (c2 != null) {
          if ((c2.c1() & i) != 0) {
            c1 = null;
            while (c2 != null) {
              f f3;
              if (c2 instanceof FocusTargetNode) {
                f.d(c2);
                c = c1;
              } else {
                int j;
                if ((c2.c1() & i) != 0) {
                  j = 1;
                } else {
                  j = 0;
                } 
                c = c1;
                if (j) {
                  c = c1;
                  if (c2 instanceof l) {
                    f f4;
                    c = ((l)c2).B1();
                    j = 0;
                    while (c != null) {
                      boolean bool;
                      f f5;
                      if ((c.c1() & i) != 0) {
                        bool = true;
                      } else {
                        bool = false;
                      } 
                      e.c c3 = c1;
                      int k = j;
                      e.c c4 = c2;
                      if (bool) {
                        k = j + 1;
                        if (k == 1) {
                          c4 = c;
                          c3 = c1;
                        } else {
                          c3 = c1;
                          if (c1 == null)
                            f5 = new f((Object[])new e.c[16], 0); 
                          c4 = c2;
                          if (c2 != null) {
                            f5.d(c2);
                            c4 = null;
                          } 
                          f5.d(c);
                        } 
                      } 
                      c = c.Y0();
                      f4 = f5;
                      j = k;
                      c2 = c4;
                    } 
                    f3 = f4;
                    if (j == 1)
                      continue; 
                  } 
                } 
              } 
              c2 = k.b(f3);
              f f2 = f3;
            } 
            break;
          } 
          c2 = c2.Y0();
        } 
      } 
      while (f.w()) {
        paramFocusTargetNode1 = j(f, p.d(paramFocusTargetNode2), paramInt);
        if (paramFocusTargetNode1 == null)
          return false; 
        if (paramFocusTargetNode1.E1().q())
          return ((Boolean)paraml.invoke(paramFocusTargetNode1)).booleanValue(); 
        if (l(paramFocusTargetNode1, paramFocusTargetNode2, paramInt, paraml))
          return true; 
        f.z(paramFocusTargetNode1);
      } 
      return false;
    } 
    throw new IllegalStateException("visitChildren called on an unattached node".toString());
  }
  
  private static final h s(h paramh) {
    return new h(paramh.i(), paramh.l(), paramh.i(), paramh.l());
  }
  
  public static final Boolean t(FocusTargetNode paramFocusTargetNode, int paramInt, l<? super FocusTargetNode, Boolean> paraml) {
    q.j(paramFocusTargetNode, "$this$twoDimensionalFocusSearch");
    q.j(paraml, "onFound");
    p p = paramFocusTargetNode.G1();
    int[] arrayOfInt = a.a;
    int i = arrayOfInt[p.ordinal()];
    if (i != 1) {
      if (i != 2 && i != 3) {
        if (i == 4)
          return paramFocusTargetNode.E1().q() ? (Boolean)paraml.invoke(paramFocusTargetNode) : Boolean.FALSE; 
        throw new NoWhenBranchMatchedException();
      } 
      return Boolean.valueOf(k(paramFocusTargetNode, paramInt, paraml));
    } 
    FocusTargetNode focusTargetNode = p.f(paramFocusTargetNode);
    if (focusTargetNode != null) {
      i = arrayOfInt[focusTargetNode.G1().ordinal()];
      if (i != 1) {
        if (i != 2 && i != 3) {
          if (i != 4)
            throw new NoWhenBranchMatchedException(); 
          throw new IllegalStateException("ActiveParent must have a focusedChild".toString());
        } 
        return Boolean.valueOf(l(paramFocusTargetNode, focusTargetNode, paramInt, paraml));
      } 
      Boolean bool = t(focusTargetNode, paramInt, paraml);
      return !q.e(bool, Boolean.FALSE) ? bool : Boolean.valueOf(l(paramFocusTargetNode, b(focusTargetNode), paramInt, paraml));
    } 
    throw new IllegalStateException("ActiveParent must have a focusedChild".toString());
  }
  
  static final class b extends r implements l<c.a, Boolean> {
    b(FocusTargetNode param1FocusTargetNode1, FocusTargetNode param1FocusTargetNode2, int param1Int, l<? super FocusTargetNode, Boolean> param1l) {
      super(1);
    }
    
    public final Boolean a(c.a param1a) {
      boolean bool;
      q.j(param1a, "$this$searchBeyondBounds");
      Boolean bool1 = Boolean.valueOf(s.a(this.s0, this.t0, this.u0, this.v0));
      if (bool1.booleanValue() || !param1a.a()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool ? bool1 : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */