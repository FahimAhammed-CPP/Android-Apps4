package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import q1.u0;
import rj.v;
import z0.o;

final class FocusChangedElement extends u0<c> {
  private final l<o, v> c;
  
  public FocusChangedElement(l<? super o, v> paraml) {
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof FocusChangedElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((FocusChangedElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public c s() {
    return new c(this.c);
  }
  
  public void t(c paramc) {
    q.j(paramc, "node");
    paramc.A1(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FocusChangedElement(onFocusChanged=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\FocusChangedElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */