package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import z0.n;

final class n extends e.c implements n {
  private k F0;
  
  public n(k paramk) {
    this.F0 = paramk;
  }
  
  public final k A1() {
    return this.F0;
  }
  
  public final void B1(k paramk) {
    q.j(paramk, "<set-?>");
    this.F0 = paramk;
  }
  
  public void k1() {
    super.k1();
    this.F0.d().d(this);
  }
  
  public void l1() {
    this.F0.d().z(this);
    super.l1();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */