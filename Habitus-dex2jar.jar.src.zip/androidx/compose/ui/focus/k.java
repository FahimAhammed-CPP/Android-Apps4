package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import m0.f;
import q1.l;
import q1.z0;
import z0.n;

public final class k {
  public static final a b = new a(null);
  
  private static final k c = new k();
  
  private static final k d = new k();
  
  private final f<n> a = new f((Object[])new n[16], 0);
  
  public final boolean c() {
    int i;
    a a1 = b;
    if (this != a1.b()) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      if (this != a1.a()) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i) {
        if (this.a.w()) {
          f<n> f1 = this.a;
          int j = f1.s();
          if (j > 0) {
            Object[] arrayOfObject = f1.r();
            i = 0;
            boolean bool = false;
            while (true) {
              n n = (n)arrayOfObject[i];
              int m = z0.a(1024);
              if (n.Q().h1()) {
                boolean bool1;
                f f2 = new f((Object[])new e.c[16], 0);
                e.c c = n.Q().Y0();
                if (c == null) {
                  q1.k.a(f2, n.Q());
                } else {
                  f2.d(c);
                } 
                label91: while (true) {
                  bool1 = bool;
                  if (f2.w()) {
                    e.c c1 = (e.c)f2.B(f2.s() - 1);
                    e.c c2 = c1;
                    if ((c1.X0() & m) == 0) {
                      q1.k.a(f2, c1);
                      continue;
                    } 
                    while (c2 != null) {
                      if ((c2.c1() & m) != 0) {
                        c1 = null;
                        while (c2 != null) {
                          f f4;
                          if (c2 instanceof FocusTargetNode) {
                            c = c2;
                            if (c.E1().q()) {
                              bool1 = o.j((FocusTargetNode)c);
                            } else {
                              bool1 = s.k((FocusTargetNode)c, d.b.b(), b.s0);
                            } 
                            c = c1;
                            if (bool1) {
                              bool1 = true;
                              break label91;
                            } 
                          } else {
                            int i2;
                            if ((c2.c1() & m) != 0) {
                              i2 = 1;
                            } else {
                              i2 = 0;
                            } 
                            c = c1;
                            if (i2) {
                              c = c1;
                              if (c2 instanceof l) {
                                f f5;
                                c = ((l)c2).B1();
                                for (i2 = 0; c != null; i2 = i3) {
                                  boolean bool2;
                                  f f6;
                                  if ((c.c1() & m) != 0) {
                                    bool2 = true;
                                  } else {
                                    bool2 = false;
                                  } 
                                  e.c c3 = c2;
                                  e.c c4 = c1;
                                  int i3 = i2;
                                  if (bool2) {
                                    i3 = i2 + 1;
                                    if (i3 == 1) {
                                      c3 = c;
                                      c4 = c1;
                                    } else {
                                      f f7;
                                      c3 = c1;
                                      if (c1 == null)
                                        f7 = new f((Object[])new e.c[16], 0); 
                                      c1 = c2;
                                      if (c2 != null) {
                                        f7.d(c2);
                                        c1 = null;
                                      } 
                                      f7.d(c);
                                      f6 = f7;
                                      c3 = c1;
                                    } 
                                  } 
                                  c = c.Y0();
                                  c2 = c3;
                                  f5 = f6;
                                } 
                                f4 = f5;
                                if (i2 == 1)
                                  continue; 
                              } 
                            } 
                          } 
                          c2 = q1.k.b(f4);
                          f f3 = f4;
                        } 
                        break;
                      } 
                      c2 = c2.Y0();
                    } 
                    continue;
                  } 
                  break;
                } 
                int i1 = i + 1;
                i = i1;
                bool = bool1;
                if (i1 >= j)
                  return bool1; 
                continue;
              } 
              throw new IllegalStateException("visitChildren called on an unattached node".toString());
            } 
          } 
          return false;
        } 
        throw new IllegalStateException("\n   FocusRequester is not initialized. Here are some possible fixes:\n\n   1. Remember the FocusRequester: val focusRequester = remember { FocusRequester() }\n   2. Did you forget to add a Modifier.focusRequester() ?\n   3. Are you attempting to request focus during composition? Focus requests should be made in\n   response to some event. Eg Modifier.clickable { focusRequester.requestFocus() }\n".toString());
      } 
      throw new IllegalStateException("\n    Please check whether the focusRequester is FocusRequester.Cancel or FocusRequester.Default\n    before invoking any functions on the focusRequester.\n".toString());
    } 
    throw new IllegalStateException("\n    Please check whether the focusRequester is FocusRequester.Cancel or FocusRequester.Default\n    before invoking any functions on the focusRequester.\n".toString());
  }
  
  public final f<n> d() {
    return this.a;
  }
  
  public final void e() {
    c();
  }
  
  public static final class a {
    private a() {}
    
    public final k a() {
      return k.a();
    }
    
    public final k b() {
      return k.b();
    }
  }
  
  static final class b extends r implements l<FocusTargetNode, Boolean> {
    public static final b s0 = new b();
    
    b() {
      super(1);
    }
    
    public final Boolean a(FocusTargetNode param1FocusTargetNode) {
      q.j(param1FocusTargetNode, "it");
      return Boolean.valueOf(o.j(param1FocusTargetNode));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */