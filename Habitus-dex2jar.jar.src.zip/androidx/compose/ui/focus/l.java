package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;

public final class l {
  public static final e a(e parame, k paramk) {
    q.j(parame, "<this>");
    q.j(paramk, "focusRequester");
    return parame.then((e)new FocusRequesterElement(paramk));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */