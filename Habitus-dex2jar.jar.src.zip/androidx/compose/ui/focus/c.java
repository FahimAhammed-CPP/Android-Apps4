package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import rj.v;
import z0.c;
import z0.o;

final class c extends e.c implements c {
  private l<? super o, v> F0;
  
  private o G0;
  
  public c(l<? super o, v> paraml) {
    this.F0 = paraml;
  }
  
  public final void A1(l<? super o, v> paraml) {
    q.j(paraml, "<set-?>");
    this.F0 = paraml;
  }
  
  public void x(o paramo) {
    q.j(paramo, "focusState");
    if (!q.e(this.G0, paramo)) {
      this.G0 = paramo;
      this.F0.invoke(paramo);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */