package androidx.compose.ui.focus;

import dk.l;

public interface g {
  k a();
  
  k b();
  
  k c();
  
  k j();
  
  k k();
  
  l<d, k> l();
  
  k m();
  
  k n();
  
  void o(boolean paramBoolean);
  
  l<d, k> p();
  
  boolean q();
  
  k r();
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */