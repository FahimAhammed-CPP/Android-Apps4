package androidx.compose.ui.focus;

import dk.l;
import kotlin.jvm.internal.r;

public final class h implements g {
  private boolean a = true;
  
  private k b;
  
  private k c;
  
  private k d;
  
  private k e;
  
  private k f;
  
  private k g;
  
  private k h;
  
  private k i;
  
  private l<? super d, k> j;
  
  private l<? super d, k> k;
  
  public h() {
    k.a a = k.b;
    this.b = a.b();
    this.c = a.b();
    this.d = a.b();
    this.e = a.b();
    this.f = a.b();
    this.g = a.b();
    this.h = a.b();
    this.i = a.b();
    this.j = a.s0;
    this.k = b.s0;
  }
  
  public k a() {
    return this.h;
  }
  
  public k b() {
    return this.f;
  }
  
  public k c() {
    return this.b;
  }
  
  public k j() {
    return this.g;
  }
  
  public k k() {
    return this.d;
  }
  
  public l<d, k> l() {
    return (l)this.k;
  }
  
  public k m() {
    return this.i;
  }
  
  public k n() {
    return this.e;
  }
  
  public void o(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public l<d, k> p() {
    return (l)this.j;
  }
  
  public boolean q() {
    return this.a;
  }
  
  public k r() {
    return this.c;
  }
  
  static final class a extends r implements l<d, k> {
    public static final a s0 = new a();
    
    a() {
      super(1);
    }
    
    public final k a(int param1Int) {
      return k.b.b();
    }
  }
  
  static final class b extends r implements l<d, k> {
    public static final b s0 = new b();
    
    b() {
      super(1);
    }
    
    public final k a(int param1Int) {
      return k.b.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */