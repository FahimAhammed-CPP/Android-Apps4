package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import kotlin.jvm.internal.h0;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import m0.f;
import o1.c;
import o1.d;
import p1.c;
import p1.g;
import p1.h;
import p1.i;
import q1.c1;
import q1.d1;
import q1.j;
import q1.j0;
import q1.k;
import q1.l;
import q1.u0;
import q1.z0;
import rj.v;
import z0.c;
import z0.d;
import z0.p;

public final class FocusTargetNode extends e.c implements c1, i {
  private boolean F0;
  
  private boolean G0;
  
  private p H0 = p.v0;
  
  public final g E1() {
    h h = new h();
    int j = z0.a(2048);
    int k = z0.a(1024);
    e.c c2 = Q();
    int m = j | k;
    if (Q().h1()) {
      e.c c3 = Q();
      j0 j0 = k.k((j)this);
      while (j0 != null) {
        if ((j0.h0().k().X0() & m) != 0) {
          e.c c4 = c3;
          while (true)
            c4 = c4.e1(); 
        } 
        j0 = j0.k0();
        if (j0 != null) {
          androidx.compose.ui.node.a a = j0.h0();
          if (a != null)
            continue; 
        } 
        c3 = null;
        continue;
        c3 = c3.o();
      } 
      return h;
    } 
    throw new IllegalStateException("visitAncestors called on an unattached node".toString());
  }
  
  public final c F1() {
    return (c)f((c)d.a());
  }
  
  public p G1() {
    return this.H0;
  }
  
  public final void H1() {
    p p1 = G1();
    int j = a.a[p1.ordinal()];
    if (j != 1 && j != 2)
      return; 
    h0<g> h0 = new h0();
    d1.a(this, new b(h0, this));
    Object object = h0.s0;
    if (object == null) {
      q.B("focusProperties");
      object = null;
    } else {
      object = object;
    } 
    if (!object.q())
      k.l((j)this).getFocusOwner().m(true); 
  }
  
  public final void I1() {
    e.c c3 = Q();
    int j = z0.a(4096);
    e.c c2 = null;
    while (c3 != null) {
      f f2;
      if (c3 instanceof c) {
        d.b((c)c3);
        e.c c4 = c2;
      } else {
        int k;
        if ((c3.c1() & j) != 0) {
          k = 1;
        } else {
          k = 0;
        } 
        e.c c4 = c2;
        if (k) {
          c4 = c2;
          if (c3 instanceof l) {
            f f;
            c4 = ((l)c3).B1();
            for (k = 0; c4 != null; k = m) {
              boolean bool;
              f f3;
              if ((c4.c1() & j) != 0) {
                bool = true;
              } else {
                bool = false;
              } 
              e.c c5 = c3;
              e.c c6 = c2;
              int m = k;
              if (bool) {
                m = k + 1;
                if (m == 1) {
                  c5 = c4;
                  c6 = c2;
                } else {
                  f f4;
                  c5 = c2;
                  if (c2 == null)
                    f4 = new f((Object[])new e.c[16], 0); 
                  c2 = c3;
                  if (c3 != null) {
                    f4.d(c3);
                    c2 = null;
                  } 
                  f4.d(c4);
                  f3 = f4;
                  c5 = c2;
                } 
              } 
              c4 = c4.Y0();
              c3 = c5;
              f = f3;
            } 
            f2 = f;
            if (k == 1)
              continue; 
          } 
        } 
      } 
      c3 = k.b(f2);
      f f1 = f2;
    } 
    j = z0.a(4096) | z0.a(1024);
    if (Q().h1()) {
      c2 = Q().e1();
      j0 j0 = k.k((j)this);
      while (j0 != null) {
        if ((j0.h0().k().X0() & j) != 0)
          for (e.c c4 = c2; c4 != null; c4 = c4.e1()) {
            if ((c4.c1() & j) != 0) {
              int k;
              if ((z0.a(1024) & c4.c1()) != 0) {
                k = 1;
              } else {
                k = 0;
              } 
              if (!k && c4.h1()) {
                int m = z0.a(4096);
                c2 = null;
                e.c c5 = c4;
                while (c5 != null) {
                  f f2;
                  if (c5 instanceof c) {
                    d.b((c)c5);
                    c3 = c2;
                  } else {
                    if ((c5.c1() & m) != 0) {
                      k = 1;
                    } else {
                      k = 0;
                    } 
                    c3 = c2;
                    if (k) {
                      c3 = c2;
                      if (c5 instanceof l) {
                        f f;
                        c3 = ((l)c5).B1();
                        for (k = 0; c3 != null; k = n) {
                          boolean bool;
                          f f3;
                          if ((c3.c1() & m) != 0) {
                            bool = true;
                          } else {
                            bool = false;
                          } 
                          e.c c6 = c5;
                          e.c c7 = c2;
                          int n = k;
                          if (bool) {
                            n = k + 1;
                            if (n == 1) {
                              c6 = c3;
                              c7 = c2;
                            } else {
                              f f4;
                              c6 = c2;
                              if (c2 == null)
                                f4 = new f((Object[])new e.c[16], 0); 
                              c2 = c5;
                              if (c5 != null) {
                                f4.d(c5);
                                c2 = null;
                              } 
                              f4.d(c3);
                              f3 = f4;
                              c6 = c2;
                            } 
                          } 
                          c3 = c3.Y0();
                          c5 = c6;
                          f = f3;
                        } 
                        f2 = f;
                        if (k == 1)
                          continue; 
                      } 
                    } 
                  } 
                  c5 = k.b(f2);
                  f f1 = f2;
                } 
              } 
            } 
          }  
        j0 = j0.k0();
        if (j0 != null) {
          androidx.compose.ui.node.a a = j0.h0();
          if (a != null) {
            e.c c4 = a.o();
            continue;
          } 
        } 
        c2 = null;
      } 
      return;
    } 
    throw new IllegalStateException("visitAncestors called on an unattached node".toString());
  }
  
  public void J1(p paramp) {
    q.j(paramp, "<set-?>");
    this.H0 = paramp;
  }
  
  public void U() {
    p p1 = G1();
    H1();
    if (p1 != G1())
      d.c(this); 
  }
  
  public void m1() {
    p p1 = G1();
    int j = a.a[p1.ordinal()];
    if (j != 1 && j != 2) {
      if (j != 3) {
        if (j != 4)
          return; 
        I1();
        return;
      } 
      I1();
      J1(p.v0);
      return;
    } 
    k.l((j)this).getFocusOwner().m(true);
  }
  
  public static final class FocusTargetElement extends u0<FocusTargetNode> {
    public static final FocusTargetElement c = new FocusTargetElement();
    
    public boolean equals(Object param1Object) {
      return (param1Object == this);
    }
    
    public int hashCode() {
      return 1739042953;
    }
    
    public FocusTargetNode s() {
      return new FocusTargetNode();
    }
    
    public void t(FocusTargetNode param1FocusTargetNode) {
      q.j(param1FocusTargetNode, "node");
    }
  }
  
  static final class b extends r implements dk.a<v> {
    b(h0<g> param1h0, FocusTargetNode param1FocusTargetNode) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.s0 = this.t0.E1();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\FocusTargetNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */