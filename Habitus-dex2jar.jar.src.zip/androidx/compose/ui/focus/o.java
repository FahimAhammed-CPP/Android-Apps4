package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import m0.f;
import q1.d1;
import q1.i1;
import q1.j;
import q1.j0;
import q1.k;
import q1.l;
import q1.x0;
import q1.z0;
import rj.v;
import z0.d;
import z0.p;

public final class o {
  private static final boolean a(FocusTargetNode paramFocusTargetNode, boolean paramBoolean1, boolean paramBoolean2) {
    paramFocusTargetNode = p.f(paramFocusTargetNode);
    return (paramFocusTargetNode != null) ? c(paramFocusTargetNode, paramBoolean1, paramBoolean2) : true;
  }
  
  public static final boolean c(FocusTargetNode paramFocusTargetNode, boolean paramBoolean1, boolean paramBoolean2) {
    q.j(paramFocusTargetNode, "<this>");
    p p = paramFocusTargetNode.G1();
    int i = a.b[p.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4)
            throw new NoWhenBranchMatchedException(); 
          return true;
        } 
        if (a(paramFocusTargetNode, paramBoolean1, paramBoolean2)) {
          paramFocusTargetNode.J1(p.v0);
          if (paramBoolean2)
            d.c(paramFocusTargetNode); 
          return true;
        } 
        return false;
      } 
      if (paramBoolean1) {
        paramFocusTargetNode.J1(p.v0);
        if (paramBoolean2) {
          d.c(paramFocusTargetNode);
          return paramBoolean1;
        } 
      } 
    } else {
      paramFocusTargetNode.J1(p.v0);
      if (paramBoolean2)
        d.c(paramFocusTargetNode); 
      return true;
    } 
    return paramBoolean1;
  }
  
  private static final boolean d(FocusTargetNode paramFocusTargetNode) {
    d1.a(paramFocusTargetNode, new b(paramFocusTargetNode));
    p p = paramFocusTargetNode.G1();
    int i = a.b[p.ordinal()];
    if (i == 3 || i == 4)
      paramFocusTargetNode.J1(p.s0); 
    return true;
  }
  
  public static final z0.a e(FocusTargetNode paramFocusTargetNode, int paramInt) {
    q.j(paramFocusTargetNode, "$this$performCustomClearFocus");
    p p = paramFocusTargetNode.G1();
    int i = a.b[p.ordinal()];
    boolean bool = true;
    if (i != 1)
      if (i != 2) {
        if (i != 3) {
          if (i != 4)
            throw new NoWhenBranchMatchedException(); 
        } else {
          z0.a a;
          FocusTargetNode focusTargetNode = p.f(paramFocusTargetNode);
          if (focusTargetNode != null) {
            z0.a a1 = e(focusTargetNode, paramInt);
            if (a1 != z0.a.s0)
              bool = false; 
            if (bool)
              a1 = null; 
            a = a1;
            if (a1 == null)
              return g(paramFocusTargetNode, paramInt); 
          } else {
            throw new IllegalStateException("Required value was null.".toString());
          } 
          return a;
        } 
      } else {
        return z0.a.t0;
      }  
    return z0.a.s0;
  }
  
  private static final z0.a f(FocusTargetNode paramFocusTargetNode, int paramInt) {
    if (!FocusTargetNode.A1(paramFocusTargetNode)) {
      FocusTargetNode.C1(paramFocusTargetNode, true);
      try {
        k k = (k)paramFocusTargetNode.E1().p().invoke(d.i(paramInt));
        k.a a = k.b;
        if (k != a.b()) {
          z0.a a1;
          if (k == a.a()) {
            a1 = z0.a.t0;
            return a1;
          } 
          if (a1.c()) {
            a1 = z0.a.u0;
          } else {
            a1 = z0.a.v0;
          } 
          return a1;
        } 
      } finally {
        FocusTargetNode.C1(paramFocusTargetNode, false);
      } 
    } 
    return z0.a.s0;
  }
  
  private static final z0.a g(FocusTargetNode paramFocusTargetNode, int paramInt) {
    if (!FocusTargetNode.B1(paramFocusTargetNode)) {
      FocusTargetNode.D1(paramFocusTargetNode, true);
      try {
        k k = (k)paramFocusTargetNode.E1().l().invoke(d.i(paramInt));
        k.a a = k.b;
        if (k != a.b()) {
          z0.a a1;
          if (k == a.a()) {
            a1 = z0.a.t0;
            return a1;
          } 
          if (a1.c()) {
            a1 = z0.a.u0;
          } else {
            a1 = z0.a.v0;
          } 
          return a1;
        } 
      } finally {
        FocusTargetNode.D1(paramFocusTargetNode, false);
      } 
    } 
    return z0.a.s0;
  }
  
  public static final z0.a h(FocusTargetNode paramFocusTargetNode, int paramInt) {
    q.j(paramFocusTargetNode, "$this$performCustomRequestFocus");
    p p = paramFocusTargetNode.G1();
    int i = a.b[p.ordinal()];
    boolean bool = true;
    if (i != 1 && i != 2) {
      z0.a a;
      if (i != 3) {
        if (i == 4) {
          int j = z0.a(1024);
          if (paramFocusTargetNode.Q().h1()) {
            z0.a a1;
            p p2;
            e.c c2 = paramFocusTargetNode.Q().e1();
            j0 j0 = k.k((j)paramFocusTargetNode);
            e.c c1 = c2;
            while (true) {
              p2 = null;
              if (j0 != null) {
                if ((j0.h0().k().X0() & j) != 0)
                  for (e.c c = c1; c != null; c = c.e1()) {
                    if ((c.c1() & j) != 0) {
                      c2 = c;
                      c1 = null;
                      while (c2 != null && !(c2 instanceof FocusTargetNode)) {
                        f f2;
                        if ((c2.c1() & j) != 0) {
                          i = 1;
                        } else {
                          i = 0;
                        } 
                        e.c c3 = c1;
                        if (i != 0) {
                          c3 = c1;
                          if (c2 instanceof l) {
                            f f;
                            c3 = ((l)c2).B1();
                            for (i = 0; c3 != null; i = k) {
                              boolean bool1;
                              f f3;
                              if ((c3.c1() & j) != 0) {
                                bool1 = true;
                              } else {
                                bool1 = false;
                              } 
                              e.c c4 = c2;
                              e.c c5 = c1;
                              int k = i;
                              if (bool1) {
                                k = i + 1;
                                if (k == 1) {
                                  c4 = c3;
                                  c5 = c1;
                                } else {
                                  f f4;
                                  c4 = c1;
                                  if (c1 == null)
                                    f4 = new f((Object[])new e.c[16], 0); 
                                  c1 = c2;
                                  if (c2 != null) {
                                    f4.d(c2);
                                    c1 = null;
                                  } 
                                  f4.d(c3);
                                  f3 = f4;
                                  c4 = c1;
                                } 
                              } 
                              c3 = c3.Y0();
                              c2 = c4;
                              f = f3;
                            } 
                            f2 = f;
                            if (i == 1)
                              continue; 
                          } 
                        } 
                        c2 = k.b(f2);
                        f f1 = f2;
                      } 
                    } 
                  }  
                j0 = j0.k0();
                if (j0 != null) {
                  androidx.compose.ui.node.a a2 = j0.h0();
                  if (a2 != null) {
                    e.c c = a2.o();
                    continue;
                  } 
                } 
                c1 = null;
                continue;
              } 
              c2 = null;
              break;
            } 
            FocusTargetNode focusTargetNode1 = (FocusTargetNode)c2;
            if (focusTargetNode1 == null)
              return z0.a.s0; 
            p p1 = focusTargetNode1.G1();
            i = a.b[p1.ordinal()];
            if (i != 1) {
              if (i != 2) {
                if (i != 3) {
                  if (i == 4) {
                    a1 = h(focusTargetNode1, paramInt);
                    if (a1 == z0.a.s0) {
                      i = bool;
                    } else {
                      i = 0;
                    } 
                    p1 = p2;
                    if (i == 0)
                      a = a1; 
                    a1 = a;
                    if (a == null)
                      return f(focusTargetNode1, paramInt); 
                  } else {
                    throw new NoWhenBranchMatchedException();
                  } 
                } else {
                  return h(focusTargetNode1, paramInt);
                } 
              } else {
                return z0.a.t0;
              } 
            } else {
              a1 = f(focusTargetNode1, paramInt);
            } 
            return a1;
          } 
          throw new IllegalStateException("visitAncestors called on an unattached node".toString());
        } 
        throw new NoWhenBranchMatchedException();
      } 
      FocusTargetNode focusTargetNode = p.f((FocusTargetNode)a);
      if (focusTargetNode != null)
        return e(focusTargetNode, paramInt); 
      throw new IllegalStateException("Required value was null.".toString());
    } 
    return z0.a.s0;
  }
  
  public static final boolean i(FocusTargetNode paramFocusTargetNode) {
    q.j(paramFocusTargetNode, "<this>");
    p p = paramFocusTargetNode.G1();
    int i = a.b[p.ordinal()];
    boolean bool1 = true;
    boolean bool3 = true;
    boolean bool2 = true;
    if (i != 1 && i != 2) {
      e.c c = null;
      if (i != 3) {
        if (i == 4) {
          int j = z0.a(1024);
          if (paramFocusTargetNode.Q().h1()) {
            e.c c2;
            e.c c1 = paramFocusTargetNode.Q().e1();
            j0 j0 = k.k((j)paramFocusTargetNode);
            label90: while (true) {
              c2 = c;
              if (j0 != null) {
                if ((j0.h0().k().X0() & j) != 0)
                  for (e.c c3 = c1; c3 != null; c3 = c3.e1()) {
                    if ((c3.c1() & j) != 0) {
                      c2 = c3;
                      c1 = null;
                      while (c2 != null) {
                        f f2;
                        if (c2 instanceof FocusTargetNode)
                          break label90; 
                        if ((c2.c1() & j) != 0) {
                          i = 1;
                        } else {
                          i = 0;
                        } 
                        e.c c4 = c1;
                        if (i != 0) {
                          c4 = c1;
                          if (c2 instanceof l) {
                            f f;
                            c4 = ((l)c2).B1();
                            for (i = 0; c4 != null; i = k) {
                              boolean bool;
                              f f3;
                              if ((c4.c1() & j) != 0) {
                                bool = true;
                              } else {
                                bool = false;
                              } 
                              e.c c5 = c2;
                              e.c c6 = c1;
                              int k = i;
                              if (bool) {
                                k = i + 1;
                                if (k == 1) {
                                  c5 = c4;
                                  c6 = c1;
                                } else {
                                  f f4;
                                  c5 = c1;
                                  if (c1 == null)
                                    f4 = new f((Object[])new e.c[16], 0); 
                                  c1 = c2;
                                  if (c2 != null) {
                                    f4.d(c2);
                                    c1 = null;
                                  } 
                                  f4.d(c4);
                                  f3 = f4;
                                  c5 = c1;
                                } 
                              } 
                              c4 = c4.Y0();
                              c2 = c5;
                              f = f3;
                            } 
                            f2 = f;
                            if (i == 1)
                              continue; 
                          } 
                        } 
                        c2 = k.b(f2);
                        f f1 = f2;
                      } 
                    } 
                  }  
                j0 = j0.k0();
                if (j0 != null) {
                  androidx.compose.ui.node.a a = j0.h0();
                  if (a != null) {
                    e.c c3 = a.o();
                    continue;
                  } 
                } 
                c1 = null;
                continue;
              } 
              break;
            } 
            c1 = c2;
            if (c1 != null)
              return k((FocusTargetNode)c1, paramFocusTargetNode); 
            if (!l(paramFocusTargetNode) || !d(paramFocusTargetNode))
              bool2 = false; 
            bool1 = bool2;
            if (bool2) {
              d.c(paramFocusTargetNode);
              return bool2;
            } 
          } else {
            throw new IllegalStateException("visitAncestors called on an unattached node".toString());
          } 
        } else {
          throw new NoWhenBranchMatchedException();
        } 
      } else {
        if (b(paramFocusTargetNode, false, false, 3, null) && d(paramFocusTargetNode)) {
          bool2 = bool1;
        } else {
          bool2 = false;
        } 
        bool1 = bool2;
        if (bool2) {
          d.c(paramFocusTargetNode);
          return bool2;
        } 
      } 
    } else {
      d.c(paramFocusTargetNode);
      bool1 = bool3;
    } 
    return bool1;
  }
  
  public static final boolean j(FocusTargetNode paramFocusTargetNode) {
    q.j(paramFocusTargetNode, "<this>");
    z0.a a = h(paramFocusTargetNode, d.b.b());
    int i = a.a[a.ordinal()];
    boolean bool = true;
    if (i != 1) {
      if (i != 2) {
        if (i == 3 || i == 4)
          return false; 
        throw new NoWhenBranchMatchedException();
      } 
    } else {
      bool = i(paramFocusTargetNode);
    } 
    return bool;
  }
  
  private static final boolean k(FocusTargetNode paramFocusTargetNode1, FocusTargetNode paramFocusTargetNode2) {
    int i = z0.a(1024);
    if (paramFocusTargetNode2.Q().h1()) {
      boolean bool1;
      boolean bool;
      boolean bool2;
      e.c c2;
      e.c c3;
      e.c c1 = paramFocusTargetNode2.Q().e1();
      j0 j0 = k.k((j)paramFocusTargetNode2);
      while (true) {
        c3 = null;
        bool2 = true;
        bool1 = true;
        bool = false;
        if (j0 != null) {
          if ((j0.h0().k().X0() & i) != 0)
            for (e.c c = c1; c != null; c = c.e1()) {
              if ((c.c1() & i) != 0) {
                e.c c4 = c;
                c1 = null;
                while (c4 != null && !(c4 instanceof FocusTargetNode)) {
                  int j;
                  f f2;
                  if ((c4.c1() & i) != 0) {
                    j = 1;
                  } else {
                    j = 0;
                  } 
                  e.c c5 = c1;
                  if (j) {
                    c5 = c1;
                    if (c4 instanceof l) {
                      f f;
                      c5 = ((l)c4).B1();
                      for (j = 0; c5 != null; j = k) {
                        boolean bool3;
                        f f3;
                        if ((c5.c1() & i) != 0) {
                          bool3 = true;
                        } else {
                          bool3 = false;
                        } 
                        e.c c6 = c4;
                        e.c c7 = c1;
                        int k = j;
                        if (bool3) {
                          k = j + 1;
                          if (k == 1) {
                            c6 = c5;
                            c7 = c1;
                          } else {
                            f f4;
                            c6 = c1;
                            if (c1 == null)
                              f4 = new f((Object[])new e.c[16], 0); 
                            c1 = c4;
                            if (c4 != null) {
                              f4.d(c4);
                              c1 = null;
                            } 
                            f4.d(c5);
                            f3 = f4;
                            c6 = c1;
                          } 
                        } 
                        c5 = c5.Y0();
                        c4 = c6;
                        f = f3;
                      } 
                      f2 = f;
                      if (j == 1)
                        continue; 
                    } 
                  } 
                  c4 = k.b(f2);
                  f f1 = f2;
                } 
              } 
            }  
          j0 = j0.k0();
          if (j0 != null) {
            androidx.compose.ui.node.a a = j0.h0();
            if (a != null) {
              e.c c = a.o();
              continue;
            } 
          } 
          c1 = null;
          continue;
        } 
        c2 = null;
        break;
      } 
      if (q.e(c2, paramFocusTargetNode1)) {
        boolean bool3;
        p p = paramFocusTargetNode1.G1();
        int j = a.b[p.ordinal()];
        if (j != 1) {
          bool3 = bool;
          if (j != 2)
            if (j != 3) {
              if (j == 4) {
                i = z0.a(1024);
                if (paramFocusTargetNode1.Q().h1()) {
                  e.c c = paramFocusTargetNode1.Q().e1();
                  j0 = k.k((j)paramFocusTargetNode1);
                  label162: while (true) {
                    c2 = c3;
                    if (j0 != null) {
                      if ((j0.h0().k().X0() & i) != 0)
                        for (e.c c4 = c; c4 != null; c4 = c4.e1()) {
                          if ((c4.c1() & i) != 0) {
                            c2 = c4;
                            c = null;
                            while (c2 != null) {
                              f f2;
                              if (c2 instanceof FocusTargetNode)
                                break label162; 
                              if ((c2.c1() & i) != 0) {
                                j = 1;
                              } else {
                                j = 0;
                              } 
                              e.c c5 = c;
                              if (j != 0) {
                                c5 = c;
                                if (c2 instanceof l) {
                                  f f;
                                  c5 = ((l)c2).B1();
                                  for (j = 0; c5 != null; j = k) {
                                    boolean bool4;
                                    f f3;
                                    if ((c5.c1() & i) != 0) {
                                      bool4 = true;
                                    } else {
                                      bool4 = false;
                                    } 
                                    e.c c6 = c2;
                                    e.c c7 = c;
                                    int k = j;
                                    if (bool4) {
                                      k = j + 1;
                                      if (k == 1) {
                                        c6 = c5;
                                        c7 = c;
                                      } else {
                                        f f4;
                                        c6 = c;
                                        if (c == null)
                                          f4 = new f((Object[])new e.c[16], 0); 
                                        c = c2;
                                        if (c2 != null) {
                                          f4.d(c2);
                                          c = null;
                                        } 
                                        f4.d(c5);
                                        f3 = f4;
                                        c6 = c;
                                      } 
                                    } 
                                    c5 = c5.Y0();
                                    c2 = c6;
                                    f = f3;
                                  } 
                                  f2 = f;
                                  if (j == 1)
                                    continue; 
                                } 
                              } 
                              c2 = k.b(f2);
                              f f1 = f2;
                            } 
                          } 
                        }  
                      j0 = j0.k0();
                      if (j0 != null) {
                        androidx.compose.ui.node.a a = j0.h0();
                        if (a != null) {
                          e.c c4 = a.o();
                          continue;
                        } 
                      } 
                      c = null;
                      continue;
                    } 
                    break;
                  } 
                  c = c2;
                  if (c == null && l(paramFocusTargetNode1)) {
                    paramFocusTargetNode1.J1(p.s0);
                    d.c(paramFocusTargetNode1);
                    return k(paramFocusTargetNode1, paramFocusTargetNode2);
                  } 
                  bool3 = bool;
                  if (c != null) {
                    bool3 = bool;
                    if (k((FocusTargetNode)c, paramFocusTargetNode1)) {
                      bool3 = k(paramFocusTargetNode1, paramFocusTargetNode2);
                      if (paramFocusTargetNode1.G1() == p.t0) {
                        j = bool1;
                      } else {
                        j = 0;
                      } 
                      if (j != 0)
                        return bool3; 
                      throw new IllegalStateException("Check failed.".toString());
                    } 
                  } 
                } else {
                  throw new IllegalStateException("visitAncestors called on an unattached node".toString());
                } 
              } else {
                throw new NoWhenBranchMatchedException();
              } 
            } else {
              if (p.f(paramFocusTargetNode1) != null) {
                if (b(paramFocusTargetNode1, false, false, 3, null) && d(paramFocusTargetNode2)) {
                  bool3 = bool2;
                } else {
                  bool3 = false;
                } 
                if (bool3)
                  d.c(paramFocusTargetNode2); 
                return bool3;
              } 
              throw new IllegalStateException("Required value was null.".toString());
            }  
        } else {
          bool = d(paramFocusTargetNode2);
          bool3 = bool;
          if (bool) {
            paramFocusTargetNode1.J1(p.t0);
            d.c(paramFocusTargetNode2);
            d.c(paramFocusTargetNode1);
            bool3 = bool;
          } 
        } 
        return bool3;
      } 
      throw new IllegalStateException("Non child node cannot request focus.".toString());
    } 
    throw new IllegalStateException("visitAncestors called on an unattached node".toString());
  }
  
  private static final boolean l(FocusTargetNode paramFocusTargetNode) {
    x0 x0 = paramFocusTargetNode.Z0();
    if (x0 != null) {
      j0 j0 = x0.c1();
      if (j0 != null) {
        i1 i1 = j0.j0();
        if (i1 != null)
          return i1.requestFocus(); 
      } 
    } 
    throw new IllegalStateException("Owner not initialized.".toString());
  }
  
  static final class b extends r implements dk.a<v> {
    b(FocusTargetNode param1FocusTargetNode) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.E1();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */