package androidx.compose.ui.focus;

import java.util.Comparator;
import m0.f;
import q1.j0;
import q1.x0;

final class q implements Comparator<FocusTargetNode> {
  public static final q s0 = new q();
  
  private final f<j0> b(j0 paramj0) {
    f<j0> f = new f((Object[])new j0[16], 0);
    while (paramj0 != null) {
      f.a(0, paramj0);
      paramj0 = paramj0.k0();
    } 
    return f;
  }
  
  public int a(FocusTargetNode paramFocusTargetNode1, FocusTargetNode paramFocusTargetNode2) {
    if (paramFocusTargetNode1 != null) {
      if (paramFocusTargetNode2 != null) {
        boolean bool = p.g(paramFocusTargetNode1);
        int i = 0;
        if (!bool || !p.g(paramFocusTargetNode2))
          return p.g(paramFocusTargetNode1) ? -1 : (p.g(paramFocusTargetNode2) ? 1 : 0); 
        x0 x0 = paramFocusTargetNode1.Z0();
        FocusTargetNode focusTargetNode = null;
        if (x0 != null) {
          j0 j0 = x0.c1();
        } else {
          x0 = null;
        } 
        if (x0 != null) {
          j0 j0;
          x0 x01 = paramFocusTargetNode2.Z0();
          paramFocusTargetNode2 = focusTargetNode;
          if (x01 != null)
            j0 = x01.c1(); 
          if (j0 != null) {
            if (kotlin.jvm.internal.q.e(x0, j0))
              return 0; 
            f<j0> f1 = b((j0)x0);
            f<j0> f2 = b(j0);
            int j = Math.min(f1.s() - 1, f2.s() - 1);
            if (j >= 0)
              while (true) {
                if (!kotlin.jvm.internal.q.e(f1.r()[i], f2.r()[i]))
                  return kotlin.jvm.internal.q.l(((j0)f1.r()[i]).m0(), ((j0)f2.r()[i]).m0()); 
                if (i != j) {
                  i++;
                  continue;
                } 
                break;
              }  
            throw new IllegalStateException("Could not find a common ancestor between the two FocusModifiers.".toString());
          } 
          throw new IllegalStateException("Required value was null.".toString());
        } 
        throw new IllegalStateException("Required value was null.".toString());
      } 
      throw new IllegalArgumentException("Required value was null.".toString());
    } 
    throw new IllegalArgumentException("Required value was null.".toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */