package androidx.compose.ui.focus;

import kotlin.jvm.internal.q;

public final class e {
  public static final androidx.compose.ui.e a(androidx.compose.ui.e parame) {
    q.j(parame, "<this>");
    return parame.then((androidx.compose.ui.e)FocusTargetNode.FocusTargetElement.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */