package androidx.compose.ui.focus;

import dk.l;
import o1.c;

public final class a {
  public static final <T> T a(FocusTargetNode paramFocusTargetNode, int paramInt, l<? super c.a, ? extends T> paraml) {
    // Byte code:
    //   0: aload_0
    //   1: ldc '$this$searchBeyondBounds'
    //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_2
    //   7: ldc 'block'
    //   9: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: sipush #1024
    //   15: invokestatic a : (I)I
    //   18: istore #6
    //   20: aload_0
    //   21: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   26: invokevirtual h1 : ()Z
    //   29: ifeq -> 583
    //   32: aload_0
    //   33: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   38: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   41: astore #7
    //   43: aload_0
    //   44: invokestatic k : (Lq1/j;)Lq1/j0;
    //   47: astore #12
    //   49: aload #12
    //   51: ifnull -> 384
    //   54: aload #12
    //   56: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   59: invokevirtual k : ()Landroidx/compose/ui/e$c;
    //   62: invokevirtual X0 : ()I
    //   65: iload #6
    //   67: iand
    //   68: ifeq -> 344
    //   71: aload #7
    //   73: astore #9
    //   75: aload #9
    //   77: ifnull -> 344
    //   80: aload #9
    //   82: invokevirtual c1 : ()I
    //   85: iload #6
    //   87: iand
    //   88: ifeq -> 334
    //   91: aload #9
    //   93: astore #8
    //   95: aconst_null
    //   96: astore #7
    //   98: aload #8
    //   100: ifnull -> 334
    //   103: aload #8
    //   105: instanceof androidx/compose/ui/focus/FocusTargetNode
    //   108: ifeq -> 114
    //   111: goto -> 387
    //   114: aload #8
    //   116: invokevirtual c1 : ()I
    //   119: iload #6
    //   121: iand
    //   122: ifeq -> 130
    //   125: iconst_1
    //   126: istore_3
    //   127: goto -> 132
    //   130: iconst_0
    //   131: istore_3
    //   132: aload #7
    //   134: astore #10
    //   136: iload_3
    //   137: ifeq -> 320
    //   140: aload #7
    //   142: astore #10
    //   144: aload #8
    //   146: instanceof q1/l
    //   149: ifeq -> 320
    //   152: aload #8
    //   154: checkcast q1/l
    //   157: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   160: astore #10
    //   162: iconst_0
    //   163: istore_3
    //   164: aload #10
    //   166: ifnull -> 308
    //   169: aload #10
    //   171: invokevirtual c1 : ()I
    //   174: iload #6
    //   176: iand
    //   177: ifeq -> 186
    //   180: iconst_1
    //   181: istore #4
    //   183: goto -> 189
    //   186: iconst_0
    //   187: istore #4
    //   189: aload #8
    //   191: astore #11
    //   193: aload #7
    //   195: astore #13
    //   197: iload_3
    //   198: istore #5
    //   200: iload #4
    //   202: ifeq -> 287
    //   205: iload_3
    //   206: iconst_1
    //   207: iadd
    //   208: istore #5
    //   210: iload #5
    //   212: iconst_1
    //   213: if_icmpne -> 227
    //   216: aload #10
    //   218: astore #11
    //   220: aload #7
    //   222: astore #13
    //   224: goto -> 287
    //   227: aload #7
    //   229: astore #11
    //   231: aload #7
    //   233: ifnonnull -> 251
    //   236: new m0/f
    //   239: dup
    //   240: bipush #16
    //   242: anewarray androidx/compose/ui/e$c
    //   245: iconst_0
    //   246: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   249: astore #11
    //   251: aload #8
    //   253: astore #7
    //   255: aload #8
    //   257: ifnull -> 271
    //   260: aload #11
    //   262: aload #8
    //   264: invokevirtual d : (Ljava/lang/Object;)Z
    //   267: pop
    //   268: aconst_null
    //   269: astore #7
    //   271: aload #11
    //   273: aload #10
    //   275: invokevirtual d : (Ljava/lang/Object;)Z
    //   278: pop
    //   279: aload #11
    //   281: astore #13
    //   283: aload #7
    //   285: astore #11
    //   287: aload #10
    //   289: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   292: astore #10
    //   294: aload #11
    //   296: astore #8
    //   298: aload #13
    //   300: astore #7
    //   302: iload #5
    //   304: istore_3
    //   305: goto -> 164
    //   308: aload #7
    //   310: astore #10
    //   312: iload_3
    //   313: iconst_1
    //   314: if_icmpne -> 320
    //   317: goto -> 98
    //   320: aload #10
    //   322: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   325: astore #8
    //   327: aload #10
    //   329: astore #7
    //   331: goto -> 98
    //   334: aload #9
    //   336: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   339: astore #9
    //   341: goto -> 75
    //   344: aload #12
    //   346: invokevirtual k0 : ()Lq1/j0;
    //   349: astore #12
    //   351: aload #12
    //   353: ifnull -> 378
    //   356: aload #12
    //   358: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   361: astore #7
    //   363: aload #7
    //   365: ifnull -> 378
    //   368: aload #7
    //   370: invokevirtual o : ()Landroidx/compose/ui/e$c;
    //   373: astore #7
    //   375: goto -> 49
    //   378: aconst_null
    //   379: astore #7
    //   381: goto -> 49
    //   384: aconst_null
    //   385: astore #8
    //   387: aload #8
    //   389: checkcast androidx/compose/ui/focus/FocusTargetNode
    //   392: astore #7
    //   394: aload #7
    //   396: ifnull -> 416
    //   399: aload #7
    //   401: invokevirtual F1 : ()Lo1/c;
    //   404: aload_0
    //   405: invokevirtual F1 : ()Lo1/c;
    //   408: invokestatic e : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   411: ifeq -> 416
    //   414: aconst_null
    //   415: areturn
    //   416: aload_0
    //   417: invokevirtual F1 : ()Lo1/c;
    //   420: astore_0
    //   421: aload_0
    //   422: ifnull -> 581
    //   425: getstatic androidx/compose/ui/focus/d.b : Landroidx/compose/ui/focus/d$a;
    //   428: astore #7
    //   430: iload_1
    //   431: aload #7
    //   433: invokevirtual h : ()I
    //   436: invokestatic l : (II)Z
    //   439: ifeq -> 452
    //   442: getstatic o1/c$b.a : Lo1/c$b$a;
    //   445: invokevirtual a : ()I
    //   448: istore_1
    //   449: goto -> 559
    //   452: iload_1
    //   453: aload #7
    //   455: invokevirtual a : ()I
    //   458: invokestatic l : (II)Z
    //   461: ifeq -> 474
    //   464: getstatic o1/c$b.a : Lo1/c$b$a;
    //   467: invokevirtual d : ()I
    //   470: istore_1
    //   471: goto -> 559
    //   474: iload_1
    //   475: aload #7
    //   477: invokevirtual d : ()I
    //   480: invokestatic l : (II)Z
    //   483: ifeq -> 496
    //   486: getstatic o1/c$b.a : Lo1/c$b$a;
    //   489: invokevirtual e : ()I
    //   492: istore_1
    //   493: goto -> 559
    //   496: iload_1
    //   497: aload #7
    //   499: invokevirtual g : ()I
    //   502: invokestatic l : (II)Z
    //   505: ifeq -> 518
    //   508: getstatic o1/c$b.a : Lo1/c$b$a;
    //   511: invokevirtual f : ()I
    //   514: istore_1
    //   515: goto -> 559
    //   518: iload_1
    //   519: aload #7
    //   521: invokevirtual e : ()I
    //   524: invokestatic l : (II)Z
    //   527: ifeq -> 540
    //   530: getstatic o1/c$b.a : Lo1/c$b$a;
    //   533: invokevirtual b : ()I
    //   536: istore_1
    //   537: goto -> 559
    //   540: iload_1
    //   541: aload #7
    //   543: invokevirtual f : ()I
    //   546: invokestatic l : (II)Z
    //   549: ifeq -> 568
    //   552: getstatic o1/c$b.a : Lo1/c$b$a;
    //   555: invokevirtual c : ()I
    //   558: istore_1
    //   559: aload_0
    //   560: iload_1
    //   561: aload_2
    //   562: invokeinterface a : (ILdk/l;)Ljava/lang/Object;
    //   567: areturn
    //   568: new java/lang/IllegalStateException
    //   571: dup
    //   572: ldc 'Unsupported direction for beyond bounds layout'
    //   574: invokevirtual toString : ()Ljava/lang/String;
    //   577: invokespecial <init> : (Ljava/lang/String;)V
    //   580: athrow
    //   581: aconst_null
    //   582: areturn
    //   583: new java/lang/IllegalStateException
    //   586: dup
    //   587: ldc 'visitAncestors called on an unattached node'
    //   589: invokevirtual toString : ()Ljava/lang/String;
    //   592: invokespecial <init> : (Ljava/lang/String;)V
    //   595: athrow
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */