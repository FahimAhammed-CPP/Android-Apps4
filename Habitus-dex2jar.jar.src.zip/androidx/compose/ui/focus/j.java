package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import rj.v;
import z0.k;

final class j extends e.c implements k {
  private l<? super g, v> F0;
  
  public j(l<? super g, v> paraml) {
    this.F0 = paraml;
  }
  
  public final void A1(l<? super g, v> paraml) {
    q.j(paraml, "<set-?>");
    this.F0 = paraml;
  }
  
  public void n0(g paramg) {
    q.j(paramg, "focusProperties");
    this.F0.invoke(paramg);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */