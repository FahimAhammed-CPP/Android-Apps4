package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import q1.u0;
import rj.v;

final class FocusPropertiesElement extends u0<j> {
  private final l<g, v> c;
  
  public FocusPropertiesElement(l<? super g, v> paraml) {
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof FocusPropertiesElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((FocusPropertiesElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public j s() {
    return new j(this.c);
  }
  
  public void t(j paramj) {
    q.j(paramj, "node");
    paramj.A1(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FocusPropertiesElement(scope=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\FocusPropertiesElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */