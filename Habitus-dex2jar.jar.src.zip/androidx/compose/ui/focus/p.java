package androidx.compose.ui.focus;

import a1.h;
import androidx.compose.ui.e;
import dk.l;
import k2.r;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.q;
import m0.f;
import o1.s;
import o1.t;
import q1.j;
import q1.j0;
import q1.k;
import q1.l;
import q1.x0;
import q1.z0;

public final class p {
  public static final k a(FocusTargetNode paramFocusTargetNode, int paramInt, r paramr) {
    k k1;
    k k2;
    q.j(paramFocusTargetNode, "$this$customFocusSearch");
    q.j(paramr, "layoutDirection");
    g g = paramFocusTargetNode.E1();
    d.a a = d.b;
    if (d.l(paramInt, a.e()))
      return g.c(); 
    if (d.l(paramInt, a.f()))
      return g.r(); 
    if (d.l(paramInt, a.h()))
      return g.k(); 
    if (d.l(paramInt, a.a()))
      return g.n(); 
    boolean bool = d.l(paramInt, a.d());
    boolean bool2 = false;
    boolean bool1 = false;
    if (bool) {
      paramInt = a.a[paramr.ordinal()];
      if (paramInt != 1) {
        if (paramInt == 2) {
          k1 = g.m();
        } else {
          throw new NoWhenBranchMatchedException();
        } 
      } else {
        k1 = g.a();
      } 
      paramInt = bool1;
      if (k1 == k.b.b())
        paramInt = 1; 
      if (paramInt != 0)
        k1 = null; 
      k2 = k1;
      return (k1 == null) ? g.b() : k2;
    } 
    if (d.l(paramInt, k1.g())) {
      paramInt = a.a[k2.ordinal()];
      if (paramInt != 1) {
        if (paramInt == 2) {
          k1 = g.a();
        } else {
          throw new NoWhenBranchMatchedException();
        } 
      } else {
        k1 = g.m();
      } 
      paramInt = bool2;
      if (k1 == k.b.b())
        paramInt = 1; 
      if (paramInt != 0)
        k1 = null; 
      k2 = k1;
      return (k1 == null) ? g.j() : k2;
    } 
    if (d.l(paramInt, k1.b()))
      return (k)g.p().invoke(d.i(paramInt)); 
    if (d.l(paramInt, k1.c()))
      return (k)g.l().invoke(d.i(paramInt)); 
    throw new IllegalStateException("invalid FocusDirection".toString());
  }
  
  public static final FocusTargetNode b(FocusTargetNode paramFocusTargetNode) {
    f f;
    q.j(paramFocusTargetNode, "<this>");
    z0.p p1 = paramFocusTargetNode.G1();
    int i = a.b[p1.ordinal()];
    if (i != 1)
      if (i != 2) {
        if (i != 3) {
          if (i == 4)
            return null; 
          throw new NoWhenBranchMatchedException();
        } 
      } else {
        int j = z0.a(1024);
        if (paramFocusTargetNode.Q().h1()) {
          f f1 = new f((Object[])new e.c[16], 0);
          e.c c = paramFocusTargetNode.Q().Y0();
          if (c == null) {
            k.a(f1, paramFocusTargetNode.Q());
          } else {
            f1.d(c);
          } 
          while (f1.w()) {
            e.c c1 = (e.c)f1.B(f1.s() - 1);
            e.c c2 = c1;
            if ((c1.X0() & j) == 0) {
              k.a(f1, c1);
              continue;
            } 
            while (c2 != null) {
              if ((c2.c1() & j) != 0) {
                c1 = null;
                while (c2 != null) {
                  f f2;
                  if (c2 instanceof FocusTargetNode) {
                    c2 = b((FocusTargetNode)c2);
                    c = c1;
                    if (c2 != null)
                      return (FocusTargetNode)c2; 
                  } else {
                    if ((c2.c1() & j) != 0) {
                      i = 1;
                    } else {
                      i = 0;
                    } 
                    c = c1;
                    if (i != 0) {
                      c = c1;
                      if (c2 instanceof l) {
                        f f3;
                        c = ((l)c2).B1();
                        i = 0;
                        while (c != null) {
                          boolean bool;
                          f f4;
                          if ((c.c1() & j) != 0) {
                            bool = true;
                          } else {
                            bool = false;
                          } 
                          e.c c3 = c1;
                          int k = i;
                          e.c c4 = c2;
                          if (bool) {
                            k = i + 1;
                            if (k == 1) {
                              c4 = c;
                              c3 = c1;
                            } else {
                              c3 = c1;
                              if (c1 == null)
                                f4 = new f((Object[])new e.c[16], 0); 
                              c4 = c2;
                              if (c2 != null) {
                                f4.d(c2);
                                c4 = null;
                              } 
                              f4.d(c);
                            } 
                          } 
                          c = c.Y0();
                          f3 = f4;
                          i = k;
                          c2 = c4;
                        } 
                        f2 = f3;
                        if (i == 1)
                          continue; 
                      } 
                    } 
                  } 
                  c2 = k.b(f2);
                  f = f2;
                } 
                break;
              } 
              c2 = c2.Y0();
            } 
          } 
          return null;
        } 
        throw new IllegalStateException("visitChildren called on an unattached node".toString());
      }  
    return (FocusTargetNode)f;
  }
  
  private static final FocusTargetNode c(FocusTargetNode paramFocusTargetNode) {
    int i = z0.a(1024);
    if (paramFocusTargetNode.Q().h1()) {
      e.c c2 = paramFocusTargetNode.Q().e1();
      j0 j0 = k.k((j)paramFocusTargetNode);
      for (e.c c1 = c2; j0 != null; c1 = null) {
        if ((j0.h0().k().X0() & i) != 0)
          for (c2 = c1; c2 != null; c2 = c2.e1()) {
            if ((c2.c1() & i) != 0) {
              e.c c = c2;
              c1 = null;
              while (c != null) {
                f f2;
                if (c instanceof FocusTargetNode) {
                  c = c;
                  e.c c3 = c1;
                  if (c.E1().q())
                    return (FocusTargetNode)c; 
                } else {
                  int j;
                  if ((c.c1() & i) != 0) {
                    j = 1;
                  } else {
                    j = 0;
                  } 
                  e.c c3 = c1;
                  if (j) {
                    c3 = c1;
                    if (c instanceof l) {
                      f f;
                      c3 = ((l)c).B1();
                      for (j = 0; c3 != null; j = k) {
                        boolean bool;
                        f f3;
                        if ((c3.c1() & i) != 0) {
                          bool = true;
                        } else {
                          bool = false;
                        } 
                        e.c c4 = c;
                        e.c c5 = c1;
                        int k = j;
                        if (bool) {
                          k = j + 1;
                          if (k == 1) {
                            c4 = c3;
                            c5 = c1;
                          } else {
                            f f4;
                            c4 = c1;
                            if (c1 == null)
                              f4 = new f((Object[])new e.c[16], 0); 
                            c1 = c;
                            if (c != null) {
                              f4.d(c);
                              c1 = null;
                            } 
                            f4.d(c3);
                            f3 = f4;
                            c4 = c1;
                          } 
                        } 
                        c3 = c3.Y0();
                        c = c4;
                        f = f3;
                      } 
                      f2 = f;
                      if (j == 1)
                        continue; 
                    } 
                  } 
                } 
                c = k.b(f2);
                f f1 = f2;
              } 
            } 
          }  
        j0 = j0.k0();
        if (j0 != null) {
          androidx.compose.ui.node.a a = j0.h0();
          if (a != null) {
            e.c c = a.o();
            continue;
          } 
        } 
      } 
      return null;
    } 
    throw new IllegalStateException("visitAncestors called on an unattached node".toString());
  }
  
  public static final h d(FocusTargetNode paramFocusTargetNode) {
    q.j(paramFocusTargetNode, "<this>");
    x0 x0 = paramFocusTargetNode.Z0();
    if (x0 != null) {
      h h2 = t.d((s)x0).G((s)x0, false);
      h h1 = h2;
      return (h2 == null) ? h.e.a() : h1;
    } 
    return h.e.a();
  }
  
  public static final boolean e(FocusTargetNode paramFocusTargetNode, int paramInt, r paramr, l<? super FocusTargetNode, Boolean> paraml) {
    Boolean bool;
    boolean bool1;
    q.j(paramFocusTargetNode, "$this$focusSearch");
    q.j(paramr, "layoutDirection");
    q.j(paraml, "onFound");
    d.a a = d.b;
    if (d.l(paramInt, a.e())) {
      bool1 = true;
    } else {
      bool1 = d.l(paramInt, a.f());
    } 
    if (bool1)
      return r.f(paramFocusTargetNode, paramInt, paraml); 
    if (d.l(paramInt, a.d())) {
      bool1 = true;
    } else {
      bool1 = d.l(paramInt, a.g());
    } 
    if (bool1) {
      bool1 = true;
    } else {
      bool1 = d.l(paramInt, a.h());
    } 
    if (bool1) {
      bool1 = true;
    } else {
      bool1 = d.l(paramInt, a.a());
    } 
    if (bool1) {
      bool = s.t(paramFocusTargetNode, paramInt, paraml);
      return (bool != null) ? bool.booleanValue() : false;
    } 
    if (d.l(paramInt, a.b())) {
      paramInt = a.a[paramr.ordinal()];
      if (paramInt != 1) {
        if (paramInt == 2) {
          paramInt = a.d();
        } else {
          throw new NoWhenBranchMatchedException();
        } 
      } else {
        paramInt = a.g();
      } 
      FocusTargetNode focusTargetNode = b((FocusTargetNode)bool);
      if (focusTargetNode != null) {
        bool = s.t(focusTargetNode, paramInt, paraml);
        if (bool != null)
          return bool.booleanValue(); 
      } 
      return false;
    } 
    if (d.l(paramInt, a.c())) {
      FocusTargetNode focusTargetNode = b((FocusTargetNode)bool);
      if (focusTargetNode != null) {
        focusTargetNode = c(focusTargetNode);
      } else {
        focusTargetNode = null;
      } 
      return (focusTargetNode != null && !q.e(focusTargetNode, bool)) ? ((Boolean)paraml.invoke(focusTargetNode)).booleanValue() : false;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Focus search invoked with invalid FocusDirection ");
    stringBuilder.append(d.n(paramInt));
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public static final FocusTargetNode f(FocusTargetNode paramFocusTargetNode) {
    q.j(paramFocusTargetNode, "<this>");
    if (!paramFocusTargetNode.Q().h1())
      return null; 
    int i = z0.a(1024);
    if (paramFocusTargetNode.Q().h1()) {
      f f = new f((Object[])new e.c[16], 0);
      e.c c = paramFocusTargetNode.Q().Y0();
      if (c == null) {
        k.a(f, paramFocusTargetNode.Q());
      } else {
        f.d(c);
      } 
      while (f.w()) {
        e.c c1 = (e.c)f.B(f.s() - 1);
        e.c c2 = c1;
        if ((c1.X0() & i) == 0) {
          k.a(f, c1);
          continue;
        } 
        while (c2 != null) {
          if ((c2.c1() & i) != 0) {
            c1 = null;
            while (c2 != null) {
              f f2;
              z0.p p1;
              if (c2 instanceof FocusTargetNode) {
                c = c2;
                p1 = c.G1();
                int j = a.b[p1.ordinal()];
                if (j != 1 && j != 2 && j != 3) {
                  c = c1;
                } else {
                  return (FocusTargetNode)c;
                } 
              } else {
                int j;
                if ((p1.c1() & i) != 0) {
                  j = 1;
                } else {
                  j = 0;
                } 
                c = c1;
                if (j) {
                  c = c1;
                  if (p1 instanceof l) {
                    f f3;
                    c = ((l)p1).B1();
                    j = 0;
                    while (c != null) {
                      boolean bool;
                      f f4;
                      if ((c.c1() & i) != 0) {
                        bool = true;
                      } else {
                        bool = false;
                      } 
                      e.c c4 = c1;
                      int k = j;
                      z0.p p2 = p1;
                      if (bool) {
                        k = j + 1;
                        if (k == 1) {
                          e.c c5 = c;
                          c4 = c1;
                        } else {
                          c4 = c1;
                          if (c1 == null)
                            f4 = new f((Object[])new e.c[16], 0); 
                          p2 = p1;
                          if (p1 != null) {
                            f4.d(p1);
                            p2 = null;
                          } 
                          f4.d(c);
                        } 
                      } 
                      c = c.Y0();
                      f3 = f4;
                      j = k;
                      p1 = p2;
                    } 
                    f2 = f3;
                    if (j == 1)
                      continue; 
                  } 
                } 
              } 
              c3 = k.b(f2);
              f f1 = f2;
            } 
            break;
          } 
          e.c c3 = c3.Y0();
        } 
      } 
      return null;
    } 
    throw new IllegalStateException("visitChildren called on an unattached node".toString());
  }
  
  public static final boolean g(FocusTargetNode paramFocusTargetNode) {
    // Byte code:
    //   0: aload_0
    //   1: ldc '<this>'
    //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_0
    //   7: invokevirtual Z0 : ()Lq1/x0;
    //   10: astore_2
    //   11: aload_2
    //   12: ifnull -> 37
    //   15: aload_2
    //   16: invokevirtual c1 : ()Lq1/j0;
    //   19: astore_2
    //   20: aload_2
    //   21: ifnull -> 37
    //   24: aload_2
    //   25: invokevirtual c : ()Z
    //   28: iconst_1
    //   29: if_icmpne -> 37
    //   32: iconst_1
    //   33: istore_1
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_1
    //   39: iload_1
    //   40: ifeq -> 82
    //   43: aload_0
    //   44: invokevirtual Z0 : ()Lq1/x0;
    //   47: astore_0
    //   48: aload_0
    //   49: ifnull -> 74
    //   52: aload_0
    //   53: invokevirtual c1 : ()Lq1/j0;
    //   56: astore_0
    //   57: aload_0
    //   58: ifnull -> 74
    //   61: aload_0
    //   62: invokevirtual H0 : ()Z
    //   65: iconst_1
    //   66: if_icmpne -> 74
    //   69: iconst_1
    //   70: istore_1
    //   71: goto -> 76
    //   74: iconst_0
    //   75: istore_1
    //   76: iload_1
    //   77: ifeq -> 82
    //   80: iconst_1
    //   81: ireturn
    //   82: iconst_0
    //   83: ireturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */