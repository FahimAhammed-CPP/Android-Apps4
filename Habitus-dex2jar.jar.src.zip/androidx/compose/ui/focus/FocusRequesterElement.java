package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q1.u0;

final class FocusRequesterElement extends u0<n> {
  private final k c;
  
  public FocusRequesterElement(k paramk) {
    this.c = paramk;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof FocusRequesterElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((FocusRequesterElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public n s() {
    return new n(this.c);
  }
  
  public void t(n paramn) {
    q.j(paramn, "node");
    paramn.A1().d().z(paramn);
    paramn.B1(this.c);
    paramn.A1().d().d(paramn);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FocusRequesterElement(focusRequester=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\FocusRequesterElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */