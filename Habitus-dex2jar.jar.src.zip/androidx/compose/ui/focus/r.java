package androidx.compose.ui.focus;

import androidx.compose.ui.e;
import dk.l;
import ik.f;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.q;
import m0.f;
import o1.c;
import q1.j;
import q1.j0;
import q1.k;
import q1.l;
import q1.z0;
import z0.p;

public final class r {
  private static final boolean b(FocusTargetNode paramFocusTargetNode, l<? super FocusTargetNode, Boolean> paraml) {
    p p = paramFocusTargetNode.G1();
    int[] arrayOfInt = a.a;
    int i = arrayOfInt[p.ordinal()];
    if (i != 1) {
      if (i != 2 && i != 3) {
        if (i == 4) {
          if (!g(paramFocusTargetNode, paraml)) {
            boolean bool;
            if (paramFocusTargetNode.E1().q()) {
              bool = ((Boolean)paraml.invoke(paramFocusTargetNode)).booleanValue();
            } else {
              bool = false;
            } 
            if (bool)
              return true; 
          } else {
            return true;
          } 
        } else {
          throw new NoWhenBranchMatchedException();
        } 
      } else {
        return g(paramFocusTargetNode, paraml);
      } 
    } else {
      FocusTargetNode focusTargetNode = p.f(paramFocusTargetNode);
      if (focusTargetNode != null) {
        i = arrayOfInt[focusTargetNode.G1().ordinal()];
        if (i != 1) {
          if (i != 2 && i != 3) {
            if (i != 4)
              throw new NoWhenBranchMatchedException(); 
            throw new IllegalStateException("ActiveParent must have a focusedChild".toString());
          } 
          return d(paramFocusTargetNode, focusTargetNode, d.b.f(), paraml);
        } 
        return (b(focusTargetNode, paraml) || d(paramFocusTargetNode, focusTargetNode, d.b.f(), paraml) || (focusTargetNode.E1().q() && ((Boolean)paraml.invoke(focusTargetNode)).booleanValue()));
      } 
      throw new IllegalStateException("ActiveParent must have a focusedChild".toString());
    } 
    return false;
  }
  
  private static final boolean c(FocusTargetNode paramFocusTargetNode, l<? super FocusTargetNode, Boolean> paraml) {
    p p = paramFocusTargetNode.G1();
    int i = a.a[p.ordinal()];
    boolean bool = true;
    if (i != 1) {
      if (i != 2 && i != 3) {
        if (i == 4)
          return paramFocusTargetNode.E1().q() ? ((Boolean)paraml.invoke(paramFocusTargetNode)).booleanValue() : h(paramFocusTargetNode, paraml); 
        throw new NoWhenBranchMatchedException();
      } 
      return h(paramFocusTargetNode, paraml);
    } 
    FocusTargetNode focusTargetNode = p.f(paramFocusTargetNode);
    if (focusTargetNode != null) {
      if (!c(focusTargetNode, paraml)) {
        if (d(paramFocusTargetNode, focusTargetNode, d.b.e(), paraml))
          return true; 
        bool = false;
      } 
      return bool;
    } 
    throw new IllegalStateException("ActiveParent must have a focusedChild".toString());
  }
  
  private static final boolean d(FocusTargetNode paramFocusTargetNode1, FocusTargetNode paramFocusTargetNode2, int paramInt, l<? super FocusTargetNode, Boolean> paraml) {
    if (i(paramFocusTargetNode1, paramFocusTargetNode2, paramInt, paraml))
      return true; 
    Boolean bool = a.<Boolean>a(paramFocusTargetNode1, paramInt, new b(paramFocusTargetNode1, paramFocusTargetNode2, paramInt, paraml));
    return (bool != null) ? bool.booleanValue() : false;
  }
  
  private static final boolean e(FocusTargetNode paramFocusTargetNode) {
    int i = z0.a(1024);
    if (paramFocusTargetNode.Q().h1()) {
      boolean bool;
      e.c c2 = paramFocusTargetNode.Q().e1();
      j0 j0 = k.k((j)paramFocusTargetNode);
      e.c c1 = c2;
      label66: while (true) {
        c2 = null;
        bool = false;
        if (j0 != null) {
          if ((j0.h0().k().X0() & i) != 0)
            for (e.c c = c1; c != null; c = c.e1()) {
              if ((c.c1() & i) != 0) {
                c2 = c;
                c1 = null;
                while (c2 != null) {
                  int j;
                  f f2;
                  if (c2 instanceof FocusTargetNode)
                    break label66; 
                  if ((c2.c1() & i) != 0) {
                    j = 1;
                  } else {
                    j = 0;
                  } 
                  e.c c3 = c1;
                  if (j) {
                    c3 = c1;
                    if (c2 instanceof l) {
                      f f;
                      c3 = ((l)c2).B1();
                      for (j = 0; c3 != null; j = k) {
                        boolean bool1;
                        f f3;
                        if ((c3.c1() & i) != 0) {
                          bool1 = true;
                        } else {
                          bool1 = false;
                        } 
                        e.c c4 = c2;
                        e.c c5 = c1;
                        int k = j;
                        if (bool1) {
                          k = j + 1;
                          if (k == 1) {
                            c4 = c3;
                            c5 = c1;
                          } else {
                            f f4;
                            c4 = c1;
                            if (c1 == null)
                              f4 = new f((Object[])new e.c[16], 0); 
                            c1 = c2;
                            if (c2 != null) {
                              f4.d(c2);
                              c1 = null;
                            } 
                            f4.d(c3);
                            f3 = f4;
                            c4 = c1;
                          } 
                        } 
                        c3 = c3.Y0();
                        c2 = c4;
                        f = f3;
                      } 
                      f2 = f;
                      if (j == 1)
                        continue; 
                    } 
                  } 
                  c2 = k.b(f2);
                  f f1 = f2;
                } 
              } 
            }  
          j0 = j0.k0();
          if (j0 != null) {
            androidx.compose.ui.node.a a = j0.h0();
            if (a != null) {
              e.c c = a.o();
              continue;
            } 
          } 
          c1 = null;
          continue;
        } 
        break;
      } 
      if (c2 == null)
        bool = true; 
      return bool;
    } 
    throw new IllegalStateException("visitAncestors called on an unattached node".toString());
  }
  
  public static final boolean f(FocusTargetNode paramFocusTargetNode, int paramInt, l<? super FocusTargetNode, Boolean> paraml) {
    q.j(paramFocusTargetNode, "$this$oneDimensionalFocusSearch");
    q.j(paraml, "onFound");
    d.a a = d.b;
    if (d.l(paramInt, a.e()))
      return c(paramFocusTargetNode, paraml); 
    if (d.l(paramInt, a.f()))
      return b(paramFocusTargetNode, paraml); 
    throw new IllegalStateException("This function should only be used for 1-D focus search".toString());
  }
  
  private static final boolean g(FocusTargetNode paramFocusTargetNode, l<? super FocusTargetNode, Boolean> paraml) {
    f f = new f((Object[])new FocusTargetNode[16], 0);
    int i = z0.a(1024);
    if (paramFocusTargetNode.Q().h1()) {
      f f1 = new f((Object[])new e.c[16], 0);
      e.c c = paramFocusTargetNode.Q().Y0();
      if (c == null) {
        k.a(f1, paramFocusTargetNode.Q());
      } else {
        f1.d(c);
      } 
      while (f1.w()) {
        e.c c1 = (e.c)f1.B(f1.s() - 1);
        e.c c2 = c1;
        if ((c1.X0() & i) == 0) {
          k.a(f1, c1);
          continue;
        } 
        while (c2 != null) {
          if ((c2.c1() & i) != 0) {
            c1 = null;
            while (c2 != null) {
              f f3;
              if (c2 instanceof FocusTargetNode) {
                f.d(c2);
                c = c1;
              } else {
                int k;
                if ((c2.c1() & i) != 0) {
                  k = 1;
                } else {
                  k = 0;
                } 
                c = c1;
                if (k) {
                  c = c1;
                  if (c2 instanceof l) {
                    f f4;
                    c = ((l)c2).B1();
                    k = 0;
                    while (c != null) {
                      boolean bool;
                      f f5;
                      if ((c.c1() & i) != 0) {
                        bool = true;
                      } else {
                        bool = false;
                      } 
                      e.c c3 = c1;
                      int m = k;
                      e.c c4 = c2;
                      if (bool) {
                        m = k + 1;
                        if (m == 1) {
                          c4 = c;
                          c3 = c1;
                        } else {
                          c3 = c1;
                          if (c1 == null)
                            f5 = new f((Object[])new e.c[16], 0); 
                          c4 = c2;
                          if (c2 != null) {
                            f5.d(c2);
                            c4 = null;
                          } 
                          f5.d(c);
                        } 
                      } 
                      c = c.Y0();
                      f4 = f5;
                      k = m;
                      c2 = c4;
                    } 
                    f3 = f4;
                    if (k == 1)
                      continue; 
                  } 
                } 
              } 
              c2 = k.b(f3);
              f f2 = f3;
            } 
            break;
          } 
          c2 = c2.Y0();
        } 
      } 
      f.F(q.s0);
      int j = f.s();
      if (j > 0) {
        int k;
        j--;
        Object[] arrayOfObject = f.r();
        do {
          c = (FocusTargetNode)arrayOfObject[j];
          if (p.g((FocusTargetNode)c) && b((FocusTargetNode)c, paraml))
            return true; 
          k = j - 1;
          j = k;
        } while (k >= 0);
      } 
      return false;
    } 
    throw new IllegalStateException("visitChildren called on an unattached node".toString());
  }
  
  private static final boolean h(FocusTargetNode paramFocusTargetNode, l<? super FocusTargetNode, Boolean> paraml) {
    f f = new f((Object[])new FocusTargetNode[16], 0);
    int i = z0.a(1024);
    if (paramFocusTargetNode.Q().h1()) {
      f f1 = new f((Object[])new e.c[16], 0);
      e.c c = paramFocusTargetNode.Q().Y0();
      if (c == null) {
        k.a(f1, paramFocusTargetNode.Q());
      } else {
        f1.d(c);
      } 
      while (f1.w()) {
        e.c c1 = (e.c)f1.B(f1.s() - 1);
        e.c c2 = c1;
        if ((c1.X0() & i) == 0) {
          k.a(f1, c1);
          continue;
        } 
        while (c2 != null) {
          if ((c2.c1() & i) != 0) {
            c1 = null;
            while (c2 != null) {
              f f3;
              if (c2 instanceof FocusTargetNode) {
                f.d(c2);
                c = c1;
              } else {
                int k;
                if ((c2.c1() & i) != 0) {
                  k = 1;
                } else {
                  k = 0;
                } 
                c = c1;
                if (k) {
                  c = c1;
                  if (c2 instanceof l) {
                    f f4;
                    c = ((l)c2).B1();
                    k = 0;
                    while (c != null) {
                      boolean bool;
                      f f5;
                      if ((c.c1() & i) != 0) {
                        bool = true;
                      } else {
                        bool = false;
                      } 
                      e.c c3 = c1;
                      int m = k;
                      e.c c4 = c2;
                      if (bool) {
                        m = k + 1;
                        if (m == 1) {
                          c4 = c;
                          c3 = c1;
                        } else {
                          c3 = c1;
                          if (c1 == null)
                            f5 = new f((Object[])new e.c[16], 0); 
                          c4 = c2;
                          if (c2 != null) {
                            f5.d(c2);
                            c4 = null;
                          } 
                          f5.d(c);
                        } 
                      } 
                      c = c.Y0();
                      f4 = f5;
                      k = m;
                      c2 = c4;
                    } 
                    f3 = f4;
                    if (k == 1)
                      continue; 
                  } 
                } 
              } 
              c2 = k.b(f3);
              f f2 = f3;
            } 
            break;
          } 
          c2 = c2.Y0();
        } 
      } 
      f.F(q.s0);
      int j = f.s();
      if (j > 0) {
        int m;
        Object[] arrayOfObject = f.r();
        int k = 0;
        do {
          c = (FocusTargetNode)arrayOfObject[k];
          if (p.g((FocusTargetNode)c) && c((FocusTargetNode)c, paraml)) {
            m = 1;
          } else {
            m = 0;
          } 
          if (m)
            return true; 
          m = k + 1;
          k = m;
        } while (m < j);
      } 
      return false;
    } 
    throw new IllegalStateException("visitChildren called on an unattached node".toString());
  }
  
  private static final boolean i(FocusTargetNode paramFocusTargetNode1, FocusTargetNode paramFocusTargetNode2, int paramInt, l<? super FocusTargetNode, Boolean> paraml) {
    int i;
    if (paramFocusTargetNode1.G1() == p.t0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      f f = new f((Object[])new FocusTargetNode[16], 0);
      int j = z0.a(1024);
      if (paramFocusTargetNode1.Q().h1()) {
        FocusTargetNode focusTargetNode;
        f f1 = new f((Object[])new e.c[16], 0);
        e.c c = paramFocusTargetNode1.Q().Y0();
        if (c == null) {
          k.a(f1, paramFocusTargetNode1.Q());
        } else {
          f1.d(c);
        } 
        while (f1.w()) {
          c = (e.c)f1.B(f1.s() - 1);
          e.c c1 = c;
          if ((c.X0() & j) == 0) {
            k.a(f1, c);
            continue;
          } 
          while (c1 != null) {
            if ((c1.c1() & j) != 0) {
              c = null;
              while (c1 != null) {
                f f3;
                if (c1 instanceof FocusTargetNode) {
                  f.d(c1);
                  e.c c2 = c;
                } else {
                  if ((c1.c1() & j) != 0) {
                    i = 1;
                  } else {
                    i = 0;
                  } 
                  e.c c2 = c;
                  if (i) {
                    c2 = c;
                    if (c1 instanceof l) {
                      f f4;
                      c2 = ((l)c1).B1();
                      for (i = 0; c2 != null; i = k) {
                        boolean bool;
                        f f5;
                        if ((c2.c1() & j) != 0) {
                          bool = true;
                        } else {
                          bool = false;
                        } 
                        e.c c3 = c1;
                        e.c c4 = c;
                        int k = i;
                        if (bool) {
                          k = i + 1;
                          if (k == 1) {
                            c3 = c2;
                            c4 = c;
                          } else {
                            f f6;
                            c3 = c;
                            if (c == null)
                              f6 = new f((Object[])new e.c[16], 0); 
                            c = c1;
                            if (c1 != null) {
                              f6.d(c1);
                              c = null;
                            } 
                            f6.d(c2);
                            f5 = f6;
                            c3 = c;
                          } 
                        } 
                        c2 = c2.Y0();
                        c1 = c3;
                        f4 = f5;
                      } 
                      f3 = f4;
                      if (i == 1)
                        continue; 
                    } 
                  } 
                } 
                c1 = k.b(f3);
                f f2 = f3;
              } 
              break;
            } 
            c1 = c1.Y0();
          } 
        } 
        f.F(q.s0);
        d.a a = d.b;
        if (d.l(paramInt, a.e())) {
          f f2 = new f(0, f.s() - 1);
          i = f2.i();
          int k = f2.j();
          if (i <= k) {
            boolean bool = false;
            while (true) {
              if (bool) {
                focusTargetNode = (FocusTargetNode)f.r()[i];
                if (p.g(focusTargetNode) && c(focusTargetNode, paraml))
                  return true; 
              } 
              if (q.e(f.r()[i], paramFocusTargetNode2))
                bool = true; 
              if (i != k) {
                i++;
                continue;
              } 
              break;
            } 
          } 
        } else if (d.l(paramInt, focusTargetNode.f())) {
          f f2 = new f(0, f.s() - 1);
          int k = f2.i();
          i = f2.j();
          if (k <= i) {
            boolean bool = false;
            while (true) {
              if (bool) {
                FocusTargetNode focusTargetNode1 = (FocusTargetNode)f.r()[i];
                if (p.g(focusTargetNode1) && b(focusTargetNode1, paraml))
                  return true; 
              } 
              if (q.e(f.r()[i], paramFocusTargetNode2))
                bool = true; 
              if (i != k) {
                i--;
                continue;
              } 
              break;
            } 
          } 
        } else {
          throw new IllegalStateException("This function should only be used for 1-D focus search".toString());
        } 
        return (!d.l(paramInt, d.b.e()) && paramFocusTargetNode1.E1().q()) ? (e(paramFocusTargetNode1) ? false : ((Boolean)paraml.invoke(paramFocusTargetNode1)).booleanValue()) : false;
      } 
      throw new IllegalStateException("visitChildren called on an unattached node".toString());
    } 
    throw new IllegalStateException("This function should only be used within a parent that has focus.".toString());
  }
  
  static final class b extends kotlin.jvm.internal.r implements l<c.a, Boolean> {
    b(FocusTargetNode param1FocusTargetNode1, FocusTargetNode param1FocusTargetNode2, int param1Int, l<? super FocusTargetNode, Boolean> param1l) {
      super(1);
    }
    
    public final Boolean a(c.a param1a) {
      boolean bool;
      q.j(param1a, "$this$searchBeyondBounds");
      Boolean bool1 = Boolean.valueOf(r.a(this.s0, this.t0, this.u0, this.v0));
      if (bool1.booleanValue() || !param1a.a()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool ? bool1 : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */