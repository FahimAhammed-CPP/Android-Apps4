package androidx.compose.ui.focus;

import a1.h;
import android.view.KeyEvent;
import androidx.compose.ui.e;
import dk.l;
import k2.r;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.d0;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import m0.f;
import q1.j;
import q1.j0;
import q1.k;
import q1.l;
import q1.u0;
import q1.z0;
import rj.v;
import z0.c;
import z0.e;
import z0.j;
import z0.k;
import z0.p;

public final class FocusOwnerImpl implements j {
  private FocusTargetNode a = new FocusTargetNode();
  
  private final e b;
  
  private final e c;
  
  public r d;
  
  public FocusOwnerImpl(l<? super dk.a<v>, v> paraml) {
    this.b = new e(paraml);
    this.c = (e)new FocusOwnerImpl$modifier$1(this);
  }
  
  private final e.c q(j paramj) {
    int i = z0.a(1024) | z0.a(8192);
    if (paramj.Q().h1()) {
      e.c c1 = paramj.Q();
      int k = c1.X0();
      e.c c3 = null;
      e.c c2 = null;
      if ((k & i) != 0) {
        c1 = c1.Y0();
        while (true) {
          c3 = c2;
          if (c1 != null) {
            c3 = c2;
            if ((c1.c1() & i) != 0) {
              if ((z0.a(1024) & c1.c1()) != 0) {
                k = 1;
              } else {
                k = 0;
              } 
              if (k != 0)
                return c2; 
              c3 = c1;
            } 
            c1 = c1.Y0();
            c2 = c3;
            continue;
          } 
          break;
        } 
      } 
      return c3;
    } 
    throw new IllegalStateException("visitLocalDescendants called on an unattached node".toString());
  }
  
  private final boolean r(int paramInt) {
    if (this.a.G1().j()) {
      boolean bool;
      if (this.a.G1().d())
        return false; 
      d.a a = d.b;
      if (d.l(paramInt, a.e())) {
        bool = true;
      } else {
        bool = d.l(paramInt, a.f());
      } 
      if (bool) {
        m(false);
        return !this.a.G1().d() ? false : f(paramInt);
      } 
    } 
    return false;
  }
  
  public void a(r paramr) {
    q.j(paramr, "<set-?>");
    this.d = paramr;
  }
  
  public void b() {
    if (this.a.G1() == p.v0)
      this.a.J1(p.s0); 
  }
  
  public void c(boolean paramBoolean1, boolean paramBoolean2) {
    if (!paramBoolean1) {
      z0.a a = o.e(this.a, d.b.c());
      int i = a.a[a.ordinal()];
      if (i == 1 || i == 2 || i == 3)
        return; 
    } 
    p p = this.a.G1();
    if (o.c(this.a, paramBoolean1, paramBoolean2)) {
      FocusTargetNode focusTargetNode = this.a;
      int i = a.b[p.ordinal()];
      if (i != 1 && i != 2 && i != 3) {
        if (i == 4) {
          p = p.v0;
        } else {
          throw new NoWhenBranchMatchedException();
        } 
      } else {
        p = p.s0;
      } 
      focusTargetNode.J1(p);
    } 
  }
  
  public boolean d(n1.b paramb) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'event'
    //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_0
    //   7: getfield a : Landroidx/compose/ui/focus/FocusTargetNode;
    //   10: invokestatic b : (Landroidx/compose/ui/focus/FocusTargetNode;)Landroidx/compose/ui/focus/FocusTargetNode;
    //   13: astore #7
    //   15: aload #7
    //   17: ifnull -> 418
    //   20: sipush #16384
    //   23: invokestatic a : (I)I
    //   26: istore #5
    //   28: aload #7
    //   30: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   35: invokevirtual h1 : ()Z
    //   38: ifeq -> 405
    //   41: aload #7
    //   43: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   48: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   51: astore #6
    //   53: aload #7
    //   55: invokestatic k : (Lq1/j;)Lq1/j0;
    //   58: astore #11
    //   60: aload #11
    //   62: ifnull -> 392
    //   65: aload #11
    //   67: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   70: invokevirtual k : ()Landroidx/compose/ui/e$c;
    //   73: invokevirtual X0 : ()I
    //   76: iload #5
    //   78: iand
    //   79: ifeq -> 352
    //   82: aload #6
    //   84: astore #8
    //   86: aload #8
    //   88: ifnull -> 352
    //   91: aload #8
    //   93: invokevirtual c1 : ()I
    //   96: iload #5
    //   98: iand
    //   99: ifeq -> 342
    //   102: aconst_null
    //   103: astore #6
    //   105: aload #8
    //   107: astore #7
    //   109: aload #7
    //   111: ifnull -> 342
    //   114: aload #7
    //   116: instanceof n1/a
    //   119: ifeq -> 125
    //   122: goto -> 395
    //   125: aload #7
    //   127: invokevirtual c1 : ()I
    //   130: iload #5
    //   132: iand
    //   133: ifeq -> 141
    //   136: iconst_1
    //   137: istore_2
    //   138: goto -> 143
    //   141: iconst_0
    //   142: istore_2
    //   143: aload #6
    //   145: astore #9
    //   147: iload_2
    //   148: ifeq -> 328
    //   151: aload #6
    //   153: astore #9
    //   155: aload #7
    //   157: instanceof q1/l
    //   160: ifeq -> 328
    //   163: aload #7
    //   165: checkcast q1/l
    //   168: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   171: astore #9
    //   173: iconst_0
    //   174: istore_2
    //   175: aload #9
    //   177: ifnull -> 316
    //   180: aload #9
    //   182: invokevirtual c1 : ()I
    //   185: iload #5
    //   187: iand
    //   188: ifeq -> 196
    //   191: iconst_1
    //   192: istore_3
    //   193: goto -> 198
    //   196: iconst_0
    //   197: istore_3
    //   198: aload #7
    //   200: astore #10
    //   202: aload #6
    //   204: astore #12
    //   206: iload_2
    //   207: istore #4
    //   209: iload_3
    //   210: ifeq -> 295
    //   213: iload_2
    //   214: iconst_1
    //   215: iadd
    //   216: istore #4
    //   218: iload #4
    //   220: iconst_1
    //   221: if_icmpne -> 235
    //   224: aload #9
    //   226: astore #10
    //   228: aload #6
    //   230: astore #12
    //   232: goto -> 295
    //   235: aload #6
    //   237: astore #10
    //   239: aload #6
    //   241: ifnonnull -> 259
    //   244: new m0/f
    //   247: dup
    //   248: bipush #16
    //   250: anewarray androidx/compose/ui/e$c
    //   253: iconst_0
    //   254: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   257: astore #10
    //   259: aload #7
    //   261: astore #6
    //   263: aload #7
    //   265: ifnull -> 279
    //   268: aload #10
    //   270: aload #7
    //   272: invokevirtual d : (Ljava/lang/Object;)Z
    //   275: pop
    //   276: aconst_null
    //   277: astore #6
    //   279: aload #10
    //   281: aload #9
    //   283: invokevirtual d : (Ljava/lang/Object;)Z
    //   286: pop
    //   287: aload #10
    //   289: astore #12
    //   291: aload #6
    //   293: astore #10
    //   295: aload #9
    //   297: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   300: astore #9
    //   302: aload #10
    //   304: astore #7
    //   306: aload #12
    //   308: astore #6
    //   310: iload #4
    //   312: istore_2
    //   313: goto -> 175
    //   316: aload #6
    //   318: astore #9
    //   320: iload_2
    //   321: iconst_1
    //   322: if_icmpne -> 328
    //   325: goto -> 109
    //   328: aload #9
    //   330: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   333: astore #7
    //   335: aload #9
    //   337: astore #6
    //   339: goto -> 109
    //   342: aload #8
    //   344: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   347: astore #8
    //   349: goto -> 86
    //   352: aload #11
    //   354: invokevirtual k0 : ()Lq1/j0;
    //   357: astore #11
    //   359: aload #11
    //   361: ifnull -> 386
    //   364: aload #11
    //   366: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   369: astore #6
    //   371: aload #6
    //   373: ifnull -> 386
    //   376: aload #6
    //   378: invokevirtual o : ()Landroidx/compose/ui/e$c;
    //   381: astore #6
    //   383: goto -> 60
    //   386: aconst_null
    //   387: astore #6
    //   389: goto -> 60
    //   392: aconst_null
    //   393: astore #7
    //   395: aload #7
    //   397: checkcast n1/a
    //   400: astore #12
    //   402: goto -> 421
    //   405: new java/lang/IllegalStateException
    //   408: dup
    //   409: ldc 'visitAncestors called on an unattached node'
    //   411: invokevirtual toString : ()Ljava/lang/String;
    //   414: invokespecial <init> : (Ljava/lang/String;)V
    //   417: athrow
    //   418: aconst_null
    //   419: astore #12
    //   421: aload #12
    //   423: ifnull -> 1524
    //   426: sipush #16384
    //   429: invokestatic a : (I)I
    //   432: istore #5
    //   434: aload #12
    //   436: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   441: invokevirtual h1 : ()Z
    //   444: ifeq -> 1511
    //   447: aload #12
    //   449: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   454: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   457: astore #7
    //   459: aload #12
    //   461: invokestatic k : (Lq1/j;)Lq1/j0;
    //   464: astore #13
    //   466: aconst_null
    //   467: astore #8
    //   469: aload #13
    //   471: ifnull -> 881
    //   474: aload #8
    //   476: astore #9
    //   478: aload #13
    //   480: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   483: invokevirtual k : ()Landroidx/compose/ui/e$c;
    //   486: invokevirtual X0 : ()I
    //   489: iload #5
    //   491: iand
    //   492: ifeq -> 833
    //   495: aload #8
    //   497: astore #6
    //   499: aload #7
    //   501: astore #8
    //   503: aload #6
    //   505: astore #9
    //   507: aload #8
    //   509: ifnull -> 833
    //   512: aload #6
    //   514: astore #9
    //   516: aload #8
    //   518: invokevirtual c1 : ()I
    //   521: iload #5
    //   523: iand
    //   524: ifeq -> 819
    //   527: aload #8
    //   529: astore #10
    //   531: aconst_null
    //   532: astore #7
    //   534: aload #6
    //   536: astore #9
    //   538: aload #10
    //   540: ifnull -> 819
    //   543: aload #10
    //   545: instanceof n1/a
    //   548: ifeq -> 586
    //   551: aload #6
    //   553: astore #9
    //   555: aload #6
    //   557: ifnonnull -> 569
    //   560: new java/util/ArrayList
    //   563: dup
    //   564: invokespecial <init> : ()V
    //   567: astore #9
    //   569: aload #9
    //   571: aload #10
    //   573: invokeinterface add : (Ljava/lang/Object;)Z
    //   578: pop
    //   579: aload #7
    //   581: astore #11
    //   583: goto -> 801
    //   586: aload #10
    //   588: invokevirtual c1 : ()I
    //   591: iload #5
    //   593: iand
    //   594: ifeq -> 602
    //   597: iconst_1
    //   598: istore_2
    //   599: goto -> 604
    //   602: iconst_0
    //   603: istore_2
    //   604: aload #6
    //   606: astore #9
    //   608: aload #7
    //   610: astore #11
    //   612: iload_2
    //   613: ifeq -> 801
    //   616: aload #6
    //   618: astore #9
    //   620: aload #7
    //   622: astore #11
    //   624: aload #10
    //   626: instanceof q1/l
    //   629: ifeq -> 801
    //   632: aload #10
    //   634: checkcast q1/l
    //   637: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   640: astore #9
    //   642: iconst_0
    //   643: istore_2
    //   644: aload #9
    //   646: ifnull -> 785
    //   649: aload #9
    //   651: invokevirtual c1 : ()I
    //   654: iload #5
    //   656: iand
    //   657: ifeq -> 665
    //   660: iconst_1
    //   661: istore_3
    //   662: goto -> 667
    //   665: iconst_0
    //   666: istore_3
    //   667: aload #10
    //   669: astore #11
    //   671: aload #7
    //   673: astore #14
    //   675: iload_2
    //   676: istore #4
    //   678: iload_3
    //   679: ifeq -> 764
    //   682: iload_2
    //   683: iconst_1
    //   684: iadd
    //   685: istore #4
    //   687: iload #4
    //   689: iconst_1
    //   690: if_icmpne -> 704
    //   693: aload #9
    //   695: astore #11
    //   697: aload #7
    //   699: astore #14
    //   701: goto -> 764
    //   704: aload #7
    //   706: astore #11
    //   708: aload #7
    //   710: ifnonnull -> 728
    //   713: new m0/f
    //   716: dup
    //   717: bipush #16
    //   719: anewarray androidx/compose/ui/e$c
    //   722: iconst_0
    //   723: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   726: astore #11
    //   728: aload #10
    //   730: astore #7
    //   732: aload #10
    //   734: ifnull -> 748
    //   737: aload #11
    //   739: aload #10
    //   741: invokevirtual d : (Ljava/lang/Object;)Z
    //   744: pop
    //   745: aconst_null
    //   746: astore #7
    //   748: aload #11
    //   750: aload #9
    //   752: invokevirtual d : (Ljava/lang/Object;)Z
    //   755: pop
    //   756: aload #11
    //   758: astore #14
    //   760: aload #7
    //   762: astore #11
    //   764: aload #9
    //   766: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   769: astore #9
    //   771: aload #11
    //   773: astore #10
    //   775: aload #14
    //   777: astore #7
    //   779: iload #4
    //   781: istore_2
    //   782: goto -> 644
    //   785: aload #6
    //   787: astore #9
    //   789: aload #7
    //   791: astore #11
    //   793: iload_2
    //   794: iconst_1
    //   795: if_icmpne -> 801
    //   798: goto -> 534
    //   801: aload #11
    //   803: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   806: astore #10
    //   808: aload #9
    //   810: astore #6
    //   812: aload #11
    //   814: astore #7
    //   816: goto -> 534
    //   819: aload #8
    //   821: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   824: astore #8
    //   826: aload #9
    //   828: astore #6
    //   830: goto -> 503
    //   833: aload #13
    //   835: invokevirtual k0 : ()Lq1/j0;
    //   838: astore #13
    //   840: aload #13
    //   842: ifnull -> 871
    //   845: aload #13
    //   847: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   850: astore #6
    //   852: aload #6
    //   854: ifnull -> 871
    //   857: aload #6
    //   859: invokevirtual o : ()Landroidx/compose/ui/e$c;
    //   862: astore #7
    //   864: aload #9
    //   866: astore #8
    //   868: goto -> 469
    //   871: aconst_null
    //   872: astore #7
    //   874: aload #9
    //   876: astore #8
    //   878: goto -> 469
    //   881: aload #8
    //   883: ifnull -> 938
    //   886: aload #8
    //   888: invokeinterface size : ()I
    //   893: iconst_1
    //   894: isub
    //   895: istore_2
    //   896: iload_2
    //   897: iflt -> 938
    //   900: iload_2
    //   901: iconst_1
    //   902: isub
    //   903: istore_3
    //   904: aload #8
    //   906: iload_2
    //   907: invokeinterface get : (I)Ljava/lang/Object;
    //   912: checkcast n1/a
    //   915: aload_1
    //   916: invokeinterface k0 : (Ln1/b;)Z
    //   921: ifeq -> 926
    //   924: iconst_1
    //   925: ireturn
    //   926: iload_3
    //   927: ifge -> 933
    //   930: goto -> 938
    //   933: iload_3
    //   934: istore_2
    //   935: goto -> 900
    //   938: aload #12
    //   940: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   945: astore #9
    //   947: aconst_null
    //   948: astore #6
    //   950: aload #9
    //   952: ifnull -> 1200
    //   955: aload #9
    //   957: instanceof n1/a
    //   960: ifeq -> 983
    //   963: aload #6
    //   965: astore #7
    //   967: aload #9
    //   969: checkcast n1/a
    //   972: aload_1
    //   973: invokeinterface k0 : (Ln1/b;)Z
    //   978: ifeq -> 1186
    //   981: iconst_1
    //   982: ireturn
    //   983: aload #9
    //   985: invokevirtual c1 : ()I
    //   988: iload #5
    //   990: iand
    //   991: ifeq -> 999
    //   994: iconst_1
    //   995: istore_2
    //   996: goto -> 1001
    //   999: iconst_0
    //   1000: istore_2
    //   1001: aload #6
    //   1003: astore #7
    //   1005: iload_2
    //   1006: ifeq -> 1186
    //   1009: aload #6
    //   1011: astore #7
    //   1013: aload #9
    //   1015: instanceof q1/l
    //   1018: ifeq -> 1186
    //   1021: aload #9
    //   1023: checkcast q1/l
    //   1026: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   1029: astore #7
    //   1031: iconst_0
    //   1032: istore_2
    //   1033: aload #7
    //   1035: ifnull -> 1174
    //   1038: aload #7
    //   1040: invokevirtual c1 : ()I
    //   1043: iload #5
    //   1045: iand
    //   1046: ifeq -> 1054
    //   1049: iconst_1
    //   1050: istore_3
    //   1051: goto -> 1056
    //   1054: iconst_0
    //   1055: istore_3
    //   1056: aload #9
    //   1058: astore #10
    //   1060: aload #6
    //   1062: astore #11
    //   1064: iload_2
    //   1065: istore #4
    //   1067: iload_3
    //   1068: ifeq -> 1153
    //   1071: iload_2
    //   1072: iconst_1
    //   1073: iadd
    //   1074: istore #4
    //   1076: iload #4
    //   1078: iconst_1
    //   1079: if_icmpne -> 1093
    //   1082: aload #7
    //   1084: astore #10
    //   1086: aload #6
    //   1088: astore #11
    //   1090: goto -> 1153
    //   1093: aload #6
    //   1095: astore #10
    //   1097: aload #6
    //   1099: ifnonnull -> 1117
    //   1102: new m0/f
    //   1105: dup
    //   1106: bipush #16
    //   1108: anewarray androidx/compose/ui/e$c
    //   1111: iconst_0
    //   1112: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1115: astore #10
    //   1117: aload #9
    //   1119: astore #6
    //   1121: aload #9
    //   1123: ifnull -> 1137
    //   1126: aload #10
    //   1128: aload #9
    //   1130: invokevirtual d : (Ljava/lang/Object;)Z
    //   1133: pop
    //   1134: aconst_null
    //   1135: astore #6
    //   1137: aload #10
    //   1139: aload #7
    //   1141: invokevirtual d : (Ljava/lang/Object;)Z
    //   1144: pop
    //   1145: aload #10
    //   1147: astore #11
    //   1149: aload #6
    //   1151: astore #10
    //   1153: aload #7
    //   1155: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   1158: astore #7
    //   1160: aload #10
    //   1162: astore #9
    //   1164: aload #11
    //   1166: astore #6
    //   1168: iload #4
    //   1170: istore_2
    //   1171: goto -> 1033
    //   1174: aload #6
    //   1176: astore #7
    //   1178: iload_2
    //   1179: iconst_1
    //   1180: if_icmpne -> 1186
    //   1183: goto -> 950
    //   1186: aload #7
    //   1188: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   1191: astore #9
    //   1193: aload #7
    //   1195: astore #6
    //   1197: goto -> 950
    //   1200: aload #12
    //   1202: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   1207: astore #9
    //   1209: aconst_null
    //   1210: astore #6
    //   1212: aload #9
    //   1214: ifnull -> 1462
    //   1217: aload #9
    //   1219: instanceof n1/a
    //   1222: ifeq -> 1245
    //   1225: aload #6
    //   1227: astore #7
    //   1229: aload #9
    //   1231: checkcast n1/a
    //   1234: aload_1
    //   1235: invokeinterface D : (Ln1/b;)Z
    //   1240: ifeq -> 1448
    //   1243: iconst_1
    //   1244: ireturn
    //   1245: aload #9
    //   1247: invokevirtual c1 : ()I
    //   1250: iload #5
    //   1252: iand
    //   1253: ifeq -> 1261
    //   1256: iconst_1
    //   1257: istore_2
    //   1258: goto -> 1263
    //   1261: iconst_0
    //   1262: istore_2
    //   1263: aload #6
    //   1265: astore #7
    //   1267: iload_2
    //   1268: ifeq -> 1448
    //   1271: aload #6
    //   1273: astore #7
    //   1275: aload #9
    //   1277: instanceof q1/l
    //   1280: ifeq -> 1448
    //   1283: aload #9
    //   1285: checkcast q1/l
    //   1288: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   1291: astore #7
    //   1293: iconst_0
    //   1294: istore_2
    //   1295: aload #7
    //   1297: ifnull -> 1436
    //   1300: aload #7
    //   1302: invokevirtual c1 : ()I
    //   1305: iload #5
    //   1307: iand
    //   1308: ifeq -> 1316
    //   1311: iconst_1
    //   1312: istore_3
    //   1313: goto -> 1318
    //   1316: iconst_0
    //   1317: istore_3
    //   1318: aload #9
    //   1320: astore #10
    //   1322: aload #6
    //   1324: astore #11
    //   1326: iload_2
    //   1327: istore #4
    //   1329: iload_3
    //   1330: ifeq -> 1415
    //   1333: iload_2
    //   1334: iconst_1
    //   1335: iadd
    //   1336: istore #4
    //   1338: iload #4
    //   1340: iconst_1
    //   1341: if_icmpne -> 1355
    //   1344: aload #7
    //   1346: astore #10
    //   1348: aload #6
    //   1350: astore #11
    //   1352: goto -> 1415
    //   1355: aload #6
    //   1357: astore #10
    //   1359: aload #6
    //   1361: ifnonnull -> 1379
    //   1364: new m0/f
    //   1367: dup
    //   1368: bipush #16
    //   1370: anewarray androidx/compose/ui/e$c
    //   1373: iconst_0
    //   1374: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1377: astore #10
    //   1379: aload #9
    //   1381: astore #6
    //   1383: aload #9
    //   1385: ifnull -> 1399
    //   1388: aload #10
    //   1390: aload #9
    //   1392: invokevirtual d : (Ljava/lang/Object;)Z
    //   1395: pop
    //   1396: aconst_null
    //   1397: astore #6
    //   1399: aload #10
    //   1401: aload #7
    //   1403: invokevirtual d : (Ljava/lang/Object;)Z
    //   1406: pop
    //   1407: aload #10
    //   1409: astore #11
    //   1411: aload #6
    //   1413: astore #10
    //   1415: aload #7
    //   1417: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   1420: astore #7
    //   1422: aload #10
    //   1424: astore #9
    //   1426: aload #11
    //   1428: astore #6
    //   1430: iload #4
    //   1432: istore_2
    //   1433: goto -> 1295
    //   1436: aload #6
    //   1438: astore #7
    //   1440: iload_2
    //   1441: iconst_1
    //   1442: if_icmpne -> 1448
    //   1445: goto -> 1212
    //   1448: aload #7
    //   1450: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   1453: astore #9
    //   1455: aload #7
    //   1457: astore #6
    //   1459: goto -> 1212
    //   1462: aload #8
    //   1464: ifnull -> 1524
    //   1467: aload #8
    //   1469: invokeinterface size : ()I
    //   1474: istore_3
    //   1475: iconst_0
    //   1476: istore_2
    //   1477: iload_2
    //   1478: iload_3
    //   1479: if_icmpge -> 1524
    //   1482: aload #8
    //   1484: iload_2
    //   1485: invokeinterface get : (I)Ljava/lang/Object;
    //   1490: checkcast n1/a
    //   1493: aload_1
    //   1494: invokeinterface D : (Ln1/b;)Z
    //   1499: ifeq -> 1504
    //   1502: iconst_1
    //   1503: ireturn
    //   1504: iload_2
    //   1505: iconst_1
    //   1506: iadd
    //   1507: istore_2
    //   1508: goto -> 1477
    //   1511: new java/lang/IllegalStateException
    //   1514: dup
    //   1515: ldc 'visitAncestors called on an unattached node'
    //   1517: invokevirtual toString : ()Ljava/lang/String;
    //   1520: invokespecial <init> : (Ljava/lang/String;)V
    //   1523: athrow
    //   1524: iconst_0
    //   1525: ireturn
  }
  
  public void e(k paramk) {
    q.j(paramk, "node");
    this.b.g(paramk);
  }
  
  public boolean f(int paramInt) {
    FocusTargetNode focusTargetNode = p.b(this.a);
    boolean bool = false;
    boolean bool1 = false;
    if (focusTargetNode == null)
      return false; 
    k k = p.a(focusTargetNode, paramInt, o());
    k.a a = k.b;
    if (k != a.b()) {
      boolean bool2 = bool1;
      if (k != a.a()) {
        bool2 = bool1;
        if (k.c())
          bool2 = true; 
      } 
      return bool2;
    } 
    d0 d0 = new d0();
    bool1 = p.e(this.a, paramInt, o(), new b(focusTargetNode, paramInt, d0));
    null = bool;
    if (!d0.s0) {
      if (!bool1) {
        null = bool;
        return r(paramInt) ? true : null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public boolean g(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: ldc_w 'keyEvent'
    //   4: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   7: aload_0
    //   8: getfield a : Landroidx/compose/ui/focus/FocusTargetNode;
    //   11: invokestatic b : (Landroidx/compose/ui/focus/FocusTargetNode;)Landroidx/compose/ui/focus/FocusTargetNode;
    //   14: astore #7
    //   16: aload #7
    //   18: ifnull -> 419
    //   21: ldc_w 131072
    //   24: invokestatic a : (I)I
    //   27: istore #5
    //   29: aload #7
    //   31: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   36: invokevirtual h1 : ()Z
    //   39: ifeq -> 406
    //   42: aload #7
    //   44: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   49: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   52: astore #6
    //   54: aload #7
    //   56: invokestatic k : (Lq1/j;)Lq1/j0;
    //   59: astore #11
    //   61: aload #11
    //   63: ifnull -> 393
    //   66: aload #11
    //   68: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   71: invokevirtual k : ()Landroidx/compose/ui/e$c;
    //   74: invokevirtual X0 : ()I
    //   77: iload #5
    //   79: iand
    //   80: ifeq -> 353
    //   83: aload #6
    //   85: astore #8
    //   87: aload #8
    //   89: ifnull -> 353
    //   92: aload #8
    //   94: invokevirtual c1 : ()I
    //   97: iload #5
    //   99: iand
    //   100: ifeq -> 343
    //   103: aconst_null
    //   104: astore #6
    //   106: aload #8
    //   108: astore #7
    //   110: aload #7
    //   112: ifnull -> 343
    //   115: aload #7
    //   117: instanceof j1/g
    //   120: ifeq -> 126
    //   123: goto -> 396
    //   126: aload #7
    //   128: invokevirtual c1 : ()I
    //   131: iload #5
    //   133: iand
    //   134: ifeq -> 142
    //   137: iconst_1
    //   138: istore_2
    //   139: goto -> 144
    //   142: iconst_0
    //   143: istore_2
    //   144: aload #6
    //   146: astore #9
    //   148: iload_2
    //   149: ifeq -> 329
    //   152: aload #6
    //   154: astore #9
    //   156: aload #7
    //   158: instanceof q1/l
    //   161: ifeq -> 329
    //   164: aload #7
    //   166: checkcast q1/l
    //   169: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   172: astore #9
    //   174: iconst_0
    //   175: istore_2
    //   176: aload #9
    //   178: ifnull -> 317
    //   181: aload #9
    //   183: invokevirtual c1 : ()I
    //   186: iload #5
    //   188: iand
    //   189: ifeq -> 197
    //   192: iconst_1
    //   193: istore_3
    //   194: goto -> 199
    //   197: iconst_0
    //   198: istore_3
    //   199: aload #7
    //   201: astore #10
    //   203: aload #6
    //   205: astore #12
    //   207: iload_2
    //   208: istore #4
    //   210: iload_3
    //   211: ifeq -> 296
    //   214: iload_2
    //   215: iconst_1
    //   216: iadd
    //   217: istore #4
    //   219: iload #4
    //   221: iconst_1
    //   222: if_icmpne -> 236
    //   225: aload #9
    //   227: astore #10
    //   229: aload #6
    //   231: astore #12
    //   233: goto -> 296
    //   236: aload #6
    //   238: astore #10
    //   240: aload #6
    //   242: ifnonnull -> 260
    //   245: new m0/f
    //   248: dup
    //   249: bipush #16
    //   251: anewarray androidx/compose/ui/e$c
    //   254: iconst_0
    //   255: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   258: astore #10
    //   260: aload #7
    //   262: astore #6
    //   264: aload #7
    //   266: ifnull -> 280
    //   269: aload #10
    //   271: aload #7
    //   273: invokevirtual d : (Ljava/lang/Object;)Z
    //   276: pop
    //   277: aconst_null
    //   278: astore #6
    //   280: aload #10
    //   282: aload #9
    //   284: invokevirtual d : (Ljava/lang/Object;)Z
    //   287: pop
    //   288: aload #10
    //   290: astore #12
    //   292: aload #6
    //   294: astore #10
    //   296: aload #9
    //   298: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   301: astore #9
    //   303: aload #10
    //   305: astore #7
    //   307: aload #12
    //   309: astore #6
    //   311: iload #4
    //   313: istore_2
    //   314: goto -> 176
    //   317: aload #6
    //   319: astore #9
    //   321: iload_2
    //   322: iconst_1
    //   323: if_icmpne -> 329
    //   326: goto -> 110
    //   329: aload #9
    //   331: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   334: astore #7
    //   336: aload #9
    //   338: astore #6
    //   340: goto -> 110
    //   343: aload #8
    //   345: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   348: astore #8
    //   350: goto -> 87
    //   353: aload #11
    //   355: invokevirtual k0 : ()Lq1/j0;
    //   358: astore #11
    //   360: aload #11
    //   362: ifnull -> 387
    //   365: aload #11
    //   367: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   370: astore #6
    //   372: aload #6
    //   374: ifnull -> 387
    //   377: aload #6
    //   379: invokevirtual o : ()Landroidx/compose/ui/e$c;
    //   382: astore #6
    //   384: goto -> 61
    //   387: aconst_null
    //   388: astore #6
    //   390: goto -> 61
    //   393: aconst_null
    //   394: astore #7
    //   396: aload #7
    //   398: checkcast j1/g
    //   401: astore #12
    //   403: goto -> 422
    //   406: new java/lang/IllegalStateException
    //   409: dup
    //   410: ldc 'visitAncestors called on an unattached node'
    //   412: invokevirtual toString : ()Ljava/lang/String;
    //   415: invokespecial <init> : (Ljava/lang/String;)V
    //   418: athrow
    //   419: aconst_null
    //   420: astore #12
    //   422: aload #12
    //   424: ifnull -> 1525
    //   427: ldc_w 131072
    //   430: invokestatic a : (I)I
    //   433: istore #5
    //   435: aload #12
    //   437: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   442: invokevirtual h1 : ()Z
    //   445: ifeq -> 1512
    //   448: aload #12
    //   450: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   455: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   458: astore #7
    //   460: aload #12
    //   462: invokestatic k : (Lq1/j;)Lq1/j0;
    //   465: astore #13
    //   467: aconst_null
    //   468: astore #8
    //   470: aload #13
    //   472: ifnull -> 882
    //   475: aload #8
    //   477: astore #9
    //   479: aload #13
    //   481: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   484: invokevirtual k : ()Landroidx/compose/ui/e$c;
    //   487: invokevirtual X0 : ()I
    //   490: iload #5
    //   492: iand
    //   493: ifeq -> 834
    //   496: aload #8
    //   498: astore #6
    //   500: aload #7
    //   502: astore #8
    //   504: aload #6
    //   506: astore #9
    //   508: aload #8
    //   510: ifnull -> 834
    //   513: aload #6
    //   515: astore #9
    //   517: aload #8
    //   519: invokevirtual c1 : ()I
    //   522: iload #5
    //   524: iand
    //   525: ifeq -> 820
    //   528: aload #8
    //   530: astore #10
    //   532: aconst_null
    //   533: astore #7
    //   535: aload #6
    //   537: astore #9
    //   539: aload #10
    //   541: ifnull -> 820
    //   544: aload #10
    //   546: instanceof j1/g
    //   549: ifeq -> 587
    //   552: aload #6
    //   554: astore #9
    //   556: aload #6
    //   558: ifnonnull -> 570
    //   561: new java/util/ArrayList
    //   564: dup
    //   565: invokespecial <init> : ()V
    //   568: astore #9
    //   570: aload #9
    //   572: aload #10
    //   574: invokeinterface add : (Ljava/lang/Object;)Z
    //   579: pop
    //   580: aload #7
    //   582: astore #11
    //   584: goto -> 802
    //   587: aload #10
    //   589: invokevirtual c1 : ()I
    //   592: iload #5
    //   594: iand
    //   595: ifeq -> 603
    //   598: iconst_1
    //   599: istore_2
    //   600: goto -> 605
    //   603: iconst_0
    //   604: istore_2
    //   605: aload #6
    //   607: astore #9
    //   609: aload #7
    //   611: astore #11
    //   613: iload_2
    //   614: ifeq -> 802
    //   617: aload #6
    //   619: astore #9
    //   621: aload #7
    //   623: astore #11
    //   625: aload #10
    //   627: instanceof q1/l
    //   630: ifeq -> 802
    //   633: aload #10
    //   635: checkcast q1/l
    //   638: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   641: astore #9
    //   643: iconst_0
    //   644: istore_2
    //   645: aload #9
    //   647: ifnull -> 786
    //   650: aload #9
    //   652: invokevirtual c1 : ()I
    //   655: iload #5
    //   657: iand
    //   658: ifeq -> 666
    //   661: iconst_1
    //   662: istore_3
    //   663: goto -> 668
    //   666: iconst_0
    //   667: istore_3
    //   668: aload #10
    //   670: astore #11
    //   672: aload #7
    //   674: astore #14
    //   676: iload_2
    //   677: istore #4
    //   679: iload_3
    //   680: ifeq -> 765
    //   683: iload_2
    //   684: iconst_1
    //   685: iadd
    //   686: istore #4
    //   688: iload #4
    //   690: iconst_1
    //   691: if_icmpne -> 705
    //   694: aload #9
    //   696: astore #11
    //   698: aload #7
    //   700: astore #14
    //   702: goto -> 765
    //   705: aload #7
    //   707: astore #11
    //   709: aload #7
    //   711: ifnonnull -> 729
    //   714: new m0/f
    //   717: dup
    //   718: bipush #16
    //   720: anewarray androidx/compose/ui/e$c
    //   723: iconst_0
    //   724: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   727: astore #11
    //   729: aload #10
    //   731: astore #7
    //   733: aload #10
    //   735: ifnull -> 749
    //   738: aload #11
    //   740: aload #10
    //   742: invokevirtual d : (Ljava/lang/Object;)Z
    //   745: pop
    //   746: aconst_null
    //   747: astore #7
    //   749: aload #11
    //   751: aload #9
    //   753: invokevirtual d : (Ljava/lang/Object;)Z
    //   756: pop
    //   757: aload #11
    //   759: astore #14
    //   761: aload #7
    //   763: astore #11
    //   765: aload #9
    //   767: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   770: astore #9
    //   772: aload #11
    //   774: astore #10
    //   776: aload #14
    //   778: astore #7
    //   780: iload #4
    //   782: istore_2
    //   783: goto -> 645
    //   786: aload #6
    //   788: astore #9
    //   790: aload #7
    //   792: astore #11
    //   794: iload_2
    //   795: iconst_1
    //   796: if_icmpne -> 802
    //   799: goto -> 535
    //   802: aload #11
    //   804: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   807: astore #10
    //   809: aload #9
    //   811: astore #6
    //   813: aload #11
    //   815: astore #7
    //   817: goto -> 535
    //   820: aload #8
    //   822: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   825: astore #8
    //   827: aload #9
    //   829: astore #6
    //   831: goto -> 504
    //   834: aload #13
    //   836: invokevirtual k0 : ()Lq1/j0;
    //   839: astore #13
    //   841: aload #13
    //   843: ifnull -> 872
    //   846: aload #13
    //   848: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   851: astore #6
    //   853: aload #6
    //   855: ifnull -> 872
    //   858: aload #6
    //   860: invokevirtual o : ()Landroidx/compose/ui/e$c;
    //   863: astore #7
    //   865: aload #9
    //   867: astore #8
    //   869: goto -> 470
    //   872: aconst_null
    //   873: astore #7
    //   875: aload #9
    //   877: astore #8
    //   879: goto -> 470
    //   882: aload #8
    //   884: ifnull -> 939
    //   887: aload #8
    //   889: invokeinterface size : ()I
    //   894: iconst_1
    //   895: isub
    //   896: istore_2
    //   897: iload_2
    //   898: iflt -> 939
    //   901: iload_2
    //   902: iconst_1
    //   903: isub
    //   904: istore_3
    //   905: aload #8
    //   907: iload_2
    //   908: invokeinterface get : (I)Ljava/lang/Object;
    //   913: checkcast j1/g
    //   916: aload_1
    //   917: invokeinterface A : (Landroid/view/KeyEvent;)Z
    //   922: ifeq -> 927
    //   925: iconst_1
    //   926: ireturn
    //   927: iload_3
    //   928: ifge -> 934
    //   931: goto -> 939
    //   934: iload_3
    //   935: istore_2
    //   936: goto -> 901
    //   939: aload #12
    //   941: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   946: astore #9
    //   948: aconst_null
    //   949: astore #6
    //   951: aload #9
    //   953: ifnull -> 1201
    //   956: aload #9
    //   958: instanceof j1/g
    //   961: ifeq -> 984
    //   964: aload #6
    //   966: astore #7
    //   968: aload #9
    //   970: checkcast j1/g
    //   973: aload_1
    //   974: invokeinterface A : (Landroid/view/KeyEvent;)Z
    //   979: ifeq -> 1187
    //   982: iconst_1
    //   983: ireturn
    //   984: aload #9
    //   986: invokevirtual c1 : ()I
    //   989: iload #5
    //   991: iand
    //   992: ifeq -> 1000
    //   995: iconst_1
    //   996: istore_2
    //   997: goto -> 1002
    //   1000: iconst_0
    //   1001: istore_2
    //   1002: aload #6
    //   1004: astore #7
    //   1006: iload_2
    //   1007: ifeq -> 1187
    //   1010: aload #6
    //   1012: astore #7
    //   1014: aload #9
    //   1016: instanceof q1/l
    //   1019: ifeq -> 1187
    //   1022: aload #9
    //   1024: checkcast q1/l
    //   1027: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   1030: astore #7
    //   1032: iconst_0
    //   1033: istore_2
    //   1034: aload #7
    //   1036: ifnull -> 1175
    //   1039: aload #7
    //   1041: invokevirtual c1 : ()I
    //   1044: iload #5
    //   1046: iand
    //   1047: ifeq -> 1055
    //   1050: iconst_1
    //   1051: istore_3
    //   1052: goto -> 1057
    //   1055: iconst_0
    //   1056: istore_3
    //   1057: aload #9
    //   1059: astore #10
    //   1061: aload #6
    //   1063: astore #11
    //   1065: iload_2
    //   1066: istore #4
    //   1068: iload_3
    //   1069: ifeq -> 1154
    //   1072: iload_2
    //   1073: iconst_1
    //   1074: iadd
    //   1075: istore #4
    //   1077: iload #4
    //   1079: iconst_1
    //   1080: if_icmpne -> 1094
    //   1083: aload #7
    //   1085: astore #10
    //   1087: aload #6
    //   1089: astore #11
    //   1091: goto -> 1154
    //   1094: aload #6
    //   1096: astore #10
    //   1098: aload #6
    //   1100: ifnonnull -> 1118
    //   1103: new m0/f
    //   1106: dup
    //   1107: bipush #16
    //   1109: anewarray androidx/compose/ui/e$c
    //   1112: iconst_0
    //   1113: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1116: astore #10
    //   1118: aload #9
    //   1120: astore #6
    //   1122: aload #9
    //   1124: ifnull -> 1138
    //   1127: aload #10
    //   1129: aload #9
    //   1131: invokevirtual d : (Ljava/lang/Object;)Z
    //   1134: pop
    //   1135: aconst_null
    //   1136: astore #6
    //   1138: aload #10
    //   1140: aload #7
    //   1142: invokevirtual d : (Ljava/lang/Object;)Z
    //   1145: pop
    //   1146: aload #10
    //   1148: astore #11
    //   1150: aload #6
    //   1152: astore #10
    //   1154: aload #7
    //   1156: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   1159: astore #7
    //   1161: aload #10
    //   1163: astore #9
    //   1165: aload #11
    //   1167: astore #6
    //   1169: iload #4
    //   1171: istore_2
    //   1172: goto -> 1034
    //   1175: aload #6
    //   1177: astore #7
    //   1179: iload_2
    //   1180: iconst_1
    //   1181: if_icmpne -> 1187
    //   1184: goto -> 951
    //   1187: aload #7
    //   1189: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   1192: astore #9
    //   1194: aload #7
    //   1196: astore #6
    //   1198: goto -> 951
    //   1201: aload #12
    //   1203: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   1208: astore #9
    //   1210: aconst_null
    //   1211: astore #6
    //   1213: aload #9
    //   1215: ifnull -> 1463
    //   1218: aload #9
    //   1220: instanceof j1/g
    //   1223: ifeq -> 1246
    //   1226: aload #6
    //   1228: astore #7
    //   1230: aload #9
    //   1232: checkcast j1/g
    //   1235: aload_1
    //   1236: invokeinterface N : (Landroid/view/KeyEvent;)Z
    //   1241: ifeq -> 1449
    //   1244: iconst_1
    //   1245: ireturn
    //   1246: aload #9
    //   1248: invokevirtual c1 : ()I
    //   1251: iload #5
    //   1253: iand
    //   1254: ifeq -> 1262
    //   1257: iconst_1
    //   1258: istore_2
    //   1259: goto -> 1264
    //   1262: iconst_0
    //   1263: istore_2
    //   1264: aload #6
    //   1266: astore #7
    //   1268: iload_2
    //   1269: ifeq -> 1449
    //   1272: aload #6
    //   1274: astore #7
    //   1276: aload #9
    //   1278: instanceof q1/l
    //   1281: ifeq -> 1449
    //   1284: aload #9
    //   1286: checkcast q1/l
    //   1289: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   1292: astore #7
    //   1294: iconst_0
    //   1295: istore_2
    //   1296: aload #7
    //   1298: ifnull -> 1437
    //   1301: aload #7
    //   1303: invokevirtual c1 : ()I
    //   1306: iload #5
    //   1308: iand
    //   1309: ifeq -> 1317
    //   1312: iconst_1
    //   1313: istore_3
    //   1314: goto -> 1319
    //   1317: iconst_0
    //   1318: istore_3
    //   1319: aload #9
    //   1321: astore #10
    //   1323: aload #6
    //   1325: astore #11
    //   1327: iload_2
    //   1328: istore #4
    //   1330: iload_3
    //   1331: ifeq -> 1416
    //   1334: iload_2
    //   1335: iconst_1
    //   1336: iadd
    //   1337: istore #4
    //   1339: iload #4
    //   1341: iconst_1
    //   1342: if_icmpne -> 1356
    //   1345: aload #7
    //   1347: astore #10
    //   1349: aload #6
    //   1351: astore #11
    //   1353: goto -> 1416
    //   1356: aload #6
    //   1358: astore #10
    //   1360: aload #6
    //   1362: ifnonnull -> 1380
    //   1365: new m0/f
    //   1368: dup
    //   1369: bipush #16
    //   1371: anewarray androidx/compose/ui/e$c
    //   1374: iconst_0
    //   1375: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1378: astore #10
    //   1380: aload #9
    //   1382: astore #6
    //   1384: aload #9
    //   1386: ifnull -> 1400
    //   1389: aload #10
    //   1391: aload #9
    //   1393: invokevirtual d : (Ljava/lang/Object;)Z
    //   1396: pop
    //   1397: aconst_null
    //   1398: astore #6
    //   1400: aload #10
    //   1402: aload #7
    //   1404: invokevirtual d : (Ljava/lang/Object;)Z
    //   1407: pop
    //   1408: aload #10
    //   1410: astore #11
    //   1412: aload #6
    //   1414: astore #10
    //   1416: aload #7
    //   1418: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   1421: astore #7
    //   1423: aload #10
    //   1425: astore #9
    //   1427: aload #11
    //   1429: astore #6
    //   1431: iload #4
    //   1433: istore_2
    //   1434: goto -> 1296
    //   1437: aload #6
    //   1439: astore #7
    //   1441: iload_2
    //   1442: iconst_1
    //   1443: if_icmpne -> 1449
    //   1446: goto -> 1213
    //   1449: aload #7
    //   1451: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   1454: astore #9
    //   1456: aload #7
    //   1458: astore #6
    //   1460: goto -> 1213
    //   1463: aload #8
    //   1465: ifnull -> 1525
    //   1468: aload #8
    //   1470: invokeinterface size : ()I
    //   1475: istore_3
    //   1476: iconst_0
    //   1477: istore_2
    //   1478: iload_2
    //   1479: iload_3
    //   1480: if_icmpge -> 1525
    //   1483: aload #8
    //   1485: iload_2
    //   1486: invokeinterface get : (I)Ljava/lang/Object;
    //   1491: checkcast j1/g
    //   1494: aload_1
    //   1495: invokeinterface N : (Landroid/view/KeyEvent;)Z
    //   1500: ifeq -> 1505
    //   1503: iconst_1
    //   1504: ireturn
    //   1505: iload_2
    //   1506: iconst_1
    //   1507: iadd
    //   1508: istore_2
    //   1509: goto -> 1478
    //   1512: new java/lang/IllegalStateException
    //   1515: dup
    //   1516: ldc 'visitAncestors called on an unattached node'
    //   1518: invokevirtual toString : ()Ljava/lang/String;
    //   1521: invokespecial <init> : (Ljava/lang/String;)V
    //   1524: athrow
    //   1525: iconst_0
    //   1526: ireturn
  }
  
  public void h(FocusTargetNode paramFocusTargetNode) {
    q.j(paramFocusTargetNode, "node");
    this.b.d(paramFocusTargetNode);
  }
  
  public e i() {
    return this.c;
  }
  
  public h j() {
    FocusTargetNode focusTargetNode = p.b(this.a);
    return (focusTargetNode != null) ? p.d(focusTargetNode) : null;
  }
  
  public void k() {
    o.c(this.a, true, true);
  }
  
  public void l(c paramc) {
    q.j(paramc, "node");
    this.b.f(paramc);
  }
  
  public void m(boolean paramBoolean) {
    c(paramBoolean, true);
  }
  
  public boolean n(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: ldc_w 'keyEvent'
    //   4: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   7: aload_0
    //   8: getfield a : Landroidx/compose/ui/focus/FocusTargetNode;
    //   11: invokestatic b : (Landroidx/compose/ui/focus/FocusTargetNode;)Landroidx/compose/ui/focus/FocusTargetNode;
    //   14: astore #7
    //   16: aload #7
    //   18: ifnull -> 1561
    //   21: aload_0
    //   22: aload #7
    //   24: invokespecial q : (Lq1/j;)Landroidx/compose/ui/e$c;
    //   27: astore #6
    //   29: aload #6
    //   31: astore #8
    //   33: aload #6
    //   35: ifnonnull -> 456
    //   38: sipush #8192
    //   41: invokestatic a : (I)I
    //   44: istore #5
    //   46: aload #7
    //   48: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   53: invokevirtual h1 : ()Z
    //   56: ifeq -> 443
    //   59: aload #7
    //   61: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   66: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   69: astore #6
    //   71: aload #7
    //   73: invokestatic k : (Lq1/j;)Lq1/j0;
    //   76: astore #11
    //   78: aload #11
    //   80: ifnull -> 410
    //   83: aload #11
    //   85: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   88: invokevirtual k : ()Landroidx/compose/ui/e$c;
    //   91: invokevirtual X0 : ()I
    //   94: iload #5
    //   96: iand
    //   97: ifeq -> 370
    //   100: aload #6
    //   102: astore #8
    //   104: aload #8
    //   106: ifnull -> 370
    //   109: aload #8
    //   111: invokevirtual c1 : ()I
    //   114: iload #5
    //   116: iand
    //   117: ifeq -> 360
    //   120: aconst_null
    //   121: astore #6
    //   123: aload #8
    //   125: astore #7
    //   127: aload #7
    //   129: ifnull -> 360
    //   132: aload #7
    //   134: instanceof j1/e
    //   137: ifeq -> 143
    //   140: goto -> 413
    //   143: aload #7
    //   145: invokevirtual c1 : ()I
    //   148: iload #5
    //   150: iand
    //   151: ifeq -> 159
    //   154: iconst_1
    //   155: istore_2
    //   156: goto -> 161
    //   159: iconst_0
    //   160: istore_2
    //   161: aload #6
    //   163: astore #9
    //   165: iload_2
    //   166: ifeq -> 346
    //   169: aload #6
    //   171: astore #9
    //   173: aload #7
    //   175: instanceof q1/l
    //   178: ifeq -> 346
    //   181: aload #7
    //   183: checkcast q1/l
    //   186: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   189: astore #9
    //   191: iconst_0
    //   192: istore_2
    //   193: aload #9
    //   195: ifnull -> 334
    //   198: aload #9
    //   200: invokevirtual c1 : ()I
    //   203: iload #5
    //   205: iand
    //   206: ifeq -> 214
    //   209: iconst_1
    //   210: istore_3
    //   211: goto -> 216
    //   214: iconst_0
    //   215: istore_3
    //   216: aload #7
    //   218: astore #10
    //   220: aload #6
    //   222: astore #12
    //   224: iload_2
    //   225: istore #4
    //   227: iload_3
    //   228: ifeq -> 313
    //   231: iload_2
    //   232: iconst_1
    //   233: iadd
    //   234: istore #4
    //   236: iload #4
    //   238: iconst_1
    //   239: if_icmpne -> 253
    //   242: aload #9
    //   244: astore #10
    //   246: aload #6
    //   248: astore #12
    //   250: goto -> 313
    //   253: aload #6
    //   255: astore #10
    //   257: aload #6
    //   259: ifnonnull -> 277
    //   262: new m0/f
    //   265: dup
    //   266: bipush #16
    //   268: anewarray androidx/compose/ui/e$c
    //   271: iconst_0
    //   272: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   275: astore #10
    //   277: aload #7
    //   279: astore #6
    //   281: aload #7
    //   283: ifnull -> 297
    //   286: aload #10
    //   288: aload #7
    //   290: invokevirtual d : (Ljava/lang/Object;)Z
    //   293: pop
    //   294: aconst_null
    //   295: astore #6
    //   297: aload #10
    //   299: aload #9
    //   301: invokevirtual d : (Ljava/lang/Object;)Z
    //   304: pop
    //   305: aload #10
    //   307: astore #12
    //   309: aload #6
    //   311: astore #10
    //   313: aload #9
    //   315: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   318: astore #9
    //   320: aload #10
    //   322: astore #7
    //   324: aload #12
    //   326: astore #6
    //   328: iload #4
    //   330: istore_2
    //   331: goto -> 193
    //   334: aload #6
    //   336: astore #9
    //   338: iload_2
    //   339: iconst_1
    //   340: if_icmpne -> 346
    //   343: goto -> 127
    //   346: aload #9
    //   348: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   351: astore #7
    //   353: aload #9
    //   355: astore #6
    //   357: goto -> 127
    //   360: aload #8
    //   362: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   365: astore #8
    //   367: goto -> 104
    //   370: aload #11
    //   372: invokevirtual k0 : ()Lq1/j0;
    //   375: astore #11
    //   377: aload #11
    //   379: ifnull -> 404
    //   382: aload #11
    //   384: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   387: astore #6
    //   389: aload #6
    //   391: ifnull -> 404
    //   394: aload #6
    //   396: invokevirtual o : ()Landroidx/compose/ui/e$c;
    //   399: astore #6
    //   401: goto -> 78
    //   404: aconst_null
    //   405: astore #6
    //   407: goto -> 78
    //   410: aconst_null
    //   411: astore #7
    //   413: aload #7
    //   415: checkcast j1/e
    //   418: astore #6
    //   420: aload #6
    //   422: ifnull -> 437
    //   425: aload #6
    //   427: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   432: astore #8
    //   434: goto -> 456
    //   437: aconst_null
    //   438: astore #8
    //   440: goto -> 456
    //   443: new java/lang/IllegalStateException
    //   446: dup
    //   447: ldc 'visitAncestors called on an unattached node'
    //   449: invokevirtual toString : ()Ljava/lang/String;
    //   452: invokespecial <init> : (Ljava/lang/String;)V
    //   455: athrow
    //   456: aload #8
    //   458: ifnull -> 1559
    //   461: sipush #8192
    //   464: invokestatic a : (I)I
    //   467: istore #5
    //   469: aload #8
    //   471: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   476: invokevirtual h1 : ()Z
    //   479: ifeq -> 1546
    //   482: aload #8
    //   484: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   489: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   492: astore #7
    //   494: aload #8
    //   496: invokestatic k : (Lq1/j;)Lq1/j0;
    //   499: astore #13
    //   501: aconst_null
    //   502: astore #9
    //   504: aload #13
    //   506: ifnull -> 916
    //   509: aload #9
    //   511: astore #10
    //   513: aload #13
    //   515: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   518: invokevirtual k : ()Landroidx/compose/ui/e$c;
    //   521: invokevirtual X0 : ()I
    //   524: iload #5
    //   526: iand
    //   527: ifeq -> 868
    //   530: aload #9
    //   532: astore #6
    //   534: aload #7
    //   536: astore #9
    //   538: aload #6
    //   540: astore #10
    //   542: aload #9
    //   544: ifnull -> 868
    //   547: aload #6
    //   549: astore #10
    //   551: aload #9
    //   553: invokevirtual c1 : ()I
    //   556: iload #5
    //   558: iand
    //   559: ifeq -> 854
    //   562: aload #9
    //   564: astore #11
    //   566: aconst_null
    //   567: astore #7
    //   569: aload #6
    //   571: astore #10
    //   573: aload #11
    //   575: ifnull -> 854
    //   578: aload #11
    //   580: instanceof j1/e
    //   583: ifeq -> 621
    //   586: aload #6
    //   588: astore #10
    //   590: aload #6
    //   592: ifnonnull -> 604
    //   595: new java/util/ArrayList
    //   598: dup
    //   599: invokespecial <init> : ()V
    //   602: astore #10
    //   604: aload #10
    //   606: aload #11
    //   608: invokeinterface add : (Ljava/lang/Object;)Z
    //   613: pop
    //   614: aload #7
    //   616: astore #12
    //   618: goto -> 836
    //   621: aload #11
    //   623: invokevirtual c1 : ()I
    //   626: iload #5
    //   628: iand
    //   629: ifeq -> 637
    //   632: iconst_1
    //   633: istore_2
    //   634: goto -> 639
    //   637: iconst_0
    //   638: istore_2
    //   639: aload #6
    //   641: astore #10
    //   643: aload #7
    //   645: astore #12
    //   647: iload_2
    //   648: ifeq -> 836
    //   651: aload #6
    //   653: astore #10
    //   655: aload #7
    //   657: astore #12
    //   659: aload #11
    //   661: instanceof q1/l
    //   664: ifeq -> 836
    //   667: aload #11
    //   669: checkcast q1/l
    //   672: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   675: astore #10
    //   677: iconst_0
    //   678: istore_2
    //   679: aload #10
    //   681: ifnull -> 820
    //   684: aload #10
    //   686: invokevirtual c1 : ()I
    //   689: iload #5
    //   691: iand
    //   692: ifeq -> 700
    //   695: iconst_1
    //   696: istore_3
    //   697: goto -> 702
    //   700: iconst_0
    //   701: istore_3
    //   702: aload #11
    //   704: astore #12
    //   706: aload #7
    //   708: astore #14
    //   710: iload_2
    //   711: istore #4
    //   713: iload_3
    //   714: ifeq -> 799
    //   717: iload_2
    //   718: iconst_1
    //   719: iadd
    //   720: istore #4
    //   722: iload #4
    //   724: iconst_1
    //   725: if_icmpne -> 739
    //   728: aload #10
    //   730: astore #12
    //   732: aload #7
    //   734: astore #14
    //   736: goto -> 799
    //   739: aload #7
    //   741: astore #12
    //   743: aload #7
    //   745: ifnonnull -> 763
    //   748: new m0/f
    //   751: dup
    //   752: bipush #16
    //   754: anewarray androidx/compose/ui/e$c
    //   757: iconst_0
    //   758: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   761: astore #12
    //   763: aload #11
    //   765: astore #7
    //   767: aload #11
    //   769: ifnull -> 783
    //   772: aload #12
    //   774: aload #11
    //   776: invokevirtual d : (Ljava/lang/Object;)Z
    //   779: pop
    //   780: aconst_null
    //   781: astore #7
    //   783: aload #12
    //   785: aload #10
    //   787: invokevirtual d : (Ljava/lang/Object;)Z
    //   790: pop
    //   791: aload #12
    //   793: astore #14
    //   795: aload #7
    //   797: astore #12
    //   799: aload #10
    //   801: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   804: astore #10
    //   806: aload #12
    //   808: astore #11
    //   810: aload #14
    //   812: astore #7
    //   814: iload #4
    //   816: istore_2
    //   817: goto -> 679
    //   820: aload #6
    //   822: astore #10
    //   824: aload #7
    //   826: astore #12
    //   828: iload_2
    //   829: iconst_1
    //   830: if_icmpne -> 836
    //   833: goto -> 569
    //   836: aload #12
    //   838: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   841: astore #11
    //   843: aload #10
    //   845: astore #6
    //   847: aload #12
    //   849: astore #7
    //   851: goto -> 569
    //   854: aload #9
    //   856: invokevirtual e1 : ()Landroidx/compose/ui/e$c;
    //   859: astore #9
    //   861: aload #10
    //   863: astore #6
    //   865: goto -> 538
    //   868: aload #13
    //   870: invokevirtual k0 : ()Lq1/j0;
    //   873: astore #13
    //   875: aload #13
    //   877: ifnull -> 906
    //   880: aload #13
    //   882: invokevirtual h0 : ()Landroidx/compose/ui/node/a;
    //   885: astore #6
    //   887: aload #6
    //   889: ifnull -> 906
    //   892: aload #6
    //   894: invokevirtual o : ()Landroidx/compose/ui/e$c;
    //   897: astore #7
    //   899: aload #10
    //   901: astore #9
    //   903: goto -> 504
    //   906: aconst_null
    //   907: astore #7
    //   909: aload #10
    //   911: astore #9
    //   913: goto -> 504
    //   916: aload #9
    //   918: ifnull -> 973
    //   921: aload #9
    //   923: invokeinterface size : ()I
    //   928: iconst_1
    //   929: isub
    //   930: istore_2
    //   931: iload_2
    //   932: iflt -> 973
    //   935: iload_2
    //   936: iconst_1
    //   937: isub
    //   938: istore_3
    //   939: aload #9
    //   941: iload_2
    //   942: invokeinterface get : (I)Ljava/lang/Object;
    //   947: checkcast j1/e
    //   950: aload_1
    //   951: invokeinterface e0 : (Landroid/view/KeyEvent;)Z
    //   956: ifeq -> 961
    //   959: iconst_1
    //   960: ireturn
    //   961: iload_3
    //   962: ifge -> 968
    //   965: goto -> 973
    //   968: iload_3
    //   969: istore_2
    //   970: goto -> 935
    //   973: aload #8
    //   975: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   980: astore #10
    //   982: aconst_null
    //   983: astore #6
    //   985: aload #10
    //   987: ifnull -> 1235
    //   990: aload #10
    //   992: instanceof j1/e
    //   995: ifeq -> 1018
    //   998: aload #6
    //   1000: astore #7
    //   1002: aload #10
    //   1004: checkcast j1/e
    //   1007: aload_1
    //   1008: invokeinterface e0 : (Landroid/view/KeyEvent;)Z
    //   1013: ifeq -> 1221
    //   1016: iconst_1
    //   1017: ireturn
    //   1018: aload #10
    //   1020: invokevirtual c1 : ()I
    //   1023: iload #5
    //   1025: iand
    //   1026: ifeq -> 1034
    //   1029: iconst_1
    //   1030: istore_2
    //   1031: goto -> 1036
    //   1034: iconst_0
    //   1035: istore_2
    //   1036: aload #6
    //   1038: astore #7
    //   1040: iload_2
    //   1041: ifeq -> 1221
    //   1044: aload #6
    //   1046: astore #7
    //   1048: aload #10
    //   1050: instanceof q1/l
    //   1053: ifeq -> 1221
    //   1056: aload #10
    //   1058: checkcast q1/l
    //   1061: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   1064: astore #7
    //   1066: iconst_0
    //   1067: istore_2
    //   1068: aload #7
    //   1070: ifnull -> 1209
    //   1073: aload #7
    //   1075: invokevirtual c1 : ()I
    //   1078: iload #5
    //   1080: iand
    //   1081: ifeq -> 1089
    //   1084: iconst_1
    //   1085: istore_3
    //   1086: goto -> 1091
    //   1089: iconst_0
    //   1090: istore_3
    //   1091: aload #10
    //   1093: astore #11
    //   1095: aload #6
    //   1097: astore #12
    //   1099: iload_2
    //   1100: istore #4
    //   1102: iload_3
    //   1103: ifeq -> 1188
    //   1106: iload_2
    //   1107: iconst_1
    //   1108: iadd
    //   1109: istore #4
    //   1111: iload #4
    //   1113: iconst_1
    //   1114: if_icmpne -> 1128
    //   1117: aload #7
    //   1119: astore #11
    //   1121: aload #6
    //   1123: astore #12
    //   1125: goto -> 1188
    //   1128: aload #6
    //   1130: astore #11
    //   1132: aload #6
    //   1134: ifnonnull -> 1152
    //   1137: new m0/f
    //   1140: dup
    //   1141: bipush #16
    //   1143: anewarray androidx/compose/ui/e$c
    //   1146: iconst_0
    //   1147: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1150: astore #11
    //   1152: aload #10
    //   1154: astore #6
    //   1156: aload #10
    //   1158: ifnull -> 1172
    //   1161: aload #11
    //   1163: aload #10
    //   1165: invokevirtual d : (Ljava/lang/Object;)Z
    //   1168: pop
    //   1169: aconst_null
    //   1170: astore #6
    //   1172: aload #11
    //   1174: aload #7
    //   1176: invokevirtual d : (Ljava/lang/Object;)Z
    //   1179: pop
    //   1180: aload #11
    //   1182: astore #12
    //   1184: aload #6
    //   1186: astore #11
    //   1188: aload #7
    //   1190: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   1193: astore #7
    //   1195: aload #11
    //   1197: astore #10
    //   1199: aload #12
    //   1201: astore #6
    //   1203: iload #4
    //   1205: istore_2
    //   1206: goto -> 1068
    //   1209: aload #6
    //   1211: astore #7
    //   1213: iload_2
    //   1214: iconst_1
    //   1215: if_icmpne -> 1221
    //   1218: goto -> 985
    //   1221: aload #7
    //   1223: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   1226: astore #10
    //   1228: aload #7
    //   1230: astore #6
    //   1232: goto -> 985
    //   1235: aload #8
    //   1237: invokeinterface Q : ()Landroidx/compose/ui/e$c;
    //   1242: astore #8
    //   1244: aconst_null
    //   1245: astore #6
    //   1247: aload #8
    //   1249: ifnull -> 1497
    //   1252: aload #8
    //   1254: instanceof j1/e
    //   1257: ifeq -> 1280
    //   1260: aload #6
    //   1262: astore #7
    //   1264: aload #8
    //   1266: checkcast j1/e
    //   1269: aload_1
    //   1270: invokeinterface p0 : (Landroid/view/KeyEvent;)Z
    //   1275: ifeq -> 1483
    //   1278: iconst_1
    //   1279: ireturn
    //   1280: aload #8
    //   1282: invokevirtual c1 : ()I
    //   1285: iload #5
    //   1287: iand
    //   1288: ifeq -> 1296
    //   1291: iconst_1
    //   1292: istore_2
    //   1293: goto -> 1298
    //   1296: iconst_0
    //   1297: istore_2
    //   1298: aload #6
    //   1300: astore #7
    //   1302: iload_2
    //   1303: ifeq -> 1483
    //   1306: aload #6
    //   1308: astore #7
    //   1310: aload #8
    //   1312: instanceof q1/l
    //   1315: ifeq -> 1483
    //   1318: aload #8
    //   1320: checkcast q1/l
    //   1323: invokevirtual B1 : ()Landroidx/compose/ui/e$c;
    //   1326: astore #7
    //   1328: iconst_0
    //   1329: istore_2
    //   1330: aload #7
    //   1332: ifnull -> 1471
    //   1335: aload #7
    //   1337: invokevirtual c1 : ()I
    //   1340: iload #5
    //   1342: iand
    //   1343: ifeq -> 1351
    //   1346: iconst_1
    //   1347: istore_3
    //   1348: goto -> 1353
    //   1351: iconst_0
    //   1352: istore_3
    //   1353: aload #8
    //   1355: astore #10
    //   1357: aload #6
    //   1359: astore #11
    //   1361: iload_2
    //   1362: istore #4
    //   1364: iload_3
    //   1365: ifeq -> 1450
    //   1368: iload_2
    //   1369: iconst_1
    //   1370: iadd
    //   1371: istore #4
    //   1373: iload #4
    //   1375: iconst_1
    //   1376: if_icmpne -> 1390
    //   1379: aload #7
    //   1381: astore #10
    //   1383: aload #6
    //   1385: astore #11
    //   1387: goto -> 1450
    //   1390: aload #6
    //   1392: astore #10
    //   1394: aload #6
    //   1396: ifnonnull -> 1414
    //   1399: new m0/f
    //   1402: dup
    //   1403: bipush #16
    //   1405: anewarray androidx/compose/ui/e$c
    //   1408: iconst_0
    //   1409: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1412: astore #10
    //   1414: aload #8
    //   1416: astore #6
    //   1418: aload #8
    //   1420: ifnull -> 1434
    //   1423: aload #10
    //   1425: aload #8
    //   1427: invokevirtual d : (Ljava/lang/Object;)Z
    //   1430: pop
    //   1431: aconst_null
    //   1432: astore #6
    //   1434: aload #10
    //   1436: aload #7
    //   1438: invokevirtual d : (Ljava/lang/Object;)Z
    //   1441: pop
    //   1442: aload #10
    //   1444: astore #11
    //   1446: aload #6
    //   1448: astore #10
    //   1450: aload #7
    //   1452: invokevirtual Y0 : ()Landroidx/compose/ui/e$c;
    //   1455: astore #7
    //   1457: aload #10
    //   1459: astore #8
    //   1461: aload #11
    //   1463: astore #6
    //   1465: iload #4
    //   1467: istore_2
    //   1468: goto -> 1330
    //   1471: aload #6
    //   1473: astore #7
    //   1475: iload_2
    //   1476: iconst_1
    //   1477: if_icmpne -> 1483
    //   1480: goto -> 1247
    //   1483: aload #7
    //   1485: invokestatic b : (Lm0/f;)Landroidx/compose/ui/e$c;
    //   1488: astore #8
    //   1490: aload #7
    //   1492: astore #6
    //   1494: goto -> 1247
    //   1497: aload #9
    //   1499: ifnull -> 1559
    //   1502: aload #9
    //   1504: invokeinterface size : ()I
    //   1509: istore_3
    //   1510: iconst_0
    //   1511: istore_2
    //   1512: iload_2
    //   1513: iload_3
    //   1514: if_icmpge -> 1559
    //   1517: aload #9
    //   1519: iload_2
    //   1520: invokeinterface get : (I)Ljava/lang/Object;
    //   1525: checkcast j1/e
    //   1528: aload_1
    //   1529: invokeinterface p0 : (Landroid/view/KeyEvent;)Z
    //   1534: ifeq -> 1539
    //   1537: iconst_1
    //   1538: ireturn
    //   1539: iload_2
    //   1540: iconst_1
    //   1541: iadd
    //   1542: istore_2
    //   1543: goto -> 1512
    //   1546: new java/lang/IllegalStateException
    //   1549: dup
    //   1550: ldc 'visitAncestors called on an unattached node'
    //   1552: invokevirtual toString : ()Ljava/lang/String;
    //   1555: invokespecial <init> : (Ljava/lang/String;)V
    //   1558: athrow
    //   1559: iconst_0
    //   1560: ireturn
    //   1561: new java/lang/IllegalStateException
    //   1564: dup
    //   1565: ldc_w 'Event can't be processed because we do not have an active focus target.'
    //   1568: invokevirtual toString : ()Ljava/lang/String;
    //   1571: invokespecial <init> : (Ljava/lang/String;)V
    //   1574: athrow
  }
  
  public r o() {
    r r1 = this.d;
    if (r1 != null)
      return r1; 
    q.B("layoutDirection");
    return null;
  }
  
  public final FocusTargetNode p() {
    return this.a;
  }
  
  static final class b extends r implements l<FocusTargetNode, Boolean> {
    b(FocusTargetNode param1FocusTargetNode, int param1Int, d0 param1d0) {
      super(1);
    }
    
    public final Boolean a(FocusTargetNode param1FocusTargetNode) {
      q.j(param1FocusTargetNode, "destination");
      if (q.e(param1FocusTargetNode, this.s0))
        return Boolean.FALSE; 
      int i = z0.a(1024);
      if (param1FocusTargetNode.Q().h1()) {
        boolean bool;
        e.c c2;
        e.c c1 = param1FocusTargetNode.Q().e1();
        j0 j0 = k.k((j)param1FocusTargetNode);
        label78: while (true) {
          c2 = null;
          bool = true;
          if (j0 != null) {
            if ((j0.h0().k().X0() & i) != 0)
              for (e.c c = c1; c != null; c = c.e1()) {
                if ((c.c1() & i) != 0) {
                  c2 = c;
                  c1 = null;
                  while (c2 != null) {
                    int j;
                    f f2;
                    if (c2 instanceof FocusTargetNode)
                      break label78; 
                    if ((c2.c1() & i) != 0) {
                      j = 1;
                    } else {
                      j = 0;
                    } 
                    e.c c3 = c1;
                    if (j) {
                      c3 = c1;
                      if (c2 instanceof l) {
                        f f;
                        c3 = ((l)c2).B1();
                        for (j = 0; c3 != null; j = k) {
                          boolean bool1;
                          f f3;
                          if ((c3.c1() & i) != 0) {
                            bool1 = true;
                          } else {
                            bool1 = false;
                          } 
                          e.c c4 = c2;
                          e.c c5 = c1;
                          int k = j;
                          if (bool1) {
                            k = j + 1;
                            if (k == 1) {
                              c4 = c3;
                              c5 = c1;
                            } else {
                              f f4;
                              c4 = c1;
                              if (c1 == null)
                                f4 = new f((Object[])new e.c[16], 0); 
                              c1 = c2;
                              if (c2 != null) {
                                f4.d(c2);
                                c1 = null;
                              } 
                              f4.d(c3);
                              f3 = f4;
                              c4 = c1;
                            } 
                          } 
                          c3 = c3.Y0();
                          c2 = c4;
                          f = f3;
                        } 
                        f2 = f;
                        if (j == 1)
                          continue; 
                      } 
                    } 
                    c2 = k.b(f2);
                    f f1 = f2;
                  } 
                } 
              }  
            j0 = j0.k0();
            if (j0 != null) {
              androidx.compose.ui.node.a a = j0.h0();
              if (a != null) {
                e.c c = a.o();
                continue;
              } 
            } 
            c1 = null;
            continue;
          } 
          break;
        } 
        if (c2 != null) {
          z0.a a = o.h(param1FocusTargetNode, this.t0);
          int j = a.a[a.ordinal()];
          boolean bool1 = bool;
          if (j != 1)
            if (j != 2 && j != 3) {
              if (j == 4) {
                bool1 = o.i(param1FocusTargetNode);
              } else {
                throw new NoWhenBranchMatchedException();
              } 
            } else {
              this.u0.s0 = true;
              bool1 = bool;
            }  
          return Boolean.valueOf(bool1);
        } 
        throw new IllegalStateException("Focus search landed at the root.".toString());
      } 
      throw new IllegalStateException("visitAncestors called on an unattached node".toString());
    }
  }
  
  public static final class FocusOwnerImpl$modifier$1 extends u0<FocusTargetNode> {
    FocusOwnerImpl$modifier$1(FocusOwnerImpl param1FocusOwnerImpl) {}
    
    public boolean equals(Object param1Object) {
      return (param1Object == this);
    }
    
    public int hashCode() {
      return this.c.p().hashCode();
    }
    
    public FocusTargetNode s() {
      return this.c.p();
    }
    
    public void t(FocusTargetNode param1FocusTargetNode) {
      q.j(param1FocusTargetNode, "node");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\focus\FocusOwnerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */