package androidx.compose.ui.draw;

import a1.l;
import a1.m;
import androidx.compose.ui.e;
import b1.q1;
import d1.c;
import dk.l;
import e1.d;
import k2.b;
import k2.c;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.e1;
import o1.f;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q1.e0;
import q1.q;
import q1.r;
import rj.v;
import w0.b;

final class e extends e.c implements e0, r {
  private d F0;
  
  private boolean G0;
  
  private b H0;
  
  private f I0;
  
  private float J0;
  
  private q1 K0;
  
  public e(d paramd, boolean paramBoolean, b paramb, f paramf, float paramFloat, q1 paramq1) {
    this.F0 = paramd;
    this.G0 = paramBoolean;
    this.H0 = paramb;
    this.I0 = paramf;
    this.J0 = paramFloat;
    this.K0 = paramq1;
  }
  
  private final long A1(long paramLong) {
    float f2;
    boolean bool1;
    if (!D1())
      return paramLong; 
    if (!F1(this.F0.h())) {
      f1 = l.i(paramLong);
    } else {
      f1 = l.i(this.F0.h());
    } 
    if (!E1(this.F0.h())) {
      f2 = l.g(paramLong);
    } else {
      f2 = l.g(this.F0.h());
    } 
    long l = m.a(f1, f2);
    float f1 = l.i(paramLong);
    boolean bool2 = true;
    if (f1 == 0.0F) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (!bool1) {
      if (l.g(paramLong) == 0.0F) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      if (!bool1)
        return e1.b(l, this.I0.a(l, paramLong)); 
    } 
    return l.b.b();
  }
  
  private final boolean D1() {
    boolean bool = this.G0;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      boolean bool3;
      if (this.F0.h() != l.b.a()) {
        bool3 = true;
      } else {
        bool3 = false;
      } 
      bool1 = bool2;
      if (bool3)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private final boolean E1(long paramLong) {
    boolean bool = l.f(paramLong, l.b.a());
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (!bool) {
      boolean bool3;
      float f1 = l.g(paramLong);
      if (!Float.isInfinite(f1) && !Float.isNaN(f1)) {
        bool3 = true;
      } else {
        bool3 = false;
      } 
      bool1 = bool2;
      if (bool3)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private final boolean F1(long paramLong) {
    boolean bool = l.f(paramLong, l.b.a());
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (!bool) {
      boolean bool3;
      float f1 = l.i(paramLong);
      if (!Float.isInfinite(f1) && !Float.isNaN(f1)) {
        bool3 = true;
      } else {
        bool3 = false;
      } 
      bool1 = bool2;
      if (bool3)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private final long G1(long paramLong) {
    boolean bool = b.j(paramLong);
    int j = 1;
    if (bool && b.i(paramLong)) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!b.l(paramLong) || !b.k(paramLong))
      j = 0; 
    if ((!D1() && i) || j)
      return b.e(paramLong, b.n(paramLong), 0, b.m(paramLong), 0, 10, null); 
    long l = this.F0.h();
    if (F1(l)) {
      i = fk.a.d(l.i(l));
    } else {
      i = b.p(paramLong);
    } 
    if (E1(l)) {
      j = fk.a.d(l.g(l));
    } else {
      j = b.o(paramLong);
    } 
    int i = c.g(paramLong, i);
    j = c.f(paramLong, j);
    l = A1(m.a(i, j));
    return b.e(paramLong, c.g(paramLong, fk.a.d(l.i(l))), 0, c.f(paramLong, fk.a.d(l.g(l))), 0, 10, null);
  }
  
  public final d B1() {
    return this.F0;
  }
  
  public final boolean C1() {
    return this.G0;
  }
  
  public final void H1(b paramb) {
    q.j(paramb, "<set-?>");
    this.H0 = paramb;
  }
  
  public final void I1(q1 paramq1) {
    this.K0 = paramq1;
  }
  
  public final void J1(f paramf) {
    q.j(paramf, "<set-?>");
    this.I0 = paramf;
  }
  
  public final void K1(d paramd) {
    q.j(paramd, "<set-?>");
    this.F0 = paramd;
  }
  
  public final void L1(boolean paramBoolean) {
    this.G0 = paramBoolean;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    y0 y0 = paramg0.Q(G1(paramLong));
    return k0.b(paraml0, y0.N0(), y0.p0(), null, new a(y0), 4, null);
  }
  
  public int d(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    if (D1()) {
      long l = G1(c.b(0, 0, 0, paramInt, 7, null));
      paramInt = paramm.N(paramInt);
      return Math.max(b.p(l), paramInt);
    } 
    return paramm.N(paramInt);
  }
  
  public boolean f1() {
    return false;
  }
  
  public final void g(float paramFloat) {
    this.J0 = paramFloat;
  }
  
  public int j(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    if (D1()) {
      long l = G1(c.b(0, paramInt, 0, 0, 13, null));
      paramInt = paramm.C(paramInt);
      return Math.max(b.o(l), paramInt);
    } 
    return paramm.C(paramInt);
  }
  
  public int o(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    if (D1()) {
      long l = G1(c.b(0, paramInt, 0, 0, 13, null));
      paramInt = paramm.d(paramInt);
      return Math.max(b.o(l), paramInt);
    } 
    return paramm.d(paramInt);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PainterModifier(painter=");
    stringBuilder.append(this.F0);
    stringBuilder.append(", sizeToIntrinsics=");
    stringBuilder.append(this.G0);
    stringBuilder.append(", alignment=");
    stringBuilder.append(this.H0);
    stringBuilder.append(", alpha=");
    stringBuilder.append(this.J0);
    stringBuilder.append(", colorFilter=");
    stringBuilder.append(this.K0);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public int u(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    if (D1()) {
      long l = G1(c.b(0, 0, 0, paramInt, 7, null));
      paramInt = paramm.K(paramInt);
      return Math.max(b.p(l), paramInt);
    } 
    return paramm.K(paramInt);
  }
  
  public void w(c paramc) {
    // Byte code:
    //   0: aload_1
    //   1: ldc '<this>'
    //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_0
    //   7: getfield F0 : Le1/d;
    //   10: invokevirtual h : ()J
    //   13: lstore #6
    //   15: aload_0
    //   16: lload #6
    //   18: invokespecial F1 : (J)Z
    //   21: ifeq -> 33
    //   24: lload #6
    //   26: invokestatic i : (J)F
    //   29: fstore_2
    //   30: goto -> 43
    //   33: aload_1
    //   34: invokeinterface b : ()J
    //   39: invokestatic i : (J)F
    //   42: fstore_2
    //   43: aload_0
    //   44: lload #6
    //   46: invokespecial E1 : (J)Z
    //   49: ifeq -> 61
    //   52: lload #6
    //   54: invokestatic g : (J)F
    //   57: fstore_3
    //   58: goto -> 71
    //   61: aload_1
    //   62: invokeinterface b : ()J
    //   67: invokestatic g : (J)F
    //   70: fstore_3
    //   71: fload_2
    //   72: fload_3
    //   73: invokestatic a : (FF)J
    //   76: lstore #6
    //   78: aload_1
    //   79: invokeinterface b : ()J
    //   84: invokestatic i : (J)F
    //   87: fstore_2
    //   88: iconst_1
    //   89: istore #5
    //   91: fload_2
    //   92: fconst_0
    //   93: fcmpg
    //   94: ifne -> 103
    //   97: iconst_1
    //   98: istore #4
    //   100: goto -> 106
    //   103: iconst_0
    //   104: istore #4
    //   106: iload #4
    //   108: ifne -> 167
    //   111: aload_1
    //   112: invokeinterface b : ()J
    //   117: invokestatic g : (J)F
    //   120: fconst_0
    //   121: fcmpg
    //   122: ifne -> 132
    //   125: iload #5
    //   127: istore #4
    //   129: goto -> 135
    //   132: iconst_0
    //   133: istore #4
    //   135: iload #4
    //   137: ifne -> 167
    //   140: lload #6
    //   142: aload_0
    //   143: getfield I0 : Lo1/f;
    //   146: lload #6
    //   148: aload_1
    //   149: invokeinterface b : ()J
    //   154: invokeinterface a : (JJ)J
    //   159: invokestatic b : (JJ)J
    //   162: lstore #6
    //   164: goto -> 175
    //   167: getstatic a1/l.b : La1/l$a;
    //   170: invokevirtual b : ()J
    //   173: lstore #6
    //   175: aload_0
    //   176: getfield H0 : Lw0/b;
    //   179: lload #6
    //   181: invokestatic i : (J)F
    //   184: invokestatic d : (F)I
    //   187: lload #6
    //   189: invokestatic g : (J)F
    //   192: invokestatic d : (F)I
    //   195: invokestatic a : (II)J
    //   198: aload_1
    //   199: invokeinterface b : ()J
    //   204: invokestatic i : (J)F
    //   207: invokestatic d : (F)I
    //   210: aload_1
    //   211: invokeinterface b : ()J
    //   216: invokestatic g : (J)F
    //   219: invokestatic d : (F)I
    //   222: invokestatic a : (II)J
    //   225: aload_1
    //   226: invokeinterface getLayoutDirection : ()Lk2/r;
    //   231: invokeinterface a : (JJLk2/r;)J
    //   236: lstore #8
    //   238: lload #8
    //   240: invokestatic j : (J)I
    //   243: i2f
    //   244: fstore_2
    //   245: lload #8
    //   247: invokestatic k : (J)I
    //   250: i2f
    //   251: fstore_3
    //   252: aload_1
    //   253: invokeinterface G0 : ()Ld1/d;
    //   258: invokeinterface a : ()Ld1/i;
    //   263: fload_2
    //   264: fload_3
    //   265: invokeinterface b : (FF)V
    //   270: aload_0
    //   271: getfield F0 : Le1/d;
    //   274: aload_1
    //   275: lload #6
    //   277: aload_0
    //   278: getfield J0 : F
    //   281: aload_0
    //   282: getfield K0 : Lb1/q1;
    //   285: invokevirtual g : (Ld1/f;JFLb1/q1;)V
    //   288: aload_1
    //   289: invokeinterface G0 : ()Ld1/d;
    //   294: invokeinterface a : ()Ld1/i;
    //   299: fload_2
    //   300: fneg
    //   301: fload_3
    //   302: fneg
    //   303: invokeinterface b : (FF)V
    //   308: aload_1
    //   309: invokeinterface V0 : ()V
    //   314: return
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(y0 param1y0) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      y0.a.r(param1a, this.s0, 0, 0, 0.0F, 4, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\draw\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */