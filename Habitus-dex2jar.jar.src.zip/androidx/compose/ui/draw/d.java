package androidx.compose.ui.draw;

import androidx.compose.ui.e;
import b1.q1;
import kotlin.jvm.internal.q;
import o1.f;
import w0.b;

public final class d {
  public static final e a(e parame, e1.d paramd, boolean paramBoolean, b paramb, f paramf, float paramFloat, q1 paramq1) {
    q.j(parame, "<this>");
    q.j(paramd, "painter");
    q.j(paramb, "alignment");
    q.j(paramf, "contentScale");
    return parame.then((e)new PainterElement(paramd, paramBoolean, paramb, paramf, paramFloat, paramq1));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\draw\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */