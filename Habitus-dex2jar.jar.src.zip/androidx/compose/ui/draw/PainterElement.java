package androidx.compose.ui.draw;

import a1.l;
import androidx.compose.ui.e;
import b1.q1;
import e1.d;
import kotlin.jvm.internal.q;
import o1.f;
import q1.h0;
import q1.s;
import q1.u0;
import w0.b;

final class PainterElement extends u0<e> {
  private final d c;
  
  private final boolean d;
  
  private final b e;
  
  private final f f;
  
  private final float g;
  
  private final q1 h;
  
  public PainterElement(d paramd, boolean paramBoolean, b paramb, f paramf, float paramFloat, q1 paramq1) {
    this.c = paramd;
    this.d = paramBoolean;
    this.e = paramb;
    this.f = paramf;
    this.g = paramFloat;
    this.h = paramq1;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof PainterElement))
      return false; 
    paramObject = paramObject;
    return !q.e(this.c, ((PainterElement)paramObject).c) ? false : ((this.d != ((PainterElement)paramObject).d) ? false : (!q.e(this.e, ((PainterElement)paramObject).e) ? false : (!q.e(this.f, ((PainterElement)paramObject).f) ? false : ((Float.compare(this.g, ((PainterElement)paramObject).g) != 0) ? false : (!!q.e(this.h, ((PainterElement)paramObject).h))))));
  }
  
  public int hashCode() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public e s() {
    return new e(this.c, this.d, this.e, this.f, this.g, this.h);
  }
  
  public void t(e parame) {
    boolean bool;
    q.j(parame, "node");
    boolean bool1 = parame.C1();
    boolean bool2 = this.d;
    if (bool1 != bool2 || (bool2 && !l.f(parame.B1().h(), this.c.h()))) {
      bool = true;
    } else {
      bool = false;
    } 
    parame.K1(this.c);
    parame.L1(this.d);
    parame.H1(this.e);
    parame.J1(this.f);
    parame.g(this.g);
    parame.I1(this.h);
    if (bool)
      h0.b(parame); 
    s.a(parame);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PainterElement(painter=");
    stringBuilder.append(this.c);
    stringBuilder.append(", sizeToIntrinsics=");
    stringBuilder.append(this.d);
    stringBuilder.append(", alignment=");
    stringBuilder.append(this.e);
    stringBuilder.append(", contentScale=");
    stringBuilder.append(this.f);
    stringBuilder.append(", alpha=");
    stringBuilder.append(this.g);
    stringBuilder.append(", colorFilter=");
    stringBuilder.append(this.h);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\draw\PainterElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */