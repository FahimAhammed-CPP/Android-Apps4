package androidx.compose.ui.draw;

import androidx.compose.ui.e;
import d1.f;
import dk.l;
import kotlin.jvm.internal.q;
import q1.u0;
import rj.v;
import y0.f;

final class DrawBehindElement extends u0<f> {
  private final l<f, v> c;
  
  public DrawBehindElement(l<? super f, v> paraml) {
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof DrawBehindElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((DrawBehindElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public f s() {
    return new f(this.c);
  }
  
  public void t(f paramf) {
    q.j(paramf, "node");
    paramf.A1(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DrawBehindElement(onDraw=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\draw\DrawBehindElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */