package androidx.compose.ui.draw;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import q1.u0;
import y0.d;
import y0.i;

final class DrawWithCacheElement extends u0<a> {
  private final l<d, i> c;
  
  public DrawWithCacheElement(l<? super d, i> paraml) {
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof DrawWithCacheElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((DrawWithCacheElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public a s() {
    return new a(new d(), this.c);
  }
  
  public void t(a parama) {
    q.j(parama, "node");
    parama.C1(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DrawWithCacheElement(onBuildDrawCache=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\draw\DrawWithCacheElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */