package androidx.compose.ui.draw;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import q1.q;
import q1.r;
import rj.v;

final class c extends e.c implements r {
  private l<? super d1.c, v> F0;
  
  public c(l<? super d1.c, v> paraml) {
    this.F0 = paraml;
  }
  
  public final void A1(l<? super d1.c, v> paraml) {
    q.j(paraml, "<set-?>");
    this.F0 = paraml;
  }
  
  public void w(d1.c paramc) {
    q.j(paramc, "<this>");
    this.F0.invoke(paramc);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\draw\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */