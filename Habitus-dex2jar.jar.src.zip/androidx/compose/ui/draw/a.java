package androidx.compose.ui.draw;

import androidx.compose.ui.e;
import d1.c;
import dk.l;
import k2.e;
import k2.q;
import k2.r;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import q1.c1;
import q1.d1;
import q1.j;
import q1.k;
import q1.r;
import q1.s;
import q1.z0;
import rj.v;
import y0.b;
import y0.c;
import y0.d;
import y0.i;

final class a extends e.c implements c, c1, b {
  private final d F0;
  
  private boolean G0;
  
  private l<? super d, i> H0;
  
  public a(d paramd, l<? super d, i> paraml) {
    this.F0 = paramd;
    this.H0 = paraml;
    paramd.e(this);
  }
  
  private final i B1() {
    if (!this.G0) {
      d d1 = this.F0;
      d1.f(null);
      d1.a(this, new a(this, d1));
      if (d1.c() != null) {
        this.G0 = true;
      } else {
        throw new IllegalStateException("DrawResult not defined, did you forget to call onDraw?".toString());
      } 
    } 
    i i = this.F0.c();
    q.g(i);
    return i;
  }
  
  public final l<d, i> A1() {
    return (l)this.H0;
  }
  
  public final void C1(l<? super d, i> paraml) {
    q.j(paraml, "value");
    this.H0 = paraml;
    j0();
  }
  
  public void U() {
    j0();
  }
  
  public long b() {
    return q.c(k.h((j)this, z0.a(128)).a());
  }
  
  public e getDensity() {
    return k.i((j)this);
  }
  
  public r getLayoutDirection() {
    return k.j((j)this);
  }
  
  public void j0() {
    this.G0 = false;
    this.F0.f(null);
    s.a((r)this);
  }
  
  public void t0() {
    j0();
  }
  
  public void w(c paramc) {
    q.j(paramc, "<this>");
    B1().a().invoke(paramc);
  }
  
  static final class a extends r implements dk.a<v> {
    a(a param1a, d param1d) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.A1().invoke(this.t0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\draw\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */