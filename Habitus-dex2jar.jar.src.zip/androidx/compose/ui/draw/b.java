package androidx.compose.ui.draw;

import androidx.compose.ui.e;
import d1.c;
import d1.f;
import dk.l;
import kotlin.jvm.internal.q;
import rj.v;
import y0.c;
import y0.d;
import y0.i;

public final class b {
  public static final c a(l<? super d, i> paraml) {
    q.j(paraml, "onBuildDrawCache");
    return new a(new d(), paraml);
  }
  
  public static final e b(e parame, l<? super f, v> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "onDraw");
    return parame.then((e)new DrawBehindElement(paraml));
  }
  
  public static final e c(e parame, l<? super d, i> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "onBuildDrawCache");
    return parame.then((e)new DrawWithCacheElement(paraml));
  }
  
  public static final e d(e parame, l<? super c, v> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "onDraw");
    return parame.then((e)new DrawWithContentElement(paraml));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\draw\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */