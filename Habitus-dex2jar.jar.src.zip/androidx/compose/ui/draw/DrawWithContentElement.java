package androidx.compose.ui.draw;

import androidx.compose.ui.e;
import d1.c;
import dk.l;
import kotlin.jvm.internal.q;
import q1.u0;
import rj.v;

final class DrawWithContentElement extends u0<c> {
  private final l<c, v> c;
  
  public DrawWithContentElement(l<? super c, v> paraml) {
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof DrawWithContentElement))
      return false; 
    paramObject = paramObject;
    return !!q.e(this.c, ((DrawWithContentElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public c s() {
    return new c(this.c);
  }
  
  public void t(c paramc) {
    q.j(paramc, "node");
    paramc.A1(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DrawWithContentElement(onDraw=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compos\\ui\draw\DrawWithContentElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */