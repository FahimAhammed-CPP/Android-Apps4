package androidx.compose.foundation;

import androidx.compose.ui.e;
import dk.p;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import l1.r;
import l1.t;
import l1.u;
import q1.n1;
import q1.o1;
import rj.n;
import rj.v;
import t.g;
import t.h;
import t.j;
import t.m;

final class s extends e.c implements o1 {
  private m F0;
  
  private g G0;
  
  public s(m paramm) {
    this.F0 = paramm;
  }
  
  public final Object A1(vj.d<? super v> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/compose/foundation/s$a
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast androidx/compose/foundation/s$a
    //   11: astore_3
    //   12: aload_3
    //   13: getfield w0 : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 37
    //   24: aload_3
    //   25: iload_2
    //   26: ldc -2147483648
    //   28: iadd
    //   29: putfield w0 : I
    //   32: aload_3
    //   33: astore_1
    //   34: goto -> 47
    //   37: new androidx/compose/foundation/s$a
    //   40: dup
    //   41: aload_0
    //   42: aload_1
    //   43: invokespecial <init> : (Landroidx/compose/foundation/s;Lvj/d;)V
    //   46: astore_1
    //   47: aload_1
    //   48: getfield u0 : Ljava/lang/Object;
    //   51: astore #4
    //   53: invokestatic d : ()Ljava/lang/Object;
    //   56: astore #5
    //   58: aload_1
    //   59: getfield w0 : I
    //   62: istore_2
    //   63: iload_2
    //   64: ifeq -> 106
    //   67: iload_2
    //   68: iconst_1
    //   69: if_icmpne -> 96
    //   72: aload_1
    //   73: getfield t0 : Ljava/lang/Object;
    //   76: checkcast t/g
    //   79: astore_3
    //   80: aload_1
    //   81: getfield s0 : Ljava/lang/Object;
    //   84: checkcast androidx/compose/foundation/s
    //   87: astore_1
    //   88: aload #4
    //   90: invokestatic b : (Ljava/lang/Object;)V
    //   93: goto -> 166
    //   96: new java/lang/IllegalStateException
    //   99: dup
    //   100: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   102: invokespecial <init> : (Ljava/lang/String;)V
    //   105: athrow
    //   106: aload #4
    //   108: invokestatic b : (Ljava/lang/Object;)V
    //   111: aload_0
    //   112: getfield G0 : Lt/g;
    //   115: ifnonnull -> 171
    //   118: new t/g
    //   121: dup
    //   122: invokespecial <init> : ()V
    //   125: astore_3
    //   126: aload_0
    //   127: getfield F0 : Lt/m;
    //   130: astore #4
    //   132: aload_1
    //   133: aload_0
    //   134: putfield s0 : Ljava/lang/Object;
    //   137: aload_1
    //   138: aload_3
    //   139: putfield t0 : Ljava/lang/Object;
    //   142: aload_1
    //   143: iconst_1
    //   144: putfield w0 : I
    //   147: aload #4
    //   149: aload_3
    //   150: aload_1
    //   151: invokeinterface c : (Lt/j;Lvj/d;)Ljava/lang/Object;
    //   156: aload #5
    //   158: if_acmpne -> 164
    //   161: aload #5
    //   163: areturn
    //   164: aload_0
    //   165: astore_1
    //   166: aload_1
    //   167: aload_3
    //   168: putfield G0 : Lt/g;
    //   171: getstatic rj/v.a : Lrj/v;
    //   174: areturn
  }
  
  public final Object B1(vj.d<? super v> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/compose/foundation/s$b
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast androidx/compose/foundation/s$b
    //   11: astore_3
    //   12: aload_3
    //   13: getfield v0 : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 37
    //   24: aload_3
    //   25: iload_2
    //   26: ldc -2147483648
    //   28: iadd
    //   29: putfield v0 : I
    //   32: aload_3
    //   33: astore_1
    //   34: goto -> 47
    //   37: new androidx/compose/foundation/s$b
    //   40: dup
    //   41: aload_0
    //   42: aload_1
    //   43: invokespecial <init> : (Landroidx/compose/foundation/s;Lvj/d;)V
    //   46: astore_1
    //   47: aload_1
    //   48: getfield t0 : Ljava/lang/Object;
    //   51: astore #4
    //   53: invokestatic d : ()Ljava/lang/Object;
    //   56: astore_3
    //   57: aload_1
    //   58: getfield v0 : I
    //   61: istore_2
    //   62: iload_2
    //   63: ifeq -> 97
    //   66: iload_2
    //   67: iconst_1
    //   68: if_icmpne -> 87
    //   71: aload_1
    //   72: getfield s0 : Ljava/lang/Object;
    //   75: checkcast androidx/compose/foundation/s
    //   78: astore_1
    //   79: aload #4
    //   81: invokestatic b : (Ljava/lang/Object;)V
    //   84: goto -> 158
    //   87: new java/lang/IllegalStateException
    //   90: dup
    //   91: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   93: invokespecial <init> : (Ljava/lang/String;)V
    //   96: athrow
    //   97: aload #4
    //   99: invokestatic b : (Ljava/lang/Object;)V
    //   102: aload_0
    //   103: getfield G0 : Lt/g;
    //   106: astore #4
    //   108: aload #4
    //   110: ifnull -> 163
    //   113: new t/h
    //   116: dup
    //   117: aload #4
    //   119: invokespecial <init> : (Lt/g;)V
    //   122: astore #4
    //   124: aload_0
    //   125: getfield F0 : Lt/m;
    //   128: astore #5
    //   130: aload_1
    //   131: aload_0
    //   132: putfield s0 : Ljava/lang/Object;
    //   135: aload_1
    //   136: iconst_1
    //   137: putfield v0 : I
    //   140: aload #5
    //   142: aload #4
    //   144: aload_1
    //   145: invokeinterface c : (Lt/j;Lvj/d;)Ljava/lang/Object;
    //   150: aload_3
    //   151: if_acmpne -> 156
    //   154: aload_3
    //   155: areturn
    //   156: aload_0
    //   157: astore_1
    //   158: aload_1
    //   159: aconst_null
    //   160: putfield G0 : Lt/g;
    //   163: getstatic rj/v.a : Lrj/v;
    //   166: areturn
  }
  
  public void C(r paramr, t paramt, long paramLong) {
    q.j(paramr, "pointerEvent");
    q.j(paramt, "pass");
    if (paramt == t.t0) {
      int i = paramr.f();
      u.a a = u.a;
      if (u.i(i, a.a())) {
        BuildersKt.launch$default(a1(), null, null, new c(this, null), 3, null);
        return;
      } 
      if (u.i(i, a.b()))
        BuildersKt.launch$default(a1(), null, null, new d(this, null), 3, null); 
    } 
  }
  
  public final void C1() {
    g g1 = this.G0;
    if (g1 != null) {
      h h = new h(g1);
      this.F0.a((j)h);
      this.G0 = null;
    } 
  }
  
  public final void D1(m paramm) {
    q.j(paramm, "interactionSource");
    if (!q.e(this.F0, paramm)) {
      C1();
      this.F0 = paramm;
    } 
  }
  
  public void l1() {
    C1();
  }
  
  public void q0() {
    C1();
  }
  
  @f(c = "androidx.compose.foundation.HoverableNode", f = "Hoverable.kt", l = {108}, m = "emitEnter")
  static final class a extends kotlin.coroutines.jvm.internal.d {
    Object s0;
    
    Object t0;
    
    int w0;
    
    a(s param1s, vj.d<? super a> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.u0 = param1Object;
      this.w0 |= Integer.MIN_VALUE;
      return this.v0.A1((vj.d<? super v>)this);
    }
  }
  
  @f(c = "androidx.compose.foundation.HoverableNode", f = "Hoverable.kt", l = {116}, m = "emitExit")
  static final class b extends kotlin.coroutines.jvm.internal.d {
    Object s0;
    
    int v0;
    
    b(s param1s, vj.d<? super b> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.t0 = param1Object;
      this.v0 |= Integer.MIN_VALUE;
      return this.u0.B1((vj.d<? super v>)this);
    }
  }
  
  @f(c = "androidx.compose.foundation.HoverableNode$onPointerEvent$1", f = "Hoverable.kt", l = {91}, m = "invokeSuspend")
  static final class c extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
    int s0;
    
    c(s param1s, vj.d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      return (vj.d<v>)new c(this.t0, (vj.d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, vj.d<? super v> param1d) {
      return ((c)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0;
        this.s0 = 1;
        if (param1Object.A1((vj.d<? super v>)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
  
  @f(c = "androidx.compose.foundation.HoverableNode$onPointerEvent$2", f = "Hoverable.kt", l = {92}, m = "invokeSuspend")
  static final class d extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
    int s0;
    
    d(s param1s, vj.d<? super d> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      return (vj.d<v>)new d(this.t0, (vj.d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, vj.d<? super v> param1d) {
      return ((d)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0;
        this.s0 = 1;
        if (param1Object.B1((vj.d<? super v>)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */