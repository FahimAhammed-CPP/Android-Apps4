package androidx.compose.foundation;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import o1.s;
import q1.u0;
import rj.v;

final class FocusedBoundsObserverElement extends u0<q> {
  private final l<s, v> c;
  
  public FocusedBoundsObserverElement(l<? super s, v> paraml) {
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof FocusedBoundsObserverElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? false : q.e(this.c, ((FocusedBoundsObserverElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public q s() {
    return new q(this.c);
  }
  
  public void t(q paramq) {
    q.j(paramq, "node");
    paramq.C1(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\FocusedBoundsObserverElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */