package androidx.compose.foundation;

import androidx.compose.ui.e;
import androidx.compose.ui.focus.g;
import androidx.compose.ui.platform.y0;
import i1.a;
import i1.b;
import kotlin.jvm.internal.q;
import l0.t;
import q1.h;
import q1.i;
import z0.k;

final class k extends e.c implements h, k {
  private final b A1() {
    return (b)i.a(this, (t)y0.i());
  }
  
  public void n0(g paramg) {
    q.j(paramg, "focusProperties");
    paramg.o(a.f(A1().a(), a.b.b()) ^ true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */