package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import dk.l;
import k2.h;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import o1.a;
import q1.u0;
import rj.v;

final class AlignmentLineOffsetDpElement extends u0<b> {
  private final a c;
  
  private final float d;
  
  private final float e;
  
  private final l<l1, v> f;
  
  private AlignmentLineOffsetDpElement(a parama, float paramFloat1, float paramFloat2, l<? super l1, v> paraml) {
    boolean bool;
    this.c = parama;
    this.d = paramFloat1;
    this.e = paramFloat2;
    this.f = (l)paraml;
    if ((paramFloat1 >= 0.0F || h.m(paramFloat1, h.t0.b())) && (paramFloat2 >= 0.0F || h.m(paramFloat2, h.t0.b()))) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    throw new IllegalArgumentException("Padding from alignment line must be a non-negative number".toString());
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof AlignmentLineOffsetDpElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? false : ((q.e(this.c, ((AlignmentLineOffsetDpElement)paramObject).c) && h.m(this.d, ((AlignmentLineOffsetDpElement)paramObject).d) && h.m(this.e, ((AlignmentLineOffsetDpElement)paramObject).e)));
  }
  
  public int hashCode() {
    return (this.c.hashCode() * 31 + h.o(this.d)) * 31 + h.o(this.e);
  }
  
  public b s() {
    return new b(this.c, this.d, this.e, null);
  }
  
  public void t(b paramb) {
    q.j(paramb, "node");
    paramb.B1(this.c);
    paramb.C1(this.d);
    paramb.A1(this.e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\AlignmentLineOffsetDpElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */