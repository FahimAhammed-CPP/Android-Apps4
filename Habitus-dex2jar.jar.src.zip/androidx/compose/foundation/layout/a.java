package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.j1;
import androidx.compose.ui.platform.l1;
import dk.l;
import ik.j;
import k2.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.y0;
import rj.v;

public final class a {
  private static final j0 c(l0 paraml0, o1.a parama, float paramFloat1, float paramFloat2, g0 paramg0, long paramLong) {
    int j;
    long l;
    if (d(parama)) {
      l = k2.b.e(paramLong, 0, 0, 0, 0, 11, null);
    } else {
      l = k2.b.e(paramLong, 0, 0, 0, 0, 14, null);
    } 
    y0 y0 = paramg0.Q(l);
    int i = y0.w(parama);
    if (i == Integer.MIN_VALUE)
      i = 0; 
    if (d(parama)) {
      j = y0.p0();
    } else {
      j = y0.N0();
    } 
    if (d(parama)) {
      k = k2.b.m(paramLong);
    } else {
      k = k2.b.n(paramLong);
    } 
    h.a a1 = h.t0;
    if (!h.m(paramFloat1, a1.b())) {
      m = paraml0.Y(paramFloat1);
    } else {
      m = 0;
    } 
    int n = k - j;
    int m = j.k(m - i, 0, n);
    if (!h.m(paramFloat2, a1.b())) {
      k = paraml0.Y(paramFloat2);
    } else {
      k = 0;
    } 
    int k = j.k(k - j + i, 0, n - m);
    if (d(parama)) {
      i = y0.N0();
    } else {
      i = Math.max(y0.N0() + m + k, k2.b.p(paramLong));
    } 
    if (d(parama)) {
      j = Math.max(y0.p0() + m + k, k2.b.o(paramLong));
    } else {
      j = y0.p0();
    } 
    return k0.b(paraml0, i, j, null, new a(parama, paramFloat1, m, i, k, y0, j), 4, null);
  }
  
  private static final boolean d(o1.a parama) {
    return parama instanceof o1.k;
  }
  
  public static final e e(e parame, o1.a parama, float paramFloat1, float paramFloat2) {
    l l;
    q.j(parame, "$this$paddingFrom");
    q.j(parama, "alignmentLine");
    if (j1.c()) {
      l = new b(parama, paramFloat1, paramFloat2);
    } else {
      l = j1.a();
    } 
    return parame.then((e)new AlignmentLineOffsetDpElement(parama, paramFloat1, paramFloat2, l, null));
  }
  
  public static final e g(e parame, float paramFloat1, float paramFloat2) {
    e.a a1;
    e.a a2;
    q.j(parame, "$this$paddingFromBaseline");
    h.a a3 = h.t0;
    if (!h.m(paramFloat1, a3.b())) {
      e e2 = f((e)e.a, (o1.a)o1.b.a(), paramFloat1, 0.0F, 4, null);
    } else {
      a2 = e.a;
    } 
    e e1 = parame.then((e)a2);
    if (!h.m(paramFloat2, a3.b())) {
      parame = f((e)e.a, (o1.a)o1.b.b(), 0.0F, paramFloat2, 2, null);
    } else {
      a1 = e.a;
    } 
    return e1.then((e)a1);
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(o1.a param1a, float param1Float, int param1Int1, int param1Int2, int param1Int3, y0 param1y0, int param1Int4) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      int i;
      int j;
      q.j(param1a, "$this$layout");
      if (a.b(this.s0)) {
        j = 0;
      } else {
        if (!h.m(this.t0, h.t0.b())) {
          i = this.u0;
        } else {
          i = this.v0 - this.w0 - this.x0.N0();
        } 
        j = i;
      } 
      if (!a.b(this.s0)) {
        i = 0;
      } else if (!h.m(this.t0, h.t0.b())) {
        i = this.u0;
      } else {
        i = this.y0 - this.w0 - this.x0.p0();
      } 
      y0.a.r(param1a, this.x0, j, i, 0.0F, 4, null);
    }
  }
  
  public static final class b extends r implements l<l1, v> {
    public b(o1.a param1a, float param1Float1, float param1Float2) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("paddingFrom");
      param1l1.a().b("alignmentLine", this.s0);
      param1l1.a().b("before", h.d(this.t0));
      param1l1.a().b("after", h.d(this.u0));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */