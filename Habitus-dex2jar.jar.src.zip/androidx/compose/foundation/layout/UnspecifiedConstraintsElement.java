package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import k2.h;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q1.u0;

final class UnspecifiedConstraintsElement extends u0<q> {
  private final float c;
  
  private final float d;
  
  private UnspecifiedConstraintsElement(float paramFloat1, float paramFloat2) {
    this.c = paramFloat1;
    this.d = paramFloat2;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof UnspecifiedConstraintsElement;
    boolean bool1 = false;
    if (!bool)
      return false; 
    float f = this.c;
    paramObject = paramObject;
    bool = bool1;
    if (h.m(f, ((UnspecifiedConstraintsElement)paramObject).c)) {
      bool = bool1;
      if (h.m(this.d, ((UnspecifiedConstraintsElement)paramObject).d))
        bool = true; 
    } 
    return bool;
  }
  
  public int hashCode() {
    return h.o(this.c) * 31 + h.o(this.d);
  }
  
  public q s() {
    return new q(this.c, this.d, null);
  }
  
  public void t(q paramq) {
    q.j(paramq, "node");
    paramq.B1(this.c);
    paramq.A1(this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\UnspecifiedConstraintsElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */