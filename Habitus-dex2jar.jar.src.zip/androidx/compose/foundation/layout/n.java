package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.l;
import k2.c;
import k2.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.y0;
import q1.d0;
import q1.e0;
import rj.v;
import u.a0;

final class n extends e.c implements e0 {
  private a0 F0;
  
  public n(a0 parama0) {
    this.F0 = parama0;
  }
  
  public final a0 A1() {
    return this.F0;
  }
  
  public final void B1(a0 parama0) {
    q.j(parama0, "<set-?>");
    this.F0 = parama0;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    float f1 = this.F0.b(paraml0.getLayoutDirection());
    int j = 0;
    float f2 = false;
    int i = j;
    if (h.j(f1, h.k(f2)) >= 0) {
      i = j;
      if (h.j(this.F0.c(), h.k(f2)) >= 0) {
        i = j;
        if (h.j(this.F0.d(paraml0.getLayoutDirection()), h.k(f2)) >= 0) {
          i = j;
          if (h.j(this.F0.a(), h.k(f2)) >= 0)
            i = 1; 
        } 
      } 
    } 
    if (i) {
      i = paraml0.Y(this.F0.b(paraml0.getLayoutDirection())) + paraml0.Y(this.F0.d(paraml0.getLayoutDirection()));
      j = paraml0.Y(this.F0.c()) + paraml0.Y(this.F0.a());
      y0 y0 = paramg0.Q(c.i(paramLong, -i, -j));
      return k0.b(paraml0, c.g(paramLong, y0.N0() + i), c.f(paramLong, y0.p0() + j), null, new a(y0, paraml0, this), 4, null);
    } 
    throw new IllegalArgumentException("Padding must be non-negative".toString());
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(y0 param1y0, l0 param1l0, n param1n) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      y0.a.n(param1a, this.s0, this.t0.Y(this.u0.A1().b(this.t0.getLayoutDirection())), this.t0.Y(this.u0.A1().c()), 0.0F, 4, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */