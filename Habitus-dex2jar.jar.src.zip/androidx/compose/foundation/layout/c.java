package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.j1;
import androidx.compose.ui.platform.l1;
import dk.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;

public final class c {
  public static final e a(e parame, float paramFloat, boolean paramBoolean) {
    l<? super l1, v> l;
    q.j(parame, "<this>");
    if (j1.c()) {
      l = new a(paramFloat, paramBoolean);
    } else {
      l = j1.a();
    } 
    return parame.then((e)new AspectRatioElement(paramFloat, paramBoolean, l));
  }
  
  public static final class a extends r implements l<l1, v> {
    public a(float param1Float, boolean param1Boolean) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("aspectRatio");
      param1l1.a().b("ratio", Float.valueOf(this.s0));
      param1l1.a().b("matchHeightConstraintsFirst", Boolean.valueOf(this.t0));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */