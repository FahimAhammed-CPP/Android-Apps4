package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.l;
import ik.j;
import k2.b;
import k2.c;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q1.d0;
import q1.e0;
import rj.v;
import u.m;

final class h extends e.c implements e0 {
  private m F0;
  
  private float G0;
  
  public h(m paramm, float paramFloat) {
    this.F0 = paramm;
    this.G0 = paramFloat;
  }
  
  public final void A1(m paramm) {
    q.j(paramm, "<set-?>");
    this.F0 = paramm;
  }
  
  public final void B1(float paramFloat) {
    this.G0 = paramFloat;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    int i;
    int j;
    int k;
    int n;
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    if (b.j(paramLong) && this.F0 != m.s0) {
      i = j.k(fk.a.d(b.n(paramLong) * this.G0), b.p(paramLong), b.n(paramLong));
      j = i;
    } else {
      i = b.p(paramLong);
      j = b.n(paramLong);
    } 
    if (b.i(paramLong) && this.F0 != m.t0) {
      k = j.k(fk.a.d(b.m(paramLong) * this.G0), b.o(paramLong), b.m(paramLong));
      int i1 = k;
      n = i1;
    } else {
      int i1 = b.o(paramLong);
      n = b.m(paramLong);
      k = i1;
    } 
    y0 y0 = paramg0.Q(c.a(i, j, k, n));
    return k0.b(paraml0, y0.N0(), y0.p0(), null, new a(y0), 4, null);
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(y0 param1y0) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      y0.a.r(param1a, this.s0, 0, 0, 0.0F, 4, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */