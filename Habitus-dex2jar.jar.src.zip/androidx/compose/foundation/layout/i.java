package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import dk.l;
import k2.e;
import k2.h;
import k2.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;

public final class i {
  public static final e a(e parame, l<? super e, l> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "offset");
    return parame.then((e)new OffsetPxElement(paraml, true, new b(paraml)));
  }
  
  public static final e b(e parame, float paramFloat1, float paramFloat2) {
    q.j(parame, "$this$offset");
    return parame.then((e)new OffsetElement(paramFloat1, paramFloat2, true, new a(paramFloat1, paramFloat2), null));
  }
  
  static final class a extends r implements l<l1, v> {
    a(float param1Float1, float param1Float2) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$$receiver");
      param1l1.b("offset");
      param1l1.a().b("x", h.d(this.s0));
      param1l1.a().b("y", h.d(this.t0));
    }
  }
  
  static final class b extends r implements l<l1, v> {
    b(l<? super e, l> param1l) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$$receiver");
      param1l1.b("offset");
      param1l1.a().b("offset", this.s0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */