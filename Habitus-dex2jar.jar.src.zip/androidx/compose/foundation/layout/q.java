package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.l;
import ik.j;
import k2.b;
import k2.c;
import k2.h;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q1.e0;
import rj.v;

final class q extends e.c implements e0 {
  private float F0;
  
  private float G0;
  
  private q(float paramFloat1, float paramFloat2) {
    this.F0 = paramFloat1;
    this.G0 = paramFloat2;
  }
  
  public final void A1(float paramFloat) {
    this.G0 = paramFloat;
  }
  
  public final void B1(float paramFloat) {
    this.F0 = paramFloat;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    int i;
    int j;
    kotlin.jvm.internal.q.j(paraml0, "$this$measure");
    kotlin.jvm.internal.q.j(paramg0, "measurable");
    float f = this.F0;
    h.a a = h.t0;
    if (!h.m(f, a.b()) && b.p(paramLong) == 0) {
      i = j.d(j.g(paraml0.Y(this.F0), b.n(paramLong)), 0);
    } else {
      i = b.p(paramLong);
    } 
    int k = b.n(paramLong);
    if (!h.m(this.G0, a.b()) && b.o(paramLong) == 0) {
      j = j.d(j.g(paraml0.Y(this.G0), b.m(paramLong)), 0);
    } else {
      j = b.o(paramLong);
    } 
    y0 y0 = paramg0.Q(c.a(i, k, j, b.m(paramLong)));
    return k0.b(paraml0, y0.N0(), y0.p0(), null, new a(y0), 4, null);
  }
  
  public int d(n paramn, m paramm, int paramInt) {
    kotlin.jvm.internal.q.j(paramn, "<this>");
    kotlin.jvm.internal.q.j(paramm, "measurable");
    int i = paramm.N(paramInt);
    if (!h.m(this.F0, h.t0.b())) {
      paramInt = paramn.Y(this.F0);
    } else {
      paramInt = 0;
    } 
    return j.d(i, paramInt);
  }
  
  public int j(n paramn, m paramm, int paramInt) {
    kotlin.jvm.internal.q.j(paramn, "<this>");
    kotlin.jvm.internal.q.j(paramm, "measurable");
    int i = paramm.C(paramInt);
    if (!h.m(this.G0, h.t0.b())) {
      paramInt = paramn.Y(this.G0);
    } else {
      paramInt = 0;
    } 
    return j.d(i, paramInt);
  }
  
  public int o(n paramn, m paramm, int paramInt) {
    kotlin.jvm.internal.q.j(paramn, "<this>");
    kotlin.jvm.internal.q.j(paramm, "measurable");
    int i = paramm.d(paramInt);
    if (!h.m(this.G0, h.t0.b())) {
      paramInt = paramn.Y(this.G0);
    } else {
      paramInt = 0;
    } 
    return j.d(i, paramInt);
  }
  
  public int u(n paramn, m paramm, int paramInt) {
    kotlin.jvm.internal.q.j(paramn, "<this>");
    kotlin.jvm.internal.q.j(paramm, "measurable");
    int i = paramm.K(paramInt);
    if (!h.m(this.F0, h.t0.b())) {
      paramInt = paramn.Y(this.F0);
    } else {
      paramInt = 0;
    } 
    return j.d(i, paramInt);
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(y0 param1y0) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      kotlin.jvm.internal.q.j(param1a, "$this$layout");
      y0.a.r(param1a, this.s0, 0, 0, 0.0F, 4, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */