package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.l;
import dk.p;
import ik.j;
import k2.b;
import k2.c;
import k2.l;
import k2.p;
import k2.q;
import kotlin.jvm.internal.q;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q1.d0;
import q1.e0;
import rj.v;
import u.m;

final class r extends e.c implements e0 {
  private m F0;
  
  private boolean G0;
  
  private p<? super p, ? super k2.r, l> H0;
  
  public r(m paramm, boolean paramBoolean, p<? super p, ? super k2.r, l> paramp) {
    this.F0 = paramm;
    this.G0 = paramBoolean;
    this.H0 = paramp;
  }
  
  public final p<p, k2.r, l> A1() {
    return (p)this.H0;
  }
  
  public final void B1(p<? super p, ? super k2.r, l> paramp) {
    q.j(paramp, "<set-?>");
    this.H0 = paramp;
  }
  
  public final void C1(m paramm) {
    q.j(paramm, "<set-?>");
    this.F0 = paramm;
  }
  
  public final void D1(boolean paramBoolean) {
    this.G0 = paramBoolean;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    int k;
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    m m2 = this.F0;
    m m1 = m.s0;
    int j = 0;
    if (m2 != m1) {
      i = 0;
    } else {
      i = b.p(paramLong);
    } 
    m m3 = this.F0;
    m2 = m.t0;
    if (m3 == m2)
      j = b.o(paramLong); 
    m3 = this.F0;
    int n = Integer.MAX_VALUE;
    if (m3 != m1 && this.G0) {
      k = Integer.MAX_VALUE;
    } else {
      k = b.n(paramLong);
    } 
    if (this.F0 == m2 || !this.G0)
      n = b.m(paramLong); 
    y0 y0 = paramg0.Q(c.a(i, k, j, n));
    int i = j.k(y0.N0(), b.p(paramLong), b.n(paramLong));
    j = j.k(y0.p0(), b.o(paramLong), b.m(paramLong));
    return k0.b(paraml0, i, j, null, new a(this, i, y0, j, paraml0), 4, null);
  }
  
  static final class a extends kotlin.jvm.internal.r implements l<y0.a, v> {
    a(r param1r, int param1Int1, y0 param1y0, int param1Int2, l0 param1l0) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      long l1 = ((l)this.s0.A1().invoke(p.b(q.a(this.t0 - this.u0.N0(), this.v0 - this.u0.p0())), this.w0.getLayoutDirection())).o();
      y0.a.p(param1a, this.u0, l1, 0.0F, 2, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */