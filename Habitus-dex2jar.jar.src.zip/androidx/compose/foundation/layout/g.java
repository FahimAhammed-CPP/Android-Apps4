package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.j1;
import androidx.compose.ui.platform.l1;
import dk.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;
import u.d;

public final class g implements d {
  public static final g a = new g();
  
  public e align(e parame, w0.b paramb) {
    l<? super l1, v> l;
    q.j(parame, "<this>");
    q.j(paramb, "alignment");
    if (j1.c()) {
      l = new a(paramb);
    } else {
      l = j1.a();
    } 
    return parame.then((e)new BoxChildDataElement(paramb, false, l));
  }
  
  public e b(e parame) {
    l<? super l1, v> l;
    q.j(parame, "<this>");
    w0.b b = w0.b.a.e();
    if (j1.c()) {
      l = new b();
    } else {
      l = j1.a();
    } 
    return parame.then((e)new BoxChildDataElement(b, true, l));
  }
  
  public static final class a extends r implements l<l1, v> {
    public a(w0.b param1b) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("align");
      param1l1.c(this.s0);
    }
  }
  
  public static final class b extends r implements l<l1, v> {
    public b() {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("matchParentSize");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */