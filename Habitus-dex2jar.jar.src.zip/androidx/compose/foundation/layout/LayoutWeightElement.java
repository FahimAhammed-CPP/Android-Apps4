package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import u.u;

public final class LayoutWeightElement extends u0<u> {
  private final float c;
  
  private final boolean d;
  
  public LayoutWeightElement(float paramFloat, boolean paramBoolean) {
    this.c = paramFloat;
    this.d = paramBoolean;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool;
    if (this == paramObject)
      return true; 
    if (paramObject instanceof LayoutWeightElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    if (paramObject == null)
      return false; 
    if (this.c == ((LayoutWeightElement)paramObject).c) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool && this.d == ((LayoutWeightElement)paramObject).d);
  }
  
  public int hashCode() {
    return Float.floatToIntBits(this.c) * 31 + k.a(this.d);
  }
  
  public u s() {
    return new u(this.c, this.d);
  }
  
  public void t(u paramu) {
    q.j(paramu, "node");
    paramu.C1(this.c);
    paramu.B1(this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\LayoutWeightElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */