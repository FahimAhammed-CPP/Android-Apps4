package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import k2.h;
import k2.r;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;
import u.a0;
import u.b0;

public final class l {
  public static final a0 a(float paramFloat) {
    return (a0)new b0(paramFloat, paramFloat, paramFloat, paramFloat, null);
  }
  
  public static final a0 b(float paramFloat1, float paramFloat2) {
    return (a0)new b0(paramFloat1, paramFloat2, paramFloat1, paramFloat2, null);
  }
  
  public static final a0 d(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return (a0)new b0(paramFloat1, paramFloat2, paramFloat3, paramFloat4, null);
  }
  
  public static final float f(a0 parama0, r paramr) {
    q.j(parama0, "<this>");
    q.j(paramr, "layoutDirection");
    return (paramr == r.s0) ? parama0.d(paramr) : parama0.b(paramr);
  }
  
  public static final float g(a0 parama0, r paramr) {
    q.j(parama0, "<this>");
    q.j(paramr, "layoutDirection");
    return (paramr == r.s0) ? parama0.b(paramr) : parama0.d(paramr);
  }
  
  public static final e h(e parame, a0 parama0) {
    q.j(parame, "<this>");
    q.j(parama0, "paddingValues");
    return parame.then((e)new PaddingValuesElement(parama0, new d(parama0)));
  }
  
  public static final e i(e parame, float paramFloat) {
    q.j(parame, "$this$padding");
    return parame.then((e)new PaddingElement(paramFloat, paramFloat, paramFloat, paramFloat, true, new c(paramFloat), null));
  }
  
  public static final e j(e parame, float paramFloat1, float paramFloat2) {
    q.j(parame, "$this$padding");
    return parame.then((e)new PaddingElement(paramFloat1, paramFloat2, paramFloat1, paramFloat2, true, new b(paramFloat1, paramFloat2), null));
  }
  
  public static final e l(e parame, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    q.j(parame, "$this$padding");
    return parame.then((e)new PaddingElement(paramFloat1, paramFloat2, paramFloat3, paramFloat4, true, new a(paramFloat1, paramFloat2, paramFloat3, paramFloat4), null));
  }
  
  static final class a extends r implements dk.l<l1, v> {
    a(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$$receiver");
      param1l1.b("padding");
      param1l1.a().b("start", h.d(this.s0));
      param1l1.a().b("top", h.d(this.t0));
      param1l1.a().b("end", h.d(this.u0));
      param1l1.a().b("bottom", h.d(this.v0));
    }
  }
  
  static final class b extends r implements dk.l<l1, v> {
    b(float param1Float1, float param1Float2) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$$receiver");
      param1l1.b("padding");
      param1l1.a().b("horizontal", h.d(this.s0));
      param1l1.a().b("vertical", h.d(this.t0));
    }
  }
  
  static final class c extends r implements dk.l<l1, v> {
    c(float param1Float) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$$receiver");
      param1l1.b("padding");
      param1l1.c(h.d(this.s0));
    }
  }
  
  static final class d extends r implements dk.l<l1, v> {
    d(a0 param1a0) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$$receiver");
      param1l1.b("padding");
      param1l1.a().b("paddingValues", this.s0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */