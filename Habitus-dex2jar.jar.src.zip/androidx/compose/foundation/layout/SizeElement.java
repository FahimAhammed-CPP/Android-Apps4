package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import dk.l;
import k2.h;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import rj.v;

final class SizeElement extends u0<p> {
  private final float c;
  
  private final float d;
  
  private final float e;
  
  private final float f;
  
  private final boolean g;
  
  private final l<l1, v> h;
  
  private SizeElement(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean, l<? super l1, v> paraml) {
    this.c = paramFloat1;
    this.d = paramFloat2;
    this.e = paramFloat3;
    this.f = paramFloat4;
    this.g = paramBoolean;
    this.h = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SizeElement))
      return false; 
    float f = this.c;
    paramObject = paramObject;
    return !h.m(f, ((SizeElement)paramObject).c) ? false : (!h.m(this.d, ((SizeElement)paramObject).d) ? false : (!h.m(this.e, ((SizeElement)paramObject).e) ? false : (!h.m(this.f, ((SizeElement)paramObject).f) ? false : (!(this.g != ((SizeElement)paramObject).g)))));
  }
  
  public int hashCode() {
    return (((h.o(this.c) * 31 + h.o(this.d)) * 31 + h.o(this.e)) * 31 + h.o(this.f)) * 31 + k.a(this.g);
  }
  
  public p s() {
    return new p(this.c, this.d, this.e, this.f, this.g, null);
  }
  
  public void t(p paramp) {
    q.j(paramp, "node");
    paramp.F1(this.c);
    paramp.E1(this.d);
    paramp.D1(this.e);
    paramp.C1(this.f);
    paramp.B1(this.g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\SizeElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */