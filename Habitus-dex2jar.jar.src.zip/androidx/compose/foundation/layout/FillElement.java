package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q1.u0;
import u.m;

final class FillElement extends u0<h> {
  public static final a f = new a(null);
  
  private final m c;
  
  private final float d;
  
  private final String e;
  
  public FillElement(m paramm, float paramFloat, String paramString) {
    this.c = paramm;
    this.d = paramFloat;
    this.e = paramString;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool;
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof FillElement))
      return false; 
    m m1 = this.c;
    paramObject = paramObject;
    if (m1 != ((FillElement)paramObject).c)
      return false; 
    if (this.d == ((FillElement)paramObject).d) {
      bool = true;
    } else {
      bool = false;
    } 
    return !!bool;
  }
  
  public int hashCode() {
    return this.c.hashCode() * 31 + Float.floatToIntBits(this.d);
  }
  
  public h s() {
    return new h(this.c, this.d);
  }
  
  public void t(h paramh) {
    q.j(paramh, "node");
    paramh.A1(this.c);
    paramh.B1(this.d);
  }
  
  public static final class a {
    private a() {}
    
    public final FillElement a(float param1Float) {
      return new FillElement(m.s0, param1Float, "fillMaxHeight");
    }
    
    public final FillElement b(float param1Float) {
      return new FillElement(m.u0, param1Float, "fillMaxSize");
    }
    
    public final FillElement c(float param1Float) {
      return new FillElement(m.t0, param1Float, "fillMaxWidth");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\FillElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */