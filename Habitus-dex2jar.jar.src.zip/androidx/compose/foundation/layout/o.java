package androidx.compose.foundation.layout;

import androidx.compose.ui.platform.j1;
import androidx.compose.ui.platform.l1;
import dk.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;

public final class o {
  private static final FillElement a;
  
  private static final FillElement b;
  
  private static final FillElement c;
  
  private static final WrapContentElement d;
  
  private static final WrapContentElement e;
  
  private static final WrapContentElement f;
  
  private static final WrapContentElement g;
  
  private static final WrapContentElement h;
  
  private static final WrapContentElement i;
  
  static {
    FillElement.a a1 = FillElement.f;
    a = a1.c(1.0F);
    b = a1.a(1.0F);
    c = a1.b(1.0F);
    WrapContentElement.a a = WrapContentElement.h;
    w0.b.a a2 = w0.b.a;
    d = a.c(a2.g(), false);
    e = a.c(a2.k(), false);
    f = a.a(a2.i(), false);
    g = a.a(a2.l(), false);
    h = a.b(a2.e(), false);
    i = a.b(a2.n(), false);
  }
  
  public static final androidx.compose.ui.e a(androidx.compose.ui.e parame, float paramFloat1, float paramFloat2) {
    q.j(parame, "$this$defaultMinSize");
    return parame.then((androidx.compose.ui.e)new UnspecifiedConstraintsElement(paramFloat1, paramFloat2, null));
  }
  
  public static final androidx.compose.ui.e c(androidx.compose.ui.e parame, float paramFloat) {
    boolean bool;
    FillElement fillElement;
    q.j(parame, "<this>");
    if (paramFloat == 1.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      fillElement = b;
    } else {
      fillElement = FillElement.f.a(paramFloat);
    } 
    return parame.then((androidx.compose.ui.e)fillElement);
  }
  
  public static final androidx.compose.ui.e e(androidx.compose.ui.e parame, float paramFloat) {
    boolean bool;
    FillElement fillElement;
    q.j(parame, "<this>");
    if (paramFloat == 1.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      fillElement = c;
    } else {
      fillElement = FillElement.f.b(paramFloat);
    } 
    return parame.then((androidx.compose.ui.e)fillElement);
  }
  
  public static final androidx.compose.ui.e g(androidx.compose.ui.e parame, float paramFloat) {
    boolean bool;
    FillElement fillElement;
    q.j(parame, "<this>");
    if (paramFloat == 1.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      fillElement = a;
    } else {
      fillElement = FillElement.f.c(paramFloat);
    } 
    return parame.then((androidx.compose.ui.e)fillElement);
  }
  
  public static final androidx.compose.ui.e i(androidx.compose.ui.e parame, float paramFloat) {
    l l;
    q.j(parame, "$this$height");
    if (j1.c()) {
      l = new a(paramFloat);
    } else {
      l = j1.a();
    } 
    return parame.then((androidx.compose.ui.e)new SizeElement(0.0F, paramFloat, 0.0F, paramFloat, true, l, 5, null));
  }
  
  public static final androidx.compose.ui.e j(androidx.compose.ui.e parame, float paramFloat1, float paramFloat2) {
    l l;
    q.j(parame, "$this$heightIn");
    if (j1.c()) {
      l = new b(paramFloat1, paramFloat2);
    } else {
      l = j1.a();
    } 
    return parame.then((androidx.compose.ui.e)new SizeElement(0.0F, paramFloat1, 0.0F, paramFloat2, true, l, 5, null));
  }
  
  public static final androidx.compose.ui.e l(androidx.compose.ui.e parame, float paramFloat) {
    l l;
    q.j(parame, "$this$requiredSize");
    if (j1.c()) {
      l = new c(paramFloat);
    } else {
      l = j1.a();
    } 
    return parame.then((androidx.compose.ui.e)new SizeElement(paramFloat, paramFloat, paramFloat, paramFloat, false, l, null));
  }
  
  public static final androidx.compose.ui.e m(androidx.compose.ui.e parame, float paramFloat1, float paramFloat2) {
    l l;
    q.j(parame, "$this$requiredSize");
    if (j1.c()) {
      l = new d(paramFloat1, paramFloat2);
    } else {
      l = j1.a();
    } 
    return parame.then((androidx.compose.ui.e)new SizeElement(paramFloat1, paramFloat2, paramFloat1, paramFloat2, false, l, null));
  }
  
  public static final androidx.compose.ui.e n(androidx.compose.ui.e parame, float paramFloat) {
    l l;
    q.j(parame, "$this$size");
    if (j1.c()) {
      l = new e(paramFloat);
    } else {
      l = j1.a();
    } 
    return parame.then((androidx.compose.ui.e)new SizeElement(paramFloat, paramFloat, paramFloat, paramFloat, true, l, null));
  }
  
  public static final androidx.compose.ui.e o(androidx.compose.ui.e parame, float paramFloat1, float paramFloat2) {
    l l;
    q.j(parame, "$this$size");
    if (j1.c()) {
      l = new f(paramFloat1, paramFloat2);
    } else {
      l = j1.a();
    } 
    return parame.then((androidx.compose.ui.e)new SizeElement(paramFloat1, paramFloat2, paramFloat1, paramFloat2, true, l, null));
  }
  
  public static final androidx.compose.ui.e p(androidx.compose.ui.e parame, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    l l;
    q.j(parame, "$this$sizeIn");
    if (j1.c()) {
      l = new g(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    } else {
      l = j1.a();
    } 
    return parame.then((androidx.compose.ui.e)new SizeElement(paramFloat1, paramFloat2, paramFloat3, paramFloat4, true, l, null));
  }
  
  public static final androidx.compose.ui.e r(androidx.compose.ui.e parame, float paramFloat) {
    l l;
    q.j(parame, "$this$width");
    if (j1.c()) {
      l = new h(paramFloat);
    } else {
      l = j1.a();
    } 
    return parame.then((androidx.compose.ui.e)new SizeElement(paramFloat, 0.0F, paramFloat, 0.0F, true, l, 10, null));
  }
  
  public static final androidx.compose.ui.e s(androidx.compose.ui.e parame, float paramFloat1, float paramFloat2) {
    l l;
    q.j(parame, "$this$widthIn");
    if (j1.c()) {
      l = new i(paramFloat1, paramFloat2);
    } else {
      l = j1.a();
    } 
    return parame.then((androidx.compose.ui.e)new SizeElement(paramFloat1, 0.0F, paramFloat2, 0.0F, true, l, 10, null));
  }
  
  public static final androidx.compose.ui.e u(androidx.compose.ui.e parame, w0.b.c paramc, boolean paramBoolean) {
    WrapContentElement wrapContentElement;
    q.j(parame, "<this>");
    q.j(paramc, "align");
    w0.b.a a = w0.b.a;
    if (q.e(paramc, a.i()) && !paramBoolean) {
      wrapContentElement = f;
    } else if (q.e(wrapContentElement, a.l()) && !paramBoolean) {
      wrapContentElement = g;
    } else {
      wrapContentElement = WrapContentElement.h.a((w0.b.c)wrapContentElement, paramBoolean);
    } 
    return parame.then((androidx.compose.ui.e)wrapContentElement);
  }
  
  public static final androidx.compose.ui.e w(androidx.compose.ui.e parame, w0.b paramb, boolean paramBoolean) {
    WrapContentElement wrapContentElement;
    q.j(parame, "<this>");
    q.j(paramb, "align");
    w0.b.a a = w0.b.a;
    if (q.e(paramb, a.e()) && !paramBoolean) {
      wrapContentElement = h;
    } else if (q.e(wrapContentElement, a.n()) && !paramBoolean) {
      wrapContentElement = i;
    } else {
      wrapContentElement = WrapContentElement.h.b((w0.b)wrapContentElement, paramBoolean);
    } 
    return parame.then((androidx.compose.ui.e)wrapContentElement);
  }
  
  public static final androidx.compose.ui.e y(androidx.compose.ui.e parame, w0.b.b paramb, boolean paramBoolean) {
    WrapContentElement wrapContentElement;
    q.j(parame, "<this>");
    q.j(paramb, "align");
    w0.b.a a = w0.b.a;
    if (q.e(paramb, a.g()) && !paramBoolean) {
      wrapContentElement = d;
    } else if (q.e(wrapContentElement, a.k()) && !paramBoolean) {
      wrapContentElement = e;
    } else {
      wrapContentElement = WrapContentElement.h.c((w0.b.b)wrapContentElement, paramBoolean);
    } 
    return parame.then((androidx.compose.ui.e)wrapContentElement);
  }
  
  public static final class a extends r implements l<l1, v> {
    public a(float param1Float) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("height");
      param1l1.c(k2.h.d(this.s0));
    }
  }
  
  public static final class b extends r implements l<l1, v> {
    public b(float param1Float1, float param1Float2) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("heightIn");
      param1l1.a().b("min", k2.h.d(this.s0));
      param1l1.a().b("max", k2.h.d(this.t0));
    }
  }
  
  public static final class c extends r implements l<l1, v> {
    public c(float param1Float) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("requiredSize");
      param1l1.c(k2.h.d(this.s0));
    }
  }
  
  public static final class d extends r implements l<l1, v> {
    public d(float param1Float1, float param1Float2) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("requiredSize");
      param1l1.a().b("width", k2.h.d(this.s0));
      param1l1.a().b("height", k2.h.d(this.t0));
    }
  }
  
  public static final class e extends r implements l<l1, v> {
    public e(float param1Float) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("size");
      param1l1.c(k2.h.d(this.s0));
    }
  }
  
  public static final class f extends r implements l<l1, v> {
    public f(float param1Float1, float param1Float2) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("size");
      param1l1.a().b("width", k2.h.d(this.s0));
      param1l1.a().b("height", k2.h.d(this.t0));
    }
  }
  
  public static final class g extends r implements l<l1, v> {
    public g(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("sizeIn");
      param1l1.a().b("minWidth", k2.h.d(this.s0));
      param1l1.a().b("minHeight", k2.h.d(this.t0));
      param1l1.a().b("maxWidth", k2.h.d(this.u0));
      param1l1.a().b("maxHeight", k2.h.d(this.v0));
    }
  }
  
  public static final class h extends r implements l<l1, v> {
    public h(float param1Float) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("width");
      param1l1.c(k2.h.d(this.s0));
    }
  }
  
  public static final class i extends r implements l<l1, v> {
    public i(float param1Float1, float param1Float2) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("widthIn");
      param1l1.a().b("min", k2.h.d(this.s0));
      param1l1.a().b("max", k2.h.d(this.t0));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */