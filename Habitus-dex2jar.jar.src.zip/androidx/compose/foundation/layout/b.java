package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import o1.a;
import o1.g0;
import o1.j0;
import o1.l0;
import o1.m;
import o1.n;
import q1.d0;
import q1.e0;

final class b extends e.c implements e0 {
  private a F0;
  
  private float G0;
  
  private float H0;
  
  private b(a parama, float paramFloat1, float paramFloat2) {
    this.F0 = parama;
    this.G0 = paramFloat1;
    this.H0 = paramFloat2;
  }
  
  public final void A1(float paramFloat) {
    this.H0 = paramFloat;
  }
  
  public final void B1(a parama) {
    q.j(parama, "<set-?>");
    this.F0 = parama;
  }
  
  public final void C1(float paramFloat) {
    this.G0 = paramFloat;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    return a.a(paraml0, this.F0, this.G0, this.H0, paramg0, paramLong);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */