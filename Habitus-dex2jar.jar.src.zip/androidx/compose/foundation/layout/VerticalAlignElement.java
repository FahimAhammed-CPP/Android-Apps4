package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q1.u0;
import u.n0;
import w0.b;

public final class VerticalAlignElement extends u0<n0> {
  private final b.c c;
  
  public VerticalAlignElement(b.c paramc) {
    this.c = paramc;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof VerticalAlignElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? false : q.e(this.c, ((VerticalAlignElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public n0 s() {
    return new n0(this.c);
  }
  
  public void t(n0 paramn0) {
    q.j(paramn0, "node");
    paramn0.B1(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\VerticalAlignElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */