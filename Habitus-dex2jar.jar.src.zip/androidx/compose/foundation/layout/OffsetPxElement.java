package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import dk.l;
import k2.e;
import k2.l;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import rj.v;

final class OffsetPxElement extends u0<k> {
  private final l<e, l> c;
  
  private final boolean d;
  
  private final l<l1, v> e;
  
  public OffsetPxElement(l<? super e, l> paraml, boolean paramBoolean, l<? super l1, v> paraml1) {
    this.c = (l)paraml;
    this.d = paramBoolean;
    this.e = (l)paraml1;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof OffsetPxElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? false : ((q.e(this.c, ((OffsetPxElement)paramObject).c) && this.d == ((OffsetPxElement)paramObject).d));
  }
  
  public int hashCode() {
    return this.c.hashCode() * 31 + k.a(this.d);
  }
  
  public k s() {
    return new k(this.c, this.d);
  }
  
  public void t(k paramk) {
    q.j(paramk, "node");
    paramk.C1(this.c);
    paramk.D1(this.d);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("OffsetPxModifier(offset=");
    stringBuilder.append(this.c);
    stringBuilder.append(", rtlAware=");
    stringBuilder.append(this.d);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\OffsetPxElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */