package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import dk.l;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import rj.v;
import w0.b;

final class BoxChildDataElement extends u0<e> {
  private final b c;
  
  private final boolean d;
  
  private final l<l1, v> e;
  
  public BoxChildDataElement(b paramb, boolean paramBoolean, l<? super l1, v> paraml) {
    this.c = paramb;
    this.d = paramBoolean;
    this.e = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof BoxChildDataElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? false : ((q.e(this.c, ((BoxChildDataElement)paramObject).c) && this.d == ((BoxChildDataElement)paramObject).d));
  }
  
  public int hashCode() {
    return this.c.hashCode() * 31 + k.a(this.d);
  }
  
  public e s() {
    return new e(this.c, this.d);
  }
  
  public void t(e parame) {
    q.j(parame, "node");
    parame.D1(this.c);
    parame.E1(this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\BoxChildDataElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */