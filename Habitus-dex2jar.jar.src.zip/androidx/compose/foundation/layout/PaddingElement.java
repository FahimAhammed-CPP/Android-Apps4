package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import dk.l;
import k2.h;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import rj.v;

final class PaddingElement extends u0<m> {
  private float c;
  
  private float d;
  
  private float e;
  
  private float f;
  
  private boolean g;
  
  private final l<l1, v> h;
  
  private PaddingElement(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean, l<? super l1, v> paraml) {
    // Byte code:
    //   0: aload #6
    //   2: ldc 'inspectorInfo'
    //   4: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   7: aload_0
    //   8: invokespecial <init> : ()V
    //   11: aload_0
    //   12: fload_1
    //   13: putfield c : F
    //   16: aload_0
    //   17: fload_2
    //   18: putfield d : F
    //   21: aload_0
    //   22: fload_3
    //   23: putfield e : F
    //   26: aload_0
    //   27: fload #4
    //   29: putfield f : F
    //   32: aload_0
    //   33: iload #5
    //   35: putfield g : Z
    //   38: aload_0
    //   39: aload #6
    //   41: putfield h : Ldk/l;
    //   44: fload_1
    //   45: fconst_0
    //   46: fcmpl
    //   47: ifge -> 63
    //   50: fload_1
    //   51: getstatic k2/h.t0 : Lk2/h$a;
    //   54: invokevirtual b : ()F
    //   57: invokestatic m : (FF)Z
    //   60: ifeq -> 138
    //   63: aload_0
    //   64: getfield d : F
    //   67: fstore_1
    //   68: fload_1
    //   69: fconst_0
    //   70: fcmpl
    //   71: ifge -> 87
    //   74: fload_1
    //   75: getstatic k2/h.t0 : Lk2/h$a;
    //   78: invokevirtual b : ()F
    //   81: invokestatic m : (FF)Z
    //   84: ifeq -> 138
    //   87: aload_0
    //   88: getfield e : F
    //   91: fstore_1
    //   92: fload_1
    //   93: fconst_0
    //   94: fcmpl
    //   95: ifge -> 111
    //   98: fload_1
    //   99: getstatic k2/h.t0 : Lk2/h$a;
    //   102: invokevirtual b : ()F
    //   105: invokestatic m : (FF)Z
    //   108: ifeq -> 138
    //   111: aload_0
    //   112: getfield f : F
    //   115: fstore_1
    //   116: fload_1
    //   117: fconst_0
    //   118: fcmpl
    //   119: ifge -> 144
    //   122: fload_1
    //   123: getstatic k2/h.t0 : Lk2/h$a;
    //   126: invokevirtual b : ()F
    //   129: invokestatic m : (FF)Z
    //   132: ifeq -> 138
    //   135: goto -> 144
    //   138: iconst_0
    //   139: istore #7
    //   141: goto -> 147
    //   144: iconst_1
    //   145: istore #7
    //   147: iload #7
    //   149: ifeq -> 153
    //   152: return
    //   153: new java/lang/IllegalArgumentException
    //   156: dup
    //   157: ldc 'Padding must be non-negative'
    //   159: invokevirtual toString : ()Ljava/lang/String;
    //   162: invokespecial <init> : (Ljava/lang/String;)V
    //   165: athrow
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof PaddingElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    boolean bool2 = false;
    if (paramObject == null)
      return false; 
    boolean bool1 = bool2;
    if (h.m(this.c, ((PaddingElement)paramObject).c)) {
      bool1 = bool2;
      if (h.m(this.d, ((PaddingElement)paramObject).d)) {
        bool1 = bool2;
        if (h.m(this.e, ((PaddingElement)paramObject).e)) {
          bool1 = bool2;
          if (h.m(this.f, ((PaddingElement)paramObject).f)) {
            bool1 = bool2;
            if (this.g == ((PaddingElement)paramObject).g)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public int hashCode() {
    return (((h.o(this.c) * 31 + h.o(this.d)) * 31 + h.o(this.e)) * 31 + h.o(this.f)) * 31 + k.a(this.g);
  }
  
  public m s() {
    return new m(this.c, this.d, this.e, this.f, this.g, null);
  }
  
  public void t(m paramm) {
    q.j(paramm, "node");
    paramm.G1(this.c);
    paramm.H1(this.d);
    paramm.E1(this.e);
    paramm.D1(this.f);
    paramm.F1(this.g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\PaddingElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */