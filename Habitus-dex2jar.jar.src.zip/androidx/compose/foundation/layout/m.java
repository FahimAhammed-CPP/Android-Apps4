package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.l;
import k2.c;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.n;
import o1.y0;
import q1.d0;
import q1.e0;
import rj.v;

final class m extends e.c implements e0 {
  private float F0;
  
  private float G0;
  
  private float H0;
  
  private float I0;
  
  private boolean J0;
  
  private m(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean) {
    this.F0 = paramFloat1;
    this.G0 = paramFloat2;
    this.H0 = paramFloat3;
    this.I0 = paramFloat4;
    this.J0 = paramBoolean;
  }
  
  public final boolean A1() {
    return this.J0;
  }
  
  public final float B1() {
    return this.F0;
  }
  
  public final float C1() {
    return this.G0;
  }
  
  public final void D1(float paramFloat) {
    this.I0 = paramFloat;
  }
  
  public final void E1(float paramFloat) {
    this.H0 = paramFloat;
  }
  
  public final void F1(boolean paramBoolean) {
    this.J0 = paramBoolean;
  }
  
  public final void G1(float paramFloat) {
    this.F0 = paramFloat;
  }
  
  public final void H1(float paramFloat) {
    this.G0 = paramFloat;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    int i = paraml0.Y(this.F0) + paraml0.Y(this.H0);
    int j = paraml0.Y(this.G0) + paraml0.Y(this.I0);
    y0 y0 = paramg0.Q(c.i(paramLong, -i, -j));
    return k0.b(paraml0, c.g(paramLong, y0.N0() + i), c.f(paramLong, y0.p0() + j), null, new a(this, y0, paraml0), 4, null);
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(m param1m, y0 param1y0, l0 param1l0) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      if (this.s0.A1()) {
        y0.a.r(param1a, this.t0, this.u0.Y(this.s0.B1()), this.u0.Y(this.s0.C1()), 0.0F, 4, null);
        return;
      } 
      y0.a.n(param1a, this.t0, this.u0.Y(this.s0.B1()), this.u0.Y(this.s0.C1()), 0.0F, 4, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */