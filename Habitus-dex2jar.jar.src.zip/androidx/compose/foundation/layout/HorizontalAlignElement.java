package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q1.u0;
import u.n;
import w0.b;

public final class HorizontalAlignElement extends u0<n> {
  private final b.b c;
  
  public HorizontalAlignElement(b.b paramb) {
    this.c = paramb;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof HorizontalAlignElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? false : q.e(this.c, ((HorizontalAlignElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public n s() {
    return new n(this.c);
  }
  
  public void t(n paramn) {
    q.j(paramn, "node");
    paramn.B1(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\HorizontalAlignElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */