package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.p;
import k2.l;
import k2.m;
import k2.p;
import k2.r;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import q.k;
import q1.u0;
import u.m;

final class WrapContentElement extends u0<r> {
  public static final a h = new a(null);
  
  private final m c;
  
  private final boolean d;
  
  private final p<p, r, l> e;
  
  private final Object f;
  
  private final String g;
  
  public WrapContentElement(m paramm, boolean paramBoolean, p<? super p, ? super r, l> paramp, Object paramObject, String paramString) {
    this.c = paramm;
    this.d = paramBoolean;
    this.e = (p)paramp;
    this.f = paramObject;
    this.g = paramString;
  }
  
  public boolean equals(Object paramObject) {
    Object object;
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      object = paramObject.getClass();
    } else {
      object = null;
    } 
    if (!q.e(WrapContentElement.class, object))
      return false; 
    q.h(paramObject, "null cannot be cast to non-null type androidx.compose.foundation.layout.WrapContentElement");
    paramObject = paramObject;
    return (this.c != ((WrapContentElement)paramObject).c) ? false : ((this.d != ((WrapContentElement)paramObject).d) ? false : (!!q.e(this.f, ((WrapContentElement)paramObject).f)));
  }
  
  public int hashCode() {
    return (this.c.hashCode() * 31 + k.a(this.d)) * 31 + this.f.hashCode();
  }
  
  public r s() {
    return new r(this.c, this.d, this.e);
  }
  
  public void t(r paramr) {
    q.j(paramr, "node");
    paramr.C1(this.c);
    paramr.D1(this.d);
    paramr.B1(this.e);
  }
  
  public static final class a {
    private a() {}
    
    public final WrapContentElement a(w0.b.c param1c, boolean param1Boolean) {
      q.j(param1c, "align");
      return new WrapContentElement(m.s0, param1Boolean, new a(param1c), param1c, "wrapContentHeight");
    }
    
    public final WrapContentElement b(w0.b param1b, boolean param1Boolean) {
      q.j(param1b, "align");
      return new WrapContentElement(m.u0, param1Boolean, new b(param1b), param1b, "wrapContentSize");
    }
    
    public final WrapContentElement c(w0.b.b param1b, boolean param1Boolean) {
      q.j(param1b, "align");
      return new WrapContentElement(m.t0, param1Boolean, new c(param1b), param1b, "wrapContentWidth");
    }
    
    static final class a extends r implements p<p, r, l> {
      a(w0.b.c param2c) {
        super(2);
      }
      
      public final long a(long param2Long, r param2r) {
        q.j(param2r, "<anonymous parameter 1>");
        return m.a(0, this.s0.a(0, p.f(param2Long)));
      }
    }
    
    static final class b extends r implements p<p, r, l> {
      b(w0.b param2b) {
        super(2);
      }
      
      public final long a(long param2Long, r param2r) {
        q.j(param2r, "layoutDirection");
        return this.s0.a(p.b.a(), param2Long, param2r);
      }
    }
    
    static final class c extends r implements p<p, r, l> {
      c(w0.b.b param2b) {
        super(2);
      }
      
      public final long a(long param2Long, r param2r) {
        q.j(param2r, "layoutDirection");
        return m.a(this.s0.a(0, p.g(param2Long), param2r), 0);
      }
    }
  }
  
  static final class a extends r implements p<p, r, l> {
    a(w0.b.c param1c) {
      super(2);
    }
    
    public final long a(long param1Long, r param1r) {
      q.j(param1r, "<anonymous parameter 1>");
      return m.a(0, this.s0.a(0, p.f(param1Long)));
    }
  }
  
  static final class b extends r implements p<p, r, l> {
    b(w0.b param1b) {
      super(2);
    }
    
    public final long a(long param1Long, r param1r) {
      q.j(param1r, "layoutDirection");
      return this.s0.a(p.b.a(), param1Long, param1r);
    }
  }
  
  static final class c extends r implements p<p, r, l> {
    c(w0.b.b param1b) {
      super(2);
    }
    
    public final long a(long param1Long, r param1r) {
      q.j(param1r, "layoutDirection");
      return m.a(this.s0.a(0, p.g(param1Long), param1r), 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\WrapContentElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */