package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import dk.l;
import kotlin.jvm.internal.q;
import q1.u0;
import rj.v;
import u.a0;

final class PaddingValuesElement extends u0<n> {
  private final a0 c;
  
  private final l<l1, v> d;
  
  public PaddingValuesElement(a0 parama0, l<? super l1, v> paraml) {
    this.c = parama0;
    this.d = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof PaddingValuesElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? false : q.e(this.c, ((PaddingValuesElement)paramObject).c);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public n s() {
    return new n(this.c);
  }
  
  public void t(n paramn) {
    q.j(paramn, "node");
    paramn.B1(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\PaddingValuesElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */