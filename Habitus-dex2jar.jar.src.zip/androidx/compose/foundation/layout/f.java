package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.l;
import dk.p;
import dk.q;
import java.util.List;
import k2.r;
import kotlin.jvm.internal.f0;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l0.d2;
import l0.j;
import l0.k2;
import l0.l;
import l0.m2;
import l0.n;
import l0.p3;
import l0.v;
import o1.g0;
import o1.h0;
import o1.i0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.n;
import o1.x;
import o1.y0;
import q1.g;
import rj.v;

public final class f {
  private static final i0 a = d(w0.b.a.n(), false);
  
  private static final i0 b = b.a;
  
  public static final void a(e parame, l paraml, int paramInt) {
    int i;
    q.j(parame, "modifier");
    paraml = paraml.i(-211209833);
    if ((paramInt & 0xE) == 0) {
      if (paraml.R(parame)) {
        i = 4;
      } else {
        i = 2;
      } 
      i |= paramInt;
    } else {
      i = paramInt;
    } 
    if ((i & 0xB) != 2 || !paraml.j()) {
      if (n.K())
        n.V(-211209833, i, -1, "androidx.compose.foundation.layout.Box (Box.kt:198)"); 
      i0 i01 = b;
      paraml.x(-1323940314);
      int j = j.a(paraml, 0);
      v v = paraml.o();
      g.a a = g.n0;
      dk.a a1 = a.a();
      q q = x.b(parame);
      if (!(paraml.k() instanceof l0.f))
        j.c(); 
      paraml.E();
      if (paraml.f()) {
        paraml.K(a1);
      } else {
        paraml.p();
      } 
      l l1 = p3.a(paraml);
      p3.b(l1, i01, a.e());
      p3.b(l1, v, a.g());
      p p = a.b();
      if (l1.f() || !q.e(l1.y(), Integer.valueOf(j))) {
        l1.r(Integer.valueOf(j));
        l1.g(Integer.valueOf(j), p);
      } 
      q.invoke(m2.a(m2.b(paraml)), paraml, Integer.valueOf(((i << 3 & 0x70 | 0x180) << 9 & 0x1C00 | 0x6) >> 3 & 0x70));
      paraml.x(2058660585);
      paraml.Q();
      paraml.s();
      paraml.Q();
      if (n.K())
        n.U(); 
    } else {
      paraml.J();
    } 
    k2 k2 = paraml.l();
    if (k2 == null)
      return; 
    k2.a(new a(parame, paramInt));
  }
  
  public static final i0 d(w0.b paramb, boolean paramBoolean) {
    q.j(paramb, "alignment");
    return new c(paramBoolean, paramb);
  }
  
  private static final e e(g0 paramg0) {
    Object object = paramg0.x();
    return (object instanceof e) ? (e)object : null;
  }
  
  private static final boolean f(g0 paramg0) {
    e e = e(paramg0);
    return (e != null) ? e.B1() : false;
  }
  
  private static final void g(y0.a parama, y0 paramy0, g0 paramg0, r paramr, int paramInt1, int paramInt2, w0.b paramb) {
    // Byte code:
    //   0: aload_2
    //   1: invokestatic e : (Lo1/g0;)Landroidx/compose/foundation/layout/e;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 24
    //   9: aload_2
    //   10: invokevirtual A1 : ()Lw0/b;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnonnull -> 21
    //   18: goto -> 24
    //   21: goto -> 27
    //   24: aload #6
    //   26: astore_2
    //   27: aload_0
    //   28: aload_1
    //   29: aload_2
    //   30: aload_1
    //   31: invokevirtual N0 : ()I
    //   34: aload_1
    //   35: invokevirtual p0 : ()I
    //   38: invokestatic a : (II)J
    //   41: iload #4
    //   43: iload #5
    //   45: invokestatic a : (II)J
    //   48: aload_3
    //   49: invokeinterface a : (JJLk2/r;)J
    //   54: fconst_0
    //   55: iconst_2
    //   56: aconst_null
    //   57: invokestatic p : (Lo1/y0$a;Lo1/y0;JFILjava/lang/Object;)V
    //   60: return
  }
  
  public static final i0 h(w0.b paramb, boolean paramBoolean, l paraml, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: ldc 'alignment'
    //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_2
    //   7: ldc_w 56522820
    //   10: invokeinterface x : (I)V
    //   15: invokestatic K : ()Z
    //   18: ifeq -> 32
    //   21: ldc_w 56522820
    //   24: iload_3
    //   25: iconst_m1
    //   26: ldc_w 'androidx.compose.foundation.layout.rememberBoxMeasurePolicy (Box.kt:79)'
    //   29: invokestatic V : (IIILjava/lang/String;)V
    //   32: aload_0
    //   33: getstatic w0/b.a : Lw0/b$a;
    //   36: invokevirtual n : ()Lw0/b;
    //   39: invokestatic e : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   42: ifeq -> 56
    //   45: iload_1
    //   46: ifne -> 56
    //   49: getstatic androidx/compose/foundation/layout/f.a : Lo1/i0;
    //   52: astore_0
    //   53: goto -> 144
    //   56: aload_2
    //   57: ldc_w 511388516
    //   60: invokeinterface x : (I)V
    //   65: aload_2
    //   66: aload_0
    //   67: invokeinterface R : (Ljava/lang/Object;)Z
    //   72: istore #4
    //   74: aload_2
    //   75: iload_1
    //   76: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   79: invokeinterface R : (Ljava/lang/Object;)Z
    //   84: istore #5
    //   86: aload_2
    //   87: invokeinterface y : ()Ljava/lang/Object;
    //   92: astore #7
    //   94: iload #5
    //   96: iload #4
    //   98: ior
    //   99: ifne -> 117
    //   102: aload #7
    //   104: astore #6
    //   106: aload #7
    //   108: getstatic l0/l.a : Ll0/l$a;
    //   111: invokevirtual a : ()Ljava/lang/Object;
    //   114: if_acmpne -> 132
    //   117: aload_0
    //   118: iload_1
    //   119: invokestatic d : (Lw0/b;Z)Lo1/i0;
    //   122: astore #6
    //   124: aload_2
    //   125: aload #6
    //   127: invokeinterface r : (Ljava/lang/Object;)V
    //   132: aload_2
    //   133: invokeinterface Q : ()V
    //   138: aload #6
    //   140: checkcast o1/i0
    //   143: astore_0
    //   144: invokestatic K : ()Z
    //   147: ifeq -> 153
    //   150: invokestatic U : ()V
    //   153: aload_2
    //   154: invokeinterface Q : ()V
    //   159: aload_0
    //   160: areturn
  }
  
  static final class a extends r implements p<l, Integer, v> {
    a(e param1e, int param1Int) {
      super(2);
    }
    
    public final void invoke(l param1l, int param1Int) {
      f.a(this.s0, param1l, d2.a(this.t0 | 0x1));
    }
  }
  
  static final class b implements i0 {
    public static final b a = new b();
    
    public final j0 measure-3p2s80s(l0 param1l0, List<? extends g0> param1List, long param1Long) {
      q.j(param1l0, "$this$MeasurePolicy");
      q.j(param1List, "<anonymous parameter 0>");
      return k0.b(param1l0, k2.b.p(param1Long), k2.b.o(param1Long), null, a.s0, 4, null);
    }
    
    static final class a extends r implements l<y0.a, v> {
      public static final a s0 = new a();
      
      a() {
        super(1);
      }
      
      public final void invoke(y0.a param2a) {
        q.j(param2a, "$this$layout");
      }
    }
  }
  
  static final class a extends r implements l<y0.a, v> {
    public static final a s0 = new a();
    
    a() {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
    }
  }
  
  static final class c implements i0 {
    c(boolean param1Boolean, w0.b param1b) {}
    
    public final j0 measure-3p2s80s(l0 param1l0, List<? extends g0> param1List, long param1Long) {
      y0<g0> y0;
      long l;
      q.j(param1l0, "$this$MeasurePolicy");
      q.j(param1List, "measurables");
      if (param1List.isEmpty())
        return k0.b(param1l0, k2.b.p(param1Long), k2.b.o(param1Long), null, a.s0, 4, null); 
      if (this.a) {
        l = param1Long;
      } else {
        l = k2.b.e(param1Long, 0, 0, 0, 0, 10, null);
      } 
      int i = param1List.size();
      boolean bool = false;
      if (i == 1) {
        int m;
        g0 g0 = param1List.get(0);
        if (!f.b(g0)) {
          y0 = g0.Q(l);
          i = Math.max(k2.b.p(param1Long), y0.N0());
          m = Math.max(k2.b.o(param1Long), y0.p0());
        } else {
          i = k2.b.p(param1Long);
          m = k2.b.o(param1Long);
          y0 = g0.Q(k2.b.b.c(k2.b.p(param1Long), k2.b.o(param1Long)));
        } 
        return k0.b(param1l0, i, m, null, new b(y0, g0, param1l0, i, m, this.b), 4, null);
      } 
      y0[] arrayOfY0 = new y0[y0.size()];
      f0 f01 = new f0();
      f01.s0 = k2.b.p(param1Long);
      f0 f02 = new f0();
      f02.s0 = k2.b.o(param1Long);
      int k = y0.size();
      i = 0;
      int j = 0;
      while (i < k) {
        g0 g0 = y0.get(i);
        if (!f.b(g0)) {
          y0 y01 = g0.Q(l);
          arrayOfY0[i] = y01;
          f01.s0 = Math.max(f01.s0, y01.N0());
          f02.s0 = Math.max(f02.s0, y01.p0());
        } else {
          j = 1;
        } 
        i++;
      } 
      if (j) {
        k = f01.s0;
        if (k != Integer.MAX_VALUE) {
          i = k;
        } else {
          i = 0;
        } 
        int m = f02.s0;
        if (m != Integer.MAX_VALUE) {
          j = m;
        } else {
          j = 0;
        } 
        param1Long = k2.c.a(i, k, j, m);
        j = y0.size();
        for (i = bool; i < j; i++) {
          g0 g0 = y0.get(i);
          if (f.b(g0))
            arrayOfY0[i] = g0.Q(param1Long); 
        } 
      } 
      return k0.b(param1l0, f01.s0, f02.s0, null, new c(arrayOfY0, (List<? extends g0>)y0, param1l0, f01, f02, this.b), 4, null);
    }
    
    static final class a extends r implements l<y0.a, v> {
      public static final a s0 = new a();
      
      a() {
        super(1);
      }
      
      public final void invoke(y0.a param2a) {
        q.j(param2a, "$this$layout");
      }
    }
    
    static final class b extends r implements l<y0.a, v> {
      b(y0 param2y0, g0 param2g0, l0 param2l0, int param2Int1, int param2Int2, w0.b param2b) {
        super(1);
      }
      
      public final void invoke(y0.a param2a) {
        q.j(param2a, "$this$layout");
        f.c(param2a, this.s0, this.t0, this.u0.getLayoutDirection(), this.v0, this.w0, this.x0);
      }
    }
    
    static final class c extends r implements l<y0.a, v> {
      c(y0[] param2ArrayOfy0, List<? extends g0> param2List, l0 param2l0, f0 param2f01, f0 param2f02, w0.b param2b) {
        super(1);
      }
      
      public final void invoke(y0.a param2a) {
        q.j(param2a, "$this$layout");
        y0[] arrayOfY0 = this.s0;
        List<g0> list = this.t0;
        l0 l01 = this.u0;
        f0 f01 = this.v0;
        f0 f02 = this.w0;
        w0.b b1 = this.x0;
        int k = arrayOfY0.length;
        int i = 0;
        int j = 0;
        while (j < k) {
          y0 y01 = arrayOfY0[j];
          q.h(y01, "null cannot be cast to non-null type androidx.compose.ui.layout.Placeable");
          f.c(param2a, y01, list.get(i), l01.getLayoutDirection(), f01.s0, f02.s0, b1);
          j++;
          i++;
        } 
      }
    }
  }
  
  static final class a extends r implements l<y0.a, v> {
    public static final a s0 = new a();
    
    a() {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
    }
  }
  
  static final class b extends r implements l<y0.a, v> {
    b(y0 param1y0, g0 param1g0, l0 param1l0, int param1Int1, int param1Int2, w0.b param1b) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      f.c(param1a, this.s0, this.t0, this.u0.getLayoutDirection(), this.v0, this.w0, this.x0);
    }
  }
  
  static final class c extends r implements l<y0.a, v> {
    c(y0[] param1ArrayOfy0, List<? extends g0> param1List, l0 param1l0, f0 param1f01, f0 param1f02, w0.b param1b) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      y0[] arrayOfY0 = this.s0;
      List<g0> list = this.t0;
      l0 l01 = this.u0;
      f0 f01 = this.v0;
      f0 f02 = this.w0;
      w0.b b1 = this.x0;
      int k = arrayOfY0.length;
      int i = 0;
      int j = 0;
      while (j < k) {
        y0 y01 = arrayOfY0[j];
        q.h(y01, "null cannot be cast to non-null type androidx.compose.ui.layout.Placeable");
        f.c(param1a, y01, list.get(i), l01.getLayoutDirection(), f01.s0, f02.s0, b1);
        j++;
        i++;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */