package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.l;
import k2.b;
import k2.c;
import k2.p;
import k2.q;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q1.e0;
import rj.v;

final class d extends e.c implements e0 {
  private float F0;
  
  private boolean G0;
  
  public d(float paramFloat, boolean paramBoolean) {
    this.F0 = paramFloat;
    this.G0 = paramBoolean;
  }
  
  private final long A1(long paramLong) {
    if (!this.G0) {
      long l = G1(this, paramLong, false, 1, null);
      p.a a = p.b;
      if (!p.e(l, a.a()))
        return l; 
      l = E1(this, paramLong, false, 1, null);
      if (!p.e(l, a.a()))
        return l; 
      l = K1(this, paramLong, false, 1, null);
      if (!p.e(l, a.a()))
        return l; 
      l = I1(this, paramLong, false, 1, null);
      if (!p.e(l, a.a()))
        return l; 
      l = F1(paramLong, false);
      if (!p.e(l, a.a()))
        return l; 
      l = D1(paramLong, false);
      if (!p.e(l, a.a()))
        return l; 
      l = J1(paramLong, false);
      if (!p.e(l, a.a()))
        return l; 
      paramLong = H1(paramLong, false);
      if (!p.e(paramLong, a.a()))
        return paramLong; 
    } else {
      long l = E1(this, paramLong, false, 1, null);
      p.a a = p.b;
      if (!p.e(l, a.a()))
        return l; 
      l = G1(this, paramLong, false, 1, null);
      if (!p.e(l, a.a()))
        return l; 
      l = I1(this, paramLong, false, 1, null);
      if (!p.e(l, a.a()))
        return l; 
      l = K1(this, paramLong, false, 1, null);
      if (!p.e(l, a.a()))
        return l; 
      l = D1(paramLong, false);
      if (!p.e(l, a.a()))
        return l; 
      l = F1(paramLong, false);
      if (!p.e(l, a.a()))
        return l; 
      l = H1(paramLong, false);
      if (!p.e(l, a.a()))
        return l; 
      paramLong = J1(paramLong, false);
      if (!p.e(paramLong, a.a()))
        return paramLong; 
    } 
    return p.b.a();
  }
  
  private final long D1(long paramLong, boolean paramBoolean) {
    int i = b.m(paramLong);
    if (i != Integer.MAX_VALUE) {
      int j = fk.a.d(i * this.F0);
      if (j > 0) {
        long l = q.a(j, i);
        if (!paramBoolean || c.h(paramLong, l))
          return l; 
      } 
    } 
    return p.b.a();
  }
  
  private final long F1(long paramLong, boolean paramBoolean) {
    int i = b.n(paramLong);
    if (i != Integer.MAX_VALUE) {
      int j = fk.a.d(i / this.F0);
      if (j > 0) {
        long l = q.a(i, j);
        if (!paramBoolean || c.h(paramLong, l))
          return l; 
      } 
    } 
    return p.b.a();
  }
  
  private final long H1(long paramLong, boolean paramBoolean) {
    int i = b.o(paramLong);
    int j = fk.a.d(i * this.F0);
    if (j > 0) {
      long l = q.a(j, i);
      if (!paramBoolean || c.h(paramLong, l))
        return l; 
    } 
    return p.b.a();
  }
  
  private final long J1(long paramLong, boolean paramBoolean) {
    int i = b.p(paramLong);
    int j = fk.a.d(i / this.F0);
    if (j > 0) {
      long l = q.a(i, j);
      if (!paramBoolean || c.h(paramLong, l))
        return l; 
    } 
    return p.b.a();
  }
  
  public final void B1(float paramFloat) {
    this.F0 = paramFloat;
  }
  
  public final void C1(boolean paramBoolean) {
    this.G0 = paramBoolean;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    long l = A1(paramLong);
    if (!p.e(l, p.b.a()))
      paramLong = b.b.c(p.g(l), p.f(l)); 
    y0 y0 = paramg0.Q(paramLong);
    return k0.b(paraml0, y0.N0(), y0.p0(), null, new a(y0), 4, null);
  }
  
  public int d(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    return (paramInt != Integer.MAX_VALUE) ? fk.a.d(paramInt * this.F0) : paramm.N(paramInt);
  }
  
  public int j(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    return (paramInt != Integer.MAX_VALUE) ? fk.a.d(paramInt / this.F0) : paramm.C(paramInt);
  }
  
  public int o(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    return (paramInt != Integer.MAX_VALUE) ? fk.a.d(paramInt / this.F0) : paramm.d(paramInt);
  }
  
  public int u(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    return (paramInt != Integer.MAX_VALUE) ? fk.a.d(paramInt * this.F0) : paramm.K(paramInt);
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(y0 param1y0) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      y0.a.r(param1a, this.s0, 0, 0, 0.0F, 4, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */