package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import dk.l;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import rj.v;

final class AspectRatioElement extends u0<d> {
  private final float c;
  
  private final boolean d;
  
  private final l<l1, v> e;
  
  public AspectRatioElement(float paramFloat, boolean paramBoolean, l<? super l1, v> paraml) {
    boolean bool;
    this.c = paramFloat;
    this.d = paramBoolean;
    this.e = (l)paraml;
    if (paramFloat > 0.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("aspectRatio ");
    stringBuilder.append(paramFloat);
    stringBuilder.append(" must be > 0");
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public boolean equals(Object paramObject) {
    boolean bool;
    Object object;
    if (this == paramObject)
      return true; 
    if (paramObject instanceof AspectRatioElement) {
      object = paramObject;
    } else {
      object = null;
    } 
    if (object == null)
      return false; 
    if (this.c == ((AspectRatioElement)object).c) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool && this.d == ((AspectRatioElement)paramObject).d);
  }
  
  public int hashCode() {
    return Float.floatToIntBits(this.c) * 31 + k.a(this.d);
  }
  
  public d s() {
    return new d(this.c, this.d);
  }
  
  public void t(d paramd) {
    q.j(paramd, "node");
    paramd.B1(this.c);
    paramd.C1(this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\AspectRatioElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */