package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.l;
import k2.e;
import k2.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q1.d0;
import q1.e0;
import rj.v;

final class k extends e.c implements e0 {
  private l<? super e, l> F0;
  
  private boolean G0;
  
  public k(l<? super e, l> paraml, boolean paramBoolean) {
    this.F0 = paraml;
    this.G0 = paramBoolean;
  }
  
  public final l<e, l> A1() {
    return (l)this.F0;
  }
  
  public final boolean B1() {
    return this.G0;
  }
  
  public final void C1(l<? super e, l> paraml) {
    q.j(paraml, "<set-?>");
    this.F0 = paraml;
  }
  
  public final void D1(boolean paramBoolean) {
    this.G0 = paramBoolean;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    y0 y0 = paramg0.Q(paramLong);
    return k0.b(paraml0, y0.N0(), y0.p0(), null, new a(this, paraml0, y0), 4, null);
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(k param1k, l0 param1l0, y0 param1y0) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      long l1 = ((l)this.s0.A1().invoke(this.t0)).o();
      if (this.s0.B1()) {
        y0.a.v(param1a, this.u0, l.j(l1), l.k(l1), 0.0F, null, 12, null);
        return;
      } 
      y0.a.z(param1a, this.u0, l.j(l1), l.k(l1), 0.0F, null, 12, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */