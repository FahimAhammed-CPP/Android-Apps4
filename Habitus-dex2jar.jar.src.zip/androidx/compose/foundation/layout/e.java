package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q1.l1;
import w0.b;

final class e extends e.c implements l1 {
  private b F0;
  
  private boolean G0;
  
  public e(b paramb, boolean paramBoolean) {
    this.F0 = paramb;
    this.G0 = paramBoolean;
  }
  
  public final b A1() {
    return this.F0;
  }
  
  public final boolean B1() {
    return this.G0;
  }
  
  public e C1(k2.e parame, Object paramObject) {
    q.j(parame, "<this>");
    return this;
  }
  
  public final void D1(b paramb) {
    q.j(paramb, "<set-?>");
    this.F0 = paramb;
  }
  
  public final void E1(boolean paramBoolean) {
    this.G0 = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */