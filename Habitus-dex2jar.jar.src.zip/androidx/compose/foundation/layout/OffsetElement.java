package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import dk.l;
import k2.h;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import rj.v;

final class OffsetElement extends u0<j> {
  private final float c;
  
  private final float d;
  
  private final boolean e;
  
  private final l<l1, v> f;
  
  private OffsetElement(float paramFloat1, float paramFloat2, boolean paramBoolean, l<? super l1, v> paraml) {
    this.c = paramFloat1;
    this.d = paramFloat2;
    this.e = paramBoolean;
    this.f = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof OffsetElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? false : ((h.m(this.c, ((OffsetElement)paramObject).c) && h.m(this.d, ((OffsetElement)paramObject).d) && this.e == ((OffsetElement)paramObject).e));
  }
  
  public int hashCode() {
    return (h.o(this.c) * 31 + h.o(this.d)) * 31 + k.a(this.e);
  }
  
  public j s() {
    return new j(this.c, this.d, this.e, null);
  }
  
  public void t(j paramj) {
    q.j(paramj, "node");
    paramj.E1(this.c);
    paramj.F1(this.d);
    paramj.D1(this.e);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("OffsetModifierElement(x=");
    stringBuilder.append(h.q(this.c));
    stringBuilder.append(", y=");
    stringBuilder.append(h.q(this.d));
    stringBuilder.append(", rtlAware=");
    stringBuilder.append(this.e);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\OffsetElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */