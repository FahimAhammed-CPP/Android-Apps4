package androidx.compose.foundation.layout;

import androidx.compose.ui.e;
import dk.l;
import ik.j;
import k2.b;
import k2.c;
import k2.e;
import k2.h;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q1.e0;
import rj.v;

final class p extends e.c implements e0 {
  private float F0;
  
  private float G0;
  
  private float H0;
  
  private float I0;
  
  private boolean J0;
  
  private p(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean) {
    this.F0 = paramFloat1;
    this.G0 = paramFloat2;
    this.H0 = paramFloat3;
    this.I0 = paramFloat4;
    this.J0 = paramBoolean;
  }
  
  private final long A1(e parame) {
    // Byte code:
    //   0: aload_0
    //   1: getfield H0 : F
    //   4: fstore_2
    //   5: getstatic k2/h.t0 : Lk2/h$a;
    //   8: astore #10
    //   10: fload_2
    //   11: aload #10
    //   13: invokevirtual b : ()F
    //   16: invokestatic m : (FF)Z
    //   19: istore #9
    //   21: iconst_0
    //   22: istore #7
    //   24: iload #9
    //   26: ifne -> 47
    //   29: aload_1
    //   30: aload_0
    //   31: getfield H0 : F
    //   34: invokeinterface Y : (F)I
    //   39: iconst_0
    //   40: invokestatic d : (II)I
    //   43: istore_3
    //   44: goto -> 50
    //   47: ldc 2147483647
    //   49: istore_3
    //   50: aload_0
    //   51: getfield I0 : F
    //   54: aload #10
    //   56: invokevirtual b : ()F
    //   59: invokestatic m : (FF)Z
    //   62: ifne -> 84
    //   65: aload_1
    //   66: aload_0
    //   67: getfield I0 : F
    //   70: invokeinterface Y : (F)I
    //   75: iconst_0
    //   76: invokestatic d : (II)I
    //   79: istore #4
    //   81: goto -> 88
    //   84: ldc 2147483647
    //   86: istore #4
    //   88: aload_0
    //   89: getfield F0 : F
    //   92: aload #10
    //   94: invokevirtual b : ()F
    //   97: invokestatic m : (FF)Z
    //   100: ifne -> 133
    //   103: aload_1
    //   104: aload_0
    //   105: getfield F0 : F
    //   108: invokeinterface Y : (F)I
    //   113: iload_3
    //   114: invokestatic g : (II)I
    //   117: iconst_0
    //   118: invokestatic d : (II)I
    //   121: istore #5
    //   123: iload #5
    //   125: ldc 2147483647
    //   127: if_icmpeq -> 133
    //   130: goto -> 136
    //   133: iconst_0
    //   134: istore #5
    //   136: iload #7
    //   138: istore #6
    //   140: aload_0
    //   141: getfield G0 : F
    //   144: aload #10
    //   146: invokevirtual b : ()F
    //   149: invokestatic m : (FF)Z
    //   152: ifne -> 191
    //   155: aload_1
    //   156: aload_0
    //   157: getfield G0 : F
    //   160: invokeinterface Y : (F)I
    //   165: iload #4
    //   167: invokestatic g : (II)I
    //   170: iconst_0
    //   171: invokestatic d : (II)I
    //   174: istore #8
    //   176: iload #7
    //   178: istore #6
    //   180: iload #8
    //   182: ldc 2147483647
    //   184: if_icmpeq -> 191
    //   187: iload #8
    //   189: istore #6
    //   191: iload #5
    //   193: iload_3
    //   194: iload #6
    //   196: iload #4
    //   198: invokestatic a : (IIII)J
    //   201: lreturn
  }
  
  public final void B1(boolean paramBoolean) {
    this.J0 = paramBoolean;
  }
  
  public final void C1(float paramFloat) {
    this.I0 = paramFloat;
  }
  
  public final void D1(float paramFloat) {
    this.H0 = paramFloat;
  }
  
  public final void E1(float paramFloat) {
    this.G0 = paramFloat;
  }
  
  public final void F1(float paramFloat) {
    this.F0 = paramFloat;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    long l = A1((e)paraml0);
    if (this.J0) {
      paramLong = c.e(paramLong, l);
    } else {
      int i;
      int j;
      int k;
      int m;
      float f = this.F0;
      h.a a = h.t0;
      if (!h.m(f, a.b())) {
        i = b.p(l);
      } else {
        i = j.g(b.p(paramLong), b.n(l));
      } 
      if (!h.m(this.H0, a.b())) {
        j = b.n(l);
      } else {
        j = j.d(b.n(paramLong), b.p(l));
      } 
      if (!h.m(this.G0, a.b())) {
        k = b.o(l);
      } else {
        k = j.g(b.o(paramLong), b.m(l));
      } 
      if (!h.m(this.I0, a.b())) {
        m = b.m(l);
      } else {
        m = j.d(b.m(paramLong), b.o(l));
      } 
      paramLong = c.a(i, j, k, m);
    } 
    y0 y0 = paramg0.Q(paramLong);
    return k0.b(paraml0, y0.N0(), y0.p0(), null, new a(y0), 4, null);
  }
  
  public int d(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    long l = A1((e)paramn);
    return b.l(l) ? b.n(l) : c.g(l, paramm.N(paramInt));
  }
  
  public int j(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    long l = A1((e)paramn);
    return b.k(l) ? b.m(l) : c.f(l, paramm.C(paramInt));
  }
  
  public int o(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    long l = A1((e)paramn);
    return b.k(l) ? b.m(l) : c.f(l, paramm.d(paramInt));
  }
  
  public int u(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    long l = A1((e)paramn);
    return b.l(l) ? b.n(l) : c.g(l, paramm.K(paramInt));
  }
  
  static final class a extends r implements l<y0.a, v> {
    a(y0 param1y0) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      q.j(param1a, "$this$layout");
      y0.a.r(param1a, this.s0, 0, 0, 0.0F, 4, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\layout\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */