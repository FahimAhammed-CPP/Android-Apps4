package androidx.compose.foundation.text.modifiers;

import androidx.compose.ui.e;
import b1.s1;
import b2.l;
import e0.l;
import h2.u;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import w1.i0;

public final class TextStringSimpleElement extends u0<l> {
  private final String c;
  
  private final i0 d;
  
  private final l.b e;
  
  private final int f;
  
  private final boolean g;
  
  private final int h;
  
  private final int i;
  
  private final s1 j;
  
  private TextStringSimpleElement(String paramString, i0 parami0, l.b paramb, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, s1 params1) {
    this.c = paramString;
    this.d = parami0;
    this.e = paramb;
    this.f = paramInt1;
    this.g = paramBoolean;
    this.h = paramInt2;
    this.i = paramInt3;
    this.j = params1;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof TextStringSimpleElement))
      return false; 
    s1 s11 = this.j;
    paramObject = paramObject;
    return !q.e(s11, ((TextStringSimpleElement)paramObject).j) ? false : (!q.e(this.c, ((TextStringSimpleElement)paramObject).c) ? false : (!q.e(this.d, ((TextStringSimpleElement)paramObject).d) ? false : (!q.e(this.e, ((TextStringSimpleElement)paramObject).e) ? false : (!u.e(this.f, ((TextStringSimpleElement)paramObject).f) ? false : ((this.g != ((TextStringSimpleElement)paramObject).g) ? false : ((this.h != ((TextStringSimpleElement)paramObject).h) ? false : (!(this.i != ((TextStringSimpleElement)paramObject).i))))))));
  }
  
  public int hashCode() {
    byte b1;
    int i = this.c.hashCode();
    int j = this.d.hashCode();
    int k = this.e.hashCode();
    int m = u.f(this.f);
    int n = k.a(this.g);
    int i1 = this.h;
    int i2 = this.i;
    s1 s11 = this.j;
    if (s11 != null) {
      b1 = s11.hashCode();
    } else {
      b1 = 0;
    } 
    return ((((((i * 31 + j) * 31 + k) * 31 + m) * 31 + n) * 31 + i1) * 31 + i2) * 31 + b1;
  }
  
  public l s() {
    return new l(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, null);
  }
  
  public void t(l paraml) {
    q.j(paraml, "node");
    paraml.B1(paraml.E1(this.j, this.d), paraml.G1(this.c), paraml.F1(this.d, this.i, this.h, this.g, this.e, this.f));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\text\modifiers\TextStringSimpleElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */