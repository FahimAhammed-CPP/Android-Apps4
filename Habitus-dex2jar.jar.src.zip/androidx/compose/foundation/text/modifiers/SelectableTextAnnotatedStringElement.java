package androidx.compose.foundation.text.modifiers;

import a1.h;
import androidx.compose.ui.e;
import b1.s1;
import b2.l;
import dk.l;
import e0.g;
import e0.h;
import h2.u;
import java.util.List;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import rj.v;
import w1.d;
import w1.e0;
import w1.i0;
import w1.u;

public final class SelectableTextAnnotatedStringElement extends u0<g> {
  private final d c;
  
  private final i0 d;
  
  private final l.b e;
  
  private final l<e0, v> f;
  
  private final int g;
  
  private final boolean h;
  
  private final int i;
  
  private final int j;
  
  private final List<d.b<u>> k;
  
  private final l<List<h>, v> l;
  
  private final h m;
  
  private final s1 n;
  
  private SelectableTextAnnotatedStringElement(d paramd, i0 parami0, l.b paramb, l<? super e0, v> paraml, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, List<d.b<u>> paramList, l<? super List<h>, v> paraml1, h paramh, s1 params1) {
    this.c = paramd;
    this.d = parami0;
    this.e = paramb;
    this.f = (l)paraml;
    this.g = paramInt1;
    this.h = paramBoolean;
    this.i = paramInt2;
    this.j = paramInt3;
    this.k = paramList;
    this.l = (l)paraml1;
    this.m = paramh;
    this.n = params1;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SelectableTextAnnotatedStringElement))
      return false; 
    s1 s11 = this.n;
    paramObject = paramObject;
    return !q.e(s11, ((SelectableTextAnnotatedStringElement)paramObject).n) ? false : (!q.e(this.c, ((SelectableTextAnnotatedStringElement)paramObject).c) ? false : (!q.e(this.d, ((SelectableTextAnnotatedStringElement)paramObject).d) ? false : (!q.e(this.k, ((SelectableTextAnnotatedStringElement)paramObject).k) ? false : (!q.e(this.e, ((SelectableTextAnnotatedStringElement)paramObject).e) ? false : (!q.e(this.f, ((SelectableTextAnnotatedStringElement)paramObject).f) ? false : (!u.e(this.g, ((SelectableTextAnnotatedStringElement)paramObject).g) ? false : ((this.h != ((SelectableTextAnnotatedStringElement)paramObject).h) ? false : ((this.i != ((SelectableTextAnnotatedStringElement)paramObject).i) ? false : ((this.j != ((SelectableTextAnnotatedStringElement)paramObject).j) ? false : (!q.e(this.l, ((SelectableTextAnnotatedStringElement)paramObject).l) ? false : (!!q.e(this.m, ((SelectableTextAnnotatedStringElement)paramObject).m))))))))))));
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    int j = this.c.hashCode();
    int k = this.d.hashCode();
    int m = this.e.hashCode();
    l<e0, v> l2 = this.f;
    int i = 0;
    if (l2 != null) {
      b1 = l2.hashCode();
    } else {
      b1 = 0;
    } 
    int n = u.f(this.g);
    int i1 = k.a(this.h);
    int i2 = this.i;
    int i3 = this.j;
    List<d.b<u>> list = this.k;
    if (list != null) {
      b2 = list.hashCode();
    } else {
      b2 = 0;
    } 
    l<List<h>, v> l1 = this.l;
    if (l1 != null) {
      b3 = l1.hashCode();
    } else {
      b3 = 0;
    } 
    h h1 = this.m;
    if (h1 != null) {
      b4 = h1.hashCode();
    } else {
      b4 = 0;
    } 
    s1 s11 = this.n;
    if (s11 != null)
      i = s11.hashCode(); 
    return ((((((((((j * 31 + k) * 31 + m) * 31 + b1) * 31 + n) * 31 + i1) * 31 + i2) * 31 + i3) * 31 + b2) * 31 + b3) * 31 + b4) * 31 + i;
  }
  
  public g s() {
    return new g(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, null);
  }
  
  public void t(g paramg) {
    q.j(paramg, "node");
    paramg.F1(this.c, this.d, this.k, this.j, this.i, this.h, this.e, this.g, this.f, this.l, this.m, this.n);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SelectableTextAnnotatedStringElement(text=");
    stringBuilder.append(this.c);
    stringBuilder.append(", style=");
    stringBuilder.append(this.d);
    stringBuilder.append(", fontFamilyResolver=");
    stringBuilder.append(this.e);
    stringBuilder.append(", onTextLayout=");
    stringBuilder.append(this.f);
    stringBuilder.append(", overflow=");
    stringBuilder.append(u.g(this.g));
    stringBuilder.append(", softWrap=");
    stringBuilder.append(this.h);
    stringBuilder.append(", maxLines=");
    stringBuilder.append(this.i);
    stringBuilder.append(", minLines=");
    stringBuilder.append(this.j);
    stringBuilder.append(", placeholders=");
    stringBuilder.append(this.k);
    stringBuilder.append(", onPlaceholderLayout=");
    stringBuilder.append(this.l);
    stringBuilder.append(", selectionController=");
    stringBuilder.append(this.m);
    stringBuilder.append(", color=");
    stringBuilder.append(this.n);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\text\modifiers\SelectableTextAnnotatedStringElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */