package androidx.compose.foundation;

import androidx.compose.ui.e;
import dk.l;
import ik.j;
import k2.b;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.g0;
import o1.j0;
import o1.k0;
import o1.l0;
import o1.m;
import o1.n;
import o1.y0;
import q.j;
import q1.e0;
import r.q;

final class v extends e.c implements e0 {
  private u F0;
  
  private boolean G0;
  
  private boolean H0;
  
  public v(u paramu, boolean paramBoolean1, boolean paramBoolean2) {
    this.F0 = paramu;
    this.G0 = paramBoolean1;
    this.H0 = paramBoolean2;
  }
  
  public final u A1() {
    return this.F0;
  }
  
  public final boolean B1() {
    return this.G0;
  }
  
  public final boolean C1() {
    return this.H0;
  }
  
  public final void D1(boolean paramBoolean) {
    this.G0 = paramBoolean;
  }
  
  public final void E1(u paramu) {
    q.j(paramu, "<set-?>");
    this.F0 = paramu;
  }
  
  public final void F1(boolean paramBoolean) {
    this.H0 = paramBoolean;
  }
  
  public j0 c(l0 paraml0, g0 paramg0, long paramLong) {
    q q;
    q.j(paraml0, "$this$measure");
    q.j(paramg0, "measurable");
    if (this.H0) {
      q = q.s0;
    } else {
      q = q.t0;
    } 
    j.a(paramLong, q);
    if (this.H0) {
      i = Integer.MAX_VALUE;
    } else {
      i = b.m(paramLong);
    } 
    if (this.H0) {
      j = b.n(paramLong);
    } else {
      j = Integer.MAX_VALUE;
    } 
    y0 y0 = paramg0.Q(b.e(paramLong, 0, j, 0, i, 5, null));
    int k = j.g(y0.N0(), b.n(paramLong));
    int m = j.g(y0.p0(), b.m(paramLong));
    int i = y0.p0() - m;
    int j = y0.N0();
    if (!this.H0)
      i = j - k; 
    this.F0.i(i);
    u u1 = this.F0;
    if (this.H0) {
      j = m;
    } else {
      j = k;
    } 
    u1.k(j);
    return k0.b(paraml0, k, m, null, new a(this, i, y0), 4, null);
  }
  
  public int d(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    return this.H0 ? paramm.N(2147483647) : paramm.N(paramInt);
  }
  
  public int j(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    return this.H0 ? paramm.C(paramInt) : paramm.C(2147483647);
  }
  
  public int o(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    return this.H0 ? paramm.d(paramInt) : paramm.d(2147483647);
  }
  
  public int u(n paramn, m paramm, int paramInt) {
    q.j(paramn, "<this>");
    q.j(paramm, "measurable");
    return this.H0 ? paramm.K(2147483647) : paramm.K(paramInt);
  }
  
  static final class a extends r implements l<y0.a, rj.v> {
    a(v param1v, int param1Int, y0 param1y0) {
      super(1);
    }
    
    public final void invoke(y0.a param1a) {
      int j;
      q.j(param1a, "$this$layout");
      int i = j.k(this.s0.A1().h(), 0, this.t0);
      if (this.s0.B1()) {
        i -= this.t0;
      } else {
        i = -i;
      } 
      if (this.s0.C1()) {
        j = 0;
      } else {
        j = i;
      } 
      if (!this.s0.C1())
        i = 0; 
      y0.a.v(param1a, this.u0, j, i, 0.0F, null, 12, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */