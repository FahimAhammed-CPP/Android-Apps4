package androidx.compose.foundation;

import androidx.compose.foundation.gestures.d;
import dk.p;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l1.l0;
import l1.r;
import l1.t;
import l1.u0;
import l1.v0;
import p1.c;
import p1.g;
import p1.h;
import p1.i;
import q.l;
import q1.h;
import q1.j;
import q1.l;
import q1.n1;
import q1.o1;
import r.s;
import rj.n;
import rj.v;
import t.m;
import vj.d;

abstract class b extends l implements i, h, o1 {
  private boolean H0;
  
  private m I0;
  
  private dk.a<v> J0;
  
  private final a.a K0;
  
  private final dk.a<Boolean> L0;
  
  private final v0 M0;
  
  private b(boolean paramBoolean, m paramm, dk.a<v> parama, a.a parama1) {
    this.H0 = paramBoolean;
    this.I0 = paramm;
    this.J0 = parama;
    this.K0 = parama1;
    this.L0 = new a(this);
    this.M0 = (v0)A1((j)u0.a(new b(this, null)));
  }
  
  public void C(r paramr, t paramt, long paramLong) {
    q.j(paramr, "pointerEvent");
    q.j(paramt, "pass");
    this.M0.C(paramr, paramt, paramLong);
  }
  
  protected final boolean F1() {
    return this.H0;
  }
  
  protected final a.a G1() {
    return this.K0;
  }
  
  protected final dk.a<v> H1() {
    return this.J0;
  }
  
  protected final Object I1(s params, long paramLong, d<? super v> paramd) {
    m m1 = this.I0;
    if (m1 != null) {
      Object object = e.a(params, paramLong, m1, this.K0, this.L0, paramd);
      if (object == wj.b.d())
        return object; 
    } 
    return v.a;
  }
  
  protected abstract Object J1(l0 paraml0, d<? super v> paramd);
  
  protected final void K1(boolean paramBoolean) {
    this.H0 = paramBoolean;
  }
  
  protected final void L1(m paramm) {
    this.I0 = paramm;
  }
  
  protected final void M1(dk.a<v> parama) {
    q.j(parama, "<set-?>");
    this.J0 = parama;
  }
  
  protected final void d0() {
    this.M0.d0();
  }
  
  public void q0() {
    this.M0.q0();
  }
  
  static final class a extends r implements dk.a<Boolean> {
    a(b param1b) {
      super(0);
    }
    
    public final Boolean invoke() {
      if (((Boolean)this.s0.f((c)d.g())).booleanValue() || l.c(this.s0)) {
        boolean bool1 = true;
        return Boolean.valueOf(bool1);
      } 
      boolean bool = false;
      return Boolean.valueOf(bool);
    }
  }
  
  @f(c = "androidx.compose.foundation.AbstractClickablePointerInputNode$pointerInputNode$1", f = "Clickable.kt", l = {846}, m = "invokeSuspend")
  static final class b extends l implements p<l0, d<? super v>, Object> {
    int s0;
    
    b(b param1b, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final Object a(l0 param1l0, d<? super v> param1d) {
      return ((b)create(param1l0, param1d)).invokeSuspend(v.a);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      b b1 = new b(this.u0, (d)param1d);
      b1.t0 = param1Object;
      return (d<v>)b1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0;
        b b1 = this.u0;
        this.s0 = 1;
        if (b1.J1((l0)param1Object, (d<? super v>)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */