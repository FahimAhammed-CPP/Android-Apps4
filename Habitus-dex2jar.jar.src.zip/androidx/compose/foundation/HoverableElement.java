package androidx.compose.foundation;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q1.u0;
import t.m;

final class HoverableElement extends u0<s> {
  private final m c;
  
  public HoverableElement(m paramm) {
    this.c = paramm;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof HoverableElement) ? false : (!!q.e(((HoverableElement)paramObject).c, this.c)));
  }
  
  public int hashCode() {
    return this.c.hashCode() * 31;
  }
  
  public s s() {
    return new s(this.c);
  }
  
  public void t(s params) {
    q.j(params, "node");
    params.D1(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\HoverableElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */