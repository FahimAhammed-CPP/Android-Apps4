package androidx.compose.foundation;

import androidx.compose.ui.e;
import kotlin.jvm.internal.h0;
import kotlin.jvm.internal.r;
import l0.t;
import o1.w0;
import o1.x0;
import q1.c1;
import q1.d1;
import q1.h;
import q1.i;
import rj.v;

final class n extends e.c implements h, c1 {
  private w0.a F0;
  
  private boolean G0;
  
  private final w0 A1() {
    h0<w0> h0 = new h0();
    d1.a(this, new a(h0, this));
    return (w0)h0.s0;
  }
  
  public final void B1(boolean paramBoolean) {
    w0.a a1 = null;
    if (paramBoolean) {
      w0 w0 = A1();
      if (w0 != null)
        a1 = w0.a(); 
      this.F0 = a1;
    } else {
      a1 = this.F0;
      if (a1 != null)
        a1.release(); 
      this.F0 = null;
    } 
    this.G0 = paramBoolean;
  }
  
  public void U() {
    w0 w0 = A1();
    if (this.G0) {
      w0.a a1 = this.F0;
      if (a1 != null)
        a1.release(); 
      if (w0 != null) {
        w0.a a2 = w0.a();
      } else {
        w0 = null;
      } 
      this.F0 = (w0.a)w0;
    } 
  }
  
  public void m1() {
    w0.a a1 = this.F0;
    if (a1 != null)
      a1.release(); 
    this.F0 = null;
  }
  
  static final class a extends r implements dk.a<v> {
    a(h0<w0> param1h0, n param1n) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.s0 = i.a(this.t0, (t)x0.a());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */