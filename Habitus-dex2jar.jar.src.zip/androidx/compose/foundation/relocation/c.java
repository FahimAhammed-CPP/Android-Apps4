package androidx.compose.foundation.relocation;

import a0.d;
import androidx.compose.ui.e;
import kotlin.jvm.internal.q;

public final class c {
  public static final d a() {
    return new b();
  }
  
  public static final e b(e parame, d paramd) {
    q.j(parame, "<this>");
    q.j(paramd, "bringIntoViewRequester");
    return parame.then((e)new BringIntoViewRequesterElement(paramd));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\relocation\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */