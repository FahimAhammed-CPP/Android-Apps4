package androidx.compose.foundation.relocation;

import a0.b;
import a0.f;
import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import o1.s;
import p1.c;
import p1.g;
import p1.h;
import p1.i;
import q1.b0;
import q1.c0;
import q1.h;

public abstract class a extends e.c implements i, c0, h {
  private final b F0 = f.b(this);
  
  private s G0;
  
  private final b B1() {
    return (b)f((c)a0.a.a());
  }
  
  protected final s A1() {
    s s1 = this.G0;
    return (s1 != null && s1.p()) ? s1 : null;
  }
  
  protected final b C1() {
    b b2 = B1();
    b b1 = b2;
    if (b2 == null)
      b1 = this.F0; 
    return b1;
  }
  
  public void r(s params) {
    q.j(params, "coordinates");
    this.G0 = params;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\relocation\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */