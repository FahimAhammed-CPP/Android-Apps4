package androidx.compose.foundation.relocation;

import a0.b;
import a0.e;
import a1.h;
import dk.p;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.n;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Job;
import o1.s;
import p1.g;
import p1.j;
import rj.n;
import rj.r;
import rj.v;
import vj.d;

final class f extends a implements b {
  private e H0;
  
  private final g I0;
  
  public f(e parame) {
    this.H0 = parame;
    this.I0 = j.b(r.a(a0.a.a(), this));
  }
  
  private static final h E1(f paramf, s params, dk.a<h> parama) {
    s s1 = paramf.A1();
    if (s1 == null)
      return null; 
    if (!params.p())
      params = null; 
    if (params == null)
      return null; 
    h h = (h)parama.invoke();
    return (h == null) ? null : e.a(s1, params, h);
  }
  
  public final e F1() {
    return this.H0;
  }
  
  public final void G1(e parame) {
    q.j(parame, "<set-?>");
    this.H0 = parame;
  }
  
  public g K() {
    return this.I0;
  }
  
  public Object S0(s params, dk.a<h> parama, d<? super v> paramd) {
    Object object = CoroutineScopeKt.coroutineScope(new a(this, params, parama, new b(this, params, parama), null), paramd);
    return (object == wj.b.d()) ? object : v.a;
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.relocation.BringIntoViewResponderNode$bringChildIntoView$2", f = "BringIntoViewResponder.kt", l = {}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, d<? super Job>, Object> {
    int s0;
    
    a(f param1f, s param1s, dk.a<h> param1a1, dk.a<h> param1a2, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.u0, this.v0, this.w0, this.x0, (d)param1d);
      a1.t0 = param1Object;
      return (d<v>)a1;
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super Job> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      wj.b.d();
      if (this.s0 == 0) {
        n.b(param1Object);
        param1Object = this.t0;
        BuildersKt.launch$default((CoroutineScope)param1Object, null, null, new a(this.u0, this.v0, this.w0, null), 3, null);
        return BuildersKt.launch$default((CoroutineScope)param1Object, null, null, new b(this.u0, this.x0, null), 3, null);
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.relocation.BringIntoViewResponderNode$bringChildIntoView$2$1", f = "BringIntoViewResponder.kt", l = {170}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      a(f param2f, s param2s, dk.a<h> param2a, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<v> create(Object param2Object, d<?> param2d) {
        return (d<v>)new a(this.t0, this.u0, this.v0, (d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, d<? super v> param2d) {
        return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1) {
            n.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param2Object);
          param2Object = this.t0.F1();
          a a1 = new a(this.t0, this.u0, this.v0);
          this.s0 = 1;
          if (param2Object.a(a1, (d)this) == object)
            return object; 
        } 
        return v.a;
      }
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.relocation.BringIntoViewResponderNode$bringChildIntoView$2$2", f = "BringIntoViewResponder.kt", l = {179}, m = "invokeSuspend")
    static final class b extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      b(f param2f, dk.a<h> param2a, d<? super b> param2d) {
        super(2, param2d);
      }
      
      public final d<v> create(Object param2Object, d<?> param2d) {
        return (d<v>)new b(this.t0, this.u0, (d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, d<? super v> param2d) {
        return ((b)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1) {
            n.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param2Object);
          param2Object = this.t0.C1();
          s s = this.t0.A1();
          if (s == null)
            return v.a; 
          dk.a<h> a1 = this.u0;
          this.s0 = 1;
          if (param2Object.S0(s, a1, (d)this) == object)
            return object; 
        } 
        return v.a;
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.relocation.BringIntoViewResponderNode$bringChildIntoView$2$1", f = "BringIntoViewResponder.kt", l = {170}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    a(f param1f, s param1s, dk.a<h> param1a, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      return (d<v>)new a(this.t0, this.u0, this.v0, (d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0.F1();
        a a1 = new a(this.t0, this.u0, this.v0);
        this.s0 = 1;
        if (param1Object.a(a1, (d)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.relocation.BringIntoViewResponderNode$bringChildIntoView$2$2", f = "BringIntoViewResponder.kt", l = {179}, m = "invokeSuspend")
  static final class b extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    b(f param1f, dk.a<h> param1a, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      return (d<v>)new b(this.t0, this.u0, (d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((b)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0.C1();
        s s = this.t0.A1();
        if (s == null)
          return v.a; 
        dk.a<h> a1 = this.u0;
        this.s0 = 1;
        if (param1Object.S0(s, a1, (d)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
  
  static final class b extends r implements dk.a<h> {
    b(f param1f, s param1s, dk.a<h> param1a) {
      super(0);
    }
    
    public final h d() {
      h h = f.D1(this.s0, this.t0, this.u0);
      return (h != null) ? this.s0.F1().b(h) : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\relocation\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */