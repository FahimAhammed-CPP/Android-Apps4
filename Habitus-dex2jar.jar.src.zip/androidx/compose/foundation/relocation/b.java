package androidx.compose.foundation.relocation;

import a0.d;
import a1.h;
import kotlin.coroutines.jvm.internal.d;
import kotlin.coroutines.jvm.internal.f;
import m0.f;
import rj.v;
import vj.d;

final class b implements d {
  private final f<d> a = new f((Object[])new d[16], 0);
  
  public Object a(h paramh, d<? super v> paramd) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof androidx/compose/foundation/relocation/b$a
    //   4: ifeq -> 41
    //   7: aload_2
    //   8: checkcast androidx/compose/foundation/relocation/b$a
    //   11: astore #7
    //   13: aload #7
    //   15: getfield y0 : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc -2147483648
    //   22: iand
    //   23: ifeq -> 41
    //   26: aload #7
    //   28: iload_3
    //   29: ldc -2147483648
    //   31: iadd
    //   32: putfield y0 : I
    //   35: aload #7
    //   37: astore_2
    //   38: goto -> 51
    //   41: new androidx/compose/foundation/relocation/b$a
    //   44: dup
    //   45: aload_0
    //   46: aload_2
    //   47: invokespecial <init> : (Landroidx/compose/foundation/relocation/b;Lvj/d;)V
    //   50: astore_2
    //   51: aload_2
    //   52: getfield w0 : Ljava/lang/Object;
    //   55: astore #7
    //   57: invokestatic d : ()Ljava/lang/Object;
    //   60: astore #10
    //   62: aload_2
    //   63: getfield y0 : I
    //   66: istore_3
    //   67: iload_3
    //   68: ifeq -> 123
    //   71: iload_3
    //   72: iconst_1
    //   73: if_icmpne -> 113
    //   76: aload_2
    //   77: getfield v0 : I
    //   80: istore_3
    //   81: aload_2
    //   82: getfield u0 : I
    //   85: istore #4
    //   87: aload_2
    //   88: getfield t0 : Ljava/lang/Object;
    //   91: checkcast [Ljava/lang/Object;
    //   94: astore #8
    //   96: aload_2
    //   97: getfield s0 : Ljava/lang/Object;
    //   100: checkcast a1/h
    //   103: astore #9
    //   105: aload #7
    //   107: invokestatic b : (Ljava/lang/Object;)V
    //   110: goto -> 225
    //   113: new java/lang/IllegalStateException
    //   116: dup
    //   117: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   119: invokespecial <init> : (Ljava/lang/String;)V
    //   122: athrow
    //   123: aload #7
    //   125: invokestatic b : (Ljava/lang/Object;)V
    //   128: aload_0
    //   129: getfield a : Lm0/f;
    //   132: astore #7
    //   134: aload #7
    //   136: invokevirtual s : ()I
    //   139: istore #5
    //   141: iload #5
    //   143: ifle -> 250
    //   146: aload #7
    //   148: invokevirtual r : ()[Ljava/lang/Object;
    //   151: astore #8
    //   153: iconst_0
    //   154: istore_3
    //   155: aload_2
    //   156: astore #7
    //   158: aload #8
    //   160: iload_3
    //   161: aaload
    //   162: checkcast androidx/compose/foundation/relocation/d
    //   165: astore #11
    //   167: aload #7
    //   169: aload_1
    //   170: putfield s0 : Ljava/lang/Object;
    //   173: aload #7
    //   175: aload #8
    //   177: putfield t0 : Ljava/lang/Object;
    //   180: aload #7
    //   182: iload #5
    //   184: putfield u0 : I
    //   187: aload #7
    //   189: iload_3
    //   190: putfield v0 : I
    //   193: aload #7
    //   195: iconst_1
    //   196: putfield y0 : I
    //   199: aload #7
    //   201: astore_2
    //   202: iload #5
    //   204: istore #4
    //   206: aload_1
    //   207: astore #9
    //   209: aload #11
    //   211: aload_1
    //   212: aload #7
    //   214: invokevirtual D1 : (La1/h;Lvj/d;)Ljava/lang/Object;
    //   217: aload #10
    //   219: if_acmpne -> 225
    //   222: aload #10
    //   224: areturn
    //   225: iload_3
    //   226: iconst_1
    //   227: iadd
    //   228: istore #6
    //   230: aload_2
    //   231: astore #7
    //   233: iload #4
    //   235: istore #5
    //   237: iload #6
    //   239: istore_3
    //   240: aload #9
    //   242: astore_1
    //   243: iload #6
    //   245: iload #4
    //   247: if_icmplt -> 158
    //   250: getstatic rj/v.a : Lrj/v;
    //   253: areturn
  }
  
  public final f<d> b() {
    return this.a;
  }
  
  @f(c = "androidx.compose.foundation.relocation.BringIntoViewRequesterImpl", f = "BringIntoViewRequester.kt", l = {110}, m = "bringIntoView")
  static final class a extends d {
    Object s0;
    
    Object t0;
    
    int u0;
    
    int v0;
    
    int y0;
    
    a(b param1b, d<? super a> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.w0 = param1Object;
      this.y0 |= Integer.MIN_VALUE;
      return this.x0.a(null, (d<? super v>)this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\relocation\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */