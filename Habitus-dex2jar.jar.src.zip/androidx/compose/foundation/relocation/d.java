package androidx.compose.foundation.relocation;

import a0.b;
import a1.h;
import a1.m;
import k2.q;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.s;
import rj.v;
import wj.b;

public final class d extends a {
  private a0.d H0;
  
  public d(a0.d paramd) {
    this.H0 = paramd;
  }
  
  private final void E1() {
    a0.d d1 = this.H0;
    if (d1 instanceof b) {
      q.h(d1, "null cannot be cast to non-null type androidx.compose.foundation.relocation.BringIntoViewRequesterImpl");
      ((b)d1).b().z(this);
    } 
  }
  
  public final Object D1(h paramh, vj.d<? super v> paramd) {
    b b = C1();
    s s = A1();
    if (s == null)
      return v.a; 
    Object object = b.S0(s, new a(paramh, this), paramd);
    return (object == b.d()) ? object : v.a;
  }
  
  public final void F1(a0.d paramd) {
    q.j(paramd, "requester");
    E1();
    if (paramd instanceof b)
      ((b)paramd).b().d(this); 
    this.H0 = paramd;
  }
  
  public void k1() {
    F1(this.H0);
  }
  
  public void l1() {
    E1();
  }
  
  static final class a extends r implements dk.a<h> {
    a(h param1h, d param1d) {
      super(0);
    }
    
    public final h d() {
      s s;
      h h2 = this.s0;
      h h1 = h2;
      if (h2 == null) {
        s = this.t0.A1();
        if (s != null)
          return m.c(q.c(s.a())); 
        s = null;
      } 
      return (h)s;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\relocation\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */