package androidx.compose.foundation.relocation;

import a1.h;
import kotlin.jvm.internal.q;
import o1.s;

public final class e {
  public static final androidx.compose.ui.e b(androidx.compose.ui.e parame, a0.e parame1) {
    q.j(parame, "<this>");
    q.j(parame1, "responder");
    return parame.then((androidx.compose.ui.e)new BringIntoViewResponderElement(parame1));
  }
  
  private static final h c(s params1, s params2, h paramh) {
    return paramh.r(params1.G(params2, false).m());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\relocation\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */