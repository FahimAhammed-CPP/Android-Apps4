package androidx.compose.foundation.relocation;

import a0.e;
import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q1.u0;

final class BringIntoViewResponderElement extends u0<f> {
  private final e c;
  
  public BringIntoViewResponderElement(e parame) {
    this.c = parame;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject || (paramObject instanceof BringIntoViewResponderElement && q.e(this.c, ((BringIntoViewResponderElement)paramObject).c)));
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public f s() {
    return new f(this.c);
  }
  
  public void t(f paramf) {
    q.j(paramf, "node");
    paramf.G1(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\relocation\BringIntoViewResponderElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */