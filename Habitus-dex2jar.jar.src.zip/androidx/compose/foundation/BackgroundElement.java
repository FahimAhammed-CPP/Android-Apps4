package androidx.compose.foundation;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.l1;
import b1.e1;
import b1.p1;
import b1.r4;
import dk.l;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q1.u0;
import rj.v;

final class BackgroundElement extends u0<d> {
  private final long c;
  
  private final e1 d;
  
  private final float e;
  
  private final r4 f;
  
  private final l<l1, v> g;
  
  private BackgroundElement(long paramLong, e1 parame1, float paramFloat, r4 paramr4, l<? super l1, v> paraml) {
    this.c = paramLong;
    this.d = parame1;
    this.e = paramFloat;
    this.f = paramr4;
    this.g = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof BackgroundElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    boolean bool2 = false;
    if (paramObject == null)
      return false; 
    boolean bool1 = bool2;
    if (p1.q(this.c, ((BackgroundElement)paramObject).c)) {
      bool1 = bool2;
      if (q.e(this.d, ((BackgroundElement)paramObject).d)) {
        boolean bool;
        if (this.e == ((BackgroundElement)paramObject).e) {
          bool = true;
        } else {
          bool = false;
        } 
        bool1 = bool2;
        if (bool) {
          bool1 = bool2;
          if (q.e(this.f, ((BackgroundElement)paramObject).f))
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  public int hashCode() {
    byte b;
    int i = p1.w(this.c);
    e1 e11 = this.d;
    if (e11 != null) {
      b = e11.hashCode();
    } else {
      b = 0;
    } 
    return ((i * 31 + b) * 31 + Float.floatToIntBits(this.e)) * 31 + this.f.hashCode();
  }
  
  public d s() {
    return new d(this.c, this.d, this.e, this.f, null);
  }
  
  public void t(d paramd) {
    q.j(paramd, "node");
    paramd.D1(this.c);
    paramd.C1(this.d);
    paramd.g(this.e);
    paramd.o0(this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\BackgroundElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */