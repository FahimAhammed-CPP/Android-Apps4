package androidx.compose.foundation;

import androidx.compose.ui.e;
import b1.e1;
import b1.r4;
import k2.h;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q.f;
import q1.u0;

public final class BorderModifierNodeElement extends u0<f> {
  private final float c;
  
  private final e1 d;
  
  private final r4 e;
  
  private BorderModifierNodeElement(float paramFloat, e1 parame1, r4 paramr4) {
    this.c = paramFloat;
    this.d = parame1;
    this.e = paramr4;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof BorderModifierNodeElement))
      return false; 
    paramObject = paramObject;
    return !h.m(this.c, ((BorderModifierNodeElement)paramObject).c) ? false : (!q.e(this.d, ((BorderModifierNodeElement)paramObject).d) ? false : (!!q.e(this.e, ((BorderModifierNodeElement)paramObject).e)));
  }
  
  public int hashCode() {
    return (h.o(this.c) * 31 + this.d.hashCode()) * 31 + this.e.hashCode();
  }
  
  public f s() {
    return new f(this.c, this.d, this.e, null);
  }
  
  public void t(f paramf) {
    q.j(paramf, "node");
    paramf.N1(this.c);
    paramf.M1(this.d);
    paramf.o0(this.e);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("BorderModifierNodeElement(width=");
    stringBuilder.append(h.q(this.c));
    stringBuilder.append(", brush=");
    stringBuilder.append(this.d);
    stringBuilder.append(", shape=");
    stringBuilder.append(this.e);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\BorderModifierNodeElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */