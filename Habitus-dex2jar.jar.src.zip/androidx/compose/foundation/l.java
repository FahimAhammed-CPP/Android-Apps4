package androidx.compose.foundation;

import androidx.compose.ui.e;
import dk.p;
import kotlin.coroutines.jvm.internal.f;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import rj.n;
import rj.v;
import t.d;
import t.e;
import t.j;
import t.m;
import vj.d;
import wj.b;

final class l extends e.c {
  private m F0;
  
  private d G0;
  
  public l(m paramm) {
    this.F0 = paramm;
  }
  
  private final void A1() {
    m m1 = this.F0;
    if (m1 != null) {
      d d1 = this.G0;
      if (d1 != null)
        m1.a((j)new e(d1)); 
    } 
    this.G0 = null;
  }
  
  private final void B1(m paramm, j paramj) {
    if (h1()) {
      BuildersKt.launch$default(a1(), null, null, new a(paramm, paramj, null), 3, null);
      return;
    } 
    paramm.a(paramj);
  }
  
  public final void C1(boolean paramBoolean) {
    m m1 = this.F0;
    if (m1 != null) {
      if (paramBoolean) {
        d d2 = this.G0;
        if (d2 != null) {
          B1(m1, (j)new e(d2));
          this.G0 = null;
        } 
        d2 = new d();
        B1(m1, (j)d2);
        this.G0 = d2;
        return;
      } 
      d d1 = this.G0;
      if (d1 != null) {
        B1(m1, (j)new e(d1));
        this.G0 = null;
      } 
    } 
  }
  
  public final void D1(m paramm) {
    if (!q.e(this.F0, paramm)) {
      A1();
      this.F0 = paramm;
    } 
  }
  
  @f(c = "androidx.compose.foundation.FocusableInteractionNode$emitWithFallback$1", f = "Focusable.kt", l = {310}, m = "invokeSuspend")
  static final class a extends kotlin.coroutines.jvm.internal.l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    a(m param1m, j param1j, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      return (d<v>)new a(this.t0, this.u0, (d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0;
        j j1 = this.u0;
        this.s0 = 1;
        if (param1Object.c(j1, (d)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */