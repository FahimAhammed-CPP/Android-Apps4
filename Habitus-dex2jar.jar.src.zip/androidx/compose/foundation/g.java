package androidx.compose.foundation;

import a1.f;
import dk.l;
import dk.q;
import k2.l;
import k2.q;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l1.l0;
import r.b0;
import r.s;
import rj.n;
import rj.v;
import t.m;
import vj.d;

final class g extends b {
  public g(boolean paramBoolean, m paramm, dk.a<v> parama, a.a parama1) {
    super(paramBoolean, paramm, parama, parama1, null);
  }
  
  protected Object J1(l0 paraml0, d<? super v> paramd) {
    a.a a = G1();
    long l = q.b(paraml0.a());
    a.d(a1.g.a(l.j(l), l.k(l)));
    Object object = b0.h(paraml0, new a(this, null), new b(this), paramd);
    return (object == wj.b.d()) ? object : v.a;
  }
  
  public final void N1(boolean paramBoolean, m paramm, dk.a<v> parama) {
    q.j(paramm, "interactionSource");
    q.j(parama, "onClick");
    K1(paramBoolean);
    M1(parama);
    L1(paramm);
  }
  
  @f(c = "androidx.compose.foundation.ClickablePointerInputNode$pointerInput$2", f = "Clickable.kt", l = {892}, m = "invokeSuspend")
  static final class a extends l implements q<s, f, d<? super v>, Object> {
    int s0;
    
    a(g param1g, d<? super a> param1d) {
      super(3, param1d);
    }
    
    public final Object a(s param1s, long param1Long, d<? super v> param1d) {
      a a1 = new a(this.v0, (d)param1d);
      a1.t0 = param1s;
      a1.u0 = param1Long;
      return a1.invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0;
        long l1 = this.u0;
        if (this.v0.F1()) {
          g g1 = this.v0;
          this.s0 = 1;
          if (g1.I1((s)param1Object, l1, (d<? super v>)this) == object)
            return object; 
        } 
      } 
      return v.a;
    }
  }
  
  static final class b extends r implements l<f, v> {
    b(g param1g) {
      super(1);
    }
    
    public final void a(long param1Long) {
      if (this.s0.F1())
        this.s0.H1().invoke(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */