package androidx.compose.foundation;

import a0.c;
import a0.d;
import androidx.compose.foundation.relocation.c;
import androidx.compose.foundation.relocation.d;
import dk.p;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import o1.s;
import q.q;
import q1.b0;
import q1.c0;
import q1.j;
import q1.l;
import q1.s1;
import q1.t1;
import q1.u;
import q1.u1;
import rj.n;
import rj.v;
import u1.x;
import vj.d;
import wj.b;
import z0.c;
import z0.o;

final class m extends l implements c, c0, t1, u {
  private o H0;
  
  private final o I0 = (o)A1((j)new o());
  
  private final l J0;
  
  private final n K0;
  
  private final q L0;
  
  private final d M0;
  
  private final d N0;
  
  public m(t.m paramm) {
    this.J0 = (l)A1((j)new l(paramm));
    this.K0 = (n)A1((j)new n());
    this.L0 = (q)A1((j)new q());
    d d1 = c.a();
    this.M0 = d1;
    this.N0 = (d)A1((j)new d(d1));
  }
  
  public final void G1(t.m paramm) {
    this.J0.D1(paramm);
  }
  
  public void I0(x paramx) {
    q.j(paramx, "<this>");
    this.I0.I0(paramx);
  }
  
  public void p(s params) {
    q.j(params, "coordinates");
    this.L0.p(params);
  }
  
  public void r(s params) {
    q.j(params, "coordinates");
    this.N0.r(params);
  }
  
  public void x(o paramo) {
    q.j(paramo, "focusState");
    if (!q.e(this.H0, paramo)) {
      boolean bool = paramo.d();
      if (bool)
        BuildersKt.launch$default(a1(), null, null, new a(this, null), 3, null); 
      if (h1())
        u1.b(this); 
      this.J0.C1(bool);
      this.L0.C1(bool);
      this.K0.B1(bool);
      this.I0.A1(bool);
      this.H0 = paramo;
    } 
  }
  
  @f(c = "androidx.compose.foundation.FocusableNode$onFocusEvent$1", f = "Focusable.kt", l = {237}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    a(m param1m, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      return (d<v>)new a(this.t0, (d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = m.F1(this.t0);
        this.s0 = 1;
        if (c.a((d)param1Object, null, (d)this, 1, null) == object)
          return object; 
      } 
      return v.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */