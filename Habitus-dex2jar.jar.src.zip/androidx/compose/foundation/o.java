package androidx.compose.foundation;

import androidx.compose.ui.e;
import androidx.compose.ui.focus.m;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import q1.s1;
import q1.t1;
import u1.l;
import u1.v;
import u1.x;
import z0.n;

final class o extends e.c implements t1, n {
  private l F0 = new l();
  
  private boolean G0;
  
  public final void A1(boolean paramBoolean) {
    this.G0 = paramBoolean;
  }
  
  public void I0(x paramx) {
    q.j(paramx, "<this>");
    v.S(paramx, this.G0);
    v.I(paramx, null, new a(this), 1, null);
  }
  
  static final class a extends r implements dk.a<Boolean> {
    a(o param1o) {
      super(0);
    }
    
    public final Boolean invoke() {
      return Boolean.valueOf(m.a(this.s0));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */