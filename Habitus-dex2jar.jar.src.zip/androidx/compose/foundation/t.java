package androidx.compose.foundation;

import androidx.compose.foundation.gestures.d;
import androidx.compose.ui.e;
import androidx.compose.ui.platform.j1;
import androidx.compose.ui.platform.l1;
import androidx.compose.ui.platform.y0;
import dk.l;
import dk.p;
import dk.q;
import k2.r;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import l0.h0;
import l0.l;
import l0.n;
import l0.x;
import q.g0;
import q.h0;
import q.m;
import r.o;
import r.q;
import r.v;
import r.x;
import r.z;
import rj.n;
import rj.v;
import t.m;
import u1.j;
import u1.o;
import u1.v;
import u1.x;
import vj.d;
import vj.g;
import vj.h;

public final class t {
  public static final e a(e parame, u paramu, boolean paramBoolean1, o paramo, boolean paramBoolean2) {
    q.j(parame, "<this>");
    q.j(paramu, "state");
    return d(parame, paramu, paramBoolean2, paramo, paramBoolean1, false);
  }
  
  public static final u c(int paramInt1, l paraml, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_1
    //   1: ldc -1464256199
    //   3: invokeinterface x : (I)V
    //   8: iload_3
    //   9: iconst_1
    //   10: iand
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: istore_0
    //   16: invokestatic K : ()Z
    //   19: ifeq -> 31
    //   22: ldc -1464256199
    //   24: iload_2
    //   25: iconst_m1
    //   26: ldc 'androidx.compose.foundation.rememberScrollState (Scroll.kt:72)'
    //   28: invokestatic V : (IIILjava/lang/String;)V
    //   31: getstatic androidx/compose/foundation/u.i : Landroidx/compose/foundation/u$c;
    //   34: invokevirtual a : ()Lt0/i;
    //   37: astore #7
    //   39: aload_1
    //   40: ldc 1157296644
    //   42: invokeinterface x : (I)V
    //   47: aload_1
    //   48: iload_0
    //   49: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   52: invokeinterface R : (Ljava/lang/Object;)Z
    //   57: istore #4
    //   59: aload_1
    //   60: invokeinterface y : ()Ljava/lang/Object;
    //   65: astore #6
    //   67: iload #4
    //   69: ifne -> 87
    //   72: aload #6
    //   74: astore #5
    //   76: aload #6
    //   78: getstatic l0/l.a : Ll0/l$a;
    //   81: invokevirtual a : ()Ljava/lang/Object;
    //   84: if_acmpne -> 105
    //   87: new androidx/compose/foundation/t$a
    //   90: dup
    //   91: iload_0
    //   92: invokespecial <init> : (I)V
    //   95: astore #5
    //   97: aload_1
    //   98: aload #5
    //   100: invokeinterface r : (Ljava/lang/Object;)V
    //   105: aload_1
    //   106: invokeinterface Q : ()V
    //   111: aload #5
    //   113: checkcast dk/a
    //   116: astore #5
    //   118: iconst_0
    //   119: anewarray java/lang/Object
    //   122: aload #7
    //   124: aconst_null
    //   125: aload #5
    //   127: aload_1
    //   128: bipush #72
    //   130: iconst_4
    //   131: invokestatic b : ([Ljava/lang/Object;Lt0/i;Ljava/lang/String;Ldk/a;Ll0/l;II)Ljava/lang/Object;
    //   134: checkcast androidx/compose/foundation/u
    //   137: astore #5
    //   139: invokestatic K : ()Z
    //   142: ifeq -> 148
    //   145: invokestatic U : ()V
    //   148: aload_1
    //   149: invokeinterface Q : ()V
    //   154: aload #5
    //   156: areturn
  }
  
  private static final e d(e parame, u paramu, boolean paramBoolean1, o paramo, boolean paramBoolean2, boolean paramBoolean3) {
    l l;
    if (j1.c()) {
      l = new b(paramu, paramBoolean1, paramo, paramBoolean2, paramBoolean3);
    } else {
      l = j1.a();
    } 
    return androidx.compose.ui.c.a(parame, l, new c(paramBoolean3, paramBoolean1, paramu, paramBoolean2, paramo));
  }
  
  public static final e e(e parame, u paramu, boolean paramBoolean1, o paramo, boolean paramBoolean2) {
    q.j(parame, "<this>");
    q.j(paramu, "state");
    return d(parame, paramu, paramBoolean2, paramo, paramBoolean1, true);
  }
  
  static final class a extends r implements dk.a<u> {
    a(int param1Int) {
      super(0);
    }
    
    public final u d() {
      return new u(this.s0);
    }
  }
  
  public static final class b extends r implements l<l1, v> {
    public b(u param1u, boolean param1Boolean1, o param1o, boolean param1Boolean2, boolean param1Boolean3) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("scroll");
      param1l1.a().b("state", this.s0);
      param1l1.a().b("reverseScrolling", Boolean.valueOf(this.t0));
      param1l1.a().b("flingBehavior", this.u0);
      param1l1.a().b("isScrollable", Boolean.valueOf(this.v0));
      param1l1.a().b("isVertical", Boolean.valueOf(this.w0));
    }
  }
  
  static final class c extends r implements q<e, l, Integer, e> {
    c(boolean param1Boolean1, boolean param1Boolean2, u param1u, boolean param1Boolean3, o param1o) {
      super(3);
    }
    
    public final e invoke(e param1e, l param1l, int param1Int) {
      q.j(param1e, "$this$composed");
      param1l.x(1478351300);
      if (n.K())
        n.V(1478351300, param1Int, -1, "androidx.compose.foundation.scroll.<anonymous> (Scroll.kt:266)"); 
      x x = x.a;
      g0 g0 = x.b(param1l, 6);
      param1l.x(773894976);
      param1l.x(-492369756);
      Object object2 = param1l.y();
      Object object1 = object2;
      if (object2 == l.a.a()) {
        object1 = new x(h0.h((g)h.s0, param1l));
        param1l.r(object1);
      } 
      param1l.Q();
      object1 = ((x)object1).a();
      param1l.Q();
      e.a a = e.a;
      object2 = o.c((e)a, false, new a(this.t0, this.s0, this.v0, this.u0, (CoroutineScope)object1), 1, null);
      if (this.s0) {
        object1 = q.s0;
      } else {
        object1 = q.t0;
      } 
      boolean bool = x.c((r)param1l.H((l0.t)y0.j()), (q)object1, this.t0);
      m m = this.u0.f();
      e e1 = d.i((e)a, this.u0, (q)object1, g0, this.v0, bool, this.w0, m);
      ScrollingLayoutElement scrollingLayoutElement = new ScrollingLayoutElement(this.u0, this.t0, this.s0);
      object1 = h0.a(m.a((e)object2, (q)object1), g0).then(e1).then((e)scrollingLayoutElement);
      if (n.K())
        n.U(); 
      param1l.Q();
      return (e)object1;
    }
    
    static final class a extends r implements l<x, v> {
      a(boolean param2Boolean1, boolean param2Boolean2, boolean param2Boolean3, u param2u, CoroutineScope param2CoroutineScope) {
        super(1);
      }
      
      public final void invoke(x param2x) {
        q.j(param2x, "$this$semantics");
        v.h0(param2x, true);
        j j = new j(new b(this.v0), new c(this.v0), this.s0);
        if (this.t0) {
          v.i0(param2x, j);
        } else {
          v.T(param2x, j);
        } 
        if (this.u0)
          v.K(param2x, null, new a(this.w0, this.t0, this.v0), 1, null); 
      }
      
      static final class a extends r implements p<Float, Float, Boolean> {
        a(CoroutineScope param3CoroutineScope, boolean param3Boolean, u param3u) {
          super(2);
        }
        
        public final Boolean a(float param3Float1, float param3Float2) {
          BuildersKt.launch$default(this.s0, null, null, new a(this.t0, this.u0, param3Float2, param3Float1, null), 3, null);
          return Boolean.TRUE;
        }
        
        @f(c = "androidx.compose.foundation.ScrollKt$scroll$2$semantics$1$1$1", f = "Scroll.kt", l = {288, 290}, m = "invokeSuspend")
        static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
          int s0;
          
          a(boolean param4Boolean, u param4u, float param4Float1, float param4Float2, d<? super a> param4d) {
            super(2, param4d);
          }
          
          public final d<v> create(Object param4Object, d<?> param4d) {
            return (d<v>)new a(this.t0, this.u0, this.v0, this.w0, (d)param4d);
          }
          
          public final Object invoke(CoroutineScope param4CoroutineScope, d<? super v> param4d) {
            return ((a)create(param4CoroutineScope, param4d)).invokeSuspend(v.a);
          }
          
          public final Object invokeSuspend(Object param4Object) {
            Object object = wj.b.d();
            int i = this.s0;
            if (i != 0) {
              if (i == 1 || i == 2) {
                n.b(param4Object);
                return v.a;
              } 
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
            n.b(param4Object);
            if (this.t0) {
              param4Object = this.u0;
              q.h(param4Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
              float f = this.v0;
              this.s0 = 1;
              if (v.b((z)param4Object, f, null, (d)this, 2, null) == object)
                return object; 
            } else {
              param4Object = this.u0;
              q.h(param4Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
              float f = this.w0;
              this.s0 = 2;
              if (v.b((z)param4Object, f, null, (d)this, 2, null) == object)
                return object; 
            } 
            return v.a;
          }
        }
      }
      
      @f(c = "androidx.compose.foundation.ScrollKt$scroll$2$semantics$1$1$1", f = "Scroll.kt", l = {288, 290}, m = "invokeSuspend")
      static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
        int s0;
        
        a(boolean param3Boolean, u param3u, float param3Float1, float param3Float2, d<? super a> param3d) {
          super(2, param3d);
        }
        
        public final d<v> create(Object param3Object, d<?> param3d) {
          return (d<v>)new a(this.t0, this.u0, this.v0, this.w0, (d)param3d);
        }
        
        public final Object invoke(CoroutineScope param3CoroutineScope, d<? super v> param3d) {
          return ((a)create(param3CoroutineScope, param3d)).invokeSuspend(v.a);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          Object object = wj.b.d();
          int i = this.s0;
          if (i != 0) {
            if (i == 1 || i == 2) {
              n.b(param3Object);
              return v.a;
            } 
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
          n.b(param3Object);
          if (this.t0) {
            param3Object = this.u0;
            q.h(param3Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
            float f = this.v0;
            this.s0 = 1;
            if (v.b((z)param3Object, f, null, (d)this, 2, null) == object)
              return object; 
          } else {
            param3Object = this.u0;
            q.h(param3Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
            float f = this.w0;
            this.s0 = 2;
            if (v.b((z)param3Object, f, null, (d)this, 2, null) == object)
              return object; 
          } 
          return v.a;
        }
      }
      
      static final class b extends r implements dk.a<Float> {
        b(u param3u) {
          super(0);
        }
        
        public final Float d() {
          return Float.valueOf(this.s0.h());
        }
      }
      
      static final class c extends r implements dk.a<Float> {
        c(u param3u) {
          super(0);
        }
        
        public final Float d() {
          return Float.valueOf(this.s0.g());
        }
      }
    }
    
    static final class a extends r implements p<Float, Float, Boolean> {
      a(CoroutineScope param2CoroutineScope, boolean param2Boolean, u param2u) {
        super(2);
      }
      
      public final Boolean a(float param2Float1, float param2Float2) {
        BuildersKt.launch$default(this.s0, null, null, new a(this.t0, this.u0, param2Float2, param2Float1, null), 3, null);
        return Boolean.TRUE;
      }
      
      @f(c = "androidx.compose.foundation.ScrollKt$scroll$2$semantics$1$1$1", f = "Scroll.kt", l = {288, 290}, m = "invokeSuspend")
      static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
        int s0;
        
        a(boolean param4Boolean, u param4u, float param4Float1, float param4Float2, d<? super a> param4d) {
          super(2, param4d);
        }
        
        public final d<v> create(Object param4Object, d<?> param4d) {
          return (d<v>)new a(this.t0, this.u0, this.v0, this.w0, (d)param4d);
        }
        
        public final Object invoke(CoroutineScope param4CoroutineScope, d<? super v> param4d) {
          return ((a)create(param4CoroutineScope, param4d)).invokeSuspend(v.a);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          Object object = wj.b.d();
          int i = this.s0;
          if (i != 0) {
            if (i == 1 || i == 2) {
              n.b(param4Object);
              return v.a;
            } 
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
          n.b(param4Object);
          if (this.t0) {
            param4Object = this.u0;
            q.h(param4Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
            float f = this.v0;
            this.s0 = 1;
            if (v.b((z)param4Object, f, null, (d)this, 2, null) == object)
              return object; 
          } else {
            param4Object = this.u0;
            q.h(param4Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
            float f = this.w0;
            this.s0 = 2;
            if (v.b((z)param4Object, f, null, (d)this, 2, null) == object)
              return object; 
          } 
          return v.a;
        }
      }
    }
    
    @f(c = "androidx.compose.foundation.ScrollKt$scroll$2$semantics$1$1$1", f = "Scroll.kt", l = {288, 290}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      a(boolean param2Boolean, u param2u, float param2Float1, float param2Float2, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<v> create(Object param2Object, d<?> param2d) {
        return (d<v>)new a(this.t0, this.u0, this.v0, this.w0, (d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, d<? super v> param2d) {
        return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1 || i == 2) {
            n.b(param2Object);
            return v.a;
          } 
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
        n.b(param2Object);
        if (this.t0) {
          param2Object = this.u0;
          q.h(param2Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
          float f = this.v0;
          this.s0 = 1;
          if (v.b((z)param2Object, f, null, (d)this, 2, null) == object)
            return object; 
        } else {
          param2Object = this.u0;
          q.h(param2Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
          float f = this.w0;
          this.s0 = 2;
          if (v.b((z)param2Object, f, null, (d)this, 2, null) == object)
            return object; 
        } 
        return v.a;
      }
    }
    
    static final class b extends r implements dk.a<Float> {
      b(u param2u) {
        super(0);
      }
      
      public final Float d() {
        return Float.valueOf(this.s0.h());
      }
    }
    
    static final class c extends r implements dk.a<Float> {
      c(u param2u) {
        super(0);
      }
      
      public final Float d() {
        return Float.valueOf(this.s0.g());
      }
    }
  }
  
  static final class a extends r implements l<x, v> {
    a(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, u param1u, CoroutineScope param1CoroutineScope) {
      super(1);
    }
    
    public final void invoke(x param1x) {
      q.j(param1x, "$this$semantics");
      v.h0(param1x, true);
      j j = new j(new b(this.v0), new c(this.v0), this.s0);
      if (this.t0) {
        v.i0(param1x, j);
      } else {
        v.T(param1x, j);
      } 
      if (this.u0)
        v.K(param1x, null, new a(this.w0, this.t0, this.v0), 1, null); 
    }
    
    static final class a extends r implements p<Float, Float, Boolean> {
      a(CoroutineScope param3CoroutineScope, boolean param3Boolean, u param3u) {
        super(2);
      }
      
      public final Boolean a(float param3Float1, float param3Float2) {
        BuildersKt.launch$default(this.s0, null, null, new a(this.t0, this.u0, param3Float2, param3Float1, null), 3, null);
        return Boolean.TRUE;
      }
      
      @f(c = "androidx.compose.foundation.ScrollKt$scroll$2$semantics$1$1$1", f = "Scroll.kt", l = {288, 290}, m = "invokeSuspend")
      static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
        int s0;
        
        a(boolean param4Boolean, u param4u, float param4Float1, float param4Float2, d<? super a> param4d) {
          super(2, param4d);
        }
        
        public final d<v> create(Object param4Object, d<?> param4d) {
          return (d<v>)new a(this.t0, this.u0, this.v0, this.w0, (d)param4d);
        }
        
        public final Object invoke(CoroutineScope param4CoroutineScope, d<? super v> param4d) {
          return ((a)create(param4CoroutineScope, param4d)).invokeSuspend(v.a);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          Object object = wj.b.d();
          int i = this.s0;
          if (i != 0) {
            if (i == 1 || i == 2) {
              n.b(param4Object);
              return v.a;
            } 
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
          n.b(param4Object);
          if (this.t0) {
            param4Object = this.u0;
            q.h(param4Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
            float f = this.v0;
            this.s0 = 1;
            if (v.b((z)param4Object, f, null, (d)this, 2, null) == object)
              return object; 
          } else {
            param4Object = this.u0;
            q.h(param4Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
            float f = this.w0;
            this.s0 = 2;
            if (v.b((z)param4Object, f, null, (d)this, 2, null) == object)
              return object; 
          } 
          return v.a;
        }
      }
    }
    
    @f(c = "androidx.compose.foundation.ScrollKt$scroll$2$semantics$1$1$1", f = "Scroll.kt", l = {288, 290}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      a(boolean param3Boolean, u param3u, float param3Float1, float param3Float2, d<? super a> param3d) {
        super(2, param3d);
      }
      
      public final d<v> create(Object param3Object, d<?> param3d) {
        return (d<v>)new a(this.t0, this.u0, this.v0, this.w0, (d)param3d);
      }
      
      public final Object invoke(CoroutineScope param3CoroutineScope, d<? super v> param3d) {
        return ((a)create(param3CoroutineScope, param3d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1 || i == 2) {
            n.b(param3Object);
            return v.a;
          } 
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
        n.b(param3Object);
        if (this.t0) {
          param3Object = this.u0;
          q.h(param3Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
          float f = this.v0;
          this.s0 = 1;
          if (v.b((z)param3Object, f, null, (d)this, 2, null) == object)
            return object; 
        } else {
          param3Object = this.u0;
          q.h(param3Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
          float f = this.w0;
          this.s0 = 2;
          if (v.b((z)param3Object, f, null, (d)this, 2, null) == object)
            return object; 
        } 
        return v.a;
      }
    }
    
    static final class b extends r implements dk.a<Float> {
      b(u param3u) {
        super(0);
      }
      
      public final Float d() {
        return Float.valueOf(this.s0.h());
      }
    }
    
    static final class c extends r implements dk.a<Float> {
      c(u param3u) {
        super(0);
      }
      
      public final Float d() {
        return Float.valueOf(this.s0.g());
      }
    }
  }
  
  static final class a extends r implements p<Float, Float, Boolean> {
    a(CoroutineScope param1CoroutineScope, boolean param1Boolean, u param1u) {
      super(2);
    }
    
    public final Boolean a(float param1Float1, float param1Float2) {
      BuildersKt.launch$default(this.s0, null, null, new a(this.t0, this.u0, param1Float2, param1Float1, null), 3, null);
      return Boolean.TRUE;
    }
    
    @f(c = "androidx.compose.foundation.ScrollKt$scroll$2$semantics$1$1$1", f = "Scroll.kt", l = {288, 290}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      a(boolean param4Boolean, u param4u, float param4Float1, float param4Float2, d<? super a> param4d) {
        super(2, param4d);
      }
      
      public final d<v> create(Object param4Object, d<?> param4d) {
        return (d<v>)new a(this.t0, this.u0, this.v0, this.w0, (d)param4d);
      }
      
      public final Object invoke(CoroutineScope param4CoroutineScope, d<? super v> param4d) {
        return ((a)create(param4CoroutineScope, param4d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param4Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1 || i == 2) {
            n.b(param4Object);
            return v.a;
          } 
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
        n.b(param4Object);
        if (this.t0) {
          param4Object = this.u0;
          q.h(param4Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
          float f = this.v0;
          this.s0 = 1;
          if (v.b((z)param4Object, f, null, (d)this, 2, null) == object)
            return object; 
        } else {
          param4Object = this.u0;
          q.h(param4Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
          float f = this.w0;
          this.s0 = 2;
          if (v.b((z)param4Object, f, null, (d)this, 2, null) == object)
            return object; 
        } 
        return v.a;
      }
    }
  }
  
  @f(c = "androidx.compose.foundation.ScrollKt$scroll$2$semantics$1$1$1", f = "Scroll.kt", l = {288, 290}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    a(boolean param1Boolean, u param1u, float param1Float1, float param1Float2, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      return (d<v>)new a(this.t0, this.u0, this.v0, this.w0, (d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1 || i == 2) {
          n.b(param1Object);
          return v.a;
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
      n.b(param1Object);
      if (this.t0) {
        param1Object = this.u0;
        q.h(param1Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
        float f = this.v0;
        this.s0 = 1;
        if (v.b((z)param1Object, f, null, (d)this, 2, null) == object)
          return object; 
      } else {
        param1Object = this.u0;
        q.h(param1Object, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableState");
        float f = this.w0;
        this.s0 = 2;
        if (v.b((z)param1Object, f, null, (d)this, 2, null) == object)
          return object; 
      } 
      return v.a;
    }
  }
  
  static final class b extends r implements dk.a<Float> {
    b(u param1u) {
      super(0);
    }
    
    public final Float d() {
      return Float.valueOf(this.s0.h());
    }
  }
  
  static final class c extends r implements dk.a<Float> {
    c(u param1u) {
      super(0);
    }
    
    public final Float d() {
      return Float.valueOf(this.s0.g());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */