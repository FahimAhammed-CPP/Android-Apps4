package androidx.compose.foundation;

import androidx.compose.ui.e;
import dk.a;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import rj.v;
import t.m;
import u1.i;

final class ClickableElement extends u0<f> {
  private final m c;
  
  private final boolean d;
  
  private final String e;
  
  private final i f;
  
  private final a<v> g;
  
  private ClickableElement(m paramm, boolean paramBoolean, String paramString, i parami, a<v> parama) {
    this.c = paramm;
    this.d = paramBoolean;
    this.e = paramString;
    this.f = parami;
    this.g = parama;
  }
  
  public boolean equals(Object paramObject) {
    Object object;
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      object = paramObject.getClass();
    } else {
      object = null;
    } 
    if (!q.e(ClickableElement.class, object))
      return false; 
    q.h(paramObject, "null cannot be cast to non-null type androidx.compose.foundation.ClickableElement");
    paramObject = paramObject;
    return !q.e(this.c, ((ClickableElement)paramObject).c) ? false : ((this.d != ((ClickableElement)paramObject).d) ? false : (!q.e(this.e, ((ClickableElement)paramObject).e) ? false : (!q.e(this.f, ((ClickableElement)paramObject).f) ? false : (!!q.e(this.g, ((ClickableElement)paramObject).g)))));
  }
  
  public int hashCode() {
    byte b;
    int k = this.c.hashCode();
    int n = k.a(this.d);
    String str = this.e;
    int j = 0;
    if (str != null) {
      b = str.hashCode();
    } else {
      b = 0;
    } 
    i i1 = this.f;
    if (i1 != null)
      j = i.l(i1.n()); 
    return (((k * 31 + n) * 31 + b) * 31 + j) * 31 + this.g.hashCode();
  }
  
  public f s() {
    return new f(this.c, this.d, this.e, this.f, this.g, null);
  }
  
  public void t(f paramf) {
    q.j(paramf, "node");
    paramf.M1(this.c, this.d, this.e, this.f, this.g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\ClickableElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */