package androidx.compose.foundation;

import androidx.compose.ui.e;
import androidx.compose.ui.platform.j1;
import androidx.compose.ui.platform.l1;
import b1.l4;
import b1.p1;
import b1.r4;
import dk.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;

public final class c {
  public static final e a(e parame, long paramLong, r4 paramr4) {
    l l;
    q.j(parame, "$this$background");
    q.j(paramr4, "shape");
    if (j1.c()) {
      l = new a(paramLong, paramr4);
    } else {
      l = j1.a();
    } 
    return parame.then((e)new BackgroundElement(paramLong, null, 1.0F, paramr4, l, 2, null));
  }
  
  public static final class a extends r implements l<l1, v> {
    public a(long param1Long, r4 param1r4) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("background");
      param1l1.c(p1.g(this.s0));
      param1l1.a().b("color", p1.g(this.s0));
      param1l1.a().b("shape", this.t0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */