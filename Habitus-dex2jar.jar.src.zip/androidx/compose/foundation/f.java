package androidx.compose.foundation;

import dk.a;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q1.j;
import rj.v;
import t.m;
import u1.i;

final class f extends a {
  private final h N0;
  
  private final g O0;
  
  private f(m paramm, boolean paramBoolean, String paramString, i parami, a<v> parama) {
    super(paramm, paramBoolean, paramString, parami, parama, null);
    this.N0 = (h)A1((j)new h(paramBoolean, paramString, parami, parama, null, null, null));
    this.O0 = (g)A1((j)new g(paramBoolean, paramm, parama, I1()));
  }
  
  public g K1() {
    return this.O0;
  }
  
  public h L1() {
    return this.N0;
  }
  
  public final void M1(m paramm, boolean paramBoolean, String paramString, i parami, a<v> parama) {
    q.j(paramm, "interactionSource");
    q.j(parama, "onClick");
    J1(paramm, paramBoolean, paramString, parami, parama);
    L1().C1(paramBoolean, paramString, parami, parama, null, null);
    K1().N1(paramBoolean, paramm, parama);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */