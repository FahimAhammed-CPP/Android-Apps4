package androidx.compose.foundation;

import androidx.compose.ui.platform.j1;
import androidx.compose.ui.platform.l1;
import dk.l;
import dk.p;
import dk.q;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Job;
import l0.l;
import l0.n;
import l0.t;
import q.l;
import q.t;
import q.v;
import r.s;
import rj.n;
import rj.v;
import t.j;
import t.k;
import t.l;
import t.m;
import t.p;
import t.q;
import u1.i;

public final class e {
  public static final androidx.compose.ui.e b(androidx.compose.ui.e parame, m paramm, t paramt, boolean paramBoolean, String paramString, i parami, dk.a<v> parama) {
    l l;
    q.j(parame, "$this$clickable");
    q.j(paramm, "interactionSource");
    q.j(parama, "onClick");
    if (j1.c()) {
      l = new b(paramm, paramt, paramBoolean, paramString, parami, parama);
    } else {
      l = j1.a();
    } 
    return j1.b(parame, l, FocusableKt.c(r.a(v.b((androidx.compose.ui.e)androidx.compose.ui.e.a, (k)paramm, paramt), paramm, paramBoolean), paramBoolean, paramm).then((androidx.compose.ui.e)new ClickableElement(paramm, paramBoolean, paramString, parami, parama, null)));
  }
  
  public static final androidx.compose.ui.e d(androidx.compose.ui.e parame, boolean paramBoolean, String paramString, i parami, dk.a<v> parama) {
    l l;
    q.j(parame, "$this$clickable");
    q.j(parama, "onClick");
    if (j1.c()) {
      l = new c(paramBoolean, paramString, parami, parama);
    } else {
      l = j1.a();
    } 
    return androidx.compose.ui.c.a(parame, l, new a(paramBoolean, paramString, parami, parama));
  }
  
  public static final androidx.compose.ui.e f(androidx.compose.ui.e parame, m paramm, t paramt, boolean paramBoolean, String paramString1, i parami, String paramString2, dk.a<v> parama1, dk.a<v> parama2, dk.a<v> parama3) {
    l l;
    q.j(parame, "$this$combinedClickable");
    q.j(paramm, "interactionSource");
    q.j(parama3, "onClick");
    if (j1.c()) {
      l = new e(paramt, paramm, paramBoolean, paramString1, parami, parama3, parama2, parama1, paramString2);
    } else {
      l = j1.a();
    } 
    return j1.b(parame, l, FocusableKt.c(r.a(v.b((androidx.compose.ui.e)androidx.compose.ui.e.a, (k)paramm, paramt), paramm, paramBoolean), paramBoolean, paramm).then((androidx.compose.ui.e)new CombinedClickableElement(paramm, paramBoolean, paramString1, parami, parama3, paramString2, parama1, parama2, null)));
  }
  
  public static final androidx.compose.ui.e g(androidx.compose.ui.e parame, boolean paramBoolean, String paramString1, i parami, String paramString2, dk.a<v> parama1, dk.a<v> parama2, dk.a<v> parama3) {
    l l;
    q.j(parame, "$this$combinedClickable");
    q.j(parama3, "onClick");
    if (j1.c()) {
      l = new f(paramBoolean, paramString1, parami, parama3, parama2, parama1, paramString2);
    } else {
      l = j1.a();
    } 
    return androidx.compose.ui.c.a(parame, l, new d(paramBoolean, paramString1, parami, paramString2, parama1, parama2, parama3));
  }
  
  private static final Object i(s params, long paramLong, m paramm, a.a parama, dk.a<Boolean> parama1, vj.d<? super v> paramd) {
    Object object = CoroutineScopeKt.coroutineScope(new g(params, paramLong, paramm, parama, parama1, null), paramd);
    return (object == wj.b.d()) ? object : v.a;
  }
  
  static final class a extends r implements q<androidx.compose.ui.e, l, Integer, androidx.compose.ui.e> {
    a(boolean param1Boolean, String param1String, i param1i, dk.a<v> param1a) {
      super(3);
    }
    
    public final androidx.compose.ui.e invoke(androidx.compose.ui.e param1e, l param1l, int param1Int) {
      q.j(param1e, "$this$composed");
      param1l.x(-756081143);
      if (n.K())
        n.V(-756081143, param1Int, -1, "androidx.compose.foundation.clickable.<anonymous> (Clickable.kt:97)"); 
      androidx.compose.ui.e.a a1 = androidx.compose.ui.e.a;
      t t = (t)param1l.H((t)v.a());
      param1l.x(-492369756);
      Object object2 = param1l.y();
      Object object1 = object2;
      if (object2 == l.a.a()) {
        object1 = l.a();
        param1l.r(object1);
      } 
      param1l.Q();
      object1 = e.b((androidx.compose.ui.e)a1, (m)object1, t, this.s0, this.t0, this.u0, this.v0);
      if (n.K())
        n.U(); 
      param1l.Q();
      return (androidx.compose.ui.e)object1;
    }
  }
  
  public static final class b extends r implements l<l1, v> {
    public b(m param1m, t param1t, boolean param1Boolean, String param1String, i param1i, dk.a param1a) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("clickable");
      param1l1.a().b("interactionSource", this.s0);
      param1l1.a().b("indication", this.t0);
      param1l1.a().b("enabled", Boolean.valueOf(this.u0));
      param1l1.a().b("onClickLabel", this.v0);
      param1l1.a().b("role", this.w0);
      param1l1.a().b("onClick", this.x0);
    }
  }
  
  public static final class c extends r implements l<l1, v> {
    public c(boolean param1Boolean, String param1String, i param1i, dk.a param1a) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("clickable");
      param1l1.a().b("enabled", Boolean.valueOf(this.s0));
      param1l1.a().b("onClickLabel", this.t0);
      param1l1.a().b("role", this.u0);
      param1l1.a().b("onClick", this.v0);
    }
  }
  
  static final class d extends r implements q<androidx.compose.ui.e, l, Integer, androidx.compose.ui.e> {
    d(boolean param1Boolean, String param1String1, i param1i, String param1String2, dk.a<v> param1a1, dk.a<v> param1a2, dk.a<v> param1a3) {
      super(3);
    }
    
    public final androidx.compose.ui.e invoke(androidx.compose.ui.e param1e, l param1l, int param1Int) {
      q.j(param1e, "$this$composed");
      param1l.x(1969174843);
      if (n.K())
        n.V(1969174843, param1Int, -1, "androidx.compose.foundation.combinedClickable.<anonymous> (Clickable.kt:200)"); 
      androidx.compose.ui.e.a a1 = androidx.compose.ui.e.a;
      t t = (t)param1l.H((t)v.a());
      param1l.x(-492369756);
      Object object2 = param1l.y();
      Object object1 = object2;
      if (object2 == l.a.a()) {
        object1 = l.a();
        param1l.r(object1);
      } 
      param1l.Q();
      object1 = e.f((androidx.compose.ui.e)a1, (m)object1, t, this.s0, this.t0, this.u0, this.v0, this.w0, this.x0, this.y0);
      if (n.K())
        n.U(); 
      param1l.Q();
      return (androidx.compose.ui.e)object1;
    }
  }
  
  public static final class e extends r implements l<l1, v> {
    public e(t param1t, m param1m, boolean param1Boolean, String param1String1, i param1i, dk.a param1a1, dk.a param1a2, dk.a param1a3, String param1String2) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("combinedClickable");
      param1l1.a().b("indication", this.s0);
      param1l1.a().b("interactionSource", this.t0);
      param1l1.a().b("enabled", Boolean.valueOf(this.u0));
      param1l1.a().b("onClickLabel", this.v0);
      param1l1.a().b("role", this.w0);
      param1l1.a().b("onClick", this.x0);
      param1l1.a().b("onDoubleClick", this.y0);
      param1l1.a().b("onLongClick", this.z0);
      param1l1.a().b("onLongClickLabel", this.A0);
    }
  }
  
  public static final class f extends r implements l<l1, v> {
    public f(boolean param1Boolean, String param1String1, i param1i, dk.a param1a1, dk.a param1a2, dk.a param1a3, String param1String2) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("combinedClickable");
      param1l1.a().b("enabled", Boolean.valueOf(this.s0));
      param1l1.a().b("onClickLabel", this.t0);
      param1l1.a().b("role", this.u0);
      param1l1.a().b("onClick", this.v0);
      param1l1.a().b("onDoubleClick", this.w0);
      param1l1.a().b("onLongClick", this.x0);
      param1l1.a().b("onLongClickLabel", this.y0);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.ClickableKt$handlePressInteraction$2", f = "Clickable.kt", l = {299, 301, 308, 309, 318}, m = "invokeSuspend")
  static final class g extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
    boolean s0;
    
    int t0;
    
    g(s param1s, long param1Long, m param1m, a.a param1a, dk.a<Boolean> param1a1, vj.d<? super g> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      g g1 = new g(this.v0, this.w0, this.x0, this.y0, this.z0, (vj.d)param1d);
      g1.u0 = param1Object;
      return (vj.d<v>)g1;
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, vj.d<? super v> param1d) {
      return ((g)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.t0;
      if (i != 0) {
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              if (i == 4 || i == 5) {
                n.b(param1Object);
                this.y0.e(null);
                return v.a;
              } 
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
            q q = (q)this.u0;
            n.b(param1Object);
            param1Object = q;
          } else {
            boolean bool = this.s0;
            n.b(param1Object);
            if (bool) {
              p p1 = new p(this.w0, null);
              param1Object = new q(p1);
              m m2 = this.x0;
              this.u0 = param1Object;
              this.t0 = 3;
              if (m2.c((j)p1, (vj.d)this) == object)
                return object; 
            } else {
              this.y0.e(null);
              return v.a;
            } 
          } 
        } else {
          Job job = (Job)this.u0;
          n.b(param1Object);
          Object object1 = param1Object;
          param1Object = job;
          boolean bool = ((Boolean)object1).booleanValue();
        } 
      } else {
        n.b(param1Object);
        param1Object = BuildersKt.launch$default((CoroutineScope)this.u0, null, null, new a(this.z0, this.w0, this.x0, this.y0, null), 3, null);
        s s1 = this.v0;
        this.u0 = param1Object;
        this.t0 = 1;
        Object object2 = s1.M((vj.d)this);
        Object object1 = object2;
        if (object2 == object)
          return object; 
        boolean bool = ((Boolean)object1).booleanValue();
      } 
      m m1 = this.x0;
      this.u0 = null;
      this.t0 = 4;
      if (m1.c((j)param1Object, (vj.d)this) == object)
        return object; 
      this.y0.e(null);
      return v.a;
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.ClickableKt$handlePressInteraction$2$delayJob$1", f = "Clickable.kt", l = {293, 296}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
      Object s0;
      
      int t0;
      
      a(dk.a<Boolean> param2a, long param2Long, m param2m, a.a param2a1, vj.d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final vj.d<v> create(Object param2Object, vj.d<?> param2d) {
        return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, (vj.d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, vj.d<? super v> param2d) {
        return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = wj.b.d();
        int i = this.t0;
        if (i != 0) {
          if (i != 1) {
            if (i == 2) {
              object = this.s0;
              n.b(param2Object);
              param2Object = object;
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            n.b(param2Object);
            param2Object = new p(this.v0, null);
            m m1 = this.w0;
            this.s0 = param2Object;
            this.t0 = 2;
          } 
        } else {
          n.b(param2Object);
          if (((Boolean)this.u0.invoke()).booleanValue()) {
            long l1 = l.a();
            this.t0 = 1;
            if (DelayKt.delay(l1, (vj.d)this) == object)
              return object; 
          } 
          param2Object = new p(this.v0, null);
          m m1 = this.w0;
          this.s0 = param2Object;
          this.t0 = 2;
        } 
        this.x0.e((p)param2Object);
        return v.a;
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.ClickableKt$handlePressInteraction$2$delayJob$1", f = "Clickable.kt", l = {293, 296}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
    Object s0;
    
    int t0;
    
    a(dk.a<Boolean> param1a, long param1Long, m param1m, a.a param1a1, vj.d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, (vj.d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, vj.d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.t0;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            object = this.s0;
            n.b(param1Object);
            param1Object = object;
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param1Object);
          param1Object = new p(this.v0, null);
          m m1 = this.w0;
          this.s0 = param1Object;
          this.t0 = 2;
        } 
      } else {
        n.b(param1Object);
        if (((Boolean)this.u0.invoke()).booleanValue()) {
          long l1 = l.a();
          this.t0 = 1;
          if (DelayKt.delay(l1, (vj.d)this) == object)
            return object; 
        } 
        param1Object = new p(this.v0, null);
        m m1 = this.w0;
        this.s0 = param1Object;
        this.t0 = 2;
      } 
      this.x0.e((p)param1Object);
      return v.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */