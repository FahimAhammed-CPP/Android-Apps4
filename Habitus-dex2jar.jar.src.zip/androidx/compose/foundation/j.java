package androidx.compose.foundation;

import a1.f;
import a1.g;
import dk.l;
import dk.q;
import k2.l;
import k2.q;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l1.l0;
import r.b0;
import r.s;
import rj.n;
import rj.v;
import t.m;

final class j extends b {
  private dk.a<v> N0;
  
  private dk.a<v> O0;
  
  public j(boolean paramBoolean, m paramm, dk.a<v> parama1, a.a parama, dk.a<v> parama2, dk.a<v> parama3) {
    super(paramBoolean, paramm, parama1, parama, null);
    this.N0 = parama2;
    this.O0 = parama3;
  }
  
  protected Object J1(l0 paraml0, vj.d<? super v> paramd) {
    l l1;
    a.a a1 = G1();
    long l = q.b(paraml0.a());
    a1.d(g.a(l.j(l), l.k(l)));
    if (F1() && this.O0 != null) {
      a a2 = new a(this);
    } else {
      a1 = null;
    } 
    if (F1() && this.N0 != null) {
      l1 = new b(this);
    } else {
      l1 = null;
    } 
    Object object = b0.i(paraml0, (l)a1, l1, new c(this, null), new d(this), paramd);
    return (object == wj.b.d()) ? object : v.a;
  }
  
  public final void P1(boolean paramBoolean, m paramm, dk.a<v> parama1, dk.a<v> parama2, dk.a<v> parama3) {
    boolean bool1;
    boolean bool2;
    q.j(paramm, "interactionSource");
    q.j(parama1, "onClick");
    M1(parama1);
    L1(paramm);
    boolean bool = F1();
    boolean bool4 = true;
    boolean bool5 = false;
    if (bool != paramBoolean) {
      K1(paramBoolean);
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (this.N0 == null) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (parama2 == null) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    if (bool2 != bool3)
      bool1 = true; 
    this.N0 = parama2;
    if (this.O0 == null) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    boolean bool3 = bool5;
    if (parama3 == null)
      bool3 = true; 
    if (bool2 != bool3)
      bool1 = bool4; 
    this.O0 = parama3;
    if (bool1)
      d0(); 
  }
  
  static final class a extends r implements l<f, v> {
    a(j param1j) {
      super(1);
    }
    
    public final void a(long param1Long) {
      dk.a a1 = j.N1(this.s0);
      if (a1 != null)
        a1.invoke(); 
    }
  }
  
  static final class b extends r implements l<f, v> {
    b(j param1j) {
      super(1);
    }
    
    public final void a(long param1Long) {
      dk.a a = j.O1(this.s0);
      if (a != null)
        a.invoke(); 
    }
  }
  
  @f(c = "androidx.compose.foundation.CombinedClickablePointerInputNode$pointerInput$4", f = "Clickable.kt", l = {936}, m = "invokeSuspend")
  static final class c extends l implements q<s, f, vj.d<? super v>, Object> {
    int s0;
    
    c(j param1j, vj.d<? super c> param1d) {
      super(3, param1d);
    }
    
    public final Object a(s param1s, long param1Long, vj.d<? super v> param1d) {
      c c1 = new c(this.v0, (vj.d)param1d);
      c1.t0 = param1s;
      c1.u0 = param1Long;
      return c1.invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0;
        long l1 = this.u0;
        if (this.v0.F1()) {
          j j1 = this.v0;
          this.s0 = 1;
          if (j1.I1((s)param1Object, l1, (vj.d<? super v>)this) == object)
            return object; 
        } 
      } 
      return v.a;
    }
  }
  
  static final class d extends r implements l<f, v> {
    d(j param1j) {
      super(1);
    }
    
    public final void a(long param1Long) {
      if (this.s0.F1())
        this.s0.H1().invoke(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */