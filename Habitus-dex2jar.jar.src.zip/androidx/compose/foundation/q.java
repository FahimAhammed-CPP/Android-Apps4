package androidx.compose.foundation;

import androidx.compose.ui.e;
import dk.l;
import o1.s;
import p1.c;
import p1.g;
import p1.h;
import p1.i;
import p1.j;
import rj.r;
import rj.v;

final class q extends e.c implements i, l<s, v> {
  private l<? super s, v> F0;
  
  private final g G0;
  
  public q(l<? super s, v> paraml) {
    this.F0 = paraml;
    this.G0 = j.b(r.a(p.a(), this));
  }
  
  private final l<s, v> A1() {
    return h1() ? (l<s, v>)f((c)p.a()) : null;
  }
  
  public void B1(s params) {
    if (!h1())
      return; 
    this.F0.invoke(params);
    l<s, v> l1 = A1();
    if (l1 != null)
      l1.invoke(params); 
  }
  
  public final void C1(l<? super s, v> paraml) {
    kotlin.jvm.internal.q.j(paraml, "<set-?>");
    this.F0 = paraml;
  }
  
  public g K() {
    return this.G0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */