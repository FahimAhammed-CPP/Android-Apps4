package androidx.compose.foundation.lazy.grid;

import androidx.compose.ui.e;
import k2.l;
import kotlin.jvm.internal.q;
import p.e0;
import w.r;

public final class b implements r {
  public static final b a = new b();
  
  public e a(e parame, e0<l> parame0) {
    q.j(parame, "<this>");
    q.j(parame0, "animationSpec");
    return parame.then((e)new AnimateItemPlacementElement(parame0));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\lazy\grid\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */