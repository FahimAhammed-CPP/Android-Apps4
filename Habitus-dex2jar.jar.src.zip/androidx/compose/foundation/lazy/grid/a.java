package androidx.compose.foundation.lazy.grid;

import k2.e;
import k2.l;
import kotlin.jvm.internal.q;
import p.e0;
import q1.j;
import q1.l;
import q1.l1;
import x.i;

final class a extends l implements l1 {
  private final i H0;
  
  public a(e0<l> parame0) {
    this.H0 = (i)A1((j)new i(parame0));
  }
  
  public final i F1() {
    return this.H0;
  }
  
  public Object modifyParentData(e parame, Object paramObject) {
    q.j(parame, "<this>");
    return this.H0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\lazy\grid\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */