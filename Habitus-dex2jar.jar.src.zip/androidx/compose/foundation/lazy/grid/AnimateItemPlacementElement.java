package androidx.compose.foundation.lazy.grid;

import androidx.compose.ui.e;
import k2.l;
import kotlin.jvm.internal.q;
import p.e0;
import q1.u0;

final class AnimateItemPlacementElement extends u0<a> {
  private final e0<l> c;
  
  public AnimateItemPlacementElement(e0<l> parame0) {
    this.c = parame0;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof AnimateItemPlacementElement) ? false : (q.e(this.c, ((AnimateItemPlacementElement)paramObject).c) ^ true));
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public a s() {
    return new a(this.c);
  }
  
  public void t(a parama) {
    q.j(parama, "node");
    parama.F1().L1(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\lazy\grid\AnimateItemPlacementElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */