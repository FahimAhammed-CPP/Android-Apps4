package androidx.compose.foundation;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;

final class ScrollingLayoutElement extends u0<v> {
  private final u c;
  
  private final boolean d;
  
  private final boolean e;
  
  public ScrollingLayoutElement(u paramu, boolean paramBoolean1, boolean paramBoolean2) {
    this.c = paramu;
    this.d = paramBoolean1;
    this.e = paramBoolean2;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof ScrollingLayoutElement;
    boolean bool1 = false;
    if (!bool)
      return false; 
    u u1 = this.c;
    paramObject = paramObject;
    bool = bool1;
    if (q.e(u1, ((ScrollingLayoutElement)paramObject).c)) {
      bool = bool1;
      if (this.d == ((ScrollingLayoutElement)paramObject).d) {
        bool = bool1;
        if (this.e == ((ScrollingLayoutElement)paramObject).e)
          bool = true; 
      } 
    } 
    return bool;
  }
  
  public int hashCode() {
    return (this.c.hashCode() * 31 + k.a(this.d)) * 31 + k.a(this.e);
  }
  
  public v s() {
    return new v(this.c, this.d, this.e);
  }
  
  public void t(v paramv) {
    q.j(paramv, "node");
    paramv.E1(this.c);
    paramv.D1(this.d);
    paramv.F1(this.e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\ScrollingLayoutElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */