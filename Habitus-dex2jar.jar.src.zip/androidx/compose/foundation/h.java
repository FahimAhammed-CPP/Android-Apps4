package androidx.compose.foundation;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import q1.s1;
import q1.t1;
import rj.v;
import u1.i;
import u1.v;
import u1.x;

final class h extends e.c implements t1 {
  private boolean F0;
  
  private String G0;
  
  private i H0;
  
  private dk.a<v> I0;
  
  private String J0;
  
  private dk.a<v> K0;
  
  private h(boolean paramBoolean, String paramString1, i parami, dk.a<v> parama1, String paramString2, dk.a<v> parama2) {
    this.F0 = paramBoolean;
    this.G0 = paramString1;
    this.H0 = parami;
    this.I0 = parama1;
    this.J0 = paramString2;
    this.K0 = parama2;
  }
  
  public final void C1(boolean paramBoolean, String paramString1, i parami, dk.a<v> parama1, String paramString2, dk.a<v> parama2) {
    q.j(parama1, "onClick");
    this.F0 = paramBoolean;
    this.G0 = paramString1;
    this.H0 = parami;
    this.I0 = parama1;
    this.J0 = paramString2;
    this.K0 = parama2;
  }
  
  public void I0(x paramx) {
    q.j(paramx, "<this>");
    i i1 = this.H0;
    if (i1 != null) {
      q.g(i1);
      v.Y(paramx, i1.n());
    } 
    v.p(paramx, this.G0, new a(this));
    if (this.K0 != null)
      v.r(paramx, this.J0, new b(this)); 
    if (!this.F0)
      v.f(paramx); 
  }
  
  public boolean T0() {
    return true;
  }
  
  static final class a extends r implements dk.a<Boolean> {
    a(h param1h) {
      super(0);
    }
    
    public final Boolean invoke() {
      h.A1(this.s0).invoke();
      return Boolean.TRUE;
    }
  }
  
  static final class b extends r implements dk.a<Boolean> {
    b(h param1h) {
      super(0);
    }
    
    public final Boolean invoke() {
      dk.a a1 = h.B1(this.s0);
      if (a1 != null)
        a1.invoke(); 
      return Boolean.TRUE;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */