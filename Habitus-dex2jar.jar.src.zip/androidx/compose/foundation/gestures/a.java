package androidx.compose.foundation.gestures;

import androidx.compose.ui.e;
import dk.l;
import dk.p;
import p1.k;
import p1.m;
import w0.d;
import w0.e;

final class a implements k<Boolean> {
  public static final a c = new a();
  
  private static final m<Boolean> d = d.g();
  
  private static final boolean e = true;
  
  public Boolean a() {
    return Boolean.valueOf(e);
  }
  
  public m<Boolean> getKey() {
    return d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\gestures\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */