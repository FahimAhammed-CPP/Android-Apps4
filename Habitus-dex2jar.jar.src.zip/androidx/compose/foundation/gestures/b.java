package androidx.compose.foundation.gestures;

import dk.p;
import java.util.List;
import k2.e;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.k;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import l0.k3;
import l1.c0;
import l1.e;
import l1.l0;
import l1.r;
import l1.t;
import l1.u0;
import l1.v0;
import q1.j;
import q1.l;
import q1.n1;
import q1.o1;
import r.u;
import rj.n;
import rj.v;
import vj.d;

final class b extends l implements o1 {
  private k3<e> H0;
  
  private u I0;
  
  private final v0 J0;
  
  public b(k3<e> paramk3, u paramu) {
    this.H0 = paramk3;
    this.I0 = paramu;
    this.J0 = (v0)A1((j)u0.a(new a(this, null)));
  }
  
  public void C(r paramr, t paramt, long paramLong) {
    q.j(paramr, "pointerEvent");
    q.j(paramt, "pass");
    this.J0.C(paramr, paramt, paramLong);
  }
  
  public final u F1() {
    return this.I0;
  }
  
  public final k3<e> G1() {
    return this.H0;
  }
  
  public final void H1(u paramu) {
    q.j(paramu, "<set-?>");
    this.I0 = paramu;
  }
  
  public final void I1(k3<e> paramk3) {
    q.j(paramk3, "<set-?>");
    this.H0 = paramk3;
  }
  
  public void q0() {
    this.J0.q0();
  }
  
  @f(c = "androidx.compose.foundation.gestures.MouseWheelScrollNode$pointerInputNode$1", f = "Scrollable.kt", l = {336}, m = "invokeSuspend")
  static final class a extends l implements p<l0, d<? super v>, Object> {
    int s0;
    
    a(b param1b, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final Object a(l0 param1l0, d<? super v> param1d) {
      return ((a)create(param1l0, param1d)).invokeSuspend(v.a);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.u0, (d)param1d);
      a1.t0 = param1Object;
      return (d<v>)a1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0;
        a a1 = new a(this.u0, null);
        this.s0 = 1;
        if (param1Object.Q0(a1, (d)this) == object)
          return object; 
      } 
      return v.a;
    }
    
    @f(c = "androidx.compose.foundation.gestures.MouseWheelScrollNode$pointerInputNode$1$1", f = "Scrollable.kt", l = {338}, m = "invokeSuspend")
    static final class a extends k implements p<e, d<? super v>, Object> {
      int s0;
      
      a(b param2b, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final Object a(e param2e, d<? super v> param2d) {
        return ((a)create(param2e, param2d)).invokeSuspend(v.a);
      }
      
      public final d<v> create(Object param2Object, d<?> param2d) {
        a a1 = new a(this.u0, (d)param2d);
        a1.t0 = param2Object;
        return (d<v>)a1;
      }
      
      public final Object invokeSuspend(Object param2Object) {
        e e;
        Object object2 = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1) {
            e = (e)this.t0;
            n.b(param2Object);
            object1 = object2;
            object2 = this;
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param2Object);
          e = (e)this.t0;
          object1 = this;
          param2Object = object2;
          ((a)object1).t0 = e;
          ((a)object1).s0 = 1;
          Object object = d.a(e, (d)object1);
        } 
        param2Object = param2Object;
        List<c0> list = param2Object.c();
        int j = list.size();
        boolean bool = false;
        i = 0;
        while (true) {
          if (i < j) {
            if ((((c0)list.get(i)).o() ^ true) == 0) {
              i = 0;
              break;
            } 
            i++;
            continue;
          } 
          i = 1;
          break;
        } 
        if (i != 0) {
          u u = ((a)object2).u0.F1();
          b b1 = ((a)object2).u0;
          long l = u.a((e)e, (r)param2Object, e.a());
          e e1 = (e)b1.G1().getValue();
          float f = e1.j(e1.p(l));
          if (e1.e().dispatchRawDelta(f) == 0.0F) {
            i = 1;
          } else {
            i = 0;
          } 
          if (i == 0) {
            param2Object = param2Object.c();
            j = param2Object.size();
            for (i = bool; i < j; i++)
              ((c0)param2Object.get(i)).a(); 
          } 
        } 
        param2Object = object1;
        Object object1 = object2;
        ((a)object1).t0 = e;
        ((a)object1).s0 = 1;
        Object object3 = d.a(e, (d)object1);
      }
    }
  }
  
  @f(c = "androidx.compose.foundation.gestures.MouseWheelScrollNode$pointerInputNode$1$1", f = "Scrollable.kt", l = {338}, m = "invokeSuspend")
  static final class a extends k implements p<e, d<? super v>, Object> {
    int s0;
    
    a(b param1b, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final Object a(e param1e, d<? super v> param1d) {
      return ((a)create(param1e, param1d)).invokeSuspend(v.a);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.u0, (d)param1d);
      a1.t0 = param1Object;
      return (d<v>)a1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      e e;
      Object object2 = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          e = (e)this.t0;
          n.b(param1Object);
          object1 = object2;
          object2 = this;
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        e = (e)this.t0;
        object1 = this;
        param1Object = object2;
        ((a)object1).t0 = e;
        ((a)object1).s0 = 1;
        Object object = d.a(e, (d)object1);
      } 
      param1Object = param1Object;
      List<c0> list = param1Object.c();
      int j = list.size();
      boolean bool = false;
      i = 0;
      while (true) {
        if (i < j) {
          if ((((c0)list.get(i)).o() ^ true) == 0) {
            i = 0;
            break;
          } 
          i++;
          continue;
        } 
        i = 1;
        break;
      } 
      if (i != 0) {
        u u = ((a)object2).u0.F1();
        b b1 = ((a)object2).u0;
        long l = u.a((e)e, (r)param1Object, e.a());
        e e1 = (e)b1.G1().getValue();
        float f = e1.j(e1.p(l));
        if (e1.e().dispatchRawDelta(f) == 0.0F) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i == 0) {
          param1Object = param1Object.c();
          j = param1Object.size();
          for (i = bool; i < j; i++)
            ((c0)param1Object.get(i)).a(); 
        } 
      } 
      param1Object = object1;
      Object object1 = object2;
      ((a)object1).t0 = e;
      ((a)object1).s0 = 1;
      Object object3 = d.a(e, (d)object1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\gestures\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */