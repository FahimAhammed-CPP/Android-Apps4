package androidx.compose.foundation.gestures;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import l0.k3;
import q1.u0;
import r.u;

final class MouseWheelScrollElement extends u0<b> {
  private final k3<e> c;
  
  private final u d;
  
  public MouseWheelScrollElement(k3<e> paramk3, u paramu) {
    this.c = paramk3;
    this.d = paramu;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof MouseWheelScrollElement))
      return false; 
    k3<e> k31 = this.c;
    paramObject = paramObject;
    return !q.e(k31, ((MouseWheelScrollElement)paramObject).c) ? false : (!!q.e(this.d, ((MouseWheelScrollElement)paramObject).d));
  }
  
  public int hashCode() {
    return this.c.hashCode() * 31 + this.d.hashCode();
  }
  
  public b s() {
    return new b(this.c, this.d);
  }
  
  public void t(b paramb) {
    q.j(paramb, "node");
    paramb.I1(this.c);
    paramb.H1(this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\gestures\MouseWheelScrollElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */