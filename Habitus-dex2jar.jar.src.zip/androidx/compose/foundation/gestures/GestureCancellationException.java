package androidx.compose.foundation.gestures;

import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.h;

public final class GestureCancellationException extends CancellationException {
  static {
  
  }
  
  public GestureCancellationException() {
    this(null, 1, null);
  }
  
  public GestureCancellationException(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\gestures\GestureCancellationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */