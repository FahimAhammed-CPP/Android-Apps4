package androidx.compose.foundation.gestures;

import a1.f;
import a1.g;
import dk.l;
import dk.p;
import k1.f;
import k2.v;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.g0;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l0.c3;
import l0.j1;
import l0.k3;
import q.g0;
import r.o;
import r.q;
import r.w;
import r.z;
import rj.n;
import rj.v;

final class e {
  private final q a;
  
  private final boolean b;
  
  private final k3<k1.c> c;
  
  private final z d;
  
  private final o e;
  
  private final g0 f;
  
  private final j1<Boolean> g;
  
  public e(q paramq, boolean paramBoolean, k3<k1.c> paramk3, z paramz, o paramo, g0 paramg0) {
    this.a = paramq;
    this.b = paramBoolean;
    this.c = paramk3;
    this.d = paramz;
    this.e = paramo;
    this.f = paramg0;
    this.g = c3.j(Boolean.FALSE, null, 2, null);
  }
  
  private final boolean f() {
    return (this.d.getCanScrollForward() || this.d.getCanScrollBackward());
  }
  
  public final long a(w paramw, long paramLong, int paramInt) {
    q.j(paramw, "$this$dispatchScroll");
    paramLong = m(paramLong);
    a a = new a(this, paramInt, paramw);
    return (this.f != null && f()) ? this.f.a(paramLong, paramInt, a) : ((f)a.invoke(f.d(paramLong))).x();
  }
  
  public final Object b(long paramLong, vj.d<? super v> paramd) {
    // Byte code:
    //   0: aload_3
    //   1: instanceof androidx/compose/foundation/gestures/e$b
    //   4: ifeq -> 44
    //   7: aload_3
    //   8: checkcast androidx/compose/foundation/gestures/e$b
    //   11: astore #5
    //   13: aload #5
    //   15: getfield v0 : I
    //   18: istore #4
    //   20: iload #4
    //   22: ldc -2147483648
    //   24: iand
    //   25: ifeq -> 44
    //   28: aload #5
    //   30: iload #4
    //   32: ldc -2147483648
    //   34: iadd
    //   35: putfield v0 : I
    //   38: aload #5
    //   40: astore_3
    //   41: goto -> 54
    //   44: new androidx/compose/foundation/gestures/e$b
    //   47: dup
    //   48: aload_0
    //   49: aload_3
    //   50: invokespecial <init> : (Landroidx/compose/foundation/gestures/e;Lvj/d;)V
    //   53: astore_3
    //   54: aload_3
    //   55: getfield t0 : Ljava/lang/Object;
    //   58: astore #5
    //   60: invokestatic d : ()Ljava/lang/Object;
    //   63: astore #6
    //   65: aload_3
    //   66: getfield v0 : I
    //   69: istore #4
    //   71: iload #4
    //   73: ifeq -> 108
    //   76: iload #4
    //   78: iconst_1
    //   79: if_icmpne -> 98
    //   82: aload_3
    //   83: getfield s0 : Ljava/lang/Object;
    //   86: checkcast kotlin/jvm/internal/g0
    //   89: astore_3
    //   90: aload #5
    //   92: invokestatic b : (Ljava/lang/Object;)V
    //   95: goto -> 181
    //   98: new java/lang/IllegalStateException
    //   101: dup
    //   102: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   104: invokespecial <init> : (Ljava/lang/String;)V
    //   107: athrow
    //   108: aload #5
    //   110: invokestatic b : (Ljava/lang/Object;)V
    //   113: new kotlin/jvm/internal/g0
    //   116: dup
    //   117: invokespecial <init> : ()V
    //   120: astore #5
    //   122: aload #5
    //   124: lload_1
    //   125: putfield s0 : J
    //   128: aload_0
    //   129: getfield d : Lr/z;
    //   132: astore #7
    //   134: new androidx/compose/foundation/gestures/e$c
    //   137: dup
    //   138: aload_0
    //   139: aload #5
    //   141: lload_1
    //   142: aconst_null
    //   143: invokespecial <init> : (Landroidx/compose/foundation/gestures/e;Lkotlin/jvm/internal/g0;JLvj/d;)V
    //   146: astore #8
    //   148: aload_3
    //   149: aload #5
    //   151: putfield s0 : Ljava/lang/Object;
    //   154: aload_3
    //   155: iconst_1
    //   156: putfield v0 : I
    //   159: aload #7
    //   161: aconst_null
    //   162: aload #8
    //   164: aload_3
    //   165: iconst_1
    //   166: aconst_null
    //   167: invokestatic c : (Lr/z;Lq/z;Ldk/p;Lvj/d;ILjava/lang/Object;)Ljava/lang/Object;
    //   170: aload #6
    //   172: if_acmpne -> 178
    //   175: aload #6
    //   177: areturn
    //   178: aload #5
    //   180: astore_3
    //   181: aload_3
    //   182: getfield s0 : J
    //   185: invokestatic b : (J)Lk2/v;
    //   188: areturn
  }
  
  public final o c() {
    return this.e;
  }
  
  public final k3<k1.c> d() {
    return this.c;
  }
  
  public final z e() {
    return this.d;
  }
  
  public final Object g(long paramLong, vj.d<? super v> paramd) {
    // Byte code:
    //   0: aload_3
    //   1: instanceof androidx/compose/foundation/gestures/e$d
    //   4: ifeq -> 44
    //   7: aload_3
    //   8: checkcast androidx/compose/foundation/gestures/e$d
    //   11: astore #5
    //   13: aload #5
    //   15: getfield v0 : I
    //   18: istore #4
    //   20: iload #4
    //   22: ldc -2147483648
    //   24: iand
    //   25: ifeq -> 44
    //   28: aload #5
    //   30: iload #4
    //   32: ldc -2147483648
    //   34: iadd
    //   35: putfield v0 : I
    //   38: aload #5
    //   40: astore_3
    //   41: goto -> 54
    //   44: new androidx/compose/foundation/gestures/e$d
    //   47: dup
    //   48: aload_0
    //   49: aload_3
    //   50: invokespecial <init> : (Landroidx/compose/foundation/gestures/e;Lvj/d;)V
    //   53: astore_3
    //   54: aload_3
    //   55: getfield t0 : Ljava/lang/Object;
    //   58: astore #6
    //   60: invokestatic d : ()Ljava/lang/Object;
    //   63: astore #5
    //   65: aload_3
    //   66: getfield v0 : I
    //   69: istore #4
    //   71: iload #4
    //   73: ifeq -> 117
    //   76: iload #4
    //   78: iconst_1
    //   79: if_icmpeq -> 101
    //   82: iload #4
    //   84: iconst_2
    //   85: if_icmpne -> 91
    //   88: goto -> 101
    //   91: new java/lang/IllegalStateException
    //   94: dup
    //   95: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   97: invokespecial <init> : (Ljava/lang/String;)V
    //   100: athrow
    //   101: aload_3
    //   102: getfield s0 : Ljava/lang/Object;
    //   105: checkcast androidx/compose/foundation/gestures/e
    //   108: astore_3
    //   109: aload #6
    //   111: invokestatic b : (Ljava/lang/Object;)V
    //   114: goto -> 232
    //   117: aload #6
    //   119: invokestatic b : (Ljava/lang/Object;)V
    //   122: aload_0
    //   123: iconst_1
    //   124: invokevirtual i : (Z)V
    //   127: aload_0
    //   128: lload_1
    //   129: invokevirtual n : (J)J
    //   132: lstore_1
    //   133: new androidx/compose/foundation/gestures/e$e
    //   136: dup
    //   137: aload_0
    //   138: aconst_null
    //   139: invokespecial <init> : (Landroidx/compose/foundation/gestures/e;Lvj/d;)V
    //   142: astore #6
    //   144: aload_0
    //   145: getfield f : Lq/g0;
    //   148: ifnull -> 198
    //   151: aload_0
    //   152: invokespecial f : ()Z
    //   155: ifeq -> 198
    //   158: aload_0
    //   159: getfield f : Lq/g0;
    //   162: astore #7
    //   164: aload_3
    //   165: aload_0
    //   166: putfield s0 : Ljava/lang/Object;
    //   169: aload_3
    //   170: iconst_1
    //   171: putfield v0 : I
    //   174: aload #7
    //   176: lload_1
    //   177: aload #6
    //   179: aload_3
    //   180: invokeinterface d : (JLdk/p;Lvj/d;)Ljava/lang/Object;
    //   185: aload #5
    //   187: if_acmpne -> 193
    //   190: aload #5
    //   192: areturn
    //   193: aload_0
    //   194: astore_3
    //   195: goto -> 232
    //   198: lload_1
    //   199: invokestatic b : (J)Lk2/v;
    //   202: astore #7
    //   204: aload_3
    //   205: aload_0
    //   206: putfield s0 : Ljava/lang/Object;
    //   209: aload_3
    //   210: iconst_2
    //   211: putfield v0 : I
    //   214: aload #6
    //   216: aload #7
    //   218: aload_3
    //   219: invokeinterface invoke : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   224: aload #5
    //   226: if_acmpne -> 193
    //   229: aload #5
    //   231: areturn
    //   232: aload_3
    //   233: iconst_0
    //   234: invokevirtual i : (Z)V
    //   237: getstatic rj/v.a : Lrj/v;
    //   240: areturn
  }
  
  public final long h(long paramLong) {
    return this.d.isScrollInProgress() ? f.b.c() : q(j(this.d.dispatchRawDelta(j(p(paramLong)))));
  }
  
  public final void i(boolean paramBoolean) {
    this.g.setValue(Boolean.valueOf(paramBoolean));
  }
  
  public final float j(float paramFloat) {
    float f = paramFloat;
    if (this.b)
      f = paramFloat * -1; 
    return f;
  }
  
  public final long k(long paramLong) {
    long l = paramLong;
    if (this.b)
      l = f.u(paramLong, -1.0F); 
    return l;
  }
  
  public final boolean l() {
    if (!this.d.isScrollInProgress() && !((Boolean)this.g.getValue()).booleanValue()) {
      boolean bool1;
      g0 g01 = this.f;
      boolean bool2 = false;
      if (g01 != null) {
        bool1 = g01.b();
      } else {
        bool1 = false;
      } 
      return bool1 ? true : bool2;
    } 
    return true;
  }
  
  public final long m(long paramLong) {
    return (this.a == q.t0) ? f.i(paramLong, 0.0F, 0.0F, 1, null) : f.i(paramLong, 0.0F, 0.0F, 2, null);
  }
  
  public final long n(long paramLong) {
    return (this.a == q.t0) ? v.e(paramLong, 0.0F, 0.0F, 1, null) : v.e(paramLong, 0.0F, 0.0F, 2, null);
  }
  
  public final float o(long paramLong) {
    return (this.a == q.t0) ? v.h(paramLong) : v.i(paramLong);
  }
  
  public final float p(long paramLong) {
    return (this.a == q.t0) ? f.o(paramLong) : f.p(paramLong);
  }
  
  public final long q(float paramFloat) {
    boolean bool;
    if (paramFloat == 0.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? f.b.c() : ((this.a == q.t0) ? g.a(paramFloat, 0.0F) : g.a(0.0F, paramFloat));
  }
  
  public final long r(long paramLong, float paramFloat) {
    return (this.a == q.t0) ? v.e(paramLong, paramFloat, 0.0F, 2, null) : v.e(paramLong, 0.0F, paramFloat, 1, null);
  }
  
  static final class a extends r implements l<f, f> {
    a(e param1e, int param1Int, w param1w) {
      super(1);
    }
    
    public final long a(long param1Long) {
      k1.c c = (k1.c)this.s0.d().getValue();
      long l1 = c.d(param1Long, this.t0);
      long l2 = f.s(param1Long, l1);
      e e1 = this.s0;
      param1Long = e1.k(e1.q(this.u0.a(e1.p(e1.k(l2)))));
      l2 = c.b(param1Long, f.s(l2, param1Long), this.t0);
      return f.t(f.t(l1, param1Long), l2);
    }
  }
  
  @f(c = "androidx.compose.foundation.gestures.ScrollingLogic", f = "Scrollable.kt", l = {488}, m = "doFlingAnimation-QWom1Mo")
  static final class b extends kotlin.coroutines.jvm.internal.d {
    Object s0;
    
    int v0;
    
    b(e param1e, vj.d<? super b> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.t0 = param1Object;
      this.v0 |= Integer.MIN_VALUE;
      return this.u0.b(0L, (vj.d<? super v>)this);
    }
  }
  
  @f(c = "androidx.compose.foundation.gestures.ScrollingLogic$doFlingAnimation$2", f = "Scrollable.kt", l = {500}, m = "invokeSuspend")
  static final class c extends l implements p<w, vj.d<? super v>, Object> {
    Object s0;
    
    Object t0;
    
    long u0;
    
    int v0;
    
    c(e param1e, g0 param1g0, long param1Long, vj.d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      c c1 = new c(this.x0, this.y0, this.z0, (vj.d)param1d);
      c1.w0 = param1Object;
      return (vj.d<v>)c1;
    }
    
    public final Object invoke(w param1w, vj.d<? super v> param1d) {
      return ((c)create(param1w, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      long l1;
      g0 g01;
      Object object2;
      Object object3;
      Object object1 = wj.b.d();
      int i = this.v0;
      if (i != 0) {
        if (i == 1) {
          l1 = this.u0;
          g01 = (g0)this.t0;
          object1 = this.s0;
          object2 = this.w0;
          n.b(param1Object);
          object3 = param1Object;
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.w0;
        param1Object = new a(this.x0, (w)param1Object);
        b b = new b(this.x0, (l<? super f, f>)param1Object);
        param1Object = this.x0;
        g01 = this.y0;
        long l2 = this.z0;
        o o = param1Object.c();
        l1 = g01.s0;
        float f = param1Object.j(param1Object.o(l2));
        this.w0 = param1Object;
        this.s0 = param1Object;
        this.t0 = g01;
        this.u0 = l1;
        this.v0 = 1;
        object3 = o.a(b, f, (vj.d)this);
        if (object3 == object1)
          return object1; 
        object2 = param1Object;
        object1 = param1Object;
      } 
      g01.s0 = object1.r(l1, object2.j(((Number)object3).floatValue()));
      return v.a;
    }
    
    static final class a extends r implements l<f, f> {
      a(e param2e, w param2w) {
        super(1);
      }
      
      public final long a(long param2Long) {
        e e1 = this.s0;
        return e1.k(e1.a(this.t0, e1.k(param2Long), f.a.b()));
      }
    }
    
    public static final class b implements w {
      b(e param2e, l<? super f, f> param2l) {}
      
      public float a(float param2Float) {
        e e1 = this.a;
        return e1.p(((f)this.b.invoke(f.d(e1.q(param2Float)))).x());
      }
    }
  }
  
  static final class a extends r implements l<f, f> {
    a(e param1e, w param1w) {
      super(1);
    }
    
    public final long a(long param1Long) {
      e e1 = this.s0;
      return e1.k(e1.a(this.t0, e1.k(param1Long), f.a.b()));
    }
  }
  
  public static final class b implements w {
    b(e param1e, l<? super f, f> param1l) {}
    
    public float a(float param1Float) {
      e e1 = this.a;
      return e1.p(((f)this.b.invoke(f.d(e1.q(param1Float)))).x());
    }
  }
  
  @f(c = "androidx.compose.foundation.gestures.ScrollingLogic", f = "Scrollable.kt", l = {477, 479}, m = "onDragStopped-sF-c-tU")
  static final class d extends kotlin.coroutines.jvm.internal.d {
    Object s0;
    
    int v0;
    
    d(e param1e, vj.d<? super d> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.t0 = param1Object;
      this.v0 |= Integer.MIN_VALUE;
      return this.u0.g(0L, (vj.d<? super v>)this);
    }
  }
  
  @f(c = "androidx.compose.foundation.gestures.ScrollingLogic$onDragStopped$performFling$1", f = "Scrollable.kt", l = {464, 466, 468}, m = "invokeSuspend")
  static final class e extends l implements p<v, vj.d<? super v>, Object> {
    long s0;
    
    int t0;
    
    e(e param1e, vj.d<? super e> param1d) {
      super(2, param1d);
    }
    
    public final Object a(long param1Long, vj.d<? super v> param1d) {
      return ((e)create(v.b(param1Long), param1d)).invokeSuspend(v.a);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      e e1 = new e(this.v0, (vj.d)param1d);
      e1.u0 = ((v)param1Object).o();
      return (vj.d<v>)e1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      long l1;
      long l2;
      Object object = wj.b.d();
      int i = this.t0;
      if (i != 0) {
        if (i != 1) {
          if (i != 2) {
            if (i == 3) {
              long l3 = this.s0;
              l1 = this.u0;
              n.b(param1Object);
              l2 = l3;
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            l1 = this.s0;
            long l3 = this.u0;
            n.b(param1Object);
            l2 = ((v)param1Object).o();
            param1Object = this.v0.d().getValue();
            l1 = v.k(l1, l2);
            this.u0 = l3;
            this.s0 = l2;
            this.t0 = 3;
            param1Object = param1Object.a(l1, l2, (vj.d)this);
          } 
        } else {
          long l3 = this.u0;
          n.b(param1Object);
          l1 = v.k(l3, ((v)param1Object).o());
          param1Object = this.v0;
          this.u0 = l3;
          this.s0 = l1;
          this.t0 = 2;
          param1Object = param1Object.b(l1, (vj.d<? super v>)this);
        } 
      } else {
        n.b(param1Object);
        long l3 = this.u0;
        param1Object = this.v0.d().getValue();
        this.u0 = l3;
        this.t0 = 1;
        param1Object = param1Object.c(l3, (vj.d)this);
        if (param1Object == object)
          return object; 
        l1 = v.k(l3, ((v)param1Object).o());
        param1Object = this.v0;
        this.u0 = l3;
        this.s0 = l1;
        this.t0 = 2;
        param1Object = param1Object.b(l1, (vj.d<? super v>)this);
      } 
      return v.b(v.k(l1, v.k(l2, ((v)param1Object).o())));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\gestures\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */