package androidx.compose.foundation.gestures;

import a1.f;
import androidx.compose.ui.e;
import dk.a;
import dk.l;
import dk.q;
import k2.v;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.CoroutineScope;
import l1.c0;
import q.k;
import q1.u0;
import r.l;
import r.n;
import r.q;
import rj.v;
import t.m;
import vj.d;

public final class DraggableElement extends u0<l> {
  private final n c;
  
  private final l<c0, Boolean> d;
  
  private final q e;
  
  private final boolean f;
  
  private final m g;
  
  private final a<Boolean> h;
  
  private final q<CoroutineScope, f, d<? super v>, Object> i;
  
  private final q<CoroutineScope, v, d<? super v>, Object> j;
  
  private final boolean k;
  
  public DraggableElement(n paramn, l<? super c0, Boolean> paraml, q paramq, boolean paramBoolean1, m paramm, a<Boolean> parama, q<? super CoroutineScope, ? super f, ? super d<? super v>, ? extends Object> paramq1, q<? super CoroutineScope, ? super v, ? super d<? super v>, ? extends Object> paramq2, boolean paramBoolean2) {
    this.c = paramn;
    this.d = (l)paraml;
    this.e = paramq;
    this.f = paramBoolean1;
    this.g = paramm;
    this.h = parama;
    this.i = (q)paramq1;
    this.j = (q)paramq2;
    this.k = paramBoolean2;
  }
  
  public boolean equals(Object paramObject) {
    Object object;
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      object = paramObject.getClass();
    } else {
      object = null;
    } 
    if (!q.e(DraggableElement.class, object))
      return false; 
    q.h(paramObject, "null cannot be cast to non-null type androidx.compose.foundation.gestures.DraggableElement");
    paramObject = paramObject;
    return !q.e(this.c, ((DraggableElement)paramObject).c) ? false : (!q.e(this.d, ((DraggableElement)paramObject).d) ? false : ((this.e != ((DraggableElement)paramObject).e) ? false : ((this.f != ((DraggableElement)paramObject).f) ? false : (!q.e(this.g, ((DraggableElement)paramObject).g) ? false : (!q.e(this.h, ((DraggableElement)paramObject).h) ? false : (!q.e(this.i, ((DraggableElement)paramObject).i) ? false : (!q.e(this.j, ((DraggableElement)paramObject).j) ? false : (!(this.k != ((DraggableElement)paramObject).k)))))))));
  }
  
  public int hashCode() {
    byte b;
    int i = this.c.hashCode();
    int j = this.d.hashCode();
    int k = this.e.hashCode();
    int i1 = k.a(this.f);
    m m1 = this.g;
    if (m1 != null) {
      b = m1.hashCode();
    } else {
      b = 0;
    } 
    return (((((((i * 31 + j) * 31 + k) * 31 + i1) * 31 + b) * 31 + this.h.hashCode()) * 31 + this.i.hashCode()) * 31 + this.j.hashCode()) * 31 + k.a(this.k);
  }
  
  public l s() {
    return new l(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k);
  }
  
  public void t(l paraml) {
    q.j(paraml, "node");
    paraml.W1(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\gestures\DraggableElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */