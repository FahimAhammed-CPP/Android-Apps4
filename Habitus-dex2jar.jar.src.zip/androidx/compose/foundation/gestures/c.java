package androidx.compose.foundation.gestures;

import dk.p;
import k1.f;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import l0.k3;
import q.z;
import r.j;
import r.n;
import r.w;
import rj.n;
import rj.v;
import vj.d;
import wj.b;

final class c implements n, j {
  private final k3<e> a;
  
  private w b;
  
  public c(k3<e> paramk3) {
    this.a = paramk3;
    this.b = d.b();
  }
  
  public void a(float paramFloat) {
    e e = (e)this.a.getValue();
    e.a(this.b, e.q(paramFloat), f.a.a());
  }
  
  public Object b(z paramz, p<? super j, ? super d<? super v>, ? extends Object> paramp, d<? super v> paramd) {
    Object object = ((e)this.a.getValue()).e().scroll(paramz, new a(this, paramp, null), paramd);
    return (object == b.d()) ? object : v.a;
  }
  
  public final void c(w paramw) {
    q.j(paramw, "<set-?>");
    this.b = paramw;
  }
  
  @f(c = "androidx.compose.foundation.gestures.ScrollDraggableState$drag$2", f = "Scrollable.kt", l = {534}, m = "invokeSuspend")
  static final class a extends l implements p<w, d<? super v>, Object> {
    int s0;
    
    a(c param1c, p<? super j, ? super d<? super v>, ? extends Object> param1p, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.u0, this.v0, (d)param1d);
      a1.t0 = param1Object;
      return (d<v>)a1;
    }
    
    public final Object invoke(w param1w, d<? super v> param1d) {
      return ((a)create(param1w, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object<j, d<? super v>, Object> param1Object) {
      Object object = b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = (Object<j, d<? super v>, Object>)this.t0;
        this.u0.c((w)param1Object);
        param1Object = (Object<j, d<? super v>, Object>)this.v0;
        c c1 = this.u0;
        this.s0 = 1;
        if (param1Object.invoke(c1, this) == object)
          return object; 
      } 
      return v.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\gestures\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */