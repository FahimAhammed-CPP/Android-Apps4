package androidx.compose.foundation.gestures;

import androidx.compose.ui.platform.j1;
import androidx.compose.ui.platform.l1;
import dk.l;
import dk.p;
import dk.q;
import k2.v;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import l0.j1;
import l0.k3;
import l0.l;
import l1.c0;
import l1.q0;
import l1.r;
import p1.m;
import q.g0;
import r.o;
import r.q;
import r.w;
import r.z;
import rj.n;
import rj.v;
import t.m;

public final class d {
  private static final q<CoroutineScope, a1.f, vj.d<? super v>, Object> a = new c(null);
  
  private static final w b = new d();
  
  private static final m<Boolean> c = p1.e.a(b.s0);
  
  private static final w0.g d = new a();
  
  private static final Object e(l1.e parame, vj.d<? super r> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/compose/foundation/gestures/d$e
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast androidx/compose/foundation/gestures/d$e
    //   11: astore_3
    //   12: aload_3
    //   13: getfield u0 : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 37
    //   24: aload_3
    //   25: iload_2
    //   26: ldc -2147483648
    //   28: iadd
    //   29: putfield u0 : I
    //   32: aload_3
    //   33: astore_1
    //   34: goto -> 46
    //   37: new androidx/compose/foundation/gestures/d$e
    //   40: dup
    //   41: aload_1
    //   42: invokespecial <init> : (Lvj/d;)V
    //   45: astore_1
    //   46: aload_1
    //   47: getfield t0 : Ljava/lang/Object;
    //   50: astore_3
    //   51: invokestatic d : ()Ljava/lang/Object;
    //   54: astore #5
    //   56: aload_1
    //   57: getfield u0 : I
    //   60: istore_2
    //   61: iload_2
    //   62: ifeq -> 95
    //   65: iload_2
    //   66: iconst_1
    //   67: if_icmpne -> 85
    //   70: aload_1
    //   71: getfield s0 : Ljava/lang/Object;
    //   74: checkcast l1/e
    //   77: astore_0
    //   78: aload_3
    //   79: invokestatic b : (Ljava/lang/Object;)V
    //   82: goto -> 132
    //   85: new java/lang/IllegalStateException
    //   88: dup
    //   89: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   91: invokespecial <init> : (Ljava/lang/String;)V
    //   94: athrow
    //   95: aload_3
    //   96: invokestatic b : (Ljava/lang/Object;)V
    //   99: aload_1
    //   100: aload_0
    //   101: putfield s0 : Ljava/lang/Object;
    //   104: aload_1
    //   105: iconst_1
    //   106: putfield u0 : I
    //   109: aload_0
    //   110: aconst_null
    //   111: aload_1
    //   112: iconst_1
    //   113: aconst_null
    //   114: invokestatic a : (Ll1/e;Ll1/t;Lvj/d;ILjava/lang/Object;)Ljava/lang/Object;
    //   117: astore #4
    //   119: aload #4
    //   121: astore_3
    //   122: aload #4
    //   124: aload #5
    //   126: if_acmpne -> 132
    //   129: aload #5
    //   131: areturn
    //   132: aload_3
    //   133: checkcast l1/r
    //   136: astore_3
    //   137: aload_3
    //   138: invokevirtual f : ()I
    //   141: getstatic l1/u.a : Ll1/u$a;
    //   144: invokevirtual f : ()I
    //   147: invokestatic i : (II)Z
    //   150: ifeq -> 99
    //   153: aload_3
    //   154: areturn
  }
  
  public static final w0.g f() {
    return d;
  }
  
  public static final m<Boolean> g() {
    return c;
  }
  
  private static final androidx.compose.ui.e h(androidx.compose.ui.e parame, m paramm, q paramq, boolean paramBoolean1, z paramz, o paramo, g0 paramg0, boolean paramBoolean2, l paraml, int paramInt) {
    // Byte code:
    //   0: aload #8
    //   2: ldc -2012025036
    //   4: invokeinterface x : (I)V
    //   9: invokestatic K : ()Z
    //   12: ifeq -> 25
    //   15: ldc -2012025036
    //   17: iload #9
    //   19: iconst_m1
    //   20: ldc 'androidx.compose.foundation.gestures.pointerScrollable (Scrollable.kt:247)'
    //   22: invokestatic V : (IIILjava/lang/String;)V
    //   25: aload #8
    //   27: ldc -1730185954
    //   29: invokeinterface x : (I)V
    //   34: aload #5
    //   36: ifnonnull -> 54
    //   39: getstatic r/x.a : Lr/x;
    //   42: aload #8
    //   44: bipush #6
    //   46: invokevirtual a : (Ll0/l;I)Lr/o;
    //   49: astore #5
    //   51: goto -> 54
    //   54: aload #8
    //   56: invokeinterface Q : ()V
    //   61: aload #8
    //   63: ldc -492369756
    //   65: invokeinterface x : (I)V
    //   70: aload #8
    //   72: invokeinterface y : ()Ljava/lang/Object;
    //   77: astore #12
    //   79: getstatic l0/l.a : Ll0/l$a;
    //   82: astore #13
    //   84: aload #12
    //   86: astore #11
    //   88: aload #12
    //   90: aload #13
    //   92: invokevirtual a : ()Ljava/lang/Object;
    //   95: if_acmpne -> 122
    //   98: new k1/c
    //   101: dup
    //   102: invokespecial <init> : ()V
    //   105: aconst_null
    //   106: iconst_2
    //   107: aconst_null
    //   108: invokestatic j : (Ljava/lang/Object;Ll0/b3;ILjava/lang/Object;)Ll0/j1;
    //   111: astore #11
    //   113: aload #8
    //   115: aload #11
    //   117: invokeinterface r : (Ljava/lang/Object;)V
    //   122: aload #8
    //   124: invokeinterface Q : ()V
    //   129: aload #11
    //   131: checkcast l0/j1
    //   134: astore #11
    //   136: new androidx/compose/foundation/gestures/e
    //   139: dup
    //   140: aload_2
    //   141: iload_3
    //   142: aload #11
    //   144: aload #4
    //   146: aload #5
    //   148: aload #6
    //   150: invokespecial <init> : (Lr/q;ZLl0/k3;Lr/z;Lr/o;Lq/g0;)V
    //   153: aload #8
    //   155: iconst_0
    //   156: invokestatic n : (Ljava/lang/Object;Ll0/l;I)Ll0/k3;
    //   159: astore #6
    //   161: aload #8
    //   163: ldc 1157296644
    //   165: invokeinterface x : (I)V
    //   170: aload #8
    //   172: iload #7
    //   174: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   177: invokeinterface R : (Ljava/lang/Object;)Z
    //   182: istore_3
    //   183: aload #8
    //   185: invokeinterface y : ()Ljava/lang/Object;
    //   190: astore #4
    //   192: iload_3
    //   193: ifne -> 212
    //   196: aload #4
    //   198: aload #13
    //   200: invokevirtual a : ()Ljava/lang/Object;
    //   203: if_acmpne -> 209
    //   206: goto -> 212
    //   209: goto -> 230
    //   212: aload #6
    //   214: iload #7
    //   216: invokestatic d : (Ll0/k3;Z)Lk1/b;
    //   219: astore #4
    //   221: aload #8
    //   223: aload #4
    //   225: invokeinterface r : (Ljava/lang/Object;)V
    //   230: aload #8
    //   232: invokeinterface Q : ()V
    //   237: aload #4
    //   239: checkcast k1/b
    //   242: astore #12
    //   244: aload #8
    //   246: ldc -492369756
    //   248: invokeinterface x : (I)V
    //   253: aload #8
    //   255: invokeinterface y : ()Ljava/lang/Object;
    //   260: astore #5
    //   262: aload #5
    //   264: astore #4
    //   266: aload #5
    //   268: aload #13
    //   270: invokevirtual a : ()Ljava/lang/Object;
    //   273: if_acmpne -> 296
    //   276: new androidx/compose/foundation/gestures/c
    //   279: dup
    //   280: aload #6
    //   282: invokespecial <init> : (Ll0/k3;)V
    //   285: astore #4
    //   287: aload #8
    //   289: aload #4
    //   291: invokeinterface r : (Ljava/lang/Object;)V
    //   296: aload #8
    //   298: invokeinterface Q : ()V
    //   303: aload #4
    //   305: checkcast androidx/compose/foundation/gestures/c
    //   308: astore #14
    //   310: aload #8
    //   312: iconst_0
    //   313: invokestatic a : (Ll0/l;I)Lr/u;
    //   316: astore #15
    //   318: getstatic androidx/compose/foundation/gestures/d.a : Ldk/q;
    //   321: astore #16
    //   323: getstatic androidx/compose/foundation/gestures/d$f.s0 : Landroidx/compose/foundation/gestures/d$f;
    //   326: astore #17
    //   328: aload #8
    //   330: ldc 1157296644
    //   332: invokeinterface x : (I)V
    //   337: aload #8
    //   339: aload #6
    //   341: invokeinterface R : (Ljava/lang/Object;)Z
    //   346: istore_3
    //   347: aload #8
    //   349: invokeinterface y : ()Ljava/lang/Object;
    //   354: astore #5
    //   356: iload_3
    //   357: ifne -> 374
    //   360: aload #5
    //   362: astore #4
    //   364: aload #5
    //   366: aload #13
    //   368: invokevirtual a : ()Ljava/lang/Object;
    //   371: if_acmpne -> 394
    //   374: new androidx/compose/foundation/gestures/d$g
    //   377: dup
    //   378: aload #6
    //   380: invokespecial <init> : (Ll0/k3;)V
    //   383: astore #4
    //   385: aload #8
    //   387: aload #4
    //   389: invokeinterface r : (Ljava/lang/Object;)V
    //   394: aload #8
    //   396: invokeinterface Q : ()V
    //   401: aload #4
    //   403: checkcast dk/a
    //   406: astore #18
    //   408: aload #8
    //   410: ldc 511388516
    //   412: invokeinterface x : (I)V
    //   417: aload #8
    //   419: aload #11
    //   421: invokeinterface R : (Ljava/lang/Object;)Z
    //   426: istore_3
    //   427: aload #8
    //   429: aload #6
    //   431: invokeinterface R : (Ljava/lang/Object;)Z
    //   436: istore #10
    //   438: aload #8
    //   440: invokeinterface y : ()Ljava/lang/Object;
    //   445: astore #5
    //   447: iload_3
    //   448: iload #10
    //   450: ior
    //   451: ifne -> 468
    //   454: aload #5
    //   456: astore #4
    //   458: aload #5
    //   460: aload #13
    //   462: invokevirtual a : ()Ljava/lang/Object;
    //   465: if_acmpne -> 491
    //   468: new androidx/compose/foundation/gestures/d$h
    //   471: dup
    //   472: aload #11
    //   474: aload #6
    //   476: aconst_null
    //   477: invokespecial <init> : (Ll0/j1;Ll0/k3;Lvj/d;)V
    //   480: astore #4
    //   482: aload #8
    //   484: aload #4
    //   486: invokeinterface r : (Ljava/lang/Object;)V
    //   491: aload #8
    //   493: invokeinterface Q : ()V
    //   498: aload_0
    //   499: new androidx/compose/foundation/gestures/DraggableElement
    //   502: dup
    //   503: aload #14
    //   505: aload #17
    //   507: aload_2
    //   508: iload #7
    //   510: aload_1
    //   511: aload #18
    //   513: aload #16
    //   515: aload #4
    //   517: checkcast dk/q
    //   520: iconst_0
    //   521: invokespecial <init> : (Lr/n;Ldk/l;Lr/q;ZLt/m;Ldk/a;Ldk/q;Ldk/q;Z)V
    //   524: invokeinterface then : (Landroidx/compose/ui/e;)Landroidx/compose/ui/e;
    //   529: new androidx/compose/foundation/gestures/MouseWheelScrollElement
    //   532: dup
    //   533: aload #6
    //   535: aload #15
    //   537: invokespecial <init> : (Ll0/k3;Lr/u;)V
    //   540: invokeinterface then : (Landroidx/compose/ui/e;)Landroidx/compose/ui/e;
    //   545: aload #12
    //   547: aload #11
    //   549: invokeinterface getValue : ()Ljava/lang/Object;
    //   554: checkcast k1/c
    //   557: invokestatic a : (Landroidx/compose/ui/e;Lk1/b;Lk1/c;)Landroidx/compose/ui/e;
    //   560: astore_0
    //   561: invokestatic K : ()Z
    //   564: ifeq -> 570
    //   567: invokestatic U : ()V
    //   570: aload #8
    //   572: invokeinterface Q : ()V
    //   577: aload_0
    //   578: areturn
  }
  
  public static final androidx.compose.ui.e i(androidx.compose.ui.e parame, z paramz, q paramq, g0 paramg0, boolean paramBoolean1, boolean paramBoolean2, o paramo, m paramm) {
    l l;
    q.j(parame, "<this>");
    q.j(paramz, "state");
    q.j(paramq, "orientation");
    if (j1.c()) {
      l = new i(paramq, paramz, paramg0, paramBoolean1, paramBoolean2, paramo, paramm);
    } else {
      l = j1.a();
    } 
    return androidx.compose.ui.c.a(parame, l, new j(paramq, paramz, paramBoolean2, paramm, paramo, paramg0, paramBoolean1));
  }
  
  public static final androidx.compose.ui.e j(androidx.compose.ui.e parame, z paramz, q paramq, boolean paramBoolean1, boolean paramBoolean2, o paramo, m paramm) {
    q.j(parame, "<this>");
    q.j(paramz, "state");
    q.j(paramq, "orientation");
    return i(parame, paramz, paramq, null, paramBoolean1, paramBoolean2, paramo, paramm);
  }
  
  private static final k1.b l(k3<e> paramk3, boolean paramBoolean) {
    return new k(paramk3, paramBoolean);
  }
  
  public static final class a implements w0.g {
    public float f() {
      return 1.0F;
    }
    
    public <R> R fold(R param1R, p<? super R, ? super vj.g.b, ? extends R> param1p) {
      return (R)w0.g.a.a(this, param1R, param1p);
    }
    
    public <E extends vj.g.b> E get(vj.g.c<E> param1c) {
      return (E)w0.g.a.b(this, param1c);
    }
    
    public vj.g minusKey(vj.g.c<?> param1c) {
      return w0.g.a.c(this, param1c);
    }
    
    public vj.g plus(vj.g param1g) {
      return w0.g.a.d(this, param1g);
    }
  }
  
  static final class b extends r implements dk.a<Boolean> {
    public static final b s0 = new b();
    
    b() {
      super(0);
    }
    
    public final Boolean invoke() {
      return Boolean.FALSE;
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.gestures.ScrollableKt$NoOpOnDragStarted$1", f = "Scrollable.kt", l = {}, m = "invokeSuspend")
  static final class c extends l implements q<CoroutineScope, a1.f, vj.d<? super v>, Object> {
    int s0;
    
    c(vj.d<? super c> param1d) {
      super(3, param1d);
    }
    
    public final Object a(CoroutineScope param1CoroutineScope, long param1Long, vj.d<? super v> param1d) {
      return (new c((vj.d)param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      wj.b.d();
      if (this.s0 == 0) {
        n.b(param1Object);
        return v.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  public static final class d implements w {
    public float a(float param1Float) {
      return param1Float;
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.gestures.ScrollableKt", f = "Scrollable.kt", l = {371}, m = "awaitScrollEvent")
  static final class e extends kotlin.coroutines.jvm.internal.d {
    Object s0;
    
    int u0;
    
    e(vj.d<? super e> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.t0 = param1Object;
      this.u0 |= Integer.MIN_VALUE;
      return d.a(null, (vj.d)this);
    }
  }
  
  static final class f extends r implements l<c0, Boolean> {
    public static final f s0 = new f();
    
    f() {
      super(1);
    }
    
    public final Boolean a(c0 param1c0) {
      q.j(param1c0, "down");
      return Boolean.valueOf(q0.g(param1c0.m(), q0.a.b()) ^ true);
    }
  }
  
  static final class g extends r implements dk.a<Boolean> {
    g(k3<e> param1k3) {
      super(0);
    }
    
    public final Boolean invoke() {
      return Boolean.valueOf(((e)this.s0.getValue()).l());
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.gestures.ScrollableKt$pointerScrollable$3$1", f = "Scrollable.kt", l = {}, m = "invokeSuspend")
  static final class h extends l implements q<CoroutineScope, v, vj.d<? super v>, Object> {
    int s0;
    
    h(j1<k1.c> param1j1, k3<e> param1k3, vj.d<? super h> param1d) {
      super(3, param1d);
    }
    
    public final Object a(CoroutineScope param1CoroutineScope, long param1Long, vj.d<? super v> param1d) {
      h h1 = new h(this.u0, this.v0, (vj.d)param1d);
      h1.t0 = param1Long;
      return h1.invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      wj.b.d();
      if (this.s0 == 0) {
        n.b(param1Object);
        long l1 = this.t0;
        BuildersKt.launch$default(((k1.c)this.u0.getValue()).e(), null, null, new a(this.v0, l1, null), 3, null);
        return v.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.gestures.ScrollableKt$pointerScrollable$3$1$1", f = "Scrollable.kt", l = {286}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
      int s0;
      
      a(k3<e> param2k3, long param2Long, vj.d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final vj.d<v> create(Object param2Object, vj.d<?> param2d) {
        return (vj.d<v>)new a(this.t0, this.u0, (vj.d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, vj.d<? super v> param2d) {
        return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1) {
            n.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param2Object);
          param2Object = this.t0.getValue();
          long l1 = this.u0;
          this.s0 = 1;
          if (param2Object.g(l1, (vj.d<? super v>)this) == object)
            return object; 
        } 
        return v.a;
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.gestures.ScrollableKt$pointerScrollable$3$1$1", f = "Scrollable.kt", l = {286}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
    int s0;
    
    a(k3<e> param1k3, long param1Long, vj.d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      return (vj.d<v>)new a(this.t0, this.u0, (vj.d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, vj.d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0.getValue();
        long l1 = this.u0;
        this.s0 = 1;
        if (param1Object.g(l1, (vj.d<? super v>)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
  
  public static final class i extends r implements l<l1, v> {
    public i(q param1q, z param1z, g0 param1g0, boolean param1Boolean1, boolean param1Boolean2, o param1o, m param1m) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("scrollable");
      param1l1.a().b("orientation", this.s0);
      param1l1.a().b("state", this.t0);
      param1l1.a().b("overscrollEffect", this.u0);
      param1l1.a().b("enabled", Boolean.valueOf(this.v0));
      param1l1.a().b("reverseDirection", Boolean.valueOf(this.w0));
      param1l1.a().b("flingBehavior", this.x0);
      param1l1.a().b("interactionSource", this.y0);
    }
  }
  
  static final class j extends r implements q<androidx.compose.ui.e, l, Integer, androidx.compose.ui.e> {
    j(q param1q, z param1z, boolean param1Boolean1, m param1m, o param1o, g0 param1g0, boolean param1Boolean2) {
      super(3);
    }
    
    public final androidx.compose.ui.e invoke(androidx.compose.ui.e param1e, l param1l, int param1Int) {
      // Byte code:
      //   0: aload_1
      //   1: ldc '$this$composed'
      //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: aload_2
      //   7: ldc -629830927
      //   9: invokeinterface x : (I)V
      //   14: invokestatic K : ()Z
      //   17: ifeq -> 29
      //   20: ldc -629830927
      //   22: iload_3
      //   23: iconst_m1
      //   24: ldc 'androidx.compose.foundation.gestures.scrollable.<anonymous> (Scrollable.kt:161)'
      //   26: invokestatic V : (IIILjava/lang/String;)V
      //   29: aload_2
      //   30: ldc 773894976
      //   32: invokeinterface x : (I)V
      //   37: aload_2
      //   38: ldc -492369756
      //   40: invokeinterface x : (I)V
      //   45: aload_2
      //   46: invokeinterface y : ()Ljava/lang/Object;
      //   51: astore #7
      //   53: aload #7
      //   55: astore_1
      //   56: aload #7
      //   58: getstatic l0/l.a : Ll0/l$a;
      //   61: invokevirtual a : ()Ljava/lang/Object;
      //   64: if_acmpne -> 89
      //   67: new l0/x
      //   70: dup
      //   71: getstatic vj/h.s0 : Lvj/h;
      //   74: aload_2
      //   75: invokestatic h : (Lvj/g;Ll0/l;)Lkotlinx/coroutines/CoroutineScope;
      //   78: invokespecial <init> : (Lkotlinx/coroutines/CoroutineScope;)V
      //   81: astore_1
      //   82: aload_2
      //   83: aload_1
      //   84: invokeinterface r : (Ljava/lang/Object;)V
      //   89: aload_2
      //   90: invokeinterface Q : ()V
      //   95: aload_1
      //   96: checkcast l0/x
      //   99: invokevirtual a : ()Lkotlinx/coroutines/CoroutineScope;
      //   102: astore #8
      //   104: aload_2
      //   105: invokeinterface Q : ()V
      //   110: iconst_0
      //   111: istore_3
      //   112: aload_0
      //   113: getfield s0 : Lr/q;
      //   116: astore_1
      //   117: aload_0
      //   118: getfield t0 : Lr/z;
      //   121: astore #7
      //   123: aload_0
      //   124: getfield u0 : Z
      //   127: istore #5
      //   129: aload_0
      //   130: getfield s0 : Lr/q;
      //   133: astore #9
      //   135: aload_0
      //   136: getfield t0 : Lr/z;
      //   139: astore #10
      //   141: aload_0
      //   142: getfield u0 : Z
      //   145: istore #6
      //   147: aload_2
      //   148: ldc -568225417
      //   150: invokeinterface x : (I)V
      //   155: iconst_0
      //   156: istore #4
      //   158: iload_3
      //   159: iconst_4
      //   160: if_icmpge -> 209
      //   163: iload #4
      //   165: aload_2
      //   166: iconst_4
      //   167: anewarray java/lang/Object
      //   170: dup
      //   171: iconst_0
      //   172: aload #8
      //   174: aastore
      //   175: dup
      //   176: iconst_1
      //   177: aload_1
      //   178: aastore
      //   179: dup
      //   180: iconst_2
      //   181: aload #7
      //   183: aastore
      //   184: dup
      //   185: iconst_3
      //   186: iload #5
      //   188: invokestatic valueOf : (Z)Ljava/lang/Boolean;
      //   191: aastore
      //   192: iload_3
      //   193: aaload
      //   194: invokeinterface R : (Ljava/lang/Object;)Z
      //   199: ior
      //   200: istore #4
      //   202: iload_3
      //   203: iconst_1
      //   204: iadd
      //   205: istore_3
      //   206: goto -> 158
      //   209: aload_2
      //   210: invokeinterface y : ()Ljava/lang/Object;
      //   215: astore #7
      //   217: iload #4
      //   219: ifne -> 236
      //   222: aload #7
      //   224: astore_1
      //   225: aload #7
      //   227: getstatic l0/l.a : Ll0/l$a;
      //   230: invokevirtual a : ()Ljava/lang/Object;
      //   233: if_acmpne -> 259
      //   236: new r/d
      //   239: dup
      //   240: aload #8
      //   242: aload #9
      //   244: aload #10
      //   246: iload #6
      //   248: invokespecial <init> : (Lkotlinx/coroutines/CoroutineScope;Lr/q;Lr/z;Z)V
      //   251: astore_1
      //   252: aload_2
      //   253: aload_1
      //   254: invokeinterface r : (Ljava/lang/Object;)V
      //   259: aload_2
      //   260: invokeinterface Q : ()V
      //   265: aload_1
      //   266: checkcast r/d
      //   269: astore #7
      //   271: getstatic androidx/compose/ui/e.a : Landroidx/compose/ui/e$a;
      //   274: astore_1
      //   275: aload_1
      //   276: invokestatic a : (Landroidx/compose/ui/e;)Landroidx/compose/ui/e;
      //   279: aload #7
      //   281: invokevirtual N : ()Landroidx/compose/ui/e;
      //   284: invokeinterface then : (Landroidx/compose/ui/e;)Landroidx/compose/ui/e;
      //   289: aload_0
      //   290: getfield v0 : Lt/m;
      //   293: aload_0
      //   294: getfield s0 : Lr/q;
      //   297: aload_0
      //   298: getfield u0 : Z
      //   301: aload_0
      //   302: getfield t0 : Lr/z;
      //   305: aload_0
      //   306: getfield w0 : Lr/o;
      //   309: aload_0
      //   310: getfield x0 : Lq/g0;
      //   313: aload_0
      //   314: getfield y0 : Z
      //   317: aload_2
      //   318: iconst_0
      //   319: invokestatic c : (Landroidx/compose/ui/e;Lt/m;Lr/q;ZLr/z;Lr/o;Lq/g0;ZLl0/l;I)Landroidx/compose/ui/e;
      //   322: astore #7
      //   324: aload_0
      //   325: getfield y0 : Z
      //   328: ifeq -> 335
      //   331: getstatic androidx/compose/foundation/gestures/a.c : Landroidx/compose/foundation/gestures/a;
      //   334: astore_1
      //   335: aload #7
      //   337: aload_1
      //   338: invokeinterface then : (Landroidx/compose/ui/e;)Landroidx/compose/ui/e;
      //   343: astore_1
      //   344: invokestatic K : ()Z
      //   347: ifeq -> 353
      //   350: invokestatic U : ()V
      //   353: aload_2
      //   354: invokeinterface Q : ()V
      //   359: aload_1
      //   360: areturn
    }
  }
  
  public static final class k implements k1.b {
    k(k3<e> param1k3, boolean param1Boolean) {}
    
    public Object onPostFling-RZ2iAVY(long param1Long1, long param1Long2, vj.d<? super v> param1d) {
      // Byte code:
      //   0: aload #5
      //   2: instanceof androidx/compose/foundation/gestures/d$k$a
      //   5: ifeq -> 47
      //   8: aload #5
      //   10: checkcast androidx/compose/foundation/gestures/d$k$a
      //   13: astore #7
      //   15: aload #7
      //   17: getfield w0 : I
      //   20: istore #6
      //   22: iload #6
      //   24: ldc -2147483648
      //   26: iand
      //   27: ifeq -> 47
      //   30: aload #7
      //   32: iload #6
      //   34: ldc -2147483648
      //   36: iadd
      //   37: putfield w0 : I
      //   40: aload #7
      //   42: astore #5
      //   44: goto -> 59
      //   47: new androidx/compose/foundation/gestures/d$k$a
      //   50: dup
      //   51: aload_0
      //   52: aload #5
      //   54: invokespecial <init> : (Landroidx/compose/foundation/gestures/d$k;Lvj/d;)V
      //   57: astore #5
      //   59: aload #5
      //   61: getfield u0 : Ljava/lang/Object;
      //   64: astore #7
      //   66: invokestatic d : ()Ljava/lang/Object;
      //   69: astore #8
      //   71: aload #5
      //   73: getfield w0 : I
      //   76: istore #6
      //   78: iload #6
      //   80: ifeq -> 123
      //   83: iload #6
      //   85: iconst_1
      //   86: if_icmpne -> 113
      //   89: aload #5
      //   91: getfield t0 : J
      //   94: lstore_3
      //   95: aload #5
      //   97: getfield s0 : Ljava/lang/Object;
      //   100: checkcast androidx/compose/foundation/gestures/d$k
      //   103: astore #5
      //   105: aload #7
      //   107: invokestatic b : (Ljava/lang/Object;)V
      //   110: goto -> 190
      //   113: new java/lang/IllegalStateException
      //   116: dup
      //   117: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   119: invokespecial <init> : (Ljava/lang/String;)V
      //   122: athrow
      //   123: aload #7
      //   125: invokestatic b : (Ljava/lang/Object;)V
      //   128: aload_0
      //   129: getfield t0 : Z
      //   132: ifeq -> 206
      //   135: aload_0
      //   136: getfield s0 : Ll0/k3;
      //   139: invokeinterface getValue : ()Ljava/lang/Object;
      //   144: checkcast androidx/compose/foundation/gestures/e
      //   147: astore #7
      //   149: aload #5
      //   151: aload_0
      //   152: putfield s0 : Ljava/lang/Object;
      //   155: aload #5
      //   157: lload_3
      //   158: putfield t0 : J
      //   161: aload #5
      //   163: iconst_1
      //   164: putfield w0 : I
      //   167: aload #7
      //   169: lload_3
      //   170: aload #5
      //   172: invokevirtual b : (JLvj/d;)Ljava/lang/Object;
      //   175: astore #7
      //   177: aload #7
      //   179: aload #8
      //   181: if_acmpne -> 187
      //   184: aload #8
      //   186: areturn
      //   187: aload_0
      //   188: astore #5
      //   190: lload_3
      //   191: aload #7
      //   193: checkcast k2/v
      //   196: invokevirtual o : ()J
      //   199: invokestatic k : (JJ)J
      //   202: lstore_1
      //   203: goto -> 216
      //   206: getstatic k2/v.b : Lk2/v$a;
      //   209: invokevirtual a : ()J
      //   212: lstore_1
      //   213: aload_0
      //   214: astore #5
      //   216: lload_1
      //   217: invokestatic b : (J)Lk2/v;
      //   220: astore #7
      //   222: aload #5
      //   224: getfield s0 : Ll0/k3;
      //   227: astore #5
      //   229: aload #7
      //   231: invokevirtual o : ()J
      //   234: pop2
      //   235: aload #5
      //   237: invokeinterface getValue : ()Ljava/lang/Object;
      //   242: checkcast androidx/compose/foundation/gestures/e
      //   245: iconst_0
      //   246: invokevirtual i : (Z)V
      //   249: aload #7
      //   251: areturn
    }
    
    public long onPostScroll-DzOQY0M(long param1Long1, long param1Long2, int param1Int) {
      return this.t0 ? ((e)this.s0.getValue()).h(param1Long2) : a1.f.b.c();
    }
    
    public long onPreScroll-OzD1aCk(long param1Long, int param1Int) {
      if (k1.f.d(param1Int, k1.f.a.b()))
        ((e)this.s0.getValue()).i(true); 
      return a1.f.b.c();
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.gestures.ScrollableKt$scrollableNestedScrollConnection$1", f = "Scrollable.kt", l = {574}, m = "onPostFling-RZ2iAVY")
    static final class a extends kotlin.coroutines.jvm.internal.d {
      Object s0;
      
      long t0;
      
      int w0;
      
      a(d.k param2k, vj.d<? super a> param2d) {
        super(param2d);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        this.u0 = param2Object;
        this.w0 |= Integer.MIN_VALUE;
        return this.v0.onPostFling-RZ2iAVY(0L, 0L, (vj.d<? super v>)this);
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.compose.foundation.gestures.ScrollableKt$scrollableNestedScrollConnection$1", f = "Scrollable.kt", l = {574}, m = "onPostFling-RZ2iAVY")
  static final class a extends kotlin.coroutines.jvm.internal.d {
    Object s0;
    
    long t0;
    
    int w0;
    
    a(d.k param1k, vj.d<? super a> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.u0 = param1Object;
      this.w0 |= Integer.MIN_VALUE;
      return this.v0.onPostFling-RZ2iAVY(0L, 0L, (vj.d<? super v>)this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\gestures\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */