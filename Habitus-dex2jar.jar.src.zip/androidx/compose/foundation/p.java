package androidx.compose.foundation;

import androidx.compose.ui.e;
import dk.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import o1.s;
import p1.e;
import p1.m;
import rj.v;

public final class p {
  private static final m<l<s, v>> a = e.a(a.s0);
  
  public static final m<l<s, v>> a() {
    return a;
  }
  
  public static final e b(e parame, l<? super s, v> paraml) {
    q.j(parame, "<this>");
    q.j(paraml, "onPositioned");
    return parame.then((e)new FocusedBoundsObserverElement(paraml));
  }
  
  static final class a extends r implements dk.a<l<? super s, ? extends v>> {
    public static final a s0 = new a();
    
    a() {
      super(0);
    }
    
    public final l<s, v> d() {
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */