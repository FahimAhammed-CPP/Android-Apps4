package androidx.compose.foundation;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import q1.u0;
import t.m;

final class FocusableElement extends u0<m> {
  private final m c;
  
  public FocusableElement(m paramm) {
    this.c = paramm;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof FocusableElement) ? false : (!!q.e(this.c, ((FocusableElement)paramObject).c)));
  }
  
  public int hashCode() {
    m m1 = this.c;
    return (m1 != null) ? m1.hashCode() : 0;
  }
  
  public m s() {
    return new m(this.c);
  }
  
  public void t(m paramm) {
    q.j(paramm, "node");
    paramm.G1(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\FocusableElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */