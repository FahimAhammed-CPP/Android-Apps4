package androidx.compose.foundation;

import dk.a;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q1.j;
import rj.v;
import t.m;

final class i extends a {
  private a<v> N0;
  
  private final h O0;
  
  private final j P0;
  
  private i(m paramm, boolean paramBoolean, String paramString1, u1.i parami, a<v> parama1, String paramString2, a<v> parama2, a<v> parama3) {
    super(paramm, paramBoolean, paramString1, parami, parama1, null);
    this.N0 = parama2;
    this.O0 = (h)A1((j)new h(paramBoolean, paramString1, parami, parama1, paramString2, parama2, null));
    this.P0 = (j)A1((j)new j(paramBoolean, paramm, parama1, I1(), this.N0, parama3));
  }
  
  public j K1() {
    return this.P0;
  }
  
  public h L1() {
    return this.O0;
  }
  
  public final void M1(m paramm, boolean paramBoolean, String paramString1, u1.i parami, a<v> parama1, String paramString2, a<v> parama2, a<v> parama3) {
    boolean bool1;
    q.j(paramm, "interactionSource");
    q.j(parama1, "onClick");
    a<v> a1 = this.N0;
    boolean bool2 = true;
    if (a1 == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (parama2 != null)
      bool2 = false; 
    if (bool1 != bool2)
      G1(); 
    this.N0 = parama2;
    J1(paramm, paramBoolean, paramString1, parami, parama1);
    L1().C1(paramBoolean, paramString1, parami, parama1, paramString2, parama2);
    K1().P1(paramBoolean, paramm, parama1, parama2, parama3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */