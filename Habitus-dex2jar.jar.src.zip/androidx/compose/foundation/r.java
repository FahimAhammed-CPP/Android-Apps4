package androidx.compose.foundation;

import androidx.compose.ui.e;
import kotlin.jvm.internal.q;
import t.m;

public final class r {
  public static final e a(e parame, m paramm, boolean paramBoolean) {
    e.a a;
    q.j(parame, "<this>");
    q.j(paramm, "interactionSource");
    if (paramBoolean) {
      HoverableElement hoverableElement = new HoverableElement(paramm);
    } else {
      a = e.a;
    } 
    return parame.then((e)a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */