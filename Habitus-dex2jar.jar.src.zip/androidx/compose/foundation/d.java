package androidx.compose.foundation;

import a1.l;
import androidx.compose.ui.e;
import b1.a4;
import b1.e1;
import b1.l4;
import b1.p1;
import b1.r4;
import b1.z3;
import d1.c;
import d1.e;
import d1.f;
import k2.e;
import k2.r;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q1.q;
import q1.r;

final class d extends e.c implements r {
  private long F0;
  
  private e1 G0;
  
  private float H0;
  
  private r4 I0;
  
  private l J0;
  
  private r K0;
  
  private z3 L0;
  
  private r4 M0;
  
  private d(long paramLong, e1 parame1, float paramFloat, r4 paramr4) {
    this.F0 = paramLong;
    this.G0 = parame1;
    this.H0 = paramFloat;
    this.I0 = paramr4;
  }
  
  private final void A1(c paramc) {
    z3 z31;
    if (l.e(paramc.b(), this.J0) && paramc.getLayoutDirection() == this.K0 && q.e(this.M0, this.I0)) {
      z31 = this.L0;
      q.g(z31);
    } else {
      z31 = this.I0.a(paramc.b(), paramc.getLayoutDirection(), (e)paramc);
    } 
    if (!p1.q(this.F0, p1.b.e()))
      a4.e((f)paramc, z31, this.F0, 0.0F, null, null, 0, 60, null); 
    e1 e11 = this.G0;
    if (e11 != null)
      a4.c((f)paramc, z31, e11, this.H0, null, null, 0, 56, null); 
    this.L0 = z31;
    this.J0 = l.c(paramc.b());
    this.K0 = paramc.getLayoutDirection();
    this.M0 = this.I0;
  }
  
  private final void B1(c paramc) {
    if (!p1.q(this.F0, p1.b.e()))
      e.m((f)paramc, this.F0, 0L, 0L, 0.0F, null, null, 0, 126, null); 
    e1 e11 = this.G0;
    if (e11 != null)
      e.l((f)paramc, e11, 0L, 0L, this.H0, null, null, 0, 118, null); 
  }
  
  public final void C1(e1 parame1) {
    this.G0 = parame1;
  }
  
  public final void D1(long paramLong) {
    this.F0 = paramLong;
  }
  
  public final void g(float paramFloat) {
    this.H0 = paramFloat;
  }
  
  public final void o0(r4 paramr4) {
    q.j(paramr4, "<set-?>");
    this.I0 = paramr4;
  }
  
  public void w(c paramc) {
    q.j(paramc, "<this>");
    if (this.I0 == l4.a()) {
      B1(paramc);
    } else {
      A1(paramc);
    } 
    paramc.V0();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */