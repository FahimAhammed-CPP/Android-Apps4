package androidx.compose.foundation;

import a1.f;
import android.view.KeyEvent;
import dk.p;
import j1.d;
import j1.e;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import l1.r;
import l1.t;
import q.l;
import q1.l;
import q1.n1;
import q1.o1;
import rj.n;
import rj.v;
import t.j;
import t.m;
import t.o;
import t.p;
import t.q;
import u1.i;
import vj.d;

abstract class a extends l implements o1, e {
  private m H0;
  
  private boolean I0;
  
  private String J0;
  
  private i K0;
  
  private dk.a<v> L0;
  
  private final a M0;
  
  private a(m paramm, boolean paramBoolean, String paramString, i parami, dk.a<v> parama) {
    this.H0 = paramm;
    this.I0 = paramBoolean;
    this.J0 = paramString;
    this.K0 = parami;
    this.L0 = parama;
    this.M0 = new a();
  }
  
  public void C(r paramr, t paramt, long paramLong) {
    q.j(paramr, "pointerEvent");
    q.j(paramt, "pass");
    H1().C(paramr, paramt, paramLong);
  }
  
  protected final void G1() {
    p p = this.M0.c();
    if (p != null) {
      o o = new o(p);
      this.H0.a((j)o);
    } 
    for (p p1 : this.M0.b().values())
      this.H0.a((j)new o(p1)); 
    this.M0.e(null);
    this.M0.b().clear();
  }
  
  public abstract b H1();
  
  protected final a I1() {
    return this.M0;
  }
  
  protected final void J1(m paramm, boolean paramBoolean, String paramString, i parami, dk.a<v> parama) {
    q.j(paramm, "interactionSource");
    q.j(parama, "onClick");
    if (!q.e(this.H0, paramm)) {
      G1();
      this.H0 = paramm;
    } 
    if (this.I0 != paramBoolean) {
      if (!paramBoolean)
        G1(); 
      this.I0 = paramBoolean;
    } 
    this.J0 = paramString;
    this.K0 = parami;
    this.L0 = parama;
  }
  
  public boolean e0(KeyEvent paramKeyEvent) {
    q.j(paramKeyEvent, "event");
    return false;
  }
  
  public void l1() {
    G1();
  }
  
  public boolean p0(KeyEvent paramKeyEvent) {
    q.j(paramKeyEvent, "event");
    if (this.I0 && l.f(paramKeyEvent)) {
      if (!this.M0.b().containsKey(j1.a.k(d.a(paramKeyEvent)))) {
        p p = new p(this.M0.a(), null);
        this.M0.b().put(j1.a.k(d.a(paramKeyEvent)), p);
        BuildersKt.launch$default(a1(), null, null, new b(this, p, null), 3, null);
        return true;
      } 
    } else if (this.I0 && l.b(paramKeyEvent)) {
      p p = this.M0.b().remove(j1.a.k(d.a(paramKeyEvent)));
      if (p != null)
        BuildersKt.launch$default(a1(), null, null, new c(this, p, null), 3, null); 
      this.L0.invoke();
      return true;
    } 
    return false;
  }
  
  public void q0() {
    H1().q0();
  }
  
  public static final class a {
    private final Map<j1.a, p> a = new LinkedHashMap<j1.a, p>();
    
    private p b;
    
    private long c = f.b.c();
    
    public final long a() {
      return this.c;
    }
    
    public final Map<j1.a, p> b() {
      return this.a;
    }
    
    public final p c() {
      return this.b;
    }
    
    public final void d(long param1Long) {
      this.c = param1Long;
    }
    
    public final void e(p param1p) {
      this.b = param1p;
    }
  }
  
  @f(c = "androidx.compose.foundation.AbstractClickableNode$onKeyEvent$1", f = "Clickable.kt", l = {718}, m = "invokeSuspend")
  static final class b extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    b(a param1a, p param1p, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      return (d<v>)new b(this.t0, this.u0, (d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((b)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = a.F1(this.t0);
        p p1 = this.u0;
        this.s0 = 1;
        if (param1Object.c((j)p1, (d)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
  
  @f(c = "androidx.compose.foundation.AbstractClickableNode$onKeyEvent$2$1", f = "Clickable.kt", l = {727}, m = "invokeSuspend")
  static final class c extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    c(a param1a, p param1p, d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      return (d<v>)new c(this.t0, this.u0, (d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((c)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = a.F1(this.t0);
        q q = new q(this.u0);
        this.s0 = 1;
        if (param1Object.c((j)q, (d)this) == object)
          return object; 
      } 
      return v.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */