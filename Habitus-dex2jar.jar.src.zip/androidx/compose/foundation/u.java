package androidx.compose.foundation;

import dk.l;
import dk.p;
import ik.j;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import l0.c3;
import l0.g1;
import l0.k3;
import l0.s2;
import p.j;
import q.z;
import r.a0;
import r.v;
import r.w;
import r.z;
import rj.v;
import t.l;
import t.m;
import t0.i;
import t0.j;
import t0.k;

public final class u implements z {
  public static final c i = new c(null);
  
  private static final i<u, ?> j = j.a(a.s0, b.s0);
  
  private final g1 a;
  
  private final g1 b;
  
  private final m c;
  
  private g1 d;
  
  private float e;
  
  private final z f;
  
  private final k3 g;
  
  private final k3 h;
  
  public u(int paramInt) {
    this.a = s2.a(paramInt);
    this.b = s2.a(0);
    this.c = l.a();
    this.d = s2.a(2147483647);
    this.f = a0.a(new f(this));
    this.g = c3.d(new e(this));
    this.h = c3.d(new d(this));
  }
  
  private final void j(int paramInt) {
    this.a.h(paramInt);
  }
  
  public float dispatchRawDelta(float paramFloat) {
    return this.f.dispatchRawDelta(paramFloat);
  }
  
  public final Object e(int paramInt, j<Float> paramj, vj.d<? super v> paramd) {
    Object object = v.a(this, (paramInt - h()), paramj, paramd);
    return (object == wj.b.d()) ? object : v.a;
  }
  
  public final m f() {
    return this.c;
  }
  
  public final int g() {
    return this.d.f();
  }
  
  public boolean getCanScrollBackward() {
    return ((Boolean)this.h.getValue()).booleanValue();
  }
  
  public boolean getCanScrollForward() {
    return ((Boolean)this.g.getValue()).booleanValue();
  }
  
  public final int h() {
    return this.a.f();
  }
  
  public final void i(int paramInt) {
    this.d.h(paramInt);
    if (h() > paramInt)
      j(paramInt); 
  }
  
  public boolean isScrollInProgress() {
    return this.f.isScrollInProgress();
  }
  
  public final void k(int paramInt) {
    this.b.h(paramInt);
  }
  
  public Object scroll(z paramz, p<? super w, ? super vj.d<? super v>, ? extends Object> paramp, vj.d<? super v> paramd) {
    Object object = this.f.scroll(paramz, paramp, paramd);
    return (object == wj.b.d()) ? object : v.a;
  }
  
  static final class a extends r implements p<k, u, Integer> {
    public static final a s0 = new a();
    
    a() {
      super(2);
    }
    
    public final Integer a(k param1k, u param1u) {
      q.j(param1k, "$this$Saver");
      q.j(param1u, "it");
      return Integer.valueOf(param1u.h());
    }
  }
  
  static final class b extends r implements l<Integer, u> {
    public static final b s0 = new b();
    
    b() {
      super(1);
    }
    
    public final u a(int param1Int) {
      return new u(param1Int);
    }
  }
  
  public static final class c {
    private c() {}
    
    public final i<u, ?> a() {
      return u.b();
    }
  }
  
  static final class d extends r implements dk.a<Boolean> {
    d(u param1u) {
      super(0);
    }
    
    public final Boolean invoke() {
      boolean bool;
      if (this.s0.h() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return Boolean.valueOf(bool);
    }
  }
  
  static final class e extends r implements dk.a<Boolean> {
    e(u param1u) {
      super(0);
    }
    
    public final Boolean invoke() {
      boolean bool;
      if (this.s0.h() < this.s0.g()) {
        bool = true;
      } else {
        bool = false;
      } 
      return Boolean.valueOf(bool);
    }
  }
  
  static final class f extends r implements l<Float, Float> {
    f(u param1u) {
      super(1);
    }
    
    public final Float invoke(float param1Float) {
      boolean bool;
      float f1 = this.s0.h() + param1Float + u.a(this.s0);
      float f2 = j.j(f1, 0.0F, this.s0.g());
      if (f1 == f2) {
        bool = true;
      } else {
        bool = false;
      } 
      f1 = f2 - this.s0.h();
      int i = fk.a.d(f1);
      u u1 = this.s0;
      u.d(u1, u1.h() + i);
      u.c(this.s0, f1 - i);
      if ((bool ^ true) != 0)
        param1Float = f1; 
      return Float.valueOf(param1Float);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundatio\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */