package androidx.compose.foundation;

import androidx.compose.ui.e;
import dk.a;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import q.k;
import q1.u0;
import rj.v;
import t.m;
import u1.i;

final class CombinedClickableElement extends u0<i> {
  private final m c;
  
  private final boolean d;
  
  private final String e;
  
  private final i f;
  
  private final a<v> g;
  
  private final String h;
  
  private final a<v> i;
  
  private final a<v> j;
  
  private CombinedClickableElement(m paramm, boolean paramBoolean, String paramString1, i parami, a<v> parama1, String paramString2, a<v> parama2, a<v> parama3) {
    this.c = paramm;
    this.d = paramBoolean;
    this.e = paramString1;
    this.f = parami;
    this.g = parama1;
    this.h = paramString2;
    this.i = parama2;
    this.j = parama3;
  }
  
  public boolean equals(Object paramObject) {
    Object object;
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      object = paramObject.getClass();
    } else {
      object = null;
    } 
    if (!q.e(CombinedClickableElement.class, object))
      return false; 
    q.h(paramObject, "null cannot be cast to non-null type androidx.compose.foundation.CombinedClickableElement");
    paramObject = paramObject;
    return !q.e(this.c, ((CombinedClickableElement)paramObject).c) ? false : ((this.d != ((CombinedClickableElement)paramObject).d) ? false : (!q.e(this.e, ((CombinedClickableElement)paramObject).e) ? false : (!q.e(this.f, ((CombinedClickableElement)paramObject).f) ? false : (!q.e(this.g, ((CombinedClickableElement)paramObject).g) ? false : (!q.e(this.h, ((CombinedClickableElement)paramObject).h) ? false : (!q.e(this.i, ((CombinedClickableElement)paramObject).i) ? false : (!!q.e(this.j, ((CombinedClickableElement)paramObject).j))))))));
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    int k = this.c.hashCode();
    int n = k.a(this.d);
    String str2 = this.e;
    int j = 0;
    if (str2 != null) {
      b1 = str2.hashCode();
    } else {
      b1 = 0;
    } 
    i i2 = this.f;
    if (i2 != null) {
      b2 = i.l(i2.n());
    } else {
      b2 = 0;
    } 
    int i1 = this.g.hashCode();
    String str1 = this.h;
    if (str1 != null) {
      b3 = str1.hashCode();
    } else {
      b3 = 0;
    } 
    a<v> a1 = this.i;
    if (a1 != null) {
      b4 = a1.hashCode();
    } else {
      b4 = 0;
    } 
    a1 = this.j;
    if (a1 != null)
      j = a1.hashCode(); 
    return ((((((k * 31 + n) * 31 + b1) * 31 + b2) * 31 + i1) * 31 + b3) * 31 + b4) * 31 + j;
  }
  
  public i s() {
    return new i(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, null);
  }
  
  public void t(i parami) {
    q.j(parami, "node");
    parami.M1(this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\CombinedClickableElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */