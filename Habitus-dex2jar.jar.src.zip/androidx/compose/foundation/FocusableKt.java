package androidx.compose.foundation;

import androidx.compose.ui.e;
import androidx.compose.ui.focus.e;
import androidx.compose.ui.focus.g;
import androidx.compose.ui.focus.i;
import androidx.compose.ui.platform.i1;
import androidx.compose.ui.platform.j1;
import androidx.compose.ui.platform.l1;
import dk.l;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import q1.u0;
import rj.v;
import t.m;

public final class FocusableKt {
  private static final i1 a;
  
  private static final FocusableKt$FocusableInNonTouchModeElement$1 b = new FocusableKt$FocusableInNonTouchModeElement$1();
  
  public static final e a(e parame) {
    q.j(parame, "<this>");
    return e.a(i.a(parame.then((e)a), a.s0));
  }
  
  public static final e b(e parame, boolean paramBoolean, m paramm) {
    e.a a;
    q.j(parame, "<this>");
    if (paramBoolean) {
      e e1 = e.a((e)new FocusableElement(paramm));
    } else {
      a = e.a;
    } 
    return parame.then((e)a);
  }
  
  public static final e c(e parame, boolean paramBoolean, m paramm) {
    q.j(parame, "<this>");
    return j1.b(parame, new b(paramBoolean, paramm), b(e.a.then((e)b), paramBoolean, paramm));
  }
  
  static {
    l l;
    if (j1.c()) {
      l = new c();
    } else {
      l = j1.a();
    } 
    a = new i1(l);
  }
  
  public static final class FocusableKt$FocusableInNonTouchModeElement$1 extends u0<k> {
    public boolean equals(Object param1Object) {
      return (this == param1Object);
    }
    
    public int hashCode() {
      return System.identityHashCode(this);
    }
    
    public k s() {
      return new k();
    }
    
    public void t(k param1k) {
      q.j(param1k, "node");
    }
  }
  
  static final class a extends r implements l<g, v> {
    public static final a s0 = new a();
    
    a() {
      super(1);
    }
    
    public final void a(g param1g) {
      q.j(param1g, "$this$focusProperties");
      param1g.o(false);
    }
  }
  
  static final class b extends r implements l<l1, v> {
    b(boolean param1Boolean, m param1m) {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$inspectable");
      param1l1.b("focusableInNonTouchMode");
      param1l1.a().b("enabled", Boolean.valueOf(this.s0));
      param1l1.a().b("interactionSource", this.t0);
    }
  }
  
  public static final class c extends r implements l<l1, v> {
    public c() {
      super(1);
    }
    
    public final void invoke(l1 param1l1) {
      q.j(param1l1, "$this$null");
      param1l1.b("focusGroup");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\compose\foundation\FocusableKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */