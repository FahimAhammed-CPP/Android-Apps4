package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;

interface c {
  void a(b paramb, float paramFloat);
  
  float b(b paramb);
  
  void c(b paramb, float paramFloat);
  
  float d(b paramb);
  
  ColorStateList e(b paramb);
  
  float f(b paramb);
  
  void g(b paramb);
  
  void h(b paramb, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3);
  
  float i(b paramb);
  
  void j(b paramb);
  
  void k(b paramb);
  
  void l();
  
  float m(b paramb);
  
  void n(b paramb, ColorStateList paramColorStateList);
  
  void o(b paramb, float paramFloat);
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\cardview\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */