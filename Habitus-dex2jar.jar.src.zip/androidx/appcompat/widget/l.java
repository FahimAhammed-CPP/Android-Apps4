package androidx.appcompat.widget;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Shader;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import androidx.core.graphics.drawable.c;

class l {
  private static final int[] c = new int[] { 16843067, 16843068 };
  
  private final ProgressBar a;
  
  private Bitmap b;
  
  l(ProgressBar paramProgressBar) {
    this.a = paramProgressBar;
  }
  
  private Shape a() {
    return (Shape)new RoundRectShape(new float[] { 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }, null, null);
  }
  
  private Drawable e(Drawable paramDrawable) {
    AnimationDrawable animationDrawable;
    Drawable drawable = paramDrawable;
    if (paramDrawable instanceof AnimationDrawable) {
      AnimationDrawable animationDrawable1 = (AnimationDrawable)paramDrawable;
      int j = animationDrawable1.getNumberOfFrames();
      animationDrawable = new AnimationDrawable();
      animationDrawable.setOneShot(animationDrawable1.isOneShot());
      for (int i = 0; i < j; i++) {
        Drawable drawable1 = d(animationDrawable1.getFrame(i), true);
        drawable1.setLevel(10000);
        animationDrawable.addFrame(drawable1, animationDrawable1.getDuration(i));
      } 
      animationDrawable.setLevel(10000);
    } 
    return (Drawable)animationDrawable;
  }
  
  Bitmap b() {
    return this.b;
  }
  
  void c(AttributeSet paramAttributeSet, int paramInt) {
    p0 p0 = p0.v(this.a.getContext(), paramAttributeSet, c, paramInt, 0);
    Drawable drawable = p0.h(0);
    if (drawable != null)
      this.a.setIndeterminateDrawable(e(drawable)); 
    drawable = p0.h(1);
    if (drawable != null)
      this.a.setProgressDrawable(d(drawable, false)); 
    p0.w();
  }
  
  Drawable d(Drawable paramDrawable, boolean paramBoolean) {
    ClipDrawable clipDrawable;
    if (paramDrawable instanceof c) {
      c c = (c)paramDrawable;
      Drawable drawable = c.a();
      if (drawable != null) {
        c.b(d(drawable, paramBoolean));
        return paramDrawable;
      } 
    } else {
      LayerDrawable layerDrawable;
      if (paramDrawable instanceof LayerDrawable) {
        layerDrawable = (LayerDrawable)paramDrawable;
        int j = layerDrawable.getNumberOfLayers();
        Drawable[] arrayOfDrawable = new Drawable[j];
        boolean bool = false;
        int i;
        for (i = 0; i < j; i++) {
          int k = layerDrawable.getId(i);
          Drawable drawable = layerDrawable.getDrawable(i);
          if (k == 16908301 || k == 16908303) {
            paramBoolean = true;
          } else {
            paramBoolean = false;
          } 
          arrayOfDrawable[i] = d(drawable, paramBoolean);
        } 
        LayerDrawable layerDrawable1 = new LayerDrawable(arrayOfDrawable);
        for (i = bool; i < j; i++) {
          layerDrawable1.setId(i, layerDrawable.getId(i));
          if (Build.VERSION.SDK_INT >= 23)
            a.a(layerDrawable, layerDrawable1, i); 
        } 
        return (Drawable)layerDrawable1;
      } 
      if (layerDrawable instanceof BitmapDrawable) {
        BitmapDrawable bitmapDrawable = (BitmapDrawable)layerDrawable;
        Bitmap bitmap = bitmapDrawable.getBitmap();
        if (this.b == null)
          this.b = bitmap; 
        ShapeDrawable shapeDrawable2 = new ShapeDrawable(a());
        BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP);
        shapeDrawable2.getPaint().setShader((Shader)bitmapShader);
        shapeDrawable2.getPaint().setColorFilter(bitmapDrawable.getPaint().getColorFilter());
        ShapeDrawable shapeDrawable1 = shapeDrawable2;
        if (paramBoolean)
          clipDrawable = new ClipDrawable((Drawable)shapeDrawable2, 3, 1); 
        return (Drawable)clipDrawable;
      } 
    } 
    return (Drawable)clipDrawable;
  }
  
  private static class a {
    public static void a(LayerDrawable param1LayerDrawable1, LayerDrawable param1LayerDrawable2, int param1Int) {
      param1LayerDrawable2.setLayerGravity(param1Int, param1LayerDrawable1.getLayerGravity(param1Int));
      param1LayerDrawable2.setLayerWidth(param1Int, param1LayerDrawable1.getLayerWidth(param1Int));
      param1LayerDrawable2.setLayerHeight(param1Int, param1LayerDrawable1.getLayerHeight(param1Int));
      param1LayerDrawable2.setLayerInsetLeft(param1Int, param1LayerDrawable1.getLayerInsetLeft(param1Int));
      param1LayerDrawable2.setLayerInsetRight(param1Int, param1LayerDrawable1.getLayerInsetRight(param1Int));
      param1LayerDrawable2.setLayerInsetTop(param1Int, param1LayerDrawable1.getLayerInsetTop(param1Int));
      param1LayerDrawable2.setLayerInsetBottom(param1Int, param1LayerDrawable1.getLayerInsetBottom(param1Int));
      param1LayerDrawable2.setLayerInsetStart(param1Int, param1LayerDrawable1.getLayerInsetStart(param1Int));
      param1LayerDrawable2.setLayerInsetEnd(param1Int, param1LayerDrawable1.getLayerInsetEnd(param1Int));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */