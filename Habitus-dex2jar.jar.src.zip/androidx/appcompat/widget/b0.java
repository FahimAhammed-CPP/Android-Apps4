package androidx.appcompat.widget;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import androidx.appcompat.view.menu.p;

public abstract class b0 implements View.OnTouchListener, View.OnAttachStateChangeListener {
  private final int[] A0 = new int[2];
  
  private final float s0;
  
  private final int t0;
  
  private final int u0;
  
  final View v0;
  
  private Runnable w0;
  
  private Runnable x0;
  
  private boolean y0;
  
  private int z0;
  
  public b0(View paramView) {
    this.v0 = paramView;
    paramView.setLongClickable(true);
    paramView.addOnAttachStateChangeListener(this);
    this.s0 = ViewConfiguration.get(paramView.getContext()).getScaledTouchSlop();
    int i = ViewConfiguration.getTapTimeout();
    this.t0 = i;
    this.u0 = (i + ViewConfiguration.getLongPressTimeout()) / 2;
  }
  
  private void a() {
    Runnable runnable = this.x0;
    if (runnable != null)
      this.v0.removeCallbacks(runnable); 
    runnable = this.w0;
    if (runnable != null)
      this.v0.removeCallbacks(runnable); 
  }
  
  private boolean f(MotionEvent paramMotionEvent) {
    View view = this.v0;
    p p = b();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (p != null) {
      if (!p.a())
        return false; 
      z z = (z)p.o();
      bool1 = bool2;
      if (z != null) {
        if (!z.isShown())
          return false; 
        MotionEvent motionEvent = MotionEvent.obtainNoHistory(paramMotionEvent);
        i(view, motionEvent);
        j((View)z, motionEvent);
        boolean bool = z.e(motionEvent, this.z0);
        motionEvent.recycle();
        int i = paramMotionEvent.getActionMasked();
        if (i != 1 && i != 3) {
          i = 1;
        } else {
          i = 0;
        } 
        bool1 = bool2;
        if (bool) {
          bool1 = bool2;
          if (i != 0)
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  private boolean g(MotionEvent paramMotionEvent) {
    View view = this.v0;
    if (!view.isEnabled())
      return false; 
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3)
            return false; 
        } else {
          i = paramMotionEvent.findPointerIndex(this.z0);
          if (i >= 0 && !h(view, paramMotionEvent.getX(i), paramMotionEvent.getY(i), this.s0)) {
            a();
            view.getParent().requestDisallowInterceptTouchEvent(true);
            return true;
          } 
          return false;
        }  
      a();
      return false;
    } 
    this.z0 = paramMotionEvent.getPointerId(0);
    if (this.w0 == null)
      this.w0 = new a(this); 
    view.postDelayed(this.w0, this.t0);
    if (this.x0 == null)
      this.x0 = new b(this); 
    view.postDelayed(this.x0, this.u0);
    return false;
  }
  
  private static boolean h(View paramView, float paramFloat1, float paramFloat2, float paramFloat3) {
    float f = -paramFloat3;
    return (paramFloat1 >= f && paramFloat2 >= f && paramFloat1 < (paramView.getRight() - paramView.getLeft()) + paramFloat3 && paramFloat2 < (paramView.getBottom() - paramView.getTop()) + paramFloat3);
  }
  
  private boolean i(View paramView, MotionEvent paramMotionEvent) {
    int[] arrayOfInt = this.A0;
    paramView.getLocationOnScreen(arrayOfInt);
    paramMotionEvent.offsetLocation(arrayOfInt[0], arrayOfInt[1]);
    return true;
  }
  
  private boolean j(View paramView, MotionEvent paramMotionEvent) {
    int[] arrayOfInt = this.A0;
    paramView.getLocationOnScreen(arrayOfInt);
    paramMotionEvent.offsetLocation(-arrayOfInt[0], -arrayOfInt[1]);
    return true;
  }
  
  public abstract p b();
  
  protected abstract boolean c();
  
  protected boolean d() {
    p p = b();
    if (p != null && p.a())
      p.dismiss(); 
    return true;
  }
  
  void e() {
    a();
    View view = this.v0;
    if (view.isEnabled()) {
      if (view.isLongClickable())
        return; 
      if (!c())
        return; 
      view.getParent().requestDisallowInterceptTouchEvent(true);
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      view.onTouchEvent(motionEvent);
      motionEvent.recycle();
      this.y0 = true;
    } 
  }
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    boolean bool1;
    boolean bool = this.y0;
    boolean bool3 = true;
    if (bool) {
      if (f(paramMotionEvent) || !d()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
    } else {
      boolean bool4;
      if (g(paramMotionEvent) && c()) {
        bool4 = true;
      } else {
        bool4 = false;
      } 
      bool1 = bool4;
      if (bool4) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        this.v0.onTouchEvent(motionEvent);
        motionEvent.recycle();
        bool1 = bool4;
      } 
    } 
    this.y0 = bool1;
    boolean bool2 = bool3;
    if (!bool1) {
      if (bool)
        return true; 
      bool2 = false;
    } 
    return bool2;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    this.y0 = false;
    this.z0 = -1;
    Runnable runnable = this.w0;
    if (runnable != null)
      this.v0.removeCallbacks(runnable); 
  }
  
  private class a implements Runnable {
    a(b0 this$0) {}
    
    public void run() {
      ViewParent viewParent = this.s0.v0.getParent();
      if (viewParent != null)
        viewParent.requestDisallowInterceptTouchEvent(true); 
    }
  }
  
  private class b implements Runnable {
    b(b0 this$0) {}
    
    public void run() {
      this.s0.e();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */