package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;
import androidx.core.widget.j;
import androidx.core.widget.n;
import g.a;

public class AppCompatButton extends Button implements n {
  private final d s0;
  
  private final r t0;
  
  private i u0;
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.buttonStyle);
  }
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(m0.b(paramContext), paramAttributeSet, paramInt);
    k0.a((View)this, getContext());
    d d1 = new d((View)this);
    this.s0 = d1;
    d1.e(paramAttributeSet, paramInt);
    r r1 = new r((TextView)this);
    this.t0 = r1;
    r1.m(paramAttributeSet, paramInt);
    r1.b();
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private i getEmojiTextViewHelper() {
    if (this.u0 == null)
      this.u0 = new i((TextView)this); 
    return this.u0;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.s0;
    if (d1 != null)
      d1.b(); 
    r r1 = this.t0;
    if (r1 != null)
      r1.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (a1.b)
      return super.getAutoSizeMaxTextSize(); 
    r r1 = this.t0;
    return (r1 != null) ? r1.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (a1.b)
      return super.getAutoSizeMinTextSize(); 
    r r1 = this.t0;
    return (r1 != null) ? r1.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (a1.b)
      return super.getAutoSizeStepGranularity(); 
    r r1 = this.t0;
    return (r1 != null) ? r1.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (a1.b)
      return super.getAutoSizeTextAvailableSizes(); 
    r r1 = this.t0;
    return (r1 != null) ? r1.h() : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = a1.b;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    r r1 = this.t0;
    return (r1 != null) ? r1.i() : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.q(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.s0;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.s0;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.t0.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.t0.k();
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(Button.class.getName());
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(Button.class.getName());
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    r r1 = this.t0;
    if (r1 != null)
      r1.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    r r1 = this.t0;
    if (r1 != null && !a1.b && r1.l()) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt1 != 0)
      this.t0.c(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    if (a1.b) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    r r1 = this.t0;
    if (r1 != null)
      r1.t(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    if (a1.b) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    r r1 = this.t0;
    if (r1 != null)
      r1.u(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (a1.b) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    r r1 = this.t0;
    if (r1 != null)
      r1.v(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.s0;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.s0;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.r((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setSupportAllCaps(boolean paramBoolean) {
    r r1 = this.t0;
    if (r1 != null)
      r1.s(paramBoolean); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.s0;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.s0;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.t0.w(paramColorStateList);
    this.t0.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.t0.x(paramMode);
    this.t0.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    r r1 = this.t0;
    if (r1 != null)
      r1.q(paramContext, paramInt); 
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (a1.b) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    r r1 = this.t0;
    if (r1 != null)
      r1.A(paramInt, paramFloat); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\AppCompatButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */