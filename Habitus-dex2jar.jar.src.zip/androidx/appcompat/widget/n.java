package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import androidx.core.graphics.drawable.a;
import androidx.core.view.m0;
import g.j;

class n extends l {
  private final SeekBar d;
  
  private Drawable e;
  
  private ColorStateList f = null;
  
  private PorterDuff.Mode g = null;
  
  private boolean h = false;
  
  private boolean i = false;
  
  n(SeekBar paramSeekBar) {
    super((ProgressBar)paramSeekBar);
    this.d = paramSeekBar;
  }
  
  private void f() {
    Drawable drawable = this.e;
    if (drawable != null && (this.h || this.i)) {
      drawable = a.r(drawable.mutate());
      this.e = drawable;
      if (this.h)
        a.o(drawable, this.f); 
      if (this.i)
        a.p(this.e, this.g); 
      if (this.e.isStateful())
        this.e.setState(this.d.getDrawableState()); 
    } 
  }
  
  void c(AttributeSet paramAttributeSet, int paramInt) {
    super.c(paramAttributeSet, paramInt);
    p0 p0 = p0.v(this.d.getContext(), paramAttributeSet, j.AppCompatSeekBar, paramInt, 0);
    SeekBar seekBar = this.d;
    m0.q0((View)seekBar, seekBar.getContext(), j.AppCompatSeekBar, paramAttributeSet, p0.r(), paramInt, 0);
    Drawable drawable = p0.h(j.AppCompatSeekBar_android_thumb);
    if (drawable != null)
      this.d.setThumb(drawable); 
    j(p0.g(j.AppCompatSeekBar_tickMark));
    if (p0.s(j.AppCompatSeekBar_tickMarkTintMode)) {
      this.g = y.d(p0.k(j.AppCompatSeekBar_tickMarkTintMode, -1), this.g);
      this.i = true;
    } 
    if (p0.s(j.AppCompatSeekBar_tickMarkTint)) {
      this.f = p0.c(j.AppCompatSeekBar_tickMarkTint);
      this.h = true;
    } 
    p0.w();
    f();
  }
  
  void g(Canvas paramCanvas) {
    if (this.e != null) {
      int j = this.d.getMax();
      int i = 1;
      if (j > 1) {
        int k = this.e.getIntrinsicWidth();
        int m = this.e.getIntrinsicHeight();
        if (k >= 0) {
          k /= 2;
        } else {
          k = 1;
        } 
        if (m >= 0)
          i = m / 2; 
        this.e.setBounds(-k, -i, k, i);
        float f = (this.d.getWidth() - this.d.getPaddingLeft() - this.d.getPaddingRight()) / j;
        i = paramCanvas.save();
        paramCanvas.translate(this.d.getPaddingLeft(), (this.d.getHeight() / 2));
        for (k = 0; k <= j; k++) {
          this.e.draw(paramCanvas);
          paramCanvas.translate(f, 0.0F);
        } 
        paramCanvas.restoreToCount(i);
      } 
    } 
  }
  
  void h() {
    Drawable drawable = this.e;
    if (drawable != null && drawable.isStateful() && drawable.setState(this.d.getDrawableState()))
      this.d.invalidateDrawable(drawable); 
  }
  
  void i() {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
  }
  
  void j(Drawable paramDrawable) {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.setCallback(null); 
    this.e = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback((Drawable.Callback)this.d);
      a.m(paramDrawable, m0.E((View)this.d));
      if (paramDrawable.isStateful())
        paramDrawable.setState(this.d.getDrawableState()); 
      f();
    } 
    this.d.invalidate();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */