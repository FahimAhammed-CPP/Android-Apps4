package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.core.view.m0;
import androidx.core.widget.e;
import g.j;
import h.a;

public class k {
  private final ImageView a;
  
  private n0 b;
  
  private n0 c;
  
  private n0 d;
  
  private int e = 0;
  
  public k(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.d == null)
      this.d = new n0(); 
    n0 n01 = this.d;
    n01.a();
    ColorStateList colorStateList = e.a(this.a);
    if (colorStateList != null) {
      n01.d = true;
      n01.a = colorStateList;
    } 
    PorterDuff.Mode mode = e.b(this.a);
    if (mode != null) {
      n01.c = true;
      n01.b = mode;
    } 
    if (n01.d || n01.c) {
      g.i(paramDrawable, n01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean l() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.b != null)) : ((i == 21));
  }
  
  void b() {
    if (this.a.getDrawable() != null)
      this.a.getDrawable().setLevel(this.e); 
  }
  
  void c() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      y.b(drawable); 
    if (drawable != null) {
      if (l() && a(drawable))
        return; 
      n0 n01 = this.c;
      if (n01 != null) {
        g.i(drawable, n01, this.a.getDrawableState());
        return;
      } 
      n01 = this.b;
      if (n01 != null)
        g.i(drawable, n01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList d() {
    n0 n01 = this.c;
    return (n01 != null) ? n01.a : null;
  }
  
  PorterDuff.Mode e() {
    n0 n01 = this.c;
    return (n01 != null) ? n01.b : null;
  }
  
  boolean f() {
    return !(this.a.getBackground() instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void g(AttributeSet paramAttributeSet, int paramInt) {
    p0 p0 = p0.v(this.a.getContext(), paramAttributeSet, j.AppCompatImageView, paramInt, 0);
    ImageView imageView = this.a;
    m0.q0((View)imageView, imageView.getContext(), j.AppCompatImageView, paramAttributeSet, p0.r(), paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = p0.n(j.AppCompatImageView_srcCompat, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.b(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        y.b(drawable1); 
      if (p0.s(j.AppCompatImageView_tint))
        e.c(this.a, p0.c(j.AppCompatImageView_tint)); 
      if (p0.s(j.AppCompatImageView_tintMode))
        e.d(this.a, y.d(p0.k(j.AppCompatImageView_tintMode, -1), null)); 
      return;
    } finally {
      p0.w();
    } 
  }
  
  void h(Drawable paramDrawable) {
    this.e = paramDrawable.getLevel();
  }
  
  public void i(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.b(this.a.getContext(), paramInt);
      if (drawable != null)
        y.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    c();
  }
  
  void j(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new n0(); 
    n0 n01 = this.c;
    n01.a = paramColorStateList;
    n01.d = true;
    c();
  }
  
  void k(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new n0(); 
    n0 n01 = this.c;
    n01.b = paramMode;
    n01.c = true;
    c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */