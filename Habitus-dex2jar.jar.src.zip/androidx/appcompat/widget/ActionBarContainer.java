package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.core.view.m0;
import g.f;
import g.j;

public class ActionBarContainer extends FrameLayout {
  boolean A0;
  
  private int B0;
  
  private boolean s0;
  
  private View t0;
  
  private View u0;
  
  private View v0;
  
  Drawable w0;
  
  Drawable x0;
  
  Drawable y0;
  
  boolean z0;
  
  public ActionBarContainer(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    m0.w0((View)this, new b(this));
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.ActionBar);
    this.w0 = typedArray.getDrawable(j.ActionBar_background);
    this.x0 = typedArray.getDrawable(j.ActionBar_backgroundStacked);
    this.B0 = typedArray.getDimensionPixelSize(j.ActionBar_height, -1);
    int i = getId();
    int j = f.split_action_bar;
    boolean bool = true;
    if (i == j) {
      this.z0 = true;
      this.y0 = typedArray.getDrawable(j.ActionBar_backgroundSplit);
    } 
    typedArray.recycle();
    if (this.z0 ? (this.y0 == null) : (this.w0 == null && this.x0 == null))
      bool = false; 
    setWillNotDraw(bool);
  }
  
  private int a(View paramView) {
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)paramView.getLayoutParams();
    return paramView.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
  }
  
  private boolean b(View paramView) {
    return (paramView == null || paramView.getVisibility() == 8 || paramView.getMeasuredHeight() == 0);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    Drawable drawable = this.w0;
    if (drawable != null && drawable.isStateful())
      this.w0.setState(getDrawableState()); 
    drawable = this.x0;
    if (drawable != null && drawable.isStateful())
      this.x0.setState(getDrawableState()); 
    drawable = this.y0;
    if (drawable != null && drawable.isStateful())
      this.y0.setState(getDrawableState()); 
  }
  
  public View getTabContainer() {
    return this.t0;
  }
  
  public void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    Drawable drawable = this.w0;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    drawable = this.x0;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    drawable = this.y0;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
  }
  
  public void onFinishInflate() {
    super.onFinishInflate();
    this.u0 = findViewById(f.action_bar);
    this.v0 = findViewById(f.action_context_bar);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    super.onHoverEvent(paramMotionEvent);
    return true;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return (this.s0 || super.onInterceptTouchEvent(paramMotionEvent));
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable;
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    View view = this.t0;
    paramInt2 = 1;
    paramInt4 = 0;
    if (view != null && view.getVisibility() != 8) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    if (view != null && view.getVisibility() != 8) {
      int i = getMeasuredHeight();
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int j = view.getMeasuredHeight();
      int k = layoutParams.bottomMargin;
      view.layout(paramInt1, i - j - k, paramInt3, i - k);
    } 
    if (this.z0) {
      drawable = this.y0;
      if (drawable != null) {
        drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
        paramInt1 = paramInt2;
      } else {
        paramInt1 = 0;
      } 
    } else {
      paramInt1 = paramInt4;
      if (this.w0 != null) {
        if (this.u0.getVisibility() == 0) {
          this.w0.setBounds(this.u0.getLeft(), this.u0.getTop(), this.u0.getRight(), this.u0.getBottom());
        } else {
          View view1 = this.v0;
          if (view1 != null && view1.getVisibility() == 0) {
            this.w0.setBounds(this.v0.getLeft(), this.v0.getTop(), this.v0.getRight(), this.v0.getBottom());
          } else {
            this.w0.setBounds(0, 0, 0, 0);
          } 
        } 
        paramInt1 = 1;
      } 
      this.A0 = paramBoolean;
      if (paramBoolean) {
        Drawable drawable1 = this.x0;
        if (drawable1 != null) {
          drawable1.setBounds(drawable.getLeft(), drawable.getTop(), drawable.getRight(), drawable.getBottom());
          paramInt1 = paramInt2;
        } 
      } 
    } 
    if (paramInt1 != 0)
      invalidate(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int i = paramInt2;
    if (this.u0 == null) {
      i = paramInt2;
      if (View.MeasureSpec.getMode(paramInt2) == Integer.MIN_VALUE) {
        int j = this.B0;
        i = paramInt2;
        if (j >= 0)
          i = View.MeasureSpec.makeMeasureSpec(Math.min(j, View.MeasureSpec.getSize(paramInt2)), -2147483648); 
      } 
    } 
    super.onMeasure(paramInt1, i);
    if (this.u0 == null)
      return; 
    paramInt2 = View.MeasureSpec.getMode(i);
    View view = this.t0;
    if (view != null && view.getVisibility() != 8 && paramInt2 != 1073741824) {
      if (!b(this.u0)) {
        paramInt1 = a(this.u0);
      } else if (!b(this.v0)) {
        paramInt1 = a(this.v0);
      } else {
        paramInt1 = 0;
      } 
      if (paramInt2 == Integer.MIN_VALUE) {
        paramInt2 = View.MeasureSpec.getSize(i);
      } else {
        paramInt2 = Integer.MAX_VALUE;
      } 
      setMeasuredDimension(getMeasuredWidth(), Math.min(paramInt1 + a(this.t0), paramInt2));
    } 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    super.onTouchEvent(paramMotionEvent);
    return true;
  }
  
  public void setPrimaryBackground(Drawable paramDrawable) {
    Drawable drawable = this.w0;
    if (drawable != null) {
      drawable.setCallback(null);
      unscheduleDrawable(this.w0);
    } 
    this.w0 = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback((Drawable.Callback)this);
      View view = this.u0;
      if (view != null)
        this.w0.setBounds(view.getLeft(), this.u0.getTop(), this.u0.getRight(), this.u0.getBottom()); 
    } 
    boolean bool1 = this.z0;
    boolean bool = true;
    if (bool1 ? (this.y0 == null) : (this.w0 == null && this.x0 == null))
      bool = false; 
    setWillNotDraw(bool);
    invalidate();
    a.a(this);
  }
  
  public void setSplitBackground(Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield y0 : Landroid/graphics/drawable/Drawable;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 25
    //   11: aload #4
    //   13: aconst_null
    //   14: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   17: aload_0
    //   18: aload_0
    //   19: getfield y0 : Landroid/graphics/drawable/Drawable;
    //   22: invokevirtual unscheduleDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   25: aload_0
    //   26: aload_1
    //   27: putfield y0 : Landroid/graphics/drawable/Drawable;
    //   30: iconst_0
    //   31: istore_3
    //   32: aload_1
    //   33: ifnull -> 71
    //   36: aload_1
    //   37: aload_0
    //   38: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   41: aload_0
    //   42: getfield z0 : Z
    //   45: ifeq -> 71
    //   48: aload_0
    //   49: getfield y0 : Landroid/graphics/drawable/Drawable;
    //   52: astore_1
    //   53: aload_1
    //   54: ifnull -> 71
    //   57: aload_1
    //   58: iconst_0
    //   59: iconst_0
    //   60: aload_0
    //   61: invokevirtual getMeasuredWidth : ()I
    //   64: aload_0
    //   65: invokevirtual getMeasuredHeight : ()I
    //   68: invokevirtual setBounds : (IIII)V
    //   71: aload_0
    //   72: getfield z0 : Z
    //   75: ifeq -> 92
    //   78: iload_3
    //   79: istore_2
    //   80: aload_0
    //   81: getfield y0 : Landroid/graphics/drawable/Drawable;
    //   84: ifnonnull -> 113
    //   87: iconst_1
    //   88: istore_2
    //   89: goto -> 113
    //   92: iload_3
    //   93: istore_2
    //   94: aload_0
    //   95: getfield w0 : Landroid/graphics/drawable/Drawable;
    //   98: ifnonnull -> 113
    //   101: iload_3
    //   102: istore_2
    //   103: aload_0
    //   104: getfield x0 : Landroid/graphics/drawable/Drawable;
    //   107: ifnonnull -> 113
    //   110: goto -> 87
    //   113: aload_0
    //   114: iload_2
    //   115: invokevirtual setWillNotDraw : (Z)V
    //   118: aload_0
    //   119: invokevirtual invalidate : ()V
    //   122: aload_0
    //   123: invokestatic a : (Landroidx/appcompat/widget/ActionBarContainer;)V
    //   126: return
  }
  
  public void setStackedBackground(Drawable paramDrawable) {
    Drawable drawable = this.x0;
    if (drawable != null) {
      drawable.setCallback(null);
      unscheduleDrawable(this.x0);
    } 
    this.x0 = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback((Drawable.Callback)this);
      if (this.A0) {
        paramDrawable = this.x0;
        if (paramDrawable != null)
          paramDrawable.setBounds(this.t0.getLeft(), this.t0.getTop(), this.t0.getRight(), this.t0.getBottom()); 
      } 
    } 
    boolean bool1 = this.z0;
    boolean bool = true;
    if (bool1 ? (this.y0 == null) : (this.w0 == null && this.x0 == null))
      bool = false; 
    setWillNotDraw(bool);
    invalidate();
    a.a(this);
  }
  
  public void setTabContainer(i0 parami0) {
    View view = this.t0;
    if (view != null)
      removeView(view); 
    this.t0 = (View)parami0;
    if (parami0 != null) {
      addView((View)parami0);
      ViewGroup.LayoutParams layoutParams = parami0.getLayoutParams();
      layoutParams.width = -1;
      layoutParams.height = -2;
      parami0.setAllowCollapse(false);
    } 
  }
  
  public void setTransitioning(boolean paramBoolean) {
    int i;
    this.s0 = paramBoolean;
    if (paramBoolean) {
      i = 393216;
    } else {
      i = 262144;
    } 
    setDescendantFocusability(i);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Drawable drawable = this.w0;
    if (drawable != null)
      drawable.setVisible(bool, false); 
    drawable = this.x0;
    if (drawable != null)
      drawable.setVisible(bool, false); 
    drawable = this.y0;
    if (drawable != null)
      drawable.setVisible(bool, false); 
  }
  
  public ActionMode startActionModeForChild(View paramView, ActionMode.Callback paramCallback) {
    return null;
  }
  
  public ActionMode startActionModeForChild(View paramView, ActionMode.Callback paramCallback, int paramInt) {
    return (paramInt != 0) ? super.startActionModeForChild(paramView, paramCallback, paramInt) : null;
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return ((paramDrawable == this.w0 && !this.z0) || (paramDrawable == this.x0 && this.A0) || (paramDrawable == this.y0 && this.z0) || super.verifyDrawable(paramDrawable));
  }
  
  private static class a {
    public static void a(ActionBarContainer param1ActionBarContainer) {
      param1ActionBarContainer.invalidateOutline();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\ActionBarContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */