package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.TextView;
import g.j;
import i3.f;

class i {
  private final TextView a;
  
  private final f b;
  
  i(TextView paramTextView) {
    this.a = paramTextView;
    this.b = new f(paramTextView, false);
  }
  
  InputFilter[] a(InputFilter[] paramArrayOfInputFilter) {
    return this.b.a(paramArrayOfInputFilter);
  }
  
  public boolean b() {
    return this.b.b();
  }
  
  void c(AttributeSet paramAttributeSet, int paramInt) {
    TypedArray typedArray = this.a.getContext().obtainStyledAttributes(paramAttributeSet, j.AppCompatTextView, paramInt, 0);
    try {
      boolean bool2 = typedArray.hasValue(j.AppCompatTextView_emojiCompatEnabled);
      boolean bool1 = true;
      if (bool2)
        bool1 = typedArray.getBoolean(j.AppCompatTextView_emojiCompatEnabled, true); 
      typedArray.recycle();
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  void d(boolean paramBoolean) {
    this.b.c(paramBoolean);
  }
  
  void e(boolean paramBoolean) {
    this.b.d(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */