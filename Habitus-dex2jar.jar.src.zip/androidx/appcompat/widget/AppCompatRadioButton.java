package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.core.widget.m;
import androidx.core.widget.n;
import g.a;
import h.a;

public class AppCompatRadioButton extends RadioButton implements m, n {
  private final f s0;
  
  private final d t0;
  
  private final r u0;
  
  private i v0;
  
  public AppCompatRadioButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.radioButtonStyle);
  }
  
  public AppCompatRadioButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(m0.b(paramContext), paramAttributeSet, paramInt);
    k0.a((View)this, getContext());
    f f1 = new f((CompoundButton)this);
    this.s0 = f1;
    f1.e(paramAttributeSet, paramInt);
    d d1 = new d((View)this);
    this.t0 = d1;
    d1.e(paramAttributeSet, paramInt);
    r r1 = new r((TextView)this);
    this.u0 = r1;
    r1.m(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private i getEmojiTextViewHelper() {
    if (this.v0 == null)
      this.v0 = new i((TextView)this); 
    return this.v0;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.t0;
    if (d1 != null)
      d1.b(); 
    r r1 = this.u0;
    if (r1 != null)
      r1.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    int k = super.getCompoundPaddingLeft();
    f f1 = this.s0;
    int j = k;
    if (f1 != null)
      j = f1.b(k); 
    return j;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.t0;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.t0;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    f f1 = this.s0;
    return (f1 != null) ? f1.c() : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    f f1 = this.s0;
    return (f1 != null) ? f1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.u0.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.u0.k();
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.t0;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.t0;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(a.b(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    f f1 = this.s0;
    if (f1 != null)
      f1.f(); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.u0;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.u0;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.t0;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.t0;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    f f1 = this.s0;
    if (f1 != null)
      f1.g(paramColorStateList); 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.s0;
    if (f1 != null)
      f1.h(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.u0.w(paramColorStateList);
    this.u0.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.u0.x(paramMode);
    this.u0.b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\AppCompatRadioButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */