package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.view.u0;

public interface x {
  boolean a();
  
  boolean b();
  
  boolean c();
  
  void collapseActionView();
  
  void d(Menu paramMenu, m.a parama);
  
  boolean e();
  
  void f();
  
  boolean g();
  
  Context getContext();
  
  CharSequence getTitle();
  
  boolean h();
  
  void i(int paramInt);
  
  Menu j();
  
  int k();
  
  u0 l(int paramInt, long paramLong);
  
  ViewGroup m();
  
  void n(boolean paramBoolean);
  
  void o();
  
  void p(boolean paramBoolean);
  
  void q();
  
  void r(i0 parami0);
  
  void s(int paramInt);
  
  void setIcon(int paramInt);
  
  void setIcon(Drawable paramDrawable);
  
  void setTitle(CharSequence paramCharSequence);
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
  
  void t(int paramInt);
  
  void u(m.a parama, g.a parama1);
  
  void v(int paramInt);
  
  int w();
  
  void x();
  
  void y(Drawable paramDrawable);
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */