package androidx.appcompat.widget;

import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.core.util.i;

final class q {
  private TextView a;
  
  private TextClassifier b;
  
  q(TextView paramTextView) {
    this.a = (TextView)i.g(paramTextView);
  }
  
  public TextClassifier a() {
    TextClassifier textClassifier2 = this.b;
    TextClassifier textClassifier1 = textClassifier2;
    if (textClassifier2 == null)
      textClassifier1 = a.a(this.a); 
    return textClassifier1;
  }
  
  public void b(TextClassifier paramTextClassifier) {
    this.b = paramTextClassifier;
  }
  
  private static final class a {
    static TextClassifier a(TextView param1TextView) {
      TextClassificationManager textClassificationManager = (TextClassificationManager)param1TextView.getContext().getSystemService(TextClassificationManager.class);
      return (textClassificationManager != null) ? textClassificationManager.getTextClassifier() : TextClassifier.NO_OP;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */