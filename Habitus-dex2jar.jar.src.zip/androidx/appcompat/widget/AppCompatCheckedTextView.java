package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;
import androidx.core.widget.j;
import androidx.core.widget.n;
import g.a;
import h.a;

public class AppCompatCheckedTextView extends CheckedTextView implements n {
  private final e s0;
  
  private final d t0;
  
  private final r u0;
  
  private i v0;
  
  public AppCompatCheckedTextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.checkedTextViewStyle);
  }
  
  public AppCompatCheckedTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(m0.b(paramContext), paramAttributeSet, paramInt);
    k0.a((View)this, getContext());
    r r1 = new r((TextView)this);
    this.u0 = r1;
    r1.m(paramAttributeSet, paramInt);
    r1.b();
    d d1 = new d((View)this);
    this.t0 = d1;
    d1.e(paramAttributeSet, paramInt);
    e e1 = new e(this);
    this.s0 = e1;
    e1.d(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private i getEmojiTextViewHelper() {
    if (this.v0 == null)
      this.v0 = new i((TextView)this); 
    return this.v0;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    r r1 = this.u0;
    if (r1 != null)
      r1.b(); 
    d d1 = this.t0;
    if (d1 != null)
      d1.b(); 
    e e1 = this.s0;
    if (e1 != null)
      e1.a(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.q(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.t0;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.t0;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCheckMarkTintList() {
    e e1 = this.s0;
    return (e1 != null) ? e1.b() : null;
  }
  
  public PorterDuff.Mode getSupportCheckMarkTintMode() {
    e e1 = this.s0;
    return (e1 != null) ? e1.c() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.u0.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.u0.k();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return j.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.t0;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.t0;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCheckMarkDrawable(int paramInt) {
    setCheckMarkDrawable(a.b(getContext(), paramInt));
  }
  
  public void setCheckMarkDrawable(Drawable paramDrawable) {
    super.setCheckMarkDrawable(paramDrawable);
    e e1 = this.s0;
    if (e1 != null)
      e1.e(); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.u0;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.u0;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.r((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.t0;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.t0;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCheckMarkTintList(ColorStateList paramColorStateList) {
    e e1 = this.s0;
    if (e1 != null)
      e1.f(paramColorStateList); 
  }
  
  public void setSupportCheckMarkTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.s0;
    if (e1 != null)
      e1.g(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.u0.w(paramColorStateList);
    this.u0.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.u0.x(paramMode);
    this.u0.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    r r1 = this.u0;
    if (r1 != null)
      r1.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\AppCompatCheckedTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */