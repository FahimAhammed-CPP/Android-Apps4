package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.r;
import androidx.core.view.m0;
import androidx.core.view.o;
import androidx.core.view.r;
import androidx.core.view.s;
import androidx.core.view.v;
import androidx.core.view.x;
import g.j;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup implements s {
  View A0;
  
  private Context B0;
  
  private int C0;
  
  private int D0;
  
  private int E0;
  
  int F0;
  
  private int G0;
  
  private int H0;
  
  private int I0;
  
  private int J0;
  
  private int K0;
  
  private h0 L0;
  
  private int M0;
  
  private int N0;
  
  private int O0 = 8388627;
  
  private CharSequence P0;
  
  private CharSequence Q0;
  
  private ColorStateList R0;
  
  private ColorStateList S0;
  
  private boolean T0;
  
  private boolean U0;
  
  private final ArrayList<View> V0 = new ArrayList<View>();
  
  private final ArrayList<View> W0 = new ArrayList<View>();
  
  private final int[] X0 = new int[2];
  
  final v Y0 = new v(new q0(this));
  
  private ArrayList<MenuItem> Z0 = new ArrayList<MenuItem>();
  
  h a1;
  
  private final ActionMenuView.e b1 = new a(this);
  
  private t0 c1;
  
  private c d1;
  
  private f e1;
  
  private m.a f1;
  
  androidx.appcompat.view.menu.g.a g1;
  
  private boolean h1;
  
  private OnBackInvokedCallback i1;
  
  private OnBackInvokedDispatcher j1;
  
  private boolean k1;
  
  private final Runnable l1 = new b(this);
  
  ActionMenuView s0;
  
  private TextView t0;
  
  private TextView u0;
  
  private ImageButton v0;
  
  private ImageView w0;
  
  private Drawable x0;
  
  private CharSequence y0;
  
  ImageButton z0;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, g.a.toolbarStyle);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    p0 p0 = p0.v(getContext(), paramAttributeSet, j.Toolbar, paramInt, 0);
    m0.q0((View)this, paramContext, j.Toolbar, paramAttributeSet, p0.r(), paramInt, 0);
    this.D0 = p0.n(j.Toolbar_titleTextAppearance, 0);
    this.E0 = p0.n(j.Toolbar_subtitleTextAppearance, 0);
    this.O0 = p0.l(j.Toolbar_android_gravity, this.O0);
    this.F0 = p0.l(j.Toolbar_buttonGravity, 48);
    int i = p0.e(j.Toolbar_titleMargin, 0);
    paramInt = i;
    if (p0.s(j.Toolbar_titleMargins))
      paramInt = p0.e(j.Toolbar_titleMargins, i); 
    this.K0 = paramInt;
    this.J0 = paramInt;
    this.I0 = paramInt;
    this.H0 = paramInt;
    paramInt = p0.e(j.Toolbar_titleMarginStart, -1);
    if (paramInt >= 0)
      this.H0 = paramInt; 
    paramInt = p0.e(j.Toolbar_titleMarginEnd, -1);
    if (paramInt >= 0)
      this.I0 = paramInt; 
    paramInt = p0.e(j.Toolbar_titleMarginTop, -1);
    if (paramInt >= 0)
      this.J0 = paramInt; 
    paramInt = p0.e(j.Toolbar_titleMarginBottom, -1);
    if (paramInt >= 0)
      this.K0 = paramInt; 
    this.G0 = p0.f(j.Toolbar_maxButtonHeight, -1);
    paramInt = p0.e(j.Toolbar_contentInsetStart, -2147483648);
    i = p0.e(j.Toolbar_contentInsetEnd, -2147483648);
    int j = p0.f(j.Toolbar_contentInsetLeft, 0);
    int k = p0.f(j.Toolbar_contentInsetRight, 0);
    h();
    this.L0.e(j, k);
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      this.L0.g(paramInt, i); 
    this.M0 = p0.e(j.Toolbar_contentInsetStartWithNavigation, -2147483648);
    this.N0 = p0.e(j.Toolbar_contentInsetEndWithActions, -2147483648);
    this.x0 = p0.g(j.Toolbar_collapseIcon);
    this.y0 = p0.p(j.Toolbar_collapseContentDescription);
    CharSequence charSequence3 = p0.p(j.Toolbar_title);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = p0.p(j.Toolbar_subtitle);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.B0 = getContext();
    setPopupTheme(p0.n(j.Toolbar_popupTheme, 0));
    Drawable drawable2 = p0.g(j.Toolbar_navigationIcon);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = p0.p(j.Toolbar_navigationContentDescription);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = p0.g(j.Toolbar_logo);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = p0.p(j.Toolbar_logoDescription);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    if (p0.s(j.Toolbar_titleTextColor))
      setTitleTextColor(p0.c(j.Toolbar_titleTextColor)); 
    if (p0.s(j.Toolbar_subtitleTextColor))
      setSubtitleTextColor(p0.c(j.Toolbar_subtitleTextColor)); 
    if (p0.s(j.Toolbar_menu))
      x(p0.n(j.Toolbar_menu, 0)); 
    p0.w();
  }
  
  private int C(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    g g = (g)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)g).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, i);
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + i + ((ViewGroup.MarginLayoutParams)g).rightMargin;
  }
  
  private int D(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    g g = (g)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)g).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)g).leftMargin;
  }
  
  private int E(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int j = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfint[0] = Math.max(0, -i);
    paramArrayOfint[1] = Math.max(0, -j);
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + k + paramInt2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + k;
  }
  
  private void F(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  private void G() {
    Menu menu = getMenu();
    ArrayList<MenuItem> arrayList1 = getCurrentMenuItems();
    this.Y0.h(menu, getMenuInflater());
    ArrayList<MenuItem> arrayList2 = getCurrentMenuItems();
    arrayList2.removeAll(arrayList1);
    this.Z0 = arrayList2;
  }
  
  private void H() {
    removeCallbacks(this.l1);
    post(this.l1);
  }
  
  private boolean P() {
    if (!this.h1)
      return false; 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (Q(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  private boolean Q(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  private void b(List<View> paramList, int paramInt) {
    int i = m0.E((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = o.b(paramInt, m0.E((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        g g = (g)view.getLayoutParams();
        if (g.b == 0 && Q(view) && p(g.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        g g = (g)view.getLayoutParams();
        if (g.b == 0 && Q(view) && p(g.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  private void c(View paramView, boolean paramBoolean) {
    g g;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      g = m();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)g)) {
      g = o((ViewGroup.LayoutParams)g);
    } else {
      g = g;
    } 
    g.b = 1;
    if (paramBoolean && this.A0 != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)g);
      this.W0.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)g);
  }
  
  private ArrayList<MenuItem> getCurrentMenuItems() {
    ArrayList<MenuItem> arrayList = new ArrayList();
    Menu menu = getMenu();
    for (int i = 0; i < menu.size(); i++)
      arrayList.add(menu.getItem(i)); 
    return arrayList;
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new androidx.appcompat.view.g(getContext());
  }
  
  private void h() {
    if (this.L0 == null)
      this.L0 = new h0(); 
  }
  
  private void i() {
    if (this.w0 == null)
      this.w0 = new AppCompatImageView(getContext()); 
  }
  
  private void j() {
    k();
    if (this.s0.q() == null) {
      androidx.appcompat.view.menu.g g = (androidx.appcompat.view.menu.g)this.s0.getMenu();
      if (this.e1 == null)
        this.e1 = new f(this); 
      this.s0.setExpandedActionViewsExclusive(true);
      g.c(this.e1, this.B0);
      S();
    } 
  }
  
  private void k() {
    if (this.s0 == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext());
      this.s0 = actionMenuView;
      actionMenuView.setPopupTheme(this.C0);
      this.s0.setOnMenuItemClickListener(this.b1);
      this.s0.r(this.f1, new c(this));
      g g = m();
      g.a = this.F0 & 0x70 | 0x800005;
      this.s0.setLayoutParams((ViewGroup.LayoutParams)g);
      c((View)this.s0, false);
    } 
  }
  
  private void l() {
    if (this.v0 == null) {
      this.v0 = new AppCompatImageButton(getContext(), null, g.a.toolbarNavigationButtonStyle);
      g g = m();
      g.a = this.F0 & 0x70 | 0x800003;
      this.v0.setLayoutParams((ViewGroup.LayoutParams)g);
    } 
  }
  
  private int p(int paramInt) {
    int i = m0.E((View)this);
    int j = o.b(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  private int q(View paramView, int paramInt) {
    g g = (g)paramView.getLayoutParams();
    int j = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (j - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = r(g.a);
    if (i != 48) {
      if (i != 80) {
        int k = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - k - m - j) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)g).topMargin;
        if (i >= paramInt) {
          j = n - m - j - i - k;
          m = ((ViewGroup.MarginLayoutParams)g).bottomMargin;
          paramInt = i;
          if (j < m)
            paramInt = Math.max(0, i - m - j); 
        } 
        return k + paramInt;
      } 
      return getHeight() - getPaddingBottom() - j - ((ViewGroup.MarginLayoutParams)g).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int r(int paramInt) {
    int i = paramInt & 0x70;
    paramInt = i;
    if (i != 16) {
      paramInt = i;
      if (i != 48) {
        paramInt = i;
        if (i != 80)
          paramInt = this.O0 & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  private int s(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return r.b(marginLayoutParams) + r.a(marginLayoutParams);
  }
  
  private int t(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int u(List<View> paramList, int[] paramArrayOfint) {
    int m = paramArrayOfint[0];
    int k = paramArrayOfint[1];
    int n = paramList.size();
    int i = 0;
    int j = 0;
    while (i < n) {
      View view = paramList.get(i);
      g g = (g)view.getLayoutParams();
      m = ((ViewGroup.MarginLayoutParams)g).leftMargin - m;
      k = ((ViewGroup.MarginLayoutParams)g).rightMargin - k;
      int i1 = Math.max(0, m);
      int i2 = Math.max(0, k);
      m = Math.max(0, -m);
      k = Math.max(0, -k);
      j += i1 + view.getMeasuredWidth() + i2;
      i++;
    } 
    return j;
  }
  
  private boolean z(View paramView) {
    return (paramView.getParent() == this || this.W0.contains(paramView));
  }
  
  public boolean A() {
    ActionMenuView actionMenuView = this.s0;
    return (actionMenuView != null && actionMenuView.l());
  }
  
  public boolean B() {
    ActionMenuView actionMenuView = this.s0;
    return (actionMenuView != null && actionMenuView.m());
  }
  
  void I() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((g)view.getLayoutParams()).b != 2 && view != this.s0) {
        removeViewAt(i);
        this.W0.add(view);
      } 
    } 
  }
  
  public void J(int paramInt1, int paramInt2) {
    h();
    this.L0.e(paramInt1, paramInt2);
  }
  
  public void K(int paramInt1, int paramInt2) {
    h();
    this.L0.g(paramInt1, paramInt2);
  }
  
  public void L(androidx.appcompat.view.menu.g paramg, c paramc) {
    if (paramg == null && this.s0 == null)
      return; 
    k();
    androidx.appcompat.view.menu.g g1 = this.s0.q();
    if (g1 == paramg)
      return; 
    if (g1 != null) {
      g1.Q((m)this.d1);
      g1.Q(this.e1);
    } 
    if (this.e1 == null)
      this.e1 = new f(this); 
    paramc.I(true);
    if (paramg != null) {
      paramg.c((m)paramc, this.B0);
      paramg.c(this.e1, this.B0);
    } else {
      paramc.k(this.B0, null);
      this.e1.k(this.B0, null);
      paramc.h(true);
      this.e1.h(true);
    } 
    this.s0.setPopupTheme(this.C0);
    this.s0.setPresenter(paramc);
    this.d1 = paramc;
    S();
  }
  
  public void M(m.a parama, androidx.appcompat.view.menu.g.a parama1) {
    this.f1 = parama;
    this.g1 = parama1;
    ActionMenuView actionMenuView = this.s0;
    if (actionMenuView != null)
      actionMenuView.r(parama, parama1); 
  }
  
  public void N(Context paramContext, int paramInt) {
    this.E0 = paramInt;
    TextView textView = this.u0;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void O(Context paramContext, int paramInt) {
    this.D0 = paramInt;
    TextView textView = this.t0;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public boolean R() {
    ActionMenuView actionMenuView = this.s0;
    return (actionMenuView != null && actionMenuView.s());
  }
  
  void S() {
    if (Build.VERSION.SDK_INT >= 33) {
      boolean bool;
      OnBackInvokedDispatcher onBackInvokedDispatcher = e.a((View)this);
      if (v() && onBackInvokedDispatcher != null && m0.V((View)this) && this.k1) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool && this.j1 == null) {
        if (this.i1 == null)
          this.i1 = e.b(new r0(this)); 
        e.c(onBackInvokedDispatcher, this.i1);
        this.j1 = onBackInvokedDispatcher;
        return;
      } 
      if (!bool) {
        onBackInvokedDispatcher = this.j1;
        if (onBackInvokedDispatcher != null) {
          e.d(onBackInvokedDispatcher, this.i1);
          this.j1 = null;
        } 
      } 
    } 
  }
  
  void a() {
    for (int i = this.W0.size() - 1; i >= 0; i--)
      addView(this.W0.get(i)); 
    this.W0.clear();
  }
  
  public void addMenuProvider(x paramx) {
    this.Y0.c(paramx);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof g);
  }
  
  public boolean d() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.s0;
      if (actionMenuView != null && actionMenuView.n())
        return true; 
    } 
    return false;
  }
  
  public void e() {
    androidx.appcompat.view.menu.i i;
    f f1 = this.e1;
    if (f1 == null) {
      f1 = null;
    } else {
      i = f1.t0;
    } 
    if (i != null)
      i.collapseActionView(); 
  }
  
  public void f() {
    ActionMenuView actionMenuView = this.s0;
    if (actionMenuView != null)
      actionMenuView.e(); 
  }
  
  void g() {
    if (this.z0 == null) {
      AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, g.a.toolbarNavigationButtonStyle);
      this.z0 = appCompatImageButton;
      appCompatImageButton.setImageDrawable(this.x0);
      this.z0.setContentDescription(this.y0);
      g g = m();
      g.a = this.F0 & 0x70 | 0x800003;
      g.b = 2;
      this.z0.setLayoutParams((ViewGroup.LayoutParams)g);
      this.z0.setOnClickListener(new d(this));
    } 
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.z0;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.z0;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    h0 h01 = this.L0;
    return (h01 != null) ? h01.a() : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.N0;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    h0 h01 = this.L0;
    return (h01 != null) ? h01.b() : 0;
  }
  
  public int getContentInsetRight() {
    h0 h01 = this.L0;
    return (h01 != null) ? h01.c() : 0;
  }
  
  public int getContentInsetStart() {
    h0 h01 = this.L0;
    return (h01 != null) ? h01.d() : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.M0;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield s0 : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokevirtual q : ()Landroidx/appcompat/view/menu/g;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield N0 : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (m0.E((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (m0.E((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.M0, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.w0;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.w0;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    j();
    return this.s0.getMenu();
  }
  
  View getNavButtonView() {
    return (View)this.v0;
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.v0;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.v0;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  c getOuterActionMenuPresenter() {
    return this.d1;
  }
  
  public Drawable getOverflowIcon() {
    j();
    return this.s0.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.B0;
  }
  
  public int getPopupTheme() {
    return this.C0;
  }
  
  public CharSequence getSubtitle() {
    return this.Q0;
  }
  
  final TextView getSubtitleTextView() {
    return this.u0;
  }
  
  public CharSequence getTitle() {
    return this.P0;
  }
  
  public int getTitleMarginBottom() {
    return this.K0;
  }
  
  public int getTitleMarginEnd() {
    return this.I0;
  }
  
  public int getTitleMarginStart() {
    return this.H0;
  }
  
  public int getTitleMarginTop() {
    return this.J0;
  }
  
  final TextView getTitleTextView() {
    return this.t0;
  }
  
  public x getWrapper() {
    if (this.c1 == null)
      this.c1 = new t0(this, true); 
    return this.c1;
  }
  
  protected g m() {
    return new g(-2, -2);
  }
  
  public g n(AttributeSet paramAttributeSet) {
    return new g(getContext(), paramAttributeSet);
  }
  
  protected g o(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof g) ? new g((g)paramLayoutParams) : ((paramLayoutParams instanceof androidx.appcompat.app.a.a) ? new g((androidx.appcompat.app.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new g((ViewGroup.MarginLayoutParams)paramLayoutParams) : new g(paramLayoutParams)));
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    S();
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.l1);
    S();
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.U0 = false; 
    if (!this.U0) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.U0 = true; 
    } 
    if (i == 10 || i == 3)
      this.U0 = false; 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (m0.E((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    int i = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.X0;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = m0.F((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (Q((View)this.v0)) {
      if (k) {
        j = D((View)this.v0, m, arrayOfInt, paramInt4);
        paramInt3 = i;
      } else {
        paramInt3 = C((View)this.v0, i, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      paramInt3 = i;
      j = m;
    } 
    paramInt1 = paramInt3;
    paramInt2 = j;
    if (Q((View)this.z0))
      if (k) {
        paramInt2 = D((View)this.z0, j, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = C((View)this.z0, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    int j = paramInt1;
    paramInt3 = paramInt2;
    if (Q((View)this.s0))
      if (k) {
        j = C((View)this.s0, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = D((View)this.s0, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - paramInt3);
    paramInt2 = Math.max(j, paramInt2);
    paramInt3 = Math.min(paramInt3, m - paramInt1);
    paramInt1 = paramInt2;
    j = paramInt3;
    if (Q(this.A0))
      if (k) {
        j = D(this.A0, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = C(this.A0, paramInt2, arrayOfInt, paramInt4);
        j = paramInt3;
      }  
    paramInt3 = paramInt1;
    paramInt2 = j;
    if (Q((View)this.w0))
      if (k) {
        paramInt2 = D((View)this.w0, j, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = C((View)this.w0, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    paramBoolean = Q((View)this.t0);
    boolean bool = Q((View)this.u0);
    if (paramBoolean) {
      g g = (g)this.t0.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)g).topMargin + this.t0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)g).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      g g = (g)this.u0.getLayoutParams();
      paramInt1 += ((ViewGroup.MarginLayoutParams)g).topMargin + this.u0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)g).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.t0;
      } else {
        textView1 = this.u0;
      } 
      if (bool) {
        textView2 = this.u0;
      } else {
        textView2 = this.t0;
      } 
      g g1 = (g)textView1.getLayoutParams();
      g g2 = (g)textView2.getLayoutParams();
      if ((paramBoolean && this.t0.getMeasuredWidth() > 0) || (bool && this.u0.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.O0 & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)g1).topMargin;
          int i6 = this.J0;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)g1).bottomMargin;
            i5 = this.K0;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)g2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)g2).bottomMargin - this.K0 - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)g1).topMargin + this.J0;
      } 
      if (k) {
        if (j != 0) {
          k = this.H0;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[1];
        paramInt2 -= Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          g1 = (g)this.t0.getLayoutParams();
          m = paramInt2 - this.t0.getMeasuredWidth();
          k = this.t0.getMeasuredHeight() + paramInt1;
          this.t0.layout(m, paramInt1, paramInt2, k);
          paramInt1 = m - this.I0;
          m = k + ((ViewGroup.MarginLayoutParams)g1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = m + ((ViewGroup.MarginLayoutParams)this.u0.getLayoutParams()).topMargin;
          m = this.u0.getMeasuredWidth();
          i2 = this.u0.getMeasuredHeight();
          this.u0.layout(paramInt2 - m, k, paramInt2, i2 + k);
          k = paramInt2 - this.I0;
        } else {
          k = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, k); 
        paramInt1 = paramInt3;
      } else {
        if (j != 0) {
          k = this.H0;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[0];
        paramInt3 += Math.max(0, k);
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          g1 = (g)this.t0.getLayoutParams();
          k = this.t0.getMeasuredWidth() + paramInt3;
          m = this.t0.getMeasuredHeight() + paramInt1;
          this.t0.layout(paramInt3, paramInt1, k, m);
          k += this.I0;
          paramInt1 = m + ((ViewGroup.MarginLayoutParams)g1).bottomMargin;
        } else {
          k = paramInt3;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.u0.getLayoutParams()).topMargin;
          m = this.u0.getMeasuredWidth() + paramInt3;
          i2 = this.u0.getMeasuredHeight();
          this.u0.layout(paramInt3, paramInt1, m, i2 + paramInt1);
          m += this.I0;
        } else {
          m = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (j != 0) {
          paramInt1 = Math.max(k, m);
          paramInt3 = paramInt2;
        } 
        j = i;
        i = 0;
        b(this.V0, 3);
        k = this.V0.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    j = i;
    i = 0;
    b(this.V0, 3);
    int k = this.V0.size();
    paramInt2 = 0;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof i)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    i i1 = (i)paramParcelable;
    super.onRestoreInstanceState(i1.a());
    ActionMenuView actionMenuView = this.s0;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.g g = actionMenuView.q();
    } else {
      actionMenuView = null;
    } 
    int i = i1.u0;
    if (i != 0 && this.e1 != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (i1.v0)
      H(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    h();
    h0 h01 = this.L0;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    h01.f(bool);
  }
  
  protected Parcelable onSaveInstanceState() {
    i i = new i(super.onSaveInstanceState());
    f f1 = this.e1;
    if (f1 != null) {
      androidx.appcompat.view.menu.i i1 = f1.t0;
      if (i1 != null)
        i.u0 = i1.getItemId(); 
    } 
    i.v0 = B();
    return (Parcelable)i;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.T0 = false; 
    if (!this.T0) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.T0 = true; 
    } 
    if (i == 1 || i == 3)
      this.T0 = false; 
    return true;
  }
  
  public void removeMenuProvider(x paramx) {
    this.Y0.l(paramx);
  }
  
  public void setBackInvokedCallbackEnabled(boolean paramBoolean) {
    if (this.k1 != paramBoolean) {
      this.k1 = paramBoolean;
      S();
    } 
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.z0;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(h.a.b(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      this.z0.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.z0;
    if (imageButton != null)
      imageButton.setImageDrawable(this.x0); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.h1 = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.N0) {
      this.N0 = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.M0) {
      this.M0 = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(h.a.b(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      i();
      if (!z((View)this.w0))
        c((View)this.w0, true); 
    } else {
      ImageView imageView1 = this.w0;
      if (imageView1 != null && z((View)imageView1)) {
        removeView((View)this.w0);
        this.W0.remove(this.w0);
      } 
    } 
    ImageView imageView = this.w0;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      i(); 
    ImageView imageView = this.w0;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      l(); 
    ImageButton imageButton = this.v0;
    if (imageButton != null) {
      imageButton.setContentDescription(paramCharSequence);
      u0.a((View)this.v0, paramCharSequence);
    } 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(h.a.b(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      l();
      if (!z((View)this.v0))
        c((View)this.v0, true); 
    } else {
      ImageButton imageButton1 = this.v0;
      if (imageButton1 != null && z((View)imageButton1)) {
        removeView((View)this.v0);
        this.W0.remove(this.v0);
      } 
    } 
    ImageButton imageButton = this.v0;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    l();
    this.v0.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(h paramh) {
    this.a1 = paramh;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    j();
    this.s0.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.C0 != paramInt) {
      this.C0 = paramInt;
      if (paramInt == 0) {
        this.B0 = getContext();
        return;
      } 
      this.B0 = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.u0 == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.u0 = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.u0.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.E0;
        if (i != 0)
          this.u0.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.S0;
        if (colorStateList != null)
          this.u0.setTextColor(colorStateList); 
      } 
      if (!z((View)this.u0))
        c((View)this.u0, true); 
    } else {
      TextView textView1 = this.u0;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.u0);
        this.W0.remove(this.u0);
      } 
    } 
    TextView textView = this.u0;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.Q0 = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.S0 = paramColorStateList;
    TextView textView = this.u0;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.t0 == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.t0 = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.t0.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.D0;
        if (i != 0)
          this.t0.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.R0;
        if (colorStateList != null)
          this.t0.setTextColor(colorStateList); 
      } 
      if (!z((View)this.t0))
        c((View)this.t0, true); 
    } else {
      TextView textView1 = this.t0;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.t0);
        this.W0.remove(this.t0);
      } 
    } 
    TextView textView = this.t0;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.P0 = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.K0 = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.I0 = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.H0 = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.J0 = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.R0 = paramColorStateList;
    TextView textView = this.t0;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public boolean v() {
    f f1 = this.e1;
    return (f1 != null && f1.t0 != null);
  }
  
  public boolean w() {
    ActionMenuView actionMenuView = this.s0;
    return (actionMenuView != null && actionMenuView.k());
  }
  
  public void x(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public void y() {
    for (MenuItem menuItem : this.Z0)
      getMenu().removeItem(menuItem.getItemId()); 
    G();
  }
  
  class a implements ActionMenuView.e {
    a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      if (this.a.Y0.j(param1MenuItem))
        return true; 
      Toolbar.h h = this.a.a1;
      return (h != null) ? h.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  class b implements Runnable {
    b(Toolbar this$0) {}
    
    public void run() {
      this.s0.R();
    }
  }
  
  class c implements androidx.appcompat.view.menu.g.a {
    c(Toolbar this$0) {}
    
    public boolean a(androidx.appcompat.view.menu.g param1g, MenuItem param1MenuItem) {
      androidx.appcompat.view.menu.g.a a1 = this.s0.g1;
      return (a1 != null && a1.a(param1g, param1MenuItem));
    }
    
    public void b(androidx.appcompat.view.menu.g param1g) {
      if (!this.s0.s0.m())
        this.s0.Y0.k((Menu)param1g); 
      androidx.appcompat.view.menu.g.a a1 = this.s0.g1;
      if (a1 != null)
        a1.b(param1g); 
    }
  }
  
  class d implements View.OnClickListener {
    d(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.s0.e();
    }
  }
  
  static class e {
    static OnBackInvokedDispatcher a(View param1View) {
      return param1View.findOnBackInvokedDispatcher();
    }
    
    static OnBackInvokedCallback b(Runnable param1Runnable) {
      Objects.requireNonNull(param1Runnable);
      return new s0(param1Runnable);
    }
    
    static void c(Object param1Object1, Object param1Object2) {
      ((OnBackInvokedDispatcher)param1Object1).registerOnBackInvokedCallback(1000000, (OnBackInvokedCallback)param1Object2);
    }
    
    static void d(Object param1Object1, Object param1Object2) {
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  private class f implements m {
    androidx.appcompat.view.menu.g s0;
    
    androidx.appcompat.view.menu.i t0;
    
    f(Toolbar this$0) {}
    
    public void b(androidx.appcompat.view.menu.g param1g, boolean param1Boolean) {}
    
    public boolean c(androidx.appcompat.view.menu.g param1g, androidx.appcompat.view.menu.i param1i) {
      this.u0.g();
      ViewParent viewParent = this.u0.z0.getParent();
      Toolbar toolbar = this.u0;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.z0); 
        Toolbar toolbar1 = this.u0;
        toolbar1.addView((View)toolbar1.z0);
      } 
      this.u0.A0 = param1i.getActionView();
      this.t0 = param1i;
      viewParent = this.u0.A0.getParent();
      toolbar = this.u0;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.A0); 
        Toolbar.g g1 = this.u0.m();
        toolbar = this.u0;
        g1.a = toolbar.F0 & 0x70 | 0x800003;
        g1.b = 2;
        toolbar.A0.setLayoutParams((ViewGroup.LayoutParams)g1);
        Toolbar toolbar1 = this.u0;
        toolbar1.addView(toolbar1.A0);
      } 
      this.u0.I();
      this.u0.requestLayout();
      param1i.r(true);
      View view = this.u0.A0;
      if (view instanceof androidx.appcompat.view.c)
        ((androidx.appcompat.view.c)view).onActionViewExpanded(); 
      this.u0.S();
      return true;
    }
    
    public void e(Parcelable param1Parcelable) {}
    
    public boolean f(r param1r) {
      return false;
    }
    
    public Parcelable g() {
      return null;
    }
    
    public int getId() {
      return 0;
    }
    
    public void h(boolean param1Boolean) {
      if (this.t0 != null) {
        androidx.appcompat.view.menu.g g1 = this.s0;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (g1 != null) {
          int k = g1.size();
          int j = 0;
          while (true) {
            bool1 = bool2;
            if (j < k) {
              if (this.s0.getItem(j) == this.t0) {
                bool1 = true;
                break;
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          j(this.s0, this.t0); 
      } 
    }
    
    public boolean i() {
      return false;
    }
    
    public boolean j(androidx.appcompat.view.menu.g param1g, androidx.appcompat.view.menu.i param1i) {
      View view = this.u0.A0;
      if (view instanceof androidx.appcompat.view.c)
        ((androidx.appcompat.view.c)view).onActionViewCollapsed(); 
      Toolbar toolbar = this.u0;
      toolbar.removeView(toolbar.A0);
      toolbar = this.u0;
      toolbar.removeView((View)toolbar.z0);
      toolbar = this.u0;
      toolbar.A0 = null;
      toolbar.a();
      this.t0 = null;
      this.u0.requestLayout();
      param1i.r(false);
      this.u0.S();
      return true;
    }
    
    public void k(Context param1Context, androidx.appcompat.view.menu.g param1g) {
      androidx.appcompat.view.menu.g g1 = this.s0;
      if (g1 != null) {
        androidx.appcompat.view.menu.i i1 = this.t0;
        if (i1 != null)
          g1.f(i1); 
      } 
      this.s0 = param1g;
    }
  }
  
  public static class g extends androidx.appcompat.app.a.a {
    int b = 0;
    
    public g(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public g(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public g(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public g(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    public g(androidx.appcompat.app.a.a param1a) {
      super(param1a);
    }
    
    public g(g param1g) {
      super(param1g);
      this.b = param1g.b;
    }
    
    void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface h {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class i extends z2.a {
    public static final Parcelable.Creator<i> CREATOR = (Parcelable.Creator<i>)new a();
    
    int u0;
    
    boolean v0;
    
    public i(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.u0 = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.v0 = bool;
    }
    
    public i(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    class a implements Parcelable.ClassLoaderCreator<i> {
      public Toolbar.i a(Parcel param2Parcel) {
        return new Toolbar.i(param2Parcel, null);
      }
      
      public Toolbar.i b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.i(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.i[] c(int param2Int) {
        return new Toolbar.i[param2Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator<i> {
    public Toolbar.i a(Parcel param1Parcel) {
      return new Toolbar.i(param1Parcel, null);
    }
    
    public Toolbar.i b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.i(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.i[] c(int param1Int) {
      return new Toolbar.i[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */