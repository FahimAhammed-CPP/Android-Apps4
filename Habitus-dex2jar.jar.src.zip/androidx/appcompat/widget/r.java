package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.LocaleList;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import androidx.core.content.res.h;
import androidx.core.view.m0;
import g.j;
import java.lang.ref.WeakReference;
import java.util.Locale;

class r {
  private final TextView a;
  
  private n0 b;
  
  private n0 c;
  
  private n0 d;
  
  private n0 e;
  
  private n0 f;
  
  private n0 g;
  
  private n0 h;
  
  private final s i;
  
  private int j = 0;
  
  private int k = -1;
  
  private Typeface l;
  
  private boolean m;
  
  r(TextView paramTextView) {
    this.a = paramTextView;
    this.i = new s(paramTextView);
  }
  
  private void B(int paramInt, float paramFloat) {
    this.i.t(paramInt, paramFloat);
  }
  
  private void C(Context paramContext, p0 paramp0) {
    this.j = paramp0.k(j.TextAppearance_android_textStyle, this.j);
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (i >= 28) {
      int j = paramp0.k(j.TextAppearance_android_textFontWeight, -1);
      this.k = j;
      if (j != -1)
        this.j = this.j & 0x2 | 0x0; 
    } 
    if (paramp0.s(j.TextAppearance_android_fontFamily) || paramp0.s(j.TextAppearance_fontFamily)) {
      int j;
      this.l = null;
      if (paramp0.s(j.TextAppearance_fontFamily)) {
        j = j.TextAppearance_fontFamily;
      } else {
        j = j.TextAppearance_android_fontFamily;
      } 
      int k = this.k;
      int m = this.j;
      if (!paramContext.isRestricted()) {
        a a = new a(this, k, m, new WeakReference<TextView>(this.a));
        try {
          boolean bool1;
          Typeface typeface = paramp0.j(j, this.j, a);
          if (typeface != null)
            if (i >= 28 && this.k != -1) {
              typeface = Typeface.create(typeface, 0);
              i = this.k;
              if ((this.j & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              } 
              this.l = g.a(typeface, i, bool1);
            } else {
              this.l = typeface;
            }  
          if (this.l == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.m = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.l == null) {
        String str = paramp0.o(j);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.k != -1) {
            typeface = Typeface.create(str, 0);
            j = this.k;
            boolean bool1 = bool;
            if ((this.j & 0x2) != 0)
              bool1 = true; 
            this.l = g.a(typeface, j, bool1);
            return;
          } 
          this.l = Typeface.create((String)typeface, this.j);
        } 
      } 
      return;
    } 
    if (paramp0.s(j.TextAppearance_android_typeface)) {
      this.m = false;
      int j = paramp0.k(j.TextAppearance_android_typeface, 1);
      if (j != 1) {
        if (j != 2) {
          if (j != 3)
            return; 
          this.l = Typeface.MONOSPACE;
          return;
        } 
        this.l = Typeface.SERIF;
        return;
      } 
      this.l = Typeface.SANS_SERIF;
    } 
  }
  
  private void a(Drawable paramDrawable, n0 paramn0) {
    if (paramDrawable != null && paramn0 != null)
      g.i(paramDrawable, paramn0, this.a.getDrawableState()); 
  }
  
  private static n0 d(Context paramContext, g paramg, int paramInt) {
    ColorStateList colorStateList = paramg.f(paramContext, paramInt);
    if (colorStateList != null) {
      n0 n01 = new n0();
      n01.d = true;
      n01.a = colorStateList;
      return n01;
    } 
    return null;
  }
  
  private void y(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4, Drawable paramDrawable5, Drawable paramDrawable6) {
    TextView textView;
    Drawable[] arrayOfDrawable;
    if (paramDrawable5 != null || paramDrawable6 != null) {
      arrayOfDrawable = c.a(this.a);
      textView = this.a;
      if (paramDrawable5 == null)
        paramDrawable5 = arrayOfDrawable[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable[1]; 
      if (paramDrawable6 == null)
        paramDrawable6 = arrayOfDrawable[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable[3]; 
      c.b(textView, paramDrawable5, paramDrawable2, paramDrawable6, paramDrawable4);
      return;
    } 
    if (textView != null || paramDrawable2 != null || arrayOfDrawable != null || paramDrawable4 != null) {
      Drawable drawable1;
      Drawable drawable2;
      Drawable[] arrayOfDrawable1 = c.a(this.a);
      paramDrawable5 = arrayOfDrawable1[0];
      if (paramDrawable5 != null || arrayOfDrawable1[2] != null) {
        textView = this.a;
        if (paramDrawable2 == null)
          paramDrawable2 = arrayOfDrawable1[1]; 
        drawable2 = arrayOfDrawable1[2];
        if (paramDrawable4 == null)
          paramDrawable4 = arrayOfDrawable1[3]; 
        c.b(textView, paramDrawable5, paramDrawable2, drawable2, paramDrawable4);
        return;
      } 
      arrayOfDrawable1 = this.a.getCompoundDrawables();
      TextView textView1 = this.a;
      if (textView == null)
        drawable1 = arrayOfDrawable1[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable1[1]; 
      if (drawable2 == null)
        drawable2 = arrayOfDrawable1[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable1[3]; 
      textView1.setCompoundDrawablesWithIntrinsicBounds(drawable1, paramDrawable2, drawable2, paramDrawable4);
      return;
    } 
  }
  
  private void z() {
    n0 n01 = this.h;
    this.b = n01;
    this.c = n01;
    this.d = n01;
    this.e = n01;
    this.f = n01;
    this.g = n01;
  }
  
  void A(int paramInt, float paramFloat) {
    if (!a1.b && !l())
      B(paramInt, paramFloat); 
  }
  
  void b() {
    if (this.b != null || this.c != null || this.d != null || this.e != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.b);
      a(arrayOfDrawable[1], this.c);
      a(arrayOfDrawable[2], this.d);
      a(arrayOfDrawable[3], this.e);
    } 
    if (this.f != null || this.g != null) {
      Drawable[] arrayOfDrawable = c.a(this.a);
      a(arrayOfDrawable[0], this.f);
      a(arrayOfDrawable[2], this.g);
    } 
  }
  
  void c() {
    this.i.a();
  }
  
  int e() {
    return this.i.f();
  }
  
  int f() {
    return this.i.g();
  }
  
  int g() {
    return this.i.h();
  }
  
  int[] h() {
    return this.i.i();
  }
  
  int i() {
    return this.i.j();
  }
  
  ColorStateList j() {
    n0 n01 = this.h;
    return (n01 != null) ? n01.a : null;
  }
  
  PorterDuff.Mode k() {
    n0 n01 = this.h;
    return (n01 != null) ? n01.b : null;
  }
  
  boolean l() {
    return this.i.n();
  }
  
  @SuppressLint({"NewApi"})
  void m(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #16
    //   9: invokestatic b : ()Landroidx/appcompat/widget/g;
    //   12: astore #15
    //   14: aload #16
    //   16: aload_1
    //   17: getstatic g/j.AppCompatTextHelper : [I
    //   20: iload_2
    //   21: iconst_0
    //   22: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/p0;
    //   25: astore #7
    //   27: aload_0
    //   28: getfield a : Landroid/widget/TextView;
    //   31: astore #8
    //   33: aload #8
    //   35: aload #8
    //   37: invokevirtual getContext : ()Landroid/content/Context;
    //   40: getstatic g/j.AppCompatTextHelper : [I
    //   43: aload_1
    //   44: aload #7
    //   46: invokevirtual r : ()Landroid/content/res/TypedArray;
    //   49: iload_2
    //   50: iconst_0
    //   51: invokestatic q0 : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   54: aload #7
    //   56: getstatic g/j.AppCompatTextHelper_android_textAppearance : I
    //   59: iconst_m1
    //   60: invokevirtual n : (II)I
    //   63: istore_3
    //   64: aload #7
    //   66: getstatic g/j.AppCompatTextHelper_android_drawableLeft : I
    //   69: invokevirtual s : (I)Z
    //   72: ifeq -> 95
    //   75: aload_0
    //   76: aload #16
    //   78: aload #15
    //   80: aload #7
    //   82: getstatic g/j.AppCompatTextHelper_android_drawableLeft : I
    //   85: iconst_0
    //   86: invokevirtual n : (II)I
    //   89: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/g;I)Landroidx/appcompat/widget/n0;
    //   92: putfield b : Landroidx/appcompat/widget/n0;
    //   95: aload #7
    //   97: getstatic g/j.AppCompatTextHelper_android_drawableTop : I
    //   100: invokevirtual s : (I)Z
    //   103: ifeq -> 126
    //   106: aload_0
    //   107: aload #16
    //   109: aload #15
    //   111: aload #7
    //   113: getstatic g/j.AppCompatTextHelper_android_drawableTop : I
    //   116: iconst_0
    //   117: invokevirtual n : (II)I
    //   120: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/g;I)Landroidx/appcompat/widget/n0;
    //   123: putfield c : Landroidx/appcompat/widget/n0;
    //   126: aload #7
    //   128: getstatic g/j.AppCompatTextHelper_android_drawableRight : I
    //   131: invokevirtual s : (I)Z
    //   134: ifeq -> 157
    //   137: aload_0
    //   138: aload #16
    //   140: aload #15
    //   142: aload #7
    //   144: getstatic g/j.AppCompatTextHelper_android_drawableRight : I
    //   147: iconst_0
    //   148: invokevirtual n : (II)I
    //   151: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/g;I)Landroidx/appcompat/widget/n0;
    //   154: putfield d : Landroidx/appcompat/widget/n0;
    //   157: aload #7
    //   159: getstatic g/j.AppCompatTextHelper_android_drawableBottom : I
    //   162: invokevirtual s : (I)Z
    //   165: ifeq -> 188
    //   168: aload_0
    //   169: aload #16
    //   171: aload #15
    //   173: aload #7
    //   175: getstatic g/j.AppCompatTextHelper_android_drawableBottom : I
    //   178: iconst_0
    //   179: invokevirtual n : (II)I
    //   182: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/g;I)Landroidx/appcompat/widget/n0;
    //   185: putfield e : Landroidx/appcompat/widget/n0;
    //   188: getstatic android/os/Build$VERSION.SDK_INT : I
    //   191: istore #4
    //   193: aload #7
    //   195: getstatic g/j.AppCompatTextHelper_android_drawableStart : I
    //   198: invokevirtual s : (I)Z
    //   201: ifeq -> 224
    //   204: aload_0
    //   205: aload #16
    //   207: aload #15
    //   209: aload #7
    //   211: getstatic g/j.AppCompatTextHelper_android_drawableStart : I
    //   214: iconst_0
    //   215: invokevirtual n : (II)I
    //   218: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/g;I)Landroidx/appcompat/widget/n0;
    //   221: putfield f : Landroidx/appcompat/widget/n0;
    //   224: aload #7
    //   226: getstatic g/j.AppCompatTextHelper_android_drawableEnd : I
    //   229: invokevirtual s : (I)Z
    //   232: ifeq -> 255
    //   235: aload_0
    //   236: aload #16
    //   238: aload #15
    //   240: aload #7
    //   242: getstatic g/j.AppCompatTextHelper_android_drawableEnd : I
    //   245: iconst_0
    //   246: invokevirtual n : (II)I
    //   249: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/g;I)Landroidx/appcompat/widget/n0;
    //   252: putfield g : Landroidx/appcompat/widget/n0;
    //   255: aload #7
    //   257: invokevirtual w : ()V
    //   260: aload_0
    //   261: getfield a : Landroid/widget/TextView;
    //   264: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   267: instanceof android/text/method/PasswordTransformationMethod
    //   270: istore #6
    //   272: iload_3
    //   273: iconst_m1
    //   274: if_icmpeq -> 524
    //   277: aload #16
    //   279: iload_3
    //   280: getstatic g/j.TextAppearance : [I
    //   283: invokestatic t : (Landroid/content/Context;I[I)Landroidx/appcompat/widget/p0;
    //   286: astore #13
    //   288: iload #6
    //   290: ifne -> 320
    //   293: aload #13
    //   295: getstatic g/j.TextAppearance_textAllCaps : I
    //   298: invokevirtual s : (I)Z
    //   301: ifeq -> 320
    //   304: aload #13
    //   306: getstatic g/j.TextAppearance_textAllCaps : I
    //   309: iconst_0
    //   310: invokevirtual a : (IZ)Z
    //   313: istore #5
    //   315: iconst_1
    //   316: istore_3
    //   317: goto -> 325
    //   320: iconst_0
    //   321: istore #5
    //   323: iconst_0
    //   324: istore_3
    //   325: aload_0
    //   326: aload #16
    //   328: aload #13
    //   330: invokespecial C : (Landroid/content/Context;Landroidx/appcompat/widget/p0;)V
    //   333: iload #4
    //   335: bipush #23
    //   337: if_icmpge -> 434
    //   340: aload #13
    //   342: getstatic g/j.TextAppearance_android_textColor : I
    //   345: invokevirtual s : (I)Z
    //   348: ifeq -> 364
    //   351: aload #13
    //   353: getstatic g/j.TextAppearance_android_textColor : I
    //   356: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   359: astore #7
    //   361: goto -> 367
    //   364: aconst_null
    //   365: astore #7
    //   367: aload #13
    //   369: getstatic g/j.TextAppearance_android_textColorHint : I
    //   372: invokevirtual s : (I)Z
    //   375: ifeq -> 391
    //   378: aload #13
    //   380: getstatic g/j.TextAppearance_android_textColorHint : I
    //   383: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   386: astore #8
    //   388: goto -> 394
    //   391: aconst_null
    //   392: astore #8
    //   394: aload #7
    //   396: astore #10
    //   398: aload #8
    //   400: astore #9
    //   402: aload #13
    //   404: getstatic g/j.TextAppearance_android_textColorLink : I
    //   407: invokevirtual s : (I)Z
    //   410: ifeq -> 440
    //   413: aload #13
    //   415: getstatic g/j.TextAppearance_android_textColorLink : I
    //   418: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   421: astore #11
    //   423: aload #7
    //   425: astore #10
    //   427: aload #8
    //   429: astore #7
    //   431: goto -> 447
    //   434: aconst_null
    //   435: astore #10
    //   437: aconst_null
    //   438: astore #9
    //   440: aconst_null
    //   441: astore #11
    //   443: aload #9
    //   445: astore #7
    //   447: aload #13
    //   449: getstatic g/j.TextAppearance_textLocale : I
    //   452: invokevirtual s : (I)Z
    //   455: ifeq -> 471
    //   458: aload #13
    //   460: getstatic g/j.TextAppearance_textLocale : I
    //   463: invokevirtual o : (I)Ljava/lang/String;
    //   466: astore #12
    //   468: goto -> 474
    //   471: aconst_null
    //   472: astore #12
    //   474: iload #4
    //   476: bipush #26
    //   478: if_icmplt -> 505
    //   481: aload #13
    //   483: getstatic g/j.TextAppearance_fontVariationSettings : I
    //   486: invokevirtual s : (I)Z
    //   489: ifeq -> 505
    //   492: aload #13
    //   494: getstatic g/j.TextAppearance_fontVariationSettings : I
    //   497: invokevirtual o : (I)Ljava/lang/String;
    //   500: astore #9
    //   502: goto -> 508
    //   505: aconst_null
    //   506: astore #9
    //   508: aload #13
    //   510: invokevirtual w : ()V
    //   513: aload #10
    //   515: astore #8
    //   517: aload #12
    //   519: astore #10
    //   521: goto -> 544
    //   524: aconst_null
    //   525: astore #9
    //   527: aconst_null
    //   528: astore #8
    //   530: aconst_null
    //   531: astore #10
    //   533: iconst_0
    //   534: istore #5
    //   536: aconst_null
    //   537: astore #7
    //   539: aconst_null
    //   540: astore #11
    //   542: iconst_0
    //   543: istore_3
    //   544: aload #16
    //   546: aload_1
    //   547: getstatic g/j.TextAppearance : [I
    //   550: iload_2
    //   551: iconst_0
    //   552: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/p0;
    //   555: astore #17
    //   557: iload #6
    //   559: ifne -> 589
    //   562: aload #17
    //   564: getstatic g/j.TextAppearance_textAllCaps : I
    //   567: invokevirtual s : (I)Z
    //   570: ifeq -> 589
    //   573: aload #17
    //   575: getstatic g/j.TextAppearance_textAllCaps : I
    //   578: iconst_0
    //   579: invokevirtual a : (IZ)Z
    //   582: istore #5
    //   584: iconst_1
    //   585: istore_3
    //   586: goto -> 589
    //   589: aload #8
    //   591: astore #12
    //   593: aload #7
    //   595: astore #13
    //   597: aload #11
    //   599: astore #14
    //   601: iload #4
    //   603: bipush #23
    //   605: if_icmpge -> 691
    //   608: aload #17
    //   610: getstatic g/j.TextAppearance_android_textColor : I
    //   613: invokevirtual s : (I)Z
    //   616: ifeq -> 629
    //   619: aload #17
    //   621: getstatic g/j.TextAppearance_android_textColor : I
    //   624: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   627: astore #8
    //   629: aload #17
    //   631: getstatic g/j.TextAppearance_android_textColorHint : I
    //   634: invokevirtual s : (I)Z
    //   637: ifeq -> 650
    //   640: aload #17
    //   642: getstatic g/j.TextAppearance_android_textColorHint : I
    //   645: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   648: astore #7
    //   650: aload #8
    //   652: astore #12
    //   654: aload #7
    //   656: astore #13
    //   658: aload #11
    //   660: astore #14
    //   662: aload #17
    //   664: getstatic g/j.TextAppearance_android_textColorLink : I
    //   667: invokevirtual s : (I)Z
    //   670: ifeq -> 691
    //   673: aload #17
    //   675: getstatic g/j.TextAppearance_android_textColorLink : I
    //   678: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   681: astore #14
    //   683: aload #7
    //   685: astore #13
    //   687: aload #8
    //   689: astore #12
    //   691: aload #17
    //   693: getstatic g/j.TextAppearance_textLocale : I
    //   696: invokevirtual s : (I)Z
    //   699: ifeq -> 712
    //   702: aload #17
    //   704: getstatic g/j.TextAppearance_textLocale : I
    //   707: invokevirtual o : (I)Ljava/lang/String;
    //   710: astore #10
    //   712: aload #9
    //   714: astore #7
    //   716: iload #4
    //   718: bipush #26
    //   720: if_icmplt -> 748
    //   723: aload #9
    //   725: astore #7
    //   727: aload #17
    //   729: getstatic g/j.TextAppearance_fontVariationSettings : I
    //   732: invokevirtual s : (I)Z
    //   735: ifeq -> 748
    //   738: aload #17
    //   740: getstatic g/j.TextAppearance_fontVariationSettings : I
    //   743: invokevirtual o : (I)Ljava/lang/String;
    //   746: astore #7
    //   748: iload #4
    //   750: bipush #28
    //   752: if_icmplt -> 790
    //   755: aload #17
    //   757: getstatic g/j.TextAppearance_android_textSize : I
    //   760: invokevirtual s : (I)Z
    //   763: ifeq -> 790
    //   766: aload #17
    //   768: getstatic g/j.TextAppearance_android_textSize : I
    //   771: iconst_m1
    //   772: invokevirtual f : (II)I
    //   775: ifne -> 790
    //   778: aload_0
    //   779: getfield a : Landroid/widget/TextView;
    //   782: iconst_0
    //   783: fconst_0
    //   784: invokevirtual setTextSize : (IF)V
    //   787: goto -> 790
    //   790: aload_0
    //   791: aload #16
    //   793: aload #17
    //   795: invokespecial C : (Landroid/content/Context;Landroidx/appcompat/widget/p0;)V
    //   798: aload #17
    //   800: invokevirtual w : ()V
    //   803: aload #12
    //   805: ifnull -> 817
    //   808: aload_0
    //   809: getfield a : Landroid/widget/TextView;
    //   812: aload #12
    //   814: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   817: aload #13
    //   819: ifnull -> 831
    //   822: aload_0
    //   823: getfield a : Landroid/widget/TextView;
    //   826: aload #13
    //   828: invokevirtual setHintTextColor : (Landroid/content/res/ColorStateList;)V
    //   831: aload #14
    //   833: ifnull -> 845
    //   836: aload_0
    //   837: getfield a : Landroid/widget/TextView;
    //   840: aload #14
    //   842: invokevirtual setLinkTextColor : (Landroid/content/res/ColorStateList;)V
    //   845: iload #6
    //   847: ifne -> 860
    //   850: iload_3
    //   851: ifeq -> 860
    //   854: aload_0
    //   855: iload #5
    //   857: invokevirtual s : (Z)V
    //   860: aload_0
    //   861: getfield l : Landroid/graphics/Typeface;
    //   864: astore #8
    //   866: aload #8
    //   868: ifnull -> 904
    //   871: aload_0
    //   872: getfield k : I
    //   875: iconst_m1
    //   876: if_icmpne -> 895
    //   879: aload_0
    //   880: getfield a : Landroid/widget/TextView;
    //   883: aload #8
    //   885: aload_0
    //   886: getfield j : I
    //   889: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   892: goto -> 904
    //   895: aload_0
    //   896: getfield a : Landroid/widget/TextView;
    //   899: aload #8
    //   901: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   904: aload #7
    //   906: ifnull -> 919
    //   909: aload_0
    //   910: getfield a : Landroid/widget/TextView;
    //   913: aload #7
    //   915: invokestatic d : (Landroid/widget/TextView;Ljava/lang/String;)Z
    //   918: pop
    //   919: aload #10
    //   921: ifnull -> 970
    //   924: iload #4
    //   926: bipush #24
    //   928: if_icmplt -> 946
    //   931: aload_0
    //   932: getfield a : Landroid/widget/TextView;
    //   935: aload #10
    //   937: invokestatic a : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   940: invokestatic b : (Landroid/widget/TextView;Landroid/os/LocaleList;)V
    //   943: goto -> 970
    //   946: aload #10
    //   948: ldc_w ','
    //   951: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   954: iconst_0
    //   955: aaload
    //   956: astore #7
    //   958: aload_0
    //   959: getfield a : Landroid/widget/TextView;
    //   962: aload #7
    //   964: invokestatic a : (Ljava/lang/String;)Ljava/util/Locale;
    //   967: invokestatic c : (Landroid/widget/TextView;Ljava/util/Locale;)V
    //   970: aload_0
    //   971: getfield i : Landroidx/appcompat/widget/s;
    //   974: aload_1
    //   975: iload_2
    //   976: invokevirtual o : (Landroid/util/AttributeSet;I)V
    //   979: getstatic androidx/appcompat/widget/a1.b : Z
    //   982: ifeq -> 1067
    //   985: aload_0
    //   986: getfield i : Landroidx/appcompat/widget/s;
    //   989: invokevirtual j : ()I
    //   992: ifeq -> 1067
    //   995: aload_0
    //   996: getfield i : Landroidx/appcompat/widget/s;
    //   999: invokevirtual i : ()[I
    //   1002: astore #7
    //   1004: aload #7
    //   1006: arraylength
    //   1007: ifle -> 1067
    //   1010: aload_0
    //   1011: getfield a : Landroid/widget/TextView;
    //   1014: invokestatic a : (Landroid/widget/TextView;)I
    //   1017: i2f
    //   1018: ldc_w -1.0
    //   1021: fcmpl
    //   1022: ifeq -> 1057
    //   1025: aload_0
    //   1026: getfield a : Landroid/widget/TextView;
    //   1029: aload_0
    //   1030: getfield i : Landroidx/appcompat/widget/s;
    //   1033: invokevirtual g : ()I
    //   1036: aload_0
    //   1037: getfield i : Landroidx/appcompat/widget/s;
    //   1040: invokevirtual f : ()I
    //   1043: aload_0
    //   1044: getfield i : Landroidx/appcompat/widget/s;
    //   1047: invokevirtual h : ()I
    //   1050: iconst_0
    //   1051: invokestatic b : (Landroid/widget/TextView;IIII)V
    //   1054: goto -> 1067
    //   1057: aload_0
    //   1058: getfield a : Landroid/widget/TextView;
    //   1061: aload #7
    //   1063: iconst_0
    //   1064: invokestatic c : (Landroid/widget/TextView;[II)V
    //   1067: aload #16
    //   1069: aload_1
    //   1070: getstatic g/j.AppCompatTextView : [I
    //   1073: invokestatic u : (Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroidx/appcompat/widget/p0;
    //   1076: astore #12
    //   1078: aload #12
    //   1080: getstatic g/j.AppCompatTextView_drawableLeftCompat : I
    //   1083: iconst_m1
    //   1084: invokevirtual n : (II)I
    //   1087: istore_2
    //   1088: iload_2
    //   1089: iconst_m1
    //   1090: if_icmpeq -> 1105
    //   1093: aload #15
    //   1095: aload #16
    //   1097: iload_2
    //   1098: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1101: astore_1
    //   1102: goto -> 1107
    //   1105: aconst_null
    //   1106: astore_1
    //   1107: aload #12
    //   1109: getstatic g/j.AppCompatTextView_drawableTopCompat : I
    //   1112: iconst_m1
    //   1113: invokevirtual n : (II)I
    //   1116: istore_2
    //   1117: iload_2
    //   1118: iconst_m1
    //   1119: if_icmpeq -> 1135
    //   1122: aload #15
    //   1124: aload #16
    //   1126: iload_2
    //   1127: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1130: astore #7
    //   1132: goto -> 1138
    //   1135: aconst_null
    //   1136: astore #7
    //   1138: aload #12
    //   1140: getstatic g/j.AppCompatTextView_drawableRightCompat : I
    //   1143: iconst_m1
    //   1144: invokevirtual n : (II)I
    //   1147: istore_2
    //   1148: iload_2
    //   1149: iconst_m1
    //   1150: if_icmpeq -> 1166
    //   1153: aload #15
    //   1155: aload #16
    //   1157: iload_2
    //   1158: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1161: astore #8
    //   1163: goto -> 1169
    //   1166: aconst_null
    //   1167: astore #8
    //   1169: aload #12
    //   1171: getstatic g/j.AppCompatTextView_drawableBottomCompat : I
    //   1174: iconst_m1
    //   1175: invokevirtual n : (II)I
    //   1178: istore_2
    //   1179: iload_2
    //   1180: iconst_m1
    //   1181: if_icmpeq -> 1197
    //   1184: aload #15
    //   1186: aload #16
    //   1188: iload_2
    //   1189: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1192: astore #9
    //   1194: goto -> 1200
    //   1197: aconst_null
    //   1198: astore #9
    //   1200: aload #12
    //   1202: getstatic g/j.AppCompatTextView_drawableStartCompat : I
    //   1205: iconst_m1
    //   1206: invokevirtual n : (II)I
    //   1209: istore_2
    //   1210: iload_2
    //   1211: iconst_m1
    //   1212: if_icmpeq -> 1228
    //   1215: aload #15
    //   1217: aload #16
    //   1219: iload_2
    //   1220: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1223: astore #10
    //   1225: goto -> 1231
    //   1228: aconst_null
    //   1229: astore #10
    //   1231: aload #12
    //   1233: getstatic g/j.AppCompatTextView_drawableEndCompat : I
    //   1236: iconst_m1
    //   1237: invokevirtual n : (II)I
    //   1240: istore_2
    //   1241: iload_2
    //   1242: iconst_m1
    //   1243: if_icmpeq -> 1259
    //   1246: aload #15
    //   1248: aload #16
    //   1250: iload_2
    //   1251: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1254: astore #11
    //   1256: goto -> 1262
    //   1259: aconst_null
    //   1260: astore #11
    //   1262: aload_0
    //   1263: aload_1
    //   1264: aload #7
    //   1266: aload #8
    //   1268: aload #9
    //   1270: aload #10
    //   1272: aload #11
    //   1274: invokespecial y : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1277: aload #12
    //   1279: getstatic g/j.AppCompatTextView_drawableTint : I
    //   1282: invokevirtual s : (I)Z
    //   1285: ifeq -> 1305
    //   1288: aload #12
    //   1290: getstatic g/j.AppCompatTextView_drawableTint : I
    //   1293: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   1296: astore_1
    //   1297: aload_0
    //   1298: getfield a : Landroid/widget/TextView;
    //   1301: aload_1
    //   1302: invokestatic h : (Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V
    //   1305: aload #12
    //   1307: getstatic g/j.AppCompatTextView_drawableTintMode : I
    //   1310: invokevirtual s : (I)Z
    //   1313: ifeq -> 1341
    //   1316: aload #12
    //   1318: getstatic g/j.AppCompatTextView_drawableTintMode : I
    //   1321: iconst_m1
    //   1322: invokevirtual k : (II)I
    //   1325: aconst_null
    //   1326: invokestatic d : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   1329: astore_1
    //   1330: aload_0
    //   1331: getfield a : Landroid/widget/TextView;
    //   1334: aload_1
    //   1335: invokestatic i : (Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V
    //   1338: goto -> 1341
    //   1341: aload #12
    //   1343: getstatic g/j.AppCompatTextView_firstBaselineToTopHeight : I
    //   1346: iconst_m1
    //   1347: invokevirtual f : (II)I
    //   1350: istore_2
    //   1351: aload #12
    //   1353: getstatic g/j.AppCompatTextView_lastBaselineToBottomHeight : I
    //   1356: iconst_m1
    //   1357: invokevirtual f : (II)I
    //   1360: istore_3
    //   1361: aload #12
    //   1363: getstatic g/j.AppCompatTextView_lineHeight : I
    //   1366: iconst_m1
    //   1367: invokevirtual f : (II)I
    //   1370: istore #4
    //   1372: aload #12
    //   1374: invokevirtual w : ()V
    //   1377: iload_2
    //   1378: iconst_m1
    //   1379: if_icmpeq -> 1390
    //   1382: aload_0
    //   1383: getfield a : Landroid/widget/TextView;
    //   1386: iload_2
    //   1387: invokestatic k : (Landroid/widget/TextView;I)V
    //   1390: iload_3
    //   1391: iconst_m1
    //   1392: if_icmpeq -> 1403
    //   1395: aload_0
    //   1396: getfield a : Landroid/widget/TextView;
    //   1399: iload_3
    //   1400: invokestatic l : (Landroid/widget/TextView;I)V
    //   1403: iload #4
    //   1405: iconst_m1
    //   1406: if_icmpeq -> 1418
    //   1409: aload_0
    //   1410: getfield a : Landroid/widget/TextView;
    //   1413: iload #4
    //   1415: invokestatic m : (Landroid/widget/TextView;I)V
    //   1418: return
  }
  
  void n(WeakReference<TextView> paramWeakReference, Typeface paramTypeface) {
    if (this.m) {
      this.l = paramTypeface;
      TextView textView = paramWeakReference.get();
      if (textView != null) {
        if (m0.V((View)textView)) {
          textView.post(new b(this, textView, paramTypeface, this.j));
          return;
        } 
        textView.setTypeface(paramTypeface, this.j);
      } 
    } 
  }
  
  void o(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!a1.b)
      c(); 
  }
  
  void p() {
    b();
  }
  
  void q(Context paramContext, int paramInt) {
    p0 p0 = p0.t(paramContext, paramInt, j.TextAppearance);
    if (p0.s(j.TextAppearance_textAllCaps))
      s(p0.a(j.TextAppearance_textAllCaps, false)); 
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 23) {
      if (p0.s(j.TextAppearance_android_textColor)) {
        ColorStateList colorStateList = p0.c(j.TextAppearance_android_textColor);
        if (colorStateList != null)
          this.a.setTextColor(colorStateList); 
      } 
      if (p0.s(j.TextAppearance_android_textColorLink)) {
        ColorStateList colorStateList = p0.c(j.TextAppearance_android_textColorLink);
        if (colorStateList != null)
          this.a.setLinkTextColor(colorStateList); 
      } 
      if (p0.s(j.TextAppearance_android_textColorHint)) {
        ColorStateList colorStateList = p0.c(j.TextAppearance_android_textColorHint);
        if (colorStateList != null)
          this.a.setHintTextColor(colorStateList); 
      } 
    } 
    if (p0.s(j.TextAppearance_android_textSize) && p0.f(j.TextAppearance_android_textSize, -1) == 0)
      this.a.setTextSize(0, 0.0F); 
    C(paramContext, p0);
    if (paramInt >= 26 && p0.s(j.TextAppearance_fontVariationSettings)) {
      String str = p0.o(j.TextAppearance_fontVariationSettings);
      if (str != null)
        f.d(this.a, str); 
    } 
    p0.w();
    Typeface typeface = this.l;
    if (typeface != null)
      this.a.setTypeface(typeface, this.j); 
  }
  
  void r(TextView paramTextView, InputConnection paramInputConnection, EditorInfo paramEditorInfo) {
    if (Build.VERSION.SDK_INT < 30 && paramInputConnection != null)
      w2.c.f(paramEditorInfo, paramTextView.getText()); 
  }
  
  void s(boolean paramBoolean) {
    this.a.setAllCaps(paramBoolean);
  }
  
  void t(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    this.i.p(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void u(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    this.i.q(paramArrayOfint, paramInt);
  }
  
  void v(int paramInt) {
    this.i.r(paramInt);
  }
  
  void w(ColorStateList paramColorStateList) {
    boolean bool;
    if (this.h == null)
      this.h = new n0(); 
    n0 n01 = this.h;
    n01.a = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    n01.d = bool;
    z();
  }
  
  void x(PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.h == null)
      this.h = new n0(); 
    n0 n01 = this.h;
    n01.b = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    n01.c = bool;
    z();
  }
  
  class a extends h.e {
    a(r this$0, int param1Int1, int param1Int2, WeakReference param1WeakReference) {}
    
    public void h(int param1Int) {}
    
    public void i(Typeface param1Typeface) {
      Typeface typeface = param1Typeface;
      if (Build.VERSION.SDK_INT >= 28) {
        int i = this.a;
        typeface = param1Typeface;
        if (i != -1) {
          boolean bool;
          if ((this.b & 0x2) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          typeface = r.g.a(param1Typeface, i, bool);
        } 
      } 
      this.d.n(this.c, typeface);
    }
  }
  
  class b implements Runnable {
    b(r this$0, TextView param1TextView, Typeface param1Typeface, int param1Int) {}
    
    public void run() {
      this.s0.setTypeface(this.t0, this.u0);
    }
  }
  
  static class c {
    static Drawable[] a(TextView param1TextView) {
      return param1TextView.getCompoundDrawablesRelative();
    }
    
    static void b(TextView param1TextView, Drawable param1Drawable1, Drawable param1Drawable2, Drawable param1Drawable3, Drawable param1Drawable4) {
      param1TextView.setCompoundDrawablesRelativeWithIntrinsicBounds(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
    
    static void c(TextView param1TextView, Locale param1Locale) {
      param1TextView.setTextLocale(param1Locale);
    }
  }
  
  static class d {
    static Locale a(String param1String) {
      return Locale.forLanguageTag(param1String);
    }
  }
  
  static class e {
    static LocaleList a(String param1String) {
      return LocaleList.forLanguageTags(param1String);
    }
    
    static void b(TextView param1TextView, LocaleList param1LocaleList) {
      param1TextView.setTextLocales(param1LocaleList);
    }
  }
  
  static class f {
    static int a(TextView param1TextView) {
      return param1TextView.getAutoSizeStepGranularity();
    }
    
    static void b(TextView param1TextView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1TextView.setAutoSizeTextTypeUniformWithConfiguration(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void c(TextView param1TextView, int[] param1ArrayOfint, int param1Int) {
      param1TextView.setAutoSizeTextTypeUniformWithPresetSizes(param1ArrayOfint, param1Int);
    }
    
    static boolean d(TextView param1TextView, String param1String) {
      return param1TextView.setFontVariationSettings(param1String);
    }
  }
  
  static class g {
    static Typeface a(Typeface param1Typeface, int param1Int, boolean param1Boolean) {
      return Typeface.create(param1Typeface, param1Int, param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */