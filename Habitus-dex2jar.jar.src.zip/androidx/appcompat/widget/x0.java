package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.m0;
import androidx.core.view.o0;

class x0 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  private static x0 C0;
  
  private static x0 D0;
  
  private boolean A0;
  
  private boolean B0;
  
  private final View s0;
  
  private final CharSequence t0;
  
  private final int u0;
  
  private final Runnable v0 = new v0(this);
  
  private final Runnable w0 = new w0(this);
  
  private int x0;
  
  private int y0;
  
  private y0 z0;
  
  private x0(View paramView, CharSequence paramCharSequence) {
    this.s0 = paramView;
    this.t0 = paramCharSequence;
    this.u0 = o0.d(ViewConfiguration.get(paramView.getContext()));
    c();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  private void b() {
    this.s0.removeCallbacks(this.v0);
  }
  
  private void c() {
    this.B0 = true;
  }
  
  private void f() {
    this.s0.postDelayed(this.v0, ViewConfiguration.getLongPressTimeout());
  }
  
  private static void g(x0 paramx0) {
    x0 x01 = C0;
    if (x01 != null)
      x01.b(); 
    C0 = paramx0;
    if (paramx0 != null)
      paramx0.f(); 
  }
  
  public static void h(View paramView, CharSequence paramCharSequence) {
    x0 x01;
    x0 x02 = C0;
    if (x02 != null && x02.s0 == paramView)
      g(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      x01 = D0;
      if (x01 != null && x01.s0 == paramView)
        x01.d(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new x0(paramView, (CharSequence)x01);
  }
  
  private boolean j(MotionEvent paramMotionEvent) {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if (this.B0 || Math.abs(i - this.x0) > this.u0 || Math.abs(j - this.y0) > this.u0) {
      this.x0 = i;
      this.y0 = j;
      this.B0 = false;
      return true;
    } 
    return false;
  }
  
  void d() {
    if (D0 == this) {
      D0 = null;
      y0 y01 = this.z0;
      if (y01 != null) {
        y01.c();
        this.z0 = null;
        c();
        this.s0.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (C0 == this)
      g(null); 
    this.s0.removeCallbacks(this.w0);
  }
  
  void i(boolean paramBoolean) {
    long l;
    if (!m0.V(this.s0))
      return; 
    g(null);
    x0 x01 = D0;
    if (x01 != null)
      x01.d(); 
    D0 = this;
    this.A0 = paramBoolean;
    y0 y01 = new y0(this.s0.getContext());
    this.z0 = y01;
    y01.e(this.s0, this.x0, this.y0, this.A0, this.t0);
    this.s0.addOnAttachStateChangeListener(this);
    if (this.A0) {
      l = 2500L;
    } else {
      long l1;
      if ((m0.O(this.s0) & 0x1) == 1) {
        l = ViewConfiguration.getLongPressTimeout();
        l1 = 3000L;
      } else {
        l = ViewConfiguration.getLongPressTimeout();
        l1 = 15000L;
      } 
      l = l1 - l;
    } 
    this.s0.removeCallbacks(this.w0);
    this.s0.postDelayed(this.w0, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.z0 != null && this.A0)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.s0.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      c();
      d();
      return false;
    } 
    if (this.s0.isEnabled() && this.z0 == null && j(paramMotionEvent))
      g(this); 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.x0 = paramView.getWidth() / 2;
    this.y0 = paramView.getHeight() / 2;
    i(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */