package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.view.menu.p;
import androidx.core.view.m0;

public class AppCompatSpinner extends Spinner {
  @SuppressLint({"ResourceType"})
  private static final int[] A0 = new int[] { 16843505 };
  
  private final d s0;
  
  private final Context t0;
  
  private b0 u0;
  
  private SpinnerAdapter v0;
  
  private final boolean w0;
  
  private j x0;
  
  int y0;
  
  final Rect z0;
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, g.a.spinnerStyle);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield z0 : Landroid/graphics/Rect;
    //   18: aload_0
    //   19: aload_0
    //   20: invokevirtual getContext : ()Landroid/content/Context;
    //   23: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   26: aload_1
    //   27: aload_2
    //   28: getstatic g/j.Spinner : [I
    //   31: iload_3
    //   32: iconst_0
    //   33: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/p0;
    //   36: astore #9
    //   38: aload_0
    //   39: new androidx/appcompat/widget/d
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Landroid/view/View;)V
    //   47: putfield s0 : Landroidx/appcompat/widget/d;
    //   50: aload #5
    //   52: ifnull -> 72
    //   55: aload_0
    //   56: new androidx/appcompat/view/d
    //   59: dup
    //   60: aload_1
    //   61: aload #5
    //   63: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/Resources$Theme;)V
    //   66: putfield t0 : Landroid/content/Context;
    //   69: goto -> 110
    //   72: aload #9
    //   74: getstatic g/j.Spinner_popupTheme : I
    //   77: iconst_0
    //   78: invokevirtual n : (II)I
    //   81: istore #6
    //   83: iload #6
    //   85: ifeq -> 105
    //   88: aload_0
    //   89: new androidx/appcompat/view/d
    //   92: dup
    //   93: aload_1
    //   94: iload #6
    //   96: invokespecial <init> : (Landroid/content/Context;I)V
    //   99: putfield t0 : Landroid/content/Context;
    //   102: goto -> 110
    //   105: aload_0
    //   106: aload_1
    //   107: putfield t0 : Landroid/content/Context;
    //   110: aconst_null
    //   111: astore #7
    //   113: iload #4
    //   115: istore #6
    //   117: iload #4
    //   119: iconst_m1
    //   120: if_icmpne -> 242
    //   123: aload_1
    //   124: aload_2
    //   125: getstatic androidx/appcompat/widget/AppCompatSpinner.A0 : [I
    //   128: iload_3
    //   129: iconst_0
    //   130: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   133: astore #5
    //   135: iload #4
    //   137: istore #6
    //   139: aload #5
    //   141: astore #8
    //   143: aload #5
    //   145: astore #7
    //   147: aload #5
    //   149: iconst_0
    //   150: invokevirtual hasValue : (I)Z
    //   153: ifeq -> 173
    //   156: aload #5
    //   158: astore #7
    //   160: aload #5
    //   162: iconst_0
    //   163: iconst_0
    //   164: invokevirtual getInt : (II)I
    //   167: istore #6
    //   169: aload #5
    //   171: astore #8
    //   173: aload #8
    //   175: invokevirtual recycle : ()V
    //   178: goto -> 242
    //   181: astore #8
    //   183: goto -> 195
    //   186: astore_1
    //   187: goto -> 230
    //   190: astore #8
    //   192: aconst_null
    //   193: astore #5
    //   195: aload #5
    //   197: astore #7
    //   199: ldc 'AppCompatSpinner'
    //   201: ldc 'Could not read android:spinnerMode'
    //   203: aload #8
    //   205: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   208: pop
    //   209: iload #4
    //   211: istore #6
    //   213: aload #5
    //   215: ifnull -> 242
    //   218: iload #4
    //   220: istore #6
    //   222: aload #5
    //   224: astore #8
    //   226: goto -> 173
    //   229: astore_1
    //   230: aload #7
    //   232: ifnull -> 240
    //   235: aload #7
    //   237: invokevirtual recycle : ()V
    //   240: aload_1
    //   241: athrow
    //   242: iload #6
    //   244: ifeq -> 356
    //   247: iload #6
    //   249: iconst_1
    //   250: if_icmpeq -> 256
    //   253: goto -> 387
    //   256: new androidx/appcompat/widget/AppCompatSpinner$h
    //   259: dup
    //   260: aload_0
    //   261: aload_0
    //   262: getfield t0 : Landroid/content/Context;
    //   265: aload_2
    //   266: iload_3
    //   267: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   270: astore #5
    //   272: aload_0
    //   273: getfield t0 : Landroid/content/Context;
    //   276: aload_2
    //   277: getstatic g/j.Spinner : [I
    //   280: iload_3
    //   281: iconst_0
    //   282: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/p0;
    //   285: astore #7
    //   287: aload_0
    //   288: aload #7
    //   290: getstatic g/j.Spinner_android_dropDownWidth : I
    //   293: bipush #-2
    //   295: invokevirtual m : (II)I
    //   298: putfield y0 : I
    //   301: aload #5
    //   303: aload #7
    //   305: getstatic g/j.Spinner_android_popupBackground : I
    //   308: invokevirtual g : (I)Landroid/graphics/drawable/Drawable;
    //   311: invokevirtual b : (Landroid/graphics/drawable/Drawable;)V
    //   314: aload #5
    //   316: aload #9
    //   318: getstatic g/j.Spinner_android_prompt : I
    //   321: invokevirtual o : (I)Ljava/lang/String;
    //   324: invokevirtual h : (Ljava/lang/CharSequence;)V
    //   327: aload #7
    //   329: invokevirtual w : ()V
    //   332: aload_0
    //   333: aload #5
    //   335: putfield x0 : Landroidx/appcompat/widget/AppCompatSpinner$j;
    //   338: aload_0
    //   339: new androidx/appcompat/widget/AppCompatSpinner$a
    //   342: dup
    //   343: aload_0
    //   344: aload_0
    //   345: aload #5
    //   347: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;Landroid/view/View;Landroidx/appcompat/widget/AppCompatSpinner$h;)V
    //   350: putfield u0 : Landroidx/appcompat/widget/b0;
    //   353: goto -> 387
    //   356: new androidx/appcompat/widget/AppCompatSpinner$f
    //   359: dup
    //   360: aload_0
    //   361: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;)V
    //   364: astore #5
    //   366: aload_0
    //   367: aload #5
    //   369: putfield x0 : Landroidx/appcompat/widget/AppCompatSpinner$j;
    //   372: aload #5
    //   374: aload #9
    //   376: getstatic g/j.Spinner_android_prompt : I
    //   379: invokevirtual o : (I)Ljava/lang/String;
    //   382: invokeinterface h : (Ljava/lang/CharSequence;)V
    //   387: aload #9
    //   389: getstatic g/j.Spinner_android_entries : I
    //   392: invokevirtual q : (I)[Ljava/lang/CharSequence;
    //   395: astore #5
    //   397: aload #5
    //   399: ifnull -> 427
    //   402: new android/widget/ArrayAdapter
    //   405: dup
    //   406: aload_1
    //   407: ldc 17367048
    //   409: aload #5
    //   411: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   414: astore_1
    //   415: aload_1
    //   416: getstatic g/g.support_simple_spinner_dropdown_item : I
    //   419: invokevirtual setDropDownViewResource : (I)V
    //   422: aload_0
    //   423: aload_1
    //   424: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   427: aload #9
    //   429: invokevirtual w : ()V
    //   432: aload_0
    //   433: iconst_1
    //   434: putfield w0 : Z
    //   437: aload_0
    //   438: getfield v0 : Landroid/widget/SpinnerAdapter;
    //   441: astore_1
    //   442: aload_1
    //   443: ifnull -> 456
    //   446: aload_0
    //   447: aload_1
    //   448: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   451: aload_0
    //   452: aconst_null
    //   453: putfield v0 : Landroid/widget/SpinnerAdapter;
    //   456: aload_0
    //   457: getfield s0 : Landroidx/appcompat/widget/d;
    //   460: aload_2
    //   461: iload_3
    //   462: invokevirtual e : (Landroid/util/AttributeSet;I)V
    //   465: return
    // Exception table:
    //   from	to	target	type
    //   123	135	190	java/lang/Exception
    //   123	135	186	finally
    //   147	156	181	java/lang/Exception
    //   147	156	229	finally
    //   160	169	181	java/lang/Exception
    //   160	169	229	finally
    //   199	209	229	finally
  }
  
  int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int m = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int i1 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i2 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int k = Math.max(0, i - 15 - i2 - i);
    View view = null;
    i = 0;
    while (k < i2) {
      int i4 = paramSpinnerAdapter.getItemViewType(k);
      int i3 = m;
      if (i4 != m) {
        view = null;
        i3 = i4;
      } 
      view = paramSpinnerAdapter.getView(k, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(n, i1);
      i = Math.max(i, view.getMeasuredWidth());
      k++;
      m = i3;
    } 
    k = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.z0);
      Rect rect = this.z0;
      k = i + rect.left + rect.right;
    } 
    return k;
  }
  
  void b() {
    this.x0.k(d.b((View)this), d.a((View)this));
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.s0;
    if (d1 != null)
      d1.b(); 
  }
  
  public int getDropDownHorizontalOffset() {
    j j1 = this.x0;
    return (j1 != null) ? j1.c() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    j j1 = this.x0;
    return (j1 != null) ? j1.l() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.x0 != null) ? this.y0 : super.getDropDownWidth();
  }
  
  final j getInternalPopup() {
    return this.x0;
  }
  
  public Drawable getPopupBackground() {
    j j1 = this.x0;
    return (j1 != null) ? j1.g() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.t0;
  }
  
  public CharSequence getPrompt() {
    j j1 = this.x0;
    return (j1 != null) ? j1.f() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.s0;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.s0;
    return (d1 != null) ? d1.d() : null;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    j j1 = this.x0;
    if (j1 != null && j1.a())
      this.x0.dismiss(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.x0 != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    i i = (i)paramParcelable;
    super.onRestoreInstanceState(i.getSuperState());
    if (i.s0) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new b(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    i i = new i(super.onSaveInstanceState());
    j j1 = this.x0;
    if (j1 != null && j1.a()) {
      bool = true;
    } else {
      bool = false;
    } 
    i.s0 = bool;
    return (Parcelable)i;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    b0 b01 = this.u0;
    return (b01 != null && b01.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    j j1 = this.x0;
    if (j1 != null) {
      if (!j1.a())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.w0) {
      this.v0 = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.x0 != null) {
      Context context2 = this.t0;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.x0.m(new g(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.s0;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.s0;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    j j1 = this.x0;
    if (j1 != null) {
      j1.j(paramInt);
      this.x0.e(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    j j1 = this.x0;
    if (j1 != null) {
      j1.i(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.x0 != null) {
      this.y0 = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    j j1 = this.x0;
    if (j1 != null) {
      j1.b(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(h.a.b(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    j j1 = this.x0;
    if (j1 != null) {
      j1.h(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.s0;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.s0;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  class a extends b0 {
    a(AppCompatSpinner this$0, View param1View, AppCompatSpinner.h param1h) {
      super(param1View);
    }
    
    public p b() {
      return this.B0;
    }
    
    @SuppressLint({"SyntheticAccessor"})
    public boolean c() {
      if (!this.C0.getInternalPopup().a())
        this.C0.b(); 
      return true;
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(AppCompatSpinner this$0) {}
    
    public void onGlobalLayout() {
      if (!this.s0.getInternalPopup().a())
        this.s0.b(); 
      ViewTreeObserver viewTreeObserver = this.s0.getViewTreeObserver();
      if (viewTreeObserver != null)
        AppCompatSpinner.c.a(viewTreeObserver, this); 
    }
  }
  
  private static final class c {
    static void a(ViewTreeObserver param1ViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {
      param1ViewTreeObserver.removeOnGlobalLayoutListener(param1OnGlobalLayoutListener);
    }
  }
  
  private static final class d {
    static int a(View param1View) {
      return param1View.getTextAlignment();
    }
    
    static int b(View param1View) {
      return param1View.getTextDirection();
    }
    
    static void c(View param1View, int param1Int) {
      param1View.setTextAlignment(param1Int);
    }
    
    static void d(View param1View, int param1Int) {
      param1View.setTextDirection(param1Int);
    }
  }
  
  private static final class e {
    static void a(ThemedSpinnerAdapter param1ThemedSpinnerAdapter, Resources.Theme param1Theme) {
      if (!androidx.core.util.c.a(param1ThemedSpinnerAdapter.getDropDownViewTheme(), param1Theme))
        param1ThemedSpinnerAdapter.setDropDownViewTheme(param1Theme); 
    }
  }
  
  class f implements j, DialogInterface.OnClickListener {
    androidx.appcompat.app.c s0;
    
    private ListAdapter t0;
    
    private CharSequence u0;
    
    f(AppCompatSpinner this$0) {}
    
    public boolean a() {
      androidx.appcompat.app.c c1 = this.s0;
      return (c1 != null) ? c1.isShowing() : false;
    }
    
    public void b(Drawable param1Drawable) {
      Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }
    
    public int c() {
      return 0;
    }
    
    public void dismiss() {
      androidx.appcompat.app.c c1 = this.s0;
      if (c1 != null) {
        c1.dismiss();
        this.s0 = null;
      } 
    }
    
    public void e(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }
    
    public CharSequence f() {
      return this.u0;
    }
    
    public Drawable g() {
      return null;
    }
    
    public void h(CharSequence param1CharSequence) {
      this.u0 = param1CharSequence;
    }
    
    public void i(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }
    
    public void j(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
    
    public void k(int param1Int1, int param1Int2) {
      if (this.t0 == null)
        return; 
      androidx.appcompat.app.c.a a = new androidx.appcompat.app.c.a(this.v0.getPopupContext());
      CharSequence charSequence = this.u0;
      if (charSequence != null)
        a.setTitle(charSequence); 
      androidx.appcompat.app.c c1 = a.i(this.t0, this.v0.getSelectedItemPosition(), this).create();
      this.s0 = c1;
      ListView listView = c1.c();
      AppCompatSpinner.d.d((View)listView, param1Int1);
      AppCompatSpinner.d.c((View)listView, param1Int2);
      this.s0.show();
    }
    
    public int l() {
      return 0;
    }
    
    public void m(ListAdapter param1ListAdapter) {
      this.t0 = param1ListAdapter;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.v0.setSelection(param1Int);
      if (this.v0.getOnItemClickListener() != null)
        this.v0.performItemClick(null, param1Int, this.t0.getItemId(param1Int)); 
      dismiss();
    }
  }
  
  private static class g implements ListAdapter, SpinnerAdapter {
    private SpinnerAdapter s0;
    
    private ListAdapter t0;
    
    public g(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.s0 = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.t0 = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        if (Build.VERSION.SDK_INT >= 23 && o.a(param1SpinnerAdapter)) {
          AppCompatSpinner.e.a(p.a(param1SpinnerAdapter), param1Theme);
          return;
        } 
        if (param1SpinnerAdapter instanceof l0) {
          param1SpinnerAdapter = param1SpinnerAdapter;
          if (param1SpinnerAdapter.getDropDownViewTheme() == null)
            param1SpinnerAdapter.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.t0;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.s0;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.s0;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.s0;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.s0;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.s0;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.t0;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.s0;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.s0;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  class h extends ListPopupWindow implements j {
    private CharSequence b1;
    
    ListAdapter c1;
    
    private final Rect d1 = new Rect();
    
    private int e1;
    
    public h(AppCompatSpinner this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
      C((View)this$0);
      I(true);
      O(0);
      K(new a(this, this$0));
    }
    
    void S() {
      int i;
      Drawable drawable = g();
      if (drawable != null) {
        drawable.getPadding(this.f1.z0);
        if (a1.b((View)this.f1)) {
          i = this.f1.z0.right;
        } else {
          i = -this.f1.z0.left;
        } 
      } else {
        Rect rect = this.f1.z0;
        rect.right = 0;
        rect.left = 0;
        i = 0;
      } 
      int m = this.f1.getPaddingLeft();
      int n = this.f1.getPaddingRight();
      int i1 = this.f1.getWidth();
      AppCompatSpinner appCompatSpinner = this.f1;
      int k = appCompatSpinner.y0;
      if (k == -2) {
        int i2 = appCompatSpinner.a((SpinnerAdapter)this.c1, g());
        k = (this.f1.getContext().getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.f1.z0;
        int i3 = k - rect.left - rect.right;
        k = i2;
        if (i2 > i3)
          k = i3; 
        E(Math.max(k, i1 - m - n));
      } else if (k == -1) {
        E(i1 - m - n);
      } else {
        E(k);
      } 
      if (a1.b((View)this.f1)) {
        i += i1 - n - y() - T();
      } else {
        i += m + T();
      } 
      e(i);
    }
    
    public int T() {
      return this.e1;
    }
    
    boolean U(View param1View) {
      return (m0.V(param1View) && param1View.getGlobalVisibleRect(this.d1));
    }
    
    public CharSequence f() {
      return this.b1;
    }
    
    public void h(CharSequence param1CharSequence) {
      this.b1 = param1CharSequence;
    }
    
    public void j(int param1Int) {
      this.e1 = param1Int;
    }
    
    public void k(int param1Int1, int param1Int2) {
      boolean bool = a();
      S();
      H(2);
      show();
      ListView listView = o();
      listView.setChoiceMode(1);
      AppCompatSpinner.d.d((View)listView, param1Int1);
      AppCompatSpinner.d.c((View)listView, param1Int2);
      P(this.f1.getSelectedItemPosition());
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.f1.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        J(new c(this, b));
      } 
    }
    
    public void m(ListAdapter param1ListAdapter) {
      super.m(param1ListAdapter);
      this.c1 = param1ListAdapter;
    }
    
    class a implements AdapterView.OnItemClickListener {
      a(AppCompatSpinner.h this$0, AppCompatSpinner param2AppCompatSpinner) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.t0.f1.setSelection(param2Int);
        if (this.t0.f1.getOnItemClickListener() != null) {
          AppCompatSpinner.h h1 = this.t0;
          h1.f1.performItemClick(param2View, param2Int, h1.c1.getItemId(param2Int));
        } 
        this.t0.dismiss();
      }
    }
    
    class b implements ViewTreeObserver.OnGlobalLayoutListener {
      b(AppCompatSpinner.h this$0) {}
      
      public void onGlobalLayout() {
        AppCompatSpinner.h h1 = this.s0;
        if (!h1.U((View)h1.f1)) {
          this.s0.dismiss();
          return;
        } 
        this.s0.S();
        AppCompatSpinner.h.R(this.s0);
      }
    }
    
    class c implements PopupWindow.OnDismissListener {
      c(AppCompatSpinner.h this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.t0.f1.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.s0); 
      }
    }
  }
  
  class a implements AdapterView.OnItemClickListener {
    a(AppCompatSpinner this$0, AppCompatSpinner param1AppCompatSpinner) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.t0.f1.setSelection(param1Int);
      if (this.t0.f1.getOnItemClickListener() != null) {
        AppCompatSpinner.h h1 = this.t0;
        h1.f1.performItemClick(param1View, param1Int, h1.c1.getItemId(param1Int));
      } 
      this.t0.dismiss();
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(AppCompatSpinner this$0) {}
    
    public void onGlobalLayout() {
      AppCompatSpinner.h h1 = this.s0;
      if (!h1.U((View)h1.f1)) {
        this.s0.dismiss();
        return;
      } 
      this.s0.S();
      AppCompatSpinner.h.R(this.s0);
    }
  }
  
  class c implements PopupWindow.OnDismissListener {
    c(AppCompatSpinner this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.t0.f1.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.s0); 
    }
  }
  
  static class i extends View.BaseSavedState {
    public static final Parcelable.Creator<i> CREATOR = new a();
    
    boolean s0;
    
    i(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.s0 = bool;
    }
    
    i(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.s0);
    }
    
    class a implements Parcelable.Creator<i> {
      public AppCompatSpinner.i a(Parcel param2Parcel) {
        return new AppCompatSpinner.i(param2Parcel);
      }
      
      public AppCompatSpinner.i[] b(int param2Int) {
        return new AppCompatSpinner.i[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<i> {
    public AppCompatSpinner.i a(Parcel param1Parcel) {
      return new AppCompatSpinner.i(param1Parcel);
    }
    
    public AppCompatSpinner.i[] b(int param1Int) {
      return new AppCompatSpinner.i[param1Int];
    }
  }
  
  static interface j {
    boolean a();
    
    void b(Drawable param1Drawable);
    
    int c();
    
    void dismiss();
    
    void e(int param1Int);
    
    CharSequence f();
    
    Drawable g();
    
    void h(CharSequence param1CharSequence);
    
    void i(int param1Int);
    
    void j(int param1Int);
    
    void k(int param1Int1, int param1Int2);
    
    int l();
    
    void m(ListAdapter param1ListAdapter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\AppCompatSpinner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */