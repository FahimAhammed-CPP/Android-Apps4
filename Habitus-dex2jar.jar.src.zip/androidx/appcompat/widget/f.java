package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import androidx.core.graphics.drawable.a;
import androidx.core.widget.c;

class f {
  private final CompoundButton a;
  
  private ColorStateList b = null;
  
  private PorterDuff.Mode c = null;
  
  private boolean d = false;
  
  private boolean e = false;
  
  private boolean f;
  
  f(CompoundButton paramCompoundButton) {
    this.a = paramCompoundButton;
  }
  
  void a() {
    Drawable drawable = c.a(this.a);
    if (drawable != null && (this.d || this.e)) {
      drawable = a.r(drawable).mutate();
      if (this.d)
        a.o(drawable, this.b); 
      if (this.e)
        a.p(drawable, this.c); 
      if (drawable.isStateful())
        drawable.setState(this.a.getDrawableState()); 
      this.a.setButtonDrawable(drawable);
    } 
  }
  
  int b(int paramInt) {
    return paramInt;
  }
  
  ColorStateList c() {
    return this.b;
  }
  
  PorterDuff.Mode d() {
    return this.c;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/CompoundButton;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: aload_1
    //   8: getstatic g/j.CompoundButton : [I
    //   11: iload_2
    //   12: iconst_0
    //   13: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/p0;
    //   16: astore_3
    //   17: aload_0
    //   18: getfield a : Landroid/widget/CompoundButton;
    //   21: astore #4
    //   23: aload #4
    //   25: aload #4
    //   27: invokevirtual getContext : ()Landroid/content/Context;
    //   30: getstatic g/j.CompoundButton : [I
    //   33: aload_1
    //   34: aload_3
    //   35: invokevirtual r : ()Landroid/content/res/TypedArray;
    //   38: iload_2
    //   39: iconst_0
    //   40: invokestatic q0 : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   43: aload_3
    //   44: getstatic g/j.CompoundButton_buttonCompat : I
    //   47: invokevirtual s : (I)Z
    //   50: ifeq -> 88
    //   53: aload_3
    //   54: getstatic g/j.CompoundButton_buttonCompat : I
    //   57: iconst_0
    //   58: invokevirtual n : (II)I
    //   61: istore_2
    //   62: iload_2
    //   63: ifeq -> 88
    //   66: aload_0
    //   67: getfield a : Landroid/widget/CompoundButton;
    //   70: astore_1
    //   71: aload_1
    //   72: aload_1
    //   73: invokevirtual getContext : ()Landroid/content/Context;
    //   76: iload_2
    //   77: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   80: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   83: iconst_1
    //   84: istore_2
    //   85: goto -> 90
    //   88: iconst_0
    //   89: istore_2
    //   90: iload_2
    //   91: ifne -> 134
    //   94: aload_3
    //   95: getstatic g/j.CompoundButton_android_button : I
    //   98: invokevirtual s : (I)Z
    //   101: ifeq -> 134
    //   104: aload_3
    //   105: getstatic g/j.CompoundButton_android_button : I
    //   108: iconst_0
    //   109: invokevirtual n : (II)I
    //   112: istore_2
    //   113: iload_2
    //   114: ifeq -> 134
    //   117: aload_0
    //   118: getfield a : Landroid/widget/CompoundButton;
    //   121: astore_1
    //   122: aload_1
    //   123: aload_1
    //   124: invokevirtual getContext : ()Landroid/content/Context;
    //   127: iload_2
    //   128: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   131: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   134: aload_3
    //   135: getstatic g/j.CompoundButton_buttonTint : I
    //   138: invokevirtual s : (I)Z
    //   141: ifeq -> 158
    //   144: aload_0
    //   145: getfield a : Landroid/widget/CompoundButton;
    //   148: aload_3
    //   149: getstatic g/j.CompoundButton_buttonTint : I
    //   152: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   155: invokestatic d : (Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V
    //   158: aload_3
    //   159: getstatic g/j.CompoundButton_buttonTintMode : I
    //   162: invokevirtual s : (I)Z
    //   165: ifeq -> 187
    //   168: aload_0
    //   169: getfield a : Landroid/widget/CompoundButton;
    //   172: aload_3
    //   173: getstatic g/j.CompoundButton_buttonTintMode : I
    //   176: iconst_m1
    //   177: invokevirtual k : (II)I
    //   180: aconst_null
    //   181: invokestatic d : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   184: invokestatic e : (Landroid/widget/CompoundButton;Landroid/graphics/PorterDuff$Mode;)V
    //   187: aload_3
    //   188: invokevirtual w : ()V
    //   191: return
    //   192: astore_1
    //   193: aload_3
    //   194: invokevirtual w : ()V
    //   197: aload_1
    //   198: athrow
    //   199: astore_1
    //   200: goto -> 88
    // Exception table:
    //   from	to	target	type
    //   43	62	192	finally
    //   66	83	199	android/content/res/Resources$NotFoundException
    //   66	83	192	finally
    //   94	113	192	finally
    //   117	134	192	finally
    //   134	158	192	finally
    //   158	187	192	finally
  }
  
  void f() {
    if (this.f) {
      this.f = false;
      return;
    } 
    this.f = true;
    a();
  }
  
  void g(ColorStateList paramColorStateList) {
    this.b = paramColorStateList;
    this.d = true;
    a();
  }
  
  void h(PorterDuff.Mode paramMode) {
    this.c = paramMode;
    this.e = true;
    a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */