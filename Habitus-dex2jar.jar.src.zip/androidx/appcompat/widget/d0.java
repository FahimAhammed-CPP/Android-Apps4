package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.view.menu.f;
import androidx.appcompat.view.menu.g;
import java.lang.reflect.Method;

public class d0 extends ListPopupWindow implements c0 {
  private static Method c1;
  
  private c0 b1;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        c1 = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public d0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void R(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      a.a(this.X0, (Transition)paramObject); 
  }
  
  public void S(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      a.b(this.X0, (Transition)paramObject); 
  }
  
  public void T(c0 paramc0) {
    this.b1 = paramc0;
  }
  
  public void U(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = c1;
      if (method != null)
        try {
          method.invoke(this.X0, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      b.a(this.X0, paramBoolean);
    } 
  }
  
  public void d(g paramg, MenuItem paramMenuItem) {
    c0 c01 = this.b1;
    if (c01 != null)
      c01.d(paramg, paramMenuItem); 
  }
  
  public void n(g paramg, MenuItem paramMenuItem) {
    c0 c01 = this.b1;
    if (c01 != null)
      c01.n(paramg, paramMenuItem); 
  }
  
  z r(Context paramContext, boolean paramBoolean) {
    c c = new c(paramContext, paramBoolean);
    c.setHoverListener(this);
    return c;
  }
  
  static class a {
    static void a(PopupWindow param1PopupWindow, Transition param1Transition) {
      param1PopupWindow.setEnterTransition(param1Transition);
    }
    
    static void b(PopupWindow param1PopupWindow, Transition param1Transition) {
      param1PopupWindow.setExitTransition(param1Transition);
    }
  }
  
  static class b {
    static void a(PopupWindow param1PopupWindow, boolean param1Boolean) {
      param1PopupWindow.setTouchModal(param1Boolean);
    }
  }
  
  public static class c extends z {
    final int F0;
    
    final int G0;
    
    private c0 H0;
    
    private MenuItem I0;
    
    public c(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      if (1 == a.a(param1Context.getResources().getConfiguration())) {
        this.F0 = 21;
        this.G0 = 22;
        return;
      } 
      this.F0 = 22;
      this.G0 = 21;
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_0
      //   1: getfield H0 : Landroidx/appcompat/widget/c0;
      //   4: ifnull -> 178
      //   7: aload_0
      //   8: invokevirtual getAdapter : ()Landroid/widget/ListAdapter;
      //   11: astore #4
      //   13: aload #4
      //   15: instanceof android/widget/HeaderViewListAdapter
      //   18: ifeq -> 47
      //   21: aload #4
      //   23: checkcast android/widget/HeaderViewListAdapter
      //   26: astore #4
      //   28: aload #4
      //   30: invokevirtual getHeadersCount : ()I
      //   33: istore_2
      //   34: aload #4
      //   36: invokevirtual getWrappedAdapter : ()Landroid/widget/ListAdapter;
      //   39: checkcast androidx/appcompat/view/menu/f
      //   42: astore #4
      //   44: goto -> 56
      //   47: aload #4
      //   49: checkcast androidx/appcompat/view/menu/f
      //   52: astore #4
      //   54: iconst_0
      //   55: istore_2
      //   56: aload_1
      //   57: invokevirtual getAction : ()I
      //   60: bipush #10
      //   62: if_icmpeq -> 113
      //   65: aload_0
      //   66: aload_1
      //   67: invokevirtual getX : ()F
      //   70: f2i
      //   71: aload_1
      //   72: invokevirtual getY : ()F
      //   75: f2i
      //   76: invokevirtual pointToPosition : (II)I
      //   79: istore_3
      //   80: iload_3
      //   81: iconst_m1
      //   82: if_icmpeq -> 113
      //   85: iload_3
      //   86: iload_2
      //   87: isub
      //   88: istore_2
      //   89: iload_2
      //   90: iflt -> 113
      //   93: iload_2
      //   94: aload #4
      //   96: invokevirtual getCount : ()I
      //   99: if_icmpge -> 113
      //   102: aload #4
      //   104: iload_2
      //   105: invokevirtual c : (I)Landroidx/appcompat/view/menu/i;
      //   108: astore #5
      //   110: goto -> 116
      //   113: aconst_null
      //   114: astore #5
      //   116: aload_0
      //   117: getfield I0 : Landroid/view/MenuItem;
      //   120: astore #6
      //   122: aload #6
      //   124: aload #5
      //   126: if_acmpeq -> 178
      //   129: aload #4
      //   131: invokevirtual b : ()Landroidx/appcompat/view/menu/g;
      //   134: astore #4
      //   136: aload #6
      //   138: ifnull -> 154
      //   141: aload_0
      //   142: getfield H0 : Landroidx/appcompat/widget/c0;
      //   145: aload #4
      //   147: aload #6
      //   149: invokeinterface n : (Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V
      //   154: aload_0
      //   155: aload #5
      //   157: putfield I0 : Landroid/view/MenuItem;
      //   160: aload #5
      //   162: ifnull -> 178
      //   165: aload_0
      //   166: getfield H0 : Landroidx/appcompat/widget/c0;
      //   169: aload #4
      //   171: aload #5
      //   173: invokeinterface d : (Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V
      //   178: aload_0
      //   179: aload_1
      //   180: invokespecial onHoverEvent : (Landroid/view/MotionEvent;)Z
      //   183: ireturn
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      f f;
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.F0) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.G0) {
        setSelection(-1);
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          f = (f)((HeaderViewListAdapter)listAdapter).getWrappedAdapter();
        } else {
          f = f;
        } 
        f.b().e(false);
        return true;
      } 
      return super.onKeyDown(param1Int, (KeyEvent)f);
    }
    
    public void setHoverListener(c0 param1c0) {
      this.H0 = param1c0;
    }
    
    static class a {
      static int a(Configuration param2Configuration) {
        return param2Configuration.getLayoutDirection();
      }
    }
  }
  
  static class a {
    static int a(Configuration param1Configuration) {
      return param1Configuration.getLayoutDirection();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */