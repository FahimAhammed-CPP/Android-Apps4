package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.g;

public interface c0 {
  void d(g paramg, MenuItem paramMenuItem);
  
  void n(g paramg, MenuItem paramMenuItem);
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */