package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.view.b;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.view.m0;
import androidx.core.view.u0;
import g.f;
import g.g;
import g.j;

public class ActionBarContextView extends a {
  private CharSequence A0;
  
  private CharSequence B0;
  
  private View C0;
  
  private View D0;
  
  private View E0;
  
  private LinearLayout F0;
  
  private TextView G0;
  
  private TextView H0;
  
  private int I0;
  
  private int J0;
  
  private boolean K0;
  
  private int L0;
  
  public ActionBarContextView(Context paramContext) {
    this(paramContext, null);
  }
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, g.a.actionModeStyle);
  }
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    p0 p0 = p0.v(paramContext, paramAttributeSet, j.ActionMode, paramInt, 0);
    m0.w0((View)this, p0.g(j.ActionMode_background));
    this.I0 = p0.n(j.ActionMode_titleTextStyle, 0);
    this.J0 = p0.n(j.ActionMode_subtitleTextStyle, 0);
    this.w0 = p0.m(j.ActionMode_height, 0);
    this.L0 = p0.n(j.ActionMode_closeItemLayout, g.abc_action_mode_close_item_material);
    p0.w();
  }
  
  private void i() {
    if (this.F0 == null) {
      LayoutInflater.from(getContext()).inflate(g.abc_action_bar_title_item, this);
      LinearLayout linearLayout1 = (LinearLayout)getChildAt(getChildCount() - 1);
      this.F0 = linearLayout1;
      this.G0 = (TextView)linearLayout1.findViewById(f.action_bar_title);
      this.H0 = (TextView)this.F0.findViewById(f.action_bar_subtitle);
      if (this.I0 != 0)
        this.G0.setTextAppearance(getContext(), this.I0); 
      if (this.J0 != 0)
        this.H0.setTextAppearance(getContext(), this.J0); 
    } 
    this.G0.setText(this.A0);
    this.H0.setText(this.B0);
    boolean bool1 = TextUtils.isEmpty(this.A0);
    int i = TextUtils.isEmpty(this.B0) ^ true;
    TextView textView = this.H0;
    boolean bool = false;
    if (i != 0) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    LinearLayout linearLayout = this.F0;
    byte b = bool;
    if ((bool1 ^ true) == 0)
      if (i != 0) {
        b = bool;
      } else {
        b = 8;
      }  
    linearLayout.setVisibility(b);
    if (this.F0.getParent() == null)
      addView((View)this.F0); 
  }
  
  public void g() {
    if (this.C0 == null)
      k(); 
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-1, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }
  
  public CharSequence getSubtitle() {
    return this.B0;
  }
  
  public CharSequence getTitle() {
    return this.A0;
  }
  
  public void h(b paramb) {
    View view = this.C0;
    if (view == null) {
      view = LayoutInflater.from(getContext()).inflate(this.L0, this, false);
      this.C0 = view;
      addView(view);
    } else if (view.getParent() == null) {
      addView(this.C0);
    } 
    view = this.C0.findViewById(f.action_mode_close_button);
    this.D0 = view;
    view.setOnClickListener(new a(this, paramb));
    g g = (g)paramb.e();
    c c = this.v0;
    if (c != null)
      c.A(); 
    c = new c(getContext());
    this.v0 = c;
    c.L(true);
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
    g.c((m)this.v0, this.t0);
    ActionMenuView actionMenuView = (ActionMenuView)this.v0.q(this);
    this.u0 = actionMenuView;
    m0.w0((View)actionMenuView, null);
    addView((View)this.u0, layoutParams);
  }
  
  public boolean j() {
    return this.K0;
  }
  
  public void k() {
    removeAllViews();
    this.E0 = null;
    this.u0 = null;
    this.v0 = null;
    View view = this.D0;
    if (view != null)
      view.setOnClickListener(null); 
  }
  
  public boolean l() {
    c c = this.v0;
    return (c != null) ? c.M() : false;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    c c = this.v0;
    if (c != null) {
      c.D();
      this.v0.E();
    } 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    paramBoolean = a1.b((View)this);
    if (paramBoolean) {
      i = paramInt3 - paramInt1 - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    View view2 = this.C0;
    paramInt2 = i;
    if (view2 != null) {
      paramInt2 = i;
      if (view2.getVisibility() != 8) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.C0.getLayoutParams();
        if (paramBoolean) {
          paramInt2 = marginLayoutParams.rightMargin;
        } else {
          paramInt2 = marginLayoutParams.leftMargin;
        } 
        if (paramBoolean) {
          paramInt4 = marginLayoutParams.leftMargin;
        } else {
          paramInt4 = marginLayoutParams.rightMargin;
        } 
        paramInt2 = a.d(i, paramInt2, paramBoolean);
        paramInt2 = a.d(paramInt2 + e(this.C0, paramInt2, j, k, paramBoolean), paramInt4, paramBoolean);
      } 
    } 
    LinearLayout linearLayout = this.F0;
    paramInt4 = paramInt2;
    if (linearLayout != null) {
      paramInt4 = paramInt2;
      if (this.E0 == null) {
        paramInt4 = paramInt2;
        if (linearLayout.getVisibility() != 8)
          paramInt4 = paramInt2 + e((View)this.F0, paramInt2, j, k, paramBoolean); 
      } 
    } 
    View view1 = this.E0;
    if (view1 != null)
      e(view1, paramInt4, j, k, paramBoolean); 
    if (paramBoolean) {
      paramInt1 = getPaddingLeft();
    } else {
      paramInt1 = paramInt3 - paramInt1 - getPaddingRight();
    } 
    ActionMenuView actionMenuView = this.u0;
    if (actionMenuView != null)
      e((View)actionMenuView, paramInt1, j, k, paramBoolean ^ true); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = 1073741824;
    if (i == 1073741824) {
      if (View.MeasureSpec.getMode(paramInt2) != 0) {
        int n = View.MeasureSpec.getSize(paramInt1);
        i = this.w0;
        if (i <= 0)
          i = View.MeasureSpec.getSize(paramInt2); 
        int i1 = getPaddingTop() + getPaddingBottom();
        paramInt1 = n - getPaddingLeft() - getPaddingRight();
        int m = i - i1;
        int k = View.MeasureSpec.makeMeasureSpec(m, -2147483648);
        View view2 = this.C0;
        boolean bool = false;
        paramInt2 = paramInt1;
        if (view2 != null) {
          paramInt1 = c(view2, paramInt1, k, 0);
          ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.C0.getLayoutParams();
          paramInt2 = paramInt1 - marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
        } 
        ActionMenuView actionMenuView = this.u0;
        paramInt1 = paramInt2;
        if (actionMenuView != null) {
          paramInt1 = paramInt2;
          if (actionMenuView.getParent() == this)
            paramInt1 = c((View)this.u0, paramInt2, k, 0); 
        } 
        LinearLayout linearLayout = this.F0;
        paramInt2 = paramInt1;
        if (linearLayout != null) {
          paramInt2 = paramInt1;
          if (this.E0 == null)
            if (this.K0) {
              paramInt2 = View.MeasureSpec.makeMeasureSpec(0, 0);
              this.F0.measure(paramInt2, k);
              int i2 = this.F0.getMeasuredWidth();
              if (i2 <= paramInt1) {
                k = 1;
              } else {
                k = 0;
              } 
              paramInt2 = paramInt1;
              if (k != 0)
                paramInt2 = paramInt1 - i2; 
              linearLayout = this.F0;
              if (k != 0) {
                paramInt1 = 0;
              } else {
                paramInt1 = 8;
              } 
              linearLayout.setVisibility(paramInt1);
            } else {
              paramInt2 = c((View)linearLayout, paramInt1, k, 0);
            }  
        } 
        View view1 = this.E0;
        if (view1 != null) {
          ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
          int i2 = layoutParams.width;
          if (i2 != -2) {
            paramInt1 = 1073741824;
          } else {
            paramInt1 = Integer.MIN_VALUE;
          } 
          k = paramInt2;
          if (i2 >= 0)
            k = Math.min(i2, paramInt2); 
          i2 = layoutParams.height;
          if (i2 != -2) {
            paramInt2 = j;
          } else {
            paramInt2 = Integer.MIN_VALUE;
          } 
          j = m;
          if (i2 >= 0)
            j = Math.min(i2, m); 
          this.E0.measure(View.MeasureSpec.makeMeasureSpec(k, paramInt1), View.MeasureSpec.makeMeasureSpec(j, paramInt2));
        } 
        if (this.w0 <= 0) {
          j = getChildCount();
          paramInt2 = 0;
          paramInt1 = bool;
          while (paramInt1 < j) {
            k = getChildAt(paramInt1).getMeasuredHeight() + i1;
            i = paramInt2;
            if (k > paramInt2)
              i = k; 
            paramInt1++;
            paramInt2 = i;
          } 
          setMeasuredDimension(n, paramInt2);
          return;
        } 
        setMeasuredDimension(n, i);
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getClass().getSimpleName());
      stringBuilder1.append(" can only be used with android:layout_height=\"wrap_content\"");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void setContentHeight(int paramInt) {
    this.w0 = paramInt;
  }
  
  public void setCustomView(View paramView) {
    View view = this.E0;
    if (view != null)
      removeView(view); 
    this.E0 = paramView;
    if (paramView != null) {
      LinearLayout linearLayout = this.F0;
      if (linearLayout != null) {
        removeView((View)linearLayout);
        this.F0 = null;
      } 
    } 
    if (paramView != null)
      addView(paramView); 
    requestLayout();
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.B0 = paramCharSequence;
    i();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.A0 = paramCharSequence;
    i();
    m0.v0((View)this, paramCharSequence);
  }
  
  public void setTitleOptional(boolean paramBoolean) {
    if (paramBoolean != this.K0)
      requestLayout(); 
    this.K0 = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  class a implements View.OnClickListener {
    a(ActionBarContextView this$0, b param1b) {}
    
    public void onClick(View param1View) {
      this.s0.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\ActionBarContextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */