package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import androidx.core.widget.n;
import g.a;
import h.a;

public class AppCompatMultiAutoCompleteTextView extends MultiAutoCompleteTextView implements n {
  private static final int[] v0 = new int[] { 16843126 };
  
  private final d s0;
  
  private final r t0;
  
  private final h u0;
  
  public AppCompatMultiAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.autoCompleteTextViewStyle);
  }
  
  public AppCompatMultiAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(m0.b(paramContext), paramAttributeSet, paramInt);
    k0.a((View)this, getContext());
    p0 p0 = p0.v(getContext(), paramAttributeSet, v0, paramInt, 0);
    if (p0.s(0))
      setDropDownBackgroundDrawable(p0.g(0)); 
    p0.w();
    d d1 = new d((View)this);
    this.s0 = d1;
    d1.e(paramAttributeSet, paramInt);
    r r1 = new r((TextView)this);
    this.t0 = r1;
    r1.m(paramAttributeSet, paramInt);
    r1.b();
    h h1 = new h((EditText)this);
    this.u0 = h1;
    h1.c(paramAttributeSet, paramInt);
    a(h1);
  }
  
  void a(h paramh) {
    KeyListener keyListener = getKeyListener();
    if (paramh.b(keyListener)) {
      boolean bool1 = isFocusable();
      boolean bool2 = isClickable();
      boolean bool3 = isLongClickable();
      int i = getInputType();
      KeyListener keyListener1 = paramh.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(i);
      setFocusable(bool1);
      setClickable(bool2);
      setLongClickable(bool3);
    } 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.s0;
    if (d1 != null)
      d1.b(); 
    r r1 = this.t0;
    if (r1 != null)
      r1.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.s0;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.s0;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.t0.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.t0.k();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = j.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
    return this.u0.d(inputConnection, paramEditorInfo);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.s0;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.s0;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.t0;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.t0;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(a.b(getContext(), paramInt));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.u0.e(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.u0.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.s0;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.s0;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.t0.w(paramColorStateList);
    this.t0.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.t0.x(paramMode);
    this.t0.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    r r1 = this.t0;
    if (r1 != null)
      r1.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\AppCompatMultiAutoCompleteTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */