package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.view.m0;
import g.j;

class d {
  private final View a;
  
  private final g b;
  
  private int c = -1;
  
  private n0 d;
  
  private n0 e;
  
  private n0 f;
  
  d(View paramView) {
    this.a = paramView;
    this.b = g.b();
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new n0(); 
    n0 n01 = this.f;
    n01.a();
    ColorStateList colorStateList = m0.u(this.a);
    if (colorStateList != null) {
      n01.d = true;
      n01.a = colorStateList;
    } 
    PorterDuff.Mode mode = m0.v(this.a);
    if (mode != null) {
      n01.c = true;
      n01.b = mode;
    } 
    if (n01.d || n01.c) {
      g.i(paramDrawable, n01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.d != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      n0 n01 = this.e;
      if (n01 != null) {
        g.i(drawable, n01, this.a.getDrawableState());
        return;
      } 
      n01 = this.d;
      if (n01 != null)
        g.i(drawable, n01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    n0 n01 = this.e;
    return (n01 != null) ? n01.a : null;
  }
  
  PorterDuff.Mode d() {
    n0 n01 = this.e;
    return (n01 != null) ? n01.b : null;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    p0 p0 = p0.v(this.a.getContext(), paramAttributeSet, j.ViewBackgroundHelper, paramInt, 0);
    View view = this.a;
    m0.q0(view, view.getContext(), j.ViewBackgroundHelper, paramAttributeSet, p0.r(), paramInt, 0);
    try {
      if (p0.s(j.ViewBackgroundHelper_android_background)) {
        this.c = p0.n(j.ViewBackgroundHelper_android_background, -1);
        ColorStateList colorStateList = this.b.f(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      if (p0.s(j.ViewBackgroundHelper_backgroundTint))
        m0.x0(this.a, p0.c(j.ViewBackgroundHelper_backgroundTint)); 
      if (p0.s(j.ViewBackgroundHelper_backgroundTintMode))
        m0.y0(this.a, y.d(p0.k(j.ViewBackgroundHelper_backgroundTintMode, -1), null)); 
      return;
    } finally {
      p0.w();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    g g1 = this.b;
    if (g1 != null) {
      ColorStateList colorStateList = g1.f(this.a.getContext(), paramInt);
    } else {
      g1 = null;
    } 
    h((ColorStateList)g1);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new n0(); 
      n0 n01 = this.d;
      n01.a = paramColorStateList;
      n01.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new n0(); 
    n0 n01 = this.e;
    n01.a = paramColorStateList;
    n01.d = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new n0(); 
    n0 n01 = this.e;
    n01.b = paramMode;
    n01.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */