package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.core.graphics.i;
import androidx.core.text.t;
import androidx.core.widget.j;
import androidx.core.widget.n;
import java.util.concurrent.Future;

public class AppCompatTextView extends TextView implements n {
  private final d mBackgroundTintHelper;
  
  private i mEmojiTextViewHelper;
  
  private boolean mIsSetTypefaceProcessing = false;
  
  private Future<t> mPrecomputedTextFuture;
  
  private a mSuperCaller = null;
  
  private final q mTextClassifierHelper;
  
  private final r mTextHelper;
  
  public AppCompatTextView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(m0.b(paramContext), paramAttributeSet, paramInt);
    k0.a((View)this, getContext());
    d d1 = new d((View)this);
    this.mBackgroundTintHelper = d1;
    d1.e(paramAttributeSet, paramInt);
    r r1 = new r(this);
    this.mTextHelper = r1;
    r1.m(paramAttributeSet, paramInt);
    r1.b();
    this.mTextClassifierHelper = new q(this);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private void consumeTextFutureAndSetBlocking() {
    Future<t> future = this.mPrecomputedTextFuture;
    if (future != null)
      try {
        this.mPrecomputedTextFuture = null;
        j.n(this, future.get());
        return;
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
        return;
      }  
  }
  
  private i getEmojiTextViewHelper() {
    if (this.mEmojiTextViewHelper == null)
      this.mEmojiTextViewHelper = new i(this); 
    return this.mEmojiTextViewHelper;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.b(); 
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (a1.b)
      return getSuperCaller().g(); 
    r r1 = this.mTextHelper;
    return (r1 != null) ? r1.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (a1.b)
      return getSuperCaller().d(); 
    r r1 = this.mTextHelper;
    return (r1 != null) ? r1.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (a1.b)
      return getSuperCaller().k(); 
    r r1 = this.mTextHelper;
    return (r1 != null) ? r1.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (a1.b)
      return getSuperCaller().e(); 
    r r1 = this.mTextHelper;
    return (r1 != null) ? r1.h() : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = a1.b;
    boolean bool = false;
    if (bool1) {
      if (getSuperCaller().c() == 1)
        bool = true; 
      return bool;
    } 
    r r1 = this.mTextHelper;
    return (r1 != null) ? r1.i() : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.q(super.getCustomSelectionActionModeCallback());
  }
  
  public int getFirstBaselineToTopHeight() {
    return j.b(this);
  }
  
  public int getLastBaselineToBottomHeight() {
    return j.c(this);
  }
  
  a getSuperCaller() {
    if (this.mSuperCaller == null) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 28) {
        this.mSuperCaller = new c(this);
      } else if (j >= 26) {
        this.mSuperCaller = new b(this);
      } 
    } 
    return this.mSuperCaller;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.mBackgroundTintHelper;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.mBackgroundTintHelper;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.mTextHelper.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.mTextHelper.k();
  }
  
  public CharSequence getText() {
    consumeTextFutureAndSetBlocking();
    return super.getText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      q q1 = this.mTextClassifierHelper;
      if (q1 != null)
        return q1.a(); 
    } 
    return getSuperCaller().f();
  }
  
  public t.a getTextMetricsParamsCompat() {
    return j.g(this);
  }
  
  public boolean isEmojiCompatEnabled() {
    return getEmojiTextViewHelper().b();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    this.mTextHelper.r(this, inputConnection, paramEditorInfo);
    return j.a(inputConnection, paramEditorInfo, (View)this);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    consumeTextFutureAndSetBlocking();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    r r1 = this.mTextHelper;
    if (r1 != null && !a1.b && r1.l()) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt1 != 0)
      this.mTextHelper.c(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    if (a1.b) {
      getSuperCaller().i(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.t(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    if (a1.b) {
      getSuperCaller().a(paramArrayOfint, paramInt);
      return;
    } 
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.u(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (a1.b) {
      getSuperCaller().l(paramInt);
      return;
    } 
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.v(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = h.a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = h.a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = h.a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = h.a.b(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = h.a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = h.a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = h.a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = h.a.b(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.r(this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      getSuperCaller().j(paramInt);
      return;
    } 
    j.k(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      getSuperCaller().b(paramInt);
      return;
    } 
    j.l(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    j.m(this, paramInt);
  }
  
  public void setPrecomputedText(t paramt) {
    j.n(this, paramt);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.mTextHelper.w(paramColorStateList);
    this.mTextHelper.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.mTextHelper.x(paramMode);
    this.mTextHelper.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      q q1 = this.mTextClassifierHelper;
      if (q1 != null) {
        q1.b(paramTextClassifier);
        return;
      } 
    } 
    getSuperCaller().h(paramTextClassifier);
  }
  
  public void setTextFuture(Future<t> paramFuture) {
    this.mPrecomputedTextFuture = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(t.a parama) {
    j.p(this, parama);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (a1.b) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    r r1 = this.mTextHelper;
    if (r1 != null)
      r1.A(paramInt, paramFloat); 
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt) {
    Typeface typeface;
    if (this.mIsSetTypefaceProcessing)
      return; 
    if (paramTypeface != null && paramInt > 0) {
      typeface = i.a(getContext(), paramTypeface, paramInt);
    } else {
      typeface = null;
    } 
    this.mIsSetTypefaceProcessing = true;
    if (typeface != null)
      paramTypeface = typeface; 
    try {
      super.setTypeface(paramTypeface, paramInt);
      return;
    } finally {
      this.mIsSetTypefaceProcessing = false;
    } 
  }
  
  private static interface a {
    void a(int[] param1ArrayOfint, int param1Int);
    
    void b(int param1Int);
    
    int c();
    
    int d();
    
    int[] e();
    
    TextClassifier f();
    
    int g();
    
    void h(TextClassifier param1TextClassifier);
    
    void i(int param1Int1, int param1Int2, int param1Int3, int param1Int4);
    
    void j(int param1Int);
    
    int k();
    
    void l(int param1Int);
  }
  
  class b implements a {
    b(AppCompatTextView this$0) {}
    
    public void a(int[] param1ArrayOfint, int param1Int) {
      this.a.setAutoSizeTextTypeUniformWithPresetSizes(param1ArrayOfint, param1Int);
    }
    
    public void b(int param1Int) {}
    
    public int c() {
      return this.a.getAutoSizeTextType();
    }
    
    public int d() {
      return this.a.getAutoSizeMinTextSize();
    }
    
    public int[] e() {
      return this.a.getAutoSizeTextAvailableSizes();
    }
    
    public TextClassifier f() {
      return this.a.getTextClassifier();
    }
    
    public int g() {
      return this.a.getAutoSizeMaxTextSize();
    }
    
    public void h(TextClassifier param1TextClassifier) {
      this.a.setTextClassifier(param1TextClassifier);
    }
    
    public void i(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.a.setAutoSizeTextTypeUniformWithConfiguration(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void j(int param1Int) {}
    
    public int k() {
      return this.a.getAutoSizeStepGranularity();
    }
    
    public void l(int param1Int) {
      this.a.setAutoSizeTextTypeWithDefaults(param1Int);
    }
  }
  
  class c extends b {
    c(AppCompatTextView this$0) {
      super(this$0);
    }
    
    public void b(int param1Int) {
      this.b.setLastBaselineToBottomHeight(param1Int);
    }
    
    public void j(int param1Int) {
      this.b.setFirstBaselineToTopHeight(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */