package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import g.a;

public class AppCompatImageButton extends ImageButton {
  private final d s0;
  
  private final k t0;
  
  private boolean u0 = false;
  
  public AppCompatImageButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.imageButtonStyle);
  }
  
  public AppCompatImageButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(m0.b(paramContext), paramAttributeSet, paramInt);
    k0.a((View)this, getContext());
    d d1 = new d((View)this);
    this.s0 = d1;
    d1.e(paramAttributeSet, paramInt);
    k k1 = new k((ImageView)this);
    this.t0 = k1;
    k1.g(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.s0;
    if (d1 != null)
      d1.b(); 
    k k1 = this.t0;
    if (k1 != null)
      k1.c(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.s0;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.s0;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    k k1 = this.t0;
    return (k1 != null) ? k1.d() : null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    k k1 = this.t0;
    return (k1 != null) ? k1.e() : null;
  }
  
  public boolean hasOverlappingRendering() {
    return (this.t0.f() && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.s0;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.s0;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    k k1 = this.t0;
    if (k1 != null)
      k1.c(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    k k2 = this.t0;
    if (k2 != null && paramDrawable != null && !this.u0)
      k2.h(paramDrawable); 
    super.setImageDrawable(paramDrawable);
    k k1 = this.t0;
    if (k1 != null) {
      k1.c();
      if (!this.u0)
        this.t0.b(); 
    } 
  }
  
  public void setImageLevel(int paramInt) {
    super.setImageLevel(paramInt);
    this.u0 = true;
  }
  
  public void setImageResource(int paramInt) {
    this.t0.i(paramInt);
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    k k1 = this.t0;
    if (k1 != null)
      k1.c(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.s0;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.s0;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    k k1 = this.t0;
    if (k1 != null)
      k1.j(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    k k1 = this.t0;
    if (k1 != null)
      k1.k(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\AppCompatImageButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */