package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.p;
import androidx.core.view.m0;
import g.j;
import java.lang.reflect.Method;

public class ListPopupWindow implements p {
  private static Method Y0;
  
  private static Method Z0;
  
  private static Method a1;
  
  private boolean A0;
  
  private boolean B0;
  
  private boolean C0;
  
  private int D0 = 0;
  
  private boolean E0 = false;
  
  private boolean F0 = false;
  
  int G0 = Integer.MAX_VALUE;
  
  private View H0;
  
  private int I0 = 0;
  
  private DataSetObserver J0;
  
  private View K0;
  
  private Drawable L0;
  
  private AdapterView.OnItemClickListener M0;
  
  private AdapterView.OnItemSelectedListener N0;
  
  final i O0 = new i(this);
  
  private final h P0 = new h(this);
  
  private final g Q0 = new g(this);
  
  private final e R0 = new e(this);
  
  private Runnable S0;
  
  final Handler T0;
  
  private final Rect U0 = new Rect();
  
  private Rect V0;
  
  private boolean W0;
  
  PopupWindow X0;
  
  private Context s0;
  
  private ListAdapter t0;
  
  z u0;
  
  private int v0 = -2;
  
  private int w0 = -2;
  
  private int x0;
  
  private int y0;
  
  private int z0 = 1002;
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        Y0 = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      } 
      try {
        a1 = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      } 
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        Z0 = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }  
  }
  
  public ListPopupWindow(Context paramContext) {
    this(paramContext, null, g.a.listPopupWindowStyle);
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.s0 = paramContext;
    this.T0 = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.ListPopupWindow, paramInt1, paramInt2);
    this.x0 = typedArray.getDimensionPixelOffset(j.ListPopupWindow_android_dropDownHorizontalOffset, 0);
    int j = typedArray.getDimensionPixelOffset(j.ListPopupWindow_android_dropDownVerticalOffset, 0);
    this.y0 = j;
    if (j != 0)
      this.A0 = true; 
    typedArray.recycle();
    AppCompatPopupWindow appCompatPopupWindow = new AppCompatPopupWindow(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.X0 = appCompatPopupWindow;
    appCompatPopupWindow.setInputMethodMode(1);
  }
  
  private void B() {
    View view = this.H0;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.H0); 
    } 
  }
  
  private void N(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = Y0;
      if (method != null)
        try {
          method.invoke(this.X0, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      d.b(this.X0, paramBoolean);
    } 
  }
  
  private int p() {
    byte b1;
    byte b2;
    z z1 = this.u0;
    boolean bool = true;
    if (z1 == null) {
      LinearLayout.LayoutParams layoutParams1;
      LinearLayout.LayoutParams layoutParams2;
      Context context = this.s0;
      this.S0 = new a(this);
      z z3 = r(context, this.W0 ^ true);
      this.u0 = z3;
      Drawable drawable1 = this.L0;
      if (drawable1 != null)
        z3.setSelector(drawable1); 
      this.u0.setAdapter(this.t0);
      this.u0.setOnItemClickListener(this.M0);
      this.u0.setFocusable(true);
      this.u0.setFocusableInTouchMode(true);
      this.u0.setOnItemSelectedListener(new b(this));
      this.u0.setOnScrollListener(this.Q0);
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.N0;
      if (onItemSelectedListener != null)
        this.u0.setOnItemSelectedListener(onItemSelectedListener); 
      z z2 = this.u0;
      View view = this.H0;
      if (view != null) {
        boolean bool1;
        StringBuilder stringBuilder;
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        b1 = this.I0;
        if (b1 != 0) {
          if (b1 != 1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid hint position ");
            stringBuilder.append(this.I0);
            Log.e("ListPopupWindow", stringBuilder.toString());
          } else {
            linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
            linearLayout.addView(view);
          } 
        } else {
          linearLayout.addView(view);
          linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
        } 
        b1 = this.w0;
        if (b1 >= 0) {
          bool1 = true;
        } else {
          b1 = 0;
          bool1 = false;
        } 
        view.measure(View.MeasureSpec.makeMeasureSpec(b1, bool1), 0);
        layoutParams2 = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
      } else {
        b1 = 0;
        layoutParams1 = layoutParams2;
      } 
      this.X0.setContentView((View)layoutParams1);
    } else {
      ViewGroup viewGroup = (ViewGroup)this.X0.getContentView();
      View view = this.H0;
      if (view != null) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } else {
        b1 = 0;
      } 
    } 
    Drawable drawable = this.X0.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.U0);
      Rect rect = this.U0;
      int n = rect.top;
      int m = rect.bottom + n;
      b2 = m;
      if (!this.A0) {
        this.y0 = -n;
        b2 = m;
      } 
    } else {
      this.U0.setEmpty();
      b2 = 0;
    } 
    if (this.X0.getInputMethodMode() != 2)
      bool = false; 
    int k = t(s(), this.y0, bool);
    if (this.E0 || this.v0 == -1)
      return k + b2; 
    int j = this.w0;
    if (j != -2) {
      if (j != -1) {
        j = View.MeasureSpec.makeMeasureSpec(j, 1073741824);
      } else {
        j = (this.s0.getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.U0;
        j = View.MeasureSpec.makeMeasureSpec(j - rect.left + rect.right, 1073741824);
      } 
    } else {
      j = (this.s0.getResources().getDisplayMetrics()).widthPixels;
      Rect rect = this.U0;
      j = View.MeasureSpec.makeMeasureSpec(j - rect.left + rect.right, -2147483648);
    } 
    k = this.u0.d(j, 0, -1, k - b1, -1);
    j = b1;
    if (k > 0)
      j = b1 + b2 + this.u0.getPaddingTop() + this.u0.getPaddingBottom(); 
    return k + j;
  }
  
  private int t(View paramView, int paramInt, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 23) {
      Method method = Z0;
      if (method != null)
        try {
          return ((Integer)method.invoke(this.X0, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
        }  
      return this.X0.getMaxAvailableHeight(paramView, paramInt);
    } 
    return c.a(this.X0, paramView, paramInt, paramBoolean);
  }
  
  public boolean A() {
    return this.W0;
  }
  
  public void C(View paramView) {
    this.K0 = paramView;
  }
  
  public void D(int paramInt) {
    this.X0.setAnimationStyle(paramInt);
  }
  
  public void E(int paramInt) {
    Drawable drawable = this.X0.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.U0);
      Rect rect = this.U0;
      this.w0 = rect.left + rect.right + paramInt;
      return;
    } 
    Q(paramInt);
  }
  
  public void F(int paramInt) {
    this.D0 = paramInt;
  }
  
  public void G(Rect paramRect) {
    if (paramRect != null) {
      paramRect = new Rect(paramRect);
    } else {
      paramRect = null;
    } 
    this.V0 = paramRect;
  }
  
  public void H(int paramInt) {
    this.X0.setInputMethodMode(paramInt);
  }
  
  public void I(boolean paramBoolean) {
    this.W0 = paramBoolean;
    this.X0.setFocusable(paramBoolean);
  }
  
  public void J(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.X0.setOnDismissListener(paramOnDismissListener);
  }
  
  public void K(AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.M0 = paramOnItemClickListener;
  }
  
  public void L(AdapterView.OnItemSelectedListener paramOnItemSelectedListener) {
    this.N0 = paramOnItemSelectedListener;
  }
  
  public void M(boolean paramBoolean) {
    this.C0 = true;
    this.B0 = paramBoolean;
  }
  
  public void O(int paramInt) {
    this.I0 = paramInt;
  }
  
  public void P(int paramInt) {
    z z1 = this.u0;
    if (a() && z1 != null) {
      z1.setListSelectionHidden(false);
      z1.setSelection(paramInt);
      if (z1.getChoiceMode() != 0)
        z1.setItemChecked(paramInt, true); 
    } 
  }
  
  public void Q(int paramInt) {
    this.w0 = paramInt;
  }
  
  public boolean a() {
    return this.X0.isShowing();
  }
  
  public void b(Drawable paramDrawable) {
    this.X0.setBackgroundDrawable(paramDrawable);
  }
  
  public int c() {
    return this.x0;
  }
  
  public void dismiss() {
    this.X0.dismiss();
    B();
    this.X0.setContentView(null);
    this.u0 = null;
    this.T0.removeCallbacks(this.O0);
  }
  
  public void e(int paramInt) {
    this.x0 = paramInt;
  }
  
  public Drawable g() {
    return this.X0.getBackground();
  }
  
  public void i(int paramInt) {
    this.y0 = paramInt;
    this.A0 = true;
  }
  
  public int l() {
    return !this.A0 ? 0 : this.y0;
  }
  
  public void m(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.J0;
    if (dataSetObserver == null) {
      this.J0 = new f(this);
    } else {
      ListAdapter listAdapter = this.t0;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.t0 = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.J0); 
    z z1 = this.u0;
    if (z1 != null)
      z1.setAdapter(this.t0); 
  }
  
  public ListView o() {
    return this.u0;
  }
  
  public void q() {
    z z1 = this.u0;
    if (z1 != null) {
      z1.setListSelectionHidden(true);
      z1.requestLayout();
    } 
  }
  
  z r(Context paramContext, boolean paramBoolean) {
    return new z(paramContext, paramBoolean);
  }
  
  public View s() {
    return this.K0;
  }
  
  public void show() {
    int j;
    int k = p();
    boolean bool1 = z();
    androidx.core.widget.h.b(this.X0, this.z0);
    boolean bool2 = this.X0.isShowing();
    boolean bool = true;
    if (bool2) {
      if (!m0.V(s()))
        return; 
      int n = this.w0;
      if (n == -1) {
        j = -1;
      } else {
        j = n;
        if (n == -2)
          j = s().getWidth(); 
      } 
      n = this.v0;
      if (n == -1) {
        if (!bool1)
          k = -1; 
        if (bool1) {
          PopupWindow popupWindow2 = this.X0;
          if (this.w0 == -1) {
            n = -1;
          } else {
            n = 0;
          } 
          popupWindow2.setWidth(n);
          this.X0.setHeight(0);
        } else {
          PopupWindow popupWindow2 = this.X0;
          if (this.w0 == -1) {
            n = -1;
          } else {
            n = 0;
          } 
          popupWindow2.setWidth(n);
          this.X0.setHeight(-1);
        } 
      } else if (n != -2) {
        k = n;
      } 
      PopupWindow popupWindow1 = this.X0;
      if (this.F0 || this.E0)
        bool = false; 
      popupWindow1.setOutsideTouchable(bool);
      popupWindow1 = this.X0;
      View view = s();
      n = this.x0;
      int i1 = this.y0;
      if (j < 0)
        j = -1; 
      if (k < 0)
        k = -1; 
      popupWindow1.update(view, n, i1, j, k);
      return;
    } 
    int m = this.w0;
    if (m == -1) {
      j = -1;
    } else {
      j = m;
      if (m == -2)
        j = s().getWidth(); 
    } 
    m = this.v0;
    if (m == -1) {
      k = -1;
    } else if (m != -2) {
      k = m;
    } 
    this.X0.setWidth(j);
    this.X0.setHeight(k);
    N(true);
    PopupWindow popupWindow = this.X0;
    if (!this.F0 && !this.E0) {
      bool = true;
    } else {
      bool = false;
    } 
    popupWindow.setOutsideTouchable(bool);
    this.X0.setTouchInterceptor(this.P0);
    if (this.C0)
      androidx.core.widget.h.a(this.X0, this.B0); 
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = a1;
      if (method != null)
        try {
          method.invoke(this.X0, new Object[] { this.V0 });
        } catch (Exception exception) {
          Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", exception);
        }  
    } else {
      d.a(this.X0, this.V0);
    } 
    androidx.core.widget.h.c(this.X0, s(), this.x0, this.y0, this.D0);
    this.u0.setSelection(-1);
    if (!this.W0 || this.u0.isInTouchMode())
      q(); 
    if (!this.W0)
      this.T0.post(this.R0); 
  }
  
  public Object u() {
    return !a() ? null : this.u0.getSelectedItem();
  }
  
  public long v() {
    return !a() ? Long.MIN_VALUE : this.u0.getSelectedItemId();
  }
  
  public int w() {
    return !a() ? -1 : this.u0.getSelectedItemPosition();
  }
  
  public View x() {
    return !a() ? null : this.u0.getSelectedView();
  }
  
  public int y() {
    return this.w0;
  }
  
  public boolean z() {
    return (this.X0.getInputMethodMode() == 2);
  }
  
  class a implements Runnable {
    a(ListPopupWindow this$0) {}
    
    public void run() {
      View view = this.s0.s();
      if (view != null && view.getWindowToken() != null)
        this.s0.show(); 
    }
  }
  
  class b implements AdapterView.OnItemSelectedListener {
    b(ListPopupWindow this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int != -1) {
        z z = this.s0.u0;
        if (z != null)
          z.setListSelectionHidden(false); 
      } 
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  static class c {
    static int a(PopupWindow param1PopupWindow, View param1View, int param1Int, boolean param1Boolean) {
      return param1PopupWindow.getMaxAvailableHeight(param1View, param1Int, param1Boolean);
    }
  }
  
  static class d {
    static void a(PopupWindow param1PopupWindow, Rect param1Rect) {
      param1PopupWindow.setEpicenterBounds(param1Rect);
    }
    
    static void b(PopupWindow param1PopupWindow, boolean param1Boolean) {
      param1PopupWindow.setIsClippedToScreen(param1Boolean);
    }
  }
  
  private class e implements Runnable {
    e(ListPopupWindow this$0) {}
    
    public void run() {
      this.s0.q();
    }
  }
  
  private class f extends DataSetObserver {
    f(ListPopupWindow this$0) {}
    
    public void onChanged() {
      if (this.a.a())
        this.a.show(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  private class g implements AbsListView.OnScrollListener {
    g(ListPopupWindow this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !this.a.z() && this.a.X0.getContentView() != null) {
        ListPopupWindow listPopupWindow = this.a;
        listPopupWindow.T0.removeCallbacks(listPopupWindow.O0);
        this.a.O0.run();
      } 
    }
  }
  
  private class h implements View.OnTouchListener {
    h(ListPopupWindow this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.s0.X0;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.s0.X0.getWidth() && k >= 0 && k < this.s0.X0.getHeight()) {
          ListPopupWindow listPopupWindow = this.s0;
          listPopupWindow.T0.postDelayed(listPopupWindow.O0, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        ListPopupWindow listPopupWindow = this.s0;
        listPopupWindow.T0.removeCallbacks(listPopupWindow.O0);
      } 
      return false;
    }
  }
  
  private class i implements Runnable {
    i(ListPopupWindow this$0) {}
    
    public void run() {
      z z = this.s0.u0;
      if (z != null && m0.V((View)z) && this.s0.u0.getCount() > this.s0.u0.getChildCount()) {
        int j = this.s0.u0.getChildCount();
        ListPopupWindow listPopupWindow = this.s0;
        if (j <= listPopupWindow.G0) {
          listPopupWindow.X0.setInputMethodMode(2);
          this.s0.show();
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\ListPopupWindow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */