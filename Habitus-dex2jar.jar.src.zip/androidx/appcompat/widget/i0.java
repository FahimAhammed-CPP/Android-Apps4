package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class i0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  private static final Interpolator B0 = (Interpolator)new DecelerateInterpolator();
  
  private int A0;
  
  Runnable s0;
  
  private c t0;
  
  LinearLayoutCompat u0;
  
  private Spinner v0;
  
  private boolean w0;
  
  int x0;
  
  int y0;
  
  private int z0;
  
  private Spinner b() {
    AppCompatSpinner appCompatSpinner = new AppCompatSpinner(getContext(), null, g.a.actionDropDownStyle);
    appCompatSpinner.setLayoutParams((ViewGroup.LayoutParams)new LinearLayoutCompat.a(-2, -1));
    appCompatSpinner.setOnItemSelectedListener(this);
    return appCompatSpinner;
  }
  
  private boolean d() {
    Spinner spinner = this.v0;
    return (spinner != null && spinner.getParent() == this);
  }
  
  private void e() {
    if (d())
      return; 
    if (this.v0 == null)
      this.v0 = b(); 
    removeView((View)this.u0);
    addView((View)this.v0, new ViewGroup.LayoutParams(-2, -1));
    if (this.v0.getAdapter() == null)
      this.v0.setAdapter((SpinnerAdapter)new b(this)); 
    Runnable runnable = this.s0;
    if (runnable != null) {
      removeCallbacks(runnable);
      this.s0 = null;
    } 
    this.v0.setSelection(this.A0);
  }
  
  private boolean f() {
    if (!d())
      return false; 
    removeView((View)this.v0);
    addView((View)this.u0, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.v0.getSelectedItemPosition());
    return false;
  }
  
  public void a(int paramInt) {
    View view = this.u0.getChildAt(paramInt);
    Runnable runnable = this.s0;
    if (runnable != null)
      removeCallbacks(runnable); 
    a a = new a(this, view);
    this.s0 = a;
    post(a);
  }
  
  d c(androidx.appcompat.app.a.c paramc, boolean paramBoolean) {
    d d = new d(this, getContext(), paramc, paramBoolean);
    if (paramBoolean) {
      d.setBackgroundDrawable(null);
      d.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, this.z0));
      return d;
    } 
    d.setFocusable(true);
    if (this.t0 == null)
      this.t0 = new c(this); 
    d.setOnClickListener(this.t0);
    return d;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Runnable runnable = this.s0;
    if (runnable != null)
      post(runnable); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    androidx.appcompat.view.a a = androidx.appcompat.view.a.b(getContext());
    setContentHeight(a.f());
    this.y0 = a.e();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Runnable runnable = this.s0;
    if (runnable != null)
      removeCallbacks(runnable); 
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((d)paramView).b().e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt2 = 1;
    if (i == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    setFillViewport(bool);
    int j = this.u0.getChildCount();
    if (j > 1 && (i == 1073741824 || i == Integer.MIN_VALUE)) {
      if (j > 2) {
        this.x0 = (int)(View.MeasureSpec.getSize(paramInt1) * 0.4F);
      } else {
        this.x0 = View.MeasureSpec.getSize(paramInt1) / 2;
      } 
      this.x0 = Math.min(this.x0, this.y0);
    } else {
      this.x0 = -1;
    } 
    i = View.MeasureSpec.makeMeasureSpec(this.z0, 1073741824);
    if (bool || !this.w0)
      paramInt2 = 0; 
    if (paramInt2 != 0) {
      this.u0.measure(0, i);
      if (this.u0.getMeasuredWidth() > View.MeasureSpec.getSize(paramInt1)) {
        e();
      } else {
        f();
      } 
    } else {
      f();
    } 
    paramInt2 = getMeasuredWidth();
    super.onMeasure(paramInt1, i);
    paramInt1 = getMeasuredWidth();
    if (bool && paramInt2 != paramInt1)
      setTabSelected(this.A0); 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void setAllowCollapse(boolean paramBoolean) {
    this.w0 = paramBoolean;
  }
  
  public void setContentHeight(int paramInt) {
    this.z0 = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.A0 = paramInt;
    int j = this.u0.getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool;
      View view = this.u0.getChildAt(i);
      if (i == paramInt) {
        bool = true;
      } else {
        bool = false;
      } 
      view.setSelected(bool);
      if (bool)
        a(paramInt); 
    } 
    Spinner spinner = this.v0;
    if (spinner != null && paramInt >= 0)
      spinner.setSelection(paramInt); 
  }
  
  class a implements Runnable {
    a(i0 this$0, View param1View) {}
    
    public void run() {
      int i = this.s0.getLeft();
      int j = (this.t0.getWidth() - this.s0.getWidth()) / 2;
      this.t0.smoothScrollTo(i - j, 0);
      this.t0.s0 = null;
    }
  }
  
  private class b extends BaseAdapter {
    b(i0 this$0) {}
    
    public int getCount() {
      return this.s0.u0.getChildCount();
    }
    
    public Object getItem(int param1Int) {
      return ((i0.d)this.s0.u0.getChildAt(param1Int)).b();
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null)
        return (View)this.s0.c((androidx.appcompat.app.a.c)getItem(param1Int), true); 
      ((i0.d)param1View).a((androidx.appcompat.app.a.c)getItem(param1Int));
      return param1View;
    }
  }
  
  private class c implements View.OnClickListener {
    c(i0 this$0) {}
    
    public void onClick(View param1View) {
      ((i0.d)param1View).b().e();
      int j = this.s0.u0.getChildCount();
      for (int i = 0; i < j; i++) {
        boolean bool;
        View view = this.s0.u0.getChildAt(i);
        if (view == param1View) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      } 
    }
  }
  
  private class d extends LinearLayout {
    private final int[] s0;
    
    private androidx.appcompat.app.a.c t0;
    
    private TextView u0;
    
    private ImageView v0;
    
    private View w0;
    
    public d(i0 this$0, Context param1Context, androidx.appcompat.app.a.c param1c, boolean param1Boolean) {
      super(param1Context, null, g.a.actionBarTabStyle);
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = 16842964;
      this.s0 = arrayOfInt;
      this.t0 = param1c;
      p0 p0 = p0.v(param1Context, null, arrayOfInt, g.a.actionBarTabStyle, 0);
      if (p0.s(0))
        setBackgroundDrawable(p0.g(0)); 
      p0.w();
      if (param1Boolean)
        setGravity(8388627); 
      c();
    }
    
    public void a(androidx.appcompat.app.a.c param1c) {
      this.t0 = param1c;
      c();
    }
    
    public androidx.appcompat.app.a.c b() {
      return this.t0;
    }
    
    public void c() {
      androidx.appcompat.app.a.c c1 = this.t0;
      View view = c1.b();
      ViewParent viewParent = null;
      if (view != null) {
        viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.w0 = view;
        TextView textView = this.u0;
        if (textView != null)
          textView.setVisibility(8); 
        ImageView imageView = this.v0;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.v0.setImageDrawable(null);
          return;
        } 
      } else {
        CharSequence charSequence1;
        view = this.w0;
        if (view != null) {
          removeView(view);
          this.w0 = null;
        } 
        Drawable drawable = c1.c();
        CharSequence charSequence2 = c1.d();
        if (drawable != null) {
          if (this.v0 == null) {
            AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatImageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatImageView, 0);
            this.v0 = appCompatImageView;
          } 
          this.v0.setImageDrawable(drawable);
          this.v0.setVisibility(0);
        } else {
          ImageView imageView1 = this.v0;
          if (imageView1 != null) {
            imageView1.setVisibility(8);
            this.v0.setImageDrawable(null);
          } 
        } 
        int i = TextUtils.isEmpty(charSequence2) ^ true;
        if (i != 0) {
          if (this.u0 == null) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, g.a.actionBarTabTextStyle);
            appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatTextView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatTextView);
            this.u0 = appCompatTextView;
          } 
          this.u0.setText(charSequence2);
          this.u0.setVisibility(0);
        } else {
          TextView textView = this.u0;
          if (textView != null) {
            textView.setVisibility(8);
            this.u0.setText(null);
          } 
        } 
        ImageView imageView = this.v0;
        if (imageView != null)
          imageView.setContentDescription(c1.a()); 
        if (i == 0)
          charSequence1 = c1.a(); 
        u0.a((View)this, charSequence1);
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (this.x0.x0 > 0) {
        param1Int1 = getMeasuredWidth();
        int i = this.x0.x0;
        if (param1Int1 > i)
          super.onMeasure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), param1Int2); 
      } 
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */