package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;
import androidx.core.view.m0;
import g.j;
import j$.util.concurrent.ConcurrentHashMap;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

class s {
  private static final RectF l = new RectF();
  
  @SuppressLint({"BanConcurrentHashMap"})
  private static ConcurrentHashMap<String, Method> m = new ConcurrentHashMap();
  
  @SuppressLint({"BanConcurrentHashMap"})
  private static ConcurrentHashMap<String, Field> n = new ConcurrentHashMap();
  
  private int a = 0;
  
  private boolean b = false;
  
  private float c = -1.0F;
  
  private float d = -1.0F;
  
  private float e = -1.0F;
  
  private int[] f = new int[0];
  
  private boolean g = false;
  
  private TextPaint h;
  
  private final TextView i;
  
  private final Context j;
  
  private final f k;
  
  s(TextView paramTextView) {
    this.i = paramTextView;
    this.j = paramTextView.getContext();
    int i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      this.k = new e();
      return;
    } 
    if (i >= 23) {
      this.k = new d();
      return;
    } 
    this.k = new f();
  }
  
  private int[] b(int[] paramArrayOfint) {
    int j = paramArrayOfint.length;
    if (j == 0)
      return paramArrayOfint; 
    Arrays.sort(paramArrayOfint);
    ArrayList<? extends Comparable<? super Integer>> arrayList = new ArrayList();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      int k = paramArrayOfint[i];
      if (k > 0 && Collections.binarySearch(arrayList, Integer.valueOf(k)) < 0)
        arrayList.add(Integer.valueOf(k)); 
    } 
    if (j == arrayList.size())
      return paramArrayOfint; 
    j = arrayList.size();
    paramArrayOfint = new int[j];
    for (i = bool; i < j; i++)
      paramArrayOfint[i] = ((Integer)arrayList.get(i)).intValue(); 
    return paramArrayOfint;
  }
  
  private void c() {
    this.a = 0;
    this.d = -1.0F;
    this.e = -1.0F;
    this.c = -1.0F;
    this.f = new int[0];
    this.b = false;
  }
  
  private int e(RectF paramRectF) {
    int i = this.f.length;
    if (i != 0) {
      int j = 1;
      int k = i - 1;
      i = 0;
      while (j <= k) {
        int m = (j + k) / 2;
        if (x(this.f[m], paramRectF)) {
          i = j;
          j = m + 1;
          continue;
        } 
        i = m - 1;
        k = i;
      } 
      return this.f[i];
    } 
    throw new IllegalStateException("No available text sizes to choose from.");
  }
  
  private static Method k(String paramString) {
    try {
      Method method2 = (Method)m.get(paramString);
      Method method1 = method2;
      if (method2 == null) {
        method2 = TextView.class.getDeclaredMethod(paramString, new Class[0]);
        method1 = method2;
        if (method2 != null) {
          method2.setAccessible(true);
          m.put(paramString, method2);
          method1 = method2;
        } 
      } 
      return method1;
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to retrieve TextView#");
      stringBuilder.append(paramString);
      stringBuilder.append("() method");
      Log.w("ACTVAutoSizeHelper", stringBuilder.toString(), exception);
      return null;
    } 
  }
  
  static <T> T m(Object paramObject, String paramString, T paramT) {
    try {
      return (T)k(paramString).invoke(paramObject, new Object[0]);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to invoke TextView#");
      stringBuilder.append(paramString);
      stringBuilder.append("() method");
      Log.w("ACTVAutoSizeHelper", stringBuilder.toString(), exception);
      return paramT;
    } finally {}
  }
  
  private void s(float paramFloat) {
    if (paramFloat != this.i.getPaint().getTextSize()) {
      this.i.getPaint().setTextSize(paramFloat);
      boolean bool = b.a((View)this.i);
      if (this.i.getLayout() != null) {
        this.b = false;
        try {
          Method method = k("nullLayouts");
          if (method != null)
            method.invoke(this.i, new Object[0]); 
        } catch (Exception exception) {
          Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", exception);
        } 
        if (!bool) {
          this.i.requestLayout();
        } else {
          this.i.forceLayout();
        } 
        this.i.invalidate();
      } 
    } 
  }
  
  private boolean u() {
    boolean bool = y();
    int i = 0;
    if (bool && this.a == 1) {
      if (!this.g || this.f.length == 0) {
        int j = (int)Math.floor(((this.e - this.d) / this.c)) + 1;
        int[] arrayOfInt = new int[j];
        while (i < j) {
          arrayOfInt[i] = Math.round(this.d + i * this.c);
          i++;
        } 
        this.f = b(arrayOfInt);
      } 
      this.b = true;
    } else {
      this.b = false;
    } 
    return this.b;
  }
  
  private void v(TypedArray paramTypedArray) {
    int i = paramTypedArray.length();
    int[] arrayOfInt = new int[i];
    if (i > 0) {
      for (int j = 0; j < i; j++)
        arrayOfInt[j] = paramTypedArray.getDimensionPixelSize(j, -1); 
      this.f = b(arrayOfInt);
      w();
    } 
  }
  
  private boolean w() {
    boolean bool;
    int[] arrayOfInt = this.f;
    int i = arrayOfInt.length;
    if (i > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.g = bool;
    if (bool) {
      this.a = 1;
      this.d = arrayOfInt[0];
      this.e = arrayOfInt[i - 1];
      this.c = -1.0F;
    } 
    return bool;
  }
  
  private boolean x(int paramInt, RectF paramRectF) {
    CharSequence charSequence2 = this.i.getText();
    TransformationMethod transformationMethod = this.i.getTransformationMethod();
    CharSequence charSequence1 = charSequence2;
    if (transformationMethod != null) {
      CharSequence charSequence = transformationMethod.getTransformation(charSequence2, (View)this.i);
      charSequence1 = charSequence2;
      if (charSequence != null)
        charSequence1 = charSequence; 
    } 
    int i = a.b(this.i);
    l(paramInt);
    StaticLayout staticLayout = d(charSequence1, m(this.i, "getLayoutAlignment", Layout.Alignment.ALIGN_NORMAL), Math.round(paramRectF.right), i);
    return (i != -1 && (staticLayout.getLineCount() > i || staticLayout.getLineEnd(staticLayout.getLineCount() - 1) != charSequence1.length())) ? false : (!(staticLayout.getHeight() > paramRectF.bottom));
  }
  
  private boolean y() {
    return this.i instanceof AppCompatEditText ^ true;
  }
  
  private void z(float paramFloat1, float paramFloat2, float paramFloat3) throws IllegalArgumentException {
    if (paramFloat1 > 0.0F) {
      if (paramFloat2 > paramFloat1) {
        if (paramFloat3 > 0.0F) {
          this.a = 1;
          this.d = paramFloat1;
          this.e = paramFloat2;
          this.c = paramFloat3;
          this.g = false;
          return;
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("The auto-size step granularity (");
        stringBuilder2.append(paramFloat3);
        stringBuilder2.append("px) is less or equal to (0px)");
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Maximum auto-size text size (");
      stringBuilder1.append(paramFloat2);
      stringBuilder1.append("px) is less or equal to minimum auto-size text size (");
      stringBuilder1.append(paramFloat1);
      stringBuilder1.append("px)");
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Minimum auto-size text size (");
    stringBuilder.append(paramFloat1);
    stringBuilder.append("px) is less or equal to (0px)");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void a() {
    if (!n())
      return; 
    if (this.b)
      if (this.i.getMeasuredHeight() > 0) {
        int i;
        if (this.i.getMeasuredWidth() <= 0)
          return; 
        if (this.k.b(this.i)) {
          i = 1048576;
        } else {
          i = this.i.getMeasuredWidth() - this.i.getTotalPaddingLeft() - this.i.getTotalPaddingRight();
        } 
        int j = this.i.getHeight() - this.i.getCompoundPaddingBottom() - this.i.getCompoundPaddingTop();
        if (i > 0) {
          if (j <= 0)
            return; 
          synchronized (l) {
            null.setEmpty();
            null.right = i;
            null.bottom = j;
            float f1 = e(null);
            if (f1 != this.i.getTextSize())
              t(0, f1); 
          } 
        } else {
          return;
        } 
      } else {
        return;
      }  
    this.b = true;
  }
  
  StaticLayout d(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt1, int paramInt2) {
    return (Build.VERSION.SDK_INT >= 23) ? c.a(paramCharSequence, paramAlignment, paramInt1, paramInt2, this.i, this.h, this.k) : a.a(paramCharSequence, paramAlignment, paramInt1, this.i, this.h);
  }
  
  int f() {
    return Math.round(this.e);
  }
  
  int g() {
    return Math.round(this.d);
  }
  
  int h() {
    return Math.round(this.c);
  }
  
  int[] i() {
    return this.f;
  }
  
  int j() {
    return this.a;
  }
  
  void l(int paramInt) {
    TextPaint textPaint = this.h;
    if (textPaint == null) {
      this.h = new TextPaint();
    } else {
      textPaint.reset();
    } 
    this.h.set(this.i.getPaint());
    this.h.setTextSize(paramInt);
  }
  
  boolean n() {
    return (y() && this.a != 0);
  }
  
  void o(AttributeSet paramAttributeSet, int paramInt) {
    float f1;
    float f2;
    float f3;
    TypedArray typedArray = this.j.obtainStyledAttributes(paramAttributeSet, j.AppCompatTextView, paramInt, 0);
    TextView textView = this.i;
    m0.q0((View)textView, textView.getContext(), j.AppCompatTextView, paramAttributeSet, typedArray, paramInt, 0);
    if (typedArray.hasValue(j.AppCompatTextView_autoSizeTextType))
      this.a = typedArray.getInt(j.AppCompatTextView_autoSizeTextType, 0); 
    if (typedArray.hasValue(j.AppCompatTextView_autoSizeStepGranularity)) {
      f1 = typedArray.getDimension(j.AppCompatTextView_autoSizeStepGranularity, -1.0F);
    } else {
      f1 = -1.0F;
    } 
    if (typedArray.hasValue(j.AppCompatTextView_autoSizeMinTextSize)) {
      f2 = typedArray.getDimension(j.AppCompatTextView_autoSizeMinTextSize, -1.0F);
    } else {
      f2 = -1.0F;
    } 
    if (typedArray.hasValue(j.AppCompatTextView_autoSizeMaxTextSize)) {
      f3 = typedArray.getDimension(j.AppCompatTextView_autoSizeMaxTextSize, -1.0F);
    } else {
      f3 = -1.0F;
    } 
    if (typedArray.hasValue(j.AppCompatTextView_autoSizePresetSizes)) {
      paramInt = typedArray.getResourceId(j.AppCompatTextView_autoSizePresetSizes, 0);
      if (paramInt > 0) {
        TypedArray typedArray1 = typedArray.getResources().obtainTypedArray(paramInt);
        v(typedArray1);
        typedArray1.recycle();
      } 
    } 
    typedArray.recycle();
    if (y()) {
      if (this.a == 1) {
        if (!this.g) {
          DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
          float f4 = f2;
          if (f2 == -1.0F)
            f4 = TypedValue.applyDimension(2, 12.0F, displayMetrics); 
          f2 = f3;
          if (f3 == -1.0F)
            f2 = TypedValue.applyDimension(2, 112.0F, displayMetrics); 
          f3 = f1;
          if (f1 == -1.0F)
            f3 = 1.0F; 
          z(f4, f2, f3);
        } 
        u();
        return;
      } 
    } else {
      this.a = 0;
    } 
  }
  
  void p(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    if (y()) {
      DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
      z(TypedValue.applyDimension(paramInt4, paramInt1, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt2, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt3, displayMetrics));
      if (u())
        a(); 
    } 
  }
  
  void q(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    if (y()) {
      int j = paramArrayOfint.length;
      int i = 0;
      if (j > 0) {
        int[] arrayOfInt1;
        int[] arrayOfInt2 = new int[j];
        if (paramInt == 0) {
          arrayOfInt1 = Arrays.copyOf(paramArrayOfint, j);
        } else {
          DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
          while (true) {
            arrayOfInt1 = arrayOfInt2;
            if (i < j) {
              arrayOfInt2[i] = Math.round(TypedValue.applyDimension(paramInt, paramArrayOfint[i], displayMetrics));
              i++;
              continue;
            } 
            break;
          } 
        } 
        this.f = b(arrayOfInt1);
        if (!w()) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("None of the preset sizes is valid: ");
          stringBuilder.append(Arrays.toString(paramArrayOfint));
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        this.g = false;
      } 
      if (u())
        a(); 
    } 
  }
  
  void r(int paramInt) {
    if (y())
      if (paramInt != 0) {
        if (paramInt == 1) {
          DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
          z(TypedValue.applyDimension(2, 12.0F, displayMetrics), TypedValue.applyDimension(2, 112.0F, displayMetrics), 1.0F);
          if (u()) {
            a();
            return;
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown auto-size text type: ");
          stringBuilder.append(paramInt);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        c();
      }  
  }
  
  void t(int paramInt, float paramFloat) {
    Resources resources;
    Context context = this.j;
    if (context == null) {
      resources = Resources.getSystem();
    } else {
      resources = resources.getResources();
    } 
    s(TypedValue.applyDimension(paramInt, paramFloat, resources.getDisplayMetrics()));
  }
  
  private static final class a {
    static StaticLayout a(CharSequence param1CharSequence, Layout.Alignment param1Alignment, int param1Int, TextView param1TextView, TextPaint param1TextPaint) {
      return new StaticLayout(param1CharSequence, param1TextPaint, param1Int, param1Alignment, param1TextView.getLineSpacingMultiplier(), param1TextView.getLineSpacingExtra(), param1TextView.getIncludeFontPadding());
    }
    
    static int b(TextView param1TextView) {
      return param1TextView.getMaxLines();
    }
  }
  
  private static final class b {
    static boolean a(View param1View) {
      return param1View.isInLayout();
    }
  }
  
  private static final class c {
    static StaticLayout a(CharSequence param1CharSequence, Layout.Alignment param1Alignment, int param1Int1, int param1Int2, TextView param1TextView, TextPaint param1TextPaint, s.f param1f) {
      StaticLayout.Builder builder1 = StaticLayout.Builder.obtain(param1CharSequence, 0, param1CharSequence.length(), param1TextPaint, param1Int1);
      StaticLayout.Builder builder2 = builder1.setAlignment(param1Alignment).setLineSpacing(param1TextView.getLineSpacingExtra(), param1TextView.getLineSpacingMultiplier()).setIncludePad(param1TextView.getIncludeFontPadding()).setBreakStrategy(param1TextView.getBreakStrategy()).setHyphenationFrequency(param1TextView.getHyphenationFrequency());
      param1Int1 = param1Int2;
      if (param1Int2 == -1)
        param1Int1 = Integer.MAX_VALUE; 
      builder2.setMaxLines(param1Int1);
      try {
        param1f.a(builder1, param1TextView);
      } catch (ClassCastException classCastException) {
        Log.w("ACTVAutoSizeHelper", "Failed to obtain TextDirectionHeuristic, auto size may be incorrect");
      } 
      return builder1.build();
    }
  }
  
  private static class d extends f {
    void a(StaticLayout.Builder param1Builder, TextView param1TextView) {
      t.a(param1Builder, s.<TextDirectionHeuristic>m(param1TextView, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR));
    }
  }
  
  private static class e extends d {
    void a(StaticLayout.Builder param1Builder, TextView param1TextView) {
      t.a(param1Builder, v.a(param1TextView));
    }
    
    boolean b(TextView param1TextView) {
      return u.a(param1TextView);
    }
  }
  
  private static class f {
    void a(StaticLayout.Builder param1Builder, TextView param1TextView) {}
    
    boolean b(TextView param1TextView) {
      return ((Boolean)s.<Boolean>m(param1TextView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */