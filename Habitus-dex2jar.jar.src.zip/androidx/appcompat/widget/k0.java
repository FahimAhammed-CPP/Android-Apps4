package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import androidx.core.graphics.a;
import g.j;

public class k0 {
  private static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  static final int[] b = new int[] { -16842910 };
  
  static final int[] c = new int[] { 16842908 };
  
  static final int[] d = new int[] { 16843518 };
  
  static final int[] e = new int[] { 16842919 };
  
  static final int[] f = new int[] { 16842912 };
  
  static final int[] g = new int[] { 16842913 };
  
  static final int[] h = new int[] { -16842919, -16842908 };
  
  static final int[] i = new int[0];
  
  private static final int[] j = new int[1];
  
  public static void a(View paramView, Context paramContext) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(j.AppCompatTheme);
    try {
      if (!typedArray.hasValue(j.AppCompatTheme_windowActionBar)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("View ");
        stringBuilder.append(paramView.getClass());
        stringBuilder.append(" is an AppCompat widget that can only be used with a Theme.AppCompat theme (or descendant).");
        Log.e("ThemeUtils", stringBuilder.toString());
      } 
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  public static int b(Context paramContext, int paramInt) {
    ColorStateList colorStateList = e(paramContext, paramInt);
    if (colorStateList != null && colorStateList.isStateful())
      return colorStateList.getColorForState(b, colorStateList.getDefaultColor()); 
    TypedValue typedValue = f();
    paramContext.getTheme().resolveAttribute(16842803, typedValue, true);
    return d(paramContext, paramInt, typedValue.getFloat());
  }
  
  public static int c(Context paramContext, int paramInt) {
    null = j;
    null[0] = paramInt;
    p0 p0 = p0.u(paramContext, null, null);
    try {
      paramInt = p0.b(0, 0);
      return paramInt;
    } finally {
      p0.w();
    } 
  }
  
  static int d(Context paramContext, int paramInt, float paramFloat) {
    paramInt = c(paramContext, paramInt);
    return a.k(paramInt, Math.round(Color.alpha(paramInt) * paramFloat));
  }
  
  public static ColorStateList e(Context paramContext, int paramInt) {
    null = j;
    null[0] = paramInt;
    p0 p0 = p0.u(paramContext, null, null);
    try {
      return p0.c(0);
    } finally {
      p0.w();
    } 
  }
  
  private static TypedValue f() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\widget\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */