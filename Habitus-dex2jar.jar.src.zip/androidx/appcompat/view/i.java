package androidx.appcompat.view;

import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SearchEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;

public class i implements Window.Callback {
  final Window.Callback s0;
  
  public i(Window.Callback paramCallback) {
    if (paramCallback != null) {
      this.s0 = paramCallback;
      return;
    } 
    throw new IllegalArgumentException("Window callback may not be null");
  }
  
  public final Window.Callback a() {
    return this.s0;
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent) {
    return this.s0.dispatchGenericMotionEvent(paramMotionEvent);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return this.s0.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    return this.s0.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return this.s0.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent);
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    return this.s0.dispatchTouchEvent(paramMotionEvent);
  }
  
  public boolean dispatchTrackballEvent(MotionEvent paramMotionEvent) {
    return this.s0.dispatchTrackballEvent(paramMotionEvent);
  }
  
  public void onActionModeFinished(ActionMode paramActionMode) {
    this.s0.onActionModeFinished(paramActionMode);
  }
  
  public void onActionModeStarted(ActionMode paramActionMode) {
    this.s0.onActionModeStarted(paramActionMode);
  }
  
  public void onAttachedToWindow() {
    this.s0.onAttachedToWindow();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return this.s0.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreatePanelView(int paramInt) {
    return this.s0.onCreatePanelView(paramInt);
  }
  
  public void onDetachedFromWindow() {
    this.s0.onDetachedFromWindow();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return this.s0.onMenuItemSelected(paramInt, paramMenuItem);
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return this.s0.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    this.s0.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPointerCaptureChanged(boolean paramBoolean) {
    c.a(this.s0, paramBoolean);
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return this.s0.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> paramList, Menu paramMenu, int paramInt) {
    b.a(this.s0, paramList, paramMenu, paramInt);
  }
  
  public boolean onSearchRequested() {
    return this.s0.onSearchRequested();
  }
  
  public boolean onSearchRequested(SearchEvent paramSearchEvent) {
    return a.a(this.s0, paramSearchEvent);
  }
  
  public void onWindowAttributesChanged(WindowManager.LayoutParams paramLayoutParams) {
    this.s0.onWindowAttributesChanged(paramLayoutParams);
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    this.s0.onWindowFocusChanged(paramBoolean);
  }
  
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback) {
    return this.s0.onWindowStartingActionMode(paramCallback);
  }
  
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback, int paramInt) {
    return a.b(this.s0, paramCallback, paramInt);
  }
  
  static class a {
    static boolean a(Window.Callback param1Callback, SearchEvent param1SearchEvent) {
      return param1Callback.onSearchRequested(param1SearchEvent);
    }
    
    static ActionMode b(Window.Callback param1Callback, ActionMode.Callback param1Callback1, int param1Int) {
      return param1Callback.onWindowStartingActionMode(param1Callback1, param1Int);
    }
  }
  
  static class b {
    static void a(Window.Callback param1Callback, List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      param1Callback.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
  }
  
  static class c {
    static void a(Window.Callback param1Callback, boolean param1Boolean) {
      param1Callback.onPointerCaptureChanged(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */