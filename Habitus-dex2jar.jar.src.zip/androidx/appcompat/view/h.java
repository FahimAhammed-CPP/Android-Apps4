package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.view.u0;
import androidx.core.view.v0;
import androidx.core.view.w0;
import java.util.ArrayList;
import java.util.Iterator;

public class h {
  final ArrayList<u0> a = new ArrayList<u0>();
  
  private long b = -1L;
  
  private Interpolator c;
  
  v0 d;
  
  private boolean e;
  
  private final w0 f = new a(this);
  
  public void a() {
    if (!this.e)
      return; 
    Iterator<u0> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((u0)iterator.next()).c(); 
    this.e = false;
  }
  
  void b() {
    this.e = false;
  }
  
  public h c(u0 paramu0) {
    if (!this.e)
      this.a.add(paramu0); 
    return this;
  }
  
  public h d(u0 paramu01, u0 paramu02) {
    this.a.add(paramu01);
    paramu02.j(paramu01.d());
    this.a.add(paramu02);
    return this;
  }
  
  public h e(long paramLong) {
    if (!this.e)
      this.b = paramLong; 
    return this;
  }
  
  public h f(Interpolator paramInterpolator) {
    if (!this.e)
      this.c = paramInterpolator; 
    return this;
  }
  
  public h g(v0 paramv0) {
    if (!this.e)
      this.d = paramv0; 
    return this;
  }
  
  public void h() {
    if (this.e)
      return; 
    for (u0 u0 : this.a) {
      long l = this.b;
      if (l >= 0L)
        u0.f(l); 
      Interpolator interpolator = this.c;
      if (interpolator != null)
        u0.g(interpolator); 
      if (this.d != null)
        u0.h((v0)this.f); 
      u0.l();
    } 
    this.e = true;
  }
  
  class a extends w0 {
    private boolean a = false;
    
    private int b = 0;
    
    a(h this$0) {}
    
    public void b(View param1View) {
      int i = this.b + 1;
      this.b = i;
      if (i == this.c.a.size()) {
        v0 v0 = this.c.d;
        if (v0 != null)
          v0.b(null); 
        d();
      } 
    }
    
    public void c(View param1View) {
      if (this.a)
        return; 
      this.a = true;
      v0 v0 = this.c.d;
      if (v0 != null)
        v0.c(null); 
    }
    
    void d() {
      this.b = 0;
      this.a = false;
      this.c.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */