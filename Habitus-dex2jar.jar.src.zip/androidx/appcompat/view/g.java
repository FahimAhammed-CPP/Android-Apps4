package androidx.appcompat.view;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.j;
import androidx.core.view.w;
import g.j;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class g extends MenuInflater {
  static final Class<?>[] e;
  
  static final Class<?>[] f;
  
  final Object[] a;
  
  final Object[] b;
  
  Context c;
  
  private Object d;
  
  static {
    Class[] arrayOfClass = new Class[1];
    arrayOfClass[0] = Context.class;
    e = arrayOfClass;
    f = arrayOfClass;
  }
  
  public g(Context paramContext) {
    super(paramContext);
    this.c = paramContext;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramContext;
    this.a = arrayOfObject;
    this.b = arrayOfObject;
  }
  
  private Object a(Object paramObject) {
    if (paramObject instanceof android.app.Activity)
      return paramObject; 
    Object object = paramObject;
    if (paramObject instanceof ContextWrapper)
      object = a(((ContextWrapper)paramObject).getBaseContext()); 
    return object;
  }
  
  private void c(XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Menu paramMenu) throws XmlPullParserException, IOException {
    StringBuilder stringBuilder;
    b b = new b(this, paramMenu);
    int i = paramXmlPullParser.getEventType();
    while (true) {
      if (i == 2) {
        String str = paramXmlPullParser.getName();
        if (str.equals("menu")) {
          i = paramXmlPullParser.next();
          break;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Expecting menu, got ");
        stringBuilder.append(str);
        throw new RuntimeException(stringBuilder.toString());
      } 
      int k = stringBuilder.next();
      i = k;
      if (k == 1) {
        i = k;
        break;
      } 
    } 
    Menu menu = null;
    boolean bool = false;
    int j = 0;
    while (!bool) {
      if (i != 1) {
        Menu menu1;
        boolean bool1;
        if (i != 2) {
          if (i != 3) {
            bool1 = bool;
            i = j;
            paramMenu = menu;
          } else {
            String str = stringBuilder.getName();
            if (j && str.equals(menu)) {
              paramMenu = null;
              i = 0;
              bool1 = bool;
            } else if (str.equals("group")) {
              b.h();
              bool1 = bool;
              i = j;
              paramMenu = menu;
            } else if (str.equals("item")) {
              bool1 = bool;
              i = j;
              paramMenu = menu;
              if (!b.d()) {
                androidx.core.view.b b1 = b.A;
                if (b1 != null && b1.a()) {
                  b.b();
                  bool1 = bool;
                  i = j;
                  menu1 = menu;
                } else {
                  b.a();
                  bool1 = bool;
                  i = j;
                  menu1 = menu;
                } 
              } 
            } else {
              bool1 = bool;
              i = j;
              paramMenu = menu;
              if (str.equals("menu")) {
                bool1 = true;
                i = j;
                paramMenu = menu;
              } 
            } 
          } 
        } else if (j) {
          bool1 = bool;
          i = j;
          paramMenu = menu;
        } else {
          String str = stringBuilder.getName();
          if (str.equals("group")) {
            b.f(paramAttributeSet);
            bool1 = bool;
            i = j;
            menu1 = menu;
          } else if (menu1.equals("item")) {
            b.g(paramAttributeSet);
            bool1 = bool;
            i = j;
            menu1 = menu;
          } else if (menu1.equals("menu")) {
            c((XmlPullParser)stringBuilder, paramAttributeSet, (Menu)b.b());
            bool1 = bool;
            i = j;
            menu1 = menu;
          } else {
            i = 1;
            bool1 = bool;
          } 
        } 
        int k = stringBuilder.next();
        bool = bool1;
        j = i;
        menu = menu1;
        i = k;
        continue;
      } 
      throw new RuntimeException("Unexpected end of document");
    } 
  }
  
  Object b() {
    if (this.d == null)
      this.d = a(this.c); 
    return this.d;
  }
  
  public void inflate(int paramInt, Menu paramMenu) {
    if (!(paramMenu instanceof t2.a)) {
      super.inflate(paramInt, paramMenu);
      return;
    } 
    XmlResourceParser xmlResourceParser2 = null;
    XmlResourceParser xmlResourceParser3 = null;
    XmlResourceParser xmlResourceParser1 = null;
    try {
      XmlResourceParser xmlResourceParser = this.c.getResources().getLayout(paramInt);
      xmlResourceParser1 = xmlResourceParser;
      xmlResourceParser2 = xmlResourceParser;
      xmlResourceParser3 = xmlResourceParser;
      c((XmlPullParser)xmlResourceParser, Xml.asAttributeSet((XmlPullParser)xmlResourceParser), paramMenu);
      if (xmlResourceParser != null)
        xmlResourceParser.close(); 
      return;
    } catch (XmlPullParserException xmlPullParserException) {
      xmlResourceParser1 = xmlResourceParser3;
      throw new InflateException("Error inflating menu XML", xmlPullParserException);
    } catch (IOException iOException) {
      xmlResourceParser1 = xmlResourceParser2;
      throw new InflateException("Error inflating menu XML", iOException);
    } finally {}
    if (xmlResourceParser1 != null)
      xmlResourceParser1.close(); 
    throw paramMenu;
  }
  
  private static class a implements MenuItem.OnMenuItemClickListener {
    private static final Class<?>[] c = new Class[] { MenuItem.class };
    
    private Object a;
    
    private Method b;
    
    public a(Object param1Object, String param1String) {
      this.a = param1Object;
      Class<?> clazz = param1Object.getClass();
      try {
        this.b = clazz.getMethod(param1String, c);
        return;
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Couldn't resolve menu item onClick handler ");
        stringBuilder.append(param1String);
        stringBuilder.append(" in class ");
        stringBuilder.append(clazz.getName());
        InflateException inflateException = new InflateException(stringBuilder.toString());
        inflateException.initCause(exception);
        throw inflateException;
      } 
    }
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      try {
        if (this.b.getReturnType() == boolean.class)
          return ((Boolean)this.b.invoke(this.a, new Object[] { param1MenuItem })).booleanValue(); 
        this.b.invoke(this.a, new Object[] { param1MenuItem });
        return true;
      } catch (Exception exception) {
        throw new RuntimeException(exception);
      } 
    }
  }
  
  private class b {
    androidx.core.view.b A;
    
    private CharSequence B;
    
    private CharSequence C;
    
    private ColorStateList D = null;
    
    private PorterDuff.Mode E = null;
    
    private Menu a;
    
    private int b;
    
    private int c;
    
    private int d;
    
    private int e;
    
    private boolean f;
    
    private boolean g;
    
    private boolean h;
    
    private int i;
    
    private int j;
    
    private CharSequence k;
    
    private CharSequence l;
    
    private int m;
    
    private char n;
    
    private int o;
    
    private char p;
    
    private int q;
    
    private int r;
    
    private boolean s;
    
    private boolean t;
    
    private boolean u;
    
    private int v;
    
    private int w;
    
    private String x;
    
    private String y;
    
    private String z;
    
    public b(g this$0, Menu param1Menu) {
      this.a = param1Menu;
      h();
    }
    
    private char c(String param1String) {
      return (param1String == null) ? Character.MIN_VALUE : param1String.charAt(0);
    }
    
    private <T> T e(String param1String, Class<?>[] param1ArrayOfClass, Object[] param1ArrayOfObject) {
      try {
        null = Class.forName(param1String, false, this.F.c.getClassLoader()).getConstructor(param1ArrayOfClass);
        null.setAccessible(true);
        return (T)null.newInstance(param1ArrayOfObject);
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot instantiate class: ");
        stringBuilder.append(param1String);
        Log.w("SupportMenuInflater", stringBuilder.toString(), exception);
        return null;
      } 
    }
    
    private void i(MenuItem param1MenuItem) {
      boolean bool2;
      MenuItem menuItem = param1MenuItem.setChecked(this.s).setVisible(this.t).setEnabled(this.u);
      int i = this.r;
      boolean bool1 = false;
      if (i >= 1) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      menuItem.setCheckable(bool2).setTitleCondensed(this.l).setIcon(this.m);
      i = this.v;
      if (i >= 0)
        param1MenuItem.setShowAsAction(i); 
      if (this.z != null)
        if (!this.F.c.isRestricted()) {
          param1MenuItem.setOnMenuItemClickListener(new g.a(this.F.b(), this.z));
        } else {
          throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
        }  
      if (this.r >= 2)
        if (param1MenuItem instanceof i) {
          ((i)param1MenuItem).t(true);
        } else if (param1MenuItem instanceof j) {
          ((j)param1MenuItem).h(true);
        }  
      String str = this.x;
      if (str != null) {
        param1MenuItem.setActionView(e(str, g.e, this.F.a));
        bool1 = true;
      } 
      i = this.w;
      if (i > 0)
        if (!bool1) {
          param1MenuItem.setActionView(i);
        } else {
          Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
        }  
      androidx.core.view.b b1 = this.A;
      if (b1 != null)
        w.a(param1MenuItem, b1); 
      w.c(param1MenuItem, this.B);
      w.g(param1MenuItem, this.C);
      w.b(param1MenuItem, this.n, this.o);
      w.f(param1MenuItem, this.p, this.q);
      PorterDuff.Mode mode = this.E;
      if (mode != null)
        w.e(param1MenuItem, mode); 
      ColorStateList colorStateList = this.D;
      if (colorStateList != null)
        w.d(param1MenuItem, colorStateList); 
    }
    
    public void a() {
      this.h = true;
      i(this.a.add(this.b, this.i, this.j, this.k));
    }
    
    public SubMenu b() {
      this.h = true;
      SubMenu subMenu = this.a.addSubMenu(this.b, this.i, this.j, this.k);
      i(subMenu.getItem());
      return subMenu;
    }
    
    public boolean d() {
      return this.h;
    }
    
    public void f(AttributeSet param1AttributeSet) {
      TypedArray typedArray = this.F.c.obtainStyledAttributes(param1AttributeSet, j.MenuGroup);
      this.b = typedArray.getResourceId(j.MenuGroup_android_id, 0);
      this.c = typedArray.getInt(j.MenuGroup_android_menuCategory, 0);
      this.d = typedArray.getInt(j.MenuGroup_android_orderInCategory, 0);
      this.e = typedArray.getInt(j.MenuGroup_android_checkableBehavior, 0);
      this.f = typedArray.getBoolean(j.MenuGroup_android_visible, true);
      this.g = typedArray.getBoolean(j.MenuGroup_android_enabled, true);
      typedArray.recycle();
    }
    
    public void g(AttributeSet param1AttributeSet) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public void h() {
      this.b = 0;
      this.c = 0;
      this.d = 0;
      this.e = 0;
      this.f = true;
      this.g = true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */