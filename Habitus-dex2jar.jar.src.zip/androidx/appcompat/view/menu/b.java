package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class b implements m {
  protected n A0;
  
  private int B0;
  
  protected Context s0;
  
  protected Context t0;
  
  protected g u0;
  
  protected LayoutInflater v0;
  
  protected LayoutInflater w0;
  
  private m.a x0;
  
  private int y0;
  
  private int z0;
  
  public b(Context paramContext, int paramInt1, int paramInt2) {
    this.s0 = paramContext;
    this.v0 = LayoutInflater.from(paramContext);
    this.y0 = paramInt1;
    this.z0 = paramInt2;
  }
  
  protected void a(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.A0).addView(paramView, paramInt);
  }
  
  public void b(g paramg, boolean paramBoolean) {
    m.a a1 = this.x0;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public boolean c(g paramg, i parami) {
    return false;
  }
  
  public void d(m.a parama) {
    this.x0 = parama;
  }
  
  public boolean f(r paramr) {
    m.a a1 = this.x0;
    if (a1 != null) {
      g g1;
      if (paramr == null)
        g1 = this.u0; 
      return a1.c(g1);
    } 
    return false;
  }
  
  public int getId() {
    return this.B0;
  }
  
  public void h(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.A0;
    if (viewGroup == null)
      return; 
    g g1 = this.u0;
    int i = 0;
    if (g1 != null) {
      g1.t();
      ArrayList<i> arrayList = this.u0.G();
      int k = arrayList.size();
      int j = 0;
      for (i = 0; j < k; i = i1) {
        i i2 = arrayList.get(j);
        int i1 = i;
        if (s(i, i2)) {
          View view1 = viewGroup.getChildAt(i);
          if (view1 instanceof n.a) {
            i i3 = ((n.a)view1).getItemData();
          } else {
            g1 = null;
          } 
          View view2 = p(i2, view1, viewGroup);
          if (i2 != g1) {
            view2.setPressed(false);
            view2.jumpDrawablesToCurrentState();
          } 
          if (view2 != view1)
            a(view2, i); 
          i1 = i + 1;
        } 
        j++;
      } 
    } 
    while (i < viewGroup.getChildCount()) {
      if (!n(viewGroup, i))
        i++; 
    } 
  }
  
  public boolean j(g paramg, i parami) {
    return false;
  }
  
  public void k(Context paramContext, g paramg) {
    this.t0 = paramContext;
    this.w0 = LayoutInflater.from(paramContext);
    this.u0 = paramg;
  }
  
  public abstract void l(i parami, n.a parama);
  
  public n.a m(ViewGroup paramViewGroup) {
    return (n.a)this.v0.inflate(this.z0, paramViewGroup, false);
  }
  
  protected boolean n(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public m.a o() {
    return this.x0;
  }
  
  public View p(i parami, View paramView, ViewGroup paramViewGroup) {
    n.a a1;
    if (paramView instanceof n.a) {
      a1 = (n.a)paramView;
    } else {
      a1 = m(paramViewGroup);
    } 
    l(parami, a1);
    return (View)a1;
  }
  
  public n q(ViewGroup paramViewGroup) {
    if (this.A0 == null) {
      n n1 = (n)this.v0.inflate(this.y0, paramViewGroup, false);
      this.A0 = n1;
      n1.a(this.u0);
      h(true);
    } 
    return this.A0;
  }
  
  public void r(int paramInt) {
    this.B0 = paramInt;
  }
  
  public abstract boolean s(int paramInt, i parami);
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\menu\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */