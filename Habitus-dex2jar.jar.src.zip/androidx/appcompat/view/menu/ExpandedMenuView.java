package androidx.appcompat.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.widget.p0;

public final class ExpandedMenuView extends ListView implements g.b, n, AdapterView.OnItemClickListener {
  private static final int[] u0 = new int[] { 16842964, 16843049 };
  
  private g s0;
  
  private int t0;
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842868);
  }
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    setOnItemClickListener(this);
    p0 p0 = p0.v(paramContext, paramAttributeSet, u0, paramInt, 0);
    if (p0.s(0))
      setBackgroundDrawable(p0.g(0)); 
    if (p0.s(1))
      setDivider(p0.g(1)); 
    p0.w();
  }
  
  public void a(g paramg) {
    this.s0 = paramg;
  }
  
  public boolean b(i parami) {
    return this.s0.N((MenuItem)parami, 0);
  }
  
  public int getWindowAnimations() {
    return this.t0;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    setChildrenDrawingCacheEnabled(false);
  }
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {
    b((i)getAdapter().getItem(paramInt));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\menu\ExpandedMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */