package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import g.g;
import java.util.ArrayList;

public class e implements m, AdapterView.OnItemClickListener {
  a A0;
  
  private int B0;
  
  Context s0;
  
  LayoutInflater t0;
  
  g u0;
  
  ExpandedMenuView v0;
  
  int w0;
  
  int x0;
  
  int y0;
  
  private m.a z0;
  
  public e(int paramInt1, int paramInt2) {
    this.y0 = paramInt1;
    this.x0 = paramInt2;
  }
  
  public e(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.s0 = paramContext;
    this.t0 = LayoutInflater.from(paramContext);
  }
  
  public ListAdapter a() {
    if (this.A0 == null)
      this.A0 = new a(this); 
    return (ListAdapter)this.A0;
  }
  
  public void b(g paramg, boolean paramBoolean) {
    m.a a1 = this.z0;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public boolean c(g paramg, i parami) {
    return false;
  }
  
  public void d(m.a parama) {
    this.z0 = parama;
  }
  
  public void e(Parcelable paramParcelable) {
    m((Bundle)paramParcelable);
  }
  
  public boolean f(r paramr) {
    if (!paramr.hasVisibleItems())
      return false; 
    (new h(paramr)).d(null);
    m.a a1 = this.z0;
    if (a1 != null)
      a1.c(paramr); 
    return true;
  }
  
  public Parcelable g() {
    if (this.v0 == null)
      return null; 
    Bundle bundle = new Bundle();
    n(bundle);
    return (Parcelable)bundle;
  }
  
  public int getId() {
    return this.B0;
  }
  
  public void h(boolean paramBoolean) {
    a a1 = this.A0;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean i() {
    return false;
  }
  
  public boolean j(g paramg, i parami) {
    return false;
  }
  
  public void k(Context paramContext, g paramg) {
    ContextThemeWrapper contextThemeWrapper;
    if (this.x0 != 0) {
      contextThemeWrapper = new ContextThemeWrapper(paramContext, this.x0);
      this.s0 = (Context)contextThemeWrapper;
      this.t0 = LayoutInflater.from((Context)contextThemeWrapper);
    } else if (this.s0 != null) {
      this.s0 = (Context)contextThemeWrapper;
      if (this.t0 == null)
        this.t0 = LayoutInflater.from((Context)contextThemeWrapper); 
    } 
    this.u0 = paramg;
    a a1 = this.A0;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public n l(ViewGroup paramViewGroup) {
    if (this.v0 == null) {
      this.v0 = (ExpandedMenuView)this.t0.inflate(g.abc_expanded_menu_layout, paramViewGroup, false);
      if (this.A0 == null)
        this.A0 = new a(this); 
      this.v0.setAdapter((ListAdapter)this.A0);
      this.v0.setOnItemClickListener(this);
    } 
    return this.v0;
  }
  
  public void m(Bundle paramBundle) {
    SparseArray sparseArray = paramBundle.getSparseParcelableArray("android:menu:list");
    if (sparseArray != null)
      this.v0.restoreHierarchyState(sparseArray); 
  }
  
  public void n(Bundle paramBundle) {
    SparseArray sparseArray = new SparseArray();
    ExpandedMenuView expandedMenuView = this.v0;
    if (expandedMenuView != null)
      expandedMenuView.saveHierarchyState(sparseArray); 
    paramBundle.putSparseParcelableArray("android:menu:list", sparseArray);
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.u0.O((MenuItem)this.A0.b(paramInt), this, 0);
  }
  
  private class a extends BaseAdapter {
    private int s0 = -1;
    
    public a(e this$0) {
      a();
    }
    
    void a() {
      i i = this.t0.u0.x();
      if (i != null) {
        ArrayList<i> arrayList = this.t0.u0.B();
        int k = arrayList.size();
        for (int j = 0; j < k; j++) {
          if ((i)arrayList.get(j) == i) {
            this.s0 = j;
            return;
          } 
        } 
      } 
      this.s0 = -1;
    }
    
    public i b(int param1Int) {
      ArrayList<i> arrayList = this.t0.u0.B();
      int i = param1Int + this.t0.w0;
      int j = this.s0;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      int i = this.t0.u0.B().size() - this.t0.w0;
      return (this.s0 < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null) {
        e e1 = this.t0;
        view = e1.t0.inflate(e1.y0, param1ViewGroup, false);
      } 
      ((n.a)view).c(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\menu\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */