package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Parcelable;

public interface m {
  void b(g paramg, boolean paramBoolean);
  
  boolean c(g paramg, i parami);
  
  void d(a parama);
  
  void e(Parcelable paramParcelable);
  
  boolean f(r paramr);
  
  Parcelable g();
  
  int getId();
  
  void h(boolean paramBoolean);
  
  boolean i();
  
  boolean j(g paramg, i parami);
  
  void k(Context paramContext, g paramg);
  
  public static interface a {
    void b(g param1g, boolean param1Boolean);
    
    boolean c(g param1g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\menu\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */