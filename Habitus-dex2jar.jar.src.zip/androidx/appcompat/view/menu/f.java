package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class f extends BaseAdapter {
  g s0;
  
  private int t0 = -1;
  
  private boolean u0;
  
  private final boolean v0;
  
  private final LayoutInflater w0;
  
  private final int x0;
  
  public f(g paramg, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.v0 = paramBoolean;
    this.w0 = paramLayoutInflater;
    this.s0 = paramg;
    this.x0 = paramInt;
    a();
  }
  
  void a() {
    i i = this.s0.x();
    if (i != null) {
      ArrayList<i> arrayList = this.s0.B();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        if ((i)arrayList.get(j) == i) {
          this.t0 = j;
          return;
        } 
      } 
    } 
    this.t0 = -1;
  }
  
  public g b() {
    return this.s0;
  }
  
  public i c(int paramInt) {
    ArrayList<i> arrayList;
    if (this.v0) {
      arrayList = this.s0.B();
    } else {
      arrayList = this.s0.G();
    } 
    int j = this.t0;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public void d(boolean paramBoolean) {
    this.u0 = paramBoolean;
  }
  
  public int getCount() {
    ArrayList<i> arrayList;
    if (this.v0) {
      arrayList = this.s0.B();
    } else {
      arrayList = this.s0.G();
    } 
    return (this.t0 < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.w0.inflate(this.x0, paramViewGroup, false); 
    int j = c(paramInt).getGroupId();
    int i = paramInt - 1;
    if (i >= 0) {
      i = c(i).getGroupId();
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.s0.H() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    n.a a = (n.a)view;
    if (this.u0)
      listMenuItemView.setForceShowIcon(true); 
    a.c(c(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */