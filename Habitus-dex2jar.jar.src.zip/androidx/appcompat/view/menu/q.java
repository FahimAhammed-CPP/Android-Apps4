package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.os.Parcelable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.d0;
import androidx.core.view.m0;
import g.d;
import g.g;

final class q extends k implements PopupWindow.OnDismissListener, View.OnKeyListener {
  private static final int N0 = g.abc_popup_menu_item_layout;
  
  final d0 A0;
  
  final ViewTreeObserver.OnGlobalLayoutListener B0 = new a(this);
  
  private final View.OnAttachStateChangeListener C0 = new b(this);
  
  private PopupWindow.OnDismissListener D0;
  
  private View E0;
  
  View F0;
  
  private m.a G0;
  
  ViewTreeObserver H0;
  
  private boolean I0;
  
  private boolean J0;
  
  private int K0;
  
  private int L0 = 0;
  
  private boolean M0;
  
  private final Context t0;
  
  private final g u0;
  
  private final f v0;
  
  private final boolean w0;
  
  private final int x0;
  
  private final int y0;
  
  private final int z0;
  
  public q(Context paramContext, g paramg, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.t0 = paramContext;
    this.u0 = paramg;
    this.w0 = paramBoolean;
    this.v0 = new f(paramg, LayoutInflater.from(paramContext), paramBoolean, N0);
    this.y0 = paramInt1;
    this.z0 = paramInt2;
    Resources resources = paramContext.getResources();
    this.x0 = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.abc_config_prefDialogWidth));
    this.E0 = paramView;
    this.A0 = new d0(paramContext, null, paramInt1, paramInt2);
    paramg.c(this, paramContext);
  }
  
  private boolean A() {
    if (a())
      return true; 
    if (!this.I0) {
      boolean bool;
      View view = this.E0;
      if (view == null)
        return false; 
      this.F0 = view;
      this.A0.J(this);
      this.A0.K(this);
      this.A0.I(true);
      view = this.F0;
      if (this.H0 == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.H0 = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.B0); 
      view.addOnAttachStateChangeListener(this.C0);
      this.A0.C(view);
      this.A0.F(this.L0);
      if (!this.J0) {
        this.K0 = k.p((ListAdapter)this.v0, null, this.t0, this.x0);
        this.J0 = true;
      } 
      this.A0.E(this.K0);
      this.A0.H(2);
      this.A0.G(n());
      this.A0.show();
      ListView listView = this.A0.o();
      listView.setOnKeyListener(this);
      if (this.M0 && this.u0.z() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.t0).inflate(g.abc_popup_menu_header_item_layout, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.u0.z()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.A0.m((ListAdapter)this.v0);
      this.A0.show();
      return true;
    } 
    return false;
  }
  
  public boolean a() {
    return (!this.I0 && this.A0.a());
  }
  
  public void b(g paramg, boolean paramBoolean) {
    if (paramg != this.u0)
      return; 
    dismiss();
    m.a a1 = this.G0;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public void d(m.a parama) {
    this.G0 = parama;
  }
  
  public void dismiss() {
    if (a())
      this.A0.dismiss(); 
  }
  
  public void e(Parcelable paramParcelable) {}
  
  public boolean f(r paramr) {
    if (paramr.hasVisibleItems()) {
      l l = new l(this.t0, paramr, this.F0, this.w0, this.y0, this.z0);
      l.j(this.G0);
      l.g(k.y(paramr));
      l.i(this.D0);
      this.D0 = null;
      this.u0.e(false);
      int j = this.A0.c();
      int m = this.A0.l();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.L0, m0.E(this.E0)) & 0x7) == 5)
        i = j + this.E0.getWidth(); 
      if (l.n(i, m)) {
        m.a a1 = this.G0;
        if (a1 != null)
          a1.c(paramr); 
        return true;
      } 
    } 
    return false;
  }
  
  public Parcelable g() {
    return null;
  }
  
  public void h(boolean paramBoolean) {
    this.J0 = false;
    f f1 = this.v0;
    if (f1 != null)
      f1.notifyDataSetChanged(); 
  }
  
  public boolean i() {
    return false;
  }
  
  public void l(g paramg) {}
  
  public ListView o() {
    return this.A0.o();
  }
  
  public void onDismiss() {
    this.I0 = true;
    this.u0.close();
    ViewTreeObserver viewTreeObserver = this.H0;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.H0 = this.F0.getViewTreeObserver(); 
      this.H0.removeGlobalOnLayoutListener(this.B0);
      this.H0 = null;
    } 
    this.F0.removeOnAttachStateChangeListener(this.C0);
    PopupWindow.OnDismissListener onDismissListener = this.D0;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void q(View paramView) {
    this.E0 = paramView;
  }
  
  public void s(boolean paramBoolean) {
    this.v0.d(paramBoolean);
  }
  
  public void show() {
    if (A())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void t(int paramInt) {
    this.L0 = paramInt;
  }
  
  public void u(int paramInt) {
    this.A0.e(paramInt);
  }
  
  public void v(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.D0 = paramOnDismissListener;
  }
  
  public void w(boolean paramBoolean) {
    this.M0 = paramBoolean;
  }
  
  public void x(int paramInt) {
    this.A0.i(paramInt);
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    a(q this$0) {}
    
    public void onGlobalLayout() {
      if (this.s0.a() && !this.s0.A0.A()) {
        View view = this.s0.F0;
        if (view == null || !view.isShown()) {
          this.s0.dismiss();
          return;
        } 
        this.s0.A0.show();
        return;
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    b(q this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.s0.H0;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.s0.H0 = param1View.getViewTreeObserver(); 
        q q1 = this.s0;
        q1.H0.removeGlobalOnLayoutListener(q1.B0);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\menu\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */