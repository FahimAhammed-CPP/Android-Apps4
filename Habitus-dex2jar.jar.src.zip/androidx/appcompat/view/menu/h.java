package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.c;
import g.g;

class h implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, m.a {
  private g s0;
  
  private c t0;
  
  e u0;
  
  private m.a v0;
  
  public h(g paramg) {
    this.s0 = paramg;
  }
  
  public void a() {
    c c1 = this.t0;
    if (c1 != null)
      c1.dismiss(); 
  }
  
  public void b(g paramg, boolean paramBoolean) {
    if (paramBoolean || paramg == this.s0)
      a(); 
    m.a a1 = this.v0;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public boolean c(g paramg) {
    m.a a1 = this.v0;
    return (a1 != null) ? a1.c(paramg) : false;
  }
  
  public void d(IBinder paramIBinder) {
    g g1 = this.s0;
    c.a a1 = new c.a(g1.w());
    e e1 = new e(a1.getContext(), g.abc_list_menu_item_layout);
    this.u0 = e1;
    e1.d(this);
    this.s0.b(this.u0);
    a1.a(this.u0.a(), this);
    View view = g1.A();
    if (view != null) {
      a1.c(view);
    } else {
      a1.d(g1.y()).setTitle(g1.z());
    } 
    a1.h(this);
    c c1 = a1.create();
    this.t0 = c1;
    c1.setOnDismissListener(this);
    WindowManager.LayoutParams layoutParams = this.t0.getWindow().getAttributes();
    layoutParams.type = 1003;
    if (paramIBinder != null)
      layoutParams.token = paramIBinder; 
    layoutParams.flags |= 0x20000;
    this.t0.show();
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.s0.N((MenuItem)this.u0.a().getItem(paramInt), 0);
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    this.u0.b(this.s0, true);
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 82 || paramInt == 4) {
      KeyEvent.DispatcherState dispatcherState;
      if (paramKeyEvent.getAction() == 0 && paramKeyEvent.getRepeatCount() == 0) {
        Window window = this.t0.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            dispatcherState = view.getKeyDispatcherState();
            if (dispatcherState != null) {
              dispatcherState.startTracking(paramKeyEvent, this);
              return true;
            } 
          } 
        } 
      } else if (paramKeyEvent.getAction() == 1 && !paramKeyEvent.isCanceled()) {
        Window window = this.t0.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            KeyEvent.DispatcherState dispatcherState1 = view.getKeyDispatcherState();
            if (dispatcherState1 != null && dispatcherState1.isTracking(paramKeyEvent)) {
              this.s0.e(true);
              dispatcherState.dismiss();
              return true;
            } 
          } 
        } 
      } 
    } 
    return this.s0.performShortcut(paramInt, paramKeyEvent, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\menu\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */