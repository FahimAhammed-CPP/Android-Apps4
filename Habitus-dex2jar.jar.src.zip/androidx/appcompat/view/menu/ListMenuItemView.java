package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.p0;
import androidx.core.view.m0;
import g.a;
import g.f;
import g.g;
import g.j;

public class ListMenuItemView extends LinearLayout implements n.a, AbsListView.SelectionBoundsAdjuster {
  private LinearLayout A0;
  
  private Drawable B0;
  
  private int C0;
  
  private Context D0;
  
  private boolean E0;
  
  private Drawable F0;
  
  private boolean G0;
  
  private LayoutInflater H0;
  
  private boolean I0;
  
  private i s0;
  
  private ImageView t0;
  
  private RadioButton u0;
  
  private TextView v0;
  
  private CheckBox w0;
  
  private TextView x0;
  
  private ImageView y0;
  
  private ImageView z0;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.listMenuViewStyle);
  }
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    p0 p0 = p0.v(getContext(), paramAttributeSet, j.MenuView, paramInt, 0);
    this.B0 = p0.g(j.MenuView_android_itemBackground);
    this.C0 = p0.n(j.MenuView_android_itemTextAppearance, -1);
    this.E0 = p0.a(j.MenuView_preserveIconSpacing, false);
    this.D0 = paramContext;
    this.F0 = p0.g(j.MenuView_subMenuArrow);
    Resources.Theme theme = paramContext.getTheme();
    paramInt = a.dropDownListViewStyle;
    TypedArray typedArray = theme.obtainStyledAttributes(null, new int[] { 16843049 }, paramInt, 0);
    this.G0 = typedArray.hasValue(0);
    p0.w();
    typedArray.recycle();
  }
  
  private void a(View paramView) {
    b(paramView, -1);
  }
  
  private void b(View paramView, int paramInt) {
    LinearLayout linearLayout = this.A0;
    if (linearLayout != null) {
      linearLayout.addView(paramView, paramInt);
      return;
    } 
    addView(paramView, paramInt);
  }
  
  private void e() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(g.abc_list_menu_item_checkbox, (ViewGroup)this, false);
    this.w0 = checkBox;
    a((View)checkBox);
  }
  
  private void f() {
    ImageView imageView = (ImageView)getInflater().inflate(g.abc_list_menu_item_icon, (ViewGroup)this, false);
    this.t0 = imageView;
    b((View)imageView, 0);
  }
  
  private void g() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(g.abc_list_menu_item_radio, (ViewGroup)this, false);
    this.u0 = radioButton;
    a((View)radioButton);
  }
  
  private LayoutInflater getInflater() {
    if (this.H0 == null)
      this.H0 = LayoutInflater.from(getContext()); 
    return this.H0;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.y0;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.z0;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.z0.getLayoutParams();
      paramRect.top += this.z0.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    } 
  }
  
  public void c(i parami, int paramInt) {
    this.s0 = parami;
    if (parami.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(parami.i(this));
    setCheckable(parami.isCheckable());
    h(parami.A(), parami.g());
    setIcon(parami.getIcon());
    setEnabled(parami.isEnabled());
    setSubMenuArrowVisible(parami.hasSubMenu());
    setContentDescription(parami.getContentDescription());
  }
  
  public boolean d() {
    return false;
  }
  
  public i getItemData() {
    return this.s0;
  }
  
  public void h(boolean paramBoolean, char paramChar) {
    if (paramBoolean && this.s0.A()) {
      paramChar = Character.MIN_VALUE;
    } else {
      paramChar = '\b';
    } 
    if (paramChar == '\000')
      this.x0.setText(this.s0.h()); 
    if (this.x0.getVisibility() != paramChar)
      this.x0.setVisibility(paramChar); 
  }
  
  protected void onFinishInflate() {
    super.onFinishInflate();
    m0.w0((View)this, this.B0);
    TextView textView = (TextView)findViewById(f.title);
    this.v0 = textView;
    int j = this.C0;
    if (j != -1)
      textView.setTextAppearance(this.D0, j); 
    this.x0 = (TextView)findViewById(f.shortcut);
    ImageView imageView = (ImageView)findViewById(f.submenuarrow);
    this.y0 = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.F0); 
    this.z0 = (ImageView)findViewById(f.group_divider);
    this.A0 = (LinearLayout)findViewById(f.content);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.t0 != null && this.E0) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.t0.getLayoutParams();
      int j = layoutParams.height;
      if (j > 0 && layoutParams1.width <= 0)
        layoutParams1.width = j; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.u0 == null && this.w0 == null)
      return; 
    if (this.s0.m()) {
      if (this.u0 == null)
        g(); 
      RadioButton radioButton1 = this.u0;
      CheckBox checkBox1 = this.w0;
    } else {
      if (this.w0 == null)
        e(); 
      checkBox = this.w0;
      radioButton = this.u0;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.s0.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.w0;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.u0;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.s0.m()) {
      if (this.u0 == null)
        g(); 
      RadioButton radioButton = this.u0;
    } else {
      if (this.w0 == null)
        e(); 
      checkBox = this.w0;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.I0 = paramBoolean;
    this.E0 = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.z0;
    if (imageView != null) {
      byte b;
      if (!this.G0 && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    if (this.s0.z() || this.I0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.E0)
      return; 
    ImageView imageView = this.t0;
    if (imageView == null && paramDrawable == null && !this.E0)
      return; 
    if (imageView == null)
      f(); 
    if (paramDrawable != null || this.E0) {
      imageView = this.t0;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.t0.getVisibility() != 0)
        this.t0.setVisibility(0); 
      return;
    } 
    this.t0.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.v0.setText(paramCharSequence);
      if (this.v0.getVisibility() != 0) {
        this.v0.setVisibility(0);
        return;
      } 
    } else if (this.v0.getVisibility() != 8) {
      this.v0.setVisibility(8);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */