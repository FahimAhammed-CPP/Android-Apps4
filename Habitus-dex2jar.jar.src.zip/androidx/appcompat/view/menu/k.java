package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;

abstract class k implements p, m, AdapterView.OnItemClickListener {
  private Rect s0;
  
  protected static int p(ListAdapter paramListAdapter, ViewGroup paramViewGroup, Context paramContext, int paramInt) {
    int i = 0;
    int i1 = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i2 = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i3 = paramListAdapter.getCount();
    ViewGroup viewGroup2 = null;
    int j = 0;
    int n = 0;
    ViewGroup viewGroup1 = paramViewGroup;
    paramViewGroup = viewGroup2;
    while (i < i3) {
      FrameLayout frameLayout2;
      int i5 = paramListAdapter.getItemViewType(i);
      int i4 = n;
      if (i5 != n) {
        paramViewGroup = null;
        i4 = i5;
      } 
      viewGroup2 = viewGroup1;
      if (viewGroup1 == null)
        frameLayout2 = new FrameLayout(paramContext); 
      View view = paramListAdapter.getView(i, (View)paramViewGroup, (ViewGroup)frameLayout2);
      view.measure(i1, i2);
      i5 = view.getMeasuredWidth();
      if (i5 >= paramInt)
        return paramInt; 
      n = j;
      if (i5 > j)
        n = i5; 
      i++;
      j = n;
      n = i4;
      FrameLayout frameLayout1 = frameLayout2;
    } 
    return j;
  }
  
  protected static boolean y(g paramg) {
    int j = paramg.size();
    for (int i = 0; i < j; i++) {
      MenuItem menuItem = paramg.getItem(i);
      if (menuItem.isVisible() && menuItem.getIcon() != null)
        return true; 
    } 
    return false;
  }
  
  protected static f z(ListAdapter paramListAdapter) {
    return (paramListAdapter instanceof HeaderViewListAdapter) ? (f)((HeaderViewListAdapter)paramListAdapter).getWrappedAdapter() : (f)paramListAdapter;
  }
  
  public boolean c(g paramg, i parami) {
    return false;
  }
  
  public int getId() {
    return 0;
  }
  
  public boolean j(g paramg, i parami) {
    return false;
  }
  
  public void k(Context paramContext, g paramg) {}
  
  public abstract void l(g paramg);
  
  protected boolean m() {
    return true;
  }
  
  public Rect n() {
    return this.s0;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ListAdapter listAdapter = (ListAdapter)paramAdapterView.getAdapter();
    g g = (z(listAdapter)).s0;
    MenuItem menuItem = (MenuItem)listAdapter.getItem(paramInt);
    if (m()) {
      paramInt = 0;
    } else {
      paramInt = 4;
    } 
    g.O(menuItem, this, paramInt);
  }
  
  public abstract void q(View paramView);
  
  public void r(Rect paramRect) {
    this.s0 = paramRect;
  }
  
  public abstract void s(boolean paramBoolean);
  
  public abstract void t(int paramInt);
  
  public abstract void u(int paramInt);
  
  public abstract void v(PopupWindow.OnDismissListener paramOnDismissListener);
  
  public abstract void w(boolean paramBoolean);
  
  public abstract void x(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\menu\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */