package androidx.appcompat.view;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

public class e extends b implements g.a {
  private g A0;
  
  private Context u0;
  
  private ActionBarContextView v0;
  
  private b.a w0;
  
  private WeakReference<View> x0;
  
  private boolean y0;
  
  private boolean z0;
  
  public e(Context paramContext, ActionBarContextView paramActionBarContextView, b.a parama, boolean paramBoolean) {
    this.u0 = paramContext;
    this.v0 = paramActionBarContextView;
    this.w0 = parama;
    g g1 = (new g(paramActionBarContextView.getContext())).W(1);
    this.A0 = g1;
    g1.V(this);
    this.z0 = paramBoolean;
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    return this.w0.c(this, paramMenuItem);
  }
  
  public void b(g paramg) {
    k();
    this.v0.l();
  }
  
  public void c() {
    if (this.y0)
      return; 
    this.y0 = true;
    this.w0.a(this);
  }
  
  public View d() {
    WeakReference<View> weakReference = this.x0;
    return (weakReference != null) ? weakReference.get() : null;
  }
  
  public Menu e() {
    return (Menu)this.A0;
  }
  
  public MenuInflater f() {
    return new g(this.v0.getContext());
  }
  
  public CharSequence g() {
    return this.v0.getSubtitle();
  }
  
  public CharSequence i() {
    return this.v0.getTitle();
  }
  
  public void k() {
    this.w0.d(this, (Menu)this.A0);
  }
  
  public boolean l() {
    return this.v0.j();
  }
  
  public void m(View paramView) {
    this.v0.setCustomView(paramView);
    if (paramView != null) {
      WeakReference<View> weakReference = new WeakReference<View>(paramView);
    } else {
      paramView = null;
    } 
    this.x0 = (WeakReference<View>)paramView;
  }
  
  public void n(int paramInt) {
    o(this.u0.getString(paramInt));
  }
  
  public void o(CharSequence paramCharSequence) {
    this.v0.setSubtitle(paramCharSequence);
  }
  
  public void q(int paramInt) {
    r(this.u0.getString(paramInt));
  }
  
  public void r(CharSequence paramCharSequence) {
    this.v0.setTitle(paramCharSequence);
  }
  
  public void s(boolean paramBoolean) {
    super.s(paramBoolean);
    this.v0.setTitleOptional(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\view\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */