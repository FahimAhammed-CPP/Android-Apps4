package androidx.appcompat.app;

import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.Executor;

class c0 {
  static void a(Context paramContext, String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ldc ''
    //   3: invokevirtual equals : (Ljava/lang/Object;)Z
    //   6: ifeq -> 17
    //   9: aload_0
    //   10: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   12: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   15: pop
    //   16: return
    //   17: aload_0
    //   18: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   20: iconst_0
    //   21: invokevirtual openFileOutput : (Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   24: astore_0
    //   25: invokestatic newSerializer : ()Lorg/xmlpull/v1/XmlSerializer;
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aconst_null
    //   32: invokeinterface setOutput : (Ljava/io/OutputStream;Ljava/lang/String;)V
    //   37: aload_2
    //   38: ldc 'UTF-8'
    //   40: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   43: invokeinterface startDocument : (Ljava/lang/String;Ljava/lang/Boolean;)V
    //   48: aload_2
    //   49: aconst_null
    //   50: ldc 'locales'
    //   52: invokeinterface startTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   57: pop
    //   58: aload_2
    //   59: aconst_null
    //   60: ldc 'application_locales'
    //   62: aload_1
    //   63: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   68: pop
    //   69: aload_2
    //   70: aconst_null
    //   71: ldc 'locales'
    //   73: invokeinterface endTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   78: pop
    //   79: aload_2
    //   80: invokeinterface endDocument : ()V
    //   85: new java/lang/StringBuilder
    //   88: dup
    //   89: invokespecial <init> : ()V
    //   92: astore_2
    //   93: aload_2
    //   94: ldc 'Storing App Locales : app-locales: '
    //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: pop
    //   100: aload_2
    //   101: aload_1
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: aload_2
    //   107: ldc ' persisted successfully.'
    //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: pop
    //   113: aload_0
    //   114: ifnull -> 166
    //   117: aload_0
    //   118: invokevirtual close : ()V
    //   121: return
    //   122: astore_1
    //   123: goto -> 167
    //   126: astore_2
    //   127: new java/lang/StringBuilder
    //   130: dup
    //   131: invokespecial <init> : ()V
    //   134: astore_3
    //   135: aload_3
    //   136: ldc 'Storing App Locales : Failed to persist app-locales: '
    //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   141: pop
    //   142: aload_3
    //   143: aload_1
    //   144: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   147: pop
    //   148: ldc 'AppLocalesStorageHelper'
    //   150: aload_3
    //   151: invokevirtual toString : ()Ljava/lang/String;
    //   154: aload_2
    //   155: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   158: pop
    //   159: aload_0
    //   160: ifnull -> 166
    //   163: goto -> 117
    //   166: return
    //   167: aload_0
    //   168: ifnull -> 175
    //   171: aload_0
    //   172: invokevirtual close : ()V
    //   175: aload_1
    //   176: athrow
    //   177: ldc 'AppLocalesStorageHelper'
    //   179: ldc 'Storing App Locales : FileNotFoundException: Cannot open file %s for writing '
    //   181: iconst_1
    //   182: anewarray java/lang/Object
    //   185: dup
    //   186: iconst_0
    //   187: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   189: aastore
    //   190: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   193: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   196: pop
    //   197: return
    //   198: astore_0
    //   199: goto -> 177
    //   202: astore_0
    //   203: return
    //   204: astore_0
    //   205: goto -> 175
    // Exception table:
    //   from	to	target	type
    //   17	25	198	java/io/FileNotFoundException
    //   29	113	126	java/lang/Exception
    //   29	113	122	finally
    //   117	121	202	java/io/IOException
    //   127	159	122	finally
    //   171	175	204	java/io/IOException
  }
  
  static String b(Context paramContext) {
    // Byte code:
    //   0: ldc ''
    //   2: astore #4
    //   4: aload_0
    //   5: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   7: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   10: astore #6
    //   12: invokestatic newPullParser : ()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore #5
    //   17: aload #5
    //   19: aload #6
    //   21: ldc 'UTF-8'
    //   23: invokeinterface setInput : (Ljava/io/InputStream;Ljava/lang/String;)V
    //   28: aload #5
    //   30: invokeinterface getDepth : ()I
    //   35: istore_1
    //   36: aload #5
    //   38: invokeinterface next : ()I
    //   43: istore_2
    //   44: aload #4
    //   46: astore_3
    //   47: iload_2
    //   48: iconst_1
    //   49: if_icmpeq -> 100
    //   52: iload_2
    //   53: iconst_3
    //   54: if_icmpne -> 235
    //   57: aload #4
    //   59: astore_3
    //   60: aload #5
    //   62: invokeinterface getDepth : ()I
    //   67: iload_1
    //   68: if_icmple -> 100
    //   71: goto -> 235
    //   74: aload #5
    //   76: invokeinterface getName : ()Ljava/lang/String;
    //   81: ldc 'locales'
    //   83: invokevirtual equals : (Ljava/lang/Object;)Z
    //   86: ifeq -> 36
    //   89: aload #5
    //   91: aconst_null
    //   92: ldc 'application_locales'
    //   94: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   99: astore_3
    //   100: aload_3
    //   101: astore #5
    //   103: aload #6
    //   105: ifnull -> 152
    //   108: aload #6
    //   110: invokevirtual close : ()V
    //   113: aload_3
    //   114: astore #5
    //   116: goto -> 152
    //   119: aload_3
    //   120: astore #5
    //   122: goto -> 152
    //   125: astore_0
    //   126: goto -> 195
    //   129: ldc 'AppLocalesStorageHelper'
    //   131: ldc 'Reading app Locales : Unable to parse through file :androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   133: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   136: pop
    //   137: aload #4
    //   139: astore #5
    //   141: aload #6
    //   143: ifnull -> 152
    //   146: aload #4
    //   148: astore_3
    //   149: goto -> 108
    //   152: aload #5
    //   154: invokevirtual isEmpty : ()Z
    //   157: ifne -> 185
    //   160: new java/lang/StringBuilder
    //   163: dup
    //   164: invokespecial <init> : ()V
    //   167: astore_0
    //   168: aload_0
    //   169: ldc 'Reading app Locales : Locales read from file: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file , appLocales: '
    //   171: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   174: pop
    //   175: aload_0
    //   176: aload #5
    //   178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: pop
    //   182: aload #5
    //   184: areturn
    //   185: aload_0
    //   186: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   188: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   191: pop
    //   192: aload #5
    //   194: areturn
    //   195: aload #6
    //   197: ifnull -> 205
    //   200: aload #6
    //   202: invokevirtual close : ()V
    //   205: aload_0
    //   206: athrow
    //   207: ldc 'AppLocalesStorageHelper'
    //   209: ldc 'Reading app Locales : Locales record file not found: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   211: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   214: pop
    //   215: ldc ''
    //   217: areturn
    //   218: astore_0
    //   219: goto -> 207
    //   222: astore_3
    //   223: goto -> 129
    //   226: astore #4
    //   228: goto -> 119
    //   231: astore_3
    //   232: goto -> 205
    //   235: iload_2
    //   236: iconst_3
    //   237: if_icmpeq -> 36
    //   240: iload_2
    //   241: iconst_4
    //   242: if_icmpne -> 74
    //   245: goto -> 36
    // Exception table:
    //   from	to	target	type
    //   4	12	218	java/io/FileNotFoundException
    //   12	36	222	org/xmlpull/v1/XmlPullParserException
    //   12	36	222	java/io/IOException
    //   12	36	125	finally
    //   36	44	222	org/xmlpull/v1/XmlPullParserException
    //   36	44	222	java/io/IOException
    //   36	44	125	finally
    //   60	71	222	org/xmlpull/v1/XmlPullParserException
    //   60	71	222	java/io/IOException
    //   60	71	125	finally
    //   74	100	222	org/xmlpull/v1/XmlPullParserException
    //   74	100	222	java/io/IOException
    //   74	100	125	finally
    //   108	113	226	java/io/IOException
    //   129	137	125	finally
    //   200	205	231	java/io/IOException
  }
  
  static void c(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 33) {
      ComponentName componentName = new ComponentName(paramContext, "androidx.appcompat.app.AppLocalesMetadataHolderService");
      if (paramContext.getPackageManager().getComponentEnabledSetting(componentName) != 1) {
        if (g.m().f()) {
          String str = b(paramContext);
          Object object = paramContext.getSystemService("locale");
          if (object != null)
            g.b.b(object, g.a.a(str)); 
        } 
        paramContext.getPackageManager().setComponentEnabledSetting(componentName, 1, 1);
      } 
    } 
  }
  
  static class a implements Executor {
    private final Object s0 = new Object();
    
    final Queue<Runnable> t0 = new ArrayDeque<Runnable>();
    
    final Executor u0;
    
    Runnable v0;
    
    a(Executor param1Executor) {
      this.u0 = param1Executor;
    }
    
    protected void c() {
      synchronized (this.s0) {
        Runnable runnable = this.t0.poll();
        this.v0 = runnable;
        if (runnable != null)
          this.u0.execute(runnable); 
        return;
      } 
    }
    
    public void execute(Runnable param1Runnable) {
      synchronized (this.s0) {
        this.t0.add(new b0(this, param1Runnable));
        if (this.v0 == null)
          c(); 
        return;
      } 
    }
  }
  
  static class b implements Executor {
    public void execute(Runnable param1Runnable) {
      (new Thread(param1Runnable)).start();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */