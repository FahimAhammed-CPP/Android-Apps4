package androidx.appcompat.app;

import androidx.core.os.i;
import java.util.LinkedHashSet;
import java.util.Locale;

final class e0 {
  private static i a(i parami1, i parami2) {
    LinkedHashSet<Locale> linkedHashSet = new LinkedHashSet();
    for (int j = 0; j < parami1.g() + parami2.g(); j++) {
      Locale locale;
      if (j < parami1.g()) {
        locale = parami1.d(j);
      } else {
        locale = parami2.d(j - parami1.g());
      } 
      if (locale != null)
        linkedHashSet.add(locale); 
    } 
    return i.a(linkedHashSet.<Locale>toArray(new Locale[linkedHashSet.size()]));
  }
  
  static i b(i parami1, i parami2) {
    return (parami1 == null || parami1.f()) ? i.e() : a(parami1, parami2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */