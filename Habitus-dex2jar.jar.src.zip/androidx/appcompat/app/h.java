package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.a1;
import androidx.appcompat.widget.p0;
import androidx.appcompat.widget.w;
import androidx.appcompat.widget.z0;
import androidx.core.view.e0;
import androidx.core.view.m0;
import androidx.core.view.m1;
import androidx.core.view.u0;
import androidx.core.view.v0;
import androidx.core.view.w0;
import j$.util.Objects;
import java.util.List;
import java.util.Locale;
import org.xmlpull.v1.XmlPullParser;

class h extends g implements g.a, LayoutInflater.Factory2 {
  private static final androidx.collection.g<String, Integer> B1 = new androidx.collection.g();
  
  private static final boolean C1 = false;
  
  private static final int[] D1 = new int[] { 16842836 };
  
  private static final boolean E1 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  private static final boolean F1 = true;
  
  private OnBackInvokedCallback A1;
  
  final Object B0;
  
  final Context C0;
  
  Window D0;
  
  private o E0;
  
  final e F0;
  
  a G0;
  
  MenuInflater H0;
  
  private CharSequence I0;
  
  private w J0;
  
  private h K0;
  
  private v L0;
  
  androidx.appcompat.view.b M0;
  
  ActionBarContextView N0;
  
  PopupWindow O0;
  
  Runnable P0;
  
  u0 Q0 = null;
  
  private boolean R0 = true;
  
  private boolean S0;
  
  ViewGroup T0;
  
  private TextView U0;
  
  private View V0;
  
  private boolean W0;
  
  private boolean X0;
  
  boolean Y0;
  
  boolean Z0;
  
  boolean a1;
  
  boolean b1;
  
  boolean c1;
  
  private boolean d1;
  
  private u[] e1;
  
  private u f1;
  
  private boolean g1;
  
  private boolean h1;
  
  private boolean i1;
  
  boolean j1;
  
  private Configuration k1;
  
  private int l1 = -100;
  
  private int m1;
  
  private int n1;
  
  private boolean o1;
  
  private q p1;
  
  private q q1;
  
  boolean r1;
  
  int s1;
  
  private final Runnable t1 = new a(this);
  
  private boolean u1;
  
  private Rect v1;
  
  private Rect w1;
  
  private z x1;
  
  private d0 y1;
  
  private OnBackInvokedDispatcher z1;
  
  h(Activity paramActivity, e parame) {
    this((Context)paramActivity, null, parame, paramActivity);
  }
  
  h(Dialog paramDialog, e parame) {
    this(paramDialog.getContext(), paramDialog.getWindow(), parame, paramDialog);
  }
  
  private h(Context paramContext, Window paramWindow, e parame, Object paramObject) {
    this.C0 = paramContext;
    this.F0 = parame;
    this.B0 = paramObject;
    if (this.l1 == -100 && paramObject instanceof Dialog) {
      d d = c1();
      if (d != null)
        this.l1 = d.getDelegate().q(); 
    } 
    if (this.l1 == -100) {
      androidx.collection.g<String, Integer> g1 = B1;
      Integer integer = (Integer)g1.get(paramObject.getClass().getName());
      if (integer != null) {
        this.l1 = integer.intValue();
        g1.remove(paramObject.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      Y(paramWindow); 
    androidx.appcompat.widget.g.h();
  }
  
  private boolean A0(u paramu) {
    View view = paramu.i;
    if (view != null) {
      paramu.h = view;
      return true;
    } 
    if (paramu.j == null)
      return false; 
    if (this.L0 == null)
      this.L0 = new v(this); 
    view = (View)paramu.a(this.L0);
    paramu.h = view;
    return (view != null);
  }
  
  private boolean B0(u paramu) {
    paramu.d(r0());
    paramu.g = (ViewGroup)new t(this, paramu.l);
    paramu.c = 81;
    return true;
  }
  
  private boolean C0(u paramu) {
    // Byte code:
    //   0: aload_0
    //   1: getfield C0 : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield J0 : Landroidx/appcompat/widget/w;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #6
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #7
    //   50: aload #7
    //   52: getstatic g/a.actionBarTheme : I
    //   55: aload #6
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aload #6
    //   64: getfield resourceId : I
    //   67: ifeq -> 109
    //   70: aload #5
    //   72: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   75: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   78: astore_3
    //   79: aload_3
    //   80: aload #7
    //   82: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   85: aload_3
    //   86: aload #6
    //   88: getfield resourceId : I
    //   91: iconst_1
    //   92: invokevirtual applyStyle : (IZ)V
    //   95: aload_3
    //   96: getstatic g/a.actionBarWidgetTheme : I
    //   99: aload #6
    //   101: iconst_1
    //   102: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   105: pop
    //   106: goto -> 123
    //   109: aload #7
    //   111: getstatic g/a.actionBarWidgetTheme : I
    //   114: aload #6
    //   116: iconst_1
    //   117: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   120: pop
    //   121: aconst_null
    //   122: astore_3
    //   123: aload_3
    //   124: astore #4
    //   126: aload #6
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #7
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #6
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new androidx/appcompat/view/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new androidx/appcompat/view/menu/g
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual V : (Landroidx/appcompat/view/menu/g$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Landroidx/appcompat/view/menu/g;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  private void D0(int paramInt) {
    this.s1 = 1 << paramInt | this.s1;
    if (!this.r1) {
      m0.k0(this.D0.getDecorView(), this.t1);
      this.r1 = true;
    } 
  }
  
  private boolean I0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      u u1 = w0(paramInt, true);
      if (!u1.o)
        return S0(u1, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean L0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield M0 : Landroidx/appcompat/view/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual w0 : (IZ)Landroidx/appcompat/app/h$u;
    //   18: astore #5
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield J0 : Landroidx/appcompat/widget/w;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 113
    //   35: aload #6
    //   37: invokeinterface a : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield C0 : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield J0 : Landroidx/appcompat/widget/w;
    //   62: invokeinterface e : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield j1 : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #5
    //   80: aload_2
    //   81: invokespecial S0 : (Landroidx/appcompat/app/h$u;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield J0 : Landroidx/appcompat/widget/w;
    //   91: invokeinterface c : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield J0 : Landroidx/appcompat/widget/w;
    //   104: invokeinterface b : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #5
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #5
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #5
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #5
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #5
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #5
    //   159: aload_2
    //   160: invokespecial S0 : (Landroidx/appcompat/app/h$u;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #5
    //   176: aload_2
    //   177: invokespecial P0 : (Landroidx/appcompat/app/h$u;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #5
    //   194: iconst_1
    //   195: invokevirtual f0 : (Landroidx/appcompat/app/h$u;Z)V
    //   198: iload_3
    //   199: ifeq -> 240
    //   202: aload_0
    //   203: getfield C0 : Landroid/content/Context;
    //   206: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   209: ldc_w 'audio'
    //   212: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   215: checkcast android/media/AudioManager
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 230
    //   223: aload_2
    //   224: iconst_0
    //   225: invokevirtual playSoundEffect : (I)V
    //   228: iload_3
    //   229: ireturn
    //   230: ldc_w 'AppCompatDelegate'
    //   233: ldc_w 'Couldn't get audio manager'
    //   236: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: iload_3
    //   241: ireturn
  }
  
  private void P0(u paramu, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 416
    //   7: aload_0
    //   8: getfield j1 : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield C0 : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual y0 : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Landroidx/appcompat/view/menu/g;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual f0 : (Landroidx/appcompat/app/h$u;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield C0 : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokespecial S0 : (Landroidx/appcompat/app/h$u;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield q : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield i : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 331
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 331
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 331
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 334
    //   171: aload_2
    //   172: ifnonnull -> 191
    //   175: aload_0
    //   176: aload_1
    //   177: invokespecial B0 : (Landroidx/appcompat/app/h$u;)Z
    //   180: ifeq -> 190
    //   183: aload_1
    //   184: getfield g : Landroid/view/ViewGroup;
    //   187: ifnonnull -> 212
    //   190: return
    //   191: aload_1
    //   192: getfield q : Z
    //   195: ifeq -> 212
    //   198: aload_2
    //   199: invokevirtual getChildCount : ()I
    //   202: ifle -> 212
    //   205: aload_1
    //   206: getfield g : Landroid/view/ViewGroup;
    //   209: invokevirtual removeAllViews : ()V
    //   212: aload_0
    //   213: aload_1
    //   214: invokespecial A0 : (Landroidx/appcompat/app/h$u;)Z
    //   217: ifeq -> 411
    //   220: aload_1
    //   221: invokevirtual b : ()Z
    //   224: ifne -> 230
    //   227: goto -> 411
    //   230: aload_1
    //   231: getfield h : Landroid/view/View;
    //   234: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   237: astore #4
    //   239: aload #4
    //   241: astore_2
    //   242: aload #4
    //   244: ifnonnull -> 259
    //   247: new android/view/ViewGroup$LayoutParams
    //   250: dup
    //   251: bipush #-2
    //   253: bipush #-2
    //   255: invokespecial <init> : (II)V
    //   258: astore_2
    //   259: aload_1
    //   260: getfield b : I
    //   263: istore_3
    //   264: aload_1
    //   265: getfield g : Landroid/view/ViewGroup;
    //   268: iload_3
    //   269: invokevirtual setBackgroundResource : (I)V
    //   272: aload_1
    //   273: getfield h : Landroid/view/View;
    //   276: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   279: astore #4
    //   281: aload #4
    //   283: instanceof android/view/ViewGroup
    //   286: ifeq -> 301
    //   289: aload #4
    //   291: checkcast android/view/ViewGroup
    //   294: aload_1
    //   295: getfield h : Landroid/view/View;
    //   298: invokevirtual removeView : (Landroid/view/View;)V
    //   301: aload_1
    //   302: getfield g : Landroid/view/ViewGroup;
    //   305: aload_1
    //   306: getfield h : Landroid/view/View;
    //   309: aload_2
    //   310: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   313: aload_1
    //   314: getfield h : Landroid/view/View;
    //   317: invokevirtual hasFocus : ()Z
    //   320: ifne -> 331
    //   323: aload_1
    //   324: getfield h : Landroid/view/View;
    //   327: invokevirtual requestFocus : ()Z
    //   330: pop
    //   331: bipush #-2
    //   333: istore_3
    //   334: aload_1
    //   335: iconst_0
    //   336: putfield n : Z
    //   339: new android/view/WindowManager$LayoutParams
    //   342: dup
    //   343: iload_3
    //   344: bipush #-2
    //   346: aload_1
    //   347: getfield d : I
    //   350: aload_1
    //   351: getfield e : I
    //   354: sipush #1002
    //   357: ldc_w 8519680
    //   360: bipush #-3
    //   362: invokespecial <init> : (IIIIIII)V
    //   365: astore_2
    //   366: aload_2
    //   367: aload_1
    //   368: getfield c : I
    //   371: putfield gravity : I
    //   374: aload_2
    //   375: aload_1
    //   376: getfield f : I
    //   379: putfield windowAnimations : I
    //   382: aload #5
    //   384: aload_1
    //   385: getfield g : Landroid/view/ViewGroup;
    //   388: aload_2
    //   389: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   394: aload_1
    //   395: iconst_1
    //   396: putfield o : Z
    //   399: aload_1
    //   400: getfield a : I
    //   403: ifne -> 410
    //   406: aload_0
    //   407: invokevirtual f1 : ()V
    //   410: return
    //   411: aload_1
    //   412: iconst_1
    //   413: putfield q : Z
    //   416: return
  }
  
  private boolean R0(u paramu, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokespecial S0 : (Landroidx/appcompat/app/h$u;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Landroidx/appcompat/view/menu/g;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield J0 : Landroidx/appcompat/widget/w;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual f0 : (Landroidx/appcompat/app/h$u;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  private boolean S0(u paramu, KeyEvent paramKeyEvent) {
    w w1;
    if (this.j1)
      return false; 
    if (paramu.m)
      return true; 
    u u1 = this.f1;
    if (u1 != null && u1 != paramu)
      f0(u1, false); 
    Window.Callback callback = y0();
    if (callback != null)
      paramu.i = callback.onCreatePanelView(paramu.a); 
    int i = paramu.a;
    if (i == 0 || i == 108) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      w w2 = this.J0;
      if (w2 != null)
        w2.f(); 
    } 
    if (paramu.i == null && (i == 0 || !(Q0() instanceof g0))) {
      w w2;
      boolean bool;
      g g1 = paramu.j;
      if (g1 == null || paramu.r) {
        if (g1 == null && (!C0(paramu) || paramu.j == null))
          return false; 
        if (i != 0 && this.J0 != null) {
          if (this.K0 == null)
            this.K0 = new h(this); 
          this.J0.d((Menu)paramu.j, this.K0);
        } 
        paramu.j.h0();
        if (!callback.onCreatePanelMenu(paramu.a, (Menu)paramu.j)) {
          paramu.c(null);
          if (i != 0) {
            w1 = this.J0;
            if (w1 != null)
              w1.d(null, this.K0); 
          } 
          return false;
        } 
        ((u)w1).r = false;
      } 
      ((u)w1).j.h0();
      Bundle bundle = ((u)w1).s;
      if (bundle != null) {
        ((u)w1).j.R(bundle);
        ((u)w1).s = null;
      } 
      if (!callback.onPreparePanel(0, ((u)w1).i, (Menu)((u)w1).j)) {
        if (i != 0) {
          w2 = this.J0;
          if (w2 != null)
            w2.d(null, this.K0); 
        } 
        ((u)w1).j.g0();
        return false;
      } 
      if (w2 != null) {
        i = w2.getDeviceId();
      } else {
        i = -1;
      } 
      if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((u)w1).p = bool;
      ((u)w1).j.setQwertyMode(bool);
      ((u)w1).j.g0();
    } 
    ((u)w1).m = true;
    ((u)w1).n = false;
    this.f1 = (u)w1;
    return true;
  }
  
  private void T0(boolean paramBoolean) {
    w w1 = this.J0;
    if (w1 != null && w1.a() && (!ViewConfiguration.get(this.C0).hasPermanentMenuKey() || this.J0.g())) {
      Window.Callback callback = y0();
      if (!this.J0.e() || !paramBoolean) {
        if (callback != null && !this.j1) {
          if (this.r1 && (this.s1 & 0x1) != 0) {
            this.D0.getDecorView().removeCallbacks(this.t1);
            this.t1.run();
          } 
          u u2 = w0(0, true);
          g g1 = u2.j;
          if (g1 != null && !u2.r && callback.onPreparePanel(0, u2.i, (Menu)g1)) {
            callback.onMenuOpened(108, (Menu)u2.j);
            this.J0.c();
          } 
        } 
        return;
      } 
      this.J0.b();
      if (!this.j1) {
        callback.onPanelClosed(108, (Menu)(w0(0, true)).j);
        return;
      } 
      return;
    } 
    u u1 = w0(0, true);
    u1.q = true;
    f0(u1, false);
    P0(u1, null);
  }
  
  private int U0(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    int i = paramInt;
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      i = 109;
    } 
    return i;
  }
  
  private boolean V(boolean paramBoolean) {
    return W(paramBoolean, true);
  }
  
  private boolean W(boolean paramBoolean1, boolean paramBoolean2) {
    androidx.core.os.i i1;
    if (this.j1)
      return false; 
    int i = a0();
    int j = F0(this.C0, i);
    if (Build.VERSION.SDK_INT < 33) {
      i1 = Z(this.C0);
    } else {
      i1 = null;
    } 
    androidx.core.os.i i2 = i1;
    if (!paramBoolean2) {
      i2 = i1;
      if (i1 != null)
        i2 = v0(this.C0.getResources().getConfiguration()); 
    } 
    paramBoolean1 = e1(j, i2, paramBoolean1);
    if (i == 0) {
      u0(this.C0).e();
    } else {
      q q2 = this.p1;
      if (q2 != null)
        q2.a(); 
    } 
    if (i == 3) {
      t0(this.C0).e();
      return paramBoolean1;
    } 
    q q1 = this.q1;
    if (q1 != null)
      q1.a(); 
    return paramBoolean1;
  }
  
  private void X() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.T0.findViewById(16908290);
    View view = this.D0.getDecorView();
    contentFrameLayout.a(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.C0.obtainStyledAttributes(g.j.AppCompatTheme);
    typedArray.getValue(g.j.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(g.j.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
    if (typedArray.hasValue(g.j.AppCompatTheme_windowFixedWidthMajor))
      typedArray.getValue(g.j.AppCompatTheme_windowFixedWidthMajor, contentFrameLayout.getFixedWidthMajor()); 
    if (typedArray.hasValue(g.j.AppCompatTheme_windowFixedWidthMinor))
      typedArray.getValue(g.j.AppCompatTheme_windowFixedWidthMinor, contentFrameLayout.getFixedWidthMinor()); 
    if (typedArray.hasValue(g.j.AppCompatTheme_windowFixedHeightMajor))
      typedArray.getValue(g.j.AppCompatTheme_windowFixedHeightMajor, contentFrameLayout.getFixedHeightMajor()); 
    if (typedArray.hasValue(g.j.AppCompatTheme_windowFixedHeightMinor))
      typedArray.getValue(g.j.AppCompatTheme_windowFixedHeightMinor, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private void Y(Window paramWindow) {
    if (this.D0 == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof o)) {
        o o1 = new o(this, callback);
        this.E0 = o1;
        paramWindow.setCallback((Window.Callback)o1);
        p0 p0 = p0.u(this.C0, null, D1);
        Drawable drawable = p0.h(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        p0.w();
        this.D0 = paramWindow;
        if (Build.VERSION.SDK_INT >= 33 && this.z1 == null)
          P(null); 
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  private boolean Y0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.D0.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (m0.V((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  private int a0() {
    int i = this.l1;
    return (i != -100) ? i : g.o();
  }
  
  private void b1() {
    if (!this.S0)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  private d c1() {
    Context context = this.C0;
    while (context != null) {
      if (context instanceof d)
        return (d)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  private void d0() {
    q q1 = this.p1;
    if (q1 != null)
      q1.a(); 
    q1 = this.q1;
    if (q1 != null)
      q1.a(); 
  }
  
  private void d1(Configuration paramConfiguration) {
    Activity activity = (Activity)this.B0;
    if (activity instanceof androidx.lifecycle.p) {
      if (((androidx.lifecycle.p)activity).getLifecycle().b().e(androidx.lifecycle.j.b.u0)) {
        activity.onConfigurationChanged(paramConfiguration);
        return;
      } 
    } else if (this.i1 && !this.j1) {
      activity.onConfigurationChanged(paramConfiguration);
    } 
  }
  
  private boolean e1(int paramInt, androidx.core.os.i parami, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield C0 : Landroid/content/Context;
    //   5: iload_1
    //   6: aload_2
    //   7: aconst_null
    //   8: iconst_0
    //   9: invokespecial g0 : (Landroid/content/Context;ILandroidx/core/os/i;Landroid/content/res/Configuration;Z)Landroid/content/res/Configuration;
    //   12: astore #12
    //   14: aload_0
    //   15: aload_0
    //   16: getfield C0 : Landroid/content/Context;
    //   19: invokespecial s0 : (Landroid/content/Context;)I
    //   22: istore #6
    //   24: aload_0
    //   25: getfield k1 : Landroid/content/res/Configuration;
    //   28: astore #11
    //   30: aload #11
    //   32: astore #10
    //   34: aload #11
    //   36: ifnonnull -> 51
    //   39: aload_0
    //   40: getfield C0 : Landroid/content/Context;
    //   43: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   46: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   49: astore #10
    //   51: aload #10
    //   53: getfield uiMode : I
    //   56: istore #4
    //   58: aload #12
    //   60: getfield uiMode : I
    //   63: bipush #48
    //   65: iand
    //   66: istore #7
    //   68: aload_0
    //   69: aload #10
    //   71: invokevirtual v0 : (Landroid/content/res/Configuration;)Landroidx/core/os/i;
    //   74: astore #11
    //   76: aload_2
    //   77: ifnonnull -> 86
    //   80: aconst_null
    //   81: astore #10
    //   83: goto -> 94
    //   86: aload_0
    //   87: aload #12
    //   89: invokevirtual v0 : (Landroid/content/res/Configuration;)Landroidx/core/os/i;
    //   92: astore #10
    //   94: iconst_0
    //   95: istore #9
    //   97: iload #4
    //   99: bipush #48
    //   101: iand
    //   102: iload #7
    //   104: if_icmpeq -> 115
    //   107: sipush #512
    //   110: istore #4
    //   112: goto -> 118
    //   115: iconst_0
    //   116: istore #4
    //   118: iload #4
    //   120: istore #5
    //   122: aload #10
    //   124: ifnull -> 151
    //   127: iload #4
    //   129: istore #5
    //   131: aload #11
    //   133: aload #10
    //   135: invokevirtual equals : (Ljava/lang/Object;)Z
    //   138: ifne -> 151
    //   141: iload #4
    //   143: iconst_4
    //   144: ior
    //   145: sipush #8192
    //   148: ior
    //   149: istore #5
    //   151: iconst_1
    //   152: istore #8
    //   154: iload #6
    //   156: iload #5
    //   158: iand
    //   159: ifeq -> 226
    //   162: iload_3
    //   163: ifeq -> 226
    //   166: aload_0
    //   167: getfield h1 : Z
    //   170: ifeq -> 226
    //   173: getstatic androidx/appcompat/app/h.E1 : Z
    //   176: ifne -> 186
    //   179: aload_0
    //   180: getfield i1 : Z
    //   183: ifeq -> 226
    //   186: aload_0
    //   187: getfield B0 : Ljava/lang/Object;
    //   190: astore #11
    //   192: aload #11
    //   194: instanceof android/app/Activity
    //   197: ifeq -> 226
    //   200: aload #11
    //   202: checkcast android/app/Activity
    //   205: invokevirtual isChild : ()Z
    //   208: ifne -> 226
    //   211: aload_0
    //   212: getfield B0 : Ljava/lang/Object;
    //   215: checkcast android/app/Activity
    //   218: invokestatic t : (Landroid/app/Activity;)V
    //   221: iconst_1
    //   222: istore_3
    //   223: goto -> 228
    //   226: iconst_0
    //   227: istore_3
    //   228: iload_3
    //   229: ifne -> 268
    //   232: iload #5
    //   234: ifeq -> 268
    //   237: iload #9
    //   239: istore_3
    //   240: iload #5
    //   242: iload #6
    //   244: iand
    //   245: iload #5
    //   247: if_icmpne -> 252
    //   250: iconst_1
    //   251: istore_3
    //   252: aload_0
    //   253: iload #7
    //   255: aload #10
    //   257: iload_3
    //   258: aconst_null
    //   259: invokespecial g1 : (ILandroidx/core/os/i;ZLandroid/content/res/Configuration;)V
    //   262: iload #8
    //   264: istore_3
    //   265: goto -> 268
    //   268: iload_3
    //   269: ifeq -> 322
    //   272: aload_0
    //   273: getfield B0 : Ljava/lang/Object;
    //   276: astore #11
    //   278: aload #11
    //   280: instanceof androidx/appcompat/app/d
    //   283: ifeq -> 322
    //   286: iload #5
    //   288: sipush #512
    //   291: iand
    //   292: ifeq -> 304
    //   295: aload #11
    //   297: checkcast androidx/appcompat/app/d
    //   300: iload_1
    //   301: invokevirtual onNightModeChanged : (I)V
    //   304: iload #5
    //   306: iconst_4
    //   307: iand
    //   308: ifeq -> 322
    //   311: aload_0
    //   312: getfield B0 : Ljava/lang/Object;
    //   315: checkcast androidx/appcompat/app/d
    //   318: aload_2
    //   319: invokevirtual onLocalesChanged : (Landroidx/core/os/i;)V
    //   322: iload_3
    //   323: ifeq -> 349
    //   326: aload #10
    //   328: ifnull -> 349
    //   331: aload_0
    //   332: aload_0
    //   333: aload_0
    //   334: getfield C0 : Landroid/content/Context;
    //   337: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   340: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   343: invokevirtual v0 : (Landroid/content/res/Configuration;)Landroidx/core/os/i;
    //   346: invokevirtual W0 : (Landroidx/core/os/i;)V
    //   349: iload_3
    //   350: ireturn
  }
  
  private Configuration g0(Context paramContext, int paramInt, androidx.core.os.i parami, Configuration paramConfiguration, boolean paramBoolean) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramBoolean) {
          paramInt = 0;
        } else {
          paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
        } 
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    if (parami != null)
      V0(configuration, parami); 
    return configuration;
  }
  
  private void g1(int paramInt, androidx.core.os.i parami, boolean paramBoolean, Configuration paramConfiguration) {
    Resources resources = this.C0.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    if (paramConfiguration != null)
      configuration.updateFrom(paramConfiguration); 
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    if (parami != null)
      V0(configuration, parami); 
    resources.updateConfiguration(configuration, null);
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 26)
      f0.a(resources); 
    int j = this.m1;
    if (j != 0) {
      this.C0.setTheme(j);
      if (paramInt >= 23)
        this.C0.getTheme().applyStyle(this.m1, true); 
    } 
    if (paramBoolean && this.B0 instanceof Activity)
      d1(configuration); 
  }
  
  private ViewGroup h0() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.C0.obtainStyledAttributes(g.j.AppCompatTheme);
    if (typedArray.hasValue(g.j.AppCompatTheme_windowActionBar)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(g.j.AppCompatTheme_windowNoTitle, false)) {
        J(1);
      } else if (typedArray.getBoolean(g.j.AppCompatTheme_windowActionBar, false)) {
        J(108);
      } 
      if (typedArray.getBoolean(g.j.AppCompatTheme_windowActionBarOverlay, false))
        J(109); 
      if (typedArray.getBoolean(g.j.AppCompatTheme_windowActionModeOverlay, false))
        J(10); 
      this.b1 = typedArray.getBoolean(g.j.AppCompatTheme_android_windowIsFloating, false);
      typedArray.recycle();
      o0();
      this.D0.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.C0);
      if (!this.c1) {
        if (this.b1) {
          viewGroup = (ViewGroup)layoutInflater.inflate(g.g.abc_dialog_title_material, null);
          this.Z0 = false;
          this.Y0 = false;
        } else if (this.Y0) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.C0.getTheme().resolveAttribute(g.a.actionBarTheme, typedValue, true);
          if (typedValue.resourceId != 0) {
            androidx.appcompat.view.d d = new androidx.appcompat.view.d(this.C0, typedValue.resourceId);
          } else {
            context = this.C0;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(g.g.abc_screen_toolbar, null);
          w w1 = (w)viewGroup1.findViewById(g.f.decor_content_parent);
          this.J0 = w1;
          w1.setWindowCallback(y0());
          if (this.Z0)
            this.J0.h(109); 
          if (this.W0)
            this.J0.h(2); 
          viewGroup = viewGroup1;
          if (this.X0) {
            this.J0.h(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else if (this.a1) {
        viewGroup = (ViewGroup)layoutInflater.inflate(g.g.abc_screen_simple_overlay_action_mode, null);
      } else {
        viewGroup = (ViewGroup)viewGroup.inflate(g.g.abc_screen_simple, null);
      } 
      if (viewGroup != null) {
        m0.H0((View)viewGroup, new b(this));
        if (this.J0 == null)
          this.U0 = (TextView)viewGroup.findViewById(g.f.title); 
        a1.c((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(g.f.action_bar_activity_content);
        ViewGroup viewGroup1 = (ViewGroup)this.D0.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.D0.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new c(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.Y0);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.Z0);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.b1);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.a1);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.c1);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
  }
  
  private void i1(View paramView) {
    int i;
    if ((m0.O(paramView) & 0x2000) != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = androidx.core.content.a.c(this.C0, g.c.abc_decor_view_status_guard_light);
    } else {
      i = androidx.core.content.a.c(this.C0, g.c.abc_decor_view_status_guard);
    } 
    paramView.setBackgroundColor(i);
  }
  
  private void n0() {
    if (!this.S0) {
      this.T0 = h0();
      CharSequence charSequence = x0();
      if (!TextUtils.isEmpty(charSequence)) {
        w w1 = this.J0;
        if (w1 != null) {
          w1.setWindowTitle(charSequence);
        } else if (Q0() != null) {
          Q0().z(charSequence);
        } else {
          TextView textView = this.U0;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      X();
      O0(this.T0);
      this.S0 = true;
      u u1 = w0(0, false);
      if (!this.j1 && (u1 == null || u1.j == null))
        D0(108); 
    } 
  }
  
  private void o0() {
    if (this.D0 == null) {
      Object object = this.B0;
      if (object instanceof Activity)
        Y(((Activity)object).getWindow()); 
    } 
    if (this.D0 != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  private static Configuration q0(Configuration paramConfiguration1, Configuration paramConfiguration2) {
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration2 != null) {
      if (paramConfiguration1.diff(paramConfiguration2) == 0)
        return configuration; 
      float f1 = paramConfiguration1.fontScale;
      float f2 = paramConfiguration2.fontScale;
      if (f1 != f2)
        configuration.fontScale = f2; 
      int i = paramConfiguration1.mcc;
      int j = paramConfiguration2.mcc;
      if (i != j)
        configuration.mcc = j; 
      i = paramConfiguration1.mnc;
      j = paramConfiguration2.mnc;
      if (i != j)
        configuration.mnc = j; 
      i = Build.VERSION.SDK_INT;
      if (i >= 24) {
        l.a(paramConfiguration1, paramConfiguration2, configuration);
      } else if (!androidx.core.util.c.a(paramConfiguration1.locale, paramConfiguration2.locale)) {
        configuration.locale = paramConfiguration2.locale;
      } 
      j = paramConfiguration1.touchscreen;
      int k = paramConfiguration2.touchscreen;
      if (j != k)
        configuration.touchscreen = k; 
      j = paramConfiguration1.keyboard;
      k = paramConfiguration2.keyboard;
      if (j != k)
        configuration.keyboard = k; 
      j = paramConfiguration1.keyboardHidden;
      k = paramConfiguration2.keyboardHidden;
      if (j != k)
        configuration.keyboardHidden = k; 
      j = paramConfiguration1.navigation;
      k = paramConfiguration2.navigation;
      if (j != k)
        configuration.navigation = k; 
      j = paramConfiguration1.navigationHidden;
      k = paramConfiguration2.navigationHidden;
      if (j != k)
        configuration.navigationHidden = k; 
      j = paramConfiguration1.orientation;
      k = paramConfiguration2.orientation;
      if (j != k)
        configuration.orientation = k; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xF) != (k & 0xF))
        configuration.screenLayout |= k & 0xF; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xC0) != (k & 0xC0))
        configuration.screenLayout |= k & 0xC0; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x30) != (k & 0x30))
        configuration.screenLayout |= k & 0x30; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x300) != (k & 0x300))
        configuration.screenLayout |= k & 0x300; 
      if (i >= 26)
        m.a(paramConfiguration1, paramConfiguration2, configuration); 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0xF) != (j & 0xF))
        configuration.uiMode |= j & 0xF; 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0x30) != (j & 0x30))
        configuration.uiMode |= j & 0x30; 
      i = paramConfiguration1.screenWidthDp;
      j = paramConfiguration2.screenWidthDp;
      if (i != j)
        configuration.screenWidthDp = j; 
      i = paramConfiguration1.screenHeightDp;
      j = paramConfiguration2.screenHeightDp;
      if (i != j)
        configuration.screenHeightDp = j; 
      i = paramConfiguration1.smallestScreenWidthDp;
      j = paramConfiguration2.smallestScreenWidthDp;
      if (i != j)
        configuration.smallestScreenWidthDp = j; 
      j.b(paramConfiguration1, paramConfiguration2, configuration);
    } 
    return configuration;
  }
  
  private int s0(Context paramContext) {
    if (!this.o1 && this.B0 instanceof Activity) {
      PackageManager packageManager = paramContext.getPackageManager();
      if (packageManager == null)
        return 0; 
      try {
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
          i = 269221888;
        } else if (i >= 24) {
          i = 786432;
        } else {
          i = 0;
        } 
        ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(paramContext, this.B0.getClass()), i);
        if (activityInfo != null)
          this.n1 = activityInfo.configChanges; 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        this.n1 = 0;
      } 
    } 
    this.o1 = true;
    return this.n1;
  }
  
  private q t0(Context paramContext) {
    if (this.q1 == null)
      this.q1 = new p(this, paramContext); 
    return this.q1;
  }
  
  private q u0(Context paramContext) {
    if (this.p1 == null)
      this.p1 = new r(this, i0.a(paramContext)); 
    return this.p1;
  }
  
  private void z0() {
    n0();
    if (this.Y0) {
      if (this.G0 != null)
        return; 
      Object object = this.B0;
      if (object instanceof Activity) {
        this.G0 = new j0((Activity)this.B0, this.Z0);
      } else if (object instanceof Dialog) {
        this.G0 = new j0((Dialog)this.B0);
      } 
      object = this.G0;
      if (object != null)
        object.r(this.u1); 
    } 
  }
  
  public void A(Bundle paramBundle) {
    this.h1 = true;
    V(false);
    o0();
    Object object = this.B0;
    if (object instanceof Activity) {
      try {
        object = androidx.core.app.k.c((Activity)object);
      } catch (IllegalArgumentException illegalArgumentException) {
        illegalArgumentException = null;
      } 
      if (illegalArgumentException != null) {
        a a1 = Q0();
        if (a1 == null) {
          this.u1 = true;
        } else {
          a1.r(true);
        } 
      } 
      g.d(this);
    } 
    this.k1 = new Configuration(this.C0.getResources().getConfiguration());
    this.i1 = true;
  }
  
  public void B() {
    // Byte code:
    //   0: aload_0
    //   1: getfield B0 : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 14
    //   10: aload_0
    //   11: invokestatic H : (Landroidx/appcompat/app/g;)V
    //   14: aload_0
    //   15: getfield r1 : Z
    //   18: ifeq -> 36
    //   21: aload_0
    //   22: getfield D0 : Landroid/view/Window;
    //   25: invokevirtual getDecorView : ()Landroid/view/View;
    //   28: aload_0
    //   29: getfield t1 : Ljava/lang/Runnable;
    //   32: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   35: pop
    //   36: aload_0
    //   37: iconst_1
    //   38: putfield j1 : Z
    //   41: aload_0
    //   42: getfield l1 : I
    //   45: bipush #-100
    //   47: if_icmpeq -> 99
    //   50: aload_0
    //   51: getfield B0 : Ljava/lang/Object;
    //   54: astore_1
    //   55: aload_1
    //   56: instanceof android/app/Activity
    //   59: ifeq -> 99
    //   62: aload_1
    //   63: checkcast android/app/Activity
    //   66: invokevirtual isChangingConfigurations : ()Z
    //   69: ifeq -> 99
    //   72: getstatic androidx/appcompat/app/h.B1 : Landroidx/collection/g;
    //   75: aload_0
    //   76: getfield B0 : Ljava/lang/Object;
    //   79: invokevirtual getClass : ()Ljava/lang/Class;
    //   82: invokevirtual getName : ()Ljava/lang/String;
    //   85: aload_0
    //   86: getfield l1 : I
    //   89: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   92: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   95: pop
    //   96: goto -> 116
    //   99: getstatic androidx/appcompat/app/h.B1 : Landroidx/collection/g;
    //   102: aload_0
    //   103: getfield B0 : Ljava/lang/Object;
    //   106: invokevirtual getClass : ()Ljava/lang/Class;
    //   109: invokevirtual getName : ()Ljava/lang/String;
    //   112: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   115: pop
    //   116: aload_0
    //   117: getfield G0 : Landroidx/appcompat/app/a;
    //   120: astore_1
    //   121: aload_1
    //   122: ifnull -> 129
    //   125: aload_1
    //   126: invokevirtual n : ()V
    //   129: aload_0
    //   130: invokespecial d0 : ()V
    //   133: return
  }
  
  public void C(Bundle paramBundle) {
    n0();
  }
  
  public void D() {
    a a1 = u();
    if (a1 != null)
      a1.x(true); 
  }
  
  public void E(Bundle paramBundle) {}
  
  public boolean E0() {
    return this.R0;
  }
  
  public void F() {
    W(true, false);
  }
  
  int F0(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1)
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3)
              return t0(paramContext).c(); 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          return (Build.VERSION.SDK_INT >= 23 && ((UiModeManager)paramContext.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) ? -1 : u0(paramContext).c();
        }  
      return paramInt;
    } 
    return -1;
  }
  
  public void G() {
    a a1 = u();
    if (a1 != null)
      a1.x(false); 
  }
  
  boolean G0() {
    boolean bool = this.g1;
    this.g1 = false;
    u u1 = w0(0, false);
    if (u1 != null && u1.o) {
      if (!bool)
        f0(u1, true); 
      return true;
    } 
    androidx.appcompat.view.b b1 = this.M0;
    if (b1 != null) {
      b1.c();
      return true;
    } 
    a a1 = u();
    return (a1 != null && a1.h());
  }
  
  boolean H0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      I0(0, paramKeyEvent);
      return true;
    } 
    if ((paramKeyEvent.getFlags() & 0x80) == 0)
      bool = false; 
    this.g1 = bool;
    return false;
  }
  
  public boolean J(int paramInt) {
    paramInt = U0(paramInt);
    if (this.c1 && paramInt == 108)
      return false; 
    if (this.Y0 && paramInt == 1)
      this.Y0 = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.D0.requestFeature(paramInt); 
              b1();
              this.Z0 = true;
              return true;
            } 
            b1();
            this.Y0 = true;
            return true;
          } 
          b1();
          this.a1 = true;
          return true;
        } 
        b1();
        this.X0 = true;
        return true;
      } 
      b1();
      this.W0 = true;
      return true;
    } 
    b1();
    this.c1 = true;
    return true;
  }
  
  boolean J0(int paramInt, KeyEvent paramKeyEvent) {
    u u1;
    a a1 = u();
    if (a1 != null && a1.o(paramInt, paramKeyEvent))
      return true; 
    u u2 = this.f1;
    if (u2 != null && R0(u2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      u1 = this.f1;
      if (u1 != null)
        u1.n = true; 
      return true;
    } 
    if (this.f1 == null) {
      u2 = w0(0, true);
      S0(u2, (KeyEvent)u1);
      boolean bool = R0(u2, u1.getKeyCode(), (KeyEvent)u1, 1);
      u2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void K(int paramInt) {
    n0();
    ViewGroup viewGroup = (ViewGroup)this.T0.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.C0).inflate(paramInt, viewGroup);
    this.E0.c(this.D0.getCallback());
  }
  
  boolean K0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      L0(0, paramKeyEvent);
      return true;
    } 
    return G0();
  }
  
  public void L(View paramView) {
    n0();
    ViewGroup viewGroup = (ViewGroup)this.T0.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.E0.c(this.D0.getCallback());
  }
  
  public void M(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    n0();
    ViewGroup viewGroup = (ViewGroup)this.T0.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.E0.c(this.D0.getCallback());
  }
  
  void M0(int paramInt) {
    if (paramInt == 108) {
      a a1 = u();
      if (a1 != null)
        a1.i(true); 
    } 
  }
  
  void N0(int paramInt) {
    if (paramInt == 108) {
      a a1 = u();
      if (a1 != null) {
        a1.i(false);
        return;
      } 
    } else if (paramInt == 0) {
      u u1 = w0(paramInt, true);
      if (u1.o)
        f0(u1, false); 
    } 
  }
  
  public void O(int paramInt) {
    if (this.l1 != paramInt) {
      this.l1 = paramInt;
      if (this.h1)
        f(); 
    } 
  }
  
  void O0(ViewGroup paramViewGroup) {}
  
  public void P(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial P : (Landroid/window/OnBackInvokedDispatcher;)V
    //   5: aload_0
    //   6: getfield z1 : Landroid/window/OnBackInvokedDispatcher;
    //   9: astore_2
    //   10: aload_2
    //   11: ifnull -> 33
    //   14: aload_0
    //   15: getfield A1 : Landroid/window/OnBackInvokedCallback;
    //   18: astore_3
    //   19: aload_3
    //   20: ifnull -> 33
    //   23: aload_2
    //   24: aload_3
    //   25: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   28: aload_0
    //   29: aconst_null
    //   30: putfield A1 : Landroid/window/OnBackInvokedCallback;
    //   33: aload_1
    //   34: ifnonnull -> 76
    //   37: aload_0
    //   38: getfield B0 : Ljava/lang/Object;
    //   41: astore_2
    //   42: aload_2
    //   43: instanceof android/app/Activity
    //   46: ifeq -> 76
    //   49: aload_2
    //   50: checkcast android/app/Activity
    //   53: invokevirtual getWindow : ()Landroid/view/Window;
    //   56: ifnull -> 76
    //   59: aload_0
    //   60: aload_0
    //   61: getfield B0 : Ljava/lang/Object;
    //   64: checkcast android/app/Activity
    //   67: invokestatic a : (Landroid/app/Activity;)Landroid/window/OnBackInvokedDispatcher;
    //   70: putfield z1 : Landroid/window/OnBackInvokedDispatcher;
    //   73: goto -> 81
    //   76: aload_0
    //   77: aload_1
    //   78: putfield z1 : Landroid/window/OnBackInvokedDispatcher;
    //   81: aload_0
    //   82: invokevirtual f1 : ()V
    //   85: return
  }
  
  public void Q(Toolbar paramToolbar) {
    if (!(this.B0 instanceof Activity))
      return; 
    a a1 = u();
    if (!(a1 instanceof j0)) {
      this.H0 = null;
      if (a1 != null)
        a1.n(); 
      this.G0 = null;
      if (paramToolbar != null) {
        a1 = new g0(paramToolbar, x0(), (Window.Callback)this.E0);
        this.G0 = a1;
        this.E0.e(((g0)a1).c);
        paramToolbar.setBackInvokedCallbackEnabled(true);
      } else {
        this.E0.e(null);
      } 
      w();
      return;
    } 
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  final a Q0() {
    return this.G0;
  }
  
  public void R(int paramInt) {
    this.m1 = paramInt;
  }
  
  public final void S(CharSequence paramCharSequence) {
    this.I0 = paramCharSequence;
    w w1 = this.J0;
    if (w1 != null) {
      w1.setWindowTitle(paramCharSequence);
      return;
    } 
    if (Q0() != null) {
      Q0().z(paramCharSequence);
      return;
    } 
    TextView textView = this.U0;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public androidx.appcompat.view.b T(androidx.appcompat.view.b.a parama) {
    if (parama != null) {
      androidx.appcompat.view.b b1 = this.M0;
      if (b1 != null)
        b1.c(); 
      parama = new i(this, parama);
      a a1 = u();
      if (a1 != null) {
        androidx.appcompat.view.b b2 = a1.A(parama);
        this.M0 = b2;
        if (b2 != null) {
          e e1 = this.F0;
          if (e1 != null)
            e1.onSupportActionModeStarted(b2); 
        } 
      } 
      if (this.M0 == null)
        this.M0 = a1(parama); 
      f1();
      return this.M0;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  void V0(Configuration paramConfiguration, androidx.core.os.i parami) {
    if (Build.VERSION.SDK_INT >= 24) {
      l.d(paramConfiguration, parami);
      return;
    } 
    j.d(paramConfiguration, parami.d(0));
    j.c(paramConfiguration, parami.d(0));
  }
  
  void W0(androidx.core.os.i parami) {
    if (Build.VERSION.SDK_INT >= 24) {
      l.c(parami);
      return;
    } 
    Locale.setDefault(parami.d(0));
  }
  
  final boolean X0() {
    if (this.S0) {
      ViewGroup viewGroup = this.T0;
      if (viewGroup != null && m0.W((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  androidx.core.os.i Z(Context paramContext) {
    androidx.core.os.i i1;
    int i = Build.VERSION.SDK_INT;
    if (i >= 33)
      return null; 
    androidx.core.os.i i3 = g.t();
    if (i3 == null)
      return null; 
    androidx.core.os.i i2 = v0(paramContext.getApplicationContext().getResources().getConfiguration());
    if (i >= 24) {
      i1 = e0.b(i3, i2);
    } else if (i3.f()) {
      i1 = androidx.core.os.i.e();
    } else {
      i1 = androidx.core.os.i.c(i3.d(0).toString());
    } 
    return i1.f() ? i2 : i1;
  }
  
  boolean Z0() {
    if (this.z1 == null)
      return false; 
    u u1 = w0(0, false);
    return (u1 != null && u1.o) ? true : ((this.M0 != null));
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    Window.Callback callback = y0();
    if (callback != null && !this.j1) {
      u u1 = p0((Menu)paramg.F());
      if (u1 != null)
        return callback.onMenuItemSelected(u1.a, paramMenuItem); 
    } 
    return false;
  }
  
  androidx.appcompat.view.b a1(androidx.appcompat.view.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual m0 : ()V
    //   4: aload_0
    //   5: getfield M0 : Landroidx/appcompat/view/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual c : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof androidx/appcompat/app/h$i
    //   27: ifne -> 41
    //   30: new androidx/appcompat/app/h$i
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Landroidx/appcompat/app/h;Landroidx/appcompat/view/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield F0 : Landroidx/appcompat/app/e;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield j1 : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface onWindowStartingSupportActionMode : (Landroidx/appcompat/view/b$a;)Landroidx/appcompat/view/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield M0 : Landroidx/appcompat/view/b;
    //   80: goto -> 565
    //   83: aload_0
    //   84: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield b1 : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield C0 : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic g/a.actionBarTheme : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield C0 : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new androidx/appcompat/view/d
    //   169: dup
    //   170: aload_0
    //   171: getfield C0 : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield C0 : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic g/a.actionModePopupWindowStyle : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield O0 : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield O0 : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield O0 : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic g/a.actionBarSize : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield O0 : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new androidx/appcompat/app/h$d
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Landroidx/appcompat/app/h;)V
    //   309: putfield P0 : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield T0 : Landroid/view/ViewGroup;
    //   319: getstatic g/f.action_mode_bar_stub : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual r0 : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual a : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 565
    //   362: aload_0
    //   363: invokevirtual m0 : ()V
    //   366: aload_0
    //   367: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual k : ()V
    //   373: aload_0
    //   374: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore_1
    //   381: aload_0
    //   382: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   385: astore #5
    //   387: aload_0
    //   388: getfield O0 : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new androidx/appcompat/view/e
    //   402: dup
    //   403: aload_1
    //   404: aload #5
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Landroidx/appcompat/view/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual e : ()Landroid/view/Menu;
    //   420: invokeinterface b : (Landroidx/appcompat/view/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 560
    //   428: aload_1
    //   429: invokevirtual k : ()V
    //   432: aload_0
    //   433: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual h : (Landroidx/appcompat/view/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield M0 : Landroidx/appcompat/view/b;
    //   445: aload_0
    //   446: invokevirtual X0 : ()Z
    //   449: ifeq -> 493
    //   452: aload_0
    //   453: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic e : (Landroid/view/View;)Landroidx/core/view/u0;
    //   467: fconst_1
    //   468: invokevirtual b : (F)Landroidx/core/view/u0;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield Q0 : Landroidx/core/view/u0;
    //   477: aload_1
    //   478: new androidx/appcompat/app/h$e
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/appcompat/app/h;)V
    //   486: invokevirtual h : (Landroidx/core/view/v0;)Landroidx/core/view/u0;
    //   489: pop
    //   490: goto -> 535
    //   493: aload_0
    //   494: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   497: fconst_1
    //   498: invokevirtual setAlpha : (F)V
    //   501: aload_0
    //   502: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   505: iconst_0
    //   506: invokevirtual setVisibility : (I)V
    //   509: aload_0
    //   510: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   513: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   516: instanceof android/view/View
    //   519: ifeq -> 535
    //   522: aload_0
    //   523: getfield N0 : Landroidx/appcompat/widget/ActionBarContextView;
    //   526: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   529: checkcast android/view/View
    //   532: invokestatic p0 : (Landroid/view/View;)V
    //   535: aload_0
    //   536: getfield O0 : Landroid/widget/PopupWindow;
    //   539: ifnull -> 565
    //   542: aload_0
    //   543: getfield D0 : Landroid/view/Window;
    //   546: invokevirtual getDecorView : ()Landroid/view/View;
    //   549: aload_0
    //   550: getfield P0 : Ljava/lang/Runnable;
    //   553: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   556: pop
    //   557: goto -> 565
    //   560: aload_0
    //   561: aconst_null
    //   562: putfield M0 : Landroidx/appcompat/view/b;
    //   565: aload_0
    //   566: getfield M0 : Landroidx/appcompat/view/b;
    //   569: astore_1
    //   570: aload_1
    //   571: ifnull -> 593
    //   574: aload_0
    //   575: getfield F0 : Landroidx/appcompat/app/e;
    //   578: astore #4
    //   580: aload #4
    //   582: ifnull -> 593
    //   585: aload #4
    //   587: aload_1
    //   588: invokeinterface onSupportActionModeStarted : (Landroidx/appcompat/view/b;)V
    //   593: aload_0
    //   594: invokevirtual f1 : ()V
    //   597: aload_0
    //   598: getfield M0 : Landroidx/appcompat/view/b;
    //   601: areturn
    //   602: astore_1
    //   603: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	602	java/lang/AbstractMethodError
  }
  
  public void b(g paramg) {
    T0(true);
  }
  
  void b0(int paramInt, u paramu, Menu paramMenu) {
    g g1;
    u u1 = paramu;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      u u2 = paramu;
      if (paramu == null) {
        u2 = paramu;
        if (paramInt >= 0) {
          u[] arrayOfU = this.e1;
          u2 = paramu;
          if (paramInt < arrayOfU.length)
            u2 = arrayOfU[paramInt]; 
        } 
      } 
      u1 = u2;
      menu = paramMenu;
      if (u2 != null) {
        g1 = u2.j;
        u1 = u2;
      } 
    } 
    if (u1 != null && !u1.o)
      return; 
    if (!this.j1)
      this.E0.d(this.D0.getCallback(), paramInt, (Menu)g1); 
  }
  
  void c0(g paramg) {
    if (this.d1)
      return; 
    this.d1 = true;
    this.J0.i();
    Window.Callback callback = y0();
    if (callback != null && !this.j1)
      callback.onPanelClosed(108, (Menu)paramg); 
    this.d1 = false;
  }
  
  public void e(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    n0();
    ((ViewGroup)this.T0.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.E0.c(this.D0.getCallback());
  }
  
  void e0(int paramInt) {
    f0(w0(paramInt, true), true);
  }
  
  public boolean f() {
    return V(true);
  }
  
  void f0(u paramu, boolean paramBoolean) {
    if (paramBoolean && paramu.a == 0) {
      w w1 = this.J0;
      if (w1 != null && w1.e()) {
        c0(paramu.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.C0.getSystemService("window");
    if (windowManager != null && paramu.o) {
      ViewGroup viewGroup = paramu.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          b0(paramu.a, paramu, null); 
      } 
    } 
    paramu.m = false;
    paramu.n = false;
    paramu.o = false;
    paramu.h = null;
    paramu.q = true;
    if (this.f1 == paramu)
      this.f1 = null; 
    if (paramu.a == 0)
      f1(); 
  }
  
  void f1() {
    if (Build.VERSION.SDK_INT >= 33) {
      boolean bool = Z0();
      if (bool && this.A1 == null) {
        this.A1 = n.b(this.z1, this);
        return;
      } 
      if (!bool) {
        OnBackInvokedCallback onBackInvokedCallback = this.A1;
        if (onBackInvokedCallback != null)
          n.c(this.z1, onBackInvokedCallback); 
      } 
    } 
  }
  
  final int h1(m1 paramm1, Rect paramRect) {
    int i;
    int j;
    boolean bool1;
    boolean bool2 = false;
    if (paramm1 != null) {
      i = paramm1.l();
    } else if (paramRect != null) {
      i = paramRect.top;
    } else {
      i = 0;
    } 
    ActionBarContextView actionBarContextView = this.N0;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.N0.getLayoutParams();
      boolean bool3 = this.N0.isShown();
      int k = 1;
      bool1 = true;
      if (bool3) {
        int m;
        if (this.v1 == null) {
          this.v1 = new Rect();
          this.w1 = new Rect();
        } 
        Rect rect1 = this.v1;
        Rect rect2 = this.w1;
        if (paramm1 == null) {
          rect1.set(paramRect);
        } else {
          rect1.set(paramm1.j(), paramm1.l(), paramm1.k(), paramm1.i());
        } 
        a1.a((View)this.T0, rect1, rect2);
        int n = rect1.top;
        bool = rect1.left;
        int i1 = rect1.right;
        paramm1 = m0.L((View)this.T0);
        if (paramm1 == null) {
          k = 0;
        } else {
          k = paramm1.j();
        } 
        if (paramm1 == null) {
          m = 0;
        } else {
          m = paramm1.k();
        } 
        if (marginLayoutParams.topMargin != n || marginLayoutParams.leftMargin != bool || marginLayoutParams.rightMargin != i1) {
          marginLayoutParams.topMargin = n;
          marginLayoutParams.leftMargin = bool;
          marginLayoutParams.rightMargin = i1;
          bool = true;
        } else {
          bool = false;
        } 
        if (n > 0 && this.V0 == null) {
          View view2 = new View(this.C0);
          this.V0 = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = k;
          layoutParams.rightMargin = m;
          this.T0.addView(this.V0, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.V0;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            n = marginLayoutParams1.height;
            i1 = marginLayoutParams.topMargin;
            if (n != i1 || marginLayoutParams1.leftMargin != k || marginLayoutParams1.rightMargin != m) {
              marginLayoutParams1.height = i1;
              marginLayoutParams1.leftMargin = k;
              marginLayoutParams1.rightMargin = m;
              this.V0.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.V0;
        if (view1 != null) {
          m = bool1;
        } else {
          m = 0;
        } 
        if (m != 0 && view1.getVisibility() != 0)
          i1(this.V0); 
        k = i;
        if (!this.a1) {
          k = i;
          if (m != 0)
            k = 0; 
        } 
        i = k;
        k = bool;
        bool = m;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
      } else {
        bool = false;
        k = 0;
      } 
      j = i;
      bool1 = bool;
      if (k != 0) {
        this.N0.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        j = i;
        bool1 = bool;
      } 
    } else {
      bool1 = false;
      j = i;
    } 
    View view = this.V0;
    if (view != null) {
      if (bool1) {
        i = bool2;
      } else {
        i = 8;
      } 
      view.setVisibility(i);
    } 
    return j;
  }
  
  public Context i(Context paramContext) {
    int i = 1;
    this.h1 = true;
    int j = F0(paramContext, a0());
    if (g.x(paramContext))
      g.U(paramContext); 
    androidx.core.os.i i1 = Z(paramContext);
    if (F1 && paramContext instanceof ContextThemeWrapper) {
      Configuration configuration = g0(paramContext, j, i1, null, false);
      try {
        s.a((ContextThemeWrapper)paramContext, configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (paramContext instanceof androidx.appcompat.view.d) {
      Configuration configuration = g0(paramContext, j, i1, null, false);
      try {
        ((androidx.appcompat.view.d)paramContext).a(configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (!E1)
      return super.i(paramContext); 
    Configuration configuration1 = new Configuration();
    configuration1.uiMode = -1;
    configuration1.fontScale = 0.0F;
    configuration1 = j.a(paramContext, configuration1).getResources().getConfiguration();
    Configuration configuration3 = paramContext.getResources().getConfiguration();
    configuration1.uiMode = configuration3.uiMode;
    if (!configuration1.equals(configuration3)) {
      configuration1 = q0(configuration1, configuration3);
    } else {
      configuration1 = null;
    } 
    Configuration configuration2 = g0(paramContext, j, i1, configuration1, true);
    androidx.appcompat.view.d d = new androidx.appcompat.view.d(paramContext, g.i.Theme_AppCompat_Empty);
    d.a(configuration2);
    j = 0;
    try {
      Resources.Theme theme = paramContext.getTheme();
      if (theme == null)
        i = 0; 
    } catch (NullPointerException nullPointerException) {
      i = j;
    } 
    if (i != 0)
      androidx.core.content.res.h.f.a(d.getTheme()); 
    return super.i((Context)d);
  }
  
  public View i0(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    z z1 = this.x1;
    boolean bool1 = false;
    if (z1 == null) {
      String str = this.C0.obtainStyledAttributes(g.j.AppCompatTheme).getString(g.j.AppCompatTheme_viewInflaterClass);
      if (str == null) {
        this.x1 = new z();
      } else {
        try {
          this.x1 = this.C0.getClassLoader().loadClass(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } finally {
          Exception exception = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), exception);
        } 
      } 
    } 
    boolean bool2 = C1;
    if (bool2) {
      if (this.y1 == null)
        this.y1 = new d0(); 
      if (this.y1.a(paramAttributeSet)) {
        bool1 = true;
      } else if (paramAttributeSet instanceof XmlPullParser) {
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = true; 
      } else {
        bool1 = Y0((ViewParent)paramView);
      } 
    } else {
      bool1 = false;
    } 
    return this.x1.r(paramView, paramString, paramContext, paramAttributeSet, bool1, bool2, true, z0.c());
  }
  
  void j0() {
    w w1 = this.J0;
    if (w1 != null)
      w1.i(); 
    if (this.O0 != null) {
      this.D0.getDecorView().removeCallbacks(this.P0);
      if (this.O0.isShowing())
        try {
          this.O0.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.O0 = null;
    } 
    m0();
    u u1 = w0(0, false);
    if (u1 != null) {
      g g1 = u1.j;
      if (g1 != null)
        g1.close(); 
    } 
  }
  
  boolean k0(KeyEvent paramKeyEvent) {
    Object object = this.B0;
    boolean bool1 = object instanceof androidx.core.view.p.a;
    boolean bool = true;
    if (bool1 || object instanceof x) {
      object = this.D0.getDecorView();
      if (object != null && androidx.core.view.p.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.E0.b(this.D0.getCallback(), paramKeyEvent))
      return true; 
    int i = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? H0(i, paramKeyEvent) : K0(i, paramKeyEvent);
  }
  
  public <T extends View> T l(int paramInt) {
    n0();
    return (T)this.D0.findViewById(paramInt);
  }
  
  void l0(int paramInt) {
    u u1 = w0(paramInt, true);
    if (u1.j != null) {
      Bundle bundle = new Bundle();
      u1.j.T(bundle);
      if (bundle.size() > 0)
        u1.s = bundle; 
      u1.j.h0();
      u1.j.clear();
    } 
    u1.r = true;
    u1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.J0 != null) {
      u1 = w0(0, false);
      if (u1 != null) {
        u1.m = false;
        S0(u1, null);
      } 
    } 
  }
  
  void m0() {
    u0 u01 = this.Q0;
    if (u01 != null)
      u01.c(); 
  }
  
  public Context n() {
    return this.C0;
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return i0(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public final b p() {
    return new f(this);
  }
  
  u p0(Menu paramMenu) {
    byte b1;
    u[] arrayOfU = this.e1;
    int i = 0;
    if (arrayOfU != null) {
      b1 = arrayOfU.length;
    } else {
      b1 = 0;
    } 
    while (i < b1) {
      u u1 = arrayOfU[i];
      if (u1 != null && u1.j == paramMenu)
        return u1; 
      i++;
    } 
    return null;
  }
  
  public int q() {
    return this.l1;
  }
  
  final Context r0() {
    Context context;
    a a1 = u();
    if (a1 != null) {
      Context context1 = a1.k();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null)
      context = this.C0; 
    return context;
  }
  
  public MenuInflater s() {
    if (this.H0 == null) {
      Context context;
      z0();
      a a1 = this.G0;
      if (a1 != null) {
        context = a1.k();
      } else {
        context = this.C0;
      } 
      this.H0 = (MenuInflater)new androidx.appcompat.view.g(context);
    } 
    return this.H0;
  }
  
  public a u() {
    z0();
    return this.G0;
  }
  
  public void v() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.C0);
    if (layoutInflater.getFactory() == null) {
      androidx.core.view.q.a(layoutInflater, this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof h))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  androidx.core.os.i v0(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? l.b(paramConfiguration) : androidx.core.os.i.c(k.b(paramConfiguration.locale));
  }
  
  public void w() {
    if (Q0() != null) {
      if (u().l())
        return; 
      D0(0);
    } 
  }
  
  protected u w0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e1 : [Landroidx/appcompat/app/h$u;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray androidx/appcompat/app/h$u
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield e1 : [Landroidx/appcompat/app/h$u;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new androidx/appcompat/app/h$u
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  final CharSequence x0() {
    Object object = this.B0;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.I0;
  }
  
  final Window.Callback y0() {
    return this.D0.getCallback();
  }
  
  public void z(Configuration paramConfiguration) {
    if (this.Y0 && this.S0) {
      a a1 = u();
      if (a1 != null)
        a1.m(paramConfiguration); 
    } 
    androidx.appcompat.widget.g.b().g(this.C0);
    this.k1 = new Configuration(this.C0.getResources().getConfiguration());
    W(false, false);
  }
  
  class a implements Runnable {
    a(h this$0) {}
    
    public void run() {
      h h1 = this.s0;
      if ((h1.s1 & 0x1) != 0)
        h1.l0(0); 
      h1 = this.s0;
      if ((h1.s1 & 0x1000) != 0)
        h1.l0(108); 
      h1 = this.s0;
      h1.r1 = false;
      h1.s1 = 0;
    }
  }
  
  class b implements e0 {
    b(h this$0) {}
    
    public m1 a(View param1View, m1 param1m1) {
      int i = param1m1.l();
      int j = this.a.h1(param1m1, null);
      m1 m11 = param1m1;
      if (i != j)
        m11 = param1m1.q(param1m1.j(), j, param1m1.k(), param1m1.i()); 
      return m0.e0(param1View, m11);
    }
  }
  
  class c implements ContentFrameLayout.a {
    c(h this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.j0();
    }
  }
  
  class d implements Runnable {
    d(h this$0) {}
    
    public void run() {
      h h1 = this.s0;
      h1.O0.showAtLocation((View)h1.N0, 55, 0, 0);
      this.s0.m0();
      if (this.s0.X0()) {
        this.s0.N0.setAlpha(0.0F);
        h1 = this.s0;
        h1.Q0 = m0.e((View)h1.N0).b(1.0F);
        this.s0.Q0.h((v0)new a(this));
        return;
      } 
      this.s0.N0.setAlpha(1.0F);
      this.s0.N0.setVisibility(0);
    }
    
    class a extends w0 {
      a(h.d this$0) {}
      
      public void b(View param2View) {
        this.a.s0.N0.setAlpha(1.0F);
        this.a.s0.Q0.h(null);
        this.a.s0.Q0 = null;
      }
      
      public void c(View param2View) {
        this.a.s0.N0.setVisibility(0);
      }
    }
  }
  
  class a extends w0 {
    a(h this$0) {}
    
    public void b(View param1View) {
      this.a.s0.N0.setAlpha(1.0F);
      this.a.s0.Q0.h(null);
      this.a.s0.Q0 = null;
    }
    
    public void c(View param1View) {
      this.a.s0.N0.setVisibility(0);
    }
  }
  
  class e extends w0 {
    e(h this$0) {}
    
    public void b(View param1View) {
      this.a.N0.setAlpha(1.0F);
      this.a.Q0.h(null);
      this.a.Q0 = null;
    }
    
    public void c(View param1View) {
      this.a.N0.setVisibility(0);
      if (this.a.N0.getParent() instanceof View)
        m0.p0((View)this.a.N0.getParent()); 
    }
  }
  
  private class f implements b {
    f(h this$0) {}
  }
  
  static interface g {
    boolean a(int param1Int);
    
    View onCreatePanelView(int param1Int);
  }
  
  private final class h implements androidx.appcompat.view.menu.m.a {
    h(h this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      this.s0.c0(param1g);
    }
    
    public boolean c(g param1g) {
      Window.Callback callback = this.s0.y0();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1g); 
      return true;
    }
  }
  
  class i implements androidx.appcompat.view.b.a {
    private androidx.appcompat.view.b.a a;
    
    public i(h this$0, androidx.appcompat.view.b.a param1a) {
      this.a = param1a;
    }
    
    public void a(androidx.appcompat.view.b param1b) {
      this.a.a(param1b);
      h h1 = this.b;
      if (h1.O0 != null)
        h1.D0.getDecorView().removeCallbacks(this.b.P0); 
      h1 = this.b;
      if (h1.N0 != null) {
        h1.m0();
        h1 = this.b;
        h1.Q0 = m0.e((View)h1.N0).b(0.0F);
        this.b.Q0.h((v0)new a(this));
      } 
      h1 = this.b;
      e e = h1.F0;
      if (e != null)
        e.onSupportActionModeFinished(h1.M0); 
      h1 = this.b;
      h1.M0 = null;
      m0.p0((View)h1.T0);
      this.b.f1();
    }
    
    public boolean b(androidx.appcompat.view.b param1b, Menu param1Menu) {
      return this.a.b(param1b, param1Menu);
    }
    
    public boolean c(androidx.appcompat.view.b param1b, MenuItem param1MenuItem) {
      return this.a.c(param1b, param1MenuItem);
    }
    
    public boolean d(androidx.appcompat.view.b param1b, Menu param1Menu) {
      m0.p0((View)this.b.T0);
      return this.a.d(param1b, param1Menu);
    }
    
    class a extends w0 {
      a(h.i this$0) {}
      
      public void b(View param2View) {
        this.a.b.N0.setVisibility(8);
        h h = this.a.b;
        PopupWindow popupWindow = h.O0;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (h.N0.getParent() instanceof View) {
          m0.p0((View)this.a.b.N0.getParent());
        } 
        this.a.b.N0.k();
        this.a.b.Q0.h(null);
        h = this.a.b;
        h.Q0 = null;
        m0.p0((View)h.T0);
      }
    }
  }
  
  class a extends w0 {
    a(h this$0) {}
    
    public void b(View param1View) {
      this.a.b.N0.setVisibility(8);
      h h = this.a.b;
      PopupWindow popupWindow = h.O0;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (h.N0.getParent() instanceof View) {
        m0.p0((View)this.a.b.N0.getParent());
      } 
      this.a.b.N0.k();
      this.a.b.Q0.h(null);
      h = this.a.b;
      h.Q0 = null;
      m0.p0((View)h.T0);
    }
  }
  
  static class j {
    static Context a(Context param1Context, Configuration param1Configuration) {
      return param1Context.createConfigurationContext(param1Configuration);
    }
    
    static void b(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.densityDpi;
      int k = param1Configuration2.densityDpi;
      if (i != k)
        param1Configuration3.densityDpi = k; 
    }
    
    static void c(Configuration param1Configuration, Locale param1Locale) {
      param1Configuration.setLayoutDirection(param1Locale);
    }
    
    static void d(Configuration param1Configuration, Locale param1Locale) {
      param1Configuration.setLocale(param1Locale);
    }
  }
  
  static class k {
    static boolean a(PowerManager param1PowerManager) {
      return param1PowerManager.isPowerSaveMode();
    }
    
    static String b(Locale param1Locale) {
      return param1Locale.toLanguageTag();
    }
  }
  
  static class l {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      LocaleList localeList1 = k.a(param1Configuration1);
      LocaleList localeList2 = k.a(param1Configuration2);
      if (!n.a(localeList1, localeList2)) {
        m.a(param1Configuration3, localeList2);
        param1Configuration3.locale = param1Configuration2.locale;
      } 
    }
    
    static androidx.core.os.i b(Configuration param1Configuration) {
      return androidx.core.os.i.c(l.a(k.a(param1Configuration)));
    }
    
    public static void c(androidx.core.os.i param1i) {
      j.a(i.a(param1i.h()));
    }
    
    static void d(Configuration param1Configuration, androidx.core.os.i param1i) {
      m.a(param1Configuration, i.a(param1i.h()));
    }
  }
  
  static class m {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      if ((o.a(param1Configuration1) & 0x3) != (o.a(param1Configuration2) & 0x3))
        p.a(param1Configuration3, o.a(param1Configuration3) | o.a(param1Configuration2) & 0x3); 
      if ((o.a(param1Configuration1) & 0xC) != (o.a(param1Configuration2) & 0xC))
        p.a(param1Configuration3, o.a(param1Configuration3) | o.a(param1Configuration2) & 0xC); 
    }
  }
  
  static class n {
    static OnBackInvokedDispatcher a(Activity param1Activity) {
      return q.a(param1Activity);
    }
    
    static OnBackInvokedCallback b(Object param1Object, h param1h) {
      Objects.requireNonNull(param1h);
      v v = new v(param1h);
      u.a(s.a(param1Object), 1000000, v);
      return v;
    }
    
    static void c(Object param1Object1, Object param1Object2) {
      param1Object2 = r.a(param1Object2);
      t.a(s.a(param1Object1), (OnBackInvokedCallback)param1Object2);
    }
  }
  
  class o extends androidx.appcompat.view.i {
    private h.g t0;
    
    private boolean u0;
    
    private boolean v0;
    
    private boolean w0;
    
    o(h this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public boolean b(Window.Callback param1Callback, KeyEvent param1KeyEvent) {
      try {
        this.v0 = true;
        return param1Callback.dispatchKeyEvent(param1KeyEvent);
      } finally {
        this.v0 = false;
      } 
    }
    
    public void c(Window.Callback param1Callback) {
      try {
        this.u0 = true;
        param1Callback.onContentChanged();
        return;
      } finally {
        this.u0 = false;
      } 
    }
    
    public void d(Window.Callback param1Callback, int param1Int, Menu param1Menu) {
      try {
        this.w0 = true;
        param1Callback.onPanelClosed(param1Int, param1Menu);
        return;
      } finally {
        this.w0 = false;
      } 
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return this.v0 ? a().dispatchKeyEvent(param1KeyEvent) : ((this.x0.k0(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent)));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.x0.J0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    void e(h.g param1g) {
      this.t0 = param1g;
    }
    
    final ActionMode f(ActionMode.Callback param1Callback) {
      androidx.appcompat.view.f.a a = new androidx.appcompat.view.f.a(this.x0.C0, param1Callback);
      androidx.appcompat.view.b b = this.x0.T((androidx.appcompat.view.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public void onContentChanged() {
      if (this.u0)
        a().onContentChanged(); 
    }
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof g)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public View onCreatePanelView(int param1Int) {
      h.g g1 = this.t0;
      if (g1 != null) {
        View view = g1.onCreatePanelView(param1Int);
        if (view != null)
          return view; 
      } 
      return super.onCreatePanelView(param1Int);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.x0.M0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      if (this.w0) {
        a().onPanelClosed(param1Int, param1Menu);
        return;
      } 
      super.onPanelClosed(param1Int, param1Menu);
      this.x0.N0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      g g1;
      if (param1Menu instanceof g) {
        g1 = (g)param1Menu;
      } else {
        g1 = null;
      } 
      if (param1Int == 0 && g1 == null)
        return false; 
      boolean bool1 = true;
      if (g1 != null)
        g1.e0(true); 
      h.g g2 = this.t0;
      if (g2 == null || !g2.a(param1Int))
        bool1 = false; 
      boolean bool2 = bool1;
      if (!bool1)
        bool2 = super.onPreparePanel(param1Int, param1View, param1Menu); 
      if (g1 != null)
        g1.e0(false); 
      return bool2;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      h.u u = this.x0.w0(0, true);
      if (u != null) {
        g g1 = u.j;
        if (g1 != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)g1, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return (Build.VERSION.SDK_INT >= 23) ? null : (this.x0.E0() ? f(param1Callback) : super.onWindowStartingActionMode(param1Callback));
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.x0.E0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : f(param1Callback);
    }
  }
  
  private class p extends q {
    private final PowerManager c;
    
    p(h this$0, Context param1Context) {
      super(this$0);
      this.c = (PowerManager)param1Context.getApplicationContext().getSystemService("power");
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
      return intentFilter;
    }
    
    public int c() {
      return h.k.a(this.c) ? 2 : 1;
    }
    
    public void d() {
      this.d.f();
    }
  }
  
  abstract class q {
    private BroadcastReceiver a;
    
    q(h this$0) {}
    
    void a() {
      BroadcastReceiver broadcastReceiver = this.a;
      if (broadcastReceiver != null) {
        try {
          this.b.C0.unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException illegalArgumentException) {}
        this.a = null;
      } 
    }
    
    abstract IntentFilter b();
    
    abstract int c();
    
    abstract void d();
    
    void e() {
      a();
      IntentFilter intentFilter = b();
      if (intentFilter != null) {
        if (intentFilter.countActions() == 0)
          return; 
        if (this.a == null)
          this.a = new a(this); 
        this.b.C0.registerReceiver(this.a, intentFilter);
      } 
    }
    
    class a extends BroadcastReceiver {
      a(h.q this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.d();
      }
    }
  }
  
  class a extends BroadcastReceiver {
    a(h this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.d();
    }
  }
  
  private class r extends q {
    private final i0 c;
    
    r(h this$0, i0 param1i0) {
      super(this$0);
      this.c = param1i0;
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.TIME_SET");
      intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
      intentFilter.addAction("android.intent.action.TIME_TICK");
      return intentFilter;
    }
    
    public int c() {
      return this.c.d() ? 2 : 1;
    }
    
    public void d() {
      this.d.f();
    }
  }
  
  private static class s {
    static void a(ContextThemeWrapper param1ContextThemeWrapper, Configuration param1Configuration) {
      param1ContextThemeWrapper.applyOverrideConfiguration(param1Configuration);
    }
  }
  
  private class t extends ContentFrameLayout {
    public t(h this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean b(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.A0.k0(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && b((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.A0.e0(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(h.a.b(getContext(), param1Int));
    }
  }
  
  protected static final class u {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    g j;
    
    androidx.appcompat.view.menu.e k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    public boolean p;
    
    boolean q;
    
    boolean r;
    
    Bundle s;
    
    u(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    androidx.appcompat.view.menu.n a(androidx.appcompat.view.menu.m.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        androidx.appcompat.view.menu.e e1 = new androidx.appcompat.view.menu.e(this.l, g.g.abc_list_menu_item_layout);
        this.k = e1;
        e1.d(param1a);
        this.j.b((androidx.appcompat.view.menu.m)this.k);
      } 
      return this.k.l(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.a().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    void c(g param1g) {
      g g1 = this.j;
      if (param1g == g1)
        return; 
      if (g1 != null)
        g1.Q((androidx.appcompat.view.menu.m)this.k); 
      this.j = param1g;
      if (param1g != null) {
        androidx.appcompat.view.menu.e e1 = this.k;
        if (e1 != null)
          param1g.b((androidx.appcompat.view.menu.m)e1); 
      } 
    }
    
    void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(g.a.actionBarPopupTheme, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(g.a.panelMenuListTheme, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(g.i.Theme_AppCompat_CompactMenu, true);
      } 
      androidx.appcompat.view.d d = new androidx.appcompat.view.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(g.j.AppCompatTheme);
      this.b = typedArray.getResourceId(g.j.AppCompatTheme_panelBackground, 0);
      this.f = typedArray.getResourceId(g.j.AppCompatTheme_android_windowAnimationStyle, 0);
      typedArray.recycle();
    }
  }
  
  private final class v implements androidx.appcompat.view.menu.m.a {
    v(h this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      boolean bool;
      g g1 = param1g.F();
      if (g1 != param1g) {
        bool = true;
      } else {
        bool = false;
      } 
      h h1 = this.s0;
      if (bool)
        param1g = g1; 
      h.u u = h1.p0((Menu)param1g);
      if (u != null) {
        if (bool) {
          this.s0.b0(u.a, u, (Menu)g1);
          this.s0.f0(u, true);
          return;
        } 
        this.s0.f0(u, param1Boolean);
      } 
    }
    
    public boolean c(g param1g) {
      if (param1g == param1g.F()) {
        h h1 = this.s0;
        if (h1.Y0) {
          Window.Callback callback = h1.y0();
          if (callback != null && !this.s0.j1)
            callback.onMenuOpened(108, (Menu)param1g); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */