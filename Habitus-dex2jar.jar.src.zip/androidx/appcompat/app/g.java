package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.LocaleManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.LocaleList;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.Toolbar;
import androidx.core.os.i;
import java.lang.ref.WeakReference;
import java.util.Iterator;

public abstract class g {
  private static final Object A0;
  
  static c0.a s0 = new c0.a(new c0.b());
  
  private static int t0 = -100;
  
  private static i u0 = null;
  
  private static i v0 = null;
  
  private static Boolean w0 = null;
  
  private static boolean x0 = false;
  
  private static final androidx.collection.b<WeakReference<g>> y0 = new androidx.collection.b();
  
  private static final Object z0 = new Object();
  
  static {
    A0 = new Object();
  }
  
  static void H(g paramg) {
    synchronized (z0) {
      I(paramg);
      return;
    } 
  }
  
  private static void I(g paramg) {
    synchronized (z0) {
      Iterator<WeakReference<g>> iterator = y0.iterator();
      while (iterator.hasNext()) {
        g g1 = ((WeakReference<g>)iterator.next()).get();
        if (g1 == paramg || g1 == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  public static void N(int paramInt) {
    if (paramInt != -1 && paramInt != 0 && paramInt != 1 && paramInt != 2 && paramInt != 3)
      return; 
    if (t0 != paramInt) {
      t0 = paramInt;
      g();
    } 
  }
  
  static void U(Context paramContext) {
    if (!x(paramContext))
      return; 
    if (androidx.core.os.a.b()) {
      if (!x0) {
        s0.execute(new f(paramContext));
        return;
      } 
    } else {
      synchronized (A0) {
        i i1 = u0;
        if (i1 == null) {
          if (v0 == null)
            v0 = i.c(c0.b(paramContext)); 
          if (v0.f())
            return; 
          u0 = v0;
        } else if (!i1.equals(v0)) {
          i1 = u0;
          v0 = i1;
          c0.a(paramContext, i1.h());
        } 
        return;
      } 
    } 
  }
  
  static void d(g paramg) {
    synchronized (z0) {
      I(paramg);
      y0.add(new WeakReference<g>(paramg));
      return;
    } 
  }
  
  private static void g() {
    synchronized (z0) {
      Iterator<WeakReference<g>> iterator = y0.iterator();
      while (iterator.hasNext()) {
        g g1 = ((WeakReference<g>)iterator.next()).get();
        if (g1 != null)
          g1.f(); 
      } 
      return;
    } 
  }
  
  public static g j(Activity paramActivity, e parame) {
    return new h(paramActivity, parame);
  }
  
  public static g k(Dialog paramDialog, e parame) {
    return new h(paramDialog, parame);
  }
  
  public static i m() {
    if (androidx.core.os.a.b()) {
      Object object = r();
      if (object != null)
        return i.j(b.a(object)); 
    } else {
      i i1 = u0;
      if (i1 != null)
        return i1; 
    } 
    return i.e();
  }
  
  public static int o() {
    return t0;
  }
  
  static Object r() {
    Iterator<WeakReference<g>> iterator = y0.iterator();
    while (iterator.hasNext()) {
      g g1 = ((WeakReference<g>)iterator.next()).get();
      if (g1 != null) {
        Context context = g1.n();
        if (context != null)
          return context.getSystemService("locale"); 
      } 
    } 
    return null;
  }
  
  static i t() {
    return u0;
  }
  
  static boolean x(Context paramContext) {
    if (w0 == null)
      try {
        Bundle bundle = (a0.a(paramContext)).metaData;
        if (bundle != null)
          w0 = Boolean.valueOf(bundle.getBoolean("autoStoreLocales")); 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        w0 = Boolean.FALSE;
      }  
    return w0.booleanValue();
  }
  
  public abstract void A(Bundle paramBundle);
  
  public abstract void B();
  
  public abstract void C(Bundle paramBundle);
  
  public abstract void D();
  
  public abstract void E(Bundle paramBundle);
  
  public abstract void F();
  
  public abstract void G();
  
  public abstract boolean J(int paramInt);
  
  public abstract void K(int paramInt);
  
  public abstract void L(View paramView);
  
  public abstract void M(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract void O(int paramInt);
  
  public void P(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {}
  
  public abstract void Q(Toolbar paramToolbar);
  
  public void R(int paramInt) {}
  
  public abstract void S(CharSequence paramCharSequence);
  
  public abstract androidx.appcompat.view.b T(androidx.appcompat.view.b.a parama);
  
  public abstract void e(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract boolean f();
  
  @Deprecated
  public void h(Context paramContext) {}
  
  public Context i(Context paramContext) {
    h(paramContext);
    return paramContext;
  }
  
  public abstract <T extends View> T l(int paramInt);
  
  public Context n() {
    return null;
  }
  
  public abstract b p();
  
  public int q() {
    return -100;
  }
  
  public abstract MenuInflater s();
  
  public abstract a u();
  
  public abstract void v();
  
  public abstract void w();
  
  public abstract void z(Configuration paramConfiguration);
  
  static class a {
    static LocaleList a(String param1String) {
      return LocaleList.forLanguageTags(param1String);
    }
  }
  
  static class b {
    static LocaleList a(Object param1Object) {
      return ((LocaleManager)param1Object).getApplicationLocales();
    }
    
    static void b(Object param1Object, LocaleList param1LocaleList) {
      ((LocaleManager)param1Object).setApplicationLocales(param1LocaleList);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */