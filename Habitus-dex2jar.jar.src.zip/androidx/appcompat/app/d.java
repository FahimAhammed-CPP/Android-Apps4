package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.p;
import androidx.activity.s;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.z0;
import androidx.core.app.k;
import androidx.core.app.x;
import androidx.core.os.i;
import androidx.fragment.app.s;
import androidx.lifecycle.p;
import androidx.lifecycle.r0;
import androidx.lifecycle.s0;
import androidx.lifecycle.t0;
import d4.e;

public class d extends s implements e, x.a {
  private static final String DELEGATE_TAG = "androidx:appcompat";
  
  private g mDelegate;
  
  private Resources mResources;
  
  public d() {
    initDelegate();
  }
  
  public d(int paramInt) {
    super(paramInt);
    initDelegate();
  }
  
  private void initDelegate() {
    getSavedStateRegistry().h("androidx:appcompat", new a(this));
    addOnContextAvailableListener(new b(this));
  }
  
  private void initViewTreeOwners() {
    s0.b(getWindow().getDecorView(), (p)this);
    t0.b(getWindow().getDecorView(), (r0)this);
    e.b(getWindow().getDecorView(), (d4.d)this);
    s.b(getWindow().getDecorView(), (p)this);
  }
  
  private boolean performMenuItemShortcut(KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    getDelegate().e(paramView, paramLayoutParams);
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(getDelegate().i(paramContext));
  }
  
  public void closeOptionsMenu() {
    a a1 = getSupportActionBar();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.g()))
      super.closeOptionsMenu(); 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a1 = getSupportActionBar();
    return (i == 82 && a1 != null && a1.p(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return getDelegate().l(paramInt);
  }
  
  public g getDelegate() {
    if (this.mDelegate == null)
      this.mDelegate = g.j((Activity)this, this); 
    return this.mDelegate;
  }
  
  public b getDrawerToggleDelegate() {
    return getDelegate().p();
  }
  
  public MenuInflater getMenuInflater() {
    return getDelegate().s();
  }
  
  public Resources getResources() {
    if (this.mResources == null && z0.c())
      this.mResources = (Resources)new z0((Context)this, super.getResources()); 
    Resources resources2 = this.mResources;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public a getSupportActionBar() {
    return getDelegate().u();
  }
  
  public Intent getSupportParentActivityIntent() {
    return k.a((Activity)this);
  }
  
  public void invalidateOptionsMenu() {
    getDelegate().w();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    getDelegate().z(paramConfiguration);
    if (this.mResources != null) {
      paramConfiguration = super.getResources().getConfiguration();
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.mResources.updateConfiguration(paramConfiguration, displayMetrics);
    } 
  }
  
  public void onContentChanged() {
    onSupportContentChanged();
  }
  
  public void onCreateSupportNavigateUpTaskStack(x paramx) {
    paramx.e((Activity)this);
  }
  
  protected void onDestroy() {
    super.onDestroy();
    getDelegate().B();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return performMenuItemShortcut(paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  protected void onLocalesChanged(i parami) {}
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a1 = getSupportActionBar();
    return (paramMenuItem.getItemId() == 16908332 && a1 != null && (a1.j() & 0x4) != 0) ? onSupportNavigateUp() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  protected void onNightModeChanged(int paramInt) {}
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    getDelegate().C(paramBundle);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    getDelegate().D();
  }
  
  public void onPrepareSupportNavigateUpTaskStack(x paramx) {}
  
  protected void onStart() {
    super.onStart();
    getDelegate().F();
  }
  
  protected void onStop() {
    super.onStop();
    getDelegate().G();
  }
  
  public void onSupportActionModeFinished(androidx.appcompat.view.b paramb) {}
  
  public void onSupportActionModeStarted(androidx.appcompat.view.b paramb) {}
  
  @Deprecated
  public void onSupportContentChanged() {}
  
  public boolean onSupportNavigateUp() {
    Intent intent = getSupportParentActivityIntent();
    if (intent != null) {
      if (supportShouldUpRecreateTask(intent)) {
        x x = x.i((Context)this);
        onCreateSupportNavigateUpTaskStack(x);
        onPrepareSupportNavigateUpTaskStack(x);
        x.j();
        try {
          androidx.core.app.b.p((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        supportNavigateUpTo((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    getDelegate().S(paramCharSequence);
  }
  
  public androidx.appcompat.view.b onWindowStartingSupportActionMode(androidx.appcompat.view.b.a parama) {
    return null;
  }
  
  public void openOptionsMenu() {
    a a1 = getSupportActionBar();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.q()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    getDelegate().K(paramInt);
  }
  
  public void setContentView(View paramView) {
    initViewTreeOwners();
    getDelegate().L(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    getDelegate().M(paramView, paramLayoutParams);
  }
  
  public void setSupportActionBar(Toolbar paramToolbar) {
    getDelegate().Q(paramToolbar);
  }
  
  @Deprecated
  public void setSupportProgress(int paramInt) {}
  
  @Deprecated
  public void setSupportProgressBarIndeterminate(boolean paramBoolean) {}
  
  @Deprecated
  public void setSupportProgressBarIndeterminateVisibility(boolean paramBoolean) {}
  
  @Deprecated
  public void setSupportProgressBarVisibility(boolean paramBoolean) {}
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    getDelegate().R(paramInt);
  }
  
  public androidx.appcompat.view.b startSupportActionMode(androidx.appcompat.view.b.a parama) {
    return getDelegate().T(parama);
  }
  
  public void supportInvalidateOptionsMenu() {
    getDelegate().w();
  }
  
  public void supportNavigateUpTo(Intent paramIntent) {
    k.e((Activity)this, paramIntent);
  }
  
  public boolean supportRequestWindowFeature(int paramInt) {
    return getDelegate().J(paramInt);
  }
  
  public boolean supportShouldUpRecreateTask(Intent paramIntent) {
    return k.f((Activity)this, paramIntent);
  }
  
  class a implements androidx.savedstate.a.c {
    a(d this$0) {}
    
    public Bundle saveState() {
      Bundle bundle = new Bundle();
      this.a.getDelegate().E(bundle);
      return bundle;
    }
  }
  
  class b implements e.b {
    b(d this$0) {}
    
    public void onContextAvailable(Context param1Context) {
      g g = this.a.getDelegate();
      g.v();
      g.A(this.a.getSavedStateRegistry().b("androidx:appcompat"));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */