package androidx.appcompat.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.i;
import androidx.appcompat.view.b;
import androidx.core.view.p;
import g.a;

public class x extends i implements e {
  private g mDelegate;
  
  private final p.a mKeyDispatcher = new w(this);
  
  public x(Context paramContext) {
    this(paramContext, 0);
  }
  
  public x(Context paramContext, int paramInt) {
    super(paramContext, getThemeResId(paramContext, paramInt));
    g g1 = getDelegate();
    g1.R(getThemeResId(paramContext, paramInt));
    g1.A(null);
  }
  
  protected x(Context paramContext, boolean paramBoolean, DialogInterface.OnCancelListener paramOnCancelListener) {
    super(paramContext);
    setCancelable(paramBoolean);
    setOnCancelListener(paramOnCancelListener);
  }
  
  private static int getThemeResId(Context paramContext, int paramInt) {
    int j = paramInt;
    if (paramInt == 0) {
      TypedValue typedValue = new TypedValue();
      paramContext.getTheme().resolveAttribute(a.dialogTheme, typedValue, true);
      j = typedValue.resourceId;
    } 
    return j;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    getDelegate().e(paramView, paramLayoutParams);
  }
  
  public void dismiss() {
    super.dismiss();
    getDelegate().B();
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return p.e(this.mKeyDispatcher, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return getDelegate().l(paramInt);
  }
  
  public g getDelegate() {
    if (this.mDelegate == null)
      this.mDelegate = g.k((Dialog)this, this); 
    return this.mDelegate;
  }
  
  public a getSupportActionBar() {
    return getDelegate().u();
  }
  
  public void invalidateOptionsMenu() {
    getDelegate().w();
  }
  
  protected void onCreate(Bundle paramBundle) {
    getDelegate().v();
    super.onCreate(paramBundle);
    getDelegate().A(paramBundle);
  }
  
  protected void onStop() {
    super.onStop();
    getDelegate().G();
  }
  
  public void onSupportActionModeFinished(b paramb) {}
  
  public void onSupportActionModeStarted(b paramb) {}
  
  public b onWindowStartingSupportActionMode(b.a parama) {
    return null;
  }
  
  public void setContentView(int paramInt) {
    getDelegate().K(paramInt);
  }
  
  public void setContentView(View paramView) {
    getDelegate().L(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    getDelegate().M(paramView, paramLayoutParams);
  }
  
  public void setTitle(int paramInt) {
    super.setTitle(paramInt);
    getDelegate().S(getContext().getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    getDelegate().S(paramCharSequence);
  }
  
  boolean superDispatchKeyEvent(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean supportRequestWindowFeature(int paramInt) {
    return getDelegate().J(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */