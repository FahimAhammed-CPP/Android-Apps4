package androidx.appcompat.app;

import android.content.res.Resources;
import android.os.Build;
import android.util.Log;
import android.util.LongSparseArray;
import java.lang.reflect.Field;
import java.util.Map;

class f0 {
  private static Field a;
  
  private static boolean b;
  
  private static Class<?> c;
  
  private static boolean d;
  
  private static Field e;
  
  private static boolean f;
  
  private static Field g;
  
  private static boolean h;
  
  static void a(Resources paramResources) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 28)
      return; 
    if (i >= 24) {
      d(paramResources);
      return;
    } 
    if (i >= 23) {
      c(paramResources);
      return;
    } 
    b(paramResources);
  }
  
  private static void b(Resources paramResources) {
    if (!b) {
      try {
        Field field1 = Resources.class.getDeclaredField("mDrawableCache");
        a = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", noSuchFieldException);
      } 
      b = true;
    } 
    Field field = a;
    if (field != null) {
      try {
        Map map = (Map)field.get(paramResources);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", illegalAccessException);
        illegalAccessException = null;
      } 
      if (illegalAccessException != null)
        illegalAccessException.clear(); 
    } 
  }
  
  private static void c(Resources paramResources) {
    if (!b) {
      try {
        Field field1 = Resources.class.getDeclaredField("mDrawableCache");
        a = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", noSuchFieldException);
      } 
      b = true;
    } 
    Field field = a;
    if (field != null) {
      try {
        object = field.get(paramResources);
      } catch (IllegalAccessException object) {
        Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", (Throwable)object);
        object = null;
      } 
      if (object == null)
        return; 
      e(object);
      return;
    } 
    paramResources = null;
  }
  
  private static void d(Resources paramResources) {
    if (!h) {
      try {
        Field field = Resources.class.getDeclaredField("mResourcesImpl");
        g = field;
        field.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mResourcesImpl field", noSuchFieldException);
      } 
      h = true;
    } 
    Field field1 = g;
    if (field1 == null)
      return; 
    Field field2 = null;
    try {
      object = field1.get(paramResources);
    } catch (IllegalAccessException object) {
      Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mResourcesImpl", (Throwable)object);
      object = null;
    } 
    if (object == null)
      return; 
    if (!b) {
      try {
        field1 = object.getClass().getDeclaredField("mDrawableCache");
        a = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("ResourcesFlusher", "Could not retrieve ResourcesImpl#mDrawableCache field", noSuchFieldException);
      } 
      b = true;
    } 
    Field field3 = a;
    field1 = field2;
    if (field3 != null)
      try {
        Object object1 = field3.get(object);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("ResourcesFlusher", "Could not retrieve value from ResourcesImpl#mDrawableCache", illegalAccessException);
        field1 = field2;
      }  
    if (field1 != null)
      e(field1); 
  }
  
  private static void e(Object paramObject) {
    if (!d) {
      try {
        c = Class.forName("android.content.res.ThemedResourceCache");
      } catch (ClassNotFoundException classNotFoundException) {
        Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", classNotFoundException);
      } 
      d = true;
    } 
    Class<?> clazz = c;
    if (clazz == null)
      return; 
    if (!f) {
      try {
        Field field1 = clazz.getDeclaredField("mUnthemedEntries");
        e = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", noSuchFieldException);
      } 
      f = true;
    } 
    Field field = e;
    if (field == null)
      return; 
    try {
      paramObject = field.get(paramObject);
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", illegalAccessException);
      illegalAccessException = null;
    } 
    if (illegalAccessException != null)
      a.a((LongSparseArray)illegalAccessException); 
  }
  
  static class a {
    static void a(LongSparseArray param1LongSparseArray) {
      param1LongSparseArray.clear();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */