package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.t0;
import androidx.appcompat.widget.x;
import androidx.core.util.i;
import androidx.core.view.m0;
import java.util.ArrayList;

class g0 extends a {
  final x a;
  
  final Window.Callback b;
  
  final h.g c;
  
  boolean d;
  
  private boolean e;
  
  private boolean f;
  
  private ArrayList<a.b> g = new ArrayList<a.b>();
  
  private final Runnable h = new a(this);
  
  private final Toolbar.h i;
  
  g0(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback) {
    b b = new b(this);
    this.i = b;
    i.g(paramToolbar);
    t0 t0 = new t0(paramToolbar, false);
    this.a = (x)t0;
    this.b = (Window.Callback)i.g(paramCallback);
    t0.setWindowCallback(paramCallback);
    paramToolbar.setOnMenuItemClickListener(b);
    t0.setWindowTitle(paramCharSequence);
    this.c = new e(this);
  }
  
  private Menu B() {
    if (!this.e) {
      this.a.u(new c(this), new d(this));
      this.e = true;
    } 
    return this.a.j();
  }
  
  void C() {
    g g1;
    null = B();
    if (null instanceof g) {
      g1 = (g)null;
    } else {
      g1 = null;
    } 
    if (g1 != null)
      g1.h0(); 
    try {
      null.clear();
      if (!this.b.onCreatePanelMenu(0, null) || !this.b.onPreparePanel(0, null, null))
        null.clear(); 
      return;
    } finally {
      if (g1 != null)
        g1.g0(); 
    } 
  }
  
  public void D(int paramInt1, int paramInt2) {
    int i = this.a.w();
    this.a.i(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  public boolean g() {
    return this.a.b();
  }
  
  public boolean h() {
    if (this.a.h()) {
      this.a.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean == this.f)
      return; 
    this.f = paramBoolean;
    int j = this.g.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.g.get(i)).a(paramBoolean); 
  }
  
  public int j() {
    return this.a.w();
  }
  
  public Context k() {
    return this.a.getContext();
  }
  
  public boolean l() {
    this.a.m().removeCallbacks(this.h);
    m0.k0((View)this.a.m(), this.h);
    return true;
  }
  
  public void m(Configuration paramConfiguration) {
    super.m(paramConfiguration);
  }
  
  void n() {
    this.a.m().removeCallbacks(this.h);
  }
  
  public boolean o(int paramInt, KeyEvent paramKeyEvent) {
    Menu menu = B();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public boolean p(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1)
      q(); 
    return true;
  }
  
  public boolean q() {
    return this.a.c();
  }
  
  public void r(boolean paramBoolean) {}
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    D(bool, 4);
  }
  
  public void t(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    D(bool, 8);
  }
  
  public void u(int paramInt) {
    this.a.t(paramInt);
  }
  
  public void v(Drawable paramDrawable) {
    this.a.y(paramDrawable);
  }
  
  public void w(boolean paramBoolean) {}
  
  public void x(boolean paramBoolean) {}
  
  public void y(CharSequence paramCharSequence) {
    this.a.setTitle(paramCharSequence);
  }
  
  public void z(CharSequence paramCharSequence) {
    this.a.setWindowTitle(paramCharSequence);
  }
  
  class a implements Runnable {
    a(g0 this$0) {}
    
    public void run() {
      this.s0.C();
    }
  }
  
  class b implements Toolbar.h {
    b(g0 this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      return this.a.b.onMenuItemSelected(0, param1MenuItem);
    }
  }
  
  private final class c implements m.a {
    private boolean s0;
    
    c(g0 this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      if (this.s0)
        return; 
      this.s0 = true;
      this.t0.a.q();
      this.t0.b.onPanelClosed(108, (Menu)param1g);
      this.s0 = false;
    }
    
    public boolean c(g param1g) {
      this.t0.b.onMenuOpened(108, (Menu)param1g);
      return true;
    }
  }
  
  private final class d implements g.a {
    d(g0 this$0) {}
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      return false;
    }
    
    public void b(g param1g) {
      if (this.s0.a.e()) {
        this.s0.b.onPanelClosed(108, (Menu)param1g);
        return;
      } 
      if (this.s0.b.onPreparePanel(0, null, (Menu)param1g))
        this.s0.b.onMenuOpened(108, (Menu)param1g); 
    }
  }
  
  private class e implements h.g {
    e(g0 this$0) {}
    
    public boolean a(int param1Int) {
      if (param1Int == 0) {
        g0 g01 = this.a;
        if (!g01.d) {
          g01.a.f();
          this.a.d = true;
        } 
      } 
      return false;
    }
    
    public View onCreatePanelView(int param1Int) {
      return (param1Int == 0) ? new View(this.a.a.getContext()) : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */