package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.view.g;
import androidx.appcompat.view.h;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.i0;
import androidx.appcompat.widget.x;
import androidx.core.view.m0;
import androidx.core.view.u0;
import androidx.core.view.v0;
import androidx.core.view.w0;
import androidx.core.view.x0;
import g.f;
import g.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class j0 extends a implements ActionBarOverlayLayout.d {
  private static final Interpolator E = (Interpolator)new AccelerateInterpolator();
  
  private static final Interpolator F = (Interpolator)new DecelerateInterpolator();
  
  boolean A;
  
  final v0 B = (v0)new a(this);
  
  final v0 C = (v0)new b(this);
  
  final x0 D = new c(this);
  
  Context a;
  
  private Context b;
  
  private Activity c;
  
  ActionBarOverlayLayout d;
  
  ActionBarContainer e;
  
  x f;
  
  ActionBarContextView g;
  
  View h;
  
  i0 i;
  
  private ArrayList<Object> j = new ArrayList();
  
  private int k = -1;
  
  private boolean l;
  
  d m;
  
  androidx.appcompat.view.b n;
  
  androidx.appcompat.view.b.a o;
  
  private boolean p;
  
  private ArrayList<a.b> q = new ArrayList<a.b>();
  
  private boolean r;
  
  private int s = 0;
  
  boolean t = true;
  
  boolean u;
  
  boolean v;
  
  private boolean w;
  
  private boolean x = true;
  
  h y;
  
  private boolean z;
  
  public j0(Activity paramActivity, boolean paramBoolean) {
    this.c = paramActivity;
    View view = paramActivity.getWindow().getDecorView();
    J(view);
    if (!paramBoolean)
      this.h = view.findViewById(16908290); 
  }
  
  public j0(Dialog paramDialog) {
    J(paramDialog.getWindow().getDecorView());
  }
  
  static boolean C(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  private x G(View paramView) {
    String str;
    if (paramView instanceof x)
      return (x)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    if (paramView != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    stringBuilder.append(str);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void I() {
    if (this.w) {
      this.w = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      Q(false);
    } 
  }
  
  private void J(View paramView) {
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(f.decor_content_parent);
    this.d = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    this.f = G(paramView.findViewById(f.action_bar));
    this.g = (ActionBarContextView)paramView.findViewById(f.action_context_bar);
    ActionBarContainer actionBarContainer = (ActionBarContainer)paramView.findViewById(f.action_bar_container);
    this.e = actionBarContainer;
    x x1 = this.f;
    if (x1 != null && this.g != null && actionBarContainer != null) {
      boolean bool;
      this.a = x1.getContext();
      if ((this.f.w() & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.l = true; 
      androidx.appcompat.view.a a1 = androidx.appcompat.view.a.b(this.a);
      if (a1.a() || i) {
        bool = true;
      } else {
        bool = false;
      } 
      w(bool);
      M(a1.g());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, j.ActionBar, g.a.actionBarStyle, 0);
      if (typedArray.getBoolean(j.ActionBar_hideOnContentScroll, false))
        N(true); 
      int i = typedArray.getDimensionPixelSize(j.ActionBar_elevation, 0);
      if (i != 0)
        L(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void M(boolean paramBoolean) {
    this.r = paramBoolean;
    if (!paramBoolean) {
      this.f.r(null);
      this.e.setTabContainer(this.i);
    } else {
      this.e.setTabContainer(null);
      this.f.r(this.i);
    } 
    int i = H();
    boolean bool = true;
    if (i == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    i0 i01 = this.i;
    if (i01 != null) {
      ActionBarOverlayLayout actionBarOverlayLayout1;
      if (i != 0) {
        i01.setVisibility(0);
        actionBarOverlayLayout1 = this.d;
        if (actionBarOverlayLayout1 != null)
          m0.p0((View)actionBarOverlayLayout1); 
      } else {
        actionBarOverlayLayout1.setVisibility(8);
      } 
    } 
    x x1 = this.f;
    if (!this.r && i != 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    x1.p(paramBoolean);
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (!this.r && i != 0) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(paramBoolean);
  }
  
  private boolean O() {
    return m0.W((View)this.e);
  }
  
  private void P() {
    if (!this.w) {
      this.w = true;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(true); 
      Q(false);
    } 
  }
  
  private void Q(boolean paramBoolean) {
    if (C(this.u, this.v, this.w)) {
      if (!this.x) {
        this.x = true;
        F(paramBoolean);
        return;
      } 
    } else if (this.x) {
      this.x = false;
      E(paramBoolean);
    } 
  }
  
  public androidx.appcompat.view.b A(androidx.appcompat.view.b.a parama) {
    d d2 = this.m;
    if (d2 != null)
      d2.c(); 
    this.d.setHideOnContentScrollEnabled(false);
    this.g.k();
    d d1 = new d(this, this.g.getContext(), parama);
    if (d1.t()) {
      this.m = d1;
      d1.k();
      this.g.h(d1);
      B(true);
      return d1;
    } 
    return null;
  }
  
  public void B(boolean paramBoolean) {
    if (paramBoolean) {
      P();
    } else {
      I();
    } 
    if (O()) {
      u0 u01;
      u0 u02;
      if (paramBoolean) {
        u02 = this.f.l(4, 100L);
        u01 = this.g.f(0, 200L);
      } else {
        u01 = this.f.l(0, 200L);
        u02 = this.g.f(8, 100L);
      } 
      h h1 = new h();
      h1.d(u02, u01);
      h1.h();
      return;
    } 
    if (paramBoolean) {
      this.f.v(4);
      this.g.setVisibility(0);
      return;
    } 
    this.f.v(0);
    this.g.setVisibility(8);
  }
  
  void D() {
    androidx.appcompat.view.b.a a1 = this.o;
    if (a1 != null) {
      a1.a(this.n);
      this.n = null;
      this.o = null;
    } 
  }
  
  public void E(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setAlpha(1.0F);
      this.e.setTransitioning(true);
      h1 = new h();
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      u0 u0 = m0.e((View)this.e).m(f1);
      u0.k(this.D);
      h1.c(u0);
      if (this.t) {
        View view = this.h;
        if (view != null)
          h1.c(m0.e(view).m(f1)); 
      } 
      h1.f(E);
      h1.e(250L);
      h1.g(this.B);
      this.y = h1;
      h1.h();
      return;
    } 
    this.B.b(null);
  }
  
  public void F(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    this.e.setVisibility(0);
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setTranslationY(0.0F);
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      this.e.setTranslationY(f1);
      h1 = new h();
      u0 u0 = m0.e((View)this.e).m(0.0F);
      u0.k(this.D);
      h1.c(u0);
      if (this.t) {
        View view = this.h;
        if (view != null) {
          view.setTranslationY(f1);
          h1.c(m0.e(this.h).m(0.0F));
        } 
      } 
      h1.f(F);
      h1.e(250L);
      h1.g(this.C);
      this.y = h1;
      h1.h();
    } else {
      this.e.setAlpha(1.0F);
      this.e.setTranslationY(0.0F);
      if (this.t) {
        View view = this.h;
        if (view != null)
          view.setTranslationY(0.0F); 
      } 
      this.C.b(null);
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (actionBarOverlayLayout != null)
      m0.p0((View)actionBarOverlayLayout); 
  }
  
  public int H() {
    return this.f.k();
  }
  
  public void K(int paramInt1, int paramInt2) {
    int i = this.f.w();
    if ((paramInt2 & 0x4) != 0)
      this.l = true; 
    this.f.i(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  public void L(float paramFloat) {
    m0.A0((View)this.e, paramFloat);
  }
  
  public void N(boolean paramBoolean) {
    if (!paramBoolean || this.d.q()) {
      this.A = paramBoolean;
      this.d.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void a() {
    if (this.v) {
      this.v = false;
      Q(true);
    } 
  }
  
  public void b(int paramInt) {
    this.s = paramInt;
  }
  
  public void c() {}
  
  public void d(boolean paramBoolean) {
    this.t = paramBoolean;
  }
  
  public void e() {
    if (!this.v) {
      this.v = true;
      Q(true);
    } 
  }
  
  public void f() {
    h h1 = this.y;
    if (h1 != null) {
      h1.a();
      this.y = null;
    } 
  }
  
  public boolean h() {
    x x1 = this.f;
    if (x1 != null && x1.h()) {
      this.f.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean == this.p)
      return; 
    this.p = paramBoolean;
    int j = this.q.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.q.get(i)).a(paramBoolean); 
  }
  
  public int j() {
    return this.f.w();
  }
  
  public Context k() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(g.a.actionBarWidgetTheme, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void m(Configuration paramConfiguration) {
    M(androidx.appcompat.view.a.b(this.a).g());
  }
  
  public boolean o(int paramInt, KeyEvent paramKeyEvent) {
    d d1 = this.m;
    if (d1 == null)
      return false; 
    Menu menu = d1.e();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void r(boolean paramBoolean) {
    if (!this.l)
      s(paramBoolean); 
  }
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    K(bool, 4);
  }
  
  public void t(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    K(bool, 8);
  }
  
  public void u(int paramInt) {
    this.f.t(paramInt);
  }
  
  public void v(Drawable paramDrawable) {
    this.f.y(paramDrawable);
  }
  
  public void w(boolean paramBoolean) {
    this.f.n(paramBoolean);
  }
  
  public void x(boolean paramBoolean) {
    this.z = paramBoolean;
    if (!paramBoolean) {
      h h1 = this.y;
      if (h1 != null)
        h1.a(); 
    } 
  }
  
  public void y(CharSequence paramCharSequence) {
    this.f.setTitle(paramCharSequence);
  }
  
  public void z(CharSequence paramCharSequence) {
    this.f.setWindowTitle(paramCharSequence);
  }
  
  class a extends w0 {
    a(j0 this$0) {}
    
    public void b(View param1View) {
      j0 j01 = this.a;
      if (j01.t) {
        View view = j01.h;
        if (view != null) {
          view.setTranslationY(0.0F);
          this.a.e.setTranslationY(0.0F);
        } 
      } 
      this.a.e.setVisibility(8);
      this.a.e.setTransitioning(false);
      j01 = this.a;
      j01.y = null;
      j01.D();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a.d;
      if (actionBarOverlayLayout != null)
        m0.p0((View)actionBarOverlayLayout); 
    }
  }
  
  class b extends w0 {
    b(j0 this$0) {}
    
    public void b(View param1View) {
      j0 j01 = this.a;
      j01.y = null;
      j01.e.requestLayout();
    }
  }
  
  class c implements x0 {
    c(j0 this$0) {}
    
    public void a(View param1View) {
      ((View)this.a.e.getParent()).invalidate();
    }
  }
  
  public class d extends androidx.appcompat.view.b implements g.a {
    private final Context u0;
    
    private final g v0;
    
    private androidx.appcompat.view.b.a w0;
    
    private WeakReference<View> x0;
    
    public d(j0 this$0, Context param1Context, androidx.appcompat.view.b.a param1a) {
      this.u0 = param1Context;
      this.w0 = param1a;
      g g1 = (new g(param1Context)).W(1);
      this.v0 = g1;
      g1.V(this);
    }
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      androidx.appcompat.view.b.a a1 = this.w0;
      return (a1 != null) ? a1.c(this, param1MenuItem) : false;
    }
    
    public void b(g param1g) {
      if (this.w0 == null)
        return; 
      k();
      this.y0.g.l();
    }
    
    public void c() {
      j0 j01 = this.y0;
      if (j01.m != this)
        return; 
      if (!j0.C(j01.u, j01.v, false)) {
        j01 = this.y0;
        j01.n = this;
        j01.o = this.w0;
      } else {
        this.w0.a(this);
      } 
      this.w0 = null;
      this.y0.B(false);
      this.y0.g.g();
      j01 = this.y0;
      j01.d.setHideOnContentScrollEnabled(j01.A);
      this.y0.m = null;
    }
    
    public View d() {
      WeakReference<View> weakReference = this.x0;
      return (weakReference != null) ? weakReference.get() : null;
    }
    
    public Menu e() {
      return (Menu)this.v0;
    }
    
    public MenuInflater f() {
      return (MenuInflater)new g(this.u0);
    }
    
    public CharSequence g() {
      return this.y0.g.getSubtitle();
    }
    
    public CharSequence i() {
      return this.y0.g.getTitle();
    }
    
    public void k() {
      if (this.y0.m != this)
        return; 
      this.v0.h0();
      try {
        this.w0.d(this, (Menu)this.v0);
        return;
      } finally {
        this.v0.g0();
      } 
    }
    
    public boolean l() {
      return this.y0.g.j();
    }
    
    public void m(View param1View) {
      this.y0.g.setCustomView(param1View);
      this.x0 = new WeakReference<View>(param1View);
    }
    
    public void n(int param1Int) {
      o(this.y0.a.getResources().getString(param1Int));
    }
    
    public void o(CharSequence param1CharSequence) {
      this.y0.g.setSubtitle(param1CharSequence);
    }
    
    public void q(int param1Int) {
      r(this.y0.a.getResources().getString(param1Int));
    }
    
    public void r(CharSequence param1CharSequence) {
      this.y0.g.setTitle(param1CharSequence);
    }
    
    public void s(boolean param1Boolean) {
      super.s(param1Boolean);
      this.y0.g.setTitleOptional(param1Boolean);
    }
    
    public boolean t() {
      this.v0.h0();
      try {
        return this.w0.b(this, (Menu)this.v0);
      } finally {
        this.v0.g0();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */