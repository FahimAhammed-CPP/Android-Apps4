package androidx.appcompat.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.InflateException;
import android.view.View;
import androidx.appcompat.view.d;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatCheckedTextView;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatMultiAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.AppCompatToggleButton;
import androidx.collection.g;
import androidx.core.view.m0;
import g.j;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class z {
  private static final Class<?>[] b = new Class[] { Context.class, AttributeSet.class };
  
  private static final int[] c = new int[] { 16843375 };
  
  private static final int[] d = new int[] { 16844160 };
  
  private static final int[] e = new int[] { 16844156 };
  
  private static final int[] f = new int[] { 16844148 };
  
  private static final String[] g = new String[] { "android.widget.", "android.view.", "android.webkit." };
  
  private static final g<String, Constructor<? extends View>> h = new g();
  
  private final Object[] a = new Object[2];
  
  private void a(Context paramContext, View paramView, AttributeSet paramAttributeSet) {
    if (Build.VERSION.SDK_INT > 28)
      return; 
    TypedArray typedArray2 = paramContext.obtainStyledAttributes(paramAttributeSet, d);
    if (typedArray2.hasValue(0))
      m0.t0(paramView, typedArray2.getBoolean(0, false)); 
    typedArray2.recycle();
    typedArray2 = paramContext.obtainStyledAttributes(paramAttributeSet, e);
    if (typedArray2.hasValue(0))
      m0.v0(paramView, typedArray2.getString(0)); 
    typedArray2.recycle();
    TypedArray typedArray1 = paramContext.obtainStyledAttributes(paramAttributeSet, f);
    if (typedArray1.hasValue(0))
      m0.K0(paramView, typedArray1.getBoolean(0, false)); 
    typedArray1.recycle();
  }
  
  private void b(View paramView, AttributeSet paramAttributeSet) {
    Context context = paramView.getContext();
    if (context instanceof ContextWrapper) {
      if (!m0.R(paramView))
        return; 
      TypedArray typedArray = context.obtainStyledAttributes(paramAttributeSet, c);
      String str = typedArray.getString(0);
      if (str != null)
        paramView.setOnClickListener(new a(paramView, str)); 
      typedArray.recycle();
    } 
  }
  
  private View s(Context paramContext, String paramString1, String paramString2) throws ClassNotFoundException, InflateException {
    g<String, Constructor<? extends View>> g1 = h;
    Constructor constructor1 = (Constructor)g1.get(paramString1);
    Constructor<View> constructor = constructor1;
    if (constructor1 == null) {
      if (paramString2 != null)
        try {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramString2);
          stringBuilder.append(paramString1);
          paramString2 = stringBuilder.toString();
          constructor = Class.forName(paramString2, false, paramContext.getClassLoader()).<View>asSubclass(View.class).getConstructor(b);
          g1.put(paramString1, constructor);
          constructor.setAccessible(true);
          return constructor.newInstance(this.a);
        } catch (Exception exception) {
          return null;
        }  
    } else {
      constructor.setAccessible(true);
      return constructor.newInstance(this.a);
    } 
    paramString2 = paramString1;
    constructor = Class.forName(paramString2, false, paramContext.getClassLoader()).<View>asSubclass(View.class).getConstructor(b);
    g1.put(paramString1, constructor);
    constructor.setAccessible(true);
    return constructor.newInstance(this.a);
  }
  
  private View t(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    String str = paramString;
    if (paramString.equals("view"))
      str = paramAttributeSet.getAttributeValue(null, "class"); 
    try {
      Object[] arrayOfObject1;
      Object[] arrayOfObject2 = this.a;
      arrayOfObject2[0] = paramContext;
      arrayOfObject2[1] = paramAttributeSet;
      if (-1 == str.indexOf('.')) {
        int i = 0;
        while (true) {
          String[] arrayOfString = g;
          if (i < arrayOfString.length) {
            View view = s(paramContext, str, arrayOfString[i]);
            if (view != null)
              return view; 
            i++;
            continue;
          } 
          return null;
        } 
      } 
      return s((Context)arrayOfObject1, str, null);
    } catch (Exception exception) {
      return null;
    } finally {
      Object[] arrayOfObject = this.a;
      arrayOfObject[0] = null;
      arrayOfObject[1] = null;
    } 
  }
  
  private static Context u(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2) {
    int i;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.View, 0, 0);
    if (paramBoolean1) {
      i = typedArray.getResourceId(j.View_android_theme, 0);
    } else {
      i = 0;
    } 
    int j = i;
    if (paramBoolean2) {
      j = i;
      if (!i) {
        i = typedArray.getResourceId(j.View_theme, 0);
        j = i;
        if (i != 0) {
          Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
          j = i;
        } 
      } 
    } 
    typedArray.recycle();
    Context context = paramContext;
    if (j != 0) {
      if (paramContext instanceof d) {
        context = paramContext;
        return (Context)((((d)paramContext).c() != j) ? new d(paramContext, j) : context);
      } 
    } else {
      return context;
    } 
    return (Context)new d(paramContext, j);
  }
  
  private void v(View paramView, String paramString) {
    if (paramView != null)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getName());
    stringBuilder.append(" asked to inflate view for <");
    stringBuilder.append(paramString);
    stringBuilder.append(">, but returned null");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected AppCompatAutoCompleteTextView c(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatButton d(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatButton(paramContext, paramAttributeSet);
  }
  
  protected AppCompatCheckBox e(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatCheckBox(paramContext, paramAttributeSet);
  }
  
  protected AppCompatCheckedTextView f(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatCheckedTextView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatEditText g(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatEditText(paramContext, paramAttributeSet);
  }
  
  protected AppCompatImageButton h(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatImageButton(paramContext, paramAttributeSet);
  }
  
  protected AppCompatImageView i(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatImageView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatMultiAutoCompleteTextView j(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatMultiAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatRadioButton k(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatRadioButton(paramContext, paramAttributeSet);
  }
  
  protected AppCompatRatingBar l(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatRatingBar(paramContext, paramAttributeSet);
  }
  
  protected AppCompatSeekBar m(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatSeekBar(paramContext, paramAttributeSet);
  }
  
  protected AppCompatSpinner n(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatSpinner(paramContext, paramAttributeSet);
  }
  
  protected AppCompatTextView o(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatTextView(paramContext, paramAttributeSet);
  }
  
  protected AppCompatToggleButton p(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatToggleButton(paramContext, paramAttributeSet);
  }
  
  protected View q(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    return null;
  }
  
  public final View r(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: iload #5
    //   2: ifeq -> 18
    //   5: aload_1
    //   6: ifnull -> 18
    //   9: aload_1
    //   10: invokevirtual getContext : ()Landroid/content/Context;
    //   13: astore #11
    //   15: goto -> 21
    //   18: aload_3
    //   19: astore #11
    //   21: iload #6
    //   23: ifne -> 34
    //   26: aload #11
    //   28: astore_1
    //   29: iload #7
    //   31: ifeq -> 46
    //   34: aload #11
    //   36: aload #4
    //   38: iload #6
    //   40: iload #7
    //   42: invokestatic u : (Landroid/content/Context;Landroid/util/AttributeSet;ZZ)Landroid/content/Context;
    //   45: astore_1
    //   46: aload_1
    //   47: astore #11
    //   49: iload #8
    //   51: ifeq -> 60
    //   54: aload_1
    //   55: invokestatic b : (Landroid/content/Context;)Landroid/content/Context;
    //   58: astore #11
    //   60: aload_2
    //   61: invokevirtual hashCode : ()I
    //   64: pop
    //   65: aload_2
    //   66: invokevirtual hashCode : ()I
    //   69: istore #10
    //   71: iconst_m1
    //   72: istore #9
    //   74: iload #10
    //   76: lookupswitch default -> 200, -1946472170 -> 458, -1455429095 -> 439, -1346021293 -> 420, -938935918 -> 401, -937446323 -> 382, -658531749 -> 363, -339785223 -> 343, 776382189 -> 323, 799298502 -> 303, 1125864064 -> 283, 1413872058 -> 263, 1601505219 -> 243, 1666676343 -> 223, 2001146706 -> 203
    //   200: goto -> 474
    //   203: aload_2
    //   204: ldc_w 'Button'
    //   207: invokevirtual equals : (Ljava/lang/Object;)Z
    //   210: ifne -> 216
    //   213: goto -> 474
    //   216: bipush #13
    //   218: istore #9
    //   220: goto -> 474
    //   223: aload_2
    //   224: ldc_w 'EditText'
    //   227: invokevirtual equals : (Ljava/lang/Object;)Z
    //   230: ifne -> 236
    //   233: goto -> 474
    //   236: bipush #12
    //   238: istore #9
    //   240: goto -> 474
    //   243: aload_2
    //   244: ldc_w 'CheckBox'
    //   247: invokevirtual equals : (Ljava/lang/Object;)Z
    //   250: ifne -> 256
    //   253: goto -> 474
    //   256: bipush #11
    //   258: istore #9
    //   260: goto -> 474
    //   263: aload_2
    //   264: ldc_w 'AutoCompleteTextView'
    //   267: invokevirtual equals : (Ljava/lang/Object;)Z
    //   270: ifne -> 276
    //   273: goto -> 474
    //   276: bipush #10
    //   278: istore #9
    //   280: goto -> 474
    //   283: aload_2
    //   284: ldc_w 'ImageView'
    //   287: invokevirtual equals : (Ljava/lang/Object;)Z
    //   290: ifne -> 296
    //   293: goto -> 474
    //   296: bipush #9
    //   298: istore #9
    //   300: goto -> 474
    //   303: aload_2
    //   304: ldc_w 'ToggleButton'
    //   307: invokevirtual equals : (Ljava/lang/Object;)Z
    //   310: ifne -> 316
    //   313: goto -> 474
    //   316: bipush #8
    //   318: istore #9
    //   320: goto -> 474
    //   323: aload_2
    //   324: ldc_w 'RadioButton'
    //   327: invokevirtual equals : (Ljava/lang/Object;)Z
    //   330: ifne -> 336
    //   333: goto -> 474
    //   336: bipush #7
    //   338: istore #9
    //   340: goto -> 474
    //   343: aload_2
    //   344: ldc_w 'Spinner'
    //   347: invokevirtual equals : (Ljava/lang/Object;)Z
    //   350: ifne -> 356
    //   353: goto -> 474
    //   356: bipush #6
    //   358: istore #9
    //   360: goto -> 474
    //   363: aload_2
    //   364: ldc_w 'SeekBar'
    //   367: invokevirtual equals : (Ljava/lang/Object;)Z
    //   370: ifne -> 376
    //   373: goto -> 474
    //   376: iconst_5
    //   377: istore #9
    //   379: goto -> 474
    //   382: aload_2
    //   383: ldc_w 'ImageButton'
    //   386: invokevirtual equals : (Ljava/lang/Object;)Z
    //   389: ifne -> 395
    //   392: goto -> 474
    //   395: iconst_4
    //   396: istore #9
    //   398: goto -> 474
    //   401: aload_2
    //   402: ldc_w 'TextView'
    //   405: invokevirtual equals : (Ljava/lang/Object;)Z
    //   408: ifne -> 414
    //   411: goto -> 474
    //   414: iconst_3
    //   415: istore #9
    //   417: goto -> 474
    //   420: aload_2
    //   421: ldc_w 'MultiAutoCompleteTextView'
    //   424: invokevirtual equals : (Ljava/lang/Object;)Z
    //   427: ifne -> 433
    //   430: goto -> 474
    //   433: iconst_2
    //   434: istore #9
    //   436: goto -> 474
    //   439: aload_2
    //   440: ldc_w 'CheckedTextView'
    //   443: invokevirtual equals : (Ljava/lang/Object;)Z
    //   446: ifne -> 452
    //   449: goto -> 474
    //   452: iconst_1
    //   453: istore #9
    //   455: goto -> 474
    //   458: aload_2
    //   459: ldc_w 'RatingBar'
    //   462: invokevirtual equals : (Ljava/lang/Object;)Z
    //   465: ifne -> 471
    //   468: goto -> 474
    //   471: iconst_0
    //   472: istore #9
    //   474: iload #9
    //   476: tableswitch default -> 548, 0 -> 795, 1 -> 777, 2 -> 759, 3 -> 741, 4 -> 723, 5 -> 705, 6 -> 687, 7 -> 669, 8 -> 651, 9 -> 633, 10 -> 615, 11 -> 597, 12 -> 579, 13 -> 561
    //   548: aload_0
    //   549: aload #11
    //   551: aload_2
    //   552: aload #4
    //   554: invokevirtual q : (Landroid/content/Context;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    //   557: astore_1
    //   558: goto -> 810
    //   561: aload_0
    //   562: aload #11
    //   564: aload #4
    //   566: invokevirtual d : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatButton;
    //   569: astore_1
    //   570: aload_0
    //   571: aload_1
    //   572: aload_2
    //   573: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   576: goto -> 810
    //   579: aload_0
    //   580: aload #11
    //   582: aload #4
    //   584: invokevirtual g : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatEditText;
    //   587: astore_1
    //   588: aload_0
    //   589: aload_1
    //   590: aload_2
    //   591: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   594: goto -> 810
    //   597: aload_0
    //   598: aload #11
    //   600: aload #4
    //   602: invokevirtual e : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatCheckBox;
    //   605: astore_1
    //   606: aload_0
    //   607: aload_1
    //   608: aload_2
    //   609: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   612: goto -> 810
    //   615: aload_0
    //   616: aload #11
    //   618: aload #4
    //   620: invokevirtual c : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatAutoCompleteTextView;
    //   623: astore_1
    //   624: aload_0
    //   625: aload_1
    //   626: aload_2
    //   627: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   630: goto -> 810
    //   633: aload_0
    //   634: aload #11
    //   636: aload #4
    //   638: invokevirtual i : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatImageView;
    //   641: astore_1
    //   642: aload_0
    //   643: aload_1
    //   644: aload_2
    //   645: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   648: goto -> 810
    //   651: aload_0
    //   652: aload #11
    //   654: aload #4
    //   656: invokevirtual p : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatToggleButton;
    //   659: astore_1
    //   660: aload_0
    //   661: aload_1
    //   662: aload_2
    //   663: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   666: goto -> 810
    //   669: aload_0
    //   670: aload #11
    //   672: aload #4
    //   674: invokevirtual k : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatRadioButton;
    //   677: astore_1
    //   678: aload_0
    //   679: aload_1
    //   680: aload_2
    //   681: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   684: goto -> 810
    //   687: aload_0
    //   688: aload #11
    //   690: aload #4
    //   692: invokevirtual n : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatSpinner;
    //   695: astore_1
    //   696: aload_0
    //   697: aload_1
    //   698: aload_2
    //   699: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   702: goto -> 810
    //   705: aload_0
    //   706: aload #11
    //   708: aload #4
    //   710: invokevirtual m : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatSeekBar;
    //   713: astore_1
    //   714: aload_0
    //   715: aload_1
    //   716: aload_2
    //   717: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   720: goto -> 810
    //   723: aload_0
    //   724: aload #11
    //   726: aload #4
    //   728: invokevirtual h : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatImageButton;
    //   731: astore_1
    //   732: aload_0
    //   733: aload_1
    //   734: aload_2
    //   735: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   738: goto -> 810
    //   741: aload_0
    //   742: aload #11
    //   744: aload #4
    //   746: invokevirtual o : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatTextView;
    //   749: astore_1
    //   750: aload_0
    //   751: aload_1
    //   752: aload_2
    //   753: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   756: goto -> 810
    //   759: aload_0
    //   760: aload #11
    //   762: aload #4
    //   764: invokevirtual j : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatMultiAutoCompleteTextView;
    //   767: astore_1
    //   768: aload_0
    //   769: aload_1
    //   770: aload_2
    //   771: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   774: goto -> 810
    //   777: aload_0
    //   778: aload #11
    //   780: aload #4
    //   782: invokevirtual f : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatCheckedTextView;
    //   785: astore_1
    //   786: aload_0
    //   787: aload_1
    //   788: aload_2
    //   789: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   792: goto -> 810
    //   795: aload_0
    //   796: aload #11
    //   798: aload #4
    //   800: invokevirtual l : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatRatingBar;
    //   803: astore_1
    //   804: aload_0
    //   805: aload_1
    //   806: aload_2
    //   807: invokespecial v : (Landroid/view/View;Ljava/lang/String;)V
    //   810: aload_1
    //   811: astore #12
    //   813: aload_1
    //   814: ifnonnull -> 837
    //   817: aload_1
    //   818: astore #12
    //   820: aload_3
    //   821: aload #11
    //   823: if_acmpeq -> 837
    //   826: aload_0
    //   827: aload #11
    //   829: aload_2
    //   830: aload #4
    //   832: invokespecial t : (Landroid/content/Context;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    //   835: astore #12
    //   837: aload #12
    //   839: ifnull -> 860
    //   842: aload_0
    //   843: aload #12
    //   845: aload #4
    //   847: invokespecial b : (Landroid/view/View;Landroid/util/AttributeSet;)V
    //   850: aload_0
    //   851: aload #11
    //   853: aload #12
    //   855: aload #4
    //   857: invokespecial a : (Landroid/content/Context;Landroid/view/View;Landroid/util/AttributeSet;)V
    //   860: aload #12
    //   862: areturn
  }
  
  private static class a implements View.OnClickListener {
    private final View s0;
    
    private final String t0;
    
    private Method u0;
    
    private Context v0;
    
    public a(View param1View, String param1String) {
      this.s0 = param1View;
      this.t0 = param1String;
    }
    
    private void a(Context param1Context) {
      while (true) {
        String str;
        if (param1Context != null) {
          try {
            if (!param1Context.isRestricted()) {
              Method method = param1Context.getClass().getMethod(this.t0, new Class[] { View.class });
              if (method != null) {
                this.u0 = method;
                this.v0 = param1Context;
                return;
              } 
            } 
          } catch (NoSuchMethodException noSuchMethodException) {}
          if (param1Context instanceof ContextWrapper) {
            param1Context = ((ContextWrapper)param1Context).getBaseContext();
            continue;
          } 
          param1Context = null;
          continue;
        } 
        int i = this.s0.getId();
        if (i == -1) {
          str = "";
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" with id '");
          stringBuilder1.append(this.s0.getContext().getResources().getResourceEntryName(i));
          stringBuilder1.append("'");
          str = stringBuilder1.toString();
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not find method ");
        stringBuilder.append(this.t0);
        stringBuilder.append("(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
        stringBuilder.append(this.s0.getClass());
        stringBuilder.append(str);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    }
    
    public void onClick(View param1View) {
      if (this.u0 == null)
        a(this.s0.getContext()); 
      try {
        this.u0.invoke(this.v0, new Object[] { param1View });
        return;
      } catch (IllegalAccessException illegalAccessException) {
        throw new IllegalStateException("Could not execute non-public method for android:onClick", illegalAccessException);
      } catch (InvocationTargetException invocationTargetException) {
        throw new IllegalStateException("Could not execute method for android:onClick", invocationTargetException);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */