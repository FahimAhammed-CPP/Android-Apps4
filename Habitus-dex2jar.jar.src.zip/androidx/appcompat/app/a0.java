package androidx.appcompat.app;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

public final class a0 extends Service {
  public static ServiceInfo a(Context paramContext) throws PackageManager.NameNotFoundException {
    char c;
    if (Build.VERSION.SDK_INT >= 24) {
      c = a.a() | 0x80;
    } else {
      c = 'ʀ';
    } 
    return paramContext.getPackageManager().getServiceInfo(new ComponentName(paramContext, a0.class), c);
  }
  
  public IBinder onBind(Intent paramIntent) {
    throw new UnsupportedOperationException();
  }
  
  private static class a {
    static int a() {
      return 512;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\appcompat\app\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */