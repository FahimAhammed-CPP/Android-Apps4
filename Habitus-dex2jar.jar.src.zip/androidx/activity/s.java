package androidx.activity;

import android.view.View;
import android.view.ViewParent;
import dk.l;
import kk.j;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;

public final class s {
  public static final p a(View paramView) {
    q.j(paramView, "<this>");
    return (p)j.o(j.u(j.f(paramView, a.s0), b.s0));
  }
  
  public static final void b(View paramView, p paramp) {
    q.j(paramView, "<this>");
    q.j(paramp, "onBackPressedDispatcherOwner");
    paramView.setTag(q.view_tree_on_back_pressed_dispatcher_owner, paramp);
  }
  
  static final class a extends r implements l<View, View> {
    public static final a s0 = new a();
    
    a() {
      super(1);
    }
    
    public final View a(View param1View) {
      q.j(param1View, "it");
      ViewParent viewParent = param1View.getParent();
      return (viewParent instanceof View) ? (View)viewParent : null;
    }
  }
  
  static final class b extends r implements l<View, p> {
    public static final b s0 = new b();
    
    b() {
      super(1);
    }
    
    public final p a(View param1View) {
      q.j(param1View, "it");
      Object object = param1View.getTag(q.view_tree_on_back_pressed_dispatcher_owner);
      return (object instanceof p) ? (p)object : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */