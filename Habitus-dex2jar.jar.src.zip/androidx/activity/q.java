package androidx.activity;

public final class q {
  public static int report_drawn = 2131428117;
  
  public static int view_tree_on_back_pressed_dispatcher_owner = 2131428526;
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */