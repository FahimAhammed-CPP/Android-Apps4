package androidx.activity;

import androidx.lifecycle.p;
import dk.l;
import kotlin.jvm.internal.q;
import rj.v;

public final class o {
  public static final m a(OnBackPressedDispatcher paramOnBackPressedDispatcher, p paramp, boolean paramBoolean, l<? super m, v> paraml) {
    q.j(paramOnBackPressedDispatcher, "<this>");
    q.j(paraml, "onBackPressed");
    a a = new a(paramBoolean, paraml);
    if (paramp != null) {
      paramOnBackPressedDispatcher.c(paramp, a);
      return a;
    } 
    paramOnBackPressedDispatcher.b(a);
    return a;
  }
  
  public static final class a extends m {
    a(boolean param1Boolean, l<? super m, v> param1l) {
      super(param1Boolean);
    }
    
    public void handleOnBackPressed() {
      this.a.invoke(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */