package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;

@SuppressLint({"BanParcelableUsage"})
public final class e implements Parcelable {
  public static final Parcelable.Creator<e> CREATOR;
  
  public static final c w0 = new c(null);
  
  private final IntentSender s0;
  
  private final Intent t0;
  
  private final int u0;
  
  private final int v0;
  
  static {
    CREATOR = new b();
  }
  
  public e(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2) {
    this.s0 = paramIntentSender;
    this.t0 = paramIntent;
    this.u0 = paramInt1;
    this.v0 = paramInt2;
  }
  
  public e(Parcel paramParcel) {
    this((IntentSender)parcelable, (Intent)paramParcel.readParcelable(Intent.class.getClassLoader()), paramParcel.readInt(), paramParcel.readInt());
  }
  
  public final Intent a() {
    return this.t0;
  }
  
  public final int b() {
    return this.u0;
  }
  
  public final int c() {
    return this.v0;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public final IntentSender f() {
    return this.s0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    q.j(paramParcel, "dest");
    paramParcel.writeParcelable((Parcelable)this.s0, paramInt);
    paramParcel.writeParcelable((Parcelable)this.t0, paramInt);
    paramParcel.writeInt(this.u0);
    paramParcel.writeInt(this.v0);
  }
  
  public static final class a {
    private final IntentSender a;
    
    private Intent b;
    
    private int c;
    
    private int d;
    
    public a(IntentSender param1IntentSender) {
      this.a = param1IntentSender;
    }
    
    public final e a() {
      return new e(this.a, this.b, this.c, this.d);
    }
    
    public final a b(Intent param1Intent) {
      this.b = param1Intent;
      return this;
    }
    
    public final a c(int param1Int1, int param1Int2) {
      this.d = param1Int1;
      this.c = param1Int2;
      return this;
    }
  }
  
  public static final class b implements Parcelable.Creator<e> {
    public e a(Parcel param1Parcel) {
      q.j(param1Parcel, "inParcel");
      return new e(param1Parcel);
    }
    
    public e[] b(int param1Int) {
      return new e[param1Int];
    }
  }
  
  public static final class c {
    private c() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\result\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */