package androidx.activity;

import dk.a;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.jvm.internal.q;
import rj.v;

public abstract class m {
  private final CopyOnWriteArrayList<a> cancellables;
  
  private a<v> enabledChangedCallback;
  
  private boolean isEnabled;
  
  public m(boolean paramBoolean) {
    this.isEnabled = paramBoolean;
    this.cancellables = new CopyOnWriteArrayList<a>();
  }
  
  public final void addCancellable(a parama) {
    q.j(parama, "cancellable");
    this.cancellables.add(parama);
  }
  
  public final a<v> getEnabledChangedCallback$activity_release() {
    return this.enabledChangedCallback;
  }
  
  public abstract void handleOnBackPressed();
  
  public final boolean isEnabled() {
    return this.isEnabled;
  }
  
  public final void remove() {
    Iterator<a> iterator = this.cancellables.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).cancel(); 
  }
  
  public final void removeCancellable(a parama) {
    q.j(parama, "cancellable");
    this.cancellables.remove(parama);
  }
  
  public final void setEnabled(boolean paramBoolean) {
    this.isEnabled = paramBoolean;
    a<v> a1 = this.enabledChangedCallback;
    if (a1 != null)
      a1.invoke(); 
  }
  
  public final void setEnabledChangedCallback$activity_release(a<v> parama) {
    this.enabledChangedCallback = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */