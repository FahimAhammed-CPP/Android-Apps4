package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.b;
import androidx.activity.result.c;
import androidx.activity.result.d;
import androidx.activity.result.e;
import androidx.core.app.h;
import androidx.core.app.j;
import androidx.core.app.r;
import androidx.core.app.s;
import androidx.core.app.u;
import androidx.core.content.d;
import androidx.core.content.e;
import androidx.core.view.s;
import androidx.core.view.v;
import androidx.core.view.x;
import androidx.lifecycle.b0;
import androidx.lifecycle.f0;
import androidx.lifecycle.i;
import androidx.lifecycle.i0;
import androidx.lifecycle.j;
import androidx.lifecycle.m;
import androidx.lifecycle.n0;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import androidx.lifecycle.q0;
import androidx.lifecycle.r;
import androidx.lifecycle.r0;
import androidx.lifecycle.s0;
import androidx.lifecycle.t0;
import d4.d;
import java.io.Serializable;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import rj.v;

public class ComponentActivity extends h implements r0, i, d, p, d, d, e, r, s, s, l {
  private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
  
  private final ActivityResultRegistry mActivityResultRegistry;
  
  private int mContentLayoutId;
  
  final e.a mContextAwareHelper = new e.a();
  
  private n0.b mDefaultFactory;
  
  private boolean mDispatchingOnMultiWindowModeChanged;
  
  private boolean mDispatchingOnPictureInPictureModeChanged;
  
  final k mFullyDrawnReporter;
  
  private final r mLifecycleRegistry = new r(this);
  
  private final v mMenuHostHelper = new v(new b(this));
  
  private final AtomicInteger mNextLocalRequestCode;
  
  private final OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Configuration>> mOnConfigurationChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<j>> mOnMultiWindowModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Intent>> mOnNewIntentListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<u>> mOnPictureInPictureModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Integer>> mOnTrimMemoryListeners;
  
  final f mReportFullyDrawnExecutor;
  
  final d4.c mSavedStateRegistryController;
  
  private q0 mViewModelStore;
  
  public ComponentActivity() {
    d4.c c1 = d4.c.a(this);
    this.mSavedStateRegistryController = c1;
    this.mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a(this));
    f f1 = createFullyDrawnExecutor();
    this.mReportFullyDrawnExecutor = f1;
    this.mFullyDrawnReporter = new k(f1, new c(this));
    this.mNextLocalRequestCode = new AtomicInteger();
    this.mActivityResultRegistry = new b(this);
    this.mOnConfigurationChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<Configuration>>();
    this.mOnTrimMemoryListeners = new CopyOnWriteArrayList<androidx.core.util.a<Integer>>();
    this.mOnNewIntentListeners = new CopyOnWriteArrayList<androidx.core.util.a<Intent>>();
    this.mOnMultiWindowModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<j>>();
    this.mOnPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<u>>();
    this.mDispatchingOnMultiWindowModeChanged = false;
    this.mDispatchingOnPictureInPictureModeChanged = false;
    if (getLifecycle() != null) {
      int j = Build.VERSION.SDK_INT;
      getLifecycle().a((o)new m(this) {
            public void d(p param1p, j.a param1a) {
              if (param1a == j.a.ON_STOP) {
                Window window = this.s0.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  ComponentActivity.c.a((View)window); 
              } 
            }
          });
      getLifecycle().a((o)new m(this) {
            public void d(p param1p, j.a param1a) {
              if (param1a == j.a.ON_DESTROY) {
                this.s0.mContextAwareHelper.b();
                if (!this.s0.isChangingConfigurations())
                  this.s0.getViewModelStore().a(); 
                this.s0.mReportFullyDrawnExecutor.d();
              } 
            }
          });
      getLifecycle().a((o)new m(this) {
            public void d(p param1p, j.a param1a) {
              this.s0.ensureViewModelStore();
              this.s0.getLifecycle().d((o)this);
            }
          });
      c1.c();
      f0.c(this);
      if (j <= 23)
        getLifecycle().a((o)new ImmLeaksCleaner((Activity)this)); 
      getSavedStateRegistry().h("android:support:activity-result", new d(this));
      addOnContextAvailableListener(new e(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  public ComponentActivity(int paramInt) {
    this();
    this.mContentLayoutId = paramInt;
  }
  
  private f createFullyDrawnExecutor() {
    return new g(this);
  }
  
  private void initViewTreeOwners() {
    s0.b(getWindow().getDecorView(), this);
    t0.b(getWindow().getDecorView(), this);
    d4.e.b(getWindow().getDecorView(), this);
    s.b(getWindow().getDecorView(), this);
    r.a(getWindow().getDecorView(), this);
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    this.mReportFullyDrawnExecutor.o(getWindow().getDecorView());
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public void addMenuProvider(x paramx) {
    this.mMenuHostHelper.c(paramx);
  }
  
  public void addMenuProvider(x paramx, p paramp) {
    this.mMenuHostHelper.d(paramx, paramp);
  }
  
  @SuppressLint({"LambdaLast"})
  public void addMenuProvider(x paramx, p paramp, j.b paramb) {
    this.mMenuHostHelper.e(paramx, paramp, paramb);
  }
  
  public final void addOnConfigurationChangedListener(androidx.core.util.a<Configuration> parama) {
    this.mOnConfigurationChangedListeners.add(parama);
  }
  
  public final void addOnContextAvailableListener(e.b paramb) {
    this.mContextAwareHelper.a(paramb);
  }
  
  public final void addOnMultiWindowModeChangedListener(androidx.core.util.a<j> parama) {
    this.mOnMultiWindowModeChangedListeners.add(parama);
  }
  
  public final void addOnNewIntentListener(androidx.core.util.a<Intent> parama) {
    this.mOnNewIntentListeners.add(parama);
  }
  
  public final void addOnPictureInPictureModeChangedListener(androidx.core.util.a<u> parama) {
    this.mOnPictureInPictureModeChangedListeners.add(parama);
  }
  
  public final void addOnTrimMemoryListener(androidx.core.util.a<Integer> parama) {
    this.mOnTrimMemoryListeners.add(parama);
  }
  
  void ensureViewModelStore() {
    if (this.mViewModelStore == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      if (e1 != null)
        this.mViewModelStore = e1.b; 
      if (this.mViewModelStore == null)
        this.mViewModelStore = new q0(); 
    } 
  }
  
  public final ActivityResultRegistry getActivityResultRegistry() {
    return this.mActivityResultRegistry;
  }
  
  public q3.a getDefaultViewModelCreationExtras() {
    q3.d d1 = new q3.d();
    if (getApplication() != null)
      d1.c(n0.a.g, getApplication()); 
    d1.c(f0.a, this);
    d1.c(f0.b, this);
    if (getIntent() != null && getIntent().getExtras() != null)
      d1.c(f0.c, getIntent().getExtras()); 
    return (q3.a)d1;
  }
  
  public n0.b getDefaultViewModelProviderFactory() {
    if (this.mDefaultFactory == null) {
      Bundle bundle;
      Application application = getApplication();
      if (getIntent() != null) {
        bundle = getIntent().getExtras();
      } else {
        bundle = null;
      } 
      this.mDefaultFactory = (n0.b)new i0(application, this, bundle);
    } 
    return this.mDefaultFactory;
  }
  
  public k getFullyDrawnReporter() {
    return this.mFullyDrawnReporter;
  }
  
  @Deprecated
  public Object getLastCustomNonConfigurationInstance() {
    e e1 = (e)getLastNonConfigurationInstance();
    return (e1 != null) ? e1.a : null;
  }
  
  public j getLifecycle() {
    return (j)this.mLifecycleRegistry;
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.mOnBackPressedDispatcher;
  }
  
  public final androidx.savedstate.a getSavedStateRegistry() {
    return this.mSavedStateRegistryController.b();
  }
  
  public q0 getViewModelStore() {
    if (getApplication() != null) {
      ensureViewModelStore();
      return this.mViewModelStore;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void invalidateMenu() {
    invalidateOptionsMenu();
  }
  
  @Deprecated
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.mActivityResultRegistry.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.mOnBackPressedDispatcher.f();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Iterator<androidx.core.util.a<Configuration>> iterator = this.mOnConfigurationChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramConfiguration); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.mSavedStateRegistryController.d(paramBundle);
    this.mContextAwareHelper.c((Context)this);
    super.onCreate(paramBundle);
    b0.e((Activity)this);
    if (androidx.core.os.a.b())
      this.mOnBackPressedDispatcher.g(d.a((Activity)this)); 
    int j = this.mContentLayoutId;
    if (j != 0)
      setContentView(j); 
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      this.mMenuHostHelper.h(paramMenu, getMenuInflater());
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 0) ? this.mMenuHostHelper.j(paramMenuItem) : false);
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    if (this.mDispatchingOnMultiWindowModeChanged)
      return; 
    Iterator<androidx.core.util.a<j>> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new j(paramBoolean)); 
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.mDispatchingOnMultiWindowModeChanged = true;
    try {
      super.onMultiWindowModeChanged(paramBoolean, paramConfiguration);
      this.mDispatchingOnMultiWindowModeChanged = false;
      Iterator<androidx.core.util.a<j>> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
      return;
    } finally {
      this.mDispatchingOnMultiWindowModeChanged = false;
    } 
  }
  
  protected void onNewIntent(@SuppressLint({"UnknownNullness", "MissingNullability"}) Intent paramIntent) {
    super.onNewIntent(paramIntent);
    Iterator<androidx.core.util.a<Intent>> iterator = this.mOnNewIntentListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    this.mMenuHostHelper.i(paramMenu);
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    if (this.mDispatchingOnPictureInPictureModeChanged)
      return; 
    Iterator<androidx.core.util.a<u>> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new u(paramBoolean)); 
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.mDispatchingOnPictureInPictureModeChanged = true;
    try {
      super.onPictureInPictureModeChanged(paramBoolean, paramConfiguration);
      this.mDispatchingOnPictureInPictureModeChanged = false;
      Iterator<androidx.core.util.a<u>> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
      return;
    } finally {
      this.mDispatchingOnPictureInPictureModeChanged = false;
    } 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      this.mMenuHostHelper.k(paramMenu);
    } 
    return true;
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.mActivityResultRegistry.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  @Deprecated
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = onRetainCustomNonConfigurationInstance();
    q0 q02 = this.mViewModelStore;
    q0 q01 = q02;
    if (q02 == null) {
      e e2 = (e)getLastNonConfigurationInstance();
      q01 = q02;
      if (e2 != null)
        q01 = e2.b; 
    } 
    if (q01 == null && object == null)
      return null; 
    e e1 = new e();
    e1.a = object;
    e1.b = q01;
    return e1;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    j j = getLifecycle();
    if (j instanceof r)
      ((r)j).o(j.b.u0); 
    super.onSaveInstanceState(paramBundle);
    this.mSavedStateRegistryController.e(paramBundle);
  }
  
  public void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<androidx.core.util.a<Integer>> iterator = this.mOnTrimMemoryListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(Integer.valueOf(paramInt)); 
  }
  
  public Context peekAvailableContext() {
    return this.mContextAwareHelper.d();
  }
  
  public final <I, O> c<I> registerForActivityResult(f.a<I, O> parama, ActivityResultRegistry paramActivityResultRegistry, b<O> paramb) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("activity_rq#");
    stringBuilder.append(this.mNextLocalRequestCode.getAndIncrement());
    return paramActivityResultRegistry.i(stringBuilder.toString(), this, parama, paramb);
  }
  
  public final <I, O> c<I> registerForActivityResult(f.a<I, O> parama, b<O> paramb) {
    return registerForActivityResult(parama, this.mActivityResultRegistry, paramb);
  }
  
  public void removeMenuProvider(x paramx) {
    this.mMenuHostHelper.l(paramx);
  }
  
  public final void removeOnConfigurationChangedListener(androidx.core.util.a<Configuration> parama) {
    this.mOnConfigurationChangedListeners.remove(parama);
  }
  
  public final void removeOnContextAvailableListener(e.b paramb) {
    this.mContextAwareHelper.e(paramb);
  }
  
  public final void removeOnMultiWindowModeChangedListener(androidx.core.util.a<j> parama) {
    this.mOnMultiWindowModeChangedListeners.remove(parama);
  }
  
  public final void removeOnNewIntentListener(androidx.core.util.a<Intent> parama) {
    this.mOnNewIntentListeners.remove(parama);
  }
  
  public final void removeOnPictureInPictureModeChangedListener(androidx.core.util.a<u> parama) {
    this.mOnPictureInPictureModeChangedListeners.remove(parama);
  }
  
  public final void removeOnTrimMemoryListener(androidx.core.util.a<Integer> parama) {
    this.mOnTrimMemoryListeners.remove(parama);
  }
  
  public void reportFullyDrawn() {
    try {
      if (j4.b.d())
        j4.b.a("reportFullyDrawn() for ComponentActivity"); 
      super.reportFullyDrawn();
      this.mFullyDrawnReporter.b();
      return;
    } finally {
      j4.b.b();
    } 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    this.mReportFullyDrawnExecutor.o(getWindow().getDecorView());
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    initViewTreeOwners();
    this.mReportFullyDrawnExecutor.o(getWindow().getDecorView());
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    this.mReportFullyDrawnExecutor.o(getWindow().getDecorView());
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        this.s0.onBackPressed();
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends ActivityResultRegistry {
    b(ComponentActivity this$0) {}
    
    public <I, O> void f(int param1Int, f.a<I, O> param1a, I param1I, androidx.core.app.d param1d) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      e e;
      ComponentActivity componentActivity = this.i;
      f.a.a a1 = param1a.b((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.a((Context)componentActivity, param1I);
      if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null)
        intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } else {
        param1a = null;
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        androidx.core.app.b.u((Activity)componentActivity, arrayOfString1, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayOfString2.getAction())) {
        e = (e)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          androidx.core.app.b.z((Activity)componentActivity, e.f(), param1Int, e.a(), e.b(), e.c(), 0, (Bundle)arrayOfString1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
          return;
        } 
      } 
      androidx.core.app.b.y((Activity)componentActivity, (Intent)e, param1Int, (Bundle)sendIntentException);
    }
    
    class a implements Runnable {
      a(ComponentActivity.b this$0, int param2Int, f.a.a param2a) {}
      
      public void run() {
        this.u0.c(this.s0, this.t0.a());
      }
    }
    
    class b implements Runnable {
      b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.u0.b(this.s0, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.t0));
      }
    }
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0, int param1Int, f.a.a param1a) {}
    
    public void run() {
      this.u0.c(this.s0, this.t0.a());
    }
  }
  
  class b implements Runnable {
    b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.u0.b(this.s0, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.t0));
    }
  }
  
  static class c {
    static void a(View param1View) {
      param1View.cancelPendingInputEvents();
    }
  }
  
  static class d {
    static OnBackInvokedDispatcher a(Activity param1Activity) {
      return param1Activity.getOnBackInvokedDispatcher();
    }
  }
  
  static final class e {
    Object a;
    
    q0 b;
  }
  
  private static interface f extends Executor {
    void d();
    
    void o(View param1View);
  }
  
  class g implements f, ViewTreeObserver.OnDrawListener, Runnable {
    final long s0 = SystemClock.uptimeMillis() + 10000L;
    
    Runnable t0;
    
    boolean u0 = false;
    
    g(ComponentActivity this$0) {}
    
    public void d() {
      this.v0.getWindow().getDecorView().removeCallbacks(this);
      this.v0.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
    
    public void execute(Runnable param1Runnable) {
      this.t0 = param1Runnable;
      View view = this.v0.getWindow().getDecorView();
      if (this.u0) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
          view.invalidate();
          return;
        } 
        view.postInvalidate();
        return;
      } 
      view.postOnAnimation(new f(this));
    }
    
    public void o(View param1View) {
      if (!this.u0) {
        this.u0 = true;
        param1View.getViewTreeObserver().addOnDrawListener(this);
      } 
    }
    
    public void onDraw() {
      Runnable runnable = this.t0;
      if (runnable != null) {
        runnable.run();
        this.t0 = null;
        if (this.v0.mFullyDrawnReporter.c()) {
          this.u0 = false;
          this.v0.getWindow().getDecorView().post(this);
          return;
        } 
      } else if (SystemClock.uptimeMillis() > this.s0) {
        this.u0 = false;
        this.v0.getWindow().getDecorView().post(this);
      } 
    }
    
    public void run() {
      this.v0.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */