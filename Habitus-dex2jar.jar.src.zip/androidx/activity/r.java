package androidx.activity;

import android.view.View;
import kotlin.jvm.internal.q;

public final class r {
  public static final void a(View paramView, l paraml) {
    q.j(paramView, "<this>");
    q.j(paraml, "fullyDrawnReporterOwner");
    paramView.setTag(q.report_drawn, paraml);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */