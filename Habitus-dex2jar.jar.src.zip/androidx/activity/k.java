package androidx.activity;

import dk.a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import kotlin.jvm.internal.q;
import rj.v;

public final class k {
  private final Executor a;
  
  private final a<v> b;
  
  private final Object c;
  
  private int d;
  
  private boolean e;
  
  private boolean f;
  
  private final List<a<v>> g;
  
  private final Runnable h;
  
  public k(Executor paramExecutor, a<v> parama) {
    this.a = paramExecutor;
    this.b = parama;
    this.c = new Object();
    this.g = new ArrayList<a<v>>();
    this.h = new j(this);
  }
  
  private static final void d(k paramk) {
    q.j(paramk, "this$0");
    synchronized (paramk.c) {
      paramk.e = false;
      if (paramk.d == 0 && !paramk.f) {
        paramk.b.invoke();
        paramk.b();
      } 
      v v = v.a;
      return;
    } 
  }
  
  public final void b() {
    synchronized (this.c) {
      this.f = true;
      Iterator<a<v>> iterator = this.g.iterator();
      while (iterator.hasNext())
        ((a)iterator.next()).invoke(); 
      this.g.clear();
      v v = v.a;
      return;
    } 
  }
  
  public final boolean c() {
    synchronized (this.c) {
      return this.f;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */