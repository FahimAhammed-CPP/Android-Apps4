package androidx.activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.j;
import androidx.lifecycle.p;
import androidx.lifecycle.r;
import androidx.lifecycle.s0;
import androidx.savedstate.a;
import d4.c;
import d4.d;
import d4.e;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;

public class i extends Dialog implements p, p, d {
  private r _lifecycleRegistry;
  
  private final OnBackPressedDispatcher onBackPressedDispatcher = new OnBackPressedDispatcher(new h(this));
  
  private final c savedStateRegistryController = c.d.a(this);
  
  public i(Context paramContext) {
    this(paramContext, 0, 2, null);
  }
  
  public i(Context paramContext, int paramInt) {
    super(paramContext, paramInt);
  }
  
  private final r getLifecycleRegistry() {
    r r2 = this._lifecycleRegistry;
    r r1 = r2;
    if (r2 == null) {
      r1 = new r(this);
      this._lifecycleRegistry = r1;
    } 
    return r1;
  }
  
  private final void initViewTreeOwners() {
    Window window3 = getWindow();
    q.g(window3);
    View view3 = window3.getDecorView();
    q.i(view3, "window!!.decorView");
    s0.b(view3, this);
    Window window2 = getWindow();
    q.g(window2);
    View view2 = window2.getDecorView();
    q.i(view2, "window!!.decorView");
    s.b(view2, this);
    Window window1 = getWindow();
    q.g(window1);
    View view1 = window1.getDecorView();
    q.i(view1, "window!!.decorView");
    e.b(view1, this);
  }
  
  private static final void onBackPressedDispatcher$lambda$1(i parami) {
    q.j(parami, "this$0");
    parami.onBackPressed();
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    q.j(paramView, "view");
    initViewTreeOwners();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public j getLifecycle() {
    return (j)getLifecycleRegistry();
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.onBackPressedDispatcher;
  }
  
  public a getSavedStateRegistry() {
    return this.savedStateRegistryController.b();
  }
  
  public void onBackPressed() {
    this.onBackPressedDispatcher.f();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (Build.VERSION.SDK_INT >= 33) {
      OnBackPressedDispatcher onBackPressedDispatcher = this.onBackPressedDispatcher;
      OnBackInvokedDispatcher onBackInvokedDispatcher = g.a(this);
      q.i(onBackInvokedDispatcher, "onBackInvokedDispatcher");
      onBackPressedDispatcher.g(onBackInvokedDispatcher);
    } 
    this.savedStateRegistryController.d(paramBundle);
    getLifecycleRegistry().i(j.a.ON_CREATE);
  }
  
  public Bundle onSaveInstanceState() {
    Bundle bundle = super.onSaveInstanceState();
    q.i(bundle, "super.onSaveInstanceState()");
    this.savedStateRegistryController.e(bundle);
    return bundle;
  }
  
  protected void onStart() {
    super.onStart();
    getLifecycleRegistry().i(j.a.ON_RESUME);
  }
  
  protected void onStop() {
    getLifecycleRegistry().i(j.a.ON_DESTROY);
    this._lifecycleRegistry = null;
    super.onStop();
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    super.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    q.j(paramView, "view");
    initViewTreeOwners();
    super.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    q.j(paramView, "view");
    initViewTreeOwners();
    super.setContentView(paramView, paramLayoutParams);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */