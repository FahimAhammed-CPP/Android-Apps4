package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.j;
import androidx.lifecycle.m;
import androidx.lifecycle.p;
import java.lang.reflect.Field;

final class ImmLeaksCleaner implements m {
  private static int t0;
  
  private static Field u0;
  
  private static Field v0;
  
  private static Field w0;
  
  private Activity s0;
  
  ImmLeaksCleaner(Activity paramActivity) {
    this.s0 = paramActivity;
  }
  
  @SuppressLint({"SoonBlockedPrivateApi"})
  private static void a() {
    try {
      t0 = 2;
      Field field = InputMethodManager.class.getDeclaredField("mServedView");
      v0 = field;
      field.setAccessible(true);
      field = InputMethodManager.class.getDeclaredField("mNextServedView");
      w0 = field;
      field.setAccessible(true);
      field = InputMethodManager.class.getDeclaredField("mH");
      u0 = field;
      field.setAccessible(true);
      t0 = 1;
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      return;
    } 
  }
  
  public void d(p paramp, j.a parama) {
    if (parama != j.a.ON_DESTROY)
      return; 
    if (t0 == 0)
      a(); 
    if (t0 == 1) {
      InputMethodManager inputMethodManager = (InputMethodManager)this.s0.getSystemService("input_method");
      try {
        Object object = u0.get(inputMethodManager);
        if (object == null)
          return; 
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          View view = (View)v0.get(inputMethodManager);
          if (view == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          if (view.isAttachedToWindow()) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          try {
            w0.set(inputMethodManager, null);
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            inputMethodManager.isActive();
            return;
          } catch (IllegalAccessException illegalAccessException) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
        } catch (IllegalAccessException illegalAccessException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } catch (ClassCastException classCastException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } finally {}
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        throw inputMethodManager;
      } catch (IllegalAccessException illegalAccessException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\ImmLeaksCleaner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */