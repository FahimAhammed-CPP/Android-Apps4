package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.j;
import androidx.lifecycle.m;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import java.util.Iterator;
import kotlin.collections.k;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  private final k<m> b;
  
  private dk.a<v> c;
  
  private OnBackInvokedCallback d;
  
  private OnBackInvokedDispatcher e;
  
  private boolean f;
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
    this.b = new k();
    if (Build.VERSION.SDK_INT >= 33) {
      this.c = new a(this);
      this.d = c.a.b(new b(this));
    } 
  }
  
  public final void b(m paramm) {
    q.j(paramm, "onBackPressedCallback");
    d(paramm);
  }
  
  public final void c(p paramp, m paramm) {
    q.j(paramp, "owner");
    q.j(paramm, "onBackPressedCallback");
    j j = paramp.getLifecycle();
    if (j.b() == j.b.s0)
      return; 
    paramm.addCancellable(new LifecycleOnBackPressedCancellable(this, j, paramm));
    if (Build.VERSION.SDK_INT >= 33) {
      h();
      paramm.setEnabledChangedCallback$activity_release(this.c);
    } 
  }
  
  public final a d(m paramm) {
    q.j(paramm, "onBackPressedCallback");
    this.b.add(paramm);
    d d = new d(this, paramm);
    paramm.addCancellable(d);
    if (Build.VERSION.SDK_INT >= 33) {
      h();
      paramm.setEnabledChangedCallback$activity_release(this.c);
    } 
    return d;
  }
  
  public final boolean e() {
    k<m> k1 = this.b;
    boolean bool = k1 instanceof java.util.Collection;
    boolean bool1 = false;
    if (bool && k1.isEmpty())
      return false; 
    Iterator<m> iterator = k1.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        if (((m)iterator.next()).isEnabled()) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  public final void f() {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Lkotlin/collections/k;
    //   4: astore_1
    //   5: aload_1
    //   6: aload_1
    //   7: invokeinterface size : ()I
    //   12: invokeinterface listIterator : (I)Ljava/util/ListIterator;
    //   17: astore_2
    //   18: aload_2
    //   19: invokeinterface hasPrevious : ()Z
    //   24: ifeq -> 47
    //   27: aload_2
    //   28: invokeinterface previous : ()Ljava/lang/Object;
    //   33: astore_1
    //   34: aload_1
    //   35: checkcast androidx/activity/m
    //   38: invokevirtual isEnabled : ()Z
    //   41: ifeq -> 18
    //   44: goto -> 49
    //   47: aconst_null
    //   48: astore_1
    //   49: aload_1
    //   50: checkcast androidx/activity/m
    //   53: astore_1
    //   54: aload_1
    //   55: ifnull -> 63
    //   58: aload_1
    //   59: invokevirtual handleOnBackPressed : ()V
    //   62: return
    //   63: aload_0
    //   64: getfield a : Ljava/lang/Runnable;
    //   67: astore_1
    //   68: aload_1
    //   69: ifnull -> 78
    //   72: aload_1
    //   73: invokeinterface run : ()V
    //   78: return
  }
  
  public final void g(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    q.j(paramOnBackInvokedDispatcher, "invoker");
    this.e = paramOnBackInvokedDispatcher;
    h();
  }
  
  public final void h() {
    boolean bool = e();
    OnBackInvokedDispatcher onBackInvokedDispatcher = this.e;
    OnBackInvokedCallback onBackInvokedCallback = this.d;
    if (onBackInvokedDispatcher != null && onBackInvokedCallback != null) {
      if (bool && !this.f) {
        c.a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
        this.f = true;
        return;
      } 
      if (!bool && this.f) {
        c.a.e(onBackInvokedDispatcher, onBackInvokedCallback);
        this.f = false;
      } 
    } 
  }
  
  private final class LifecycleOnBackPressedCancellable implements m, a {
    private final j s0;
    
    private final m t0;
    
    private a u0;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, j param1j, m param1m) {
      this.s0 = param1j;
      this.t0 = param1m;
      param1j.a((o)this);
    }
    
    public void cancel() {
      this.s0.d((o)this);
      this.t0.removeCancellable(this);
      a a1 = this.u0;
      if (a1 != null)
        a1.cancel(); 
      this.u0 = null;
    }
    
    public void d(p param1p, j.a param1a) {
      q.j(param1p, "source");
      q.j(param1a, "event");
      if (param1a == j.a.ON_START) {
        this.u0 = this.v0.d(this.t0);
        return;
      } 
      if (param1a == j.a.ON_STOP) {
        a a1 = this.u0;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1a == j.a.ON_DESTROY) {
        cancel();
      } 
    }
  }
  
  static final class a extends r implements dk.a<v> {
    a(OnBackPressedDispatcher param1OnBackPressedDispatcher) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.h();
    }
  }
  
  static final class b extends r implements dk.a<v> {
    b(OnBackPressedDispatcher param1OnBackPressedDispatcher) {
      super(0);
    }
    
    public final void invoke() {
      this.s0.f();
    }
  }
  
  public static final class c {
    public static final c a = new c();
    
    private static final void c(dk.a param1a) {
      q.j(param1a, "$onBackInvoked");
      param1a.invoke();
    }
    
    public final OnBackInvokedCallback b(dk.a<v> param1a) {
      q.j(param1a, "onBackInvoked");
      return new n(param1a);
    }
    
    public final void d(Object param1Object1, int param1Int, Object param1Object2) {
      q.j(param1Object1, "dispatcher");
      q.j(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).registerOnBackInvokedCallback(param1Int, (OnBackInvokedCallback)param1Object2);
    }
    
    public final void e(Object param1Object1, Object param1Object2) {
      q.j(param1Object1, "dispatcher");
      q.j(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  private final class d implements a {
    private final m s0;
    
    public d(OnBackPressedDispatcher this$0, m param1m) {
      this.s0 = param1m;
    }
    
    public void cancel() {
      OnBackPressedDispatcher.a(this.t0).remove(this.s0);
      this.s0.removeCancellable(this);
      if (Build.VERSION.SDK_INT >= 33) {
        this.s0.setEnabledChangedCallback$activity_release(null);
        this.t0.h();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */