package a1;

import kotlin.jvm.internal.q;

public final class e {
  public static final h a(d paramd) {
    q.j(paramd, "<this>");
    return new h(paramd.b(), paramd.d(), paramd.c(), paramd.a());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */