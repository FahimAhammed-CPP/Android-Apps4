package a1;

import kotlin.jvm.internal.h;
import kotlin.jvm.internal.j;
import o.y;

public final class a {
  public static final a a = new a(null);
  
  private static final long b = b.b(0.0F, 0.0F, 2, null);
  
  public static long b(long paramLong) {
    return paramLong;
  }
  
  public static final boolean c(long paramLong1, long paramLong2) {
    return (paramLong1 == paramLong2);
  }
  
  public static final float d(long paramLong) {
    j j = j.a;
    return Float.intBitsToFloat((int)(paramLong >> 32L));
  }
  
  public static final float e(long paramLong) {
    j j = j.a;
    return Float.intBitsToFloat((int)(paramLong & 0xFFFFFFFFL));
  }
  
  public static int f(long paramLong) {
    return y.a(paramLong);
  }
  
  public static String g(long paramLong) {
    boolean bool;
    if (d(paramLong) == e(paramLong)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("CornerRadius.circular(");
      stringBuilder1.append(c.a(d(paramLong), 1));
      stringBuilder1.append(')');
      return stringBuilder1.toString();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CornerRadius.elliptical(");
    stringBuilder.append(c.a(d(paramLong), 1));
    stringBuilder.append(", ");
    stringBuilder.append(c.a(e(paramLong), 1));
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public static final class a {
    private a() {}
    
    public final long a() {
      return a.a();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */