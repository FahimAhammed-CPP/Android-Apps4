package a1;

import kotlin.jvm.internal.h;
import kotlin.jvm.internal.j;
import o.y;

public final class f {
  public static final a b = new a(null);
  
  private static final long c = g.a(0.0F, 0.0F);
  
  private static final long d = g.a(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY);
  
  private static final long e = g.a(Float.NaN, Float.NaN);
  
  private final long a;
  
  public static final float e(long paramLong) {
    return o(paramLong);
  }
  
  public static final float f(long paramLong) {
    return p(paramLong);
  }
  
  public static long g(long paramLong) {
    return paramLong;
  }
  
  public static final long h(long paramLong, float paramFloat1, float paramFloat2) {
    return g.a(paramFloat1, paramFloat2);
  }
  
  public static final long j(long paramLong, float paramFloat) {
    return g.a(o(paramLong) / paramFloat, p(paramLong) / paramFloat);
  }
  
  public static boolean k(long paramLong, Object paramObject) {
    return !(paramObject instanceof f) ? false : (!(paramLong != ((f)paramObject).x()));
  }
  
  public static final boolean l(long paramLong1, long paramLong2) {
    return (paramLong1 == paramLong2);
  }
  
  public static final float m(long paramLong) {
    return (float)Math.sqrt((o(paramLong) * o(paramLong) + p(paramLong) * p(paramLong)));
  }
  
  public static final float n(long paramLong) {
    return o(paramLong) * o(paramLong) + p(paramLong) * p(paramLong);
  }
  
  public static final float o(long paramLong) {
    boolean bool;
    if (paramLong != e) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      j j = j.a;
      return Float.intBitsToFloat((int)(paramLong >> 32L));
    } 
    throw new IllegalStateException("Offset is unspecified".toString());
  }
  
  public static final float p(long paramLong) {
    boolean bool;
    if (paramLong != e) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      j j = j.a;
      return Float.intBitsToFloat((int)(paramLong & 0xFFFFFFFFL));
    } 
    throw new IllegalStateException("Offset is unspecified".toString());
  }
  
  public static int q(long paramLong) {
    return y.a(paramLong);
  }
  
  public static final boolean r(long paramLong) {
    boolean bool;
    if (!Float.isNaN(o(paramLong)) && !Float.isNaN(p(paramLong))) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return true; 
    throw new IllegalStateException("Offset argument contained a NaN value.".toString());
  }
  
  public static final long s(long paramLong1, long paramLong2) {
    return g.a(o(paramLong1) - o(paramLong2), p(paramLong1) - p(paramLong2));
  }
  
  public static final long t(long paramLong1, long paramLong2) {
    return g.a(o(paramLong1) + o(paramLong2), p(paramLong1) + p(paramLong2));
  }
  
  public static final long u(long paramLong, float paramFloat) {
    return g.a(o(paramLong) * paramFloat, p(paramLong) * paramFloat);
  }
  
  public static String v(long paramLong) {
    if (g.c(paramLong)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Offset(");
      stringBuilder.append(c.a(o(paramLong), 1));
      stringBuilder.append(", ");
      stringBuilder.append(c.a(p(paramLong), 1));
      stringBuilder.append(')');
      return stringBuilder.toString();
    } 
    return "Offset.Unspecified";
  }
  
  public static final long w(long paramLong) {
    return g.a(-o(paramLong), -p(paramLong));
  }
  
  public boolean equals(Object paramObject) {
    return k(this.a, paramObject);
  }
  
  public int hashCode() {
    return q(this.a);
  }
  
  public String toString() {
    return v(this.a);
  }
  
  public static final class a {
    private a() {}
    
    public final long a() {
      return f.a();
    }
    
    public final long b() {
      return f.b();
    }
    
    public final long c() {
      return f.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */