package a1;

import kotlin.jvm.internal.h;
import kotlin.jvm.internal.j;
import o.y;

public final class l {
  public static final a b = new a(null);
  
  private static final long c = m.a(0.0F, 0.0F);
  
  private static final long d = m.a(Float.NaN, Float.NaN);
  
  private final long a;
  
  public static long d(long paramLong) {
    return paramLong;
  }
  
  public static boolean e(long paramLong, Object paramObject) {
    return !(paramObject instanceof l) ? false : (!(paramLong != ((l)paramObject).n()));
  }
  
  public static final boolean f(long paramLong1, long paramLong2) {
    return (paramLong1 == paramLong2);
  }
  
  public static final float g(long paramLong) {
    boolean bool;
    if (paramLong != d) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      j j = j.a;
      return Float.intBitsToFloat((int)(paramLong & 0xFFFFFFFFL));
    } 
    throw new IllegalStateException("Size is unspecified".toString());
  }
  
  public static final float h(long paramLong) {
    return Math.min(Math.abs(i(paramLong)), Math.abs(g(paramLong)));
  }
  
  public static final float i(long paramLong) {
    boolean bool;
    if (paramLong != d) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      j j = j.a;
      return Float.intBitsToFloat((int)(paramLong >> 32L));
    } 
    throw new IllegalStateException("Size is unspecified".toString());
  }
  
  public static int j(long paramLong) {
    return y.a(paramLong);
  }
  
  public static final boolean k(long paramLong) {
    return (i(paramLong) <= 0.0F || g(paramLong) <= 0.0F);
  }
  
  public static final long l(long paramLong, float paramFloat) {
    return m.a(i(paramLong) * paramFloat, g(paramLong) * paramFloat);
  }
  
  public static String m(long paramLong) {
    boolean bool;
    if (paramLong != b.a()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Size(");
      stringBuilder.append(c.a(i(paramLong), 1));
      stringBuilder.append(", ");
      stringBuilder.append(c.a(g(paramLong), 1));
      stringBuilder.append(')');
      return stringBuilder.toString();
    } 
    return "Size.Unspecified";
  }
  
  public boolean equals(Object paramObject) {
    return e(this.a, paramObject);
  }
  
  public int hashCode() {
    return j(this.a);
  }
  
  public String toString() {
    return m(this.a);
  }
  
  public static final class a {
    private a() {}
    
    public final long a() {
      return l.a();
    }
    
    public final long b() {
      return l.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */