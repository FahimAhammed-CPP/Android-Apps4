package a1;

public final class m {
  public static final long a(float paramFloat1, float paramFloat2) {
    long l = Float.floatToIntBits(paramFloat1);
    return l.d(Float.floatToIntBits(paramFloat2) & 0xFFFFFFFFL | l << 32L);
  }
  
  public static final long b(long paramLong) {
    return g.a(l.i(paramLong) / 2.0F, l.g(paramLong) / 2.0F);
  }
  
  public static final h c(long paramLong) {
    return i.b(f.b.c(), paramLong);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */