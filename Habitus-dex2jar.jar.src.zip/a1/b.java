package a1;

public final class b {
  public static final long a(float paramFloat1, float paramFloat2) {
    long l = Float.floatToIntBits(paramFloat1);
    return a.b(Float.floatToIntBits(paramFloat2) & 0xFFFFFFFFL | l << 32L);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */