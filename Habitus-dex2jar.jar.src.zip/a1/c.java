package a1;

public final class c {
  public static final String a(float paramFloat, int paramInt) {
    int j = Math.max(paramInt, 0);
    float f = (float)Math.pow(10.0F, j);
    paramFloat *= f;
    int i = (int)paramFloat;
    paramInt = i;
    if (paramFloat - i >= 0.5F)
      paramInt = i + 1; 
    paramFloat = paramInt / f;
    return (j > 0) ? String.valueOf(paramFloat) : String.valueOf((int)paramFloat);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */