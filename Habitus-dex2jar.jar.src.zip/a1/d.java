package a1;

public final class d {
  private float a;
  
  private float b;
  
  private float c;
  
  private float d;
  
  public d(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.a = paramFloat1;
    this.b = paramFloat2;
    this.c = paramFloat3;
    this.d = paramFloat4;
  }
  
  public final float a() {
    return this.d;
  }
  
  public final float b() {
    return this.a;
  }
  
  public final float c() {
    return this.c;
  }
  
  public final float d() {
    return this.b;
  }
  
  public final void e(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.a = Math.max(paramFloat1, this.a);
    this.b = Math.max(paramFloat2, this.b);
    this.c = Math.min(paramFloat3, this.c);
    this.d = Math.min(paramFloat4, this.d);
  }
  
  public final boolean f() {
    return (this.a >= this.c || this.b >= this.d);
  }
  
  public final void g(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.a = paramFloat1;
    this.b = paramFloat2;
    this.c = paramFloat3;
    this.d = paramFloat4;
  }
  
  public final void h(float paramFloat) {
    this.d = paramFloat;
  }
  
  public final void i(float paramFloat) {
    this.a = paramFloat;
  }
  
  public final void j(float paramFloat) {
    this.c = paramFloat;
  }
  
  public final void k(float paramFloat) {
    this.b = paramFloat;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MutableRect(");
    stringBuilder.append(c.a(this.a, 1));
    stringBuilder.append(", ");
    stringBuilder.append(c.a(this.b, 1));
    stringBuilder.append(", ");
    stringBuilder.append(c.a(this.c, 1));
    stringBuilder.append(", ");
    stringBuilder.append(c.a(this.d, 1));
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */