package a1;

import kotlin.jvm.internal.q;

public final class k {
  public static final j a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    long l = b.a(paramFloat5, paramFloat6);
    return new j(paramFloat1, paramFloat2, paramFloat3, paramFloat4, l, l, l, l, null);
  }
  
  public static final j b(h paramh, long paramLong1, long paramLong2, long paramLong3, long paramLong4) {
    q.j(paramh, "rect");
    return new j(paramh.i(), paramh.l(), paramh.j(), paramh.e(), paramLong1, paramLong2, paramLong3, paramLong4, null);
  }
  
  public static final j c(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong) {
    return a(paramFloat1, paramFloat2, paramFloat3, paramFloat4, a.d(paramLong), a.e(paramLong));
  }
  
  public static final boolean d(j paramj) {
    boolean bool;
    q.j(paramj, "<this>");
    if (a.d(paramj.h()) == a.e(paramj.h())) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (a.d(paramj.h()) == a.d(paramj.i())) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        if (a.d(paramj.h()) == a.e(paramj.i())) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool) {
          if (a.d(paramj.h()) == a.d(paramj.c())) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool) {
            if (a.d(paramj.h()) == a.e(paramj.c())) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool) {
              if (a.d(paramj.h()) == a.d(paramj.b())) {
                bool = true;
              } else {
                bool = false;
              } 
              if (bool) {
                if (a.d(paramj.h()) == a.e(paramj.b())) {
                  bool = true;
                } else {
                  bool = false;
                } 
                if (bool)
                  return true; 
              } 
            } 
          } 
        } 
      } 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */