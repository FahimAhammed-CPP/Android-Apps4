package a1;

public final class i {
  public static final h a(long paramLong1, long paramLong2) {
    return new h(f.o(paramLong1), f.p(paramLong1), f.o(paramLong2), f.p(paramLong2));
  }
  
  public static final h b(long paramLong1, long paramLong2) {
    return new h(f.o(paramLong1), f.p(paramLong1), f.o(paramLong1) + l.i(paramLong2), f.p(paramLong1) + l.g(paramLong2));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */