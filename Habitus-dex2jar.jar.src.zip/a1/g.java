package a1;

import l2.a;

public final class g {
  public static final long a(float paramFloat1, float paramFloat2) {
    long l = Float.floatToIntBits(paramFloat1);
    return f.g(Float.floatToIntBits(paramFloat2) & 0xFFFFFFFFL | l << 32L);
  }
  
  public static final boolean b(long paramLong) {
    boolean bool;
    float f = f.o(paramLong);
    if (!Float.isInfinite(f) && !Float.isNaN(f)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      f = f.p(paramLong);
      if (!Float.isInfinite(f) && !Float.isNaN(f)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public static final boolean c(long paramLong) {
    return (paramLong != f.b.b());
  }
  
  public static final boolean d(long paramLong) {
    return (paramLong == f.b.b());
  }
  
  public static final long e(long paramLong1, long paramLong2, float paramFloat) {
    return a(a.a(f.o(paramLong1), f.o(paramLong2), paramFloat), a.a(f.p(paramLong1), f.p(paramLong2), paramFloat));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */