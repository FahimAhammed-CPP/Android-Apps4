package a1;

import kotlin.jvm.internal.q;

public final class h {
  public static final a e = new a(null);
  
  private static final h f = new h(0.0F, 0.0F, 0.0F, 0.0F);
  
  private final float a;
  
  private final float b;
  
  private final float c;
  
  private final float d;
  
  public h(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.a = paramFloat1;
    this.b = paramFloat2;
    this.c = paramFloat3;
    this.d = paramFloat4;
  }
  
  public final boolean b(long paramLong) {
    return (f.o(paramLong) >= this.a && f.o(paramLong) < this.c && f.p(paramLong) >= this.b && f.p(paramLong) < this.d);
  }
  
  public final h c(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return new h(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public final float e() {
    return this.d;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof h))
      return false; 
    paramObject = paramObject;
    return (Float.compare(this.a, ((h)paramObject).a) != 0) ? false : ((Float.compare(this.b, ((h)paramObject).b) != 0) ? false : ((Float.compare(this.c, ((h)paramObject).c) != 0) ? false : (!(Float.compare(this.d, ((h)paramObject).d) != 0))));
  }
  
  public final long f() {
    return g.a(this.c, this.d);
  }
  
  public final long g() {
    return g.a(this.a + n() / 2.0F, this.b + h() / 2.0F);
  }
  
  public final float h() {
    return this.d - this.b;
  }
  
  public int hashCode() {
    return ((Float.floatToIntBits(this.a) * 31 + Float.floatToIntBits(this.b)) * 31 + Float.floatToIntBits(this.c)) * 31 + Float.floatToIntBits(this.d);
  }
  
  public final float i() {
    return this.a;
  }
  
  public final float j() {
    return this.c;
  }
  
  public final long k() {
    return m.a(n(), h());
  }
  
  public final float l() {
    return this.b;
  }
  
  public final long m() {
    return g.a(this.a, this.b);
  }
  
  public final float n() {
    return this.c - this.a;
  }
  
  public final h o(h paramh) {
    q.j(paramh, "other");
    return new h(Math.max(this.a, paramh.a), Math.max(this.b, paramh.b), Math.min(this.c, paramh.c), Math.min(this.d, paramh.d));
  }
  
  public final boolean p(h paramh) {
    q.j(paramh, "other");
    if (this.c > paramh.a) {
      if (paramh.c <= this.a)
        return false; 
      if (this.d > paramh.b)
        return !(paramh.d <= this.b); 
    } 
    return false;
  }
  
  public final h q(float paramFloat1, float paramFloat2) {
    return new h(this.a + paramFloat1, this.b + paramFloat2, this.c + paramFloat1, this.d + paramFloat2);
  }
  
  public final h r(long paramLong) {
    return new h(this.a + f.o(paramLong), this.b + f.p(paramLong), this.c + f.o(paramLong), this.d + f.p(paramLong));
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Rect.fromLTRB(");
    stringBuilder.append(c.a(this.a, 1));
    stringBuilder.append(", ");
    stringBuilder.append(c.a(this.b, 1));
    stringBuilder.append(", ");
    stringBuilder.append(c.a(this.c, 1));
    stringBuilder.append(", ");
    stringBuilder.append(c.a(this.d, 1));
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public static final class a {
    private a() {}
    
    public final h a() {
      return h.a();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */