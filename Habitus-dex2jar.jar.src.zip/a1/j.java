package a1;

import kotlin.jvm.internal.h;

public final class j {
  public static final a i = new a(null);
  
  private static final j j = k.c(0.0F, 0.0F, 0.0F, 0.0F, a.a.a());
  
  private final float a;
  
  private final float b;
  
  private final float c;
  
  private final float d;
  
  private final long e;
  
  private final long f;
  
  private final long g;
  
  private final long h;
  
  private j(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong1, long paramLong2, long paramLong3, long paramLong4) {
    this.a = paramFloat1;
    this.b = paramFloat2;
    this.c = paramFloat3;
    this.d = paramFloat4;
    this.e = paramLong1;
    this.f = paramLong2;
    this.g = paramLong3;
    this.h = paramLong4;
  }
  
  public final float a() {
    return this.d;
  }
  
  public final long b() {
    return this.h;
  }
  
  public final long c() {
    return this.g;
  }
  
  public final float d() {
    return this.d - this.b;
  }
  
  public final float e() {
    return this.a;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof j))
      return false; 
    paramObject = paramObject;
    return (Float.compare(this.a, ((j)paramObject).a) != 0) ? false : ((Float.compare(this.b, ((j)paramObject).b) != 0) ? false : ((Float.compare(this.c, ((j)paramObject).c) != 0) ? false : ((Float.compare(this.d, ((j)paramObject).d) != 0) ? false : (!a.c(this.e, ((j)paramObject).e) ? false : (!a.c(this.f, ((j)paramObject).f) ? false : (!a.c(this.g, ((j)paramObject).g) ? false : (!!a.c(this.h, ((j)paramObject).h))))))));
  }
  
  public final float f() {
    return this.c;
  }
  
  public final float g() {
    return this.b;
  }
  
  public final long h() {
    return this.e;
  }
  
  public int hashCode() {
    return ((((((Float.floatToIntBits(this.a) * 31 + Float.floatToIntBits(this.b)) * 31 + Float.floatToIntBits(this.c)) * 31 + Float.floatToIntBits(this.d)) * 31 + a.f(this.e)) * 31 + a.f(this.f)) * 31 + a.f(this.g)) * 31 + a.f(this.h);
  }
  
  public final long i() {
    return this.f;
  }
  
  public final float j() {
    return this.c - this.a;
  }
  
  public String toString() {
    long l1 = this.e;
    long l2 = this.f;
    long l3 = this.g;
    long l4 = this.h;
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(c.a(this.a, 1));
    stringBuilder1.append(", ");
    stringBuilder1.append(c.a(this.b, 1));
    stringBuilder1.append(", ");
    stringBuilder1.append(c.a(this.c, 1));
    stringBuilder1.append(", ");
    stringBuilder1.append(c.a(this.d, 1));
    String str = stringBuilder1.toString();
    if (a.c(l1, l2) && a.c(l2, l3) && a.c(l3, l4)) {
      boolean bool;
      if (a.d(l1) == a.e(l1)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("RoundRect(rect=");
        stringBuilder3.append(str);
        stringBuilder3.append(", radius=");
        stringBuilder3.append(c.a(a.d(l1), 1));
        stringBuilder3.append(')');
        return stringBuilder3.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("RoundRect(rect=");
      stringBuilder.append(str);
      stringBuilder.append(", x=");
      stringBuilder.append(c.a(a.d(l1), 1));
      stringBuilder.append(", y=");
      stringBuilder.append(c.a(a.e(l1), 1));
      stringBuilder.append(')');
      return stringBuilder.toString();
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("RoundRect(rect=");
    stringBuilder2.append(str);
    stringBuilder2.append(", topLeft=");
    stringBuilder2.append(a.g(l1));
    stringBuilder2.append(", topRight=");
    stringBuilder2.append(a.g(l2));
    stringBuilder2.append(", bottomRight=");
    stringBuilder2.append(a.g(l3));
    stringBuilder2.append(", bottomLeft=");
    stringBuilder2.append(a.g(l4));
    stringBuilder2.append(')');
    return stringBuilder2.toString();
  }
  
  public static final class a {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a1\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */