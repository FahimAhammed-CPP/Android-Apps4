package a4;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.CancellationSignal;
import android.os.Looper;
import android.util.Log;
import dk.l;
import e4.j;
import e4.k;
import j$.util.DesugarCollections;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import kotlin.collections.k0;
import kotlin.collections.r;
import kotlin.collections.s0;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;

public abstract class w {
  public static final c o = new c(null);
  
  protected volatile e4.g a;
  
  private Executor b;
  
  private Executor c;
  
  private e4.h d;
  
  private final q e = g();
  
  private boolean f;
  
  private boolean g;
  
  protected List<? extends b> h;
  
  private Map<Class<? extends b4.a>, b4.a> i = new LinkedHashMap<Class<? extends b4.a>, b4.a>();
  
  private final ReentrantReadWriteLock j = new ReentrantReadWriteLock();
  
  private c k;
  
  private final ThreadLocal<Integer> l = new ThreadLocal<Integer>();
  
  private final Map<String, Object> m;
  
  private final Map<Class<?>, Object> n;
  
  public w() {
    Map<String, Object> map = DesugarCollections.synchronizedMap(new LinkedHashMap<Object, Object>());
    q.i(map, "synchronizedMap(mutableMapOf())");
    this.m = map;
    this.n = new LinkedHashMap<Class<?>, Object>();
  }
  
  private final <T> T E(Class<T> paramClass, e4.h paramh) {
    return (T)(paramClass.isInstance(paramh) ? paramh : (Object)((paramh instanceof i) ? E(paramClass, ((i)paramh).getDelegate()) : null));
  }
  
  private final void v() {
    c();
    e4.g g1 = n().o0();
    m().u(g1);
    if (g1.D0()) {
      g1.G();
      return;
    } 
    g1.h();
  }
  
  private final void w() {
    n().o0().J();
    if (!t())
      m().m(); 
  }
  
  public Cursor A(j paramj, CancellationSignal paramCancellationSignal) {
    q.j(paramj, "query");
    c();
    d();
    return (paramCancellationSignal != null) ? n().o0().i0(paramj, paramCancellationSignal) : n().o0().v0(paramj);
  }
  
  public void C(Runnable paramRunnable) {
    q.j(paramRunnable, "body");
    e();
    try {
      paramRunnable.run();
      D();
      return;
    } finally {
      i();
    } 
  }
  
  public void D() {
    n().o0().F();
  }
  
  public void c() {
    if (this.f)
      return; 
    if ((y() ^ true) != 0)
      return; 
    throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.".toString());
  }
  
  public void d() {
    boolean bool;
    if (t() || this.l.get() == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.".toString());
  }
  
  public void e() {
    c();
    c c1 = this.k;
    if (c1 == null) {
      v();
      return;
    } 
    c1.g(new g(this));
  }
  
  public k f(String paramString) {
    q.j(paramString, "sql");
    c();
    d();
    return n().o0().c0(paramString);
  }
  
  protected abstract q g();
  
  protected abstract e4.h h(h paramh);
  
  public void i() {
    c c1 = this.k;
    if (c1 == null) {
      w();
      return;
    } 
    c1.g(new h(this));
  }
  
  public List<b4.b> j(Map<Class<? extends b4.a>, b4.a> paramMap) {
    q.j(paramMap, "autoMigrationSpecs");
    return r.l();
  }
  
  public final Map<String, Object> k() {
    return this.m;
  }
  
  public final Lock l() {
    ReentrantReadWriteLock.ReadLock readLock = this.j.readLock();
    q.i(readLock, "readWriteLock.readLock()");
    return readLock;
  }
  
  public q m() {
    return this.e;
  }
  
  public e4.h n() {
    e4.h h2 = this.d;
    e4.h h1 = h2;
    if (h2 == null) {
      q.B("internalOpenHelper");
      h1 = null;
    } 
    return h1;
  }
  
  public Executor o() {
    Executor executor2 = this.b;
    Executor executor1 = executor2;
    if (executor2 == null) {
      q.B("internalQueryExecutor");
      executor1 = null;
    } 
    return executor1;
  }
  
  public Set<Class<? extends b4.a>> p() {
    return s0.d();
  }
  
  protected Map<Class<?>, List<Class<?>>> q() {
    return k0.g();
  }
  
  public final ThreadLocal<Integer> r() {
    return this.l;
  }
  
  public Executor s() {
    Executor executor2 = this.c;
    Executor executor1 = executor2;
    if (executor2 == null) {
      q.B("internalTransactionExecutor");
      executor1 = null;
    } 
    return executor1;
  }
  
  public boolean t() {
    return n().o0().z0();
  }
  
  public void u(h paramh) {
    q.j(paramh, "configuration");
    this.d = h(paramh);
    Set<Class<? extends b4.a>> set = p();
    BitSet bitSet = new BitSet();
    Iterator<Class<? extends b4.a>> iterator = set.iterator();
    while (true) {
      StringBuilder stringBuilder;
      boolean bool = iterator.hasNext();
      int j = 1;
      byte b = -1;
      if (bool) {
        Class<? extends b4.a> clazz = iterator.next();
        int m = paramh.r.size() - 1;
        int k = b;
        if (m >= 0)
          for (k = m;; k = m) {
            m = k - 1;
            if (clazz.isAssignableFrom(paramh.r.get(k).getClass())) {
              bitSet.set(k);
              break;
            } 
            if (m < 0) {
              k = b;
              break;
            } 
          }  
        if (k < 0)
          j = 0; 
        if (j) {
          this.i.put(clazz, paramh.r.get(k));
          continue;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("A required auto migration spec (");
        stringBuilder.append(clazz.getCanonicalName());
        stringBuilder.append(") is missing in the database configuration.");
        throw new IllegalArgumentException(stringBuilder.toString().toString());
      } 
      int i = ((h)stringBuilder).r.size() - 1;
      if (i >= 0)
        while (true) {
          j = i - 1;
          if (bitSet.get(i)) {
            if (j < 0)
              break; 
            i = j;
            continue;
          } 
          throw new IllegalArgumentException("Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder.".toString());
        }  
      for (b4.b b1 : j(this.i)) {
        if (!((h)stringBuilder).d.c(b1.a, b1.b))
          ((h)stringBuilder).d.b(new b4.b[] { b1 }); 
      } 
      b0 b0 = E(b0.class, n());
      if (b0 != null)
        b0.c((h)stringBuilder); 
      d d = E(d.class, n());
      if (d != null) {
        this.k = d.t0;
        m().p(d.t0);
      } 
      if (((h)stringBuilder).g == d.u0) {
        bool = true;
      } else {
        bool = false;
      } 
      n().setWriteAheadLoggingEnabled(bool);
      this.h = ((h)stringBuilder).e;
      this.b = ((h)stringBuilder).h;
      this.c = new g0(((h)stringBuilder).i);
      this.f = ((h)stringBuilder).f;
      this.g = bool;
      if (((h)stringBuilder).j != null)
        if (((h)stringBuilder).b != null) {
          m().q(((h)stringBuilder).a, ((h)stringBuilder).b, ((h)stringBuilder).j);
        } else {
          throw new IllegalArgumentException("Required value was null.".toString());
        }  
      Map<Class<?>, List<Class<?>>> map = q();
      BitSet bitSet1 = new BitSet();
      for (Map.Entry<Class<?>, List<Class<?>>> entry : map.entrySet()) {
        Class clazz = (Class)entry.getKey();
        label93: for (Class<?> clazz1 : (Iterable<Class<?>>)entry.getValue()) {
          i = ((h)stringBuilder).q.size() - 1;
          if (i >= 0) {
            while (true) {
              j = i - 1;
              if (clazz1.isAssignableFrom(((h)stringBuilder).q.get(i).getClass())) {
                bitSet1.set(i);
                break;
              } 
              if (j < 0)
                continue label93; 
              i = j;
            } 
          } else {
            i = -1;
          } 
          if (i >= 0) {
            j = 1;
          } else {
            j = 0;
          } 
          if (j != 0) {
            this.n.put(clazz1, ((h)stringBuilder).q.get(i));
            continue;
          } 
          stringBuilder = new StringBuilder();
          stringBuilder.append("A required type converter (");
          stringBuilder.append(clazz1);
          stringBuilder.append(") for ");
          stringBuilder.append(clazz.getCanonicalName());
          stringBuilder.append(" is missing in the database configuration.");
          throw new IllegalArgumentException(stringBuilder.toString().toString());
        } 
      } 
      i = ((h)stringBuilder).q.size() - 1;
      if (i >= 0) {
        while (true) {
          j = i - 1;
          if (bitSet1.get(i)) {
            if (j < 0)
              return; 
            i = j;
            continue;
          } 
          stringBuilder = (StringBuilder)((h)stringBuilder).q.get(i);
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Unexpected type converter ");
          stringBuilder1.append(stringBuilder);
          stringBuilder1.append(". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder.");
          throw new IllegalArgumentException(stringBuilder1.toString());
        } 
        break;
      } 
      return;
    } 
  }
  
  protected void x(e4.g paramg) {
    q.j(paramg, "db");
    m().j(paramg);
  }
  
  public final boolean y() {
    return (Looper.getMainLooper().getThread() == Thread.currentThread());
  }
  
  public final boolean z() {
    e4.g g1 = this.a;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (g1 != null) {
      bool1 = bool2;
      if (g1.isOpen() == true)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public static class a<T extends w> {
    private final Context a;
    
    private final Class<T> b;
    
    private final String c;
    
    private final List<w.b> d;
    
    private final List<Object> e;
    
    private List<b4.a> f;
    
    private Executor g;
    
    private Executor h;
    
    private e4.h.c i;
    
    private boolean j;
    
    private w.d k;
    
    private Intent l;
    
    private boolean m;
    
    private boolean n;
    
    private long o;
    
    private TimeUnit p;
    
    private final w.e q;
    
    private Set<Integer> r;
    
    private Set<Integer> s;
    
    private String t;
    
    private File u;
    
    private Callable<InputStream> v;
    
    public a(Context param1Context, Class<T> param1Class, String param1String) {
      this.a = param1Context;
      this.b = param1Class;
      this.c = param1String;
      this.d = new ArrayList<w.b>();
      this.e = new ArrayList();
      this.f = new ArrayList<b4.a>();
      this.k = w.d.s0;
      this.m = true;
      this.o = -1L;
      this.q = new w.e();
      this.r = new LinkedHashSet<Integer>();
    }
    
    public a<T> a() {
      this.j = true;
      return this;
    }
    
    public T b() {
      // Byte code:
      //   0: aload_0
      //   1: getfield g : Ljava/util/concurrent/Executor;
      //   4: astore #8
      //   6: aload #8
      //   8: ifnonnull -> 38
      //   11: aload_0
      //   12: getfield h : Ljava/util/concurrent/Executor;
      //   15: ifnonnull -> 38
      //   18: invokestatic f : ()Ljava/util/concurrent/Executor;
      //   21: astore #8
      //   23: aload_0
      //   24: aload #8
      //   26: putfield h : Ljava/util/concurrent/Executor;
      //   29: aload_0
      //   30: aload #8
      //   32: putfield g : Ljava/util/concurrent/Executor;
      //   35: goto -> 72
      //   38: aload #8
      //   40: ifnull -> 59
      //   43: aload_0
      //   44: getfield h : Ljava/util/concurrent/Executor;
      //   47: ifnonnull -> 59
      //   50: aload_0
      //   51: aload #8
      //   53: putfield h : Ljava/util/concurrent/Executor;
      //   56: goto -> 72
      //   59: aload #8
      //   61: ifnonnull -> 72
      //   64: aload_0
      //   65: aload_0
      //   66: getfield h : Ljava/util/concurrent/Executor;
      //   69: putfield g : Ljava/util/concurrent/Executor;
      //   72: aload_0
      //   73: getfield s : Ljava/util/Set;
      //   76: astore #8
      //   78: iconst_1
      //   79: istore #4
      //   81: aload #8
      //   83: ifnull -> 185
      //   86: aload #8
      //   88: invokestatic g : (Ljava/lang/Object;)V
      //   91: aload #8
      //   93: invokeinterface iterator : ()Ljava/util/Iterator;
      //   98: astore #8
      //   100: aload #8
      //   102: invokeinterface hasNext : ()Z
      //   107: ifeq -> 185
      //   110: aload #8
      //   112: invokeinterface next : ()Ljava/lang/Object;
      //   117: checkcast java/lang/Number
      //   120: invokevirtual intValue : ()I
      //   123: istore_1
      //   124: aload_0
      //   125: getfield r : Ljava/util/Set;
      //   128: iload_1
      //   129: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   132: invokeinterface contains : (Ljava/lang/Object;)Z
      //   137: iconst_1
      //   138: ixor
      //   139: ifeq -> 145
      //   142: goto -> 100
      //   145: new java/lang/StringBuilder
      //   148: dup
      //   149: invokespecial <init> : ()V
      //   152: astore #8
      //   154: aload #8
      //   156: ldc 'Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: '
      //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   161: pop
      //   162: aload #8
      //   164: iload_1
      //   165: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   168: pop
      //   169: new java/lang/IllegalArgumentException
      //   172: dup
      //   173: aload #8
      //   175: invokevirtual toString : ()Ljava/lang/String;
      //   178: invokevirtual toString : ()Ljava/lang/String;
      //   181: invokespecial <init> : (Ljava/lang/String;)V
      //   184: athrow
      //   185: aload_0
      //   186: getfield i : Le4/h$c;
      //   189: astore #9
      //   191: aload #9
      //   193: astore #8
      //   195: aload #9
      //   197: ifnonnull -> 209
      //   200: new f4/f
      //   203: dup
      //   204: invokespecial <init> : ()V
      //   207: astore #8
      //   209: aload #8
      //   211: ifnull -> 479
      //   214: aload #8
      //   216: astore #9
      //   218: aload_0
      //   219: getfield o : J
      //   222: lconst_0
      //   223: lcmp
      //   224: ifle -> 328
      //   227: aload_0
      //   228: getfield c : Ljava/lang/String;
      //   231: ifnull -> 315
      //   234: aload_0
      //   235: getfield o : J
      //   238: lstore #5
      //   240: aload_0
      //   241: getfield p : Ljava/util/concurrent/TimeUnit;
      //   244: astore #9
      //   246: aload #9
      //   248: ifnull -> 302
      //   251: aload_0
      //   252: getfield g : Ljava/util/concurrent/Executor;
      //   255: astore #10
      //   257: aload #10
      //   259: ifnull -> 289
      //   262: new a4/e
      //   265: dup
      //   266: aload #8
      //   268: new a4/c
      //   271: dup
      //   272: lload #5
      //   274: aload #9
      //   276: aload #10
      //   278: invokespecial <init> : (JLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/Executor;)V
      //   281: invokespecial <init> : (Le4/h$c;La4/c;)V
      //   284: astore #9
      //   286: goto -> 328
      //   289: new java/lang/IllegalArgumentException
      //   292: dup
      //   293: ldc 'Required value was null.'
      //   295: invokevirtual toString : ()Ljava/lang/String;
      //   298: invokespecial <init> : (Ljava/lang/String;)V
      //   301: athrow
      //   302: new java/lang/IllegalArgumentException
      //   305: dup
      //   306: ldc 'Required value was null.'
      //   308: invokevirtual toString : ()Ljava/lang/String;
      //   311: invokespecial <init> : (Ljava/lang/String;)V
      //   314: athrow
      //   315: new java/lang/IllegalArgumentException
      //   318: dup
      //   319: ldc 'Cannot create auto-closing database for an in-memory database.'
      //   321: invokevirtual toString : ()Ljava/lang/String;
      //   324: invokespecial <init> : (Ljava/lang/String;)V
      //   327: athrow
      //   328: aload_0
      //   329: getfield t : Ljava/lang/String;
      //   332: astore #10
      //   334: aload #10
      //   336: ifnonnull -> 357
      //   339: aload_0
      //   340: getfield u : Ljava/io/File;
      //   343: ifnonnull -> 357
      //   346: aload #9
      //   348: astore #8
      //   350: aload_0
      //   351: getfield v : Ljava/util/concurrent/Callable;
      //   354: ifnull -> 482
      //   357: aload_0
      //   358: getfield c : Ljava/lang/String;
      //   361: ifnull -> 466
      //   364: aload #10
      //   366: ifnonnull -> 374
      //   369: iconst_0
      //   370: istore_1
      //   371: goto -> 376
      //   374: iconst_1
      //   375: istore_1
      //   376: aload_0
      //   377: getfield u : Ljava/io/File;
      //   380: astore #8
      //   382: aload #8
      //   384: ifnonnull -> 392
      //   387: iconst_0
      //   388: istore_2
      //   389: goto -> 394
      //   392: iconst_1
      //   393: istore_2
      //   394: aload_0
      //   395: getfield v : Ljava/util/concurrent/Callable;
      //   398: astore #11
      //   400: aload #11
      //   402: ifnonnull -> 410
      //   405: iconst_0
      //   406: istore_3
      //   407: goto -> 412
      //   410: iconst_1
      //   411: istore_3
      //   412: iload_1
      //   413: iload_2
      //   414: iadd
      //   415: iload_3
      //   416: iadd
      //   417: iconst_1
      //   418: if_icmpne -> 427
      //   421: iload #4
      //   423: istore_1
      //   424: goto -> 429
      //   427: iconst_0
      //   428: istore_1
      //   429: iload_1
      //   430: ifeq -> 453
      //   433: new a4/c0
      //   436: dup
      //   437: aload #10
      //   439: aload #8
      //   441: aload #11
      //   443: aload #9
      //   445: invokespecial <init> : (Ljava/lang/String;Ljava/io/File;Ljava/util/concurrent/Callable;Le4/h$c;)V
      //   448: astore #8
      //   450: goto -> 482
      //   453: new java/lang/IllegalArgumentException
      //   456: dup
      //   457: ldc 'More than one of createFromAsset(), createFromInputStream(), and createFromFile() were called on this Builder, but the database can only be created using one of the three configurations.'
      //   459: invokevirtual toString : ()Ljava/lang/String;
      //   462: invokespecial <init> : (Ljava/lang/String;)V
      //   465: athrow
      //   466: new java/lang/IllegalArgumentException
      //   469: dup
      //   470: ldc 'Cannot create from asset or file for an in-memory database.'
      //   472: invokevirtual toString : ()Ljava/lang/String;
      //   475: invokespecial <init> : (Ljava/lang/String;)V
      //   478: athrow
      //   479: aconst_null
      //   480: astore #8
      //   482: aload #8
      //   484: ifnull -> 664
      //   487: aload_0
      //   488: getfield a : Landroid/content/Context;
      //   491: astore #9
      //   493: aload_0
      //   494: getfield c : Ljava/lang/String;
      //   497: astore #10
      //   499: aload_0
      //   500: getfield q : La4/w$e;
      //   503: astore #11
      //   505: aload_0
      //   506: getfield d : Ljava/util/List;
      //   509: astore #12
      //   511: aload_0
      //   512: getfield j : Z
      //   515: istore #7
      //   517: aload_0
      //   518: getfield k : La4/w$d;
      //   521: aload #9
      //   523: invokevirtual j : (Landroid/content/Context;)La4/w$d;
      //   526: astore #13
      //   528: aload_0
      //   529: getfield g : Ljava/util/concurrent/Executor;
      //   532: astore #14
      //   534: aload #14
      //   536: ifnull -> 651
      //   539: aload_0
      //   540: getfield h : Ljava/util/concurrent/Executor;
      //   543: astore #15
      //   545: aload #15
      //   547: ifnull -> 638
      //   550: new a4/h
      //   553: dup
      //   554: aload #9
      //   556: aload #10
      //   558: aload #8
      //   560: aload #11
      //   562: aload #12
      //   564: iload #7
      //   566: aload #13
      //   568: aload #14
      //   570: aload #15
      //   572: aload_0
      //   573: getfield l : Landroid/content/Intent;
      //   576: aload_0
      //   577: getfield m : Z
      //   580: aload_0
      //   581: getfield n : Z
      //   584: aload_0
      //   585: getfield r : Ljava/util/Set;
      //   588: aload_0
      //   589: getfield t : Ljava/lang/String;
      //   592: aload_0
      //   593: getfield u : Ljava/io/File;
      //   596: aload_0
      //   597: getfield v : Ljava/util/concurrent/Callable;
      //   600: aconst_null
      //   601: aload_0
      //   602: getfield e : Ljava/util/List;
      //   605: aload_0
      //   606: getfield f : Ljava/util/List;
      //   609: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;Le4/h$c;La4/w$e;Ljava/util/List;ZLa4/w$d;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Landroid/content/Intent;ZZLjava/util/Set;Ljava/lang/String;Ljava/io/File;Ljava/util/concurrent/Callable;La4/w$f;Ljava/util/List;Ljava/util/List;)V
      //   612: astore #8
      //   614: aload_0
      //   615: getfield b : Ljava/lang/Class;
      //   618: ldc '_Impl'
      //   620: invokestatic b : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;
      //   623: checkcast a4/w
      //   626: astore #9
      //   628: aload #9
      //   630: aload #8
      //   632: invokevirtual u : (La4/h;)V
      //   635: aload #9
      //   637: areturn
      //   638: new java/lang/IllegalArgumentException
      //   641: dup
      //   642: ldc 'Required value was null.'
      //   644: invokevirtual toString : ()Ljava/lang/String;
      //   647: invokespecial <init> : (Ljava/lang/String;)V
      //   650: athrow
      //   651: new java/lang/IllegalArgumentException
      //   654: dup
      //   655: ldc 'Required value was null.'
      //   657: invokevirtual toString : ()Ljava/lang/String;
      //   660: invokespecial <init> : (Ljava/lang/String;)V
      //   663: athrow
      //   664: new java/lang/IllegalArgumentException
      //   667: dup
      //   668: ldc 'Required value was null.'
      //   670: invokevirtual toString : ()Ljava/lang/String;
      //   673: invokespecial <init> : (Ljava/lang/String;)V
      //   676: athrow
    }
  }
  
  public static abstract class b {
    public void a(e4.g param1g) {
      q.j(param1g, "db");
    }
    
    public void b(e4.g param1g) {
      q.j(param1g, "db");
    }
    
    public void c(e4.g param1g) {
      q.j(param1g, "db");
    }
  }
  
  public static final class c {
    private c() {}
  }
  
  public enum d {
    s0, t0, u0;
    
    private final boolean e(ActivityManager param1ActivityManager) {
      return e4.c.b(param1ActivityManager);
    }
    
    public final d j(Context param1Context) {
      q.j(param1Context, "context");
      if (this != s0)
        return this; 
      Object object = param1Context.getSystemService("activity");
      if (object instanceof ActivityManager) {
        object = object;
      } else {
        object = null;
      } 
      return (object != null && !e((ActivityManager)object)) ? u0 : t0;
    }
  }
  
  public static class e {
    private final Map<Integer, TreeMap<Integer, b4.b>> a = new LinkedHashMap<Integer, TreeMap<Integer, b4.b>>();
    
    private final void a(b4.b param1b) {
      int i = param1b.a;
      int j = param1b.b;
      Map<Integer, TreeMap<Integer, b4.b>> map = this.a;
      Integer integer = Integer.valueOf(i);
      TreeMap<Object, Object> treeMap2 = (TreeMap<Object, Object>)map.get(integer);
      TreeMap<Object, Object> treeMap1 = treeMap2;
      if (treeMap2 == null) {
        treeMap1 = new TreeMap<Object, Object>();
        map.put(integer, treeMap1);
      } 
      treeMap1 = treeMap1;
      if (treeMap1.containsKey(Integer.valueOf(j))) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Overriding migration ");
        stringBuilder.append(treeMap1.get(Integer.valueOf(j)));
        stringBuilder.append(" with ");
        stringBuilder.append(param1b);
        Log.w("ROOM", stringBuilder.toString());
      } 
      treeMap1.put(Integer.valueOf(j), param1b);
    }
    
    private final List<b4.b> e(List<b4.b> param1List, boolean param1Boolean, int param1Int1, int param1Int2) {
      while (true) {
        boolean bool1;
        boolean bool2 = true;
        if (param1Boolean ? (param1Int1 < param1Int2) : (param1Int1 > param1Int2)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (bool1) {
          Set set;
          TreeMap treeMap = this.a.get(Integer.valueOf(param1Int1));
          if (treeMap == null)
            return null; 
          if (param1Boolean) {
            set = treeMap.descendingKeySet();
          } else {
            set = treeMap.keySet();
          } 
          Iterator iterator = set.iterator();
          while (true) {
            while (true)
              break; 
            if (bool1) {
              treeMap = (TreeMap)treeMap.get(set);
              q.g(treeMap);
              param1List.add(treeMap);
              param1Int1 = set.intValue();
              bool1 = bool2;
              break;
            } 
          } 
          if (!bool1)
            return null; 
          continue;
        } 
        return param1List;
      } 
    }
    
    public void b(b4.b... param1VarArgs) {
      q.j(param1VarArgs, "migrations");
      int j = param1VarArgs.length;
      for (int i = 0; i < j; i++)
        a(param1VarArgs[i]); 
    }
    
    public final boolean c(int param1Int1, int param1Int2) {
      Map<Integer, Map<Integer, b4.b>> map = f();
      if (map.containsKey(Integer.valueOf(param1Int1))) {
        Map<Integer, Map<Integer, b4.b>> map1 = (Map)map.get(Integer.valueOf(param1Int1));
        map = map1;
        if (map1 == null)
          map = k0.g(); 
        return map.containsKey(Integer.valueOf(param1Int2));
      } 
      return false;
    }
    
    public List<b4.b> d(int param1Int1, int param1Int2) {
      boolean bool;
      if (param1Int1 == param1Int2)
        return r.l(); 
      if (param1Int2 > param1Int1) {
        bool = true;
      } else {
        bool = false;
      } 
      return e(new ArrayList<b4.b>(), bool, param1Int1, param1Int2);
    }
    
    public Map<Integer, Map<Integer, b4.b>> f() {
      return (Map)this.a;
    }
  }
  
  public static abstract class f {}
  
  static final class g extends r implements l<e4.g, Object> {
    g(w param1w) {
      super(1);
    }
    
    public final Object a(e4.g param1g) {
      q.j(param1g, "it");
      w.a(this.s0);
      return null;
    }
  }
  
  static final class h extends r implements l<e4.g, Object> {
    h(w param1w) {
      super(1);
    }
    
    public final Object a(e4.g param1g) {
      q.j(param1g, "it");
      w.b(this.s0);
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */