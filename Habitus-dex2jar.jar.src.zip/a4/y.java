package a4;

import kotlin.jvm.internal.q;

public final class y {
  public static final y a = new y();
  
  public static final String a(String paramString) {
    q.j(paramString, "hash");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '");
    stringBuilder.append(paramString);
    stringBuilder.append("')");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */