package a4;

import dk.p;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.jvm.internal.h;
import vj.e;
import vj.g;

public final class e0 implements g.b {
  public static final a u0 = new a(null);
  
  private final e s0;
  
  private final AtomicInteger t0;
  
  public e0(e parame) {
    this.s0 = parame;
    this.t0 = new AtomicInteger(0);
  }
  
  public final void c() {
    this.t0.incrementAndGet();
  }
  
  public final e d() {
    return this.s0;
  }
  
  public final void e() {
    if (this.t0.decrementAndGet() >= 0)
      return; 
    throw new IllegalStateException("Transaction was never started or was already released.");
  }
  
  public <R> R fold(R paramR, p<? super R, ? super g.b, ? extends R> paramp) {
    return (R)g.b.a.a(this, paramR, paramp);
  }
  
  public <E extends g.b> E get(g.c<E> paramc) {
    return (E)g.b.a.b(this, paramc);
  }
  
  public g.c<e0> getKey() {
    return u0;
  }
  
  public g minusKey(g.c<?> paramc) {
    return g.b.a.c(this, paramc);
  }
  
  public g plus(g paramg) {
    return g.b.a.d(this, paramg);
  }
  
  public static final class a implements g.c<e0> {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */