package a4;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface l extends IInterface {
  void z(String[] paramArrayOfString) throws RemoteException;
  
  public static abstract class a extends Binder implements l {
    public a() {
      attachInterface(this, "androidx.room.IMultiInstanceInvalidationCallback");
    }
    
    public static l i1(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationCallback");
      return (iInterface != null && iInterface instanceof l) ? (l)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationCallback"); 
      if (param1Int1 != 1598968902) {
        if (param1Int1 != 1)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        z(param1Parcel1.createStringArray());
        return true;
      } 
      param1Parcel2.writeString("androidx.room.IMultiInstanceInvalidationCallback");
      return true;
    }
    
    private static class a implements l {
      private IBinder c;
      
      a(IBinder param2IBinder) {
        this.c = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.c;
      }
      
      public void z(String[] param2ArrayOfString) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
          parcel.writeStringArray(param2ArrayOfString);
          this.c.transact(1, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class a implements l {
    private IBinder c;
    
    a(IBinder param1IBinder) {
      this.c = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.c;
    }
    
    public void z(String[] param1ArrayOfString) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
        parcel.writeStringArray(param1ArrayOfString);
        this.c.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */