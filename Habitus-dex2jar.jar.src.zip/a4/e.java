package a4;

import e4.h;
import kotlin.jvm.internal.q;

public final class e implements h.c {
  private final h.c a;
  
  private final c b;
  
  public e(h.c paramc, c paramc1) {
    this.a = paramc;
    this.b = paramc1;
  }
  
  public d b(h.b paramb) {
    q.j(paramb, "configuration");
    return new d(this.a.a(paramb), this.b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */