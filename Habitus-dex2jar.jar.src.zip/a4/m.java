package a4;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface m extends IInterface {
  void g0(l paraml, int paramInt) throws RemoteException;
  
  void o0(int paramInt, String[] paramArrayOfString) throws RemoteException;
  
  int x(l paraml, String paramString) throws RemoteException;
  
  public static abstract class a extends Binder implements m {
    public a() {
      attachInterface(this, "androidx.room.IMultiInstanceInvalidationService");
    }
    
    public static m i1(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationService");
      return (iInterface != null && iInterface instanceof m) ? (m)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationService"); 
      if (param1Int1 != 1598968902) {
        if (param1Int1 != 1) {
          if (param1Int1 != 2) {
            if (param1Int1 != 3)
              return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
            o0(param1Parcel1.readInt(), param1Parcel1.createStringArray());
            return true;
          } 
          g0(l.a.i1(param1Parcel1.readStrongBinder()), param1Parcel1.readInt());
          param1Parcel2.writeNoException();
          return true;
        } 
        param1Int1 = x(l.a.i1(param1Parcel1.readStrongBinder()), param1Parcel1.readString());
        param1Parcel2.writeNoException();
        param1Parcel2.writeInt(param1Int1);
        return true;
      } 
      param1Parcel2.writeString("androidx.room.IMultiInstanceInvalidationService");
      return true;
    }
    
    private static class a implements m {
      private IBinder c;
      
      a(IBinder param2IBinder) {
        this.c = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.c;
      }
      
      public void o0(int param2Int, String[] param2ArrayOfString) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
          parcel.writeInt(param2Int);
          parcel.writeStringArray(param2ArrayOfString);
          this.c.transact(3, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public int x(l param2l, String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
          parcel1.writeStrongInterface(param2l);
          parcel1.writeString(param2String);
          this.c.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements m {
    private IBinder c;
    
    a(IBinder param1IBinder) {
      this.c = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.c;
    }
    
    public void o0(int param1Int, String[] param1ArrayOfString) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
        parcel.writeInt(param1Int);
        parcel.writeStringArray(param1ArrayOfString);
        this.c.transact(3, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public int x(l param1l, String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
        parcel1.writeStrongInterface(param1l);
        parcel1.writeString(param1String);
        this.c.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */