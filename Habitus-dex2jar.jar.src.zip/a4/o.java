package a4;

import androidx.lifecycle.LiveData;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import kotlin.jvm.internal.q;

public final class o {
  private final w a;
  
  private final Set<LiveData<?>> b;
  
  public o(w paramw) {
    this.a = paramw;
    Set<?> set = Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>());
    q.i(set, "newSetFromMap(IdentityHashMap())");
    this.b = (Set)set;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */