package a4;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import b4.a;
import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

public class h {
  public final Context a;
  
  public final String b;
  
  public final e4.h.c c;
  
  public final w.e d;
  
  public final List<w.b> e;
  
  public final boolean f;
  
  public final w.d g;
  
  public final Executor h;
  
  public final Executor i;
  
  public final Intent j;
  
  public final boolean k;
  
  public final boolean l;
  
  private final Set<Integer> m;
  
  public final String n;
  
  public final File o;
  
  public final Callable<InputStream> p;
  
  public final List<Object> q;
  
  public final List<a> r;
  
  public final boolean s;
  
  @SuppressLint({"LambdaLast"})
  public h(Context paramContext, String paramString1, e4.h.c paramc, w.e parame, List<? extends w.b> paramList, boolean paramBoolean1, w.d paramd, Executor paramExecutor1, Executor paramExecutor2, Intent paramIntent, boolean paramBoolean2, boolean paramBoolean3, Set<Integer> paramSet, String paramString2, File paramFile, Callable<InputStream> paramCallable, w.f paramf, List<? extends Object> paramList1, List<? extends a> paramList2) {
    this.a = paramContext;
    this.b = paramString1;
    this.c = paramc;
    this.d = parame;
    this.e = (List)paramList;
    this.f = paramBoolean1;
    this.g = paramd;
    this.h = paramExecutor1;
    this.i = paramExecutor2;
    this.j = paramIntent;
    this.k = paramBoolean2;
    this.l = paramBoolean3;
    this.m = paramSet;
    this.n = paramString2;
    this.o = paramFile;
    this.p = paramCallable;
    this.q = (List)paramList1;
    this.r = (List)paramList2;
    if (paramIntent != null) {
      paramBoolean1 = true;
    } else {
      paramBoolean1 = false;
    } 
    this.s = paramBoolean1;
  }
  
  public boolean a(int paramInt1, int paramInt2) {
    null = true;
    if (paramInt1 > paramInt2) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    if (paramInt2 != 0 && this.l)
      return false; 
    if (this.k) {
      Set<Integer> set = this.m;
      if (set != null) {
        if (!set.contains(Integer.valueOf(paramInt1)))
          return true; 
      } else {
        return null;
      } 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */