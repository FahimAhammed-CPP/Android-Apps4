package a4;

import e4.k;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.f;
import rj.g;

public abstract class d0 {
  private final w a;
  
  private final AtomicBoolean b;
  
  private final f c;
  
  public d0(w paramw) {
    this.a = paramw;
    this.b = new AtomicBoolean(false);
    this.c = g.a(new a(this));
  }
  
  private final k d() {
    String str = e();
    return this.a.f(str);
  }
  
  private final k f() {
    return (k)this.c.getValue();
  }
  
  private final k g(boolean paramBoolean) {
    return paramBoolean ? f() : d();
  }
  
  public k b() {
    c();
    return g(this.b.compareAndSet(false, true));
  }
  
  protected void c() {
    this.a.c();
  }
  
  protected abstract String e();
  
  public void h(k paramk) {
    q.j(paramk, "statement");
    if (paramk == f())
      this.b.set(false); 
  }
  
  static final class a extends r implements dk.a<k> {
    a(d0 param1d0) {
      super(0);
    }
    
    public final k d() {
      return d0.a(this.s0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */