package a4;

import android.content.Context;
import e4.g;
import e4.h;
import g4.a;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Callable;
import kotlin.jvm.internal.q;

public final class b0 implements h, i {
  private final Context s0;
  
  private final String t0;
  
  private final File u0;
  
  private final Callable<InputStream> v0;
  
  private final int w0;
  
  private final h x0;
  
  private h y0;
  
  private boolean z0;
  
  public b0(Context paramContext, String paramString, File paramFile, Callable<InputStream> paramCallable, int paramInt, h paramh) {
    this.s0 = paramContext;
    this.t0 = paramString;
    this.u0 = paramFile;
    this.v0 = paramCallable;
    this.w0 = paramInt;
    this.x0 = paramh;
  }
  
  private final void a(File paramFile, boolean paramBoolean) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: getfield t0 : Ljava/lang/String;
    //   4: ifnull -> 34
    //   7: aload_0
    //   8: getfield s0 : Landroid/content/Context;
    //   11: invokevirtual getAssets : ()Landroid/content/res/AssetManager;
    //   14: aload_0
    //   15: getfield t0 : Ljava/lang/String;
    //   18: invokevirtual open : (Ljava/lang/String;)Ljava/io/InputStream;
    //   21: invokestatic newChannel : (Ljava/io/InputStream;)Ljava/nio/channels/ReadableByteChannel;
    //   24: astore_3
    //   25: aload_3
    //   26: ldc 'newChannel(context.assets.open(copyFromAssetPath))'
    //   28: invokestatic i : (Ljava/lang/Object;Ljava/lang/String;)V
    //   31: goto -> 95
    //   34: aload_0
    //   35: getfield u0 : Ljava/io/File;
    //   38: ifnull -> 65
    //   41: new java/io/FileInputStream
    //   44: dup
    //   45: aload_0
    //   46: getfield u0 : Ljava/io/File;
    //   49: invokespecial <init> : (Ljava/io/File;)V
    //   52: invokevirtual getChannel : ()Ljava/nio/channels/FileChannel;
    //   55: astore_3
    //   56: aload_3
    //   57: ldc 'FileInputStream(copyFromFile).channel'
    //   59: invokestatic i : (Ljava/lang/Object;Ljava/lang/String;)V
    //   62: goto -> 95
    //   65: aload_0
    //   66: getfield v0 : Ljava/util/concurrent/Callable;
    //   69: astore_3
    //   70: aload_3
    //   71: ifnull -> 301
    //   74: aload_3
    //   75: invokeinterface call : ()Ljava/lang/Object;
    //   80: checkcast java/io/InputStream
    //   83: astore_3
    //   84: aload_3
    //   85: invokestatic newChannel : (Ljava/io/InputStream;)Ljava/nio/channels/ReadableByteChannel;
    //   88: astore_3
    //   89: aload_3
    //   90: ldc 'newChannel(inputStream)'
    //   92: invokestatic i : (Ljava/lang/Object;Ljava/lang/String;)V
    //   95: ldc 'room-copy-helper'
    //   97: ldc '.tmp'
    //   99: aload_0
    //   100: getfield s0 : Landroid/content/Context;
    //   103: invokevirtual getCacheDir : ()Ljava/io/File;
    //   106: invokestatic createTempFile : (Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;
    //   109: astore #4
    //   111: aload #4
    //   113: invokevirtual deleteOnExit : ()V
    //   116: new java/io/FileOutputStream
    //   119: dup
    //   120: aload #4
    //   122: invokespecial <init> : (Ljava/io/File;)V
    //   125: invokevirtual getChannel : ()Ljava/nio/channels/FileChannel;
    //   128: astore #5
    //   130: aload #5
    //   132: ldc 'output'
    //   134: invokestatic i : (Ljava/lang/Object;Ljava/lang/String;)V
    //   137: aload_3
    //   138: aload #5
    //   140: invokestatic a : (Ljava/nio/channels/ReadableByteChannel;Ljava/nio/channels/FileChannel;)V
    //   143: aload_1
    //   144: invokevirtual getParentFile : ()Ljava/io/File;
    //   147: astore_3
    //   148: aload_3
    //   149: ifnull -> 205
    //   152: aload_3
    //   153: invokevirtual exists : ()Z
    //   156: ifne -> 205
    //   159: aload_3
    //   160: invokevirtual mkdirs : ()Z
    //   163: ifeq -> 169
    //   166: goto -> 205
    //   169: new java/lang/StringBuilder
    //   172: dup
    //   173: invokespecial <init> : ()V
    //   176: astore_3
    //   177: aload_3
    //   178: ldc 'Failed to create directories for '
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: pop
    //   184: aload_3
    //   185: aload_1
    //   186: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   189: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   192: pop
    //   193: new java/io/IOException
    //   196: dup
    //   197: aload_3
    //   198: invokevirtual toString : ()Ljava/lang/String;
    //   201: invokespecial <init> : (Ljava/lang/String;)V
    //   204: athrow
    //   205: aload #4
    //   207: ldc 'intermediateFile'
    //   209: invokestatic i : (Ljava/lang/Object;Ljava/lang/String;)V
    //   212: aload_0
    //   213: aload #4
    //   215: iload_2
    //   216: invokespecial b : (Ljava/io/File;Z)V
    //   219: aload #4
    //   221: aload_1
    //   222: invokevirtual renameTo : (Ljava/io/File;)Z
    //   225: ifeq -> 229
    //   228: return
    //   229: new java/lang/StringBuilder
    //   232: dup
    //   233: invokespecial <init> : ()V
    //   236: astore_3
    //   237: aload_3
    //   238: ldc 'Failed to move intermediate file ('
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: pop
    //   244: aload_3
    //   245: aload #4
    //   247: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: pop
    //   254: aload_3
    //   255: ldc ') to destination ('
    //   257: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   260: pop
    //   261: aload_3
    //   262: aload_1
    //   263: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   266: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   269: pop
    //   270: aload_3
    //   271: ldc ').'
    //   273: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   276: pop
    //   277: new java/io/IOException
    //   280: dup
    //   281: aload_3
    //   282: invokevirtual toString : ()Ljava/lang/String;
    //   285: invokespecial <init> : (Ljava/lang/String;)V
    //   288: athrow
    //   289: astore_1
    //   290: new java/io/IOException
    //   293: dup
    //   294: ldc 'inputStreamCallable exception on call'
    //   296: aload_1
    //   297: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   300: athrow
    //   301: new java/lang/IllegalStateException
    //   304: dup
    //   305: ldc 'copyFromAssetPath, copyFromFile and copyFromInputStream are all null!'
    //   307: invokespecial <init> : (Ljava/lang/String;)V
    //   310: athrow
    // Exception table:
    //   from	to	target	type
    //   74	84	289	java/lang/Exception
  }
  
  private final void b(File paramFile, boolean paramBoolean) {
    h h2 = this.y0;
    h h1 = h2;
    if (h2 == null) {
      q.B("databaseConfiguration");
      h1 = null;
    } 
    h1.getClass();
  }
  
  private final void d(boolean paramBoolean) {
    String str = getDatabaseName();
    if (str != null) {
      File file = this.s0.getDatabasePath(str);
      h h2 = this.y0;
      h h1 = null;
      null = h2;
      if (h2 == null) {
        q.B("databaseConfiguration");
        null = null;
      } 
      boolean bool = null.s;
      a a = new a(str, this.s0.getFilesDir(), bool);
      try {
        a.c(a, false, 1, null);
        bool = file.exists();
        if (!bool)
          try {
            q.i(file, "databaseFile");
            a(file, paramBoolean);
            return;
          } catch (IOException iOException) {
            throw new RuntimeException("Unable to copy database file.", iOException);
          }  
      } finally {
        a.d();
      } 
    } 
    throw new IllegalStateException("Required value was null.".toString());
  }
  
  public final void c(h paramh) {
    q.j(paramh, "databaseConfiguration");
    this.y0 = paramh;
  }
  
  public void close() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual getDelegate : ()Le4/h;
    //   6: invokeinterface close : ()V
    //   11: aload_0
    //   12: iconst_0
    //   13: putfield z0 : Z
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  public String getDatabaseName() {
    return getDelegate().getDatabaseName();
  }
  
  public h getDelegate() {
    return this.x0;
  }
  
  public g o0() {
    if (!this.z0) {
      d(true);
      this.z0 = true;
    } 
    return getDelegate().o0();
  }
  
  public void setWriteAheadLoggingEnabled(boolean paramBoolean) {
    getDelegate().setWriteAheadLoggingEnabled(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */