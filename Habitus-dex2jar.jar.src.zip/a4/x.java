package a4;

import dk.l;
import dk.p;
import java.util.concurrent.RejectedExecutionException;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.h;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.ThreadContextElement;
import kotlinx.coroutines.ThreadContextElementKt;
import rj.m;
import rj.n;
import rj.v;
import vj.d;
import vj.e;
import vj.g;

public final class x {
  private static final g b(w paramw, e parame) {
    e0 e0 = new e0(parame);
    ThreadContextElement threadContextElement = ThreadContextElementKt.asContextElement(paramw.r(), Integer.valueOf(System.identityHashCode(e0)));
    return parame.plus((g)e0).plus((g)threadContextElement);
  }
  
  private static final <R> Object c(w paramw, g paramg, p<? super CoroutineScope, ? super d<? super R>, ? extends Object> paramp, d<? super R> paramd) {
    CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(wj.b.c(paramd), 1);
    cancellableContinuationImpl.initCancellability();
    try {
      paramw.s().execute(new a(paramg, (CancellableContinuation<? super R>)cancellableContinuationImpl, paramw, paramp));
    } catch (RejectedExecutionException rejectedExecutionException) {
      cancellableContinuationImpl.cancel(new IllegalStateException("Unable to acquire a thread to perform the database transaction.", rejectedExecutionException));
    } 
    Object object = cancellableContinuationImpl.getResult();
    if (object == wj.b.d())
      h.c(paramd); 
    return object;
  }
  
  public static final <R> Object d(w paramw, l<? super d<? super R>, ? extends Object> paraml, d<? super R> paramd) {
    e e;
    l l1 = null;
    b b = new b(paramw, paraml, null);
    e0 e0 = (e0)paramd.getContext().get(e0.u0);
    paraml = l1;
    if (e0 != null)
      e = e0.d(); 
    return (e != null) ? BuildersKt.withContext((g)e, b, paramd) : c(paramw, paramd.getContext(), b, paramd);
  }
  
  static final class a implements Runnable {
    a(g param1g, CancellableContinuation<? super R> param1CancellableContinuation, w param1w, p<? super CoroutineScope, ? super d<? super R>, ? extends Object> param1p) {}
    
    public final void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.t0.cancel(exception);
      } 
    }
    
    @f(c = "androidx.room.RoomDatabaseKt$startTransactionCoroutine$2$1$1", f = "RoomDatabaseExt.kt", l = {97}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
      int s0;
      
      a(w param2w, CancellableContinuation<? super R> param2CancellableContinuation, p<? super CoroutineScope, ? super d<? super R>, ? extends Object> param2p, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<v> create(Object param2Object, d<?> param2d) {
        a a1 = new a(this.u0, this.v0, this.w0, (d)param2d);
        a1.t0 = param2Object;
        return (d<v>)a1;
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, d<? super v> param2d) {
        return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object<R> param2Object) {
        Object object1;
        Object<R> object = (Object<R>)wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1) {
            object = (Object<R>)this.t0;
            n.b(param2Object);
            object1 = param2Object;
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param2Object);
          param2Object = (Object<R>)((CoroutineScope)this.t0).getCoroutineContext().get((g.c)e.q0);
          q.g(param2Object);
          param2Object = param2Object;
          g g = x.a(this.u0, (e)param2Object);
          param2Object = (Object<R>)this.v0;
          p<CoroutineScope, d<? super R>, Object> p1 = this.w0;
          this.t0 = param2Object;
          this.s0 = 1;
          object1 = BuildersKt.withContext(g, p1, (d)this);
          if (object1 == object)
            return object; 
          object = param2Object;
        } 
        object.resumeWith(m.b(object1));
        return v.a;
      }
    }
  }
  
  @f(c = "androidx.room.RoomDatabaseKt$startTransactionCoroutine$2$1$1", f = "RoomDatabaseExt.kt", l = {97}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, d<? super v>, Object> {
    int s0;
    
    a(w param1w, CancellableContinuation<? super R> param1CancellableContinuation, p<? super CoroutineScope, ? super d<? super R>, ? extends Object> param1p, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.u0, this.v0, this.w0, (d)param1d);
      a1.t0 = param1Object;
      return (d<v>)a1;
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object<R> param1Object) {
      Object object1;
      Object<R> object = (Object<R>)wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          object = (Object<R>)this.t0;
          n.b(param1Object);
          object1 = param1Object;
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = (Object<R>)((CoroutineScope)this.t0).getCoroutineContext().get((g.c)e.q0);
        q.g(param1Object);
        param1Object = param1Object;
        g g = x.a(this.u0, (e)param1Object);
        param1Object = (Object<R>)this.v0;
        p<CoroutineScope, d<? super R>, Object> p1 = this.w0;
        this.t0 = param1Object;
        this.s0 = 1;
        object1 = BuildersKt.withContext(g, p1, (d)this);
        if (object1 == object)
          return object; 
        object = param1Object;
      } 
      object.resumeWith(m.b(object1));
      return v.a;
    }
  }
  
  @f(c = "androidx.room.RoomDatabaseKt$withTransaction$transactionBlock$1", f = "RoomDatabaseExt.kt", l = {56}, m = "invokeSuspend")
  static final class b extends l implements p<CoroutineScope, d<? super R>, Object> {
    int s0;
    
    b(w param1w, l<? super d<? super R>, ? extends Object> param1l, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final d<v> create(Object param1Object, d<?> param1d) {
      b b1 = new b(this.u0, this.v0, (d)param1d);
      b1.t0 = param1Object;
      return (d<v>)b1;
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, d<? super R> param1d) {
      return ((b)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      // Byte code:
      //   0: invokestatic d : ()Ljava/lang/Object;
      //   3: astore_3
      //   4: aload_0
      //   5: getfield s0 : I
      //   8: istore_2
      //   9: iload_2
      //   10: ifeq -> 53
      //   13: iload_2
      //   14: iconst_1
      //   15: if_icmpne -> 43
      //   18: aload_0
      //   19: getfield t0 : Ljava/lang/Object;
      //   22: checkcast a4/e0
      //   25: astore_3
      //   26: aload_3
      //   27: astore #4
      //   29: aload_1
      //   30: invokestatic b : (Ljava/lang/Object;)V
      //   33: aload_1
      //   34: astore #5
      //   36: goto -> 134
      //   39: astore_3
      //   40: goto -> 164
      //   43: new java/lang/IllegalStateException
      //   46: dup
      //   47: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   49: invokespecial <init> : (Ljava/lang/String;)V
      //   52: athrow
      //   53: aload_1
      //   54: invokestatic b : (Ljava/lang/Object;)V
      //   57: aload_0
      //   58: getfield t0 : Ljava/lang/Object;
      //   61: checkcast kotlinx/coroutines/CoroutineScope
      //   64: invokeinterface getCoroutineContext : ()Lvj/g;
      //   69: getstatic a4/e0.u0 : La4/e0$a;
      //   72: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
      //   77: astore_1
      //   78: aload_1
      //   79: invokestatic g : (Ljava/lang/Object;)V
      //   82: aload_1
      //   83: checkcast a4/e0
      //   86: astore_1
      //   87: aload_1
      //   88: invokevirtual c : ()V
      //   91: aload_0
      //   92: getfield u0 : La4/w;
      //   95: invokevirtual e : ()V
      //   98: aload_0
      //   99: getfield v0 : Ldk/l;
      //   102: astore #4
      //   104: aload_0
      //   105: aload_1
      //   106: putfield t0 : Ljava/lang/Object;
      //   109: aload_0
      //   110: iconst_1
      //   111: putfield s0 : I
      //   114: aload #4
      //   116: aload_0
      //   117: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
      //   122: astore #5
      //   124: aload #5
      //   126: aload_3
      //   127: if_acmpne -> 132
      //   130: aload_3
      //   131: areturn
      //   132: aload_1
      //   133: astore_3
      //   134: aload_3
      //   135: astore #4
      //   137: aload_0
      //   138: getfield u0 : La4/w;
      //   141: invokevirtual D : ()V
      //   144: aload_3
      //   145: astore_1
      //   146: aload_0
      //   147: getfield u0 : La4/w;
      //   150: invokevirtual i : ()V
      //   153: aload_3
      //   154: invokevirtual e : ()V
      //   157: aload #5
      //   159: areturn
      //   160: astore_3
      //   161: aload_1
      //   162: astore #4
      //   164: aload #4
      //   166: astore_1
      //   167: aload_0
      //   168: getfield u0 : La4/w;
      //   171: invokevirtual i : ()V
      //   174: aload #4
      //   176: astore_1
      //   177: aload_3
      //   178: athrow
      //   179: astore_3
      //   180: goto -> 184
      //   183: astore_3
      //   184: aload_1
      //   185: invokevirtual e : ()V
      //   188: aload_3
      //   189: athrow
      // Exception table:
      //   from	to	target	type
      //   29	33	39	finally
      //   91	98	183	finally
      //   98	124	160	finally
      //   137	144	39	finally
      //   146	153	179	finally
      //   167	174	179	finally
      //   177	179	179	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */