package a4;

import java.util.Map;
import kotlin.jvm.internal.q;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.ExecutorsKt;

public final class g {
  public static final CoroutineDispatcher a(w paramw) {
    q.j(paramw, "<this>");
    Map<String, Object> map = paramw.k();
    Object object2 = map.get("QueryDispatcher");
    Object object1 = object2;
    if (object2 == null) {
      object1 = ExecutorsKt.from(paramw.o());
      map.put("QueryDispatcher", object1);
    } 
    q.h(object1, "null cannot be cast to non-null type kotlinx.coroutines.CoroutineDispatcher");
    return (CoroutineDispatcher)object1;
  }
  
  public static final CoroutineDispatcher b(w paramw) {
    q.j(paramw, "<this>");
    Map<String, Object> map = paramw.k();
    Object object2 = map.get("TransactionDispatcher");
    Object object1 = object2;
    if (object2 == null) {
      object1 = ExecutorsKt.from(paramw.s());
      map.put("TransactionDispatcher", object1);
    } 
    q.h(object1, "null cannot be cast to non-null type kotlinx.coroutines.CoroutineDispatcher");
    return (CoroutineDispatcher)object1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */