package a4;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;
import kotlin.jvm.internal.q;
import rj.v;

public final class g0 implements Executor {
  private final Executor s0;
  
  private final ArrayDeque<Runnable> t0;
  
  private Runnable u0;
  
  private final Object v0;
  
  public g0(Executor paramExecutor) {
    this.s0 = paramExecutor;
    this.t0 = new ArrayDeque<Runnable>();
    this.v0 = new Object();
  }
  
  private static final void b(Runnable paramRunnable, g0 paramg0) {
    q.j(paramRunnable, "$command");
    q.j(paramg0, "this$0");
    try {
      paramRunnable.run();
      return;
    } finally {
      paramg0.c();
    } 
  }
  
  public final void c() {
    synchronized (this.v0) {
      Runnable runnable1 = (Runnable)this.t0.poll();
      Runnable runnable2 = runnable1;
      this.u0 = runnable2;
      if (runnable1 != null)
        this.s0.execute(runnable2); 
      v v = v.a;
      return;
    } 
  }
  
  public void execute(Runnable paramRunnable) {
    q.j(paramRunnable, "command");
    synchronized (this.v0) {
      this.t0.offer(new f0(paramRunnable, this));
      if (this.u0 == null)
        c(); 
      v v = v.a;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */