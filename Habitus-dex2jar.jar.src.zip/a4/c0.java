package a4;

import e4.h;
import java.io.File;
import java.io.InputStream;
import java.util.concurrent.Callable;
import kotlin.jvm.internal.q;

public final class c0 implements h.c {
  private final String a;
  
  private final File b;
  
  private final Callable<InputStream> c;
  
  private final h.c d;
  
  public c0(String paramString, File paramFile, Callable<InputStream> paramCallable, h.c paramc) {
    this.a = paramString;
    this.b = paramFile;
    this.c = paramCallable;
    this.d = paramc;
  }
  
  public h a(h.b paramb) {
    q.j(paramb, "configuration");
    return new b0(paramb.a, this.a, this.b, this.c, paramb.c.a, this.d.a(paramb));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */