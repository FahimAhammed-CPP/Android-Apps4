package a4;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import dk.l;
import e4.g;
import e4.h;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import rj.v;

public final class c {
  public static final a m = new a(null);
  
  public h a;
  
  private final Handler b = new Handler(Looper.getMainLooper());
  
  private Runnable c;
  
  private final Object d = new Object();
  
  private long e;
  
  private final Executor f;
  
  private int g;
  
  private long h;
  
  private g i;
  
  private boolean j;
  
  private final Runnable k;
  
  private final Runnable l;
  
  public c(long paramLong, TimeUnit paramTimeUnit, Executor paramExecutor) {
    this.e = paramTimeUnit.toMillis(paramLong);
    this.f = paramExecutor;
    this.h = SystemClock.uptimeMillis();
    this.k = new a(this);
    this.l = new b(this);
  }
  
  private static final void c(c paramc) {
    q.j(paramc, "this$0");
    synchronized (paramc.d) {
      long l1 = SystemClock.uptimeMillis();
      long l2 = paramc.h;
      long l3 = paramc.e;
      if (l1 - l2 < l3)
        return; 
      int i = paramc.g;
      if (i != 0)
        return; 
      Runnable runnable = paramc.c;
      if (runnable != null) {
        runnable.run();
        v v = v.a;
      } else {
        runnable = null;
      } 
      if (runnable != null) {
        g g1 = paramc.i;
        if (g1 != null && g1.isOpen())
          g1.close(); 
        paramc.i = null;
        v v = v.a;
        return;
      } 
      throw new IllegalStateException("onAutoCloseCallback is null but it should have been set before use. Please file a bug against Room at: https://issuetracker.google.com/issues/new?component=413107&template=1096568".toString());
    } 
  }
  
  private static final void f(c paramc) {
    q.j(paramc, "this$0");
    paramc.f.execute(paramc.l);
  }
  
  public final void d() throws IOException {
    synchronized (this.d) {
      this.j = true;
      g g1 = this.i;
      if (g1 != null)
        g1.close(); 
      this.i = null;
      v v = v.a;
      return;
    } 
  }
  
  public final void e() {
    synchronized (this.d) {
      int i;
      int j = this.g;
      if (j > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i) {
        i = j - 1;
        this.g = i;
        if (i == 0) {
          g g1 = this.i;
          if (g1 == null)
            return; 
          this.b.postDelayed(this.k, this.e);
        } 
        v v = v.a;
        return;
      } 
      throw new IllegalStateException("ref count is 0 or lower but we're supposed to decrement".toString());
    } 
  }
  
  public final <V> V g(l<? super g, ? extends V> paraml) {
    q.j(paraml, "block");
    try {
      return (V)paraml.invoke(j());
    } finally {
      e();
    } 
  }
  
  public final g h() {
    return this.i;
  }
  
  public final h i() {
    h h1 = this.a;
    if (h1 != null)
      return h1; 
    q.B("delegateOpenHelper");
    return null;
  }
  
  public final g j() {
    synchronized (this.d) {
      this.b.removeCallbacks(this.k);
      this.g++;
      if ((this.j ^ true) != 0) {
        g g1 = this.i;
        if (g1 != null) {
          boolean bool = g1.isOpen();
          if (bool)
            return g1; 
        } 
        g1 = i().o0();
        this.i = g1;
        return g1;
      } 
      throw new IllegalStateException("Attempting to open already closed database.".toString());
    } 
  }
  
  public final void k(h paramh) {
    q.j(paramh, "delegateOpenHelper");
    m(paramh);
  }
  
  public final void l(Runnable paramRunnable) {
    q.j(paramRunnable, "onAutoClose");
    this.c = paramRunnable;
  }
  
  public final void m(h paramh) {
    q.j(paramh, "<set-?>");
    this.a = paramh;
  }
  
  public static final class a {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */