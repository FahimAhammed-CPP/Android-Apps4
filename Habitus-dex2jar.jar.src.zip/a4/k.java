package a4;

import java.util.Iterator;
import kotlin.jvm.internal.q;

public abstract class k<T> extends d0 {
  public k(w paramw) {
    super(paramw);
  }
  
  protected abstract void i(e4.k paramk, T paramT);
  
  public final void j(Iterable<? extends T> paramIterable) {
    q.j(paramIterable, "entities");
    e4.k k1 = b();
    try {
      Iterator<? extends T> iterator = paramIterable.iterator();
      while (iterator.hasNext()) {
        i(k1, iterator.next());
        k1.W();
      } 
      return;
    } finally {
      h(k1);
    } 
  }
  
  public final void k(T paramT) {
    e4.k k1 = b();
    try {
      i(k1, paramT);
      k1.W();
      return;
    } finally {
      h(k1);
    } 
  }
  
  public final long l(T paramT) {
    e4.k k1 = b();
    try {
      i(k1, paramT);
      return k1.W();
    } finally {
      h(k1);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */