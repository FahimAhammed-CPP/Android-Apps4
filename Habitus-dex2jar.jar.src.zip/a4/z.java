package a4;

import android.database.Cursor;
import e4.g;
import e4.h;
import e4.j;
import java.io.Closeable;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;

public class z extends h.a {
  public static final a g = new a(null);
  
  private h c;
  
  private final b d;
  
  private final String e;
  
  private final String f;
  
  public z(h paramh, b paramb, String paramString1, String paramString2) {
    super(paramb.a);
    this.c = paramh;
    this.d = paramb;
    this.e = paramString1;
    this.f = paramString2;
  }
  
  private final void h(g paramg) {
    if (g.b(paramg)) {
      StringBuilder stringBuilder;
      Cursor cursor = paramg.v0((j)new e4.a("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"));
      try {
        if (cursor.moveToFirst()) {
          String str = cursor.getString(0);
        } else {
          paramg = null;
        } 
        bk.b.a((Closeable)cursor, null);
      } finally {
        paramg = null;
      } 
    } else {
      c c = this.d.g(paramg);
      if (c.a) {
        this.d.e(paramg);
        j(paramg);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Pre-packaged database has an invalid schema: ");
      stringBuilder.append(c.b);
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  private final void i(g paramg) {
    paramg.l("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
  }
  
  private final void j(g paramg) {
    i(paramg);
    paramg.l(y.a(this.e));
  }
  
  public void b(g paramg) {
    q.j(paramg, "db");
    super.b(paramg);
  }
  
  public void d(g paramg) {
    StringBuilder stringBuilder;
    q.j(paramg, "db");
    boolean bool = g.a(paramg);
    this.d.a(paramg);
    if (!bool) {
      c c = this.d.g(paramg);
      if (!c.a) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Pre-packaged database has an invalid schema: ");
        stringBuilder.append(c.b);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
    j((g)stringBuilder);
    this.d.c((g)stringBuilder);
  }
  
  public void e(g paramg, int paramInt1, int paramInt2) {
    q.j(paramg, "db");
    g(paramg, paramInt1, paramInt2);
  }
  
  public void f(g paramg) {
    q.j(paramg, "db");
    super.f(paramg);
    h(paramg);
    this.d.d(paramg);
    this.c = null;
  }
  
  public void g(g paramg, int paramInt1, int paramInt2) {
    StringBuilder stringBuilder;
    q.j(paramg, "db");
    h h1 = this.c;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (h1 != null) {
      List<b4.b> list = h1.d.d(paramInt1, paramInt2);
      bool1 = bool2;
      if (list != null) {
        this.d.f(paramg);
        Iterator<b4.b> iterator = list.iterator();
        while (iterator.hasNext())
          ((b4.b)iterator.next()).a(paramg); 
        c c = this.d.g(paramg);
        if (c.a) {
          this.d.e(paramg);
          j(paramg);
          bool1 = true;
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Migration didn't properly handle: ");
          stringBuilder.append(c.b);
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
    } 
    if (!bool1) {
      h1 = this.c;
      if (h1 != null && !h1.a(paramInt1, paramInt2)) {
        this.d.b((g)stringBuilder);
        this.d.a((g)stringBuilder);
        return;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("A migration from ");
      stringBuilder.append(paramInt1);
      stringBuilder.append(" to ");
      stringBuilder.append(paramInt2);
      stringBuilder.append(" was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.");
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  public static final class a {
    private a() {}
    
    public final boolean a(g param1g) {
      q.j(param1g, "db");
      Cursor cursor = param1g.p0("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");
      try {
        boolean bool = cursor.moveToFirst();
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (bool) {
          int i = cursor.getInt(0);
          bool1 = bool2;
          if (i == 0)
            bool1 = true; 
        } 
        return bool1;
      } finally {
        Exception exception = null;
      } 
    }
    
    public final boolean b(g param1g) {
      q.j(param1g, "db");
      Cursor cursor = param1g.p0("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");
      try {
        boolean bool = cursor.moveToFirst();
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (bool) {
          int i = cursor.getInt(0);
          bool1 = bool2;
          if (i != 0)
            bool1 = true; 
        } 
        return bool1;
      } finally {
        Exception exception = null;
      } 
    }
  }
  
  public static abstract class b {
    public final int a;
    
    public b(int param1Int) {
      this.a = param1Int;
    }
    
    public abstract void a(g param1g);
    
    public abstract void b(g param1g);
    
    public abstract void c(g param1g);
    
    public abstract void d(g param1g);
    
    public abstract void e(g param1g);
    
    public abstract void f(g param1g);
    
    public abstract z.c g(g param1g);
  }
  
  public static class c {
    public final boolean a;
    
    public final String b;
    
    public c(boolean param1Boolean, String param1String) {
      this.a = param1Boolean;
      this.b = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */