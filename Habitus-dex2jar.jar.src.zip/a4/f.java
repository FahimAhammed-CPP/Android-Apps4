package a4;

import android.os.CancellationSignal;
import dk.l;
import dk.p;
import java.util.Set;
import java.util.concurrent.Callable;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.channels.Channel;
import kotlinx.coroutines.channels.ChannelIterator;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import rj.m;
import rj.n;
import rj.v;

public final class f {
  public static final a a = new a(null);
  
  public static final <R> Flow<R> a(w paramw, boolean paramBoolean, String[] paramArrayOfString, Callable<R> paramCallable) {
    return a.a(paramw, paramBoolean, paramArrayOfString, paramCallable);
  }
  
  public static final <R> Object b(w paramw, boolean paramBoolean, CancellationSignal paramCancellationSignal, Callable<R> paramCallable, vj.d<? super R> paramd) {
    return a.b(paramw, paramBoolean, paramCancellationSignal, paramCallable, paramd);
  }
  
  public static final <R> Object c(w paramw, boolean paramBoolean, Callable<R> paramCallable, vj.d<? super R> paramd) {
    return a.c(paramw, paramBoolean, paramCallable, paramd);
  }
  
  public static final class a {
    private a() {}
    
    public final <R> Flow<R> a(w param1w, boolean param1Boolean, String[] param1ArrayOfString, Callable<R> param1Callable) {
      q.j(param1w, "db");
      q.j(param1ArrayOfString, "tableNames");
      q.j(param1Callable, "callable");
      return FlowKt.flow(new a(param1Boolean, param1w, param1ArrayOfString, param1Callable, null));
    }
    
    public final <R> Object b(w param1w, boolean param1Boolean, CancellationSignal param1CancellationSignal, Callable<R> param1Callable, vj.d<? super R> param1d) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual z : ()Z
      //   4: ifeq -> 22
      //   7: aload_1
      //   8: invokevirtual t : ()Z
      //   11: ifeq -> 22
      //   14: aload #4
      //   16: invokeinterface call : ()Ljava/lang/Object;
      //   21: areturn
      //   22: aload #5
      //   24: invokeinterface getContext : ()Lvj/g;
      //   29: getstatic a4/e0.u0 : La4/e0$a;
      //   32: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
      //   37: checkcast a4/e0
      //   40: astore #6
      //   42: aload #6
      //   44: ifnull -> 69
      //   47: aload #6
      //   49: invokevirtual d : ()Lvj/e;
      //   52: astore #7
      //   54: aload #7
      //   56: astore #6
      //   58: aload #7
      //   60: ifnonnull -> 66
      //   63: goto -> 69
      //   66: goto -> 92
      //   69: iload_2
      //   70: ifeq -> 81
      //   73: aload_1
      //   74: invokestatic b : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
      //   77: astore_1
      //   78: goto -> 86
      //   81: aload_1
      //   82: invokestatic a : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
      //   85: astore_1
      //   86: aload_1
      //   87: astore #6
      //   89: goto -> 66
      //   92: new kotlinx/coroutines/CancellableContinuationImpl
      //   95: dup
      //   96: aload #5
      //   98: invokestatic c : (Lvj/d;)Lvj/d;
      //   101: iconst_1
      //   102: invokespecial <init> : (Lvj/d;I)V
      //   105: astore_1
      //   106: aload_1
      //   107: invokevirtual initCancellability : ()V
      //   110: aload_1
      //   111: new a4/f$a$c
      //   114: dup
      //   115: aload_3
      //   116: getstatic kotlinx/coroutines/GlobalScope.INSTANCE : Lkotlinx/coroutines/GlobalScope;
      //   119: aload #6
      //   121: aconst_null
      //   122: new a4/f$a$d
      //   125: dup
      //   126: aload #4
      //   128: aload_1
      //   129: aconst_null
      //   130: invokespecial <init> : (Ljava/util/concurrent/Callable;Lkotlinx/coroutines/CancellableContinuation;Lvj/d;)V
      //   133: iconst_2
      //   134: aconst_null
      //   135: invokestatic launch$default : (Lkotlinx/coroutines/CoroutineScope;Lvj/g;Lkotlinx/coroutines/CoroutineStart;Ldk/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;
      //   138: invokespecial <init> : (Landroid/os/CancellationSignal;Lkotlinx/coroutines/Job;)V
      //   141: invokeinterface invokeOnCancellation : (Ldk/l;)V
      //   146: aload_1
      //   147: invokevirtual getResult : ()Ljava/lang/Object;
      //   150: astore_1
      //   151: aload_1
      //   152: invokestatic d : ()Ljava/lang/Object;
      //   155: if_acmpne -> 163
      //   158: aload #5
      //   160: invokestatic c : (Lvj/d;)V
      //   163: aload_1
      //   164: areturn
    }
    
    public final <R> Object c(w param1w, boolean param1Boolean, Callable<R> param1Callable, vj.d<? super R> param1d) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual z : ()Z
      //   4: ifeq -> 21
      //   7: aload_1
      //   8: invokevirtual t : ()Z
      //   11: ifeq -> 21
      //   14: aload_3
      //   15: invokeinterface call : ()Ljava/lang/Object;
      //   20: areturn
      //   21: aload #4
      //   23: invokeinterface getContext : ()Lvj/g;
      //   28: getstatic a4/e0.u0 : La4/e0$a;
      //   31: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
      //   36: checkcast a4/e0
      //   39: astore #5
      //   41: aload #5
      //   43: ifnull -> 62
      //   46: aload #5
      //   48: invokevirtual d : ()Lvj/e;
      //   51: astore #6
      //   53: aload #6
      //   55: astore #5
      //   57: aload #6
      //   59: ifnonnull -> 82
      //   62: iload_2
      //   63: ifeq -> 74
      //   66: aload_1
      //   67: invokestatic b : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
      //   70: astore_1
      //   71: goto -> 79
      //   74: aload_1
      //   75: invokestatic a : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
      //   78: astore_1
      //   79: aload_1
      //   80: astore #5
      //   82: aload #5
      //   84: new a4/f$a$b
      //   87: dup
      //   88: aload_3
      //   89: aconst_null
      //   90: invokespecial <init> : (Ljava/util/concurrent/Callable;Lvj/d;)V
      //   93: aload #4
      //   95: invokestatic withContext : (Lvj/g;Ldk/p;Lvj/d;)Ljava/lang/Object;
      //   98: areturn
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1", f = "CoroutinesRoom.kt", l = {110}, m = "invokeSuspend")
    static final class a extends l implements p<FlowCollector<R>, vj.d<? super v>, Object> {
      int s0;
      
      a(boolean param2Boolean, w param2w, String[] param2ArrayOfString, Callable<R> param2Callable, vj.d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final vj.d<v> create(Object param2Object, vj.d<?> param2d) {
        a a1 = new a(this.u0, this.v0, this.w0, this.x0, (vj.d)param2d);
        a1.t0 = param2Object;
        return (vj.d<v>)a1;
      }
      
      public final Object invoke(FlowCollector<R> param2FlowCollector, vj.d<? super v> param2d) {
        return ((a)create(param2FlowCollector, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = wj.b.d();
        int i = this.s0;
        if (i != 0) {
          if (i == 1) {
            n.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          n.b(param2Object);
          param2Object = this.t0;
          param2Object = new a(this.u0, this.v0, (FlowCollector<R>)param2Object, this.w0, this.x0, null);
          this.s0 = 1;
          if (CoroutineScopeKt.coroutineScope((p)param2Object, (vj.d)this) == object)
            return object; 
        } 
        return v.a;
      }
      
      @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1", f = "CoroutinesRoom.kt", l = {136}, m = "invokeSuspend")
      static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
        int s0;
        
        a(boolean param3Boolean, w param3w, FlowCollector<R> param3FlowCollector, String[] param3ArrayOfString, Callable<R> param3Callable, vj.d<? super a> param3d) {
          super(2, param3d);
        }
        
        public final vj.d<v> create(Object param3Object, vj.d<?> param3d) {
          a a1 = new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param3d);
          a1.t0 = param3Object;
          return (vj.d<v>)a1;
        }
        
        public final Object invoke(CoroutineScope param3CoroutineScope, vj.d<? super v> param3d) {
          return ((a)create(param3CoroutineScope, param3d)).invokeSuspend(v.a);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          // Byte code:
          //   0: invokestatic d : ()Ljava/lang/Object;
          //   3: astore #4
          //   5: aload_0
          //   6: getfield s0 : I
          //   9: istore_2
          //   10: iload_2
          //   11: ifeq -> 36
          //   14: iload_2
          //   15: iconst_1
          //   16: if_icmpne -> 26
          //   19: aload_1
          //   20: invokestatic b : (Ljava/lang/Object;)V
          //   23: goto -> 211
          //   26: new java/lang/IllegalStateException
          //   29: dup
          //   30: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   32: invokespecial <init> : (Ljava/lang/String;)V
          //   35: athrow
          //   36: aload_1
          //   37: invokestatic b : (Ljava/lang/Object;)V
          //   40: aload_0
          //   41: getfield t0 : Ljava/lang/Object;
          //   44: checkcast kotlinx/coroutines/CoroutineScope
          //   47: astore #5
          //   49: iconst_m1
          //   50: aconst_null
          //   51: aconst_null
          //   52: bipush #6
          //   54: aconst_null
          //   55: invokestatic Channel$default : (ILkotlinx/coroutines/channels/BufferOverflow;Ldk/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/Channel;
          //   58: astore #6
          //   60: new a4/f$a$a$a$b
          //   63: dup
          //   64: aload_0
          //   65: getfield x0 : [Ljava/lang/String;
          //   68: aload #6
          //   70: invokespecial <init> : ([Ljava/lang/String;Lkotlinx/coroutines/channels/Channel;)V
          //   73: astore #7
          //   75: aload #6
          //   77: getstatic rj/v.a : Lrj/v;
          //   80: invokeinterface trySend-JP2dKIU : (Ljava/lang/Object;)Ljava/lang/Object;
          //   85: pop
          //   86: aload #5
          //   88: invokeinterface getCoroutineContext : ()Lvj/g;
          //   93: getstatic a4/e0.u0 : La4/e0$a;
          //   96: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
          //   101: checkcast a4/e0
          //   104: astore_1
          //   105: aload_1
          //   106: ifnull -> 120
          //   109: aload_1
          //   110: invokevirtual d : ()Lvj/e;
          //   113: astore_3
          //   114: aload_3
          //   115: astore_1
          //   116: aload_3
          //   117: ifnonnull -> 146
          //   120: aload_0
          //   121: getfield u0 : Z
          //   124: ifeq -> 138
          //   127: aload_0
          //   128: getfield v0 : La4/w;
          //   131: invokestatic b : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
          //   134: astore_1
          //   135: goto -> 146
          //   138: aload_0
          //   139: getfield v0 : La4/w;
          //   142: invokestatic a : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
          //   145: astore_1
          //   146: iconst_0
          //   147: aconst_null
          //   148: aconst_null
          //   149: bipush #7
          //   151: aconst_null
          //   152: invokestatic Channel$default : (ILkotlinx/coroutines/channels/BufferOverflow;Ldk/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/Channel;
          //   155: astore_3
          //   156: aload #5
          //   158: aload_1
          //   159: aconst_null
          //   160: new a4/f$a$a$a$a
          //   163: dup
          //   164: aload_0
          //   165: getfield v0 : La4/w;
          //   168: aload #7
          //   170: aload #6
          //   172: aload_0
          //   173: getfield y0 : Ljava/util/concurrent/Callable;
          //   176: aload_3
          //   177: aconst_null
          //   178: invokespecial <init> : (La4/w;La4/f$a$a$a$b;Lkotlinx/coroutines/channels/Channel;Ljava/util/concurrent/Callable;Lkotlinx/coroutines/channels/Channel;Lvj/d;)V
          //   181: iconst_2
          //   182: aconst_null
          //   183: invokestatic launch$default : (Lkotlinx/coroutines/CoroutineScope;Lvj/g;Lkotlinx/coroutines/CoroutineStart;Ldk/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;
          //   186: pop
          //   187: aload_0
          //   188: getfield w0 : Lkotlinx/coroutines/flow/FlowCollector;
          //   191: astore_1
          //   192: aload_0
          //   193: iconst_1
          //   194: putfield s0 : I
          //   197: aload_1
          //   198: aload_3
          //   199: aload_0
          //   200: invokestatic emitAll : (Lkotlinx/coroutines/flow/FlowCollector;Lkotlinx/coroutines/channels/ReceiveChannel;Lvj/d;)Ljava/lang/Object;
          //   203: aload #4
          //   205: if_acmpne -> 211
          //   208: aload #4
          //   210: areturn
          //   211: getstatic rj/v.a : Lrj/v;
          //   214: areturn
        }
        
        @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {127, 129}, m = "invokeSuspend")
        static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
          Object s0;
          
          int t0;
          
          a(w param4w, f.a.a.a.b param4b, Channel<v> param4Channel, Callable<R> param4Callable, Channel<R> param4Channel1, vj.d<? super a> param4d) {
            super(2, param4d);
          }
          
          public final vj.d<v> create(Object param4Object, vj.d<?> param4d) {
            return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param4d);
          }
          
          public final Object invoke(CoroutineScope param4CoroutineScope, vj.d<? super v> param4d) {
            return ((a)create(param4CoroutineScope, param4d)).invokeSuspend(v.a);
          }
          
          public final Object invokeSuspend(Object param4Object) {
            a a1;
            Object object = wj.b.d();
            int i = this.t0;
            if (i != 0) {
              if (i != 1) {
                if (i == 2) {
                  ChannelIterator channelIterator = (ChannelIterator)this.s0;
                } else {
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                } 
              } else {
                ChannelIterator channelIterator = (ChannelIterator)this.s0;
                n.b(param4Object);
                a1 = this;
                Object object1 = param4Object;
                param4Object = a1;
              } 
            } else {
              n.b(param4Object);
              this.u0.m().c(this.v0);
              ChannelIterator channelIterator = this.w0.iterator();
              a1 = this;
            } 
            ((a)param4Object).u0.m().n(((a)param4Object).v0);
            throw a1;
          }
        }
        
        public static final class b extends q.c {
          b(String[] param4ArrayOfString, Channel<v> param4Channel) {
            super(param4ArrayOfString);
          }
          
          public void c(Set<String> param4Set) {
            q.j(param4Set, "tables");
            this.b.trySend-JP2dKIU(v.a);
          }
        }
      }
      
      @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {127, 129}, m = "invokeSuspend")
      static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
        Object s0;
        
        int t0;
        
        a(w param3w, f.a.a.a.b param3b, Channel<v> param3Channel, Callable<R> param3Callable, Channel<R> param3Channel1, vj.d<? super a> param3d) {
          super(2, param3d);
        }
        
        public final vj.d<v> create(Object param3Object, vj.d<?> param3d) {
          return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param3d);
        }
        
        public final Object invoke(CoroutineScope param3CoroutineScope, vj.d<? super v> param3d) {
          return ((a)create(param3CoroutineScope, param3d)).invokeSuspend(v.a);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          a a1;
          Object object = wj.b.d();
          int i = this.t0;
          if (i != 0) {
            if (i != 1) {
              if (i == 2) {
                ChannelIterator channelIterator = (ChannelIterator)this.s0;
              } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
              } 
            } else {
              ChannelIterator channelIterator = (ChannelIterator)this.s0;
              n.b(param3Object);
              a1 = this;
              Object object1 = param3Object;
              param3Object = a1;
            } 
          } else {
            n.b(param3Object);
            this.u0.m().c(this.v0);
            ChannelIterator channelIterator = this.w0.iterator();
            a1 = this;
          } 
          ((a)param3Object).u0.m().n(((a)param3Object).v0);
          throw a1;
        }
      }
      
      public static final class b extends q.c {
        b(String[] param3ArrayOfString, Channel<v> param3Channel) {
          super(param3ArrayOfString);
        }
        
        public void c(Set<String> param3Set) {
          q.j(param3Set, "tables");
          this.b.trySend-JP2dKIU(v.a);
        }
      }
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1", f = "CoroutinesRoom.kt", l = {136}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
      int s0;
      
      a(boolean param2Boolean, w param2w, FlowCollector<R> param2FlowCollector, String[] param2ArrayOfString, Callable<R> param2Callable, vj.d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final vj.d<v> create(Object param2Object, vj.d<?> param2d) {
        a a1 = new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param2d);
        a1.t0 = param2Object;
        return (vj.d<v>)a1;
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, vj.d<? super v> param2d) {
        return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        // Byte code:
        //   0: invokestatic d : ()Ljava/lang/Object;
        //   3: astore #4
        //   5: aload_0
        //   6: getfield s0 : I
        //   9: istore_2
        //   10: iload_2
        //   11: ifeq -> 36
        //   14: iload_2
        //   15: iconst_1
        //   16: if_icmpne -> 26
        //   19: aload_1
        //   20: invokestatic b : (Ljava/lang/Object;)V
        //   23: goto -> 211
        //   26: new java/lang/IllegalStateException
        //   29: dup
        //   30: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   32: invokespecial <init> : (Ljava/lang/String;)V
        //   35: athrow
        //   36: aload_1
        //   37: invokestatic b : (Ljava/lang/Object;)V
        //   40: aload_0
        //   41: getfield t0 : Ljava/lang/Object;
        //   44: checkcast kotlinx/coroutines/CoroutineScope
        //   47: astore #5
        //   49: iconst_m1
        //   50: aconst_null
        //   51: aconst_null
        //   52: bipush #6
        //   54: aconst_null
        //   55: invokestatic Channel$default : (ILkotlinx/coroutines/channels/BufferOverflow;Ldk/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/Channel;
        //   58: astore #6
        //   60: new a4/f$a$a$a$b
        //   63: dup
        //   64: aload_0
        //   65: getfield x0 : [Ljava/lang/String;
        //   68: aload #6
        //   70: invokespecial <init> : ([Ljava/lang/String;Lkotlinx/coroutines/channels/Channel;)V
        //   73: astore #7
        //   75: aload #6
        //   77: getstatic rj/v.a : Lrj/v;
        //   80: invokeinterface trySend-JP2dKIU : (Ljava/lang/Object;)Ljava/lang/Object;
        //   85: pop
        //   86: aload #5
        //   88: invokeinterface getCoroutineContext : ()Lvj/g;
        //   93: getstatic a4/e0.u0 : La4/e0$a;
        //   96: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
        //   101: checkcast a4/e0
        //   104: astore_1
        //   105: aload_1
        //   106: ifnull -> 120
        //   109: aload_1
        //   110: invokevirtual d : ()Lvj/e;
        //   113: astore_3
        //   114: aload_3
        //   115: astore_1
        //   116: aload_3
        //   117: ifnonnull -> 146
        //   120: aload_0
        //   121: getfield u0 : Z
        //   124: ifeq -> 138
        //   127: aload_0
        //   128: getfield v0 : La4/w;
        //   131: invokestatic b : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
        //   134: astore_1
        //   135: goto -> 146
        //   138: aload_0
        //   139: getfield v0 : La4/w;
        //   142: invokestatic a : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
        //   145: astore_1
        //   146: iconst_0
        //   147: aconst_null
        //   148: aconst_null
        //   149: bipush #7
        //   151: aconst_null
        //   152: invokestatic Channel$default : (ILkotlinx/coroutines/channels/BufferOverflow;Ldk/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/Channel;
        //   155: astore_3
        //   156: aload #5
        //   158: aload_1
        //   159: aconst_null
        //   160: new a4/f$a$a$a$a
        //   163: dup
        //   164: aload_0
        //   165: getfield v0 : La4/w;
        //   168: aload #7
        //   170: aload #6
        //   172: aload_0
        //   173: getfield y0 : Ljava/util/concurrent/Callable;
        //   176: aload_3
        //   177: aconst_null
        //   178: invokespecial <init> : (La4/w;La4/f$a$a$a$b;Lkotlinx/coroutines/channels/Channel;Ljava/util/concurrent/Callable;Lkotlinx/coroutines/channels/Channel;Lvj/d;)V
        //   181: iconst_2
        //   182: aconst_null
        //   183: invokestatic launch$default : (Lkotlinx/coroutines/CoroutineScope;Lvj/g;Lkotlinx/coroutines/CoroutineStart;Ldk/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;
        //   186: pop
        //   187: aload_0
        //   188: getfield w0 : Lkotlinx/coroutines/flow/FlowCollector;
        //   191: astore_1
        //   192: aload_0
        //   193: iconst_1
        //   194: putfield s0 : I
        //   197: aload_1
        //   198: aload_3
        //   199: aload_0
        //   200: invokestatic emitAll : (Lkotlinx/coroutines/flow/FlowCollector;Lkotlinx/coroutines/channels/ReceiveChannel;Lvj/d;)Ljava/lang/Object;
        //   203: aload #4
        //   205: if_acmpne -> 211
        //   208: aload #4
        //   210: areturn
        //   211: getstatic rj/v.a : Lrj/v;
        //   214: areturn
      }
      
      @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {127, 129}, m = "invokeSuspend")
      static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
        Object s0;
        
        int t0;
        
        a(w param4w, f.a.a.a.b param4b, Channel<v> param4Channel, Callable<R> param4Callable, Channel<R> param4Channel1, vj.d<? super a> param4d) {
          super(2, param4d);
        }
        
        public final vj.d<v> create(Object param4Object, vj.d<?> param4d) {
          return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param4d);
        }
        
        public final Object invoke(CoroutineScope param4CoroutineScope, vj.d<? super v> param4d) {
          return ((a)create(param4CoroutineScope, param4d)).invokeSuspend(v.a);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          a a1;
          Object object = wj.b.d();
          int i = this.t0;
          if (i != 0) {
            if (i != 1) {
              if (i == 2) {
                ChannelIterator channelIterator = (ChannelIterator)this.s0;
              } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
              } 
            } else {
              ChannelIterator channelIterator = (ChannelIterator)this.s0;
              n.b(param4Object);
              a1 = this;
              Object object1 = param4Object;
              param4Object = a1;
            } 
          } else {
            n.b(param4Object);
            this.u0.m().c(this.v0);
            ChannelIterator channelIterator = this.w0.iterator();
            a1 = this;
          } 
          ((a)param4Object).u0.m().n(((a)param4Object).v0);
          throw a1;
        }
      }
      
      public static final class b extends q.c {
        b(String[] param4ArrayOfString, Channel<v> param4Channel) {
          super(param4ArrayOfString);
        }
        
        public void c(Set<String> param4Set) {
          q.j(param4Set, "tables");
          this.b.trySend-JP2dKIU(v.a);
        }
      }
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {127, 129}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
      Object s0;
      
      int t0;
      
      a(w param2w, f.a.a.a.b param2b, Channel<v> param2Channel, Callable<R> param2Callable, Channel<R> param2Channel1, vj.d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final vj.d<v> create(Object param2Object, vj.d<?> param2d) {
        return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, vj.d<? super v> param2d) {
        return ((a)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        a a1;
        Object object = wj.b.d();
        int i = this.t0;
        if (i != 0) {
          if (i != 1) {
            if (i == 2) {
              ChannelIterator channelIterator = (ChannelIterator)this.s0;
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            ChannelIterator channelIterator = (ChannelIterator)this.s0;
            n.b(param2Object);
            a1 = this;
            Object object1 = param2Object;
            param2Object = a1;
          } 
        } else {
          n.b(param2Object);
          this.u0.m().c(this.v0);
          ChannelIterator channelIterator = this.w0.iterator();
          a1 = this;
        } 
        ((a)param2Object).u0.m().n(((a)param2Object).v0);
        throw a1;
      }
    }
    
    public static final class b extends q.c {
      b(String[] param2ArrayOfString, Channel<v> param2Channel) {
        super(param2ArrayOfString);
      }
      
      public void c(Set<String> param2Set) {
        q.j(param2Set, "tables");
        this.b.trySend-JP2dKIU(v.a);
      }
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$execute$2", f = "CoroutinesRoom.kt", l = {}, m = "invokeSuspend")
    static final class b extends l implements p<CoroutineScope, vj.d<? super R>, Object> {
      int s0;
      
      b(Callable<R> param2Callable, vj.d<? super b> param2d) {
        super(2, param2d);
      }
      
      public final vj.d<v> create(Object param2Object, vj.d<?> param2d) {
        return (vj.d<v>)new b(this.t0, (vj.d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, vj.d<? super R> param2d) {
        return ((b)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        wj.b.d();
        if (this.s0 == 0) {
          n.b(param2Object);
          return this.t0.call();
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }
    }
    
    static final class c extends r implements l<Throwable, v> {
      c(CancellationSignal param2CancellationSignal, Job param2Job) {
        super(1);
      }
      
      public final void invoke(Throwable param2Throwable) {
        e4.b.a(this.s0);
        Job.DefaultImpls.cancel$default(this.t0, null, 1, null);
      }
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$execute$4$job$1", f = "CoroutinesRoom.kt", l = {}, m = "invokeSuspend")
    static final class d extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
      int s0;
      
      d(Callable<R> param2Callable, CancellableContinuation<? super R> param2CancellableContinuation, vj.d<? super d> param2d) {
        super(2, param2d);
      }
      
      public final vj.d<v> create(Object param2Object, vj.d<?> param2d) {
        return (vj.d<v>)new d(this.t0, this.u0, (vj.d)param2d);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, vj.d<? super v> param2d) {
        return ((d)create(param2CoroutineScope, param2d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        wj.b.d();
        if (this.s0 == 0) {
          n.b(param2Object);
          try {
            param2Object = this.t0.call();
            this.u0.resumeWith(m.b(param2Object));
          } finally {
            param2Object = null;
            CancellableContinuation<R> cancellableContinuation = this.u0;
            m.a a = m.t0;
          } 
          return v.a;
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1", f = "CoroutinesRoom.kt", l = {110}, m = "invokeSuspend")
  static final class a extends l implements p<FlowCollector<R>, vj.d<? super v>, Object> {
    int s0;
    
    a(boolean param1Boolean, w param1w, String[] param1ArrayOfString, Callable<R> param1Callable, vj.d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      a a1 = new a(this.u0, this.v0, this.w0, this.x0, (vj.d)param1d);
      a1.t0 = param1Object;
      return (vj.d<v>)a1;
    }
    
    public final Object invoke(FlowCollector<R> param1FlowCollector, vj.d<? super v> param1d) {
      return ((a)create(param1FlowCollector, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = wj.b.d();
      int i = this.s0;
      if (i != 0) {
        if (i == 1) {
          n.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        n.b(param1Object);
        param1Object = this.t0;
        param1Object = new a(this.u0, this.v0, (FlowCollector<R>)param1Object, this.w0, this.x0, null);
        this.s0 = 1;
        if (CoroutineScopeKt.coroutineScope((p)param1Object, (vj.d)this) == object)
          return object; 
      } 
      return v.a;
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1", f = "CoroutinesRoom.kt", l = {136}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
      int s0;
      
      a(boolean param3Boolean, w param3w, FlowCollector<R> param3FlowCollector, String[] param3ArrayOfString, Callable<R> param3Callable, vj.d<? super a> param3d) {
        super(2, param3d);
      }
      
      public final vj.d<v> create(Object param3Object, vj.d<?> param3d) {
        a a1 = new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param3d);
        a1.t0 = param3Object;
        return (vj.d<v>)a1;
      }
      
      public final Object invoke(CoroutineScope param3CoroutineScope, vj.d<? super v> param3d) {
        return ((a)create(param3CoroutineScope, param3d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        // Byte code:
        //   0: invokestatic d : ()Ljava/lang/Object;
        //   3: astore #4
        //   5: aload_0
        //   6: getfield s0 : I
        //   9: istore_2
        //   10: iload_2
        //   11: ifeq -> 36
        //   14: iload_2
        //   15: iconst_1
        //   16: if_icmpne -> 26
        //   19: aload_1
        //   20: invokestatic b : (Ljava/lang/Object;)V
        //   23: goto -> 211
        //   26: new java/lang/IllegalStateException
        //   29: dup
        //   30: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   32: invokespecial <init> : (Ljava/lang/String;)V
        //   35: athrow
        //   36: aload_1
        //   37: invokestatic b : (Ljava/lang/Object;)V
        //   40: aload_0
        //   41: getfield t0 : Ljava/lang/Object;
        //   44: checkcast kotlinx/coroutines/CoroutineScope
        //   47: astore #5
        //   49: iconst_m1
        //   50: aconst_null
        //   51: aconst_null
        //   52: bipush #6
        //   54: aconst_null
        //   55: invokestatic Channel$default : (ILkotlinx/coroutines/channels/BufferOverflow;Ldk/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/Channel;
        //   58: astore #6
        //   60: new a4/f$a$a$a$b
        //   63: dup
        //   64: aload_0
        //   65: getfield x0 : [Ljava/lang/String;
        //   68: aload #6
        //   70: invokespecial <init> : ([Ljava/lang/String;Lkotlinx/coroutines/channels/Channel;)V
        //   73: astore #7
        //   75: aload #6
        //   77: getstatic rj/v.a : Lrj/v;
        //   80: invokeinterface trySend-JP2dKIU : (Ljava/lang/Object;)Ljava/lang/Object;
        //   85: pop
        //   86: aload #5
        //   88: invokeinterface getCoroutineContext : ()Lvj/g;
        //   93: getstatic a4/e0.u0 : La4/e0$a;
        //   96: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
        //   101: checkcast a4/e0
        //   104: astore_1
        //   105: aload_1
        //   106: ifnull -> 120
        //   109: aload_1
        //   110: invokevirtual d : ()Lvj/e;
        //   113: astore_3
        //   114: aload_3
        //   115: astore_1
        //   116: aload_3
        //   117: ifnonnull -> 146
        //   120: aload_0
        //   121: getfield u0 : Z
        //   124: ifeq -> 138
        //   127: aload_0
        //   128: getfield v0 : La4/w;
        //   131: invokestatic b : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
        //   134: astore_1
        //   135: goto -> 146
        //   138: aload_0
        //   139: getfield v0 : La4/w;
        //   142: invokestatic a : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
        //   145: astore_1
        //   146: iconst_0
        //   147: aconst_null
        //   148: aconst_null
        //   149: bipush #7
        //   151: aconst_null
        //   152: invokestatic Channel$default : (ILkotlinx/coroutines/channels/BufferOverflow;Ldk/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/Channel;
        //   155: astore_3
        //   156: aload #5
        //   158: aload_1
        //   159: aconst_null
        //   160: new a4/f$a$a$a$a
        //   163: dup
        //   164: aload_0
        //   165: getfield v0 : La4/w;
        //   168: aload #7
        //   170: aload #6
        //   172: aload_0
        //   173: getfield y0 : Ljava/util/concurrent/Callable;
        //   176: aload_3
        //   177: aconst_null
        //   178: invokespecial <init> : (La4/w;La4/f$a$a$a$b;Lkotlinx/coroutines/channels/Channel;Ljava/util/concurrent/Callable;Lkotlinx/coroutines/channels/Channel;Lvj/d;)V
        //   181: iconst_2
        //   182: aconst_null
        //   183: invokestatic launch$default : (Lkotlinx/coroutines/CoroutineScope;Lvj/g;Lkotlinx/coroutines/CoroutineStart;Ldk/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;
        //   186: pop
        //   187: aload_0
        //   188: getfield w0 : Lkotlinx/coroutines/flow/FlowCollector;
        //   191: astore_1
        //   192: aload_0
        //   193: iconst_1
        //   194: putfield s0 : I
        //   197: aload_1
        //   198: aload_3
        //   199: aload_0
        //   200: invokestatic emitAll : (Lkotlinx/coroutines/flow/FlowCollector;Lkotlinx/coroutines/channels/ReceiveChannel;Lvj/d;)Ljava/lang/Object;
        //   203: aload #4
        //   205: if_acmpne -> 211
        //   208: aload #4
        //   210: areturn
        //   211: getstatic rj/v.a : Lrj/v;
        //   214: areturn
      }
      
      @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {127, 129}, m = "invokeSuspend")
      static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
        Object s0;
        
        int t0;
        
        a(w param4w, f.a.a.a.b param4b, Channel<v> param4Channel, Callable<R> param4Callable, Channel<R> param4Channel1, vj.d<? super a> param4d) {
          super(2, param4d);
        }
        
        public final vj.d<v> create(Object param4Object, vj.d<?> param4d) {
          return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param4d);
        }
        
        public final Object invoke(CoroutineScope param4CoroutineScope, vj.d<? super v> param4d) {
          return ((a)create(param4CoroutineScope, param4d)).invokeSuspend(v.a);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          a a1;
          Object object = wj.b.d();
          int i = this.t0;
          if (i != 0) {
            if (i != 1) {
              if (i == 2) {
                ChannelIterator channelIterator = (ChannelIterator)this.s0;
              } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
              } 
            } else {
              ChannelIterator channelIterator = (ChannelIterator)this.s0;
              n.b(param4Object);
              a1 = this;
              Object object1 = param4Object;
              param4Object = a1;
            } 
          } else {
            n.b(param4Object);
            this.u0.m().c(this.v0);
            ChannelIterator channelIterator = this.w0.iterator();
            a1 = this;
          } 
          ((a)param4Object).u0.m().n(((a)param4Object).v0);
          throw a1;
        }
      }
      
      public static final class b extends q.c {
        b(String[] param4ArrayOfString, Channel<v> param4Channel) {
          super(param4ArrayOfString);
        }
        
        public void c(Set<String> param4Set) {
          q.j(param4Set, "tables");
          this.b.trySend-JP2dKIU(v.a);
        }
      }
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {127, 129}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
      Object s0;
      
      int t0;
      
      a(w param3w, f.a.a.a.b param3b, Channel<v> param3Channel, Callable<R> param3Callable, Channel<R> param3Channel1, vj.d<? super a> param3d) {
        super(2, param3d);
      }
      
      public final vj.d<v> create(Object param3Object, vj.d<?> param3d) {
        return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param3d);
      }
      
      public final Object invoke(CoroutineScope param3CoroutineScope, vj.d<? super v> param3d) {
        return ((a)create(param3CoroutineScope, param3d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        a a1;
        Object object = wj.b.d();
        int i = this.t0;
        if (i != 0) {
          if (i != 1) {
            if (i == 2) {
              ChannelIterator channelIterator = (ChannelIterator)this.s0;
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            ChannelIterator channelIterator = (ChannelIterator)this.s0;
            n.b(param3Object);
            a1 = this;
            Object object1 = param3Object;
            param3Object = a1;
          } 
        } else {
          n.b(param3Object);
          this.u0.m().c(this.v0);
          ChannelIterator channelIterator = this.w0.iterator();
          a1 = this;
        } 
        ((a)param3Object).u0.m().n(((a)param3Object).v0);
        throw a1;
      }
    }
    
    public static final class b extends q.c {
      b(String[] param3ArrayOfString, Channel<v> param3Channel) {
        super(param3ArrayOfString);
      }
      
      public void c(Set<String> param3Set) {
        q.j(param3Set, "tables");
        this.b.trySend-JP2dKIU(v.a);
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1", f = "CoroutinesRoom.kt", l = {136}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
    int s0;
    
    a(boolean param1Boolean, w param1w, FlowCollector<R> param1FlowCollector, String[] param1ArrayOfString, Callable<R> param1Callable, vj.d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      a a1 = new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param1d);
      a1.t0 = param1Object;
      return (vj.d<v>)a1;
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, vj.d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      // Byte code:
      //   0: invokestatic d : ()Ljava/lang/Object;
      //   3: astore #4
      //   5: aload_0
      //   6: getfield s0 : I
      //   9: istore_2
      //   10: iload_2
      //   11: ifeq -> 36
      //   14: iload_2
      //   15: iconst_1
      //   16: if_icmpne -> 26
      //   19: aload_1
      //   20: invokestatic b : (Ljava/lang/Object;)V
      //   23: goto -> 211
      //   26: new java/lang/IllegalStateException
      //   29: dup
      //   30: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   32: invokespecial <init> : (Ljava/lang/String;)V
      //   35: athrow
      //   36: aload_1
      //   37: invokestatic b : (Ljava/lang/Object;)V
      //   40: aload_0
      //   41: getfield t0 : Ljava/lang/Object;
      //   44: checkcast kotlinx/coroutines/CoroutineScope
      //   47: astore #5
      //   49: iconst_m1
      //   50: aconst_null
      //   51: aconst_null
      //   52: bipush #6
      //   54: aconst_null
      //   55: invokestatic Channel$default : (ILkotlinx/coroutines/channels/BufferOverflow;Ldk/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/Channel;
      //   58: astore #6
      //   60: new a4/f$a$a$a$b
      //   63: dup
      //   64: aload_0
      //   65: getfield x0 : [Ljava/lang/String;
      //   68: aload #6
      //   70: invokespecial <init> : ([Ljava/lang/String;Lkotlinx/coroutines/channels/Channel;)V
      //   73: astore #7
      //   75: aload #6
      //   77: getstatic rj/v.a : Lrj/v;
      //   80: invokeinterface trySend-JP2dKIU : (Ljava/lang/Object;)Ljava/lang/Object;
      //   85: pop
      //   86: aload #5
      //   88: invokeinterface getCoroutineContext : ()Lvj/g;
      //   93: getstatic a4/e0.u0 : La4/e0$a;
      //   96: invokeinterface get : (Lvj/g$c;)Lvj/g$b;
      //   101: checkcast a4/e0
      //   104: astore_1
      //   105: aload_1
      //   106: ifnull -> 120
      //   109: aload_1
      //   110: invokevirtual d : ()Lvj/e;
      //   113: astore_3
      //   114: aload_3
      //   115: astore_1
      //   116: aload_3
      //   117: ifnonnull -> 146
      //   120: aload_0
      //   121: getfield u0 : Z
      //   124: ifeq -> 138
      //   127: aload_0
      //   128: getfield v0 : La4/w;
      //   131: invokestatic b : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
      //   134: astore_1
      //   135: goto -> 146
      //   138: aload_0
      //   139: getfield v0 : La4/w;
      //   142: invokestatic a : (La4/w;)Lkotlinx/coroutines/CoroutineDispatcher;
      //   145: astore_1
      //   146: iconst_0
      //   147: aconst_null
      //   148: aconst_null
      //   149: bipush #7
      //   151: aconst_null
      //   152: invokestatic Channel$default : (ILkotlinx/coroutines/channels/BufferOverflow;Ldk/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/Channel;
      //   155: astore_3
      //   156: aload #5
      //   158: aload_1
      //   159: aconst_null
      //   160: new a4/f$a$a$a$a
      //   163: dup
      //   164: aload_0
      //   165: getfield v0 : La4/w;
      //   168: aload #7
      //   170: aload #6
      //   172: aload_0
      //   173: getfield y0 : Ljava/util/concurrent/Callable;
      //   176: aload_3
      //   177: aconst_null
      //   178: invokespecial <init> : (La4/w;La4/f$a$a$a$b;Lkotlinx/coroutines/channels/Channel;Ljava/util/concurrent/Callable;Lkotlinx/coroutines/channels/Channel;Lvj/d;)V
      //   181: iconst_2
      //   182: aconst_null
      //   183: invokestatic launch$default : (Lkotlinx/coroutines/CoroutineScope;Lvj/g;Lkotlinx/coroutines/CoroutineStart;Ldk/p;ILjava/lang/Object;)Lkotlinx/coroutines/Job;
      //   186: pop
      //   187: aload_0
      //   188: getfield w0 : Lkotlinx/coroutines/flow/FlowCollector;
      //   191: astore_1
      //   192: aload_0
      //   193: iconst_1
      //   194: putfield s0 : I
      //   197: aload_1
      //   198: aload_3
      //   199: aload_0
      //   200: invokestatic emitAll : (Lkotlinx/coroutines/flow/FlowCollector;Lkotlinx/coroutines/channels/ReceiveChannel;Lvj/d;)Ljava/lang/Object;
      //   203: aload #4
      //   205: if_acmpne -> 211
      //   208: aload #4
      //   210: areturn
      //   211: getstatic rj/v.a : Lrj/v;
      //   214: areturn
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {127, 129}, m = "invokeSuspend")
    static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
      Object s0;
      
      int t0;
      
      a(w param4w, f.a.a.a.b param4b, Channel<v> param4Channel, Callable<R> param4Callable, Channel<R> param4Channel1, vj.d<? super a> param4d) {
        super(2, param4d);
      }
      
      public final vj.d<v> create(Object param4Object, vj.d<?> param4d) {
        return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param4d);
      }
      
      public final Object invoke(CoroutineScope param4CoroutineScope, vj.d<? super v> param4d) {
        return ((a)create(param4CoroutineScope, param4d)).invokeSuspend(v.a);
      }
      
      public final Object invokeSuspend(Object param4Object) {
        a a1;
        Object object = wj.b.d();
        int i = this.t0;
        if (i != 0) {
          if (i != 1) {
            if (i == 2) {
              ChannelIterator channelIterator = (ChannelIterator)this.s0;
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            ChannelIterator channelIterator = (ChannelIterator)this.s0;
            n.b(param4Object);
            a1 = this;
            Object object1 = param4Object;
            param4Object = a1;
          } 
        } else {
          n.b(param4Object);
          this.u0.m().c(this.v0);
          ChannelIterator channelIterator = this.w0.iterator();
          a1 = this;
        } 
        ((a)param4Object).u0.m().n(((a)param4Object).v0);
        throw a1;
      }
    }
    
    public static final class b extends q.c {
      b(String[] param4ArrayOfString, Channel<v> param4Channel) {
        super(param4ArrayOfString);
      }
      
      public void c(Set<String> param4Set) {
        q.j(param4Set, "tables");
        this.b.trySend-JP2dKIU(v.a);
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {127, 129}, m = "invokeSuspend")
  static final class a extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
    Object s0;
    
    int t0;
    
    a(w param1w, f.a.a.a.b param1b, Channel<v> param1Channel, Callable<R> param1Callable, Channel<R> param1Channel1, vj.d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      return (vj.d<v>)new a(this.u0, this.v0, this.w0, this.x0, this.y0, (vj.d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, vj.d<? super v> param1d) {
      return ((a)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      a a1;
      Object object = wj.b.d();
      int i = this.t0;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            ChannelIterator channelIterator = (ChannelIterator)this.s0;
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          ChannelIterator channelIterator = (ChannelIterator)this.s0;
          n.b(param1Object);
          a1 = this;
          Object object1 = param1Object;
          param1Object = a1;
        } 
      } else {
        n.b(param1Object);
        this.u0.m().c(this.v0);
        ChannelIterator channelIterator = this.w0.iterator();
        a1 = this;
      } 
      ((a)param1Object).u0.m().n(((a)param1Object).v0);
      throw a1;
    }
  }
  
  public static final class b extends q.c {
    b(String[] param1ArrayOfString, Channel<v> param1Channel) {
      super(param1ArrayOfString);
    }
    
    public void c(Set<String> param1Set) {
      q.j(param1Set, "tables");
      this.b.trySend-JP2dKIU(v.a);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$execute$2", f = "CoroutinesRoom.kt", l = {}, m = "invokeSuspend")
  static final class b extends l implements p<CoroutineScope, vj.d<? super R>, Object> {
    int s0;
    
    b(Callable<R> param1Callable, vj.d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      return (vj.d<v>)new b(this.t0, (vj.d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, vj.d<? super R> param1d) {
      return ((b)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      wj.b.d();
      if (this.s0 == 0) {
        n.b(param1Object);
        return this.t0.call();
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  static final class c extends r implements l<Throwable, v> {
    c(CancellationSignal param1CancellationSignal, Job param1Job) {
      super(1);
    }
    
    public final void invoke(Throwable param1Throwable) {
      e4.b.a(this.s0);
      Job.DefaultImpls.cancel$default(this.t0, null, 1, null);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.room.CoroutinesRoom$Companion$execute$4$job$1", f = "CoroutinesRoom.kt", l = {}, m = "invokeSuspend")
  static final class d extends l implements p<CoroutineScope, vj.d<? super v>, Object> {
    int s0;
    
    d(Callable<R> param1Callable, CancellableContinuation<? super R> param1CancellableContinuation, vj.d<? super d> param1d) {
      super(2, param1d);
    }
    
    public final vj.d<v> create(Object param1Object, vj.d<?> param1d) {
      return (vj.d<v>)new d(this.t0, this.u0, (vj.d)param1d);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, vj.d<? super v> param1d) {
      return ((d)create(param1CoroutineScope, param1d)).invokeSuspend(v.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      wj.b.d();
      if (this.s0 == 0) {
        n.b(param1Object);
        try {
          param1Object = this.t0.call();
          this.u0.resumeWith(m.b(param1Object));
        } finally {
          param1Object = null;
          CancellableContinuation<R> cancellableContinuation = this.u0;
          m.a a = m.t0;
        } 
        return v.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */