package a4;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import e4.g;
import e4.j;
import e4.k;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import kotlin.collections.k0;
import kotlin.collections.r;
import kotlin.collections.s0;
import kotlin.jvm.internal.h;
import lk.h;
import rj.v;

public class q {
  public static final a q = new a(null);
  
  private static final String[] r = new String[] { "UPDATE", "DELETE", "INSERT" };
  
  private final w a;
  
  private final Map<String, String> b;
  
  private final Map<String, Set<String>> c;
  
  private final Map<String, Integer> d;
  
  private final String[] e;
  
  private c f;
  
  private final AtomicBoolean g;
  
  private volatile boolean h;
  
  private volatile k i;
  
  private final b j;
  
  private final o k;
  
  private final l.b<c, d> l;
  
  private t m;
  
  private final Object n;
  
  private final Object o;
  
  public final Runnable p;
  
  public q(w paramw, Map<String, String> paramMap, Map<String, Set<String>> paramMap1, String... paramVarArgs) {
    this.a = paramw;
    this.b = paramMap;
    this.c = paramMap1;
    int i = 0;
    this.g = new AtomicBoolean(false);
    this.j = new b(paramVarArgs.length);
    this.k = new o(paramw);
    this.l = new l.b();
    this.n = new Object();
    this.o = new Object();
    this.d = new LinkedHashMap<String, Integer>();
    int j = paramVarArgs.length;
    String[] arrayOfString = new String[j];
    while (i < j) {
      String str1;
      String str2 = paramVarArgs[i];
      Locale locale = Locale.US;
      kotlin.jvm.internal.q.i(locale, "US");
      str2 = str2.toLowerCase(locale);
      kotlin.jvm.internal.q.i(str2, "this as java.lang.String).toLowerCase(locale)");
      this.d.put(str2, Integer.valueOf(i));
      String str3 = this.b.get(paramVarArgs[i]);
      if (str3 != null) {
        kotlin.jvm.internal.q.i(locale, "US");
        str1 = str3.toLowerCase(locale);
        kotlin.jvm.internal.q.i(str1, "this as java.lang.String).toLowerCase(locale)");
      } else {
        locale = null;
      } 
      if (locale == null)
        str1 = str2; 
      arrayOfString[i] = str1;
      i++;
    } 
    this.e = arrayOfString;
    for (Map.Entry<String, String> entry : this.b.entrySet()) {
      String str = (String)entry.getValue();
      Locale locale = Locale.US;
      kotlin.jvm.internal.q.i(locale, "US");
      str = str.toLowerCase(locale);
      kotlin.jvm.internal.q.i(str, "this as java.lang.String).toLowerCase(locale)");
      if (this.d.containsKey(str)) {
        String str2 = (String)entry.getKey();
        kotlin.jvm.internal.q.i(locale, "US");
        String str1 = str2.toLowerCase(locale);
        kotlin.jvm.internal.q.i(str1, "this as java.lang.String).toLowerCase(locale)");
        Map<String, Integer> map = this.d;
        map.put(str1, k0.h(map, str));
      } 
    } 
    this.p = new e(this);
  }
  
  private final void l() {
    synchronized (this.o) {
      this.h = false;
      this.j.d();
      k k1 = this.i;
      if (k1 != null) {
        k1.close();
        v v = v.a;
      } 
      return;
    } 
  }
  
  private final String[] o(String[] paramArrayOfString) {
    Set<String> set = s0.b();
    int j = paramArrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str1 = paramArrayOfString[i];
      Map<String, Set<String>> map = this.c;
      Locale locale = Locale.US;
      kotlin.jvm.internal.q.i(locale, "US");
      String str2 = str1.toLowerCase(locale);
      kotlin.jvm.internal.q.i(str2, "this as java.lang.String).toLowerCase(locale)");
      if (map.containsKey(str2)) {
        map = this.c;
        kotlin.jvm.internal.q.i(locale, "US");
        str1 = str1.toLowerCase(locale);
        kotlin.jvm.internal.q.i(str1, "this as java.lang.String).toLowerCase(locale)");
        str1 = (String)map.get(str1);
        kotlin.jvm.internal.q.g(str1);
        set.addAll((Collection)str1);
      } else {
        set.add(str1);
      } 
    } 
    paramArrayOfString = s0.a(set).toArray((Object[])new String[0]);
    kotlin.jvm.internal.q.h(paramArrayOfString, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
    return paramArrayOfString;
  }
  
  private final void r(g paramg, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("INSERT OR IGNORE INTO room_table_modification_log VALUES(");
    stringBuilder.append(paramInt);
    stringBuilder.append(", 0)");
    paramg.l(stringBuilder.toString());
    String str = this.e[paramInt];
    for (String str1 : r) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("CREATE TEMP TRIGGER IF NOT EXISTS ");
      stringBuilder1.append(q.b(str, str1));
      stringBuilder1.append(" AFTER ");
      stringBuilder1.append(str1);
      stringBuilder1.append(" ON `");
      stringBuilder1.append(str);
      stringBuilder1.append("` BEGIN UPDATE ");
      stringBuilder1.append("room_table_modification_log");
      stringBuilder1.append(" SET ");
      stringBuilder1.append("invalidated");
      stringBuilder1.append(" = 1");
      stringBuilder1.append(" WHERE ");
      stringBuilder1.append("table_id");
      stringBuilder1.append(" = ");
      stringBuilder1.append(paramInt);
      stringBuilder1.append(" AND ");
      stringBuilder1.append("invalidated");
      stringBuilder1.append(" = 0");
      stringBuilder1.append("; END");
      str1 = stringBuilder1.toString();
      kotlin.jvm.internal.q.i(str1, "StringBuilder().apply(builderAction).toString()");
      paramg.l(str1);
    } 
  }
  
  private final void s(g paramg, int paramInt) {
    String str = this.e[paramInt];
    String[] arrayOfString = r;
    int i = arrayOfString.length;
    for (paramInt = 0; paramInt < i; paramInt++) {
      String str1 = arrayOfString[paramInt];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("DROP TRIGGER IF EXISTS ");
      stringBuilder.append(q.b(str, str1));
      str1 = stringBuilder.toString();
      kotlin.jvm.internal.q.i(str1, "StringBuilder().apply(builderAction).toString()");
      paramg.l(str1);
    } 
  }
  
  @SuppressLint({"RestrictedApi"})
  public void c(c paramc) {
    kotlin.jvm.internal.q.j(paramc, "observer");
    String[] arrayOfString = o(paramc.a());
    ArrayList<Integer> arrayList = new ArrayList(arrayOfString.length);
    int j = arrayOfString.length;
    int i = 0;
    while (i < j) {
      String str1 = arrayOfString[i];
      Map<String, Integer> map = this.d;
      Locale locale = Locale.US;
      kotlin.jvm.internal.q.i(locale, "US");
      String str2 = str1.toLowerCase(locale);
      kotlin.jvm.internal.q.i(str2, "this as java.lang.String).toLowerCase(locale)");
      Integer integer = map.get(str2);
      if (integer != null) {
        arrayList.add(Integer.valueOf(integer.intValue()));
        i++;
        continue;
      } 
      null = new StringBuilder();
      null.append("There is no table with name ");
      null.append(str1);
      throw new IllegalArgumentException(null.toString());
    } 
    int[] arrayOfInt = r.H0(arrayList);
    d d = new d((c)null, arrayOfInt, arrayOfString);
    synchronized (this.l) {
      d d1 = (d)this.l.j(null, d);
      if (d1 == null && this.j.b(Arrays.copyOf(arrayOfInt, arrayOfInt.length)))
        t(); 
      return;
    } 
  }
  
  public final boolean d() {
    if (!this.a.z())
      return false; 
    if (!this.h)
      this.a.n().o0(); 
    if (!this.h) {
      Log.e("ROOM", "database is not initialized even though it is open");
      return false;
    } 
    return true;
  }
  
  public final k e() {
    return this.i;
  }
  
  public final w f() {
    return this.a;
  }
  
  public final l.b<c, d> g() {
    return this.l;
  }
  
  public final AtomicBoolean h() {
    return this.g;
  }
  
  public final Map<String, Integer> i() {
    return this.d;
  }
  
  public final void j(g paramg) {
    kotlin.jvm.internal.q.j(paramg, "database");
    synchronized (this.o) {
      if (this.h) {
        Log.e("ROOM", "Invalidation tracker is initialized twice :/.");
        return;
      } 
      paramg.l("PRAGMA temp_store = MEMORY;");
      paramg.l("PRAGMA recursive_triggers='ON';");
      paramg.l("CREATE TEMP TABLE room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)");
      u(paramg);
      this.i = paramg.c0("UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1");
      this.h = true;
      v v = v.a;
      return;
    } 
  }
  
  public final void k(String... paramVarArgs) {
    kotlin.jvm.internal.q.j(paramVarArgs, "tables");
    synchronized (this.l) {
      for (Map.Entry entry : this.l) {
        kotlin.jvm.internal.q.i(entry, "(observer, wrapper)");
        c c1 = (c)entry.getKey();
        d d = (d)entry.getValue();
        if (!c1.b())
          d.c(paramVarArgs); 
      } 
      v v = v.a;
      return;
    } 
  }
  
  public void m() {
    if (this.g.compareAndSet(false, true)) {
      c c1 = this.f;
      if (c1 != null)
        c1.j(); 
      this.a.o().execute(this.p);
    } 
  }
  
  @SuppressLint({"RestrictedApi"})
  public void n(c paramc) {
    l.b<c, d> b2;
    b b1;
    kotlin.jvm.internal.q.j(paramc, "observer");
    synchronized (this.l) {
      d d = (d)this.l.k(paramc);
      if (d != null) {
        b1 = this.j;
        int[] arrayOfInt = d.a();
        if (b1.c(Arrays.copyOf(arrayOfInt, arrayOfInt.length)))
          t(); 
      } 
      return;
    } 
  }
  
  public final void p(c paramc) {
    kotlin.jvm.internal.q.j(paramc, "autoCloser");
    this.f = paramc;
    paramc.l(new p(this));
  }
  
  public final void q(Context paramContext, String paramString, Intent paramIntent) {
    kotlin.jvm.internal.q.j(paramContext, "context");
    kotlin.jvm.internal.q.j(paramString, "name");
    kotlin.jvm.internal.q.j(paramIntent, "serviceIntent");
    this.m = new t(paramContext, paramString, paramIntent, this, this.a.o());
  }
  
  public final void t() {
    if (!this.a.z())
      return; 
    u(this.a.n().o0());
  }
  
  public final void u(g paramg) {
    int i;
    int j;
    int m;
    Lock lock;
    kotlin.jvm.internal.q.j(paramg, "database");
    if (paramg.z0())
      return; 
    try {
      lock = this.a.l();
      lock.lock();
      try {
      
      } finally {
        lock.unlock();
      } 
    } catch (IllegalStateException illegalStateException) {
      Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", illegalStateException);
      return;
    } catch (SQLiteException sQLiteException) {
      Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", (Throwable)sQLiteException);
      return;
    } 
    while (true) {
      if (i < m) {
        Object object = SYNTHETIC_LOCAL_VARIABLE_8[i];
        if (object != true) {
          if (object == 2)
            s((g)sQLiteException, j); 
        } else {
          r((g)sQLiteException, j);
        } 
        i++;
        j++;
        continue;
      } 
      sQLiteException.F();
      sQLiteException.J();
      v v = v.a;
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_7} */
      lock.unlock();
      return;
    } 
  }
  
  public static final class a {
    private a() {}
    
    public final void a(g param1g) {
      kotlin.jvm.internal.q.j(param1g, "database");
      if (param1g.D0()) {
        param1g.G();
        return;
      } 
      param1g.h();
    }
    
    public final String b(String param1String1, String param1String2) {
      kotlin.jvm.internal.q.j(param1String1, "tableName");
      kotlin.jvm.internal.q.j(param1String2, "triggerType");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("`room_table_modification_trigger_");
      stringBuilder.append(param1String1);
      stringBuilder.append('_');
      stringBuilder.append(param1String2);
      stringBuilder.append('`');
      return stringBuilder.toString();
    }
  }
  
  public static final class b {
    public static final a e = new a(null);
    
    private final long[] a;
    
    private final boolean[] b;
    
    private final int[] c;
    
    private boolean d;
    
    public b(int param1Int) {
      this.a = new long[param1Int];
      this.b = new boolean[param1Int];
      this.c = new int[param1Int];
    }
    
    public final int[] a() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield d : Z
      //   6: istore #5
      //   8: iload #5
      //   10: ifne -> 17
      //   13: aload_0
      //   14: monitorexit
      //   15: aconst_null
      //   16: areturn
      //   17: aload_0
      //   18: getfield a : [J
      //   21: astore #8
      //   23: aload #8
      //   25: arraylength
      //   26: istore #4
      //   28: iconst_0
      //   29: istore_1
      //   30: iconst_0
      //   31: istore_2
      //   32: goto -> 103
      //   35: aload_0
      //   36: getfield b : [Z
      //   39: astore #9
      //   41: iload #5
      //   43: aload #9
      //   45: iload_2
      //   46: baload
      //   47: if_icmpeq -> 64
      //   50: aload_0
      //   51: getfield c : [I
      //   54: astore #10
      //   56: iload #5
      //   58: ifeq -> 136
      //   61: goto -> 138
      //   64: aload_0
      //   65: getfield c : [I
      //   68: iload_2
      //   69: iconst_0
      //   70: iastore
      //   71: goto -> 143
      //   74: aload_0
      //   75: iconst_0
      //   76: putfield d : Z
      //   79: aload_0
      //   80: getfield c : [I
      //   83: invokevirtual clone : ()Ljava/lang/Object;
      //   86: checkcast [I
      //   89: astore #8
      //   91: aload_0
      //   92: monitorexit
      //   93: aload #8
      //   95: areturn
      //   96: astore #8
      //   98: aload_0
      //   99: monitorexit
      //   100: aload #8
      //   102: athrow
      //   103: iload_1
      //   104: iload #4
      //   106: if_icmpge -> 74
      //   109: aload #8
      //   111: iload_1
      //   112: laload
      //   113: lstore #6
      //   115: iconst_1
      //   116: istore_3
      //   117: lload #6
      //   119: lconst_0
      //   120: lcmp
      //   121: ifle -> 130
      //   124: iconst_1
      //   125: istore #5
      //   127: goto -> 35
      //   130: iconst_0
      //   131: istore #5
      //   133: goto -> 35
      //   136: iconst_2
      //   137: istore_3
      //   138: aload #10
      //   140: iload_2
      //   141: iload_3
      //   142: iastore
      //   143: aload #9
      //   145: iload_2
      //   146: iload #5
      //   148: bastore
      //   149: iload_1
      //   150: iconst_1
      //   151: iadd
      //   152: istore_1
      //   153: iload_2
      //   154: iconst_1
      //   155: iadd
      //   156: istore_2
      //   157: goto -> 103
      // Exception table:
      //   from	to	target	type
      //   2	8	96	finally
      //   17	28	96	finally
      //   35	41	96	finally
      //   50	56	96	finally
      //   64	71	96	finally
      //   74	91	96	finally
    }
    
    public final boolean b(int... param1VarArgs) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'tableIds'
      //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: aload_0
      //   7: monitorenter
      //   8: aload_1
      //   9: arraylength
      //   10: istore_3
      //   11: iconst_0
      //   12: istore_2
      //   13: iconst_0
      //   14: istore #5
      //   16: iload_2
      //   17: iload_3
      //   18: if_icmpge -> 66
      //   21: aload_1
      //   22: iload_2
      //   23: iaload
      //   24: istore #4
      //   26: aload_0
      //   27: getfield a : [J
      //   30: astore #8
      //   32: aload #8
      //   34: iload #4
      //   36: laload
      //   37: lstore #6
      //   39: aload #8
      //   41: iload #4
      //   43: lconst_1
      //   44: lload #6
      //   46: ladd
      //   47: lastore
      //   48: lload #6
      //   50: lconst_0
      //   51: lcmp
      //   52: ifne -> 80
      //   55: iconst_1
      //   56: istore #5
      //   58: aload_0
      //   59: iconst_1
      //   60: putfield d : Z
      //   63: goto -> 80
      //   66: getstatic rj/v.a : Lrj/v;
      //   69: astore_1
      //   70: aload_0
      //   71: monitorexit
      //   72: iload #5
      //   74: ireturn
      //   75: astore_1
      //   76: aload_0
      //   77: monitorexit
      //   78: aload_1
      //   79: athrow
      //   80: iload_2
      //   81: iconst_1
      //   82: iadd
      //   83: istore_2
      //   84: goto -> 16
      // Exception table:
      //   from	to	target	type
      //   8	11	75	finally
      //   26	32	75	finally
      //   58	63	75	finally
      //   66	70	75	finally
    }
    
    public final boolean c(int... param1VarArgs) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'tableIds'
      //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: aload_0
      //   7: monitorenter
      //   8: aload_1
      //   9: arraylength
      //   10: istore_3
      //   11: iconst_0
      //   12: istore_2
      //   13: iconst_0
      //   14: istore #5
      //   16: iload_2
      //   17: iload_3
      //   18: if_icmpge -> 66
      //   21: aload_1
      //   22: iload_2
      //   23: iaload
      //   24: istore #4
      //   26: aload_0
      //   27: getfield a : [J
      //   30: astore #8
      //   32: aload #8
      //   34: iload #4
      //   36: laload
      //   37: lstore #6
      //   39: aload #8
      //   41: iload #4
      //   43: lload #6
      //   45: lconst_1
      //   46: lsub
      //   47: lastore
      //   48: lload #6
      //   50: lconst_1
      //   51: lcmp
      //   52: ifne -> 80
      //   55: iconst_1
      //   56: istore #5
      //   58: aload_0
      //   59: iconst_1
      //   60: putfield d : Z
      //   63: goto -> 80
      //   66: getstatic rj/v.a : Lrj/v;
      //   69: astore_1
      //   70: aload_0
      //   71: monitorexit
      //   72: iload #5
      //   74: ireturn
      //   75: astore_1
      //   76: aload_0
      //   77: monitorexit
      //   78: aload_1
      //   79: athrow
      //   80: iload_2
      //   81: iconst_1
      //   82: iadd
      //   83: istore_2
      //   84: goto -> 16
      // Exception table:
      //   from	to	target	type
      //   8	11	75	finally
      //   26	32	75	finally
      //   58	63	75	finally
      //   66	70	75	finally
    }
    
    public final void d() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield b : [Z
      //   6: iconst_0
      //   7: invokestatic fill : ([ZZ)V
      //   10: aload_0
      //   11: iconst_1
      //   12: putfield d : Z
      //   15: getstatic rj/v.a : Lrj/v;
      //   18: astore_1
      //   19: aload_0
      //   20: monitorexit
      //   21: return
      //   22: astore_1
      //   23: aload_0
      //   24: monitorexit
      //   25: aload_1
      //   26: athrow
      // Exception table:
      //   from	to	target	type
      //   2	19	22	finally
    }
    
    public static final class a {
      private a() {}
    }
  }
  
  public static final class a {
    private a() {}
  }
  
  public static abstract class c {
    private final String[] a;
    
    public c(String[] param1ArrayOfString) {
      this.a = param1ArrayOfString;
    }
    
    public final String[] a() {
      return this.a;
    }
    
    public boolean b() {
      return false;
    }
    
    public abstract void c(Set<String> param1Set);
  }
  
  public static final class d {
    private final q.c a;
    
    private final int[] b;
    
    private final String[] c;
    
    private final Set<String> d;
    
    public d(q.c param1c, int[] param1ArrayOfint, String[] param1ArrayOfString) {
      Set<String> set;
      this.a = param1c;
      this.b = param1ArrayOfint;
      this.c = param1ArrayOfString;
      int i = param1ArrayOfString.length;
      boolean bool = true;
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if ((i ^ 0x1) != 0) {
        set = s0.c(param1ArrayOfString[0]);
      } else {
        set = s0.d();
      } 
      this.d = set;
      if (param1ArrayOfint.length == param1ArrayOfString.length) {
        i = bool;
      } else {
        i = 0;
      } 
      if (i != 0)
        return; 
      throw new IllegalStateException("Check failed.".toString());
    }
    
    public final int[] a() {
      return this.b;
    }
    
    public final void b(Set<Integer> param1Set) {
      kotlin.jvm.internal.q.j(param1Set, "invalidatedTablesIds");
      int[] arrayOfInt = this.b;
      int i = arrayOfInt.length;
      if (i != 0) {
        Set<String> set;
        int j = 0;
        if (i != 1) {
          set = s0.b();
          int[] arrayOfInt1 = this.b;
          int k = arrayOfInt1.length;
          for (i = 0; j < k; i++) {
            if (param1Set.contains(Integer.valueOf(arrayOfInt1[j])))
              set.add(this.c[i]); 
            j++;
          } 
          param1Set = s0.a(set);
        } else if (param1Set.contains(Integer.valueOf(set[0]))) {
          Set<String> set1 = this.d;
        } else {
          param1Set = s0.d();
        } 
      } else {
        param1Set = s0.d();
      } 
      if ((param1Set.isEmpty() ^ true) != 0)
        this.a.c((Set)param1Set); 
    }
    
    public final void c(String[] param1ArrayOfString) {
      Set<String> set;
      kotlin.jvm.internal.q.j(param1ArrayOfString, "tables");
      int i = this.c.length;
      if (i != 0) {
        int j = 0;
        if (i != 1) {
          Set<String> set1 = s0.b();
          j = param1ArrayOfString.length;
          for (i = 0; i < j; i++) {
            String str = param1ArrayOfString[i];
            for (String str1 : this.c) {
              if (h.s(str1, str, true))
                set1.add(str1); 
            } 
          } 
          set = s0.a(set1);
        } else {
          int k;
          int m = set.length;
          i = 0;
          while (true) {
            k = j;
            if (i < m) {
              if (h.s((String)set[i], this.c[0], true)) {
                k = 1;
                break;
              } 
              i++;
              continue;
            } 
            break;
          } 
          if (k != 0) {
            set = this.d;
          } else {
            set = s0.d();
          } 
        } 
      } else {
        set = s0.d();
      } 
      if ((set.isEmpty() ^ true) != 0)
        this.a.c(set); 
    }
  }
  
  public static final class e implements Runnable {
    e(q param1q) {}
    
    private final Set<Integer> a() {
      Set<Integer> set1;
      q q1 = this.s0;
      Set<Integer> set2 = s0.b();
      Cursor cursor = w.B(q1.f(), (j)new e4.a("SELECT * FROM room_table_modification_log WHERE invalidated = 1;"), null, 2, null);
      try {
        while (cursor.moveToNext())
          set2.add(Integer.valueOf(cursor.getInt(0))); 
        v v = v.a;
        bk.b.a((Closeable)cursor, null);
        set1 = s0.a(set2);
        return set1;
      } finally {
        set2 = null;
      } 
    }
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield s0 : La4/q;
      //   4: invokevirtual f : ()La4/w;
      //   7: invokevirtual l : ()Ljava/util/concurrent/locks/Lock;
      //   10: astore_2
      //   11: aload_2
      //   12: invokeinterface lock : ()V
      //   17: aload_0
      //   18: getfield s0 : La4/q;
      //   21: invokevirtual d : ()Z
      //   24: istore_1
      //   25: iload_1
      //   26: ifne -> 52
      //   29: aload_2
      //   30: invokeinterface unlock : ()V
      //   35: aload_0
      //   36: getfield s0 : La4/q;
      //   39: invokestatic b : (La4/q;)La4/c;
      //   42: astore_2
      //   43: aload_2
      //   44: ifnull -> 51
      //   47: aload_2
      //   48: invokevirtual e : ()V
      //   51: return
      //   52: aload_0
      //   53: getfield s0 : La4/q;
      //   56: invokevirtual h : ()Ljava/util/concurrent/atomic/AtomicBoolean;
      //   59: iconst_1
      //   60: iconst_0
      //   61: invokevirtual compareAndSet : (ZZ)Z
      //   64: istore_1
      //   65: iload_1
      //   66: ifne -> 92
      //   69: aload_2
      //   70: invokeinterface unlock : ()V
      //   75: aload_0
      //   76: getfield s0 : La4/q;
      //   79: invokestatic b : (La4/q;)La4/c;
      //   82: astore_2
      //   83: aload_2
      //   84: ifnull -> 91
      //   87: aload_2
      //   88: invokevirtual e : ()V
      //   91: return
      //   92: aload_0
      //   93: getfield s0 : La4/q;
      //   96: invokevirtual f : ()La4/w;
      //   99: invokevirtual t : ()Z
      //   102: istore_1
      //   103: iload_1
      //   104: ifeq -> 130
      //   107: aload_2
      //   108: invokeinterface unlock : ()V
      //   113: aload_0
      //   114: getfield s0 : La4/q;
      //   117: invokestatic b : (La4/q;)La4/c;
      //   120: astore_2
      //   121: aload_2
      //   122: ifnull -> 129
      //   125: aload_2
      //   126: invokevirtual e : ()V
      //   129: return
      //   130: aload_0
      //   131: getfield s0 : La4/q;
      //   134: invokevirtual f : ()La4/w;
      //   137: invokevirtual n : ()Le4/h;
      //   140: invokeinterface o0 : ()Le4/g;
      //   145: astore #4
      //   147: aload #4
      //   149: invokeinterface G : ()V
      //   154: aload_0
      //   155: invokespecial a : ()Ljava/util/Set;
      //   158: astore_3
      //   159: aload #4
      //   161: invokeinterface F : ()V
      //   166: aload #4
      //   168: invokeinterface J : ()V
      //   173: aload_2
      //   174: invokeinterface unlock : ()V
      //   179: aload_0
      //   180: getfield s0 : La4/q;
      //   183: invokestatic b : (La4/q;)La4/c;
      //   186: astore #4
      //   188: aload_3
      //   189: astore_2
      //   190: aload #4
      //   192: ifnull -> 305
      //   195: aload_3
      //   196: astore_2
      //   197: aload #4
      //   199: astore_3
      //   200: aload_3
      //   201: invokevirtual e : ()V
      //   204: goto -> 305
      //   207: astore_3
      //   208: aload #4
      //   210: invokeinterface J : ()V
      //   215: aload_3
      //   216: athrow
      //   217: astore_3
      //   218: goto -> 395
      //   221: astore_3
      //   222: ldc 'ROOM'
      //   224: ldc 'Cannot run invalidation tracker. Is the db closed?'
      //   226: aload_3
      //   227: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   230: pop
      //   231: invokestatic d : ()Ljava/util/Set;
      //   234: astore #4
      //   236: aload_2
      //   237: invokeinterface unlock : ()V
      //   242: aload_0
      //   243: getfield s0 : La4/q;
      //   246: invokestatic b : (La4/q;)La4/c;
      //   249: astore_3
      //   250: aload #4
      //   252: astore_2
      //   253: aload_3
      //   254: ifnull -> 305
      //   257: aload #4
      //   259: astore_2
      //   260: goto -> 200
      //   263: astore_3
      //   264: ldc 'ROOM'
      //   266: ldc 'Cannot run invalidation tracker. Is the db closed?'
      //   268: aload_3
      //   269: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   272: pop
      //   273: invokestatic d : ()Ljava/util/Set;
      //   276: astore #4
      //   278: aload_2
      //   279: invokeinterface unlock : ()V
      //   284: aload_0
      //   285: getfield s0 : La4/q;
      //   288: invokestatic b : (La4/q;)La4/c;
      //   291: astore_3
      //   292: aload #4
      //   294: astore_2
      //   295: aload_3
      //   296: ifnull -> 305
      //   299: aload #4
      //   301: astore_2
      //   302: goto -> 200
      //   305: aload_2
      //   306: checkcast java/util/Collection
      //   309: invokeinterface isEmpty : ()Z
      //   314: iconst_1
      //   315: ixor
      //   316: ifeq -> 394
      //   319: aload_0
      //   320: getfield s0 : La4/q;
      //   323: invokevirtual g : ()Ll/b;
      //   326: astore_3
      //   327: aload_0
      //   328: getfield s0 : La4/q;
      //   331: astore #4
      //   333: aload_3
      //   334: monitorenter
      //   335: aload #4
      //   337: invokevirtual g : ()Ll/b;
      //   340: invokeinterface iterator : ()Ljava/util/Iterator;
      //   345: astore #4
      //   347: aload #4
      //   349: invokeinterface hasNext : ()Z
      //   354: ifeq -> 382
      //   357: aload #4
      //   359: invokeinterface next : ()Ljava/lang/Object;
      //   364: checkcast java/util/Map$Entry
      //   367: invokeinterface getValue : ()Ljava/lang/Object;
      //   372: checkcast a4/q$d
      //   375: aload_2
      //   376: invokevirtual b : (Ljava/util/Set;)V
      //   379: goto -> 347
      //   382: getstatic rj/v.a : Lrj/v;
      //   385: astore_2
      //   386: aload_3
      //   387: monitorexit
      //   388: return
      //   389: astore_2
      //   390: aload_3
      //   391: monitorexit
      //   392: aload_2
      //   393: athrow
      //   394: return
      //   395: aload_2
      //   396: invokeinterface unlock : ()V
      //   401: aload_0
      //   402: getfield s0 : La4/q;
      //   405: invokestatic b : (La4/q;)La4/c;
      //   408: astore_2
      //   409: aload_2
      //   410: ifnull -> 417
      //   413: aload_2
      //   414: invokevirtual e : ()V
      //   417: aload_3
      //   418: athrow
      // Exception table:
      //   from	to	target	type
      //   17	25	263	java/lang/IllegalStateException
      //   17	25	221	android/database/sqlite/SQLiteException
      //   17	25	217	finally
      //   52	65	263	java/lang/IllegalStateException
      //   52	65	221	android/database/sqlite/SQLiteException
      //   52	65	217	finally
      //   92	103	263	java/lang/IllegalStateException
      //   92	103	221	android/database/sqlite/SQLiteException
      //   92	103	217	finally
      //   130	154	263	java/lang/IllegalStateException
      //   130	154	221	android/database/sqlite/SQLiteException
      //   130	154	217	finally
      //   154	166	207	finally
      //   166	173	263	java/lang/IllegalStateException
      //   166	173	221	android/database/sqlite/SQLiteException
      //   166	173	217	finally
      //   208	217	263	java/lang/IllegalStateException
      //   208	217	221	android/database/sqlite/SQLiteException
      //   208	217	217	finally
      //   222	236	217	finally
      //   264	278	217	finally
      //   335	347	389	finally
      //   347	379	389	finally
      //   382	386	389	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */