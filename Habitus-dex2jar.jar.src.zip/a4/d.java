package a4;

import android.content.ContentResolver;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.database.SQLException;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.util.Pair;
import dk.l;
import e4.g;
import e4.h;
import e4.j;
import e4.k;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.collections.r;
import kotlin.jvm.internal.n;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import rj.v;

public final class d implements h, i {
  private final h s0;
  
  public final c t0;
  
  private final a u0;
  
  public d(h paramh, c paramc) {
    this.s0 = paramh;
    this.t0 = paramc;
    paramc.k(getDelegate());
    this.u0 = new a(paramc);
  }
  
  public void close() {
    this.u0.close();
  }
  
  public String getDatabaseName() {
    return this.s0.getDatabaseName();
  }
  
  public h getDelegate() {
    return this.s0;
  }
  
  public g o0() {
    this.u0.a();
    return this.u0;
  }
  
  public void setWriteAheadLoggingEnabled(boolean paramBoolean) {
    this.s0.setWriteAheadLoggingEnabled(paramBoolean);
  }
  
  public static final class a implements g {
    private final c s0;
    
    public a(c param1c) {
      this.s0 = param1c;
    }
    
    public boolean D0() {
      return ((Boolean)this.s0.<Boolean>g(d.s0)).booleanValue();
    }
    
    public void F() {
      g g1 = this.s0.h();
      if (g1 != null) {
        g1.F();
        v v = v.a;
      } else {
        g1 = null;
      } 
      if (g1 != null)
        return; 
      throw new IllegalStateException("setTransactionSuccessful called but delegateDb is null".toString());
    }
    
    public void G() {
      null = this.s0.j();
      try {
        return;
      } finally {
        this.s0.e();
      } 
    }
    
    public void J() {
      if (this.s0.h() != null)
        try {
          g g1 = this.s0.h();
          q.g(g1);
          g1.J();
          return;
        } finally {
          this.s0.e();
        }  
      throw new IllegalStateException("End transaction called but delegateDb is null".toString());
    }
    
    public final void a() {
      this.s0.g(f.s0);
    }
    
    public k c0(String param1String) {
      q.j(param1String, "sql");
      return new d.b(param1String, this.s0);
    }
    
    public void close() throws IOException {
      this.s0.d();
    }
    
    public String getPath() {
      return this.s0.<String>g(e.s0);
    }
    
    public void h() {
      null = this.s0.j();
      try {
        return;
      } finally {
        this.s0.e();
      } 
    }
    
    public Cursor i0(j param1j, CancellationSignal param1CancellationSignal) {
      q.j(param1j, "query");
      try {
        return new d.c(cursor, this.s0);
      } finally {
        this.s0.e();
      } 
    }
    
    public boolean isOpen() {
      g g1 = this.s0.h();
      return (g1 == null) ? false : g1.isOpen();
    }
    
    public List<Pair<String, String>> k() {
      return this.s0.<List<Pair<String, String>>>g(a.s0);
    }
    
    public void l(String param1String) throws SQLException {
      q.j(param1String, "sql");
      this.s0.g(new b(param1String));
    }
    
    public Cursor p0(String param1String) {
      q.j(param1String, "query");
      try {
        return new d.c(cursor, this.s0);
      } finally {
        this.s0.e();
      } 
    }
    
    public Cursor v0(j param1j) {
      q.j(param1j, "query");
      try {
        return new d.c(cursor, this.s0);
      } finally {
        this.s0.e();
      } 
    }
    
    public boolean z0() {
      return (this.s0.h() == null) ? false : ((Boolean)this.s0.<Boolean>g(c.s0)).booleanValue();
    }
    
    static final class a extends r implements l<g, List<? extends Pair<String, String>>> {
      public static final a s0 = new a();
      
      a() {
        super(1);
      }
      
      public final List<Pair<String, String>> a(g param2g) {
        q.j(param2g, "obj");
        return param2g.k();
      }
    }
    
    static final class b extends r implements l<g, Object> {
      b(String param2String) {
        super(1);
      }
      
      public final Object a(g param2g) {
        q.j(param2g, "db");
        param2g.l(this.s0);
        return null;
      }
    }
    
    static final class d extends r implements l<g, Boolean> {
      public static final d s0 = new d();
      
      d() {
        super(1);
      }
      
      public final Boolean a(g param2g) {
        q.j(param2g, "db");
        return Boolean.valueOf(param2g.D0());
      }
    }
    
    static final class e extends r implements l<g, String> {
      public static final e s0 = new e();
      
      e() {
        super(1);
      }
      
      public final String a(g param2g) {
        q.j(param2g, "obj");
        return param2g.getPath();
      }
    }
    
    static final class f extends r implements l<g, Object> {
      public static final f s0 = new f();
      
      f() {
        super(1);
      }
      
      public final Object a(g param2g) {
        q.j(param2g, "it");
        return null;
      }
    }
  }
  
  static final class a extends r implements l<g, List<? extends Pair<String, String>>> {
    public static final a s0 = new a();
    
    a() {
      super(1);
    }
    
    public final List<Pair<String, String>> a(g param1g) {
      q.j(param1g, "obj");
      return param1g.k();
    }
  }
  
  static final class b extends r implements l<g, Object> {
    b(String param1String) {
      super(1);
    }
    
    public final Object a(g param1g) {
      q.j(param1g, "db");
      param1g.l(this.s0);
      return null;
    }
  }
  
  static final class d extends r implements l<g, Boolean> {
    public static final d s0 = new d();
    
    d() {
      super(1);
    }
    
    public final Boolean a(g param1g) {
      q.j(param1g, "db");
      return Boolean.valueOf(param1g.D0());
    }
  }
  
  static final class e extends r implements l<g, String> {
    public static final e s0 = new e();
    
    e() {
      super(1);
    }
    
    public final String a(g param1g) {
      q.j(param1g, "obj");
      return param1g.getPath();
    }
  }
  
  static final class f extends r implements l<g, Object> {
    public static final f s0 = new f();
    
    f() {
      super(1);
    }
    
    public final Object a(g param1g) {
      q.j(param1g, "it");
      return null;
    }
  }
  
  private static final class b implements k {
    private final String s0;
    
    private final c t0;
    
    private final ArrayList<Object> u0;
    
    public b(String param1String, c param1c) {
      this.s0 = param1String;
      this.t0 = param1c;
      this.u0 = new ArrayList();
    }
    
    private final void c(k param1k) {
      Iterator iterator = this.u0.iterator();
      for (int i = 0; iterator.hasNext(); i = j) {
        iterator.next();
        int j = i + 1;
        if (i < 0)
          r.v(); 
        Object object = this.u0.get(i);
        if (object == null) {
          param1k.x0(j);
        } else if (object instanceof Long) {
          param1k.m0(j, ((Number)object).longValue());
        } else if (object instanceof Double) {
          param1k.y(j, ((Number)object).doubleValue());
        } else if (object instanceof String) {
          param1k.Z(j, (String)object);
        } else if (object instanceof byte[]) {
          param1k.n0(j, (byte[])object);
        } 
      } 
    }
    
    private final <T> T d(l<? super k, ? extends T> param1l) {
      return this.t0.g(new b(this, param1l));
    }
    
    private final void f(int param1Int, Object param1Object) {
      int i = param1Int - 1;
      if (i >= this.u0.size()) {
        param1Int = this.u0.size();
        if (param1Int <= i)
          while (true) {
            this.u0.add(null);
            if (param1Int != i) {
              param1Int++;
              continue;
            } 
            break;
          }  
      } 
      this.u0.set(i, param1Object);
    }
    
    public long W() {
      return ((Number)d(a.s0)).longValue();
    }
    
    public void Z(int param1Int, String param1String) {
      q.j(param1String, "value");
      f(param1Int, param1String);
    }
    
    public void close() throws IOException {}
    
    public void m0(int param1Int, long param1Long) {
      f(param1Int, Long.valueOf(param1Long));
    }
    
    public void n0(int param1Int, byte[] param1ArrayOfbyte) {
      q.j(param1ArrayOfbyte, "value");
      f(param1Int, param1ArrayOfbyte);
    }
    
    public int v() {
      return ((Number)d(c.s0)).intValue();
    }
    
    public void x0(int param1Int) {
      f(param1Int, null);
    }
    
    public void y(int param1Int, double param1Double) {
      f(param1Int, Double.valueOf(param1Double));
    }
    
    static final class a extends r implements l<k, Long> {
      public static final a s0 = new a();
      
      a() {
        super(1);
      }
      
      public final Long a(k param2k) {
        q.j(param2k, "obj");
        return Long.valueOf(param2k.W());
      }
    }
    
    static final class b extends r implements l<g, T> {
      b(d.b param2b, l<? super k, ? extends T> param2l) {
        super(1);
      }
      
      public final T a(g param2g) {
        q.j(param2g, "db");
        k k = param2g.c0(d.b.b(this.s0));
        d.b.a(this.s0, k);
        return (T)this.t0.invoke(k);
      }
    }
    
    static final class c extends r implements l<k, Integer> {
      public static final c s0 = new c();
      
      c() {
        super(1);
      }
      
      public final Integer a(k param2k) {
        q.j(param2k, "obj");
        return Integer.valueOf(param2k.v());
      }
    }
  }
  
  static final class a extends r implements l<k, Long> {
    public static final a s0 = new a();
    
    a() {
      super(1);
    }
    
    public final Long a(k param1k) {
      q.j(param1k, "obj");
      return Long.valueOf(param1k.W());
    }
  }
  
  static final class b extends r implements l<g, T> {
    b(d.b param1b, l<? super k, ? extends T> param1l) {
      super(1);
    }
    
    public final T a(g param1g) {
      q.j(param1g, "db");
      k k = param1g.c0(d.b.b(this.s0));
      d.b.a(this.s0, k);
      return (T)this.t0.invoke(k);
    }
  }
  
  static final class c extends r implements l<k, Integer> {
    public static final c s0 = new c();
    
    c() {
      super(1);
    }
    
    public final Integer a(k param1k) {
      q.j(param1k, "obj");
      return Integer.valueOf(param1k.v());
    }
  }
  
  private static final class c implements Cursor {
    private final Cursor s0;
    
    private final c t0;
    
    public c(Cursor param1Cursor, c param1c) {
      this.s0 = param1Cursor;
      this.t0 = param1c;
    }
    
    public void close() {
      this.s0.close();
      this.t0.e();
    }
    
    public void copyStringToBuffer(int param1Int, CharArrayBuffer param1CharArrayBuffer) {
      this.s0.copyStringToBuffer(param1Int, param1CharArrayBuffer);
    }
    
    public void deactivate() {
      this.s0.deactivate();
    }
    
    public byte[] getBlob(int param1Int) {
      return this.s0.getBlob(param1Int);
    }
    
    public int getColumnCount() {
      return this.s0.getColumnCount();
    }
    
    public int getColumnIndex(String param1String) {
      return this.s0.getColumnIndex(param1String);
    }
    
    public int getColumnIndexOrThrow(String param1String) {
      return this.s0.getColumnIndexOrThrow(param1String);
    }
    
    public String getColumnName(int param1Int) {
      return this.s0.getColumnName(param1Int);
    }
    
    public String[] getColumnNames() {
      return this.s0.getColumnNames();
    }
    
    public int getCount() {
      return this.s0.getCount();
    }
    
    public double getDouble(int param1Int) {
      return this.s0.getDouble(param1Int);
    }
    
    public Bundle getExtras() {
      return this.s0.getExtras();
    }
    
    public float getFloat(int param1Int) {
      return this.s0.getFloat(param1Int);
    }
    
    public int getInt(int param1Int) {
      return this.s0.getInt(param1Int);
    }
    
    public long getLong(int param1Int) {
      return this.s0.getLong(param1Int);
    }
    
    public Uri getNotificationUri() {
      return e4.c.a(this.s0);
    }
    
    public List<Uri> getNotificationUris() {
      return e4.f.a(this.s0);
    }
    
    public int getPosition() {
      return this.s0.getPosition();
    }
    
    public short getShort(int param1Int) {
      return this.s0.getShort(param1Int);
    }
    
    public String getString(int param1Int) {
      return this.s0.getString(param1Int);
    }
    
    public int getType(int param1Int) {
      return this.s0.getType(param1Int);
    }
    
    public boolean getWantsAllOnMoveCalls() {
      return this.s0.getWantsAllOnMoveCalls();
    }
    
    public boolean isAfterLast() {
      return this.s0.isAfterLast();
    }
    
    public boolean isBeforeFirst() {
      return this.s0.isBeforeFirst();
    }
    
    public boolean isClosed() {
      return this.s0.isClosed();
    }
    
    public boolean isFirst() {
      return this.s0.isFirst();
    }
    
    public boolean isLast() {
      return this.s0.isLast();
    }
    
    public boolean isNull(int param1Int) {
      return this.s0.isNull(param1Int);
    }
    
    public boolean move(int param1Int) {
      return this.s0.move(param1Int);
    }
    
    public boolean moveToFirst() {
      return this.s0.moveToFirst();
    }
    
    public boolean moveToLast() {
      return this.s0.moveToLast();
    }
    
    public boolean moveToNext() {
      return this.s0.moveToNext();
    }
    
    public boolean moveToPosition(int param1Int) {
      return this.s0.moveToPosition(param1Int);
    }
    
    public boolean moveToPrevious() {
      return this.s0.moveToPrevious();
    }
    
    public void registerContentObserver(ContentObserver param1ContentObserver) {
      this.s0.registerContentObserver(param1ContentObserver);
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      this.s0.registerDataSetObserver(param1DataSetObserver);
    }
    
    public boolean requery() {
      return this.s0.requery();
    }
    
    public Bundle respond(Bundle param1Bundle) {
      return this.s0.respond(param1Bundle);
    }
    
    public void setExtras(Bundle param1Bundle) {
      q.j(param1Bundle, "extras");
      e4.e.a(this.s0, param1Bundle);
    }
    
    public void setNotificationUri(ContentResolver param1ContentResolver, Uri param1Uri) {
      this.s0.setNotificationUri(param1ContentResolver, param1Uri);
    }
    
    public void setNotificationUris(ContentResolver param1ContentResolver, List<? extends Uri> param1List) {
      q.j(param1ContentResolver, "cr");
      q.j(param1List, "uris");
      e4.f.b(this.s0, param1ContentResolver, param1List);
    }
    
    public void unregisterContentObserver(ContentObserver param1ContentObserver) {
      this.s0.unregisterContentObserver(param1ContentObserver);
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      this.s0.unregisterDataSetObserver(param1DataSetObserver);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */