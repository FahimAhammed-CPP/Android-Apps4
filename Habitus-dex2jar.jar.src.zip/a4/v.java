package a4;

import android.content.Context;
import kotlin.jvm.internal.q;
import lk.h;

public final class v {
  public static final v a = new v();
  
  public static final <T extends w> w.a<T> a(Context paramContext, Class<T> paramClass, String paramString) {
    boolean bool;
    q.j(paramContext, "context");
    q.j(paramClass, "klass");
    if (paramString == null || h.v(paramString)) {
      bool = true;
    } else {
      bool = false;
    } 
    if ((true ^ bool) != 0)
      return new w.a<T>(paramContext, paramClass, paramString); 
    throw new IllegalArgumentException("Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder".toString());
  }
  
  public static final <T, C> T b(Class<C> paramClass, String paramString) {
    q.j(paramClass, "klass");
    q.j(paramString, "suffix");
    Package package_ = paramClass.getPackage();
    q.g(package_);
    String str3 = package_.getName();
    String str2 = paramClass.getCanonicalName();
    q.g(str2);
    q.i(str3, "fullPackage");
    int i = str3.length();
    boolean bool = false;
    if (i == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 0) {
      str2 = str2.substring(str3.length() + 1);
      q.i(str2, "this as java.lang.String).substring(startIndex)");
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(h.B(str2, '.', '_', false, 4, null));
    stringBuilder2.append(paramString);
    str2 = stringBuilder2.toString();
    i = bool;
    try {
      if (str3.length() == 0)
        i = 1; 
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find implementation for ");
      stringBuilder.append(paramClass.getCanonicalName());
      stringBuilder.append(". ");
      stringBuilder.append(str2);
      stringBuilder.append(" does not exist");
      throw new RuntimeException(stringBuilder.toString());
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot access the constructor ");
      stringBuilder.append(paramClass);
      stringBuilder.append(".canonicalName");
      throw new RuntimeException(stringBuilder.toString());
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to create an instance of ");
      stringBuilder.append(paramClass);
      stringBuilder.append(".canonicalName");
      throw new RuntimeException(stringBuilder.toString());
    } 
    if (i != 0) {
      paramString = str2;
      null = Class.forName(paramString, true, paramClass.getClassLoader());
      q.h(null, "null cannot be cast to non-null type java.lang.Class<T of androidx.room.Room.getGeneratedImplementation>");
      return (T)null.newInstance();
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(str3);
    stringBuilder1.append('.');
    stringBuilder1.append(str2);
    String str1 = stringBuilder1.toString();
    null = Class.forName(str1, true, paramClass.getClassLoader());
    q.h(null, "null cannot be cast to non-null type java.lang.Class<T of androidx.room.Room.getGeneratedImplementation>");
    return (T)null.newInstance();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */