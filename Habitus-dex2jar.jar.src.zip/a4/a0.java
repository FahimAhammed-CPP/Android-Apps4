package a4;

import e4.i;
import e4.j;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.q;
import rj.v;

public final class a0 implements j, i {
  public static final a A0 = new a(null);
  
  public static final TreeMap<Integer, a0> B0 = new TreeMap<Integer, a0>();
  
  private final int s0;
  
  private volatile String t0;
  
  public final long[] u0;
  
  public final double[] v0;
  
  public final String[] w0;
  
  public final byte[][] x0;
  
  private final int[] y0;
  
  private int z0;
  
  private a0(int paramInt) {
    this.s0 = paramInt;
    this.y0 = new int[++paramInt];
    this.u0 = new long[paramInt];
    this.v0 = new double[paramInt];
    this.w0 = new String[paramInt];
    this.x0 = new byte[paramInt][];
  }
  
  public static final a0 c(String paramString, int paramInt) {
    return A0.a(paramString, paramInt);
  }
  
  public void Z(int paramInt, String paramString) {
    q.j(paramString, "value");
    this.y0[paramInt] = 4;
    this.w0[paramInt] = paramString;
  }
  
  public String a() {
    String str = this.t0;
    if (str != null)
      return str; 
    throw new IllegalStateException("Required value was null.".toString());
  }
  
  public void b(i parami) {
    q.j(parami, "statement");
    int k = d();
    if (1 <= k) {
      int m = 1;
      while (true) {
        int n = this.y0[m];
        if (n != 1) {
          if (n != 2) {
            if (n != 3) {
              if (n != 4) {
                if (n == 5) {
                  byte[] arrayOfByte = this.x0[m];
                  if (arrayOfByte != null) {
                    parami.n0(m, arrayOfByte);
                  } else {
                    throw new IllegalArgumentException("Required value was null.".toString());
                  } 
                } 
              } else {
                String str = this.w0[m];
                if (str != null) {
                  parami.Z(m, str);
                } else {
                  throw new IllegalArgumentException("Required value was null.".toString());
                } 
              } 
            } else {
              parami.y(m, this.v0[m]);
            } 
          } else {
            parami.m0(m, this.u0[m]);
          } 
        } else {
          parami.x0(m);
        } 
        if (m != k) {
          m++;
          continue;
        } 
        break;
      } 
    } 
  }
  
  public void close() {}
  
  public int d() {
    return this.z0;
  }
  
  public final void f(String paramString, int paramInt) {
    q.j(paramString, "query");
    this.t0 = paramString;
    this.z0 = paramInt;
  }
  
  public final void g() {
    synchronized (B0) {
      null.put(Integer.valueOf(this.s0), this);
      A0.b();
      v v = v.a;
      return;
    } 
  }
  
  public void m0(int paramInt, long paramLong) {
    this.y0[paramInt] = 2;
    this.u0[paramInt] = paramLong;
  }
  
  public void n0(int paramInt, byte[] paramArrayOfbyte) {
    q.j(paramArrayOfbyte, "value");
    this.y0[paramInt] = 5;
    this.x0[paramInt] = paramArrayOfbyte;
  }
  
  public void x0(int paramInt) {
    this.y0[paramInt] = 1;
  }
  
  public void y(int paramInt, double paramDouble) {
    this.y0[paramInt] = 3;
    this.v0[paramInt] = paramDouble;
  }
  
  public static final class a {
    private a() {}
    
    public final a0 a(String param1String, int param1Int) {
      TreeMap<Integer, a0> treeMap;
      a0 a0;
      q.j(param1String, "query");
      synchronized (a0.B0) {
        Map.Entry<Integer, a0> entry = treeMap.ceilingEntry(Integer.valueOf(param1Int));
        if (entry != null) {
          treeMap.remove(entry.getKey());
          a0 a01 = entry.getValue();
          a01.f(param1String, param1Int);
          q.i(a01, "sqliteQuery");
          return a01;
        } 
        v v = v.a;
        a0 = new a0(param1Int, null);
        a0.f(param1String, param1Int);
        return a0;
      } 
    }
    
    public final void b() {
      TreeMap<Integer, a0> treeMap = a0.B0;
      if (treeMap.size() > 15) {
        int i = treeMap.size() - 10;
        Iterator iterator = treeMap.descendingKeySet().iterator();
        q.i(iterator, "queryPool.descendingKeySet().iterator()");
        while (i > 0) {
          iterator.next();
          iterator.remove();
          i--;
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */