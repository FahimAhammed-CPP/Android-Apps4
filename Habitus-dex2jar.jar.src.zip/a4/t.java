package a4;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import java.util.Arrays;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.jvm.internal.q;

public final class t {
  private final String a;
  
  private final q b;
  
  private final Executor c;
  
  private final Context d;
  
  private int e;
  
  public q.c f;
  
  private m g;
  
  private final l h;
  
  private final AtomicBoolean i;
  
  private final ServiceConnection j;
  
  private final Runnable k;
  
  private final Runnable l;
  
  public t(Context paramContext, String paramString, Intent paramIntent, q paramq, Executor paramExecutor) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'context'
    //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_2
    //   7: ldc 'name'
    //   9: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: aload_3
    //   13: ldc 'serviceIntent'
    //   15: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   18: aload #4
    //   20: ldc 'invalidationTracker'
    //   22: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   25: aload #5
    //   27: ldc 'executor'
    //   29: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
    //   32: aload_0
    //   33: invokespecial <init> : ()V
    //   36: aload_0
    //   37: aload_2
    //   38: putfield a : Ljava/lang/String;
    //   41: aload_0
    //   42: aload #4
    //   44: putfield b : La4/q;
    //   47: aload_0
    //   48: aload #5
    //   50: putfield c : Ljava/util/concurrent/Executor;
    //   53: aload_1
    //   54: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   57: astore_1
    //   58: aload_0
    //   59: aload_1
    //   60: putfield d : Landroid/content/Context;
    //   63: aload_0
    //   64: new a4/t$b
    //   67: dup
    //   68: aload_0
    //   69: invokespecial <init> : (La4/t;)V
    //   72: putfield h : La4/l;
    //   75: aload_0
    //   76: new java/util/concurrent/atomic/AtomicBoolean
    //   79: dup
    //   80: iconst_0
    //   81: invokespecial <init> : (Z)V
    //   84: putfield i : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   87: new a4/t$c
    //   90: dup
    //   91: aload_0
    //   92: invokespecial <init> : (La4/t;)V
    //   95: astore_2
    //   96: aload_0
    //   97: aload_2
    //   98: putfield j : Landroid/content/ServiceConnection;
    //   101: aload_0
    //   102: new a4/r
    //   105: dup
    //   106: aload_0
    //   107: invokespecial <init> : (La4/t;)V
    //   110: putfield k : Ljava/lang/Runnable;
    //   113: aload_0
    //   114: new a4/s
    //   117: dup
    //   118: aload_0
    //   119: invokespecial <init> : (La4/t;)V
    //   122: putfield l : Ljava/lang/Runnable;
    //   125: aload #4
    //   127: invokevirtual i : ()Ljava/util/Map;
    //   130: invokeinterface keySet : ()Ljava/util/Set;
    //   135: checkcast java/util/Collection
    //   138: iconst_0
    //   139: anewarray java/lang/String
    //   142: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   147: astore #4
    //   149: aload #4
    //   151: ldc 'null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>'
    //   153: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   156: aload_0
    //   157: new a4/t$a
    //   160: dup
    //   161: aload_0
    //   162: aload #4
    //   164: checkcast [Ljava/lang/String;
    //   167: invokespecial <init> : (La4/t;[Ljava/lang/String;)V
    //   170: invokevirtual l : (La4/q$c;)V
    //   173: aload_1
    //   174: aload_3
    //   175: aload_2
    //   176: iconst_1
    //   177: invokevirtual bindService : (Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   180: pop
    //   181: return
  }
  
  private static final void k(t paramt) {
    q.j(paramt, "this$0");
    paramt.b.n(paramt.f());
  }
  
  private static final void n(t paramt) {
    q.j(paramt, "this$0");
    try {
      m m1 = paramt.g;
      if (m1 != null) {
        paramt.e = m1.x(paramt.h, paramt.a);
        paramt.b.c(paramt.f());
        return;
      } 
    } catch (RemoteException remoteException) {
      Log.w("ROOM", "Cannot register multi-instance invalidation callback", (Throwable)remoteException);
    } 
  }
  
  public final int c() {
    return this.e;
  }
  
  public final Executor d() {
    return this.c;
  }
  
  public final q e() {
    return this.b;
  }
  
  public final q.c f() {
    q.c c1 = this.f;
    if (c1 != null)
      return c1; 
    q.B("observer");
    return null;
  }
  
  public final Runnable g() {
    return this.l;
  }
  
  public final m h() {
    return this.g;
  }
  
  public final Runnable i() {
    return this.k;
  }
  
  public final AtomicBoolean j() {
    return this.i;
  }
  
  public final void l(q.c paramc) {
    q.j(paramc, "<set-?>");
    this.f = paramc;
  }
  
  public final void m(m paramm) {
    this.g = paramm;
  }
  
  public static final class a extends q.c {
    a(t param1t, String[] param1ArrayOfString) {
      super(param1ArrayOfString);
    }
    
    public boolean b() {
      return true;
    }
    
    public void c(Set<String> param1Set) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'tables'
      //   3: invokestatic j : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: aload_0
      //   7: getfield b : La4/t;
      //   10: invokevirtual j : ()Ljava/util/concurrent/atomic/AtomicBoolean;
      //   13: invokevirtual get : ()Z
      //   16: ifeq -> 20
      //   19: return
      //   20: aload_0
      //   21: getfield b : La4/t;
      //   24: invokevirtual h : ()La4/m;
      //   27: astore_3
      //   28: aload_3
      //   29: ifnull -> 82
      //   32: aload_0
      //   33: getfield b : La4/t;
      //   36: invokevirtual c : ()I
      //   39: istore_2
      //   40: aload_1
      //   41: checkcast java/util/Collection
      //   44: iconst_0
      //   45: anewarray java/lang/String
      //   48: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
      //   53: astore_1
      //   54: aload_1
      //   55: ldc 'null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>'
      //   57: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
      //   60: aload_3
      //   61: iload_2
      //   62: aload_1
      //   63: checkcast [Ljava/lang/String;
      //   66: invokeinterface o0 : (I[Ljava/lang/String;)V
      //   71: return
      //   72: astore_1
      //   73: ldc 'ROOM'
      //   75: ldc 'Cannot broadcast invalidation'
      //   77: aload_1
      //   78: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   81: pop
      //   82: return
      // Exception table:
      //   from	to	target	type
      //   20	28	72	android/os/RemoteException
      //   32	71	72	android/os/RemoteException
    }
  }
  
  public static final class b extends l.a {
    b(t param1t) {}
    
    private static final void k1(t param1t, String[] param1ArrayOfString) {
      q.j(param1t, "this$0");
      q.j(param1ArrayOfString, "$tables");
      param1t.e().k(Arrays.<String>copyOf(param1ArrayOfString, param1ArrayOfString.length));
    }
    
    public void z(String[] param1ArrayOfString) {
      q.j(param1ArrayOfString, "tables");
      this.c.d().execute(new u(this.c, param1ArrayOfString));
    }
  }
  
  public static final class c implements ServiceConnection {
    c(t param1t) {}
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      q.j(param1ComponentName, "name");
      q.j(param1IBinder, "service");
      this.s0.m(m.a.i1(param1IBinder));
      this.s0.d().execute(this.s0.i());
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      q.j(param1ComponentName, "name");
      this.s0.d().execute(this.s0.g());
      this.s0.m(null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a4\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */