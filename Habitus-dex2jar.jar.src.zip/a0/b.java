package a0;

import a1.h;
import dk.a;
import o1.s;
import rj.v;
import vj.d;

public interface b {
  Object S0(s params, a<h> parama, d<? super v> paramd);
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */