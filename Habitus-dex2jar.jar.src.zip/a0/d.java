package a0;

import a1.h;
import rj.v;

public interface d {
  Object a(h paramh, vj.d<? super v> paramd);
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */