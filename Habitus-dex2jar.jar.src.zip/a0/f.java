package a0;

import a1.h;
import android.graphics.Rect;
import android.view.View;
import androidx.compose.ui.platform.i0;
import kotlin.jvm.internal.q;
import l0.t;
import o1.s;
import o1.t;
import q1.h;
import q1.i;
import rj.v;
import vj.d;

public final class f {
  public static final b b(h paramh) {
    q.j(paramh, "<this>");
    return new a(paramh);
  }
  
  private static final Rect c(h paramh) {
    return new Rect((int)paramh.i(), (int)paramh.l(), (int)paramh.j(), (int)paramh.e());
  }
  
  static final class a implements b {
    a(h param1h) {}
    
    public final Object S0(s param1s, dk.a<h> param1a, d<? super v> param1d) {
      View view = (View)i.a(this.s0, (t)i0.k());
      long l = t.e(param1s);
      h h1 = (h)param1a.invoke();
      if (h1 != null) {
        h1 = h1.r(l);
      } else {
        h1 = null;
      } 
      if (h1 != null)
        view.requestRectangleOnScreen(f.a(h1), false); 
      return v.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */