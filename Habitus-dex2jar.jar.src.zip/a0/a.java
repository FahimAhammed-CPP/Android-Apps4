package a0;

import kotlin.jvm.internal.r;
import p1.e;
import p1.m;

public final class a {
  private static final m<b> a = e.a(a.s0);
  
  public static final m<b> a() {
    return a;
  }
  
  static final class a extends r implements dk.a<b> {
    public static final a s0 = new a();
    
    a() {
      super(0);
    }
    
    public final b d() {
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */