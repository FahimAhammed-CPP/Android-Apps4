package a5;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import java.util.List;

public abstract class b extends Fragment {
  protected Context s0;
  
  protected int t0;
  
  private List<ResolveInfo> e(Intent paramIntent) {
    return this.s0.getPackageManager().queryIntentActivities(paramIntent, 0);
  }
  
  private boolean i() {
    return (this.t0 != Integer.MIN_VALUE);
  }
  
  private boolean j() {
    Intent intent = new Intent("android.intent.action.VIEW");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(h());
    stringBuilder.append("://");
    return (e(intent.setData(Uri.parse(stringBuilder.toString())).addCategory("android.intent.category.DEFAULT").addCategory("android.intent.category.BROWSABLE")).size() == 1);
  }
  
  public void f(int paramInt, Intent paramIntent) {
    if (paramInt == Integer.MIN_VALUE) {
      k(paramInt, a.a(a.v0, "Request code cannot be Integer.MIN_VALUE"), null);
      return;
    } 
    if (!j()) {
      k(paramInt, a.a(a.v0, "The return url scheme was not set up, incorrectly set up, or more than one Activity on this device defines the same url scheme in it's Android Manifest. See https://github.com/braintree/browser-switch-android for more information on setting up a return url scheme."), null);
      return;
    } 
    if (e(paramIntent).size() == 0) {
      k(paramInt, a.a(a.v0, String.format("No installed activities can open this URL: %s", new Object[] { paramIntent.getData().toString() })), null);
      return;
    } 
    this.t0 = paramInt;
    this.s0.startActivity(paramIntent);
  }
  
  public void g(int paramInt, String paramString) {
    Intent intent = (new Intent("android.intent.action.VIEW", Uri.parse(paramString))).addFlags(268435456);
    c.a(this.s0, intent);
    f(paramInt, intent);
  }
  
  public String h() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.s0.getPackageName().toLowerCase().replace("_", ""));
    stringBuilder.append(".browserswitch");
    return stringBuilder.toString();
  }
  
  public abstract void k(int paramInt, a parama, Uri paramUri);
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (this.s0 == null)
      this.s0 = getActivity().getApplicationContext(); 
    if (paramBundle != null) {
      this.t0 = paramBundle.getInt("com.braintreepayments.browserswitch.EXTRA_REQUEST_CODE");
      return;
    } 
    this.t0 = Integer.MIN_VALUE;
  }
  
  public void onResume() {
    super.onResume();
    if (i()) {
      Uri uri = a.b();
      int i = this.t0;
      this.t0 = Integer.MIN_VALUE;
      a.a();
      if (uri != null) {
        k(i, a.t0, uri);
        return;
      } 
      k(i, a.u0, null);
    } 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putInt("com.braintreepayments.browserswitch.EXTRA_REQUEST_CODE", this.t0);
  }
  
  public enum a {
    t0, u0, v0;
    
    private String s0;
    
    static {
      a a1 = new a("OK", 0);
      t0 = a1;
      a a2 = new a("CANCELED", 1);
      u0 = a2;
      a a3 = new a("ERROR", 2);
      v0 = a3;
      w0 = new a[] { a1, a2, a3 };
    }
    
    private a e(String param1String) {
      this.s0 = param1String;
      return this;
    }
    
    public String d() {
      return this.s0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(name());
      stringBuilder.append(" ");
      stringBuilder.append(d());
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a5\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */