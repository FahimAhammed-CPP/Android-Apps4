package a5;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;

public class c {
  public static Intent a(Context paramContext, Intent paramIntent) {
    if (b(paramContext)) {
      Bundle bundle = new Bundle();
      bundle.putBinder("android.support.customtabs.extra.SESSION", null);
      paramIntent.putExtras(bundle);
      paramIntent.addFlags(134250496);
    } 
    return paramIntent;
  }
  
  public static boolean b(Context paramContext) {
    Intent intent = (new Intent("android.support.customtabs.action.CustomTabsService")).setPackage("com.android.chrome");
    a a = new a();
    boolean bool = paramContext.bindService(intent, a, 33);
    paramContext.unbindService(a);
    return bool;
  }
  
  static final class a implements ServiceConnection {
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {}
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a5\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */