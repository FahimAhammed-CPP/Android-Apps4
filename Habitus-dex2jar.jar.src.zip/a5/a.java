package a5;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;

public class a extends Activity {
  private static Uri s0;
  
  public static void a() {
    s0 = null;
  }
  
  public static Uri b() {
    return s0;
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    s0 = null;
    if (getIntent() != null && getIntent().getData() != null)
      s0 = getIntent().getData(); 
    finish();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Habitus-dex2jar.jar!\a5\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */