package com.amazon.ags.auth;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import com.amazon.ags.html5.factory.AGSClientInstanceCoordinator;
import com.amazon.ags.html5.factory.AGSClientInstanceCoordinatorListener;
import com.amazon.ags.html5.util.ClientConfig;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.authorization.api.AmazonAuthorizationManager;
import com.amazon.identity.auth.device.authorization.api.AuthorizationListener;
import com.amazon.identity.auth.device.authorization.api.AuthzConstants;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class AuthManager implements AGSClientInstanceCoordinatorListener {
  private static final String[] GC_GAME_DATA_SCOPE;
  
  private static final String TAG = "GC_" + AuthManager.class.getSimpleName();
  
  private volatile Activity activity;
  
  private AmazonAuthorizationManager authorizationManager;
  
  private final ClientConfig clientConfig;
  
  private String gameId = null;
  
  static {
    GC_GAME_DATA_SCOPE = new String[] { "game_circle:game_data" };
  }
  
  public AuthManager(ClientConfig paramClientConfig) {
    AGSClientInstanceCoordinator.getInstance().addAGSClientInstanceCoordinatorListener(this);
    this.activity = AGSClientInstanceCoordinator.getInstance().getCurrentActivity();
    this.authorizationManager = new AmazonAuthorizationManager((Context)this.activity, null);
    this.clientConfig = paramClientConfig;
  }
  
  private void refreshActivity() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield activity : Landroid/app/Activity;
    //   6: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   9: invokevirtual getCurrentActivity : ()Landroid/app/Activity;
    //   12: if_acmpeq -> 41
    //   15: aload_0
    //   16: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   19: invokevirtual getCurrentActivity : ()Landroid/app/Activity;
    //   22: putfield activity : Landroid/app/Activity;
    //   25: aload_0
    //   26: new com/amazon/identity/auth/device/authorization/api/AmazonAuthorizationManager
    //   29: dup
    //   30: aload_0
    //   31: getfield activity : Landroid/app/Activity;
    //   34: aconst_null
    //   35: invokespecial <init> : (Landroid/content/Context;Landroid/os/Bundle;)V
    //   38: putfield authorizationManager : Lcom/amazon/identity/auth/device/authorization/api/AmazonAuthorizationManager;
    //   41: aload_0
    //   42: monitorexit
    //   43: return
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	41	44	finally
  }
  
  public String getGameId() {
    if (this.gameId == null)
      try {
        refreshActivity();
        this.gameId = this.authorizationManager.getAppId();
      } catch (AuthError authError) {
        Log.e(TAG, "Unable to get game id", (Throwable)authError);
      }  
    return this.gameId;
  }
  
  public boolean isLoggedIn() {
    return (tryGetToken() != null);
  }
  
  public void logout() throws AuthError {
    refreshActivity();
    this.authorizationManager.clearAuthorizationState(null);
  }
  
  public void notifyCurrentActivityChanged(Activity paramActivity) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial refreshActivity : ()V
    //   6: aload_0
    //   7: monitorexit
    //   8: return
    //   9: astore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: aload_1
    //   13: athrow
    // Exception table:
    //   from	to	target	type
    //   2	6	9	finally
  }
  
  public String tryGetToken() {
    refreshActivity();
    Future<Bundle> future = this.authorizationManager.getToken(GC_GAME_DATA_SCOPE, null);
    if (future == null) {
      Log.e(TAG, "getToken returned null.");
      return null;
    } 
    try {
      Bundle bundle = future.get(this.clientConfig.get("AUTH_GET_TOKEN_TIMEOUT_MILLIS"), TimeUnit.MILLISECONDS);
      if (bundle == null) {
        Log.e(TAG, "getToken Future returned null.");
        return null;
      } 
      AuthzConstants.FUTURE_TYPE fUTURE_TYPE = (AuthzConstants.FUTURE_TYPE)bundle.getSerializable(AuthzConstants.BUNDLE_KEY.FUTURE.val);
      if (fUTURE_TYPE == AuthzConstants.FUTURE_TYPE.SUCCESS)
        return bundle.getString(AuthzConstants.BUNDLE_KEY.TOKEN.val); 
      Log.e(TAG, "getToken failed with code " + fUTURE_TYPE);
      return null;
    } catch (InterruptedException interruptedException) {
      Log.e(TAG, "getToken was interrupted", interruptedException);
      return null;
    } catch (ExecutionException executionException) {
      Log.e(TAG, "getToken failed", executionException);
      return null;
    } catch (TimeoutException timeoutException) {
      Log.e(TAG, "getToken timed out", timeoutException);
      return null;
    } 
  }
  
  public void tryLogin(AuthorizationListener paramAuthorizationListener) {
    Bundle bundle = new Bundle();
    bundle.putBoolean(AuthzConstants.BUNDLE_KEY.BROWSER_AUTHORIZATION.val, true);
    refreshActivity();
    this.authorizationManager.authorize(GC_GAME_DATA_SCOPE, bundle, paramAuthorizationListener);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\auth\AuthManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */