package com.amazon.ags.storage;

import java.util.List;
import org.json.JSONObject;

public interface OfflineDataCache {
  void batchRemoveCachedItems(List<String> paramList);
  
  void clear();
  
  List<JSONObject> getAllCacheItems();
  
  JSONObject getCacheItem(String paramString);
  
  List<JSONObject> queryCacheItems(String paramString);
  
  void removeCachedItem(String paramString);
  
  void removeCachedItems(String paramString);
  
  void setCacheItem(OfflineCacheRequest paramOfflineCacheRequest);
  
  void setCacheItem(String paramString1, String paramString2, JSONObject paramJSONObject);
  
  void setCacheItems(List<OfflineCacheRequest> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\OfflineDataCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */