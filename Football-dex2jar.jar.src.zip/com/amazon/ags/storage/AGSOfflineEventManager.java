package com.amazon.ags.storage;

import android.util.Log;
import com.amazon.ags.html5.service.ServiceHelper;
import com.amazon.ags.html5.util.NetworkUtil;
import java.util.UUID;
import org.json.JSONObject;

public class AGSOfflineEventManager implements OfflineEventManager {
  private static final String TAG = "GC_" + AGSOfflineEventManager.class.getSimpleName();
  
  private final NetworkUtil networkUtil;
  
  private final ServiceHelper serviceHelper;
  
  protected final SQLiteOfflineEventStorage storage;
  
  public AGSOfflineEventManager(SQLiteOfflineEventStorage paramSQLiteOfflineEventStorage, NetworkUtil paramNetworkUtil, ServiceHelper paramServiceHelper) {
    this.networkUtil = paramNetworkUtil;
    if (paramSQLiteOfflineEventStorage == null)
      throw new IllegalArgumentException("storage must be non-null."); 
    this.storage = paramSQLiteOfflineEventStorage;
    this.serviceHelper = paramServiceHelper;
  }
  
  public NetworkUtil getNetworkUtil() {
    return this.networkUtil;
  }
  
  public OfflineEventManager.OfflineEventTuple getNextEvent() throws OfflineEventException {
    OfflineEventId offlineEventId = this.storage.peekEvent();
    if (offlineEventId == OfflineEventId.Invalid)
      return null; 
    Log.d(TAG, "Processing event ID: " + offlineEventId.getId());
    try {
      return new OfflineEventManager.OfflineEventTuple(offlineEventId, new OfflineEvent(this.storage.getEvent(offlineEventId)));
    } catch (OfflineEventException offlineEventException) {
      Log.e(TAG, "Failed to process event ID: " + offlineEventId.getId() + ". Removing event. Error: " + offlineEventException.toString());
      this.storage.removeEvent(offlineEventId);
      throw offlineEventException;
    } catch (Exception exception) {
      Log.e(TAG, "Error occurred while getting the next event", exception);
      return null;
    } 
  }
  
  public void onPause() {}
  
  public void onResume() {}
  
  public void processOfflineEvent(final OfflineEventManager.OfflineEventTuple eventTuple) throws OfflineEventException {
    if (eventTuple != null) {
      OfflineEvent offlineEvent = eventTuple.getOfflineEvent();
      if (offlineEvent != null)
        try {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 34);
          jSONObject.put("jsonEvent", offlineEvent.toJson());
          if (!jSONObject.has("REQUEST_ID"))
            jSONObject.put("REQUEST_ID", UUID.randomUUID().toString()); 
          OfflineEventJSONRequest offlineEventJSONRequest = new OfflineEventJSONRequest(jSONObject, new OfflineEventJSONRequest.OfflineEventJSONCallback() {
                public void onRecoverableError() {}
                
                public void onSuccess() {
                  AGSOfflineEventManager.this.removeEvent(eventTuple.getEventId());
                }
                
                public void onUnrecoverableError() {
                  AGSOfflineEventManager.this.removeEvent(eventTuple.getEventId());
                }
              });
          this.serviceHelper.handleRequestAsync(offlineEventJSONRequest);
          return;
        } catch (Exception exception) {
          Log.e(TAG, "Exception encountered while handling offline event", exception);
          return;
        }  
    } 
  }
  
  public void removeEvent(OfflineEventId paramOfflineEventId) {
    if (paramOfflineEventId == null)
      throw new IllegalArgumentException("id must be non-null."); 
    Log.d(TAG, "submitEvent() called with event ID: " + paramOfflineEventId.getId());
    this.storage.removeEvent(paramOfflineEventId);
  }
  
  public void removeNextEvent() throws OfflineEventException {
    OfflineEventManager.OfflineEventTuple offlineEventTuple = getNextEvent();
    if (offlineEventTuple != null)
      removeEvent(offlineEventTuple.getEventId()); 
  }
  
  public OfflineEventId submitEvent(OfflineEvent paramOfflineEvent) throws OfflineEventException {
    if (paramOfflineEvent == null)
      throw new IllegalArgumentException("event must be non-null."); 
    try {
      JSONObject jSONObject = paramOfflineEvent.toJson();
      OfflineEventId offlineEventId = this.storage.storeEvent(jSONObject);
      Log.d(TAG, "submitEvent() complete. Event ID: " + offlineEventId.getId());
      return offlineEventId;
    } catch (Exception exception) {
      Log.e(TAG, "submitEvent() - Failed to convert event to JSON due to error", exception);
      throw new OfflineEventException(exception);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\AGSOfflineEventManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */