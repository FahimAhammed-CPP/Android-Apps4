package com.amazon.ags.storage;

public interface OfflineEventManager {
  OfflineEventTuple getNextEvent() throws OfflineEventException;
  
  void onPause();
  
  void onResume();
  
  void processOfflineEvent(OfflineEventTuple paramOfflineEventTuple) throws OfflineEventException;
  
  void removeEvent(OfflineEventId paramOfflineEventId);
  
  void removeNextEvent() throws OfflineEventException;
  
  OfflineEventId submitEvent(OfflineEvent paramOfflineEvent) throws OfflineEventException;
  
  public static class OfflineEventTuple {
    private final OfflineEvent event;
    
    private final OfflineEventId id;
    
    public OfflineEventTuple(OfflineEventId param1OfflineEventId, OfflineEvent param1OfflineEvent) {
      this.event = param1OfflineEvent;
      this.id = param1OfflineEventId;
    }
    
    public OfflineEventId getEventId() {
      return this.id;
    }
    
    public OfflineEvent getOfflineEvent() {
      return this.event;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\OfflineEventManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */