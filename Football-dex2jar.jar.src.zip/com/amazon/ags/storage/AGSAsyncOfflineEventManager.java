package com.amazon.ags.storage;

import android.text.TextUtils;
import android.util.Log;
import com.amazon.ags.html5.service.ServiceHelper;
import com.amazon.ags.html5.util.GlobalState;
import com.amazon.ags.html5.util.NetworkUtil;
import java.util.concurrent.TimeUnit;

public class AGSAsyncOfflineEventManager extends AGSOfflineEventManager {
  private static final String TAG;
  
  private static final long WORKER_THREAD_SLEEP_TIME_MS = TimeUnit.SECONDS.toMillis(5L);
  
  private final GlobalState globalState;
  
  private Thread worker;
  
  static {
    TAG = "GC_" + AGSAsyncOfflineEventManager.class.getSimpleName();
  }
  
  public AGSAsyncOfflineEventManager(SQLiteOfflineEventStorage paramSQLiteOfflineEventStorage, NetworkUtil paramNetworkUtil, ServiceHelper paramServiceHelper, GlobalState paramGlobalState) {
    super(paramSQLiteOfflineEventStorage, paramNetworkUtil, paramServiceHelper);
    this.globalState = paramGlobalState;
    startWorker();
  }
  
  private void handleWorkerThreadWork() {
    if (this.globalState != null && !TextUtils.isEmpty(this.globalState.getPlayerId()) && getNetworkUtil() != null && getNetworkUtil().isNetworkConnected())
      try {
        OfflineEventManager.OfflineEventTuple offlineEventTuple = getNextEvent();
        if (offlineEventTuple != null)
          processOfflineEvent(offlineEventTuple); 
        return;
      } catch (OfflineEventException offlineEventException) {
        Log.e(TAG, "Failed to process event: ", offlineEventException);
        return;
      }  
  }
  
  private void shutdownWorker() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield worker : Ljava/lang/Thread;
    //   6: ifnull -> 34
    //   9: ldc com/amazon/ags/storage/AGSAsyncOfflineEventManager
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield worker : Ljava/lang/Thread;
    //   16: ifnull -> 31
    //   19: aload_0
    //   20: getfield worker : Ljava/lang/Thread;
    //   23: invokevirtual interrupt : ()V
    //   26: aload_0
    //   27: aconst_null
    //   28: putfield worker : Ljava/lang/Thread;
    //   31: ldc com/amazon/ags/storage/AGSAsyncOfflineEventManager
    //   33: monitorexit
    //   34: aload_0
    //   35: monitorexit
    //   36: return
    //   37: astore_1
    //   38: ldc com/amazon/ags/storage/AGSAsyncOfflineEventManager
    //   40: monitorexit
    //   41: aload_1
    //   42: athrow
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	43	finally
    //   12	31	37	finally
    //   31	34	37	finally
    //   38	41	37	finally
    //   41	43	43	finally
  }
  
  private void startWorker() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield worker : Ljava/lang/Thread;
    //   6: ifnonnull -> 42
    //   9: ldc com/amazon/ags/storage/AGSAsyncOfflineEventManager
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield worker : Ljava/lang/Thread;
    //   16: ifnonnull -> 39
    //   19: aload_0
    //   20: new com/amazon/ags/storage/AGSAsyncOfflineEventManager$WorkerThread
    //   23: dup
    //   24: aload_0
    //   25: aconst_null
    //   26: invokespecial <init> : (Lcom/amazon/ags/storage/AGSAsyncOfflineEventManager;Lcom/amazon/ags/storage/AGSAsyncOfflineEventManager$1;)V
    //   29: putfield worker : Ljava/lang/Thread;
    //   32: aload_0
    //   33: getfield worker : Ljava/lang/Thread;
    //   36: invokevirtual start : ()V
    //   39: ldc com/amazon/ags/storage/AGSAsyncOfflineEventManager
    //   41: monitorexit
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: astore_1
    //   46: ldc com/amazon/ags/storage/AGSAsyncOfflineEventManager
    //   48: monitorexit
    //   49: aload_1
    //   50: athrow
    //   51: astore_1
    //   52: aload_0
    //   53: monitorexit
    //   54: aload_1
    //   55: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	51	finally
    //   12	39	45	finally
    //   39	42	45	finally
    //   46	49	45	finally
    //   49	51	51	finally
  }
  
  public void onPause() {
    super.onPause();
    shutdownWorker();
  }
  
  public void onResume() {
    super.onResume();
    startWorker();
  }
  
  private class WorkerThread extends Thread {
    private WorkerThread() {}
    
    public void run() {
      while (isAlive() && !isInterrupted()) {
        try {
          sleep(AGSAsyncOfflineEventManager.WORKER_THREAD_SLEEP_TIME_MS);
          AGSAsyncOfflineEventManager.this.handleWorkerThreadWork();
        } catch (InterruptedException interruptedException) {
          Thread.currentThread().interrupt();
          break;
        } 
      } 
      Log.d("AGSWorkerThread", "Worker thread died.");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\AGSAsyncOfflineEventManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */