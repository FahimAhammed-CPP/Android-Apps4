package com.amazon.ags.storage;

public class OfflineEventId {
  public static final OfflineEventId Invalid = new OfflineEventId(0L);
  
  private final long id;
  
  public OfflineEventId(long paramLong) {
    this.id = paramLong;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (paramObject != null) {
      if (this == paramObject)
        return true; 
      if (paramObject instanceof OfflineEventId) {
        if (((OfflineEventId)paramObject).id != this.id)
          bool = false; 
        return bool;
      } 
    } 
    return false;
  }
  
  public long getId() {
    return this.id;
  }
  
  public int hashCode() {
    return (int)(this.id ^ this.id >>> 32L);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\OfflineEventId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */