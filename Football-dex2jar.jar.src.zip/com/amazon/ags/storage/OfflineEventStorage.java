package com.amazon.ags.storage;

import java.util.List;
import org.json.JSONObject;

public interface OfflineEventStorage {
  List<OfflineEventJSONTuple> getAllEvents() throws OfflineEventException;
  
  JSONObject getEvent(OfflineEventId paramOfflineEventId) throws OfflineEventException;
  
  int getSize();
  
  OfflineEventId peekEvent();
  
  void removeAllEvents();
  
  void removeEvent(OfflineEventId paramOfflineEventId);
  
  OfflineEventId storeEvent(JSONObject paramJSONObject) throws OfflineEventException;
  
  public static class OfflineEventJSONTuple {
    private final JSONObject event;
    
    private final OfflineEventId id;
    
    public OfflineEventJSONTuple(OfflineEventId param1OfflineEventId, JSONObject param1JSONObject) {
      this.event = param1JSONObject;
      this.id = param1OfflineEventId;
    }
    
    public OfflineEventId getEventId() {
      return this.id;
    }
    
    public JSONObject getJSONOfflineEvent() {
      return this.event;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\OfflineEventStorage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */