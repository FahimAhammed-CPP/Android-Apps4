package com.amazon.ags.storage;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.List;
import org.json.JSONObject;

public class SQLiteOfflineEventStorage extends SQLiteOpenHelper implements OfflineEventStorage {
  private static final int DATABASE_VERSION = 2;
  
  private static final String PRIMARY_KEY_NAME = "id";
  
  private static final String TABLE_NAME = "events";
  
  private static final String TAG = "GC_" + SQLiteOfflineEventStorage.class.getSimpleName();
  
  private static final String TEXT_KEY_NAME = "text";
  
  private final StringObfuscator obfuscator;
  
  public SQLiteOfflineEventStorage(Context paramContext, StringObfuscator paramStringObfuscator, String paramString) {
    super(paramContext, paramString, null, 2);
    this.obfuscator = paramStringObfuscator;
  }
  
  public final List<OfflineEventStorage.OfflineEventJSONTuple> getAllEvents() throws OfflineEventException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore #7
    //   5: aconst_null
    //   6: astore #5
    //   8: aconst_null
    //   9: astore #8
    //   11: aconst_null
    //   12: astore #6
    //   14: aconst_null
    //   15: astore #12
    //   17: aconst_null
    //   18: astore #9
    //   20: aconst_null
    //   21: astore #11
    //   23: aconst_null
    //   24: astore #13
    //   26: aconst_null
    //   27: astore #15
    //   29: aconst_null
    //   30: astore #10
    //   32: aconst_null
    //   33: astore #21
    //   35: aconst_null
    //   36: astore #4
    //   38: aconst_null
    //   39: astore #14
    //   41: aconst_null
    //   42: astore #22
    //   44: aconst_null
    //   45: astore #23
    //   47: aconst_null
    //   48: astore #17
    //   50: aconst_null
    //   51: astore #18
    //   53: aconst_null
    //   54: astore #19
    //   56: aconst_null
    //   57: astore #20
    //   59: aconst_null
    //   60: astore #16
    //   62: new java/util/ArrayList
    //   65: dup
    //   66: invokespecial <init> : ()V
    //   69: astore #24
    //   71: aload #16
    //   73: astore #6
    //   75: aload #10
    //   77: astore #7
    //   79: aload #17
    //   81: astore #8
    //   83: aload #18
    //   85: astore #10
    //   87: aload #19
    //   89: astore #12
    //   91: aload #20
    //   93: astore #14
    //   95: aload_0
    //   96: invokevirtual getReadableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   99: astore #4
    //   101: aload #16
    //   103: astore #6
    //   105: aload #4
    //   107: astore #7
    //   109: aload #17
    //   111: astore #8
    //   113: aload #4
    //   115: astore #9
    //   117: aload #18
    //   119: astore #10
    //   121: aload #4
    //   123: astore #11
    //   125: aload #19
    //   127: astore #12
    //   129: aload #4
    //   131: astore #13
    //   133: aload #20
    //   135: astore #14
    //   137: aload #4
    //   139: astore #15
    //   141: aload #4
    //   143: ldc 'SELECT * FROM events'
    //   145: aconst_null
    //   146: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   149: astore #5
    //   151: aload #5
    //   153: ifnull -> 801
    //   156: aload #5
    //   158: astore #6
    //   160: aload #4
    //   162: astore #7
    //   164: aload #5
    //   166: astore #8
    //   168: aload #4
    //   170: astore #9
    //   172: aload #5
    //   174: astore #10
    //   176: aload #4
    //   178: astore #11
    //   180: aload #5
    //   182: astore #12
    //   184: aload #4
    //   186: astore #13
    //   188: aload #5
    //   190: astore #14
    //   192: aload #4
    //   194: astore #15
    //   196: aload #5
    //   198: invokeinterface moveToFirst : ()Z
    //   203: ifeq -> 801
    //   206: aload #5
    //   208: astore #6
    //   210: aload #4
    //   212: astore #7
    //   214: aload #5
    //   216: astore #8
    //   218: aload #4
    //   220: astore #9
    //   222: aload #5
    //   224: astore #10
    //   226: aload #4
    //   228: astore #11
    //   230: aload #5
    //   232: astore #12
    //   234: aload #4
    //   236: astore #13
    //   238: aload #5
    //   240: astore #14
    //   242: aload #4
    //   244: astore #15
    //   246: aload_0
    //   247: getfield obfuscator : Lcom/amazon/ags/storage/StringObfuscator;
    //   250: ifnull -> 801
    //   253: aload #5
    //   255: astore #6
    //   257: aload #4
    //   259: astore #7
    //   261: aload #5
    //   263: astore #8
    //   265: aload #4
    //   267: astore #9
    //   269: aload #5
    //   271: astore #10
    //   273: aload #4
    //   275: astore #11
    //   277: aload #5
    //   279: astore #12
    //   281: aload #4
    //   283: astore #13
    //   285: aload #5
    //   287: astore #14
    //   289: aload #4
    //   291: astore #15
    //   293: aload #5
    //   295: iconst_0
    //   296: invokeinterface getLong : (I)J
    //   301: lstore_1
    //   302: aload #5
    //   304: astore #6
    //   306: aload #4
    //   308: astore #7
    //   310: aload #5
    //   312: astore #8
    //   314: aload #4
    //   316: astore #9
    //   318: aload #5
    //   320: astore #10
    //   322: aload #4
    //   324: astore #11
    //   326: aload #5
    //   328: astore #12
    //   330: aload #4
    //   332: astore #13
    //   334: aload #5
    //   336: astore #14
    //   338: aload #4
    //   340: astore #15
    //   342: aload #5
    //   344: iconst_1
    //   345: invokeinterface getString : (I)Ljava/lang/String;
    //   350: astore #16
    //   352: aload #5
    //   354: astore #6
    //   356: aload #4
    //   358: astore #7
    //   360: aload #5
    //   362: astore #8
    //   364: aload #4
    //   366: astore #9
    //   368: aload #5
    //   370: astore #10
    //   372: aload #4
    //   374: astore #11
    //   376: aload #5
    //   378: astore #12
    //   380: aload #4
    //   382: astore #13
    //   384: aload #5
    //   386: astore #14
    //   388: aload #4
    //   390: astore #15
    //   392: aload_0
    //   393: getfield obfuscator : Lcom/amazon/ags/storage/StringObfuscator;
    //   396: aload #16
    //   398: invokeinterface unobfuscate : (Ljava/lang/String;)Ljava/lang/String;
    //   403: astore #16
    //   405: aload #16
    //   407: ifnonnull -> 601
    //   410: aload #5
    //   412: astore #6
    //   414: aload #4
    //   416: astore #7
    //   418: aload #5
    //   420: astore #8
    //   422: aload #4
    //   424: astore #9
    //   426: aload #5
    //   428: astore #10
    //   430: aload #4
    //   432: astore #11
    //   434: aload #5
    //   436: astore #12
    //   438: aload #4
    //   440: astore #13
    //   442: aload #5
    //   444: astore #14
    //   446: aload #4
    //   448: astore #15
    //   450: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   453: ldc 'Failed to unobfuscate text.'
    //   455: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   458: pop
    //   459: aload #5
    //   461: astore #6
    //   463: aload #4
    //   465: astore #7
    //   467: aload #5
    //   469: astore #8
    //   471: aload #4
    //   473: astore #9
    //   475: aload #5
    //   477: astore #10
    //   479: aload #4
    //   481: astore #11
    //   483: aload #5
    //   485: astore #12
    //   487: aload #4
    //   489: astore #13
    //   491: aload #5
    //   493: astore #14
    //   495: aload #4
    //   497: astore #15
    //   499: new com/amazon/ags/storage/OfflineEventException
    //   502: dup
    //   503: ldc 'Failed to unobfuscate text.'
    //   505: invokespecial <init> : (Ljava/lang/String;)V
    //   508: athrow
    //   509: astore #8
    //   511: aload #6
    //   513: astore #4
    //   515: aload #7
    //   517: astore #5
    //   519: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   522: new java/lang/StringBuilder
    //   525: dup
    //   526: invokespecial <init> : ()V
    //   529: ldc 'Failed to open SQL database: '
    //   531: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   534: aload #8
    //   536: invokevirtual toString : ()Ljava/lang/String;
    //   539: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   542: invokevirtual toString : ()Ljava/lang/String;
    //   545: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   548: pop
    //   549: aload #6
    //   551: astore #4
    //   553: aload #7
    //   555: astore #5
    //   557: new com/amazon/ags/storage/OfflineEventException
    //   560: dup
    //   561: aload #8
    //   563: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   566: athrow
    //   567: astore #6
    //   569: aload #4
    //   571: ifnull -> 581
    //   574: aload #4
    //   576: invokeinterface close : ()V
    //   581: aload #5
    //   583: ifnull -> 591
    //   586: aload #5
    //   588: invokevirtual close : ()V
    //   591: aload #6
    //   593: athrow
    //   594: astore #4
    //   596: aload_0
    //   597: monitorexit
    //   598: aload #4
    //   600: athrow
    //   601: aload #5
    //   603: astore #6
    //   605: aload #4
    //   607: astore #7
    //   609: aload #5
    //   611: astore #8
    //   613: aload #4
    //   615: astore #9
    //   617: aload #5
    //   619: astore #10
    //   621: aload #4
    //   623: astore #11
    //   625: aload #5
    //   627: astore #12
    //   629: aload #4
    //   631: astore #13
    //   633: aload #5
    //   635: astore #14
    //   637: aload #4
    //   639: astore #15
    //   641: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   644: new java/lang/StringBuilder
    //   647: dup
    //   648: invokespecial <init> : ()V
    //   651: ldc 'GT: eventId: '
    //   653: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   656: lload_1
    //   657: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   660: ldc ', text: '
    //   662: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   665: aload #16
    //   667: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   670: invokevirtual toString : ()Ljava/lang/String;
    //   673: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   676: pop
    //   677: aload #5
    //   679: astore #6
    //   681: aload #4
    //   683: astore #7
    //   685: aload #5
    //   687: astore #8
    //   689: aload #4
    //   691: astore #9
    //   693: aload #5
    //   695: astore #10
    //   697: aload #4
    //   699: astore #11
    //   701: aload #5
    //   703: astore #12
    //   705: aload #4
    //   707: astore #13
    //   709: aload #5
    //   711: astore #14
    //   713: aload #4
    //   715: astore #15
    //   717: aload #24
    //   719: new com/amazon/ags/storage/OfflineEventStorage$OfflineEventJSONTuple
    //   722: dup
    //   723: new com/amazon/ags/storage/OfflineEventId
    //   726: dup
    //   727: lload_1
    //   728: invokespecial <init> : (J)V
    //   731: new org/json/JSONObject
    //   734: dup
    //   735: aload #16
    //   737: invokespecial <init> : (Ljava/lang/String;)V
    //   740: invokespecial <init> : (Lcom/amazon/ags/storage/OfflineEventId;Lorg/json/JSONObject;)V
    //   743: invokeinterface add : (Ljava/lang/Object;)Z
    //   748: pop
    //   749: aload #5
    //   751: astore #6
    //   753: aload #4
    //   755: astore #7
    //   757: aload #5
    //   759: astore #8
    //   761: aload #4
    //   763: astore #9
    //   765: aload #5
    //   767: astore #10
    //   769: aload #4
    //   771: astore #11
    //   773: aload #5
    //   775: astore #12
    //   777: aload #4
    //   779: astore #13
    //   781: aload #5
    //   783: astore #14
    //   785: aload #4
    //   787: astore #15
    //   789: aload #5
    //   791: invokeinterface moveToNext : ()Z
    //   796: istore_3
    //   797: iload_3
    //   798: ifne -> 253
    //   801: aload #5
    //   803: ifnull -> 813
    //   806: aload #5
    //   808: invokeinterface close : ()V
    //   813: aload #4
    //   815: ifnull -> 823
    //   818: aload #4
    //   820: invokevirtual close : ()V
    //   823: aload_0
    //   824: monitorexit
    //   825: aload #24
    //   827: areturn
    //   828: astore #6
    //   830: aload #8
    //   832: astore #15
    //   834: aload #14
    //   836: astore #4
    //   838: aload #15
    //   840: astore #5
    //   842: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   845: new java/lang/StringBuilder
    //   848: dup
    //   849: invokespecial <init> : ()V
    //   852: ldc 'Failed to parse JSON: '
    //   854: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   857: aload #6
    //   859: invokevirtual toString : ()Ljava/lang/String;
    //   862: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   865: invokevirtual toString : ()Ljava/lang/String;
    //   868: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   871: pop
    //   872: aload #14
    //   874: astore #4
    //   876: aload #15
    //   878: astore #5
    //   880: new com/amazon/ags/storage/OfflineEventException
    //   883: dup
    //   884: aload #6
    //   886: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   889: athrow
    //   890: aload #12
    //   892: astore #4
    //   894: aload #13
    //   896: astore #5
    //   898: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   901: new java/lang/StringBuilder
    //   904: dup
    //   905: invokespecial <init> : ()V
    //   908: ldc 'SQL database is in an invalid state: '
    //   910: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   913: aload #6
    //   915: invokevirtual toString : ()Ljava/lang/String;
    //   918: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   921: invokevirtual toString : ()Ljava/lang/String;
    //   924: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   927: pop
    //   928: aload #12
    //   930: astore #4
    //   932: aload #13
    //   934: astore #5
    //   936: new com/amazon/ags/storage/OfflineEventException
    //   939: dup
    //   940: aload #6
    //   942: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   945: athrow
    //   946: aload #10
    //   948: astore #4
    //   950: aload #11
    //   952: astore #5
    //   954: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   957: new java/lang/StringBuilder
    //   960: dup
    //   961: invokespecial <init> : ()V
    //   964: ldc 'Unexepected error/exception: '
    //   966: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   969: aload #6
    //   971: invokevirtual toString : ()Ljava/lang/String;
    //   974: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   977: invokevirtual toString : ()Ljava/lang/String;
    //   980: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   983: pop
    //   984: aload #10
    //   986: astore #4
    //   988: aload #11
    //   990: astore #5
    //   992: new com/amazon/ags/storage/OfflineEventException
    //   995: dup
    //   996: aload #6
    //   998: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   1001: athrow
    //   1002: astore #6
    //   1004: aload #8
    //   1006: astore #4
    //   1008: aload #9
    //   1010: astore #5
    //   1012: goto -> 569
    //   1015: astore #6
    //   1017: goto -> 946
    //   1020: astore #6
    //   1022: goto -> 890
    //   1025: astore #6
    //   1027: goto -> 834
    //   1030: astore #8
    //   1032: aload #21
    //   1034: astore #6
    //   1036: goto -> 511
    //   1039: astore #4
    //   1041: goto -> 596
    //   1044: astore #4
    //   1046: aload #22
    //   1048: astore #12
    //   1050: aload #6
    //   1052: astore #13
    //   1054: aload #4
    //   1056: astore #6
    //   1058: goto -> 890
    //   1061: astore #6
    //   1063: aload #23
    //   1065: astore #10
    //   1067: aload #12
    //   1069: astore #11
    //   1071: goto -> 946
    // Exception table:
    //   from	to	target	type
    //   62	71	1030	android/database/sqlite/SQLiteException
    //   62	71	828	org/json/JSONException
    //   62	71	1044	java/lang/IllegalStateException
    //   62	71	1061	java/lang/Throwable
    //   62	71	567	finally
    //   95	101	509	android/database/sqlite/SQLiteException
    //   95	101	1025	org/json/JSONException
    //   95	101	1020	java/lang/IllegalStateException
    //   95	101	1015	java/lang/Throwable
    //   95	101	1002	finally
    //   141	151	509	android/database/sqlite/SQLiteException
    //   141	151	1025	org/json/JSONException
    //   141	151	1020	java/lang/IllegalStateException
    //   141	151	1015	java/lang/Throwable
    //   141	151	1002	finally
    //   196	206	509	android/database/sqlite/SQLiteException
    //   196	206	1025	org/json/JSONException
    //   196	206	1020	java/lang/IllegalStateException
    //   196	206	1015	java/lang/Throwable
    //   196	206	1002	finally
    //   246	253	509	android/database/sqlite/SQLiteException
    //   246	253	1025	org/json/JSONException
    //   246	253	1020	java/lang/IllegalStateException
    //   246	253	1015	java/lang/Throwable
    //   246	253	1002	finally
    //   293	302	509	android/database/sqlite/SQLiteException
    //   293	302	1025	org/json/JSONException
    //   293	302	1020	java/lang/IllegalStateException
    //   293	302	1015	java/lang/Throwable
    //   293	302	1002	finally
    //   342	352	509	android/database/sqlite/SQLiteException
    //   342	352	1025	org/json/JSONException
    //   342	352	1020	java/lang/IllegalStateException
    //   342	352	1015	java/lang/Throwable
    //   342	352	1002	finally
    //   392	405	509	android/database/sqlite/SQLiteException
    //   392	405	1025	org/json/JSONException
    //   392	405	1020	java/lang/IllegalStateException
    //   392	405	1015	java/lang/Throwable
    //   392	405	1002	finally
    //   450	459	509	android/database/sqlite/SQLiteException
    //   450	459	1025	org/json/JSONException
    //   450	459	1020	java/lang/IllegalStateException
    //   450	459	1015	java/lang/Throwable
    //   450	459	1002	finally
    //   499	509	509	android/database/sqlite/SQLiteException
    //   499	509	1025	org/json/JSONException
    //   499	509	1020	java/lang/IllegalStateException
    //   499	509	1015	java/lang/Throwable
    //   499	509	1002	finally
    //   519	549	567	finally
    //   557	567	567	finally
    //   574	581	594	finally
    //   586	591	594	finally
    //   591	594	594	finally
    //   641	677	509	android/database/sqlite/SQLiteException
    //   641	677	1025	org/json/JSONException
    //   641	677	1020	java/lang/IllegalStateException
    //   641	677	1015	java/lang/Throwable
    //   641	677	1002	finally
    //   717	749	509	android/database/sqlite/SQLiteException
    //   717	749	1025	org/json/JSONException
    //   717	749	1020	java/lang/IllegalStateException
    //   717	749	1015	java/lang/Throwable
    //   717	749	1002	finally
    //   789	797	509	android/database/sqlite/SQLiteException
    //   789	797	1025	org/json/JSONException
    //   789	797	1020	java/lang/IllegalStateException
    //   789	797	1015	java/lang/Throwable
    //   789	797	1002	finally
    //   806	813	1039	finally
    //   818	823	1039	finally
    //   842	872	567	finally
    //   880	890	567	finally
    //   898	928	567	finally
    //   936	946	567	finally
    //   954	984	567	finally
    //   992	1002	567	finally
  }
  
  public final JSONObject getEvent(OfflineEventId paramOfflineEventId) throws OfflineEventException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore #18
    //   5: aconst_null
    //   6: astore #19
    //   8: aconst_null
    //   9: astore #20
    //   11: aconst_null
    //   12: astore #21
    //   14: aconst_null
    //   15: astore #4
    //   17: aconst_null
    //   18: astore #14
    //   20: aconst_null
    //   21: astore #15
    //   23: aconst_null
    //   24: astore #16
    //   26: aconst_null
    //   27: astore #17
    //   29: aconst_null
    //   30: astore #5
    //   32: aload #4
    //   34: astore #6
    //   36: aload #5
    //   38: astore #7
    //   40: aload #18
    //   42: astore_2
    //   43: aload #14
    //   45: astore_3
    //   46: aload #19
    //   48: astore #8
    //   50: aload #15
    //   52: astore #9
    //   54: aload #20
    //   56: astore #10
    //   58: aload #16
    //   60: astore #11
    //   62: aload #21
    //   64: astore #12
    //   66: aload #17
    //   68: astore #13
    //   70: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   73: new java/lang/StringBuilder
    //   76: dup
    //   77: invokespecial <init> : ()V
    //   80: ldc 'getEvent() event id: '
    //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: aload_1
    //   86: invokevirtual getId : ()J
    //   89: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   92: invokevirtual toString : ()Ljava/lang/String;
    //   95: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   98: pop
    //   99: aload #4
    //   101: astore #6
    //   103: aload #5
    //   105: astore #7
    //   107: aload #18
    //   109: astore_2
    //   110: aload #14
    //   112: astore_3
    //   113: aload #19
    //   115: astore #8
    //   117: aload #15
    //   119: astore #9
    //   121: aload #20
    //   123: astore #10
    //   125: aload #16
    //   127: astore #11
    //   129: aload #21
    //   131: astore #12
    //   133: aload #17
    //   135: astore #13
    //   137: aload_0
    //   138: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   141: astore #4
    //   143: aload #4
    //   145: astore #6
    //   147: aload #5
    //   149: astore #7
    //   151: aload #4
    //   153: astore_2
    //   154: aload #14
    //   156: astore_3
    //   157: aload #4
    //   159: astore #8
    //   161: aload #15
    //   163: astore #9
    //   165: aload #4
    //   167: astore #10
    //   169: aload #16
    //   171: astore #11
    //   173: aload #4
    //   175: astore #12
    //   177: aload #17
    //   179: astore #13
    //   181: new java/lang/StringBuilder
    //   184: dup
    //   185: invokespecial <init> : ()V
    //   188: ldc 'id = '
    //   190: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: aload_1
    //   194: invokevirtual getId : ()J
    //   197: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   200: invokevirtual toString : ()Ljava/lang/String;
    //   203: astore #18
    //   205: aload #4
    //   207: astore #6
    //   209: aload #5
    //   211: astore #7
    //   213: aload #4
    //   215: astore_2
    //   216: aload #14
    //   218: astore_3
    //   219: aload #4
    //   221: astore #8
    //   223: aload #15
    //   225: astore #9
    //   227: aload #4
    //   229: astore #10
    //   231: aload #16
    //   233: astore #11
    //   235: aload #4
    //   237: astore #12
    //   239: aload #17
    //   241: astore #13
    //   243: aload #4
    //   245: ldc 'events'
    //   247: iconst_1
    //   248: anewarray java/lang/String
    //   251: dup
    //   252: iconst_0
    //   253: ldc 'text'
    //   255: aastore
    //   256: aload #18
    //   258: aconst_null
    //   259: aconst_null
    //   260: aconst_null
    //   261: aconst_null
    //   262: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   265: astore #5
    //   267: aload #5
    //   269: ifnull -> 720
    //   272: aload #4
    //   274: astore #6
    //   276: aload #5
    //   278: astore #7
    //   280: aload #4
    //   282: astore_2
    //   283: aload #5
    //   285: astore_3
    //   286: aload #4
    //   288: astore #8
    //   290: aload #5
    //   292: astore #9
    //   294: aload #4
    //   296: astore #10
    //   298: aload #5
    //   300: astore #11
    //   302: aload #4
    //   304: astore #12
    //   306: aload #5
    //   308: astore #13
    //   310: aload #5
    //   312: invokeinterface moveToFirst : ()Z
    //   317: ifeq -> 720
    //   320: aload #4
    //   322: astore #6
    //   324: aload #5
    //   326: astore #7
    //   328: aload #4
    //   330: astore_2
    //   331: aload #5
    //   333: astore_3
    //   334: aload #4
    //   336: astore #8
    //   338: aload #5
    //   340: astore #9
    //   342: aload #4
    //   344: astore #10
    //   346: aload #5
    //   348: astore #11
    //   350: aload #4
    //   352: astore #12
    //   354: aload #5
    //   356: astore #13
    //   358: aload #5
    //   360: iconst_0
    //   361: invokeinterface getString : (I)Ljava/lang/String;
    //   366: astore #14
    //   368: aload #4
    //   370: astore #6
    //   372: aload #5
    //   374: astore #7
    //   376: aload #4
    //   378: astore_2
    //   379: aload #5
    //   381: astore_3
    //   382: aload #14
    //   384: astore_1
    //   385: aload #4
    //   387: astore #8
    //   389: aload #5
    //   391: astore #9
    //   393: aload #4
    //   395: astore #10
    //   397: aload #5
    //   399: astore #11
    //   401: aload #4
    //   403: astore #12
    //   405: aload #5
    //   407: astore #13
    //   409: aload_0
    //   410: getfield obfuscator : Lcom/amazon/ags/storage/StringObfuscator;
    //   413: ifnull -> 647
    //   416: aload #4
    //   418: astore #6
    //   420: aload #5
    //   422: astore #7
    //   424: aload #4
    //   426: astore_2
    //   427: aload #5
    //   429: astore_3
    //   430: aload #4
    //   432: astore #8
    //   434: aload #5
    //   436: astore #9
    //   438: aload #4
    //   440: astore #10
    //   442: aload #5
    //   444: astore #11
    //   446: aload #4
    //   448: astore #12
    //   450: aload #5
    //   452: astore #13
    //   454: aload_0
    //   455: getfield obfuscator : Lcom/amazon/ags/storage/StringObfuscator;
    //   458: aload #14
    //   460: invokeinterface unobfuscate : (Ljava/lang/String;)Ljava/lang/String;
    //   465: astore #14
    //   467: aload #14
    //   469: astore_1
    //   470: aload #14
    //   472: ifnonnull -> 647
    //   475: aload #4
    //   477: astore #6
    //   479: aload #5
    //   481: astore #7
    //   483: aload #4
    //   485: astore_2
    //   486: aload #5
    //   488: astore_3
    //   489: aload #4
    //   491: astore #8
    //   493: aload #5
    //   495: astore #9
    //   497: aload #4
    //   499: astore #10
    //   501: aload #5
    //   503: astore #11
    //   505: aload #4
    //   507: astore #12
    //   509: aload #5
    //   511: astore #13
    //   513: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   516: ldc 'Failed to unobfuscate text.'
    //   518: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   521: pop
    //   522: aload #4
    //   524: astore #6
    //   526: aload #5
    //   528: astore #7
    //   530: aload #4
    //   532: astore_2
    //   533: aload #5
    //   535: astore_3
    //   536: aload #4
    //   538: astore #8
    //   540: aload #5
    //   542: astore #9
    //   544: aload #4
    //   546: astore #10
    //   548: aload #5
    //   550: astore #11
    //   552: aload #4
    //   554: astore #12
    //   556: aload #5
    //   558: astore #13
    //   560: new com/amazon/ags/storage/OfflineEventException
    //   563: dup
    //   564: ldc 'Failed to unobfuscate text.'
    //   566: invokespecial <init> : (Ljava/lang/String;)V
    //   569: athrow
    //   570: astore_1
    //   571: aload #6
    //   573: astore_2
    //   574: aload #7
    //   576: astore_3
    //   577: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   580: new java/lang/StringBuilder
    //   583: dup
    //   584: invokespecial <init> : ()V
    //   587: ldc 'Failed to open SQL database: '
    //   589: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   592: aload_1
    //   593: invokevirtual toString : ()Ljava/lang/String;
    //   596: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   599: invokevirtual toString : ()Ljava/lang/String;
    //   602: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   605: pop
    //   606: aload #6
    //   608: astore_2
    //   609: aload #7
    //   611: astore_3
    //   612: new com/amazon/ags/storage/OfflineEventException
    //   615: dup
    //   616: aload_1
    //   617: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   620: athrow
    //   621: astore_1
    //   622: aload_3
    //   623: ifnull -> 632
    //   626: aload_3
    //   627: invokeinterface close : ()V
    //   632: aload_2
    //   633: ifnull -> 640
    //   636: aload_2
    //   637: invokevirtual close : ()V
    //   640: aload_1
    //   641: athrow
    //   642: astore_1
    //   643: aload_0
    //   644: monitorexit
    //   645: aload_1
    //   646: athrow
    //   647: aload #4
    //   649: astore #6
    //   651: aload #5
    //   653: astore #7
    //   655: aload #4
    //   657: astore_2
    //   658: aload #5
    //   660: astore_3
    //   661: aload #4
    //   663: astore #8
    //   665: aload #5
    //   667: astore #9
    //   669: aload #4
    //   671: astore #10
    //   673: aload #5
    //   675: astore #11
    //   677: aload #4
    //   679: astore #12
    //   681: aload #5
    //   683: astore #13
    //   685: new org/json/JSONObject
    //   688: dup
    //   689: aload_1
    //   690: invokespecial <init> : (Ljava/lang/String;)V
    //   693: astore_1
    //   694: aload #5
    //   696: ifnull -> 706
    //   699: aload #5
    //   701: invokeinterface close : ()V
    //   706: aload #4
    //   708: ifnull -> 716
    //   711: aload #4
    //   713: invokevirtual close : ()V
    //   716: aload_0
    //   717: monitorexit
    //   718: aload_1
    //   719: areturn
    //   720: aload #4
    //   722: astore #6
    //   724: aload #5
    //   726: astore #7
    //   728: aload #4
    //   730: astore_2
    //   731: aload #5
    //   733: astore_3
    //   734: aload #4
    //   736: astore #8
    //   738: aload #5
    //   740: astore #9
    //   742: aload #4
    //   744: astore #10
    //   746: aload #5
    //   748: astore #11
    //   750: aload #4
    //   752: astore #12
    //   754: aload #5
    //   756: astore #13
    //   758: new com/amazon/ags/storage/OfflineEventException
    //   761: dup
    //   762: new java/lang/StringBuilder
    //   765: dup
    //   766: invokespecial <init> : ()V
    //   769: ldc 'Failed to get text for id: '
    //   771: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   774: aload_1
    //   775: invokevirtual getId : ()J
    //   778: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   781: invokevirtual toString : ()Ljava/lang/String;
    //   784: invokespecial <init> : (Ljava/lang/String;)V
    //   787: athrow
    //   788: astore_1
    //   789: aload #8
    //   791: astore_2
    //   792: aload #9
    //   794: astore_3
    //   795: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   798: new java/lang/StringBuilder
    //   801: dup
    //   802: invokespecial <init> : ()V
    //   805: ldc 'Failed to parse JSON: '
    //   807: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   810: aload_1
    //   811: invokevirtual toString : ()Ljava/lang/String;
    //   814: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   817: invokevirtual toString : ()Ljava/lang/String;
    //   820: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   823: pop
    //   824: aload #8
    //   826: astore_2
    //   827: aload #9
    //   829: astore_3
    //   830: new com/amazon/ags/storage/OfflineEventException
    //   833: dup
    //   834: aload_1
    //   835: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   838: athrow
    //   839: astore_1
    //   840: aload #10
    //   842: astore_2
    //   843: aload #11
    //   845: astore_3
    //   846: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   849: new java/lang/StringBuilder
    //   852: dup
    //   853: invokespecial <init> : ()V
    //   856: ldc 'SQL database is in an invalid state: '
    //   858: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   861: aload_1
    //   862: invokevirtual toString : ()Ljava/lang/String;
    //   865: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   868: invokevirtual toString : ()Ljava/lang/String;
    //   871: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   874: pop
    //   875: aload #10
    //   877: astore_2
    //   878: aload #11
    //   880: astore_3
    //   881: new com/amazon/ags/storage/OfflineEventException
    //   884: dup
    //   885: aload_1
    //   886: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   889: athrow
    //   890: astore_1
    //   891: aload #12
    //   893: astore_2
    //   894: aload #13
    //   896: astore_3
    //   897: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   900: new java/lang/StringBuilder
    //   903: dup
    //   904: invokespecial <init> : ()V
    //   907: ldc 'Unexepected error/exception: '
    //   909: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   912: aload_1
    //   913: invokevirtual toString : ()Ljava/lang/String;
    //   916: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   919: invokevirtual toString : ()Ljava/lang/String;
    //   922: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   925: pop
    //   926: aload #12
    //   928: astore_2
    //   929: aload #13
    //   931: astore_3
    //   932: new com/amazon/ags/storage/OfflineEventException
    //   935: dup
    //   936: aload_1
    //   937: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   940: athrow
    // Exception table:
    //   from	to	target	type
    //   70	99	570	android/database/sqlite/SQLiteException
    //   70	99	788	org/json/JSONException
    //   70	99	839	java/lang/IllegalStateException
    //   70	99	890	java/lang/Throwable
    //   70	99	621	finally
    //   137	143	570	android/database/sqlite/SQLiteException
    //   137	143	788	org/json/JSONException
    //   137	143	839	java/lang/IllegalStateException
    //   137	143	890	java/lang/Throwable
    //   137	143	621	finally
    //   181	205	570	android/database/sqlite/SQLiteException
    //   181	205	788	org/json/JSONException
    //   181	205	839	java/lang/IllegalStateException
    //   181	205	890	java/lang/Throwable
    //   181	205	621	finally
    //   243	267	570	android/database/sqlite/SQLiteException
    //   243	267	788	org/json/JSONException
    //   243	267	839	java/lang/IllegalStateException
    //   243	267	890	java/lang/Throwable
    //   243	267	621	finally
    //   310	320	570	android/database/sqlite/SQLiteException
    //   310	320	788	org/json/JSONException
    //   310	320	839	java/lang/IllegalStateException
    //   310	320	890	java/lang/Throwable
    //   310	320	621	finally
    //   358	368	570	android/database/sqlite/SQLiteException
    //   358	368	788	org/json/JSONException
    //   358	368	839	java/lang/IllegalStateException
    //   358	368	890	java/lang/Throwable
    //   358	368	621	finally
    //   409	416	570	android/database/sqlite/SQLiteException
    //   409	416	788	org/json/JSONException
    //   409	416	839	java/lang/IllegalStateException
    //   409	416	890	java/lang/Throwable
    //   409	416	621	finally
    //   454	467	570	android/database/sqlite/SQLiteException
    //   454	467	788	org/json/JSONException
    //   454	467	839	java/lang/IllegalStateException
    //   454	467	890	java/lang/Throwable
    //   454	467	621	finally
    //   513	522	570	android/database/sqlite/SQLiteException
    //   513	522	788	org/json/JSONException
    //   513	522	839	java/lang/IllegalStateException
    //   513	522	890	java/lang/Throwable
    //   513	522	621	finally
    //   560	570	570	android/database/sqlite/SQLiteException
    //   560	570	788	org/json/JSONException
    //   560	570	839	java/lang/IllegalStateException
    //   560	570	890	java/lang/Throwable
    //   560	570	621	finally
    //   577	606	621	finally
    //   612	621	621	finally
    //   626	632	642	finally
    //   636	640	642	finally
    //   640	642	642	finally
    //   685	694	570	android/database/sqlite/SQLiteException
    //   685	694	788	org/json/JSONException
    //   685	694	839	java/lang/IllegalStateException
    //   685	694	890	java/lang/Throwable
    //   685	694	621	finally
    //   699	706	642	finally
    //   711	716	642	finally
    //   758	788	570	android/database/sqlite/SQLiteException
    //   758	788	788	org/json/JSONException
    //   758	788	839	java/lang/IllegalStateException
    //   758	788	890	java/lang/Throwable
    //   758	788	621	finally
    //   795	824	621	finally
    //   830	839	621	finally
    //   846	875	621	finally
    //   881	890	621	finally
    //   897	926	621	finally
    //   932	941	621	finally
  }
  
  public final int getSize() {
    // Byte code:
    //   0: iconst_m1
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aconst_null
    //   5: astore #10
    //   7: aconst_null
    //   8: astore #12
    //   10: aconst_null
    //   11: astore #4
    //   13: aconst_null
    //   14: astore #8
    //   16: aconst_null
    //   17: astore #13
    //   19: aconst_null
    //   20: astore #14
    //   22: aconst_null
    //   23: astore #15
    //   25: aconst_null
    //   26: astore #6
    //   28: aload #6
    //   30: astore #7
    //   32: aload #13
    //   34: astore #9
    //   36: aload #14
    //   38: astore #11
    //   40: aload #15
    //   42: astore_3
    //   43: aload_0
    //   44: invokevirtual getReadableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   47: astore #5
    //   49: aload #6
    //   51: astore #7
    //   53: aload #5
    //   55: astore #8
    //   57: aload #13
    //   59: astore #9
    //   61: aload #5
    //   63: astore #10
    //   65: aload #14
    //   67: astore #11
    //   69: aload #5
    //   71: astore #12
    //   73: aload #15
    //   75: astore_3
    //   76: aload #5
    //   78: astore #4
    //   80: aload #5
    //   82: ldc 'SELECT * FROM events'
    //   84: aconst_null
    //   85: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   88: astore #6
    //   90: aload #6
    //   92: astore #7
    //   94: aload #5
    //   96: astore #8
    //   98: aload #6
    //   100: astore #9
    //   102: aload #5
    //   104: astore #10
    //   106: aload #6
    //   108: astore #11
    //   110: aload #5
    //   112: astore #12
    //   114: aload #6
    //   116: astore_3
    //   117: aload #5
    //   119: astore #4
    //   121: aload #6
    //   123: invokeinterface getCount : ()I
    //   128: istore_1
    //   129: iload_1
    //   130: istore_2
    //   131: aload #6
    //   133: ifnull -> 143
    //   136: aload #6
    //   138: invokeinterface close : ()V
    //   143: iload_2
    //   144: istore_1
    //   145: aload #5
    //   147: ifnull -> 157
    //   150: aload #5
    //   152: invokevirtual close : ()V
    //   155: iload_2
    //   156: istore_1
    //   157: aload_0
    //   158: monitorexit
    //   159: iload_1
    //   160: ireturn
    //   161: astore #5
    //   163: aload #7
    //   165: astore_3
    //   166: aload #8
    //   168: astore #4
    //   170: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   173: new java/lang/StringBuilder
    //   176: dup
    //   177: invokespecial <init> : ()V
    //   180: ldc 'Failed to open SQL database: '
    //   182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: aload #5
    //   187: invokevirtual toString : ()Ljava/lang/String;
    //   190: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: invokevirtual toString : ()Ljava/lang/String;
    //   196: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   199: pop
    //   200: aload #7
    //   202: ifnull -> 212
    //   205: aload #7
    //   207: invokeinterface close : ()V
    //   212: iload_2
    //   213: istore_1
    //   214: aload #8
    //   216: ifnull -> 157
    //   219: aload #8
    //   221: invokevirtual close : ()V
    //   224: iload_2
    //   225: istore_1
    //   226: goto -> 157
    //   229: astore_3
    //   230: aload_0
    //   231: monitorexit
    //   232: aload_3
    //   233: athrow
    //   234: astore #5
    //   236: aload #9
    //   238: astore_3
    //   239: aload #10
    //   241: astore #4
    //   243: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   246: new java/lang/StringBuilder
    //   249: dup
    //   250: invokespecial <init> : ()V
    //   253: ldc 'SQL database is in an invalid state: '
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: aload #5
    //   260: invokevirtual toString : ()Ljava/lang/String;
    //   263: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   266: invokevirtual toString : ()Ljava/lang/String;
    //   269: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   272: pop
    //   273: aload #9
    //   275: ifnull -> 285
    //   278: aload #9
    //   280: invokeinterface close : ()V
    //   285: iload_2
    //   286: istore_1
    //   287: aload #10
    //   289: ifnull -> 157
    //   292: aload #10
    //   294: invokevirtual close : ()V
    //   297: iload_2
    //   298: istore_1
    //   299: goto -> 157
    //   302: astore #5
    //   304: aload #11
    //   306: astore_3
    //   307: aload #12
    //   309: astore #4
    //   311: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   314: new java/lang/StringBuilder
    //   317: dup
    //   318: invokespecial <init> : ()V
    //   321: ldc 'Unexepected error/exception: '
    //   323: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   326: aload #5
    //   328: invokevirtual toString : ()Ljava/lang/String;
    //   331: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   334: invokevirtual toString : ()Ljava/lang/String;
    //   337: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   340: pop
    //   341: aload #11
    //   343: ifnull -> 353
    //   346: aload #11
    //   348: invokeinterface close : ()V
    //   353: iload_2
    //   354: istore_1
    //   355: aload #12
    //   357: ifnull -> 157
    //   360: aload #12
    //   362: invokevirtual close : ()V
    //   365: iload_2
    //   366: istore_1
    //   367: goto -> 157
    //   370: astore #5
    //   372: aload_3
    //   373: ifnull -> 382
    //   376: aload_3
    //   377: invokeinterface close : ()V
    //   382: aload #4
    //   384: ifnull -> 392
    //   387: aload #4
    //   389: invokevirtual close : ()V
    //   392: aload #5
    //   394: athrow
    // Exception table:
    //   from	to	target	type
    //   43	49	161	android/database/sqlite/SQLiteException
    //   43	49	234	java/lang/IllegalStateException
    //   43	49	302	java/lang/Throwable
    //   43	49	370	finally
    //   80	90	161	android/database/sqlite/SQLiteException
    //   80	90	234	java/lang/IllegalStateException
    //   80	90	302	java/lang/Throwable
    //   80	90	370	finally
    //   121	129	161	android/database/sqlite/SQLiteException
    //   121	129	234	java/lang/IllegalStateException
    //   121	129	302	java/lang/Throwable
    //   121	129	370	finally
    //   136	143	229	finally
    //   150	155	229	finally
    //   170	200	370	finally
    //   205	212	229	finally
    //   219	224	229	finally
    //   243	273	370	finally
    //   278	285	229	finally
    //   292	297	229	finally
    //   311	341	370	finally
    //   346	353	229	finally
    //   360	365	229	finally
    //   376	382	229	finally
    //   387	392	229	finally
    //   392	395	229	finally
  }
  
  public final void onCreate(SQLiteDatabase paramSQLiteDatabase) {
    paramSQLiteDatabase.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT)");
  }
  
  public final void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS events");
    onCreate(paramSQLiteDatabase);
  }
  
  public final OfflineEventId peekEvent() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore #10
    //   5: aconst_null
    //   6: astore #12
    //   8: aconst_null
    //   9: astore #4
    //   11: aconst_null
    //   12: astore #8
    //   14: aconst_null
    //   15: astore #13
    //   17: aconst_null
    //   18: astore #14
    //   20: aconst_null
    //   21: astore #15
    //   23: aconst_null
    //   24: astore #6
    //   26: aload #6
    //   28: astore #7
    //   30: aload #13
    //   32: astore #9
    //   34: aload #14
    //   36: astore #11
    //   38: aload #15
    //   40: astore_3
    //   41: aload_0
    //   42: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   45: astore #5
    //   47: aload #6
    //   49: astore #7
    //   51: aload #5
    //   53: astore #8
    //   55: aload #13
    //   57: astore #9
    //   59: aload #5
    //   61: astore #10
    //   63: aload #14
    //   65: astore #11
    //   67: aload #5
    //   69: astore #12
    //   71: aload #15
    //   73: astore_3
    //   74: aload #5
    //   76: astore #4
    //   78: aload #5
    //   80: ldc 'SELECT MIN(id) FROM events'
    //   82: aconst_null
    //   83: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   86: astore #6
    //   88: aload #6
    //   90: ifnull -> 325
    //   93: aload #6
    //   95: astore #7
    //   97: aload #5
    //   99: astore #8
    //   101: aload #6
    //   103: astore #9
    //   105: aload #5
    //   107: astore #10
    //   109: aload #6
    //   111: astore #11
    //   113: aload #5
    //   115: astore #12
    //   117: aload #6
    //   119: astore_3
    //   120: aload #5
    //   122: astore #4
    //   124: aload #6
    //   126: invokeinterface moveToFirst : ()Z
    //   131: ifeq -> 325
    //   134: aload #6
    //   136: astore #7
    //   138: aload #5
    //   140: astore #8
    //   142: aload #6
    //   144: astore #9
    //   146: aload #5
    //   148: astore #10
    //   150: aload #6
    //   152: astore #11
    //   154: aload #5
    //   156: astore #12
    //   158: aload #6
    //   160: astore_3
    //   161: aload #5
    //   163: astore #4
    //   165: aload #6
    //   167: iconst_0
    //   168: invokeinterface getLong : (I)J
    //   173: lstore_1
    //   174: lload_1
    //   175: lconst_0
    //   176: lcmp
    //   177: ifne -> 248
    //   180: aload #6
    //   182: astore #7
    //   184: aload #5
    //   186: astore #8
    //   188: aload #6
    //   190: astore #9
    //   192: aload #5
    //   194: astore #10
    //   196: aload #6
    //   198: astore #11
    //   200: aload #5
    //   202: astore #12
    //   204: aload #6
    //   206: astore_3
    //   207: aload #5
    //   209: astore #4
    //   211: getstatic com/amazon/ags/storage/OfflineEventId.Invalid : Lcom/amazon/ags/storage/OfflineEventId;
    //   214: astore #13
    //   216: aload #6
    //   218: ifnull -> 228
    //   221: aload #6
    //   223: invokeinterface close : ()V
    //   228: aload #13
    //   230: astore_3
    //   231: aload #5
    //   233: ifnull -> 244
    //   236: aload #5
    //   238: invokevirtual close : ()V
    //   241: aload #13
    //   243: astore_3
    //   244: aload_0
    //   245: monitorexit
    //   246: aload_3
    //   247: areturn
    //   248: aload #6
    //   250: astore #7
    //   252: aload #5
    //   254: astore #8
    //   256: aload #6
    //   258: astore #9
    //   260: aload #5
    //   262: astore #10
    //   264: aload #6
    //   266: astore #11
    //   268: aload #5
    //   270: astore #12
    //   272: aload #6
    //   274: astore_3
    //   275: aload #5
    //   277: astore #4
    //   279: new com/amazon/ags/storage/OfflineEventId
    //   282: dup
    //   283: lload_1
    //   284: invokespecial <init> : (J)V
    //   287: astore #13
    //   289: aload #6
    //   291: ifnull -> 301
    //   294: aload #6
    //   296: invokeinterface close : ()V
    //   301: aload #13
    //   303: astore_3
    //   304: aload #5
    //   306: ifnull -> 244
    //   309: aload #5
    //   311: invokevirtual close : ()V
    //   314: aload #13
    //   316: astore_3
    //   317: goto -> 244
    //   320: astore_3
    //   321: aload_0
    //   322: monitorexit
    //   323: aload_3
    //   324: athrow
    //   325: aload #6
    //   327: astore #7
    //   329: aload #5
    //   331: astore #8
    //   333: aload #6
    //   335: astore #9
    //   337: aload #5
    //   339: astore #10
    //   341: aload #6
    //   343: astore #11
    //   345: aload #5
    //   347: astore #12
    //   349: aload #6
    //   351: astore_3
    //   352: aload #5
    //   354: astore #4
    //   356: getstatic com/amazon/ags/storage/OfflineEventId.Invalid : Lcom/amazon/ags/storage/OfflineEventId;
    //   359: astore #13
    //   361: aload #6
    //   363: ifnull -> 373
    //   366: aload #6
    //   368: invokeinterface close : ()V
    //   373: aload #13
    //   375: astore_3
    //   376: aload #5
    //   378: ifnull -> 244
    //   381: aload #5
    //   383: invokevirtual close : ()V
    //   386: aload #13
    //   388: astore_3
    //   389: goto -> 244
    //   392: astore #5
    //   394: aload #7
    //   396: astore_3
    //   397: aload #8
    //   399: astore #4
    //   401: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   404: new java/lang/StringBuilder
    //   407: dup
    //   408: invokespecial <init> : ()V
    //   411: ldc 'Failed to open SQL database: '
    //   413: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   416: aload #5
    //   418: invokevirtual toString : ()Ljava/lang/String;
    //   421: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   424: invokevirtual toString : ()Ljava/lang/String;
    //   427: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   430: pop
    //   431: aload #7
    //   433: astore_3
    //   434: aload #8
    //   436: astore #4
    //   438: getstatic com/amazon/ags/storage/OfflineEventId.Invalid : Lcom/amazon/ags/storage/OfflineEventId;
    //   441: astore #5
    //   443: aload #7
    //   445: ifnull -> 455
    //   448: aload #7
    //   450: invokeinterface close : ()V
    //   455: aload #5
    //   457: astore_3
    //   458: aload #8
    //   460: ifnull -> 244
    //   463: aload #8
    //   465: invokevirtual close : ()V
    //   468: aload #5
    //   470: astore_3
    //   471: goto -> 244
    //   474: astore #5
    //   476: aload #9
    //   478: astore_3
    //   479: aload #10
    //   481: astore #4
    //   483: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   486: new java/lang/StringBuilder
    //   489: dup
    //   490: invokespecial <init> : ()V
    //   493: ldc 'SQL database is in an invalid state: '
    //   495: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   498: aload #5
    //   500: invokevirtual toString : ()Ljava/lang/String;
    //   503: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   506: invokevirtual toString : ()Ljava/lang/String;
    //   509: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   512: pop
    //   513: aload #9
    //   515: astore_3
    //   516: aload #10
    //   518: astore #4
    //   520: getstatic com/amazon/ags/storage/OfflineEventId.Invalid : Lcom/amazon/ags/storage/OfflineEventId;
    //   523: astore #5
    //   525: aload #9
    //   527: ifnull -> 537
    //   530: aload #9
    //   532: invokeinterface close : ()V
    //   537: aload #5
    //   539: astore_3
    //   540: aload #10
    //   542: ifnull -> 244
    //   545: aload #10
    //   547: invokevirtual close : ()V
    //   550: aload #5
    //   552: astore_3
    //   553: goto -> 244
    //   556: astore #5
    //   558: aload #11
    //   560: astore_3
    //   561: aload #12
    //   563: astore #4
    //   565: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   568: new java/lang/StringBuilder
    //   571: dup
    //   572: invokespecial <init> : ()V
    //   575: ldc 'Unexepected error/exception: '
    //   577: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   580: aload #5
    //   582: invokevirtual toString : ()Ljava/lang/String;
    //   585: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   588: invokevirtual toString : ()Ljava/lang/String;
    //   591: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   594: pop
    //   595: aload #11
    //   597: astore_3
    //   598: aload #12
    //   600: astore #4
    //   602: getstatic com/amazon/ags/storage/OfflineEventId.Invalid : Lcom/amazon/ags/storage/OfflineEventId;
    //   605: astore #5
    //   607: aload #11
    //   609: ifnull -> 619
    //   612: aload #11
    //   614: invokeinterface close : ()V
    //   619: aload #5
    //   621: astore_3
    //   622: aload #12
    //   624: ifnull -> 244
    //   627: aload #12
    //   629: invokevirtual close : ()V
    //   632: aload #5
    //   634: astore_3
    //   635: goto -> 244
    //   638: astore #5
    //   640: aload_3
    //   641: ifnull -> 650
    //   644: aload_3
    //   645: invokeinterface close : ()V
    //   650: aload #4
    //   652: ifnull -> 660
    //   655: aload #4
    //   657: invokevirtual close : ()V
    //   660: aload #5
    //   662: athrow
    // Exception table:
    //   from	to	target	type
    //   41	47	392	android/database/sqlite/SQLiteException
    //   41	47	474	java/lang/IllegalStateException
    //   41	47	556	java/lang/Throwable
    //   41	47	638	finally
    //   78	88	392	android/database/sqlite/SQLiteException
    //   78	88	474	java/lang/IllegalStateException
    //   78	88	556	java/lang/Throwable
    //   78	88	638	finally
    //   124	134	392	android/database/sqlite/SQLiteException
    //   124	134	474	java/lang/IllegalStateException
    //   124	134	556	java/lang/Throwable
    //   124	134	638	finally
    //   165	174	392	android/database/sqlite/SQLiteException
    //   165	174	474	java/lang/IllegalStateException
    //   165	174	556	java/lang/Throwable
    //   165	174	638	finally
    //   211	216	392	android/database/sqlite/SQLiteException
    //   211	216	474	java/lang/IllegalStateException
    //   211	216	556	java/lang/Throwable
    //   211	216	638	finally
    //   221	228	320	finally
    //   236	241	320	finally
    //   279	289	392	android/database/sqlite/SQLiteException
    //   279	289	474	java/lang/IllegalStateException
    //   279	289	556	java/lang/Throwable
    //   279	289	638	finally
    //   294	301	320	finally
    //   309	314	320	finally
    //   356	361	392	android/database/sqlite/SQLiteException
    //   356	361	474	java/lang/IllegalStateException
    //   356	361	556	java/lang/Throwable
    //   356	361	638	finally
    //   366	373	320	finally
    //   381	386	320	finally
    //   401	431	638	finally
    //   438	443	638	finally
    //   448	455	320	finally
    //   463	468	320	finally
    //   483	513	638	finally
    //   520	525	638	finally
    //   530	537	320	finally
    //   545	550	320	finally
    //   565	595	638	finally
    //   602	607	638	finally
    //   612	619	320	finally
    //   627	632	320	finally
    //   644	650	320	finally
    //   655	660	320	finally
    //   660	663	320	finally
  }
  
  public final void removeAllEvents() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore #4
    //   5: aconst_null
    //   6: astore_3
    //   7: aload_3
    //   8: astore_2
    //   9: aload #4
    //   11: astore_1
    //   12: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   15: ldc 'Removing all events'
    //   17: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   20: pop
    //   21: aload_3
    //   22: astore_2
    //   23: aload #4
    //   25: astore_1
    //   26: aload_0
    //   27: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   30: astore_3
    //   31: aload_3
    //   32: astore_2
    //   33: aload_3
    //   34: astore_1
    //   35: aload_3
    //   36: ldc 'DELETE FROM events'
    //   38: invokevirtual execSQL : (Ljava/lang/String;)V
    //   41: aload_3
    //   42: ifnull -> 49
    //   45: aload_3
    //   46: invokevirtual close : ()V
    //   49: aload_0
    //   50: monitorexit
    //   51: return
    //   52: astore_3
    //   53: aload_2
    //   54: astore_1
    //   55: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   58: new java/lang/StringBuilder
    //   61: dup
    //   62: invokespecial <init> : ()V
    //   65: ldc 'Failed to open SQL database: '
    //   67: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: aload_3
    //   71: invokevirtual toString : ()Ljava/lang/String;
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: invokevirtual toString : ()Ljava/lang/String;
    //   80: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   83: pop
    //   84: aload_2
    //   85: ifnull -> 49
    //   88: aload_2
    //   89: invokevirtual close : ()V
    //   92: goto -> 49
    //   95: astore_1
    //   96: aload_0
    //   97: monitorexit
    //   98: aload_1
    //   99: athrow
    //   100: astore_2
    //   101: aload_1
    //   102: ifnull -> 109
    //   105: aload_1
    //   106: invokevirtual close : ()V
    //   109: aload_2
    //   110: athrow
    // Exception table:
    //   from	to	target	type
    //   12	21	52	android/database/sqlite/SQLiteException
    //   12	21	100	finally
    //   26	31	52	android/database/sqlite/SQLiteException
    //   26	31	100	finally
    //   35	41	52	android/database/sqlite/SQLiteException
    //   35	41	100	finally
    //   45	49	95	finally
    //   55	84	100	finally
    //   88	92	95	finally
    //   105	109	95	finally
    //   109	111	95	finally
  }
  
  public final void removeEvent(OfflineEventId paramOfflineEventId) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore #7
    //   5: aconst_null
    //   6: astore #8
    //   8: aconst_null
    //   9: astore #9
    //   11: aconst_null
    //   12: astore_3
    //   13: aload_3
    //   14: astore #4
    //   16: aload #7
    //   18: astore #5
    //   20: aload #8
    //   22: astore #6
    //   24: aload #9
    //   26: astore_2
    //   27: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   30: new java/lang/StringBuilder
    //   33: dup
    //   34: invokespecial <init> : ()V
    //   37: ldc 'Removing event: '
    //   39: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   42: aload_1
    //   43: invokevirtual getId : ()J
    //   46: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   49: invokevirtual toString : ()Ljava/lang/String;
    //   52: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   55: pop
    //   56: aload_3
    //   57: astore #4
    //   59: aload #7
    //   61: astore #5
    //   63: aload #8
    //   65: astore #6
    //   67: aload #9
    //   69: astore_2
    //   70: aload_0
    //   71: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   74: astore_3
    //   75: aload_3
    //   76: astore #4
    //   78: aload_3
    //   79: astore #5
    //   81: aload_3
    //   82: astore #6
    //   84: aload_3
    //   85: astore_2
    //   86: aload_3
    //   87: ldc 'events'
    //   89: new java/lang/StringBuilder
    //   92: dup
    //   93: invokespecial <init> : ()V
    //   96: ldc 'id='
    //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: aload_1
    //   102: invokevirtual getId : ()J
    //   105: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   108: invokevirtual toString : ()Ljava/lang/String;
    //   111: aconst_null
    //   112: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   115: pop
    //   116: aload_3
    //   117: ifnull -> 124
    //   120: aload_3
    //   121: invokevirtual close : ()V
    //   124: aload_0
    //   125: monitorexit
    //   126: return
    //   127: astore_1
    //   128: aload #4
    //   130: astore_2
    //   131: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   134: new java/lang/StringBuilder
    //   137: dup
    //   138: invokespecial <init> : ()V
    //   141: ldc 'Failed to open SQL database: '
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: aload_1
    //   147: invokevirtual toString : ()Ljava/lang/String;
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: invokevirtual toString : ()Ljava/lang/String;
    //   156: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   159: pop
    //   160: aload #4
    //   162: ifnull -> 124
    //   165: aload #4
    //   167: invokevirtual close : ()V
    //   170: goto -> 124
    //   173: astore_1
    //   174: aload_0
    //   175: monitorexit
    //   176: aload_1
    //   177: athrow
    //   178: astore_1
    //   179: aload #5
    //   181: astore_2
    //   182: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   185: new java/lang/StringBuilder
    //   188: dup
    //   189: invokespecial <init> : ()V
    //   192: ldc 'SQL database is in an invalid state: '
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: aload_1
    //   198: invokevirtual toString : ()Ljava/lang/String;
    //   201: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   204: invokevirtual toString : ()Ljava/lang/String;
    //   207: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   210: pop
    //   211: aload #5
    //   213: ifnull -> 124
    //   216: aload #5
    //   218: invokevirtual close : ()V
    //   221: goto -> 124
    //   224: astore_1
    //   225: aload #6
    //   227: astore_2
    //   228: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   231: new java/lang/StringBuilder
    //   234: dup
    //   235: invokespecial <init> : ()V
    //   238: ldc 'Unexepected error/exception: '
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: aload_1
    //   244: invokevirtual toString : ()Ljava/lang/String;
    //   247: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: invokevirtual toString : ()Ljava/lang/String;
    //   253: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   256: pop
    //   257: aload #6
    //   259: ifnull -> 124
    //   262: aload #6
    //   264: invokevirtual close : ()V
    //   267: goto -> 124
    //   270: astore_1
    //   271: aload_2
    //   272: ifnull -> 279
    //   275: aload_2
    //   276: invokevirtual close : ()V
    //   279: aload_1
    //   280: athrow
    // Exception table:
    //   from	to	target	type
    //   27	56	127	android/database/sqlite/SQLiteException
    //   27	56	178	java/lang/IllegalStateException
    //   27	56	224	java/lang/Throwable
    //   27	56	270	finally
    //   70	75	127	android/database/sqlite/SQLiteException
    //   70	75	178	java/lang/IllegalStateException
    //   70	75	224	java/lang/Throwable
    //   70	75	270	finally
    //   86	116	127	android/database/sqlite/SQLiteException
    //   86	116	178	java/lang/IllegalStateException
    //   86	116	224	java/lang/Throwable
    //   86	116	270	finally
    //   120	124	173	finally
    //   131	160	270	finally
    //   165	170	173	finally
    //   182	211	270	finally
    //   216	221	173	finally
    //   228	257	270	finally
    //   262	267	173	finally
    //   275	279	173	finally
    //   279	281	173	finally
  }
  
  public final OfflineEventId storeEvent(JSONObject paramJSONObject) throws OfflineEventException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore #4
    //   5: aconst_null
    //   6: astore #9
    //   8: aconst_null
    //   9: astore #11
    //   11: aconst_null
    //   12: astore #7
    //   14: aconst_null
    //   15: astore #14
    //   17: aconst_null
    //   18: astore #15
    //   20: aconst_null
    //   21: astore #16
    //   23: aconst_null
    //   24: astore #13
    //   26: aload #13
    //   28: astore #8
    //   30: aload #14
    //   32: astore #5
    //   34: aload #15
    //   36: astore #10
    //   38: aload #16
    //   40: astore #12
    //   42: aload_0
    //   43: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   46: astore #6
    //   48: aload #6
    //   50: astore #7
    //   52: aload #13
    //   54: astore #8
    //   56: aload #6
    //   58: astore #4
    //   60: aload #14
    //   62: astore #5
    //   64: aload #6
    //   66: astore #9
    //   68: aload #15
    //   70: astore #10
    //   72: aload #6
    //   74: astore #11
    //   76: aload #16
    //   78: astore #12
    //   80: aload_1
    //   81: invokevirtual toString : ()Ljava/lang/String;
    //   84: astore #17
    //   86: aload #6
    //   88: astore #7
    //   90: aload #13
    //   92: astore #8
    //   94: aload #6
    //   96: astore #4
    //   98: aload #14
    //   100: astore #5
    //   102: aload #17
    //   104: astore_1
    //   105: aload #6
    //   107: astore #9
    //   109: aload #15
    //   111: astore #10
    //   113: aload #6
    //   115: astore #11
    //   117: aload #16
    //   119: astore #12
    //   121: aload_0
    //   122: getfield obfuscator : Lcom/amazon/ags/storage/StringObfuscator;
    //   125: ifnull -> 347
    //   128: aload #6
    //   130: astore #7
    //   132: aload #13
    //   134: astore #8
    //   136: aload #6
    //   138: astore #4
    //   140: aload #14
    //   142: astore #5
    //   144: aload #6
    //   146: astore #9
    //   148: aload #15
    //   150: astore #10
    //   152: aload #6
    //   154: astore #11
    //   156: aload #16
    //   158: astore #12
    //   160: aload_0
    //   161: getfield obfuscator : Lcom/amazon/ags/storage/StringObfuscator;
    //   164: aload #17
    //   166: invokeinterface obfuscate : (Ljava/lang/String;)Ljava/lang/String;
    //   171: astore #17
    //   173: aload #17
    //   175: astore_1
    //   176: aload #17
    //   178: ifnonnull -> 347
    //   181: aload #6
    //   183: astore #7
    //   185: aload #13
    //   187: astore #8
    //   189: aload #6
    //   191: astore #4
    //   193: aload #14
    //   195: astore #5
    //   197: aload #6
    //   199: astore #9
    //   201: aload #15
    //   203: astore #10
    //   205: aload #6
    //   207: astore #11
    //   209: aload #16
    //   211: astore #12
    //   213: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   216: new java/lang/StringBuilder
    //   219: dup
    //   220: invokespecial <init> : ()V
    //   223: ldc 'Failed to obfuscate text: '
    //   225: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   228: aload #17
    //   230: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   233: invokevirtual toString : ()Ljava/lang/String;
    //   236: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: aload #6
    //   242: astore #7
    //   244: aload #13
    //   246: astore #8
    //   248: aload #6
    //   250: astore #4
    //   252: aload #14
    //   254: astore #5
    //   256: aload #6
    //   258: astore #9
    //   260: aload #15
    //   262: astore #10
    //   264: aload #6
    //   266: astore #11
    //   268: aload #16
    //   270: astore #12
    //   272: new com/amazon/ags/storage/OfflineEventException
    //   275: dup
    //   276: ldc 'Failed to obfuscate text.'
    //   278: invokespecial <init> : (Ljava/lang/String;)V
    //   281: athrow
    //   282: astore_1
    //   283: aload #7
    //   285: astore #4
    //   287: aload #8
    //   289: astore #5
    //   291: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   294: ldc 'Failed to open SQL database.'
    //   296: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   299: pop
    //   300: aload #7
    //   302: astore #4
    //   304: aload #8
    //   306: astore #5
    //   308: new com/amazon/ags/storage/OfflineEventException
    //   311: dup
    //   312: aload_1
    //   313: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   316: athrow
    //   317: astore_1
    //   318: aload #5
    //   320: ifnull -> 330
    //   323: aload #5
    //   325: invokeinterface close : ()V
    //   330: aload #4
    //   332: ifnull -> 340
    //   335: aload #4
    //   337: invokevirtual close : ()V
    //   340: aload_1
    //   341: athrow
    //   342: astore_1
    //   343: aload_0
    //   344: monitorexit
    //   345: aload_1
    //   346: athrow
    //   347: aload #6
    //   349: astore #7
    //   351: aload #13
    //   353: astore #8
    //   355: aload #6
    //   357: astore #4
    //   359: aload #14
    //   361: astore #5
    //   363: aload #6
    //   365: astore #9
    //   367: aload #15
    //   369: astore #10
    //   371: aload #6
    //   373: astore #11
    //   375: aload #16
    //   377: astore #12
    //   379: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   382: new java/lang/StringBuilder
    //   385: dup
    //   386: invokespecial <init> : ()V
    //   389: ldc 'Storing event: '
    //   391: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   394: aload_1
    //   395: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   398: invokevirtual toString : ()Ljava/lang/String;
    //   401: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   404: pop
    //   405: aload #6
    //   407: astore #7
    //   409: aload #13
    //   411: astore #8
    //   413: aload #6
    //   415: astore #4
    //   417: aload #14
    //   419: astore #5
    //   421: aload #6
    //   423: astore #9
    //   425: aload #15
    //   427: astore #10
    //   429: aload #6
    //   431: astore #11
    //   433: aload #16
    //   435: astore #12
    //   437: new android/content/ContentValues
    //   440: dup
    //   441: invokespecial <init> : ()V
    //   444: astore #17
    //   446: aload #6
    //   448: astore #7
    //   450: aload #13
    //   452: astore #8
    //   454: aload #6
    //   456: astore #4
    //   458: aload #14
    //   460: astore #5
    //   462: aload #6
    //   464: astore #9
    //   466: aload #15
    //   468: astore #10
    //   470: aload #6
    //   472: astore #11
    //   474: aload #16
    //   476: astore #12
    //   478: aload #17
    //   480: ldc 'text'
    //   482: aload_1
    //   483: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   486: aload #6
    //   488: astore #7
    //   490: aload #13
    //   492: astore #8
    //   494: aload #6
    //   496: astore #4
    //   498: aload #14
    //   500: astore #5
    //   502: aload #6
    //   504: astore #9
    //   506: aload #15
    //   508: astore #10
    //   510: aload #6
    //   512: astore #11
    //   514: aload #16
    //   516: astore #12
    //   518: aload #6
    //   520: ldc 'events'
    //   522: aconst_null
    //   523: aload #17
    //   525: invokevirtual insert : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   528: lstore_2
    //   529: lload_2
    //   530: ldc2_w -1
    //   533: lcmp
    //   534: ifne -> 677
    //   537: aload #6
    //   539: astore #7
    //   541: aload #13
    //   543: astore #8
    //   545: aload #6
    //   547: astore #4
    //   549: aload #14
    //   551: astore #5
    //   553: aload #6
    //   555: astore #9
    //   557: aload #15
    //   559: astore #10
    //   561: aload #6
    //   563: astore #11
    //   565: aload #16
    //   567: astore #12
    //   569: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   572: ldc_w 'Failed to store event in database.'
    //   575: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   578: pop
    //   579: aload #6
    //   581: astore #7
    //   583: aload #13
    //   585: astore #8
    //   587: aload #6
    //   589: astore #4
    //   591: aload #14
    //   593: astore #5
    //   595: aload #6
    //   597: astore #9
    //   599: aload #15
    //   601: astore #10
    //   603: aload #6
    //   605: astore #11
    //   607: aload #16
    //   609: astore #12
    //   611: new com/amazon/ags/storage/OfflineEventException
    //   614: dup
    //   615: ldc_w 'Failed to store event to database.'
    //   618: invokespecial <init> : (Ljava/lang/String;)V
    //   621: athrow
    //   622: astore_1
    //   623: aload #9
    //   625: astore #4
    //   627: aload #10
    //   629: astore #5
    //   631: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   634: new java/lang/StringBuilder
    //   637: dup
    //   638: invokespecial <init> : ()V
    //   641: ldc 'SQL database is in an invalid state: '
    //   643: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   646: aload_1
    //   647: invokevirtual toString : ()Ljava/lang/String;
    //   650: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   653: invokevirtual toString : ()Ljava/lang/String;
    //   656: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   659: pop
    //   660: aload #9
    //   662: astore #4
    //   664: aload #10
    //   666: astore #5
    //   668: new com/amazon/ags/storage/OfflineEventException
    //   671: dup
    //   672: aload_1
    //   673: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   676: athrow
    //   677: aload #6
    //   679: astore #7
    //   681: aload #13
    //   683: astore #8
    //   685: aload #6
    //   687: astore #4
    //   689: aload #14
    //   691: astore #5
    //   693: aload #6
    //   695: astore #9
    //   697: aload #15
    //   699: astore #10
    //   701: aload #6
    //   703: astore #11
    //   705: aload #16
    //   707: astore #12
    //   709: new java/lang/StringBuilder
    //   712: dup
    //   713: invokespecial <init> : ()V
    //   716: ldc_w 'rowid = '
    //   719: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   722: lload_2
    //   723: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   726: invokevirtual toString : ()Ljava/lang/String;
    //   729: astore_1
    //   730: aload #6
    //   732: astore #7
    //   734: aload #13
    //   736: astore #8
    //   738: aload #6
    //   740: astore #4
    //   742: aload #14
    //   744: astore #5
    //   746: aload #6
    //   748: astore #9
    //   750: aload #15
    //   752: astore #10
    //   754: aload #6
    //   756: astore #11
    //   758: aload #16
    //   760: astore #12
    //   762: aload #6
    //   764: ldc 'events'
    //   766: iconst_1
    //   767: anewarray java/lang/String
    //   770: dup
    //   771: iconst_0
    //   772: ldc 'id'
    //   774: aastore
    //   775: aload_1
    //   776: aconst_null
    //   777: aconst_null
    //   778: aconst_null
    //   779: aconst_null
    //   780: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   783: astore_1
    //   784: aload_1
    //   785: ifnull -> 894
    //   788: aload #6
    //   790: astore #7
    //   792: aload_1
    //   793: astore #8
    //   795: aload #6
    //   797: astore #4
    //   799: aload_1
    //   800: astore #5
    //   802: aload #6
    //   804: astore #9
    //   806: aload_1
    //   807: astore #10
    //   809: aload #6
    //   811: astore #11
    //   813: aload_1
    //   814: astore #12
    //   816: aload_1
    //   817: invokeinterface moveToFirst : ()Z
    //   822: ifeq -> 894
    //   825: aload #6
    //   827: astore #7
    //   829: aload_1
    //   830: astore #8
    //   832: aload #6
    //   834: astore #4
    //   836: aload_1
    //   837: astore #5
    //   839: aload #6
    //   841: astore #9
    //   843: aload_1
    //   844: astore #10
    //   846: aload #6
    //   848: astore #11
    //   850: aload_1
    //   851: astore #12
    //   853: new com/amazon/ags/storage/OfflineEventId
    //   856: dup
    //   857: aload_1
    //   858: iconst_0
    //   859: invokeinterface getLong : (I)J
    //   864: invokespecial <init> : (J)V
    //   867: astore #13
    //   869: aload_1
    //   870: ifnull -> 879
    //   873: aload_1
    //   874: invokeinterface close : ()V
    //   879: aload #6
    //   881: ifnull -> 889
    //   884: aload #6
    //   886: invokevirtual close : ()V
    //   889: aload_0
    //   890: monitorexit
    //   891: aload #13
    //   893: areturn
    //   894: aload #6
    //   896: astore #7
    //   898: aload_1
    //   899: astore #8
    //   901: aload #6
    //   903: astore #4
    //   905: aload_1
    //   906: astore #5
    //   908: aload #6
    //   910: astore #9
    //   912: aload_1
    //   913: astore #10
    //   915: aload #6
    //   917: astore #11
    //   919: aload_1
    //   920: astore #12
    //   922: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   925: ldc_w 'Failed to get cursor to inserted item'
    //   928: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   931: pop
    //   932: aload #6
    //   934: astore #7
    //   936: aload_1
    //   937: astore #8
    //   939: aload #6
    //   941: astore #4
    //   943: aload_1
    //   944: astore #5
    //   946: aload #6
    //   948: astore #9
    //   950: aload_1
    //   951: astore #10
    //   953: aload #6
    //   955: astore #11
    //   957: aload_1
    //   958: astore #12
    //   960: new com/amazon/ags/storage/OfflineEventException
    //   963: dup
    //   964: ldc_w 'Failed to get cursor to inserted item'
    //   967: invokespecial <init> : (Ljava/lang/String;)V
    //   970: athrow
    //   971: astore_1
    //   972: aload #11
    //   974: astore #4
    //   976: aload #12
    //   978: astore #5
    //   980: getstatic com/amazon/ags/storage/SQLiteOfflineEventStorage.TAG : Ljava/lang/String;
    //   983: new java/lang/StringBuilder
    //   986: dup
    //   987: invokespecial <init> : ()V
    //   990: ldc 'Unexepected error/exception: '
    //   992: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   995: aload_1
    //   996: invokevirtual toString : ()Ljava/lang/String;
    //   999: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1002: invokevirtual toString : ()Ljava/lang/String;
    //   1005: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1008: pop
    //   1009: aload #11
    //   1011: astore #4
    //   1013: aload #12
    //   1015: astore #5
    //   1017: new com/amazon/ags/storage/OfflineEventException
    //   1020: dup
    //   1021: aload_1
    //   1022: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   1025: athrow
    // Exception table:
    //   from	to	target	type
    //   42	48	282	android/database/sqlite/SQLiteException
    //   42	48	622	java/lang/IllegalStateException
    //   42	48	971	java/lang/Throwable
    //   42	48	317	finally
    //   80	86	282	android/database/sqlite/SQLiteException
    //   80	86	622	java/lang/IllegalStateException
    //   80	86	971	java/lang/Throwable
    //   80	86	317	finally
    //   121	128	282	android/database/sqlite/SQLiteException
    //   121	128	622	java/lang/IllegalStateException
    //   121	128	971	java/lang/Throwable
    //   121	128	317	finally
    //   160	173	282	android/database/sqlite/SQLiteException
    //   160	173	622	java/lang/IllegalStateException
    //   160	173	971	java/lang/Throwable
    //   160	173	317	finally
    //   213	240	282	android/database/sqlite/SQLiteException
    //   213	240	622	java/lang/IllegalStateException
    //   213	240	971	java/lang/Throwable
    //   213	240	317	finally
    //   272	282	282	android/database/sqlite/SQLiteException
    //   272	282	622	java/lang/IllegalStateException
    //   272	282	971	java/lang/Throwable
    //   272	282	317	finally
    //   291	300	317	finally
    //   308	317	317	finally
    //   323	330	342	finally
    //   335	340	342	finally
    //   340	342	342	finally
    //   379	405	282	android/database/sqlite/SQLiteException
    //   379	405	622	java/lang/IllegalStateException
    //   379	405	971	java/lang/Throwable
    //   379	405	317	finally
    //   437	446	282	android/database/sqlite/SQLiteException
    //   437	446	622	java/lang/IllegalStateException
    //   437	446	971	java/lang/Throwable
    //   437	446	317	finally
    //   478	486	282	android/database/sqlite/SQLiteException
    //   478	486	622	java/lang/IllegalStateException
    //   478	486	971	java/lang/Throwable
    //   478	486	317	finally
    //   518	529	282	android/database/sqlite/SQLiteException
    //   518	529	622	java/lang/IllegalStateException
    //   518	529	971	java/lang/Throwable
    //   518	529	317	finally
    //   569	579	282	android/database/sqlite/SQLiteException
    //   569	579	622	java/lang/IllegalStateException
    //   569	579	971	java/lang/Throwable
    //   569	579	317	finally
    //   611	622	282	android/database/sqlite/SQLiteException
    //   611	622	622	java/lang/IllegalStateException
    //   611	622	971	java/lang/Throwable
    //   611	622	317	finally
    //   631	660	317	finally
    //   668	677	317	finally
    //   709	730	282	android/database/sqlite/SQLiteException
    //   709	730	622	java/lang/IllegalStateException
    //   709	730	971	java/lang/Throwable
    //   709	730	317	finally
    //   762	784	282	android/database/sqlite/SQLiteException
    //   762	784	622	java/lang/IllegalStateException
    //   762	784	971	java/lang/Throwable
    //   762	784	317	finally
    //   816	825	282	android/database/sqlite/SQLiteException
    //   816	825	622	java/lang/IllegalStateException
    //   816	825	971	java/lang/Throwable
    //   816	825	317	finally
    //   853	869	282	android/database/sqlite/SQLiteException
    //   853	869	622	java/lang/IllegalStateException
    //   853	869	971	java/lang/Throwable
    //   853	869	317	finally
    //   873	879	342	finally
    //   884	889	342	finally
    //   922	932	282	android/database/sqlite/SQLiteException
    //   922	932	622	java/lang/IllegalStateException
    //   922	932	971	java/lang/Throwable
    //   922	932	317	finally
    //   960	971	282	android/database/sqlite/SQLiteException
    //   960	971	622	java/lang/IllegalStateException
    //   960	971	971	java/lang/Throwable
    //   960	971	317	finally
    //   980	1009	317	finally
    //   1017	1026	317	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\SQLiteOfflineEventStorage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */