package com.amazon.ags.storage;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class SQLiteOfflineDataCache extends SQLiteOpenHelper implements OfflineDataCache {
  private static final String PRIMARY_KEY_COL = "primary_key";
  
  private static final String SECONDARY_KEY_COL = "secondary_key";
  
  private static final String TAG = "GC_" + SQLiteOfflineDataCache.class.getSimpleName();
  
  private static final String TEXT_COL = "text";
  
  private final String m_DatabaseTableName;
  
  public SQLiteOfflineDataCache(Context paramContext, String paramString, int paramInt) {
    super(paramContext, paramString, null, paramInt);
    this.m_DatabaseTableName = paramString;
  }
  
  private void dropTable(SQLiteDatabase paramSQLiteDatabase) {
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + this.m_DatabaseTableName);
  }
  
  public void batchRemoveCachedItems(List<String> paramList) {
    (new ArrayList<String>()).addAll(paramList);
    SQLiteDatabase sQLiteDatabase3 = null;
    SQLiteDatabase sQLiteDatabase1 = null;
    SQLiteDatabase sQLiteDatabase2 = null;
    try {
      SQLiteDatabase sQLiteDatabase = getWritableDatabase();
      sQLiteDatabase2 = sQLiteDatabase;
      sQLiteDatabase3 = sQLiteDatabase;
      sQLiteDatabase1 = sQLiteDatabase;
      sQLiteDatabase.acquireReference();
      sQLiteDatabase2 = sQLiteDatabase;
      sQLiteDatabase3 = sQLiteDatabase;
      sQLiteDatabase1 = sQLiteDatabase;
      sQLiteDatabase.beginTransaction();
    } catch (SQLiteException sQLiteException) {
      sQLiteDatabase1 = sQLiteDatabase2;
      Log.w(TAG, "batchRemoveCachedItems - Failed to open SQL database.");
      return;
    } catch (IllegalStateException illegalStateException) {
      sQLiteDatabase1 = sQLiteDatabase3;
      Log.w(TAG, "batchRemoveCachedItems - Failed to acquire reference to database: " + illegalStateException.toString());
      return;
    } finally {
      if (sQLiteDatabase1 != null) {
        sQLiteDatabase1.releaseReference();
        sQLiteDatabase1.close();
      } 
    } 
  }
  
  public void clear() {
    SQLiteDatabase sQLiteDatabase2 = null;
    SQLiteDatabase sQLiteDatabase1 = null;
    null = null;
    try {
      SQLiteDatabase sQLiteDatabase = getWritableDatabase();
      null = sQLiteDatabase;
      sQLiteDatabase2 = sQLiteDatabase;
      sQLiteDatabase1 = sQLiteDatabase;
      sQLiteDatabase.acquireReference();
      null = sQLiteDatabase;
      sQLiteDatabase2 = sQLiteDatabase;
      sQLiteDatabase1 = sQLiteDatabase;
      int i = sQLiteDatabase.delete(this.m_DatabaseTableName, "1", null);
      null = sQLiteDatabase;
      sQLiteDatabase2 = sQLiteDatabase;
      sQLiteDatabase1 = sQLiteDatabase;
      Log.d(TAG, "clearing cache for " + this.m_DatabaseTableName + " removed " + i + " rows");
      return;
    } catch (SQLiteException sQLiteException) {
      SQLiteDatabase sQLiteDatabase = null;
      Log.w(TAG, "clear cache - Failed to open SQL database.");
      return;
    } catch (IllegalStateException illegalStateException) {
      sQLiteDatabase1 = sQLiteDatabase2;
      Log.w(TAG, "clear cache - Failed to acquire reference to database: " + illegalStateException.toString());
      return;
    } finally {
      if (sQLiteDatabase1 != null) {
        sQLiteDatabase1.releaseReference();
        sQLiteDatabase1.close();
      } 
    } 
  }
  
  public List<JSONObject> getAllCacheItems() {
    SQLiteException sQLiteException1;
    SQLiteDatabase sQLiteDatabase3 = null;
    SQLiteDatabase sQLiteDatabase1 = null;
    SQLiteDatabase sQLiteDatabase2 = null;
    Cursor cursor4 = null;
    Cursor cursor5 = null;
    Cursor cursor3 = null;
    ArrayList<JSONObject> arrayList = new ArrayList();
    null = cursor3;
    Cursor cursor2 = cursor4;
    Cursor cursor1 = cursor5;
    try {
      SQLiteDatabase sQLiteDatabase = getReadableDatabase();
      null = cursor3;
      sQLiteDatabase2 = sQLiteDatabase;
      cursor2 = cursor4;
      sQLiteDatabase3 = sQLiteDatabase;
      cursor1 = cursor5;
      sQLiteDatabase1 = sQLiteDatabase;
      cursor3 = sQLiteDatabase.rawQuery("SELECT * FROM " + this.m_DatabaseTableName, null);
      if (cursor3 != null) {
        null = cursor3;
        sQLiteDatabase2 = sQLiteDatabase;
        cursor2 = cursor3;
        sQLiteDatabase3 = sQLiteDatabase;
        cursor1 = cursor3;
        sQLiteDatabase1 = sQLiteDatabase;
        if (cursor3.moveToFirst()) {
          boolean bool;
          do {
            null = cursor3;
            sQLiteDatabase2 = sQLiteDatabase;
            cursor2 = cursor3;
            sQLiteDatabase3 = sQLiteDatabase;
            cursor1 = cursor3;
            sQLiteDatabase1 = sQLiteDatabase;
            arrayList.add(new JSONObject(cursor3.getString(2)));
            null = cursor3;
            sQLiteDatabase2 = sQLiteDatabase;
            cursor2 = cursor3;
            sQLiteDatabase3 = sQLiteDatabase;
            cursor1 = cursor3;
            sQLiteDatabase1 = sQLiteDatabase;
            bool = cursor3.moveToNext();
          } while (bool);
        } 
      } 
      return arrayList;
    } catch (SQLiteException sQLiteException2) {
      cursor1 = null;
      sQLiteDatabase1 = sQLiteDatabase2;
      Log.e(TAG, "getAllCacheItems - Failed to open SQL database: " + sQLiteException2.toString());
      return null;
    } catch (JSONException jSONException) {
      sQLiteException1 = sQLiteException2;
      sQLiteDatabase1 = sQLiteDatabase3;
      Log.e(TAG, "getAllCacheItems - Failed to parse JSON: " + jSONException.toString());
      return null;
    } finally {
      if (sQLiteException1 != null)
        sQLiteException1.close(); 
      if (sQLiteDatabase1 != null)
        sQLiteDatabase1.close(); 
    } 
  }
  
  public JSONObject getCacheItem(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/ArrayList
    //   5: dup
    //   6: invokespecial <init> : ()V
    //   9: aload_1
    //   10: invokeinterface add : (Ljava/lang/Object;)Z
    //   15: pop
    //   16: aload_1
    //   17: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   20: ifeq -> 38
    //   23: new java/lang/IllegalArgumentException
    //   26: dup
    //   27: ldc 'primaryKey is not valid'
    //   29: invokespecial <init> : (Ljava/lang/String;)V
    //   32: athrow
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    //   38: aconst_null
    //   39: astore #15
    //   41: aconst_null
    //   42: astore #16
    //   44: aconst_null
    //   45: astore #17
    //   47: aconst_null
    //   48: astore #4
    //   50: aconst_null
    //   51: astore #12
    //   53: aconst_null
    //   54: astore #13
    //   56: aconst_null
    //   57: astore #14
    //   59: aconst_null
    //   60: astore #11
    //   62: aload #4
    //   64: astore #5
    //   66: aload #11
    //   68: astore #6
    //   70: aload #15
    //   72: astore #7
    //   74: aload #12
    //   76: astore #8
    //   78: aload #16
    //   80: astore #9
    //   82: aload #13
    //   84: astore #10
    //   86: aload #17
    //   88: astore_2
    //   89: aload #14
    //   91: astore_3
    //   92: invokestatic isDebugLoggingEnabled : ()Z
    //   95: ifeq -> 159
    //   98: aload #4
    //   100: astore #5
    //   102: aload #11
    //   104: astore #6
    //   106: aload #15
    //   108: astore #7
    //   110: aload #12
    //   112: astore #8
    //   114: aload #16
    //   116: astore #9
    //   118: aload #13
    //   120: astore #10
    //   122: aload #17
    //   124: astore_2
    //   125: aload #14
    //   127: astore_3
    //   128: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   131: new java/lang/StringBuilder
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: ldc 'getCacheItem - primaryKey('
    //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: aload_1
    //   144: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   147: ldc ')'
    //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: invokevirtual toString : ()Ljava/lang/String;
    //   155: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   158: pop
    //   159: aload #4
    //   161: astore #5
    //   163: aload #11
    //   165: astore #6
    //   167: aload #15
    //   169: astore #7
    //   171: aload #12
    //   173: astore #8
    //   175: aload #16
    //   177: astore #9
    //   179: aload #13
    //   181: astore #10
    //   183: aload #17
    //   185: astore_2
    //   186: aload #14
    //   188: astore_3
    //   189: aload_0
    //   190: invokevirtual getReadableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   193: astore #4
    //   195: aload #4
    //   197: astore #5
    //   199: aload #11
    //   201: astore #6
    //   203: aload #4
    //   205: astore #7
    //   207: aload #12
    //   209: astore #8
    //   211: aload #4
    //   213: astore #9
    //   215: aload #13
    //   217: astore #10
    //   219: aload #4
    //   221: astore_2
    //   222: aload #14
    //   224: astore_3
    //   225: aload #4
    //   227: invokevirtual acquireReference : ()V
    //   230: aload #4
    //   232: astore #5
    //   234: aload #11
    //   236: astore #6
    //   238: aload #4
    //   240: astore #7
    //   242: aload #12
    //   244: astore #8
    //   246: aload #4
    //   248: astore #9
    //   250: aload #13
    //   252: astore #10
    //   254: aload #4
    //   256: astore_2
    //   257: aload #14
    //   259: astore_3
    //   260: aload_0
    //   261: getfield m_DatabaseTableName : Ljava/lang/String;
    //   264: astore #15
    //   266: aload #4
    //   268: astore #5
    //   270: aload #11
    //   272: astore #6
    //   274: aload #4
    //   276: astore #7
    //   278: aload #12
    //   280: astore #8
    //   282: aload #4
    //   284: astore #9
    //   286: aload #13
    //   288: astore #10
    //   290: aload #4
    //   292: astore_2
    //   293: aload #14
    //   295: astore_3
    //   296: new java/lang/StringBuilder
    //   299: dup
    //   300: invokespecial <init> : ()V
    //   303: ldc 'primary_key=''
    //   305: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   308: aload_1
    //   309: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   312: ldc '''
    //   314: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: invokevirtual toString : ()Ljava/lang/String;
    //   320: astore_1
    //   321: aload #4
    //   323: astore #5
    //   325: aload #11
    //   327: astore #6
    //   329: aload #4
    //   331: astore #7
    //   333: aload #12
    //   335: astore #8
    //   337: aload #4
    //   339: astore #9
    //   341: aload #13
    //   343: astore #10
    //   345: aload #4
    //   347: astore_2
    //   348: aload #14
    //   350: astore_3
    //   351: aload #4
    //   353: aload #15
    //   355: iconst_1
    //   356: anewarray java/lang/String
    //   359: dup
    //   360: iconst_0
    //   361: ldc 'text'
    //   363: aastore
    //   364: aload_1
    //   365: aconst_null
    //   366: aconst_null
    //   367: aconst_null
    //   368: aconst_null
    //   369: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   372: astore_1
    //   373: aload_1
    //   374: ifnull -> 489
    //   377: aload #4
    //   379: astore #5
    //   381: aload_1
    //   382: astore #6
    //   384: aload #4
    //   386: astore #7
    //   388: aload_1
    //   389: astore #8
    //   391: aload #4
    //   393: astore #9
    //   395: aload_1
    //   396: astore #10
    //   398: aload #4
    //   400: astore_2
    //   401: aload_1
    //   402: astore_3
    //   403: aload_1
    //   404: invokeinterface moveToFirst : ()Z
    //   409: ifeq -> 489
    //   412: aload #4
    //   414: astore #5
    //   416: aload_1
    //   417: astore #6
    //   419: aload #4
    //   421: astore #7
    //   423: aload_1
    //   424: astore #8
    //   426: aload #4
    //   428: astore #9
    //   430: aload_1
    //   431: astore #10
    //   433: aload #4
    //   435: astore_2
    //   436: aload_1
    //   437: astore_3
    //   438: new org/json/JSONObject
    //   441: dup
    //   442: aload_1
    //   443: iconst_0
    //   444: invokeinterface getString : (I)Ljava/lang/String;
    //   449: invokespecial <init> : (Ljava/lang/String;)V
    //   452: astore #11
    //   454: aload_1
    //   455: ifnull -> 464
    //   458: aload_1
    //   459: invokeinterface close : ()V
    //   464: aload #11
    //   466: astore_1
    //   467: aload #4
    //   469: ifnull -> 485
    //   472: aload #4
    //   474: invokevirtual releaseReference : ()V
    //   477: aload #4
    //   479: invokevirtual close : ()V
    //   482: aload #11
    //   484: astore_1
    //   485: aload_0
    //   486: monitorexit
    //   487: aload_1
    //   488: areturn
    //   489: aload_1
    //   490: ifnull -> 499
    //   493: aload_1
    //   494: invokeinterface close : ()V
    //   499: aload #4
    //   501: ifnull -> 514
    //   504: aload #4
    //   506: invokevirtual releaseReference : ()V
    //   509: aload #4
    //   511: invokevirtual close : ()V
    //   514: aconst_null
    //   515: astore_1
    //   516: goto -> 485
    //   519: astore_1
    //   520: aload #5
    //   522: astore_2
    //   523: aload #6
    //   525: astore_3
    //   526: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   529: new java/lang/StringBuilder
    //   532: dup
    //   533: invokespecial <init> : ()V
    //   536: ldc 'getCacheItem - Failed to open SQL database: '
    //   538: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   541: aload_1
    //   542: invokevirtual toString : ()Ljava/lang/String;
    //   545: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   548: invokevirtual toString : ()Ljava/lang/String;
    //   551: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   554: pop
    //   555: aload #6
    //   557: ifnull -> 567
    //   560: aload #6
    //   562: invokeinterface close : ()V
    //   567: aload #5
    //   569: ifnull -> 582
    //   572: aload #5
    //   574: invokevirtual releaseReference : ()V
    //   577: aload #5
    //   579: invokevirtual close : ()V
    //   582: aconst_null
    //   583: astore_1
    //   584: goto -> 485
    //   587: astore_1
    //   588: aload #7
    //   590: astore_2
    //   591: aload #8
    //   593: astore_3
    //   594: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   597: new java/lang/StringBuilder
    //   600: dup
    //   601: invokespecial <init> : ()V
    //   604: ldc 'getCacheItem - Failed to parse JSON: '
    //   606: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   609: aload_1
    //   610: invokevirtual toString : ()Ljava/lang/String;
    //   613: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   616: invokevirtual toString : ()Ljava/lang/String;
    //   619: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   622: pop
    //   623: aload #8
    //   625: ifnull -> 635
    //   628: aload #8
    //   630: invokeinterface close : ()V
    //   635: aload #7
    //   637: ifnull -> 650
    //   640: aload #7
    //   642: invokevirtual releaseReference : ()V
    //   645: aload #7
    //   647: invokevirtual close : ()V
    //   650: aconst_null
    //   651: astore_1
    //   652: goto -> 485
    //   655: astore_1
    //   656: aload #9
    //   658: astore_2
    //   659: aload #10
    //   661: astore_3
    //   662: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   665: new java/lang/StringBuilder
    //   668: dup
    //   669: invokespecial <init> : ()V
    //   672: ldc 'getCacheItem - Failed to acquire reference to database: '
    //   674: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   677: aload_1
    //   678: invokevirtual toString : ()Ljava/lang/String;
    //   681: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   684: invokevirtual toString : ()Ljava/lang/String;
    //   687: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   690: pop
    //   691: aload #10
    //   693: ifnull -> 703
    //   696: aload #10
    //   698: invokeinterface close : ()V
    //   703: aload #9
    //   705: ifnull -> 746
    //   708: aload #9
    //   710: invokevirtual releaseReference : ()V
    //   713: aload #9
    //   715: invokevirtual close : ()V
    //   718: goto -> 746
    //   721: astore_1
    //   722: aload_3
    //   723: ifnull -> 732
    //   726: aload_3
    //   727: invokeinterface close : ()V
    //   732: aload_2
    //   733: ifnull -> 744
    //   736: aload_2
    //   737: invokevirtual releaseReference : ()V
    //   740: aload_2
    //   741: invokevirtual close : ()V
    //   744: aload_1
    //   745: athrow
    //   746: aconst_null
    //   747: astore_1
    //   748: goto -> 485
    // Exception table:
    //   from	to	target	type
    //   2	33	33	finally
    //   92	98	519	android/database/sqlite/SQLiteException
    //   92	98	587	org/json/JSONException
    //   92	98	655	java/lang/IllegalStateException
    //   92	98	721	finally
    //   128	159	519	android/database/sqlite/SQLiteException
    //   128	159	587	org/json/JSONException
    //   128	159	655	java/lang/IllegalStateException
    //   128	159	721	finally
    //   189	195	519	android/database/sqlite/SQLiteException
    //   189	195	587	org/json/JSONException
    //   189	195	655	java/lang/IllegalStateException
    //   189	195	721	finally
    //   225	230	519	android/database/sqlite/SQLiteException
    //   225	230	587	org/json/JSONException
    //   225	230	655	java/lang/IllegalStateException
    //   225	230	721	finally
    //   260	266	519	android/database/sqlite/SQLiteException
    //   260	266	587	org/json/JSONException
    //   260	266	655	java/lang/IllegalStateException
    //   260	266	721	finally
    //   296	321	519	android/database/sqlite/SQLiteException
    //   296	321	587	org/json/JSONException
    //   296	321	655	java/lang/IllegalStateException
    //   296	321	721	finally
    //   351	373	519	android/database/sqlite/SQLiteException
    //   351	373	587	org/json/JSONException
    //   351	373	655	java/lang/IllegalStateException
    //   351	373	721	finally
    //   403	412	519	android/database/sqlite/SQLiteException
    //   403	412	587	org/json/JSONException
    //   403	412	655	java/lang/IllegalStateException
    //   403	412	721	finally
    //   438	454	519	android/database/sqlite/SQLiteException
    //   438	454	587	org/json/JSONException
    //   438	454	655	java/lang/IllegalStateException
    //   438	454	721	finally
    //   458	464	33	finally
    //   472	482	33	finally
    //   493	499	33	finally
    //   504	514	33	finally
    //   526	555	721	finally
    //   560	567	33	finally
    //   572	582	33	finally
    //   594	623	721	finally
    //   628	635	33	finally
    //   640	650	33	finally
    //   662	691	721	finally
    //   696	703	33	finally
    //   708	718	33	finally
    //   726	732	33	finally
    //   736	744	33	finally
    //   744	746	33	finally
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase) {
    paramSQLiteDatabase.execSQL(String.format("CREATE TABLE " + this.m_DatabaseTableName + " (" + "primary_key" + " TEXT PRIMARY KEY ON CONFLICT REPLACE, " + "secondary_key" + " TEXT, " + "text" + " TEXT);", new Object[] { this.m_DatabaseTableName }));
  }
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
    dropTable(paramSQLiteDatabase);
    onCreate(paramSQLiteDatabase);
  }
  
  public List<JSONObject> queryCacheItems(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: ifeq -> 25
    //   9: new java/lang/IllegalArgumentException
    //   12: dup
    //   13: ldc_w 'secondaryKey is invalid'
    //   16: invokespecial <init> : (Ljava/lang/String;)V
    //   19: athrow
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    //   25: new java/util/ArrayList
    //   28: dup
    //   29: invokespecial <init> : ()V
    //   32: aload_1
    //   33: invokeinterface add : (Ljava/lang/Object;)Z
    //   38: pop
    //   39: aconst_null
    //   40: astore #15
    //   42: aconst_null
    //   43: astore #16
    //   45: aconst_null
    //   46: astore #17
    //   48: aconst_null
    //   49: astore #4
    //   51: aconst_null
    //   52: astore #12
    //   54: aconst_null
    //   55: astore #13
    //   57: aconst_null
    //   58: astore #14
    //   60: aconst_null
    //   61: astore #11
    //   63: aload #4
    //   65: astore #5
    //   67: aload #11
    //   69: astore #6
    //   71: aload #15
    //   73: astore #7
    //   75: aload #12
    //   77: astore #8
    //   79: aload #16
    //   81: astore #9
    //   83: aload #13
    //   85: astore #10
    //   87: aload #17
    //   89: astore_2
    //   90: aload #14
    //   92: astore_3
    //   93: invokestatic isDebugLoggingEnabled : ()Z
    //   96: ifeq -> 161
    //   99: aload #4
    //   101: astore #5
    //   103: aload #11
    //   105: astore #6
    //   107: aload #15
    //   109: astore #7
    //   111: aload #12
    //   113: astore #8
    //   115: aload #16
    //   117: astore #9
    //   119: aload #13
    //   121: astore #10
    //   123: aload #17
    //   125: astore_2
    //   126: aload #14
    //   128: astore_3
    //   129: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   132: new java/lang/StringBuilder
    //   135: dup
    //   136: invokespecial <init> : ()V
    //   139: ldc_w 'queryCacheItems - secondaryKey('
    //   142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: aload_1
    //   146: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: ldc ')'
    //   151: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: invokevirtual toString : ()Ljava/lang/String;
    //   157: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   160: pop
    //   161: aload #4
    //   163: astore #5
    //   165: aload #11
    //   167: astore #6
    //   169: aload #15
    //   171: astore #7
    //   173: aload #12
    //   175: astore #8
    //   177: aload #16
    //   179: astore #9
    //   181: aload #13
    //   183: astore #10
    //   185: aload #17
    //   187: astore_2
    //   188: aload #14
    //   190: astore_3
    //   191: aload_0
    //   192: invokevirtual getReadableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   195: astore #4
    //   197: aload #4
    //   199: astore #5
    //   201: aload #11
    //   203: astore #6
    //   205: aload #4
    //   207: astore #7
    //   209: aload #12
    //   211: astore #8
    //   213: aload #4
    //   215: astore #9
    //   217: aload #13
    //   219: astore #10
    //   221: aload #4
    //   223: astore_2
    //   224: aload #14
    //   226: astore_3
    //   227: aload #4
    //   229: invokevirtual acquireReference : ()V
    //   232: aload #4
    //   234: astore #5
    //   236: aload #11
    //   238: astore #6
    //   240: aload #4
    //   242: astore #7
    //   244: aload #12
    //   246: astore #8
    //   248: aload #4
    //   250: astore #9
    //   252: aload #13
    //   254: astore #10
    //   256: aload #4
    //   258: astore_2
    //   259: aload #14
    //   261: astore_3
    //   262: aload_0
    //   263: getfield m_DatabaseTableName : Ljava/lang/String;
    //   266: astore #15
    //   268: aload #4
    //   270: astore #5
    //   272: aload #11
    //   274: astore #6
    //   276: aload #4
    //   278: astore #7
    //   280: aload #12
    //   282: astore #8
    //   284: aload #4
    //   286: astore #9
    //   288: aload #13
    //   290: astore #10
    //   292: aload #4
    //   294: astore_2
    //   295: aload #14
    //   297: astore_3
    //   298: new java/lang/StringBuilder
    //   301: dup
    //   302: invokespecial <init> : ()V
    //   305: ldc 'secondary_key=''
    //   307: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   310: aload_1
    //   311: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   314: ldc '''
    //   316: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   319: invokevirtual toString : ()Ljava/lang/String;
    //   322: astore_1
    //   323: aload #4
    //   325: astore #5
    //   327: aload #11
    //   329: astore #6
    //   331: aload #4
    //   333: astore #7
    //   335: aload #12
    //   337: astore #8
    //   339: aload #4
    //   341: astore #9
    //   343: aload #13
    //   345: astore #10
    //   347: aload #4
    //   349: astore_2
    //   350: aload #14
    //   352: astore_3
    //   353: aload #4
    //   355: aload #15
    //   357: iconst_1
    //   358: anewarray java/lang/String
    //   361: dup
    //   362: iconst_0
    //   363: ldc 'text'
    //   365: aastore
    //   366: aload_1
    //   367: aconst_null
    //   368: aconst_null
    //   369: aconst_null
    //   370: aconst_null
    //   371: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   374: astore_1
    //   375: aload_1
    //   376: ifnull -> 678
    //   379: aload #4
    //   381: astore #5
    //   383: aload_1
    //   384: astore #6
    //   386: aload #4
    //   388: astore #7
    //   390: aload_1
    //   391: astore #8
    //   393: aload #4
    //   395: astore #9
    //   397: aload_1
    //   398: astore #10
    //   400: aload #4
    //   402: astore_2
    //   403: aload_1
    //   404: astore_3
    //   405: aload_1
    //   406: invokeinterface moveToFirst : ()Z
    //   411: ifeq -> 678
    //   414: aload #4
    //   416: astore #5
    //   418: aload_1
    //   419: astore #6
    //   421: aload #4
    //   423: astore #7
    //   425: aload_1
    //   426: astore #8
    //   428: aload #4
    //   430: astore #9
    //   432: aload_1
    //   433: astore #10
    //   435: aload #4
    //   437: astore_2
    //   438: aload_1
    //   439: astore_3
    //   440: new java/util/ArrayList
    //   443: dup
    //   444: aload_1
    //   445: invokeinterface getCount : ()I
    //   450: invokespecial <init> : (I)V
    //   453: astore #11
    //   455: aload #4
    //   457: astore #5
    //   459: aload_1
    //   460: astore #6
    //   462: aload #4
    //   464: astore #7
    //   466: aload_1
    //   467: astore #8
    //   469: aload #4
    //   471: astore #9
    //   473: aload_1
    //   474: astore #10
    //   476: aload #4
    //   478: astore_2
    //   479: aload_1
    //   480: astore_3
    //   481: aload_1
    //   482: invokeinterface isAfterLast : ()Z
    //   487: ifne -> 644
    //   490: aload #4
    //   492: astore #5
    //   494: aload_1
    //   495: astore #6
    //   497: aload #4
    //   499: astore #7
    //   501: aload_1
    //   502: astore #8
    //   504: aload #4
    //   506: astore #9
    //   508: aload_1
    //   509: astore #10
    //   511: aload #4
    //   513: astore_2
    //   514: aload_1
    //   515: astore_3
    //   516: aload #11
    //   518: new org/json/JSONObject
    //   521: dup
    //   522: aload_1
    //   523: iconst_0
    //   524: invokeinterface getString : (I)Ljava/lang/String;
    //   529: invokespecial <init> : (Ljava/lang/String;)V
    //   532: invokeinterface add : (Ljava/lang/Object;)Z
    //   537: pop
    //   538: aload #4
    //   540: astore #5
    //   542: aload_1
    //   543: astore #6
    //   545: aload #4
    //   547: astore #7
    //   549: aload_1
    //   550: astore #8
    //   552: aload #4
    //   554: astore #9
    //   556: aload_1
    //   557: astore #10
    //   559: aload #4
    //   561: astore_2
    //   562: aload_1
    //   563: astore_3
    //   564: aload_1
    //   565: invokeinterface moveToNext : ()Z
    //   570: pop
    //   571: goto -> 455
    //   574: astore_1
    //   575: aload #5
    //   577: astore_2
    //   578: aload #6
    //   580: astore_3
    //   581: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   584: new java/lang/StringBuilder
    //   587: dup
    //   588: invokespecial <init> : ()V
    //   591: ldc_w 'queryCacheItems - Failed to open SQL database: '
    //   594: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   597: aload_1
    //   598: invokevirtual toString : ()Ljava/lang/String;
    //   601: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   604: invokevirtual toString : ()Ljava/lang/String;
    //   607: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   610: pop
    //   611: aload #6
    //   613: ifnull -> 623
    //   616: aload #6
    //   618: invokeinterface close : ()V
    //   623: aload #5
    //   625: ifnull -> 638
    //   628: aload #5
    //   630: invokevirtual releaseReference : ()V
    //   633: aload #5
    //   635: invokevirtual close : ()V
    //   638: aconst_null
    //   639: astore_1
    //   640: aload_0
    //   641: monitorexit
    //   642: aload_1
    //   643: areturn
    //   644: aload_1
    //   645: ifnull -> 654
    //   648: aload_1
    //   649: invokeinterface close : ()V
    //   654: aload #11
    //   656: astore_1
    //   657: aload #4
    //   659: ifnull -> 640
    //   662: aload #4
    //   664: invokevirtual releaseReference : ()V
    //   667: aload #4
    //   669: invokevirtual close : ()V
    //   672: aload #11
    //   674: astore_1
    //   675: goto -> 640
    //   678: aload_1
    //   679: ifnull -> 688
    //   682: aload_1
    //   683: invokeinterface close : ()V
    //   688: aload #4
    //   690: ifnull -> 703
    //   693: aload #4
    //   695: invokevirtual releaseReference : ()V
    //   698: aload #4
    //   700: invokevirtual close : ()V
    //   703: aconst_null
    //   704: astore_1
    //   705: goto -> 640
    //   708: astore_1
    //   709: aload #7
    //   711: astore_2
    //   712: aload #8
    //   714: astore_3
    //   715: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   718: new java/lang/StringBuilder
    //   721: dup
    //   722: invokespecial <init> : ()V
    //   725: ldc_w 'queryCacheItems - Failed to parse JSON: '
    //   728: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   731: aload_1
    //   732: invokevirtual toString : ()Ljava/lang/String;
    //   735: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   738: invokevirtual toString : ()Ljava/lang/String;
    //   741: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   744: pop
    //   745: aload #8
    //   747: ifnull -> 757
    //   750: aload #8
    //   752: invokeinterface close : ()V
    //   757: aload #7
    //   759: ifnull -> 772
    //   762: aload #7
    //   764: invokevirtual releaseReference : ()V
    //   767: aload #7
    //   769: invokevirtual close : ()V
    //   772: aconst_null
    //   773: astore_1
    //   774: goto -> 640
    //   777: astore_1
    //   778: aload #9
    //   780: astore_2
    //   781: aload #10
    //   783: astore_3
    //   784: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   787: new java/lang/StringBuilder
    //   790: dup
    //   791: invokespecial <init> : ()V
    //   794: ldc_w 'queryCacheItems - Failed to acquire reference to database: '
    //   797: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   800: aload_1
    //   801: invokevirtual toString : ()Ljava/lang/String;
    //   804: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   807: invokevirtual toString : ()Ljava/lang/String;
    //   810: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   813: pop
    //   814: aload #10
    //   816: ifnull -> 826
    //   819: aload #10
    //   821: invokeinterface close : ()V
    //   826: aload #9
    //   828: ifnull -> 869
    //   831: aload #9
    //   833: invokevirtual releaseReference : ()V
    //   836: aload #9
    //   838: invokevirtual close : ()V
    //   841: goto -> 869
    //   844: astore_1
    //   845: aload_3
    //   846: ifnull -> 855
    //   849: aload_3
    //   850: invokeinterface close : ()V
    //   855: aload_2
    //   856: ifnull -> 867
    //   859: aload_2
    //   860: invokevirtual releaseReference : ()V
    //   863: aload_2
    //   864: invokevirtual close : ()V
    //   867: aload_1
    //   868: athrow
    //   869: aconst_null
    //   870: astore_1
    //   871: goto -> 640
    // Exception table:
    //   from	to	target	type
    //   2	20	20	finally
    //   25	39	20	finally
    //   93	99	574	android/database/sqlite/SQLiteException
    //   93	99	708	org/json/JSONException
    //   93	99	777	java/lang/IllegalStateException
    //   93	99	844	finally
    //   129	161	574	android/database/sqlite/SQLiteException
    //   129	161	708	org/json/JSONException
    //   129	161	777	java/lang/IllegalStateException
    //   129	161	844	finally
    //   191	197	574	android/database/sqlite/SQLiteException
    //   191	197	708	org/json/JSONException
    //   191	197	777	java/lang/IllegalStateException
    //   191	197	844	finally
    //   227	232	574	android/database/sqlite/SQLiteException
    //   227	232	708	org/json/JSONException
    //   227	232	777	java/lang/IllegalStateException
    //   227	232	844	finally
    //   262	268	574	android/database/sqlite/SQLiteException
    //   262	268	708	org/json/JSONException
    //   262	268	777	java/lang/IllegalStateException
    //   262	268	844	finally
    //   298	323	574	android/database/sqlite/SQLiteException
    //   298	323	708	org/json/JSONException
    //   298	323	777	java/lang/IllegalStateException
    //   298	323	844	finally
    //   353	375	574	android/database/sqlite/SQLiteException
    //   353	375	708	org/json/JSONException
    //   353	375	777	java/lang/IllegalStateException
    //   353	375	844	finally
    //   405	414	574	android/database/sqlite/SQLiteException
    //   405	414	708	org/json/JSONException
    //   405	414	777	java/lang/IllegalStateException
    //   405	414	844	finally
    //   440	455	574	android/database/sqlite/SQLiteException
    //   440	455	708	org/json/JSONException
    //   440	455	777	java/lang/IllegalStateException
    //   440	455	844	finally
    //   481	490	574	android/database/sqlite/SQLiteException
    //   481	490	708	org/json/JSONException
    //   481	490	777	java/lang/IllegalStateException
    //   481	490	844	finally
    //   516	538	574	android/database/sqlite/SQLiteException
    //   516	538	708	org/json/JSONException
    //   516	538	777	java/lang/IllegalStateException
    //   516	538	844	finally
    //   564	571	574	android/database/sqlite/SQLiteException
    //   564	571	708	org/json/JSONException
    //   564	571	777	java/lang/IllegalStateException
    //   564	571	844	finally
    //   581	611	844	finally
    //   616	623	20	finally
    //   628	638	20	finally
    //   648	654	20	finally
    //   662	672	20	finally
    //   682	688	20	finally
    //   693	703	20	finally
    //   715	745	844	finally
    //   750	757	20	finally
    //   762	772	20	finally
    //   784	814	844	finally
    //   819	826	20	finally
    //   831	841	20	finally
    //   849	855	20	finally
    //   859	867	20	finally
    //   867	869	20	finally
  }
  
  public void removeCachedItem(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: ifeq -> 24
    //   9: new java/lang/IllegalArgumentException
    //   12: dup
    //   13: ldc 'primaryKey is not valid'
    //   15: invokespecial <init> : (Ljava/lang/String;)V
    //   18: athrow
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    //   24: new java/util/ArrayList
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: aload_1
    //   32: invokeinterface add : (Ljava/lang/Object;)Z
    //   37: pop
    //   38: aconst_null
    //   39: astore #4
    //   41: aconst_null
    //   42: astore_2
    //   43: aconst_null
    //   44: astore_3
    //   45: aload_0
    //   46: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   49: astore #5
    //   51: aload #5
    //   53: astore_3
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: astore_2
    //   61: aload #5
    //   63: invokevirtual acquireReference : ()V
    //   66: aload #5
    //   68: astore_3
    //   69: aload #5
    //   71: astore #4
    //   73: aload #5
    //   75: astore_2
    //   76: invokestatic isDebugLoggingEnabled : ()Z
    //   79: ifeq -> 124
    //   82: aload #5
    //   84: astore_3
    //   85: aload #5
    //   87: astore #4
    //   89: aload #5
    //   91: astore_2
    //   92: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   95: new java/lang/StringBuilder
    //   98: dup
    //   99: invokespecial <init> : ()V
    //   102: ldc_w 'removeCachedItem - Removing primaryKey('
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: aload_1
    //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: ldc ')'
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: invokevirtual toString : ()Ljava/lang/String;
    //   120: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   123: pop
    //   124: aload #5
    //   126: astore_3
    //   127: aload #5
    //   129: astore #4
    //   131: aload #5
    //   133: astore_2
    //   134: new java/lang/StringBuilder
    //   137: dup
    //   138: invokespecial <init> : ()V
    //   141: ldc 'primary_key=''
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: aload_1
    //   147: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: ldc '''
    //   152: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   155: invokevirtual toString : ()Ljava/lang/String;
    //   158: astore_1
    //   159: aload #5
    //   161: astore_3
    //   162: aload #5
    //   164: astore #4
    //   166: aload #5
    //   168: astore_2
    //   169: aload #5
    //   171: aload_0
    //   172: getfield m_DatabaseTableName : Ljava/lang/String;
    //   175: aload_1
    //   176: aconst_null
    //   177: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   180: pop
    //   181: aload #5
    //   183: ifnull -> 196
    //   186: aload #5
    //   188: invokevirtual releaseReference : ()V
    //   191: aload #5
    //   193: invokevirtual close : ()V
    //   196: aload_0
    //   197: monitorexit
    //   198: return
    //   199: astore_1
    //   200: aload_3
    //   201: astore_2
    //   202: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   205: ldc_w 'removeCachedItem - Failed to open SQL database.'
    //   208: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   211: pop
    //   212: aload_3
    //   213: ifnull -> 196
    //   216: aload_3
    //   217: invokevirtual releaseReference : ()V
    //   220: aload_3
    //   221: invokevirtual close : ()V
    //   224: goto -> 196
    //   227: astore_1
    //   228: aload #4
    //   230: astore_2
    //   231: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   234: new java/lang/StringBuilder
    //   237: dup
    //   238: invokespecial <init> : ()V
    //   241: ldc_w 'removeCachedItem - Failed to acquire reference to database: '
    //   244: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   247: aload_1
    //   248: invokevirtual toString : ()Ljava/lang/String;
    //   251: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   254: invokevirtual toString : ()Ljava/lang/String;
    //   257: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   260: pop
    //   261: aload #4
    //   263: ifnull -> 196
    //   266: aload #4
    //   268: invokevirtual releaseReference : ()V
    //   271: aload #4
    //   273: invokevirtual close : ()V
    //   276: goto -> 196
    //   279: astore_1
    //   280: aload_2
    //   281: ifnull -> 292
    //   284: aload_2
    //   285: invokevirtual releaseReference : ()V
    //   288: aload_2
    //   289: invokevirtual close : ()V
    //   292: aload_1
    //   293: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	19	finally
    //   24	38	19	finally
    //   45	51	199	android/database/sqlite/SQLiteException
    //   45	51	227	java/lang/IllegalStateException
    //   45	51	279	finally
    //   61	66	199	android/database/sqlite/SQLiteException
    //   61	66	227	java/lang/IllegalStateException
    //   61	66	279	finally
    //   76	82	199	android/database/sqlite/SQLiteException
    //   76	82	227	java/lang/IllegalStateException
    //   76	82	279	finally
    //   92	124	199	android/database/sqlite/SQLiteException
    //   92	124	227	java/lang/IllegalStateException
    //   92	124	279	finally
    //   134	159	199	android/database/sqlite/SQLiteException
    //   134	159	227	java/lang/IllegalStateException
    //   134	159	279	finally
    //   169	181	199	android/database/sqlite/SQLiteException
    //   169	181	227	java/lang/IllegalStateException
    //   169	181	279	finally
    //   186	196	19	finally
    //   202	212	279	finally
    //   216	224	19	finally
    //   231	261	279	finally
    //   266	276	19	finally
    //   284	292	19	finally
    //   292	294	19	finally
  }
  
  public void removeCachedItems(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: ifeq -> 25
    //   9: new java/lang/IllegalArgumentException
    //   12: dup
    //   13: ldc_w 'secondaryKey is not valid'
    //   16: invokespecial <init> : (Ljava/lang/String;)V
    //   19: athrow
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    //   25: new java/util/ArrayList
    //   28: dup
    //   29: invokespecial <init> : ()V
    //   32: aload_1
    //   33: invokeinterface add : (Ljava/lang/Object;)Z
    //   38: pop
    //   39: aconst_null
    //   40: astore #5
    //   42: aconst_null
    //   43: astore_3
    //   44: aconst_null
    //   45: astore #4
    //   47: aload_0
    //   48: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   51: astore #6
    //   53: aload #6
    //   55: astore #4
    //   57: aload #6
    //   59: astore #5
    //   61: aload #6
    //   63: astore_3
    //   64: aload #6
    //   66: invokevirtual acquireReference : ()V
    //   69: aload #6
    //   71: astore #4
    //   73: aload #6
    //   75: astore #5
    //   77: aload #6
    //   79: astore_3
    //   80: invokestatic isDebugLoggingEnabled : ()Z
    //   83: ifeq -> 129
    //   86: aload #6
    //   88: astore #4
    //   90: aload #6
    //   92: astore #5
    //   94: aload #6
    //   96: astore_3
    //   97: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   100: new java/lang/StringBuilder
    //   103: dup
    //   104: invokespecial <init> : ()V
    //   107: ldc_w 'removeCachedItem - Removing secondaryKey('
    //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: aload_1
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: ldc ')'
    //   119: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   122: invokevirtual toString : ()Ljava/lang/String;
    //   125: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   128: pop
    //   129: aload #6
    //   131: astore #4
    //   133: aload #6
    //   135: astore #5
    //   137: aload #6
    //   139: astore_3
    //   140: new java/lang/StringBuilder
    //   143: dup
    //   144: invokespecial <init> : ()V
    //   147: ldc 'secondary_key=''
    //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: aload_1
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: ldc '''
    //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: invokevirtual toString : ()Ljava/lang/String;
    //   164: astore_1
    //   165: aload #6
    //   167: astore #4
    //   169: aload #6
    //   171: astore #5
    //   173: aload #6
    //   175: astore_3
    //   176: aload #6
    //   178: aload_0
    //   179: getfield m_DatabaseTableName : Ljava/lang/String;
    //   182: aload_1
    //   183: aconst_null
    //   184: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   187: istore_2
    //   188: aload #6
    //   190: astore #4
    //   192: aload #6
    //   194: astore #5
    //   196: aload #6
    //   198: astore_3
    //   199: invokestatic isDebugLoggingEnabled : ()Z
    //   202: ifeq -> 248
    //   205: aload #6
    //   207: astore #4
    //   209: aload #6
    //   211: astore #5
    //   213: aload #6
    //   215: astore_3
    //   216: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   219: new java/lang/StringBuilder
    //   222: dup
    //   223: invokespecial <init> : ()V
    //   226: ldc_w 'removeCachedItem - Removed '
    //   229: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: iload_2
    //   233: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   236: ldc ' items'
    //   238: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: invokevirtual toString : ()Ljava/lang/String;
    //   244: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   247: pop
    //   248: aload #6
    //   250: ifnull -> 263
    //   253: aload #6
    //   255: invokevirtual releaseReference : ()V
    //   258: aload #6
    //   260: invokevirtual close : ()V
    //   263: aload_0
    //   264: monitorexit
    //   265: return
    //   266: astore_1
    //   267: aload #4
    //   269: astore_3
    //   270: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   273: ldc_w 'removeCachedItems - Failed to open SQL database.'
    //   276: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   279: pop
    //   280: aload #4
    //   282: ifnull -> 263
    //   285: aload #4
    //   287: invokevirtual releaseReference : ()V
    //   290: aload #4
    //   292: invokevirtual close : ()V
    //   295: goto -> 263
    //   298: astore_1
    //   299: aload #5
    //   301: astore_3
    //   302: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   305: new java/lang/StringBuilder
    //   308: dup
    //   309: invokespecial <init> : ()V
    //   312: ldc_w 'removeCachedItems - Failed to acquire reference to database: '
    //   315: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   318: aload_1
    //   319: invokevirtual toString : ()Ljava/lang/String;
    //   322: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: invokevirtual toString : ()Ljava/lang/String;
    //   328: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   331: pop
    //   332: aload #5
    //   334: ifnull -> 263
    //   337: aload #5
    //   339: invokevirtual releaseReference : ()V
    //   342: aload #5
    //   344: invokevirtual close : ()V
    //   347: goto -> 263
    //   350: astore_1
    //   351: aload_3
    //   352: ifnull -> 363
    //   355: aload_3
    //   356: invokevirtual releaseReference : ()V
    //   359: aload_3
    //   360: invokevirtual close : ()V
    //   363: aload_1
    //   364: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	20	finally
    //   25	39	20	finally
    //   47	53	266	android/database/sqlite/SQLiteException
    //   47	53	298	java/lang/IllegalStateException
    //   47	53	350	finally
    //   64	69	266	android/database/sqlite/SQLiteException
    //   64	69	298	java/lang/IllegalStateException
    //   64	69	350	finally
    //   80	86	266	android/database/sqlite/SQLiteException
    //   80	86	298	java/lang/IllegalStateException
    //   80	86	350	finally
    //   97	129	266	android/database/sqlite/SQLiteException
    //   97	129	298	java/lang/IllegalStateException
    //   97	129	350	finally
    //   140	165	266	android/database/sqlite/SQLiteException
    //   140	165	298	java/lang/IllegalStateException
    //   140	165	350	finally
    //   176	188	266	android/database/sqlite/SQLiteException
    //   176	188	298	java/lang/IllegalStateException
    //   176	188	350	finally
    //   199	205	266	android/database/sqlite/SQLiteException
    //   199	205	298	java/lang/IllegalStateException
    //   199	205	350	finally
    //   216	248	266	android/database/sqlite/SQLiteException
    //   216	248	298	java/lang/IllegalStateException
    //   216	248	350	finally
    //   253	263	20	finally
    //   270	280	350	finally
    //   285	295	20	finally
    //   302	332	350	finally
    //   337	347	20	finally
    //   355	363	20	finally
    //   363	365	20	finally
  }
  
  public void setCacheItem(OfflineCacheRequest paramOfflineCacheRequest) {
    if (paramOfflineCacheRequest == null)
      throw new IllegalArgumentException("cacheRequest is null"); 
    setCacheItem(paramOfflineCacheRequest.getPrimaryKey(), paramOfflineCacheRequest.getSecondaryKey(), paramOfflineCacheRequest.getJsonObject());
  }
  
  public void setCacheItem(String paramString1, String paramString2, JSONObject paramJSONObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: ifeq -> 25
    //   9: new java/lang/IllegalArgumentException
    //   12: dup
    //   13: ldc_w 'primaryKey is invalid'
    //   16: invokespecial <init> : (Ljava/lang/String;)V
    //   19: athrow
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    //   25: aload_2
    //   26: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   29: ifeq -> 43
    //   32: new java/lang/IllegalArgumentException
    //   35: dup
    //   36: ldc_w 'secondaryKey is invalid'
    //   39: invokespecial <init> : (Ljava/lang/String;)V
    //   42: athrow
    //   43: aload_3
    //   44: ifnonnull -> 58
    //   47: new java/lang/IllegalArgumentException
    //   50: dup
    //   51: ldc_w 'jsonObject is null'
    //   54: invokespecial <init> : (Ljava/lang/String;)V
    //   57: athrow
    //   58: new java/util/ArrayList
    //   61: dup
    //   62: invokespecial <init> : ()V
    //   65: new java/lang/StringBuilder
    //   68: dup
    //   69: invokespecial <init> : ()V
    //   72: aload_1
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: ldc_w '_'
    //   79: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   82: aload_2
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: invokevirtual toString : ()Ljava/lang/String;
    //   89: invokeinterface add : (Ljava/lang/Object;)Z
    //   94: pop
    //   95: aconst_null
    //   96: astore #6
    //   98: aconst_null
    //   99: astore #4
    //   101: aconst_null
    //   102: astore #5
    //   104: aload_0
    //   105: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   108: astore #7
    //   110: aload #7
    //   112: astore #5
    //   114: aload #7
    //   116: astore #6
    //   118: aload #7
    //   120: astore #4
    //   122: aload #7
    //   124: invokevirtual acquireReference : ()V
    //   127: aload #7
    //   129: astore #5
    //   131: aload #7
    //   133: astore #6
    //   135: aload #7
    //   137: astore #4
    //   139: new android/content/ContentValues
    //   142: dup
    //   143: invokespecial <init> : ()V
    //   146: astore #8
    //   148: aload #7
    //   150: astore #5
    //   152: aload #7
    //   154: astore #6
    //   156: aload #7
    //   158: astore #4
    //   160: aload_3
    //   161: invokevirtual toString : ()Ljava/lang/String;
    //   164: astore_3
    //   165: aload #7
    //   167: astore #5
    //   169: aload #7
    //   171: astore #6
    //   173: aload #7
    //   175: astore #4
    //   177: invokestatic isDebugLoggingEnabled : ()Z
    //   180: ifeq -> 237
    //   183: aload #7
    //   185: astore #5
    //   187: aload #7
    //   189: astore #6
    //   191: aload #7
    //   193: astore #4
    //   195: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   198: new java/lang/StringBuilder
    //   201: dup
    //   202: invokespecial <init> : ()V
    //   205: ldc_w 'setCacheItem - Storing primaryKey('
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: aload_1
    //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: ldc_w '),secondaryKey('
    //   218: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   221: aload_2
    //   222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: ldc ')'
    //   227: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   230: invokevirtual toString : ()Ljava/lang/String;
    //   233: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   236: pop
    //   237: aload #7
    //   239: astore #5
    //   241: aload #7
    //   243: astore #6
    //   245: aload #7
    //   247: astore #4
    //   249: aload #8
    //   251: ldc 'text'
    //   253: aload_3
    //   254: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   257: aload #7
    //   259: astore #5
    //   261: aload #7
    //   263: astore #6
    //   265: aload #7
    //   267: astore #4
    //   269: aload #8
    //   271: ldc 'primary_key'
    //   273: aload_1
    //   274: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   277: aload #7
    //   279: astore #5
    //   281: aload #7
    //   283: astore #6
    //   285: aload #7
    //   287: astore #4
    //   289: aload #8
    //   291: ldc 'secondary_key'
    //   293: aload_2
    //   294: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   297: aload #7
    //   299: astore #5
    //   301: aload #7
    //   303: astore #6
    //   305: aload #7
    //   307: astore #4
    //   309: aload #7
    //   311: aload_0
    //   312: getfield m_DatabaseTableName : Ljava/lang/String;
    //   315: aconst_null
    //   316: aload #8
    //   318: invokevirtual insert : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   321: ldc2_w -1
    //   324: lcmp
    //   325: ifne -> 350
    //   328: aload #7
    //   330: astore #5
    //   332: aload #7
    //   334: astore #6
    //   336: aload #7
    //   338: astore #4
    //   340: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   343: ldc_w 'setCacheItem - Failed to store item in database.'
    //   346: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   349: pop
    //   350: aload #7
    //   352: ifnull -> 365
    //   355: aload #7
    //   357: invokevirtual releaseReference : ()V
    //   360: aload #7
    //   362: invokevirtual close : ()V
    //   365: aload_0
    //   366: monitorexit
    //   367: return
    //   368: astore_1
    //   369: aload #5
    //   371: astore #4
    //   373: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   376: ldc_w 'setCacheItem - Failed to open SQL database.'
    //   379: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   382: pop
    //   383: aload #5
    //   385: ifnull -> 365
    //   388: aload #5
    //   390: invokevirtual releaseReference : ()V
    //   393: aload #5
    //   395: invokevirtual close : ()V
    //   398: goto -> 365
    //   401: astore_1
    //   402: aload #6
    //   404: astore #4
    //   406: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   409: new java/lang/StringBuilder
    //   412: dup
    //   413: invokespecial <init> : ()V
    //   416: ldc_w 'setCacheItem - Failed to acquire reference to database: '
    //   419: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   422: aload_1
    //   423: invokevirtual toString : ()Ljava/lang/String;
    //   426: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   429: invokevirtual toString : ()Ljava/lang/String;
    //   432: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   435: pop
    //   436: aload #6
    //   438: ifnull -> 365
    //   441: aload #6
    //   443: invokevirtual releaseReference : ()V
    //   446: aload #6
    //   448: invokevirtual close : ()V
    //   451: goto -> 365
    //   454: astore_1
    //   455: aload #4
    //   457: ifnull -> 470
    //   460: aload #4
    //   462: invokevirtual releaseReference : ()V
    //   465: aload #4
    //   467: invokevirtual close : ()V
    //   470: aload_1
    //   471: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	20	finally
    //   25	43	20	finally
    //   47	58	20	finally
    //   58	95	20	finally
    //   104	110	368	android/database/sqlite/SQLiteException
    //   104	110	401	java/lang/IllegalStateException
    //   104	110	454	finally
    //   122	127	368	android/database/sqlite/SQLiteException
    //   122	127	401	java/lang/IllegalStateException
    //   122	127	454	finally
    //   139	148	368	android/database/sqlite/SQLiteException
    //   139	148	401	java/lang/IllegalStateException
    //   139	148	454	finally
    //   160	165	368	android/database/sqlite/SQLiteException
    //   160	165	401	java/lang/IllegalStateException
    //   160	165	454	finally
    //   177	183	368	android/database/sqlite/SQLiteException
    //   177	183	401	java/lang/IllegalStateException
    //   177	183	454	finally
    //   195	237	368	android/database/sqlite/SQLiteException
    //   195	237	401	java/lang/IllegalStateException
    //   195	237	454	finally
    //   249	257	368	android/database/sqlite/SQLiteException
    //   249	257	401	java/lang/IllegalStateException
    //   249	257	454	finally
    //   269	277	368	android/database/sqlite/SQLiteException
    //   269	277	401	java/lang/IllegalStateException
    //   269	277	454	finally
    //   289	297	368	android/database/sqlite/SQLiteException
    //   289	297	401	java/lang/IllegalStateException
    //   289	297	454	finally
    //   309	328	368	android/database/sqlite/SQLiteException
    //   309	328	401	java/lang/IllegalStateException
    //   309	328	454	finally
    //   340	350	368	android/database/sqlite/SQLiteException
    //   340	350	401	java/lang/IllegalStateException
    //   340	350	454	finally
    //   355	365	20	finally
    //   373	383	454	finally
    //   388	398	20	finally
    //   406	436	454	finally
    //   441	451	20	finally
    //   460	470	20	finally
    //   470	472	20	finally
  }
  
  public void setCacheItems(List<OfflineCacheRequest> paramList) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 22
    //   6: new java/lang/IllegalArgumentException
    //   9: dup
    //   10: ldc_w 'batchRequest is null'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: athrow
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    //   22: new java/util/ArrayList
    //   25: dup
    //   26: invokespecial <init> : ()V
    //   29: astore #6
    //   31: aconst_null
    //   32: astore #5
    //   34: aconst_null
    //   35: astore_2
    //   36: aconst_null
    //   37: astore #4
    //   39: aload_0
    //   40: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   43: astore_3
    //   44: aload_3
    //   45: astore #4
    //   47: aload_3
    //   48: astore #5
    //   50: aload_3
    //   51: astore_2
    //   52: aload_3
    //   53: invokevirtual acquireReference : ()V
    //   56: aload_3
    //   57: astore #4
    //   59: aload_3
    //   60: astore #5
    //   62: aload_3
    //   63: astore_2
    //   64: aload_3
    //   65: invokevirtual beginTransaction : ()V
    //   68: aload_3
    //   69: new java/lang/StringBuilder
    //   72: dup
    //   73: invokespecial <init> : ()V
    //   76: ldc_w 'INSERT into '
    //   79: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   82: aload_0
    //   83: getfield m_DatabaseTableName : Ljava/lang/String;
    //   86: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   89: ldc ' ('
    //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: ldc 'primary_key'
    //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: ldc_w ','
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: ldc 'secondary_key'
    //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: ldc_w ','
    //   113: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: ldc 'text'
    //   118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: ldc_w ') values(?,?,?);'
    //   124: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   127: invokevirtual toString : ()Ljava/lang/String;
    //   130: invokevirtual compileStatement : (Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;
    //   133: astore_2
    //   134: aload_1
    //   135: invokeinterface iterator : ()Ljava/util/Iterator;
    //   140: astore_1
    //   141: aload_1
    //   142: invokeinterface hasNext : ()Z
    //   147: ifeq -> 280
    //   150: aload_1
    //   151: invokeinterface next : ()Ljava/lang/Object;
    //   156: checkcast com/amazon/ags/storage/OfflineCacheRequest
    //   159: astore #4
    //   161: aload #6
    //   163: new java/lang/StringBuilder
    //   166: dup
    //   167: invokespecial <init> : ()V
    //   170: aload #4
    //   172: invokevirtual getPrimaryKey : ()Ljava/lang/String;
    //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   178: ldc_w '_'
    //   181: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   184: aload #4
    //   186: invokevirtual getSecondaryKey : ()Ljava/lang/String;
    //   189: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   192: invokevirtual toString : ()Ljava/lang/String;
    //   195: invokeinterface add : (Ljava/lang/Object;)Z
    //   200: pop
    //   201: aload_2
    //   202: iconst_1
    //   203: aload #4
    //   205: invokevirtual getPrimaryKey : ()Ljava/lang/String;
    //   208: invokevirtual bindString : (ILjava/lang/String;)V
    //   211: aload_2
    //   212: iconst_2
    //   213: aload #4
    //   215: invokevirtual getSecondaryKey : ()Ljava/lang/String;
    //   218: invokevirtual bindString : (ILjava/lang/String;)V
    //   221: aload_2
    //   222: iconst_3
    //   223: aload #4
    //   225: invokevirtual getJsonObject : ()Lorg/json/JSONObject;
    //   228: invokevirtual toString : ()Ljava/lang/String;
    //   231: invokevirtual bindString : (ILjava/lang/String;)V
    //   234: aload_2
    //   235: invokevirtual executeInsert : ()J
    //   238: pop2
    //   239: goto -> 141
    //   242: astore_1
    //   243: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   246: ldc_w 'setCacheItems - Failed to open SQL database.'
    //   249: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   252: pop
    //   253: aload_3
    //   254: astore #4
    //   256: aload_3
    //   257: astore #5
    //   259: aload_3
    //   260: astore_2
    //   261: aload_3
    //   262: invokevirtual endTransaction : ()V
    //   265: aload_3
    //   266: ifnull -> 277
    //   269: aload_3
    //   270: invokevirtual releaseReference : ()V
    //   273: aload_3
    //   274: invokevirtual close : ()V
    //   277: aload_0
    //   278: monitorexit
    //   279: return
    //   280: aload_3
    //   281: invokevirtual setTransactionSuccessful : ()V
    //   284: aload_3
    //   285: astore #4
    //   287: aload_3
    //   288: astore #5
    //   290: aload_3
    //   291: astore_2
    //   292: aload_3
    //   293: invokevirtual endTransaction : ()V
    //   296: goto -> 265
    //   299: astore_1
    //   300: aload #4
    //   302: astore_2
    //   303: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   306: ldc_w 'setCacheItems - Failed to open SQL database.'
    //   309: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   312: pop
    //   313: aload #4
    //   315: ifnull -> 277
    //   318: aload #4
    //   320: invokevirtual releaseReference : ()V
    //   323: aload #4
    //   325: invokevirtual close : ()V
    //   328: goto -> 277
    //   331: astore_1
    //   332: aload_3
    //   333: astore #4
    //   335: aload_3
    //   336: astore #5
    //   338: aload_3
    //   339: astore_2
    //   340: aload_3
    //   341: invokevirtual endTransaction : ()V
    //   344: aload_3
    //   345: astore #4
    //   347: aload_3
    //   348: astore #5
    //   350: aload_3
    //   351: astore_2
    //   352: aload_1
    //   353: athrow
    //   354: astore_1
    //   355: aload #5
    //   357: astore_2
    //   358: getstatic com/amazon/ags/storage/SQLiteOfflineDataCache.TAG : Ljava/lang/String;
    //   361: new java/lang/StringBuilder
    //   364: dup
    //   365: invokespecial <init> : ()V
    //   368: ldc_w 'setCacheItems - Failed to acquire reference to database: '
    //   371: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   374: aload_1
    //   375: invokevirtual toString : ()Ljava/lang/String;
    //   378: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   381: invokevirtual toString : ()Ljava/lang/String;
    //   384: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   387: pop
    //   388: aload #5
    //   390: ifnull -> 277
    //   393: aload #5
    //   395: invokevirtual releaseReference : ()V
    //   398: aload #5
    //   400: invokevirtual close : ()V
    //   403: goto -> 277
    //   406: astore_1
    //   407: aload_2
    //   408: ifnull -> 419
    //   411: aload_2
    //   412: invokevirtual releaseReference : ()V
    //   415: aload_2
    //   416: invokevirtual close : ()V
    //   419: aload_1
    //   420: athrow
    // Exception table:
    //   from	to	target	type
    //   6	17	17	finally
    //   22	31	17	finally
    //   39	44	299	android/database/sqlite/SQLiteException
    //   39	44	354	java/lang/IllegalStateException
    //   39	44	406	finally
    //   52	56	299	android/database/sqlite/SQLiteException
    //   52	56	354	java/lang/IllegalStateException
    //   52	56	406	finally
    //   64	68	299	android/database/sqlite/SQLiteException
    //   64	68	354	java/lang/IllegalStateException
    //   64	68	406	finally
    //   68	141	242	android/database/sqlite/SQLiteException
    //   68	141	331	finally
    //   141	239	242	android/database/sqlite/SQLiteException
    //   141	239	331	finally
    //   243	253	331	finally
    //   261	265	299	android/database/sqlite/SQLiteException
    //   261	265	354	java/lang/IllegalStateException
    //   261	265	406	finally
    //   269	277	17	finally
    //   280	284	242	android/database/sqlite/SQLiteException
    //   280	284	331	finally
    //   292	296	299	android/database/sqlite/SQLiteException
    //   292	296	354	java/lang/IllegalStateException
    //   292	296	406	finally
    //   303	313	406	finally
    //   318	328	17	finally
    //   340	344	299	android/database/sqlite/SQLiteException
    //   340	344	354	java/lang/IllegalStateException
    //   340	344	406	finally
    //   352	354	299	android/database/sqlite/SQLiteException
    //   352	354	354	java/lang/IllegalStateException
    //   352	354	406	finally
    //   358	388	406	finally
    //   393	403	17	finally
    //   411	419	17	finally
    //   419	421	17	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\SQLiteOfflineDataCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */