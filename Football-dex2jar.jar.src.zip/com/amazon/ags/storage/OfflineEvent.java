package com.amazon.ags.storage;

import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;

public class OfflineEvent {
  public static final String KEY_EVENT_TIME = "eventTime";
  
  private final JSONObject eventJson;
  
  private final Date eventTime;
  
  public OfflineEvent(JSONObject paramJSONObject) throws JSONException {
    long l = paramJSONObject.getLong("eventTime");
    this.eventJson = paramJSONObject;
    this.eventTime = new Date(l);
  }
  
  public Date getEventTime() {
    return new Date(this.eventTime.getTime());
  }
  
  public JSONObject toJson() throws JSONException {
    return this.eventJson;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\OfflineEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */