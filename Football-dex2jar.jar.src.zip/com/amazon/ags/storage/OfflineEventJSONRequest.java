package com.amazon.ags.storage;

import android.util.Log;
import com.amazon.ags.client.JSONRequest;
import org.json.JSONObject;

public class OfflineEventJSONRequest implements JSONRequest {
  private static final String TAG = "GC_" + OfflineEventJSONRequest.class.getSimpleName();
  
  private final OfflineEventJSONCallback callback;
  
  private final JSONObject request;
  
  public OfflineEventJSONRequest(JSONObject paramJSONObject, OfflineEventJSONCallback paramOfflineEventJSONCallback) {
    this.request = paramJSONObject;
    this.callback = paramOfflineEventJSONCallback;
  }
  
  public JSONObject getRequest() {
    return this.request;
  }
  
  public void setResponse(JSONObject paramJSONObject) {
    int i;
    try {
      i = paramJSONObject.getInt("RESPONSE_CODE");
      if (i == 17) {
        this.callback.onSuccess();
        return;
      } 
    } catch (Exception exception) {
      Log.e(TAG, "Unable to read response for request due to error", exception);
      this.callback.onUnrecoverableError();
      return;
    } 
    if (i == 30 || i == 28) {
      this.callback.onRecoverableError();
      return;
    } 
    this.callback.onUnrecoverableError();
  }
  
  public static interface OfflineEventJSONCallback {
    void onRecoverableError();
    
    void onSuccess();
    
    void onUnrecoverableError();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\OfflineEventJSONRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */