package com.amazon.ags.storage;

import android.util.Base64;
import android.util.Log;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public class EncryptionStringObfuscator implements StringObfuscator {
  private static final String ALGORITHM = "DES";
  
  private static final String TAG = "GC_" + EncryptionStringObfuscator.class.getSimpleName();
  
  private static final String UTF8 = "UTF8";
  
  private final SecretKey key;
  
  private final boolean valid;
  
  public EncryptionStringObfuscator(byte[] paramArrayOfbyte) {
    SecretKey secretKey;
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0)
      throw new IllegalArgumentException("secretKey must be non-null"); 
    byte[] arrayOfByte = paramArrayOfbyte;
    if (paramArrayOfbyte.length < 8) {
      byte[] arrayOfByte1 = new byte[8];
      int i = 0;
      int j = 0;
      while (true) {
        arrayOfByte = arrayOfByte1;
        if (j < 8) {
          arrayOfByte1[j] = paramArrayOfbyte[i];
          int k = i + 1;
          i = k;
          if (k >= paramArrayOfbyte.length)
            i = 0; 
          j++;
          continue;
        } 
        break;
      } 
    } 
    paramArrayOfbyte = null;
    boolean bool = false;
    try {
      DESKeySpec dESKeySpec = new DESKeySpec(arrayOfByte);
      SecretKey secretKey1 = SecretKeyFactory.getInstance("DES").generateSecret(dESKeySpec);
      secretKey = secretKey1;
      bool = true;
    } catch (Exception exception) {
      Log.e(TAG, "Failed to constructor secret key", exception);
    } 
    this.key = secretKey;
    this.valid = bool;
  }
  
  public String obfuscate(String paramString) {
    if (this.valid && paramString != null)
      try {
        Cipher cipher = Cipher.getInstance("DES");
        byte[] arrayOfByte = paramString.getBytes("UTF8");
        cipher.init(1, this.key);
        return Base64.encodeToString(cipher.doFinal(arrayOfByte), 0);
      } catch (Exception exception) {
        Log.e(TAG, "Failed to obfuscate string", exception);
        return null;
      }  
    return null;
  }
  
  public String unobfuscate(String paramString) {
    if (this.valid && paramString != null)
      try {
        Cipher cipher = Cipher.getInstance("DES");
        byte[] arrayOfByte = Base64.decode(paramString.getBytes("UTF8"), 0);
        cipher.init(2, this.key);
        return new String(cipher.doFinal(arrayOfByte), "UTF8");
      } catch (Exception exception) {
        Log.e(TAG, "Failed to unobfuscate string", exception);
        return null;
      }  
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\EncryptionStringObfuscator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */