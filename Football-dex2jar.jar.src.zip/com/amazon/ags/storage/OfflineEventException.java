package com.amazon.ags.storage;

public class OfflineEventException extends Exception {
  private static final long serialVersionUID = -5999670364817975593L;
  
  public OfflineEventException() {}
  
  public OfflineEventException(String paramString) {
    super(paramString);
  }
  
  public OfflineEventException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public OfflineEventException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\OfflineEventException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */