package com.amazon.ags.storage;

import android.text.TextUtils;
import org.json.JSONObject;

public class OfflineCacheRequest {
  private final JSONObject m_JsonObject;
  
  private final String m_PrimaryKey;
  
  private final String m_SecondaryKey;
  
  public OfflineCacheRequest(String paramString1, String paramString2, JSONObject paramJSONObject) {
    if (TextUtils.isEmpty(paramString1))
      throw new IllegalArgumentException("primaryKey is invalid"); 
    if (TextUtils.isEmpty(paramString2))
      throw new IllegalArgumentException("secondaryKey is invalid"); 
    if (paramJSONObject == null)
      throw new IllegalArgumentException("jsonObject is null"); 
    this.m_PrimaryKey = paramString1;
    this.m_SecondaryKey = paramString2;
    this.m_JsonObject = paramJSONObject;
  }
  
  public JSONObject getJsonObject() {
    return this.m_JsonObject;
  }
  
  public String getPrimaryKey() {
    return this.m_PrimaryKey;
  }
  
  public String getSecondaryKey() {
    return this.m_SecondaryKey;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\storage\OfflineCacheRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */