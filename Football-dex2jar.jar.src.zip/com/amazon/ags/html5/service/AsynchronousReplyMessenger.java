package com.amazon.ags.html5.service;

import android.os.Handler;
import android.util.Log;
import com.amazon.ags.client.JSONRequest;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

public class AsynchronousReplyMessenger {
  private static final long REQUEST_TIMEOUT_MILLIS = 10000L;
  
  private static final String TAG = "GC_" + AsynchronousReplyMessenger.class.getSimpleName();
  
  private final Map<String, JSONRequest> pendingMessages = Collections.synchronizedMap(new HashMap<String, JSONRequest>());
  
  private final ScheduledExecutorService scheduledExecutorService;
  
  private final Handler uiThreadHandler;
  
  public AsynchronousReplyMessenger(Handler paramHandler, ScheduledExecutorService paramScheduledExecutorService) {
    this.uiThreadHandler = paramHandler;
    this.scheduledExecutorService = paramScheduledExecutorService;
  }
  
  private void scheduleTimeoutTask(final String requestId) {
    Runnable runnable = new Runnable() {
        public void run() {
          JSONRequest jSONRequest = (JSONRequest)AsynchronousReplyMessenger.this.pendingMessages.remove(requestId);
          if (jSONRequest == null)
            return; 
          try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("RESPONSE_CODE", 24);
            jSONObject.put("REQUEST_ID", requestId);
            jSONRequest.setResponse(jSONObject);
            Log.w(AsynchronousReplyMessenger.TAG, "Request " + requestId + " timed out.");
            return;
          } catch (JSONException jSONException) {
            Log.e(AsynchronousReplyMessenger.TAG, "Failed to generate a timeout response for request " + requestId + ".  The callback won't be called.", (Throwable)jSONException);
            return;
          } 
        }
      };
    this.scheduledExecutorService.schedule(runnable, 10000L, TimeUnit.MILLISECONDS);
  }
  
  public void addAsyncRequest(JSONRequest paramJSONRequest) {
    String str;
    if (paramJSONRequest == null)
      return; 
    try {
      str = paramJSONRequest.getRequest().getString("REQUEST_ID");
      if (str == null)
        throw new IllegalArgumentException("Messages must contain a request id"); 
    } catch (JSONException jSONException) {
      throw new IllegalArgumentException("Unable to get request id", jSONException);
    } 
    scheduleTimeoutTask(str);
    this.pendingMessages.put(str, jSONException);
  }
  
  public void sendReply(JSONObject paramJSONObject) {
    String str;
    if (paramJSONObject == null) {
      Log.d(TAG, "Null reply recieved");
      return;
    } 
    try {
      str = paramJSONObject.getString("REQUEST_ID");
      if (str == null) {
        Log.e(TAG, "sendReply received a null request id");
        return;
      } 
    } catch (JSONException jSONException) {
      Log.e(TAG, "Unable to get request id", (Throwable)jSONException);
      return;
    } 
    final JSONRequest asyncRequest = this.pendingMessages.remove(str);
    if (jSONRequest != null) {
      this.uiThreadHandler.post(new Runnable() {
            public void run() {
              asyncRequest.setResponse(reply);
            }
          });
      return;
    } 
    Log.w(TAG, "No pending message found for message id " + str);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\service\AsynchronousReplyMessenger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */