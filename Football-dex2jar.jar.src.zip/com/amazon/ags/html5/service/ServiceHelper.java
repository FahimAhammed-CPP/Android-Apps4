package com.amazon.ags.html5.service;

import com.amazon.ags.client.JSONRequest;

public interface ServiceHelper {
  void handleRequestAsync(JSONRequest paramJSONRequest);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\service\ServiceHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */