package com.amazon.ags.html5.service;

import android.content.Context;
import android.os.Handler;
import android.webkit.WebView;
import com.amazon.ags.client.JSONRequest;
import com.amazon.ags.html5.javascript.JavascriptRepository;
import com.amazon.ags.html5.javascript.domain.JavascriptInterface;
import com.amazon.ags.html5.javascript.domain.MessageHandlerReadyListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;

public class WebViewServiceHelper implements ServiceHelper, MessageHandlerReadyListener {
  private final Context context;
  
  private final JavascriptInterface javascriptInterface;
  
  private final List<JSONObject> messageQueue = new ArrayList<JSONObject>();
  
  private final AsynchronousReplyMessenger replyMessenger;
  
  private final Handler uiThreadHandler;
  
  final WebView webView;
  
  public WebViewServiceHelper(Context paramContext, JavascriptRepository paramJavascriptRepository, JavascriptInterface paramJavascriptInterface, AsynchronousReplyMessenger paramAsynchronousReplyMessenger, WebView paramWebView, Handler paramHandler) {
    this.javascriptInterface = paramJavascriptInterface;
    this.javascriptInterface.addMessageHandlerReadyListener(this);
    this.context = paramContext;
    this.webView = paramWebView;
    this.replyMessenger = paramAsynchronousReplyMessenger;
    this.uiThreadHandler = paramHandler;
  }
  
  private void deliverMessageToJavascript(final JSONObject msg) {
    this.uiThreadHandler.post(new Runnable() {
          public void run() {
            WebViewServiceHelper.this.webView.loadUrl("javascript:handleMessage(" + msg.toString() + ")");
          }
        });
  }
  
  private void deliverOrQueueMessage(JSONObject paramJSONObject) {
    if (this.javascriptInterface.isReady()) {
      deliverMessageToJavascript(paramJSONObject);
      return;
    } 
    synchronized (this.messageQueue) {
      if (this.javascriptInterface.isReady()) {
        deliverMessageToJavascript(paramJSONObject);
      } else {
        this.messageQueue.add(paramJSONObject);
      } 
      return;
    } 
  }
  
  public void handleRequestAsync(JSONRequest paramJSONRequest) {
    this.replyMessenger.addAsyncRequest(paramJSONRequest);
    deliverOrQueueMessage(paramJSONRequest.getRequest());
  }
  
  public void messageHandlerReady() {
    synchronized (this.messageQueue) {
      Iterator<JSONObject> iterator = this.messageQueue.iterator();
      while (iterator.hasNext())
        deliverMessageToJavascript(iterator.next()); 
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\service\WebViewServiceHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */