package com.amazon.ags.html5.factory;

import android.app.Activity;
import com.amazon.ags.api.AmazonGamesCallback;
import com.amazon.ags.api.AmazonGamesFeature;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public final class AGSClientInstanceCoordinator {
  private static final String TAG = "GC_" + AGSClientInstanceCoordinator.class.getSimpleName();
  
  private static AGSClientInstanceCoordinator instance = null;
  
  private Activity currentActivity;
  
  private EnumSet<AmazonGamesFeature> features;
  
  private AmazonGamesCallback latestAmazonGamesCallback;
  
  private Set<AGSClientInstanceCoordinatorListener> listeners;
  
  private AGSClientInstanceCoordinator(Activity paramActivity, AmazonGamesCallback paramAmazonGamesCallback, EnumSet<AmazonGamesFeature> paramEnumSet) {
    this.currentActivity = paramActivity;
    this.listeners = new HashSet<AGSClientInstanceCoordinatorListener>();
    this.latestAmazonGamesCallback = paramAmazonGamesCallback;
    this.features = paramEnumSet;
  }
  
  public static AGSClientInstanceCoordinator getInstance() {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/factory/AGSClientInstanceCoordinator
    //   2: monitorenter
    //   3: getstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.instance : Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   6: ifnonnull -> 34
    //   9: getstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.TAG : Ljava/lang/String;
    //   12: ldc 'AGSClientInstanceCoordinator must be initialized before using'
    //   14: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: new java/lang/IllegalAccessError
    //   21: dup
    //   22: ldc 'AGSClientInstanceCoordinator must be initialized before using'
    //   24: invokespecial <init> : (Ljava/lang/String;)V
    //   27: athrow
    //   28: astore_0
    //   29: ldc com/amazon/ags/html5/factory/AGSClientInstanceCoordinator
    //   31: monitorexit
    //   32: aload_0
    //   33: athrow
    //   34: getstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.instance : Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   37: astore_0
    //   38: ldc com/amazon/ags/html5/factory/AGSClientInstanceCoordinator
    //   40: monitorexit
    //   41: aload_0
    //   42: areturn
    // Exception table:
    //   from	to	target	type
    //   3	28	28	finally
    //   34	38	28	finally
  }
  
  public static AGSClientInstanceCoordinator initialize(Activity paramActivity, AmazonGamesCallback paramAmazonGamesCallback, EnumSet<AmazonGamesFeature> paramEnumSet) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/factory/AGSClientInstanceCoordinator
    //   2: monitorenter
    //   3: getstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.instance : Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   6: ifnull -> 48
    //   9: getstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.TAG : Ljava/lang/String;
    //   12: ldc 'AGSClientInstanceCoordinator already initialized.'
    //   14: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: getstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.instance : Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   21: aload_0
    //   22: invokevirtual updateActivity : (Landroid/app/Activity;)V
    //   25: getstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.instance : Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   28: aload_1
    //   29: invokevirtual updateCallback : (Lcom/amazon/ags/api/AmazonGamesCallback;)V
    //   32: getstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.instance : Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   35: aload_2
    //   36: invokevirtual updateFeatures : (Ljava/util/EnumSet;)V
    //   39: getstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.instance : Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   42: astore_0
    //   43: ldc com/amazon/ags/html5/factory/AGSClientInstanceCoordinator
    //   45: monitorexit
    //   46: aload_0
    //   47: areturn
    //   48: new com/amazon/ags/html5/factory/AGSClientInstanceCoordinator
    //   51: dup
    //   52: aload_0
    //   53: aload_1
    //   54: aload_2
    //   55: invokespecial <init> : (Landroid/app/Activity;Lcom/amazon/ags/api/AmazonGamesCallback;Ljava/util/EnumSet;)V
    //   58: putstatic com/amazon/ags/html5/factory/AGSClientInstanceCoordinator.instance : Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   61: goto -> 39
    //   64: astore_0
    //   65: ldc com/amazon/ags/html5/factory/AGSClientInstanceCoordinator
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    // Exception table:
    //   from	to	target	type
    //   3	39	64	finally
    //   39	43	64	finally
    //   48	61	64	finally
  }
  
  public void addAGSClientInstanceCoordinatorListener(AGSClientInstanceCoordinatorListener paramAGSClientInstanceCoordinatorListener) {
    this.listeners.add(paramAGSClientInstanceCoordinatorListener);
  }
  
  public Activity getCurrentActivity() {
    return this.currentActivity;
  }
  
  public EnumSet<AmazonGamesFeature> getEnabledFeatures() {
    return this.features;
  }
  
  public AmazonGamesCallback getLatestCallback() {
    return this.latestAmazonGamesCallback;
  }
  
  public void updateActivity(Activity paramActivity) {
    this.currentActivity = paramActivity;
    Iterator<AGSClientInstanceCoordinatorListener> iterator = this.listeners.iterator();
    while (iterator.hasNext())
      ((AGSClientInstanceCoordinatorListener)iterator.next()).notifyCurrentActivityChanged(this.currentActivity); 
  }
  
  public void updateCallback(AmazonGamesCallback paramAmazonGamesCallback) {
    this.latestAmazonGamesCallback = paramAmazonGamesCallback;
  }
  
  public void updateFeatures(EnumSet<AmazonGamesFeature> paramEnumSet) {
    this.features = paramEnumSet;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\factory\AGSClientInstanceCoordinator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */