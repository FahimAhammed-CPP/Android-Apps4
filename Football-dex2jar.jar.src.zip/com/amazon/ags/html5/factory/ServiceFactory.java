package com.amazon.ags.html5.factory;

import android.content.Context;
import android.os.Handler;
import android.webkit.WebView;
import com.amazon.ags.client.KindleFireProxy;
import com.amazon.ags.client.OverlayClient;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.session.SessionClient;
import com.amazon.ags.html5.comm.NetworkClient;
import com.amazon.ags.html5.content.ContentManager;
import com.amazon.ags.html5.content.ContentVersion;
import com.amazon.ags.html5.content.GCVariationManager;
import com.amazon.ags.html5.javascript.CallHandlerBase;
import com.amazon.ags.html5.javascript.JavascriptRepository;
import com.amazon.ags.html5.javascript.domain.JavascriptInterface;
import com.amazon.ags.html5.overlay.OverlayManager;
import com.amazon.ags.html5.overlay.toasts.ClickableToastFactoryImpl;
import com.amazon.ags.html5.service.AsynchronousReplyMessenger;
import com.amazon.ags.html5.service.ServiceHelper;
import com.amazon.ags.html5.util.GlobalState;
import com.amazon.ags.html5.util.LocalizationUtil;
import com.amazon.ags.html5.util.WebViewFactory;
import com.amazon.ags.storage.OfflineDataCache;
import com.amazon.ags.storage.OfflineEventManager;
import com.amazon.ags.storage.StringObfuscator;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

public final class ServiceFactory {
  private static final int ACHIEVEMENTS_CACHE_VERSION = 1;
  
  private static final int LEADERBOARDS_CACHE_VERSION = 1;
  
  private static final int MINIMUM_THREAD_POOL_SIZE = 5;
  
  private static final int PLAYER_PROFILE_CACHE_VERSION = 1;
  
  private static final int SETTINGS_CACHE_VERSION = 1;
  
  private static final String TAG = "GC_" + ServiceFactory.class.getSimpleName();
  
  private static boolean debugLoggingEnabled;
  
  private static ServiceFactory instance = null;
  
  private static String showToastsFlag;
  
  private OfflineDataCache achOfflineDataCache;
  
  private final String applicationName;
  
  private final EventCollectorClient eventCollectorClient;
  
  private final GCVariationManager gcVariationManager;
  
  private ContentVersion initializedContentVersion;
  
  private JavascriptRepository javascriptRepository;
  
  private final KindleFireProxy kindleFireProxy;
  
  private OfflineDataCache leaderboardOfflineDataCache;
  
  private final LocalizationUtil localizationUtil;
  
  private List<CallHandlerBase> nativeCallHandlers;
  
  private final NetworkClient networkClient;
  
  private OfflineEventManager offlineEventManager;
  
  private OverlayClient overlayClient;
  
  private OverlayManager overlayManager;
  
  private OfflineDataCache playerProfileOfflineDataCache;
  
  private AsynchronousReplyMessenger replyMessenger;
  
  private ServiceHelper serviceHelper;
  
  private final SessionClient sessionClient;
  
  private final OfflineDataCache settingsDataCache;
  
  private final ThreadPoolExecutor threadPoolExecutor;
  
  private final ClickableToastFactoryImpl toastFactory;
  
  private final Object toastLock;
  
  private final Handler uiThreadHandler;
  
  private WebViewFactory webViewFactory;
  
  static {
    debugLoggingEnabled = false;
  }
  
  private ServiceFactory(Context paramContext, String paramString, ContentManager paramContentManager, EventCollectorClient paramEventCollectorClient, StringObfuscator paramStringObfuscator, GCVariationManager paramGCVariationManager, GlobalState paramGlobalState) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: new android/os/Handler
    //   8: dup
    //   9: invokestatic getMainLooper : ()Landroid/os/Looper;
    //   12: invokespecial <init> : (Landroid/os/Looper;)V
    //   15: putfield uiThreadHandler : Landroid/os/Handler;
    //   18: aload_0
    //   19: new java/lang/Object
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: putfield toastLock : Ljava/lang/Object;
    //   29: aload_0
    //   30: aload #6
    //   32: putfield gcVariationManager : Lcom/amazon/ags/html5/content/GCVariationManager;
    //   35: aload_1
    //   36: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   39: astore #10
    //   41: aconst_null
    //   42: astore #6
    //   44: aload #10
    //   46: aload_2
    //   47: iconst_0
    //   48: invokevirtual getApplicationInfo : (Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   51: astore_2
    //   52: aload_2
    //   53: ifnull -> 750
    //   56: aload #10
    //   58: aload_2
    //   59: invokevirtual getApplicationLabel : (Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;
    //   62: astore_2
    //   63: aload_0
    //   64: aload_2
    //   65: checkcast java/lang/String
    //   68: checkcast java/lang/String
    //   71: putfield applicationName : Ljava/lang/String;
    //   74: aload_0
    //   75: aload_3
    //   76: putfield javascriptRepository : Lcom/amazon/ags/html5/javascript/JavascriptRepository;
    //   79: aload_0
    //   80: aload_3
    //   81: invokevirtual getInitializedContentVersion : ()Lcom/amazon/ags/html5/content/ContentVersion;
    //   84: putfield initializedContentVersion : Lcom/amazon/ags/html5/content/ContentVersion;
    //   87: aload_0
    //   88: aload #4
    //   90: putfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   93: ldc 'toastsUndefined'
    //   95: putstatic com/amazon/ags/html5/factory/ServiceFactory.showToastsFlag : Ljava/lang/String;
    //   98: aload_0
    //   99: new com/amazon/ags/html5/util/LocalizationUtil
    //   102: dup
    //   103: aload_1
    //   104: invokespecial <init> : (Landroid/content/Context;)V
    //   107: putfield localizationUtil : Lcom/amazon/ags/html5/util/LocalizationUtil;
    //   110: new com/amazon/ags/html5/util/NetworkUtil
    //   113: dup
    //   114: aload_1
    //   115: invokespecial <init> : (Landroid/content/Context;)V
    //   118: astore_2
    //   119: new com/amazon/ags/html5/util/BrowserUtil
    //   122: dup
    //   123: aload_1
    //   124: invokespecial <init> : (Landroid/content/Context;)V
    //   127: astore #6
    //   129: new com/amazon/ags/html5/util/EmailUtil
    //   132: dup
    //   133: aload_1
    //   134: invokespecial <init> : (Landroid/content/Context;)V
    //   137: astore #10
    //   139: new com/amazon/ags/html5/util/ImageManager
    //   142: dup
    //   143: aload_3
    //   144: invokespecial <init> : (Lcom/amazon/ags/html5/content/ContentManager;)V
    //   147: astore #11
    //   149: aload_0
    //   150: new com/amazon/ags/storage/SQLiteOfflineDataCache
    //   153: dup
    //   154: aload_1
    //   155: ldc 'AchievementsCache'
    //   157: iconst_1
    //   158: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;I)V
    //   161: putfield achOfflineDataCache : Lcom/amazon/ags/storage/OfflineDataCache;
    //   164: aload_0
    //   165: new com/amazon/ags/storage/SQLiteOfflineDataCache
    //   168: dup
    //   169: aload_1
    //   170: ldc 'LeaderboardsCache'
    //   172: iconst_1
    //   173: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;I)V
    //   176: putfield leaderboardOfflineDataCache : Lcom/amazon/ags/storage/OfflineDataCache;
    //   179: aload_0
    //   180: new com/amazon/ags/storage/SQLiteOfflineDataCache
    //   183: dup
    //   184: aload_1
    //   185: ldc 'PlayerProfileCache'
    //   187: iconst_1
    //   188: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;I)V
    //   191: putfield playerProfileOfflineDataCache : Lcom/amazon/ags/storage/OfflineDataCache;
    //   194: aload_0
    //   195: new com/amazon/ags/storage/SQLiteOfflineDataCache
    //   198: dup
    //   199: aload_1
    //   200: ldc 'SettingsCache'
    //   202: iconst_1
    //   203: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;I)V
    //   206: putfield settingsDataCache : Lcom/amazon/ags/storage/OfflineDataCache;
    //   209: new com/amazon/ags/html5/util/ClientConfig
    //   212: dup
    //   213: invokespecial <init> : ()V
    //   216: astore #13
    //   218: aload #13
    //   220: aload_0
    //   221: getfield settingsDataCache : Lcom/amazon/ags/storage/OfflineDataCache;
    //   224: ldc 'clientConfig'
    //   226: invokeinterface getCacheItem : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   231: invokevirtual load : (Lorg/json/JSONObject;)V
    //   234: aload_0
    //   235: getfield gcVariationManager : Lcom/amazon/ags/html5/content/GCVariationManager;
    //   238: invokevirtual getCachedVariations : ()Ljava/util/Map;
    //   241: pop
    //   242: aload #13
    //   244: ldc 'THREAD_POOL_SIZE'
    //   246: invokevirtual get : (Ljava/lang/String;)J
    //   249: l2i
    //   250: istore #9
    //   252: iload #9
    //   254: istore #8
    //   256: iload #9
    //   258: iconst_5
    //   259: if_icmpge -> 265
    //   262: iconst_5
    //   263: istore #8
    //   265: aload_0
    //   266: new java/util/concurrent/ThreadPoolExecutor
    //   269: dup
    //   270: iconst_5
    //   271: iload #8
    //   273: aload #13
    //   275: ldc 'THREAD_TIMEOUT'
    //   277: invokevirtual get : (Ljava/lang/String;)J
    //   280: l2i
    //   281: i2l
    //   282: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
    //   285: new java/util/concurrent/SynchronousQueue
    //   288: dup
    //   289: invokespecial <init> : ()V
    //   292: new java/util/concurrent/ThreadPoolExecutor$AbortPolicy
    //   295: dup
    //   296: invokespecial <init> : ()V
    //   299: invokespecial <init> : (IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/RejectedExecutionHandler;)V
    //   302: putfield threadPoolExecutor : Ljava/util/concurrent/ThreadPoolExecutor;
    //   305: new com/amazon/ags/auth/AuthManager
    //   308: dup
    //   309: aload #13
    //   311: invokespecial <init> : (Lcom/amazon/ags/html5/util/ClientConfig;)V
    //   314: astore #12
    //   316: new org/apache/http/impl/client/DefaultHttpClient
    //   319: dup
    //   320: invokespecial <init> : ()V
    //   323: astore #15
    //   325: aload #15
    //   327: invokevirtual getConnectionManager : ()Lorg/apache/http/conn/ClientConnectionManager;
    //   330: astore #14
    //   332: aload #15
    //   334: invokevirtual getParams : ()Lorg/apache/http/params/HttpParams;
    //   337: astore #15
    //   339: aload #15
    //   341: ldc_w 'http.useragent'
    //   344: new com/amazon/ags/html5/comm/UserAgentIdentifier
    //   347: dup
    //   348: invokestatic getSDKVersion : ()Lcom/amazon/ags/VersionInfo;
    //   351: aload_0
    //   352: getfield initializedContentVersion : Lcom/amazon/ags/html5/content/ContentVersion;
    //   355: invokespecial <init> : (Lcom/amazon/ags/VersionInfo;Lcom/amazon/ags/html5/content/ContentVersion;)V
    //   358: invokevirtual getUserAgent : ()Ljava/lang/String;
    //   361: invokeinterface setParameter : (Ljava/lang/String;Ljava/lang/Object;)Lorg/apache/http/params/HttpParams;
    //   366: pop
    //   367: aload #15
    //   369: aload #13
    //   371: ldc_w 'HTTP_MAX_TOTAL_CONNECTIONS'
    //   374: invokevirtual get : (Ljava/lang/String;)J
    //   377: l2i
    //   378: invokestatic setMaxTotalConnections : (Lorg/apache/http/params/HttpParams;I)V
    //   381: aload #15
    //   383: new org/apache/http/conn/params/ConnPerRouteBean
    //   386: dup
    //   387: aload #13
    //   389: ldc_w 'HTTP_MAX_CONNECTIONS_PER_ROUTE'
    //   392: invokevirtual get : (Ljava/lang/String;)J
    //   395: l2i
    //   396: invokespecial <init> : (I)V
    //   399: invokestatic setMaxConnectionsPerRoute : (Lorg/apache/http/params/HttpParams;Lorg/apache/http/conn/params/ConnPerRoute;)V
    //   402: aload #15
    //   404: aload #13
    //   406: ldc_w 'HTTP_CONNECTION_POOL_TIMEOUT_MILLIS'
    //   409: invokevirtual get : (Ljava/lang/String;)J
    //   412: invokestatic setTimeout : (Lorg/apache/http/params/HttpParams;J)V
    //   415: aload #15
    //   417: aload #13
    //   419: ldc_w 'HTTP_CONNECTION_TIMEOUT_MILLIS'
    //   422: invokevirtual get : (Ljava/lang/String;)J
    //   425: l2i
    //   426: invokestatic setConnectionTimeout : (Lorg/apache/http/params/HttpParams;I)V
    //   429: aload #15
    //   431: aload #13
    //   433: ldc_w 'HTTP_SOCKET_TIMEOUT_MILLIS'
    //   436: invokevirtual get : (Ljava/lang/String;)J
    //   439: l2i
    //   440: invokestatic setSoTimeout : (Lorg/apache/http/params/HttpParams;I)V
    //   443: new org/apache/http/impl/client/DefaultHttpClient
    //   446: dup
    //   447: new org/apache/http/impl/conn/tsccm/ThreadSafeClientConnManager
    //   450: dup
    //   451: aload #15
    //   453: aload #14
    //   455: invokeinterface getSchemeRegistry : ()Lorg/apache/http/conn/scheme/SchemeRegistry;
    //   460: invokespecial <init> : (Lorg/apache/http/params/HttpParams;Lorg/apache/http/conn/scheme/SchemeRegistry;)V
    //   463: aload #15
    //   465: invokespecial <init> : (Lorg/apache/http/conn/ClientConnectionManager;Lorg/apache/http/params/HttpParams;)V
    //   468: astore #13
    //   470: aload_0
    //   471: new com/amazon/ags/client/KindleFireIPCProxy
    //   474: dup
    //   475: aload_1
    //   476: invokespecial <init> : (Landroid/content/Context;)V
    //   479: putfield kindleFireProxy : Lcom/amazon/ags/client/KindleFireProxy;
    //   482: new com/amazon/ags/html5/util/DeviceInfo
    //   485: dup
    //   486: aload_0
    //   487: getfield kindleFireProxy : Lcom/amazon/ags/client/KindleFireProxy;
    //   490: invokespecial <init> : (Lcom/amazon/ags/client/KindleFireProxy;)V
    //   493: astore #14
    //   495: aload_0
    //   496: new com/amazon/ags/html5/comm/HttpNetworkClient
    //   499: dup
    //   500: aload #13
    //   502: aload_0
    //   503: getfield kindleFireProxy : Lcom/amazon/ags/client/KindleFireProxy;
    //   506: aload #12
    //   508: aload #14
    //   510: aload #4
    //   512: aload_0
    //   513: getfield localizationUtil : Lcom/amazon/ags/html5/util/LocalizationUtil;
    //   516: invokespecial <init> : (Lorg/apache/http/client/HttpClient;Lcom/amazon/ags/client/KindleFireProxy;Lcom/amazon/ags/auth/AuthManager;Lcom/amazon/ags/html5/util/DeviceInfo;Lcom/amazon/ags/client/metrics/EventCollectorClient;Lcom/amazon/ags/html5/util/LocalizationUtil;)V
    //   519: putfield networkClient : Lcom/amazon/ags/html5/comm/NetworkClient;
    //   522: aload_0
    //   523: new com/amazon/ags/html5/util/WebViewFactory
    //   526: dup
    //   527: aload_1
    //   528: aload_0
    //   529: getfield javascriptRepository : Lcom/amazon/ags/html5/javascript/JavascriptRepository;
    //   532: invokespecial <init> : (Landroid/content/Context;Lcom/amazon/ags/html5/javascript/JavascriptRepository;)V
    //   535: putfield webViewFactory : Lcom/amazon/ags/html5/util/WebViewFactory;
    //   538: iconst_1
    //   539: invokestatic newScheduledThreadPool : (I)Ljava/util/concurrent/ScheduledExecutorService;
    //   542: astore #15
    //   544: aload_0
    //   545: new com/amazon/ags/html5/service/AsynchronousReplyMessenger
    //   548: dup
    //   549: aload_0
    //   550: getfield uiThreadHandler : Landroid/os/Handler;
    //   553: aload #15
    //   555: invokespecial <init> : (Landroid/os/Handler;Ljava/util/concurrent/ScheduledExecutorService;)V
    //   558: putfield replyMessenger : Lcom/amazon/ags/html5/service/AsynchronousReplyMessenger;
    //   561: aload_0
    //   562: new com/amazon/ags/html5/overlay/toasts/ClickableToastFactoryImpl
    //   565: dup
    //   566: aload_0
    //   567: getfield uiThreadHandler : Landroid/os/Handler;
    //   570: aload_0
    //   571: getfield webViewFactory : Lcom/amazon/ags/html5/util/WebViewFactory;
    //   574: aload_3
    //   575: aload_0
    //   576: getfield localizationUtil : Lcom/amazon/ags/html5/util/LocalizationUtil;
    //   579: invokespecial <init> : (Landroid/os/Handler;Lcom/amazon/ags/html5/util/WebViewFactory;Lcom/amazon/ags/html5/javascript/JavascriptRepository;Lcom/amazon/ags/html5/util/LocalizationUtil;)V
    //   582: putfield toastFactory : Lcom/amazon/ags/html5/overlay/toasts/ClickableToastFactoryImpl;
    //   585: new com/amazon/ags/html5/overlay/OverlaySessionInformation
    //   588: dup
    //   589: invokestatic getGameCircleVersion : ()Lcom/amazon/ags/VersionInfo;
    //   592: invokevirtual getVersion : ()Ljava/lang/String;
    //   595: invokestatic getSDKVersion : ()Lcom/amazon/ags/VersionInfo;
    //   598: invokevirtual getVersion : ()Ljava/lang/String;
    //   601: aload_0
    //   602: getfield initializedContentVersion : Lcom/amazon/ags/html5/content/ContentVersion;
    //   605: invokevirtual getVersion : ()Ljava/lang/String;
    //   608: aload_0
    //   609: getfield applicationName : Ljava/lang/String;
    //   612: aload_0
    //   613: getfield localizationUtil : Lcom/amazon/ags/html5/util/LocalizationUtil;
    //   616: aload #14
    //   618: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/amazon/ags/html5/util/LocalizationUtil;Lcom/amazon/ags/html5/util/DeviceInfo;)V
    //   621: astore_3
    //   622: aload_0
    //   623: new com/amazon/ags/html5/overlay/OverlayManager
    //   626: dup
    //   627: aload_1
    //   628: aload_0
    //   629: getfield uiThreadHandler : Landroid/os/Handler;
    //   632: aload_0
    //   633: getfield toastFactory : Lcom/amazon/ags/html5/overlay/toasts/ClickableToastFactoryImpl;
    //   636: aload_0
    //   637: getfield kindleFireProxy : Lcom/amazon/ags/client/KindleFireProxy;
    //   640: aload_3
    //   641: aload_0
    //   642: getfield gcVariationManager : Lcom/amazon/ags/html5/content/GCVariationManager;
    //   645: aload #11
    //   647: invokespecial <init> : (Landroid/content/Context;Landroid/os/Handler;Lcom/amazon/ags/html5/overlay/toasts/ClickableToastFactory;Lcom/amazon/ags/client/KindleFireProxy;Lcom/amazon/ags/html5/overlay/OverlaySessionInformation;Lcom/amazon/ags/html5/content/GCVariationManager;Lcom/amazon/ags/html5/util/ImageManager;)V
    //   650: putfield overlayManager : Lcom/amazon/ags/html5/overlay/OverlayManager;
    //   653: aload_0
    //   654: getfield webViewFactory : Lcom/amazon/ags/html5/util/WebViewFactory;
    //   657: invokevirtual getBackgroundWebview : ()Landroid/webkit/WebView;
    //   660: astore_3
    //   661: aload #7
    //   663: aload #4
    //   665: invokevirtual addListener : (Lcom/amazon/ags/html5/util/GlobalState$GlobalStateListener;)V
    //   668: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   671: invokevirtual getEnabledFeatures : ()Ljava/util/EnumSet;
    //   674: astore #16
    //   676: new java/lang/StringBuilder
    //   679: dup
    //   680: invokespecial <init> : ()V
    //   683: astore #15
    //   685: aload #16
    //   687: invokevirtual iterator : ()Ljava/util/Iterator;
    //   690: astore #16
    //   692: aload #16
    //   694: invokeinterface hasNext : ()Z
    //   699: ifeq -> 757
    //   702: aload #15
    //   704: aload #16
    //   706: invokeinterface next : ()Ljava/lang/Object;
    //   711: checkcast com/amazon/ags/api/AmazonGamesFeature
    //   714: invokevirtual name : ()Ljava/lang/String;
    //   717: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   720: pop
    //   721: aload #15
    //   723: ldc_w ';'
    //   726: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   729: pop
    //   730: goto -> 692
    //   733: astore_2
    //   734: getstatic com/amazon/ags/html5/factory/ServiceFactory.TAG : Ljava/lang/String;
    //   737: ldc_w 'Unable to retrieve application name'
    //   740: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   743: pop
    //   744: aload #6
    //   746: astore_2
    //   747: goto -> 52
    //   750: ldc_w ''
    //   753: astore_2
    //   754: goto -> 63
    //   757: aload #15
    //   759: ldc_w ';'
    //   762: invokevirtual lastIndexOf : (Ljava/lang/String;)I
    //   765: istore #8
    //   767: iload #8
    //   769: iconst_m1
    //   770: if_icmple -> 781
    //   773: aload #15
    //   775: iload #8
    //   777: invokevirtual deleteCharAt : (I)Ljava/lang/StringBuilder;
    //   780: pop
    //   781: aload #7
    //   783: ldc_w 'devFeatures'
    //   786: aload #15
    //   788: invokevirtual toString : ()Ljava/lang/String;
    //   791: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   794: new com/amazon/ags/html5/comm/NetworkCallFactory
    //   797: dup
    //   798: aload #12
    //   800: aload_0
    //   801: getfield uiThreadHandler : Landroid/os/Handler;
    //   804: aload #7
    //   806: aload_0
    //   807: getfield localizationUtil : Lcom/amazon/ags/html5/util/LocalizationUtil;
    //   810: aload_0
    //   811: getfield networkClient : Lcom/amazon/ags/html5/comm/NetworkClient;
    //   814: invokespecial <init> : (Lcom/amazon/ags/auth/AuthManager;Landroid/os/Handler;Lcom/amazon/ags/html5/util/GlobalState;Lcom/amazon/ags/html5/util/LocalizationUtil;Lcom/amazon/ags/html5/comm/NetworkClient;)V
    //   817: astore #15
    //   819: aload_0
    //   820: new java/util/ArrayList
    //   823: dup
    //   824: invokespecial <init> : ()V
    //   827: putfield nativeCallHandlers : Ljava/util/List;
    //   830: aload_0
    //   831: getfield nativeCallHandlers : Ljava/util/List;
    //   834: aload #15
    //   836: invokeinterface add : (Ljava/lang/Object;)Z
    //   841: pop
    //   842: aload_0
    //   843: aload_3
    //   844: ldc_w 'backgroundwebview'
    //   847: invokevirtual getJavascriptInterface : (Landroid/webkit/WebView;Ljava/lang/String;)Lcom/amazon/ags/html5/javascript/domain/JavascriptInterface;
    //   850: astore #15
    //   852: aload_3
    //   853: aload #15
    //   855: ldc_w 'hostinterface'
    //   858: invokevirtual addJavascriptInterface : (Ljava/lang/Object;Ljava/lang/String;)V
    //   861: aload_0
    //   862: new com/amazon/ags/html5/service/WebViewServiceHelper
    //   865: dup
    //   866: aload_1
    //   867: aload_0
    //   868: getfield javascriptRepository : Lcom/amazon/ags/html5/javascript/JavascriptRepository;
    //   871: aload #15
    //   873: aload_0
    //   874: getfield replyMessenger : Lcom/amazon/ags/html5/service/AsynchronousReplyMessenger;
    //   877: aload_3
    //   878: aload_0
    //   879: getfield uiThreadHandler : Landroid/os/Handler;
    //   882: invokespecial <init> : (Landroid/content/Context;Lcom/amazon/ags/html5/javascript/JavascriptRepository;Lcom/amazon/ags/html5/javascript/domain/JavascriptInterface;Lcom/amazon/ags/html5/service/AsynchronousReplyMessenger;Landroid/webkit/WebView;Landroid/os/Handler;)V
    //   885: putfield serviceHelper : Lcom/amazon/ags/html5/service/ServiceHelper;
    //   888: aload_0
    //   889: new com/amazon/ags/storage/AGSAsyncOfflineEventManager
    //   892: dup
    //   893: new com/amazon/ags/storage/SQLiteOfflineEventStorage
    //   896: dup
    //   897: aload_1
    //   898: aload #5
    //   900: ldc_w 'offlineEvents'
    //   903: invokespecial <init> : (Landroid/content/Context;Lcom/amazon/ags/storage/StringObfuscator;Ljava/lang/String;)V
    //   906: aload_2
    //   907: aload_0
    //   908: getfield serviceHelper : Lcom/amazon/ags/html5/service/ServiceHelper;
    //   911: aload #7
    //   913: invokespecial <init> : (Lcom/amazon/ags/storage/SQLiteOfflineEventStorage;Lcom/amazon/ags/html5/util/NetworkUtil;Lcom/amazon/ags/html5/service/ServiceHelper;Lcom/amazon/ags/html5/util/GlobalState;)V
    //   916: putfield offlineEventManager : Lcom/amazon/ags/storage/OfflineEventManager;
    //   919: new com/amazon/ags/html5/javascript/event/JavascriptEventsManager
    //   922: dup
    //   923: invokespecial <init> : ()V
    //   926: astore #5
    //   928: aload_0
    //   929: getfield nativeCallHandlers : Ljava/util/List;
    //   932: new com/amazon/ags/html5/javascript/NativeCallHandler
    //   935: dup
    //   936: aload_1
    //   937: aload_0
    //   938: getfield uiThreadHandler : Landroid/os/Handler;
    //   941: aload_2
    //   942: aload #6
    //   944: aload #10
    //   946: aload_0
    //   947: getfield offlineEventManager : Lcom/amazon/ags/storage/OfflineEventManager;
    //   950: aload #11
    //   952: aload_0
    //   953: getfield localizationUtil : Lcom/amazon/ags/html5/util/LocalizationUtil;
    //   956: aload_0
    //   957: getfield gcVariationManager : Lcom/amazon/ags/html5/content/GCVariationManager;
    //   960: invokespecial <init> : (Landroid/content/Context;Landroid/os/Handler;Lcom/amazon/ags/html5/util/NetworkUtil;Lcom/amazon/ags/html5/util/BrowserUtil;Lcom/amazon/ags/html5/util/EmailUtil;Lcom/amazon/ags/storage/OfflineEventManager;Lcom/amazon/ags/html5/util/ImageManager;Lcom/amazon/ags/html5/util/LocalizationUtil;Lcom/amazon/ags/html5/content/GCVariationManager;)V
    //   963: invokeinterface add : (Ljava/lang/Object;)Z
    //   968: pop
    //   969: aload_0
    //   970: getfield nativeCallHandlers : Ljava/util/List;
    //   973: new com/amazon/ags/html5/javascript/NativeToastCallHandler
    //   976: dup
    //   977: aload_1
    //   978: aload_0
    //   979: getfield uiThreadHandler : Landroid/os/Handler;
    //   982: aload_0
    //   983: getfield overlayManager : Lcom/amazon/ags/html5/overlay/OverlayManager;
    //   986: invokespecial <init> : (Landroid/content/Context;Landroid/os/Handler;Lcom/amazon/ags/html5/overlay/OverlayManager;)V
    //   989: invokeinterface add : (Ljava/lang/Object;)Z
    //   994: pop
    //   995: aload_0
    //   996: getfield nativeCallHandlers : Ljava/util/List;
    //   999: new com/amazon/ags/html5/javascript/NativeCacheCallHandler
    //   1002: dup
    //   1003: aload_0
    //   1004: getfield uiThreadHandler : Landroid/os/Handler;
    //   1007: aload_0
    //   1008: getfield achOfflineDataCache : Lcom/amazon/ags/storage/OfflineDataCache;
    //   1011: aload_0
    //   1012: getfield leaderboardOfflineDataCache : Lcom/amazon/ags/storage/OfflineDataCache;
    //   1015: aload_0
    //   1016: getfield playerProfileOfflineDataCache : Lcom/amazon/ags/storage/OfflineDataCache;
    //   1019: invokespecial <init> : (Landroid/os/Handler;Lcom/amazon/ags/storage/OfflineDataCache;Lcom/amazon/ags/storage/OfflineDataCache;Lcom/amazon/ags/storage/OfflineDataCache;)V
    //   1022: invokeinterface add : (Ljava/lang/Object;)Z
    //   1027: pop
    //   1028: aload_0
    //   1029: getfield nativeCallHandlers : Ljava/util/List;
    //   1032: new com/amazon/ags/html5/javascript/NativeAuthCallHandler
    //   1035: dup
    //   1036: aload_0
    //   1037: getfield uiThreadHandler : Landroid/os/Handler;
    //   1040: aload #12
    //   1042: invokespecial <init> : (Landroid/os/Handler;Lcom/amazon/ags/auth/AuthManager;)V
    //   1045: invokeinterface add : (Ljava/lang/Object;)Z
    //   1050: pop
    //   1051: aload_0
    //   1052: getfield nativeCallHandlers : Ljava/util/List;
    //   1055: new com/amazon/ags/html5/javascript/NativeGlobalStateCallHandler
    //   1058: dup
    //   1059: aload_0
    //   1060: getfield uiThreadHandler : Landroid/os/Handler;
    //   1063: aload #7
    //   1065: invokespecial <init> : (Landroid/os/Handler;Lcom/amazon/ags/html5/util/GlobalState;)V
    //   1068: invokeinterface add : (Ljava/lang/Object;)Z
    //   1073: pop
    //   1074: aload_0
    //   1075: getfield nativeCallHandlers : Ljava/util/List;
    //   1078: new com/amazon/ags/html5/javascript/NativeSettingsCallHandler
    //   1081: dup
    //   1082: aload_0
    //   1083: getfield uiThreadHandler : Landroid/os/Handler;
    //   1086: aload_0
    //   1087: getfield settingsDataCache : Lcom/amazon/ags/storage/OfflineDataCache;
    //   1090: invokespecial <init> : (Landroid/os/Handler;Lcom/amazon/ags/storage/OfflineDataCache;)V
    //   1093: invokeinterface add : (Ljava/lang/Object;)Z
    //   1098: pop
    //   1099: aload_0
    //   1100: getfield nativeCallHandlers : Ljava/util/List;
    //   1103: new com/amazon/ags/html5/javascript/BackgroundTaskHandler
    //   1106: dup
    //   1107: aload_0
    //   1108: getfield serviceHelper : Lcom/amazon/ags/html5/service/ServiceHelper;
    //   1111: aload_0
    //   1112: getfield uiThreadHandler : Landroid/os/Handler;
    //   1115: invokespecial <init> : (Lcom/amazon/ags/html5/service/ServiceHelper;Landroid/os/Handler;)V
    //   1118: invokeinterface add : (Ljava/lang/Object;)Z
    //   1123: pop
    //   1124: aload_0
    //   1125: getfield nativeCallHandlers : Ljava/util/List;
    //   1128: new com/amazon/ags/html5/javascript/ReportEventHandler
    //   1131: dup
    //   1132: aload #4
    //   1134: aload_0
    //   1135: getfield uiThreadHandler : Landroid/os/Handler;
    //   1138: invokespecial <init> : (Lcom/amazon/ags/client/metrics/EventCollectorClient;Landroid/os/Handler;)V
    //   1141: invokeinterface add : (Ljava/lang/Object;)Z
    //   1146: pop
    //   1147: aload_0
    //   1148: getfield nativeCallHandlers : Ljava/util/List;
    //   1151: new com/amazon/ags/html5/javascript/NativeKindleFireStateCallHandler
    //   1154: dup
    //   1155: aload_1
    //   1156: aload_0
    //   1157: getfield uiThreadHandler : Landroid/os/Handler;
    //   1160: aload_0
    //   1161: getfield kindleFireProxy : Lcom/amazon/ags/client/KindleFireProxy;
    //   1164: invokespecial <init> : (Landroid/content/Context;Landroid/os/Handler;Lcom/amazon/ags/client/KindleFireProxy;)V
    //   1167: invokeinterface add : (Ljava/lang/Object;)Z
    //   1172: pop
    //   1173: aload_0
    //   1174: getfield nativeCallHandlers : Ljava/util/List;
    //   1177: new com/amazon/ags/html5/javascript/event/NativeJavascriptEventsCallHandler
    //   1180: dup
    //   1181: aload_0
    //   1182: getfield uiThreadHandler : Landroid/os/Handler;
    //   1185: aload #5
    //   1187: invokespecial <init> : (Landroid/os/Handler;Lcom/amazon/ags/html5/javascript/event/JavascriptEventsManager;)V
    //   1190: invokeinterface add : (Ljava/lang/Object;)Z
    //   1195: pop
    //   1196: aload_0
    //   1197: getfield toastFactory : Lcom/amazon/ags/html5/overlay/toasts/ClickableToastFactoryImpl;
    //   1200: aload_0
    //   1201: getfield serviceHelper : Lcom/amazon/ags/html5/service/ServiceHelper;
    //   1204: invokevirtual setServiceHelper : (Lcom/amazon/ags/html5/service/ServiceHelper;)V
    //   1207: aload_0
    //   1208: getfield javascriptRepository : Lcom/amazon/ags/html5/javascript/JavascriptRepository;
    //   1211: aload_3
    //   1212: invokeinterface loadBackgroundJavascript : (Landroid/webkit/WebView;)V
    //   1217: aload_0
    //   1218: new com/amazon/ags/client/OverlayClient
    //   1221: dup
    //   1222: aload_0
    //   1223: getfield serviceHelper : Lcom/amazon/ags/html5/service/ServiceHelper;
    //   1226: invokespecial <init> : (Lcom/amazon/ags/html5/service/ServiceHelper;)V
    //   1229: putfield overlayClient : Lcom/amazon/ags/client/OverlayClient;
    //   1232: aload_0
    //   1233: new com/amazon/ags/client/session/SessionClient
    //   1236: dup
    //   1237: aload_0
    //   1238: getfield serviceHelper : Lcom/amazon/ags/html5/service/ServiceHelper;
    //   1241: invokespecial <init> : (Lcom/amazon/ags/html5/service/ServiceHelper;)V
    //   1244: putfield sessionClient : Lcom/amazon/ags/client/session/SessionClient;
    //   1247: invokestatic getInstance : ()Lcom/amazon/ags/client/whispersync/WhispersyncClientImpl;
    //   1250: aload_0
    //   1251: getfield networkClient : Lcom/amazon/ags/html5/comm/NetworkClient;
    //   1254: aload_2
    //   1255: aload_0
    //   1256: getfield sessionClient : Lcom/amazon/ags/client/session/SessionClient;
    //   1259: aload #13
    //   1261: aload #12
    //   1263: aload #5
    //   1265: invokevirtual setNetworkDependencies : (Lcom/amazon/ags/html5/comm/NetworkClient;Lcom/amazon/ags/html5/util/NetworkUtil;Lcom/amazon/ags/client/session/SessionClient;Lorg/apache/http/client/HttpClient;Lcom/amazon/ags/auth/AuthManager;Lcom/amazon/ags/html5/javascript/event/JavascriptEventsManager;)V
    //   1268: aload #4
    //   1270: aload #12
    //   1272: invokevirtual setAuthManager : (Lcom/amazon/ags/auth/AuthManager;)V
    //   1275: aload #4
    //   1277: aload #7
    //   1279: invokevirtual setGlobalState : (Lcom/amazon/ags/html5/util/GlobalState;)V
    //   1282: aload #4
    //   1284: aload_0
    //   1285: getfield initializedContentVersion : Lcom/amazon/ags/html5/content/ContentVersion;
    //   1288: invokevirtual setContentVersion : (Lcom/amazon/ags/html5/content/ContentVersion;)V
    //   1291: aload #4
    //   1293: aload #14
    //   1295: invokevirtual setDeviceInfo : (Lcom/amazon/ags/html5/util/DeviceInfo;)V
    //   1298: return
    // Exception table:
    //   from	to	target	type
    //   44	52	733	java/lang/Exception
  }
  
  public static ServiceFactory getInstance() {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/factory/ServiceFactory
    //   2: monitorenter
    //   3: getstatic com/amazon/ags/html5/factory/ServiceFactory.instance : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   6: ifnonnull -> 36
    //   9: getstatic com/amazon/ags/html5/factory/ServiceFactory.TAG : Ljava/lang/String;
    //   12: ldc_w 'ServiceFactory must be initialized before using'
    //   15: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: new java/lang/IllegalAccessError
    //   22: dup
    //   23: ldc_w 'ServiceFactory must be initialized before using'
    //   26: invokespecial <init> : (Ljava/lang/String;)V
    //   29: athrow
    //   30: astore_0
    //   31: ldc com/amazon/ags/html5/factory/ServiceFactory
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    //   36: getstatic com/amazon/ags/html5/factory/ServiceFactory.instance : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   39: astore_0
    //   40: ldc com/amazon/ags/html5/factory/ServiceFactory
    //   42: monitorexit
    //   43: aload_0
    //   44: areturn
    // Exception table:
    //   from	to	target	type
    //   3	30	30	finally
    //   36	40	30	finally
  }
  
  public static String getShowToastsString() {
    return showToastsFlag;
  }
  
  public static ServiceFactory initialize(Context paramContext, String paramString, ContentManager paramContentManager, EventCollectorClient paramEventCollectorClient, StringObfuscator paramStringObfuscator, GCVariationManager paramGCVariationManager, GlobalState paramGlobalState) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/factory/ServiceFactory
    //   2: monitorenter
    //   3: getstatic com/amazon/ags/html5/factory/ServiceFactory.instance : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   6: ifnull -> 28
    //   9: getstatic com/amazon/ags/html5/factory/ServiceFactory.TAG : Ljava/lang/String;
    //   12: ldc_w 'ServiceFactory already initialized.'
    //   15: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: getstatic com/amazon/ags/html5/factory/ServiceFactory.instance : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   22: astore_0
    //   23: ldc com/amazon/ags/html5/factory/ServiceFactory
    //   25: monitorexit
    //   26: aload_0
    //   27: areturn
    //   28: new com/amazon/ags/html5/factory/ServiceFactory
    //   31: dup
    //   32: aload_0
    //   33: aload_1
    //   34: aload_2
    //   35: aload_3
    //   36: aload #4
    //   38: aload #5
    //   40: aload #6
    //   42: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;Lcom/amazon/ags/html5/content/ContentManager;Lcom/amazon/ags/client/metrics/EventCollectorClient;Lcom/amazon/ags/storage/StringObfuscator;Lcom/amazon/ags/html5/content/GCVariationManager;Lcom/amazon/ags/html5/util/GlobalState;)V
    //   45: putstatic com/amazon/ags/html5/factory/ServiceFactory.instance : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   48: goto -> 19
    //   51: astore_0
    //   52: ldc com/amazon/ags/html5/factory/ServiceFactory
    //   54: monitorexit
    //   55: aload_0
    //   56: athrow
    // Exception table:
    //   from	to	target	type
    //   3	19	51	finally
    //   19	23	51	finally
    //   28	48	51	finally
  }
  
  public static boolean isDebugLoggingEnabled() {
    return debugLoggingEnabled;
  }
  
  private void resolveToastLock() {
    synchronized (this.toastLock) {
      this.toastLock.notifyAll();
      return;
    } 
  }
  
  public static void setDebugLoggingEnabled(boolean paramBoolean) {
    debugLoggingEnabled = paramBoolean;
  }
  
  public void disableToastCreation() {
    showToastsFlag = "dontShowToasts";
    resolveToastLock();
  }
  
  public void enableToastCreation() {
    showToastsFlag = "showToasts";
    resolveToastLock();
  }
  
  public String getApplicationName() {
    return this.applicationName;
  }
  
  public EventCollectorClient getEventCollectorClient() {
    return this.eventCollectorClient;
  }
  
  public ContentVersion getInitializedContentVersion() {
    return this.initializedContentVersion;
  }
  
  public JavascriptInterface getJavascriptInterface(WebView paramWebView, String paramString) {
    return new JavascriptInterface(paramString, this.replyMessenger, this.overlayManager, this.nativeCallHandlers, this.threadPoolExecutor, paramWebView, this.toastLock);
  }
  
  public JavascriptRepository getJavascriptRepository() {
    return this.javascriptRepository;
  }
  
  public KindleFireProxy getKindleFireProxy() {
    return this.kindleFireProxy;
  }
  
  public LocalizationUtil getLocalizationUtil() {
    return this.localizationUtil;
  }
  
  public NetworkClient getNetworkClient() {
    return this.networkClient;
  }
  
  public OverlayClient getOverlayClient() {
    return this.overlayClient;
  }
  
  public ServiceHelper getServiceHelper() {
    return this.serviceHelper;
  }
  
  public SessionClient getSessionClient() {
    return this.sessionClient;
  }
  
  public Handler getUiThreadHandler() {
    return this.uiThreadHandler;
  }
  
  public WebViewFactory getWebViewFactory() {
    return this.webViewFactory;
  }
  
  public void onPause() {
    this.toastFactory.dismissCurrentToast();
    if (this.offlineEventManager != null)
      this.offlineEventManager.onPause(); 
  }
  
  public void onResume() {
    if (this.offlineEventManager != null)
      this.offlineEventManager.onResume(); 
  }
  
  public void shutdown() {
    instance = null;
    this.achOfflineDataCache = null;
    this.leaderboardOfflineDataCache = null;
    this.playerProfileOfflineDataCache = null;
    this.offlineEventManager = null;
    this.serviceHelper = null;
    this.overlayClient = null;
    this.overlayManager = null;
    this.webViewFactory = null;
    this.nativeCallHandlers = null;
    this.replyMessenger = null;
    this.javascriptRepository = null;
    showToastsFlag = null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\factory\ServiceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */