package com.amazon.ags.html5.content;

import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import org.json.JSONException;
import org.json.JSONObject;

public class ContentVersion implements Comparable<ContentVersion> {
  private static final String TAG = ContentVersion.class.getSimpleName();
  
  private static final String VERSION_FILENAME = "version.txt";
  
  private static final String majorKey = "major";
  
  private static final String minorKey = "minor";
  
  private static final String patchKey = "patch";
  
  private static final String separator = "::";
  
  private static final String versionKey = "version";
  
  private Integer majorVersion;
  
  private Integer minorVersion;
  
  private Integer patchVersion;
  
  public ContentVersion(int paramInt1, int paramInt2, int paramInt3) {
    this.majorVersion = Integer.valueOf(paramInt1);
    this.minorVersion = Integer.valueOf(paramInt2);
    this.patchVersion = Integer.valueOf(paramInt3);
  }
  
  public ContentVersion(String paramString) {
    if (paramString == null)
      throw new IllegalArgumentException("Input json must not be null"); 
    try {
      JSONObject jSONObject = (new JSONObject(paramString)).getJSONObject("version");
      this.majorVersion = Integer.valueOf(jSONObject.getInt("major"));
      this.minorVersion = Integer.valueOf(jSONObject.getInt("minor"));
      this.patchVersion = Integer.valueOf(jSONObject.getInt("patch"));
      return;
    } catch (JSONException jSONException) {
      Log.e(TAG, "Unable to parse version JSON: " + jSONException, (Throwable)jSONException);
      this.majorVersion = Integer.valueOf(-1);
      this.minorVersion = Integer.valueOf(-1);
      this.patchVersion = Integer.valueOf(-1);
      return;
    } 
  }
  
  public static ContentVersion createVersionFromDefaultContentRawResource(Context paramContext, String paramString1, String paramString2) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aconst_null
    //   3: astore #4
    //   5: new java/util/zip/ZipInputStream
    //   8: dup
    //   9: new java/io/BufferedInputStream
    //   12: dup
    //   13: aload_0
    //   14: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   17: aload_0
    //   18: aload_1
    //   19: aload_2
    //   20: invokestatic getIdentifier : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I
    //   23: invokevirtual openRawResource : (I)Ljava/io/InputStream;
    //   26: invokespecial <init> : (Ljava/io/InputStream;)V
    //   29: invokespecial <init> : (Ljava/io/InputStream;)V
    //   32: astore_1
    //   33: aconst_null
    //   34: astore_3
    //   35: aload_1
    //   36: invokevirtual getNextEntry : ()Ljava/util/zip/ZipEntry;
    //   39: astore_0
    //   40: aload_3
    //   41: astore_2
    //   42: aload_0
    //   43: ifnull -> 60
    //   46: aload_0
    //   47: invokevirtual getName : ()Ljava/lang/String;
    //   50: ldc 'version.txt'
    //   52: invokevirtual equals : (Ljava/lang/Object;)Z
    //   55: ifeq -> 100
    //   58: aload_0
    //   59: astore_2
    //   60: aload_2
    //   61: ifnull -> 122
    //   64: aload_2
    //   65: invokevirtual getSize : ()J
    //   68: l2i
    //   69: newarray byte
    //   71: astore_0
    //   72: aload_1
    //   73: aload_0
    //   74: invokevirtual read : ([B)I
    //   77: pop
    //   78: new java/lang/String
    //   81: dup
    //   82: aload_0
    //   83: invokespecial <init> : ([B)V
    //   86: invokestatic parseContentVersion : (Ljava/lang/String;)Lcom/amazon/ags/html5/content/ContentVersion;
    //   89: astore_0
    //   90: aload_1
    //   91: ifnull -> 98
    //   94: aload_1
    //   95: invokevirtual close : ()V
    //   98: aload_0
    //   99: areturn
    //   100: aload_1
    //   101: invokevirtual getNextEntry : ()Ljava/util/zip/ZipEntry;
    //   104: astore_0
    //   105: goto -> 40
    //   108: astore_1
    //   109: getstatic com/amazon/ags/html5/content/ContentVersion.TAG : Ljava/lang/String;
    //   112: ldc 'Error encountered while cleaning up version file read operation'
    //   114: aload_1
    //   115: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   118: pop
    //   119: goto -> 98
    //   122: aload_1
    //   123: ifnull -> 130
    //   126: aload_1
    //   127: invokevirtual close : ()V
    //   130: invokestatic getBlankContentVersion : ()Lcom/amazon/ags/html5/content/ContentVersion;
    //   133: areturn
    //   134: astore_0
    //   135: getstatic com/amazon/ags/html5/content/ContentVersion.TAG : Ljava/lang/String;
    //   138: ldc 'Error encountered while cleaning up version file read operation'
    //   140: aload_0
    //   141: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   144: pop
    //   145: goto -> 130
    //   148: astore_1
    //   149: aload #4
    //   151: astore_0
    //   152: aload_0
    //   153: astore_3
    //   154: getstatic com/amazon/ags/html5/content/ContentVersion.TAG : Ljava/lang/String;
    //   157: ldc 'Could not extract version from content zip file.'
    //   159: aload_1
    //   160: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   163: pop
    //   164: aload_0
    //   165: ifnull -> 130
    //   168: aload_0
    //   169: invokevirtual close : ()V
    //   172: goto -> 130
    //   175: astore_0
    //   176: getstatic com/amazon/ags/html5/content/ContentVersion.TAG : Ljava/lang/String;
    //   179: ldc 'Error encountered while cleaning up version file read operation'
    //   181: aload_0
    //   182: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   185: pop
    //   186: goto -> 130
    //   189: astore_0
    //   190: aload_3
    //   191: ifnull -> 198
    //   194: aload_3
    //   195: invokevirtual close : ()V
    //   198: aload_0
    //   199: athrow
    //   200: astore_1
    //   201: getstatic com/amazon/ags/html5/content/ContentVersion.TAG : Ljava/lang/String;
    //   204: ldc 'Error encountered while cleaning up version file read operation'
    //   206: aload_1
    //   207: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   210: pop
    //   211: goto -> 198
    //   214: astore_0
    //   215: aload_1
    //   216: astore_3
    //   217: goto -> 190
    //   220: astore_2
    //   221: aload_1
    //   222: astore_0
    //   223: aload_2
    //   224: astore_1
    //   225: goto -> 152
    // Exception table:
    //   from	to	target	type
    //   5	33	148	java/io/IOException
    //   5	33	189	finally
    //   35	40	220	java/io/IOException
    //   35	40	214	finally
    //   46	58	220	java/io/IOException
    //   46	58	214	finally
    //   64	90	220	java/io/IOException
    //   64	90	214	finally
    //   94	98	108	java/io/IOException
    //   100	105	220	java/io/IOException
    //   100	105	214	finally
    //   126	130	134	java/io/IOException
    //   154	164	189	finally
    //   168	172	175	java/io/IOException
    //   194	198	200	java/io/IOException
  }
  
  public static ContentVersion createVersionFromFile(String paramString) {
    // Byte code:
    //   0: new java/io/File
    //   3: dup
    //   4: aload_0
    //   5: invokespecial <init> : (Ljava/lang/String;)V
    //   8: astore_0
    //   9: aload_0
    //   10: invokevirtual exists : ()Z
    //   13: ifeq -> 23
    //   16: aload_0
    //   17: invokevirtual isFile : ()Z
    //   20: ifne -> 27
    //   23: aconst_null
    //   24: astore_0
    //   25: aload_0
    //   26: areturn
    //   27: aconst_null
    //   28: astore_2
    //   29: aconst_null
    //   30: astore #5
    //   32: aconst_null
    //   33: astore_1
    //   34: aconst_null
    //   35: astore_3
    //   36: aconst_null
    //   37: astore #4
    //   39: new java/io/FileInputStream
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Ljava/io/File;)V
    //   47: astore_0
    //   48: new java/io/BufferedReader
    //   51: dup
    //   52: new java/io/InputStreamReader
    //   55: dup
    //   56: aload_0
    //   57: invokespecial <init> : (Ljava/io/InputStream;)V
    //   60: invokespecial <init> : (Ljava/io/Reader;)V
    //   63: astore_1
    //   64: aload_1
    //   65: invokevirtual readLine : ()Ljava/lang/String;
    //   68: invokestatic parseContentVersion : (Ljava/lang/String;)Lcom/amazon/ags/html5/content/ContentVersion;
    //   71: astore_2
    //   72: aload_0
    //   73: ifnull -> 80
    //   76: aload_0
    //   77: invokevirtual close : ()V
    //   80: aload_2
    //   81: astore_0
    //   82: aload_1
    //   83: ifnull -> 25
    //   86: aload_1
    //   87: invokevirtual close : ()V
    //   90: aload_2
    //   91: areturn
    //   92: astore_0
    //   93: getstatic com/amazon/ags/html5/content/ContentVersion.TAG : Ljava/lang/String;
    //   96: ldc 'Error encountered while cleaning up version file read operation'
    //   98: aload_0
    //   99: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   102: pop
    //   103: aload_2
    //   104: areturn
    //   105: astore_3
    //   106: aload #5
    //   108: astore_0
    //   109: aload #4
    //   111: astore_1
    //   112: aload_0
    //   113: astore_2
    //   114: getstatic com/amazon/ags/html5/content/ContentVersion.TAG : Ljava/lang/String;
    //   117: ldc 'Error encountered in reading version file.'
    //   119: aload_3
    //   120: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   123: pop
    //   124: aload_0
    //   125: ifnull -> 132
    //   128: aload_0
    //   129: invokevirtual close : ()V
    //   132: aload #4
    //   134: ifnull -> 142
    //   137: aload #4
    //   139: invokevirtual close : ()V
    //   142: invokestatic getBlankContentVersion : ()Lcom/amazon/ags/html5/content/ContentVersion;
    //   145: areturn
    //   146: astore_0
    //   147: getstatic com/amazon/ags/html5/content/ContentVersion.TAG : Ljava/lang/String;
    //   150: ldc 'Error encountered while cleaning up version file read operation'
    //   152: aload_0
    //   153: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   156: pop
    //   157: goto -> 142
    //   160: astore_0
    //   161: aload_2
    //   162: ifnull -> 169
    //   165: aload_2
    //   166: invokevirtual close : ()V
    //   169: aload_1
    //   170: ifnull -> 177
    //   173: aload_1
    //   174: invokevirtual close : ()V
    //   177: aload_0
    //   178: athrow
    //   179: astore_1
    //   180: getstatic com/amazon/ags/html5/content/ContentVersion.TAG : Ljava/lang/String;
    //   183: ldc 'Error encountered while cleaning up version file read operation'
    //   185: aload_1
    //   186: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   189: pop
    //   190: goto -> 177
    //   193: astore #4
    //   195: aload_3
    //   196: astore_1
    //   197: aload_0
    //   198: astore_2
    //   199: aload #4
    //   201: astore_0
    //   202: goto -> 161
    //   205: astore_3
    //   206: aload_0
    //   207: astore_2
    //   208: aload_3
    //   209: astore_0
    //   210: goto -> 161
    //   213: astore_3
    //   214: goto -> 109
    //   217: astore_3
    //   218: aload_1
    //   219: astore #4
    //   221: goto -> 109
    // Exception table:
    //   from	to	target	type
    //   39	48	105	java/io/IOException
    //   39	48	160	finally
    //   48	64	213	java/io/IOException
    //   48	64	193	finally
    //   64	72	217	java/io/IOException
    //   64	72	205	finally
    //   76	80	92	java/io/IOException
    //   86	90	92	java/io/IOException
    //   114	124	160	finally
    //   128	132	146	java/io/IOException
    //   137	142	146	java/io/IOException
    //   165	169	179	java/io/IOException
    //   173	177	179	java/io/IOException
  }
  
  public static ContentVersion createVersionFromZip(ZipFile paramZipFile) {
    ZipEntry zipEntry = paramZipFile.getEntry("version.txt");
    if (zipEntry == null)
      return null; 
    ContentVersion contentVersion1 = null;
    ContentVersion contentVersion2 = null;
    try {
      BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramZipFile.getInputStream(zipEntry)));
      try {
        contentVersion1 = parseContentVersion(bufferedReader.readLine());
      } catch (IOException iOException1) {
      
      } finally {
        ContentVersion contentVersion;
        contentVersion2 = null;
        IOException iOException1 = iOException;
      } 
    } catch (IOException iOException1) {
      ContentVersion contentVersion = contentVersion2;
      IOException iOException2 = iOException1;
      contentVersion1 = contentVersion;
      Log.e(TAG, "Error encountered in reading version file.", iOException2);
      if (contentVersion != null)
        try {
          contentVersion.close();
        } catch (IOException iOException) {
          Log.e(TAG, "Error encountered while cleaning up version file read operation", iOException);
        }  
      return getBlankContentVersion();
    } finally {}
    if (contentVersion1 != null)
      try {
        contentVersion1.close();
      } catch (IOException iOException) {
        Log.e(TAG, "Error encountered while cleaning up version file read operation", iOException);
      }  
    throw paramZipFile;
  }
  
  public static ContentVersion getBlankContentVersion() {
    return new ContentVersion(-1, -1, -1);
  }
  
  private static ContentVersion parseContentVersion(String paramString) {
    ContentVersion contentVersion = null;
    if (paramString.contains("version")) {
      String[] arrayOfString = paramString.split("::");
      if (arrayOfString.length != 2)
        return null; 
      arrayOfString = arrayOfString[1].trim().split("\\.");
      if (arrayOfString.length != 3)
        return null; 
      try {
        return new ContentVersion(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]));
      } catch (NumberFormatException numberFormatException) {
        return null;
      } 
    } 
    return contentVersion;
  }
  
  public int compareTo(ContentVersion paramContentVersion) {
    if (paramContentVersion == null)
      throw new IllegalArgumentException("Compared version must not be null"); 
    int j = this.majorVersion.compareTo(Integer.valueOf(paramContentVersion.getMajorVersion()));
    int i = j;
    if (j == 0)
      i = this.minorVersion.compareTo(Integer.valueOf(paramContentVersion.getMinorVersion())); 
    j = i;
    if (i == 0)
      j = this.patchVersion.compareTo(Integer.valueOf(paramContentVersion.getPatchVersion())); 
    return j;
  }
  
  public int getMajorVersion() {
    return this.majorVersion.intValue();
  }
  
  public int getMinorVersion() {
    return this.minorVersion.intValue();
  }
  
  public int getPatchVersion() {
    return this.patchVersion.intValue();
  }
  
  public String getVersion() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.majorVersion);
    stringBuilder.append(".");
    stringBuilder.append(this.minorVersion);
    stringBuilder.append(".");
    stringBuilder.append(this.patchVersion);
    return stringBuilder.toString();
  }
  
  public String toString() {
    return getVersion();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\content\ContentVersion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */