package com.amazon.ags.html5.content;

import android.content.Context;
import java.io.File;

public class FileUtils {
  private static final int BYTES_PER_KILOBYTE = 1024;
  
  private static final int DOWNLOAD_BUFFER_SIZE_BYTES = 8192;
  
  private static final int DOWNLOAD_CONNECTION_TIMEOUT_MS = 2000;
  
  private static final int DOWNLOAD_READ_TIMEOUT_MS = 2000;
  
  private static final int MAX_DOWNLOAD_TIME_MS = 5000;
  
  private static final String PARTIAL_DOWNLOAD_FILENAME_MODIFIER = ".part";
  
  private static final String TAG = "GC_" + FileUtils.class.getSimpleName();
  
  private static final int ZIP_BUFFER_SIZE = 2048;
  
  public static boolean copyResourceContentIntoDirectory(Context paramContext, String paramString1, String paramString2, String paramString3) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/content/FileUtils
    //   2: monitorenter
    //   3: iconst_1
    //   4: istore #6
    //   6: iconst_1
    //   7: istore #5
    //   9: aconst_null
    //   10: astore #12
    //   12: aconst_null
    //   13: astore #11
    //   15: aconst_null
    //   16: astore #10
    //   18: aconst_null
    //   19: astore #8
    //   21: aload #12
    //   23: astore #9
    //   25: aload_0
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: aload_0
    //   30: ldc 'raw'
    //   32: aload_1
    //   33: invokestatic getIdentifier : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I
    //   36: invokevirtual openRawResource : (I)Ljava/io/InputStream;
    //   39: astore_0
    //   40: aload #12
    //   42: astore #9
    //   44: aload_0
    //   45: astore #8
    //   47: aload_0
    //   48: astore #10
    //   50: new java/io/File
    //   53: dup
    //   54: aload_3
    //   55: invokespecial <init> : (Ljava/lang/String;)V
    //   58: invokestatic ensureDirectoryExists : (Ljava/io/File;)Z
    //   61: istore #7
    //   63: iload #7
    //   65: ifne -> 141
    //   68: iconst_0
    //   69: istore #6
    //   71: aload_0
    //   72: ifnull -> 79
    //   75: aload_0
    //   76: invokevirtual close : ()V
    //   79: iconst_0
    //   80: ifeq -> 91
    //   83: new java/lang/NullPointerException
    //   86: dup
    //   87: invokespecial <init> : ()V
    //   90: athrow
    //   91: iload #6
    //   93: istore #5
    //   95: ldc com/amazon/ags/html5/content/FileUtils
    //   97: monitorexit
    //   98: iload #5
    //   100: ireturn
    //   101: astore_0
    //   102: iconst_0
    //   103: istore #5
    //   105: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   108: new java/lang/StringBuilder
    //   111: dup
    //   112: invokespecial <init> : ()V
    //   115: ldc 'An error occurred while cleaning up resource copy operation for resource: '
    //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: aload_1
    //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: invokevirtual toString : ()Ljava/lang/String;
    //   127: aload_0
    //   128: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   131: pop
    //   132: goto -> 91
    //   135: astore_0
    //   136: ldc com/amazon/ags/html5/content/FileUtils
    //   138: monitorexit
    //   139: aload_0
    //   140: athrow
    //   141: aload #12
    //   143: astore #9
    //   145: aload_0
    //   146: astore #8
    //   148: aload_0
    //   149: astore #10
    //   151: new java/io/FileOutputStream
    //   154: dup
    //   155: new java/io/File
    //   158: dup
    //   159: new java/lang/StringBuilder
    //   162: dup
    //   163: invokespecial <init> : ()V
    //   166: aload_3
    //   167: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: getstatic java/io/File.separator : Ljava/lang/String;
    //   173: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   176: aload_2
    //   177: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   180: invokevirtual toString : ()Ljava/lang/String;
    //   183: invokespecial <init> : (Ljava/lang/String;)V
    //   186: invokespecial <init> : (Ljava/io/File;)V
    //   189: astore_2
    //   190: sipush #1024
    //   193: newarray byte
    //   195: astore_3
    //   196: aload_0
    //   197: aload_3
    //   198: invokevirtual read : ([B)I
    //   201: istore #4
    //   203: iload #4
    //   205: iconst_m1
    //   206: if_icmpeq -> 298
    //   209: aload_2
    //   210: aload_3
    //   211: iconst_0
    //   212: iload #4
    //   214: invokevirtual write : ([BII)V
    //   217: goto -> 196
    //   220: astore_3
    //   221: aload_0
    //   222: astore #10
    //   224: aload_2
    //   225: astore_0
    //   226: aload_3
    //   227: astore_2
    //   228: iconst_0
    //   229: istore #6
    //   231: aload_0
    //   232: astore #9
    //   234: aload #10
    //   236: astore #8
    //   238: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   241: new java/lang/StringBuilder
    //   244: dup
    //   245: invokespecial <init> : ()V
    //   248: ldc 'An error occurred while attempting to access resource: '
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: aload_1
    //   254: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   257: invokevirtual toString : ()Ljava/lang/String;
    //   260: aload_2
    //   261: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   264: pop
    //   265: aload #10
    //   267: ifnull -> 275
    //   270: aload #10
    //   272: invokevirtual close : ()V
    //   275: iload #6
    //   277: istore #5
    //   279: aload_0
    //   280: ifnull -> 295
    //   283: aload_0
    //   284: invokevirtual flush : ()V
    //   287: aload_0
    //   288: invokevirtual close : ()V
    //   291: iload #6
    //   293: istore #5
    //   295: goto -> 95
    //   298: aload_0
    //   299: ifnull -> 306
    //   302: aload_0
    //   303: invokevirtual close : ()V
    //   306: aload_2
    //   307: ifnull -> 318
    //   310: aload_2
    //   311: invokevirtual flush : ()V
    //   314: aload_2
    //   315: invokevirtual close : ()V
    //   318: iload #6
    //   320: istore #5
    //   322: goto -> 295
    //   325: astore_0
    //   326: iconst_0
    //   327: istore #5
    //   329: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   332: new java/lang/StringBuilder
    //   335: dup
    //   336: invokespecial <init> : ()V
    //   339: ldc 'An error occurred while cleaning up resource copy operation for resource: '
    //   341: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   344: aload_1
    //   345: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   348: invokevirtual toString : ()Ljava/lang/String;
    //   351: aload_0
    //   352: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   355: pop
    //   356: goto -> 295
    //   359: astore_0
    //   360: iconst_0
    //   361: istore #5
    //   363: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   366: new java/lang/StringBuilder
    //   369: dup
    //   370: invokespecial <init> : ()V
    //   373: ldc 'An error occurred while cleaning up resource copy operation for resource: '
    //   375: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   378: aload_1
    //   379: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   382: invokevirtual toString : ()Ljava/lang/String;
    //   385: aload_0
    //   386: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   389: pop
    //   390: goto -> 295
    //   393: astore_0
    //   394: aload #8
    //   396: ifnull -> 404
    //   399: aload #8
    //   401: invokevirtual close : ()V
    //   404: aload #9
    //   406: ifnull -> 419
    //   409: aload #9
    //   411: invokevirtual flush : ()V
    //   414: aload #9
    //   416: invokevirtual close : ()V
    //   419: aload_0
    //   420: athrow
    //   421: astore_2
    //   422: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   425: new java/lang/StringBuilder
    //   428: dup
    //   429: invokespecial <init> : ()V
    //   432: ldc 'An error occurred while cleaning up resource copy operation for resource: '
    //   434: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   437: aload_1
    //   438: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   441: invokevirtual toString : ()Ljava/lang/String;
    //   444: aload_2
    //   445: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   448: pop
    //   449: goto -> 419
    //   452: astore_3
    //   453: aload_2
    //   454: astore #9
    //   456: aload_0
    //   457: astore #8
    //   459: aload_3
    //   460: astore_0
    //   461: goto -> 394
    //   464: astore_2
    //   465: aload #11
    //   467: astore_0
    //   468: goto -> 228
    //   471: astore_0
    //   472: goto -> 136
    // Exception table:
    //   from	to	target	type
    //   25	40	464	java/lang/Exception
    //   25	40	393	finally
    //   50	63	464	java/lang/Exception
    //   50	63	393	finally
    //   75	79	101	java/lang/Exception
    //   75	79	135	finally
    //   83	91	101	java/lang/Exception
    //   83	91	135	finally
    //   105	132	135	finally
    //   151	190	464	java/lang/Exception
    //   151	190	393	finally
    //   190	196	220	java/lang/Exception
    //   190	196	452	finally
    //   196	203	220	java/lang/Exception
    //   196	203	452	finally
    //   209	217	220	java/lang/Exception
    //   209	217	452	finally
    //   238	265	393	finally
    //   270	275	359	java/lang/Exception
    //   270	275	135	finally
    //   283	291	359	java/lang/Exception
    //   283	291	135	finally
    //   302	306	325	java/lang/Exception
    //   302	306	471	finally
    //   310	318	325	java/lang/Exception
    //   310	318	471	finally
    //   329	356	471	finally
    //   363	390	135	finally
    //   399	404	421	java/lang/Exception
    //   399	404	135	finally
    //   409	419	421	java/lang/Exception
    //   409	419	135	finally
    //   419	421	135	finally
    //   422	449	135	finally
  }
  
  public static boolean deleteDirectory(File paramFile) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_3
    //   2: ldc com/amazon/ags/html5/content/FileUtils
    //   4: monitorenter
    //   5: iconst_1
    //   6: istore #4
    //   8: aload_0
    //   9: invokevirtual exists : ()Z
    //   12: istore #5
    //   14: iload #5
    //   16: ifne -> 24
    //   19: ldc com/amazon/ags/html5/content/FileUtils
    //   21: monitorexit
    //   22: iload_3
    //   23: ireturn
    //   24: aload_0
    //   25: invokevirtual canWrite : ()Z
    //   28: ifne -> 44
    //   31: aload_0
    //   32: iconst_1
    //   33: invokevirtual setWritable : (Z)Z
    //   36: ifne -> 44
    //   39: iconst_0
    //   40: istore_3
    //   41: goto -> 19
    //   44: iload #4
    //   46: istore_3
    //   47: aload_0
    //   48: invokevirtual exists : ()Z
    //   51: ifeq -> 138
    //   54: aload_0
    //   55: invokevirtual listFiles : ()[Ljava/io/File;
    //   58: astore #6
    //   60: aload #6
    //   62: arraylength
    //   63: istore_2
    //   64: iconst_0
    //   65: istore_1
    //   66: iload_1
    //   67: iload_2
    //   68: if_icmpge -> 133
    //   71: aload #6
    //   73: iload_1
    //   74: aaload
    //   75: astore #7
    //   77: aload #7
    //   79: invokevirtual isDirectory : ()Z
    //   82: ifeq -> 98
    //   85: aload #7
    //   87: invokestatic deleteDirectory : (Ljava/io/File;)Z
    //   90: ifne -> 147
    //   93: iconst_0
    //   94: istore_3
    //   95: goto -> 19
    //   98: aload #7
    //   100: invokevirtual canWrite : ()Z
    //   103: ifne -> 120
    //   106: aload #7
    //   108: iconst_1
    //   109: invokevirtual setWritable : (Z)Z
    //   112: ifne -> 120
    //   115: iconst_0
    //   116: istore_3
    //   117: goto -> 19
    //   120: aload #7
    //   122: invokevirtual delete : ()Z
    //   125: ifne -> 147
    //   128: iconst_0
    //   129: istore_3
    //   130: goto -> 19
    //   133: aload_0
    //   134: invokevirtual delete : ()Z
    //   137: istore_3
    //   138: goto -> 19
    //   141: astore_0
    //   142: ldc com/amazon/ags/html5/content/FileUtils
    //   144: monitorexit
    //   145: aload_0
    //   146: athrow
    //   147: iload_1
    //   148: iconst_1
    //   149: iadd
    //   150: istore_1
    //   151: goto -> 66
    // Exception table:
    //   from	to	target	type
    //   8	14	141	finally
    //   24	39	141	finally
    //   47	64	141	finally
    //   77	93	141	finally
    //   98	115	141	finally
    //   120	128	141	finally
    //   133	138	141	finally
  }
  
  public static boolean downloadFile(String paramString1, String paramString2, long paramLong) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/content/FileUtils
    //   2: monitorenter
    //   3: iconst_0
    //   4: istore #12
    //   6: iconst_0
    //   7: istore #11
    //   9: aconst_null
    //   10: astore #18
    //   12: aconst_null
    //   13: astore #17
    //   15: aconst_null
    //   16: astore #19
    //   18: aconst_null
    //   19: astore #15
    //   21: aconst_null
    //   22: astore #16
    //   24: aload #18
    //   26: astore #13
    //   28: aload #19
    //   30: astore #14
    //   32: new java/net/URL
    //   35: dup
    //   36: aload_0
    //   37: invokespecial <init> : (Ljava/lang/String;)V
    //   40: astore_0
    //   41: aload #18
    //   43: astore #13
    //   45: aload #19
    //   47: astore #14
    //   49: aload_0
    //   50: invokevirtual openConnection : ()Ljava/net/URLConnection;
    //   53: astore #20
    //   55: aload #18
    //   57: astore #13
    //   59: aload #19
    //   61: astore #14
    //   63: aload #20
    //   65: sipush #2000
    //   68: invokevirtual setConnectTimeout : (I)V
    //   71: aload #18
    //   73: astore #13
    //   75: aload #19
    //   77: astore #14
    //   79: aload #20
    //   81: sipush #2000
    //   84: invokevirtual setReadTimeout : (I)V
    //   87: aload #18
    //   89: astore #13
    //   91: aload #19
    //   93: astore #14
    //   95: aload #20
    //   97: iconst_0
    //   98: invokevirtual setUseCaches : (Z)V
    //   101: aload #18
    //   103: astore #13
    //   105: aload #19
    //   107: astore #14
    //   109: aload #20
    //   111: invokevirtual connect : ()V
    //   114: aload #18
    //   116: astore #13
    //   118: aload #19
    //   120: astore #14
    //   122: new java/io/BufferedInputStream
    //   125: dup
    //   126: aload_0
    //   127: invokevirtual openStream : ()Ljava/io/InputStream;
    //   130: sipush #8192
    //   133: invokespecial <init> : (Ljava/io/InputStream;I)V
    //   136: astore_0
    //   137: new java/io/File
    //   140: dup
    //   141: new java/lang/StringBuilder
    //   144: dup
    //   145: invokespecial <init> : ()V
    //   148: aload_1
    //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: ldc '.part'
    //   154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: invokevirtual toString : ()Ljava/lang/String;
    //   160: invokespecial <init> : (Ljava/lang/String;)V
    //   163: astore #14
    //   165: new java/io/FileOutputStream
    //   168: dup
    //   169: aload #14
    //   171: invokespecial <init> : (Ljava/io/File;)V
    //   174: astore #13
    //   176: sipush #1024
    //   179: newarray byte
    //   181: astore #15
    //   183: lconst_0
    //   184: lstore #5
    //   186: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   189: ldc 'Beginning download of %s'
    //   191: iconst_1
    //   192: anewarray java/lang/Object
    //   195: dup
    //   196: iconst_0
    //   197: aload_1
    //   198: aastore
    //   199: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   202: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   205: pop
    //   206: invokestatic currentTimeMillis : ()J
    //   209: lstore #9
    //   211: aload_0
    //   212: aload #15
    //   214: invokevirtual read : ([B)I
    //   217: istore #4
    //   219: lload #5
    //   221: lstore #7
    //   223: iload #4
    //   225: iconst_m1
    //   226: if_icmpeq -> 271
    //   229: lload #5
    //   231: iload #4
    //   233: i2l
    //   234: ladd
    //   235: lstore #7
    //   237: aload #13
    //   239: aload #15
    //   241: iconst_0
    //   242: iload #4
    //   244: invokevirtual write : ([BII)V
    //   247: lload #7
    //   249: lstore #5
    //   251: invokestatic currentTimeMillis : ()J
    //   254: lload #9
    //   256: lsub
    //   257: lload_2
    //   258: lcmp
    //   259: iflt -> 211
    //   262: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   265: ldc 'Maximum time to download file exceeded.  Aborting download.'
    //   267: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   270: pop
    //   271: lload #7
    //   273: lconst_0
    //   274: lcmp
    //   275: ifle -> 293
    //   278: aload #14
    //   280: new java/io/File
    //   283: dup
    //   284: aload_1
    //   285: invokespecial <init> : (Ljava/lang/String;)V
    //   288: invokevirtual renameTo : (Ljava/io/File;)Z
    //   291: istore #11
    //   293: aload #13
    //   295: ifnull -> 308
    //   298: aload #13
    //   300: invokevirtual flush : ()V
    //   303: aload #13
    //   305: invokevirtual close : ()V
    //   308: aload_0
    //   309: ifnull -> 316
    //   312: aload_0
    //   313: invokevirtual close : ()V
    //   316: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   319: ldc 'Download of %s was successful: %b'
    //   321: iconst_2
    //   322: anewarray java/lang/Object
    //   325: dup
    //   326: iconst_0
    //   327: aload_1
    //   328: aastore
    //   329: dup
    //   330: iconst_1
    //   331: iload #11
    //   333: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   336: aastore
    //   337: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   340: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   343: pop
    //   344: ldc com/amazon/ags/html5/content/FileUtils
    //   346: monitorexit
    //   347: iload #11
    //   349: ireturn
    //   350: astore_0
    //   351: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   354: ldc 'Error encountered during post-download cleanup'
    //   356: aload_0
    //   357: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   360: pop
    //   361: goto -> 316
    //   364: astore #15
    //   366: aload #17
    //   368: astore_0
    //   369: aload_0
    //   370: astore #13
    //   372: aload #16
    //   374: astore #14
    //   376: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   379: ldc 'Error encountered while trying to download file'
    //   381: aload #15
    //   383: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   386: pop
    //   387: aload #16
    //   389: ifnull -> 402
    //   392: aload #16
    //   394: invokevirtual flush : ()V
    //   397: aload #16
    //   399: invokevirtual close : ()V
    //   402: iload #12
    //   404: istore #11
    //   406: aload_0
    //   407: ifnull -> 316
    //   410: aload_0
    //   411: invokevirtual close : ()V
    //   414: iload #12
    //   416: istore #11
    //   418: goto -> 316
    //   421: astore_0
    //   422: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   425: ldc 'Error encountered during post-download cleanup'
    //   427: aload_0
    //   428: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   431: pop
    //   432: iload #12
    //   434: istore #11
    //   436: goto -> 316
    //   439: astore_0
    //   440: ldc com/amazon/ags/html5/content/FileUtils
    //   442: monitorexit
    //   443: aload_0
    //   444: athrow
    //   445: astore_0
    //   446: aload #14
    //   448: ifnull -> 461
    //   451: aload #14
    //   453: invokevirtual flush : ()V
    //   456: aload #14
    //   458: invokevirtual close : ()V
    //   461: aload #13
    //   463: ifnull -> 471
    //   466: aload #13
    //   468: invokevirtual close : ()V
    //   471: aload_0
    //   472: athrow
    //   473: astore_1
    //   474: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   477: ldc 'Error encountered during post-download cleanup'
    //   479: aload_1
    //   480: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   483: pop
    //   484: goto -> 471
    //   487: astore_1
    //   488: aload_0
    //   489: astore #13
    //   491: aload #15
    //   493: astore #14
    //   495: aload_1
    //   496: astore_0
    //   497: goto -> 446
    //   500: astore_1
    //   501: aload #13
    //   503: astore #14
    //   505: aload_0
    //   506: astore #13
    //   508: aload_1
    //   509: astore_0
    //   510: goto -> 446
    //   513: astore #15
    //   515: goto -> 369
    //   518: astore #15
    //   520: aload #13
    //   522: astore #16
    //   524: goto -> 369
    //   527: astore_0
    //   528: goto -> 440
    // Exception table:
    //   from	to	target	type
    //   32	41	364	java/lang/Exception
    //   32	41	445	finally
    //   49	55	364	java/lang/Exception
    //   49	55	445	finally
    //   63	71	364	java/lang/Exception
    //   63	71	445	finally
    //   79	87	364	java/lang/Exception
    //   79	87	445	finally
    //   95	101	364	java/lang/Exception
    //   95	101	445	finally
    //   109	114	364	java/lang/Exception
    //   109	114	445	finally
    //   122	137	364	java/lang/Exception
    //   122	137	445	finally
    //   137	176	513	java/lang/Exception
    //   137	176	487	finally
    //   176	183	518	java/lang/Exception
    //   176	183	500	finally
    //   186	211	518	java/lang/Exception
    //   186	211	500	finally
    //   211	219	518	java/lang/Exception
    //   211	219	500	finally
    //   237	247	518	java/lang/Exception
    //   237	247	500	finally
    //   251	271	518	java/lang/Exception
    //   251	271	500	finally
    //   278	293	518	java/lang/Exception
    //   278	293	500	finally
    //   298	308	350	java/lang/Exception
    //   298	308	527	finally
    //   312	316	350	java/lang/Exception
    //   312	316	527	finally
    //   316	344	439	finally
    //   351	361	527	finally
    //   376	387	445	finally
    //   392	402	421	java/lang/Exception
    //   392	402	439	finally
    //   410	414	421	java/lang/Exception
    //   410	414	439	finally
    //   422	432	439	finally
    //   451	461	473	java/lang/Exception
    //   451	461	439	finally
    //   466	471	473	java/lang/Exception
    //   466	471	439	finally
    //   471	473	439	finally
    //   474	484	439	finally
  }
  
  public static boolean ensureDirectoryExists(File paramFile) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/content/FileUtils
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 14
    //   7: iconst_0
    //   8: istore_1
    //   9: ldc com/amazon/ags/html5/content/FileUtils
    //   11: monitorexit
    //   12: iload_1
    //   13: ireturn
    //   14: iconst_1
    //   15: istore_2
    //   16: iload_2
    //   17: istore_1
    //   18: aload_0
    //   19: invokevirtual exists : ()Z
    //   22: ifne -> 9
    //   25: aload_0
    //   26: invokevirtual mkdirs : ()Z
    //   29: pop
    //   30: aload_0
    //   31: invokevirtual exists : ()Z
    //   34: ifne -> 42
    //   37: iconst_0
    //   38: istore_1
    //   39: goto -> 9
    //   42: aload_0
    //   43: iconst_1
    //   44: invokevirtual setWritable : (Z)Z
    //   47: pop
    //   48: iload_2
    //   49: istore_1
    //   50: goto -> 9
    //   53: astore_0
    //   54: ldc com/amazon/ags/html5/content/FileUtils
    //   56: monitorexit
    //   57: aload_0
    //   58: athrow
    // Exception table:
    //   from	to	target	type
    //   18	37	53	finally
    //   42	48	53	finally
  }
  
  public static boolean extractZipToDirectory(String paramString1, String paramString2) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/content/FileUtils
    //   2: monitorenter
    //   3: new java/io/File
    //   6: dup
    //   7: aload_1
    //   8: invokespecial <init> : (Ljava/lang/String;)V
    //   11: invokestatic ensureDirectoryExists : (Ljava/io/File;)Z
    //   14: istore_3
    //   15: iload_3
    //   16: ifne -> 26
    //   19: iconst_0
    //   20: istore_3
    //   21: ldc com/amazon/ags/html5/content/FileUtils
    //   23: monitorexit
    //   24: iload_3
    //   25: ireturn
    //   26: new java/util/zip/ZipFile
    //   29: dup
    //   30: new java/io/File
    //   33: dup
    //   34: aload_0
    //   35: invokespecial <init> : (Ljava/lang/String;)V
    //   38: invokespecial <init> : (Ljava/io/File;)V
    //   41: astore #10
    //   43: iconst_1
    //   44: istore #4
    //   46: aload #10
    //   48: invokevirtual entries : ()Ljava/util/Enumeration;
    //   51: astore #11
    //   53: iload #4
    //   55: istore_3
    //   56: aload #11
    //   58: invokeinterface hasMoreElements : ()Z
    //   63: ifeq -> 21
    //   66: aload #11
    //   68: invokeinterface nextElement : ()Ljava/lang/Object;
    //   73: checkcast java/util/zip/ZipEntry
    //   76: astore_0
    //   77: new java/io/File
    //   80: dup
    //   81: aload_1
    //   82: aload_0
    //   83: invokevirtual getName : ()Ljava/lang/String;
    //   86: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   89: astore #12
    //   91: aload #12
    //   93: invokevirtual getParentFile : ()Ljava/io/File;
    //   96: invokestatic ensureDirectoryExists : (Ljava/io/File;)Z
    //   99: pop
    //   100: aload_0
    //   101: invokevirtual isDirectory : ()Z
    //   104: istore_3
    //   105: iload_3
    //   106: ifne -> 53
    //   109: aconst_null
    //   110: astore #6
    //   112: aconst_null
    //   113: astore #9
    //   115: aconst_null
    //   116: astore #5
    //   118: aconst_null
    //   119: astore #8
    //   121: aconst_null
    //   122: astore #7
    //   124: new java/io/BufferedInputStream
    //   127: dup
    //   128: aload #10
    //   130: aload_0
    //   131: invokevirtual getInputStream : (Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;
    //   134: invokespecial <init> : (Ljava/io/InputStream;)V
    //   137: astore_0
    //   138: sipush #2048
    //   141: newarray byte
    //   143: astore #6
    //   145: new java/io/FileOutputStream
    //   148: dup
    //   149: aload #12
    //   151: invokespecial <init> : (Ljava/io/File;)V
    //   154: astore #5
    //   156: new java/io/BufferedOutputStream
    //   159: dup
    //   160: aload #5
    //   162: sipush #2048
    //   165: invokespecial <init> : (Ljava/io/OutputStream;I)V
    //   168: astore #5
    //   170: aload_0
    //   171: aload #6
    //   173: iconst_0
    //   174: sipush #2048
    //   177: invokevirtual read : ([BII)I
    //   180: istore_2
    //   181: iload_2
    //   182: iconst_m1
    //   183: if_icmpeq -> 296
    //   186: aload #5
    //   188: aload #6
    //   190: iconst_0
    //   191: iload_2
    //   192: invokevirtual write : ([BII)V
    //   195: goto -> 170
    //   198: astore_1
    //   199: aload #5
    //   201: astore #7
    //   203: iconst_0
    //   204: istore #4
    //   206: aload #7
    //   208: astore #5
    //   210: aload_0
    //   211: astore #6
    //   213: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   216: ldc_w 'An error occurred while performing zip extraction operation'
    //   219: aload_1
    //   220: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   223: pop
    //   224: aload #7
    //   226: ifnull -> 239
    //   229: aload #7
    //   231: invokevirtual flush : ()V
    //   234: aload #7
    //   236: invokevirtual close : ()V
    //   239: iload #4
    //   241: istore_3
    //   242: aload_0
    //   243: ifnull -> 21
    //   246: aload_0
    //   247: invokevirtual close : ()V
    //   250: iload #4
    //   252: istore_3
    //   253: goto -> 21
    //   256: astore_0
    //   257: iconst_0
    //   258: istore_3
    //   259: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   262: ldc_w 'An error occurred while cleaning up zip extraction operation'
    //   265: aload_0
    //   266: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   269: pop
    //   270: goto -> 21
    //   273: astore_0
    //   274: ldc com/amazon/ags/html5/content/FileUtils
    //   276: monitorexit
    //   277: aload_0
    //   278: athrow
    //   279: astore_0
    //   280: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   283: ldc_w 'Unable to extract zip file'
    //   286: aload_0
    //   287: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   290: pop
    //   291: iconst_0
    //   292: istore_3
    //   293: goto -> 21
    //   296: aload #5
    //   298: ifnull -> 311
    //   301: aload #5
    //   303: invokevirtual flush : ()V
    //   306: aload #5
    //   308: invokevirtual close : ()V
    //   311: aload_0
    //   312: ifnull -> 53
    //   315: aload_0
    //   316: invokevirtual close : ()V
    //   319: goto -> 53
    //   322: astore_0
    //   323: iconst_0
    //   324: istore_3
    //   325: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   328: ldc_w 'An error occurred while cleaning up zip extraction operation'
    //   331: aload_0
    //   332: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   335: pop
    //   336: goto -> 21
    //   339: astore_1
    //   340: aload #6
    //   342: astore_0
    //   343: aload #5
    //   345: ifnull -> 358
    //   348: aload #5
    //   350: invokevirtual flush : ()V
    //   353: aload #5
    //   355: invokevirtual close : ()V
    //   358: aload_0
    //   359: ifnull -> 366
    //   362: aload_0
    //   363: invokevirtual close : ()V
    //   366: aload_1
    //   367: athrow
    //   368: astore_0
    //   369: iconst_0
    //   370: istore_3
    //   371: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   374: ldc_w 'An error occurred while cleaning up zip extraction operation'
    //   377: aload_0
    //   378: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   381: pop
    //   382: goto -> 21
    //   385: astore_1
    //   386: aload #8
    //   388: astore #5
    //   390: goto -> 343
    //   393: astore_1
    //   394: aload #8
    //   396: astore #5
    //   398: goto -> 343
    //   401: astore_1
    //   402: goto -> 343
    //   405: astore_1
    //   406: aload #9
    //   408: astore_0
    //   409: goto -> 203
    //   412: astore_1
    //   413: goto -> 203
    //   416: astore_1
    //   417: goto -> 203
    // Exception table:
    //   from	to	target	type
    //   3	15	273	finally
    //   26	43	279	java/lang/Exception
    //   26	43	273	finally
    //   46	53	273	finally
    //   56	105	273	finally
    //   124	138	405	java/lang/Exception
    //   124	138	339	finally
    //   138	156	412	java/lang/Exception
    //   138	156	385	finally
    //   156	170	416	java/lang/Exception
    //   156	170	393	finally
    //   170	181	198	java/lang/Exception
    //   170	181	401	finally
    //   186	195	198	java/lang/Exception
    //   186	195	401	finally
    //   213	224	339	finally
    //   229	239	256	java/lang/Exception
    //   229	239	273	finally
    //   246	250	256	java/lang/Exception
    //   246	250	273	finally
    //   259	270	273	finally
    //   280	291	273	finally
    //   301	311	322	java/lang/Exception
    //   301	311	273	finally
    //   315	319	322	java/lang/Exception
    //   315	319	273	finally
    //   325	336	273	finally
    //   348	358	368	java/lang/Exception
    //   348	358	273	finally
    //   362	366	368	java/lang/Exception
    //   362	366	273	finally
    //   366	368	273	finally
    //   371	382	273	finally
  }
  
  public static long getDirectorySize(File paramFile) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/content/FileUtils
    //   2: monitorenter
    //   3: lconst_0
    //   4: lstore_3
    //   5: aload_0
    //   6: invokevirtual listFiles : ()[Ljava/io/File;
    //   9: astore_0
    //   10: aload_0
    //   11: arraylength
    //   12: istore_2
    //   13: iconst_0
    //   14: istore_1
    //   15: iload_1
    //   16: iload_2
    //   17: if_icmpge -> 59
    //   20: aload_0
    //   21: iload_1
    //   22: aaload
    //   23: astore #7
    //   25: aload #7
    //   27: invokevirtual isDirectory : ()Z
    //   30: ifeq -> 44
    //   33: lload_3
    //   34: aload #7
    //   36: invokestatic getDirectorySize : (Ljava/io/File;)J
    //   39: ladd
    //   40: lstore_3
    //   41: goto -> 70
    //   44: aload #7
    //   46: invokevirtual length : ()J
    //   49: lstore #5
    //   51: lload_3
    //   52: lload #5
    //   54: ladd
    //   55: lstore_3
    //   56: goto -> 70
    //   59: ldc com/amazon/ags/html5/content/FileUtils
    //   61: monitorexit
    //   62: lload_3
    //   63: lreturn
    //   64: astore_0
    //   65: ldc com/amazon/ags/html5/content/FileUtils
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    //   70: iload_1
    //   71: iconst_1
    //   72: iadd
    //   73: istore_1
    //   74: goto -> 15
    // Exception table:
    //   from	to	target	type
    //   5	13	64	finally
    //   25	41	64	finally
    //   44	51	64	finally
  }
  
  public static String getMD5ChecksumForFile(String paramString) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/content/FileUtils
    //   2: monitorenter
    //   3: aload_0
    //   4: invokestatic readFileBytes : (Ljava/lang/String;)[B
    //   7: astore_3
    //   8: aload_3
    //   9: ifnonnull -> 19
    //   12: aconst_null
    //   13: astore_0
    //   14: ldc com/amazon/ags/html5/content/FileUtils
    //   16: monitorexit
    //   17: aload_0
    //   18: areturn
    //   19: new java/lang/StringBuilder
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: astore_0
    //   27: ldc_w 'MD5'
    //   30: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
    //   33: astore #4
    //   35: aload #4
    //   37: invokevirtual reset : ()V
    //   40: aload #4
    //   42: aload_3
    //   43: invokevirtual update : ([B)V
    //   46: new java/math/BigInteger
    //   49: dup
    //   50: iconst_1
    //   51: aload #4
    //   53: invokevirtual digest : ()[B
    //   56: invokespecial <init> : (I[B)V
    //   59: bipush #16
    //   61: invokevirtual toString : (I)Ljava/lang/String;
    //   64: astore_3
    //   65: aload_3
    //   66: ifnull -> 104
    //   69: aload_3
    //   70: invokevirtual length : ()I
    //   73: istore_2
    //   74: iconst_0
    //   75: istore_1
    //   76: iload_1
    //   77: bipush #32
    //   79: iload_2
    //   80: isub
    //   81: if_icmpge -> 98
    //   84: aload_0
    //   85: bipush #48
    //   87: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   90: pop
    //   91: iload_1
    //   92: iconst_1
    //   93: iadd
    //   94: istore_1
    //   95: goto -> 76
    //   98: aload_0
    //   99: aload_3
    //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: pop
    //   104: aload_0
    //   105: invokevirtual toString : ()Ljava/lang/String;
    //   108: astore_0
    //   109: aload_0
    //   110: astore_3
    //   111: aload_0
    //   112: ifnull -> 181
    //   115: aload_0
    //   116: astore_3
    //   117: aload_0
    //   118: invokevirtual length : ()I
    //   121: bipush #32
    //   123: if_icmpeq -> 181
    //   126: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   129: new java/lang/StringBuilder
    //   132: dup
    //   133: invokespecial <init> : ()V
    //   136: ldc_w 'Invalid checksum calculated.  Discarding result: '
    //   139: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   142: aload_0
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: invokevirtual toString : ()Ljava/lang/String;
    //   149: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   152: pop
    //   153: aconst_null
    //   154: astore_3
    //   155: goto -> 181
    //   158: astore_0
    //   159: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   162: ldc_w 'Error encountered during checksum calculation'
    //   165: aload_0
    //   166: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   169: pop
    //   170: aconst_null
    //   171: astore_0
    //   172: goto -> 109
    //   175: astore_0
    //   176: ldc com/amazon/ags/html5/content/FileUtils
    //   178: monitorexit
    //   179: aload_0
    //   180: athrow
    //   181: aload_3
    //   182: astore_0
    //   183: goto -> 14
    // Exception table:
    //   from	to	target	type
    //   3	8	175	finally
    //   19	27	175	finally
    //   27	65	158	java/lang/Exception
    //   27	65	175	finally
    //   69	74	158	java/lang/Exception
    //   69	74	175	finally
    //   84	91	158	java/lang/Exception
    //   84	91	175	finally
    //   98	104	158	java/lang/Exception
    //   98	104	175	finally
    //   104	109	158	java/lang/Exception
    //   104	109	175	finally
    //   117	153	175	finally
    //   159	170	175	finally
  }
  
  public static byte[] readFileBytes(String paramString) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/content/FileUtils
    //   2: monitorenter
    //   3: new java/io/File
    //   6: dup
    //   7: aload_0
    //   8: invokespecial <init> : (Ljava/lang/String;)V
    //   11: astore #7
    //   13: aload #7
    //   15: ifnull -> 38
    //   18: aload #7
    //   20: invokevirtual exists : ()Z
    //   23: ifeq -> 38
    //   26: aload #7
    //   28: invokevirtual canRead : ()Z
    //   31: istore #4
    //   33: iload #4
    //   35: ifne -> 45
    //   38: aconst_null
    //   39: astore_0
    //   40: ldc com/amazon/ags/html5/content/FileUtils
    //   42: monitorexit
    //   43: aload_0
    //   44: areturn
    //   45: aconst_null
    //   46: astore_0
    //   47: aconst_null
    //   48: astore #6
    //   50: new java/io/FileInputStream
    //   53: dup
    //   54: aload #7
    //   56: invokespecial <init> : (Ljava/io/File;)V
    //   59: astore #5
    //   61: aload #7
    //   63: invokevirtual length : ()J
    //   66: l2i
    //   67: istore_2
    //   68: iload_2
    //   69: newarray byte
    //   71: astore_0
    //   72: iconst_0
    //   73: istore_1
    //   74: iload_1
    //   75: iload_2
    //   76: if_icmpge -> 97
    //   79: aload #5
    //   81: aload_0
    //   82: iload_1
    //   83: iload_2
    //   84: iload_1
    //   85: isub
    //   86: invokevirtual read : ([BII)I
    //   89: istore_3
    //   90: iload_1
    //   91: iload_3
    //   92: iadd
    //   93: istore_1
    //   94: goto -> 74
    //   97: aload #5
    //   99: ifnull -> 241
    //   102: aload #5
    //   104: invokevirtual close : ()V
    //   107: goto -> 40
    //   110: astore #5
    //   112: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   115: ldc_w 'Error encountered during post file-to-byte conversion cleanup'
    //   118: aload #5
    //   120: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   123: pop
    //   124: goto -> 107
    //   127: astore_0
    //   128: aload #6
    //   130: astore #5
    //   132: aload_0
    //   133: astore #6
    //   135: aload #5
    //   137: astore_0
    //   138: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   141: ldc_w 'Error encountered when decoding file to bytes'
    //   144: aload #6
    //   146: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   149: pop
    //   150: aconst_null
    //   151: astore #6
    //   153: aload #6
    //   155: astore_0
    //   156: aload #5
    //   158: ifnull -> 107
    //   161: aload #5
    //   163: invokevirtual close : ()V
    //   166: aload #6
    //   168: astore_0
    //   169: goto -> 107
    //   172: astore_0
    //   173: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   176: ldc_w 'Error encountered during post file-to-byte conversion cleanup'
    //   179: aload_0
    //   180: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   183: pop
    //   184: aload #6
    //   186: astore_0
    //   187: goto -> 107
    //   190: astore_0
    //   191: ldc com/amazon/ags/html5/content/FileUtils
    //   193: monitorexit
    //   194: aload_0
    //   195: athrow
    //   196: astore #5
    //   198: aload_0
    //   199: ifnull -> 206
    //   202: aload_0
    //   203: invokevirtual close : ()V
    //   206: aload #5
    //   208: athrow
    //   209: astore_0
    //   210: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   213: ldc_w 'Error encountered during post file-to-byte conversion cleanup'
    //   216: aload_0
    //   217: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   220: pop
    //   221: goto -> 206
    //   224: astore #6
    //   226: aload #5
    //   228: astore_0
    //   229: aload #6
    //   231: astore #5
    //   233: goto -> 198
    //   236: astore #6
    //   238: goto -> 135
    //   241: goto -> 107
    // Exception table:
    //   from	to	target	type
    //   3	13	190	finally
    //   18	33	190	finally
    //   50	61	127	java/lang/Exception
    //   50	61	196	finally
    //   61	72	236	java/lang/Exception
    //   61	72	224	finally
    //   79	90	236	java/lang/Exception
    //   79	90	224	finally
    //   102	107	110	java/lang/Exception
    //   102	107	190	finally
    //   112	124	190	finally
    //   138	150	196	finally
    //   161	166	172	java/lang/Exception
    //   161	166	190	finally
    //   173	184	190	finally
    //   202	206	209	java/lang/Exception
    //   202	206	190	finally
    //   206	209	190	finally
    //   210	221	190	finally
  }
  
  public static boolean renameDirectory(String paramString1, String paramString2) {
    // Byte code:
    //   0: ldc com/amazon/ags/html5/content/FileUtils
    //   2: monitorenter
    //   3: iconst_0
    //   4: istore_2
    //   5: new java/io/File
    //   8: dup
    //   9: aload_0
    //   10: invokespecial <init> : (Ljava/lang/String;)V
    //   13: astore #4
    //   15: new java/io/File
    //   18: dup
    //   19: aload_1
    //   20: invokespecial <init> : (Ljava/lang/String;)V
    //   23: astore #5
    //   25: aload #4
    //   27: aload #5
    //   29: invokevirtual renameTo : (Ljava/io/File;)Z
    //   32: istore_3
    //   33: iload_3
    //   34: istore_2
    //   35: ldc com/amazon/ags/html5/content/FileUtils
    //   37: monitorexit
    //   38: iload_2
    //   39: ireturn
    //   40: astore #4
    //   42: getstatic com/amazon/ags/html5/content/FileUtils.TAG : Ljava/lang/String;
    //   45: new java/lang/StringBuilder
    //   48: dup
    //   49: invokespecial <init> : ()V
    //   52: ldc_w 'Error occurred while trying to rename directory ('
    //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: aload_0
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: ldc_w ') to ('
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: aload_1
    //   69: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: ldc_w ')'
    //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: invokevirtual toString : ()Ljava/lang/String;
    //   81: aload #4
    //   83: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   86: pop
    //   87: goto -> 35
    //   90: astore_0
    //   91: ldc com/amazon/ags/html5/content/FileUtils
    //   93: monitorexit
    //   94: aload_0
    //   95: athrow
    // Exception table:
    //   from	to	target	type
    //   5	25	90	finally
    //   25	33	40	java/lang/Exception
    //   25	33	90	finally
    //   42	87	90	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\content\FileUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */