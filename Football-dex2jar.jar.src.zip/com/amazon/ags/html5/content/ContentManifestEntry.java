package com.amazon.ags.html5.content;

import android.util.Log;
import com.amazon.ags.VersionInfo;
import java.util.Map;

public class ContentManifestEntry {
  private static final String CHECKSUM_KEY = "checksum";
  
  private static final String COMPATIBILITY_KEY = "sdkVersionCompatibility";
  
  private static final String CONTENT_KEY = "content";
  
  private static final String SEPARATOR = ":::";
  
  private static final String TAG = ContentManifestEntry.class.getSimpleName();
  
  private static final String VERSION_KEY = "version";
  
  private String checksum;
  
  private String contentURL;
  
  private ContentVersion contentVersion;
  
  public ContentManifestEntry(ContentVersion paramContentVersion, String paramString1, String paramString2) {
    this.contentVersion = paramContentVersion;
    this.contentURL = paramString1;
    this.checksum = paramString2;
  }
  
  public static Map<String, ContentManifestEntry> createManifestEntriesFromFile(String paramString) {
    // Byte code:
    //   0: new java/util/HashMap
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #12
    //   9: new java/io/File
    //   12: dup
    //   13: aload_0
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: astore_0
    //   18: aload #12
    //   20: astore_2
    //   21: aload_0
    //   22: invokevirtual exists : ()Z
    //   25: ifeq -> 38
    //   28: aload_0
    //   29: invokevirtual isFile : ()Z
    //   32: ifne -> 40
    //   35: aload #12
    //   37: astore_2
    //   38: aload_2
    //   39: areturn
    //   40: aconst_null
    //   41: astore #6
    //   43: aconst_null
    //   44: astore #9
    //   46: aconst_null
    //   47: astore #5
    //   49: aconst_null
    //   50: astore #10
    //   52: aconst_null
    //   53: astore_3
    //   54: aconst_null
    //   55: astore #4
    //   57: aconst_null
    //   58: astore #8
    //   60: aconst_null
    //   61: astore #7
    //   63: new java/io/FileInputStream
    //   66: dup
    //   67: aload_0
    //   68: invokespecial <init> : (Ljava/io/File;)V
    //   71: astore_0
    //   72: new java/io/DataInputStream
    //   75: dup
    //   76: aload_0
    //   77: invokespecial <init> : (Ljava/io/InputStream;)V
    //   80: astore_2
    //   81: new java/io/BufferedReader
    //   84: dup
    //   85: new java/io/InputStreamReader
    //   88: dup
    //   89: aload_2
    //   90: invokespecial <init> : (Ljava/io/InputStream;)V
    //   93: invokespecial <init> : (Ljava/io/Reader;)V
    //   96: astore_3
    //   97: aload_3
    //   98: invokevirtual readLine : ()Ljava/lang/String;
    //   101: astore #4
    //   103: aload #4
    //   105: ifnull -> 563
    //   108: aload #4
    //   110: ldc ':::'
    //   112: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   115: astore #13
    //   117: aload #13
    //   119: arraylength
    //   120: iconst_2
    //   121: if_icmplt -> 97
    //   124: aconst_null
    //   125: astore #5
    //   127: aconst_null
    //   128: astore #4
    //   130: aconst_null
    //   131: astore #6
    //   133: aconst_null
    //   134: astore #7
    //   136: iconst_0
    //   137: istore_1
    //   138: iload_1
    //   139: aload #13
    //   141: arraylength
    //   142: iconst_1
    //   143: isub
    //   144: if_icmpge -> 421
    //   147: ldc 'version'
    //   149: aload #13
    //   151: iload_1
    //   152: aaload
    //   153: invokevirtual equals : (Ljava/lang/Object;)Z
    //   156: ifeq -> 213
    //   159: aload #7
    //   161: astore #8
    //   163: aload #6
    //   165: astore #9
    //   167: aload #5
    //   169: astore #10
    //   171: aload #4
    //   173: astore #11
    //   175: aload #13
    //   177: iload_1
    //   178: iconst_1
    //   179: iadd
    //   180: aaload
    //   181: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   184: ifne -> 727
    //   187: aload #13
    //   189: iload_1
    //   190: iconst_1
    //   191: iadd
    //   192: aaload
    //   193: invokestatic parseContentVersion : (Ljava/lang/String;)Lcom/amazon/ags/html5/content/ContentVersion;
    //   196: astore #10
    //   198: aload #7
    //   200: astore #8
    //   202: aload #6
    //   204: astore #9
    //   206: aload #4
    //   208: astore #11
    //   210: goto -> 727
    //   213: ldc 'content'
    //   215: aload #13
    //   217: iload_1
    //   218: aaload
    //   219: invokevirtual equals : (Ljava/lang/Object;)Z
    //   222: ifeq -> 276
    //   225: aload #7
    //   227: astore #8
    //   229: aload #6
    //   231: astore #9
    //   233: aload #5
    //   235: astore #10
    //   237: aload #4
    //   239: astore #11
    //   241: aload #13
    //   243: iload_1
    //   244: iconst_1
    //   245: iadd
    //   246: aaload
    //   247: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   250: ifne -> 727
    //   253: aload #13
    //   255: iload_1
    //   256: iconst_1
    //   257: iadd
    //   258: aaload
    //   259: astore #11
    //   261: aload #7
    //   263: astore #8
    //   265: aload #6
    //   267: astore #9
    //   269: aload #5
    //   271: astore #10
    //   273: goto -> 727
    //   276: ldc 'sdkVersionCompatibility'
    //   278: aload #13
    //   280: iload_1
    //   281: aaload
    //   282: invokevirtual equals : (Ljava/lang/Object;)Z
    //   285: ifeq -> 342
    //   288: aload #7
    //   290: astore #8
    //   292: aload #6
    //   294: astore #9
    //   296: aload #5
    //   298: astore #10
    //   300: aload #4
    //   302: astore #11
    //   304: aload #13
    //   306: iload_1
    //   307: iconst_1
    //   308: iadd
    //   309: aaload
    //   310: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   313: ifne -> 727
    //   316: aload #13
    //   318: iload_1
    //   319: iconst_1
    //   320: iadd
    //   321: aaload
    //   322: invokestatic parseCompatibilityVersion : (Ljava/lang/String;)Lcom/amazon/ags/VersionInfo;
    //   325: astore #9
    //   327: aload #7
    //   329: astore #8
    //   331: aload #5
    //   333: astore #10
    //   335: aload #4
    //   337: astore #11
    //   339: goto -> 727
    //   342: aload #7
    //   344: astore #8
    //   346: aload #6
    //   348: astore #9
    //   350: aload #5
    //   352: astore #10
    //   354: aload #4
    //   356: astore #11
    //   358: ldc 'checksum'
    //   360: aload #13
    //   362: iload_1
    //   363: aaload
    //   364: invokevirtual equals : (Ljava/lang/Object;)Z
    //   367: ifeq -> 727
    //   370: aload #7
    //   372: astore #8
    //   374: aload #6
    //   376: astore #9
    //   378: aload #5
    //   380: astore #10
    //   382: aload #4
    //   384: astore #11
    //   386: aload #13
    //   388: iload_1
    //   389: iconst_1
    //   390: iadd
    //   391: aaload
    //   392: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   395: ifne -> 727
    //   398: aload #13
    //   400: iload_1
    //   401: iconst_1
    //   402: iadd
    //   403: aaload
    //   404: astore #8
    //   406: aload #6
    //   408: astore #9
    //   410: aload #5
    //   412: astore #10
    //   414: aload #4
    //   416: astore #11
    //   418: goto -> 727
    //   421: aload #5
    //   423: ifnull -> 97
    //   426: aload #4
    //   428: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   431: ifne -> 97
    //   434: aload #6
    //   436: ifnull -> 97
    //   439: aload #12
    //   441: aload #6
    //   443: invokevirtual toString : ()Ljava/lang/String;
    //   446: new com/amazon/ags/html5/content/ContentManifestEntry
    //   449: dup
    //   450: aload #5
    //   452: aload #4
    //   454: aload #7
    //   456: invokespecial <init> : (Lcom/amazon/ags/html5/content/ContentVersion;Ljava/lang/String;Ljava/lang/String;)V
    //   459: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   464: pop
    //   465: goto -> 97
    //   468: astore #4
    //   470: aload_3
    //   471: astore #7
    //   473: aload_2
    //   474: astore_3
    //   475: aload #4
    //   477: astore_2
    //   478: aload #7
    //   480: astore #4
    //   482: aload_3
    //   483: astore #5
    //   485: aload_0
    //   486: astore #6
    //   488: getstatic com/amazon/ags/html5/content/ContentManifestEntry.TAG : Ljava/lang/String;
    //   491: ldc 'Error encountered while performing manifest read operation'
    //   493: aload_2
    //   494: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   497: pop
    //   498: aload #7
    //   500: astore #4
    //   502: aload_3
    //   503: astore #5
    //   505: aload_0
    //   506: astore #6
    //   508: new java/util/HashMap
    //   511: dup
    //   512: invokespecial <init> : ()V
    //   515: astore #8
    //   517: aload #7
    //   519: ifnull -> 527
    //   522: aload #7
    //   524: invokevirtual close : ()V
    //   527: aload_3
    //   528: ifnull -> 535
    //   531: aload_3
    //   532: invokevirtual close : ()V
    //   535: aload #8
    //   537: astore_2
    //   538: aload_0
    //   539: ifnull -> 38
    //   542: aload_0
    //   543: invokevirtual close : ()V
    //   546: aload #8
    //   548: areturn
    //   549: astore_0
    //   550: getstatic com/amazon/ags/html5/content/ContentManifestEntry.TAG : Ljava/lang/String;
    //   553: ldc 'Error encountered while cleaning up manifest read operation'
    //   555: aload_0
    //   556: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   559: pop
    //   560: aload #8
    //   562: areturn
    //   563: aload_3
    //   564: ifnull -> 571
    //   567: aload_3
    //   568: invokevirtual close : ()V
    //   571: aload_2
    //   572: ifnull -> 579
    //   575: aload_2
    //   576: invokevirtual close : ()V
    //   579: aload #12
    //   581: astore_2
    //   582: aload_0
    //   583: ifnull -> 38
    //   586: aload_0
    //   587: invokevirtual close : ()V
    //   590: aload #12
    //   592: areturn
    //   593: astore_0
    //   594: getstatic com/amazon/ags/html5/content/ContentManifestEntry.TAG : Ljava/lang/String;
    //   597: ldc 'Error encountered while cleaning up manifest read operation'
    //   599: aload_0
    //   600: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   603: pop
    //   604: aload #12
    //   606: areturn
    //   607: astore_3
    //   608: aload #6
    //   610: astore_2
    //   611: aload #5
    //   613: astore_0
    //   614: aload #4
    //   616: ifnull -> 624
    //   619: aload #4
    //   621: invokevirtual close : ()V
    //   624: aload_0
    //   625: ifnull -> 632
    //   628: aload_0
    //   629: invokevirtual close : ()V
    //   632: aload_2
    //   633: ifnull -> 640
    //   636: aload_2
    //   637: invokevirtual close : ()V
    //   640: aload_3
    //   641: athrow
    //   642: astore_0
    //   643: getstatic com/amazon/ags/html5/content/ContentManifestEntry.TAG : Ljava/lang/String;
    //   646: ldc 'Error encountered while cleaning up manifest read operation'
    //   648: aload_0
    //   649: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   652: pop
    //   653: goto -> 640
    //   656: astore_3
    //   657: aload_0
    //   658: astore_2
    //   659: aload #8
    //   661: astore #4
    //   663: aload #10
    //   665: astore_0
    //   666: goto -> 614
    //   669: astore #5
    //   671: aload_0
    //   672: astore_3
    //   673: aload #8
    //   675: astore #4
    //   677: aload_2
    //   678: astore_0
    //   679: aload_3
    //   680: astore_2
    //   681: aload #5
    //   683: astore_3
    //   684: goto -> 614
    //   687: astore #6
    //   689: aload_0
    //   690: astore #5
    //   692: aload_3
    //   693: astore #4
    //   695: aload_2
    //   696: astore_0
    //   697: aload #5
    //   699: astore_2
    //   700: aload #6
    //   702: astore_3
    //   703: goto -> 614
    //   706: astore_2
    //   707: aload #9
    //   709: astore_0
    //   710: goto -> 478
    //   713: astore_2
    //   714: goto -> 478
    //   717: astore #4
    //   719: aload_2
    //   720: astore_3
    //   721: aload #4
    //   723: astore_2
    //   724: goto -> 478
    //   727: iload_1
    //   728: iconst_2
    //   729: iadd
    //   730: istore_1
    //   731: aload #8
    //   733: astore #7
    //   735: aload #9
    //   737: astore #6
    //   739: aload #10
    //   741: astore #5
    //   743: aload #11
    //   745: astore #4
    //   747: goto -> 138
    // Exception table:
    //   from	to	target	type
    //   63	72	706	java/lang/Exception
    //   63	72	607	finally
    //   72	81	713	java/lang/Exception
    //   72	81	656	finally
    //   81	97	717	java/lang/Exception
    //   81	97	669	finally
    //   97	103	468	java/lang/Exception
    //   97	103	687	finally
    //   108	124	468	java/lang/Exception
    //   108	124	687	finally
    //   138	159	468	java/lang/Exception
    //   138	159	687	finally
    //   175	198	468	java/lang/Exception
    //   175	198	687	finally
    //   213	225	468	java/lang/Exception
    //   213	225	687	finally
    //   241	253	468	java/lang/Exception
    //   241	253	687	finally
    //   276	288	468	java/lang/Exception
    //   276	288	687	finally
    //   304	327	468	java/lang/Exception
    //   304	327	687	finally
    //   358	370	468	java/lang/Exception
    //   358	370	687	finally
    //   386	398	468	java/lang/Exception
    //   386	398	687	finally
    //   426	434	468	java/lang/Exception
    //   426	434	687	finally
    //   439	465	468	java/lang/Exception
    //   439	465	687	finally
    //   488	498	607	finally
    //   508	517	607	finally
    //   522	527	549	java/lang/Exception
    //   531	535	549	java/lang/Exception
    //   542	546	549	java/lang/Exception
    //   567	571	593	java/lang/Exception
    //   575	579	593	java/lang/Exception
    //   586	590	593	java/lang/Exception
    //   619	624	642	java/lang/Exception
    //   628	632	642	java/lang/Exception
    //   636	640	642	java/lang/Exception
  }
  
  private static VersionInfo parseCompatibilityVersion(String paramString) {
    String[] arrayOfString = paramString.split("\\.");
    if (arrayOfString.length != 3)
      return null; 
    int j = arrayOfString.length;
    int i = 0;
    while (i < j) {
      String str = arrayOfString[i];
      try {
        Integer.parseInt(str);
        i++;
      } catch (Exception exception) {
        Log.w(TAG, "Exception encountered while parsing compatibility version number", exception);
        return null;
      } 
    } 
    return new VersionInfo(Integer.parseInt((String)exception[0]), Integer.parseInt((String)exception[1]), Integer.parseInt((String)exception[2]));
  }
  
  private static ContentVersion parseContentVersion(String paramString) {
    String[] arrayOfString = paramString.split("\\.");
    if (arrayOfString.length != 3)
      return null; 
    int j = arrayOfString.length;
    int i = 0;
    while (i < j) {
      String str = arrayOfString[i];
      try {
        Integer.parseInt(str);
        i++;
      } catch (Exception exception) {
        Log.w(TAG, "Exception encountered while parsing content version number", exception);
        return null;
      } 
    } 
    return new ContentVersion(Integer.parseInt((String)exception[0]), Integer.parseInt((String)exception[1]), Integer.parseInt((String)exception[2]));
  }
  
  public String getChecksum() {
    return this.checksum;
  }
  
  public String getContentURL() {
    return this.contentURL;
  }
  
  public ContentVersion getVersion() {
    return this.contentVersion;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\content\ContentManifestEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */