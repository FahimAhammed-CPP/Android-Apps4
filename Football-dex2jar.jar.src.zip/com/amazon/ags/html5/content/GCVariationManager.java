package com.amazon.ags.html5.content;

import android.content.Context;
import android.text.TextUtils;
import com.amazon.insights.ABTestClient;
import com.amazon.insights.AmazonInsights;
import com.amazon.insights.InsightsCallback;
import com.amazon.insights.InsightsCredentials;
import com.amazon.insights.Variation;
import com.amazon.insights.VariationSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class GCVariationManager {
  private static final String APPLICATION_KEY = "M3CGOMO6ILJQ65";
  
  private static final String DEFAULT_MASTER_VARIATION_LIST_NAME = "Universal Experiment List";
  
  private static final String DEFAULT_MASTER_VARIATION_LIST_VARIABLE = "experiments";
  
  private static final String DEFAULT_VARIATION_VARIABLE = "treatment";
  
  private static final String EMPTY_VARIATION_LIST_VALUE = "";
  
  private static final String EXPERIMENT_DELIMITER = ";;";
  
  private static final String NO_VARIABLE_FOUND = "GCNoVariableFound";
  
  private static final String PRIVATE_KEY = "jqyngW96w5vk9a3gLSPP0srNdRpFkRi2+Fjl6qMoPrg=";
  
  private static final String TAG = "GC_" + GCVariationManager.class.getSimpleName();
  
  private static final String TREATMENT_DELIMITER = ";";
  
  private static final String VARIATION_LIST_DELIMITER = ":";
  
  private final InsightsCredentials credentials;
  
  private final String masterVariationListName;
  
  private final String masterVariationListVariable;
  
  private Map<String, String> variationCache;
  
  public GCVariationManager() {
    this("Universal Experiment List", "experiments");
  }
  
  public GCVariationManager(String paramString1, String paramString2) {
    this.masterVariationListName = paramString1;
    this.masterVariationListVariable = paramString2;
    this.variationCache = Collections.synchronizedMap(new HashMap<String, String>());
    this.credentials = AmazonInsights.newCredentials("M3CGOMO6ILJQ65", "jqyngW96w5vk9a3gLSPP0srNdRpFkRi2+Fjl6qMoPrg=");
  }
  
  public Map<String, String> getCachedVariations() {
    return this.variationCache;
  }
  
  public void refreshVariations(Context paramContext, GCVariationManagerRefreshCallback paramGCVariationManagerRefreshCallback) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_0
    //   3: getfield credentials : Lcom/amazon/insights/InsightsCredentials;
    //   6: invokestatic getInstance : (Lcom/amazon/insights/InsightsCredentials;)Lcom/amazon/insights/AmazonInsights;
    //   9: astore #4
    //   11: aload #4
    //   13: astore_3
    //   14: aload_3
    //   15: astore #4
    //   17: aload_3
    //   18: ifnonnull -> 31
    //   21: aload_0
    //   22: getfield credentials : Lcom/amazon/insights/InsightsCredentials;
    //   25: aload_1
    //   26: invokestatic newInstance : (Lcom/amazon/insights/InsightsCredentials;Landroid/content/Context;)Lcom/amazon/insights/AmazonInsights;
    //   29: astore #4
    //   31: aload #4
    //   33: ifnull -> 115
    //   36: aload #4
    //   38: invokevirtual getABTestClient : ()Lcom/amazon/insights/ABTestClient;
    //   41: astore_1
    //   42: aload_1
    //   43: ifnull -> 95
    //   46: aload_1
    //   47: iconst_1
    //   48: anewarray java/lang/String
    //   51: dup
    //   52: iconst_0
    //   53: aload_0
    //   54: getfield masterVariationListName : Ljava/lang/String;
    //   57: aastore
    //   58: invokeinterface getVariations : ([Ljava/lang/String;)Lcom/amazon/insights/InsightsHandler;
    //   63: new com/amazon/ags/html5/content/GCVariationManager$1
    //   66: dup
    //   67: aload_0
    //   68: aload_1
    //   69: aload_2
    //   70: invokespecial <init> : (Lcom/amazon/ags/html5/content/GCVariationManager;Lcom/amazon/insights/ABTestClient;Lcom/amazon/ags/html5/content/GCVariationManager$GCVariationManagerRefreshCallback;)V
    //   73: invokeinterface setCallback : (Lcom/amazon/insights/InsightsCallback;)V
    //   78: return
    //   79: astore #4
    //   81: getstatic com/amazon/ags/html5/content/GCVariationManager.TAG : Ljava/lang/String;
    //   84: ldc 'Unable to retrieve AmazonInsights instance.  No A/B tests will be available.'
    //   86: aload #4
    //   88: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   91: pop
    //   92: goto -> 14
    //   95: getstatic com/amazon/ags/html5/content/GCVariationManager.TAG : Ljava/lang/String;
    //   98: ldc 'Unable to obtain reference to Insights ABTestClient'
    //   100: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   103: pop
    //   104: aload_2
    //   105: ifnull -> 78
    //   108: aload_2
    //   109: invokeinterface onRefreshCompleted : ()V
    //   114: return
    //   115: getstatic com/amazon/ags/html5/content/GCVariationManager.TAG : Ljava/lang/String;
    //   118: ldc 'Unable to obtain reference to Insights'
    //   120: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   123: pop
    //   124: aload_2
    //   125: ifnull -> 78
    //   128: aload_2
    //   129: invokeinterface onRefreshCompleted : ()V
    //   134: return
    // Exception table:
    //   from	to	target	type
    //   2	11	79	java/lang/Exception
  }
  
  public static interface GCVariationManagerRefreshCallback {
    void onRefreshCompleted();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\content\GCVariationManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */