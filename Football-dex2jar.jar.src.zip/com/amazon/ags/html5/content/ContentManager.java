package com.amazon.ags.html5.content;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.WebView;
import com.amazon.ags.VersionInfo;
import com.amazon.ags.html5.javascript.JavascriptRepository;
import com.amazon.ags.html5.util.NetworkUtil;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipFile;

public class ContentManager implements JavascriptRepository {
  private static final String AGS_BASE_DIRECTORY_NAME = ".ags";
  
  private static final String ALERT_JAVASCRIPT_FILE = "alert.html";
  
  private static final String BACKGROUND_JAVASCRIPT_FILE = "background.html";
  
  private static final long BYTES_PER_KB = 1024L;
  
  private static final long BYTES_PER_MB = 1048576L;
  
  private static final String CONTENT_FILENAME = "agscontent.zip";
  
  private static final String CURRENT_CONTENT_DIRECTORY_NAME = "current";
  
  private static final String DEFAULT_CONTENT_DIRECTORY_NAME = "raw";
  
  private static final String DEFAULT_CONTENT_FILENAME = "amazon_gc_prototype.zip";
  
  private static final String DEFAULT_CONTENT_RESOURCE_NAME = "amazon_gc_prototype";
  
  private static final String DOWNLOAD_DIR_NAME = "download";
  
  private static final String IMAGE_DIRECTORY_NAME = "images";
  
  private static final long KB_PER_MB = 1024L;
  
  private static final String MANIFEST_FILENAME = "agsmanifest.txt";
  
  private static final String MANIFEST_VARIATION = "ManifestSrc";
  
  private static final long MAX_ASYNCHRONOUS_DOWNLOAD_TIME_MS;
  
  private static final long MAX_IMAGE_CACHE_SIZE_BYTES = 15728640L;
  
  private static final String OVERLAY_JAVASCRIPT_FILE = "overlay.html";
  
  private static final String PREVIOUS_CONTENT_DIRECTORY_NAME = "previous";
  
  private static final String TAG = "GC_" + ContentManager.class.getSimpleName();
  
  private static final String TEMP_DIR_NAME = "tmp";
  
  private static final String TOAST_JAVASCRIPT_FILE = "toast.html";
  
  private static final String UPGRADE_CONTENT_DIRECTORY_NAME = "upgrade";
  
  private static final String VERSION_FILENAME = "version.txt";
  
  private final String agsBaseDirectoryLocation;
  
  private Context context;
  
  private final String currentContentBaseDirectoryLocation;
  
  private final String downloadContentBaseDirectoryLocation;
  
  private final String imageBaseDirectoryLocation;
  
  private ContentVersion initializedContentVersion;
  
  private NetworkUtil networkUtil;
  
  private final String previousContentBaseDirectoryLocation;
  
  private final String tempContentBaseDirectoryLocation;
  
  private final String upgradeContentBaseDirectoryLocation;
  
  private final boolean upgradesEnabled = true;
  
  static {
    MAX_ASYNCHRONOUS_DOWNLOAD_TIME_MS = TimeUnit.SECONDS.toMillis(60L);
  }
  
  public ContentManager(Context paramContext) {
    this.context = paramContext;
    this.networkUtil = new NetworkUtil(paramContext);
    this.agsBaseDirectoryLocation = paramContext.getFilesDir() + File.separator + ".ags";
    this.imageBaseDirectoryLocation = this.agsBaseDirectoryLocation + File.separator + "images";
    this.currentContentBaseDirectoryLocation = this.agsBaseDirectoryLocation + File.separator + "current";
    this.upgradeContentBaseDirectoryLocation = this.agsBaseDirectoryLocation + File.separator + "upgrade";
    this.previousContentBaseDirectoryLocation = this.agsBaseDirectoryLocation + File.separator + "previous";
    this.downloadContentBaseDirectoryLocation = this.agsBaseDirectoryLocation + File.separator + "download";
    this.tempContentBaseDirectoryLocation = this.agsBaseDirectoryLocation + File.separator + "tmp";
  }
  
  private boolean downloadRemoteContent(boolean paramBoolean, String paramString1, long paramLong, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload #5
    //   4: ifnonnull -> 16
    //   7: getstatic com/amazon/ags/html5/content/ContentManager.TAG : Ljava/lang/String;
    //   10: ldc 'No checksum was provided'
    //   12: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   15: pop
    //   16: iconst_0
    //   17: istore #6
    //   19: iload_1
    //   20: ifeq -> 53
    //   23: new java/io/File
    //   26: dup
    //   27: aload_0
    //   28: getfield downloadContentBaseDirectoryLocation : Ljava/lang/String;
    //   31: invokespecial <init> : (Ljava/lang/String;)V
    //   34: invokestatic deleteDirectory : (Ljava/io/File;)Z
    //   37: pop
    //   38: new java/io/File
    //   41: dup
    //   42: aload_0
    //   43: getfield downloadContentBaseDirectoryLocation : Ljava/lang/String;
    //   46: invokespecial <init> : (Ljava/lang/String;)V
    //   49: invokestatic ensureDirectoryExists : (Ljava/io/File;)Z
    //   52: pop
    //   53: new java/lang/StringBuilder
    //   56: dup
    //   57: invokespecial <init> : ()V
    //   60: aload_0
    //   61: getfield downloadContentBaseDirectoryLocation : Ljava/lang/String;
    //   64: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   67: getstatic java/io/File.separator : Ljava/lang/String;
    //   70: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   73: ldc 'agscontent.zip'
    //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: invokevirtual toString : ()Ljava/lang/String;
    //   81: astore #7
    //   83: iload #6
    //   85: istore_1
    //   86: aload_2
    //   87: aload #7
    //   89: lload_3
    //   90: invokestatic downloadFile : (Ljava/lang/String;Ljava/lang/String;J)Z
    //   93: ifeq -> 157
    //   96: new java/io/File
    //   99: dup
    //   100: aload #7
    //   102: invokespecial <init> : (Ljava/lang/String;)V
    //   105: astore_2
    //   106: iload #6
    //   108: istore_1
    //   109: aload_2
    //   110: ifnull -> 157
    //   113: iload #6
    //   115: istore_1
    //   116: aload_2
    //   117: invokevirtual exists : ()Z
    //   120: ifeq -> 157
    //   123: iload #6
    //   125: istore_1
    //   126: aload_2
    //   127: invokevirtual canRead : ()Z
    //   130: ifeq -> 157
    //   133: aload #5
    //   135: ifnull -> 185
    //   138: iload #6
    //   140: istore_1
    //   141: aload #5
    //   143: aload #7
    //   145: invokestatic getMD5ChecksumForFile : (Ljava/lang/String;)Ljava/lang/String;
    //   148: invokevirtual equals : (Ljava/lang/Object;)Z
    //   151: ifeq -> 157
    //   154: goto -> 185
    //   157: iload_1
    //   158: ifne -> 176
    //   161: new java/io/File
    //   164: dup
    //   165: aload_0
    //   166: getfield downloadContentBaseDirectoryLocation : Ljava/lang/String;
    //   169: invokespecial <init> : (Ljava/lang/String;)V
    //   172: invokestatic deleteDirectory : (Ljava/io/File;)Z
    //   175: pop
    //   176: aload_0
    //   177: monitorexit
    //   178: iload_1
    //   179: ireturn
    //   180: astore_2
    //   181: aload_0
    //   182: monitorexit
    //   183: aload_2
    //   184: athrow
    //   185: iconst_1
    //   186: istore_1
    //   187: goto -> 157
    // Exception table:
    //   from	to	target	type
    //   7	16	180	finally
    //   23	53	180	finally
    //   53	83	180	finally
    //   86	106	180	finally
    //   116	123	180	finally
    //   126	133	180	finally
    //   141	154	180	finally
    //   161	176	180	finally
  }
  
  private Map<String, ContentManifestEntry> downloadRemoteManifest(boolean paramBoolean, String paramString) {
    if (paramBoolean) {
      FileUtils.deleteDirectory(new File(this.downloadContentBaseDirectoryLocation));
      FileUtils.ensureDirectoryExists(new File(this.downloadContentBaseDirectoryLocation));
    } 
    if (TextUtils.isEmpty(paramString))
      return new HashMap<String, ContentManifestEntry>(); 
    FileUtils.downloadFile(paramString, this.downloadContentBaseDirectoryLocation + File.separator + "agsmanifest.txt", 5000L);
    return ContentManifestEntry.createManifestEntriesFromFile(this.downloadContentBaseDirectoryLocation + File.separator + "agsmanifest.txt");
  }
  
  private boolean downloadedFileChecksumIsValid(String paramString) {
    File file = new File(this.downloadContentBaseDirectoryLocation + File.separator + "agscontent.zip");
    return (TextUtils.isEmpty(paramString) || file == null || !file.exists() || !file.canRead()) ? false : paramString.equals(FileUtils.getMD5ChecksumForFile(this.downloadContentBaseDirectoryLocation + File.separator + "agscontent.zip"));
  }
  
  private boolean ensureBaseDirectoriesExist() {
    return true & FileUtils.ensureDirectoryExists(new File(this.agsBaseDirectoryLocation)) & FileUtils.ensureDirectoryExists(new File(this.imageBaseDirectoryLocation)) & FileUtils.ensureDirectoryExists(new File(this.currentContentBaseDirectoryLocation)) & FileUtils.ensureDirectoryExists(new File(this.upgradeContentBaseDirectoryLocation)) & FileUtils.ensureDirectoryExists(new File(this.downloadContentBaseDirectoryLocation));
  }
  
  private void fullContentInitialization(ExecutorService paramExecutorService, ContentInitializationCallback paramContentInitializationCallback, final String manifestEndpoint) {
    boolean bool;
    final ContentVersion postUpgradeCurrentContentVersion;
    if (!ensureBaseDirectoriesExist()) {
      Log.e(TAG, "Unable to setup AGS directory structure.  Content initialization aborted");
      return;
    } 
    if (!validateContentIntegrity(this.currentContentBaseDirectoryLocation))
      revertToDefaultContent(); 
    ContentVersion contentVersion3 = ContentVersion.createVersionFromDefaultContentRawResource(this.context, "raw", "amazon_gc_prototype");
    ContentVersion contentVersion2 = ContentVersion.createVersionFromFile(this.currentContentBaseDirectoryLocation + File.separator + "version.txt");
    ContentVersion contentVersion4 = localUpgradeContentVersion();
    if (contentVersion2 != null)
      Log.d(TAG, "Current JavaScript content version: " + contentVersion2); 
    if (contentVersion3 != null)
      Log.d(TAG, "Default JavaScript content version: " + contentVersion3); 
    if (contentVersion4 != null)
      Log.d(TAG, "Upgrade JavaScript content version: " + contentVersion4); 
    UpgradeAction upgradeAction1 = UpgradeAction.NO_UPGRADE;
    if (contentVersion3.compareTo(contentVersion2) > 0)
      upgradeAction1 = UpgradeAction.DEFAULT_UPGRADE_ACTION; 
    UpgradeAction upgradeAction2 = upgradeAction1;
    if (contentVersion4.compareTo(contentVersion3) > 0) {
      upgradeAction2 = upgradeAction1;
      if (contentVersion4.compareTo(contentVersion2) > 0)
        upgradeAction2 = UpgradeAction.LOCAL_UPGRADE_ACTION; 
    } 
    if (upgradeAction2 == UpgradeAction.DEFAULT_UPGRADE_ACTION || upgradeAction2 == UpgradeAction.NO_UPGRADE) {
      FileUtils.deleteDirectory(new File(this.upgradeContentBaseDirectoryLocation));
      FileUtils.deleteDirectory(new File(this.downloadContentBaseDirectoryLocation));
    } 
    updateContent(upgradeAction2);
    if (upgradeAction2 == UpgradeAction.NO_UPGRADE) {
      contentVersion1 = contentVersion2;
    } else {
      contentVersion1 = ContentVersion.createVersionFromFile(this.currentContentBaseDirectoryLocation + File.separator + "version.txt");
    } 
    if (this.networkUtil != null && this.networkUtil.isNetworkConnected())
      paramExecutorService.execute(new Runnable() {
            public void run() {
              boolean bool2 = false;
              ContentManifestEntry contentManifestEntry = (ContentManifestEntry)ContentManager.this.downloadRemoteManifest(true, manifestEndpoint).get(VersionInfo.getSDKVersion().toString());
              boolean bool1 = bool2;
              if (contentManifestEntry != null) {
                bool1 = bool2;
                if (contentManifestEntry.getVersion().compareTo(postUpgradeCurrentContentVersion) > 0)
                  bool1 = true; 
              } 
              if (bool1 && contentManifestEntry != null)
                ContentManager.this.downloadRemoteContent(true, contentManifestEntry.getContentURL(), ContentManager.MAX_ASYNCHRONOUS_DOWNLOAD_TIME_MS, contentManifestEntry.getChecksum()); 
            }
          }); 
    if (validateContentIntegrity(this.currentContentBaseDirectoryLocation)) {
      bool = true;
    } else {
      bool = revertToDefaultContent();
    } 
    if (bool) {
      this.initializedContentVersion = ContentVersion.createVersionFromFile(this.currentContentBaseDirectoryLocation + File.separator + "version.txt");
      paramContentInitializationCallback.onInitialized();
      return;
    } 
    paramContentInitializationCallback.onFailure();
  }
  
  private void loadManagedContentFileIntoWebview(final WebView webView, String paramString) {
    final File javascriptFile = new File(getContentDirectory() + File.separator + paramString);
    (new Handler(Looper.getMainLooper())).post(new Runnable() {
          public void run() {
            webView.loadUrl(javascriptFile.toURI().toString());
          }
        });
  }
  
  private ContentVersion localUpgradeContentVersion() {
    try {
      return ContentVersion.createVersionFromZip(new ZipFile(this.downloadContentBaseDirectoryLocation + File.separator + "agscontent.zip"));
    } catch (FileNotFoundException fileNotFoundException) {
      Log.i(TAG, "Upgrade zip does not exist.");
    } catch (IOException iOException) {
      Log.e(TAG, "Error in reading content version from upgrade candidate.", iOException);
    } 
    return ContentVersion.getBlankContentVersion();
  }
  
  private boolean revertToDefaultContent() {
    boolean bool = true;
    if ((new File(this.currentContentBaseDirectoryLocation)).exists() && !FileUtils.deleteDirectory(new File(this.currentContentBaseDirectoryLocation)))
      return false; 
    if (!FileUtils.ensureDirectoryExists(new File(this.currentContentBaseDirectoryLocation)))
      return false; 
    if (!FileUtils.copyResourceContentIntoDirectory(this.context, "amazon_gc_prototype", "amazon_gc_prototype.zip", this.tempContentBaseDirectoryLocation)) {
      FileUtils.deleteDirectory(new File(this.tempContentBaseDirectoryLocation));
      return false;
    } 
    if (!FileUtils.extractZipToDirectory(this.tempContentBaseDirectoryLocation + File.separator + "amazon_gc_prototype.zip", this.currentContentBaseDirectoryLocation))
      bool = false; 
    FileUtils.deleteDirectory(new File(this.tempContentBaseDirectoryLocation));
    return bool;
  }
  
  private void trimImageCache(long paramLong) {
    File file = new File(this.imageBaseDirectoryLocation);
    if (file != null && file.isDirectory() && FileUtils.getDirectorySize(file) >= paramLong) {
      FileUtils.deleteDirectory(file);
      FileUtils.ensureDirectoryExists(new File(this.imageBaseDirectoryLocation));
    } 
  }
  
  private boolean updateContent(UpgradeAction paramUpgradeAction) {
    switch (paramUpgradeAction) {
      default:
        return false;
      case DEFAULT_UPGRADE_ACTION:
        return revertToDefaultContent();
      case LOCAL_UPGRADE_ACTION:
        return updateContentFromLocalUpgrade();
      case NO_UPGRADE:
        break;
    } 
    return true;
  }
  
  private boolean updateContentFromLocalUpgrade() {
    boolean bool2 = false;
    FileUtils.ensureDirectoryExists(new File(this.currentContentBaseDirectoryLocation));
    FileUtils.ensureDirectoryExists(new File(this.upgradeContentBaseDirectoryLocation));
    boolean bool1 = bool2;
    if (FileUtils.extractZipToDirectory(this.downloadContentBaseDirectoryLocation + File.separator + "agscontent.zip", this.upgradeContentBaseDirectoryLocation)) {
      bool1 = bool2;
      FileUtils.renameDirectory(this.currentContentBaseDirectoryLocation, this.previousContentBaseDirectoryLocation);
      bool1 = bool2;
      if (validateContentIntegrity(this.upgradeContentBaseDirectoryLocation) && FileUtils.deleteDirectory(new File(this.currentContentBaseDirectoryLocation))) {
        FileUtils.renameDirectory(this.upgradeContentBaseDirectoryLocation, this.currentContentBaseDirectoryLocation);
        if (validateContentIntegrity(this.currentContentBaseDirectoryLocation)) {
          FileUtils.deleteDirectory(new File(this.previousContentBaseDirectoryLocation));
          bool1 = true;
          FileUtils.deleteDirectory(new File(this.upgradeContentBaseDirectoryLocation));
          FileUtils.deleteDirectory(new File(this.downloadContentBaseDirectoryLocation));
          return bool1;
        } 
      } else {
        FileUtils.deleteDirectory(new File(this.upgradeContentBaseDirectoryLocation));
        FileUtils.deleteDirectory(new File(this.downloadContentBaseDirectoryLocation));
        return bool1;
      } 
    } else {
      FileUtils.deleteDirectory(new File(this.upgradeContentBaseDirectoryLocation));
      FileUtils.deleteDirectory(new File(this.downloadContentBaseDirectoryLocation));
      return bool1;
    } 
    FileUtils.deleteDirectory(new File(this.currentContentBaseDirectoryLocation));
    FileUtils.renameDirectory(this.previousContentBaseDirectoryLocation, this.currentContentBaseDirectoryLocation);
    FileUtils.deleteDirectory(new File(this.previousContentBaseDirectoryLocation));
    FileUtils.deleteDirectory(new File(this.upgradeContentBaseDirectoryLocation));
    bool1 = bool2;
    FileUtils.deleteDirectory(new File(this.upgradeContentBaseDirectoryLocation));
    FileUtils.deleteDirectory(new File(this.downloadContentBaseDirectoryLocation));
    return bool1;
  }
  
  private boolean validateContentIntegrity(String paramString) {
    boolean bool = true;
    File file2 = new File(paramString + File.separator + "background.html");
    File file3 = new File(paramString + File.separator + "overlay.html");
    File file4 = new File(paramString + File.separator + "toast.html");
    File file1 = new File(paramString + File.separator + "version.txt");
    if (file2 == null || !file2.exists() || !file2.canRead())
      bool = false; 
    if (file3 == null || !file3.exists() || !file3.canRead())
      bool = false; 
    if (file4 == null || !file4.exists() || !file4.canRead())
      bool = false; 
    if (file1 == null || !file1.exists() || !file1.canRead())
      bool = false; 
    return bool;
  }
  
  public String getContentDirectory() {
    return this.currentContentBaseDirectoryLocation;
  }
  
  public String getImageDirectory() {
    return this.imageBaseDirectoryLocation;
  }
  
  public ContentVersion getInitializedContentVersion() {
    return this.initializedContentVersion;
  }
  
  public void initializeContent(ExecutorService paramExecutorService, GCVariationManager paramGCVariationManager, ContentInitializationCallback paramContentInitializationCallback) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc2_w 15728640
    //   6: invokespecial trimImageCache : (J)V
    //   9: aload_2
    //   10: aload_0
    //   11: getfield context : Landroid/content/Context;
    //   14: new com/amazon/ags/html5/content/ContentManager$1
    //   17: dup
    //   18: aload_0
    //   19: aload_2
    //   20: aload_1
    //   21: aload_3
    //   22: invokespecial <init> : (Lcom/amazon/ags/html5/content/ContentManager;Lcom/amazon/ags/html5/content/GCVariationManager;Ljava/util/concurrent/ExecutorService;Lcom/amazon/ags/html5/content/ContentManager$ContentInitializationCallback;)V
    //   25: invokevirtual refreshVariations : (Landroid/content/Context;Lcom/amazon/ags/html5/content/GCVariationManager$GCVariationManagerRefreshCallback;)V
    //   28: aload_0
    //   29: monitorexit
    //   30: return
    //   31: astore_1
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   2	28	31	finally
  }
  
  public void loadAlertJavascript(WebView paramWebView) {
    loadManagedContentFileIntoWebview(paramWebView, "alert.html");
  }
  
  public void loadBackgroundJavascript(WebView paramWebView) {
    loadManagedContentFileIntoWebview(paramWebView, "background.html");
  }
  
  public void loadOverlayJavascript(WebView paramWebView) {
    loadManagedContentFileIntoWebview(paramWebView, "overlay.html");
  }
  
  public void loadToastJavascript(WebView paramWebView) {
    loadManagedContentFileIntoWebview(paramWebView, "toast.html");
  }
  
  public void shutdown() {
    this.context = null;
    this.networkUtil = null;
  }
  
  public static interface ContentInitializationCallback {
    void onFailure();
    
    void onInitialized();
  }
  
  private enum UpgradeAction {
    DEFAULT_UPGRADE_ACTION, LOCAL_UPGRADE_ACTION, NO_UPGRADE;
    
    static {
      DEFAULT_UPGRADE_ACTION = new UpgradeAction("DEFAULT_UPGRADE_ACTION", 2);
      $VALUES = new UpgradeAction[] { NO_UPGRADE, LOCAL_UPGRADE_ACTION, DEFAULT_UPGRADE_ACTION };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\content\ContentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */