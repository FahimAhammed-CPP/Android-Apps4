package com.amazon.ags.html5.util;

import android.util.Log;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONObject;

public class GlobalState {
  private final String TAG = GlobalState.class.getSimpleName();
  
  private final Map<String, String> globalState = Collections.synchronizedMap(new HashMap<String, String>());
  
  private final Set<GlobalStateListener> listeners = new HashSet<GlobalStateListener>();
  
  public void addListener(GlobalStateListener paramGlobalStateListener) {
    this.listeners.add(paramGlobalStateListener);
  }
  
  public String get(String paramString) {
    return this.globalState.get(paramString);
  }
  
  public String getCountrySupport() {
    return this.globalState.get("countrySupport");
  }
  
  public String getPlayerId() {
    return this.globalState.get("playerId");
  }
  
  public boolean isGuestMode() {
    String str = this.globalState.get("guestMode");
    return (str == null || Boolean.parseBoolean(str));
  }
  
  public Boolean isHidden() {
    String str = this.globalState.get("hidden");
    if (str != null && Boolean.valueOf(str).booleanValue()) {
      boolean bool1 = true;
      return Boolean.valueOf(bool1);
    } 
    boolean bool = false;
    return Boolean.valueOf(bool);
  }
  
  public void put(String paramString1, String paramString2) {
    this.globalState.put(paramString1, paramString2);
    Iterator<GlobalStateListener> iterator = this.listeners.iterator();
    while (iterator.hasNext())
      ((GlobalStateListener)iterator.next()).notifyStateSet(paramString1, paramString2); 
    if ("playerId".equals(paramString1)) {
      iterator = this.listeners.iterator();
      while (iterator.hasNext())
        ((GlobalStateListener)iterator.next()).notifyPlayerIdSet(paramString2); 
    } 
    if ("guestMode".equals(paramString1))
      for (GlobalStateListener globalStateListener : this.listeners) {
        try {
          globalStateListener.notifyIsGuestModeSet(Boolean.parseBoolean(paramString2));
        } catch (Throwable throwable) {
          Log.e(this.TAG, "Could not notify guest mode state change: " + throwable.toString());
        } 
      }  
  }
  
  public void removeListener(GlobalStateListener paramGlobalStateListener) {
    this.listeners.remove(paramGlobalStateListener);
  }
  
  public JSONObject toJSON() {
    synchronized (this.globalState) {
      return new JSONObject(this.globalState);
    } 
  }
  
  public static interface GlobalStateListener {
    void notifyIsGuestModeSet(boolean param1Boolean);
    
    void notifyPlayerIdSet(String param1String);
    
    void notifyStateSet(String param1String1, String param1String2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\GlobalState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */