package com.amazon.ags.html5.util;

import android.os.Build;
import com.amazon.ags.client.KindleFireProxy;

public class DeviceInfo {
  private static final String DEVICE_TYPE_ANDROID = "A1K0FT6QT4HWL9";
  
  private static final String DEVICE_TYPE_KINDLE = "AXRZR9ASDFH6P";
  
  private final KindleFireProxy kindleFireProxy;
  
  public DeviceInfo(KindleFireProxy paramKindleFireProxy) {
    this.kindleFireProxy = paramKindleFireProxy;
  }
  
  public static String getIdentifier() {
    return (Build.SERIAL != null && Build.SERIAL.length() > 0) ? Build.SERIAL : (("android_id" != null && "android_id".length() > 0) ? "android_id" : "UNKNOWN");
  }
  
  public static String getManufacturer() {
    return Build.MANUFACTURER;
  }
  
  public static String getModel() {
    String str3 = Build.MANUFACTURER;
    String str2 = Build.MODEL;
    String str1 = str2;
    if (str2 != null) {
      str1 = str2;
      if (str3 != null) {
        str1 = str2;
        if (str2.startsWith(str3))
          str1 = str2.replace(str3, ""); 
      } 
    } 
    return str1;
  }
  
  public String getDeviceType() {
    return this.kindleFireProxy.isKindle() ? "AXRZR9ASDFH6P" : "A1K0FT6QT4HWL9";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\DeviceInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */