package com.amazon.ags.html5.util;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.amazon.ags.html5.factory.ServiceFactory;
import com.amazon.ags.html5.javascript.JavascriptRepository;

public class WebViewFactory {
  private static final String TAG = "GC_" + WebViewFactory.class.getSimpleName();
  
  private final Context context;
  
  private final WebView globalBackgroundWebview;
  
  public WebViewFactory(Context paramContext, JavascriptRepository paramJavascriptRepository) {
    this.context = paramContext;
    this.globalBackgroundWebview = newWebView(this.context);
  }
  
  private void logConsoleMessage(ConsoleMessage paramConsoleMessage) {
    if (paramConsoleMessage.messageLevel().compareTo((Enum)ConsoleMessage.MessageLevel.ERROR) >= 0) {
      Log.e(TAG, "JS(line " + paramConsoleMessage.lineNumber() + "): " + paramConsoleMessage.message());
      return;
    } 
    if (ServiceFactory.isDebugLoggingEnabled()) {
      if (paramConsoleMessage.messageLevel().compareTo((Enum)ConsoleMessage.MessageLevel.WARNING) >= 0) {
        Log.w(TAG, "JS(line " + paramConsoleMessage.lineNumber() + "): " + paramConsoleMessage.message());
        return;
      } 
      Log.d(TAG, "JS(line " + paramConsoleMessage.lineNumber() + "): " + paramConsoleMessage.message());
      return;
    } 
  }
  
  private WebView newWebView(Context paramContext) {
    WebView webView = new WebView(paramContext);
    webView.getSettings().setJavaScriptEnabled(true);
    webView.getSettings().setDefaultTextEncodingName("utf-8");
    webView.clearCache(true);
    webView.setWebViewClient(new WebViewClient() {
          public void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2) {
            Log.d(WebViewFactory.TAG, "WebView Error: " + param1String1);
          }
        });
    webView.setWebChromeClient(new WebChromeClient() {
          public boolean onConsoleMessage(ConsoleMessage param1ConsoleMessage) {
            WebViewFactory.this.logConsoleMessage(param1ConsoleMessage);
            return true;
          }
        });
    return webView;
  }
  
  public WebView getBackgroundWebview() {
    return this.globalBackgroundWebview;
  }
  
  public WebView newOverlayWebView(Activity paramActivity) {
    return newWebView((Context)paramActivity);
  }
  
  public WebView newToastWebView() {
    return newWebView(this.context);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\WebViewFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */