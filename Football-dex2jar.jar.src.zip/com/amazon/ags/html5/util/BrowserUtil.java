package com.amazon.ags.html5.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class BrowserUtil {
  private final Context context;
  
  public BrowserUtil(Context paramContext) {
    this.context = paramContext;
  }
  
  public final void launchBrowser(String paramString) {
    Intent intent = new Intent("android.intent.action.VIEW");
    intent.setFlags(335609856);
    intent.setData(Uri.parse(paramString));
    this.context.startActivity(intent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\BrowserUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */