package com.amazon.ags.html5.util;

import android.text.TextUtils;
import android.util.Log;
import com.amazon.ags.html5.content.ContentManager;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class ImageManager {
  private static final int MAX_BYTES_ALLOWED = 5000000;
  
  private static final String TAG = "GC_" + ImageManager.class.getSimpleName();
  
  private final ContentManager contentManager;
  
  public ImageManager(ContentManager paramContentManager) {
    this.contentManager = paramContentManager;
  }
  
  public final void downloadImage(String paramString) {
    if (!TextUtils.isEmpty(paramString))
      try {
        String str1 = this.contentManager.getImageDirectory();
        String str2 = paramString.substring(paramString.lastIndexOf('/') + 1, paramString.length());
        str1 = str1 + File.separator + str2;
        if (!(new File(str1)).exists()) {
          BufferedInputStream bufferedInputStream = new BufferedInputStream((new URL(paramString)).openStream());
          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
          byte[] arrayOfByte = new byte[1024];
          int i = 0;
          while (true) {
            int j = bufferedInputStream.read(arrayOfByte);
            if (j > 0) {
              int k = i + j;
              byteArrayOutputStream.write(arrayOfByte, 0, j);
              i = k;
              if (k > 5000000) {
                bufferedInputStream.close();
                byteArrayOutputStream.close();
                throw new IOException("Size of image exceeded maximum length: " + paramString);
              } 
              continue;
            } 
            bufferedInputStream.close();
            byteArrayOutputStream.close();
            byte[] arrayOfByte1 = byteArrayOutputStream.toByteArray();
            FileOutputStream fileOutputStream = new FileOutputStream(str1);
            fileOutputStream.write(arrayOfByte1);
            fileOutputStream.close();
            return;
          } 
        } 
        return;
      } catch (MalformedURLException malformedURLException) {
        Log.w(TAG, "Unable to download image due to improper URL", malformedURLException);
        return;
      } catch (IOException iOException) {
        Log.w(TAG, "Unable to download image due to IO problem", iOException);
        return;
      } catch (Exception exception) {
        Log.w(TAG, "Unable to download image due to unexpected problem", exception);
        return;
      }  
    Log.w(TAG, "Unable to download image due to empty URL supplied");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\ImageManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */