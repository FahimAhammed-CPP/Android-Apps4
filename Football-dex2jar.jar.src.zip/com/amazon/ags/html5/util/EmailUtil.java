package com.amazon.ags.html5.util;

import android.content.Context;
import android.content.Intent;

public class EmailUtil {
  private static final String TAG = "GC_" + EmailUtil.class.getSimpleName();
  
  private final Context context;
  
  public EmailUtil(Context paramContext) {
    this.context = paramContext;
  }
  
  public final void launchEmailEditor(String paramString1, String paramString2, String paramString3) {
    Intent intent = new Intent("android.intent.action.SEND");
    intent.setFlags(335609856);
    intent.putExtra("android.intent.extra.EMAIL", new String[] { paramString1 });
    intent.putExtra("android.intent.extra.CC", new String[0]);
    intent.putExtra("android.intent.extra.BCC", new String[0]);
    intent.putExtra("android.intent.extra.SUBJECT", paramString2);
    intent.setType("plain/text");
    intent.putExtra("android.intent.extra.TEXT", paramString3);
    this.context.startActivity(intent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\EmailUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */