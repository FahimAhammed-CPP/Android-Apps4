package com.amazon.ags.html5.util;

import android.content.Context;
import dalvik.system.DexFile;
import java.util.Enumeration;

public class ResourceUtils {
  private static final int INVALID_RESOURCE_IDENTIFIER = 0;
  
  private static final String RESOURCE_TYPE_STRING = "string";
  
  private static final String TAG = "GC_" + ResourceUtils.class.getSimpleName();
  
  public static final int getAnimationId(Context paramContext, String paramString) {
    return getIdentifier(paramContext, "anim", paramString);
  }
  
  public static final int getDrawableId(Context paramContext, String paramString) {
    return getIdentifier(paramContext, "drawable", paramString);
  }
  
  public static int getIdentifier(Context paramContext, String paramString1, String paramString2) {
    int k;
    int i = paramContext.getResources().getIdentifier(paramString2, paramString1, paramContext.getPackageName());
    if (i != 0)
      return i; 
    int j = i;
    try {
      Enumeration<String> enumeration = (new DexFile((paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 0)).sourceDir)).entries();
      while (true) {
        j = i;
        k = i;
        if (enumeration.hasMoreElements()) {
          j = i;
          String str = enumeration.nextElement();
          j = i;
          if (str.endsWith(".R")) {
            j = i;
            i = paramContext.getResources().getIdentifier(paramString2, paramString1, str.substring(0, str.length() - 2));
            j = i;
            i = j;
            if (j != 0)
              return j; 
          } 
          continue;
        } 
        break;
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
      k = j;
    } 
    return k;
  }
  
  public static final int getLayoutId(Context paramContext, String paramString) {
    return getIdentifier(paramContext, "layout", paramString);
  }
  
  public static String getString(Context paramContext, String paramString) {
    return paramContext.getString(getIdentifier(paramContext, "string", paramString));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\ResourceUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */