package com.amazon.ags.html5.util;

import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

public class JSONUtils {
  private static final String TAG = "GC_" + JSONUtils.class.getSimpleName();
  
  public static String sanitize(String paramString) {
    try {
      return (new JSONObject(paramString)).toString();
    } catch (JSONException jSONException) {
      Log.e(TAG, "Bad json string \"" + paramString + "\"", (Throwable)jSONException);
      return "{}";
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\JSONUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */