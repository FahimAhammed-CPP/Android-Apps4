package com.amazon.ags.html5.util;

import android.content.Context;
import java.util.Locale;

public class LocalizationUtil {
  private static final String TAG = "GC_" + LocalizationUtil.class.getSimpleName();
  
  private final Context context;
  
  public LocalizationUtil(Context paramContext) {
    this.context = paramContext;
  }
  
  public String getCountryCode() {
    return (this.context.getResources().getConfiguration()).locale.getCountry();
  }
  
  public Locale getCurrentLocale() {
    return (this.context.getResources().getConfiguration()).locale;
  }
  
  public String getLanguageCode() {
    return (this.context.getResources().getConfiguration()).locale.getLanguage();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\LocalizationUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */