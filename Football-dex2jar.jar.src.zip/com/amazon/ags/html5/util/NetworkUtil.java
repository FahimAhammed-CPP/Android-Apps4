package com.amazon.ags.html5.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class NetworkUtil {
  private static final String TAG = "GC_" + NetworkUtil.class.getSimpleName();
  
  private final Context context;
  
  public NetworkUtil(Context paramContext) {
    this.context = paramContext;
  }
  
  public boolean isNetworkConnected() {
    ConnectivityManager connectivityManager = (ConnectivityManager)this.context.getSystemService("connectivity");
    if (connectivityManager != null) {
      NetworkInfo[] arrayOfNetworkInfo = connectivityManager.getAllNetworkInfo();
      if (arrayOfNetworkInfo != null) {
        int j = arrayOfNetworkInfo.length;
        int i = 0;
        while (true) {
          if (i < j) {
            if (arrayOfNetworkInfo[i].getState() == NetworkInfo.State.CONNECTED)
              return true; 
            i++;
            continue;
          } 
          return false;
        } 
      } 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\NetworkUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */