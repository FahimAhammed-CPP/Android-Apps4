package com.amazon.ags.html5.util;

import android.util.Log;
import com.amazon.ags.html5.factory.ServiceFactory;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class ClientConfig {
  private static final String TAG = "GC_" + ClientConfig.class.getSimpleName();
  
  private final Map<String, ConfigEntry> config = new HashMap<String, ConfigEntry>();
  
  public ClientConfig() {
    this.config.put("AUTH_GET_TOKEN_TIMEOUT_MILLIS", new ConfigEntry(1000L, 10000L, 60000L));
    this.config.put("THREAD_POOL_SIZE", new ConfigEntry(5L, 100L, 100L));
    this.config.put("THREAD_TIMEOUT", new ConfigEntry(10L, 1000L, 60000L));
    this.config.put("HTTP_CONNECTION_POOL_TIMEOUT_MILLIS", new ConfigEntry(500L, 10000L, 60000L));
    this.config.put("HTTP_CONNECTION_TIMEOUT_MILLIS", new ConfigEntry(500L, 10000L, 60000L));
    this.config.put("HTTP_SOCKET_TIMEOUT_MILLIS", new ConfigEntry(500L, 10000L, 60000L));
    this.config.put("HTTP_MAX_TOTAL_CONNECTIONS", new ConfigEntry(2L, 20L, 50L));
    this.config.put("HTTP_MAX_CONNECTIONS_PER_ROUTE", new ConfigEntry(2L, 20L, 50L));
  }
  
  public long get(String paramString) {
    ConfigEntry configEntry = this.config.get(paramString);
    if (configEntry == null) {
      Log.e(TAG, "No config value for " + paramString);
      return 0L;
    } 
    return configEntry.getValue();
  }
  
  public void load(JSONObject paramJSONObject) {
    if (ServiceFactory.isDebugLoggingEnabled())
      Log.d(TAG, "Will load config data: " + paramJSONObject); 
    if (paramJSONObject != null) {
      Iterator<String> iterator = paramJSONObject.keys();
      while (true) {
        if (iterator.hasNext()) {
          String str = iterator.next();
          ConfigEntry configEntry = this.config.get(str);
          if (configEntry != null)
            try {
              configEntry.setValue(paramJSONObject.getLong(str));
              if (ServiceFactory.isDebugLoggingEnabled())
                Log.d(TAG, "Loaded config " + str + ": " + configEntry.getValue()); 
            } catch (JSONException jSONException) {
              Log.e(TAG, "Unable to parse local config value for " + str, (Throwable)jSONException);
            }  
          continue;
        } 
        return;
      } 
    } 
  }
  
  private static class ConfigEntry {
    private final long max;
    
    private final long min;
    
    private long value;
    
    public ConfigEntry(long param1Long1, long param1Long2, long param1Long3) {
      this.min = param1Long1;
      this.max = param1Long3;
      setValue(param1Long2);
    }
    
    public long getValue() {
      return this.value;
    }
    
    public void setValue(long param1Long) {
      if (param1Long < this.min) {
        Log.e(ClientConfig.TAG, "Config value too small: " + param1Long);
        this.value = this.min;
        return;
      } 
      if (param1Long > this.max) {
        Log.e(ClientConfig.TAG, "Config value too large: " + param1Long);
        this.value = this.max;
        return;
      } 
      this.value = param1Long;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html\\util\ClientConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */