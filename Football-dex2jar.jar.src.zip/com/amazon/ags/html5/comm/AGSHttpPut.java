package com.amazon.ags.html5.comm;

import java.io.UnsupportedEncodingException;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;

public class AGSHttpPut extends ServiceRequestBase {
  public AGSHttpPut(String paramString, boolean paramBoolean) {
    super(paramString, paramBoolean);
  }
  
  final HttpRequestBase prepareHttpRequestBase() throws UnsupportedEncodingException {
    HttpPut httpPut = new HttpPut(constructUri());
    if (this.requestBody != null)
      httpPut.setEntity((HttpEntity)new StringEntity(this.requestBody, "UTF-8")); 
    return (HttpRequestBase)httpPut;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\AGSHttpPut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */