package com.amazon.ags.html5.comm;

import com.amazon.ags.AGSClientException;

public interface NetworkClient {
  ServiceResponse execute(ServiceRequestBase paramServiceRequestBase) throws ConnectionException, AGSClientException;
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\NetworkClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */