package com.amazon.ags.html5.comm;

import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;

public class ServiceResponse {
  private static final String DEFAULT_CHARSET = "UTF-8";
  
  private static final String HTTP_HEADER_CHARSET_KEY = "charset";
  
  private static final String TAG = "GC_" + ServiceResponse.class.getSimpleName();
  
  private String content = null;
  
  private final HttpResponse response;
  
  public ServiceResponse(HttpResponse paramHttpResponse) {
    this.response = paramHttpResponse;
  }
  
  private String getCharSetFromEntity(HttpEntity paramHttpEntity) {
    if (paramHttpEntity == null)
      throw new IllegalArgumentException("HttpEntity must not be null"); 
    Header header = paramHttpEntity.getContentType();
    if (header == null)
      return "UTF-8"; 
    HeaderElement[] arrayOfHeaderElement = header.getElements();
    if (arrayOfHeaderElement == null || arrayOfHeaderElement.length == 0)
      return "UTF-8"; 
    NameValuePair nameValuePair = arrayOfHeaderElement[0].getParameterByName("charset");
    return (nameValuePair == null) ? "UTF-8" : nameValuePair.getValue();
  }
  
  public String getContent() throws IOException {
    BufferedReader bufferedReader1;
    StringBuilder stringBuilder1;
    BufferedReader bufferedReader3;
    if (this.content != null)
      return this.content; 
    StringBuilder stringBuilder2 = new StringBuilder();
    String str = null;
    BufferedReader bufferedReader2 = null;
    HttpEntity httpEntity = this.response.getEntity();
    if (httpEntity == null) {
      Log.w(TAG, "Http entity is null");
      return null;
    } 
    InputStream inputStream = httpEntity.getContent();
    try {
    
    } finally {
      stringBuilder2 = null;
      bufferedReader1 = bufferedReader2;
    } 
    inputStream.close();
    if (bufferedReader1 != null)
      bufferedReader1.close(); 
    if (bufferedReader3 != null)
      bufferedReader3.close(); 
    throw stringBuilder1;
  }
  
  public String getHeader(String paramString) {
    Header header = this.response.getFirstHeader(paramString);
    return (header != null) ? header.getValue() : null;
  }
  
  public HttpResponse getResponse() {
    return this.response;
  }
  
  public int getStatusCode() {
    return this.response.getStatusLine().getStatusCode();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\ServiceResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */