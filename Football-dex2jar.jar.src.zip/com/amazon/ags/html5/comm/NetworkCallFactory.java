package com.amazon.ags.html5.comm;

import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import com.amazon.ags.AGSClientException;
import com.amazon.ags.AGSServiceException;
import com.amazon.ags.auth.AuthManager;
import com.amazon.ags.html5.factory.ServiceFactory;
import com.amazon.ags.html5.javascript.CallHandlerBase;
import com.amazon.ags.html5.util.GlobalState;
import com.amazon.ags.html5.util.LocalizationUtil;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

public class NetworkCallFactory extends CallHandlerBase {
  private static final int MAX_RESPONSE_LENGTH_BYTES = 1000000;
  
  private static final String TAG = "GC_" + NetworkCallFactory.class.getSimpleName();
  
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "makeServiceCall" }));
  
  private final AuthManager authManager;
  
  private final GlobalState globalState;
  
  private final LocalizationUtil localizationUtil;
  
  private final NetworkClient networkClient;
  
  private final Set<String> supportedMethodTypes = new HashSet<String>();
  
  public NetworkCallFactory(AuthManager paramAuthManager, Handler paramHandler, GlobalState paramGlobalState, LocalizationUtil paramLocalizationUtil, NetworkClient paramNetworkClient) {
    super(paramHandler, supportedCalls);
    this.supportedMethodTypes.add("get");
    this.supportedMethodTypes.add("put");
    this.supportedMethodTypes.add("post");
    this.supportedMethodTypes.add("patch");
    this.authManager = paramAuthManager;
    this.globalState = paramGlobalState;
    this.localizationUtil = paramLocalizationUtil;
    this.networkClient = paramNetworkClient;
  }
  
  private ServiceRequestBase createRequest(String paramString1, String paramString2, String paramString3, JSONObject paramJSONObject1, JSONObject paramJSONObject2, String paramString4, boolean paramBoolean) throws JSONException {
    // Byte code:
    //   0: ldc 'put'
    //   2: aload_2
    //   3: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   6: ifeq -> 93
    //   9: new com/amazon/ags/html5/comm/AGSHttpPut
    //   12: dup
    //   13: new java/lang/StringBuilder
    //   16: dup
    //   17: invokespecial <init> : ()V
    //   20: aload_1
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: aload_3
    //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: invokevirtual toString : ()Ljava/lang/String;
    //   31: iload #7
    //   33: invokespecial <init> : (Ljava/lang/String;Z)V
    //   36: astore_1
    //   37: aload_1
    //   38: aload #5
    //   40: invokevirtual toString : ()Ljava/lang/String;
    //   43: invokevirtual setRequestBody : (Ljava/lang/String;)V
    //   46: aload #4
    //   48: ifnull -> 357
    //   51: aload #4
    //   53: invokevirtual keys : ()Ljava/util/Iterator;
    //   56: astore_2
    //   57: aload_2
    //   58: invokeinterface hasNext : ()Z
    //   63: ifeq -> 357
    //   66: aload_2
    //   67: invokeinterface next : ()Ljava/lang/Object;
    //   72: checkcast java/lang/String
    //   75: astore_3
    //   76: aload_1
    //   77: aload_3
    //   78: aload #4
    //   80: aload_3
    //   81: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   84: checkcast java/lang/String
    //   87: invokevirtual putHeaderParameter : (Ljava/lang/String;Ljava/lang/String;)V
    //   90: goto -> 57
    //   93: ldc 'post'
    //   95: aload_2
    //   96: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   99: ifeq -> 172
    //   102: new com/amazon/ags/html5/comm/AGSHttpPost
    //   105: dup
    //   106: new java/lang/StringBuilder
    //   109: dup
    //   110: invokespecial <init> : ()V
    //   113: aload_1
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: aload_3
    //   118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: invokevirtual toString : ()Ljava/lang/String;
    //   124: iload #7
    //   126: invokespecial <init> : (Ljava/lang/String;Z)V
    //   129: astore_1
    //   130: aload #5
    //   132: invokevirtual keys : ()Ljava/util/Iterator;
    //   135: astore_2
    //   136: aload_2
    //   137: invokeinterface hasNext : ()Z
    //   142: ifeq -> 169
    //   145: aload_2
    //   146: invokeinterface next : ()Ljava/lang/Object;
    //   151: checkcast java/lang/String
    //   154: astore_3
    //   155: aload_1
    //   156: aload_3
    //   157: aload #5
    //   159: aload_3
    //   160: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   163: invokevirtual putUrlParameter : (Ljava/lang/String;Ljava/lang/String;)V
    //   166: goto -> 136
    //   169: goto -> 46
    //   172: ldc 'get'
    //   174: aload_2
    //   175: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   178: ifeq -> 251
    //   181: new com/amazon/ags/html5/comm/AGSHttpGet
    //   184: dup
    //   185: new java/lang/StringBuilder
    //   188: dup
    //   189: invokespecial <init> : ()V
    //   192: aload_1
    //   193: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   196: aload_3
    //   197: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: invokevirtual toString : ()Ljava/lang/String;
    //   203: iload #7
    //   205: invokespecial <init> : (Ljava/lang/String;Z)V
    //   208: astore_1
    //   209: aload #5
    //   211: invokevirtual keys : ()Ljava/util/Iterator;
    //   214: astore_2
    //   215: aload_2
    //   216: invokeinterface hasNext : ()Z
    //   221: ifeq -> 248
    //   224: aload_2
    //   225: invokeinterface next : ()Ljava/lang/Object;
    //   230: checkcast java/lang/String
    //   233: astore_3
    //   234: aload_1
    //   235: aload_3
    //   236: aload #5
    //   238: aload_3
    //   239: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   242: invokevirtual putUrlParameter : (Ljava/lang/String;Ljava/lang/String;)V
    //   245: goto -> 215
    //   248: goto -> 46
    //   251: ldc 'patch'
    //   253: aload_2
    //   254: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   257: ifeq -> 330
    //   260: new com/amazon/ags/html5/comm/AGSHttpPatch
    //   263: dup
    //   264: new java/lang/StringBuilder
    //   267: dup
    //   268: invokespecial <init> : ()V
    //   271: aload_1
    //   272: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   275: aload_3
    //   276: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   279: invokevirtual toString : ()Ljava/lang/String;
    //   282: iload #7
    //   284: invokespecial <init> : (Ljava/lang/String;Z)V
    //   287: astore_1
    //   288: aload #5
    //   290: invokevirtual keys : ()Ljava/util/Iterator;
    //   293: astore_2
    //   294: aload_2
    //   295: invokeinterface hasNext : ()Z
    //   300: ifeq -> 327
    //   303: aload_2
    //   304: invokeinterface next : ()Ljava/lang/Object;
    //   309: checkcast java/lang/String
    //   312: astore_3
    //   313: aload_1
    //   314: aload_3
    //   315: aload #5
    //   317: aload_3
    //   318: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   321: invokevirtual putUrlParameter : (Ljava/lang/String;Ljava/lang/String;)V
    //   324: goto -> 294
    //   327: goto -> 46
    //   330: new java/lang/IllegalArgumentException
    //   333: dup
    //   334: new java/lang/StringBuilder
    //   337: dup
    //   338: invokespecial <init> : ()V
    //   341: ldc 'Unsupported http method: '
    //   343: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   346: aload_2
    //   347: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   350: invokevirtual toString : ()Ljava/lang/String;
    //   353: invokespecial <init> : (Ljava/lang/String;)V
    //   356: athrow
    //   357: aload #6
    //   359: ifnull -> 368
    //   362: aload_1
    //   363: aload #6
    //   365: invokevirtual setRequestBody : (Ljava/lang/String;)V
    //   368: aload_1
    //   369: areturn
  }
  
  private RequestResult createRequestResult(ServiceResponse paramServiceResponse) throws AGSClientException, AGSServiceException, IOException {
    boolean bool = ServiceFactory.isDebugLoggingEnabled();
    HttpResponse httpResponse = paramServiceResponse.getResponse();
    int i = paramServiceResponse.getStatusCode();
    HttpEntity httpEntity = httpResponse.getEntity();
    Header header = httpResponse.getLastHeader("X-Amzn-RequestId");
    if (bool)
      Log.d("DEBUG", "Network response: " + httpResponse.getStatusLine()); 
    if (i >= 400) {
      if (header != null)
        Log.w(TAG, "Network request ID for failed request: " + header.getValue()); 
      throw new AGSServiceException(httpResponse.getStatusLine().getReasonPhrase());
    } 
    if (httpEntity == null) {
      if (header != null)
        Log.w(TAG, "Network request ID for failed request: " + header.getValue()); 
      throw new AGSClientException("Received null entity from http response");
    } 
    if (httpEntity.getContentLength() > 1000000L) {
      if (header != null)
        Log.w(TAG, "Network request ID for failed request: " + header.getValue()); 
      throw new AGSServiceException("Response content is longer than expected");
    } 
    if (bool) {
      if (header != null) {
        try {
          Log.d("DEBUG", "Network request ID: " + header.getValue());
          Log.d("DEBUG", "Network response: " + httpResponse.getStatusLine() + " --> " + paramServiceResponse.getContent());
        } catch (IOException iOException) {}
        return new RequestResult(paramServiceResponse.getContent(), "SUCCESS");
      } 
    } else {
      return new RequestResult(paramServiceResponse.getContent(), "SUCCESS");
    } 
    Log.d("DEBUG", "Network response: " + iOException.getStatusLine() + " --> " + paramServiceResponse.getContent());
  }
  
  private void decorateRequestParametersWithPreIBAData(JSONObject paramJSONObject) throws JSONException {
    paramJSONObject.put("locale", this.localizationUtil.getCurrentLocale().toString());
    String str = this.authManager.getGameId();
    paramJSONObject.put("gameId", str);
    paramJSONObject.put("GameId", str);
    str = paramJSONObject.optString("playerId", null);
    if (str == null || "SELF".equals(str))
      str = this.globalState.getPlayerId(); 
    if (str != null) {
      paramJSONObject.put("playerId", str);
      paramJSONObject.put("PlayerId", str);
    } 
  }
  
  private void handleServiceRequest(String paramString1, String paramString2, String paramString3, String paramString4, JSONObject paramJSONObject1, JSONObject paramJSONObject2, String paramString5, boolean paramBoolean) {
    ServiceResponse serviceResponse4 = null;
    ServiceResponse serviceResponse3 = null;
    ServiceResponse serviceResponse1 = serviceResponse3;
    ServiceResponse serviceResponse2 = serviceResponse4;
    try {
      ServiceRequestBase serviceRequestBase = createRequest(paramString2, paramString3, paramString4, paramJSONObject1, paramJSONObject2, paramString5, paramBoolean);
      serviceResponse1 = serviceResponse3;
      serviceResponse2 = serviceResponse4;
      ServiceResponse serviceResponse = this.networkClient.execute(serviceRequestBase);
      serviceResponse1 = serviceResponse;
      serviceResponse2 = serviceResponse;
      sendReply(paramString1, createRequestResult(serviceResponse), String.valueOf(serviceResponse.getStatusCode()));
      return;
    } catch (ConnectionException connectionException) {
      Log.e(TAG, "Connection exception encountered while executing request: " + connectionException.toString(), connectionException);
      if (serviceResponse1 != null) {
        String str = String.valueOf(serviceResponse1.getStatusCode());
      } else {
        connectionException = null;
      } 
      sendReply(paramString1, new RequestResult("{}", "NETWORK_ERROR"), (String)connectionException);
      return;
    } catch (Exception exception) {
      Log.e(TAG, "Exception encountered while executing request: " + exception.toString(), exception);
      if (serviceResponse2 != null) {
        String str = String.valueOf(serviceResponse2.getStatusCode());
      } else {
        exception = null;
      } 
      sendReply(paramString1, new RequestResult("{}", "ERROR"), (String)exception);
      return;
    } 
  }
  
  private void sendReply(String paramString1, RequestResult paramRequestResult, String paramString2) {
    RequestResult requestResult = paramRequestResult;
    if (paramRequestResult == null)
      requestResult = new RequestResult("{}", "ERROR"); 
    sendReply(paramString1, requestResult.getResponseJSON(), requestResult.getResponseCode(), paramString2);
  }
  
  public boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    RequestResult requestResult;
    boolean bool;
    JSONObject jSONObject1;
    JSONObject jSONObject2;
    String str1;
    String str2;
    String str3;
    if (!"makeServiceCall".equals(paramString2))
      return false; 
    if (ServiceFactory.isDebugLoggingEnabled())
      Log.d(TAG, "Service call: " + paramJSONObject); 
    try {
      paramString2 = paramJSONObject.getString("method");
      jSONObject1 = paramJSONObject.optJSONObject("httpHeaders");
      jSONObject2 = paramJSONObject.getJSONObject("parameters");
      str1 = paramJSONObject.optString("httpPayload", null);
      bool = paramJSONObject.optBoolean("authenticate", false);
      str2 = paramJSONObject.getString("endPoint");
      str3 = paramJSONObject.getString("httpMethod");
      if (paramString2 == null || jSONObject2 == null || paramString1 == null || TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3))
        throw new IllegalArgumentException("Insufficient arguments for request handling"); 
      if (!this.supportedMethodTypes.contains(str3.toLowerCase()))
        throw new IllegalArgumentException("Unsupported http method: " + str3); 
    } catch (JSONException jSONException) {
      Log.e(TAG, "Unable to service request for request: " + paramJSONObject + " due to JSONException: " + jSONException.toString(), (Throwable)jSONException);
      requestResult = new RequestResult("{}", "REQUEST_ERROR");
      sendReply(paramString1, requestResult.getResponseJSON(), requestResult.getResponseCode());
      return true;
    } catch (Exception exception) {
      Log.e(TAG, "Unable to service request for request: " + paramJSONObject + " due to exception: " + exception.toString(), exception);
      requestResult = new RequestResult("{}", "REQUEST_ERROR");
      sendReply(paramString1, requestResult.getResponseJSON(), requestResult.getResponseCode());
      return true;
    } 
    decorateRequestParametersWithPreIBAData(jSONObject2);
    handleServiceRequest(paramString1, str2, str3, (String)requestResult, jSONObject1, jSONObject2, str1, bool);
    return true;
  }
  
  private class RequestResult {
    private final String responseCode;
    
    private final String responseJSON;
    
    public RequestResult(String param1String1, String param1String2) {
      this.responseJSON = param1String1;
      this.responseCode = param1String2;
    }
    
    public String getResponseCode() {
      return this.responseCode;
    }
    
    public String getResponseJSON() {
      return this.responseJSON;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\NetworkCallFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */