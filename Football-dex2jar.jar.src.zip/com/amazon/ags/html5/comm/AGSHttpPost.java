package com.amazon.ags.html5.comm;

import java.io.UnsupportedEncodingException;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;

public class AGSHttpPost extends ServiceRequestBase {
  public AGSHttpPost(String paramString, boolean paramBoolean) {
    super(paramString, paramBoolean);
  }
  
  public HttpRequestBase prepareHttpRequestBase() throws UnsupportedEncodingException {
    HttpPost httpPost = new HttpPost(constructUri());
    if (this.requestBody != null)
      httpPost.setEntity((HttpEntity)new StringEntity(this.requestBody, "UTF-8")); 
    return (HttpRequestBase)httpPost;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\AGSHttpPost.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */