package com.amazon.ags.html5.comm;

import java.io.UnsupportedEncodingException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;

public class AGSHttpGet extends ServiceRequestBase {
  public AGSHttpGet(String paramString, boolean paramBoolean) {
    super(paramString, paramBoolean);
  }
  
  final HttpRequestBase prepareHttpRequestBase() throws UnsupportedEncodingException {
    return (HttpRequestBase)new HttpGet(constructUri());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\AGSHttpGet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */