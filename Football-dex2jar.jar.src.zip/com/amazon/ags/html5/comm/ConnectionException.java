package com.amazon.ags.html5.comm;

public class ConnectionException extends Exception {
  private static final long serialVersionUID = 3026948415101973716L;
  
  public ConnectionException() {}
  
  public ConnectionException(String paramString) {
    super(paramString);
  }
  
  public ConnectionException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public ConnectionException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\ConnectionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */