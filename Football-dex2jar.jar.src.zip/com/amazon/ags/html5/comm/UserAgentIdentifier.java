package com.amazon.ags.html5.comm;

import com.amazon.ags.VersionInfo;
import com.amazon.ags.html5.content.ContentVersion;

public class UserAgentIdentifier {
  private static final String GAMECIRCLE_ANDROID_PRODUCT_TOKEN = "gamecircle-android";
  
  private static final String GAMECIRCLE_JS_PRODUCT_TOKEN = "gamecircle-js";
  
  private static final String RFC2616_PRODUCT_TOKEN_AND_VERSION_SEPARATOR = "/";
  
  private static final String RFC2616_PRODUCT_TOKEN_SEPARATOR = " ";
  
  private final ContentVersion contentVersion;
  
  private final VersionInfo versionInfo;
  
  public UserAgentIdentifier(VersionInfo paramVersionInfo, ContentVersion paramContentVersion) {
    this.versionInfo = paramVersionInfo;
    this.contentVersion = paramContentVersion;
  }
  
  public String getUserAgent() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("gamecircle-android");
    stringBuilder.append("/");
    stringBuilder.append(this.versionInfo.getVersion());
    if (this.contentVersion != null) {
      stringBuilder.append(" ");
      stringBuilder.append("gamecircle-js");
      stringBuilder.append("/");
      stringBuilder.append(this.contentVersion.getVersion());
    } 
    return stringBuilder.toString();
  }
  
  public String toString() {
    return getUserAgent();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\UserAgentIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */