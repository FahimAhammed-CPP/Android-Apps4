package com.amazon.ags.html5.comm;

import android.util.Log;
import com.amazon.ags.AGSClientException;
import com.amazon.ags.auth.AuthManager;
import com.amazon.ags.client.KindleFireProxy;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.IllegalConstructionException;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.constants.metrics.EventNames;
import com.amazon.ags.html5.util.DeviceInfo;
import com.amazon.ags.html5.util.LocalizationUtil;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.methods.HttpUriRequest;

public class HttpNetworkClient implements NetworkClient {
  private static final String AUTH_TOKEN_HEADER = "authorization-token";
  
  private static final String DEVICE_MAKE_HEADER = "device-make";
  
  private static final String DEVICE_MODEL_HEADER = "device-model";
  
  public static final String DEVICE_SERIAL_NUMBER_HEADER = "device-serial-number";
  
  private static final String DEVICE_TYPE_HEADER = "device-type";
  
  private static final String TAG = "GC_HttpNetworkClient";
  
  private final AuthManager authManager;
  
  private final DeviceInfo deviceInfo;
  
  private final EventCollectorClient eventCollectorClient;
  
  private final HttpClient httpClient;
  
  private final KindleFireProxy kindleFireProxy;
  
  private final LocalizationUtil localizationUtil;
  
  public HttpNetworkClient(HttpClient paramHttpClient, KindleFireProxy paramKindleFireProxy, AuthManager paramAuthManager, DeviceInfo paramDeviceInfo, EventCollectorClient paramEventCollectorClient, LocalizationUtil paramLocalizationUtil) {
    this.httpClient = paramHttpClient;
    this.kindleFireProxy = paramKindleFireProxy;
    this.authManager = paramAuthManager;
    this.deviceInfo = paramDeviceInfo;
    this.eventCollectorClient = paramEventCollectorClient;
    this.localizationUtil = paramLocalizationUtil;
  }
  
  private void abortRequest(HttpRequestBase paramHttpRequestBase) {
    if (paramHttpRequestBase != null)
      paramHttpRequestBase.abort(); 
  }
  
  private void addADPTokenHeaders(HttpRequestBase paramHttpRequestBase, String paramString) throws AGSClientException {
    Map map = this.kindleFireProxy.signMessage(paramHttpRequestBase.getMethod(), paramHttpRequestBase.getURI().toString(), paramString);
    if (map == null)
      throw new AGSClientException("Network request requires authentication"); 
    paramHttpRequestBase.addHeader("x-adp-token", (String)map.get("token"));
    paramHttpRequestBase.addHeader("x-adp-alg", "SHA256withRSA:1.0");
    paramHttpRequestBase.addHeader("x-adp-signature", (String)map.get("signature") + ":" + (String)map.get("nonce"));
  }
  
  private void addAuthenticationHeaders(HttpRequestBase paramHttpRequestBase, String paramString) throws AGSClientException {
    if (this.kindleFireProxy.isKindle()) {
      addADPTokenHeaders(paramHttpRequestBase, paramString);
      return;
    } 
    addLWATokenHeader(paramHttpRequestBase);
  }
  
  private void addLWATokenHeader(HttpRequestBase paramHttpRequestBase) throws AGSClientException {
    String str = this.authManager.tryGetToken();
    if (str == null)
      throw new AGSClientException("Network request requires authentication"); 
    paramHttpRequestBase.addHeader("authorization-token", str);
  }
  
  private void addRequestParameters(HttpRequestBase paramHttpRequestBase, ServiceRequestBase paramServiceRequestBase) {
    for (Map.Entry<String, String> entry : paramServiceRequestBase.getHeaderParams().entrySet()) {
      if (entry.getKey() != null && entry.getValue() != null)
        paramHttpRequestBase.addHeader((String)entry.getKey(), (String)entry.getValue()); 
    } 
  }
  
  public final ServiceResponse execute(ServiceRequestBase paramServiceRequestBase) throws ConnectionException, AGSClientException {
    HttpRequestBase httpRequestBase = prepare(paramServiceRequestBase);
    httpRequestBase.addHeader("device-type", this.deviceInfo.getDeviceType());
    httpRequestBase.addHeader("device-make", DeviceInfo.getManufacturer());
    httpRequestBase.addHeader("device-model", DeviceInfo.getModel());
    httpRequestBase.addHeader("device-serial-number", DeviceInfo.getIdentifier());
    httpRequestBase.addHeader("locale", this.localizationUtil.getCurrentLocale().toString());
    if (paramServiceRequestBase.isAuthenticationRequired())
      addAuthenticationHeaders(httpRequestBase, paramServiceRequestBase.getBody()); 
    long l = System.currentTimeMillis();
    try {
      Log.d("GC_HttpNetworkClient", "Request: " + httpRequestBase.getMethod() + " " + httpRequestBase.getURI());
      HttpResponse httpResponse = this.httpClient.execute((HttpUriRequest)httpRequestBase);
      if (httpResponse == null || httpResponse.getStatusLine() == null) {
        reportServiceCall(System.currentTimeMillis() - l, paramServiceRequestBase.getEndpoint(), httpRequestBase.getMethod(), -1, "HttpResponse must not be null");
        throw new AGSClientException("HttpResponse must not be null");
      } 
    } catch (IOException null) {
      reportServiceCall(System.currentTimeMillis() - l, paramServiceRequestBase.getEndpoint(), httpRequestBase.getMethod(), -1, exception.getMessage());
      abortRequest(httpRequestBase);
      throw new ConnectionException(exception);
    } catch (Exception exception) {
      reportServiceCall(System.currentTimeMillis() - l, paramServiceRequestBase.getEndpoint(), httpRequestBase.getMethod(), -1, exception.getMessage());
      abortRequest(httpRequestBase);
      throw new AGSClientException("Unexpected exception", exception);
    } 
    Log.d("GC_HttpNetworkClient", "Result:" + exception.getStatusLine());
    reportServiceCall(System.currentTimeMillis() - l, paramServiceRequestBase.getEndpoint(), httpRequestBase.getMethod(), exception.getStatusLine().getStatusCode(), exception.getStatusLine().getReasonPhrase());
    return new ServiceResponse((HttpResponse)exception);
  }
  
  final HttpRequestBase prepare(ServiceRequestBase paramServiceRequestBase) throws AGSClientException {
    try {
      HttpRequestBase httpRequestBase = paramServiceRequestBase.prepareHttpRequestBase();
      addRequestParameters(httpRequestBase, paramServiceRequestBase);
      return httpRequestBase;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new AGSClientException("Unable to prepare HTTP request", unsupportedEncodingException);
    } catch (URISyntaxException uRISyntaxException) {
      throw new AGSClientException("Invalid request URI", uRISyntaxException);
    } 
  }
  
  protected void reportServiceCall(long paramLong, String paramString1, String paramString2, int paramInt, String paramString3) {
    if (this.eventCollectorClient == null) {
      Log.e("GC_HttpNetworkClient", "Null collector. Cannot report service latency event.");
      return;
    } 
    if (!this.eventCollectorClient.isReportingEnabled()) {
      Log.i("GC_HttpNetworkClient", "Reporting is disabled. Cannot report service latency event.");
      return;
    } 
    String str = EventNames.GameCircleServiceCall.name();
    HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>();
    hashMap3.put("endpoint", paramString1);
    hashMap3.put("method", paramString2);
    hashMap3.put("reason", paramString3);
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
    hashMap1.put("statusCode", Integer.valueOf(paramInt));
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    hashMap2.put("latency", Long.valueOf(paramLong));
    try {
      GameCircleGenericEvent gameCircleGenericEvent = new GameCircleGenericEvent(str, hashMap3, hashMap1, hashMap2);
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent);
      return;
    } catch (IllegalConstructionException illegalConstructionException) {
      Log.e("GC_HttpNetworkClient", "Could not construct service latency event. It will not be reported.");
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\HttpNetworkClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */