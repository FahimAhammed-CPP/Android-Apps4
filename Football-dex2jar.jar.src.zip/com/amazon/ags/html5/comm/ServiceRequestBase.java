package com.amazon.ags.html5.comm;

import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.client.methods.HttpRequestBase;

public abstract class ServiceRequestBase {
  private static final String CHAR_SET = "UTF-8";
  
  private final boolean authenticationRequired;
  
  private final String endPoint;
  
  private final Map<String, String> headerParams = new HashMap<String, String>();
  
  protected String requestBody;
  
  private final Map<String, String> urlParams = new HashMap<String, String>();
  
  public ServiceRequestBase(String paramString, boolean paramBoolean) {
    this.authenticationRequired = paramBoolean;
    this.endPoint = paramString;
  }
  
  public String constructUri() throws UnsupportedEncodingException {
    StringBuilder stringBuilder = new StringBuilder(this.endPoint);
    if (stringBuilder.charAt(stringBuilder.length() - 1) == '/')
      stringBuilder.deleteCharAt(stringBuilder.length() - 1); 
    boolean bool = true;
    for (Map.Entry<String, String> entry : getUrlParams().entrySet()) {
      String str1;
      String str2 = URLEncoder.encode((String)entry.getKey(), "UTF-8");
      String str3 = URLEncoder.encode((String)entry.getValue(), "UTF-8");
      if (bool) {
        str1 = "?";
      } else {
        str1 = "&";
      } 
      stringBuilder.append(str1).append(str2).append("=").append(str3);
      bool = false;
    } 
    return stringBuilder.toString();
  }
  
  String getBody() {
    return (this.requestBody != null) ? this.requestBody : "";
  }
  
  public String getEndpoint() {
    return this.endPoint;
  }
  
  public final Map<String, String> getHeaderParams() {
    return this.headerParams;
  }
  
  public final Map<String, String> getUrlParams() {
    return this.urlParams;
  }
  
  public final boolean isAuthenticationRequired() {
    return this.authenticationRequired;
  }
  
  abstract HttpRequestBase prepareHttpRequestBase() throws UnsupportedEncodingException, URISyntaxException;
  
  public final void putHeaderParameter(String paramString1, String paramString2) {
    this.headerParams.put(paramString1, paramString2);
  }
  
  public final void putUrlParameter(String paramString1, String paramString2) {
    this.urlParams.put(paramString1, paramString2);
  }
  
  public void setRequestBody(String paramString) {
    this.requestBody = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\comm\ServiceRequestBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */