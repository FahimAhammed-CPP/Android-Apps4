package com.amazon.ags.html5.overlay;

import com.amazon.ags.api.overlay.PopUpLocation;

public enum PopUpPrefs {
  INSTANCE;
  
  private static final int FADE_IN_DURATION_MS = 500;
  
  private static final int FADE_OUT_DURATION_MS = 2000;
  
  private static final int WELCOME_BACK_FADE_IN_DURATION_MS = 500;
  
  private static final int WELCOME_BACK_FADE_OUT_DURATION_MS = 3000;
  
  private PopUpLocation popUpLocation = PopUpLocation.BOTTOM_CENTER;
  
  private boolean popUpsEnabled = true;
  
  static {
    $VALUES = new PopUpPrefs[] { INSTANCE };
  }
  
  public void disable() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/amazon/ags/html5/overlay/PopUpPrefs.INSTANCE : Lcom/amazon/ags/html5/overlay/PopUpPrefs;
    //   5: iconst_0
    //   6: putfield popUpsEnabled : Z
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
  }
  
  public void enable() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/amazon/ags/html5/overlay/PopUpPrefs.INSTANCE : Lcom/amazon/ags/html5/overlay/PopUpPrefs;
    //   5: iconst_1
    //   6: putfield popUpsEnabled : Z
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
  }
  
  public int getFadeInDuration() {
    return 500;
  }
  
  public int getFadeOutDuration() {
    return 2000;
  }
  
  public PopUpLocation getLocation() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield popUpLocation : Lcom/amazon/ags/api/overlay/PopUpLocation;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public int getWelcomeBackFadeInDuration() {
    return 500;
  }
  
  public int getWelcomeBackFadeOutDuration() {
    return 3000;
  }
  
  public boolean isEnabled() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield popUpsEnabled : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public void setLocation(PopUpLocation paramPopUpLocation) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield popUpLocation : Lcom/amazon/ags/api/overlay/PopUpLocation;
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\PopUpPrefs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */