package com.amazon.ags.html5.overlay.toasts;

import android.app.Activity;
import android.os.Handler;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import com.amazon.ags.api.overlay.PopUpLocation;
import com.amazon.ags.client.JSONRequest;
import com.amazon.ags.html5.javascript.JavascriptRepository;
import com.amazon.ags.html5.overlay.PopUpPrefs;
import com.amazon.ags.html5.service.ServiceHelper;
import com.amazon.ags.html5.util.JSONUtils;
import com.amazon.ags.html5.util.LocalizationUtil;
import com.amazon.ags.html5.util.WebViewFactory;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public class ClickableWebViewToast extends ClickableToastImpl {
  private static final String TAG = "GC_" + ClickableWebViewToast.class.getSimpleName();
  
  private String data;
  
  private final JavascriptRepository jsRepository;
  
  private LocalizationUtil localizationUtil;
  
  private ServiceHelper serviceHelper;
  
  private final Handler uiPoster;
  
  private final WebView webView;
  
  public ClickableWebViewToast(Activity paramActivity, Handler paramHandler, ClickableToastImpl.ToastParams paramToastParams, WebViewFactory paramWebViewFactory, JavascriptRepository paramJavascriptRepository, ServiceHelper paramServiceHelper, LocalizationUtil paramLocalizationUtil) {
    super(paramActivity, paramToastParams);
    this.serviceHelper = paramServiceHelper;
    this.uiPoster = paramHandler;
    this.jsRepository = paramJavascriptRepository;
    this.webView = paramWebViewFactory.newToastWebView();
    this.webView.getSettings().setRenderPriority(WebSettings.RenderPriority.LOW);
    this.webView.setBackgroundColor(0);
    this.jsRepository.loadToastJavascript(this.webView);
    this.localizationUtil = paramLocalizationUtil;
    this.data = "{}";
    addView((View)this.webView);
    setViewParams((View)this.webView);
  }
  
  private void setViewParams(View paramView) {
    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)paramView.getLayoutParams();
    layoutParams.width = (int)TypedValue.applyDimension(1, 320.0F, getResources().getDisplayMetrics());
    layoutParams.height = -2;
    layoutParams.gravity = 1;
  }
  
  protected View initView() {
    String str1 = this.localizationUtil.getLanguageCode();
    String str2 = this.localizationUtil.getCountryCode();
    boolean bool = this.toastParams.getIsFireTV();
    try {
      JSONObject jSONObject = new JSONObject(this.data);
      Integer integer1 = Integer.valueOf(jSONObject.getInt("toastDurationFadeIn"));
      Integer integer2 = Integer.valueOf(jSONObject.getInt("toastDurationShow"));
      Integer integer3 = Integer.valueOf(jSONObject.getInt("toastDurationFadeOut"));
      String str = jSONObject.getString("locationIsGCDefault");
      if (integer1 != null)
        this.toastParams.setFadeInDuration(integer1.intValue()); 
      if (integer2 != null)
        this.toastParams.setDuration(integer2.intValue()); 
      if (integer3 != null)
        this.toastParams.setFadeOutDuration(integer3.intValue()); 
      if ("true".equals(str)) {
        this.toastParams.setPopUpLocation(PopUpLocation.BOTTOM_CENTER);
      } else {
        this.toastParams.setPopUpLocation(PopUpPrefs.INSTANCE.getLocation());
      } 
      str1 = "javascript:var data = {params:" + this.data + ", aggregateCount:0, languageCode:'" + str1 + "', countryCode:'" + str2 + "', isFireTV: " + Boolean.valueOf(bool) + "};" + "renderData(data);";
      this.webView.loadUrl(str1);
    } catch (Exception exception) {
      Log.e(TAG, "Unable to prepare toast content.  Toast parameters not valid JSON", exception);
    } 
    return (View)this.webView;
  }
  
  public void setServiceHelper(ServiceHelper paramServiceHelper) {
    this.serviceHelper = paramServiceHelper;
  }
  
  public void setToastData(String paramString) {
    this.data = paramString;
  }
  
  public void show(Handler paramHandler) {
    super.show(paramHandler);
    JSONRequest jSONRequest = new JSONRequest() {
        public JSONObject getRequest() {
          JSONObject jSONObject = new JSONObject();
          try {
            JSONObject jSONObject1 = new JSONObject(ClickableWebViewToast.this.data);
            jSONObject.put("ACTION_CODE", "HANDLE_TOAST_DISPLAY_METRIC");
            jSONObject.put("REQUEST_ID", UUID.randomUUID().toString());
            jSONObject.put("toastRequestDisplayed", jSONObject1);
            return jSONObject;
          } catch (JSONException jSONException) {
            Log.w(ClickableWebViewToast.TAG, "Error building toast metric request", (Throwable)jSONException);
            return jSONObject;
          } 
        }
        
        public void setResponse(JSONObject param1JSONObject) {}
      };
    if (this.serviceHelper != null) {
      this.serviceHelper.handleRequestAsync(jSONRequest);
      return;
    } 
    Log.w(TAG, "Error submitting toast metric request");
  }
  
  public void update(final String jsRequest, int paramInt) {
    jsRequest = "javascript:var data = {params:" + JSONUtils.sanitize(jsRequest) + ", aggregateCount:" + Integer.toString(paramInt) + "};" + "renderData(data);";
    this.uiPoster.post(new Runnable() {
          public void run() {
            ClickableWebViewToast.this.webView.loadUrl(jsRequest);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\toasts\ClickableWebViewToast.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */