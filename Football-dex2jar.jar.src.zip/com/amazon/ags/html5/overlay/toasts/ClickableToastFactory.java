package com.amazon.ags.html5.overlay.toasts;

public interface ClickableToastFactory {
  ClickableToast getClickableWebViewToast(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\toasts\ClickableToastFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */