package com.amazon.ags.html5.overlay.toasts;

import android.os.Handler;
import android.view.View;

public interface ClickableToast {
  void addClickableToastObserver(ClickableToastObserver paramClickableToastObserver);
  
  void destroy();
  
  boolean isShowing();
  
  void setToastData(String paramString);
  
  void setToastOnTouchListener(View.OnTouchListener paramOnTouchListener);
  
  void show(Handler paramHandler);
  
  void update(String paramString, int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\toasts\ClickableToast.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */