package com.amazon.ags.html5.overlay.toasts;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import com.amazon.ags.api.overlay.PopUpLocation;
import java.util.HashSet;
import java.util.Set;

public abstract class ClickableToastImpl extends LinearLayout implements ClickableToast {
  private static final String TAG = "GC_" + ClickableToastImpl.class.getSimpleName();
  
  private boolean _isShowing = false;
  
  protected Animation hideAnimation;
  
  private View rootView;
  
  protected Animation showAnimation;
  
  private Set<ClickableToastObserver> toastObservers = new HashSet<ClickableToastObserver>();
  
  protected final ToastParams toastParams;
  
  private View.OnTouchListener touchListener;
  
  private final WindowManager windowManager;
  
  public ClickableToastImpl(Activity paramActivity) {
    this(paramActivity, new ToastParams());
  }
  
  public ClickableToastImpl(Activity paramActivity, ToastParams paramToastParams) {
    super((Context)paramActivity);
    this.toastParams = paramToastParams;
    this.windowManager = paramActivity.getWindowManager();
    this.touchListener = new View.OnTouchListener() {
        public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
          return false;
        }
      };
  }
  
  private void addToWindow() {
    Log.d(TAG, "Entering addToWindow...");
    try {
      this.windowManager.addView((View)this, (ViewGroup.LayoutParams)getWindowManagerParams());
      return;
    } catch (Exception exception) {
      Log.w("Attempted to show a toast after the associated activity was closed", exception);
      return;
    } 
  }
  
  private int getGravity() {
    switch (this.toastParams.getPopUpLocation()) {
      default:
        return 81;
      case TOP_LEFT:
      case TOP_CENTER:
      case TOP_RIGHT:
        break;
    } 
    return 49;
  }
  
  private final void hide() {
    post(new Runnable() {
          public void run() {
            // Byte code:
            //   0: invokestatic access$600 : ()Ljava/lang/String;
            //   3: ldc 'Entering runnable for hide()'
            //   5: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
            //   8: pop
            //   9: aload_0
            //   10: getfield this$0 : Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl;
            //   13: invokestatic access$000 : (Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl;)Landroid/view/View;
            //   16: bipush #8
            //   18: invokevirtual setVisibility : (I)V
            //   21: aload_0
            //   22: getfield this$0 : Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl;
            //   25: invokestatic access$700 : (Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl;)Landroid/view/WindowManager;
            //   28: aload_0
            //   29: getfield this$0 : Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl;
            //   32: invokeinterface removeView : (Landroid/view/View;)V
            //   37: aload_0
            //   38: getfield this$0 : Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl;
            //   41: iconst_0
            //   42: invokestatic access$300 : (Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl;Z)V
            //   45: aload_0
            //   46: getfield this$0 : Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl;
            //   49: invokestatic access$800 : (Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl;)Ljava/util/Set;
            //   52: invokeinterface iterator : ()Ljava/util/Iterator;
            //   57: astore_1
            //   58: aload_1
            //   59: invokeinterface hasNext : ()Z
            //   64: ifeq -> 98
            //   67: aload_1
            //   68: invokeinterface next : ()Ljava/lang/Object;
            //   73: checkcast com/amazon/ags/html5/overlay/toasts/ClickableToastObserver
            //   76: invokeinterface notifyToastDestroyed : ()V
            //   81: goto -> 58
            //   84: astore_1
            //   85: invokestatic access$600 : ()Ljava/lang/String;
            //   88: ldc 'Error removing view from window: '
            //   90: aload_1
            //   91: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
            //   94: pop
            //   95: goto -> 37
            //   98: return
            // Exception table:
            //   from	to	target	type
            //   21	37	84	java/lang/IllegalArgumentException
          }
        });
    setOnTouchListener(null);
  }
  
  private void setIsShowing(boolean paramBoolean) {
    this._isShowing = paramBoolean;
  }
  
  private void setupHideAnimationCallback() {
    this.hideAnimation.setAnimationListener(new Animation.AnimationListener() {
          public void onAnimationEnd(Animation param1Animation) {
            ClickableToastImpl.this.hide();
          }
          
          public void onAnimationRepeat(Animation param1Animation) {}
          
          public void onAnimationStart(Animation param1Animation) {}
        });
  }
  
  private void setupShowAnimationCallback() {
    this.showAnimation.setAnimationListener(new Animation.AnimationListener() {
          public void onAnimationEnd(Animation param1Animation) {
            ClickableToastImpl.this.startHideAnimations();
          }
          
          public void onAnimationRepeat(Animation param1Animation) {}
          
          public void onAnimationStart(Animation param1Animation) {}
        });
  }
  
  private final void startHideAnimations() {
    post(new Runnable() {
          public void run() {
            if (!ClickableToastImpl.this.isShowing())
              return; 
            ClickableToastImpl.this.hideAnimation.setStartOffset(ClickableToastImpl.this.toastParams.getDuration());
            ClickableToastImpl.this.rootView.startAnimation(ClickableToastImpl.this.hideAnimation);
          }
        });
  }
  
  public void addClickableToastObserver(ClickableToastObserver paramClickableToastObserver) {
    if (paramClickableToastObserver == null)
      throw new IllegalArgumentException("Observer cannot be null"); 
    this.toastObservers.add(paramClickableToastObserver);
  }
  
  public void destroy() {
    hide();
  }
  
  public void dismiss() {
    if (this.windowManager != null)
      try {
        this.windowManager.removeView((View)this);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
        Log.v(TAG, "Tried to remove toast but none was attached.");
        return;
      }  
  }
  
  protected WindowManager.LayoutParams getWindowManagerParams() {
    WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
    layoutParams.flags = 40;
    layoutParams.format = 1;
    layoutParams.gravity = getGravity();
    if ((getResources().getConfiguration()).orientation == 1) {
      layoutParams.verticalMargin = this.toastParams.getVerticalMarginPortrait();
      layoutParams.horizontalMargin = this.toastParams.getHorizontalMarginPortrait();
      layoutParams.height = -2;
      layoutParams.width = -2;
      return layoutParams;
    } 
    layoutParams.verticalMargin = this.toastParams.getVerticalMarginLandscape();
    layoutParams.horizontalMargin = this.toastParams.getHorizontalMarginLandscape();
    layoutParams.height = -2;
    layoutParams.width = -2;
    return layoutParams;
  }
  
  protected void initAnimations() {
    this.showAnimation = AnimationUtils.loadAnimation(getContext(), this.toastParams.getShowAnimationResource());
    this.showAnimation.setDuration(this.toastParams.getFadeInDuration());
    this.hideAnimation = AnimationUtils.loadAnimation(getContext(), this.toastParams.getHideAnimationResource());
    this.hideAnimation.setDuration(this.toastParams.getFadeOutDuration());
    setupHideAnimationCallback();
    setupShowAnimationCallback();
  }
  
  protected abstract View initView();
  
  public boolean isShowing() {
    return this._isShowing;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this._isShowing = false;
  }
  
  public void setToastOnTouchListener(View.OnTouchListener paramOnTouchListener) {
    this.touchListener = paramOnTouchListener;
  }
  
  public void show(Handler paramHandler) {
    paramHandler.post(new Runnable() {
          public void run() {
            if (ClickableToastImpl.this.isShowing())
              return; 
            ClickableToastImpl.access$002(ClickableToastImpl.this, ClickableToastImpl.this.initView());
            ClickableToastImpl.this.rootView.setOnTouchListener(ClickableToastImpl.this.touchListener);
            ClickableToastImpl.this.addToWindow();
            ClickableToastImpl.this.initAnimations();
            ClickableToastImpl.this.rootView.startAnimation(ClickableToastImpl.this.showAnimation);
            ClickableToastImpl.this.rootView.setVisibility(0);
            ClickableToastImpl.this.setIsShowing(true);
          }
        });
  }
  
  public abstract void update(String paramString, int paramInt);
  
  public static class ToastParams {
    private static final long DEFAULT_DURATION = 1500L;
    
    private static final long DEFAULT_FADE_IN_DURATION = 500L;
    
    private static final long DEFAULT_FADE_OUT_DURATION = 1000L;
    
    private static final float DEFAULT_HORIZONTAL_MARGIN_LANDSCAPE = 0.0F;
    
    private static final float DEFAULT_HORIZONTAL_MARGIN_PORTRAIT = 0.0F;
    
    private static final float DEFAULT_VERTICAL_MARGIN_LANDSCAPE = 0.0F;
    
    private static final float DEFAULT_VERTICAL_MARGIN_PORTRAIT = 0.0F;
    
    private long duration = 1500L;
    
    private long fadeInDuration = 500L;
    
    private long fadeOutDuration = 1000L;
    
    private int hideAnimationResource = 17432577;
    
    private float horizontalMarginLandscape = 0.0F;
    
    private float horizontalMarginPortrait = 0.0F;
    
    private boolean isFireTV = false;
    
    private PopUpLocation popUpLocation = PopUpLocation.DEFAULT_POPUP_LOCATION;
    
    private int showAnimationResource = 17432576;
    
    private float verticalMarginLandscape = 0.0F;
    
    private float verticalMarginPortrait = 0.0F;
    
    public ToastParams() {
      boolean bool1 = bool2;
      if (Build.MODEL.matches("AFT.*")) {
        bool1 = bool2;
        if (Build.MANUFACTURER.equals("Amazon"))
          bool1 = true; 
      } 
      this.isFireTV = bool1;
    }
    
    public long getDuration() {
      return this.duration;
    }
    
    public long getFadeInDuration() {
      return this.fadeInDuration;
    }
    
    public long getFadeOutDuration() {
      return this.fadeOutDuration;
    }
    
    public int getHideAnimationResource() {
      return this.hideAnimationResource;
    }
    
    public float getHorizontalMarginLandscape() {
      return this.horizontalMarginLandscape;
    }
    
    public float getHorizontalMarginPortrait() {
      return this.horizontalMarginPortrait;
    }
    
    public boolean getIsFireTV() {
      return this.isFireTV;
    }
    
    public PopUpLocation getPopUpLocation() {
      return this.popUpLocation;
    }
    
    public int getShowAnimationResource() {
      return this.showAnimationResource;
    }
    
    public float getVerticalMarginLandscape() {
      return this.verticalMarginLandscape;
    }
    
    public float getVerticalMarginPortrait() {
      return this.verticalMarginPortrait;
    }
    
    public void setDuration(long param1Long) {
      this.duration = param1Long;
    }
    
    public void setFadeInDuration(long param1Long) {
      this.fadeInDuration = param1Long;
    }
    
    public void setFadeOutDuration(long param1Long) {
      this.fadeOutDuration = param1Long;
    }
    
    public void setHideAnimationResource(int param1Int) {
      this.hideAnimationResource = param1Int;
    }
    
    public void setHorizontalMarginLandscape(float param1Float) {
      this.horizontalMarginLandscape = param1Float;
    }
    
    public void setHorizontalMarginPortrait(float param1Float) {
      this.horizontalMarginPortrait = param1Float;
    }
    
    public void setPopUpLocation(PopUpLocation param1PopUpLocation) {
      this.popUpLocation = param1PopUpLocation;
    }
    
    public void setShowAnimationResource(int param1Int) {
      this.showAnimationResource = param1Int;
    }
    
    public void setVerticalMarginLandscape(float param1Float) {
      this.verticalMarginLandscape = param1Float;
    }
    
    public void setVerticalMarginPortrait(float param1Float) {
      this.verticalMarginPortrait = param1Float;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\toasts\ClickableToastImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */