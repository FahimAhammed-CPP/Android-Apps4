package com.amazon.ags.html5.overlay.toasts;

import android.app.Activity;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import com.amazon.ags.api.overlay.PopUpLocation;
import com.amazon.ags.client.JSONRequest;
import com.amazon.ags.html5.factory.AGSClientInstanceCoordinator;
import com.amazon.ags.html5.factory.AGSClientInstanceCoordinatorListener;
import com.amazon.ags.html5.javascript.JavascriptRepository;
import com.amazon.ags.html5.overlay.PopUpPrefs;
import com.amazon.ags.html5.service.ServiceHelper;
import com.amazon.ags.html5.util.LocalizationUtil;
import com.amazon.ags.html5.util.WebViewFactory;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ClickableToastFactoryImpl implements ClickableToastFactory, AGSClientInstanceCoordinatorListener {
  private static final String TAG = "GC_" + ClickableToastFactoryImpl.class.getSimpleName();
  
  private static final float TOAST_HORIZONTAL_MARGIN = 0.025F;
  
  private static final float TOAST_VERTICAL_MARGIN = 0.03F;
  
  private volatile Activity activity = AGSClientInstanceCoordinator.getInstance().getCurrentActivity();
  
  private final JavascriptRepository jsRepository;
  
  private LocalizationUtil localizationUtil;
  
  private ServiceHelper serviceHelper = null;
  
  private ClickableWebViewToast toast;
  
  private final Handler uiPoster;
  
  private final WebViewFactory webViewFactory;
  
  public ClickableToastFactoryImpl(Handler paramHandler, WebViewFactory paramWebViewFactory, JavascriptRepository paramJavascriptRepository, LocalizationUtil paramLocalizationUtil) {
    AGSClientInstanceCoordinator.getInstance().addAGSClientInstanceCoordinatorListener(this);
    this.uiPoster = paramHandler;
    this.webViewFactory = paramWebViewFactory;
    this.jsRepository = paramJavascriptRepository;
    this.localizationUtil = paramLocalizationUtil;
    this.toast = new ClickableWebViewToast(this.activity, paramHandler, getToastParams(PopUpPrefs.INSTANCE.getLocation()), paramWebViewFactory, paramJavascriptRepository, this.serviceHelper, paramLocalizationUtil);
  }
  
  private ClickableToastImpl.ToastParams getToastParams(PopUpLocation paramPopUpLocation) {
    ClickableToastImpl.ToastParams toastParams = new ClickableToastImpl.ToastParams();
    toastParams.setPopUpLocation(paramPopUpLocation);
    toastParams.setVerticalMarginLandscape(0.03F);
    toastParams.setVerticalMarginPortrait(0.03F);
    if (paramPopUpLocation != PopUpLocation.BOTTOM_CENTER && paramPopUpLocation != PopUpLocation.TOP_CENTER) {
      toastParams.setHorizontalMarginLandscape(0.025F);
      toastParams.setHorizontalMarginPortrait(0.025F);
      return toastParams;
    } 
    toastParams.setHorizontalMarginLandscape(0.0F);
    toastParams.setHorizontalMarginPortrait(0.0F);
    return toastParams;
  }
  
  private void refreshActivity() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield activity : Landroid/app/Activity;
    //   6: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   9: invokevirtual getCurrentActivity : ()Landroid/app/Activity;
    //   12: if_acmpeq -> 70
    //   15: aload_0
    //   16: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   19: invokevirtual getCurrentActivity : ()Landroid/app/Activity;
    //   22: putfield activity : Landroid/app/Activity;
    //   25: aload_0
    //   26: new com/amazon/ags/html5/overlay/toasts/ClickableWebViewToast
    //   29: dup
    //   30: aload_0
    //   31: getfield activity : Landroid/app/Activity;
    //   34: aload_0
    //   35: getfield uiPoster : Landroid/os/Handler;
    //   38: aload_0
    //   39: getstatic com/amazon/ags/html5/overlay/PopUpPrefs.INSTANCE : Lcom/amazon/ags/html5/overlay/PopUpPrefs;
    //   42: invokevirtual getLocation : ()Lcom/amazon/ags/api/overlay/PopUpLocation;
    //   45: invokespecial getToastParams : (Lcom/amazon/ags/api/overlay/PopUpLocation;)Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl$ToastParams;
    //   48: aload_0
    //   49: getfield webViewFactory : Lcom/amazon/ags/html5/util/WebViewFactory;
    //   52: aload_0
    //   53: getfield jsRepository : Lcom/amazon/ags/html5/javascript/JavascriptRepository;
    //   56: aload_0
    //   57: getfield serviceHelper : Lcom/amazon/ags/html5/service/ServiceHelper;
    //   60: aload_0
    //   61: getfield localizationUtil : Lcom/amazon/ags/html5/util/LocalizationUtil;
    //   64: invokespecial <init> : (Landroid/app/Activity;Landroid/os/Handler;Lcom/amazon/ags/html5/overlay/toasts/ClickableToastImpl$ToastParams;Lcom/amazon/ags/html5/util/WebViewFactory;Lcom/amazon/ags/html5/javascript/JavascriptRepository;Lcom/amazon/ags/html5/service/ServiceHelper;Lcom/amazon/ags/html5/util/LocalizationUtil;)V
    //   67: putfield toast : Lcom/amazon/ags/html5/overlay/toasts/ClickableWebViewToast;
    //   70: aload_0
    //   71: monitorexit
    //   72: return
    //   73: astore_1
    //   74: aload_0
    //   75: monitorexit
    //   76: aload_1
    //   77: athrow
    // Exception table:
    //   from	to	target	type
    //   2	70	73	finally
  }
  
  public void dismissCurrentToast() {
    if (this.toast != null)
      this.toast.dismiss(); 
  }
  
  public ClickableToast getClickableWebViewToast(final String jsonData) {
    this.toast.setToastData(jsonData);
    this.toast.setToastOnTouchListener(new View.OnTouchListener() {
          boolean touched = false;
          
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            if (!this.touched) {
              this.touched = true;
              ClickableToastFactoryImpl.this.toast.destroy();
              try {
                final JSONArray actions = (new JSONObject(jsonData)).getJSONArray("ACTION_MAPPINGS");
                if (jSONArray != null && jSONArray.length() > 0 && ClickableToastFactoryImpl.this.serviceHelper != null) {
                  final JSONObject touchedToastData = new JSONObject();
                  jSONObject.put("TOAST_TOUCH_X", (int)param1MotionEvent.getX());
                  jSONObject.put("TOAST_TOUCH_Y", (int)param1MotionEvent.getY());
                  jSONObject.put("TOAST_WIDTH", param1View.getWidth());
                  jSONObject.put("TOAST_HEIGHT", param1View.getHeight());
                  JSONRequest jSONRequest = new JSONRequest() {
                      public JSONObject getRequest() {
                        JSONObject jSONObject = new JSONObject();
                        try {
                          jSONObject.put("ACTION_CODE", "HANDLE_TOAST_CLICK");
                          jSONObject.put("REQUEST_ID", UUID.randomUUID().toString());
                          jSONObject.put("ACTION_MAPPINGS", actions);
                          jSONObject.put("TOAST_CLICK_DATA", touchedToastData);
                          return jSONObject;
                        } catch (JSONException jSONException) {
                          Log.e(ClickableToastFactoryImpl.TAG, "Error building toast click request", (Throwable)jSONException);
                          return jSONObject;
                        } 
                      }
                      
                      public void setResponse(JSONObject param2JSONObject) {}
                    };
                  ClickableToastFactoryImpl.this.serviceHelper.handleRequestAsync(jSONRequest);
                } 
                return true;
              } catch (JSONException jSONException) {
                Log.e(ClickableToastFactoryImpl.TAG, "Error carrying out toast touch event due to JSON error", (Throwable)jSONException);
                return true;
              } catch (Exception exception) {
                Log.e(ClickableToastFactoryImpl.TAG, "Unexpected error carrying out toast touch event", exception);
                return true;
              } 
            } 
            return true;
          }
        });
    this.toast.setClickable(true);
    return this.toast;
  }
  
  public void notifyCurrentActivityChanged(Activity paramActivity) {
    refreshActivity();
  }
  
  public void setServiceHelper(ServiceHelper paramServiceHelper) {
    this.serviceHelper = paramServiceHelper;
    if (this.toast != null)
      this.toast.setServiceHelper(paramServiceHelper); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\toasts\ClickableToastFactoryImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */