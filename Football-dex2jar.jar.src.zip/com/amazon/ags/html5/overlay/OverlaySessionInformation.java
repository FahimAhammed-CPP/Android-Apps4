package com.amazon.ags.html5.overlay;

import com.amazon.ags.html5.util.DeviceInfo;
import com.amazon.ags.html5.util.LocalizationUtil;

public class OverlaySessionInformation {
  final String applicationName;
  
  final String clientVersion;
  
  final String contentVersion;
  
  final DeviceInfo deviceInfo;
  
  final String gameCircleVersion;
  
  final LocalizationUtil localizationUtil;
  
  public OverlaySessionInformation(String paramString1, String paramString2, String paramString3, String paramString4, LocalizationUtil paramLocalizationUtil, DeviceInfo paramDeviceInfo) {
    this.gameCircleVersion = paramString1;
    this.clientVersion = paramString2;
    this.contentVersion = paramString3;
    this.applicationName = paramString4;
    this.localizationUtil = paramLocalizationUtil;
    this.deviceInfo = paramDeviceInfo;
  }
  
  public String getApplicationName() {
    return this.applicationName;
  }
  
  public String getClientVersion() {
    return this.clientVersion;
  }
  
  public String getContentVersion() {
    return this.contentVersion;
  }
  
  public DeviceInfo getDeviceInfo() {
    return this.deviceInfo;
  }
  
  public String getGameCircleVersion() {
    return this.gameCircleVersion;
  }
  
  public LocalizationUtil getLocalizationUtil() {
    return this.localizationUtil;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\OverlaySessionInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */