package com.amazon.ags.html5.overlay;

import android.app.Activity;
import android.graphics.Point;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.amazon.ags.html5.factory.ServiceFactory;
import com.amazon.ags.html5.javascript.JavascriptRepository;
import com.amazon.ags.html5.javascript.domain.CloseOverlayListener;
import com.amazon.ags.html5.javascript.domain.JavascriptInterface;
import com.amazon.ags.html5.javascript.domain.MessageHandlerReadyListener;
import com.amazon.ags.html5.util.JSONUtils;
import com.amazon.ags.html5.util.ResourceUtils;
import org.json.JSONObject;

public class GameCircleUserInterface extends Activity implements CloseOverlayListener {
  private static final String TAG = "GC_" + GameCircleUserInterface.class.getSimpleName();
  
  private int getStatusBarHeight() {
    int i = 0;
    int j = getResources().getIdentifier("status_bar_height", "dimen", "android");
    if (j > 0)
      i = getResources().getDimensionPixelSize(j); 
    return i;
  }
  
  private void setViewWithSize(View paramView) {
    int i = getStatusBarHeight();
    Display display = ((WindowManager)getSystemService("window")).getDefaultDisplay();
    Point point = new Point(display.getWidth(), display.getHeight());
    int j = (getResources().getConfiguration()).screenLayout & 0xF;
    if (j == 3 || j == 4) {
      float f1;
      float f2;
      if (point.x > point.y) {
        f2 = 0.5F;
        f1 = 0.8F;
      } else {
        f2 = 0.8F;
        f1 = 0.7F;
      } 
      setContentView(ResourceUtils.getLayoutId(getBaseContext(), "modal_overlay_container"));
      ((LinearLayout)findViewById(ResourceUtils.getIdentifier(getBaseContext(), "id", "modal_overlay_container"))).addView(paramView);
      point.set((int)(point.x * f2), (int)(point.y * f1));
    } else {
      RelativeLayout relativeLayout = new RelativeLayout(getBaseContext());
      RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-1, -1);
      layoutParams1.addRule(12, 1);
      relativeLayout.addView(paramView, (ViewGroup.LayoutParams)layoutParams1);
      setContentView((View)relativeLayout);
      point.set(point.x, point.y - i);
      (relativeLayout.getLayoutParams()).width = point.x;
    } 
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    AnimationDrawable animationDrawable = (AnimationDrawable)getResources().getDrawable(ResourceUtils.getDrawableId(getBaseContext(), "gc_overlay_spinner"));
    InsetDrawable insetDrawable = new InsetDrawable((Drawable)animationDrawable, (point.x - 32) / 2, (point.y - 32) / 2, (point.x - 32) / 2, (point.y - 32) / 2);
    paramView.setBackgroundColor(0);
    paramView.setBackgroundDrawable((Drawable)insetDrawable);
    animationDrawable.start();
    layoutParams.width = point.x;
    layoutParams.height = point.y;
    Log.d(TAG, "View size set to width: " + layoutParams.width + " height: " + layoutParams.height);
  }
  
  public void closeOverlay() {
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    try {
      final ServiceFactory serviceFactory = ServiceFactory.getInstance();
      final WebView webView = serviceFactory.getWebViewFactory().newOverlayWebView(this);
      webView.getSettings().setLoadWithOverviewMode(true);
      webView.getSettings().setUseWideViewPort(true);
      webView.getSettings().setSupportZoom(false);
      webView.getSettings().setBuiltInZoomControls(false);
      JavascriptInterface javascriptInterface = serviceFactory.getJavascriptInterface(webView, "overlaywebview");
      javascriptInterface.addCloseOverlayListener(this);
      webView.addJavascriptInterface(javascriptInterface, "hostinterface");
      JavascriptRepository javascriptRepository = serviceFactory.getJavascriptRepository();
      javascriptInterface.addMessageHandlerReadyListener(new MessageHandlerReadyListener() {
            public void messageHandlerReady() {
              String str2 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_DATA_BUNDLE");
              final String overlayInputData = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_GAMECIRCLE_VERSION_KEY");
              String str3 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_CLIENT_VERSION");
              String str4 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_CONTENT_VERSION");
              String str5 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_APPLICATION_NAME");
              String str6 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_LANGUAGE_CODE");
              String str7 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_COUNTRY_CODE");
              String str8 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_DEVICE_IDENTIFIER");
              String str9 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_DEVICE_MANUFACTURER");
              String str10 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_DEVICE_MODEL");
              String str11 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_DEVICE_TYPE");
              String str12 = GameCircleUserInterface.this.getIntent().getExtras().getString("OVERLAY_SESSION_VARIATION_CACHE");
              str2 = JSONUtils.sanitize(str2);
              try {
                JSONObject jSONObject = new JSONObject(str2);
                jSONObject.put("gameCircleVersion", str1);
                jSONObject.put("clientVersion", str3);
                jSONObject.put("contentVersion", str4);
                jSONObject.put("appName", str5);
                jSONObject.put("languageCode", str6);
                jSONObject.put("countryCode", str7);
                jSONObject.put("deviceId", str8);
                jSONObject.put("deviceManufacturer", str9);
                jSONObject.put("deviceModel", str10);
                jSONObject.put("deviceType", str11);
                jSONObject.put("canSendMail", true);
                jSONObject.put("experiments", new JSONObject(str12));
                str1 = str2;
                if (jSONObject != null)
                  str1 = jSONObject.toString(); 
                try {
                  serviceFactory.getUiThreadHandler().post(new Runnable() {
                        public void run() {
                          try {
                            webView.loadUrl("javascript:handleOverlayData(" + overlayInputData + ");");
                            return;
                          } catch (Exception exception) {
                            Log.w(GameCircleUserInterface.TAG, "Unexpected error occurred while loading data into overlay.  Overlay will close.", exception);
                            GameCircleUserInterface.this.finish();
                            return;
                          } 
                        }
                      });
                  return;
                } catch (Exception exception) {
                  Log.w(GameCircleUserInterface.TAG, "Unexpected error occurred while processing overlay message.  Overlay will close.", exception);
                  GameCircleUserInterface.this.finish();
                } 
              } catch (Exception exception) {
                Log.e(GameCircleUserInterface.TAG, "Error occurred while adding client version to overlay initialization", exception);
                final String overlayInputData = str2;
                try {
                  serviceFactory.getUiThreadHandler().post(new Runnable() {
                        public void run() {
                          try {
                            webView.loadUrl("javascript:handleOverlayData(" + overlayInputData + ");");
                            return;
                          } catch (Exception exception) {
                            Log.w(GameCircleUserInterface.TAG, "Unexpected error occurred while loading data into overlay.  Overlay will close.", exception);
                            GameCircleUserInterface.this.finish();
                            return;
                          } 
                        }
                      });
                  return;
                } catch (Exception exception1) {
                  Log.w(GameCircleUserInterface.TAG, "Unexpected error occurred while processing overlay message.  Overlay will close.", exception1);
                  GameCircleUserInterface.this.finish();
                } 
              } 
            }
          });
      javascriptRepository.loadOverlayJavascript(webView);
      setViewWithSize((View)webView);
      return;
    } catch (Exception exception) {
      Log.w(TAG, "Unexpected error occurred while displaying overlay.  Overlay will close.", exception);
      finish();
      return;
    } catch (IllegalAccessError illegalAccessError) {
      Log.w(TAG, "ServiceFactory isn't ready.  Overlay will close.", illegalAccessError);
      finish();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\GameCircleUserInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */