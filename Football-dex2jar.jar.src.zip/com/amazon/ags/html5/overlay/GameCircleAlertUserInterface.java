package com.amazon.ags.html5.overlay;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.LinearLayout;
import com.amazon.ags.html5.factory.ServiceFactory;
import com.amazon.ags.html5.javascript.JavascriptRepository;
import com.amazon.ags.html5.javascript.domain.CloseAlertListener;
import com.amazon.ags.html5.javascript.domain.JavascriptInterface;
import com.amazon.ags.html5.javascript.domain.MessageHandlerReadyListener;
import com.amazon.ags.html5.util.JSONUtils;
import com.amazon.ags.html5.util.ResourceUtils;
import org.json.JSONObject;

public class GameCircleAlertUserInterface extends Activity implements CloseAlertListener {
  private static final String TAG = "GC_" + GameCircleAlertUserInterface.class.getSimpleName();
  
  public void closeAlert() {
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    final WebView webView;
    super.onCreate(paramBundle);
    String str13 = getIntent().getExtras().getString("OVERLAY_DATA_BUNDLE");
    final String processedOverlayData = getIntent().getExtras().getString("OVERLAY_SESSION_GAMECIRCLE_VERSION_KEY");
    String str3 = getIntent().getExtras().getString("OVERLAY_SESSION_CLIENT_VERSION");
    String str4 = getIntent().getExtras().getString("OVERLAY_SESSION_CONTENT_VERSION");
    String str5 = getIntent().getExtras().getString("OVERLAY_SESSION_APPLICATION_NAME");
    String str6 = getIntent().getExtras().getString("OVERLAY_SESSION_LANGUAGE_CODE");
    String str7 = getIntent().getExtras().getString("OVERLAY_SESSION_COUNTRY_CODE");
    String str8 = getIntent().getExtras().getString("OVERLAY_SESSION_DEVICE_IDENTIFIER");
    String str9 = getIntent().getExtras().getString("OVERLAY_SESSION_DEVICE_MANUFACTURER");
    String str10 = getIntent().getExtras().getString("OVERLAY_SESSION_DEVICE_MODEL");
    String str11 = getIntent().getExtras().getString("OVERLAY_SESSION_DEVICE_TYPE");
    String str12 = getIntent().getExtras().getString("OVERLAY_SESSION_VARIATION_CACHE");
    String str2 = JSONUtils.sanitize(str13);
    try {
      JSONObject jSONObject = new JSONObject(str13);
      jSONObject.put("gameCircleVersion", str1);
      jSONObject.put("clientVersion", str3);
      jSONObject.put("contentVersion", str4);
      jSONObject.put("appName", str5);
      jSONObject.put("languageCode", str6);
      jSONObject.put("countryCode", str7);
      jSONObject.put("deviceId", str8);
      jSONObject.put("deviceManufacturer", str9);
      jSONObject.put("deviceModel", str10);
      jSONObject.put("deviceType", str11);
      jSONObject.put("canSendMail", true);
      jSONObject.put("experiments", new JSONObject(str12));
      str1 = str2;
      if (jSONObject != null)
        str1 = jSONObject.toString(); 
      try {
        final ServiceFactory serviceFactory = ServiceFactory.getInstance();
        webView = serviceFactory.getWebViewFactory().newOverlayWebView(this);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setBuiltInZoomControls(false);
        JavascriptInterface javascriptInterface = serviceFactory.getJavascriptInterface(webView, "overlaywebview");
        javascriptInterface.addCloseAlertListener(this);
        JavascriptRepository javascriptRepository = serviceFactory.getJavascriptRepository();
        javascriptInterface.addMessageHandlerReadyListener(new MessageHandlerReadyListener() {
              public void messageHandlerReady() {
                final String overlayInputData = processedOverlayData;
                try {
                  serviceFactory.getUiThreadHandler().post(new Runnable() {
                        public void run() {
                          try {
                            webView.loadUrl("javascript:handleOverlayData(" + overlayInputData + ");");
                            return;
                          } catch (Exception exception) {
                            Log.w(GameCircleAlertUserInterface.TAG, "Unexpected error occurred while loading data into alert.  Alert will close.", exception);
                            GameCircleAlertUserInterface.this.finish();
                            return;
                          } 
                        }
                      });
                  return;
                } catch (Exception exception) {
                  Log.w(GameCircleAlertUserInterface.TAG, "Unexpected error occurred while processing alert message.  Alert will close.", exception);
                  GameCircleAlertUserInterface.this.finish();
                  return;
                } 
              }
            });
        javascriptRepository.loadAlertJavascript(webView);
        setContentView(ResourceUtils.getLayoutId(getBaseContext(), "modal_alert_container"));
        LinearLayout linearLayout = (LinearLayout)findViewById(ResourceUtils.getIdentifier(getBaseContext(), "id", "modal_alert_container"));
        webView.setBackgroundColor(0);
        linearLayout.addView((View)webView);
        Display display = ((WindowManager)getSystemService("window")).getDefaultDisplay();
        ViewGroup.LayoutParams layoutParams = webView.getLayoutParams();
        layoutParams.width = display.getWidth();
        layoutParams.height = display.getHeight();
        webView.addJavascriptInterface(javascriptInterface, "hostinterface");
        return;
      } catch (Exception exception) {
        Log.w(TAG, "Unexpected error occurred while displaying alert.  Alert will close.", exception);
        finish();
      } 
    } catch (Exception exception) {
      Log.e(TAG, "Error occurred while preparing alert initialization data", exception);
      final WebView processedOverlayData = webView;
      try {
        final ServiceFactory serviceFactory = ServiceFactory.getInstance();
        webView = serviceFactory.getWebViewFactory().newOverlayWebView(this);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setBuiltInZoomControls(false);
        JavascriptInterface javascriptInterface = serviceFactory.getJavascriptInterface(webView, "overlaywebview");
        javascriptInterface.addCloseAlertListener(this);
        JavascriptRepository javascriptRepository = serviceFactory.getJavascriptRepository();
        javascriptInterface.addMessageHandlerReadyListener(new MessageHandlerReadyListener() {
              public void messageHandlerReady() {
                final String overlayInputData = processedOverlayData;
                try {
                  serviceFactory.getUiThreadHandler().post(new Runnable() {
                        public void run() {
                          try {
                            webView.loadUrl("javascript:handleOverlayData(" + overlayInputData + ");");
                            return;
                          } catch (Exception exception) {
                            Log.w(GameCircleAlertUserInterface.TAG, "Unexpected error occurred while loading data into alert.  Alert will close.", exception);
                            GameCircleAlertUserInterface.this.finish();
                            return;
                          } 
                        }
                      });
                  return;
                } catch (Exception exception) {
                  Log.w(GameCircleAlertUserInterface.TAG, "Unexpected error occurred while processing alert message.  Alert will close.", exception);
                  GameCircleAlertUserInterface.this.finish();
                  return;
                } 
              }
            });
        javascriptRepository.loadAlertJavascript(webView);
        setContentView(ResourceUtils.getLayoutId(getBaseContext(), "modal_alert_container"));
        LinearLayout linearLayout = (LinearLayout)findViewById(ResourceUtils.getIdentifier(getBaseContext(), "id", "modal_alert_container"));
        webView.setBackgroundColor(0);
        linearLayout.addView((View)webView);
        Display display = ((WindowManager)getSystemService("window")).getDefaultDisplay();
        ViewGroup.LayoutParams layoutParams = webView.getLayoutParams();
        layoutParams.width = display.getWidth();
        layoutParams.height = display.getHeight();
        webView.addJavascriptInterface(javascriptInterface, "hostinterface");
        return;
      } catch (Exception exception1) {
        Log.w(TAG, "Unexpected error occurred while displaying alert.  Alert will close.", exception1);
        finish();
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\GameCircleAlertUserInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */