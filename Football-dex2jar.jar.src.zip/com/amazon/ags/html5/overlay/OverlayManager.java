package com.amazon.ags.html5.overlay;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import com.amazon.ags.client.KindleFireProxy;
import com.amazon.ags.html5.content.GCVariationManager;
import com.amazon.ags.html5.factory.AGSClientInstanceCoordinator;
import com.amazon.ags.html5.factory.AGSClientInstanceCoordinatorListener;
import com.amazon.ags.html5.overlay.toasts.ClickableToast;
import com.amazon.ags.html5.overlay.toasts.ClickableToastFactory;
import com.amazon.ags.html5.overlay.toasts.ClickableToastObserver;
import com.amazon.ags.html5.util.DeviceInfo;
import com.amazon.ags.html5.util.ImageManager;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import org.json.JSONObject;

public class OverlayManager implements ClickableToastObserver, AGSClientInstanceCoordinatorListener {
  private static final long COMMON_LEADERBOARD_MINIMUM_WAIT = 10000L;
  
  private static final String TAG = "GC_" + OverlayManager.class.getSimpleName();
  
  private InGameToastWrapper activeToast;
  
  private Activity activity;
  
  private final Context context;
  
  private final GCVariationManager gcVariationManager;
  
  private final ImageManager imageManager;
  
  private final KindleFireProxy kindleFireProxy;
  
  private final Map<String, Long> leaderboardLastTimeShownMap;
  
  private final OverlaySessionInformation overlaySessionInformation;
  
  private final Queue<String> pendingToasts;
  
  private final ClickableToastFactory toastFactory;
  
  private final Handler uiThreadHandler;
  
  public OverlayManager(Context paramContext, Handler paramHandler, ClickableToastFactory paramClickableToastFactory, KindleFireProxy paramKindleFireProxy, OverlaySessionInformation paramOverlaySessionInformation, GCVariationManager paramGCVariationManager, ImageManager paramImageManager) {
    AGSClientInstanceCoordinator.getInstance().addAGSClientInstanceCoordinatorListener(this);
    this.activity = AGSClientInstanceCoordinator.getInstance().getCurrentActivity();
    this.overlaySessionInformation = paramOverlaySessionInformation;
    this.context = paramContext;
    this.uiThreadHandler = paramHandler;
    this.toastFactory = paramClickableToastFactory;
    this.activeToast = null;
    this.kindleFireProxy = paramKindleFireProxy;
    this.gcVariationManager = paramGCVariationManager;
    this.imageManager = paramImageManager;
    this.pendingToasts = new LinkedList<String>();
    this.leaderboardLastTimeShownMap = new HashMap<String, Long>();
  }
  
  private JSONObject getVariationCacheJson() {
    JSONObject jSONObject = new JSONObject();
    Map map = this.gcVariationManager.getCachedVariations();
    try {
      for (Map.Entry entry : map.entrySet())
        jSONObject.put((String)entry.getKey(), entry.getValue()); 
    } catch (Exception exception) {
      Log.w(TAG, "Error occurred while preparing variation cache for overlay", exception);
    } 
    return jSONObject;
  }
  
  private void processNextToast() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield pendingToasts : Ljava/util/Queue;
    //   6: invokeinterface peek : ()Ljava/lang/Object;
    //   11: checkcast java/lang/String
    //   14: astore #4
    //   16: aload #4
    //   18: ifnull -> 291
    //   21: new org/json/JSONObject
    //   24: dup
    //   25: aload #4
    //   27: invokespecial <init> : (Ljava/lang/String;)V
    //   30: astore #5
    //   32: aload #5
    //   34: ldc 'canBeDisabled'
    //   36: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   39: astore #6
    //   41: getstatic com/amazon/ags/html5/overlay/PopUpPrefs.INSTANCE : Lcom/amazon/ags/html5/overlay/PopUpPrefs;
    //   44: invokevirtual isEnabled : ()Z
    //   47: ifne -> 69
    //   50: getstatic com/amazon/ags/html5/overlay/PopUpPrefs.INSTANCE : Lcom/amazon/ags/html5/overlay/PopUpPrefs;
    //   53: invokevirtual isEnabled : ()Z
    //   56: ifne -> 462
    //   59: ldc 'false'
    //   61: aload #6
    //   63: invokevirtual equals : (Ljava/lang/Object;)Z
    //   66: ifeq -> 462
    //   69: aload #5
    //   71: ldc 'type'
    //   73: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   76: astore #6
    //   78: aload #5
    //   80: ldc 'dedupeTypes'
    //   82: invokevirtual getJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   85: astore #7
    //   87: iconst_0
    //   88: istore_3
    //   89: iconst_0
    //   90: istore_2
    //   91: iload_3
    //   92: istore_1
    //   93: aload #6
    //   95: ldc 'Leaderboard'
    //   97: invokevirtual equals : (Ljava/lang/Object;)Z
    //   100: ifeq -> 185
    //   103: aload #5
    //   105: ldc 'leaderboardName'
    //   107: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   110: astore #8
    //   112: iload_3
    //   113: istore_1
    //   114: aload #8
    //   116: ifnull -> 185
    //   119: iload_2
    //   120: istore_1
    //   121: aload_0
    //   122: getfield leaderboardLastTimeShownMap : Ljava/util/Map;
    //   125: aload #8
    //   127: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   132: ifeq -> 167
    //   135: iload_2
    //   136: istore_1
    //   137: invokestatic currentTimeMillis : ()J
    //   140: aload_0
    //   141: getfield leaderboardLastTimeShownMap : Ljava/util/Map;
    //   144: aload #8
    //   146: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   151: checkcast java/lang/Long
    //   154: invokevirtual longValue : ()J
    //   157: lsub
    //   158: ldc2_w 10000
    //   161: lcmp
    //   162: ifge -> 167
    //   165: iconst_1
    //   166: istore_1
    //   167: aload_0
    //   168: getfield leaderboardLastTimeShownMap : Ljava/util/Map;
    //   171: aload #8
    //   173: invokestatic currentTimeMillis : ()J
    //   176: invokestatic valueOf : (J)Ljava/lang/Long;
    //   179: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   184: pop
    //   185: new java/util/HashSet
    //   188: dup
    //   189: aload #7
    //   191: invokevirtual length : ()I
    //   194: invokespecial <init> : (I)V
    //   197: astore #8
    //   199: iconst_0
    //   200: istore_2
    //   201: iload_2
    //   202: aload #7
    //   204: invokevirtual length : ()I
    //   207: if_icmpge -> 231
    //   210: aload #8
    //   212: aload #7
    //   214: iload_2
    //   215: invokevirtual getString : (I)Ljava/lang/String;
    //   218: invokeinterface add : (Ljava/lang/Object;)Z
    //   223: pop
    //   224: iload_2
    //   225: iconst_1
    //   226: iadd
    //   227: istore_2
    //   228: goto -> 201
    //   231: aload_0
    //   232: getfield activeToast : Lcom/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper;
    //   235: ifnull -> 294
    //   238: aload_0
    //   239: getfield activeToast : Lcom/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper;
    //   242: invokevirtual getToast : ()Lcom/amazon/ags/html5/overlay/toasts/ClickableToast;
    //   245: invokeinterface isShowing : ()Z
    //   250: ifeq -> 294
    //   253: aload_0
    //   254: getfield activeToast : Lcom/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper;
    //   257: aload #6
    //   259: invokevirtual isDedupeCompatibleWithType : (Ljava/lang/String;)Z
    //   262: ifeq -> 294
    //   265: iconst_1
    //   266: istore_2
    //   267: goto -> 477
    //   270: aload_0
    //   271: getfield pendingToasts : Ljava/util/Queue;
    //   274: aload #4
    //   276: invokeinterface remove : (Ljava/lang/Object;)Z
    //   281: pop
    //   282: aload_0
    //   283: getfield activeToast : Lcom/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper;
    //   286: aload #4
    //   288: invokevirtual aggregate : (Ljava/lang/String;)V
    //   291: aload_0
    //   292: monitorexit
    //   293: return
    //   294: iconst_0
    //   295: istore_2
    //   296: goto -> 477
    //   299: aload_0
    //   300: getfield activeToast : Lcom/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper;
    //   303: ifnull -> 321
    //   306: aload_0
    //   307: getfield activeToast : Lcom/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper;
    //   310: invokevirtual getToast : ()Lcom/amazon/ags/html5/overlay/toasts/ClickableToast;
    //   313: invokeinterface isShowing : ()Z
    //   318: ifeq -> 328
    //   321: aload_0
    //   322: getfield activeToast : Lcom/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper;
    //   325: ifnonnull -> 291
    //   328: aload_0
    //   329: getfield pendingToasts : Ljava/util/Queue;
    //   332: aload #4
    //   334: invokeinterface remove : (Ljava/lang/Object;)Z
    //   339: pop
    //   340: aload_0
    //   341: getfield toastFactory : Lcom/amazon/ags/html5/overlay/toasts/ClickableToastFactory;
    //   344: aload #4
    //   346: invokeinterface getClickableWebViewToast : (Ljava/lang/String;)Lcom/amazon/ags/html5/overlay/toasts/ClickableToast;
    //   351: astore #7
    //   353: aload #7
    //   355: aload_0
    //   356: invokeinterface addClickableToastObserver : (Lcom/amazon/ags/html5/overlay/toasts/ClickableToastObserver;)V
    //   361: aload_0
    //   362: new com/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper
    //   365: dup
    //   366: aload #6
    //   368: aload #8
    //   370: aload #7
    //   372: invokespecial <init> : (Ljava/lang/String;Ljava/util/Set;Lcom/amazon/ags/html5/overlay/toasts/ClickableToast;)V
    //   375: putfield activeToast : Lcom/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper;
    //   378: aload #5
    //   380: ldc_w 'icon'
    //   383: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   386: astore #5
    //   388: aload #5
    //   390: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   393: ifne -> 405
    //   396: aload_0
    //   397: getfield imageManager : Lcom/amazon/ags/html5/util/ImageManager;
    //   400: aload #5
    //   402: invokevirtual downloadImage : (Ljava/lang/String;)V
    //   405: aload_0
    //   406: getfield uiThreadHandler : Landroid/os/Handler;
    //   409: new com/amazon/ags/html5/overlay/OverlayManager$1
    //   412: dup
    //   413: aload_0
    //   414: aload #7
    //   416: invokespecial <init> : (Lcom/amazon/ags/html5/overlay/OverlayManager;Lcom/amazon/ags/html5/overlay/toasts/ClickableToast;)V
    //   419: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   422: pop
    //   423: goto -> 291
    //   426: astore #5
    //   428: aload_0
    //   429: getfield pendingToasts : Ljava/util/Queue;
    //   432: aload #4
    //   434: invokeinterface remove : (Ljava/lang/Object;)Z
    //   439: pop
    //   440: getstatic com/amazon/ags/html5/overlay/OverlayManager.TAG : Ljava/lang/String;
    //   443: ldc_w 'Unable to parse toast request'
    //   446: aload #5
    //   448: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   451: pop
    //   452: goto -> 291
    //   455: astore #4
    //   457: aload_0
    //   458: monitorexit
    //   459: aload #4
    //   461: athrow
    //   462: aload_0
    //   463: getfield pendingToasts : Ljava/util/Queue;
    //   466: aload #4
    //   468: invokeinterface remove : (Ljava/lang/Object;)Z
    //   473: pop
    //   474: goto -> 291
    //   477: iload_1
    //   478: ifne -> 270
    //   481: iload_2
    //   482: ifeq -> 299
    //   485: goto -> 270
    // Exception table:
    //   from	to	target	type
    //   2	16	455	finally
    //   21	69	426	java/lang/Exception
    //   21	69	455	finally
    //   69	87	426	java/lang/Exception
    //   69	87	455	finally
    //   93	112	426	java/lang/Exception
    //   93	112	455	finally
    //   121	135	426	java/lang/Exception
    //   121	135	455	finally
    //   137	165	426	java/lang/Exception
    //   137	165	455	finally
    //   167	185	426	java/lang/Exception
    //   167	185	455	finally
    //   185	199	426	java/lang/Exception
    //   185	199	455	finally
    //   201	224	426	java/lang/Exception
    //   201	224	455	finally
    //   231	265	426	java/lang/Exception
    //   231	265	455	finally
    //   270	291	426	java/lang/Exception
    //   270	291	455	finally
    //   299	321	426	java/lang/Exception
    //   299	321	455	finally
    //   321	328	426	java/lang/Exception
    //   321	328	455	finally
    //   328	405	426	java/lang/Exception
    //   328	405	455	finally
    //   405	423	426	java/lang/Exception
    //   405	423	455	finally
    //   428	452	455	finally
    //   462	474	426	java/lang/Exception
    //   462	474	455	finally
  }
  
  private void refreshActivity() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield activity : Landroid/app/Activity;
    //   6: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   9: invokevirtual getCurrentActivity : ()Landroid/app/Activity;
    //   12: if_acmpeq -> 30
    //   15: aload_0
    //   16: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   19: invokevirtual getCurrentActivity : ()Landroid/app/Activity;
    //   22: putfield activity : Landroid/app/Activity;
    //   25: aload_0
    //   26: aconst_null
    //   27: putfield activeToast : Lcom/amazon/ags/html5/overlay/OverlayManager$InGameToastWrapper;
    //   30: aload_0
    //   31: monitorexit
    //   32: return
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	33	finally
  }
  
  private void showHtmlAlert(String paramString) {
    Intent intent = new Intent();
    intent.setComponent(new ComponentName(this.context, GameCircleAlertUserInterface.class.getName()));
    intent.setFlags(335609856);
    intent.setAction(Long.toString(System.currentTimeMillis()));
    intent.putExtra("OVERLAY_DATA_BUNDLE", paramString);
    intent.putExtra("OVERLAY_SESSION_GAMECIRCLE_VERSION_KEY", this.overlaySessionInformation.getGameCircleVersion());
    intent.putExtra("OVERLAY_SESSION_CLIENT_VERSION", this.overlaySessionInformation.getClientVersion());
    intent.putExtra("OVERLAY_SESSION_CONTENT_VERSION", this.overlaySessionInformation.getContentVersion());
    intent.putExtra("OVERLAY_SESSION_APPLICATION_NAME", this.overlaySessionInformation.getApplicationName());
    intent.putExtra("OVERLAY_SESSION_LANGUAGE_CODE", this.overlaySessionInformation.getLocalizationUtil().getLanguageCode());
    intent.putExtra("OVERLAY_SESSION_COUNTRY_CODE", this.overlaySessionInformation.getLocalizationUtil().getCountryCode());
    intent.putExtra("OVERLAY_SESSION_DEVICE_IDENTIFIER", DeviceInfo.getIdentifier());
    intent.putExtra("OVERLAY_SESSION_DEVICE_MANUFACTURER", DeviceInfo.getManufacturer());
    intent.putExtra("OVERLAY_SESSION_DEVICE_MODEL", DeviceInfo.getModel());
    intent.putExtra("OVERLAY_SESSION_DEVICE_TYPE", this.overlaySessionInformation.getDeviceInfo().getDeviceType());
    intent.putExtra("OVERLAY_SESSION_VARIATION_CACHE", getVariationCacheJson().toString());
    this.context.startActivity(intent);
  }
  
  private void showHtmlOverlay(String paramString) {
    Intent intent = new Intent();
    intent.setComponent(new ComponentName(this.context, GameCircleUserInterface.class.getName()));
    intent.setFlags(335609856);
    intent.setAction(Long.toString(System.currentTimeMillis()));
    intent.putExtra("OVERLAY_DATA_BUNDLE", paramString);
    intent.putExtra("OVERLAY_SESSION_GAMECIRCLE_VERSION_KEY", this.overlaySessionInformation.getGameCircleVersion());
    intent.putExtra("OVERLAY_SESSION_CLIENT_VERSION", this.overlaySessionInformation.getClientVersion());
    intent.putExtra("OVERLAY_SESSION_CONTENT_VERSION", this.overlaySessionInformation.getContentVersion());
    intent.putExtra("OVERLAY_SESSION_APPLICATION_NAME", this.overlaySessionInformation.getApplicationName());
    intent.putExtra("OVERLAY_SESSION_LANGUAGE_CODE", this.overlaySessionInformation.getLocalizationUtil().getLanguageCode());
    intent.putExtra("OVERLAY_SESSION_COUNTRY_CODE", this.overlaySessionInformation.getLocalizationUtil().getCountryCode());
    intent.putExtra("OVERLAY_SESSION_DEVICE_IDENTIFIER", DeviceInfo.getIdentifier());
    intent.putExtra("OVERLAY_SESSION_DEVICE_MANUFACTURER", DeviceInfo.getManufacturer());
    intent.putExtra("OVERLAY_SESSION_DEVICE_MODEL", DeviceInfo.getModel());
    intent.putExtra("OVERLAY_SESSION_DEVICE_TYPE", this.overlaySessionInformation.getDeviceInfo().getDeviceType());
    intent.putExtra("OVERLAY_SESSION_VARIATION_CACHE", getVariationCacheJson().toString());
    this.context.startActivity(intent);
  }
  
  public void notifyCurrentActivityChanged(Activity paramActivity) {
    refreshActivity();
  }
  
  public void notifyToastDestroyed() {
    processNextToast();
  }
  
  public void showAlert(String paramString) {
    showHtmlAlert(paramString);
  }
  
  public void showOverlay(String paramString) {
    if (this.kindleFireProxy.isOverlaysSupported()) {
      this.kindleFireProxy.showOverlay(paramString);
      return;
    } 
    showHtmlOverlay(paramString);
  }
  
  public void showToast(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield pendingToasts : Ljava/util/Queue;
    //   6: aload_1
    //   7: invokeinterface add : (Ljava/lang/Object;)Z
    //   12: pop
    //   13: aload_0
    //   14: invokespecial processNextToast : ()V
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	20	finally
  }
  
  private static class InGameToastWrapper {
    private int aggregateCount;
    
    private final Set<String> dedupeTypes;
    
    private final ClickableToast toast;
    
    private final String type;
    
    public InGameToastWrapper(String param1String, Set<String> param1Set, ClickableToast param1ClickableToast) {
      if (param1String == null || param1Set == null || param1ClickableToast == null)
        throw new IllegalArgumentException("Cannot instantiate InGameToastWrapper with null arguments"); 
      if (TextUtils.isEmpty(param1String))
        throw new IllegalArgumentException("Cannot instantiate InGameToastWrapper with empty type"); 
      this.type = param1String;
      this.dedupeTypes = param1Set;
      this.toast = param1ClickableToast;
      this.aggregateCount = 0;
    }
    
    public void aggregate(String param1String) {
      this.aggregateCount++;
      this.toast.update(param1String, this.aggregateCount);
    }
    
    public ClickableToast getToast() {
      return this.toast;
    }
    
    public boolean isDedupeCompatibleWithType(String param1String) {
      if (TextUtils.isEmpty(param1String))
        throw new IllegalArgumentException("type argument must be non-empty"); 
      return this.dedupeTypes.contains(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\overlay\OverlayManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */