package com.amazon.ags.html5.javascript;

import android.webkit.WebView;

public interface JavascriptRepository {
  void loadAlertJavascript(WebView paramWebView);
  
  void loadBackgroundJavascript(WebView paramWebView);
  
  void loadOverlayJavascript(WebView paramWebView);
  
  void loadToastJavascript(WebView paramWebView);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\JavascriptRepository.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */