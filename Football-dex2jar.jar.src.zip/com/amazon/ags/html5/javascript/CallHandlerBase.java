package com.amazon.ags.html5.javascript;

import android.os.Handler;
import android.util.Log;
import com.amazon.ags.html5.javascript.domain.JavascriptInterface;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class CallHandlerBase {
  protected final String TAG = "GC_" + getClass().getSimpleName();
  
  private final Map<String, JavascriptInterface> replyMap;
  
  private final Set<String> supportedMessageTypes;
  
  private final Handler uiThreadHandler;
  
  public CallHandlerBase(Handler paramHandler, Set<String> paramSet) {
    this.uiThreadHandler = paramHandler;
    this.replyMap = Collections.synchronizedMap(new HashMap<String, JavascriptInterface>());
    this.supportedMessageTypes = paramSet;
  }
  
  public Set<String> getSupportedMessages() {
    return this.supportedMessageTypes;
  }
  
  public boolean handleMessage(JavascriptInterface paramJavascriptInterface, JSONObject paramJSONObject) {
    try {
      String str = paramJSONObject.getString("rid");
      try {
        String str1 = paramJSONObject.getString("nativeCall");
        this.replyMap.put(paramJavascriptInterface.getId() + "-" + str, paramJavascriptInterface);
        return handleMessage(paramJavascriptInterface.getId() + "-" + str, str1, paramJSONObject);
      } catch (JSONException jSONException) {
        Log.e(this.TAG, "Unable to get nativeCall from request " + paramJSONObject, (Throwable)jSONException);
        sendReply(str, "{}", "REQUEST_ERROR");
        return true;
      } 
    } catch (Exception exception) {
      Log.e(this.TAG, "Unable to handle request with no RID to report back to.", exception);
      return true;
    } 
  }
  
  protected abstract boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject);
  
  protected void sendReply(String paramString1, String paramString2, String paramString3) {
    sendReply(paramString1, paramString2, paramString3, null);
  }
  
  protected void sendReply(String paramString1, final String resultJson, final String resultCode, final String httpResponseCode) {
    final JavascriptInterface originalCaller = this.replyMap.remove(paramString1);
    if (javascriptInterface != null)
      try {
        final String originalRid = paramString1.split("-")[1];
        this.uiThreadHandler.post(new Runnable() {
              public void run() {
                originalCaller.sendJSReply(originalRid, resultJson, resultCode, httpResponseCode);
              }
            });
        return;
      } catch (Exception exception) {
        Log.e(this.TAG, "Unable to route reply back to caller for rid [" + paramString1 + "]", exception);
        return;
      }  
    Log.e(this.TAG, "No receiver for reply associated with rid: " + paramString1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\CallHandlerBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */