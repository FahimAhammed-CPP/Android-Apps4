package com.amazon.ags.html5.javascript;

import android.os.Handler;
import android.util.Log;
import com.amazon.ags.storage.OfflineDataCache;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class NativeSettingsCallHandler extends CallHandlerBase {
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "getSetting", "putSetting" }));
  
  private final OfflineDataCache settingsDataCache;
  
  public NativeSettingsCallHandler(Handler paramHandler, OfflineDataCache paramOfflineDataCache) {
    super(paramHandler, supportedCalls);
    this.settingsDataCache = paramOfflineDataCache;
  }
  
  private void getSetting(String paramString, JSONObject paramJSONObject) {
    try {
      String str = paramJSONObject.getJSONObject("parameters").getString("primaryKey");
      paramJSONObject = this.settingsDataCache.getCacheItem(str);
      if (paramJSONObject != null) {
        sendReply(paramString, paramJSONObject.toString(), "SUCCESS");
        return;
      } 
    } catch (JSONException jSONException) {
      Log.e(this.TAG, "Unable to get key from request " + paramJSONObject, (Throwable)jSONException);
      sendReply(paramString, "{}", "REQUEST_ERROR");
      return;
    } 
    sendReply(paramString, "{}", "ERROR");
  }
  
  private void putSetting(String paramString, JSONObject paramJSONObject) {
    try {
      JSONObject jSONObject = paramJSONObject.getJSONObject("parameters");
      String str1 = jSONObject.getString("primaryKey");
      String str2 = jSONObject.getString("secondaryKey");
      jSONObject = jSONObject.getJSONObject("value");
      this.settingsDataCache.setCacheItem(str1, str2, jSONObject);
      sendReply(paramString, "{}", "SUCCESS");
      return;
    } catch (JSONException jSONException) {
      Log.e(this.TAG, "Unable to get keys and value from request " + paramJSONObject, (Throwable)jSONException);
      sendReply(paramString, "{}", "REQUEST_ERROR");
      return;
    } 
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    if ("getSetting".equals(paramString2)) {
      getSetting(paramString1, paramJSONObject);
      return true;
    } 
    if ("putSetting".equals(paramString2)) {
      putSetting(paramString1, paramJSONObject);
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\NativeSettingsCallHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */