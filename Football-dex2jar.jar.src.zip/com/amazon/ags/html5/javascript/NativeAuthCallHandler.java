package com.amazon.ags.html5.javascript;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import com.amazon.ags.auth.AuthManager;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.authorization.api.AuthorizationListener;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class NativeAuthCallHandler extends CallHandlerBase {
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "getLoggedInStatus", "doLogin", "doLogout" }));
  
  private final AuthManager authManager;
  
  public NativeAuthCallHandler(Handler paramHandler, AuthManager paramAuthManager) {
    super(paramHandler, supportedCalls);
    this.authManager = paramAuthManager;
  }
  
  private void doLogin(final String rid) {
    this.authManager.tryLogin(new AuthorizationListener() {
          public void onCancel(Bundle param1Bundle) {
            NativeAuthCallHandler.this.sendReply(rid, "{}", "ERROR");
          }
          
          public void onError(AuthError param1AuthError) {
            NativeAuthCallHandler.this.sendReply(rid, "{}", "ERROR");
          }
          
          public void onSuccess(Bundle param1Bundle) {
            NativeAuthCallHandler.this.sendReply(rid, "{}", "SUCCESS");
          }
        });
  }
  
  private void doLogout(String paramString) {
    try {
      this.authManager.logout();
      sendReply(paramString, "{}", "SUCCESS");
      return;
    } catch (AuthError authError) {
      Log.e(this.TAG, "Failed to log out", (Throwable)authError);
      sendReply(paramString, "{}", "ERROR");
      return;
    } 
  }
  
  private void getLoggedInStatus(String paramString) {
    JSONObject jSONObject = new JSONObject();
    try {
      boolean bool = this.authManager.isLoggedIn();
      Log.d(this.TAG, "Logged in: " + bool);
      jSONObject.put("loggedInStatus", bool);
    } catch (JSONException jSONException) {
      Log.e(this.TAG, "Error building GET_LOGGED_IN_STATUS response", (Throwable)jSONException);
    } 
    sendReply(paramString, jSONObject.toString(), "SUCCESS");
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    if ("getLoggedInStatus".equals(paramString2)) {
      getLoggedInStatus(paramString1);
      return true;
    } 
    if ("doLogin".equals(paramString2)) {
      doLogin(paramString1);
      return true;
    } 
    if ("doLogout".equals(paramString2)) {
      doLogout(paramString1);
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\NativeAuthCallHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */