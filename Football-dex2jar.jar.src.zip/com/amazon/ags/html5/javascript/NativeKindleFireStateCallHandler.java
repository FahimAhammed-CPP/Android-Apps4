package com.amazon.ags.html5.javascript;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import com.amazon.ags.client.KindleFireProxy;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class NativeKindleFireStateCallHandler extends CallHandlerBase {
  private static final String GC_KINDLE_SETTINGS_ACTION = "com.amazon.ags.app.AMAZON_GAMES_SETTINGS";
  
  private static final String GC_PACKAGE_NAME = "com.amazon.ags.app";
  
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "isKindle", "isGCServiceReady", "isKindleRegistered", "hasOptedIn", "isWhispersyncEnabled", "setOptIn", "canDisplayKindleSettings", "launchKindleSettings" }));
  
  private final Context context;
  
  private final KindleFireProxy kindleFireProxy;
  
  public NativeKindleFireStateCallHandler(Context paramContext, Handler paramHandler, KindleFireProxy paramKindleFireProxy) {
    super(paramHandler, supportedCalls);
    this.kindleFireProxy = paramKindleFireProxy;
    this.context = paramContext;
  }
  
  private boolean checkKindleGameSettingsAvailability() {
    Intent intent = new Intent();
    intent.setAction("com.amazon.ags.app.AMAZON_GAMES_SETTINGS");
    intent.setPackage("com.amazon.ags.app");
    return (this.context.getPackageManager().queryIntentActivities(intent, 65536).size() > 0);
  }
  
  private void launchSettings() {
    Intent intent = new Intent();
    intent.setAction("com.amazon.ags.app.AMAZON_GAMES_SETTINGS");
    intent.setPackage("com.amazon.ags.app");
    intent.setFlags(268500992);
    this.context.startActivity(intent);
  }
  
  private String makeJsonReplyForSingleValue(Object paramObject) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("value", paramObject);
      return jSONObject.toString();
    } catch (JSONException jSONException) {
      Log.e(this.TAG, "Unable to make JSON relpy to Javascript for value [" + paramObject + "]", (Throwable)jSONException);
      return null;
    } 
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    String str1;
    Log.d(this.TAG, "Processing request [" + paramString1 + "] for call type [" + paramString2 + "]");
    String str2 = null;
    if (paramString2.equals("isKindle")) {
      str1 = makeJsonReplyForSingleValue(Boolean.valueOf(this.kindleFireProxy.isKindle()));
    } else if (paramString2.equals("isGCServiceReady")) {
      str1 = makeJsonReplyForSingleValue(Boolean.valueOf(this.kindleFireProxy.isReady()));
    } else if (paramString2.equals("isKindleRegistered")) {
      str1 = makeJsonReplyForSingleValue(Boolean.valueOf(this.kindleFireProxy.isRegistered()));
    } else if (paramString2.equals("hasOptedIn")) {
      str1 = makeJsonReplyForSingleValue(Boolean.valueOf(this.kindleFireProxy.isOptedIn()));
    } else if (paramString2.equals("isWhispersyncEnabled")) {
      str1 = makeJsonReplyForSingleValue(Boolean.valueOf(this.kindleFireProxy.isWhispersyncEnabled()));
    } else {
      if (paramString2.equals("setOptIn")) {
        try {
          boolean bool = str1.getJSONObject("parameters").getBoolean("hasOptedIn");
          this.kindleFireProxy.setOptIn(bool);
          str1 = (new JSONObject()).toString();
          Log.d(this.TAG, "Returning reply [" + str1 + "] for request [" + paramString1 + "]");
        } catch (JSONException jSONException) {
          Log.e(this.TAG, "Unable to get value for key [hasOptedIn]", (Throwable)jSONException);
          str1 = str2;
          Log.d(this.TAG, "Returning reply [" + str1 + "] for request [" + paramString1 + "]");
        } 
      } else {
        if (jSONException.equals("canDisplayKindleSettings")) {
          boolean bool1 = this.kindleFireProxy.isReady();
          boolean bool2 = this.kindleFireProxy.isRegistered();
          if (bool1 && bool2 && checkKindleGameSettingsAvailability()) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          str1 = makeJsonReplyForSingleValue(Boolean.valueOf(bool1));
        } else {
          str1 = str2;
          if (jSONException.equals("launchKindleSettings"))
            try {
              launchSettings();
              str1 = (new JSONObject()).toString();
            } catch (ActivityNotFoundException activityNotFoundException) {
              Log.e(this.TAG, "Settings were either launched without checking that they are available or an expected error occurred", (Throwable)activityNotFoundException);
              str1 = str2;
            }  
        } 
        Log.d(this.TAG, "Returning reply [" + str1 + "] for request [" + paramString1 + "]");
      } 
      return false;
    } 
    Log.d(this.TAG, "Returning reply [" + str1 + "] for request [" + paramString1 + "]");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\NativeKindleFireStateCallHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */