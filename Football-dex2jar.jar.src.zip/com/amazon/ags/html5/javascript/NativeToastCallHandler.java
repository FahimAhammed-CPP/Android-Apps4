package com.amazon.ags.html5.javascript;

import android.content.Context;
import android.os.Handler;
import com.amazon.ags.html5.overlay.OverlayManager;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONObject;

public class NativeToastCallHandler extends CallHandlerBase {
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "showToast" }));
  
  private final Context context;
  
  private final OverlayManager overlayManager;
  
  public NativeToastCallHandler(Context paramContext, Handler paramHandler, OverlayManager paramOverlayManager) {
    super(paramHandler, supportedCalls);
    this.context = paramContext;
    this.overlayManager = paramOverlayManager;
  }
  
  private void showToast(String paramString, JSONObject paramJSONObject) {
    this.overlayManager.showToast(paramJSONObject.toString());
    sendReply(paramString, "{}", "SUCCESS");
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    if ("showToast".equals(paramString2)) {
      showToast(paramString1, paramJSONObject);
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\NativeToastCallHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */