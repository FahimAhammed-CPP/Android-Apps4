package com.amazon.ags.html5.javascript;

import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.IllegalConstructionException;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.constants.NativeCallKeys;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class ReportEventHandler extends CallHandlerBase {
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "reportEvent" }));
  
  private final EventCollectorClient eventCollectorClient;
  
  public ReportEventHandler(EventCollectorClient paramEventCollectorClient, Handler paramHandler) {
    super(paramHandler, supportedCalls);
    this.eventCollectorClient = paramEventCollectorClient;
  }
  
  private Map<String, String> convertAttributes(JSONObject paramJSONObject) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramJSONObject == null) {
      Log.w(this.TAG, "Null attributes json.");
      return (Map)hashMap;
    } 
    Iterator<String> iterator = paramJSONObject.keys();
    while (true) {
      if (iterator.hasNext()) {
        String str = iterator.next();
        if (!paramJSONObject.isNull(str))
          try {
            hashMap.put(str, paramJSONObject.getString(str));
          } catch (JSONException jSONException) {
            Log.e(this.TAG, "Invalid value for key: " + str + " in json: " + paramJSONObject, (Throwable)jSONException);
          }  
        continue;
      } 
      return (Map)hashMap;
    } 
  }
  
  private Map<String, Integer> convertCounts(JSONObject paramJSONObject) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramJSONObject == null) {
      Log.w(this.TAG, "Null counts json.");
      return (Map)hashMap;
    } 
    Iterator<String> iterator = paramJSONObject.keys();
    while (true) {
      if (iterator.hasNext()) {
        String str = iterator.next();
        if (!paramJSONObject.isNull(str))
          try {
            hashMap.put(str, Integer.valueOf(paramJSONObject.getInt(str)));
          } catch (JSONException jSONException) {
            Log.e(this.TAG, "Invalid value for key: " + str + " in json: " + paramJSONObject, (Throwable)jSONException);
          }  
        continue;
      } 
      return (Map)hashMap;
    } 
  }
  
  private Map<String, Long> convertTimes(JSONObject paramJSONObject) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramJSONObject == null) {
      Log.w(this.TAG, "Null times json.");
      return (Map)hashMap;
    } 
    Iterator<String> iterator = paramJSONObject.keys();
    while (true) {
      if (iterator.hasNext()) {
        String str = iterator.next();
        if (!paramJSONObject.isNull(str))
          try {
            hashMap.put(str, Long.valueOf(paramJSONObject.getLong(str)));
          } catch (JSONException jSONException) {
            Log.e(this.TAG, "Invalid value for key: " + str + " in json: " + paramJSONObject, (Throwable)jSONException);
          }  
        continue;
      } 
      return (Map)hashMap;
    } 
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    if (!"reportEvent".equals(paramString2))
      return false; 
    HandlerReply handlerReply = reportEvent(paramJSONObject);
    sendReply(paramString1, handlerReply.getReplyMsg().toString(), handlerReply.getResult());
    return true;
  }
  
  protected HandlerReply reportEvent(JSONObject paramJSONObject) {
    Map<String, String> map;
    Map<String, Integer> map1;
    Map<String, Long> map2;
    JSONObject jSONObject1;
    String str;
    JSONObject jSONObject2;
    JSONObject jSONObject3;
    if (this.eventCollectorClient == null) {
      Log.e(this.TAG, "EventCollector is null. We will not report the event.");
      return new HandlerReply(new JSONObject(), "ERROR");
    } 
    if (!this.eventCollectorClient.isReportingEnabled()) {
      Log.i(this.TAG, "Reporting is disabled. Cannot report javascript event.");
      return new HandlerReply(new JSONObject(), "SUCCESS");
    } 
    if (paramJSONObject == null) {
      Log.e(this.TAG, "request is null. We will not report the event.");
      return new HandlerReply(new JSONObject(), "REQUEST_ERROR");
    } 
    try {
      JSONObject jSONObject = paramJSONObject.getJSONObject("parameters");
      jSONObject3 = jSONObject.optJSONObject("eventAttributes");
      jSONObject2 = jSONObject.optJSONObject("eventCountMetrics");
      jSONObject1 = jSONObject.optJSONObject("eventTimeMetrics");
      str = jSONObject.optString(NativeCallKeys.EVENT_NAME);
      if (TextUtils.isEmpty(str)) {
        Log.e(this.TAG, NativeCallKeys.EVENT_NAME + " key returns no value. This event cannot be constructed. Request: " + paramJSONObject);
        return new HandlerReply(new JSONObject(), "REQUEST_ERROR");
      } 
    } catch (JSONException jSONException) {
      Log.e(this.TAG, "No parameters for request. We will not report the event.", (Throwable)jSONException);
      return new HandlerReply(new JSONObject(), "REQUEST_ERROR");
    } 
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>();
    if (jSONObject3 != null)
      map = convertAttributes(jSONObject3); 
    if (jSONObject2 != null)
      map1 = convertCounts(jSONObject2); 
    if (jSONObject1 != null)
      map2 = convertTimes(jSONObject1); 
    try {
      GameCircleGenericEvent gameCircleGenericEvent = new GameCircleGenericEvent(str, map, map1, map2);
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent);
      return new HandlerReply(new JSONObject(), "SUCCESS");
    } catch (IllegalConstructionException illegalConstructionException) {
      Log.e(this.TAG, "Unable to create event correctly. Request: " + jSONException, (Throwable)illegalConstructionException);
      return new HandlerReply(new JSONObject(), "REQUEST_ERROR");
    } 
  }
  
  protected class HandlerReply {
    private JSONObject replyMsg;
    
    private String result;
    
    public HandlerReply(JSONObject param1JSONObject, String param1String) {
      this.replyMsg = param1JSONObject;
      this.result = param1String;
    }
    
    public JSONObject getReplyMsg() {
      return this.replyMsg;
    }
    
    public String getResult() {
      return this.result;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\ReportEventHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */