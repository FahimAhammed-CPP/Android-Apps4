package com.amazon.ags.html5.javascript;

import android.os.Handler;
import android.util.Log;
import com.amazon.ags.html5.factory.ServiceFactory;
import com.amazon.ags.storage.OfflineCacheRequest;
import com.amazon.ags.storage.OfflineDataCache;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class NativeCacheCallHandler extends CallHandlerBase {
  private static final Set<String> supportedCacheCalls = new HashSet<String>(Arrays.asList(new String[] { "setCacheItem", "setCacheItems", "getCacheItem", "queryCacheItems", "clearCache", "removeCachedItems" }));
  
  private final Map<String, OfflineDataCache> cacheNameMapping = new HashMap<String, OfflineDataCache>();
  
  public NativeCacheCallHandler(Handler paramHandler, OfflineDataCache paramOfflineDataCache1, OfflineDataCache paramOfflineDataCache2, OfflineDataCache paramOfflineDataCache3) {
    super(paramHandler, supportedCacheCalls);
    this.cacheNameMapping.put("AchievementsCache", paramOfflineDataCache1);
    this.cacheNameMapping.put("LeaderboardsCache", paramOfflineDataCache2);
    this.cacheNameMapping.put("PlayerProfileCache", paramOfflineDataCache3);
  }
  
  private OfflineCacheRequest createCacheRequestFromJSON(JSONObject paramJSONObject) throws JSONException {
    return new OfflineCacheRequest(paramJSONObject.getString("primaryKey"), paramJSONObject.getString("secondaryKey"), paramJSONObject.getJSONObject("jsonData"));
  }
  
  private void handleCacheRequest(String paramString1, String paramString2, String paramString3, JSONObject paramJSONObject) throws JSONException {
    String str1;
    String str2;
    OfflineDataCache offlineDataCache = this.cacheNameMapping.get(paramString2);
    if ("setCacheItem".equals(paramString3)) {
      offlineDataCache.setCacheItem(createCacheRequestFromJSON(paramJSONObject.getJSONObject("cacheRequest")));
      paramString3 = "{}";
      str1 = "SUCCESS";
    } else {
      ArrayList<OfflineCacheRequest> arrayList;
      if ("setCacheItems".equals(paramString3)) {
        JSONArray jSONArray = paramJSONObject.getJSONArray("cacheRequests");
        arrayList = new ArrayList(jSONArray.length());
        int i;
        for (i = 0; i < jSONArray.length(); i++)
          arrayList.add(createCacheRequestFromJSON(jSONArray.getJSONObject(i))); 
        str1.setCacheItems(arrayList);
        str2 = "{}";
        str1 = "SUCCESS";
      } else {
        String str;
        if ("getCacheItem".equals(str2)) {
          JSONObject jSONObject = str1.getCacheItem(arrayList.getString("primaryKey"));
          if (jSONObject != null) {
            str2 = jSONObject.toString();
            str = "SUCCESS";
          } else {
            str2 = "{}";
            str = "ERROR";
          } 
        } else {
          JSONObject jSONObject;
          if ("queryCacheItems".equals(str2)) {
            JSONArray jSONArray;
            List list = str.queryCacheItems(arrayList.getString("secondaryKey"));
            if (list != null) {
              jSONArray = new JSONArray(list);
            } else {
              jSONArray = new JSONArray();
            } 
            jSONObject = new JSONObject();
            jSONObject.put("queryResult", jSONArray);
            if (list != null) {
              str2 = jSONObject.toString();
              str1 = "SUCCESS";
            } else {
              str2 = "{}";
              str1 = "ERROR";
            } 
          } else if ("clearCache".equals(str2)) {
            str1.clear();
            str2 = "{}";
            str1 = "SUCCESS";
          } else if ("removeCachedItems".equals(str2)) {
            str1.removeCachedItems(jSONObject.getString("secondaryKey"));
            str2 = "{}";
            str1 = "SUCCESS";
          } else {
            throw new IllegalArgumentException("Cache request method not supported: " + str2);
          } 
        } 
      } 
    } 
    sendReply(paramString1, str2, str1);
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    String str;
    JSONObject jSONObject;
    if (!supportedCacheCalls.contains(paramString2))
      return false; 
    if (ServiceFactory.isDebugLoggingEnabled())
      Log.d(this.TAG, "Cache call: " + paramJSONObject); 
    try {
      str = paramJSONObject.getString("target");
      jSONObject = paramJSONObject.getJSONObject("parameters");
      if (str == null || jSONObject == null || paramString1 == null)
        throw new IllegalArgumentException("Insufficient arguments for cache request"); 
    } catch (Exception exception) {
      Log.e(this.TAG, "Cache request " + paramJSONObject + " failed", exception);
      sendReply(paramString1, "{}", "REQUEST_ERROR");
      return true;
    } 
    try {
      handleCacheRequest(paramString1, str, (String)exception, jSONObject);
      return true;
    } catch (Exception exception1) {
      Log.e(this.TAG, "Cache request " + paramJSONObject + " failed", exception1);
      sendReply(paramString1, "{}", "ERROR");
      return true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\NativeCacheCallHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */