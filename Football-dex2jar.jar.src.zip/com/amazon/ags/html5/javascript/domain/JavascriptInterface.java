package com.amazon.ags.html5.javascript.domain;

import android.util.Log;
import android.webkit.WebView;
import com.amazon.ags.html5.factory.ServiceFactory;
import com.amazon.ags.html5.javascript.CallHandlerBase;
import com.amazon.ags.html5.overlay.OverlayManager;
import com.amazon.ags.html5.service.AsynchronousReplyMessenger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JavascriptInterface {
  private static final String TAG = "GC_" + JavascriptInterface.class.getSimpleName();
  
  private final List<CloseAlertListener> closeAlertListeners = new ArrayList<CloseAlertListener>();
  
  private final List<CloseOverlayListener> closeOverlayListeners = new ArrayList<CloseOverlayListener>();
  
  private final ExecutorService executorService;
  
  private final String id;
  
  private boolean isJavascriptReadyToHandleMessages;
  
  private final List<CallHandlerBase> nativeCallHandlers;
  
  private final List<MessageHandlerReadyListener> notifyOnReadyListeners = new ArrayList<MessageHandlerReadyListener>();
  
  private final OverlayManager overlayLauncher;
  
  private final AsynchronousReplyMessenger replyMessenger;
  
  private final Object toastLock;
  
  private final WebView webView;
  
  public JavascriptInterface(String paramString, AsynchronousReplyMessenger paramAsynchronousReplyMessenger, OverlayManager paramOverlayManager, List<CallHandlerBase> paramList, ExecutorService paramExecutorService, WebView paramWebView, Object paramObject) {
    this.id = paramString;
    this.replyMessenger = paramAsynchronousReplyMessenger;
    this.overlayLauncher = paramOverlayManager;
    this.nativeCallHandlers = paramList;
    this.executorService = paramExecutorService;
    this.webView = paramWebView;
    this.toastLock = paramObject;
    this.isJavascriptReadyToHandleMessages = false;
  }
  
  public void addCloseAlertListener(CloseAlertListener paramCloseAlertListener) {
    this.closeAlertListeners.add(paramCloseAlertListener);
  }
  
  public void addCloseOverlayListener(CloseOverlayListener paramCloseOverlayListener) {
    this.closeOverlayListeners.add(paramCloseOverlayListener);
  }
  
  public void addMessageHandlerReadyListener(MessageHandlerReadyListener paramMessageHandlerReadyListener) {
    this.notifyOnReadyListeners.add(paramMessageHandlerReadyListener);
  }
  
  @android.webkit.JavascriptInterface
  public void closeAlert() {
    this.executorService.execute(new Runnable() {
          public void run() {
            Iterator<CloseAlertListener> iterator = JavascriptInterface.this.closeAlertListeners.iterator();
            while (iterator.hasNext())
              ((CloseAlertListener)iterator.next()).closeAlert(); 
          }
        });
  }
  
  @android.webkit.JavascriptInterface
  public void closeOverlay() {
    this.executorService.execute(new Runnable() {
          public void run() {
            Iterator<CloseOverlayListener> iterator = JavascriptInterface.this.closeOverlayListeners.iterator();
            while (iterator.hasNext())
              ((CloseOverlayListener)iterator.next()).closeOverlay(); 
          }
        });
  }
  
  public String getId() {
    return this.id;
  }
  
  @android.webkit.JavascriptInterface
  public void handleMessage(final String json) {
    this.executorService.execute(new Runnable() {
          public void run() {
            try {
              JSONObject jSONObject = new JSONObject(json);
              Iterator<CallHandlerBase> iterator = JavascriptInterface.this.nativeCallHandlers.iterator();
              while (iterator.hasNext()) {
                if (((CallHandlerBase)iterator.next()).handleMessage(JavascriptInterface.this, jSONObject))
                  return; 
              } 
              String str = jSONObject.getString("nativeCall");
              Log.e(JavascriptInterface.TAG, "No handler found for native call type " + str);
              return;
            } catch (JSONException jSONException) {
              Log.e(JavascriptInterface.TAG, "Unable to parse request from javascript: " + json, (Throwable)jSONException);
              return;
            } 
          }
        });
  }
  
  @android.webkit.JavascriptInterface
  public boolean isReady() {
    return this.isJavascriptReadyToHandleMessages;
  }
  
  @android.webkit.JavascriptInterface
  public void logMessage(String paramString) {
    if (ServiceFactory.isDebugLoggingEnabled())
      Log.d(TAG, "JS Log: " + paramString); 
  }
  
  public void sendJSReply(String paramString1, String paramString2, String paramString3, String paramString4) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("__requestId", paramString1);
      jSONObject.put("resultCode", paramString3);
      jSONObject.put("httpResponseCode", paramString4);
      if (paramString2 != null) {
        int i = paramString2.length();
        if (i != 0)
          try {
            jSONObject.put("params", (new JSONTokener(paramString2)).nextValue());
          } catch (Exception exception) {} 
      } 
      this.webView.loadUrl("javascript:receiveReply(" + jSONObject.toString() + ");");
      return;
    } catch (Exception exception) {
      Log.e(TAG, "Failed to convey response for rid [" + paramString1 + "]: " + exception.toString(), exception);
      return;
    } 
  }
  
  @android.webkit.JavascriptInterface
  public void sendReply(final String json) {
    this.executorService.execute(new Runnable() {
          public void run() {
            try {
              JSONObject jSONObject = new JSONObject(json);
              JavascriptInterface.this.replyMessenger.sendReply(jSONObject);
              return;
            } catch (JSONException jSONException) {
              Log.e(JavascriptInterface.TAG, "Unable to parse request: " + json, (Throwable)jSONException);
              return;
            } 
          }
        });
  }
  
  @android.webkit.JavascriptInterface
  public void setReadyForMessages() {
    this.isJavascriptReadyToHandleMessages = true;
    this.executorService.execute(new Runnable() {
          public void run() {
            Iterator<MessageHandlerReadyListener> iterator = JavascriptInterface.this.notifyOnReadyListeners.iterator();
            while (iterator.hasNext())
              ((MessageHandlerReadyListener)iterator.next()).messageHandlerReady(); 
          }
        });
  }
  
  @android.webkit.JavascriptInterface
  public void showAlert(final String json) {
    this.executorService.execute(new Runnable() {
          public void run() {
            JavascriptInterface.this.overlayLauncher.showAlert(json);
          }
        });
  }
  
  @android.webkit.JavascriptInterface
  public void showOverlay(final String json) {
    this.executorService.execute(new Runnable() {
          public void run() {
            JavascriptInterface.this.overlayLauncher.showOverlay(json);
          }
        });
  }
  
  @android.webkit.JavascriptInterface
  public void showToast(final String json) {
    this.executorService.execute(new Runnable() {
          public void run() {
            try {
              if (ServiceFactory.getShowToastsString().equals("toastsUndefined"))
                synchronized (JavascriptInterface.this.toastLock) {
                  JavascriptInterface.this.toastLock.wait();
                  if (ServiceFactory.getShowToastsString().equals("showToasts"))
                    JavascriptInterface.this.overlayLauncher.showToast(json); 
                  return;
                }  
            } catch (InterruptedException interruptedException) {
              interruptedException.printStackTrace();
            } 
            if (ServiceFactory.getShowToastsString().equals("showToasts"))
              JavascriptInterface.this.overlayLauncher.showToast(json); 
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\domain\JavascriptInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */