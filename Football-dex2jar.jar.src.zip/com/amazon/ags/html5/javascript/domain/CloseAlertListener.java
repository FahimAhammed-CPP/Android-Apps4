package com.amazon.ags.html5.javascript.domain;

public interface CloseAlertListener {
  void closeAlert();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\domain\CloseAlertListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */