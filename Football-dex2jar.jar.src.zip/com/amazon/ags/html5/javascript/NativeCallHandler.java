package com.amazon.ags.html5.javascript;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import com.amazon.ags.client.player.PlayerClientImpl;
import com.amazon.ags.html5.content.GCVariationManager;
import com.amazon.ags.html5.util.BrowserUtil;
import com.amazon.ags.html5.util.EmailUtil;
import com.amazon.ags.html5.util.ImageManager;
import com.amazon.ags.html5.util.LocalizationUtil;
import com.amazon.ags.html5.util.NetworkUtil;
import com.amazon.ags.storage.OfflineEvent;
import com.amazon.ags.storage.OfflineEventManager;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class NativeCallHandler extends CallHandlerBase {
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "getNetworkInfo", "getPackageName", "openEmailEditor", "queueOfflineEvent", "downloadImages", "getLocaleInfo", "getVariationVariable", "NOTIFY_SIGN_IN_STATE_CHANGE" }));
  
  private final BrowserUtil browserUtil;
  
  private final Context context;
  
  private final EmailUtil emailUtil;
  
  private final GCVariationManager gcVariationManager;
  
  private final ImageManager imageManager;
  
  private final LocalizationUtil localizationUtil;
  
  private final NetworkUtil networkUtil;
  
  private final OfflineEventManager offlineEventManager;
  
  public NativeCallHandler(Context paramContext, Handler paramHandler, NetworkUtil paramNetworkUtil, BrowserUtil paramBrowserUtil, EmailUtil paramEmailUtil, OfflineEventManager paramOfflineEventManager, ImageManager paramImageManager, LocalizationUtil paramLocalizationUtil, GCVariationManager paramGCVariationManager) {
    super(paramHandler, supportedCalls);
    this.context = paramContext;
    this.offlineEventManager = paramOfflineEventManager;
    this.networkUtil = paramNetworkUtil;
    this.browserUtil = paramBrowserUtil;
    this.emailUtil = paramEmailUtil;
    this.imageManager = paramImageManager;
    this.localizationUtil = paramLocalizationUtil;
    this.gcVariationManager = paramGCVariationManager;
  }
  
  private void downloadImages(String paramString, JSONObject paramJSONObject) {
    HashSet<String> hashSet = new HashSet();
    try {
      JSONArray jSONArray = paramJSONObject.getJSONObject("parameters").getJSONObject("imageData").getJSONArray("images");
      if (jSONArray != null && jSONArray.length() > 0)
        for (int i = 0; i < jSONArray.length(); i++) {
          try {
            String str = jSONArray.getJSONObject(i).getString("imageUrl");
            if (!hashSet.contains(str)) {
              this.imageManager.downloadImage(str);
              hashSet.add(str);
            } 
          } catch (JSONException jSONException) {
            Log.w(this.TAG, "Unable to get image data for specific image", (Throwable)jSONException);
          } catch (Exception exception) {
            Log.w(this.TAG, "Cannot process specific image download", exception);
          } 
        }  
    } catch (JSONException jSONException) {
      Log.w(this.TAG, "Unable to get image data from request " + exception, (Throwable)jSONException);
      sendReply(paramString, "{}", "REQUEST_ERROR");
      return;
    } catch (Exception exception1) {
      Log.w(this.TAG, "Cannot process downloadImages request: " + exception, exception1);
      sendReply(paramString, "{}", "ERROR");
      return;
    } 
    sendReply(paramString, "{}", "SUCCESS");
  }
  
  private void getNetworkInfo(String paramString) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("connected", this.networkUtil.isNetworkConnected());
    } catch (JSONException jSONException) {
      Log.w(this.TAG, "Unable to get network state", (Throwable)jSONException);
    } 
    sendReply(paramString, jSONObject.toString(), "SUCCESS");
  }
  
  private void getPackageName(String paramString) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("PACKAGE_NAME", this.context.getPackageName());
      sendReply(paramString, jSONObject.toString(), "SUCCESS");
      return;
    } catch (JSONException jSONException) {
      Log.w(this.TAG, "Error building response for getPackageName");
      sendReply(paramString, "{}", "ERROR");
      return;
    } 
  }
  
  private void notifySignedInStateChange(String paramString, JSONObject paramJSONObject) {
    JSONObject jSONObject = new JSONObject();
    try {
      PlayerClientImpl.notifySignedInListener(paramJSONObject.getJSONObject("parameters").getBoolean("isSignedIn"));
      sendReply(paramString, jSONObject.toString(), "SUCCESS");
      return;
    } catch (JSONException jSONException) {
      Log.w(this.TAG, "Error notifying sign in state change: " + jSONException.toString());
      sendReply(paramString, "{}", "ERROR");
      return;
    } 
  }
  
  private void openBrowser(String paramString, JSONObject paramJSONObject) {
    try {
      String str = paramJSONObject.getJSONObject("parameters").getString("url");
      this.browserUtil.launchBrowser(str);
      sendReply(paramString, "{}", "SUCCESS");
      return;
    } catch (JSONException jSONException) {
      Log.e(this.TAG, "Unable to get browser parameters from request " + paramJSONObject, (Throwable)jSONException);
      sendReply(paramString, "{}", "REQUEST_ERROR");
      return;
    } catch (Exception exception) {
      Log.e(this.TAG, "Cannot process launch browser request: " + paramJSONObject, exception);
      sendReply(paramString, "{}", "ERROR");
      return;
    } 
  }
  
  private void openEmailEditor(String paramString, JSONObject paramJSONObject) {
    try {
      JSONObject jSONObject = paramJSONObject.getJSONObject("parameters");
      String str1 = jSONObject.getString("mailTo");
      String str2 = jSONObject.getString("subject");
      String str3 = jSONObject.getString("body");
      this.emailUtil.launchEmailEditor(str1, str2, str3);
      sendReply(paramString, "{}", "SUCCESS");
      return;
    } catch (JSONException jSONException) {
      Log.e(this.TAG, "Unable to get email parameters from request " + paramJSONObject, (Throwable)jSONException);
      sendReply(paramString, "{}", "REQUEST_ERROR");
      return;
    } catch (Exception exception) {
      Log.e(this.TAG, "Cannot process open email request: " + paramJSONObject, exception);
      sendReply(paramString, "{}", "ERROR");
      return;
    } 
  }
  
  private void queueOfflineEvent(String paramString, JSONObject paramJSONObject) {
    try {
      OfflineEvent offlineEvent = new OfflineEvent(new JSONObject(paramJSONObject.getJSONObject("parameters").getString("eventJson")));
      this.offlineEventManager.submitEvent(offlineEvent);
      sendReply(paramString, "{}", "SUCCESS");
      return;
    } catch (JSONException jSONException) {
      Log.e(this.TAG, "Unable to get event parameters from request " + paramJSONObject, (Throwable)jSONException);
      sendReply(paramString, "{}", "REQUEST_ERROR");
      return;
    } catch (Exception exception) {
      Log.e(this.TAG, "Cannot process queue offline event request: " + paramJSONObject, exception);
      sendReply(paramString, "{}", "ERROR");
      return;
    } 
  }
  
  private void retrieveLocaleInfo(String paramString) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("languageCode", this.localizationUtil.getLanguageCode());
      jSONObject.put("countryCode", this.localizationUtil.getCountryCode());
      sendReply(paramString, jSONObject.toString(), "SUCCESS");
      return;
    } catch (Exception exception) {
      Log.w(this.TAG, "Unable to get locale information", exception);
      sendReply(paramString, "{}", "ERROR");
      return;
    } 
  }
  
  private void retrieveVariationVariable(String paramString, JSONObject paramJSONObject) {
    JSONObject jSONObject = new JSONObject();
    try {
      JSONObject jSONObject1 = paramJSONObject.getJSONObject("parameters");
      String str1 = jSONObject1.getString("variation");
      String str2 = jSONObject1.getString("variationVariableDefaultValue");
      str1 = (String)this.gcVariationManager.getCachedVariations().get(str1);
      if (str1 != null) {
        jSONObject.put("variation", str1);
      } else {
        jSONObject.put("variation", str2);
      } 
      sendReply(paramString, jSONObject.toString(), "SUCCESS");
      return;
    } catch (JSONException jSONException) {
      Log.w(this.TAG, "Unable to get variation data from request " + paramJSONObject, (Throwable)jSONException);
      sendReply(paramString, "{}", "REQUEST_ERROR");
      return;
    } catch (Exception exception) {
      Log.w(this.TAG, "Cannot process getVariationVariable request: " + paramJSONObject, exception);
      sendReply(paramString, "{}", "ERROR");
      return;
    } 
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    if ("getNetworkInfo".equals(paramString2)) {
      getNetworkInfo(paramString1);
      return true;
    } 
    if ("getPackageName".equals(paramString2)) {
      getPackageName(paramString1);
      return true;
    } 
    if ("openBrowser".equals(paramString2)) {
      openBrowser(paramString1, paramJSONObject);
      return true;
    } 
    if ("openEmailEditor".equals(paramString2)) {
      openEmailEditor(paramString1, paramJSONObject);
      return true;
    } 
    if ("queueOfflineEvent".equals(paramString2)) {
      queueOfflineEvent(paramString1, paramJSONObject);
      return true;
    } 
    if ("downloadImages".equals(paramString2)) {
      downloadImages(paramString1, paramJSONObject);
      return true;
    } 
    if ("getLocaleInfo".equals(paramString2)) {
      retrieveLocaleInfo(paramString1);
      return true;
    } 
    if ("getVariationVariable".equals(paramString2)) {
      retrieveVariationVariable(paramString1, paramJSONObject);
      return true;
    } 
    if ("NOTIFY_SIGN_IN_STATE_CHANGE".equals(paramString2)) {
      notifySignedInStateChange(paramString1, paramJSONObject);
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\NativeCallHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */