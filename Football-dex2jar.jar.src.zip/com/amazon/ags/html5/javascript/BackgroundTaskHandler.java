package com.amazon.ags.html5.javascript;

import android.os.Handler;
import com.amazon.ags.client.JSONRequest;
import com.amazon.ags.html5.service.ServiceHelper;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public class BackgroundTaskHandler extends CallHandlerBase {
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "backgroundTask" }));
  
  private final ServiceHelper serviceHelper;
  
  public BackgroundTaskHandler(ServiceHelper paramServiceHelper, Handler paramHandler) {
    super(paramHandler, supportedCalls);
    this.serviceHelper = paramServiceHelper;
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, final JSONObject request) {
    if (!"backgroundTask".equals(paramString2))
      return false; 
    JSONRequest jSONRequest = new JSONRequest() {
        public JSONObject getRequest() {
          try {
            JSONObject jSONObject = request.getJSONObject("parameters");
            jSONObject.put("REQUEST_ID", UUID.randomUUID().toString());
            return jSONObject;
          } catch (JSONException jSONException) {
            return new JSONObject();
          } 
        }
        
        public void setResponse(JSONObject param1JSONObject) {}
      };
    this.serviceHelper.handleRequestAsync(jSONRequest);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\BackgroundTaskHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */