package com.amazon.ags.html5.javascript;

import android.os.Handler;
import android.util.Log;
import com.amazon.ags.html5.util.GlobalState;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class NativeGlobalStateCallHandler extends CallHandlerBase {
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "batchGetGlobalState", "batchPutGlobalState" }));
  
  private final GlobalState globalState;
  
  public NativeGlobalStateCallHandler(Handler paramHandler, GlobalState paramGlobalState) {
    super(paramHandler, supportedCalls);
    this.globalState = paramGlobalState;
  }
  
  private void batchGetGlobalState(String paramString, JSONObject paramJSONObject) {
    sendReply(paramString, this.globalState.toJSON().toString(), "SUCCESS");
  }
  
  private void batchPutGlobalState(String paramString, JSONObject paramJSONObject) {
    try {
      JSONObject jSONObject = paramJSONObject.getJSONObject("parameters");
      Iterator<String> iterator = jSONObject.keys();
      while (iterator.hasNext()) {
        String str1;
        String str2 = iterator.next();
        if (!jSONObject.isNull(str2)) {
          str1 = jSONObject.getString(str2);
        } else {
          str1 = null;
        } 
        this.globalState.put(str2, str1);
      } 
    } catch (JSONException jSONException) {
      Log.e(this.TAG, "Unable to update global state from request " + paramJSONObject, (Throwable)jSONException);
      sendReply(paramString, "{}", "REQUEST_ERROR");
      return;
    } 
    sendReply(paramString, "{}", "SUCCESS");
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    if ("batchGetGlobalState".equals(paramString2)) {
      batchGetGlobalState(paramString1, paramJSONObject);
      return true;
    } 
    if ("batchPutGlobalState".equals(paramString2)) {
      batchPutGlobalState(paramString1, paramJSONObject);
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\NativeGlobalStateCallHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */