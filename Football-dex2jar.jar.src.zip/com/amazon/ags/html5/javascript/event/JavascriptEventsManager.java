package com.amazon.ags.html5.javascript.event;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class JavascriptEventsManager {
  private final Map<String, JavascriptEventListener> listeners = new HashMap<String, JavascriptEventListener>();
  
  public void addEventListener(String paramString, JavascriptEventListener paramJavascriptEventListener) {
    this.listeners.put(paramString, paramJavascriptEventListener);
  }
  
  public void notifyListeners(String paramString) {
    Iterator<JavascriptEventListener> iterator = this.listeners.values().iterator();
    while (iterator.hasNext())
      ((JavascriptEventListener)iterator.next()).onJavascriptEvent(paramString); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\event\JavascriptEventsManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */