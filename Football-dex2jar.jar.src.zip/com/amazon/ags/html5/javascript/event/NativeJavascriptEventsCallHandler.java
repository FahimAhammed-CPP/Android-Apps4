package com.amazon.ags.html5.javascript.event;

import android.os.Handler;
import com.amazon.ags.html5.javascript.CallHandlerBase;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONObject;

public class NativeJavascriptEventsCallHandler extends CallHandlerBase {
  private static final Set<String> supportedCalls = new HashSet<String>(Arrays.asList(new String[] { "notifyNative" }));
  
  private final JavascriptEventsManager javascriptEventsManager;
  
  public NativeJavascriptEventsCallHandler(Handler paramHandler, JavascriptEventsManager paramJavascriptEventsManager) {
    super(paramHandler, supportedCalls);
    this.javascriptEventsManager = paramJavascriptEventsManager;
  }
  
  protected boolean handleMessage(String paramString1, String paramString2, JSONObject paramJSONObject) {
    // Byte code:
    //   0: aload_0
    //   1: getfield TAG : Ljava/lang/String;
    //   4: new java/lang/StringBuilder
    //   7: dup
    //   8: invokespecial <init> : ()V
    //   11: ldc 'Processing request ['
    //   13: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: aload_1
    //   17: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   20: ldc '] for call type ['
    //   22: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   25: aload_2
    //   26: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: ldc ']'
    //   31: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   34: invokevirtual toString : ()Ljava/lang/String;
    //   37: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   40: pop
    //   41: aconst_null
    //   42: astore #5
    //   44: aload #5
    //   46: astore #4
    //   48: ldc 'notifyNative'
    //   50: aload_2
    //   51: invokevirtual equals : (Ljava/lang/Object;)Z
    //   54: ifeq -> 89
    //   57: aload_3
    //   58: ldc 'parameters'
    //   60: invokevirtual getJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   63: ldc 'javascriptEventType'
    //   65: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   68: astore_2
    //   69: aload_0
    //   70: getfield javascriptEventsManager : Lcom/amazon/ags/html5/javascript/event/JavascriptEventsManager;
    //   73: aload_2
    //   74: invokevirtual notifyListeners : (Ljava/lang/String;)V
    //   77: new org/json/JSONObject
    //   80: dup
    //   81: invokespecial <init> : ()V
    //   84: invokevirtual toString : ()Ljava/lang/String;
    //   87: astore #4
    //   89: aload_0
    //   90: getfield TAG : Ljava/lang/String;
    //   93: new java/lang/StringBuilder
    //   96: dup
    //   97: invokespecial <init> : ()V
    //   100: ldc 'Returning reply ['
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: aload #4
    //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: ldc '] for request ['
    //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: aload_1
    //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: ldc ']'
    //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: invokevirtual toString : ()Ljava/lang/String;
    //   127: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   130: pop
    //   131: aload #4
    //   133: ifnull -> 169
    //   136: aload_0
    //   137: aload_1
    //   138: aload #4
    //   140: invokevirtual toString : ()Ljava/lang/String;
    //   143: ldc 'SUCCESS'
    //   145: invokevirtual sendReply : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   148: iconst_1
    //   149: ireturn
    //   150: astore_2
    //   151: aload_0
    //   152: getfield TAG : Ljava/lang/String;
    //   155: ldc 'Unable to get value for key [javascriptEventType]'
    //   157: aload_2
    //   158: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   161: pop
    //   162: aload #5
    //   164: astore #4
    //   166: goto -> 89
    //   169: iconst_0
    //   170: ireturn
    // Exception table:
    //   from	to	target	type
    //   57	89	150	org/json/JSONException
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\html5\javascript\event\NativeJavascriptEventsCallHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */