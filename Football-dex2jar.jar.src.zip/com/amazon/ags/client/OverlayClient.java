package com.amazon.ags.client;

import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.html5.service.ServiceHelper;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class OverlayClient extends ClientBase {
  public OverlayClient(ServiceHelper paramServiceHelper) {
    super(paramServiceHelper);
  }
  
  private ClientBase.AsyncTaskWrapper<RequestResponse> showOverlayPage(String paramString, Object paramObject) {
    return showOverlayPage(paramString, paramObject, Collections.emptyMap());
  }
  
  private ClientBase.AsyncTaskWrapper<RequestResponse> showOverlayPage(String paramString, final Object pageCode, final Map<Object, Object> requestParams) {
    return new ClientBase.AsyncTaskWrapper<RequestResponse>(paramString) {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", pageCode);
          for (Map.Entry entry : requestParams.entrySet())
            jSONObject.put((String)entry.getKey(), entry.getValue()); 
          return jSONObject;
        }
        
        public RequestResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          return new RequestResponseImpl(17);
        }
        
        public RequestResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new RequestResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      };
  }
  
  public AGResponseHandle<RequestResponse> showAchievementsOverlay(Object... paramVarArgs) {
    return showOverlayPage("Show Achievements Overlay", Integer.valueOf(26)).execute(paramVarArgs);
  }
  
  public AGResponseHandle<RequestResponse> showGameCircle(Object... paramVarArgs) {
    return showOverlayPage("Show Game Circle", "SHOW_GAME_CIRCLE").execute(paramVarArgs);
  }
  
  public AGResponseHandle<RequestResponse> showLeaderboardOverlay(String paramString, Object... paramVarArgs) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("LEADERBOARD_ID", paramString);
    return showOverlayPage("Show Leaderboard Overlay", Integer.valueOf(28), hashMap).execute(paramVarArgs);
  }
  
  public AGResponseHandle<RequestResponse> showLeaderboardsOverlay(Object... paramVarArgs) {
    return showOverlayPage("Show Leaderboards Overlay", Integer.valueOf(27)).execute(paramVarArgs);
  }
  
  public AGResponseHandle<RequestResponse> showSignInPage(Object... paramVarArgs) {
    return showOverlayPage("Show Sign In Overlay", "SHOW_SIGN_IN_PAGE").execute(paramVarArgs);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\OverlayClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */