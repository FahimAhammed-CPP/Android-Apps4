package com.amazon.ags.client;

import com.amazon.ags.api.AGHandleStatus;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.RequestResponse;

public class AGResponseHandleImpl<T extends RequestResponse> implements AGResponseHandle<T> {
  private AGResponseCallback<T> callback = null;
  
  private T response = null;
  
  private AGHandleStatus status = AGHandleStatus.WAITING;
  
  private final Object[] userData;
  
  public AGResponseHandleImpl(Object[] paramArrayOfObject) {
    this.userData = paramArrayOfObject;
  }
  
  private void callCallback() {
    if (this.callback != null && this.response != null && this.callback != null) {
      this.callback.onComplete((RequestResponse)this.response);
      return;
    } 
  }
  
  public T getResponse() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield response : Lcom/amazon/ags/api/RequestResponse;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public AGHandleStatus getStatus() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield status : Lcom/amazon/ags/api/AGHandleStatus;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public void setCallback(AGResponseCallback<T> paramAGResponseCallback) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield callback : Lcom/amazon/ags/api/AGResponseCallback;
    //   6: ifnull -> 39
    //   9: iconst_1
    //   10: istore_2
    //   11: aload_0
    //   12: aload_1
    //   13: putfield callback : Lcom/amazon/ags/api/AGResponseCallback;
    //   16: iload_2
    //   17: ifne -> 31
    //   20: aload_0
    //   21: getfield response : Lcom/amazon/ags/api/RequestResponse;
    //   24: ifnull -> 31
    //   27: aload_0
    //   28: invokespecial callCallback : ()V
    //   31: aload_0
    //   32: monitorexit
    //   33: return
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: athrow
    //   39: iconst_0
    //   40: istore_2
    //   41: goto -> 11
    // Exception table:
    //   from	to	target	type
    //   2	9	34	finally
    //   11	16	34	finally
    //   20	31	34	finally
    //   31	33	34	finally
    //   35	37	34	finally
  }
  
  public void setResponse(T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield response : Lcom/amazon/ags/api/RequestResponse;
    //   7: aload_0
    //   8: getfield response : Lcom/amazon/ags/api/RequestResponse;
    //   11: aload_0
    //   12: getfield userData : [Ljava/lang/Object;
    //   15: invokeinterface setUserData : ([Ljava/lang/Object;)V
    //   20: aload_0
    //   21: getfield response : Lcom/amazon/ags/api/RequestResponse;
    //   24: invokeinterface isError : ()Z
    //   29: ifeq -> 46
    //   32: aload_0
    //   33: getstatic com/amazon/ags/api/AGHandleStatus.ERROR : Lcom/amazon/ags/api/AGHandleStatus;
    //   36: putfield status : Lcom/amazon/ags/api/AGHandleStatus;
    //   39: aload_0
    //   40: invokespecial callCallback : ()V
    //   43: aload_0
    //   44: monitorexit
    //   45: return
    //   46: aload_0
    //   47: getstatic com/amazon/ags/api/AGHandleStatus.SUCCESS : Lcom/amazon/ags/api/AGHandleStatus;
    //   50: putfield status : Lcom/amazon/ags/api/AGHandleStatus;
    //   53: goto -> 39
    //   56: astore_1
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    // Exception table:
    //   from	to	target	type
    //   2	39	56	finally
    //   39	43	56	finally
    //   46	53	56	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\AGResponseHandleImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */