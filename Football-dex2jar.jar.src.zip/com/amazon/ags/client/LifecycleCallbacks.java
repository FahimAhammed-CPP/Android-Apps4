package com.amazon.ags.client;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import com.amazon.ags.api.AmazonGamesCallback;
import com.amazon.ags.api.AmazonGamesClient;
import com.amazon.ags.api.AmazonGamesFeature;
import com.amazon.ags.api.AmazonGamesStatus;
import java.util.EnumSet;

@TargetApi(14)
public class LifecycleCallbacks implements Application.ActivityLifecycleCallbacks {
  private EnumSet<AmazonGamesFeature> initFeatures;
  
  public LifecycleCallbacks(EnumSet<AmazonGamesFeature> paramEnumSet) {
    this.initFeatures = paramEnumSet;
  }
  
  public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {}
  
  public void onActivityDestroyed(Activity paramActivity) {}
  
  public void onActivityPaused(Activity paramActivity) {
    if (!(paramActivity instanceof com.amazon.ags.html5.overlay.GameCircleUserInterface) && !(paramActivity instanceof com.amazon.ags.html5.overlay.GameCircleAlertUserInterface))
      AmazonGamesClient.release(); 
  }
  
  public void onActivityResumed(Activity paramActivity) {
    if (!(paramActivity instanceof com.amazon.ags.html5.overlay.GameCircleUserInterface) && !(paramActivity instanceof com.amazon.ags.html5.overlay.GameCircleAlertUserInterface))
      AmazonGamesClient.initialize(paramActivity, new AmazonGamesCallback() {
            public void onServiceNotReady(AmazonGamesStatus param1AmazonGamesStatus) {}
            
            public void onServiceReady(AmazonGamesClient param1AmazonGamesClient) {}
          },  this.initFeatures); 
  }
  
  public void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle) {}
  
  public void onActivityStarted(Activity paramActivity) {}
  
  public void onActivityStopped(Activity paramActivity) {}
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\LifecycleCallbacks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */