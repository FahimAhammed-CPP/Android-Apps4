package com.amazon.ags.client.metrics;

public class IllegalConstructionException extends Exception {
  private static final long serialVersionUID = 668722702952072814L;
  
  public IllegalConstructionException() {}
  
  public IllegalConstructionException(String paramString) {
    super(paramString);
  }
  
  public IllegalConstructionException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public IllegalConstructionException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\metrics\IllegalConstructionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */