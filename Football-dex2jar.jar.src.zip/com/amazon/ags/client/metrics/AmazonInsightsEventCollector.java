package com.amazon.ags.client.metrics;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.constants.metrics.MetricConstants;
import com.amazon.ags.constants.nonjs.MetricsParserConstants;
import com.amazon.ags.html5.util.DeviceInfo;
import com.amazon.identity.auth.device.authorization.api.AmazonAuthorizationManager;
import com.amazon.insights.AmazonInsights;
import com.amazon.insights.Event;
import com.amazon.insights.EventClient;
import com.amazon.insights.InsightsCallback;
import java.util.Map;

public class AmazonInsightsEventCollector implements EventCollector {
  private static final String APPLICATION_KEY = "M3CGOMO6ILJQ65";
  
  private static final String PRIVATE_KEY = "jqyngW96w5vk9a3gLSPP0srNdRpFkRi2+Fjl6qMoPrg=";
  
  private static final String TAG = "GC_" + AmazonInsightsEventCollector.class.getSimpleName();
  
  private EventClient eventClient;
  
  public AmazonInsightsEventCollector(Context paramContext) throws IllegalConstructionException {
    if (paramContext == null)
      throw new IllegalConstructionException("Unable to create Event collector class. Context is null."); 
    try {
      this.eventClient = initialize(paramContext);
      return;
    } catch (Exception exception) {
      throw new IllegalConstructionException(exception);
    } 
  }
  
  protected Event convertToInsightsEvent(GameCircleGenericEvent paramGameCircleGenericEvent) throws EventReportException {
    if (paramGameCircleGenericEvent == null)
      throw new EventReportException("Event is null. It cannot be reported."); 
    Event event = this.eventClient.createEvent(paramGameCircleGenericEvent.getEventName());
    Map map2 = paramGameCircleGenericEvent.getAttributes();
    if (map2 != null)
      for (Map.Entry entry : map2.entrySet()) {
        if (!TextUtils.isEmpty((CharSequence)entry.getKey()))
          event.withAttribute((String)entry.getKey(), (String)entry.getValue()); 
      }  
    map2 = paramGameCircleGenericEvent.getCountMetrics();
    if (map2 != null)
      for (Map.Entry entry : map2.entrySet()) {
        if (!TextUtils.isEmpty((CharSequence)entry.getKey()))
          event.withMetric(MetricsParserConstants.convertCountKey((String)entry.getKey()), (Number)entry.getValue()); 
      }  
    Map map1 = paramGameCircleGenericEvent.getTimeMetrics();
    if (map1 != null)
      for (Map.Entry entry : map1.entrySet()) {
        if (!TextUtils.isEmpty((CharSequence)entry.getKey()))
          event.withMetric(MetricsParserConstants.convertTimeKey((String)entry.getKey()), (Number)entry.getValue()); 
      }  
    return event;
  }
  
  protected EventClient initialize(final Context context) throws IllegalConstructionException {
    if (context == null)
      throw new IllegalConstructionException("The context is null. Insights cannot be initialized."); 
    this.eventClient = AmazonInsights.newInstance(AmazonInsights.newCredentials("M3CGOMO6ILJQ65", "jqyngW96w5vk9a3gLSPP0srNdRpFkRi2+Fjl6qMoPrg="), context, new InsightsCallback<AmazonInsights>() {
          public void onComplete(AmazonInsights param1AmazonInsights) {
            try {
              EventClient eventClient = param1AmazonInsights.getEventClient();
              eventClient.addGlobalAttribute(MetricConstants.MetricDecoratedValueAttributeKeys.DEVICE_ID.name(), DeviceInfo.getIdentifier());
              String str = (new AmazonAuthorizationManager(context, null)).getAppId();
              eventClient.addGlobalAttribute(MetricConstants.MetricDecoratedValueAttributeKeys.GAME_ID.name(), str);
              return;
            } catch (Exception exception) {
              Log.w(AmazonInsightsEventCollector.TAG, "Unexpected error occurred while attempting to add GameID and DeviceID to Insights instance", exception);
              return;
            } 
          }
        }).getEventClient();
    return this.eventClient;
  }
  
  public void pauseInsightsSession() {
    AmazonInsights amazonInsights = AmazonInsights.getInstance(AmazonInsights.newCredentials("M3CGOMO6ILJQ65", "jqyngW96w5vk9a3gLSPP0srNdRpFkRi2+Fjl6qMoPrg="));
    if (amazonInsights != null) {
      amazonInsights.getSessionClient().pauseSession();
      return;
    } 
    Log.w(TAG, "Unable to report Insights session.");
  }
  
  public void reportGenericEvent(GameCircleGenericEvent paramGameCircleGenericEvent) throws EventReportException {
    try {
      Event event = convertToInsightsEvent(paramGameCircleGenericEvent);
      if (event == null) {
        Log.e(TAG, "Conversion to Insights event failed. Will not be reported.");
        return;
      } 
      this.eventClient.recordEvent(event);
      return;
    } catch (Exception exception) {
      throw new EventReportException(exception);
    } 
  }
  
  public void resumeInsightsSession() {
    AmazonInsights amazonInsights = AmazonInsights.getInstance(AmazonInsights.newCredentials("M3CGOMO6ILJQ65", "jqyngW96w5vk9a3gLSPP0srNdRpFkRi2+Fjl6qMoPrg="));
    if (amazonInsights != null) {
      amazonInsights.getSessionClient().resumeSession();
      return;
    } 
    Log.w(TAG, "Unable to report Insights session.");
  }
  
  public void setIsGuest(boolean paramBoolean) {
    this.eventClient.removeGlobalAttribute(MetricConstants.MetricDecoratedValueAttributeKeys.PLAYING_ANONYMOUSLY.name());
    this.eventClient.addGlobalAttribute(MetricConstants.MetricDecoratedValueAttributeKeys.PLAYING_ANONYMOUSLY.name(), Boolean.toString(paramBoolean));
  }
  
  public void setPlayerId(String paramString) {
    this.eventClient.removeGlobalAttribute(MetricConstants.MetricDecoratedValueAttributeKeys.PLAYER_ID.name());
    this.eventClient.addGlobalAttribute(MetricConstants.MetricDecoratedValueAttributeKeys.PLAYER_ID.name(), paramString);
  }
  
  public void submitEvents() throws EventReportException {
    try {
      this.eventClient.submitEvents();
      return;
    } catch (Exception exception) {
      throw new EventReportException(exception);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\metrics\AmazonInsightsEventCollector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */