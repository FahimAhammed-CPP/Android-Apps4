package com.amazon.ags.client.metrics;

public class EventReportException extends Exception {
  private static final long serialVersionUID = 1L;
  
  public EventReportException() {}
  
  public EventReportException(String paramString) {
    super(paramString);
  }
  
  public EventReportException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public EventReportException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\metrics\EventReportException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */