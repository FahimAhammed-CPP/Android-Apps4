package com.amazon.ags.client.metrics.events;

import com.amazon.ags.client.metrics.IllegalConstructionException;
import com.amazon.ags.constants.metrics.MetricConstants;
import java.util.HashMap;
import java.util.Map;

public class GameCircleGenericEvent {
  private static final String TAG = "GC_" + GameCircleGenericEvent.class.getSimpleName();
  
  public static String packageName;
  
  private Map<String, String> attributes = new HashMap<String, String>();
  
  private Map<String, Integer> countMetrics = new HashMap<String, Integer>();
  
  private String eventName;
  
  private Map<String, Long> timeMetrics = new HashMap<String, Long>();
  
  public GameCircleGenericEvent(String paramString, Map<String, String> paramMap, Map<String, Integer> paramMap1, Map<String, Long> paramMap2) throws IllegalConstructionException {
    if (paramString == null)
      throw new IllegalConstructionException("EventName is empty. This event cannot be constructed."); 
    this.eventName = paramString;
    if (paramMap != null) {
      this.attributes.putAll(paramMap);
      if (packageName != null)
        this.attributes.put(MetricConstants.MetricStringValueAttributesKeys.INSTALLER_PACKAGE_NAME.name(), packageName); 
    } 
    if (paramMap1 != null)
      this.countMetrics.putAll(paramMap1); 
    if (paramMap2 != null)
      this.timeMetrics.putAll(paramMap2); 
  }
  
  public Map<String, String> getAttributes() {
    return this.attributes;
  }
  
  public Map<String, Integer> getCountMetrics() {
    return this.countMetrics;
  }
  
  public String getEventName() {
    return this.eventName;
  }
  
  public Map<String, Long> getTimeMetrics() {
    return this.timeMetrics;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\metrics\events\GameCircleGenericEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */