package com.amazon.ags.client.metrics;

import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;

public interface EventCollector {
  void pauseInsightsSession();
  
  void reportGenericEvent(GameCircleGenericEvent paramGameCircleGenericEvent) throws EventReportException;
  
  void resumeInsightsSession();
  
  void setIsGuest(boolean paramBoolean);
  
  void setPlayerId(String paramString);
  
  void submitEvents() throws EventReportException;
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\metrics\EventCollector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */