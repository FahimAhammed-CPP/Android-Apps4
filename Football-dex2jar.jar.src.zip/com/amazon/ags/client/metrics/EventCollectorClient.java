package com.amazon.ags.client.metrics;

import android.content.Context;
import android.util.Log;
import com.amazon.ags.VersionInfo;
import com.amazon.ags.auth.AuthManager;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.constants.metrics.MetricConstants;
import com.amazon.ags.html5.content.ContentVersion;
import com.amazon.ags.html5.util.DeviceInfo;
import com.amazon.ags.html5.util.GlobalState;
import java.util.Map;

public class EventCollectorClient implements GlobalState.GlobalStateListener {
  private static final String TAG = "GC_" + EventCollectorClient.class.getSimpleName();
  
  private static EventCollectorClient instance = null;
  
  private AuthManager authManager;
  
  private ContentVersion contentVersion;
  
  private DeviceInfo deviceInfo;
  
  private EventCollector eventCollector;
  
  private GlobalState globalState;
  
  private EventCollectorClient(Context paramContext) {
    try {
      this.eventCollector = new AmazonInsightsEventCollector(paramContext);
      return;
    } catch (IllegalConstructionException illegalConstructionException) {
      Log.w(TAG, "Unable to create metrics collector. Reporting events will not work.", illegalConstructionException);
      return;
    } 
  }
  
  public EventCollectorClient(EventCollector paramEventCollector, GlobalState paramGlobalState, AuthManager paramAuthManager, ContentVersion paramContentVersion, DeviceInfo paramDeviceInfo) {
    this.eventCollector = paramEventCollector;
    this.authManager = paramAuthManager;
    this.globalState = paramGlobalState;
    this.deviceInfo = paramDeviceInfo;
    this.contentVersion = paramContentVersion;
  }
  
  private void addGlobalStateAttributes(GameCircleGenericEvent paramGameCircleGenericEvent) {
    Map<String, String> map = paramGameCircleGenericEvent.getAttributes();
    if (this.globalState != null) {
      this.eventCollector.setPlayerId(this.globalState.getPlayerId());
      this.eventCollector.setIsGuest(this.globalState.isGuestMode());
      map.put(MetricConstants.MetricDecoratedValueAttributeKeys.PLAYER_ID.name(), this.globalState.getPlayerId());
      map.put(MetricConstants.MetricDecoratedValueAttributeKeys.PLAYING_ANONYMOUSLY.name(), Boolean.toString(this.globalState.isGuestMode()));
      map.put(MetricConstants.MetricDecoratedValueAttributeKeys.HIDDEN.name(), this.globalState.isHidden().toString());
      map.put(MetricConstants.MetricDecoratedValueAttributeKeys.COUNTRY_SUPPORT.name(), this.globalState.getCountrySupport());
    } 
    if (this.authManager != null)
      map.put(MetricConstants.MetricDecoratedValueAttributeKeys.GAME_ID.name(), this.authManager.getGameId()); 
    if (this.contentVersion != null)
      map.put(MetricConstants.MetricDecoratedValueAttributeKeys.JAVASCRIPT_VERSION.name(), this.contentVersion.getVersion()); 
    if (this.deviceInfo != null)
      map.put(MetricConstants.MetricDecoratedValueAttributeKeys.PLATFORM.name(), this.deviceInfo.getDeviceType()); 
    map.put(MetricConstants.MetricDecoratedValueAttributeKeys.DEVICE_ID.name(), DeviceInfo.getIdentifier());
    map.put(MetricConstants.MetricDecoratedValueAttributeKeys.DEVICE_MANUFACTURER.name(), DeviceInfo.getManufacturer());
    map.put(MetricConstants.MetricDecoratedValueAttributeKeys.DEVICE_MODEL.name(), DeviceInfo.getModel());
    map.put(MetricConstants.MetricDecoratedValueAttributeKeys.NATIVE_VERSION.name(), VersionInfo.getSDKVersion().getVersion());
  }
  
  public static EventCollectorClient getInstance() {
    // Byte code:
    //   0: ldc com/amazon/ags/client/metrics/EventCollectorClient
    //   2: monitorenter
    //   3: getstatic com/amazon/ags/client/metrics/EventCollectorClient.instance : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   6: ifnonnull -> 34
    //   9: getstatic com/amazon/ags/client/metrics/EventCollectorClient.TAG : Ljava/lang/String;
    //   12: ldc 'EventCollectorClient must be initialized before using'
    //   14: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: new java/lang/IllegalAccessError
    //   21: dup
    //   22: ldc 'EventCollectorClient must be initialized before using'
    //   24: invokespecial <init> : (Ljava/lang/String;)V
    //   27: athrow
    //   28: astore_0
    //   29: ldc com/amazon/ags/client/metrics/EventCollectorClient
    //   31: monitorexit
    //   32: aload_0
    //   33: athrow
    //   34: getstatic com/amazon/ags/client/metrics/EventCollectorClient.instance : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   37: astore_0
    //   38: ldc com/amazon/ags/client/metrics/EventCollectorClient
    //   40: monitorexit
    //   41: aload_0
    //   42: areturn
    // Exception table:
    //   from	to	target	type
    //   3	28	28	finally
    //   34	38	28	finally
  }
  
  public static EventCollectorClient initialize(Context paramContext) {
    // Byte code:
    //   0: ldc com/amazon/ags/client/metrics/EventCollectorClient
    //   2: monitorenter
    //   3: getstatic com/amazon/ags/client/metrics/EventCollectorClient.instance : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   6: ifnull -> 27
    //   9: getstatic com/amazon/ags/client/metrics/EventCollectorClient.TAG : Ljava/lang/String;
    //   12: ldc 'EventCollectorClient already initialized.'
    //   14: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: getstatic com/amazon/ags/client/metrics/EventCollectorClient.instance : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   21: astore_0
    //   22: ldc com/amazon/ags/client/metrics/EventCollectorClient
    //   24: monitorexit
    //   25: aload_0
    //   26: areturn
    //   27: new com/amazon/ags/client/metrics/EventCollectorClient
    //   30: dup
    //   31: aload_0
    //   32: invokespecial <init> : (Landroid/content/Context;)V
    //   35: putstatic com/amazon/ags/client/metrics/EventCollectorClient.instance : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   38: goto -> 18
    //   41: astore_0
    //   42: ldc com/amazon/ags/client/metrics/EventCollectorClient
    //   44: monitorexit
    //   45: aload_0
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	41	finally
    //   18	22	41	finally
    //   27	38	41	finally
  }
  
  public boolean isReportingEnabled() {
    return true;
  }
  
  public void notifyIsGuestModeSet(boolean paramBoolean) {
    this.eventCollector.setIsGuest(paramBoolean);
  }
  
  public void notifyPlayerIdSet(String paramString) {
    this.eventCollector.setPlayerId(paramString);
  }
  
  public void notifyStateSet(String paramString1, String paramString2) {}
  
  public void pauseInsightsSession() {
    this.eventCollector.pauseInsightsSession();
  }
  
  public void reportGenericEvent(GameCircleGenericEvent paramGameCircleGenericEvent) {
    if (this.eventCollector == null) {
      Log.w(TAG, "Null Event Collector in Client");
      return;
    } 
    try {
      if (isReportingEnabled()) {
        addGlobalStateAttributes(paramGameCircleGenericEvent);
        this.eventCollector.reportGenericEvent(paramGameCircleGenericEvent);
        return;
      } 
      return;
    } catch (Exception exception) {
      Log.w(TAG, "Cannot report event.", exception);
      return;
    } 
  }
  
  public void resumeInsightsSession() {
    this.eventCollector.resumeInsightsSession();
  }
  
  public void setAuthManager(AuthManager paramAuthManager) {
    if (paramAuthManager != null)
      this.authManager = paramAuthManager; 
  }
  
  public void setContentVersion(ContentVersion paramContentVersion) {
    if (paramContentVersion != null)
      this.contentVersion = paramContentVersion; 
  }
  
  public void setDeviceInfo(DeviceInfo paramDeviceInfo) {
    if (paramDeviceInfo != null)
      this.deviceInfo = paramDeviceInfo; 
  }
  
  public void setGlobalState(GlobalState paramGlobalState) {
    if (paramGlobalState != null) {
      this.globalState = paramGlobalState;
      this.eventCollector.setPlayerId(paramGlobalState.getPlayerId());
      this.eventCollector.setIsGuest(paramGlobalState.isGuestMode());
    } 
  }
  
  public void submitEvents() {
    if (this.eventCollector == null) {
      Log.w(TAG, "Null Event Collector in Client");
      return;
    } 
    try {
      if (isReportingEnabled()) {
        this.eventCollector.submitEvents();
        return;
      } 
      return;
    } catch (Exception exception) {
      Log.w(TAG, "Cannot submit events.", exception);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\metrics\EventCollectorClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */