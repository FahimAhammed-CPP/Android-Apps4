package com.amazon.ags.client;

public enum KindleFireStatus {
  CANNOT_AUTHORIZE, INITIALIZING, NOT_AUTHORIZED, NOT_REGISTERED, SERVICE_CONNECTED, SERVICE_DISCONNECTED, UNIVERSAL_NOT_SUPPORTED;
  
  static {
    CANNOT_AUTHORIZE = new KindleFireStatus("CANNOT_AUTHORIZE", 4);
    NOT_AUTHORIZED = new KindleFireStatus("NOT_AUTHORIZED", 5);
    NOT_REGISTERED = new KindleFireStatus("NOT_REGISTERED", 6);
    $VALUES = new KindleFireStatus[] { INITIALIZING, SERVICE_CONNECTED, SERVICE_DISCONNECTED, UNIVERSAL_NOT_SUPPORTED, CANNOT_AUTHORIZE, NOT_AUTHORIZED, NOT_REGISTERED };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\KindleFireStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */