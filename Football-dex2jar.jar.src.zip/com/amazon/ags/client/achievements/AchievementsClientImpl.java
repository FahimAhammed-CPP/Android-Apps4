package com.amazon.ags.client.achievements;

import android.util.Log;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.achievements.Achievement;
import com.amazon.ags.api.achievements.AchievementsClient;
import com.amazon.ags.api.achievements.GetAchievementResponse;
import com.amazon.ags.api.achievements.GetAchievementsResponse;
import com.amazon.ags.api.achievements.UpdateProgressResponse;
import com.amazon.ags.client.AGResponseHandleImpl;
import com.amazon.ags.client.ClientBase;
import com.amazon.ags.client.OverlayClient;
import com.amazon.ags.client.RequestResponseImpl;
import com.amazon.ags.html5.service.ServiceHelper;
import java.util.ArrayList;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AchievementsClientImpl extends ClientBase implements AchievementsClient {
  private OverlayClient overlayClient;
  
  public AchievementsClientImpl() {}
  
  public AchievementsClientImpl(ServiceHelper paramServiceHelper, OverlayClient paramOverlayClient) {
    super(paramServiceHelper);
    this.overlayClient = paramOverlayClient;
  }
  
  public static Achievement convertToAchievement(JSONObject paramJSONObject) throws JSONException {
    String str1 = paramJSONObject.getString("ACHIEVEMENT_ID");
    String str2 = paramJSONObject.getString("ACHIEVEMENT_TITLE");
    String str3 = paramJSONObject.getString("ACHIEVEMENT_DESCRIPTION");
    int i = paramJSONObject.getInt("ACHIEVEMENT_POINTS");
    boolean bool1 = paramJSONObject.getBoolean("ACHIEVEMENT_HIDDEN");
    boolean bool2 = paramJSONObject.getBoolean("ACHIEVEMENT_UNLOCKED");
    float f = (float)paramJSONObject.getDouble("ACHIEVEMENT_UPDATE_PERCENT");
    int j = paramJSONObject.getInt("ACHIEVEMENT_POSITION");
    long l = paramJSONObject.getLong("ACHIEVEMENT_DATE_UNLOCKED");
    String str4 = paramJSONObject.optString("ACHIEVEMENT_ICON_URL_LARGE", null);
    if (!bool2 || l == 0L) {
      paramJSONObject = null;
      return new AchievementImpl(str1, str2, str3, i, bool1, bool2, f, j, (Date)paramJSONObject, str4);
    } 
    Date date = new Date(l);
    return new AchievementImpl(str1, str2, str3, i, bool1, bool2, f, j, date, str4);
  }
  
  public AGResponseHandle<GetAchievementResponse> getAchievement(String paramString, Object... paramVarArgs) {
    return getAchievementForPlayer(paramString, "SELF", paramVarArgs);
  }
  
  public AGResponseHandle<GetAchievementResponse> getAchievementForPlayer(String paramString1, final String playerId, Object... paramVarArgs) {
    final AGResponseHandleImpl achievementId;
    if (!isClientReady()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new GetAchievementResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "getAchievement called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<GetAchievementResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<GetAchievementResponse>("Get Achievement") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 12);
          jSONObject.put("ACHIEVEMENT_ID", achievementId);
          jSONObject.put("playerId", playerId);
          return jSONObject;
        }
        
        public GetAchievementResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int i = param1JSONObject.getInt("RESPONSE_CODE");
          return new GetAchievementResponseImpl(AchievementsClientImpl.convertToAchievement(param1JSONObject), i);
        }
        
        public GetAchievementResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new GetAchievementResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(paramVarArgs);
  }
  
  public AGResponseHandle<GetAchievementsResponse> getAchievements(Object... paramVarArgs) {
    return getAchievementsForPlayer("SELF", paramVarArgs);
  }
  
  public AGResponseHandle<GetAchievementsResponse> getAchievementsForPlayer(String paramString, Object... paramVarArgs) {
    final AGResponseHandleImpl playerId;
    if (!isClientReady()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new GetAchievementsResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "getAchievements called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<GetAchievementsResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<GetAchievementsResponse>("Get Achievements") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 17);
          jSONObject.put("playerId", playerId);
          return jSONObject;
        }
        
        public GetAchievementsResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int j = param1JSONObject.getInt("RESPONSE_CODE");
          JSONArray jSONArray = param1JSONObject.getJSONArray("ACHIEVEMENTS");
          ArrayList<Achievement> arrayList = new ArrayList(jSONArray.length());
          for (int i = 0; i < jSONArray.length(); i++) {
            Object object = jSONArray.get(i);
            if (object instanceof JSONObject)
              arrayList.add(AchievementsClientImpl.convertToAchievement((JSONObject)object)); 
          } 
          return new GetAchievementsResponseImpl(arrayList, j);
        }
        
        public GetAchievementsResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new GetAchievementsResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(paramVarArgs);
  }
  
  public void setOverlayClient(OverlayClient paramOverlayClient) {
    this.overlayClient = paramOverlayClient;
  }
  
  public AGResponseHandle<RequestResponse> showAchievementsOverlay(Object... paramVarArgs) {
    AGResponseHandleImpl aGResponseHandleImpl;
    if (this.overlayClient == null) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new RequestResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "showAchievementsOverlay called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<RequestResponse>)aGResponseHandleImpl;
    } 
    return this.overlayClient.showAchievementsOverlay((Object[])aGResponseHandleImpl);
  }
  
  public void shutdown() {
    this.isReady = false;
    this.overlayClient = null;
  }
  
  public AGResponseHandle<UpdateProgressResponse> updateProgress(String paramString, final float percentComplete, Object... paramVarArgs) {
    final AGResponseHandleImpl achievementId;
    if (!isClientReady()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new UpdateProgressResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "updateProgress called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<UpdateProgressResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<UpdateProgressResponse>("Update Achievement Progress") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 13);
          jSONObject.put("ACHIEVEMENT_ID", achievementId);
          jSONObject.put("ACHIEVEMENT_UPDATE_PERCENT", percentComplete);
          return jSONObject;
        }
        
        public UpdateProgressResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int i = param1JSONObject.getInt("RESPONSE_CODE");
          return new UpdateProgressResponseImpl(param1JSONObject.getBoolean("ACHIEVEMENT_NEWLY_UNLOCKED"), i);
        }
        
        public UpdateProgressResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new UpdateProgressResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(paramVarArgs);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\achievements\AchievementsClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */