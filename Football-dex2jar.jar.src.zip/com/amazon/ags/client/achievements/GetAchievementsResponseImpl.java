package com.amazon.ags.client.achievements;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.achievements.Achievement;
import com.amazon.ags.api.achievements.GetAchievementsResponse;
import com.amazon.ags.client.RequestResponseImpl;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetAchievementsResponseImpl extends RequestResponseImpl implements GetAchievementsResponse {
  private List<Achievement> achievements = null;
  
  private Map<String, Achievement> achievementsMap = null;
  
  public GetAchievementsResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public GetAchievementsResponseImpl(List<Achievement> paramList, int paramInt) {
    super(paramInt);
    this.achievements = paramList;
  }
  
  public final List<Achievement> getAchievementsList() {
    return this.achievements;
  }
  
  public final Map<String, Achievement> getAchievementsMap() {
    if (this.achievements == null)
      return null; 
    if (this.achievementsMap == null) {
      this.achievementsMap = new HashMap<String, Achievement>();
      for (Achievement achievement : this.achievements)
        this.achievementsMap.put(achievement.getId(), achievement); 
    } 
    return this.achievementsMap;
  }
  
  public final int getEventType() {
    return 17;
  }
  
  public final int getNumVisibleAchievements() {
    return (this.achievements != null) ? this.achievements.size() : 0;
  }
  
  public final String toString() {
    String str = super.toString();
    return str + "\n Number of AchievementsClient Returned: " + getNumVisibleAchievements();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\achievements\GetAchievementsResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */