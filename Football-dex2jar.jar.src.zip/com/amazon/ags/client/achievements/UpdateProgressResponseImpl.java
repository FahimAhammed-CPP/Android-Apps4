package com.amazon.ags.client.achievements;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.achievements.UpdateProgressResponse;
import com.amazon.ags.client.RequestResponseImpl;

public class UpdateProgressResponseImpl extends RequestResponseImpl implements UpdateProgressResponse {
  private final boolean isNewlyUnlocked = false;
  
  public UpdateProgressResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public UpdateProgressResponseImpl(boolean paramBoolean, int paramInt) {
    super(paramInt);
  }
  
  public boolean isNewlyUnlocked() {
    return this.isNewlyUnlocked;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\achievements\UpdateProgressResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */