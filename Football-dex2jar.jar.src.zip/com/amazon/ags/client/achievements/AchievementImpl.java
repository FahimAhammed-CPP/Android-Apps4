package com.amazon.ags.client.achievements;

import android.util.Log;
import com.amazon.ags.api.achievements.Achievement;
import java.util.Date;

public class AchievementImpl implements Achievement {
  private static final String FEATURE_NAME = "AC";
  
  private static final String TAG = "AC_" + AchievementImpl.class.getSimpleName();
  
  private final Date dateUnlocked;
  
  private final String description;
  
  private final boolean hidden;
  
  private final String id;
  
  private final String imageURL;
  
  private final int pointValue;
  
  private final int position;
  
  private final float progress;
  
  private final String title;
  
  private final boolean unlocked;
  
  public AchievementImpl(String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, float paramFloat, int paramInt2, Date paramDate, String paramString4) {
    this.id = paramString1;
    this.title = paramString2;
    this.description = paramString3;
    this.pointValue = paramInt1;
    this.hidden = paramBoolean1;
    this.unlocked = paramBoolean2;
    this.progress = paramFloat;
    this.position = paramInt2;
    this.dateUnlocked = paramDate;
    this.imageURL = paramString4;
  }
  
  public static Achievement copyWithNewProgress(Achievement paramAchievement, float paramFloat) {
    Log.d(TAG, "Copying new achievement from source " + paramAchievement + " with progress " + paramFloat);
    if (paramFloat >= 100.0F) {
      boolean bool1 = true;
      paramFloat = Math.max(paramFloat, 100.0F);
      return new AchievementImpl(paramAchievement.getId(), paramAchievement.getTitle(), paramAchievement.getDescription(), paramAchievement.getPointValue(), paramAchievement.isHidden(), bool1, paramFloat, paramAchievement.getPosition(), paramAchievement.getDateUnlocked(), paramAchievement.getImageURL());
    } 
    boolean bool = false;
    paramFloat = Math.max(paramFloat, 100.0F);
    return new AchievementImpl(paramAchievement.getId(), paramAchievement.getTitle(), paramAchievement.getDescription(), paramAchievement.getPointValue(), paramAchievement.isHidden(), bool, paramFloat, paramAchievement.getPosition(), paramAchievement.getDateUnlocked(), paramAchievement.getImageURL());
  }
  
  public final Date getDateUnlocked() {
    return this.dateUnlocked;
  }
  
  public final String getDescription() {
    return this.description;
  }
  
  public final String getId() {
    return this.id;
  }
  
  public String getImageURL() {
    return this.imageURL;
  }
  
  public final int getPointValue() {
    return this.pointValue;
  }
  
  public final int getPosition() {
    return this.position;
  }
  
  public final float getProgress() {
    return this.progress;
  }
  
  public final String getTitle() {
    return this.title;
  }
  
  public final boolean isHidden() {
    return this.hidden;
  }
  
  public final boolean isUnlocked() {
    return this.unlocked;
  }
  
  public String toString() {
    return "Achievement{id=" + this.id + ", title=" + this.title + ", description=" + this.description + ", pointValue=" + this.pointValue + ", hidden=" + this.hidden + ", unlocked=" + this.unlocked + ", progress=" + this.progress + ", position=" + this.position + ", dateUnlocked=" + this.dateUnlocked + ", imageURL= " + this.imageURL + "}";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\achievements\AchievementImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */