package com.amazon.ags.client.achievements;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.achievements.Achievement;
import com.amazon.ags.api.achievements.GetAchievementResponse;
import com.amazon.ags.client.RequestResponseImpl;

public class GetAchievementResponseImpl extends RequestResponseImpl implements GetAchievementResponse {
  private Achievement achievement = null;
  
  public GetAchievementResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public GetAchievementResponseImpl(Achievement paramAchievement, int paramInt) {
    super(paramInt);
    this.achievement = paramAchievement;
  }
  
  public final Achievement getAchievement() {
    return this.achievement;
  }
  
  public final int getEventType() {
    return 12;
  }
  
  public final String toString() {
    return super.toString() + "\n Achievement - " + this.achievement;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\achievements\GetAchievementResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */