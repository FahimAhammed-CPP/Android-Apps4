package com.amazon.ags.client.whispersync;

import android.util.Log;
import com.amazon.ags.api.whispersync.GameDataMap;
import com.amazon.ags.api.whispersync.model.SyncableAccumulatingNumber;
import com.amazon.ags.api.whispersync.model.SyncableDeveloperString;
import com.amazon.ags.api.whispersync.model.SyncableNumber;
import com.amazon.ags.api.whispersync.model.SyncableNumberList;
import com.amazon.ags.api.whispersync.model.SyncableString;
import com.amazon.ags.api.whispersync.model.SyncableStringList;
import com.amazon.ags.api.whispersync.model.SyncableStringSet;
import com.amazon.ags.client.whispersync.model.AccumulatingNumber;
import com.amazon.ags.client.whispersync.model.DeveloperString;
import com.amazon.ags.client.whispersync.model.HighNumberList;
import com.amazon.ags.client.whispersync.model.HighestNumber;
import com.amazon.ags.client.whispersync.model.Key;
import com.amazon.ags.client.whispersync.model.LatestNumber;
import com.amazon.ags.client.whispersync.model.LatestNumberList;
import com.amazon.ags.client.whispersync.model.LatestString;
import com.amazon.ags.client.whispersync.model.LatestStringList;
import com.amazon.ags.client.whispersync.model.LowNumberList;
import com.amazon.ags.client.whispersync.model.LowestNumber;
import com.amazon.ags.client.whispersync.model.Mergeable;
import com.amazon.ags.client.whispersync.model.StringSet;
import com.amazon.ags.client.whispersync.model.SyncState;
import com.amazon.ags.client.whispersync.model.SyncableType;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class GameDataSingleMap implements InternalGameDataMap {
  private static final String TAG = "GC_Whispersync";
  
  private final Map<Key, Mergeable<?>> gameDataMap = new HashMap<Key, Mergeable<?>>();
  
  private final String name = null;
  
  public GameDataSingleMap() {}
  
  public GameDataSingleMap(String paramString) {}
  
  private Set<String> getKeysByType(SyncableType paramSyncableType) {
    HashSet<String> hashSet = new HashSet();
    for (Key key : this.gameDataMap.keySet()) {
      if (key.getType() == paramSyncableType && ((Mergeable)this.gameDataMap.get(key)).getState() != SyncState.NOT_SET)
        hashSet.add(key.getName()); 
    } 
    return hashSet;
  }
  
  private void mergeLocked(InternalGameDataMap paramInternalGameDataMap) {
    if (paramInternalGameDataMap == null || paramInternalGameDataMap.getAllElements() == null || paramInternalGameDataMap.getAllElements().isEmpty()) {
      Log.w("GC_Whispersync", "GameDataMap - Unable to merge from an invalid/unset GameDataMap " + paramInternalGameDataMap);
      return;
    } 
    Iterator<Map.Entry> iterator = paramInternalGameDataMap.getAllElements().entrySet().iterator();
    while (true) {
      if (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        Mergeable mergeable = this.gameDataMap.get(entry.getKey());
        if (mergeable == null) {
          this.gameDataMap.put((Key)entry.getKey(), (Mergeable<?>)entry.getValue());
          continue;
        } 
        mergeable.merge((Mergeable)entry.getValue());
        continue;
      } 
      return;
    } 
  }
  
  public void completeSyncing() {
    GameDataLock.lock();
    try {
      Iterator<Mergeable> iterator = this.gameDataMap.values().iterator();
    } finally {
      GameDataLock.unlock();
    } 
    GameDataLock.unlock();
  }
  
  public GameDataSingleMap deepCopy() {
    Log.v("GC_Whispersync", "GameDataMap - Deep copy of GameDataMap with name: " + this.name);
    GameDataSingleMap gameDataSingleMap = new GameDataSingleMap();
    for (Map.Entry<Key, Mergeable<?>> entry : this.gameDataMap.entrySet())
      gameDataSingleMap.gameDataMap.put((Key)entry.getKey(), ((Mergeable)entry.getValue()).deepCopy()); 
    return gameDataSingleMap;
  }
  
  public SyncableAccumulatingNumber getAccumulatingNumber(String paramString) {
    Key key = new Key(SyncableType.ACCUMULATING_NUMBER, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new AccumulatingNumber(paramString)); 
      return (SyncableAccumulatingNumber)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getAccumulatingNumberKeys() {
    return getKeysByType(SyncableType.ACCUMULATING_NUMBER);
  }
  
  public Map<Key, Mergeable<?>> getAllElements() {
    return Collections.unmodifiableMap(this.gameDataMap);
  }
  
  public SyncableDeveloperString getDeveloperString(String paramString) {
    Key key = new Key(SyncableType.DEVELOPER_STRING, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new DeveloperString(paramString)); 
      return (SyncableDeveloperString)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getDeveloperStringKeys() {
    return getKeysByType(SyncableType.DEVELOPER_STRING);
  }
  
  public SyncableNumberList getHighNumberList(String paramString) {
    Key key = new Key(SyncableType.HIGHEST_NUMBER_LIST, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new HighNumberList(paramString)); 
      return (SyncableNumberList)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getHighNumberListKeys() {
    return getKeysByType(SyncableType.HIGHEST_NUMBER_LIST);
  }
  
  public SyncableNumber getHighestNumber(String paramString) {
    Key key = new Key(SyncableType.HIGHEST_NUMBER, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new HighestNumber(paramString)); 
      return (SyncableNumber)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getHighestNumberKeys() {
    return getKeysByType(SyncableType.HIGHEST_NUMBER);
  }
  
  public SyncableNumber getLatestNumber(String paramString) {
    Key key = new Key(SyncableType.LATEST_NUMBER, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new LatestNumber(paramString)); 
      return (SyncableNumber)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getLatestNumberKeys() {
    return getKeysByType(SyncableType.LATEST_NUMBER);
  }
  
  public SyncableNumberList getLatestNumberList(String paramString) {
    Key key = new Key(SyncableType.LATEST_NUMBER_LIST, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new LatestNumberList(paramString)); 
      return (SyncableNumberList)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getLatestNumberListKeys() {
    return getKeysByType(SyncableType.LATEST_NUMBER_LIST);
  }
  
  public SyncableString getLatestString(String paramString) {
    Key key = new Key(SyncableType.LATEST_STRING, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new LatestString(paramString)); 
      return (SyncableString)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getLatestStringKeys() {
    return getKeysByType(SyncableType.LATEST_STRING);
  }
  
  public SyncableStringList getLatestStringList(String paramString) {
    Key key = new Key(SyncableType.LATEST_STRING_LIST, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new LatestStringList(paramString)); 
      return (SyncableStringList)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getLatestStringListKeys() {
    return getKeysByType(SyncableType.LATEST_STRING_LIST);
  }
  
  public SyncableNumberList getLowNumberList(String paramString) {
    Key key = new Key(SyncableType.LOWEST_NUMBER_LIST, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new LowNumberList(paramString)); 
      return (SyncableNumberList)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getLowNumberListKeys() {
    return getKeysByType(SyncableType.LOWEST_NUMBER_LIST);
  }
  
  public SyncableNumber getLowestNumber(String paramString) {
    Key key = new Key(SyncableType.LOWEST_NUMBER, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new LowestNumber(paramString)); 
      return (SyncableNumber)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getLowestNumberKeys() {
    return getKeysByType(SyncableType.LOWEST_NUMBER);
  }
  
  public GameDataMap getMap(String paramString) {
    Key key = new Key(SyncableType.MAP, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new GameDataSingleMap(paramString)); 
      return (GameDataMap)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getMapKeys() {
    return getKeysByType(SyncableType.MAP);
  }
  
  public SyncState getState() {
    SyncState syncState = SyncState.NOT_SET;
    Iterator<Mergeable> iterator = this.gameDataMap.values().iterator();
    while (true) {
      SyncState syncState1 = syncState;
      if (iterator.hasNext()) {
        Mergeable mergeable = iterator.next();
        if (mergeable.getState() == SyncState.DIRTY)
          return SyncState.DIRTY; 
      } else {
        return syncState1;
      } 
      if (syncState1.getState() == SyncState.SYNCING) {
        syncState = SyncState.SYNCING;
        continue;
      } 
      if (syncState1.getState() == SyncState.SYNCED && syncState == SyncState.NOT_SET)
        syncState = SyncState.SYNCED; 
    } 
  }
  
  public SyncableStringSet getStringSet(String paramString) {
    Key key = new Key(SyncableType.STRING_SET, paramString);
    GameDataLock.lock();
    try {
      if (!this.gameDataMap.containsKey(key))
        this.gameDataMap.put(key, new StringSet(paramString)); 
      return (SyncableStringSet)this.gameDataMap.get(key);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Set<String> getStringSetKeys() {
    return getKeysByType(SyncableType.STRING_SET);
  }
  
  public InternalGameDataMap lockAndCopy() {
    long l = System.currentTimeMillis();
    GameDataLock.lock();
    try {
      GameDataSingleMap gameDataSingleMap = deepCopy();
      GameDataLock.unlock();
      long l1 = System.currentTimeMillis();
      return gameDataSingleMap;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public void merge(InternalGameDataMap paramInternalGameDataMap) {
    GameDataLock.lock();
    try {
      mergeLocked(paramInternalGameDataMap);
      return;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public void putElement(Key paramKey, Mergeable<?> paramMergeable) {
    this.gameDataMap.put(paramKey, paramMergeable);
  }
  
  public int size() {
    return this.gameDataMap.size();
  }
  
  public void startSyncing() {
    GameDataLock.lock();
    try {
      Iterator<Mergeable> iterator = this.gameDataMap.values().iterator();
    } finally {
      GameDataLock.unlock();
    } 
    GameDataLock.unlock();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\GameDataSingleMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */