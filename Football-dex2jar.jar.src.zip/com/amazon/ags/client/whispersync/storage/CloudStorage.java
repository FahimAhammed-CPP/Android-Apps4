package com.amazon.ags.client.whispersync.storage;

import android.util.Log;
import com.amazon.ags.AGSClientException;
import com.amazon.ags.AGSServiceException;
import com.amazon.ags.client.whispersync.InternalGameDataMap;
import com.amazon.ags.client.whispersync.clock.GameDataServiceSyncedClock;
import com.amazon.ags.client.whispersync.marshaller.GameDataMarshaller;
import com.amazon.ags.client.whispersync.network.WhispersyncHttpClient;
import com.amazon.ags.client.whispersync.network.WhispersyncRequest;
import com.amazon.ags.client.whispersync.network.WhispersyncResponse;
import com.amazon.ags.html5.comm.ConnectionException;

public class CloudStorage implements RemoteStorage {
  private static final String TAG = "GC_Whispersync";
  
  private final GameDataMarshaller marshaller;
  
  private final GameDataServiceSyncedClock serviceSyncedClock;
  
  private final WhispersyncHttpClient whispersyncHttpClient;
  
  public CloudStorage(WhispersyncHttpClient paramWhispersyncHttpClient, GameDataMarshaller paramGameDataMarshaller, GameDataServiceSyncedClock paramGameDataServiceSyncedClock) {
    this.whispersyncHttpClient = paramWhispersyncHttpClient;
    this.marshaller = paramGameDataMarshaller;
    this.serviceSyncedClock = paramGameDataServiceSyncedClock;
  }
  
  public GameData retrieve(String paramString) throws AGSClientException, AGSServiceException, ConnectionException {
    InternalGameDataMap internalGameDataMap;
    WhispersyncResponse whispersyncResponse = this.whispersyncHttpClient.getWhisperData(paramString);
    String str2 = whispersyncResponse.getDocument();
    String str1 = whispersyncResponse.getVersionId();
    this.serviceSyncedClock.synchronizeClock(whispersyncResponse.getDate());
    whispersyncResponse = null;
    if (str2 != null) {
      Log.d("GC_Whispersync", "Received document [" + str2 + "] from the service, calling the marshaller");
      internalGameDataMap = this.marshaller.parse(str2);
      Log.d("GC_Whispersync", "Finished retrieving Whispersync data from the cloud");
      return new GameData(internalGameDataMap, str1);
    } 
    Log.d("GC_Whispersync", "Received an empty document from the service");
    Log.d("GC_Whispersync", "Finished retrieving Whispersync data from the cloud");
    return new GameData(internalGameDataMap, str1);
  }
  
  public GameData save(GameData paramGameData) throws AGSClientException, AGSServiceException, ConnectionException {
    InternalGameDataMap internalGameDataMap;
    String str1 = this.marshaller.composeForService(paramGameData.getGameDataMap());
    Log.v("GC_Whispersync", "Uploading document to cloud: [" + str1 + "]");
    WhispersyncRequest whispersyncRequest = new WhispersyncRequest(str1, paramGameData.getVersionId());
    WhispersyncResponse whispersyncResponse = this.whispersyncHttpClient.postWhisperData(whispersyncRequest);
    this.serviceSyncedClock.synchronizeClock(whispersyncResponse.getDate());
    String str2 = whispersyncResponse.getDocument();
    whispersyncRequest = null;
    if (str2 != null)
      internalGameDataMap = this.marshaller.parse(str2); 
    return new GameData(internalGameDataMap, whispersyncResponse.getVersionId());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\storage\CloudStorage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */