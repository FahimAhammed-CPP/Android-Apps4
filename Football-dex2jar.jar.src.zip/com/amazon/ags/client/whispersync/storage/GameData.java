package com.amazon.ags.client.whispersync.storage;

import com.amazon.ags.client.whispersync.InternalGameDataMap;

public class GameData {
  private InternalGameDataMap gameDataMap;
  
  private String versionId;
  
  public GameData(InternalGameDataMap paramInternalGameDataMap, String paramString) {
    this.gameDataMap = paramInternalGameDataMap;
    this.versionId = paramString;
  }
  
  public InternalGameDataMap getGameDataMap() {
    return this.gameDataMap;
  }
  
  public String getVersionId() {
    return this.versionId;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\storage\GameData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */