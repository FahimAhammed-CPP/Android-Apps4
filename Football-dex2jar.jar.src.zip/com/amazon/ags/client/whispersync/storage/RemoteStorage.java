package com.amazon.ags.client.whispersync.storage;

import com.amazon.ags.AGSClientException;
import com.amazon.ags.AGSServiceException;
import com.amazon.ags.html5.comm.ConnectionException;

public interface RemoteStorage {
  GameData retrieve(String paramString) throws AGSClientException, AGSServiceException, ConnectionException;
  
  GameData save(GameData paramGameData) throws AGSClientException, AGSServiceException, ConnectionException;
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\storage\RemoteStorage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */