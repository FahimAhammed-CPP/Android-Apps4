package com.amazon.ags.client.whispersync.storage;

import android.content.Context;
import android.util.Log;
import com.amazon.ags.AGSClientException;
import com.amazon.ags.client.whispersync.InternalGameDataMap;
import com.amazon.ags.client.whispersync.marshaller.GameDataMarshaller;
import com.amazon.ags.storage.StringObfuscator;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class DiskStorage implements LocalStorage {
  public static final String AMAZON_GAMES_DIR_NAME = ".amazonGamesService";
  
  private static final String BACKUP_FILE_EXTENSION = ".bak";
  
  private static final String GAME_DATA_FILE = "gameData.json";
  
  private static final String TAG = "GC_Whispersync";
  
  private static final String VERSION_INFO_FILE = "latestVersion.txt";
  
  private final Context context;
  
  private boolean hasSuccessfullySynchronized;
  
  private final GameDataMarshaller marshaller;
  
  private StringObfuscator stringObfuscator;
  
  public DiskStorage(Context paramContext, GameDataMarshaller paramGameDataMarshaller, StringObfuscator paramStringObfuscator) {
    this.context = paramContext;
    this.marshaller = paramGameDataMarshaller;
    this.stringObfuscator = paramStringObfuscator;
    init();
  }
  
  private File getAmazonGamesDir() {
    File file = new File(this.context.getFilesDir(), ".amazonGamesService");
    file.mkdirs();
    return file;
  }
  
  private void init() {
    this.hasSuccessfullySynchronized = (new File(getAmazonGamesDir(), "latestVersion.txt")).exists();
  }
  
  private byte[] readFromAmazonGamesDir(String paramString) throws IOException {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: new java/lang/StringBuilder
    //   7: dup
    //   8: invokespecial <init> : ()V
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: ldc '.bak'
    //   17: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   20: invokevirtual toString : ()Ljava/lang/String;
    //   23: astore #4
    //   25: new java/io/File
    //   28: dup
    //   29: aload_0
    //   30: invokespecial getAmazonGamesDir : ()Ljava/io/File;
    //   33: aload #4
    //   35: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   38: astore #5
    //   40: new java/io/File
    //   43: dup
    //   44: aload_0
    //   45: invokespecial getAmazonGamesDir : ()Ljava/io/File;
    //   48: aload_1
    //   49: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   52: astore_3
    //   53: aload #5
    //   55: invokevirtual exists : ()Z
    //   58: ifeq -> 161
    //   61: ldc 'GC_Whispersync'
    //   63: new java/lang/StringBuilder
    //   66: dup
    //   67: invokespecial <init> : ()V
    //   70: ldc 'Found backup file ['
    //   72: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   75: aload #4
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: ldc ']. This indicates that saving to ['
    //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: aload_1
    //   86: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   89: ldc '] previously failed.'
    //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: invokevirtual toString : ()Ljava/lang/String;
    //   97: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   100: pop
    //   101: aload_3
    //   102: invokevirtual delete : ()Z
    //   105: pop
    //   106: aload #5
    //   108: aload_3
    //   109: invokevirtual renameTo : (Ljava/io/File;)Z
    //   112: ifne -> 161
    //   115: ldc 'GC_Whispersync'
    //   117: new java/lang/StringBuilder
    //   120: dup
    //   121: invokespecial <init> : ()V
    //   124: ldc 'Couldn't rename backup file ['
    //   126: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   129: aload #5
    //   131: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   134: ldc '] to file ['
    //   136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: aload_3
    //   140: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   143: ldc ']'
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: invokevirtual toString : ()Ljava/lang/String;
    //   151: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   154: pop
    //   155: aload_2
    //   156: astore_1
    //   157: aload_0
    //   158: monitorexit
    //   159: aload_1
    //   160: areturn
    //   161: aload_2
    //   162: astore_1
    //   163: aload_3
    //   164: invokevirtual exists : ()Z
    //   167: ifeq -> 157
    //   170: new java/io/RandomAccessFile
    //   173: dup
    //   174: aload_3
    //   175: ldc 'r'
    //   177: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   180: astore_2
    //   181: aload_2
    //   182: invokevirtual length : ()J
    //   185: l2i
    //   186: newarray byte
    //   188: astore_1
    //   189: aload_2
    //   190: aload_1
    //   191: invokevirtual readFully : ([B)V
    //   194: aload_2
    //   195: invokevirtual close : ()V
    //   198: goto -> 157
    //   201: astore_2
    //   202: goto -> 157
    //   205: astore_1
    //   206: aload_2
    //   207: invokevirtual close : ()V
    //   210: aload_1
    //   211: athrow
    //   212: astore_1
    //   213: aload_0
    //   214: monitorexit
    //   215: aload_1
    //   216: athrow
    //   217: astore_2
    //   218: goto -> 210
    // Exception table:
    //   from	to	target	type
    //   4	155	212	finally
    //   163	181	212	finally
    //   181	194	205	finally
    //   194	198	201	java/io/IOException
    //   194	198	212	finally
    //   206	210	217	java/io/IOException
    //   206	210	212	finally
    //   210	212	212	finally
  }
  
  private void writeToAmazonGamesDir(String paramString, byte[] paramArrayOfbyte) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/lang/StringBuilder
    //   5: dup
    //   6: invokespecial <init> : ()V
    //   9: aload_1
    //   10: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   13: ldc '.bak'
    //   15: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   18: invokevirtual toString : ()Ljava/lang/String;
    //   21: astore #4
    //   23: new java/io/File
    //   26: dup
    //   27: aload_0
    //   28: invokespecial getAmazonGamesDir : ()Ljava/io/File;
    //   31: aload #4
    //   33: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   36: astore #5
    //   38: new java/io/File
    //   41: dup
    //   42: aload_0
    //   43: invokespecial getAmazonGamesDir : ()Ljava/io/File;
    //   46: aload_1
    //   47: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   50: astore_3
    //   51: aload_3
    //   52: invokevirtual exists : ()Z
    //   55: ifeq -> 163
    //   58: aload #5
    //   60: invokevirtual exists : ()Z
    //   63: ifne -> 118
    //   66: aload_3
    //   67: aload #5
    //   69: invokevirtual renameTo : (Ljava/io/File;)Z
    //   72: ifne -> 163
    //   75: ldc 'GC_Whispersync'
    //   77: new java/lang/StringBuilder
    //   80: dup
    //   81: invokespecial <init> : ()V
    //   84: ldc 'Couldn't rename file ['
    //   86: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   89: aload_3
    //   90: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   93: ldc '] to backup file ['
    //   95: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: aload #5
    //   100: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   103: ldc ']'
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: invokevirtual toString : ()Ljava/lang/String;
    //   111: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   114: pop
    //   115: aload_0
    //   116: monitorexit
    //   117: return
    //   118: ldc 'GC_Whispersync'
    //   120: new java/lang/StringBuilder
    //   123: dup
    //   124: invokespecial <init> : ()V
    //   127: ldc 'Found backup file ['
    //   129: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   132: aload #4
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: ldc ']. This indicates that saving to ['
    //   139: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   142: aload_1
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: ldc '] previously failed.'
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: invokevirtual toString : ()Ljava/lang/String;
    //   154: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   157: pop
    //   158: aload_3
    //   159: invokevirtual delete : ()Z
    //   162: pop
    //   163: aload_0
    //   164: aload_3
    //   165: aload_2
    //   166: invokevirtual writeDataToFile : (Ljava/io/File;[B)V
    //   169: aload #5
    //   171: invokevirtual delete : ()Z
    //   174: pop
    //   175: goto -> 115
    //   178: astore_1
    //   179: aload_0
    //   180: monitorexit
    //   181: aload_1
    //   182: athrow
    //   183: astore_1
    //   184: aload_3
    //   185: invokevirtual delete : ()Z
    //   188: pop
    //   189: aload_1
    //   190: athrow
    // Exception table:
    //   from	to	target	type
    //   2	115	178	finally
    //   118	163	178	finally
    //   163	169	183	java/io/IOException
    //   163	169	178	finally
    //   169	175	178	finally
    //   184	191	178	finally
  }
  
  public String getVersionId() throws IOException {
    byte[] arrayOfByte = readFromAmazonGamesDir("latestVersion.txt");
    return (arrayOfByte == null) ? null : new String(arrayOfByte);
  }
  
  public boolean hasSuccessfullySynchronized() {
    return this.hasSuccessfullySynchronized;
  }
  
  public void putVersionId(String paramString) throws IOException {
    this.hasSuccessfullySynchronized = true;
    writeToAmazonGamesDir("latestVersion.txt", paramString.getBytes());
  }
  
  public InternalGameDataMap retrieve() throws IOException, AGSClientException {
    byte[] arrayOfByte = readFromAmazonGamesDir("gameData.json");
    if (arrayOfByte == null) {
      Log.w("GC_Whispersync", "Retrieved an empty document from disk");
      return null;
    } 
    String str = new String(arrayOfByte);
    str = this.stringObfuscator.unobfuscate(str);
    Log.v("GC_Whispersync", "Retrieved JSON string [" + str + "] of game data map from disk");
    return this.marshaller.parse(str);
  }
  
  public int save(InternalGameDataMap paramInternalGameDataMap) throws IOException, AGSClientException {
    String str = this.marshaller.composeForDisk(paramInternalGameDataMap);
    if (str != null) {
      Log.v("GC_Whispersync", "Writing game data to disk: [" + str + "]");
      str = this.stringObfuscator.obfuscate(str);
      if (str != null) {
        writeToAmazonGamesDir("gameData.json", str.getBytes());
        return str.length();
      } 
    } else {
      Log.v("GC_Whispersync", "No game data to write to disk yet");
    } 
    return 0;
  }
  
  public void setStringObfuscator(StringObfuscator paramStringObfuscator) {
    if (paramStringObfuscator != null)
      this.stringObfuscator = paramStringObfuscator; 
  }
  
  protected void writeDataToFile(File paramFile, byte[] paramArrayOfbyte) throws IOException {
    FileOutputStream fileOutputStream = new FileOutputStream(paramFile);
    try {
      fileOutputStream.write(paramArrayOfbyte);
      return;
    } finally {
      fileOutputStream.close();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\storage\DiskStorage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */