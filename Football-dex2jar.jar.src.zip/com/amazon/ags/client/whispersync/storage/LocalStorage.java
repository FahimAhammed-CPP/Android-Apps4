package com.amazon.ags.client.whispersync.storage;

import com.amazon.ags.AGSClientException;
import com.amazon.ags.client.whispersync.InternalGameDataMap;
import java.io.IOException;

public interface LocalStorage {
  String getVersionId() throws IOException;
  
  boolean hasSuccessfullySynchronized();
  
  void putVersionId(String paramString) throws IOException;
  
  InternalGameDataMap retrieve() throws IOException, AGSClientException;
  
  int save(InternalGameDataMap paramInternalGameDataMap) throws IOException, AGSClientException;
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\storage\LocalStorage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */