package com.amazon.ags.client.whispersync.event;

import android.util.Log;
import com.amazon.ags.client.whispersync.SynchronizationManager;
import com.amazon.ags.html5.javascript.event.JavascriptEventListener;

public class WhispersyncJavascriptEventListener implements JavascriptEventListener {
  private static final String TAG = "GC_Whispersync";
  
  private final SynchronizationManager synchronizationManager;
  
  public WhispersyncJavascriptEventListener(SynchronizationManager paramSynchronizationManager) {
    this.synchronizationManager = paramSynchronizationManager;
  }
  
  public void onJavascriptEvent(String paramString) {
    Log.d("GC_Whispersync", "Received an event [" + paramString + "] from Javascript");
    if (paramString.equals("signInEvent"))
      this.synchronizationManager.syncActively(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\event\WhispersyncJavascriptEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */