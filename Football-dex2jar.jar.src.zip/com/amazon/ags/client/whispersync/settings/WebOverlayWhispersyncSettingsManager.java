package com.amazon.ags.client.whispersync.settings;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.client.session.SessionClient;
import com.amazon.ags.client.session.WhispersyncEnabledResponse;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class WebOverlayWhispersyncSettingsManager implements WhispersyncUserSettingsManager {
  private static final String TAG = "GC_Whispersync";
  
  private static final long WEB_OVERLAY_CALL_TIMEOUT_SECONDS = 1L;
  
  private WhispersyncUserSettingsManager.YesNoMaybe isWhispersyncEnabled = WhispersyncUserSettingsManager.YesNoMaybe.MAYBE;
  
  private final SessionClient sessionClient;
  
  public WebOverlayWhispersyncSettingsManager(SessionClient paramSessionClient) {
    this.sessionClient = paramSessionClient;
  }
  
  public WhispersyncUserSettingsManager.YesNoMaybe isWhispersyncEnabled() {
    Log.d("GC_Whispersync", "Checking whether Whispersync is enabled");
    AGResponseHandle aGResponseHandle = this.sessionClient.isWhispersyncEnabled();
    final CountDownLatch countDownLatch = new CountDownLatch(1);
    aGResponseHandle.setCallback(new AGResponseCallback<WhispersyncEnabledResponse>() {
          public void onComplete(WhispersyncEnabledResponse param1WhispersyncEnabledResponse) {
            if (param1WhispersyncEnabledResponse != null) {
              if (param1WhispersyncEnabledResponse.isWhispersyncEnabled()) {
                WebOverlayWhispersyncSettingsManager.access$002(WebOverlayWhispersyncSettingsManager.this, WhispersyncUserSettingsManager.YesNoMaybe.YES);
                Log.d("GC_Whispersync", "Whispersync is ENABLED");
              } else {
                WebOverlayWhispersyncSettingsManager.access$002(WebOverlayWhispersyncSettingsManager.this, WhispersyncUserSettingsManager.YesNoMaybe.NO);
                Log.d("GC_Whispersync", "Whispersync is DISABLED");
              } 
            } else {
              Log.d("GC_Whispersync", "Unable to determine whether Whispersync is enabled");
            } 
            countDownLatch.countDown();
          }
        });
    try {
      if (!countDownLatch.await(1L, TimeUnit.SECONDS))
        Log.d("GC_Whispersync", "Timed-out determining whether Whispersync is enabled"); 
    } catch (InterruptedException interruptedException) {
      Log.w("GC_Whispersync", "Thread interrupted when waiting for Whispersync enabled state [" + interruptedException.getLocalizedMessage() + "]");
      Thread.currentThread().interrupt();
    } 
    return this.isWhispersyncEnabled;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\settings\WebOverlayWhispersyncSettingsManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */