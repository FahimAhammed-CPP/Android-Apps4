package com.amazon.ags.client.whispersync.settings;

public interface WhispersyncUserSettingsManager {
  YesNoMaybe isWhispersyncEnabled();
  
  public enum YesNoMaybe {
    MAYBE, NO, YES;
    
    static {
      MAYBE = new YesNoMaybe("MAYBE", 2);
      $VALUES = new YesNoMaybe[] { YES, NO, MAYBE };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\settings\WhispersyncUserSettingsManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */