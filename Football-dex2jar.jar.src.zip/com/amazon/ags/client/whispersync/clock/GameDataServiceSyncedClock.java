package com.amazon.ags.client.whispersync.clock;

import android.util.Log;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class GameDataServiceSyncedClock implements Clock {
  private static final String TAG = "GC_Whipsersync";
  
  private final ClockSkewStorage clockSkewStorage;
  
  private final Clock localClock;
  
  public GameDataServiceSyncedClock(Clock paramClock, ClockSkewStorage paramClockSkewStorage) {
    this.localClock = paramClock;
    this.clockSkewStorage = paramClockSkewStorage;
  }
  
  private long getCurrentLocalTimeSeconds() {
    return this.localClock.getCurrentTimeSeconds();
  }
  
  private long parseServerTime(String paramString) throws ParseException {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
    return simpleDateFormat.parse(paramString).getTime() / TimeUnit.SECONDS.toMillis(1L);
  }
  
  public long getCurrentTimeSeconds() {
    return getCurrentLocalTimeSeconds() - this.clockSkewStorage.getClockSkew();
  }
  
  public void synchronizeClock(String paramString) {
    if (paramString == null) {
      Log.w("GC_Whipsersync", "Received a null date from the service, cannot synchronize with server clock");
      return;
    } 
    try {
      long l = parseServerTime(paramString);
      l = getCurrentLocalTimeSeconds() - l;
      this.clockSkewStorage.setClockSkew(l);
      Log.d("GC_Whipsersync", "Measured clock skew as: " + l);
      return;
    } catch (ParseException parseException) {
      Log.w("GC_Whipsersync", "Failed to synchronize with server clock, received an invalid date format", parseException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\clock\GameDataServiceSyncedClock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */