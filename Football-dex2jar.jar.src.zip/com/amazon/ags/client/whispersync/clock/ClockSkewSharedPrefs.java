package com.amazon.ags.client.whispersync.clock;

import android.content.Context;
import android.content.SharedPreferences;

public class ClockSkewSharedPrefs implements ClockSkewStorage {
  private final String CLOCK_SKEW_KEY = "clockSkewKey";
  
  private final String PREFS_NAME = "ClockSkewSharedPrefs";
  
  private final SharedPreferences clockSkewSharedPrefs;
  
  private final SharedPreferences.Editor editor;
  
  public ClockSkewSharedPrefs(Context paramContext) {
    this.clockSkewSharedPrefs = paramContext.getSharedPreferences("ClockSkewSharedPrefs", 0);
    this.editor = this.clockSkewSharedPrefs.edit();
  }
  
  public long getClockSkew() {
    return this.clockSkewSharedPrefs.getLong("clockSkewKey", 0L);
  }
  
  public void setClockSkew(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield editor : Landroid/content/SharedPreferences$Editor;
    //   6: ldc 'clockSkewKey'
    //   8: lload_1
    //   9: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   14: pop
    //   15: aload_0
    //   16: getfield editor : Landroid/content/SharedPreferences$Editor;
    //   19: invokeinterface commit : ()Z
    //   24: pop
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: astore_3
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_3
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	28	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\clock\ClockSkewSharedPrefs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */