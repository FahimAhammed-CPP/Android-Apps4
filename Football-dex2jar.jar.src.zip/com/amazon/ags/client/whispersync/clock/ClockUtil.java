package com.amazon.ags.client.whispersync.clock;

public class ClockUtil {
  private static Clock theClock = new LocalClock();
  
  public static long getCurrentTime() {
    return theClock.getCurrentTimeSeconds();
  }
  
  public static void setGlobalClock(Clock paramClock) {
    theClock = paramClock;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\clock\ClockUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */