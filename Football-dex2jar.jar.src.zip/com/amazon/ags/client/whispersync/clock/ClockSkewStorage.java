package com.amazon.ags.client.whispersync.clock;

public interface ClockSkewStorage {
  long getClockSkew();
  
  void setClockSkew(long paramLong);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\clock\ClockSkewStorage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */