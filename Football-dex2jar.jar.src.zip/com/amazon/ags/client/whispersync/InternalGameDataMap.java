package com.amazon.ags.client.whispersync;

import com.amazon.ags.api.whispersync.GameDataMap;
import com.amazon.ags.client.whispersync.model.Key;
import com.amazon.ags.client.whispersync.model.Mergeable;
import java.util.Map;

public interface InternalGameDataMap extends GameDataMap, Mergeable<InternalGameDataMap> {
  Map<Key, Mergeable<?>> getAllElements();
  
  InternalGameDataMap lockAndCopy();
  
  void putElement(Key paramKey, Mergeable<?> paramMergeable);
  
  int size();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\InternalGameDataMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */