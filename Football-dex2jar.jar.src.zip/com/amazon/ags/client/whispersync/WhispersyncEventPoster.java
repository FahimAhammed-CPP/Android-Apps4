package com.amazon.ags.client.whispersync;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.amazon.ags.api.whispersync.WhispersyncEventListener;

public class WhispersyncEventPoster {
  private static final String TAG = "GC_Whispersync";
  
  private final Handler uiThreadHandler = new Handler(Looper.getMainLooper());
  
  private WhispersyncEventListener whispersyncEventListener;
  
  public void postEvent(final WhispersyncEvent event) {
    Log.d("GC_Whispersync", "posting event: " + event);
    if (this.whispersyncEventListener != null)
      this.uiThreadHandler.post(new Runnable() {
            public void run() {
              // Byte code:
              //   0: getstatic com/amazon/ags/client/whispersync/WhispersyncEventPoster$2.$SwitchMap$com$amazon$ags$client$whispersync$WhispersyncEvent : [I
              //   3: aload_0
              //   4: getfield val$event : Lcom/amazon/ags/client/whispersync/WhispersyncEvent;
              //   7: invokevirtual ordinal : ()I
              //   10: iaload
              //   11: tableswitch default -> 64, 1 -> 93, 2 -> 104, 3 -> 115, 4 -> 126, 5 -> 137, 6 -> 148, 7 -> 159, 8 -> 173, 9 -> 187, 10 -> 201
              //   64: ldc 'GC_Whispersync'
              //   66: new java/lang/StringBuilder
              //   69: dup
              //   70: invokespecial <init> : ()V
              //   73: ldc 'Unexpected event: '
              //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   78: aload_0
              //   79: getfield val$event : Lcom/amazon/ags/client/whispersync/WhispersyncEvent;
              //   82: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   85: invokevirtual toString : ()Ljava/lang/String;
              //   88: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
              //   91: pop
              //   92: return
              //   93: aload_0
              //   94: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   97: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   100: invokevirtual onNewCloudData : ()V
              //   103: return
              //   104: aload_0
              //   105: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   108: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   111: invokevirtual onDataUploadedToCloud : ()V
              //   114: return
              //   115: aload_0
              //   116: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   119: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   122: invokevirtual onThrottled : ()V
              //   125: return
              //   126: aload_0
              //   127: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   130: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   133: invokevirtual onDiskWriteComplete : ()V
              //   136: return
              //   137: aload_0
              //   138: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   141: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   144: invokevirtual onFirstSynchronize : ()V
              //   147: return
              //   148: aload_0
              //   149: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   152: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   155: invokevirtual onAlreadySynchronized : ()V
              //   158: return
              //   159: aload_0
              //   160: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   163: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   166: getstatic com/amazon/ags/api/whispersync/FailReason.OFFLINE : Lcom/amazon/ags/api/whispersync/FailReason;
              //   169: invokevirtual onSyncFailed : (Lcom/amazon/ags/api/whispersync/FailReason;)V
              //   172: return
              //   173: aload_0
              //   174: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   177: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   180: getstatic com/amazon/ags/api/whispersync/FailReason.WHISPERSYNC_DISABLED : Lcom/amazon/ags/api/whispersync/FailReason;
              //   183: invokevirtual onSyncFailed : (Lcom/amazon/ags/api/whispersync/FailReason;)V
              //   186: return
              //   187: aload_0
              //   188: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   191: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   194: getstatic com/amazon/ags/api/whispersync/FailReason.SERVICE_ERROR : Lcom/amazon/ags/api/whispersync/FailReason;
              //   197: invokevirtual onSyncFailed : (Lcom/amazon/ags/api/whispersync/FailReason;)V
              //   200: return
              //   201: aload_0
              //   202: getfield this$0 : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
              //   205: invokestatic access$000 : (Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;)Lcom/amazon/ags/api/whispersync/WhispersyncEventListener;
              //   208: getstatic com/amazon/ags/api/whispersync/FailReason.CLIENT_ERROR : Lcom/amazon/ags/api/whispersync/FailReason;
              //   211: invokevirtual onSyncFailed : (Lcom/amazon/ags/api/whispersync/FailReason;)V
              //   214: return
            }
          }); 
  }
  
  public void setWhispersyncEventListener(WhispersyncEventListener paramWhispersyncEventListener) {
    this.whispersyncEventListener = paramWhispersyncEventListener;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\WhispersyncEventPoster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */