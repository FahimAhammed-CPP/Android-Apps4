package com.amazon.ags.client.whispersync;

public class SyncRequestState {
  private boolean activeCloudWrite;
  
  private boolean cloudWriteRequested;
  
  private boolean diskWriteRequested;
  
  public boolean isActiveCloudWrite() {
    return this.activeCloudWrite;
  }
  
  public boolean isCloudWriteRequested() {
    return this.cloudWriteRequested;
  }
  
  public boolean isDiskWriteRequested() {
    return this.diskWriteRequested;
  }
  
  public void setActiveCloudWrite(boolean paramBoolean) {
    this.activeCloudWrite = paramBoolean;
  }
  
  public void setCloudWriteRequested(boolean paramBoolean) {
    this.cloudWriteRequested = paramBoolean;
  }
  
  public void setDiskWriteRequested(boolean paramBoolean) {
    this.diskWriteRequested = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\SyncRequestState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */