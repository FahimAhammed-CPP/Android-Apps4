package com.amazon.ags.client.whispersync.network;

import android.util.Log;
import com.amazon.ags.AGSClientException;
import com.amazon.ags.AGSServiceException;
import com.amazon.ags.html5.comm.AGSHttpGet;
import com.amazon.ags.html5.comm.AGSHttpPost;
import com.amazon.ags.html5.comm.ConnectionException;
import com.amazon.ags.html5.comm.NetworkClient;
import com.amazon.ags.html5.comm.ServiceRequestBase;
import com.amazon.ags.html5.comm.ServiceResponse;
import java.io.IOException;

public class WhispersyncHttpClientImpl implements WhispersyncHttpClient {
  private static final String DATE_KEY = "Date";
  
  private static final String GET_ENDPOINT = "https://ags-ext.amazon.com/service/gamedata/WhisperData";
  
  private static final String POST_ENDPOINT = "https://ags-ext.amazon.com/service/gamedata/WhisperData";
  
  private static final String TAG = "GC_Whispersync";
  
  private static final String VERSION_ID_HEADER_KEY = "x-amzn-gc-version-id";
  
  private final String gameId;
  
  private final NetworkClient networkClient;
  
  public WhispersyncHttpClientImpl(NetworkClient paramNetworkClient, String paramString) {
    this.networkClient = paramNetworkClient;
    this.gameId = paramString;
  }
  
  public WhispersyncResponse getWhisperData(String paramString) throws AGSClientException, AGSServiceException, ConnectionException {
    int i;
    String str1;
    String str2;
    AGSHttpGet aGSHttpGet = new AGSHttpGet("https://ags-ext.amazon.com/service/gamedata/WhisperData", true);
    if (paramString != null)
      aGSHttpGet.putHeaderParameter("x-amzn-gc-version-id", paramString); 
    aGSHttpGet.putUrlParameter("gameId", this.gameId);
    ServiceResponse serviceResponse = this.networkClient.execute((ServiceRequestBase)aGSHttpGet);
    try {
      str1 = serviceResponse.getContent();
      str2 = serviceResponse.getHeader("Date");
      Log.d("GC_Whispersync", "Received HTTP Status Code [" + serviceResponse.getStatusCode() + "] and content [" + str1 + "] when saving data to the cloud");
      i = serviceResponse.getStatusCode();
      if (i == 200) {
        String str = serviceResponse.getHeader("x-amzn-gc-version-id");
        return new WhispersyncResponse(str1, str, str2);
      } 
    } catch (IOException iOException) {
      throw new ConnectionException("error reading content", iOException);
    } 
    if (i == 204) {
      String str = "";
      Log.d("GC_Whispersync", "No content found while getting Whispersync data from the service");
      return new WhispersyncResponse(str1, str, str2);
    } 
    if (i == 404) {
      String str = "";
      Log.d("GC_Whispersync", "Resource not found");
      return new WhispersyncResponse(str1, str, str2);
    } 
    Log.d("GC_Whispersync", "Unexpected Http Status Code received when making call to get Whispersync data from the service");
    throw new ConnectionException("Unexpected Status Response: " + i);
  }
  
  public WhispersyncResponse postWhisperData(WhispersyncRequest paramWhispersyncRequest) throws AGSClientException, AGSServiceException, ConnectionException {
    int i;
    String str2;
    String str3;
    AGSHttpPost aGSHttpPost = new AGSHttpPost("https://ags-ext.amazon.com/service/gamedata/WhisperData", true);
    aGSHttpPost.setRequestBody(paramWhispersyncRequest.getDocument());
    String str1 = paramWhispersyncRequest.getPriorVersionId();
    if (str1 != null && !str1.isEmpty())
      aGSHttpPost.putHeaderParameter("x-amzn-gc-version-id", str1); 
    aGSHttpPost.putUrlParameter("gameId", this.gameId);
    ServiceResponse serviceResponse = this.networkClient.execute((ServiceRequestBase)aGSHttpPost);
    try {
      str2 = serviceResponse.getContent();
      str3 = serviceResponse.getHeader("Date");
      Log.d("GC_Whispersync", "Received HTTP Status Code [" + serviceResponse.getStatusCode() + "] and content [" + str2 + "] when saving data to the cloud");
      i = serviceResponse.getStatusCode();
      if (i == 200) {
        String str = serviceResponse.getHeader("x-amzn-gc-version-id");
        return new WhispersyncResponse(str2, str, str3);
      } 
    } catch (IOException iOException) {
      throw new ConnectionException("error reading content", iOException);
    } 
    if (i == 204) {
      String str = "";
      Log.d("GC_Whispersync", "No content found while getting whispersync data from the service");
      return new WhispersyncResponse(str2, str, str3);
    } 
    Log.d("GC_Whispersync", "Unexpected Http Status Code received when making call to get whispersync data from the service");
    throw new AGSServiceException("Unexpected Service Response");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\network\WhispersyncHttpClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */