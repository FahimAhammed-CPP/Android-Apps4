package com.amazon.ags.client.whispersync.network;

public class WhispersyncResponse {
  private final String date;
  
  private final String document;
  
  private final String versionId;
  
  public WhispersyncResponse(String paramString1, String paramString2, String paramString3) {
    this.document = paramString1;
    this.versionId = paramString2;
    this.date = paramString3;
  }
  
  public String getDate() {
    return this.date;
  }
  
  public String getDocument() {
    return this.document;
  }
  
  public String getVersionId() {
    return this.versionId;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\network\WhispersyncResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */