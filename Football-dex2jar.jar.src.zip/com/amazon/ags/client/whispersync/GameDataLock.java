package com.amazon.ags.client.whispersync;

import android.util.Log;
import java.util.concurrent.locks.ReentrantLock;

public class GameDataLock {
  private static final String TAG = "GC_Whispersync";
  
  private static final ReentrantLock lock = new ReentrantLock(true);
  
  public static void lock() {
    long l = System.currentTimeMillis();
    lock.lock();
    if (Log.isLoggable("GC_Whispersync", 2))
      Log.v("GC_Whispersync", "Waited " + (System.currentTimeMillis() - l) + " msec. for lock"); 
  }
  
  public static void unlock() {
    lock.unlock();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\GameDataLock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */