package com.amazon.ags.client.whispersync;

import com.amazon.ags.client.metrics.EventCollectorClient;

public class SynchronizationManager {
  private static final String TAG = "GC_Whispersync";
  
  private boolean cloudSyncInProgress = false;
  
  private CloudSynchronizer cloudSynchronizer = null;
  
  private boolean diskSyncInProgress = false;
  
  private final DiskSynchronizer diskSynchronizer;
  
  private final WhispersyncEventPoster eventPoster;
  
  private final SyncRequestState syncRequestState;
  
  public SynchronizationManager(DiskSynchronizer paramDiskSynchronizer, SyncRequestState paramSyncRequestState, WhispersyncEventPoster paramWhispersyncEventPoster) {
    this.diskSynchronizer = paramDiskSynchronizer;
    this.syncRequestState = paramSyncRequestState;
    this.eventPoster = paramWhispersyncEventPoster;
  }
  
  private void startCloudSyncThread() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield cloudSynchronizer : Lcom/amazon/ags/client/whispersync/CloudSynchronizer;
    //   6: ifnonnull -> 30
    //   9: ldc 'GC_Whispersync'
    //   11: ldc 'WhispersyncClient has not completed initialization.  Cloud synchronization not available yet'
    //   13: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   16: pop
    //   17: aload_0
    //   18: getfield eventPoster : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
    //   21: getstatic com/amazon/ags/client/whispersync/WhispersyncEvent.ERROR_CLIENT : Lcom/amazon/ags/client/whispersync/WhispersyncEvent;
    //   24: invokevirtual postEvent : (Lcom/amazon/ags/client/whispersync/WhispersyncEvent;)V
    //   27: aload_0
    //   28: monitorexit
    //   29: return
    //   30: aload_0
    //   31: getfield cloudSyncInProgress : Z
    //   34: ifne -> 27
    //   37: aload_0
    //   38: iconst_1
    //   39: putfield cloudSyncInProgress : Z
    //   42: new com/amazon/ags/client/whispersync/SynchronizationManager$2
    //   45: dup
    //   46: aload_0
    //   47: invokespecial <init> : (Lcom/amazon/ags/client/whispersync/SynchronizationManager;)V
    //   50: invokevirtual start : ()V
    //   53: goto -> 27
    //   56: astore_1
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	56	finally
    //   30	53	56	finally
  }
  
  private void startDiskSyncThread() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield diskSyncInProgress : Z
    //   6: ifne -> 25
    //   9: aload_0
    //   10: iconst_1
    //   11: putfield diskSyncInProgress : Z
    //   14: new com/amazon/ags/client/whispersync/SynchronizationManager$1
    //   17: dup
    //   18: aload_0
    //   19: invokespecial <init> : (Lcom/amazon/ags/client/whispersync/SynchronizationManager;)V
    //   22: invokevirtual start : ()V
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: astore_1
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	28	finally
  }
  
  public void flush() {
    this.diskSynchronizer.syncToDiskNow();
  }
  
  public void setCloudSynchronizer(CloudSynchronizer paramCloudSynchronizer) {
    this.cloudSynchronizer = paramCloudSynchronizer;
  }
  
  public void setEventCollectorClient(EventCollectorClient paramEventCollectorClient) {
    if (this.diskSynchronizer != null)
      this.diskSynchronizer.setEventCollectorClient(paramEventCollectorClient); 
    if (this.cloudSynchronizer != null)
      this.cloudSynchronizer.setEventCollectorClient(paramEventCollectorClient); 
  }
  
  public void syncActively() {
    this.syncRequestState.setDiskWriteRequested(true);
    this.syncRequestState.setCloudWriteRequested(true);
    this.syncRequestState.setActiveCloudWrite(true);
    startDiskSyncThread();
  }
  
  public void syncFromDiskToMemory() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield diskSynchronizer : Lcom/amazon/ags/client/whispersync/DiskSynchronizer;
    //   6: invokevirtual loadFromDisk : ()V
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
  }
  
  public void syncPassively() {
    this.syncRequestState.setDiskWriteRequested(true);
    this.syncRequestState.setCloudWriteRequested(true);
    this.diskSynchronizer.notifyDataChanged();
    startDiskSyncThread();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\SynchronizationManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */