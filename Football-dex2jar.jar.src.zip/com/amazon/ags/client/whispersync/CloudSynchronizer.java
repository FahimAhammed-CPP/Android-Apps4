package com.amazon.ags.client.whispersync;

import android.util.Log;
import com.amazon.ags.AGSClientException;
import com.amazon.ags.AGSServiceException;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import com.amazon.ags.client.whispersync.settings.WhispersyncUserSettingsManager;
import com.amazon.ags.client.whispersync.storage.GameData;
import com.amazon.ags.client.whispersync.storage.LocalStorage;
import com.amazon.ags.client.whispersync.storage.RemoteStorage;
import com.amazon.ags.html5.comm.ConnectionException;
import com.amazon.ags.html5.util.NetworkUtil;
import com.amazon.ags.jni.whispersync.WhispersyncJni;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class CloudSynchronizer {
  private static final long MIN_TIME_BETWEEN_ACTIVE_SYNCS_MS = TimeUnit.SECONDS.toMillis(10L);
  
  private static final long MIN_TIME_BETWEEN_PASSIVE_SYNCS_MS = TimeUnit.SECONDS.toMillis(30L);
  
  private static final String TAG = "GC_Whispersync";
  
  private final RemoteStorage cloudStorage;
  
  private EventCollectorClient eventCollectorClient;
  
  private final WhispersyncEventPoster eventPoster;
  
  private final InternalGameDataMap gameDataMap;
  
  private final LocalStorage localStorage;
  
  private final NetworkUtil networkUtil;
  
  private long priorSyncTime;
  
  private final WhispersyncUserSettingsManager settingsManager;
  
  private final SyncRequestState syncRequestState;
  
  public CloudSynchronizer(InternalGameDataMap paramInternalGameDataMap, LocalStorage paramLocalStorage, RemoteStorage paramRemoteStorage, SyncRequestState paramSyncRequestState, WhispersyncEventPoster paramWhispersyncEventPoster, EventCollectorClient paramEventCollectorClient, NetworkUtil paramNetworkUtil, WhispersyncUserSettingsManager paramWhispersyncUserSettingsManager) {
    this.gameDataMap = paramInternalGameDataMap;
    this.localStorage = paramLocalStorage;
    this.cloudStorage = paramRemoteStorage;
    this.syncRequestState = paramSyncRequestState;
    this.eventPoster = paramWhispersyncEventPoster;
    this.eventCollectorClient = paramEventCollectorClient;
    this.networkUtil = paramNetworkUtil;
    this.settingsManager = paramWhispersyncUserSettingsManager;
  }
  
  private void downloadFromCloud() throws AGSClientException, ConnectionException, AGSServiceException, IOException {
    if (!this.networkUtil.isNetworkConnected()) {
      Log.d("GC_Whispersync", "Cannot sync with cloud because network is not connected");
      this.eventPoster.postEvent(WhispersyncEvent.OFFLINE);
      return;
    } 
    WhispersyncUserSettingsManager.YesNoMaybe yesNoMaybe = this.settingsManager.isWhispersyncEnabled();
    if (yesNoMaybe == WhispersyncUserSettingsManager.YesNoMaybe.NO) {
      Log.d("GC_Whispersync", "Cannot sync with cloud because Whispersync is disabled");
      this.eventPoster.postEvent(WhispersyncEvent.DISABLED);
      return;
    } 
    if (yesNoMaybe == WhispersyncUserSettingsManager.YesNoMaybe.MAYBE) {
      Log.d("GC_Whispersync", "Cannot determine whether Whispersync is enabled.");
      this.eventPoster.postEvent(WhispersyncEvent.ERROR_CLIENT);
      return;
    } 
    long l = System.currentTimeMillis();
    Log.d("GC_Whispersync", "Download from cloud started");
    GameData gameData = this.cloudStorage.retrieve(this.localStorage.getVersionId());
    if (gameData.getGameDataMap() != null) {
      this.gameDataMap.merge(gameData.getGameDataMap());
      this.syncRequestState.setDiskWriteRequested(true);
      this.eventPoster.postEvent(WhispersyncEvent.NEW_DATA_FROM_CLOUD);
      notifyJniNewCloudData();
      Log.d("GC_Whispersync", "Download from cloud completed - New game data");
    } else {
      Log.d("GC_Whispersync", "Download from cloud completed - No new game data");
    } 
    if (gameData.getVersionId() != null)
      this.localStorage.putVersionId(gameData.getVersionId()); 
    reportTimeEvent("WHISPERSYNC_DOWNLOAD_FROM_CLOUD", System.currentTimeMillis() - l);
  }
  
  private boolean hasSuccessfullySynchronized() {
    return this.localStorage.hasSuccessfullySynchronized();
  }
  
  private void notifyJniNewCloudData() {
    try {
      WhispersyncJni.onNewCloudData();
      return;
    } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
      Log.v("GC_Whispersync", "GameCircle JNI library not loaded, cannot call WhispersyncJni");
      return;
    } 
  }
  
  private void reportCountEvent(String paramString) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createCountEvent(paramString, 1);
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
  }
  
  private void reportTimeEvent(String paramString, long paramLong) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createGenericEvent(paramString, Integer.valueOf(1), Long.valueOf(paramLong));
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
  }
  
  private void sleepWhileThrottled() {
    if (this.syncRequestState.isActiveCloudWrite()) {
      l = MIN_TIME_BETWEEN_ACTIVE_SYNCS_MS;
    } else {
      l = MIN_TIME_BETWEEN_PASSIVE_SYNCS_MS;
    } 
    this.syncRequestState.setActiveCloudWrite(false);
    long l = this.priorSyncTime + l - System.currentTimeMillis();
    if (l > 0L)
      try {
        Log.d("GC_Whispersync", "Throttling network request.  Retrying in " + l + " msec.");
        this.eventPoster.postEvent(WhispersyncEvent.THROTTLED);
        reportCountEvent("WHISPERSYNC_CLOUD_SYNC_THROTTLED");
        Thread.sleep(l);
        return;
      } catch (InterruptedException interruptedException) {
        Thread.currentThread().interrupt();
        return;
      }  
  }
  
  private void uploadToCloud() throws IOException, AGSClientException, ConnectionException, AGSServiceException {
    sleepWhileThrottled();
    if (!this.networkUtil.isNetworkConnected()) {
      Log.d("GC_Whispersync", "Cannot sync with cloud because network is not connected");
      this.eventPoster.postEvent(WhispersyncEvent.OFFLINE);
      return;
    } 
    WhispersyncUserSettingsManager.YesNoMaybe yesNoMaybe = this.settingsManager.isWhispersyncEnabled();
    if (yesNoMaybe == WhispersyncUserSettingsManager.YesNoMaybe.NO) {
      Log.d("GC_Whispersync", "Cannot sync with cloud because Whispersync is disabled");
      this.eventPoster.postEvent(WhispersyncEvent.DISABLED);
      return;
    } 
    if (yesNoMaybe == WhispersyncUserSettingsManager.YesNoMaybe.MAYBE) {
      Log.d("GC_Whispersync", "Cannot determine whether Whispersync is enabled.");
      this.eventPoster.postEvent(WhispersyncEvent.ERROR_CLIENT);
      return;
    } 
    long l = System.currentTimeMillis();
    Log.d("GC_Whispersync", "Upload to cloud started");
    String str = this.localStorage.getVersionId();
    this.syncRequestState.setCloudWriteRequested(false);
    this.gameDataMap.startSyncing();
    GameData gameData = new GameData(this.gameDataMap.lockAndCopy(), str);
    gameData = this.cloudStorage.save(gameData);
    this.priorSyncTime = System.currentTimeMillis();
    this.eventPoster.postEvent(WhispersyncEvent.DATA_UPLOADED_TO_CLOUD);
    if (gameData.getGameDataMap() != null && gameData.getGameDataMap().size() > 0) {
      Log.i("GC_Whispersync", "Upload to cloud resulted in new data merged from another device!");
      this.gameDataMap.merge(gameData.getGameDataMap());
      this.syncRequestState.setDiskWriteRequested(true);
      this.eventPoster.postEvent(WhispersyncEvent.NEW_DATA_FROM_CLOUD);
      reportCountEvent("WHISPERSYNC_MERGE_ON_UPLOAD");
      notifyJniNewCloudData();
    } else {
      this.eventPoster.postEvent(WhispersyncEvent.ALREADY_SYNCED);
    } 
    if (gameData.getVersionId() != null)
      this.localStorage.putVersionId(gameData.getVersionId()); 
    this.gameDataMap.completeSyncing();
    Log.d("GC_Whispersync", "Upload to cloud completed");
    reportTimeEvent("WHISPERSYNC_UPLOAD_TO_CLOUD", System.currentTimeMillis() - l);
  }
  
  public void setEventCollectorClient(EventCollectorClient paramEventCollectorClient) {
    if (paramEventCollectorClient != null)
      this.eventCollectorClient = paramEventCollectorClient; 
  }
  
  public void syncToCloud() {
    try {
      if (hasSuccessfullySynchronized()) {
        uploadToCloud();
        return;
      } 
      Log.d("GC_Whispersync", "Never synced from cloud.  Attempting initial download and merge.");
      downloadFromCloud();
      if (hasSuccessfullySynchronized()) {
        this.eventPoster.postEvent(WhispersyncEvent.FIRST_SYNC);
        uploadToCloud();
        return;
      } 
    } catch (IOException iOException) {
      Log.e("GC_Whispersync", "Unable to perform full sync.", iOException);
      this.eventPoster.postEvent(WhispersyncEvent.ERROR_CLIENT);
      reportCountEvent("WHISPERSYNC_CLOUD_SYNC_IO_EXCEPTION");
      return;
    } catch (AGSClientException aGSClientException) {
      Log.e("GC_Whispersync", "Unable to perform full sync.", (Throwable)aGSClientException);
      this.eventPoster.postEvent(WhispersyncEvent.ERROR_CLIENT);
      reportCountEvent("WHISPERSYNC_CLOUD_SYNC_CLIENT_EXCEPTION");
      return;
    } catch (AGSServiceException aGSServiceException) {
      Log.e("GC_Whispersync", "Unable to perform full sync.", (Throwable)aGSServiceException);
      this.eventPoster.postEvent(WhispersyncEvent.ERROR_SERVICE);
      reportCountEvent("WHISPERSYNC_CLOUD_SYNC_SERVER_EXCEPTION");
      return;
    } catch (ConnectionException connectionException) {
      Log.e("GC_Whispersync", "Unable to perform full sync due to Network Connection", (Throwable)connectionException);
      this.eventPoster.postEvent(WhispersyncEvent.OFFLINE);
      reportCountEvent("WHISPERSYNC_CLOUD_SYNC_NETWORK_EXCEPTION");
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\CloudSynchronizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */