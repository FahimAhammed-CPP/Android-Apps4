package com.amazon.ags.client.whispersync.marshaller;

public class ParseException extends Exception {
  private static final long serialVersionUID = 1693532024920707475L;
  
  public ParseException() {}
  
  public ParseException(String paramString) {
    super(paramString);
  }
  
  public ParseException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public ParseException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\marshaller\ParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */