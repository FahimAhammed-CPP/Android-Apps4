package com.amazon.ags.client.whispersync.marshaller;

import com.amazon.ags.AGSClientException;
import com.amazon.ags.client.whispersync.InternalGameDataMap;

public interface GameDataMarshaller {
  String composeForDisk(InternalGameDataMap paramInternalGameDataMap) throws AGSClientException;
  
  String composeForService(InternalGameDataMap paramInternalGameDataMap) throws AGSClientException;
  
  InternalGameDataMap parse(String paramString) throws AGSClientException;
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\marshaller\GameDataMarshaller.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */