package com.amazon.ags.client.whispersync.marshaller;

import android.util.Base64;
import android.util.Log;
import com.amazon.ags.AGSClientException;
import com.amazon.ags.api.whispersync.model.SyncableElement;
import com.amazon.ags.api.whispersync.model.SyncableNumber;
import com.amazon.ags.api.whispersync.model.SyncableNumberElement;
import com.amazon.ags.api.whispersync.model.SyncableNumberList;
import com.amazon.ags.api.whispersync.model.SyncableString;
import com.amazon.ags.api.whispersync.model.SyncableStringElement;
import com.amazon.ags.api.whispersync.model.SyncableStringList;
import com.amazon.ags.api.whispersync.model.SyncableStringSet;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.GameDataSingleMap;
import com.amazon.ags.client.whispersync.InternalGameDataMap;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import com.amazon.ags.client.whispersync.model.AccumulatingNumber;
import com.amazon.ags.client.whispersync.model.DeveloperString;
import com.amazon.ags.client.whispersync.model.HighNumberList;
import com.amazon.ags.client.whispersync.model.HighestNumber;
import com.amazon.ags.client.whispersync.model.Key;
import com.amazon.ags.client.whispersync.model.LatestNumber;
import com.amazon.ags.client.whispersync.model.LatestNumberList;
import com.amazon.ags.client.whispersync.model.LatestString;
import com.amazon.ags.client.whispersync.model.LatestStringList;
import com.amazon.ags.client.whispersync.model.LowNumberList;
import com.amazon.ags.client.whispersync.model.LowestNumber;
import com.amazon.ags.client.whispersync.model.Mergeable;
import com.amazon.ags.client.whispersync.model.NumberElement;
import com.amazon.ags.client.whispersync.model.NumberList;
import com.amazon.ags.client.whispersync.model.StringElement;
import com.amazon.ags.client.whispersync.model.StringSet;
import com.amazon.ags.client.whispersync.model.SyncState;
import com.amazon.ags.client.whispersync.model.SyncableType;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonGameDataMarshaller implements GameDataMarshaller {
  private static final String TAG = "GC_Whispersync";
  
  private EventCollectorClient eventCollectorClient;
  
  public JsonGameDataMarshaller(EventCollectorClient paramEventCollectorClient) {
    this.eventCollectorClient = paramEventCollectorClient;
  }
  
  private String base64EncodeSha256(String paramString) throws ComposeException {
    if (paramString == null)
      return null; 
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
      messageDigest.update(paramString.getBytes());
      return new String(Base64.encode(messageDigest.digest(), 0));
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new ComposeException("SHA-256 algorithm was not found", noSuchAlgorithmException);
    } 
  }
  
  private JSONObject composeAccumulatingNumber(Mergeable<?> paramMergeable, boolean paramBoolean) throws JSONException {
    AccumulatingNumber accumulatingNumber = (AccumulatingNumber)paramMergeable;
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("local", accumulatingNumber.getLocal());
    jSONObject.put("remote", accumulatingNumber.getRemote());
    if (paramBoolean)
      jSONObject.put("state", paramMergeable.getState().toString()); 
    return jSONObject;
  }
  
  private JSONObject composeDataMap(InternalGameDataMap paramInternalGameDataMap, boolean paramBoolean) throws JSONException {
    JSONObject jSONObject = new JSONObject();
    for (Map.Entry entry : paramInternalGameDataMap.getAllElements().entrySet()) {
      Key key = (Key)entry.getKey();
      Mergeable<?> mergeable = (Mergeable)entry.getValue();
      if (mergeable.getState() != SyncState.NOT_SET && (paramBoolean || mergeable.getState() != SyncState.IN_CONFLICT) && (paramBoolean || mergeable.getState() != SyncState.SYNCED)) {
        JSONObject jSONObject1;
        entry = null;
        try {
          JSONObject jSONObject2 = composeElement(key, mergeable, paramBoolean);
          jSONObject1 = jSONObject2;
        } catch (ComposeException composeException) {
          Log.e("GC_Whispersync", "Cannot compose element with key [" + key + "]", composeException);
        } 
        if (jSONObject1 != null) {
          Log.v("GC_Whispersync", "Adding JSON element [" + jSONObject1 + "]");
          jSONObject.put(key.toString(), jSONObject1);
        } 
      } 
    } 
    return jSONObject;
  }
  
  private JSONObject composeDeveloperString(Mergeable<?> paramMergeable, boolean paramBoolean) throws JSONException, ComposeException {
    return paramBoolean ? composeDeveloperStringForDisk(paramMergeable) : composeDeveloperStringForService(paramMergeable);
  }
  
  private JSONObject composeDeveloperStringForDisk(Mergeable<?> paramMergeable) throws JSONException {
    DeveloperString developerString = (DeveloperString)paramMergeable;
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("local", composeNullableStringValue(developerString.getValue()));
    jSONObject.put("state", developerString.getState().toString());
    jSONObject.put("ts", developerString.getTimestamp());
    if (developerString.isCloudValueSet()) {
      jSONObject.put("remote", composeNullableStringValue(developerString.getCloudValue()));
      jSONObject.put("rts", developerString.getCloudTimestamp());
    } 
    return jSONObject;
  }
  
  private JSONObject composeDeveloperStringForService(Mergeable<?> paramMergeable) throws JSONException, ComposeException {
    DeveloperString developerString = (DeveloperString)paramMergeable;
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("value", composeNullableStringValue(developerString.getValue()));
    jSONObject.put("ts", developerString.getTimestamp());
    if (developerString.isCloudValueSet())
      jSONObject.put("base", composeNullableStringValue(base64EncodeSha256(developerString.getCloudValue()))); 
    return jSONObject;
  }
  
  private JSONObject composeElement(Key paramKey, Mergeable<?> paramMergeable, boolean paramBoolean) throws JSONException, ComposeException {
    switch (paramKey.getType()) {
      default:
        Log.e("GC_Whispersync", "Unexpected SyncableType cannot be composed for key:" + paramKey.toString());
        return null;
      case HIGHEST_NUMBER:
      case LOWEST_NUMBER:
      case LATEST_NUMBER:
        return composeNumber(paramMergeable, paramBoolean);
      case ACCUMULATING_NUMBER:
        return composeAccumulatingNumber(paramMergeable, paramBoolean);
      case LATEST_STRING:
        return composeString(paramMergeable, paramBoolean);
      case DEVELOPER_STRING:
        return composeDeveloperString(paramMergeable, paramBoolean);
      case HIGHEST_NUMBER_LIST:
      case LOWEST_NUMBER_LIST:
      case LATEST_NUMBER_LIST:
        return composeNumberList(paramMergeable, paramBoolean);
      case LATEST_STRING_LIST:
        return composeStringList(paramMergeable, paramBoolean);
      case STRING_SET:
        return composeStringSet(paramMergeable, paramBoolean);
      case MAP:
        break;
    } 
    return composeDataMap((InternalGameDataMap)paramMergeable, paramBoolean);
  }
  
  private void composeMetadata(SyncableElement paramSyncableElement, JSONObject paramJSONObject) throws JSONException {
    Map map = paramSyncableElement.getMetadata();
    if (map != null && !map.isEmpty()) {
      JSONObject jSONObject = new JSONObject();
      for (Map.Entry entry : map.entrySet())
        jSONObject.put((String)entry.getKey(), entry.getValue()); 
      paramJSONObject.put("md", jSONObject);
    } 
  }
  
  private Object composeNullableStringValue(String paramString) {
    Object object = paramString;
    if (paramString == null)
      object = JSONObject.NULL; 
    return object;
  }
  
  private JSONObject composeNumber(Mergeable<?> paramMergeable, boolean paramBoolean) throws JSONException {
    SyncableNumber syncableNumber = (SyncableNumber)paramMergeable;
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("value", syncableNumber.asDecimal());
    jSONObject.put("ts", syncableNumber.getTimestamp());
    if (paramBoolean)
      jSONObject.put("state", paramMergeable.getState().toString()); 
    composeMetadata((SyncableElement)syncableNumber, jSONObject);
    return jSONObject;
  }
  
  private JSONObject composeNumberList(Mergeable<?> paramMergeable, boolean paramBoolean) throws JSONException {
    SyncableNumberList syncableNumberList = (SyncableNumberList)paramMergeable;
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("maxSize", syncableNumberList.getMaxSize());
    jSONObject.put("values", composeNumberListItems(syncableNumberList.getValues()));
    if (paramBoolean)
      jSONObject.put("state", paramMergeable.getState().toString()); 
    return jSONObject;
  }
  
  private JSONObject composeNumberListItem(SyncableNumberElement paramSyncableNumberElement) throws JSONException {
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("value", paramSyncableNumberElement.asDecimal());
    jSONObject.put("ts", paramSyncableNumberElement.getTimestamp());
    composeMetadata((SyncableElement)paramSyncableNumberElement, jSONObject);
    return jSONObject;
  }
  
  private JSONArray composeNumberListItems(SyncableNumberElement[] paramArrayOfSyncableNumberElement) throws JSONException {
    JSONArray jSONArray = new JSONArray();
    int j = paramArrayOfSyncableNumberElement.length;
    for (int i = 0; i < j; i++)
      jSONArray.put(composeNumberListItem(paramArrayOfSyncableNumberElement[i])); 
    return jSONArray;
  }
  
  private JSONObject composeString(Mergeable<?> paramMergeable, boolean paramBoolean) throws JSONException {
    SyncableString syncableString = (SyncableString)paramMergeable;
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("value", composeNullableStringValue(syncableString.getValue()));
    jSONObject.put("ts", syncableString.getTimestamp());
    if (paramBoolean)
      jSONObject.put("state", paramMergeable.getState().toString()); 
    composeMetadata((SyncableElement)syncableString, jSONObject);
    return jSONObject;
  }
  
  private JSONObject composeStringItem(SyncableStringElement paramSyncableStringElement) throws JSONException {
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("value", paramSyncableStringElement.getValue());
    jSONObject.put("ts", paramSyncableStringElement.getTimestamp());
    composeMetadata((SyncableElement)paramSyncableStringElement, jSONObject);
    return jSONObject;
  }
  
  private JSONObject composeStringList(Mergeable<?> paramMergeable, boolean paramBoolean) throws JSONException {
    SyncableStringList syncableStringList = (SyncableStringList)paramMergeable;
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("maxSize", syncableStringList.getMaxSize());
    jSONObject.put("values", composeStringListItems(syncableStringList));
    if (paramBoolean)
      jSONObject.put("state", paramMergeable.getState().toString()); 
    return jSONObject;
  }
  
  private JSONArray composeStringListItems(SyncableStringList paramSyncableStringList) throws JSONException {
    JSONArray jSONArray = new JSONArray();
    SyncableStringElement[] arrayOfSyncableStringElement = paramSyncableStringList.getValues();
    int j = arrayOfSyncableStringElement.length;
    for (int i = 0; i < j; i++)
      jSONArray.put(composeStringItem(arrayOfSyncableStringElement[i])); 
    return jSONArray;
  }
  
  private JSONObject composeStringSet(Mergeable<?> paramMergeable, boolean paramBoolean) throws JSONException {
    SyncableStringSet syncableStringSet = (SyncableStringSet)paramMergeable;
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("values", composeStringSetElements(syncableStringSet));
    if (paramBoolean)
      jSONObject.put("state", paramMergeable.getState().toString()); 
    return jSONObject;
  }
  
  private JSONArray composeStringSetElements(SyncableStringSet paramSyncableStringSet) throws JSONException {
    JSONArray jSONArray = new JSONArray();
    Iterator<SyncableStringElement> iterator = paramSyncableStringSet.iterator();
    while (iterator.hasNext())
      jSONArray.put(composeStringItem(iterator.next())); 
    return jSONArray;
  }
  
  private NumberList createNumberList(Key paramKey, int paramInt, List<NumberElement> paramList, SyncState paramSyncState) throws ParseException, JSONException {
    switch (paramKey.getType()) {
      default:
        throw new ParseException("Unexpected type [" + paramKey.getType() + "] associated with key name [" + paramKey.getName() + "]");
      case HIGHEST_NUMBER_LIST:
        return (NumberList)new HighNumberList(paramKey.getName(), paramList, paramInt, paramSyncState);
      case LOWEST_NUMBER_LIST:
        return (NumberList)new LowNumberList(paramKey.getName(), paramList, paramInt, paramSyncState);
      case LATEST_NUMBER_LIST:
        break;
    } 
    return (NumberList)new LatestNumberList(paramKey.getName(), paramList, paramInt, paramSyncState);
  }
  
  private AccumulatingNumber parseAccumulatingNumber(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    BigDecimal bigDecimal1 = parseBigDecimalFromValue(paramJSONObject, "local");
    BigDecimal bigDecimal2 = parseBigDecimalFromValue(paramJSONObject, "remote");
    return new AccumulatingNumber(paramKey.getName(), bigDecimal1, bigDecimal2, parseSyncState(paramJSONObject));
  }
  
  private BigDecimal parseBigDecimalFromValue(JSONObject paramJSONObject, String paramString) throws JSONException, ParseException {
    if (!paramJSONObject.has(paramString))
      throw new ParseException("Missing '" + paramString + "' field"); 
    Object object = paramJSONObject.get(paramString);
    if (object == null)
      throw new ParseException("Unable to parse '" + paramString + "' field"); 
    if (object instanceof Integer)
      return new BigDecimal(((Integer)object).intValue()); 
    if (object instanceof Long)
      return new BigDecimal(((Long)object).longValue()); 
    if (object instanceof Double)
      return new BigDecimal(((Double)object).doubleValue()); 
    throw new ParseException("Unable to parse '" + paramString + "'");
  }
  
  private InternalGameDataMap parseDataMap(JSONObject paramJSONObject) throws ParseException, JSONException {
    GameDataSingleMap gameDataSingleMap = new GameDataSingleMap();
    Iterator<String> iterator = paramJSONObject.keys();
    while (iterator.hasNext()) {
      String str = iterator.next();
      Key key = parseKey(str);
      gameDataSingleMap.putElement(key, parseDataMapEntry(key, paramJSONObject.getJSONObject(str)));
    } 
    return (InternalGameDataMap)gameDataSingleMap;
  }
  
  private Mergeable<?> parseDataMapEntry(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    switch (paramKey.getType()) {
      default:
        throw new ParseException("Invalid type [" + paramKey.getType() + "] associated with key name [" + paramKey.getName() + "]");
      case HIGHEST_NUMBER:
      case LOWEST_NUMBER:
      case LATEST_NUMBER:
        return parseNumber(paramKey, paramJSONObject);
      case ACCUMULATING_NUMBER:
        return (Mergeable<?>)parseAccumulatingNumber(paramKey, paramJSONObject);
      case HIGHEST_NUMBER_LIST:
      case LOWEST_NUMBER_LIST:
      case LATEST_NUMBER_LIST:
        return parseNumberList(paramKey, paramJSONObject);
      case LATEST_STRING_LIST:
        return (Mergeable<?>)parseStringList(paramKey, paramJSONObject);
      case LATEST_STRING:
        return parseString(paramKey, paramJSONObject);
      case DEVELOPER_STRING:
        return parseDeveloperString(paramKey, paramJSONObject);
      case STRING_SET:
        return (Mergeable<?>)parseStringSet(paramKey, paramJSONObject);
      case MAP:
        break;
    } 
    return (Mergeable<?>)parseDataMap(paramJSONObject);
  }
  
  private Mergeable<?> parseDeveloperString(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    return !paramJSONObject.has("value") ? parseDeveloperStringFromDisk(paramKey, paramJSONObject) : parseDeveloperStringFromService(paramKey, paramJSONObject);
  }
  
  private Mergeable<?> parseDeveloperStringFromDisk(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    // Byte code:
    //   0: aload_2
    //   1: ldc 'local'
    //   3: invokevirtual has : (Ljava/lang/String;)Z
    //   6: ifne -> 40
    //   9: new com/amazon/ags/client/whispersync/marshaller/ParseException
    //   12: dup
    //   13: new java/lang/StringBuilder
    //   16: dup
    //   17: invokespecial <init> : ()V
    //   20: ldc_w 'Missing 'local' field for key:'
    //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: aload_1
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   33: invokevirtual toString : ()Ljava/lang/String;
    //   36: invokespecial <init> : (Ljava/lang/String;)V
    //   39: athrow
    //   40: aload_0
    //   41: aload_2
    //   42: ldc 'local'
    //   44: invokespecial parseNullableStringValue : (Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;
    //   47: astore #10
    //   49: aconst_null
    //   50: astore #8
    //   52: lconst_0
    //   53: lstore #4
    //   55: iconst_1
    //   56: istore_3
    //   57: aload_0
    //   58: aload_2
    //   59: ldc 'remote'
    //   61: invokespecial parseNullableStringValue : (Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;
    //   64: astore #9
    //   66: aload #9
    //   68: astore #8
    //   70: aload_2
    //   71: ldc 'rts'
    //   73: invokevirtual getLong : (Ljava/lang/String;)J
    //   76: lstore #6
    //   78: lload #6
    //   80: lstore #4
    //   82: aload #9
    //   84: astore #8
    //   86: aload_0
    //   87: aload_2
    //   88: invokespecial parseTimestamp : (Lorg/json/JSONObject;)J
    //   91: lstore #6
    //   93: iload_3
    //   94: ifeq -> 129
    //   97: new com/amazon/ags/client/whispersync/model/DeveloperString
    //   100: dup
    //   101: aload_1
    //   102: invokevirtual getName : ()Ljava/lang/String;
    //   105: aload #10
    //   107: aload #8
    //   109: lload #6
    //   111: lload #4
    //   113: aload_0
    //   114: aload_2
    //   115: invokespecial parseSyncState : (Lorg/json/JSONObject;)Lcom/amazon/ags/client/whispersync/model/SyncState;
    //   118: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJLcom/amazon/ags/client/whispersync/model/SyncState;)V
    //   121: areturn
    //   122: astore #9
    //   124: iconst_0
    //   125: istore_3
    //   126: goto -> 86
    //   129: new com/amazon/ags/client/whispersync/model/DeveloperString
    //   132: dup
    //   133: aload_1
    //   134: invokevirtual getName : ()Ljava/lang/String;
    //   137: aload #10
    //   139: lload #6
    //   141: aload_0
    //   142: aload_2
    //   143: invokespecial parseSyncState : (Lorg/json/JSONObject;)Lcom/amazon/ags/client/whispersync/model/SyncState;
    //   146: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;JLcom/amazon/ags/client/whispersync/model/SyncState;)V
    //   149: areturn
    // Exception table:
    //   from	to	target	type
    //   57	66	122	org/json/JSONException
    //   70	78	122	org/json/JSONException
  }
  
  private Mergeable<?> parseDeveloperStringFromService(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    if (!paramJSONObject.has("value"))
      throw new ParseException("Missing 'value' field for key:" + paramKey.toString()); 
    String str = parseNullableStringValue(paramJSONObject, "value");
    long l = parseTimestamp(paramJSONObject);
    return (Mergeable<?>)new DeveloperString(paramKey.getName(), str, str, l, l, parseSyncState(paramJSONObject));
  }
  
  private Key parseKey(String paramString) throws ParseException {
    try {
      return new Key(paramString);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new ParseException("Invalid key: " + paramString);
    } 
  }
  
  private int parseMaxSize(JSONObject paramJSONObject) {
    try {
      return paramJSONObject.getInt("maxSize");
    } catch (JSONException jSONException) {
      return 5;
    } 
  }
  
  private Map<String, String> parseMetadata(JSONObject paramJSONObject) throws ParseException, JSONException {
    try {
      return parseMetadataNode(paramJSONObject.getJSONObject("md"));
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  private Map<String, String> parseMetadataNode(JSONObject paramJSONObject) throws JSONException {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<String> iterator = paramJSONObject.keys();
    while (iterator.hasNext()) {
      String str = iterator.next();
      try {
        hashMap.put(str, paramJSONObject.getString(str));
      } catch (JSONException jSONException) {
        Log.e("GC_Whispersync", "Unexpected type [" + paramJSONObject.get(str).getClass() + " for key [" + str + "]");
      } 
    } 
    return (Map)hashMap;
  }
  
  private String parseNullableStringValue(JSONObject paramJSONObject, String paramString) throws JSONException {
    return (paramJSONObject.get(paramString) == JSONObject.NULL) ? null : paramJSONObject.getString(paramString);
  }
  
  private Mergeable<?> parseNumber(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    BigDecimal bigDecimal = parseBigDecimalFromValue(paramJSONObject, "value");
    long l = parseTimestamp(paramJSONObject);
    Map<String, String> map = parseMetadata(paramJSONObject);
    SyncState syncState = parseSyncState(paramJSONObject);
    switch (paramKey.getType()) {
      default:
        throw new ParseException("Unexpected type [" + paramKey.getType() + "] associated with key name [" + paramKey.getName() + "]");
      case HIGHEST_NUMBER:
        return (Mergeable<?>)new HighestNumber(paramKey.getName(), bigDecimal, map, l, syncState);
      case LOWEST_NUMBER:
        return (Mergeable<?>)new LowestNumber(paramKey.getName(), bigDecimal, map, l, syncState);
      case LATEST_NUMBER:
        break;
    } 
    return (Mergeable<?>)new LatestNumber(paramKey.getName(), bigDecimal, map, l, syncState);
  }
  
  private NumberElement parseNumberElement(JSONObject paramJSONObject) throws ParseException, JSONException {
    BigDecimal bigDecimal = parseBigDecimalFromValue(paramJSONObject, "value");
    long l = parseTimestamp(paramJSONObject);
    return new NumberElement(bigDecimal, parseMetadata(paramJSONObject), l);
  }
  
  private Mergeable<?> parseNumberList(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    int i = parseMaxSize(paramJSONObject);
    ArrayList<NumberElement> arrayList = new ArrayList();
    JSONArray jSONArray = paramJSONObject.getJSONArray("values");
    if (jSONArray != null)
      for (int j = 0; j < jSONArray.length(); j++)
        arrayList.add(parseNumberElement(jSONArray.getJSONObject(j)));  
    return (Mergeable<?>)createNumberList(paramKey, i, arrayList, parseSyncState(paramJSONObject));
  }
  
  private Mergeable<?> parseString(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    if (!paramJSONObject.has("value"))
      throw new ParseException("Missing 'value' field for key:" + paramKey.toString()); 
    String str = parseNullableStringValue(paramJSONObject, "value");
    long l = parseTimestamp(paramJSONObject);
    Map<String, String> map = parseMetadata(paramJSONObject);
    SyncState syncState = parseSyncState(paramJSONObject);
    switch (paramKey.getType()) {
      default:
        throw new ParseException("Unexpected type [" + paramKey.getType() + "] associated with key name [" + paramKey.getName() + "]");
      case LATEST_STRING:
        break;
    } 
    return (Mergeable<?>)new LatestString(paramKey.getName(), str, map, l, syncState);
  }
  
  private StringElement parseStringItem(JSONObject paramJSONObject) throws ParseException, JSONException {
    if (!paramJSONObject.has("value"))
      throw new ParseException("Missing 'value' field for StringList item"); 
    String str = paramJSONObject.getString("value");
    long l = parseTimestamp(paramJSONObject);
    return new StringElement(str, parseMetadata(paramJSONObject), l);
  }
  
  private LatestStringList parseStringList(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    int i = parseMaxSize(paramJSONObject);
    ArrayList<StringElement> arrayList = new ArrayList();
    JSONArray jSONArray = paramJSONObject.getJSONArray("values");
    if (jSONArray != null)
      for (int j = 0; j < jSONArray.length(); j++)
        arrayList.add(parseStringItem(jSONArray.getJSONObject(j)));  
    SyncState syncState = parseSyncState(paramJSONObject);
    return new LatestStringList(paramKey.getName(), arrayList, i, syncState);
  }
  
  private StringSet parseStringSet(Key paramKey, JSONObject paramJSONObject) throws ParseException, JSONException {
    JSONArray jSONArray = paramJSONObject.getJSONArray("values");
    HashSet<StringElement> hashSet = new HashSet();
    if (jSONArray != null)
      for (int i = 0; i < jSONArray.length(); i++)
        hashSet.add(parseStringItem(jSONArray.getJSONObject(i)));  
    return new StringSet(paramKey.getName(), hashSet, parseSyncState(paramJSONObject));
  }
  
  private SyncState parseSyncState(JSONObject paramJSONObject) throws ParseException, JSONException {
    if (!paramJSONObject.has("state"))
      return SyncState.SYNCED; 
    String str = paramJSONObject.getString("state");
    if (str == null)
      return SyncState.SYNCED; 
    try {
      return SyncState.valueOf(str);
    } catch (Exception exception) {
      return SyncState.SYNCED;
    } 
  }
  
  private long parseTimestamp(JSONObject paramJSONObject) {
    try {
      return paramJSONObject.getLong("ts");
    } catch (JSONException jSONException) {
      Log.w("GC_Whispersync", "No timestamp value found in node [" + paramJSONObject.toString() + "]");
      return 0L;
    } 
  }
  
  private void reportEvent(String paramString) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createCountEvent(paramString, 1);
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
  }
  
  public String composeForDisk(InternalGameDataMap paramInternalGameDataMap) throws AGSClientException {
    JSONObject jSONObject = new JSONObject();
    if (paramInternalGameDataMap != null)
      try {
        JSONObject jSONObject1 = composeDataMap(paramInternalGameDataMap, true);
        jSONObject.put("gameData", jSONObject1);
        return jSONObject.toString();
      } catch (JSONException jSONException) {
        throw new AGSClientException("Unable to compose JSON", jSONException);
      }  
    paramInternalGameDataMap = null;
    jSONObject.put("gameData", paramInternalGameDataMap);
    return jSONObject.toString();
  }
  
  public String composeForService(InternalGameDataMap paramInternalGameDataMap) throws AGSClientException {
    try {
      JSONObject jSONObject = new JSONObject();
      if (paramInternalGameDataMap != null) {
        JSONObject jSONObject1 = composeDataMap(paramInternalGameDataMap, false);
        jSONObject.put("gameData", jSONObject1);
        return jSONObject.toString();
      } 
      Object object = JSONObject.NULL;
      jSONObject.put("gameData", object);
      return jSONObject.toString();
    } catch (JSONException jSONException) {
      throw new AGSClientException("Unable to compose JSON", jSONException);
    } 
  }
  
  public InternalGameDataMap parse(String paramString) {
    if (paramString != null)
      try {
        JSONObject jSONObject = new JSONObject(paramString);
        if (jSONObject.has("gameData")) {
          jSONObject = jSONObject.getJSONObject("gameData");
          if (jSONObject != null)
            return parseDataMap(jSONObject); 
        } 
        return null;
      } catch (Exception exception) {
        Log.e("GC_Whispersync", "Exception thrown while parsing game data JSON map [" + paramString + "]", exception);
        reportEvent("WHISPERSYNC_PARSE_EXCEPTION");
        return null;
      }  
    return null;
  }
  
  public void setEventCollectorClient(EventCollectorClient paramEventCollectorClient) {
    if (paramEventCollectorClient != null)
      this.eventCollectorClient = paramEventCollectorClient; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\marshaller\JsonGameDataMarshaller.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */