package com.amazon.ags.client.whispersync.marshaller;

public class ComposeException extends Exception {
  private static final long serialVersionUID = -8452283936316342389L;
  
  public ComposeException() {}
  
  public ComposeException(String paramString) {
    super(paramString);
  }
  
  public ComposeException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public ComposeException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\marshaller\ComposeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */