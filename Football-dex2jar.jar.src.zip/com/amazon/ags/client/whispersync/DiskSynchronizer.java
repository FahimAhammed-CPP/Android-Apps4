package com.amazon.ags.client.whispersync;

import android.util.Log;
import com.amazon.ags.AGSClientException;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import com.amazon.ags.client.whispersync.storage.LocalStorage;
import java.io.IOException;

public class DiskSynchronizer {
  private static final String TAG = "GC_Whispersync";
  
  private EventCollectorClient eventCollectorClient;
  
  private final InternalGameDataMap gameDataMap;
  
  private final LocalStorage localStorage;
  
  private final QuietPeriodListener quietListener;
  
  private final SyncRequestState syncRequestState;
  
  private final WhispersyncEventPoster whispersyncEventPoster;
  
  public DiskSynchronizer(InternalGameDataMap paramInternalGameDataMap, LocalStorage paramLocalStorage, SyncRequestState paramSyncRequestState, QuietPeriodListener paramQuietPeriodListener, WhispersyncEventPoster paramWhispersyncEventPoster, EventCollectorClient paramEventCollectorClient) {
    this.gameDataMap = paramInternalGameDataMap;
    this.localStorage = paramLocalStorage;
    this.syncRequestState = paramSyncRequestState;
    this.quietListener = paramQuietPeriodListener;
    this.whispersyncEventPoster = paramWhispersyncEventPoster;
    this.eventCollectorClient = paramEventCollectorClient;
  }
  
  private void reportBooleanEvent(String paramString, long paramLong, boolean paramBoolean) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createBooleanGenericEvent(paramString, Integer.valueOf(1), Long.valueOf(paramLong), Boolean.valueOf(paramBoolean));
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
  }
  
  private void reportCountEvent(String paramString) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createCountEvent(paramString, 1);
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
  }
  
  private void reportTimeEvent(String paramString, long paramLong) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createGenericEvent(paramString, Integer.valueOf(1), Long.valueOf(paramLong));
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
  }
  
  public void loadFromDisk() {
    long l1 = System.currentTimeMillis();
    Log.d("GC_Whispersync", "Initial load from disk started");
    boolean bool = false;
    try {
      InternalGameDataMap internalGameDataMap = this.localStorage.retrieve();
      this.gameDataMap.merge(internalGameDataMap);
      bool = true;
    } catch (IOException iOException) {
      Log.e("GC_Whispersync", "Initial load from disk failed", iOException);
      return;
    } catch (AGSClientException aGSClientException) {
      Log.e("GC_Whispersync", "Initial load from disk failed", (Throwable)aGSClientException);
    } 
    long l2 = System.currentTimeMillis();
    Log.d("GC_Whispersync", "Initial load from disk completed in " + (l2 - l1) + " msec.");
    reportBooleanEvent("WHISPERSYNC_DISK_TO_MEMORY_SYNC", l2 - l1, bool);
  }
  
  public void notifyDataChanged() {
    this.quietListener.breakSilence();
  }
  
  public void setEventCollectorClient(EventCollectorClient paramEventCollectorClient) {
    if (paramEventCollectorClient != null)
      this.eventCollectorClient = paramEventCollectorClient; 
  }
  
  public void syncToDisk() {
    this.quietListener.blockUntilQuiet();
    syncToDiskNow();
  }
  
  public void syncToDiskNow() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield syncRequestState : Lcom/amazon/ags/client/whispersync/SyncRequestState;
    //   6: iconst_0
    //   7: invokevirtual setDiskWriteRequested : (Z)V
    //   10: ldc 'GC_Whispersync'
    //   12: ldc 'Starting write to file system'
    //   14: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: aload_0
    //   19: getfield gameDataMap : Lcom/amazon/ags/client/whispersync/InternalGameDataMap;
    //   22: invokeinterface lockAndCopy : ()Lcom/amazon/ags/client/whispersync/InternalGameDataMap;
    //   27: astore_2
    //   28: aload_0
    //   29: getfield localStorage : Lcom/amazon/ags/client/whispersync/storage/LocalStorage;
    //   32: aload_2
    //   33: invokeinterface save : (Lcom/amazon/ags/client/whispersync/InternalGameDataMap;)I
    //   38: istore_1
    //   39: ldc 'GC_Whispersync'
    //   41: new java/lang/StringBuilder
    //   44: dup
    //   45: invokespecial <init> : ()V
    //   48: ldc 'Completed write of '
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: iload_1
    //   54: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   57: ldc ' bytes to file system'
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: invokevirtual toString : ()Ljava/lang/String;
    //   65: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   68: pop
    //   69: aload_0
    //   70: getfield whispersyncEventPoster : Lcom/amazon/ags/client/whispersync/WhispersyncEventPoster;
    //   73: getstatic com/amazon/ags/client/whispersync/WhispersyncEvent.DISK_WRITE_COMPLETE : Lcom/amazon/ags/client/whispersync/WhispersyncEvent;
    //   76: invokevirtual postEvent : (Lcom/amazon/ags/client/whispersync/WhispersyncEvent;)V
    //   79: aload_0
    //   80: monitorexit
    //   81: return
    //   82: astore_2
    //   83: ldc 'GC_Whispersync'
    //   85: ldc 'Unable to write to file system.'
    //   87: aload_2
    //   88: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   91: pop
    //   92: aload_0
    //   93: ldc 'WHISPERSYNC_CLOUD_SYNC_IO_EXCEPTION'
    //   95: invokespecial reportCountEvent : (Ljava/lang/String;)V
    //   98: goto -> 79
    //   101: astore_2
    //   102: aload_0
    //   103: monitorexit
    //   104: aload_2
    //   105: athrow
    //   106: astore_2
    //   107: ldc 'GC_Whispersync'
    //   109: ldc 'Unable to write to file system.'
    //   111: aload_2
    //   112: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   115: pop
    //   116: aload_0
    //   117: ldc 'WHISPERSYNC_CLOUD_SYNC_CLIENT_EXCEPTION'
    //   119: invokespecial reportCountEvent : (Ljava/lang/String;)V
    //   122: goto -> 79
    // Exception table:
    //   from	to	target	type
    //   2	18	101	finally
    //   18	79	82	java/io/IOException
    //   18	79	106	com/amazon/ags/AGSClientException
    //   18	79	101	finally
    //   83	98	101	finally
    //   107	122	101	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\DiskSynchronizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */