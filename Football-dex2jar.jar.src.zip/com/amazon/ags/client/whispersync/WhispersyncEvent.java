package com.amazon.ags.client.whispersync;

public enum WhispersyncEvent {
  ALREADY_SYNCED, DATA_UPLOADED_TO_CLOUD, DISABLED, DISK_WRITE_COMPLETE, ERROR_CLIENT, ERROR_SERVICE, FIRST_SYNC, NEW_DATA_FROM_CLOUD, OFFLINE, THROTTLED;
  
  static {
    DATA_UPLOADED_TO_CLOUD = new WhispersyncEvent("DATA_UPLOADED_TO_CLOUD", 1);
    THROTTLED = new WhispersyncEvent("THROTTLED", 2);
    DISK_WRITE_COMPLETE = new WhispersyncEvent("DISK_WRITE_COMPLETE", 3);
    FIRST_SYNC = new WhispersyncEvent("FIRST_SYNC", 4);
    ALREADY_SYNCED = new WhispersyncEvent("ALREADY_SYNCED", 5);
    OFFLINE = new WhispersyncEvent("OFFLINE", 6);
    DISABLED = new WhispersyncEvent("DISABLED", 7);
    ERROR_SERVICE = new WhispersyncEvent("ERROR_SERVICE", 8);
    ERROR_CLIENT = new WhispersyncEvent("ERROR_CLIENT", 9);
    $VALUES = new WhispersyncEvent[] { NEW_DATA_FROM_CLOUD, DATA_UPLOADED_TO_CLOUD, THROTTLED, DISK_WRITE_COMPLETE, FIRST_SYNC, ALREADY_SYNCED, OFFLINE, DISABLED, ERROR_SERVICE, ERROR_CLIENT };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\WhispersyncEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */