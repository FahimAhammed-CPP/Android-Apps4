package com.amazon.ags.client.whispersync;

public class SimpleQuietPeriodListener implements QuietPeriodListener {
  private final long quietPeriodDuration;
  
  private long quietPeriodEnd = 0L;
  
  public SimpleQuietPeriodListener(long paramLong) {
    this.quietPeriodDuration = paramLong;
  }
  
  public void blockUntilQuiet() {
    while (true) {
      long l = this.quietPeriodEnd - System.currentTimeMillis();
      if (l > 0L) {
        try {
          Thread.sleep(l);
        } catch (InterruptedException interruptedException) {
          Thread.currentThread().interrupt();
        } 
        continue;
      } 
      break;
    } 
  }
  
  public void breakSilence() {
    this.quietPeriodEnd = System.currentTimeMillis() + this.quietPeriodDuration;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\SimpleQuietPeriodListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */