package com.amazon.ags.client.whispersync.migration;

import android.util.Log;
import com.amazon.ags.api.whispersync.migration.MigrationCallback;
import com.amazon.ags.api.whispersync.migration.MigrationResultCode;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import com.amazon.ags.client.whispersync.settings.WhispersyncUserSettingsManager;
import com.amazon.ags.html5.comm.ConnectionException;
import com.amazon.ags.html5.util.NetworkUtil;
import java.io.File;
import java.io.IOException;

public final class MigrationManager {
  private static final String TAG = "GC_Whispersync";
  
  private EventCollectorClient eventCollectorClient;
  
  private final MigrationHttpClient migrationClient;
  
  private final NetworkUtil networkUtil;
  
  private final WhispersyncUserSettingsManager settingsManager;
  
  public MigrationManager(MigrationHttpClient paramMigrationHttpClient, NetworkUtil paramNetworkUtil, WhispersyncUserSettingsManager paramWhispersyncUserSettingsManager, EventCollectorClient paramEventCollectorClient) {
    this.migrationClient = paramMigrationHttpClient;
    this.networkUtil = paramNetworkUtil;
    this.settingsManager = paramWhispersyncUserSettingsManager;
    this.eventCollectorClient = paramEventCollectorClient;
  }
  
  private void downloadBackground(MigrationCallback paramMigrationCallback) {
    if (!this.networkUtil.isNetworkConnected()) {
      paramMigrationCallback.onComplete(MigrationResultCode.NETWORK_FAILURE, null);
      reportMigrationEventWithResultCode(MigrationResultCode.NETWORK_FAILURE);
      return;
    } 
    if (this.settingsManager.isWhispersyncEnabled() == WhispersyncUserSettingsManager.YesNoMaybe.NO) {
      paramMigrationCallback.onComplete(MigrationResultCode.WHISPERSYNC_OFF, null);
      reportMigrationEventWithResultCode(MigrationResultCode.WHISPERSYNC_OFF);
      return;
    } 
    try {
      String str = this.migrationClient.getV1GameDataDownloadUrl();
      if (str == null) {
        paramMigrationCallback.onComplete(MigrationResultCode.FAILURE, null);
        reportMigrationEventWithResultCode(MigrationResultCode.FAILURE);
        return;
      } 
    } catch (ConnectionException connectionException) {
      paramMigrationCallback.onComplete(MigrationResultCode.NETWORK_FAILURE, null);
      reportMigrationEventWithResultCode(MigrationResultCode.NETWORK_FAILURE);
      return;
    } catch (Exception exception) {
      paramMigrationCallback.onComplete(MigrationResultCode.FAILURE, null);
      reportMigrationEventWithResultCode(MigrationResultCode.FAILURE);
      return;
    } 
    DownloadResult downloadResult = this.migrationClient.download((String)exception);
    paramMigrationCallback.onComplete(downloadResult.getResultCode(), downloadResult.getGameData());
    reportMigrationEventWithResultCode(downloadResult.getResultCode());
  }
  
  private String getEventNameFromResultCode(MigrationResultCode paramMigrationResultCode) {
    return MigrationResultCode.FAILURE.equals(paramMigrationResultCode) ? "WHISPERSYNC_V1_MIGRATION_FAILURE" : (MigrationResultCode.NETWORK_FAILURE.equals(paramMigrationResultCode) ? "WHISPERSYNC_V1_MIGRATION_NO_NETWORK" : (MigrationResultCode.NO_DATA.equals(paramMigrationResultCode) ? "WHISPERSYNC_V1_MIGRATION_NO_DATA" : (MigrationResultCode.WHISPERSYNC_OFF.equals(paramMigrationResultCode) ? "WHISPERSYNC_V1_MIGRATION_WHISPERSYNC_OFF" : "WHISPERSYNC_V1_MIGRATION")));
  }
  
  private void reportMigrationEvent(boolean paramBoolean) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createBooleanCountEvent("WHISPERSYNC_V1_MIGRATION", 1, paramBoolean);
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
  }
  
  private void reportMigrationEventWithResultCode(MigrationResultCode paramMigrationResultCode) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createCountEvent(getEventNameFromResultCode(paramMigrationResultCode), 1);
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
    reportMigrationEvent(MigrationResultCode.SUCCESS.equals(paramMigrationResultCode));
  }
  
  private void reportUnpackMultifile(boolean paramBoolean) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createBooleanCountEvent("WHISPERSYNC_V1_UNPACK_MULTIFILE", 1, paramBoolean);
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
  }
  
  public void downloadV1GameData(final MigrationCallback callback) {
    (new Thread() {
        public void run() {
          MigrationManager.this.downloadBackground(callback);
        }
      }).start();
  }
  
  public void setEventCollectorClient(EventCollectorClient paramEventCollectorClient) {
    if (paramEventCollectorClient != null)
      this.eventCollectorClient = paramEventCollectorClient; 
  }
  
  public void unpackV1MultiFileGameData(byte[] paramArrayOfbyte, File paramFile) throws IOException {
    ZipUtil zipUtil = new ZipUtil();
    try {
      zipUtil.unzip(paramArrayOfbyte, paramFile);
      Log.d("GC_Whispersync", "Successfully unpacked new multi-file game data");
      reportUnpackMultifile(true);
      return;
    } catch (IOException iOException) {
      reportUnpackMultifile(false);
      throw iOException;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\migration\MigrationManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */