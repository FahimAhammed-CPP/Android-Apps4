package com.amazon.ags.client.whispersync.migration;

import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class ZipUtil {
  private static final int KIBI = 1024;
  
  private static final String TAG = "GC_Whispersync";
  
  private ZipInputStream zipInputStream;
  
  private ZipEntry getNextEntry(ZipInputStream paramZipInputStream) {
    try {
      return paramZipInputStream.getNextEntry();
    } catch (EOFException eOFException) {
      Log.d("GC_Whispersync", "Ignoring EOFException");
      return null;
    } catch (IOException iOException) {
      return null;
    } 
  }
  
  private void unzipFile(File paramFile) throws IOException {
    Exception exception1;
    byte[] arrayOfByte1;
    paramFile.getParentFile().mkdirs();
    byte[] arrayOfByte2 = new byte[1024];
    Exception exception2 = null;
    try {
    
    } finally {
      arrayOfByte2 = null;
      exception1 = exception2;
    } 
    this.zipInputStream.closeEntry();
    if (exception1 != null)
      exception1.close(); 
    throw arrayOfByte1;
  }
  
  public final void unzip(InputStream paramInputStream, File paramFile) throws IOException {
    if (paramInputStream == null)
      throw new IllegalArgumentException("source cannot be null"); 
    if (paramFile == null)
      throw new IllegalArgumentException("destinationDir cannot be null"); 
    Log.d("GC_Whispersync", "Entering unzip() with destination directory [" + paramFile.getPath() + "]");
    this.zipInputStream = new ZipInputStream(paramInputStream);
    while (true) {
      try {
        ZipEntry zipEntry = getNextEntry(this.zipInputStream);
      } finally {
        if (this.zipInputStream != null)
          this.zipInputStream.close(); 
      } 
      if (this.zipInputStream != null)
        this.zipInputStream.close(); 
      return;
    } 
  }
  
  public final void unzip(byte[] paramArrayOfbyte, File paramFile) throws IOException {
    if (paramArrayOfbyte == null)
      throw new IllegalArgumentException("source cannot be null"); 
    unzip(new ByteArrayInputStream(paramArrayOfbyte), paramFile);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\migration\ZipUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */