package com.amazon.ags.client.whispersync.migration;

import com.amazon.ags.api.whispersync.migration.MigrationResultCode;

public class DownloadResult {
  private final byte[] gameData;
  
  private final MigrationResultCode resultCode;
  
  public DownloadResult(byte[] paramArrayOfbyte, MigrationResultCode paramMigrationResultCode) {
    this.gameData = paramArrayOfbyte;
    this.resultCode = paramMigrationResultCode;
  }
  
  public byte[] getGameData() {
    return this.gameData;
  }
  
  public MigrationResultCode getResultCode() {
    return this.resultCode;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\migration\DownloadResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */