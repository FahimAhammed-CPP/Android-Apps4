package com.amazon.ags.client.whispersync.migration;

import android.util.Log;
import com.amazon.ags.AGSClientException;
import com.amazon.ags.AGSServiceException;
import com.amazon.ags.html5.comm.AGSHttpGet;
import com.amazon.ags.html5.comm.ConnectionException;
import com.amazon.ags.html5.comm.NetworkClient;
import com.amazon.ags.html5.comm.ServiceRequestBase;
import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.json.JSONObject;

public class MigrationHttpClient {
  private static final String DOWNLOAD_URL = "https://cortana-gateway.amazon.com/cortana/gateway/getSignedDownloadUrl";
  
  private static final String DOWNLOAD_URL_RESPONSE_KEY = "downloadUrl";
  
  private static final String GAME_ID_PARAMETER_NAME = "GameId";
  
  private static final String GAME_PACKAGE_PARAM_NAME = "PackageName";
  
  private static final String TAG = "GC_Whispersync";
  
  private final String gameId;
  
  private final HttpClient httpClient;
  
  private final NetworkClient networkClient;
  
  private final String packageName;
  
  public MigrationHttpClient(String paramString1, String paramString2, NetworkClient paramNetworkClient, HttpClient paramHttpClient) {
    this.gameId = paramString2;
    this.packageName = paramString1;
    this.networkClient = paramNetworkClient;
    this.httpClient = paramHttpClient;
  }
  
  private boolean isResponseNoSuchKey(HttpResponse paramHttpResponse) {
    return (paramHttpResponse.getStatusLine().getStatusCode() == 404);
  }
  
  private String parseUrlFromResponse(String paramString) {
    try {
      return (new JSONObject(paramString)).getString("downloadUrl");
    } catch (Exception exception) {
      Log.e("GC_Whispersync", "Conversion - Error retrieving download URL", exception);
      return null;
    } 
  }
  
  public final DownloadResult download(String paramString) {
    // Byte code:
    //   0: new org/apache/http/client/methods/HttpGet
    //   3: dup
    //   4: aload_1
    //   5: invokespecial <init> : (Ljava/lang/String;)V
    //   8: astore_3
    //   9: aload_0
    //   10: getfield httpClient : Lorg/apache/http/client/HttpClient;
    //   13: aload_3
    //   14: invokeinterface execute : (Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
    //   19: astore_1
    //   20: aload_1
    //   21: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
    //   26: invokeinterface getStatusCode : ()I
    //   31: sipush #200
    //   34: if_icmpeq -> 170
    //   37: aload_0
    //   38: aload_1
    //   39: invokespecial isResponseNoSuchKey : (Lorg/apache/http/HttpResponse;)Z
    //   42: ifeq -> 125
    //   45: ldc 'GC_Whispersync'
    //   47: ldc 'Conversion - No V1 game data exists'
    //   49: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   52: pop
    //   53: new com/amazon/ags/client/whispersync/migration/DownloadResult
    //   56: dup
    //   57: aconst_null
    //   58: getstatic com/amazon/ags/api/whispersync/migration/MigrationResultCode.NO_DATA : Lcom/amazon/ags/api/whispersync/migration/MigrationResultCode;
    //   61: invokespecial <init> : ([BLcom/amazon/ags/api/whispersync/migration/MigrationResultCode;)V
    //   64: areturn
    //   65: astore_3
    //   66: ldc 'GC_Whispersync'
    //   68: new java/lang/StringBuilder
    //   71: dup
    //   72: invokespecial <init> : ()V
    //   75: ldc 'Conversion - invalid URI:'
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: aload_1
    //   81: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: invokevirtual toString : ()Ljava/lang/String;
    //   87: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   90: pop
    //   91: new com/amazon/ags/client/whispersync/migration/DownloadResult
    //   94: dup
    //   95: aconst_null
    //   96: getstatic com/amazon/ags/api/whispersync/migration/MigrationResultCode.FAILURE : Lcom/amazon/ags/api/whispersync/migration/MigrationResultCode;
    //   99: invokespecial <init> : ([BLcom/amazon/ags/api/whispersync/migration/MigrationResultCode;)V
    //   102: areturn
    //   103: astore_1
    //   104: ldc 'GC_Whispersync'
    //   106: ldc 'Conversion - Unable to download V1 game data'
    //   108: aload_1
    //   109: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   112: pop
    //   113: new com/amazon/ags/client/whispersync/migration/DownloadResult
    //   116: dup
    //   117: aconst_null
    //   118: getstatic com/amazon/ags/api/whispersync/migration/MigrationResultCode.NETWORK_FAILURE : Lcom/amazon/ags/api/whispersync/migration/MigrationResultCode;
    //   121: invokespecial <init> : ([BLcom/amazon/ags/api/whispersync/migration/MigrationResultCode;)V
    //   124: areturn
    //   125: ldc 'GC_Whispersync'
    //   127: new java/lang/StringBuilder
    //   130: dup
    //   131: invokespecial <init> : ()V
    //   134: ldc 'Conversion - Unexpected response code: '
    //   136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: aload_1
    //   140: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
    //   145: invokevirtual toString : ()Ljava/lang/String;
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: invokevirtual toString : ()Ljava/lang/String;
    //   154: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   157: pop
    //   158: new com/amazon/ags/client/whispersync/migration/DownloadResult
    //   161: dup
    //   162: aconst_null
    //   163: getstatic com/amazon/ags/api/whispersync/migration/MigrationResultCode.FAILURE : Lcom/amazon/ags/api/whispersync/migration/MigrationResultCode;
    //   166: invokespecial <init> : ([BLcom/amazon/ags/api/whispersync/migration/MigrationResultCode;)V
    //   169: areturn
    //   170: aload_1
    //   171: invokeinterface getEntity : ()Lorg/apache/http/HttpEntity;
    //   176: invokeinterface getContent : ()Ljava/io/InputStream;
    //   181: astore_3
    //   182: new java/io/ByteArrayOutputStream
    //   185: dup
    //   186: invokespecial <init> : ()V
    //   189: astore_1
    //   190: sipush #1024
    //   193: newarray byte
    //   195: astore #4
    //   197: aload_3
    //   198: aload #4
    //   200: invokevirtual read : ([B)I
    //   203: istore_2
    //   204: iload_2
    //   205: ifle -> 303
    //   208: aload_1
    //   209: aload #4
    //   211: iconst_0
    //   212: iload_2
    //   213: invokevirtual write : ([BII)V
    //   216: goto -> 197
    //   219: astore_3
    //   220: ldc 'GC_Whispersync'
    //   222: ldc 'Conversion - Network timeout'
    //   224: aload_3
    //   225: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   228: pop
    //   229: new com/amazon/ags/client/whispersync/migration/DownloadResult
    //   232: dup
    //   233: aconst_null
    //   234: getstatic com/amazon/ags/api/whispersync/migration/MigrationResultCode.FAILURE : Lcom/amazon/ags/api/whispersync/migration/MigrationResultCode;
    //   237: invokespecial <init> : ([BLcom/amazon/ags/api/whispersync/migration/MigrationResultCode;)V
    //   240: astore_3
    //   241: aload_1
    //   242: invokevirtual close : ()V
    //   245: aload_3
    //   246: areturn
    //   247: astore_1
    //   248: ldc 'GC_Whispersync'
    //   250: ldc 'Conversion - Error while closing download stream'
    //   252: aload_1
    //   253: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   256: pop
    //   257: aload_3
    //   258: areturn
    //   259: astore_1
    //   260: ldc 'GC_Whispersync'
    //   262: ldc 'Conversion - Unexpected exception: '
    //   264: aload_1
    //   265: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   268: pop
    //   269: new com/amazon/ags/client/whispersync/migration/DownloadResult
    //   272: dup
    //   273: aconst_null
    //   274: getstatic com/amazon/ags/api/whispersync/migration/MigrationResultCode.FAILURE : Lcom/amazon/ags/api/whispersync/migration/MigrationResultCode;
    //   277: invokespecial <init> : ([BLcom/amazon/ags/api/whispersync/migration/MigrationResultCode;)V
    //   280: areturn
    //   281: astore_1
    //   282: ldc 'GC_Whispersync'
    //   284: ldc 'Conversion - Unexpected exception: '
    //   286: aload_1
    //   287: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   290: pop
    //   291: new com/amazon/ags/client/whispersync/migration/DownloadResult
    //   294: dup
    //   295: aconst_null
    //   296: getstatic com/amazon/ags/api/whispersync/migration/MigrationResultCode.FAILURE : Lcom/amazon/ags/api/whispersync/migration/MigrationResultCode;
    //   299: invokespecial <init> : ([BLcom/amazon/ags/api/whispersync/migration/MigrationResultCode;)V
    //   302: areturn
    //   303: aload_1
    //   304: invokevirtual toByteArray : ()[B
    //   307: astore_3
    //   308: aload_1
    //   309: invokevirtual close : ()V
    //   312: new com/amazon/ags/client/whispersync/migration/DownloadResult
    //   315: dup
    //   316: aload_3
    //   317: getstatic com/amazon/ags/api/whispersync/migration/MigrationResultCode.SUCCESS : Lcom/amazon/ags/api/whispersync/migration/MigrationResultCode;
    //   320: invokespecial <init> : ([BLcom/amazon/ags/api/whispersync/migration/MigrationResultCode;)V
    //   323: areturn
    //   324: astore_1
    //   325: ldc 'GC_Whispersync'
    //   327: ldc 'Conversion - Error while closing download stream'
    //   329: aload_1
    //   330: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   333: pop
    //   334: goto -> 312
    //   337: astore_3
    //   338: ldc 'GC_Whispersync'
    //   340: ldc 'Conversion - Unexpected exception: '
    //   342: aload_3
    //   343: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   346: pop
    //   347: new com/amazon/ags/client/whispersync/migration/DownloadResult
    //   350: dup
    //   351: aconst_null
    //   352: getstatic com/amazon/ags/api/whispersync/migration/MigrationResultCode.FAILURE : Lcom/amazon/ags/api/whispersync/migration/MigrationResultCode;
    //   355: invokespecial <init> : ([BLcom/amazon/ags/api/whispersync/migration/MigrationResultCode;)V
    //   358: astore_3
    //   359: aload_1
    //   360: invokevirtual close : ()V
    //   363: aload_3
    //   364: areturn
    //   365: astore_1
    //   366: ldc 'GC_Whispersync'
    //   368: ldc 'Conversion - Error while closing download stream'
    //   370: aload_1
    //   371: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   374: pop
    //   375: aload_3
    //   376: areturn
    //   377: astore_3
    //   378: aload_1
    //   379: invokevirtual close : ()V
    //   382: aload_3
    //   383: athrow
    //   384: astore_1
    //   385: ldc 'GC_Whispersync'
    //   387: ldc 'Conversion - Error while closing download stream'
    //   389: aload_1
    //   390: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   393: pop
    //   394: goto -> 382
    // Exception table:
    //   from	to	target	type
    //   0	9	65	java/lang/Exception
    //   9	20	103	java/lang/Exception
    //   170	182	259	java/lang/IllegalStateException
    //   170	182	281	java/io/IOException
    //   190	197	219	javax/net/ssl/SSLException
    //   190	197	337	java/io/IOException
    //   190	197	377	finally
    //   197	204	219	javax/net/ssl/SSLException
    //   197	204	337	java/io/IOException
    //   197	204	377	finally
    //   208	216	219	javax/net/ssl/SSLException
    //   208	216	337	java/io/IOException
    //   208	216	377	finally
    //   220	241	377	finally
    //   241	245	247	java/io/IOException
    //   303	308	219	javax/net/ssl/SSLException
    //   303	308	337	java/io/IOException
    //   303	308	377	finally
    //   308	312	324	java/io/IOException
    //   338	359	377	finally
    //   359	363	365	java/io/IOException
    //   378	382	384	java/io/IOException
  }
  
  public String getV1GameDataDownloadUrl() throws ConnectionException, AGSServiceException, AGSClientException, IOException {
    AGSHttpGet aGSHttpGet = new AGSHttpGet("https://cortana-gateway.amazon.com/cortana/gateway/getSignedDownloadUrl", true);
    aGSHttpGet.putUrlParameter("PackageName", this.packageName);
    aGSHttpGet.putHeaderParameter("GameId", this.gameId);
    String str = this.networkClient.execute((ServiceRequestBase)aGSHttpGet).getContent();
    return (str != null) ? parseUrlFromResponse(str) : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\migration\MigrationHttpClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */