package com.amazon.ags.client.whispersync;

import android.content.Context;
import android.util.Log;
import com.amazon.ags.api.whispersync.GameDataMap;
import com.amazon.ags.api.whispersync.WhispersyncClient;
import com.amazon.ags.api.whispersync.WhispersyncEventListener;
import com.amazon.ags.api.whispersync.migration.MigrationCallback;
import com.amazon.ags.api.whispersync.migration.MigrationResultCode;
import com.amazon.ags.auth.AuthManager;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.session.SessionClient;
import com.amazon.ags.client.whispersync.clock.Clock;
import com.amazon.ags.client.whispersync.clock.ClockSkewSharedPrefs;
import com.amazon.ags.client.whispersync.clock.ClockSkewStorage;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import com.amazon.ags.client.whispersync.clock.GameDataServiceSyncedClock;
import com.amazon.ags.client.whispersync.clock.LocalClock;
import com.amazon.ags.client.whispersync.event.WhispersyncJavascriptEventListener;
import com.amazon.ags.client.whispersync.marshaller.GameDataMarshaller;
import com.amazon.ags.client.whispersync.marshaller.JsonGameDataMarshaller;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import com.amazon.ags.client.whispersync.migration.MigrationHttpClient;
import com.amazon.ags.client.whispersync.migration.MigrationManager;
import com.amazon.ags.client.whispersync.network.WhispersyncHttpClient;
import com.amazon.ags.client.whispersync.network.WhispersyncHttpClientImpl;
import com.amazon.ags.client.whispersync.settings.WebOverlayWhispersyncSettingsManager;
import com.amazon.ags.client.whispersync.settings.WhispersyncUserSettingsManager;
import com.amazon.ags.client.whispersync.storage.CloudStorage;
import com.amazon.ags.client.whispersync.storage.DiskStorage;
import com.amazon.ags.client.whispersync.storage.LocalStorage;
import com.amazon.ags.client.whispersync.storage.RemoteStorage;
import com.amazon.ags.html5.comm.NetworkClient;
import com.amazon.ags.html5.javascript.event.JavascriptEventListener;
import com.amazon.ags.html5.javascript.event.JavascriptEventsManager;
import com.amazon.ags.html5.util.NetworkUtil;
import com.amazon.ags.storage.StringObfuscator;
import java.io.File;
import java.io.IOException;
import org.apache.http.client.HttpClient;

public final class WhispersyncClientImpl implements WhispersyncClient {
  private static final long DEFAULT_QUIET_PERIOD_MS = 50L;
  
  private static final String TAG = "GC_Whispersync";
  
  private static final String WHISPERSYNC_JAVASCRIPT_LISTENER_ID = "whispersyncListener";
  
  private static WhispersyncClientImpl theInstance;
  
  private final Context context;
  
  private EventCollectorClient eventCollectorClient;
  
  private final InternalGameDataMap gameDataMap;
  
  private final DiskStorage localStorage;
  
  private final JsonGameDataMarshaller marshaller;
  
  private MigrationManager migrationManager = null;
  
  private final SyncRequestState syncRequestState;
  
  private final SynchronizationManager synchronizationManager;
  
  private final WhispersyncEventPoster whispersyncEventPoster;
  
  public WhispersyncClientImpl(Context paramContext, StringObfuscator paramStringObfuscator, EventCollectorClient paramEventCollectorClient) {
    this.context = paramContext;
    this.eventCollectorClient = paramEventCollectorClient;
    this.gameDataMap = new GameDataSingleMap();
    this.marshaller = new JsonGameDataMarshaller(paramEventCollectorClient);
    this.localStorage = new DiskStorage(paramContext, (GameDataMarshaller)this.marshaller, paramStringObfuscator);
    this.syncRequestState = new SyncRequestState();
    SimpleQuietPeriodListener simpleQuietPeriodListener = new SimpleQuietPeriodListener(50L);
    this.whispersyncEventPoster = new WhispersyncEventPoster();
    this.synchronizationManager = new SynchronizationManager(new DiskSynchronizer(this.gameDataMap, (LocalStorage)this.localStorage, this.syncRequestState, simpleQuietPeriodListener, this.whispersyncEventPoster, paramEventCollectorClient), this.syncRequestState, this.whispersyncEventPoster);
  }
  
  public static WhispersyncClientImpl getInstance() {
    if (theInstance == null)
      Log.e("Whispersync", "Whispersync client has not been initialized.  Please call AmazonGames.initialize()"); 
    return theInstance;
  }
  
  public static boolean hasSuccessfullySynchronized() {
    return theInstance.localStorage.hasSuccessfullySynchronized();
  }
  
  public static void initialize(Context paramContext, StringObfuscator paramStringObfuscator, EventCollectorClient paramEventCollectorClient) {
    // Byte code:
    //   0: ldc com/amazon/ags/client/whispersync/WhispersyncClientImpl
    //   2: monitorenter
    //   3: getstatic com/amazon/ags/client/whispersync/WhispersyncClientImpl.theInstance : Lcom/amazon/ags/client/whispersync/WhispersyncClientImpl;
    //   6: ifnonnull -> 32
    //   9: new com/amazon/ags/client/whispersync/WhispersyncClientImpl
    //   12: dup
    //   13: aload_0
    //   14: aload_1
    //   15: aload_2
    //   16: invokespecial <init> : (Landroid/content/Context;Lcom/amazon/ags/storage/StringObfuscator;Lcom/amazon/ags/client/metrics/EventCollectorClient;)V
    //   19: putstatic com/amazon/ags/client/whispersync/WhispersyncClientImpl.theInstance : Lcom/amazon/ags/client/whispersync/WhispersyncClientImpl;
    //   22: getstatic com/amazon/ags/client/whispersync/WhispersyncClientImpl.theInstance : Lcom/amazon/ags/client/whispersync/WhispersyncClientImpl;
    //   25: invokespecial syncMemoryFromDisk : ()V
    //   28: ldc com/amazon/ags/client/whispersync/WhispersyncClientImpl
    //   30: monitorexit
    //   31: return
    //   32: ldc 'Whispersync'
    //   34: ldc 'WhispersyncClient has already been initialized'
    //   36: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   39: pop
    //   40: getstatic com/amazon/ags/client/whispersync/WhispersyncClientImpl.theInstance : Lcom/amazon/ags/client/whispersync/WhispersyncClientImpl;
    //   43: getfield localStorage : Lcom/amazon/ags/client/whispersync/storage/DiskStorage;
    //   46: aload_1
    //   47: invokevirtual setStringObfuscator : (Lcom/amazon/ags/storage/StringObfuscator;)V
    //   50: getstatic com/amazon/ags/client/whispersync/WhispersyncClientImpl.theInstance : Lcom/amazon/ags/client/whispersync/WhispersyncClientImpl;
    //   53: aload_2
    //   54: putfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   57: getstatic com/amazon/ags/client/whispersync/WhispersyncClientImpl.theInstance : Lcom/amazon/ags/client/whispersync/WhispersyncClientImpl;
    //   60: getfield synchronizationManager : Lcom/amazon/ags/client/whispersync/SynchronizationManager;
    //   63: aload_2
    //   64: invokevirtual setEventCollectorClient : (Lcom/amazon/ags/client/metrics/EventCollectorClient;)V
    //   67: getstatic com/amazon/ags/client/whispersync/WhispersyncClientImpl.theInstance : Lcom/amazon/ags/client/whispersync/WhispersyncClientImpl;
    //   70: getfield migrationManager : Lcom/amazon/ags/client/whispersync/migration/MigrationManager;
    //   73: ifnull -> 28
    //   76: getstatic com/amazon/ags/client/whispersync/WhispersyncClientImpl.theInstance : Lcom/amazon/ags/client/whispersync/WhispersyncClientImpl;
    //   79: getfield migrationManager : Lcom/amazon/ags/client/whispersync/migration/MigrationManager;
    //   82: aload_2
    //   83: invokevirtual setEventCollectorClient : (Lcom/amazon/ags/client/metrics/EventCollectorClient;)V
    //   86: goto -> 28
    //   89: astore_0
    //   90: ldc com/amazon/ags/client/whispersync/WhispersyncClientImpl
    //   92: monitorexit
    //   93: aload_0
    //   94: athrow
    // Exception table:
    //   from	to	target	type
    //   3	28	89	finally
    //   32	86	89	finally
  }
  
  private void reportEvent(String paramString) {
    GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createCountEvent(paramString, 1);
    if (gameCircleGenericEvent != null)
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
  }
  
  private void syncMemoryFromDisk() {
    this.synchronizationManager.syncFromDiskToMemory();
  }
  
  public static void syncPassively() {
    theInstance.synchronizationManager.syncPassively();
  }
  
  public void flush() {
    this.synchronizationManager.flush();
    reportEvent("WHISPERSYNC_MANUAL_FLUSH");
  }
  
  public GameDataMap getGameData() {
    GameDataLock.lock();
    try {
      return this.gameDataMap;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public void migrateVersion1GameData(MigrationCallback paramMigrationCallback) {
    if (this.migrationManager == null) {
      Log.e("GC_Whispersync", "Unable to download version 1.x game data until client is ready.  Please wait for AmazonGamesCallback.onServiceReady()");
      paramMigrationCallback.onComplete(MigrationResultCode.FAILURE, null);
      return;
    } 
    this.migrationManager.downloadV1GameData(paramMigrationCallback);
  }
  
  public void setNetworkDependencies(NetworkClient paramNetworkClient, NetworkUtil paramNetworkUtil, SessionClient paramSessionClient, HttpClient paramHttpClient, AuthManager paramAuthManager, JavascriptEventsManager paramJavascriptEventsManager) {
    String str2 = this.context.getPackageName();
    String str1 = paramAuthManager.getGameId();
    WhispersyncHttpClientImpl whispersyncHttpClientImpl = new WhispersyncHttpClientImpl(paramNetworkClient, str1);
    WebOverlayWhispersyncSettingsManager webOverlayWhispersyncSettingsManager = new WebOverlayWhispersyncSettingsManager(paramSessionClient);
    ClockSkewSharedPrefs clockSkewSharedPrefs = new ClockSkewSharedPrefs(this.context);
    GameDataServiceSyncedClock gameDataServiceSyncedClock = new GameDataServiceSyncedClock((Clock)new LocalClock(), (ClockSkewStorage)clockSkewSharedPrefs);
    CloudStorage cloudStorage = new CloudStorage((WhispersyncHttpClient)whispersyncHttpClientImpl, (GameDataMarshaller)this.marshaller, gameDataServiceSyncedClock);
    CloudSynchronizer cloudSynchronizer = new CloudSynchronizer(this.gameDataMap, (LocalStorage)this.localStorage, (RemoteStorage)cloudStorage, this.syncRequestState, this.whispersyncEventPoster, this.eventCollectorClient, paramNetworkUtil, (WhispersyncUserSettingsManager)webOverlayWhispersyncSettingsManager);
    this.synchronizationManager.setCloudSynchronizer(cloudSynchronizer);
    paramJavascriptEventsManager.addEventListener("whispersyncListener", (JavascriptEventListener)new WhispersyncJavascriptEventListener(this.synchronizationManager));
    ClockUtil.setGlobalClock((Clock)gameDataServiceSyncedClock);
    this.migrationManager = new MigrationManager(new MigrationHttpClient(str2, str1, paramNetworkClient, paramHttpClient), paramNetworkUtil, (WhispersyncUserSettingsManager)webOverlayWhispersyncSettingsManager, this.eventCollectorClient);
  }
  
  public void setWhispersyncEventListener(WhispersyncEventListener paramWhispersyncEventListener) {
    this.whispersyncEventPoster.setWhispersyncEventListener(paramWhispersyncEventListener);
  }
  
  public void synchronize() {
    this.synchronizationManager.syncActively();
    reportEvent("WHISPERSYNC_MANUAL_SYNC");
  }
  
  public void synchronizeOnInitialization() {
    this.synchronizationManager.syncActively();
  }
  
  public void unpackVersion1MultiFileGameData(byte[] paramArrayOfbyte, File paramFile) throws IOException {
    if (paramFile == null)
      paramFile = this.context.getFilesDir().getParentFile(); 
    this.migrationManager.unpackV1MultiFileGameData(paramArrayOfbyte, paramFile);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\WhispersyncClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */