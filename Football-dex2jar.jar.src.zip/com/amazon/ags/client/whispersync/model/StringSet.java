package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableStringElement;
import com.amazon.ags.api.whispersync.model.SyncableStringSet;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.GameDataLock;
import com.amazon.ags.client.whispersync.WhispersyncClientImpl;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class StringSet implements SyncableStringSet, Mergeable<StringSet> {
  private static final String TAG = "GC_Whispersync";
  
  private final Set<SyncableStringElement> elements;
  
  private final String name;
  
  private SyncState state = SyncState.NOT_SET;
  
  public StringSet(String paramString) {
    this.name = paramString;
    this.elements = new HashSet<SyncableStringElement>();
  }
  
  public StringSet(String paramString, Set<SyncableStringElement> paramSet, SyncState paramSyncState) {
    this.elements = new HashSet<SyncableStringElement>(paramSet.size());
    for (SyncableStringElement syncableStringElement : paramSet)
      this.elements.add(new StringElement((StringElement)syncableStringElement)); 
    this.name = paramString;
    this.state = paramSyncState;
  }
  
  private void add(StringElement paramStringElement) {
    if (paramStringElement == null) {
      Log.e("GC_Whispersync", "Unable to add null StringElement to StringSet with name " + this.name);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE");
      throw new IllegalArgumentException("Unable to add null StringElement to StringSet with name " + this.name);
    } 
    try {
      GameDataLock.lock();
      if (!contains(paramStringElement.getValue())) {
        this.elements.add(paramStringElement);
        this.state = SyncState.DIRTY;
        WhispersyncClientImpl.syncPassively();
      } 
      return;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  private void reportEvent(String paramString) {
    EventCollectorClient eventCollectorClient = EventCollectorClient.getInstance();
    if (eventCollectorClient != null) {
      GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createSyncableTypeEvent(paramString, SyncableType.STRING_SET);
      if (gameCircleGenericEvent != null)
        eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
    } 
  }
  
  public void add(String paramString) {
    add(new StringElement(paramString, new HashMap<String, String>(), ClockUtil.getCurrentTime()));
  }
  
  public void add(String paramString, Map<String, String> paramMap) {
    add(new StringElement(paramString, paramMap, ClockUtil.getCurrentTime()));
  }
  
  public void completeSyncing() {
    if (this.state == SyncState.SYNCING)
      this.state = SyncState.SYNCED; 
  }
  
  public boolean contains(String paramString) {
    return (get(paramString) != null);
  }
  
  public StringSet deepCopy() {
    return new StringSet(this.name, this.elements, this.state);
  }
  
  public SyncableStringElement get(String paramString) {
    GameDataLock.lock();
    try {
      for (SyncableStringElement syncableStringElement : this.elements) {
        if (syncableStringElement != null && syncableStringElement.getValue() != null) {
          boolean bool = syncableStringElement.getValue().equals(paramString);
          if (bool)
            return syncableStringElement; 
        } 
      } 
      return null;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public SyncState getState() {
    return this.state;
  }
  
  public Set<SyncableStringElement> getValues() {
    GameDataLock.lock();
    try {
      return Collections.unmodifiableSet(this.elements);
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public boolean isSet() {
    GameDataLock.lock();
    try {
      boolean bool = this.elements.isEmpty();
      if (!bool) {
        bool = true;
        return bool;
      } 
      bool = false;
      return bool;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public Iterator<SyncableStringElement> iterator() {
    return this.elements.iterator();
  }
  
  public void merge(StringSet paramStringSet) {
    if (paramStringSet == null || paramStringSet.elements == null || paramStringSet.elements.isEmpty()) {
      Log.w("GC_Whispersync", "StringSet - Unable to merge StringSet from an invalid/unset value " + paramStringSet);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_FAILED_MERGE");
      return;
    } 
    for (SyncableStringElement syncableStringElement1 : paramStringSet) {
      SyncableStringElement syncableStringElement2 = get(syncableStringElement1.getValue());
      if (syncableStringElement2 == null) {
        this.elements.add(new StringElement((StringElement)syncableStringElement1));
        continue;
      } 
      if (syncableStringElement2.getTimestamp() < syncableStringElement1.getTimestamp()) {
        this.elements.remove(syncableStringElement2);
        this.elements.add(new StringElement((StringElement)syncableStringElement1));
      } 
    } 
    if (this.state == SyncState.NOT_SET) {
      this.state = SyncState.SYNCED;
      return;
    } 
  }
  
  public void startSyncing() {
    if (this.state == SyncState.DIRTY)
      this.state = SyncState.SYNCING; 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[").append(HighestNumber.class.getSimpleName()).append(" name=").append(this.name).append(", ").append(" value=").append(this.elements).append(", ").append(" state=").append(this.state).append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\StringSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */