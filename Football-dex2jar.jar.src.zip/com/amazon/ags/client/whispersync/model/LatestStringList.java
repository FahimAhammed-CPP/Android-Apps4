package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableStringElement;
import com.amazon.ags.api.whispersync.model.SyncableStringList;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.GameDataLock;
import com.amazon.ags.client.whispersync.WhispersyncClientImpl;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

public class LatestStringList implements SyncableStringList, Mergeable<LatestStringList> {
  private static final Comparator<StringElement> ITEM_COMPARATOR = new Comparator<StringElement>() {
      public int compare(StringElement param1StringElement1, StringElement param1StringElement2) {
        byte b = -1;
        long l = param1StringElement2.getTimestamp() - param1StringElement1.getTimestamp();
        if (l == 0L) {
          if (param1StringElement1.getValue() == null) {
            if (param1StringElement2.getValue() == null)
              b = 0; 
            return b;
          } 
          return (param1StringElement2.getValue() == null) ? 1 : param1StringElement1.getValue().compareTo(param1StringElement2.getValue());
        } 
        return (l > 0L) ? 1 : b;
      }
    };
  
  private static final String TAG = "GC_Whispersync";
  
  protected final SortedSet<StringElement> elements = new TreeSet<StringElement>(ITEM_COMPARATOR);
  
  protected int maxSize;
  
  protected final String name;
  
  protected SyncState state = SyncState.NOT_SET;
  
  public LatestStringList(String paramString) {
    this.name = paramString;
    this.maxSize = 5;
  }
  
  public LatestStringList(String paramString, List<StringElement> paramList, int paramInt, SyncState paramSyncState) {
    for (StringElement stringElement : paramList)
      this.elements.add(new StringElement(stringElement)); 
    this.name = paramString;
    this.maxSize = paramInt;
    this.state = paramSyncState;
  }
  
  private void add(StringElement paramStringElement) {
    GameDataLock.lock();
    if (paramStringElement == null)
      try {
        Log.e("GC_Whispersync", "Unable to add null StringElement to LatestStringList with name " + this.name);
        reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE");
        throw new IllegalArgumentException("Unable to add null StringElement to LatestStringList with name " + this.name);
      } finally {
        GameDataLock.unlock();
      }  
    Log.d("GC_Whispersync", "Adding string element " + paramStringElement + " to StringList");
    this.elements.add(paramStringElement);
    if (this.elements.size() > this.maxSize) {
      if (this.elements.last() != paramStringElement) {
        this.state = SyncState.DIRTY;
        WhispersyncClientImpl.syncPassively();
      } 
      this.elements.remove(this.elements.last());
    } else {
      this.state = SyncState.DIRTY;
      WhispersyncClientImpl.syncPassively();
    } 
    GameDataLock.unlock();
  }
  
  private void reportEvent(String paramString) {
    EventCollectorClient eventCollectorClient = EventCollectorClient.getInstance();
    if (eventCollectorClient != null) {
      GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createSyncableTypeEvent(paramString, SyncableType.LATEST_STRING_LIST);
      if (gameCircleGenericEvent != null)
        eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
    } 
  }
  
  public void add(String paramString) {
    add(new StringElement(paramString, new HashMap<String, String>(), ClockUtil.getCurrentTime()));
  }
  
  public void add(String paramString, Map<String, String> paramMap) {
    add(new StringElement(paramString, paramMap, ClockUtil.getCurrentTime()));
  }
  
  public void completeSyncing() {
    if (this.state == SyncState.SYNCING)
      this.state = SyncState.SYNCED; 
  }
  
  public List<StringElement> copyElements() {
    null = new ArrayList(this.elements.size());
    GameDataLock.lock();
    try {
      Iterator<StringElement> iterator = this.elements.iterator();
    } finally {
      GameDataLock.unlock();
    } 
    GameDataLock.unlock();
    return (List<StringElement>)SYNTHETIC_LOCAL_VARIABLE_1;
  }
  
  public LatestStringList deepCopy() {
    return new LatestStringList(this.name, copyElements(), this.maxSize, this.state);
  }
  
  public int getMaxSize() {
    return this.maxSize;
  }
  
  public SyncState getState() {
    return this.state;
  }
  
  public SyncableStringElement[] getValues() {
    GameDataLock.lock();
    try {
      int j = Math.min(this.elements.size(), this.maxSize);
      SyncableStringElement[] arrayOfSyncableStringElement = new SyncableStringElement[j];
      Iterator<StringElement> iterator = this.elements.iterator();
      for (int i = 0; i < j; i++)
        arrayOfSyncableStringElement[i] = iterator.next(); 
      return arrayOfSyncableStringElement;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public boolean isSet() {
    GameDataLock.lock();
    try {
      boolean bool = this.elements.isEmpty();
      if (!bool) {
        bool = true;
        return bool;
      } 
      bool = false;
      return bool;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public void merge(LatestStringList paramLatestStringList) {
    if (paramLatestStringList == null || paramLatestStringList.elements == null || paramLatestStringList.elements.isEmpty()) {
      Log.w("GC_Whispersync", "LatestStringList - Unable to merge LatestStringList from an invalid/unset value " + paramLatestStringList);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_FAILED_MERGE");
      return;
    } 
    if (paramLatestStringList.maxSize > this.maxSize) {
      Log.i("GC_Whispersync", "Increasing maxSize of " + this.name + " from " + this.maxSize + " to " + paramLatestStringList.maxSize);
      this.maxSize = paramLatestStringList.maxSize;
    } 
    Iterator<StringElement> iterator = paramLatestStringList.elements.iterator();
    while (true) {
      if (iterator.hasNext()) {
        StringElement stringElement = iterator.next();
        this.elements.add(stringElement);
        if (this.elements.size() > this.maxSize)
          this.elements.remove(this.elements.last()); 
        continue;
      } 
      return;
    } 
  }
  
  public void setMaxSize(int paramInt) {
    if (paramInt <= 0 || paramInt > 1000) {
      Log.e("GC_Whispersync", "Unable to set max size to " + paramInt);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE");
      throw new IllegalArgumentException();
    } 
    if (paramInt > this.maxSize)
      this.maxSize = paramInt; 
  }
  
  public void startSyncing() {
    if (this.state == SyncState.DIRTY)
      this.state = SyncState.SYNCING; 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[").append(HighestNumber.class.getSimpleName()).append(" name=").append(this.name).append(", ").append(" elements=").append(this.elements).append(", ").append(" isSet=").append(isSet()).append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\LatestStringList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */