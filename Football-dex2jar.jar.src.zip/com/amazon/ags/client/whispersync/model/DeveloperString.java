package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableDeveloperString;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.GameDataLock;
import com.amazon.ags.client.whispersync.WhispersyncClientImpl;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;

public class DeveloperString implements SyncableDeveloperString, Mergeable<DeveloperString> {
  private static final String TAG = "GC_Whispersync";
  
  private String cloud;
  
  private long cloudTimestamp;
  
  private boolean isCloudValueSet = false;
  
  private String local;
  
  private final String name;
  
  private String pending;
  
  private long pendingTimestamp;
  
  private SyncState state = SyncState.NOT_SET;
  
  private long timestamp;
  
  public DeveloperString(String paramString) {
    this.name = paramString;
  }
  
  public DeveloperString(String paramString1, String paramString2, long paramLong, SyncState paramSyncState) {
    this.name = paramString1;
    this.local = paramString2;
    this.state = paramSyncState;
    this.timestamp = paramLong;
    this.isCloudValueSet = false;
  }
  
  public DeveloperString(String paramString1, String paramString2, String paramString3, long paramLong1, long paramLong2, SyncState paramSyncState) {
    this.name = paramString1;
    this.local = paramString2;
    this.cloud = paramString3;
    this.state = paramSyncState;
    this.timestamp = paramLong1;
    this.cloudTimestamp = paramLong2;
    this.isCloudValueSet = true;
  }
  
  public void completeSyncing() {
    if (this.state == SyncState.SYNCING || this.state == SyncState.DIRTY) {
      this.cloud = this.pending;
      this.cloudTimestamp = this.pendingTimestamp;
      this.isCloudValueSet = true;
    } 
    if (this.state == SyncState.SYNCING)
      this.state = SyncState.SYNCED; 
  }
  
  public DeveloperString deepCopy() {
    DeveloperString developerString = new DeveloperString(this.name, this.local, this.cloud, this.timestamp, this.cloudTimestamp, this.state);
    developerString.isCloudValueSet = this.isCloudValueSet;
    return developerString;
  }
  
  public long getCloudTimestamp() {
    return this.cloudTimestamp;
  }
  
  public String getCloudValue() {
    return this.cloud;
  }
  
  public SyncState getState() {
    return this.state;
  }
  
  public long getTimestamp() {
    return this.timestamp;
  }
  
  public String getValue() {
    return this.local;
  }
  
  public boolean inConflict() {
    return (this.state == SyncState.IN_CONFLICT);
  }
  
  public boolean isCloudValueSet() {
    return this.isCloudValueSet;
  }
  
  public boolean isSet() {
    return (this.state != SyncState.NOT_SET);
  }
  
  public void markAsResolved() {
    this.state = SyncState.DIRTY;
  }
  
  public void merge(DeveloperString paramDeveloperString) {
    if (paramDeveloperString == null || paramDeveloperString.state == SyncState.NOT_SET) {
      Log.w("GC_Whispersync", "DeveloperString - Unable to merge DeveloperString from invalid value");
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_FAILED_MERGE");
      return;
    } 
    this.cloud = paramDeveloperString.local;
    this.isCloudValueSet = true;
    if (this.state == SyncState.NOT_SET || this.state == SyncState.SYNCED) {
      Log.d("GC_Whispersync", "DeveloperString - merging value for " + this.name + " from " + this.local + " to " + paramDeveloperString.local);
      this.local = paramDeveloperString.local;
      this.timestamp = paramDeveloperString.timestamp;
      this.state = SyncState.SYNCED;
      return;
    } 
    this.cloudTimestamp = paramDeveloperString.timestamp;
    if ((this.local != null && !this.local.equals(paramDeveloperString.local)) || (this.local == null && paramDeveloperString.local != null)) {
      this.state = SyncState.IN_CONFLICT;
      return;
    } 
  }
  
  protected void reportEvent(String paramString) {
    EventCollectorClient eventCollectorClient = EventCollectorClient.getInstance();
    if (eventCollectorClient != null) {
      GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createSyncableTypeEvent(paramString, SyncableType.DEVELOPER_STRING);
      if (gameCircleGenericEvent != null)
        eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
    } 
  }
  
  public void setValue(String paramString) {
    GameDataLock.lock();
    try {
      if (this.state == SyncState.NOT_SET || (this.local != null && !this.local.equals(paramString)) || (this.local == null && paramString != null)) {
        this.local = paramString;
        this.timestamp = ClockUtil.getCurrentTime();
        this.state = SyncState.DIRTY;
        WhispersyncClientImpl.syncPassively();
      } 
      return;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public void startSyncing() {
    if (this.state == SyncState.DIRTY || this.state == SyncState.SYNCING) {
      this.pending = this.local;
      this.pendingTimestamp = this.timestamp;
      this.state = SyncState.SYNCING;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\DeveloperString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */