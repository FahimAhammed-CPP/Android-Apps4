package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableNumberElement;
import com.amazon.ags.api.whispersync.model.SyncableNumberList;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.GameDataLock;
import com.amazon.ags.client.whispersync.WhispersyncClientImpl;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

public abstract class NumberList implements SyncableNumberList, Mergeable<NumberList> {
  private static final String TAG = "GC_Whispersync";
  
  protected final SortedSet<NumberElement> elements = new TreeSet<NumberElement>(getComparator());
  
  protected int maxSize;
  
  protected final String name;
  
  protected SyncState state = SyncState.NOT_SET;
  
  public NumberList(String paramString) {
    this.name = paramString;
    this.maxSize = 5;
  }
  
  public NumberList(String paramString, List<NumberElement> paramList, int paramInt, SyncState paramSyncState) {
    for (NumberElement numberElement : paramList)
      this.elements.add(new NumberElement(numberElement)); 
    this.name = paramString;
    this.maxSize = paramInt;
    this.state = paramSyncState;
  }
  
  private void add(NumberElement paramNumberElement) {
    GameDataLock.lock();
    if (paramNumberElement == null)
      try {
        Log.w("GC_Whispersync", "Unable to add null NumberElement to NumberList with name " + this.name);
        reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE");
        throw new IllegalArgumentException("Unable to add null NumberElement to NumberList with name " + this.name);
      } finally {
        GameDataLock.unlock();
      }  
    Log.d("GC_Whispersync", "Adding number element " + paramNumberElement + " to NumberList of type " + getSyncableType());
    this.elements.add(paramNumberElement);
    if (this.elements.size() > this.maxSize) {
      if (this.elements.last() != paramNumberElement) {
        this.state = SyncState.DIRTY;
        WhispersyncClientImpl.syncPassively();
      } 
      this.elements.remove(this.elements.last());
    } else {
      this.state = SyncState.DIRTY;
      WhispersyncClientImpl.syncPassively();
    } 
    GameDataLock.unlock();
  }
  
  private void add(BigDecimal paramBigDecimal, Map<String, String> paramMap) {
    add(new NumberElement(paramBigDecimal, paramMap, ClockUtil.getCurrentTime()));
  }
  
  private void reportEvent(String paramString) {
    EventCollectorClient eventCollectorClient = EventCollectorClient.getInstance();
    if (eventCollectorClient != null) {
      GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createSyncableTypeEvent(paramString, getSyncableType());
      if (gameCircleGenericEvent != null)
        eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
    } 
  }
  
  public void add(double paramDouble) {
    add(paramDouble, (Map<String, String>)null);
  }
  
  public void add(double paramDouble, Map<String, String> paramMap) {
    add(new BigDecimal(paramDouble), paramMap);
  }
  
  public void add(int paramInt) {
    add(paramInt, (Map<String, String>)null);
  }
  
  public void add(int paramInt, Map<String, String> paramMap) {
    add(new BigDecimal(paramInt), paramMap);
  }
  
  public void add(long paramLong) {
    add(paramLong, (Map<String, String>)null);
  }
  
  public void add(long paramLong, Map<String, String> paramMap) {
    add(new BigDecimal(paramLong), paramMap);
  }
  
  public void add(String paramString) {
    add(paramString, (Map<String, String>)null);
  }
  
  public void add(String paramString, Map<String, String> paramMap) {
    if (paramString == null) {
      Log.w("GC_Whispersync", "Unable to add null String to NumberList with name " + this.name);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE");
      throw new IllegalArgumentException("Unable to add null String to NumberList with name " + this.name);
    } 
    add(new BigDecimal(paramString), paramMap);
  }
  
  public void completeSyncing() {
    if (this.state == SyncState.SYNCING)
      this.state = SyncState.SYNCED; 
  }
  
  public List<NumberElement> copyElements() {
    null = new ArrayList(this.elements.size());
    GameDataLock.lock();
    try {
      Iterator<NumberElement> iterator = this.elements.iterator();
    } finally {
      GameDataLock.unlock();
    } 
    GameDataLock.unlock();
    return (List<NumberElement>)SYNTHETIC_LOCAL_VARIABLE_1;
  }
  
  public abstract Comparator<NumberElement> getComparator();
  
  public int getMaxSize() {
    return this.maxSize;
  }
  
  public SyncState getState() {
    return this.state;
  }
  
  public abstract SyncableType getSyncableType();
  
  public SyncableNumberElement[] getValues() {
    GameDataLock.lock();
    try {
      int j = Math.min(this.elements.size(), this.maxSize);
      SyncableNumberElement[] arrayOfSyncableNumberElement = new SyncableNumberElement[j];
      Iterator<NumberElement> iterator = this.elements.iterator();
      for (int i = 0; i < j; i++)
        arrayOfSyncableNumberElement[i] = iterator.next(); 
      return arrayOfSyncableNumberElement;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public boolean isSet() {
    GameDataLock.lock();
    try {
      boolean bool = this.elements.isEmpty();
      if (!bool) {
        bool = true;
        return bool;
      } 
      bool = false;
      return bool;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public void merge(NumberList paramNumberList) {
    if (paramNumberList == null || paramNumberList.elements == null || paramNumberList.elements.isEmpty()) {
      Log.w("GC_Whispersync", "NumberList - Unable to merge NumberList from an invalid/unset value " + paramNumberList);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_FAILED_MERGE");
      return;
    } 
    if (paramNumberList.getSyncableType() != getSyncableType()) {
      Log.e("GC_Whispersync", "Cannot merge a " + paramNumberList.getSyncableType() + " with a " + getSyncableType());
      return;
    } 
    if (paramNumberList.maxSize > this.maxSize) {
      Log.i("GC_Whispersync", "Increasing maxSize of " + this.name + " from " + this.maxSize + " to " + paramNumberList.maxSize);
      this.maxSize = paramNumberList.maxSize;
    } 
    for (NumberElement numberElement : paramNumberList.elements) {
      this.elements.add(numberElement);
      if (this.elements.size() > this.maxSize)
        this.elements.remove(this.elements.last()); 
    } 
    if (this.state == SyncState.NOT_SET) {
      this.state = SyncState.SYNCED;
      return;
    } 
  }
  
  public void setMaxSize(int paramInt) {
    if (paramInt <= 0 || paramInt > 1000) {
      Log.e("GC_Whispersync", "Unable to set max size to " + paramInt);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE");
      throw new IllegalArgumentException();
    } 
    if (paramInt > this.maxSize)
      this.maxSize = paramInt; 
  }
  
  public void startSyncing() {
    if (this.state == SyncState.DIRTY)
      this.state = SyncState.SYNCING; 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[").append(getSyncableType().getJsonName()).append(" name=").append(this.name).append(", ").append(" value=").append(this.elements).append(", ").append(" isSet=").append(isSet()).append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\NumberList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */