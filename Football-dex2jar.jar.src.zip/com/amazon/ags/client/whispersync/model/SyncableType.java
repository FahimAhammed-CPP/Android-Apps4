package com.amazon.ags.client.whispersync.model;

public enum SyncableType {
  ACCUMULATING_NUMBER,
  DEVELOPER_STRING,
  HIGHEST_NUMBER("HN"),
  HIGHEST_NUMBER_LIST("HN"),
  LATEST_NUMBER("HN"),
  LATEST_NUMBER_LIST("HN"),
  LATEST_STRING("HN"),
  LATEST_STRING_LIST("HN"),
  LOWEST_NUMBER("LN"),
  LOWEST_NUMBER_LIST("LN"),
  MAP("LN"),
  STRING_SET("LN");
  
  private final String jsonName;
  
  static {
    LATEST_NUMBER = new SyncableType("LATEST_NUMBER", 2, "CN");
    ACCUMULATING_NUMBER = new SyncableType("ACCUMULATING_NUMBER", 3, "AN");
    HIGHEST_NUMBER_LIST = new SyncableType("HIGHEST_NUMBER_LIST", 4, "HNL");
    LOWEST_NUMBER_LIST = new SyncableType("LOWEST_NUMBER_LIST", 5, "LNL");
    LATEST_NUMBER_LIST = new SyncableType("LATEST_NUMBER_LIST", 6, "CNL");
    LATEST_STRING = new SyncableType("LATEST_STRING", 7, "CS");
    LATEST_STRING_LIST = new SyncableType("LATEST_STRING_LIST", 8, "CSL");
    STRING_SET = new SyncableType("STRING_SET", 9, "SS");
    DEVELOPER_STRING = new SyncableType("DEVELOPER_STRING", 10, "DS");
    MAP = new SyncableType("MAP", 11, "MAP");
    $VALUES = new SyncableType[] { 
        HIGHEST_NUMBER, LOWEST_NUMBER, LATEST_NUMBER, ACCUMULATING_NUMBER, HIGHEST_NUMBER_LIST, LOWEST_NUMBER_LIST, LATEST_NUMBER_LIST, LATEST_STRING, LATEST_STRING_LIST, STRING_SET, 
        DEVELOPER_STRING, MAP };
  }
  
  SyncableType(String paramString1) {
    this.jsonName = paramString1;
  }
  
  public static SyncableType fromString(String paramString) {
    for (SyncableType syncableType : values()) {
      if (syncableType.jsonName.equalsIgnoreCase(paramString))
        return syncableType; 
    } 
    return null;
  }
  
  public String getJsonName() {
    return this.jsonName;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\SyncableType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */