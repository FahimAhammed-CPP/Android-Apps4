package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableAccumulatingNumber;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.GameDataLock;
import com.amazon.ags.client.whispersync.WhispersyncClientImpl;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import java.math.BigDecimal;

public class AccumulatingNumber implements SyncableAccumulatingNumber, Mergeable<AccumulatingNumber> {
  private static final String TAG = "GC_Whispersync";
  
  private BigDecimal local;
  
  private final String name;
  
  private BigDecimal remote;
  
  private SyncState state = SyncState.NOT_SET;
  
  public AccumulatingNumber(String paramString) {
    this.name = paramString;
    this.local = BigDecimal.ZERO;
    this.remote = BigDecimal.ZERO;
  }
  
  public AccumulatingNumber(String paramString, BigDecimal paramBigDecimal1, BigDecimal paramBigDecimal2, SyncState paramSyncState) {
    this.name = paramString;
    this.local = paramBigDecimal1;
    this.remote = paramBigDecimal2;
    this.state = paramSyncState;
  }
  
  private void decrement(BigDecimal paramBigDecimal) {
    update(paramBigDecimal.negate());
  }
  
  private void reportEvent(String paramString) {
    EventCollectorClient eventCollectorClient = EventCollectorClient.getInstance();
    if (eventCollectorClient != null) {
      GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createSyncableTypeEvent(paramString, SyncableType.ACCUMULATING_NUMBER);
      if (gameCircleGenericEvent != null)
        eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
    } 
  }
  
  private void update(BigDecimal paramBigDecimal) {
    if (paramBigDecimal == null) {
      Log.e("GC_Whispersync", "delta cannot be null for AccumulatingNumber with name " + this.name);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE");
      throw new IllegalArgumentException("delta cannot be null for AccumulatingNumber with name " + this.name);
    } 
    GameDataLock.lock();
    try {
      this.local = this.local.add(paramBigDecimal);
      this.state = SyncState.DIRTY;
      WhispersyncClientImpl.syncPassively();
      return;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public BigDecimal asDecimal() {
    return this.local.add(this.remote);
  }
  
  public double asDouble() {
    return this.local.add(this.remote).doubleValue();
  }
  
  public int asInt() {
    return this.local.add(this.remote).intValue();
  }
  
  public long asLong() {
    return this.local.add(this.remote).longValue();
  }
  
  public String asString() {
    return this.local.add(this.remote).toString();
  }
  
  public void completeSyncing() {
    if (this.state == SyncState.SYNCING)
      this.state = SyncState.SYNCED; 
  }
  
  public void decrement(double paramDouble) {
    decrement(new BigDecimal(paramDouble));
  }
  
  public void decrement(int paramInt) {
    decrement(new BigDecimal(paramInt));
  }
  
  public void decrement(long paramLong) {
    decrement(new BigDecimal(paramLong));
  }
  
  public void decrement(String paramString) {
    if (paramString == null) {
      Log.e("GC_Whispersync", "delta cannot be null for AccumulatingNumber with name " + this.name);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE");
      throw new IllegalArgumentException("delta cannot be null for AccumulatingNumber with name " + this.name);
    } 
    decrement(new BigDecimal(paramString));
  }
  
  public AccumulatingNumber deepCopy() {
    return new AccumulatingNumber(this.name, this.local, this.remote, this.state);
  }
  
  public BigDecimal getLocal() {
    return this.local;
  }
  
  public BigDecimal getRemote() {
    return this.remote;
  }
  
  public SyncState getState() {
    return this.state;
  }
  
  public void increment(double paramDouble) {
    update(new BigDecimal(paramDouble));
  }
  
  public void increment(int paramInt) {
    update(new BigDecimal(paramInt));
  }
  
  public void increment(long paramLong) {
    update(new BigDecimal(paramLong));
  }
  
  public void increment(String paramString) {
    if (paramString == null) {
      Log.e("GC_Whispersync", "delta cannot be null for AccumulatingNumber with name " + this.name);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE");
      throw new IllegalArgumentException("delta cannot be null for AccumulatingNumber with name " + this.name);
    } 
    update(new BigDecimal(paramString));
  }
  
  public void merge(AccumulatingNumber paramAccumulatingNumber) {
    boolean bool = WhispersyncClientImpl.hasSuccessfullySynchronized();
    this.remote = paramAccumulatingNumber.remote;
    if (!bool)
      this.local = this.local.add(paramAccumulatingNumber.local); 
    if (this.state == SyncState.NOT_SET)
      this.state = SyncState.SYNCED; 
  }
  
  public void startSyncing() {
    if (this.state == SyncState.DIRTY)
      this.state = SyncState.SYNCING; 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[").append(AccumulatingNumber.class.getSimpleName()).append(" name=").append(this.name).append(", ").append(" local=").append(this.local).append(", ").append(" remote=").append(this.remote).append(", ").append(" state=").append(this.state).append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\AccumulatingNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */