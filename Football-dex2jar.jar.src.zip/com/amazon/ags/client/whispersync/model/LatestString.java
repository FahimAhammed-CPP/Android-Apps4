package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableString;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.GameDataLock;
import com.amazon.ags.client.whispersync.WhispersyncClientImpl;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import java.util.Map;

public class LatestString extends StringElement implements SyncableString, Mergeable<LatestString> {
  private static final String TAG = "GC_Whispersync";
  
  private final String name;
  
  private SyncState state = SyncState.NOT_SET;
  
  public LatestString(String paramString) {
    this.name = paramString;
  }
  
  public LatestString(String paramString1, String paramString2, Map<String, String> paramMap, long paramLong, SyncState paramSyncState) {
    super(paramString2, paramMap, paramLong);
    this.name = paramString1;
    this.state = paramSyncState;
  }
  
  private void setValue(String paramString, Map<String, String> paramMap) {
    GameDataLock.lock();
    try {
      this.value = paramString;
      this.timestamp = ClockUtil.getCurrentTime();
      this.metadata.clear();
      if (paramMap != null)
        this.metadata.putAll(paramMap); 
      this.state = SyncState.DIRTY;
      WhispersyncClientImpl.syncPassively();
      return;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public void completeSyncing() {
    if (this.state == SyncState.SYNCING)
      this.state = SyncState.SYNCED; 
  }
  
  public LatestString deepCopy() {
    return new LatestString(this.name, this.value, this.metadata, this.timestamp, this.state);
  }
  
  public SyncState getState() {
    return this.state;
  }
  
  public boolean isSet() {
    return (this.state != SyncState.NOT_SET);
  }
  
  public void merge(LatestString paramLatestString) {
    if (paramLatestString == null || paramLatestString.state == SyncState.NOT_SET) {
      Log.w("GC_Whispersync", "LatestString - Unable to merge LatestString from invalid value");
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_FAILED_MERGE", SyncableType.LATEST_STRING);
      return;
    } 
    if (this.state == SyncState.NOT_SET || paramLatestString.timestamp > this.timestamp) {
      Log.d("GC_Whispersync", "LatestString - merging value for " + this.name + " from " + this.value + " to " + paramLatestString.value);
      this.value = paramLatestString.value;
      this.metadata.clear();
      this.metadata.putAll(paramLatestString.metadata);
      this.timestamp = paramLatestString.timestamp;
      if (this.state == SyncState.NOT_SET) {
        this.state = SyncState.SYNCED;
        return;
      } 
    } 
  }
  
  protected void reportEvent(String paramString, SyncableType paramSyncableType) {
    EventCollectorClient eventCollectorClient = EventCollectorClient.getInstance();
    if (eventCollectorClient != null) {
      GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createSyncableTypeEvent(paramString, paramSyncableType);
      if (gameCircleGenericEvent != null)
        eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
    } 
  }
  
  public void set(String paramString) {
    setValue(paramString, (Map<String, String>)null);
  }
  
  public void set(String paramString, Map<String, String> paramMap) {
    setValue(paramString, paramMap);
  }
  
  public void startSyncing() {
    if (this.state == SyncState.DIRTY)
      this.state = SyncState.SYNCING; 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[").append(LatestString.class.getSimpleName()).append(" name=").append(this.name).append(", ").append(" value=").append(this.value).append(", ").append(" timestamp=").append(this.timestamp).append(", ").append(" metadata=").append(this.metadata).append(", ").append(" state=").append(this.state).append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\LatestString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */