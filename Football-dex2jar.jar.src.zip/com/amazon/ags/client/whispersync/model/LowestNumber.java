package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableNumber;
import com.amazon.ags.client.whispersync.GameDataLock;
import com.amazon.ags.client.whispersync.WhispersyncClientImpl;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import java.math.BigDecimal;
import java.util.Map;

public class LowestNumber extends NumberElement implements SyncableNumber, Mergeable<LowestNumber> {
  private static final String TAG = "GC_Whispersync";
  
  private final String name;
  
  private SyncState state = SyncState.NOT_SET;
  
  public LowestNumber(String paramString) {
    this.name = paramString;
  }
  
  public LowestNumber(String paramString, BigDecimal paramBigDecimal, Map<String, String> paramMap, long paramLong, SyncState paramSyncState) {
    super(paramBigDecimal, paramMap, paramLong);
    this.name = paramString;
    this.state = paramSyncState;
  }
  
  private void setValue(BigDecimal paramBigDecimal, Map<String, String> paramMap) {
    if (paramBigDecimal == null) {
      Log.e("GC_Whispersync", "Unable to set null LowestNumber with name " + this.name);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE", SyncableType.LOWEST_NUMBER);
      throw new IllegalArgumentException("Unable to set null LowestNumber with name " + this.name);
    } 
    GameDataLock.lock();
    try {
      if (this.state == SyncState.NOT_SET || this.value.compareTo(paramBigDecimal) > 0) {
        this.value = paramBigDecimal;
        this.timestamp = ClockUtil.getCurrentTime();
        this.state = SyncState.DIRTY;
        this.metadata.clear();
        if (paramMap != null)
          this.metadata.putAll(paramMap); 
        WhispersyncClientImpl.syncPassively();
      } 
      return;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public void completeSyncing() {
    if (this.state == SyncState.SYNCING)
      this.state = SyncState.SYNCED; 
  }
  
  public LowestNumber deepCopy() {
    return new LowestNumber(this.name, this.value, this.metadata, this.timestamp, this.state);
  }
  
  public SyncState getState() {
    return this.state;
  }
  
  public boolean isSet() {
    return (this.state != SyncState.NOT_SET);
  }
  
  public void merge(LowestNumber paramLowestNumber) {
    if (paramLowestNumber == null || paramLowestNumber.state == SyncState.NOT_SET) {
      Log.w("GC_Whispersync", "LowestNumber - Unable to merge LowestNumber from invalid value");
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_FAILED_MERGE", SyncableType.LOWEST_NUMBER);
      return;
    } 
    if (this.state == SyncState.NOT_SET || paramLowestNumber.value.compareTo(this.value) < 0) {
      Log.i("GC_Whispersync", "LowestNumber - merging value for " + this.name + " from " + this.value + " to " + paramLowestNumber.value);
      this.value = paramLowestNumber.value;
      this.metadata.clear();
      this.metadata.putAll(paramLowestNumber.metadata);
      this.timestamp = paramLowestNumber.timestamp;
      if (this.state == SyncState.NOT_SET) {
        this.state = SyncState.SYNCED;
        return;
      } 
    } 
  }
  
  public void set(double paramDouble) {
    set(paramDouble, (Map<String, String>)null);
  }
  
  public void set(double paramDouble, Map<String, String> paramMap) {
    setValue(new BigDecimal(paramDouble), paramMap);
  }
  
  public void set(int paramInt) {
    set(paramInt, (Map<String, String>)null);
  }
  
  public void set(int paramInt, Map<String, String> paramMap) {
    setValue(new BigDecimal(paramInt), paramMap);
  }
  
  public void set(long paramLong) {
    set(paramLong, (Map<String, String>)null);
  }
  
  public void set(long paramLong, Map<String, String> paramMap) {
    setValue(new BigDecimal(paramLong), paramMap);
  }
  
  public void set(String paramString) {
    set(paramString, (Map<String, String>)null);
  }
  
  public void set(String paramString, Map<String, String> paramMap) {
    if (paramString == null) {
      Log.w("GC_Whispersync", "Unable to add null String to LowestNumber with name " + this.name);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE", SyncableType.LOWEST_NUMBER);
      throw new IllegalArgumentException("Unable to add null String to LowestNumber with name " + this.name);
    } 
    setValue(new BigDecimal(paramString), paramMap);
  }
  
  public void startSyncing() {
    if (this.state == SyncState.DIRTY)
      this.state = SyncState.SYNCING; 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[").append(LowestNumber.class.getSimpleName()).append(" name=").append(this.name).append(", ").append(" value=").append(this.value).append(", ").append(" timestamp=").append(this.timestamp).append(", ").append(" metadata=").append(this.metadata).append(", ").append(" state=").append(this.state).append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\LowestNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */