package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableNumberElement;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import com.amazon.ags.client.whispersync.metrics.WhispersyncMetricsFactory;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class NumberElement extends Element implements SyncableNumberElement {
  private static final String TAG = "GC_Whispersync";
  
  protected BigDecimal value;
  
  public NumberElement() {
    this.value = BigDecimal.ZERO;
  }
  
  public NumberElement(NumberElement paramNumberElement) {
    super(new HashMap<String, String>(), paramNumberElement.timestamp);
    for (String str : paramNumberElement.metadata.keySet())
      this.metadata.put(str, paramNumberElement.metadata.get(str)); 
    this.value = new BigDecimal(paramNumberElement.value.doubleValue());
  }
  
  public NumberElement(BigDecimal paramBigDecimal) {
    super(new HashMap<String, String>(), ClockUtil.getCurrentTime());
    if (paramBigDecimal == null) {
      Log.e("GC_Whispersync", "NumberElement cannot contain a null value");
      throw new IllegalArgumentException();
    } 
    this.value = paramBigDecimal;
  }
  
  public NumberElement(BigDecimal paramBigDecimal, Map<String, String> paramMap, long paramLong) {
    super(paramMap, paramLong);
    if (paramBigDecimal == null) {
      Log.e("GC_Whispersync", "NumberElement cannot contain a null value");
      throw new IllegalArgumentException();
    } 
    this.value = paramBigDecimal;
  }
  
  public BigDecimal asDecimal() {
    return this.value;
  }
  
  public double asDouble() {
    return this.value.doubleValue();
  }
  
  public int asInt() {
    return this.value.intValue();
  }
  
  public long asLong() {
    return this.value.longValue();
  }
  
  public String asString() {
    return this.value.toString();
  }
  
  protected void reportEvent(String paramString, SyncableType paramSyncableType) {
    EventCollectorClient eventCollectorClient = EventCollectorClient.getInstance();
    if (eventCollectorClient != null) {
      GameCircleGenericEvent gameCircleGenericEvent = WhispersyncMetricsFactory.createSyncableTypeEvent(paramString, paramSyncableType);
      if (gameCircleGenericEvent != null)
        eventCollectorClient.reportGenericEvent(gameCircleGenericEvent); 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[").append(NumberElement.class.getSimpleName()).append(" value=").append(this.value).append(", ").append(" timestamp=").append(this.timestamp).append(", ").append(" metadata=").append(this.metadata).append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\NumberElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */