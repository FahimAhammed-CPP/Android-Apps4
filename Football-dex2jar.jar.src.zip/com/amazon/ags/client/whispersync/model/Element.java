package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableElement;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class Element implements SyncableElement {
  private static final String TAG = "GC_Whispersync";
  
  protected final Map<String, String> metadata = new HashMap<String, String>();
  
  protected long timestamp;
  
  public Element() {}
  
  public Element(Map<String, String> paramMap, long paramLong) {
    if (paramMap != null)
      this.metadata.putAll(paramMap); 
    long l = ClockUtil.getCurrentTime();
    if (paramLong < 0L || paramLong > l) {
      Log.w("GC_Whispersync", "Received an invalid timestamp [" + paramLong + "] setting it to current time [" + l + "]");
      this.timestamp = l;
      return;
    } 
    this.timestamp = paramLong;
  }
  
  public Map<String, String> getMetadata() {
    return Collections.unmodifiableMap(this.metadata);
  }
  
  public long getTimestamp() {
    return this.timestamp;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\Element.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */