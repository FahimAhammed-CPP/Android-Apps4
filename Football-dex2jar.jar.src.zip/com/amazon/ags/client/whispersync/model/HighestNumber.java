package com.amazon.ags.client.whispersync.model;

import android.util.Log;
import com.amazon.ags.api.whispersync.model.SyncableNumber;
import com.amazon.ags.client.whispersync.GameDataLock;
import com.amazon.ags.client.whispersync.WhispersyncClientImpl;
import com.amazon.ags.client.whispersync.clock.ClockUtil;
import java.math.BigDecimal;
import java.util.Map;

public class HighestNumber extends NumberElement implements SyncableNumber, Mergeable<HighestNumber> {
  private static final String TAG = "GC_Whispersync";
  
  private final String name;
  
  private SyncState state = SyncState.NOT_SET;
  
  public HighestNumber(String paramString) {
    this.name = paramString;
  }
  
  public HighestNumber(String paramString, BigDecimal paramBigDecimal, Map<String, String> paramMap, long paramLong, SyncState paramSyncState) {
    super(paramBigDecimal, paramMap, paramLong);
    this.name = paramString;
    this.state = SyncState.SYNCED;
    this.state = paramSyncState;
  }
  
  private void setValue(BigDecimal paramBigDecimal, Map<String, String> paramMap) {
    if (paramBigDecimal == null) {
      Log.e("GC_Whispersync", "Unable to set null HighestNumber with name " + this.name);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE", SyncableType.HIGHEST_NUMBER);
      throw new IllegalArgumentException("Unable to set null HighestNumber with name " + this.name);
    } 
    GameDataLock.lock();
    try {
      if (this.state == SyncState.NOT_SET || this.value.compareTo(paramBigDecimal) < 0) {
        this.value = paramBigDecimal;
        this.timestamp = ClockUtil.getCurrentTime();
        this.state = SyncState.DIRTY;
        this.metadata.clear();
        if (paramMap != null)
          this.metadata.putAll(paramMap); 
        WhispersyncClientImpl.syncPassively();
      } 
      return;
    } finally {
      GameDataLock.unlock();
    } 
  }
  
  public void completeSyncing() {
    if (this.state == SyncState.SYNCING)
      this.state = SyncState.SYNCED; 
  }
  
  public HighestNumber deepCopy() {
    return new HighestNumber(this.name, this.value, this.metadata, this.timestamp, this.state);
  }
  
  public SyncState getState() {
    return this.state;
  }
  
  public boolean isSet() {
    return (this.state != SyncState.NOT_SET);
  }
  
  public void merge(HighestNumber paramHighestNumber) {
    if (paramHighestNumber == null || paramHighestNumber.state == SyncState.NOT_SET) {
      Log.w("GC_Whispersync", "HighestNumber - Unable to merge HighestNumber from invalid value");
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_FAILED_MERGE", SyncableType.HIGHEST_NUMBER);
      return;
    } 
    if (this.state == SyncState.NOT_SET || paramHighestNumber.value.compareTo(this.value) > 0) {
      Log.i("GC_Whispersync", "HighestNumber - merging value for " + this.name + " from " + this.value + " to " + paramHighestNumber.value);
      this.value = paramHighestNumber.value;
      this.metadata.clear();
      this.metadata.putAll(paramHighestNumber.metadata);
      this.timestamp = paramHighestNumber.timestamp;
      if (this.state == SyncState.NOT_SET) {
        this.state = SyncState.SYNCED;
        return;
      } 
    } 
  }
  
  public void set(double paramDouble) {
    set(paramDouble, (Map<String, String>)null);
  }
  
  public void set(double paramDouble, Map<String, String> paramMap) {
    setValue(new BigDecimal(paramDouble), paramMap);
  }
  
  public void set(int paramInt) {
    set(paramInt, (Map<String, String>)null);
  }
  
  public void set(int paramInt, Map<String, String> paramMap) {
    setValue(new BigDecimal(paramInt), paramMap);
  }
  
  public void set(long paramLong) {
    set(paramLong, (Map<String, String>)null);
  }
  
  public void set(long paramLong, Map<String, String> paramMap) {
    setValue(new BigDecimal(paramLong), paramMap);
  }
  
  public void set(String paramString) {
    set(paramString, (Map<String, String>)null);
  }
  
  public void set(String paramString, Map<String, String> paramMap) {
    if (paramString == null) {
      Log.w("GC_Whispersync", "Unable to add null String to HighestNumber with name " + this.name);
      reportEvent("WHISPERSYNC_SYNCABLE_TYPE_UPDATE_FAILURE", SyncableType.HIGHEST_NUMBER);
      throw new IllegalArgumentException("Unable to add null String to HighestNumber with name " + this.name);
    } 
    setValue(new BigDecimal(paramString), paramMap);
  }
  
  public void startSyncing() {
    if (this.state == SyncState.DIRTY)
      this.state = SyncState.SYNCING; 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[").append(HighestNumber.class.getSimpleName()).append(" name=").append(this.name).append(", ").append(" value=").append(this.value).append(", ").append(" timestamp=").append(this.timestamp).append(", ").append(" metadata=").append(this.metadata).append(", ").append(" state=").append(this.state).append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\HighestNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */