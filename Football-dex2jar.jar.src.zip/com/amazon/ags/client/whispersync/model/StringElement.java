package com.amazon.ags.client.whispersync.model;

import com.amazon.ags.api.whispersync.model.SyncableStringElement;
import java.util.HashMap;
import java.util.Map;

public class StringElement extends Element implements SyncableStringElement {
  protected String value;
  
  public StringElement() {}
  
  public StringElement(StringElement paramStringElement) {
    super(new HashMap<String, String>(), paramStringElement.timestamp);
    for (String str : paramStringElement.metadata.keySet())
      this.metadata.put(str, paramStringElement.metadata.get(str)); 
    this.value = paramStringElement.value;
  }
  
  public StringElement(String paramString, Map<String, String> paramMap, long paramLong) {
    super(paramMap, paramLong);
    this.value = paramString;
  }
  
  public String getValue() {
    return this.value;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[").append(StringElement.class.getSimpleName()).append(" value=").append(this.value).append(", ").append(" timestamp=").append(this.timestamp).append(", ").append(" metadata=").append(this.metadata).append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\StringElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */