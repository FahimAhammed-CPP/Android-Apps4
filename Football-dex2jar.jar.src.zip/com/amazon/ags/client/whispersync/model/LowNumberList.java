package com.amazon.ags.client.whispersync.model;

import java.util.Comparator;
import java.util.List;

public class LowNumberList extends NumberList {
  private static final Comparator<NumberElement> ITEM_COMPARATOR = new Comparator<NumberElement>() {
      public int compare(NumberElement param1NumberElement1, NumberElement param1NumberElement2) {
        if (param1NumberElement1.value.compareTo(param1NumberElement2.value) == 0) {
          long l = param1NumberElement2.getTimestamp() - param1NumberElement1.getTimestamp();
          return (l == 0L) ? 0 : ((l > 0L) ? 1 : -1);
        } 
        return param1NumberElement1.value.compareTo(param1NumberElement2.value);
      }
    };
  
  public LowNumberList(String paramString) {
    super(paramString);
  }
  
  public LowNumberList(String paramString, List<NumberElement> paramList, int paramInt, SyncState paramSyncState) {
    super(paramString, paramList, paramInt, paramSyncState);
  }
  
  public LowNumberList deepCopy() {
    return new LowNumberList(this.name, copyElements(), this.maxSize, this.state);
  }
  
  public Comparator<NumberElement> getComparator() {
    return ITEM_COMPARATOR;
  }
  
  public SyncableType getSyncableType() {
    return SyncableType.LOWEST_NUMBER_LIST;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\LowNumberList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */