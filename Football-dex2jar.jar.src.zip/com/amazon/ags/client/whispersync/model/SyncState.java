package com.amazon.ags.client.whispersync.model;

public enum SyncState {
  DIRTY, IN_CONFLICT, NOT_SET, SYNCED, SYNCING;
  
  static {
    DIRTY = new SyncState("DIRTY", 1);
    IN_CONFLICT = new SyncState("IN_CONFLICT", 2);
    SYNCING = new SyncState("SYNCING", 3);
    SYNCED = new SyncState("SYNCED", 4);
    $VALUES = new SyncState[] { NOT_SET, DIRTY, IN_CONFLICT, SYNCING, SYNCED };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\SyncState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */