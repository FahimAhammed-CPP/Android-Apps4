package com.amazon.ags.client.whispersync.model;

import java.util.Comparator;
import java.util.List;

public class LatestNumberList extends NumberList {
  private static final Comparator<NumberElement> ITEM_COMPARATOR = new Comparator<NumberElement>() {
      public int compare(NumberElement param1NumberElement1, NumberElement param1NumberElement2) {
        long l = param1NumberElement2.getTimestamp() - param1NumberElement1.getTimestamp();
        return (l == 0L) ? param1NumberElement1.value.compareTo(param1NumberElement2.value) : ((l > 0L) ? 1 : -1);
      }
    };
  
  public LatestNumberList(String paramString) {
    super(paramString);
  }
  
  public LatestNumberList(String paramString, List<NumberElement> paramList, int paramInt, SyncState paramSyncState) {
    super(paramString, paramList, paramInt, paramSyncState);
  }
  
  public LatestNumberList deepCopy() {
    return new LatestNumberList(this.name, copyElements(), this.maxSize, this.state);
  }
  
  public Comparator<NumberElement> getComparator() {
    return ITEM_COMPARATOR;
  }
  
  public SyncableType getSyncableType() {
    return SyncableType.LATEST_NUMBER_LIST;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\LatestNumberList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */