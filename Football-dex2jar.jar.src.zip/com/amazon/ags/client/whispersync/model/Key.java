package com.amazon.ags.client.whispersync.model;

import android.util.Log;

public class Key {
  public static final String DELIMITER = "~";
  
  private static final String TAG = "GC_Whispersync";
  
  private final String name;
  
  private final SyncableType type;
  
  public Key(SyncableType paramSyncableType, String paramString) {
    if (paramSyncableType == null) {
      Log.e("GC_Whispersync", "Unable to create key with null SyncableType and name " + paramString);
      throw new IllegalArgumentException("Unable to create key with null SyncableType and name " + paramString);
    } 
    if (paramString == null || paramString.isEmpty()) {
      Log.e("GC_Whispersync", "Unable to create key of type " + paramSyncableType.getJsonName() + " with null/empty name");
      throw new IllegalArgumentException("Unable to create key of type " + paramSyncableType.getJsonName() + " with null/empty name");
    } 
    this.type = paramSyncableType;
    this.name = paramString;
  }
  
  public Key(String paramString) {
    if (paramString == null) {
      Log.e("GC_Whispersync", "Unable to create key from null keyString");
      throw new IllegalArgumentException("Unable to create key from null keyString");
    } 
    if (!paramString.contains("~")) {
      Log.e("GC_Whispersync", "Unable to create key from keyString missing delimiter ~");
      throw new IllegalArgumentException("Unable to create key from keyString missing delimiter ~");
    } 
    int i = paramString.indexOf("~");
    this.type = SyncableType.fromString(paramString.substring(0, i));
    this.name = paramString.substring(i + 1);
    if (this.type == null) {
      Log.e("GC_Whispersync", "Unable to create key with null SyncableType and name " + this.name);
      throw new IllegalArgumentException("Unable to create key with null SyncableType and name " + this.name);
    } 
    if (this.name == null || this.name.isEmpty()) {
      Log.e("GC_Whispersync", "Unable to create key of type " + this.type.getJsonName() + " with null/empty name");
      throw new IllegalArgumentException("Unable to create key of type " + this.type.getJsonName() + " with null/empty name");
    } 
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject == null)
        return false; 
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      if (this.name == null) {
        if (((Key)paramObject).name != null)
          return false; 
      } else if (!this.name.equals(((Key)paramObject).name)) {
        return false;
      } 
      if (this.type != ((Key)paramObject).type)
        return false; 
    } 
    return true;
  }
  
  public String getName() {
    return this.name;
  }
  
  public SyncableType getType() {
    return this.type;
  }
  
  public int hashCode() {
    int i;
    int j = 0;
    if (this.name == null) {
      i = 0;
    } else {
      i = this.name.hashCode();
    } 
    if (this.type != null)
      j = this.type.hashCode(); 
    return (i + 31) * 31 + j;
  }
  
  public String toString() {
    return this.type.getJsonName() + "~" + this.name;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\Key.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */