package com.amazon.ags.client.whispersync.model;

public interface Mergeable<T extends Mergeable<T>> {
  void completeSyncing();
  
  T deepCopy();
  
  SyncState getState();
  
  void merge(T paramT);
  
  void startSyncing();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\model\Mergeable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */