package com.amazon.ags.client.whispersync.metrics;

import android.util.Log;
import com.amazon.ags.client.metrics.IllegalConstructionException;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.whispersync.model.SyncableType;
import java.util.HashMap;

public class WhispersyncMetricsFactory {
  private static final String COUNT_FAILURE_METRIC_LABEL = "COUNT_FAILURE";
  
  private static final String COUNT_METRIC_LABEL = "COUNT";
  
  private static final String COUNT_SUCCESS_METRIC_LABEL = "COUNT_SUCCESS";
  
  private static final String TAG = "GC_Whispersync_Metrics";
  
  private static final String TIME_METRIC_LABEL = "TIME";
  
  public static GameCircleGenericEvent createBooleanCountEvent(String paramString, int paramInt, boolean paramBoolean) {
    return createBooleanGenericEvent(paramString, Integer.valueOf(paramInt), null, Boolean.valueOf(paramBoolean));
  }
  
  public static GameCircleGenericEvent createBooleanGenericEvent(String paramString, Integer paramInteger, Long paramLong, Boolean paramBoolean) {
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>();
    if (paramInteger != null)
      if (paramBoolean != null) {
        if (paramBoolean.booleanValue()) {
          hashMap2.put("COUNT_SUCCESS", paramInteger);
        } else {
          hashMap2.put("COUNT_FAILURE", paramInteger);
        } 
      } else {
        hashMap2.put("COUNT", paramInteger);
      }  
    if (paramLong != null)
      hashMap3.put("TIME", paramLong); 
    try {
      return new GameCircleGenericEvent(paramString, hashMap1, hashMap2, hashMap3);
    } catch (IllegalConstructionException illegalConstructionException) {
      Log.w("GC_Whispersync_Metrics", "Failed to construct metric [" + paramString + "]");
      return null;
    } 
  }
  
  public static GameCircleGenericEvent createCountEvent(String paramString, int paramInt) {
    return createBooleanGenericEvent(paramString, Integer.valueOf(paramInt), null, null);
  }
  
  public static GameCircleGenericEvent createGenericEvent(String paramString, Integer paramInteger, Long paramLong) {
    return createBooleanGenericEvent(paramString, paramInteger, paramLong, null);
  }
  
  public static GameCircleGenericEvent createSyncableTypeEvent(String paramString, SyncableType paramSyncableType) {
    return createBooleanGenericEvent(paramString + "_" + paramSyncableType.name(), Integer.valueOf(1), null, null);
  }
  
  public static GameCircleGenericEvent createTimeEvent(String paramString, long paramLong) {
    return createBooleanGenericEvent(paramString, null, Long.valueOf(paramLong), null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\whispersync\metrics\WhispersyncMetricsFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */