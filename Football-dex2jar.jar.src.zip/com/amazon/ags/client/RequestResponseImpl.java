package com.amazon.ags.client;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.RequestResponse;
import org.json.JSONException;
import org.json.JSONObject;

public class RequestResponseImpl implements RequestResponse {
  private final ErrorCode errorCode;
  
  private final int responseCode;
  
  private Object[] userData;
  
  public RequestResponseImpl(int paramInt) {
    this.responseCode = paramInt;
    this.errorCode = ErrorCode.fromServiceResponseCode(paramInt);
  }
  
  public RequestResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    if (paramErrorCode == null)
      throw new IllegalArgumentException("errorCode must be non-null."); 
    this.responseCode = paramInt;
    this.errorCode = paramErrorCode;
  }
  
  public RequestResponseImpl(JSONObject paramJSONObject) {
    byte b;
    try {
      b = paramJSONObject.getInt("RESPONSE_CODE");
    } catch (JSONException jSONException) {
      b = 24;
    } 
    this.responseCode = b;
    this.errorCode = ErrorCode.fromServiceResponseCode(this.responseCode);
  }
  
  public final ErrorCode getError() {
    return this.errorCode;
  }
  
  public int getEventType() {
    return 0;
  }
  
  public final int getResponseCode() {
    return this.responseCode;
  }
  
  public final Object[] getUserData() {
    return this.userData;
  }
  
  public final boolean isError() {
    return getError().isError();
  }
  
  public final void setUserData(Object[] paramArrayOfObject) {
    this.userData = paramArrayOfObject;
  }
  
  public String toString() {
    String str1 = "ResponseCode: " + this.responseCode;
    String str2 = str1 + "\n ErrorCode: " + this.errorCode;
    str1 = str2;
    if (this.userData != null)
      str1 = str2 + "\n " + this.userData.toString(); 
    return str1 + "\n requestType: " + getEventType();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\RequestResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */