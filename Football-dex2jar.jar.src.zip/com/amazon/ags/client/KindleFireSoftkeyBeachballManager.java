package com.amazon.ags.client;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;
import com.amazon.ags.api.AmazonGames;
import com.amazon.ags.api.AmazonGamesClient;
import dalvik.system.PathClassLoader;
import java.lang.reflect.InvocationTargetException;

public class KindleFireSoftkeyBeachballManager {
  private static final String APK_PACKAGE_NAME = "com.amazon.ags.app";
  
  private static final String SOFTKEY_BAR_WRAPPER_CLASS_NAME = "com.amazon.ags.app.util.SoftkeyBarWrapper";
  
  private static final String SOFTKEY_BAR_WRAPPER_SETUP_METHOD_NAME = "setup";
  
  private static final String TAG = "KindleFireSoftkeyBeachballManager";
  
  private Application application;
  
  public KindleFireSoftkeyBeachballManager(Application paramApplication) {
    this.application = paramApplication;
    enableSoftKeyButton();
  }
  
  private void enableSoftKeyButton() {
    try {
      Class<?> clazz = Class.forName("com.amazon.ags.app.util.SoftkeyBarWrapper", true, (ClassLoader)new PathClassLoader((this.application.getPackageManager().getApplicationInfo("com.amazon.ags.app", 0)).sourceDir, ClassLoader.getSystemClassLoader()));
      clazz.getDeclaredMethod("setup", new Class[] { Application.class, BroadcastReceiver.class }).invoke(clazz.newInstance(), new Object[] { this.application, new BroadcastReceiver() {
              public void onReceive(Context param1Context, Intent param1Intent) {
                Log.d("KindleFireSoftkeyBeachballManager", "GameCircle softkey button pressed.");
                KindleFireSoftkeyBeachballManager.this.handleSoftkeyButtonPress();
              }
            } });
      return;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.i("KindleFireSoftkeyBeachballManager", "Failed to enable softkey button: " + nameNotFoundException.toString());
      return;
    } catch (ClassNotFoundException classNotFoundException) {
      Log.i("KindleFireSoftkeyBeachballManager", "Failed to enable softkey button: " + classNotFoundException.toString());
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("KindleFireSoftkeyBeachballManager", "Failed to enable softkey button: " + noSuchMethodException.toString());
      return;
    } catch (InstantiationException instantiationException) {
      Log.i("KindleFireSoftkeyBeachballManager", "Failed to enable softkey button: " + instantiationException.toString());
      return;
    } catch (IllegalAccessException illegalAccessException) {
      Log.i("KindleFireSoftkeyBeachballManager", "Failed to enable softkey button: " + illegalAccessException.toString());
      return;
    } catch (IllegalArgumentException illegalArgumentException) {
      Log.i("KindleFireSoftkeyBeachballManager", "Failed to enable softkey button: " + illegalArgumentException.toString());
      return;
    } catch (InvocationTargetException invocationTargetException) {
      Log.i("KindleFireSoftkeyBeachballManager", "Failed to enable softkey button: " + invocationTargetException.toString());
      return;
    } 
  }
  
  private void handleSoftkeyButtonPress() {
    AmazonGames amazonGames = AmazonGamesClient.getInstance();
    if (amazonGames != null)
      amazonGames.showGameCircle(new Object[0]); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\KindleFireSoftkeyBeachballManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */