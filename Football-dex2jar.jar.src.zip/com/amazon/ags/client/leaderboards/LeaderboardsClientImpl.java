package com.amazon.ags.client.leaderboards;

import android.util.Log;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.leaderboards.GetLeaderboardPercentilesResponse;
import com.amazon.ags.api.leaderboards.GetLeaderboardsResponse;
import com.amazon.ags.api.leaderboards.GetPlayerScoreResponse;
import com.amazon.ags.api.leaderboards.GetScoresResponse;
import com.amazon.ags.api.leaderboards.Leaderboard;
import com.amazon.ags.api.leaderboards.LeaderboardsClient;
import com.amazon.ags.api.leaderboards.Score;
import com.amazon.ags.api.leaderboards.SubmitScoreResponse;
import com.amazon.ags.api.player.Player;
import com.amazon.ags.client.AGResponseHandleImpl;
import com.amazon.ags.client.ClientBase;
import com.amazon.ags.client.OverlayClient;
import com.amazon.ags.client.RequestResponseImpl;
import com.amazon.ags.client.player.PlayerImpl;
import com.amazon.ags.constants.LeaderboardFilter;
import com.amazon.ags.constants.ScoreFormat;
import com.amazon.ags.html5.service.ServiceHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LeaderboardsClientImpl extends ClientBase implements LeaderboardsClient {
  private static final String UNKNOWN_VALUE = "UNKNOWN";
  
  private OverlayClient overlayClient;
  
  public LeaderboardsClientImpl() {}
  
  public LeaderboardsClientImpl(ServiceHelper paramServiceHelper, OverlayClient paramOverlayClient) {
    super(paramServiceHelper);
    this.overlayClient = paramOverlayClient;
  }
  
  private static Leaderboard convertToLeaderboard(JSONObject paramJSONObject) throws JSONException {
    String str4 = paramJSONObject.getString("LEADERBOARD_ID");
    String str5 = paramJSONObject.getString("LEADERBOARD_NAME");
    String str6 = paramJSONObject.optString("LEADERBOARD_ICON_URL", null);
    String str2 = paramJSONObject.getString("LEADERBOARD_DISPLAY_TEXT");
    String str3 = paramJSONObject.getString("LEADERBOARD_DATA_FORMAT");
    String str1 = str2;
    if (str2 == null)
      str1 = "UNKNOWN"; 
    str2 = str3;
    if (str3 == null)
      str2 = ScoreFormat.UNKNOWN.toString(); 
    return new LeaderboardImpl(str4, str5, str1, ScoreFormat.valueOf(str2), str6);
  }
  
  private Score convertToScore(JSONObject paramJSONObject, ScoreFormat paramScoreFormat) throws JSONException {
    long l = paramJSONObject.getLong("scoreValue");
    int i = paramJSONObject.getInt("rank");
    String str1 = paramJSONObject.getString("leaderboard");
    String str2 = paramJSONObject.getString("ALIAS");
    return new ScoreImpl(l, (Player)new PlayerImpl(paramJSONObject.getString("playerId"), str2, paramJSONObject.getString("avatarUrl")), i, str1, paramScoreFormat);
  }
  
  public AGResponseHandle<GetLeaderboardsResponse> getLeaderboards(Object... paramVarArgs) {
    AGResponseHandleImpl aGResponseHandleImpl;
    if (!isClientReady()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new GetLeaderboardsResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "getLeaderboards called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<GetLeaderboardsResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<GetLeaderboardsResponse>("Get Leaderboards") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 9);
          return jSONObject;
        }
        
        public GetLeaderboardsResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int j = param1JSONObject.getInt("RESPONSE_CODE");
          JSONArray jSONArray = param1JSONObject.getJSONArray("LEADERBOARDS");
          ArrayList<Leaderboard> arrayList = new ArrayList(jSONArray.length());
          for (int i = 0; i < jSONArray.length(); i++) {
            Object object = jSONArray.get(i);
            if (object instanceof JSONObject)
              arrayList.add(LeaderboardsClientImpl.convertToLeaderboard((JSONObject)object)); 
          } 
          return new GetLeaderboardsResponseImpl(arrayList, j);
        }
        
        public GetLeaderboardsResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new GetLeaderboardsResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute((Object[])aGResponseHandleImpl);
  }
  
  public AGResponseHandle<GetPlayerScoreResponse> getLocalPlayerScore(String paramString, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs) {
    return getScoreForPlayer(paramString, "SELF", paramLeaderboardFilter, paramVarArgs);
  }
  
  public AGResponseHandle<GetLeaderboardPercentilesResponse> getPercentileRanks(String paramString, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs) {
    return getPercentileRanksForPlayer(paramString, "SELF", paramLeaderboardFilter, paramVarArgs);
  }
  
  public AGResponseHandle<GetLeaderboardPercentilesResponse> getPercentileRanksForPlayer(final String leaderboardId, final String playerId, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs) {
    final AGResponseHandleImpl filter;
    if (!isClientReady() || leaderboardId == null || playerId == null) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new GetLeaderboardPercentilesResponseImpl(29, ErrorCode.UNRECOVERABLE));
      if (leaderboardId == null) {
        Log.w(this.TAG, "getPercentileRanks called with null leaderboard ID; returning empty response");
        return (AGResponseHandle<GetLeaderboardPercentilesResponse>)aGResponseHandleImpl;
      } 
      if (playerId == null) {
        Log.w(this.TAG, "getPercentileRanks called with null player ID; returning empty response");
        return (AGResponseHandle<GetLeaderboardPercentilesResponse>)aGResponseHandleImpl;
      } 
      Log.w(this.TAG, "getPercentileRanks called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<GetLeaderboardPercentilesResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<GetLeaderboardPercentilesResponse>("Get Local Player Score") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 31);
          jSONObject.put("LEADERBOARD_ID", leaderboardId);
          jSONObject.put("playerId", playerId);
          jSONObject.put("LEADERBOARD_FILTER", filter.name());
          return jSONObject;
        }
        
        public GetLeaderboardPercentilesResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int j = param1JSONObject.getInt("RESPONSE_CODE");
          String str3 = param1JSONObject.getString("LEADERBOARD_ID");
          String str4 = param1JSONObject.getString("LEADERBOARD_NAME");
          String str5 = param1JSONObject.getString("LEADERBOARD_DISPLAY_TEXT");
          String str2 = param1JSONObject.getString("LEADERBOARD_DATA_FORMAT");
          int k = param1JSONObject.getInt("LEADERBOARD_USER_INDEX");
          String str6 = param1JSONObject.optString("LEADERBOARD_ICON_URL", null);
          String str1 = str2;
          if (str2 == null)
            str1 = ScoreFormat.UNKNOWN.toString(); 
          ScoreFormat scoreFormat = ScoreFormat.valueOf(str1);
          JSONArray jSONArray = param1JSONObject.getJSONArray("LEADERBOARD_PERCENTILES_ARRAY");
          ArrayList<LeaderboardPercentileItemImpl> arrayList = new ArrayList(jSONArray.length());
          for (int i = 0; i < jSONArray.length(); i++) {
            Object object = jSONArray.get(i);
            if (object instanceof JSONObject)
              arrayList.add(new LeaderboardPercentileItemImpl((Player)new PlayerImpl(((JSONObject)object).optString("PlayerId"), ((JSONObject)object).optString("PlayerName"), ((JSONObject)object).optString("AvatarUrl")), ((JSONObject)object).getLong("PlayerScore"), ((JSONObject)object).getInt("Percentile"))); 
          } 
          return new GetLeaderboardPercentilesResponseImpl(new LeaderboardImpl(str3, str4, str5, scoreFormat, str6), (List)arrayList, k, j);
        }
        
        public GetLeaderboardPercentilesResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new GetLeaderboardPercentilesResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(paramVarArgs);
  }
  
  public AGResponseHandle<GetPlayerScoreResponse> getScoreForPlayer(final String leaderboardId, final String playerId, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs) {
    final AGResponseHandleImpl filter;
    if (!isClientReady() || leaderboardId == null || playerId == null) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new GetPlayerScoreResponseImpl(29, ErrorCode.UNRECOVERABLE));
      if (leaderboardId == null) {
        Log.w(this.TAG, "getPlayerScore called with null leaderboard ID; returning empty response");
        return (AGResponseHandle<GetPlayerScoreResponse>)aGResponseHandleImpl;
      } 
      if (playerId == null) {
        Log.w(this.TAG, "getPlayerScore called with null player ID; returning empty response");
        return (AGResponseHandle<GetPlayerScoreResponse>)aGResponseHandleImpl;
      } 
      Log.w(this.TAG, "getPlayerScore called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<GetPlayerScoreResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<GetPlayerScoreResponse>("Get Local Player Score") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 10);
          jSONObject.put("LEADERBOARD_ID", leaderboardId);
          jSONObject.put("playerId", playerId);
          jSONObject.put("LEADERBOARD_FILTER", filter.name());
          return jSONObject;
        }
        
        public GetPlayerScoreResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int i = param1JSONObject.getInt("RESPONSE_CODE");
          return new GetPlayerScoreResponseImpl(LeaderboardsClientImpl.this.getLong(param1JSONObject, "LEADERBOARD_SUBMIT_SCORE", 0L), LeaderboardsClientImpl.this.getInt(param1JSONObject, "LEADERBOARD_USER_RANK", -1), i);
        }
        
        public GetPlayerScoreResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new GetPlayerScoreResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(paramVarArgs);
  }
  
  public AGResponseHandle<GetScoresResponse> getScores(String paramString, final LeaderboardFilter filter, Object... paramVarArgs) {
    final AGResponseHandleImpl leaderboardId;
    if (!isClientReady()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new GetScoresResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "getScores called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<GetScoresResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<GetScoresResponse>("Get Local Player Score") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 7);
          jSONObject.put("LEADERBOARD_ID", leaderboardId);
          jSONObject.put("LEADERBOARD_FILTER", filter.name());
          return jSONObject;
        }
        
        public GetScoresResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int j = param1JSONObject.getInt("RESPONSE_CODE");
          String str1 = param1JSONObject.getString("LEADERBOARD_DISPLAY_TEXT");
          String str2 = param1JSONObject.getString("LEADERBOARD_NAME");
          String str3 = param1JSONObject.getString("LEADERBOARD_ID");
          String str5 = param1JSONObject.getString("LEADERBOARD_DATA_FORMAT");
          String str4 = param1JSONObject.getString("LEADERBOARD_ICON_URL");
          ScoreFormat scoreFormat = ScoreFormat.valueOf(str5);
          JSONArray jSONArray = param1JSONObject.getJSONArray("LEADERBOARD_SCORES_ARRAY");
          Score[] arrayOfScore = new Score[jSONArray.length()];
          for (int i = 0; i < jSONArray.length(); i++) {
            Object object = jSONArray.get(i);
            if (object instanceof JSONObject)
              arrayOfScore[i] = LeaderboardsClientImpl.this.convertToScore((JSONObject)object, scoreFormat); 
          } 
          return new GetScoresResponseImpl(arrayOfScore, str1, scoreFormat, str2, str3, j, str4);
        }
        
        public GetScoresResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new GetScoresResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(paramVarArgs);
  }
  
  public void setOverlayClient(OverlayClient paramOverlayClient) {
    this.overlayClient = paramOverlayClient;
  }
  
  public AGResponseHandle<RequestResponse> showLeaderboardOverlay(String paramString, Object... paramVarArgs) {
    AGResponseHandleImpl aGResponseHandleImpl;
    if (this.overlayClient == null) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new RequestResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "showLeaderboardOverlay called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<RequestResponse>)aGResponseHandleImpl;
    } 
    return this.overlayClient.showLeaderboardOverlay((String)aGResponseHandleImpl, paramVarArgs);
  }
  
  public AGResponseHandle<RequestResponse> showLeaderboardsOverlay(Object... paramVarArgs) {
    AGResponseHandleImpl aGResponseHandleImpl;
    if (this.overlayClient == null) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new RequestResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "showLeaderboardsOverlay called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<RequestResponse>)aGResponseHandleImpl;
    } 
    return this.overlayClient.showLeaderboardsOverlay((Object[])aGResponseHandleImpl);
  }
  
  public void shutdown() {
    this.isReady = false;
    this.overlayClient = null;
  }
  
  public AGResponseHandle<SubmitScoreResponse> submitScore(String paramString, final long score, Object... paramVarArgs) {
    final AGResponseHandleImpl leaderboardId;
    if (!isClientReady()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new SubmitScoreResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "submitScore called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<SubmitScoreResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<SubmitScoreResponse>("Submit Score") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 8);
          jSONObject.put("LEADERBOARD_ID", leaderboardId);
          jSONObject.put("LEADERBOARD_SUBMIT_SCORE", score);
          return jSONObject;
        }
        
        public SubmitScoreResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int i = param1JSONObject.getInt("RESPONSE_CODE");
          HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
          HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
          try {
            if (param1JSONObject.has("LEADERBOARD_SUBMIT_RESULT")) {
              JSONArray jSONArray = param1JSONObject.getJSONArray("LEADERBOARD_SUBMIT_RESULT");
              for (int j = 0;; j++) {
                if (j < jSONArray.length()) {
                  Object object = jSONArray.get(j);
                  if (object instanceof JSONObject) {
                    object = object;
                    String str = object.getString("Scope");
                    LeaderboardFilter leaderboardFilter = LeaderboardFilter.valueOf(str);
                    if (leaderboardFilter == null) {
                      Log.w(LeaderboardsClientImpl.this.TAG, "Invalid filter returned from service: " + str);
                    } else {
                      hashMap1.put(leaderboardFilter, Boolean.valueOf(object.getBoolean("IsImproved")));
                      hashMap2.put(leaderboardFilter, Integer.valueOf(object.getInt("PlayerRank")));
                    } 
                  } else {
                    Log.w(LeaderboardsClientImpl.this.TAG, "Unexpected type " + object.getClass() + ", skipping this Submit Score Result Element");
                  } 
                } else {
                  return new SubmitScoreResponseImpl((Map)hashMap1, (Map)hashMap2, i);
                } 
              } 
            } 
          } catch (JSONException jSONException) {
            Log.w(LeaderboardsClientImpl.this.TAG, "Caught JSON Exception, skipping Submit Score Result Element(s)", (Throwable)jSONException);
          } 
          return new SubmitScoreResponseImpl((Map)hashMap1, (Map)hashMap2, i);
        }
        
        public SubmitScoreResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new SubmitScoreResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(paramVarArgs);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\leaderboards\LeaderboardsClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */