package com.amazon.ags.client.leaderboards;

import android.util.Log;
import com.amazon.ags.api.leaderboards.Score;
import com.amazon.ags.api.player.Player;
import com.amazon.ags.constants.ScoreFormat;

public class ScoreImpl implements Score {
  private static final String FEATURE_NAME = "LB";
  
  private static final String TAG = "LB_" + ScoreImpl.class.getSimpleName();
  
  private final String leaderboard;
  
  private final Player player;
  
  private final int rank;
  
  private final ScoreFormat scoreFormat;
  
  private final long scoreValue;
  
  public ScoreImpl(long paramLong, Player paramPlayer, int paramInt, String paramString) {
    Log.d(TAG, "Creating score with score value " + paramLong + " player " + paramPlayer + " rank " + paramInt + " leaderboard " + paramString);
    this.scoreValue = paramLong;
    this.player = paramPlayer;
    this.rank = paramInt;
    this.leaderboard = paramString;
    this.scoreFormat = ScoreFormat.UNKNOWN;
  }
  
  public ScoreImpl(long paramLong, Player paramPlayer, int paramInt, String paramString, ScoreFormat paramScoreFormat) {
    Log.d(TAG, "Creating score with score value " + paramLong + " player " + paramPlayer + " rank " + paramInt + " leaderboard " + paramString);
    this.scoreValue = paramLong;
    this.player = paramPlayer;
    this.rank = paramInt;
    this.leaderboard = paramString;
    this.scoreFormat = paramScoreFormat;
  }
  
  public final String getLeaderboard() {
    return this.leaderboard;
  }
  
  public final Player getPlayer() {
    return this.player;
  }
  
  public final int getRank() {
    return this.rank;
  }
  
  public final String getScoreString() {
    switch (this.scoreFormat) {
      default:
        return Long.toString(this.scoreValue);
      case NUMERIC:
        return String.format("%,d", new Object[] { Long.valueOf(this.scoreValue) });
      case DURATION:
        break;
    } 
    return Long.toString(this.scoreValue);
  }
  
  public final long getScoreValue() {
    return this.scoreValue;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\leaderboards\ScoreImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */