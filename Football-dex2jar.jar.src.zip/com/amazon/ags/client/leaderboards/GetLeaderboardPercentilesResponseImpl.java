package com.amazon.ags.client.leaderboards;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.leaderboards.GetLeaderboardPercentilesResponse;
import com.amazon.ags.api.leaderboards.Leaderboard;
import com.amazon.ags.api.leaderboards.LeaderboardPercentileItem;
import com.amazon.ags.client.RequestResponseImpl;
import java.util.List;

public class GetLeaderboardPercentilesResponseImpl extends RequestResponseImpl implements GetLeaderboardPercentilesResponse {
  private final Leaderboard leaderboard = null;
  
  private final List<LeaderboardPercentileItem> percentileList = null;
  
  private final int userIndex = -1;
  
  public GetLeaderboardPercentilesResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public GetLeaderboardPercentilesResponseImpl(Leaderboard paramLeaderboard, List<LeaderboardPercentileItem> paramList, int paramInt1, int paramInt2) {
    super(paramInt2);
  }
  
  public Leaderboard getLeaderboard() {
    return this.leaderboard;
  }
  
  public List<LeaderboardPercentileItem> getPercentileList() {
    return this.percentileList;
  }
  
  public int getUserIndex() {
    return this.userIndex;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\leaderboards\GetLeaderboardPercentilesResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */