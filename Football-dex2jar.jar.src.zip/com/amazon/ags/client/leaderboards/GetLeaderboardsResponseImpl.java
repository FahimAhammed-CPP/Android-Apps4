package com.amazon.ags.client.leaderboards;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.leaderboards.GetLeaderboardsResponse;
import com.amazon.ags.api.leaderboards.Leaderboard;
import com.amazon.ags.client.RequestResponseImpl;
import java.util.List;

public class GetLeaderboardsResponseImpl extends RequestResponseImpl implements GetLeaderboardsResponse {
  private final List<Leaderboard> leaderboards;
  
  private final int numLeaderboards;
  
  public GetLeaderboardsResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
    this.numLeaderboards = 0;
    this.leaderboards = null;
  }
  
  public GetLeaderboardsResponseImpl(List<Leaderboard> paramList, int paramInt) {
    super(paramInt);
    this.leaderboards = paramList;
    if (paramList != null) {
      paramInt = paramList.size();
    } else {
      paramInt = 0;
    } 
    this.numLeaderboards = paramInt;
  }
  
  public final int getEventType() {
    return 9;
  }
  
  public final List<Leaderboard> getLeaderboards() {
    return this.leaderboards;
  }
  
  public final int getNumLeaderboards() {
    return this.numLeaderboards;
  }
  
  public final String toString() {
    String str = super.toString();
    return str + "\n numLeaderboards: " + this.numLeaderboards;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\leaderboards\GetLeaderboardsResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */