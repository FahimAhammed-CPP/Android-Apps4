package com.amazon.ags.client.leaderboards;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.leaderboards.GetPlayerScoreResponse;
import com.amazon.ags.client.RequestResponseImpl;

public class GetPlayerScoreResponseImpl extends RequestResponseImpl implements GetPlayerScoreResponse {
  private final int rank = 0;
  
  private final long scoreValue = 0L;
  
  public GetPlayerScoreResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public GetPlayerScoreResponseImpl(long paramLong, int paramInt1, int paramInt2) {
    super(paramInt2);
  }
  
  public final int getEventType() {
    return 10;
  }
  
  public final int getRank() {
    return this.rank;
  }
  
  public final long getScoreValue() {
    return this.scoreValue;
  }
  
  public final String toString() {
    String str = super.toString();
    str = str + "\n score: " + this.scoreValue;
    return str + "\n rank: " + this.rank;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\leaderboards\GetPlayerScoreResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */