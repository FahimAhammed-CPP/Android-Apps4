package com.amazon.ags.client.leaderboards;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.leaderboards.GetScoresResponse;
import com.amazon.ags.api.leaderboards.Leaderboard;
import com.amazon.ags.api.leaderboards.Score;
import com.amazon.ags.client.RequestResponseImpl;
import com.amazon.ags.constants.ScoreFormat;
import java.util.ArrayList;
import java.util.List;

public class GetScoresResponseImpl extends RequestResponseImpl implements GetScoresResponse {
  private final Leaderboard leaderboard = new LeaderboardImpl("", "", "", ScoreFormat.UNKNOWN, "");
  
  private final int numScores = 0;
  
  private final List<Score> scores = new ArrayList<Score>();
  
  public GetScoresResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public GetScoresResponseImpl(Score[] paramArrayOfScore, String paramString1, ScoreFormat paramScoreFormat, String paramString2, String paramString3, int paramInt, String paramString4) {
    super(paramInt);
  }
  
  public final int getEventType() {
    return 7;
  }
  
  public Leaderboard getLeaderboard() {
    return this.leaderboard;
  }
  
  public final int getNumScores() {
    return this.numScores;
  }
  
  public final List<Score> getScores() {
    return this.scores;
  }
  
  public final String toString() {
    String str = super.toString();
    str = str + "\n numScores: " + this.numScores;
    return str + "\n leaderboard: " + this.leaderboard;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\leaderboards\GetScoresResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */