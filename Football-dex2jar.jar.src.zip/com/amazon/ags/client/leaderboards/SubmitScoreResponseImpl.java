package com.amazon.ags.client.leaderboards;

import android.util.Log;
import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.leaderboards.SubmitScoreResponse;
import com.amazon.ags.client.RequestResponseImpl;
import com.amazon.ags.constants.LeaderboardFilter;
import java.util.HashMap;
import java.util.Map;

public class SubmitScoreResponseImpl extends RequestResponseImpl implements SubmitScoreResponse {
  private static final String FEATURE_NAME = "LB";
  
  private static final String TAG = "LB_" + SubmitScoreResponseImpl.class.getSimpleName();
  
  private final Map<LeaderboardFilter, Boolean> improvedInFilter;
  
  private final Map<LeaderboardFilter, Integer> rankInFilter;
  
  public SubmitScoreResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
    this.improvedInFilter = null;
    this.rankInFilter = null;
  }
  
  public SubmitScoreResponseImpl(Map<LeaderboardFilter, Boolean> paramMap, Map<LeaderboardFilter, Integer> paramMap1, int paramInt) {
    super(paramInt);
    if (paramMap == null || paramMap1 == null) {
      Log.d(TAG, "Constructing SubmitScoreResponse with null improvements");
      this.improvedInFilter = new HashMap<LeaderboardFilter, Boolean>();
      this.rankInFilter = new HashMap<LeaderboardFilter, Integer>();
      return;
    } 
    this.improvedInFilter = paramMap;
    this.rankInFilter = paramMap1;
  }
  
  public final int getEventType() {
    return 8;
  }
  
  public final Map<LeaderboardFilter, Integer> getNewRank() {
    return this.rankInFilter;
  }
  
  public final Map<LeaderboardFilter, Boolean> getRankImproved() {
    return this.improvedInFilter;
  }
  
  public final String toString() {
    String str = super.toString();
    str = str + "\n Improvements: " + this.improvedInFilter;
    return str + "\n Ranks: " + this.rankInFilter;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\leaderboards\SubmitScoreResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */