package com.amazon.ags.client.leaderboards;

import com.amazon.ags.api.leaderboards.Leaderboard;
import com.amazon.ags.constants.ScoreFormat;

public class LeaderboardImpl implements Leaderboard {
  private final String displayText;
  
  private final String id;
  
  private final String imageURL;
  
  private final String name;
  
  private final ScoreFormat scoreFormat;
  
  public LeaderboardImpl(String paramString1, String paramString2, String paramString3, ScoreFormat paramScoreFormat, String paramString4) {
    this.id = paramString1;
    this.name = paramString2;
    this.displayText = paramString3;
    this.scoreFormat = paramScoreFormat;
    this.imageURL = paramString4;
  }
  
  public String getDisplayText() {
    return this.displayText;
  }
  
  public String getId() {
    return this.id;
  }
  
  public String getImageURL() {
    return this.imageURL;
  }
  
  public String getName() {
    return this.name;
  }
  
  public ScoreFormat getScoreFormat() {
    return this.scoreFormat;
  }
  
  public String toString() {
    return "Leaderboard{id=" + this.id + ", name=" + this.name + "," + "displayText=" + this.displayText + ", scoreFormat=" + this.scoreFormat + ", imageURL = " + this.imageURL + "}";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\leaderboards\LeaderboardImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */