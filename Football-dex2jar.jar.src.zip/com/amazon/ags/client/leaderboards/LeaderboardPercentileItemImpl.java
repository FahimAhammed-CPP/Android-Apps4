package com.amazon.ags.client.leaderboards;

import com.amazon.ags.api.leaderboards.LeaderboardPercentileItem;
import com.amazon.ags.api.player.Player;

public class LeaderboardPercentileItemImpl implements LeaderboardPercentileItem {
  private final int percentile;
  
  private final Player player;
  
  private final long playerScore;
  
  public LeaderboardPercentileItemImpl(Player paramPlayer, long paramLong, int paramInt) {
    this.player = paramPlayer;
    this.playerScore = paramLong;
    this.percentile = paramInt;
  }
  
  public int getPercentile() {
    return this.percentile;
  }
  
  public Player getPlayer() {
    return this.player;
  }
  
  public long getPlayerScore() {
    return this.playerScore;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\leaderboards\LeaderboardPercentileItemImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */