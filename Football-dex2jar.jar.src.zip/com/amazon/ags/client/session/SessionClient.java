package com.amazon.ags.client.session;

import android.util.Log;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.client.AGResponseHandleImpl;
import com.amazon.ags.client.ClientBase;
import com.amazon.ags.client.RequestResponseImpl;
import com.amazon.ags.html5.service.ServiceHelper;
import org.json.JSONException;
import org.json.JSONObject;

public class SessionClient extends ClientBase {
  public SessionClient() {}
  
  public SessionClient(ServiceHelper paramServiceHelper) {
    super(paramServiceHelper);
  }
  
  public AGResponseHandle<InitializeSessionResponse> initializeSession() {
    if (!isClientReady()) {
      AGResponseHandleImpl aGResponseHandleImpl = new AGResponseHandleImpl(null);
      aGResponseHandleImpl.setResponse((RequestResponse)new InitializeSessionResponse(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "initializeSession called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<InitializeSessionResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<InitializeSessionResponse>("GameCircle.initialize") {
        public JSONObject buildRequest() throws JSONException {
          return buildRequestForServiceAction(25);
        }
        
        public InitializeSessionResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int i = param1JSONObject.getInt("RESPONSE_CODE");
          return new InitializeSessionResponse(param1JSONObject.getString("AUTH_RESULT"), i);
        }
        
        public InitializeSessionResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new InitializeSessionResponse(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(null);
  }
  
  public AGResponseHandle<WhispersyncEnabledResponse> isWhispersyncEnabled() {
    if (!isClientReady()) {
      AGResponseHandleImpl aGResponseHandleImpl = new AGResponseHandleImpl(null);
      aGResponseHandleImpl.setResponse((RequestResponse)new WhispersyncEnabledResponse(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "isWhispersyncEnabled called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<WhispersyncEnabledResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<WhispersyncEnabledResponse>("Is Whispersync Enabled") {
        public JSONObject buildRequest() throws JSONException {
          return buildRequestForServiceAction("IS_WHISPERSYNC_ENABLED");
        }
        
        public WhispersyncEnabledResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          return new WhispersyncEnabledResponse(param1JSONObject.getInt("RESPONSE_CODE"), param1JSONObject.getBoolean("WHISPERSYNC_ENABLED"));
        }
        
        public WhispersyncEnabledResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return new WhispersyncEnabledResponse(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(null);
  }
  
  public AGResponseHandle<RequestResponse> processSessionEvent(SessionEvent paramSessionEvent) {
    final AGResponseHandleImpl sessionEvent;
    if (!isClientReady()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(null);
      aGResponseHandleImpl.setResponse((RequestResponse)new RequestResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(this.TAG, "processSessionEvent called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<RequestResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<RequestResponse>("GameCircle.onResume") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = buildRequestForServiceAction(sessionEvent.getActionCode());
          jSONObject.put("REQUEST_TIMESTAMP", sessionEvent.getTimestamp());
          return jSONObject;
        }
        
        public RequestResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          return (RequestResponse)new RequestResponseImpl(param1JSONObject.getInt("RESPONSE_CODE"));
        }
        
        public RequestResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          return (RequestResponse)new RequestResponseImpl(24, ErrorCode.UNRECOVERABLE);
        }
      }).execute(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\session\SessionClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */