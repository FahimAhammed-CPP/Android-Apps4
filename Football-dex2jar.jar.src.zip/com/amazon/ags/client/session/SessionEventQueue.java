package com.amazon.ags.client.session;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;

public class SessionEventQueue {
  private static final int QUEUE_LIMIT = 100;
  
  private static final String TAG = "GC_" + SessionEventQueue.class.getSimpleName();
  
  private List<SessionEvent> eventQueue = new LinkedList<SessionEvent>();
  
  private SessionClient sessionClient = null;
  
  public void enqueue(SessionEvent paramSessionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield sessionClient : Lcom/amazon/ags/client/session/SessionClient;
    //   6: ifnonnull -> 73
    //   9: aload_0
    //   10: getfield eventQueue : Ljava/util/List;
    //   13: ifnonnull -> 28
    //   16: getstatic com/amazon/ags/client/session/SessionEventQueue.TAG : Ljava/lang/String;
    //   19: ldc 'Unable to queue session event: queue is null'
    //   21: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   24: pop
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: aload_0
    //   29: getfield eventQueue : Ljava/util/List;
    //   32: invokeinterface size : ()I
    //   37: bipush #100
    //   39: if_icmple -> 59
    //   42: getstatic com/amazon/ags/client/session/SessionEventQueue.TAG : Ljava/lang/String;
    //   45: ldc 'Unable to queue session event: queue is full'
    //   47: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   50: pop
    //   51: goto -> 25
    //   54: astore_1
    //   55: aload_0
    //   56: monitorexit
    //   57: aload_1
    //   58: athrow
    //   59: aload_0
    //   60: getfield eventQueue : Ljava/util/List;
    //   63: aload_1
    //   64: invokeinterface add : (Ljava/lang/Object;)Z
    //   69: pop
    //   70: goto -> 25
    //   73: aload_0
    //   74: monitorexit
    //   75: aload_0
    //   76: getfield sessionClient : Lcom/amazon/ags/client/session/SessionClient;
    //   79: aload_1
    //   80: invokevirtual processSessionEvent : (Lcom/amazon/ags/client/session/SessionEvent;)Lcom/amazon/ags/api/AGResponseHandle;
    //   83: pop
    //   84: return
    // Exception table:
    //   from	to	target	type
    //   2	25	54	finally
    //   25	27	54	finally
    //   28	51	54	finally
    //   55	57	54	finally
    //   59	70	54	finally
    //   73	75	54	finally
  }
  
  public void setSessionClient(SessionClient paramSessionClient, ExecutorService paramExecutorService) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield sessionClient : Lcom/amazon/ags/client/session/SessionClient;
    //   7: aload_0
    //   8: getfield eventQueue : Ljava/util/List;
    //   11: astore_3
    //   12: aload_0
    //   13: aconst_null
    //   14: putfield eventQueue : Ljava/util/List;
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_3
    //   20: ifnull -> 48
    //   23: aload_3
    //   24: invokeinterface isEmpty : ()Z
    //   29: ifne -> 48
    //   32: aload_2
    //   33: new com/amazon/ags/client/session/SessionEventQueue$1
    //   36: dup
    //   37: aload_0
    //   38: aload_3
    //   39: aload_1
    //   40: invokespecial <init> : (Lcom/amazon/ags/client/session/SessionEventQueue;Ljava/util/List;Lcom/amazon/ags/client/session/SessionClient;)V
    //   43: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   48: return
    //   49: astore_1
    //   50: aload_0
    //   51: monitorexit
    //   52: aload_1
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	49	finally
    //   50	52	49	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\session\SessionEventQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */