package com.amazon.ags.client.session;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.client.RequestResponseImpl;

public class WhispersyncEnabledResponse extends RequestResponseImpl {
  private final boolean whispersyncEnabled = false;
  
  public WhispersyncEnabledResponse(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public WhispersyncEnabledResponse(int paramInt, boolean paramBoolean) {
    super(paramInt);
  }
  
  public boolean isWhispersyncEnabled() {
    return this.whispersyncEnabled;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\session\WhispersyncEnabledResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */