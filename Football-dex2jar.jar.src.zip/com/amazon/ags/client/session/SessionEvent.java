package com.amazon.ags.client.session;

public class SessionEvent {
  private final String actionCode;
  
  private final long timestamp = System.currentTimeMillis();
  
  public SessionEvent(String paramString) {
    this.actionCode = paramString;
  }
  
  public String getActionCode() {
    return this.actionCode;
  }
  
  public long getTimestamp() {
    return this.timestamp;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\session\SessionEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */