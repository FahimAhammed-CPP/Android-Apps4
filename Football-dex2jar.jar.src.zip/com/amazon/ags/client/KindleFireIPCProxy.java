package com.amazon.ags.client;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import com.amazon.ags.html5.util.JSONUtils;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class KindleFireIPCProxy implements KindleFireProxy {
  private static final String SERVICE_CLASS_NAME = "com.amazon.ags.app.service.AmazonGamesService";
  
  private static final String SERVICE_PACKAGE_NAME = "com.amazon.ags.app";
  
  private static final String TAG = "KindleFireIPCProxy";
  
  private Messenger asynchronousMessenger = null;
  
  private KindleFireBindingCallback callback = null;
  
  private final Context context;
  
  private Boolean isKindle = null;
  
  private Boolean isOverlaysSupported = null;
  
  private Boolean isUniversalSupported = null;
  
  private String sessionId;
  
  private KindleFireStatus status = KindleFireStatus.INITIALIZING;
  
  private IBinder synchronousBinder = null;
  
  public KindleFireIPCProxy(Context paramContext) {
    this.context = paramContext;
  }
  
  private void authorize() {
    Log.d("KindleFireIPCProxy", "Attempting to Authorize");
    Message message = Message.obtain();
    message.what = 44;
    message.replyTo = new Messenger(new Handler() {
          public void handleMessage(Message param1Message) {
            Log.d("KindleFireIPCProxy", "Handling authorize callback");
            Bundle bundle = param1Message.getData();
            if (bundle == null) {
              Log.e("KindleFireIPCProxy", "No bundle in authorize result.");
              KindleFireIPCProxy.this.changeStatus(KindleFireStatus.CANNOT_AUTHORIZE);
              return;
            } 
            String str = bundle.getString("AUTH_RESULT");
            Log.d("KindleFireIPCProxy", "authResult: " + str);
            if ("AUTHORIZED".equals(str)) {
              KindleFireIPCProxy.this.onAuthorized();
              return;
            } 
            if ("INVALID_SESSION".equals(str)) {
              KindleFireIPCProxy.this.changeStatus(KindleFireStatus.NOT_AUTHORIZED);
              return;
            } 
            if ("CANNOT_AUTHORIZE".equals(str)) {
              KindleFireIPCProxy.this.changeStatus(KindleFireStatus.CANNOT_AUTHORIZE);
              return;
            } 
            if ("NOT_AUTHORIZED".equals(str)) {
              KindleFireIPCProxy.this.changeStatus(KindleFireStatus.NOT_AUTHORIZED);
              return;
            } 
          }
        });
    try {
      sendMessage(message);
      return;
    } catch (RemoteException remoteException) {
      Log.e("KindleFireIPCProxy", "Unable to send Message to Service: ", (Throwable)remoteException);
      changeStatus(KindleFireStatus.CANNOT_AUTHORIZE);
      return;
    } 
  }
  
  private void bindToAsynchronousService(Context paramContext) {
    ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
          KindleFireIPCProxy.access$002(KindleFireIPCProxy.this, new Messenger(param1IBinder));
          KindleFireIPCProxy.this.onBindChange();
        }
        
        public void onServiceDisconnected(ComponentName param1ComponentName) {
          KindleFireIPCProxy.access$002(KindleFireIPCProxy.this, null);
          KindleFireIPCProxy.this.onBindChange();
        }
      };
    Intent intent = createBindIntent();
    intent.setAction("BindAsynchronous");
    try {
      boolean bool = paramContext.bindService(intent, serviceConnection, 1);
      Log.d("KindleFireIPCProxy", "binding result:" + bool);
      return;
    } catch (SecurityException securityException) {
      Log.w("KindleFireIPCProxy", "Device has an outdated version of Amazon Game Services.  Player will be in Guest mode");
      changeStatus(KindleFireStatus.UNIVERSAL_NOT_SUPPORTED);
      return;
    } 
  }
  
  private void bindToSynchronousService(Context paramContext) {
    ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
          KindleFireIPCProxy.access$202(KindleFireIPCProxy.this, param1IBinder);
          KindleFireIPCProxy.this.onBindChange();
        }
        
        public void onServiceDisconnected(ComponentName param1ComponentName) {
          KindleFireIPCProxy.access$202(KindleFireIPCProxy.this, null);
          KindleFireIPCProxy.this.onBindChange();
        }
      };
    Intent intent = createBindIntent();
    intent.setAction("BindSynchronous");
    try {
      paramContext.bindService(intent, serviceConnection, 1);
      return;
    } catch (SecurityException securityException) {
      Log.w("KindleFireIPCProxy", "Device has an outdated version of Amazon Game Services.  Player will be in Guest mode");
      changeStatus(KindleFireStatus.UNIVERSAL_NOT_SUPPORTED);
      return;
    } 
  }
  
  private void changeStatus(KindleFireStatus paramKindleFireStatus) {
    if (paramKindleFireStatus != this.status) {
      Log.d("KindleFireIPCProxy", "Changing Status from:" + this.status + " to: " + paramKindleFireStatus);
      this.status = paramKindleFireStatus;
      notifyCaller();
    } 
  }
  
  private Intent createBindIntent() {
    Intent intent = new Intent();
    intent.setClassName("com.amazon.ags.app", "com.amazon.ags.app.service.AmazonGamesService");
    intent.putExtra("CLIENT_VERSION", "1.0.0");
    return intent;
  }
  
  private boolean initSession() {
    try {
      this.sessionId = transact(46, Parcel.obtain()).readString();
      if (TextUtils.isEmpty(this.sessionId)) {
        Log.e("KindleFireIPCProxy", "Could not obtain session");
        return false;
      } 
      return true;
    } catch (RemoteException remoteException) {
      Log.e("KindleFireIPCProxy", "Could not obtain session");
      return false;
    } 
  }
  
  private boolean isBound() {
    if (this.synchronousBinder == null || this.asynchronousMessenger == null) {
      Log.v("KindleFireIPCProxy", "synchronousBinder:" + this.synchronousBinder + " serviceMessengerClient:" + this.asynchronousMessenger);
      return false;
    } 
    Log.d("KindleFireIPCProxy", "Client is bound to service");
    return true;
  }
  
  private void notifyCaller() {
    if (this.callback != null) {
      if (this.status == KindleFireStatus.SERVICE_CONNECTED) {
        this.callback.onBound();
        return;
      } 
    } else {
      return;
    } 
    this.callback.onFailure(this.status);
  }
  
  private void onAuthorized() {
    if (isRegistered()) {
      changeStatus(KindleFireStatus.SERVICE_CONNECTED);
      return;
    } 
    changeStatus(KindleFireStatus.NOT_REGISTERED);
  }
  
  private void onBindChange() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial isBound : ()Z
    //   6: ifne -> 29
    //   9: aload_0
    //   10: getfield status : Lcom/amazon/ags/client/KindleFireStatus;
    //   13: getstatic com/amazon/ags/client/KindleFireStatus.SERVICE_CONNECTED : Lcom/amazon/ags/client/KindleFireStatus;
    //   16: if_acmpne -> 26
    //   19: aload_0
    //   20: getstatic com/amazon/ags/client/KindleFireStatus.SERVICE_DISCONNECTED : Lcom/amazon/ags/client/KindleFireStatus;
    //   23: invokespecial changeStatus : (Lcom/amazon/ags/client/KindleFireStatus;)V
    //   26: aload_0
    //   27: monitorexit
    //   28: return
    //   29: aload_0
    //   30: getfield status : Lcom/amazon/ags/client/KindleFireStatus;
    //   33: getstatic com/amazon/ags/client/KindleFireStatus.INITIALIZING : Lcom/amazon/ags/client/KindleFireStatus;
    //   36: if_acmpne -> 26
    //   39: aload_0
    //   40: invokevirtual isUniversalSupported : ()Z
    //   43: ifne -> 61
    //   46: aload_0
    //   47: getstatic com/amazon/ags/client/KindleFireStatus.UNIVERSAL_NOT_SUPPORTED : Lcom/amazon/ags/client/KindleFireStatus;
    //   50: invokespecial changeStatus : (Lcom/amazon/ags/client/KindleFireStatus;)V
    //   53: goto -> 26
    //   56: astore_1
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    //   61: aload_0
    //   62: invokespecial initSession : ()Z
    //   65: ifeq -> 75
    //   68: aload_0
    //   69: invokespecial authorize : ()V
    //   72: goto -> 26
    //   75: aload_0
    //   76: getstatic com/amazon/ags/client/KindleFireStatus.UNIVERSAL_NOT_SUPPORTED : Lcom/amazon/ags/client/KindleFireStatus;
    //   79: invokespecial changeStatus : (Lcom/amazon/ags/client/KindleFireStatus;)V
    //   82: goto -> 26
    // Exception table:
    //   from	to	target	type
    //   2	26	56	finally
    //   29	53	56	finally
    //   61	72	56	finally
    //   75	82	56	finally
  }
  
  private void sendMessage(Message paramMessage) throws RemoteException {
    if (paramMessage.getData() == null)
      paramMessage.setData(new Bundle()); 
    paramMessage.getData().putString("CLIENT_VERSION", "1.0.0");
    paramMessage.getData().putString("SESSION_ID", this.sessionId);
    if (this.asynchronousMessenger == null) {
      Log.e("KindleFireIPCProxy", "Service is not bound");
      return;
    } 
    this.asynchronousMessenger.send(paramMessage);
  }
  
  private Parcel transact(int paramInt, Parcel paramParcel) throws RemoteException {
    Parcel parcel = Parcel.obtain();
    if (this.synchronousBinder == null) {
      Log.v("KindleFireIPCProxy", "transact() was called while disconnected");
      return parcel;
    } 
    this.synchronousBinder.transact(paramInt, paramParcel, parcel, 0);
    return parcel;
  }
  
  public final void bindToGameCircleService(KindleFireBindingCallback paramKindleFireBindingCallback) {
    this.callback = paramKindleFireBindingCallback;
    this.status = KindleFireStatus.INITIALIZING;
    if (isKindle()) {
      Log.d("KindleFireIPCProxy", "Device appears to be a Kindle Fire.  Attempting to connect to Amazon Game Services");
      bindToAsynchronousService(this.context);
      bindToSynchronousService(this.context);
      return;
    } 
    Log.d("KindleFireIPCProxy", "Device does not appear to be a Kindle Fire.");
    changeStatus(KindleFireStatus.UNIVERSAL_NOT_SUPPORTED);
  }
  
  public final KindleFireStatus getStatus() {
    return this.status;
  }
  
  public boolean isKindle() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield isKindle : Ljava/lang/Boolean;
    //   8: ifnonnull -> 41
    //   11: aload_0
    //   12: invokespecial createBindIntent : ()Landroid/content/Intent;
    //   15: astore_2
    //   16: aload_0
    //   17: getfield context : Landroid/content/Context;
    //   20: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   23: aload_2
    //   24: iconst_0
    //   25: invokevirtual resolveService : (Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;
    //   28: ifnull -> 33
    //   31: iconst_1
    //   32: istore_1
    //   33: aload_0
    //   34: iload_1
    //   35: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   38: putfield isKindle : Ljava/lang/Boolean;
    //   41: aload_0
    //   42: getfield isKindle : Ljava/lang/Boolean;
    //   45: invokevirtual booleanValue : ()Z
    //   48: istore_1
    //   49: aload_0
    //   50: monitorexit
    //   51: iload_1
    //   52: ireturn
    //   53: astore_2
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_2
    //   57: athrow
    // Exception table:
    //   from	to	target	type
    //   4	16	53	finally
    //   16	31	53	finally
    //   33	41	53	finally
    //   41	49	53	finally
  }
  
  public boolean isOptedIn() {
    Parcel parcel = Parcel.obtain();
    try {
      return Boolean.parseBoolean(transact(42, parcel).readString());
    } catch (RemoteException remoteException) {
      Log.e("KindleFireIPCProxy", "Unable to determine whether Customer is opted in to GameCircle.  Defaulting to false.", (Throwable)remoteException);
      return false;
    } catch (Exception exception) {
      return false;
    } 
  }
  
  public boolean isOverlaysSupported() {
    if (this.isOverlaysSupported != null)
      return this.isOverlaysSupported.booleanValue(); 
    if (!isKindle() || !isUniversalSupported())
      return false; 
    Parcel parcel = Parcel.obtain();
    try {
      boolean bool = Boolean.parseBoolean(transact(47, parcel).readString());
      Log.d("KindleFireIPCProxy", "Checking isOverlaysSupported: " + bool);
      return bool;
    } catch (Exception exception) {
      Log.e("KindleFireIPCProxy", "Unable to determine whether overlays are supported.  Defaulting to false.", exception);
      return false;
    } 
  }
  
  public final boolean isReady() {
    return (this.status == KindleFireStatus.SERVICE_CONNECTED);
  }
  
  public boolean isRegistered() {
    if (isBound()) {
      Log.d("KindleFireIPCProxy", "Attempting to check is authenticated");
      try {
        Parcel parcel = Parcel.obtain();
        parcel.writeBundle(new Bundle());
        int i = transact(3, parcel).readInt();
        if (i == 5)
          return true; 
      } catch (Exception exception) {
        Log.e("KindleFireIPCProxy", "Unable to determine whether device is registered. Defaulting to false.", exception);
        return false;
      } 
    } 
    return false;
  }
  
  public boolean isUniversalSupported() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield isUniversalSupported : Ljava/lang/Boolean;
    //   6: ifnull -> 21
    //   9: aload_0
    //   10: getfield isUniversalSupported : Ljava/lang/Boolean;
    //   13: invokevirtual booleanValue : ()Z
    //   16: istore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: iload_1
    //   20: ireturn
    //   21: invokestatic obtain : ()Landroid/os/Parcel;
    //   24: astore_2
    //   25: aload_0
    //   26: aload_0
    //   27: bipush #40
    //   29: aload_2
    //   30: invokespecial transact : (ILandroid/os/Parcel;)Landroid/os/Parcel;
    //   33: invokevirtual readString : ()Ljava/lang/String;
    //   36: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   39: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   42: putfield isUniversalSupported : Ljava/lang/Boolean;
    //   45: aload_0
    //   46: getfield isUniversalSupported : Ljava/lang/Boolean;
    //   49: invokevirtual booleanValue : ()Z
    //   52: ifeq -> 75
    //   55: ldc 'KindleFireIPCProxy'
    //   57: ldc_w 'Device has compatible version of Amazon Game Services.'
    //   60: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   63: pop
    //   64: aload_0
    //   65: getfield isUniversalSupported : Ljava/lang/Boolean;
    //   68: invokevirtual booleanValue : ()Z
    //   71: istore_1
    //   72: goto -> 17
    //   75: ldc 'KindleFireIPCProxy'
    //   77: ldc 'Device has an outdated version of Amazon Game Services.  Player will be in Guest mode'
    //   79: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   82: pop
    //   83: goto -> 64
    //   86: astore_2
    //   87: ldc 'KindleFireIPCProxy'
    //   89: ldc_w 'Device has non-compatible version of Amazon Game Services.  Player will be in Guest mode'
    //   92: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   95: pop
    //   96: aload_0
    //   97: iconst_0
    //   98: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   101: putfield isUniversalSupported : Ljava/lang/Boolean;
    //   104: goto -> 64
    //   107: astore_2
    //   108: aload_0
    //   109: monitorexit
    //   110: aload_2
    //   111: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	107	finally
    //   21	25	107	finally
    //   25	64	86	java/lang/Exception
    //   25	64	107	finally
    //   64	72	107	finally
    //   75	83	86	java/lang/Exception
    //   75	83	107	finally
    //   87	104	107	finally
  }
  
  public boolean isWhispersyncEnabled() {
    Parcel parcel = Parcel.obtain();
    try {
      boolean bool = Boolean.parseBoolean(transact(43, parcel).readString());
      Log.d("KindleFireIPCProxy", "Checking isWhispersyncEnabled: " + bool);
      return bool;
    } catch (Exception exception) {
      Log.e("KindleFireIPCProxy", "Unable to determine whether Whispersync is enabled.  Defaulting to false.", exception);
      return false;
    } 
  }
  
  public void setOptIn(boolean paramBoolean) {
    Parcel parcel = Parcel.obtain();
    Bundle bundle = new Bundle();
    bundle.putBoolean("optIn", paramBoolean);
    parcel.writeBundle(bundle);
    try {
      transact(41, parcel);
      return;
    } catch (Exception exception) {
      Log.e("KindleFireIPCProxy", "Unable to update OptIn status.", exception);
      return;
    } 
  }
  
  public void showOverlay(String paramString) {
    if (!isOverlaysSupported())
      throw new UnsupportedOperationException("Proxying overlay requests is not supported on this device and software version."); 
    paramString = JSONUtils.sanitize(paramString);
    try {
      int i = (new JSONObject(paramString)).getInt("OVERLAY_ACTION_CODE");
      Message message = Message.obtain();
      message.what = 48;
      message.setData(new Bundle());
      message.getData().putInt("OVERLAY_ACTION_CODE", i);
      sendMessage(message);
      return;
    } catch (JSONException jSONException) {
      Log.e("KindleFireIPCProxy", "Error occurred while retrieve the overlay action code from the overlay data", (Throwable)jSONException);
      return;
    } catch (RemoteException remoteException) {
      Log.e("KindleFireIPCProxy", "There was an error sending the show overlay message to the APK", (Throwable)remoteException);
      return;
    } 
  }
  
  public Map<String, String> signMessage(String paramString1, String paramString2, String paramString3) {
    Parcel parcel = Parcel.obtain();
    Bundle bundle = new Bundle();
    bundle.putString("verb", paramString1);
    bundle.putString("uri", paramString2);
    bundle.putString("body", paramString3);
    bundle.putString("SESSION_ID", this.sessionId);
    parcel.writeBundle(bundle);
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    try {
      Bundle bundle1 = transact(45, parcel).readBundle();
      if (bundle1 == null)
        return null; 
      paramString2 = bundle1.getString("signature");
      paramString3 = bundle1.getString("nonce");
      String str = bundle1.getString("token");
      if (paramString2 == null || paramString3 == null || str == null)
        return null; 
      hashMap.put("signature", paramString2);
      hashMap.put("nonce", paramString3);
      hashMap.put("token", str);
      return (Map)hashMap;
    } catch (Exception exception) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\KindleFireIPCProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */