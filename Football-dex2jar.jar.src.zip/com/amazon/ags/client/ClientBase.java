package com.amazon.ags.client;

import android.util.Log;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.html5.service.ServiceHelper;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class ClientBase {
  protected final String TAG = "GC_" + getClass().getSimpleName();
  
  protected boolean isReady = false;
  
  protected ServiceHelper serviceHelper;
  
  public ClientBase() {}
  
  public ClientBase(ServiceHelper paramServiceHelper) {
    this.serviceHelper = paramServiceHelper;
    this.isReady = true;
  }
  
  protected int getInt(JSONObject paramJSONObject, String paramString, int paramInt) {
    int i = paramInt;
    try {
      if (!paramJSONObject.isNull(paramString))
        i = paramJSONObject.getInt(paramString); 
      return i;
    } catch (JSONException jSONException) {
      Log.w(this.TAG, "JSON error, returning default value " + paramInt, (Throwable)jSONException);
      return paramInt;
    } 
  }
  
  protected long getLong(JSONObject paramJSONObject, String paramString, long paramLong) {
    long l = paramLong;
    try {
      if (!paramJSONObject.isNull(paramString))
        l = paramJSONObject.getLong(paramString); 
      return l;
    } catch (JSONException jSONException) {
      Log.w(this.TAG, "JSON error, returning default value " + paramLong, (Throwable)jSONException);
      return paramLong;
    } 
  }
  
  protected boolean isClientReady() {
    return this.isReady;
  }
  
  public void setServiceHelper(ServiceHelper paramServiceHelper) {
    this.serviceHelper = paramServiceHelper;
    this.isReady = true;
  }
  
  protected abstract class AsyncTaskWrapper<T extends RequestResponse> implements JSONRequest {
    private JSONObject request = null;
    
    private final String requestDescription;
    
    private AGResponseHandleImpl<T> responseHandle;
    
    public AsyncTaskWrapper(String param1String) {
      this.requestDescription = param1String;
    }
    
    protected abstract JSONObject buildRequest() throws JSONException;
    
    public JSONObject buildRequestForServiceAction(int param1Int) throws JSONException {
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("ACTION_CODE", param1Int);
      return jSONObject;
    }
    
    public JSONObject buildRequestForServiceAction(String param1String) throws JSONException {
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("ACTION_CODE", param1String);
      return jSONObject;
    }
    
    protected abstract T convertResponse(JSONObject param1JSONObject) throws JSONException;
    
    public AGResponseHandle<T> execute(Object[] param1ArrayOfObject) {
      this.responseHandle = new AGResponseHandleImpl<T>(param1ArrayOfObject);
      try {
        this.request = buildRequest();
        if (!this.request.has("REQUEST_ID"))
          this.request.put("REQUEST_ID", UUID.randomUUID().toString()); 
        ClientBase.this.serviceHelper.handleRequestAsync(this);
      } catch (JSONException jSONException) {
        this.responseHandle.setResponse(getFailureResponse(24, null));
      } 
      return this.responseHandle;
    }
    
    protected abstract T getFailureResponse(int param1Int, JSONObject param1JSONObject);
    
    public JSONObject getRequest() {
      return this.request;
    }
    
    public void setResponse(JSONObject param1JSONObject) {
      try {
        int i = param1JSONObject.getInt("RESPONSE_CODE");
        if (i == 17) {
          this.responseHandle.setResponse(convertResponse(param1JSONObject));
          return;
        } 
        this.responseHandle.setResponse(getFailureResponse(i, param1JSONObject));
        return;
      } catch (JSONException jSONException) {
        Log.e(ClientBase.this.TAG, "Unable to read response for " + this.requestDescription, (Throwable)jSONException);
        this.responseHandle.setResponse(getFailureResponse(24, null));
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\ClientBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */