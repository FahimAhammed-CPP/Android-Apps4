package com.amazon.ags.client;

import java.util.Map;

public interface KindleFireProxy {
  void bindToGameCircleService(KindleFireBindingCallback paramKindleFireBindingCallback);
  
  KindleFireStatus getStatus();
  
  boolean isKindle();
  
  boolean isOptedIn();
  
  boolean isOverlaysSupported();
  
  boolean isReady();
  
  boolean isRegistered();
  
  boolean isUniversalSupported();
  
  boolean isWhispersyncEnabled();
  
  void setOptIn(boolean paramBoolean);
  
  void showOverlay(String paramString);
  
  Map<String, String> signMessage(String paramString1, String paramString2, String paramString3);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\KindleFireProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */