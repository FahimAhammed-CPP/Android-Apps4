package com.amazon.ags.client.player;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.player.Player;
import com.amazon.ags.api.player.RequestPlayerResponse;
import com.amazon.ags.client.RequestResponseImpl;

public class RequestPlayerResponseImpl extends RequestResponseImpl implements RequestPlayerResponse {
  private final Player player = null;
  
  public RequestPlayerResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public RequestPlayerResponseImpl(Player paramPlayer, int paramInt) {
    super(paramInt);
  }
  
  public int getEventType() {
    return 18;
  }
  
  public Player getPlayer() {
    return this.player;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\player\RequestPlayerResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */