package com.amazon.ags.client.player;

import com.amazon.ags.api.player.Player;

public class PlayerImpl implements Player {
  private final String avatarUrl;
  
  private final String playerAlias;
  
  private final String playerId;
  
  public PlayerImpl(String paramString1, String paramString2, String paramString3) {
    this.playerId = paramString1;
    this.playerAlias = paramString2;
    this.avatarUrl = paramString3;
  }
  
  public final String getAlias() {
    return this.playerAlias;
  }
  
  public final String getAvatarUrl() {
    return this.avatarUrl;
  }
  
  public String getPlayerId() {
    return this.playerId;
  }
  
  public final String toString() {
    return " ID: " + this.playerId + " Alias: " + this.playerAlias + " AvatarUrl: " + this.avatarUrl;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\player\PlayerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */