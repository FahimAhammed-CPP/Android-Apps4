package com.amazon.ags.client.player;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.player.Player;
import com.amazon.ags.api.player.RequestFriendsResponse;
import com.amazon.ags.client.RequestResponseImpl;
import java.util.List;

public class RequestFriendsResponseImpl extends RequestResponseImpl implements RequestFriendsResponse {
  List<Player> friendsProfiles = null;
  
  public RequestFriendsResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public RequestFriendsResponseImpl(List<Player> paramList, int paramInt) {
    super(paramInt);
  }
  
  public int getEventType() {
    return 19;
  }
  
  public List<Player> getFriends() {
    return this.friendsProfiles;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\player\RequestFriendsResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */