package com.amazon.ags.client.player;

import android.util.Log;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.player.AGSignedInListener;
import com.amazon.ags.api.player.PlayerClient;
import com.amazon.ags.api.player.RequestFriendIdsResponse;
import com.amazon.ags.api.player.RequestFriendsResponse;
import com.amazon.ags.api.player.RequestPlayerResponse;
import com.amazon.ags.client.AGResponseHandleImpl;
import com.amazon.ags.client.ClientBase;
import com.amazon.ags.html5.service.ServiceHelper;
import com.amazon.ags.html5.util.GlobalState;
import com.amazon.ags.jni.AGSJniHandler;
import com.amazon.ags.jni.player.ProfilesJni;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PlayerClientImpl extends ClientBase implements PlayerClient {
  private static final String TAG = "GC_" + PlayerClientImpl.class.getSimpleName();
  
  private static AGSignedInListener signedInListener;
  
  private final GlobalState globalState;
  
  public PlayerClientImpl(ServiceHelper paramServiceHelper, GlobalState paramGlobalState) {
    super(paramServiceHelper);
    this.globalState = paramGlobalState;
  }
  
  public PlayerClientImpl(GlobalState paramGlobalState) {
    this.globalState = paramGlobalState;
  }
  
  public static void notifySignedInListener(boolean paramBoolean) {
    if (signedInListener != null)
      signedInListener.onSignedInStateChange(paramBoolean); 
    try {
      if (AGSJniHandler.isLibraryLoaded())
        ProfilesJni.callSignedInStateChangedListener(paramBoolean); 
      return;
    } catch (Throwable throwable) {
      Log.e(TAG, "Error in calling signed in listener: " + throwable.toString());
      return;
    } 
  }
  
  public AGResponseHandle<RequestFriendsResponse> getBatchFriends(final List<String> playerIds, Object... paramVarArgs) {
    AGResponseHandleImpl aGResponseHandleImpl;
    if (!isClientReady() || playerIds == null || playerIds.isEmpty()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new RequestFriendsResponseImpl(29, ErrorCode.UNRECOVERABLE));
      if (playerIds == null) {
        Log.w(TAG, "getBatchFriends called with null playerIds; returning empty response");
        return (AGResponseHandle<RequestFriendsResponse>)aGResponseHandleImpl;
      } 
      if (playerIds.isEmpty()) {
        Log.w(TAG, "getBatchFriends called with empty playerIds; returning empty response");
        return (AGResponseHandle<RequestFriendsResponse>)aGResponseHandleImpl;
      } 
      Log.w(TAG, "getBatchFriends called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<RequestFriendsResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<RequestFriendsResponse>("Get Local Player Friends") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          JSONArray jSONArray = new JSONArray(playerIds);
          jSONObject.put("ACTION_CODE", 20);
          jSONObject.put("friendsPlayerIds", jSONArray);
          return jSONObject;
        }
        
        public RequestFriendsResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int i = param1JSONObject.getInt("RESPONSE_CODE");
          ArrayList<PlayerImpl> arrayList = new ArrayList();
          JSONArray jSONArray = param1JSONObject.optJSONArray("friendsProfiles");
          if (jSONArray != null)
            for (int j = 0; j < jSONArray.length(); j++) {
              JSONObject jSONObject = jSONArray.getJSONObject(j);
              arrayList.add(new PlayerImpl(jSONObject.optString("playerId", null), jSONObject.optString("ALIAS", null), jSONObject.optString("avatarUrl", null)));
            }  
          return new RequestFriendsResponseImpl((List)arrayList, i);
        }
        
        public RequestFriendsResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          Log.e(PlayerClientImpl.TAG, "Request friends failure response: " + param1JSONObject);
          return new RequestFriendsResponseImpl(null, param1Int);
        }
      }).execute((Object[])aGResponseHandleImpl);
  }
  
  public AGResponseHandle<RequestFriendIdsResponse> getFriendIds(Object... paramVarArgs) {
    AGResponseHandleImpl aGResponseHandleImpl;
    if (!isClientReady()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new RequestFriendIdsResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(TAG, "getFriendIds called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<RequestFriendIdsResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<RequestFriendIdsResponse>("Get Local Player Friends") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 19);
          return jSONObject;
        }
        
        public RequestFriendIdsResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int i = param1JSONObject.getInt("RESPONSE_CODE");
          JSONArray jSONArray = param1JSONObject.optJSONArray("friends");
          ArrayList<String> arrayList = new ArrayList();
          if (jSONArray != null)
            for (int j = 0; j < jSONArray.length(); j++)
              arrayList.add(jSONArray.getString(j));  
          return new RequestFriendIdsResponseImpl(arrayList, i);
        }
        
        public RequestFriendIdsResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          Log.e(PlayerClientImpl.TAG, "Request friends failure response: " + param1JSONObject);
          return new RequestFriendIdsResponseImpl(null, param1Int);
        }
      }).execute((Object[])aGResponseHandleImpl);
  }
  
  public AGResponseHandle<RequestPlayerResponse> getLocalPlayer(Object... paramVarArgs) {
    AGResponseHandleImpl aGResponseHandleImpl;
    if (!isClientReady()) {
      aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
      aGResponseHandleImpl.setResponse((RequestResponse)new RequestPlayerResponseImpl(29, ErrorCode.UNRECOVERABLE));
      Log.w(TAG, "getLocalPlayer called before AmazonGamesClient initialized; returning empty response");
      return (AGResponseHandle<RequestPlayerResponse>)aGResponseHandleImpl;
    } 
    return (new ClientBase.AsyncTaskWrapper<RequestPlayerResponse>("Get Local Player") {
        public JSONObject buildRequest() throws JSONException {
          JSONObject jSONObject = new JSONObject();
          jSONObject.put("ACTION_CODE", 18);
          return jSONObject;
        }
        
        public RequestPlayerResponse convertResponse(JSONObject param1JSONObject) throws JSONException {
          int i = param1JSONObject.getInt("RESPONSE_CODE");
          String str = param1JSONObject.optString("ALIAS", null);
          return new RequestPlayerResponseImpl(new PlayerImpl(param1JSONObject.optString("playerId", null), str, param1JSONObject.optString("avatarUrl", null)), i);
        }
        
        public RequestPlayerResponse getFailureResponse(int param1Int, JSONObject param1JSONObject) {
          Log.e(PlayerClientImpl.TAG, "Request player failure response: " + param1JSONObject);
          return new RequestPlayerResponseImpl(null, param1Int);
        }
      }).execute((Object[])aGResponseHandleImpl);
  }
  
  public boolean isSignedIn() {
    return !this.globalState.isGuestMode();
  }
  
  public void setSignedInListener(AGSignedInListener paramAGSignedInListener) {
    signedInListener = paramAGSignedInListener;
  }
  
  public void shutdown() {
    this.isReady = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\player\PlayerClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */