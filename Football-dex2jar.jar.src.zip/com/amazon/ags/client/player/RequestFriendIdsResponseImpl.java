package com.amazon.ags.client.player;

import com.amazon.ags.api.ErrorCode;
import com.amazon.ags.api.player.RequestFriendIdsResponse;
import com.amazon.ags.client.RequestResponseImpl;
import java.util.List;

public class RequestFriendIdsResponseImpl extends RequestResponseImpl implements RequestFriendIdsResponse {
  private final List<String> friends = null;
  
  public RequestFriendIdsResponseImpl(int paramInt, ErrorCode paramErrorCode) {
    super(paramInt, paramErrorCode);
  }
  
  public RequestFriendIdsResponseImpl(List<String> paramList, int paramInt) {
    super(paramInt);
  }
  
  public int getEventType() {
    return 19;
  }
  
  public List<String> getFriends() {
    return this.friends;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\client\player\RequestFriendIdsResponseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */