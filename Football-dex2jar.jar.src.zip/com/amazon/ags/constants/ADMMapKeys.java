package com.amazon.ags.constants;

public final class ADMMapKeys {
  public static final String FOLLOWER_ALIAS_KEY = "com.amazon.gamecircle.FollowerAlias";
  
  public static final String FOLLOWER_PLAYER_ID_KEY = "com.amazon.gamecircle.FollowerPlayerId";
  
  public static final String GAME_ID_KEY = "com.amazon.gamecircle.sync.GameId";
  
  public static final String HANDLER_TYPE_KEY = "com.amazon.gamecircle.adm.Handler";
  
  public static final String NOTIFY_HANDLER_VALUE = "com.amazon.gamecircle.adm.NotifyMessageHandler";
  
  public static final String NOTIFY_TYPE_FOLLOW = "FOLLOW";
  
  public static final String NOTIFY_TYPE_KEY = "com.amazon.gamecircle.NotifyType";
  
  public static final String PACKAGE_NAME_KEY = "com.amazon.gamecircle.sync.PackageName";
  
  public static final String SYNC_HANDLER_VALUE = "com.amazon.gamecircle.adm.SyncMessageHandler";
  
  public static final String SYNC_TYPE_FRIENDS_VALUE = "FRIENDS";
  
  public static final String SYNC_TYPE_GAME_SUMMARY_VALUE = "GAME_SUMMARY";
  
  public static final String SYNC_TYPE_KEY = "com.amazon.gamecircle.sync.SyncType";
  
  public static final String SYNC_TYPE_LIBRARY_SINGLE_GAME_VALUE = "LIBRARY_SINGLE_GAME";
  
  public static final String SYNC_TYPE_LIBRARY_VALUE = "LIBRARY";
  
  public static final String SYNC_TYPE_PROCESS_GAMECIRCLE_EVENTS_VALUE = "PROCESS_GAMECIRCLE_EVENTS";
  
  public static final String SYNC_TYPE_PROFILE_VALUE = "PROFILE";
  
  public static final String SYNC_TYPE_SDK_SINGLE_GAME_VALUE = "SDK_SINGLE_GAME";
  
  private ADMMapKeys() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\ADMMapKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */