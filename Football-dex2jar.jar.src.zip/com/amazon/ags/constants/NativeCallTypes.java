package com.amazon.ags.constants;

public class NativeCallTypes {
  public static final String BACKGROUND_TASK = "backgroundTask";
  
  public static final String BATCH_GET_GLOBAL_STATE = "batchGetGlobalState";
  
  public static final String BATCH_PUT_GLOBAL_STATE = "batchPutGlobalState";
  
  public static final String CAN_LAUNCH_KINDLE_SETTINGS = "canDisplayKindleSettings";
  
  public static final String CLEAR_CACHE = "clearCache";
  
  public static final String DOWNLOAD_IMAGES = "downloadImages";
  
  public static final String DO_LOGIN = "doLogin";
  
  public static final String DO_LOGOUT = "doLogout";
  
  public static final String GET_CACHE_ITEM = "getCacheItem";
  
  public static final String GET_LOCALE_INFO = "getLocaleInfo";
  
  public static final String GET_LOGGED_IN_STATUS = "getLoggedInStatus";
  
  public static final String GET_NETWORK_INFO = "getNetworkInfo";
  
  public static final String GET_PACKAGE_NAME = "getPackageName";
  
  public static final String GET_SETTING = "getSetting";
  
  public static final String GET_VARIATION_VARIABLE = "getVariationVariable";
  
  public static final String HAS_OPTED_IN = "hasOptedIn";
  
  public static final String IS_GC_SERVICE_READY = "isGCServiceReady";
  
  public static final String IS_KINDLE = "isKindle";
  
  public static final String IS_KINDLE_REGISTERED = "isKindleRegistered";
  
  public static final String IS_WHISERPSYNC_ENABLED = "isWhispersyncEnabled";
  
  public static final String LAUNCH_KINDLE_SETTINGS = "launchKindleSettings";
  
  public static final String MAKE_SERVICE_CALL = "makeServiceCall";
  
  public static final String NOTIFY_NATIVE = "notifyNative";
  
  public static final String NOTIFY_SIGN_IN_STATE_CHANGE = "NOTIFY_SIGN_IN_STATE_CHANGE";
  
  public static final String OPEN_BROWSER = "openBrowser";
  
  public static final String OPEN_EMAIL_EDITOR = "openEmailEditor";
  
  public static final String PUT_SETTING = "putSetting";
  
  public static final String QUERY_CACHE_ITEMS = "queryCacheItems";
  
  public static final String QUEUE_OFFLINE_EVENT = "queueOfflineEvent";
  
  public static final String REMOVE_CACHE_ITEMS = "removeCachedItems";
  
  public static final String REPORT_EVENT = "reportEvent";
  
  public static final String SET_CACHE_ITEM = "setCacheItem";
  
  public static final String SET_CACHE_ITEMS = "setCacheItems";
  
  public static final String SET_OPT_IN = "setOptIn";
  
  public static final String SHOW_TOAST = "showToast";
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\NativeCallTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */