package com.amazon.ags.constants;

public final class OverlaySize {
  public static int ALERT_HEIGHT_PIXELS = 0;
  
  public static int ALERT_WIDTH_PIXELS = 273;
  
  public static final int TOAST_HEIGHT_PIXELS = 73;
  
  public static final int TOAST_WIDTH_PIXELS = 320;
  
  static {
    ALERT_HEIGHT_PIXELS = 180;
  }
  
  private OverlaySize() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\OverlaySize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */