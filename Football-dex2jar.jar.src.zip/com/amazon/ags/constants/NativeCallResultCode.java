package com.amazon.ags.constants;

public class NativeCallResultCode {
  public static final String AUTHORIZATION_ERROR = "AUTHORIZATION_ERROR";
  
  public static final String ERROR = "ERROR";
  
  public static final String NETWORK_ERROR = "NETWORK_ERROR";
  
  public static final String REQUEST_ERROR = "REQUEST_ERROR";
  
  public static final String SUCCESS = "SUCCESS";
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\NativeCallResultCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */