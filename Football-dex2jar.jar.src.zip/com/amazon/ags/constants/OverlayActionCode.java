package com.amazon.ags.constants;

public class OverlayActionCode {
  public static final int SHOW_ACHIEVEMENTS = 1;
  
  public static final String SHOW_ACHIEVEMENT_SIGN_IN_PROMPT = "SHOW_ACHIEVEMENT_SIGN_IN_PROMPT";
  
  public static final String SHOW_AGE_VERIFICATION = "SHOW_AGE_VERIFICATION";
  
  public static final String SHOW_AGE_VIOLATION = "SHOW_AGE_VIOLATION";
  
  public static final String SHOW_COR_SELECTION = "SHOW_COR_SELECTION";
  
  public static final String SHOW_COR_UNSUPPORTED = "SHOW_COR_UNSUPPORTED";
  
  public static final int SHOW_LEADERBOARDS = 2;
  
  public static final int SHOW_LEADERBOARD_RANKS = 6;
  
  public static final String SHOW_LEADERBOARD_SIGN_IN_PROMPT = "SHOW_LEADERBOARD_SIGN_IN_PROMPT";
  
  public static final String SHOW_LOGIN = "SHOW_LOGIN";
  
  public static final int SHOW_PROFILE = 5;
  
  public static final int SHOW_SETTINGS = 3;
  
  public static final int SHOW_SUMMARY = 4;
  
  public static final String SHOW_TERMS_OF_SERVICE = "SHOW_TOS";
  
  public static final int SHOW_TOP_ALL_TIME_LEADERBOARD = 0;
  
  private OverlayActionCode() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\OverlayActionCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */