package com.amazon.ags.constants;

public final class ProfilesBindingKeys {
  public static final String ALIAS_KEY = "ALIAS";
  
  public static final String AVATAR_URL_KEY = "avatarUrl";
  
  public static final String FRIENDS_KEY = "friends";
  
  public static final String FRIENDS_PLAYER_IDS_KEY = "friendsPlayerIds";
  
  public static final String FRIENDS_PROFILES_KEY = "friendsProfiles";
  
  public static final String IS_SIGNED_IN_KEY = "isSignedIn";
  
  public static final String PLAYER_ID_KEY = "playerId";
  
  private ProfilesBindingKeys() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\ProfilesBindingKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */