package com.amazon.ags.constants;

public class ClientVersionConstants {
  public static final String CLIENT_VERSION_KEY = "CLIENT_VERSION";
  
  public static final String CLIENT_VERSION_VALUE = "1.0.0";
  
  private ClientVersionConstants() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\ClientVersionConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */