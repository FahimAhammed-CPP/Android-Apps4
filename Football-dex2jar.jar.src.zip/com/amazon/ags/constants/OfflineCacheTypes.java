package com.amazon.ags.constants;

public class OfflineCacheTypes {
  public static final String ACHIEVEMENTS_CACHE = "AchievementsCache";
  
  public static final String ACHIEVEMENTS_EXIST_CACHE = "AchievementsExistCache";
  
  public static final String LEADERBOARDS_CACHE = "LeaderboardsCache";
  
  public static final String LEADERBOARDS_EXIST_CACHE = "LeaderboardsExistCache";
  
  public static final String PLAYER_PROFILE_CACHE = "PlayerProfileCache";
  
  public static final String SETTINGS_CACHE = "SettingsCache";
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\OfflineCacheTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */