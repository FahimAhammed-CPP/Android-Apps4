package com.amazon.ags.constants;

public final class ServiceActionCode {
  public static final String ACTION_CODE_KEY = "ACTION_CODE";
  
  public static final int AUTHENTICATE = 4;
  
  public static final int AUTHORIZE_SESSION = 25;
  
  public static final int DOWNLOAD = 2;
  
  public static final int GENERIC_RESPONSE = 0;
  
  public static final int GET_GAME_PROGRESS = 33;
  
  public static final String HANDLE_TOAST_CLICK = "HANDLE_TOAST_CLICK";
  
  public static final String HANDLE_TOAST_DISPLAY_METRIC = "HANDLE_TOAST_DISPLAY_METRIC";
  
  public static final int INITIALIZE = 23;
  
  public static final String IS_WHISPERSYNC_ENABLED = "IS_WHISPERSYNC_ENABLED";
  
  public static final int LOAD_ACHIEVEMENT_ICON = 16;
  
  public static final int PROCESS_OFFLINE_EVENT = 34;
  
  public static final int QUERY_AUTHENTICATION = 3;
  
  public static final int REQUEST_ACHIEVEMENT = 12;
  
  public static final int REQUEST_ACHIEVEMENTS = 17;
  
  public static final int REQUEST_LEADERBOARDS = 9;
  
  public static final int REQUEST_LOCAL_PLAYER_FRIENDS = 19;
  
  public static final int REQUEST_LOCAL_PLAYER_FRIENDS_PROFILES = 20;
  
  public static final int REQUEST_LOCAL_PLAYER_PROFILE = 18;
  
  public static final int REQUEST_PERCENTILES = 31;
  
  public static final int REQUEST_PLAYER_SCORE = 10;
  
  public static final int REQUEST_SCORES = 7;
  
  public static final int REQUEST_SESSION = 24;
  
  public static final int RESET_ACHIEVEMENT = 15;
  
  public static final int RESET_ACHIEVEMENTS = 14;
  
  public static final int RETRIEVE_GAME_HISTORY = 11;
  
  public static final int RETRIEVE_LATEST_SAVED_GAME_SUMMARY = 6;
  
  public static final int REVERT = 22;
  
  public static final String SET_OPT_IN = "SET_OPT_IN";
  
  public static final String SHOW_GAME_CIRCLE = "SHOW_GAME_CIRCLE";
  
  public static final int SHOW_OVERLAY_ACHIEVEMENTS = 26;
  
  public static final int SHOW_OVERLAY_LEADERBOARDS = 27;
  
  public static final int SHOW_OVERLAY_PROFILE = 35;
  
  public static final int SHOW_OVERLAY_RANKS = 28;
  
  public static final int SHOW_OVERLAY_SUMMARY = 36;
  
  public static final int SHOW_SETTINGS = 29;
  
  public static final String SHOW_SIGN_IN_PAGE = "SHOW_SIGN_IN_PAGE";
  
  public static final int SHOW_SOFTKEY_PRESS_OVERLAY = 30;
  
  public static final String SHOW_TOS_PAGE = "SHOW_TOS_PAGE";
  
  public static final int SHOW_UNIVERSAL_OVERLAY = 48;
  
  public static final String START_SESSION = "START_SESSION";
  
  public static final String STOP_SESSION = "STOP_SESSION";
  
  public static final int SUBMIT_SCORE = 8;
  
  public static final int SYNCHRONIZE = 21;
  
  public static final int UNIVERSAL_AUTHORIZE_SESSION = 44;
  
  public static final int UNIVERSAL_CHECK_OPTED_IN = 42;
  
  public static final int UNIVERSAL_CHECK_SUPPORTED = 40;
  
  public static final int UNIVERSAL_CHECK_WHISPERSYNC_ENABLED = 43;
  
  public static final int UNIVERSAL_OVERLAYS_SUPPORTED = 47;
  
  public static final int UNIVERSAL_REQUEST_SESSION = 46;
  
  public static final int UNIVERSAL_SET_OPTED_IN = 41;
  
  public static final int UNIVERSAL_SIGN_MESSAGE = 45;
  
  public static final int UPDATE_ACHIEVEMENT_PROGRESS = 13;
  
  public static final String UPDATE_COUNTRY_OF_RESIDENCE = "UPDATE_COR";
  
  public static final int UPDATE_GAME_PROGRESS = 32;
  
  public static final int UPLOAD = 1;
  
  private ServiceActionCode() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\ServiceActionCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */