package com.amazon.ags.constants;

public class ClientConfigKeys {
  public static final String AUTH_GET_TOKEN_TIMEOUT_MILLIS = "AUTH_GET_TOKEN_TIMEOUT_MILLIS";
  
  public static final String HTTP_CONNECTION_POOL_TIMEOUT_MILLIS = "HTTP_CONNECTION_POOL_TIMEOUT_MILLIS";
  
  public static final String HTTP_CONNECTION_TIMEOUT_MILLIS = "HTTP_CONNECTION_TIMEOUT_MILLIS";
  
  public static final String HTTP_MAX_CONNECTIONS_PER_ROUTE = "HTTP_MAX_CONNECTIONS_PER_ROUTE";
  
  public static final String HTTP_MAX_TOTAL_CONNECTIONS = "HTTP_MAX_TOTAL_CONNECTIONS";
  
  public static final String HTTP_SOCKET_TIMEOUT_MILLIS = "HTTP_SOCKET_TIMEOUT_MILLIS";
  
  public static final String SETTINGS_CACHE_KEY = "clientConfig";
  
  public static final String THREAD_POOL_SIZE = "THREAD_POOL_SIZE";
  
  public static final String THREAD_TIMEOUT = "THREAD_TIMEOUT";
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\ClientConfigKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */