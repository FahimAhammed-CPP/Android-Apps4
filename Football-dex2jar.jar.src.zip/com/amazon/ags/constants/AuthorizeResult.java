package com.amazon.ags.constants;

public enum AuthorizeResult {
  AUTHORIZED, CANNOT_AUTHORIZE, NOT_AUTHORIZED;
  
  static {
    CANNOT_AUTHORIZE = new AuthorizeResult("CANNOT_AUTHORIZE", 2);
    $VALUES = new AuthorizeResult[] { AUTHORIZED, NOT_AUTHORIZED, CANNOT_AUTHORIZE };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\AuthorizeResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */