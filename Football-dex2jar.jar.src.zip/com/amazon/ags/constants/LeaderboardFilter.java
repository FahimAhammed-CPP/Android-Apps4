package com.amazon.ags.constants;

public enum LeaderboardFilter {
  FRIENDS_ALL_TIME, GLOBAL_ALL_TIME, GLOBAL_DAY, GLOBAL_WEEK;
  
  private static final String FEATURE_NAME = "LB";
  
  private static final String TAG;
  
  static {
    GLOBAL_DAY = new LeaderboardFilter("GLOBAL_DAY", 2);
    FRIENDS_ALL_TIME = new LeaderboardFilter("FRIENDS_ALL_TIME", 3);
    $VALUES = new LeaderboardFilter[] { GLOBAL_ALL_TIME, GLOBAL_WEEK, GLOBAL_DAY, FRIENDS_ALL_TIME };
    TAG = "LB_" + LeaderboardFilter.class.getSimpleName();
  }
  
  public static LeaderboardFilter fromOrdinal(int paramInt) {
    LeaderboardFilter[] arrayOfLeaderboardFilter = values();
    return (paramInt >= arrayOfLeaderboardFilter.length || paramInt < 0) ? null : arrayOfLeaderboardFilter[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\LeaderboardFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */