package com.amazon.ags.constants;

public enum ScoreFormat {
  DURATION, NUMERIC, UNKNOWN;
  
  static {
    DURATION = new ScoreFormat("DURATION", 1);
    UNKNOWN = new ScoreFormat("UNKNOWN", 2);
    $VALUES = new ScoreFormat[] { NUMERIC, DURATION, UNKNOWN };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\ScoreFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */