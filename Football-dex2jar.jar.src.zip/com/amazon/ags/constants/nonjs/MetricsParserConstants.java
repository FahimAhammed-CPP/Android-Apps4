package com.amazon.ags.constants.nonjs;

public class MetricsParserConstants {
  public static final String COUNT_METRIC_KEY_PREFIX = "Count";
  
  public static final String METRIC_KEY_PREFIX_DELIMITER = "::";
  
  public static final String TIME_METRIC_KEY_PREFIX = "Time";
  
  public static String convertCountKey(String paramString) {
    return "Count::" + paramString;
  }
  
  public static String convertTimeKey(String paramString) {
    return "Time::" + paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\nonjs\MetricsParserConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */