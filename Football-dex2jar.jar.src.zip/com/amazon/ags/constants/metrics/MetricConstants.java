package com.amazon.ags.constants.metrics;

public class MetricConstants {
  public enum MetricDecoratedValueAttributeKeys {
    COUNTRY_SUPPORT, DEVICE_ID, DEVICE_MANUFACTURER, DEVICE_MODEL, GAME_ID, HIDDEN, INTERNET_CONNECTION, JAVASCRIPT_VERSION, NATIVE_VERSION, PLATFORM, PLAYER_ID, PLAYING_ANONYMOUSLY, SEQUENCE_ID, SESSION_ID;
    
    static {
      HIDDEN = new MetricDecoratedValueAttributeKeys("HIDDEN", 4);
      PLAYING_ANONYMOUSLY = new MetricDecoratedValueAttributeKeys("PLAYING_ANONYMOUSLY", 5);
      NATIVE_VERSION = new MetricDecoratedValueAttributeKeys("NATIVE_VERSION", 6);
      JAVASCRIPT_VERSION = new MetricDecoratedValueAttributeKeys("JAVASCRIPT_VERSION", 7);
      DEVICE_ID = new MetricDecoratedValueAttributeKeys("DEVICE_ID", 8);
      DEVICE_MANUFACTURER = new MetricDecoratedValueAttributeKeys("DEVICE_MANUFACTURER", 9);
      DEVICE_MODEL = new MetricDecoratedValueAttributeKeys("DEVICE_MODEL", 10);
      SESSION_ID = new MetricDecoratedValueAttributeKeys("SESSION_ID", 11);
      SEQUENCE_ID = new MetricDecoratedValueAttributeKeys("SEQUENCE_ID", 12);
      INTERNET_CONNECTION = new MetricDecoratedValueAttributeKeys("INTERNET_CONNECTION", 13);
      $VALUES = new MetricDecoratedValueAttributeKeys[] { 
          COUNTRY_SUPPORT, PLAYER_ID, GAME_ID, PLATFORM, HIDDEN, PLAYING_ANONYMOUSLY, NATIVE_VERSION, JAVASCRIPT_VERSION, DEVICE_ID, DEVICE_MANUFACTURER, 
          DEVICE_MODEL, SESSION_ID, SEQUENCE_ID, INTERNET_CONNECTION };
    }
  }
  
  public enum MetricIntegerValueAttributesKeys {
    PROGRESS, BADGE_NUM, NEW_LEVEL, XP_EARNED;
    
    static {
      $VALUES = new MetricIntegerValueAttributesKeys[] { PROGRESS, XP_EARNED, BADGE_NUM, NEW_LEVEL };
    }
  }
  
  public enum MetricRestrictedStringValueAttributeKeys {
    EVENT_NAME, PAGE_TYPE;
    
    static {
    
    }
  }
  
  public enum MetricStringValueAttributesKeys {
    COUNTRY, GAMERCARD_INLIBRARY, GAME_DATA_SIZE_KB, INSTALLER_PACKAGE_NAME, IS_BACK_FILL, OBJECT_ID, PAGE_ID, REWARD_DEFINITION_ID, SCORE, SESSION_LENGTH, STATUS, TARGET_ID, XP_TYPE;
    
    static {
      GAME_DATA_SIZE_KB = new MetricStringValueAttributesKeys("GAME_DATA_SIZE_KB", 4);
      STATUS = new MetricStringValueAttributesKeys("STATUS", 5);
      TARGET_ID = new MetricStringValueAttributesKeys("TARGET_ID", 6);
      XP_TYPE = new MetricStringValueAttributesKeys("XP_TYPE", 7);
      REWARD_DEFINITION_ID = new MetricStringValueAttributesKeys("REWARD_DEFINITION_ID", 8);
      INSTALLER_PACKAGE_NAME = new MetricStringValueAttributesKeys("INSTALLER_PACKAGE_NAME", 9);
      SCORE = new MetricStringValueAttributesKeys("SCORE", 10);
      IS_BACK_FILL = new MetricStringValueAttributesKeys("IS_BACK_FILL", 11);
      GAMERCARD_INLIBRARY = new MetricStringValueAttributesKeys("GAMERCARD_INLIBRARY", 12);
      $VALUES = new MetricStringValueAttributesKeys[] { 
          COUNTRY, PAGE_ID, OBJECT_ID, SESSION_LENGTH, GAME_DATA_SIZE_KB, STATUS, TARGET_ID, XP_TYPE, REWARD_DEFINITION_ID, INSTALLER_PACKAGE_NAME, 
          SCORE, IS_BACK_FILL, GAMERCARD_INLIBRARY };
    }
  }
  
  public enum PageTypes {
    IN_GAME, GC_APP, POPUP;
    
    static {
      $VALUES = new PageTypes[] { IN_GAME, POPUP, GC_APP };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\metrics\MetricConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */