package com.amazon.ags.constants.metrics;

public enum EventNames {
  GameCircleInitialization, GameCircleReinitialization, GameCircleServiceCall, GameSession, OfflineCacheAccess;
  
  static {
    GameCircleInitialization = new EventNames("GameCircleInitialization", 1);
    GameCircleServiceCall = new EventNames("GameCircleServiceCall", 2);
    OfflineCacheAccess = new EventNames("OfflineCacheAccess", 3);
    GameSession = new EventNames("GameSession", 4);
    $VALUES = new EventNames[] { GameCircleReinitialization, GameCircleInitialization, GameCircleServiceCall, OfflineCacheAccess, GameSession };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\metrics\EventNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */