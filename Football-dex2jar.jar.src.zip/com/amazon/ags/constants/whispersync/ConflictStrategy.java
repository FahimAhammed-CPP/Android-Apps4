package com.amazon.ags.constants.whispersync;

public enum ConflictStrategy {
  AUTO_RESOLVE_TO_CLOUD, AUTO_RESOLVE_TO_IGNORE, PLAYER_SELECT;
  
  static {
    AUTO_RESOLVE_TO_CLOUD = new ConflictStrategy("AUTO_RESOLVE_TO_CLOUD", 1);
    AUTO_RESOLVE_TO_IGNORE = new ConflictStrategy("AUTO_RESOLVE_TO_IGNORE", 2);
    $VALUES = new ConflictStrategy[] { PLAYER_SELECT, AUTO_RESOLVE_TO_CLOUD, AUTO_RESOLVE_TO_IGNORE };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\whispersync\ConflictStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */