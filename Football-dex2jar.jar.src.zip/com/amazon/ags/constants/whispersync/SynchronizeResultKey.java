package com.amazon.ags.constants.whispersync;

public enum SynchronizeResultKey {
  ALREADY_SYNCHRONIZED, CONFLICT_DEFERRED, DOWNLOAD_SUCCESS, FAILURE, UPLOAD_SUCCESS;
  
  static {
    DOWNLOAD_SUCCESS = new SynchronizeResultKey("DOWNLOAD_SUCCESS", 3);
    FAILURE = new SynchronizeResultKey("FAILURE", 4);
    $VALUES = new SynchronizeResultKey[] { ALREADY_SYNCHRONIZED, CONFLICT_DEFERRED, UPLOAD_SUCCESS, DOWNLOAD_SUCCESS, FAILURE };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\whispersync\SynchronizeResultKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */