package com.amazon.ags.constants.whispersync;

public enum RevertResultKey {
  DOWNLOAD_SUCCESS, FAILURE, PLAYER_CANCELLED;
  
  static {
    DOWNLOAD_SUCCESS = new RevertResultKey("DOWNLOAD_SUCCESS", 1);
    FAILURE = new RevertResultKey("FAILURE", 2);
    $VALUES = new RevertResultKey[] { PLAYER_CANCELLED, DOWNLOAD_SUCCESS, FAILURE };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\whispersync\RevertResultKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */