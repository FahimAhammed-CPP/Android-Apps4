package com.amazon.ags.constants;

public final class OverlayBindingKeys {
  public static final String OVERLAY_ACTION_CODE_KEY = "OVERLAY_ACTION_CODE";
  
  public static final String OVERLAY_DATA_BUNDLE_KEY = "OVERLAY_DATA_BUNDLE";
  
  public static final String OVERLAY_SESSION_APPLICATION_NAME_KEY = "OVERLAY_SESSION_APPLICATION_NAME";
  
  public static final String OVERLAY_SESSION_CLIENT_VERSION_KEY = "OVERLAY_SESSION_CLIENT_VERSION";
  
  public static final String OVERLAY_SESSION_CONTENT_VERSION_KEY = "OVERLAY_SESSION_CONTENT_VERSION";
  
  public static final String OVERLAY_SESSION_COUNTRY_CODE_KEY = "OVERLAY_SESSION_COUNTRY_CODE";
  
  public static final String OVERLAY_SESSION_DEVICE_IDENTIFIER_KEY = "OVERLAY_SESSION_DEVICE_IDENTIFIER";
  
  public static final String OVERLAY_SESSION_DEVICE_MANUFACTURER_KEY = "OVERLAY_SESSION_DEVICE_MANUFACTURER";
  
  public static final String OVERLAY_SESSION_DEVICE_MODEL_KEY = "OVERLAY_SESSION_DEVICE_MODEL";
  
  public static final String OVERLAY_SESSION_DEVICE_TYPE_KEY = "OVERLAY_SESSION_DEVICE_TYPE";
  
  public static final String OVERLAY_SESSION_GAMECIRCLE_VERSION_KEY = "OVERLAY_SESSION_GAMECIRCLE_VERSION_KEY";
  
  public static final String OVERLAY_SESSION_LANGUAGE_CODE_KEY = "OVERLAY_SESSION_LANGUAGE_CODE";
  
  public static final String OVERLAY_SESSION_VARIATION_CACHE = "OVERLAY_SESSION_VARIATION_CACHE";
  
  private OverlayBindingKeys() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\OverlayBindingKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */