package com.amazon.ags.constants;

public final class ServiceResponseCode {
  public static final int ACHIEVEMENTS_ERROR_RECEIVED = 21;
  
  public static final int ACHIEVEMENTS_REQUEST_FAILURE = 20;
  
  public static final int AUTHENTICATED = 5;
  
  public static final int AUTHENTICATION_CANCELED = 8;
  
  public static final int AUTHENTICATION_ERROR_RECEIVED = 9;
  
  public static final int AUTHENTICATION_OK = 7;
  
  public static final int CLIENT_VERSION_INCOMPATIBLE = 25;
  
  public static final int CONNECTION_ERROR_RECEIVED = 11;
  
  public static final int DATA_VALIDATION_ERROR = 26;
  
  public static final int DOWNLOAD_FAILURE = 4;
  
  public static final int DOWNLOAD_SUCCESS = 3;
  
  public static final int INTERNAL_ERROR_RECEIVED = 12;
  
  public static final int LEADERBOARDS_ERROR_RECEIVED = 19;
  
  public static final int LEADERBOARDS_REQUEST_FAILURE = 18;
  
  public static final int NOT_AUTHENTICATED = 6;
  
  public static final int PROFILES_ERROR_RECEIVED = 23;
  
  public static final int PROFILES_REQUEST_FAILURE = 22;
  
  public static final String RESPONSE_CODE_KEY = "RESPONSE_CODE";
  
  public static final int RESPONSE_ERROR_NETWORK = 28;
  
  public static final int RESPONSE_ERROR_UNAUTHORIZED = 30;
  
  public static final int RESPONSE_ERROR_UNRECOVERABLE = 29;
  
  public static final int RESPONSE_SUCCESS = 27;
  
  public static final int RETRIEVE_HISTORY_FAILURE = 16;
  
  public static final int RETRIEVE_HISTORY_SUCCESS = 15;
  
  public static final int RETRIEVE_LATEST_SUMMARY_FAILURE = 14;
  
  public static final int RETRIEVE_LATEST_SUMMARY_SUCCESS = 13;
  
  public static final int SERVICE_REQUEST_FAILURE = 24;
  
  public static final int SERVICE_REQUEST_SUCCESS = 17;
  
  public static final int UPLOAD_FAILURE = 2;
  
  public static final int UPLOAD_SUCCESS = 1;
  
  private ServiceResponseCode() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\ServiceResponseCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */