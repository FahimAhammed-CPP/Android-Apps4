package com.amazon.ags.constants;

public final class ToastKeys {
  public static final String ACTION_MAPPINGS_KEY = "ACTION_MAPPINGS";
  
  public static final String SHOW_TOASTS_FALSE = "dontShowToasts";
  
  public static final String SHOW_TOASTS_TRUE = "showToasts";
  
  public static final String SHOW_TOASTS_UNDEFINED = "toastsUndefined";
  
  public static final String TOAST_BUTTON_TEXT = "buttonText";
  
  public static final String TOAST_CLICK_DATA_KEY = "TOAST_CLICK_DATA";
  
  public static final String TOAST_DEDUPE_KEY = "dedupeTypes";
  
  public static final String TOAST_DESCRIPTION_KEY = "description";
  
  public static final String TOAST_HEIGHT_KEY = "TOAST_HEIGHT";
  
  public static final String TOAST_ICON_KEY = "icon";
  
  public static final String TOAST_IS_GUEST_KEY = "isGuest";
  
  public static final String TOAST_METHOD_KEY = "method";
  
  public static final String TOAST_REQUEST_DISPLAYED = "toastRequestDisplayed";
  
  public static final String TOAST_SHOW_BUTTON_KEY = "showButton";
  
  public static final String TOAST_TARGET_KEY = "target";
  
  public static final String TOAST_TITLE_KEY = "title";
  
  public static final String TOAST_TOUCH_X_KEY = "TOAST_TOUCH_X";
  
  public static final String TOAST_TOUCH_Y_KEY = "TOAST_TOUCH_Y";
  
  public static final String TOAST_TYPE_KEY = "type";
  
  public static final String TOAST_WIDTH_KEY = "TOAST_WIDTH";
  
  private ToastKeys() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\ToastKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */