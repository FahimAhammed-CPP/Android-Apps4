package com.amazon.ags.constants;

import com.amazon.ags.constants.metrics.MetricConstants;

public class NativeCallKeys {
  public static final String AGE_VIOLATION = "ageViolation";
  
  public static final String AUTHENTICATE = "authenticate";
  
  public static final String BODY = "body";
  
  public static final String CACHE_REQUEST = "cacheRequest";
  
  public static final String CACHE_REQUESTS = "cacheRequests";
  
  public static final String CONNECTED = "connected";
  
  public static final String COUNTRY_CODE = "countryCode";
  
  public static final String COUNTRY_SUPPORT = "countrySupport";
  
  public static final String DEV_FEATURES = "devFeatures";
  
  public static final String EMAIL_ERROR_BUTTON_TITLE = "emailErrorButtonTitle";
  
  public static final String EMAIL_ERROR_MESSAGE = "emailErrorMessage";
  
  public static final String EMAIL_ERROR_TITLE = "emailErrorTitle";
  
  public static final String END_POINT = "endPoint";
  
  public static final String EVENT_ATTRIBUTES = "eventAttributes";
  
  public static final String EVENT_COUNT_METRICS = "eventCountMetrics";
  
  public static final String EVENT_NAME = MetricConstants.MetricRestrictedStringValueAttributeKeys.EVENT_NAME.name();
  
  public static final String EVENT_TIME_METRICS = "eventTimeMetrics";
  
  public static final String GUEST_MODE = "guestMode";
  
  public static final String HAS_OPTED_IN = "hasOptedIn";
  
  public static final String HIDDEN_FLAG = "hidden";
  
  public static final String HTTP_HEADERS = "httpHeaders";
  
  public static final String HTTP_METHOD = "httpMethod";
  
  public static final String HTTP_PAYLOAD = "httpPayload";
  
  public static final String JAVASCRIPT_EVENT_TYPE = "javascriptEventType";
  
  public static final String JSON_DATA = "jsonData";
  
  public static final String LANGUAGE_CODE = "languageCode";
  
  public static final String LOGGED_IN_STATUS = "loggedInStatus";
  
  public static final String MAIL_TO = "mailTo";
  
  public static final String METHOD = "method";
  
  public static final String NATIVE_CALL = "nativeCall";
  
  public static final String PARAMETERS = "parameters";
  
  public static final String PLAYER_ID = "playerId";
  
  public static final String PRIMARY_KEY = "primaryKey";
  
  public static final String REQUEST_ID = "rid";
  
  public static final String ROAMING = "roaming";
  
  public static final String SECONDARY_KEY = "secondaryKey";
  
  public static final String SELF_PLAYER_ID = "SELF";
  
  public static final String SUBJECT = "subject";
  
  public static final String TARGET = "target";
  
  public static final String URL = "url";
  
  public static final String VALUE = "value";
  
  public static final String VARIATION = "variation";
  
  public static final String VARIATION_VARIABLE = "variationVariable";
  
  public static final String VARIATION_VARIABLE_DEFAULT_VALUE = "variationVariableDefaultValue";
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\NativeCallKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */