package com.amazon.ags.constants;

public enum IconSize {
  LARGE, MEDIUM, SMALL;
  
  static {
    MEDIUM = new IconSize("MEDIUM", 1);
    LARGE = new IconSize("LARGE", 2);
    $VALUES = new IconSize[] { SMALL, MEDIUM, LARGE };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\IconSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */