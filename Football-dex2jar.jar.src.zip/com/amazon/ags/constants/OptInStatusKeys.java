package com.amazon.ags.constants;

public class OptInStatusKeys {
  public static final String NOT_OPTED_IN = "NOT_OPTED_IN";
  
  public static final String OPTED_IN = "OPTED_IN";
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\OptInStatusKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */