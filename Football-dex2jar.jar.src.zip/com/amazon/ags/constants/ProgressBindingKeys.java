package com.amazon.ags.constants;

public final class ProgressBindingKeys {
  public static final String MAX_PROGRESS_KEY = "MAX_PROGRESS";
  
  public static final String PLAYER_PROGRESS_KEY = "PLAYER_PROGRESS";
  
  private ProgressBindingKeys() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\ProgressBindingKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */