package com.amazon.ags.constants;

public class JavascriptEventType {
  public static final String SIGN_IN_EVENT = "signInEvent";
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\JavascriptEventType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */