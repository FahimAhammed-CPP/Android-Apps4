package com.amazon.ags.constants;

public final class SubmitScoreResultJSONKeys {
  public static final String FILTER = "Scope";
  
  public static final String IS_IMPROVED = "IsImproved";
  
  public static final String PLAYER_RANK = "PlayerRank";
  
  private SubmitScoreResultJSONKeys() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\constants\SubmitScoreResultJSONKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */