package com.amazon.ags;

public class AGSClientException extends Exception {
  private static final long serialVersionUID = 134523463456345L;
  
  public AGSClientException(String paramString) {
    super(paramString);
  }
  
  public AGSClientException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\AGSClientException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */