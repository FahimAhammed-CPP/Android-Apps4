package com.amazon.ags.api.leaderboards;

import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.constants.LeaderboardFilter;

public interface LeaderboardsClient {
  AGResponseHandle<GetLeaderboardsResponse> getLeaderboards(Object... paramVarArgs);
  
  AGResponseHandle<GetPlayerScoreResponse> getLocalPlayerScore(String paramString, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs);
  
  AGResponseHandle<GetLeaderboardPercentilesResponse> getPercentileRanks(String paramString, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs);
  
  AGResponseHandle<GetLeaderboardPercentilesResponse> getPercentileRanksForPlayer(String paramString1, String paramString2, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs);
  
  AGResponseHandle<GetPlayerScoreResponse> getScoreForPlayer(String paramString1, String paramString2, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs);
  
  AGResponseHandle<GetScoresResponse> getScores(String paramString, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs);
  
  AGResponseHandle<RequestResponse> showLeaderboardOverlay(String paramString, Object... paramVarArgs);
  
  AGResponseHandle<RequestResponse> showLeaderboardsOverlay(Object... paramVarArgs);
  
  AGResponseHandle<SubmitScoreResponse> submitScore(String paramString, long paramLong, Object... paramVarArgs);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\leaderboards\LeaderboardsClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */