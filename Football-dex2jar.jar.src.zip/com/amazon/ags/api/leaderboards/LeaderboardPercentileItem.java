package com.amazon.ags.api.leaderboards;

import com.amazon.ags.api.player.Player;

public interface LeaderboardPercentileItem {
  int getPercentile();
  
  Player getPlayer();
  
  long getPlayerScore();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\leaderboards\LeaderboardPercentileItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */