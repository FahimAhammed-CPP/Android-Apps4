package com.amazon.ags.api.leaderboards;

import com.amazon.ags.api.RequestResponse;
import java.util.List;

public interface GetLeaderboardsResponse extends RequestResponse {
  List<Leaderboard> getLeaderboards();
  
  int getNumLeaderboards();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\leaderboards\GetLeaderboardsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */