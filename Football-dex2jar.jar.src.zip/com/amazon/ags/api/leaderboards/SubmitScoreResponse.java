package com.amazon.ags.api.leaderboards;

import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.constants.LeaderboardFilter;
import java.util.Map;

public interface SubmitScoreResponse extends RequestResponse {
  Map<LeaderboardFilter, Integer> getNewRank();
  
  Map<LeaderboardFilter, Boolean> getRankImproved();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\leaderboards\SubmitScoreResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */