package com.amazon.ags.api.leaderboards;

import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.AmazonGamesClient;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.constants.LeaderboardFilter;

public class AGLeaderboards {
  public static AGResponseHandle<GetLeaderboardsResponse> getLeaderboards(Object... paramVarArgs) {
    return AmazonGamesClient.getInstance().getLeaderboardsClient().getLeaderboards(paramVarArgs);
  }
  
  public static void getLeaderboards(AGResponseCallback<GetLeaderboardsResponse> paramAGResponseCallback, Object... paramVarArgs) {
    AmazonGamesClient.getInstance().getLeaderboardsClient().getLeaderboards(paramVarArgs).setCallback(paramAGResponseCallback);
  }
  
  public static AGResponseHandle<GetLeaderboardPercentilesResponse> getPercentileRanks(String paramString, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs) {
    return AmazonGamesClient.getInstance().getLeaderboardsClient().getPercentileRanks(paramString, paramLeaderboardFilter, paramVarArgs);
  }
  
  public static void getPercentileRanks(String paramString, LeaderboardFilter paramLeaderboardFilter, AGResponseCallback<GetLeaderboardPercentilesResponse> paramAGResponseCallback, Object... paramVarArgs) {
    AmazonGamesClient.getInstance().getLeaderboardsClient().getPercentileRanks(paramString, paramLeaderboardFilter, paramVarArgs).setCallback(paramAGResponseCallback);
  }
  
  public static AGResponseHandle<GetPlayerScoreResponse> getScore(String paramString, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs) {
    return AmazonGamesClient.getInstance().getLeaderboardsClient().getLocalPlayerScore(paramString, paramLeaderboardFilter, paramVarArgs);
  }
  
  public static void getScore(String paramString, LeaderboardFilter paramLeaderboardFilter, AGResponseCallback<GetPlayerScoreResponse> paramAGResponseCallback, Object... paramVarArgs) {
    AmazonGamesClient.getInstance().getLeaderboardsClient().getLocalPlayerScore(paramString, paramLeaderboardFilter, paramVarArgs).setCallback(paramAGResponseCallback);
  }
  
  public static AGResponseHandle<GetScoresResponse> getScores(String paramString, LeaderboardFilter paramLeaderboardFilter, Object... paramVarArgs) {
    return AmazonGamesClient.getInstance().getLeaderboardsClient().getScores(paramString, paramLeaderboardFilter, paramVarArgs);
  }
  
  public static void getScores(String paramString, LeaderboardFilter paramLeaderboardFilter, AGResponseCallback<GetScoresResponse> paramAGResponseCallback, Object... paramVarArgs) {
    AmazonGamesClient.getInstance().getLeaderboardsClient().getScores(paramString, paramLeaderboardFilter, paramVarArgs).setCallback(paramAGResponseCallback);
  }
  
  public static AGResponseHandle<RequestResponse> showLeaderboardOverlay(String paramString) {
    return AmazonGamesClient.getInstance().getLeaderboardsClient().showLeaderboardOverlay(paramString, new Object[0]);
  }
  
  public static AGResponseHandle<RequestResponse> showLeaderboardsOverlay() {
    return AmazonGamesClient.getInstance().getLeaderboardsClient().showLeaderboardsOverlay(new Object[0]);
  }
  
  public static AGResponseHandle<SubmitScoreResponse> submitScore(String paramString, long paramLong, Object... paramVarArgs) {
    return AmazonGamesClient.getInstance().getLeaderboardsClient().submitScore(paramString, paramLong, paramVarArgs);
  }
  
  public static void submitScore(String paramString, long paramLong, AGResponseCallback<SubmitScoreResponse> paramAGResponseCallback, Object... paramVarArgs) {
    AmazonGamesClient.getInstance().getLeaderboardsClient().submitScore(paramString, paramLong, paramVarArgs).setCallback(paramAGResponseCallback);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\leaderboards\AGLeaderboards.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */