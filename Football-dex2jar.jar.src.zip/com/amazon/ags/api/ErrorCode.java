package com.amazon.ags.api;

import java.util.HashMap;
import java.util.Map;

public enum ErrorCode {
  AUTHENTICATION_ERROR,
  CONNECTION_ERROR,
  DATA_VALIDATION_ERROR,
  IO_ERROR,
  NONE(false),
  SERVICE_NOT_READY(false),
  UNRECOVERABLE(true);
  
  public static final Map<Integer, ErrorCode> CODE_TO_ERROR;
  
  private final boolean isError;
  
  static {
    SERVICE_NOT_READY = new ErrorCode("SERVICE_NOT_READY", 2, true);
    IO_ERROR = new ErrorCode("IO_ERROR", 3, true);
    CONNECTION_ERROR = new ErrorCode("CONNECTION_ERROR", 4, true);
    AUTHENTICATION_ERROR = new ErrorCode("AUTHENTICATION_ERROR", 5, true);
    DATA_VALIDATION_ERROR = new ErrorCode("DATA_VALIDATION_ERROR", 6, true);
    $VALUES = new ErrorCode[] { NONE, UNRECOVERABLE, SERVICE_NOT_READY, IO_ERROR, CONNECTION_ERROR, AUTHENTICATION_ERROR, DATA_VALIDATION_ERROR };
    CODE_TO_ERROR = new HashMap<Integer, ErrorCode>() {
        private static final long serialVersionUID = -4762006087722277344L;
      };
  }
  
  ErrorCode(boolean paramBoolean) {
    this.isError = paramBoolean;
  }
  
  public static ErrorCode fromServiceResponseCode(int paramInt) {
    ErrorCode errorCode2 = CODE_TO_ERROR.get(Integer.valueOf(paramInt));
    ErrorCode errorCode1 = errorCode2;
    if (errorCode2 == null)
      errorCode1 = UNRECOVERABLE; 
    return errorCode1;
  }
  
  public boolean isError() {
    return this.isError;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\ErrorCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */