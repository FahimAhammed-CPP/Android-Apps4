package com.amazon.ags.api;

public enum AGHandleStatus {
  ERROR, SUCCESS, WAITING;
  
  static {
    SUCCESS = new AGHandleStatus("SUCCESS", 1);
    ERROR = new AGHandleStatus("ERROR", 2);
    $VALUES = new AGHandleStatus[] { WAITING, SUCCESS, ERROR };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\AGHandleStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */