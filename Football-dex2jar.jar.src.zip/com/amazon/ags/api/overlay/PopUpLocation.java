package com.amazon.ags.api.overlay;

public enum PopUpLocation {
  BOTTOM_CENTER, BOTTOM_LEFT, BOTTOM_RIGHT, TOP_CENTER, TOP_LEFT, TOP_RIGHT;
  
  public static final PopUpLocation DEFAULT_POPUP_LOCATION;
  
  static {
    BOTTOM_LEFT = new PopUpLocation("BOTTOM_LEFT", 2);
    BOTTOM_RIGHT = new PopUpLocation("BOTTOM_RIGHT", 3);
    TOP_CENTER = new PopUpLocation("TOP_CENTER", 4);
    BOTTOM_CENTER = new PopUpLocation("BOTTOM_CENTER", 5);
    $VALUES = new PopUpLocation[] { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT, TOP_CENTER, BOTTOM_CENTER };
    DEFAULT_POPUP_LOCATION = TOP_RIGHT;
  }
  
  public static PopUpLocation getLocationFromString(String paramString, PopUpLocation paramPopUpLocation) {
    try {
      return valueOf(paramString);
    } catch (IllegalArgumentException illegalArgumentException) {
      return paramPopUpLocation;
    } catch (NullPointerException nullPointerException) {
      return paramPopUpLocation;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\overlay\PopUpLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */