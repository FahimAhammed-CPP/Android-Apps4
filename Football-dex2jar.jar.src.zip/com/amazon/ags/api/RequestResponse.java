package com.amazon.ags.api;

public interface RequestResponse {
  ErrorCode getError();
  
  Object[] getUserData();
  
  boolean isError();
  
  void setUserData(Object[] paramArrayOfObject);
  
  String toString();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\RequestResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */