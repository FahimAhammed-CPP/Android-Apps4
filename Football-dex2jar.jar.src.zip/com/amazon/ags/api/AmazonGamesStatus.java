package com.amazon.ags.api;

public enum AmazonGamesStatus {
  CANNOT_AUTHORIZE, CANNOT_BIND, CANNOT_INITIALIZE, INITIALIZING, INVALID_SESSION, NOT_AUTHENTICATED, NOT_AUTHORIZED, SERVICE_CONNECTED, SERVICE_DISCONNECTED, SERVICE_NOT_OPTED_IN;
  
  static {
    CANNOT_INITIALIZE = new AmazonGamesStatus("CANNOT_INITIALIZE", 1);
    SERVICE_CONNECTED = new AmazonGamesStatus("SERVICE_CONNECTED", 2);
    SERVICE_DISCONNECTED = new AmazonGamesStatus("SERVICE_DISCONNECTED", 3);
    CANNOT_BIND = new AmazonGamesStatus("CANNOT_BIND", 4);
    INVALID_SESSION = new AmazonGamesStatus("INVALID_SESSION", 5);
    CANNOT_AUTHORIZE = new AmazonGamesStatus("CANNOT_AUTHORIZE", 6);
    NOT_AUTHORIZED = new AmazonGamesStatus("NOT_AUTHORIZED", 7);
    SERVICE_NOT_OPTED_IN = new AmazonGamesStatus("SERVICE_NOT_OPTED_IN", 8);
    NOT_AUTHENTICATED = new AmazonGamesStatus("NOT_AUTHENTICATED", 9);
    $VALUES = new AmazonGamesStatus[] { INITIALIZING, CANNOT_INITIALIZE, SERVICE_CONNECTED, SERVICE_DISCONNECTED, CANNOT_BIND, INVALID_SESSION, CANNOT_AUTHORIZE, NOT_AUTHORIZED, SERVICE_NOT_OPTED_IN, NOT_AUTHENTICATED };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\AmazonGamesStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */