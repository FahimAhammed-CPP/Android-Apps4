package com.amazon.ags.api;

import java.util.EnumSet;

public enum AmazonGamesFeature {
  Achievements, Leaderboards, Progress, Whispersync;
  
  static {
    Achievements = new AmazonGamesFeature("Achievements", 1);
    Whispersync = new AmazonGamesFeature("Whispersync", 2);
    Progress = new AmazonGamesFeature("Progress", 3);
    $VALUES = new AmazonGamesFeature[] { Leaderboards, Achievements, Whispersync, Progress };
  }
  
  public static EnumSet<AmazonGamesFeature> all() {
    return EnumSet.allOf(AmazonGamesFeature.class);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\AmazonGamesFeature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */