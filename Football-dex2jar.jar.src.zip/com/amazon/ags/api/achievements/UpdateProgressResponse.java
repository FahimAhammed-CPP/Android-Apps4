package com.amazon.ags.api.achievements;

import com.amazon.ags.api.RequestResponse;

public interface UpdateProgressResponse extends RequestResponse {
  boolean isNewlyUnlocked();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\achievements\UpdateProgressResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */