package com.amazon.ags.api.achievements;

import java.util.Date;

public interface Achievement {
  Date getDateUnlocked();
  
  String getDescription();
  
  String getId();
  
  String getImageURL();
  
  int getPointValue();
  
  int getPosition();
  
  float getProgress();
  
  String getTitle();
  
  boolean isHidden();
  
  boolean isUnlocked();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\achievements\Achievement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */