package com.amazon.ags.api.achievements;

import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.AmazonGamesClient;
import com.amazon.ags.api.RequestResponse;

public class AGAchievements {
  public static AGResponseHandle<GetAchievementResponse> getAchievement(String paramString, Object... paramVarArgs) {
    return AmazonGamesClient.getInstance().getAchievementsClient().getAchievement(paramString, paramVarArgs);
  }
  
  public static void getAchievement(String paramString, AGResponseCallback<GetAchievementResponse> paramAGResponseCallback, Object... paramVarArgs) {
    AmazonGamesClient.getInstance().getAchievementsClient().getAchievement(paramString, paramVarArgs).setCallback(paramAGResponseCallback);
  }
  
  public static AGResponseHandle<GetAchievementsResponse> getAchievements(Object... paramVarArgs) {
    return AmazonGamesClient.getInstance().getAchievementsClient().getAchievements(paramVarArgs);
  }
  
  public static void getAchievements(AGResponseCallback<GetAchievementsResponse> paramAGResponseCallback, Object... paramVarArgs) {
    AmazonGamesClient.getInstance().getAchievementsClient().getAchievements(paramVarArgs).setCallback(paramAGResponseCallback);
  }
  
  public static AGResponseHandle<RequestResponse> showAchievementsOverlay() {
    return AmazonGamesClient.getInstance().getAchievementsClient().showAchievementsOverlay(new Object[0]);
  }
  
  public static AGResponseHandle<UpdateProgressResponse> updateProgress(String paramString, float paramFloat, Object... paramVarArgs) {
    return AmazonGamesClient.getInstance().getAchievementsClient().updateProgress(paramString, paramFloat, paramVarArgs);
  }
  
  public static void updateProgress(String paramString, float paramFloat, AGResponseCallback<UpdateProgressResponse> paramAGResponseCallback, Object... paramVarArgs) {
    AmazonGamesClient.getInstance().getAchievementsClient().updateProgress(paramString, paramFloat, paramVarArgs).setCallback(paramAGResponseCallback);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\achievements\AGAchievements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */