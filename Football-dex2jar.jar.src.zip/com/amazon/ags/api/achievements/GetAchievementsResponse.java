package com.amazon.ags.api.achievements;

import com.amazon.ags.api.RequestResponse;
import java.util.List;
import java.util.Map;

public interface GetAchievementsResponse extends RequestResponse {
  List<Achievement> getAchievementsList();
  
  Map<String, Achievement> getAchievementsMap();
  
  int getNumVisibleAchievements();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\achievements\GetAchievementsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */