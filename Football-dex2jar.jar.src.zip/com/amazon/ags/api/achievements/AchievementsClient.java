package com.amazon.ags.api.achievements;

import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.RequestResponse;

public interface AchievementsClient {
  AGResponseHandle<GetAchievementResponse> getAchievement(String paramString, Object... paramVarArgs);
  
  AGResponseHandle<GetAchievementResponse> getAchievementForPlayer(String paramString1, String paramString2, Object... paramVarArgs);
  
  AGResponseHandle<GetAchievementsResponse> getAchievements(Object... paramVarArgs);
  
  AGResponseHandle<GetAchievementsResponse> getAchievementsForPlayer(String paramString, Object... paramVarArgs);
  
  AGResponseHandle<RequestResponse> showAchievementsOverlay(Object... paramVarArgs);
  
  AGResponseHandle<UpdateProgressResponse> updateProgress(String paramString, float paramFloat, Object... paramVarArgs);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\achievements\AchievementsClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */