package com.amazon.ags.api.player;

public interface Player {
  String getAlias();
  
  String getAvatarUrl();
  
  String getPlayerId();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\player\Player.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */