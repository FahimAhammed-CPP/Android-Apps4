package com.amazon.ags.api.player;

import com.amazon.ags.api.RequestResponse;
import java.util.List;

public interface RequestFriendsResponse extends RequestResponse {
  List<Player> getFriends();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\player\RequestFriendsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */