package com.amazon.ags.api.player;

import com.amazon.ags.api.AGResponseHandle;
import java.util.List;

public interface PlayerClient {
  AGResponseHandle<RequestFriendsResponse> getBatchFriends(List<String> paramList, Object... paramVarArgs);
  
  AGResponseHandle<RequestFriendIdsResponse> getFriendIds(Object... paramVarArgs);
  
  AGResponseHandle<RequestPlayerResponse> getLocalPlayer(Object... paramVarArgs);
  
  boolean isSignedIn();
  
  void setSignedInListener(AGSignedInListener paramAGSignedInListener);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\player\PlayerClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */