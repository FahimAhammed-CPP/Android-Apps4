package com.amazon.ags.api.player;

import com.amazon.ags.api.RequestResponse;

public interface RequestPlayerResponse extends RequestResponse {
  Player getPlayer();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\player\RequestPlayerResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */