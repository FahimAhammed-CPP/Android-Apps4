package com.amazon.ags.api.whispersync;

public enum FailReason {
  CLIENT_ERROR, OFFLINE, SERVICE_ERROR, WHISPERSYNC_DISABLED;
  
  static {
    SERVICE_ERROR = new FailReason("SERVICE_ERROR", 2);
    CLIENT_ERROR = new FailReason("CLIENT_ERROR", 3);
    $VALUES = new FailReason[] { OFFLINE, WHISPERSYNC_DISABLED, SERVICE_ERROR, CLIENT_ERROR };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\FailReason.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */