package com.amazon.ags.api.whispersync;

public class WhispersyncEventListener {
  public void onAlreadySynchronized() {}
  
  public void onDataUploadedToCloud() {}
  
  public void onDiskWriteComplete() {}
  
  public void onFirstSynchronize() {}
  
  public void onNewCloudData() {}
  
  public void onSyncFailed(FailReason paramFailReason) {}
  
  public void onThrottled() {}
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\WhispersyncEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */