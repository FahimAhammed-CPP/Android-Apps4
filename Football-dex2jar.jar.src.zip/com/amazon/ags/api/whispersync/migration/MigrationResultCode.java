package com.amazon.ags.api.whispersync.migration;

public enum MigrationResultCode {
  FAILURE, NETWORK_FAILURE, NO_DATA, SUCCESS, WHISPERSYNC_OFF;
  
  static {
    NO_DATA = new MigrationResultCode("NO_DATA", 1);
    NETWORK_FAILURE = new MigrationResultCode("NETWORK_FAILURE", 2);
    WHISPERSYNC_OFF = new MigrationResultCode("WHISPERSYNC_OFF", 3);
    FAILURE = new MigrationResultCode("FAILURE", 4);
    $VALUES = new MigrationResultCode[] { SUCCESS, NO_DATA, NETWORK_FAILURE, WHISPERSYNC_OFF, FAILURE };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\migration\MigrationResultCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */