package com.amazon.ags.api.whispersync.model;

import java.math.BigDecimal;

public interface SyncableAccumulatingNumber {
  BigDecimal asDecimal();
  
  double asDouble();
  
  int asInt();
  
  long asLong();
  
  String asString();
  
  void decrement(double paramDouble);
  
  void decrement(int paramInt);
  
  void decrement(long paramLong);
  
  void decrement(String paramString);
  
  void increment(double paramDouble);
  
  void increment(int paramInt);
  
  void increment(long paramLong);
  
  void increment(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\model\SyncableAccumulatingNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */