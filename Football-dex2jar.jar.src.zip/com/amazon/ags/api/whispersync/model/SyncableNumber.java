package com.amazon.ags.api.whispersync.model;

import java.util.Map;

public interface SyncableNumber extends SyncableNumberElement {
  boolean isSet();
  
  void set(double paramDouble);
  
  void set(double paramDouble, Map<String, String> paramMap);
  
  void set(int paramInt);
  
  void set(int paramInt, Map<String, String> paramMap);
  
  void set(long paramLong);
  
  void set(long paramLong, Map<String, String> paramMap);
  
  void set(String paramString);
  
  void set(String paramString, Map<String, String> paramMap);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\model\SyncableNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */