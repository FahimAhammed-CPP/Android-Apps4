package com.amazon.ags.api.whispersync.model;

import java.util.Map;

public interface SyncableString extends SyncableStringElement {
  boolean isSet();
  
  void set(String paramString);
  
  void set(String paramString, Map<String, String> paramMap);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\model\SyncableString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */