package com.amazon.ags.api.whispersync.model;

import java.util.Map;

public interface SyncableStringList {
  public static final int DEFAULT_MAX_SIZE = 5;
  
  public static final int MAX_SIZE_LIMIT = 1000;
  
  void add(String paramString);
  
  void add(String paramString, Map<String, String> paramMap);
  
  int getMaxSize();
  
  SyncableStringElement[] getValues();
  
  boolean isSet();
  
  void setMaxSize(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\model\SyncableStringList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */