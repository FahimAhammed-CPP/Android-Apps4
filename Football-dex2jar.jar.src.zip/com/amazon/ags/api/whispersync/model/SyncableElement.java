package com.amazon.ags.api.whispersync.model;

import java.util.Map;

public interface SyncableElement {
  Map<String, String> getMetadata();
  
  long getTimestamp();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\model\SyncableElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */