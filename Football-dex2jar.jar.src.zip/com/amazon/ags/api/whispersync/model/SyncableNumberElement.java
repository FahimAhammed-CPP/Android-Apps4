package com.amazon.ags.api.whispersync.model;

import java.math.BigDecimal;

public interface SyncableNumberElement extends SyncableElement {
  BigDecimal asDecimal();
  
  double asDouble();
  
  int asInt();
  
  long asLong();
  
  String asString();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\model\SyncableNumberElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */