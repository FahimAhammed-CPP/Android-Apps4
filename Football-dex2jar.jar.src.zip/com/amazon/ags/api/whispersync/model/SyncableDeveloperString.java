package com.amazon.ags.api.whispersync.model;

public interface SyncableDeveloperString {
  long getCloudTimestamp();
  
  String getCloudValue();
  
  long getTimestamp();
  
  String getValue();
  
  boolean inConflict();
  
  boolean isSet();
  
  void markAsResolved();
  
  void setValue(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\model\SyncableDeveloperString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */