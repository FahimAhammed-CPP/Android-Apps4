package com.amazon.ags.api.whispersync;

import com.amazon.ags.api.whispersync.migration.MigrationCallback;
import java.io.File;
import java.io.IOException;

public interface WhispersyncClient {
  void flush();
  
  GameDataMap getGameData();
  
  void migrateVersion1GameData(MigrationCallback paramMigrationCallback);
  
  void setWhispersyncEventListener(WhispersyncEventListener paramWhispersyncEventListener);
  
  void synchronize();
  
  void unpackVersion1MultiFileGameData(byte[] paramArrayOfbyte, File paramFile) throws IOException;
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\WhispersyncClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */