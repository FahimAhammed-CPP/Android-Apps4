package com.amazon.ags.api.whispersync;

import com.amazon.ags.api.whispersync.model.SyncableAccumulatingNumber;
import com.amazon.ags.api.whispersync.model.SyncableDeveloperString;
import com.amazon.ags.api.whispersync.model.SyncableNumber;
import com.amazon.ags.api.whispersync.model.SyncableNumberList;
import com.amazon.ags.api.whispersync.model.SyncableString;
import com.amazon.ags.api.whispersync.model.SyncableStringList;
import com.amazon.ags.api.whispersync.model.SyncableStringSet;
import java.util.Set;

public interface GameDataMap {
  SyncableAccumulatingNumber getAccumulatingNumber(String paramString);
  
  Set<String> getAccumulatingNumberKeys();
  
  SyncableDeveloperString getDeveloperString(String paramString);
  
  Set<String> getDeveloperStringKeys();
  
  SyncableNumberList getHighNumberList(String paramString);
  
  Set<String> getHighNumberListKeys();
  
  SyncableNumber getHighestNumber(String paramString);
  
  Set<String> getHighestNumberKeys();
  
  SyncableNumber getLatestNumber(String paramString);
  
  Set<String> getLatestNumberKeys();
  
  SyncableNumberList getLatestNumberList(String paramString);
  
  Set<String> getLatestNumberListKeys();
  
  SyncableString getLatestString(String paramString);
  
  Set<String> getLatestStringKeys();
  
  SyncableStringList getLatestStringList(String paramString);
  
  Set<String> getLatestStringListKeys();
  
  SyncableNumberList getLowNumberList(String paramString);
  
  Set<String> getLowNumberListKeys();
  
  SyncableNumber getLowestNumber(String paramString);
  
  Set<String> getLowestNumberKeys();
  
  GameDataMap getMap(String paramString);
  
  Set<String> getMapKeys();
  
  SyncableStringSet getStringSet(String paramString);
  
  Set<String> getStringSetKeys();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\whispersync\GameDataMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */