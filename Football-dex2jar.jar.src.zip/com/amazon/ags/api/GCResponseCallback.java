package com.amazon.ags.api;

public interface GCResponseCallback<T extends RequestResponse> {
  void onFailure(int paramInt, ErrorCode paramErrorCode);
  
  void onSuccess(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\GCResponseCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */