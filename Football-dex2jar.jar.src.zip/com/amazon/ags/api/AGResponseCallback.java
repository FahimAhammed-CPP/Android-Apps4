package com.amazon.ags.api;

public interface AGResponseCallback<T extends RequestResponse> {
  void onComplete(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\AGResponseCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */