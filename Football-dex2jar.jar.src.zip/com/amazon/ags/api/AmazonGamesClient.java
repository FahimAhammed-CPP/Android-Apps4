package com.amazon.ags.api;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.amazon.ags.api.achievements.AchievementsClient;
import com.amazon.ags.api.leaderboards.LeaderboardsClient;
import com.amazon.ags.api.overlay.PopUpLocation;
import com.amazon.ags.api.player.PlayerClient;
import com.amazon.ags.api.whispersync.WhispersyncClient;
import com.amazon.ags.client.AGResponseHandleImpl;
import com.amazon.ags.client.KindleFireBindingCallback;
import com.amazon.ags.client.KindleFireProxy;
import com.amazon.ags.client.KindleFireSoftkeyBeachballManager;
import com.amazon.ags.client.KindleFireStatus;
import com.amazon.ags.client.RequestResponseImpl;
import com.amazon.ags.client.achievements.AchievementsClientImpl;
import com.amazon.ags.client.leaderboards.LeaderboardsClientImpl;
import com.amazon.ags.client.metrics.EventCollectorClient;
import com.amazon.ags.client.metrics.IllegalConstructionException;
import com.amazon.ags.client.metrics.events.GameCircleGenericEvent;
import com.amazon.ags.client.player.PlayerClientImpl;
import com.amazon.ags.client.session.InitializeSessionResponse;
import com.amazon.ags.client.session.SessionEventQueue;
import com.amazon.ags.client.whispersync.WhispersyncClientImpl;
import com.amazon.ags.constants.metrics.EventNames;
import com.amazon.ags.constants.metrics.MetricConstants;
import com.amazon.ags.html5.content.ContentManager;
import com.amazon.ags.html5.content.GCVariationManager;
import com.amazon.ags.html5.factory.AGSClientInstanceCoordinator;
import com.amazon.ags.html5.factory.ServiceFactory;
import com.amazon.ags.html5.overlay.PopUpPrefs;
import com.amazon.ags.html5.util.GlobalState;
import com.amazon.ags.jni.AGSJniHandler;
import com.amazon.ags.storage.StringObfuscator;
import java.security.MessageDigest;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class AmazonGamesClient implements AmazonGames {
  private static AmazonGamesClient INSTANCE = null;
  
  private static final int MAX_THREADS = 2;
  
  private static final String TAG = "GameCircleClient";
  
  private AchievementsClientImpl achievementsClient;
  
  private ContentManager contentManager;
  
  private EventCollectorClient eventCollectorClient;
  
  private ExecutorService executorService;
  
  private GlobalState globalState;
  
  private boolean initialized = false;
  
  private boolean kindleFire = false;
  
  private KindleFireSoftkeyBeachballManager kindleFireSoftkeyBeachballManager;
  
  private LeaderboardsClientImpl leaderboardsClient;
  
  private PlayerClientImpl playerClient;
  
  private ServiceFactory serviceFactory;
  
  private SessionEventQueue sessionEventQueue = new SessionEventQueue();
  
  private Date sessionStartTime;
  
  private Handler uiThreadHandler;
  
  private GCVariationManager variationManager = new GCVariationManager();
  
  private AmazonGamesClient(Activity paramActivity, AmazonGamesCallback paramAmazonGamesCallback, EnumSet<AmazonGamesFeature> paramEnumSet) {
    AGSClientInstanceCoordinator.initialize(paramActivity, paramAmazonGamesCallback, paramEnumSet);
    this.executorService = Executors.newFixedThreadPool(2);
    this.uiThreadHandler = new Handler(Looper.getMainLooper());
    EventCollectorClient.initialize(paramActivity.getApplicationContext());
    this.eventCollectorClient = EventCollectorClient.getInstance();
    this.globalState = new GlobalState();
    this.achievementsClient = new AchievementsClientImpl();
    this.leaderboardsClient = new LeaderboardsClientImpl();
    this.playerClient = new PlayerClientImpl(this.globalState);
  }
  
  private static byte[] generateSignature() {
    try {
      String str1 = AmazonGamesClient.class.getName();
      String str2 = ServiceFactory.class.getName();
      null = (str1 + str2).getBytes("UTF-8");
      return MessageDigest.getInstance("MD5").digest(null);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static AmazonGames getInstance() {
    AmazonGamesClient amazonGamesClient = INSTANCE;
    if (INSTANCE == null) {
      Log.w("GameCircleClient", "AmazonGamesClient is not initialized.  Please call AmazonGamesClient.initialize() first.");
      return amazonGamesClient;
    } 
    if (!INSTANCE.initialized) {
      Log.w("GameCircleClient", "AmazonGamesClient is not ready.  Please wait for the callback before attempting to retrieve the instance.");
      return null;
    } 
    return amazonGamesClient;
  }
  
  public static WhispersyncClient getWhispersyncClient() {
    return (WhispersyncClient)WhispersyncClientImpl.getInstance();
  }
  
  public static void initialize(Activity paramActivity, AmazonGamesCallback paramAmazonGamesCallback, EnumSet<AmazonGamesFeature> paramEnumSet) {
    // Byte code:
    //   0: ldc com/amazon/ags/api/AmazonGamesClient
    //   2: monitorenter
    //   3: new com/amazon/ags/storage/EncryptionStringObfuscator
    //   6: dup
    //   7: invokestatic generateSignature : ()[B
    //   10: invokespecial <init> : ([B)V
    //   13: astore #5
    //   15: iconst_0
    //   16: istore_3
    //   17: ldc 'GameCircleClient'
    //   19: new java/lang/StringBuilder
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: ldc_w 'SDK Version: '
    //   29: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   32: invokestatic getSDKVersion : ()Lcom/amazon/ags/VersionInfo;
    //   35: invokevirtual toString : ()Ljava/lang/String;
    //   38: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: invokevirtual toString : ()Ljava/lang/String;
    //   44: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   47: pop
    //   48: new com/amazon/identity/auth/device/authorization/api/AmazonAuthorizationManager
    //   51: dup
    //   52: aload_0
    //   53: aconst_null
    //   54: invokespecial <init> : (Landroid/content/Context;Landroid/os/Bundle;)V
    //   57: invokevirtual getAppId : ()Ljava/lang/String;
    //   60: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   63: istore #4
    //   65: iload #4
    //   67: ifne -> 72
    //   70: iconst_1
    //   71: istore_3
    //   72: aload_0
    //   73: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   76: aload_0
    //   77: invokevirtual getPackageName : ()Ljava/lang/String;
    //   80: invokevirtual getInstallerPackageName : (Ljava/lang/String;)Ljava/lang/String;
    //   83: putstatic com/amazon/ags/client/metrics/events/GameCircleGenericEvent.packageName : Ljava/lang/String;
    //   86: iload_3
    //   87: ifeq -> 190
    //   90: iconst_0
    //   91: istore #4
    //   93: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   96: ifnull -> 165
    //   99: ldc 'GameCircleClient'
    //   101: ldc_w 'AmazonGamesClient.initialize() has already been called.  Reinitializing.'
    //   104: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   107: pop
    //   108: iconst_1
    //   109: istore #4
    //   111: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   114: aload_1
    //   115: aload_0
    //   116: iload #4
    //   118: aload #5
    //   120: aload_2
    //   121: invokespecial initialize_internal : (Lcom/amazon/ags/api/AmazonGamesCallback;Landroid/app/Activity;ZLcom/amazon/ags/storage/StringObfuscator;Ljava/util/EnumSet;)V
    //   124: aload_0
    //   125: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   128: aload #5
    //   130: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   133: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   136: invokestatic initialize : (Landroid/content/Context;Lcom/amazon/ags/storage/StringObfuscator;Lcom/amazon/ags/client/metrics/EventCollectorClient;)V
    //   139: ldc com/amazon/ags/api/AmazonGamesClient
    //   141: monitorexit
    //   142: return
    //   143: astore #6
    //   145: ldc 'GameCircleClient'
    //   147: ldc_w 'Unable to read api key.  GameCircle requires an api key to be included in 'assets/api_key.txt'.  GameCircle will not initialize.'
    //   150: aload #6
    //   152: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   155: pop
    //   156: goto -> 72
    //   159: astore_0
    //   160: ldc com/amazon/ags/api/AmazonGamesClient
    //   162: monitorexit
    //   163: aload_0
    //   164: athrow
    //   165: ldc 'GameCircleClient'
    //   167: ldc_w 'AmazonGamesClient not yet initialized.  Initializing.'
    //   170: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   173: pop
    //   174: new com/amazon/ags/api/AmazonGamesClient
    //   177: dup
    //   178: aload_0
    //   179: aload_1
    //   180: aload_2
    //   181: invokespecial <init> : (Landroid/app/Activity;Lcom/amazon/ags/api/AmazonGamesCallback;Ljava/util/EnumSet;)V
    //   184: putstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   187: goto -> 111
    //   190: aload_1
    //   191: ifnull -> 139
    //   194: aload_1
    //   195: getstatic com/amazon/ags/api/AmazonGamesStatus.CANNOT_INITIALIZE : Lcom/amazon/ags/api/AmazonGamesStatus;
    //   198: invokeinterface onServiceNotReady : (Lcom/amazon/ags/api/AmazonGamesStatus;)V
    //   203: goto -> 139
    // Exception table:
    //   from	to	target	type
    //   3	15	159	finally
    //   17	48	159	finally
    //   48	65	143	java/lang/Exception
    //   48	65	159	finally
    //   72	86	159	finally
    //   93	108	159	finally
    //   111	139	159	finally
    //   145	156	159	finally
    //   165	187	159	finally
    //   194	203	159	finally
  }
  
  private void initializeSession(final boolean reinitialize, final Date startTime) {
    this.serviceFactory.getSessionClient().initializeSession().setCallback(new AGResponseCallback<InitializeSessionResponse>() {
          public void onComplete(InitializeSessionResponse param1InitializeSessionResponse) {
            try {
              AmazonGamesStatus amazonGamesStatus;
              if (param1InitializeSessionResponse.isError()) {
                amazonGamesStatus = AmazonGamesStatus.CANNOT_INITIALIZE;
                AmazonGamesClient.this.serviceFactory.disableToastCreation();
                AmazonGamesClient.this.reportInitializeEvent(reinitialize, startTime, new Date(), false, amazonGamesStatus);
                AGSClientInstanceCoordinator.getInstance().getLatestCallback().onServiceNotReady(amazonGamesStatus);
              } else if ("AUTHORIZED".equals(amazonGamesStatus.getAuthorizeResult()) && AmazonGamesClient.INSTANCE != null) {
                AmazonGamesClient.access$1102(AmazonGamesClient.INSTANCE, true);
                amazonGamesStatus = AmazonGamesStatus.SERVICE_CONNECTED;
                AmazonGamesClient.this.serviceFactory.enableToastCreation();
                AmazonGamesClient.this.reportInitializeEvent(reinitialize, startTime, new Date(), true, amazonGamesStatus);
                if (AmazonGamesClient.this.achievementsClient != null) {
                  AmazonGamesClient.this.achievementsClient.setServiceHelper(AmazonGamesClient.this.serviceFactory.getServiceHelper());
                  AmazonGamesClient.this.achievementsClient.setOverlayClient(AmazonGamesClient.this.serviceFactory.getOverlayClient());
                } 
                if (AmazonGamesClient.this.leaderboardsClient != null) {
                  AmazonGamesClient.this.leaderboardsClient.setServiceHelper(AmazonGamesClient.this.serviceFactory.getServiceHelper());
                  AmazonGamesClient.this.leaderboardsClient.setOverlayClient(AmazonGamesClient.this.serviceFactory.getOverlayClient());
                } 
                if (AmazonGamesClient.this.playerClient != null)
                  AmazonGamesClient.this.playerClient.setServiceHelper(AmazonGamesClient.this.serviceFactory.getServiceHelper()); 
                AmazonGamesClient.this.initializeJni();
                WhispersyncClientImpl.getInstance().synchronizeOnInitialization();
                Application application = AGSClientInstanceCoordinator.getInstance().getCurrentActivity().getApplication();
                if (application != null && AmazonGamesClient.this.isKindleFire())
                  AmazonGamesClient.access$1602(AmazonGamesClient.this, new KindleFireSoftkeyBeachballManager(application)); 
                AGSClientInstanceCoordinator.getInstance().getLatestCallback().onServiceReady(AmazonGamesClient.INSTANCE);
                if (AmazonGamesClient.this.eventCollectorClient != null)
                  AmazonGamesClient.this.eventCollectorClient.resumeInsightsSession(); 
              } else {
                amazonGamesStatus = AmazonGamesStatus.NOT_AUTHORIZED;
                AmazonGamesClient.this.serviceFactory.disableToastCreation();
                AmazonGamesClient.this.reportInitializeEvent(reinitialize, startTime, new Date(), false, amazonGamesStatus);
                AGSClientInstanceCoordinator.getInstance().getLatestCallback().onServiceNotReady(amazonGamesStatus);
                AmazonGamesClient.shutdown();
              } 
              return;
            } finally {
              if (AmazonGamesClient.this.serviceFactory != null && AmazonGamesClient.this.sessionEventQueue != null)
                AmazonGamesClient.this.sessionEventQueue.setSessionClient(AmazonGamesClient.this.serviceFactory.getSessionClient(), AmazonGamesClient.this.executorService); 
            } 
          }
        });
  }
  
  @SuppressLint({"NewApi"})
  private void initialize_internal(AmazonGamesCallback paramAmazonGamesCallback, Activity paramActivity, boolean paramBoolean, StringObfuscator paramStringObfuscator, EnumSet<AmazonGamesFeature> paramEnumSet) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: new java/util/Date
    //   6: dup
    //   7: invokespecial <init> : ()V
    //   10: putfield sessionStartTime : Ljava/util/Date;
    //   13: aload_0
    //   14: getfield sessionEventQueue : Lcom/amazon/ags/client/session/SessionEventQueue;
    //   17: new com/amazon/ags/client/session/SessionEvent
    //   20: dup
    //   21: ldc_w 'START_SESSION'
    //   24: invokespecial <init> : (Ljava/lang/String;)V
    //   27: invokevirtual enqueue : (Lcom/amazon/ags/client/session/SessionEvent;)V
    //   30: aload_0
    //   31: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   34: ifnull -> 44
    //   37: aload_0
    //   38: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   41: invokevirtual submitEvents : ()V
    //   44: iload_3
    //   45: ifeq -> 121
    //   48: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   51: aload_2
    //   52: invokevirtual updateActivity : (Landroid/app/Activity;)V
    //   55: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   58: aload_1
    //   59: invokevirtual updateCallback : (Lcom/amazon/ags/api/AmazonGamesCallback;)V
    //   62: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   65: aload #5
    //   67: invokevirtual updateFeatures : (Ljava/util/EnumSet;)V
    //   70: aload_0
    //   71: getfield serviceFactory : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   74: ifnull -> 84
    //   77: aload_0
    //   78: getfield serviceFactory : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   81: invokevirtual onResume : ()V
    //   84: invokestatic isInitialized : ()Z
    //   87: ifeq -> 118
    //   90: aload_0
    //   91: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   94: ifnull -> 104
    //   97: aload_0
    //   98: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   101: invokevirtual resumeInsightsSession : ()V
    //   104: invokestatic getInstance : ()Lcom/amazon/ags/html5/factory/AGSClientInstanceCoordinator;
    //   107: invokevirtual getLatestCallback : ()Lcom/amazon/ags/api/AmazonGamesCallback;
    //   110: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   113: invokeinterface onServiceReady : (Lcom/amazon/ags/api/AmazonGamesClient;)V
    //   118: aload_0
    //   119: monitorexit
    //   120: return
    //   121: aload_2
    //   122: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   125: astore #6
    //   127: aload_0
    //   128: getfield executorService : Ljava/util/concurrent/ExecutorService;
    //   131: new com/amazon/ags/api/AmazonGamesClient$1
    //   134: dup
    //   135: aload_0
    //   136: aload #6
    //   138: aload_2
    //   139: aload #4
    //   141: iload_3
    //   142: aload_1
    //   143: invokespecial <init> : (Lcom/amazon/ags/api/AmazonGamesClient;Landroid/content/Context;Landroid/app/Activity;Lcom/amazon/ags/storage/StringObfuscator;ZLcom/amazon/ags/api/AmazonGamesCallback;)V
    //   146: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   151: getstatic android/os/Build$VERSION.SDK_INT : I
    //   154: bipush #14
    //   156: if_icmplt -> 118
    //   159: aload_2
    //   160: invokevirtual getApplication : ()Landroid/app/Application;
    //   163: new com/amazon/ags/client/LifecycleCallbacks
    //   166: dup
    //   167: aload #5
    //   169: invokespecial <init> : (Ljava/util/EnumSet;)V
    //   172: invokevirtual registerActivityLifecycleCallbacks : (Landroid/app/Application$ActivityLifecycleCallbacks;)V
    //   175: goto -> 118
    //   178: astore_1
    //   179: aload_0
    //   180: monitorexit
    //   181: aload_1
    //   182: athrow
    // Exception table:
    //   from	to	target	type
    //   2	44	178	finally
    //   48	84	178	finally
    //   84	104	178	finally
    //   104	118	178	finally
    //   121	175	178	finally
  }
  
  public static boolean isInitialized() {
    return (INSTANCE != null && INSTANCE.initialized);
  }
  
  private boolean isKindleFire() {
    return this.kindleFire;
  }
  
  public static void release() {
    // Byte code:
    //   0: ldc com/amazon/ags/api/AmazonGamesClient
    //   2: monitorenter
    //   3: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   6: ifnull -> 15
    //   9: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   12: invokespecial release_internal : ()V
    //   15: ldc com/amazon/ags/api/AmazonGamesClient
    //   17: monitorexit
    //   18: return
    //   19: astore_0
    //   20: ldc com/amazon/ags/api/AmazonGamesClient
    //   22: monitorexit
    //   23: aload_0
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   3	15	19	finally
  }
  
  private void release_internal() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   6: ifnull -> 16
    //   9: aload_0
    //   10: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   13: invokevirtual pauseInsightsSession : ()V
    //   16: new java/util/Date
    //   19: dup
    //   20: invokespecial <init> : ()V
    //   23: astore_1
    //   24: aload_0
    //   25: getfield sessionStartTime : Ljava/util/Date;
    //   28: ifnull -> 74
    //   31: aload_0
    //   32: getfield sessionStartTime : Ljava/util/Date;
    //   35: invokevirtual getTime : ()J
    //   38: lconst_0
    //   39: lcmp
    //   40: ifle -> 74
    //   43: aload_1
    //   44: aload_0
    //   45: getfield sessionStartTime : Ljava/util/Date;
    //   48: invokevirtual after : (Ljava/util/Date;)Z
    //   51: ifeq -> 74
    //   54: aload_0
    //   55: aload_0
    //   56: getfield sessionStartTime : Ljava/util/Date;
    //   59: new java/util/Date
    //   62: dup
    //   63: invokespecial <init> : ()V
    //   66: invokespecial reportSessionEvent : (Ljava/util/Date;Ljava/util/Date;)V
    //   69: aload_0
    //   70: aconst_null
    //   71: putfield sessionStartTime : Ljava/util/Date;
    //   74: aload_0
    //   75: getfield sessionEventQueue : Lcom/amazon/ags/client/session/SessionEventQueue;
    //   78: new com/amazon/ags/client/session/SessionEvent
    //   81: dup
    //   82: ldc_w 'STOP_SESSION'
    //   85: invokespecial <init> : (Ljava/lang/String;)V
    //   88: invokevirtual enqueue : (Lcom/amazon/ags/client/session/SessionEvent;)V
    //   91: aload_0
    //   92: getfield serviceFactory : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   95: ifnull -> 105
    //   98: aload_0
    //   99: getfield serviceFactory : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   102: invokevirtual onPause : ()V
    //   105: aload_0
    //   106: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   109: ifnull -> 119
    //   112: aload_0
    //   113: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   116: invokevirtual submitEvents : ()V
    //   119: aload_0
    //   120: monitorexit
    //   121: return
    //   122: astore_1
    //   123: aload_0
    //   124: monitorexit
    //   125: aload_1
    //   126: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	122	finally
    //   16	74	122	finally
    //   74	105	122	finally
    //   105	119	122	finally
  }
  
  private void reportInitializeEvent(boolean paramBoolean1, Date paramDate1, Date paramDate2, boolean paramBoolean2, AmazonGamesStatus paramAmazonGamesStatus) {
    if (this.eventCollectorClient == null) {
      Log.w("GameCircleClient", "Null collector. Cannot report initialization event.");
      return;
    } 
    if (!this.eventCollectorClient.isReportingEnabled()) {
      Log.i("GameCircleClient", "Reporting is disabled. Cannot report initialization event.");
      return;
    } 
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>();
    hashMap1.put(MetricConstants.MetricStringValueAttributesKeys.STATUS.name(), paramAmazonGamesStatus.toString());
    hashMap3.put("initializationTime", Long.valueOf(paramDate2.getTime() - paramDate1.getTime()));
    if (paramBoolean2) {
      hashMap2.put("initializationSuccess", Integer.valueOf(1));
    } else {
      hashMap2.put("initializationFail", Integer.valueOf(1));
    } 
    if (paramBoolean1)
      try {
        GameCircleGenericEvent gameCircleGenericEvent1 = new GameCircleGenericEvent(EventNames.GameCircleReinitialization.name(), hashMap1, hashMap2, hashMap3);
        this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent1);
        return;
      } catch (IllegalConstructionException illegalConstructionException) {
        Log.w("GameCircleClient", "Could not construct GameCircleInitialization event. It will not be reported.");
        return;
      }  
    GameCircleGenericEvent gameCircleGenericEvent = new GameCircleGenericEvent(EventNames.GameCircleInitialization.name(), hashMap1, hashMap2, hashMap3);
    this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent);
  }
  
  private void reportSessionEvent(Date paramDate1, Date paramDate2) {
    if (this.eventCollectorClient == null) {
      Log.w("GameCircleClient", "Null collector. Cannot report session event.");
      return;
    } 
    if (!this.eventCollectorClient.isReportingEnabled()) {
      Log.i("GameCircleClient", "Reporting is disabled. Cannot report session event.");
      return;
    } 
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>();
    long l = paramDate2.getTime() - paramDate1.getTime();
    hashMap1.put(MetricConstants.MetricStringValueAttributesKeys.GAME_DATA_SIZE_KB.name(), "");
    hashMap1.put(MetricConstants.MetricStringValueAttributesKeys.SESSION_LENGTH.name(), String.valueOf(l));
    hashMap3.put(MetricConstants.MetricStringValueAttributesKeys.SESSION_LENGTH.name(), Long.valueOf(l));
    try {
      GameCircleGenericEvent gameCircleGenericEvent = new GameCircleGenericEvent(EventNames.GameSession.name(), hashMap1, hashMap2, hashMap3);
      this.eventCollectorClient.reportGenericEvent(gameCircleGenericEvent);
      return;
    } catch (IllegalConstructionException illegalConstructionException) {
      Log.w("GameCircleClient", "Could not construct session event. It will not be reported.");
      return;
    } 
  }
  
  private void setKindleFire(boolean paramBoolean) {
    this.kindleFire = paramBoolean;
  }
  
  public static void shutdown() {
    // Byte code:
    //   0: ldc com/amazon/ags/api/AmazonGamesClient
    //   2: monitorenter
    //   3: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   6: ifnull -> 15
    //   9: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   12: invokespecial shutdown_internal : ()V
    //   15: ldc com/amazon/ags/api/AmazonGamesClient
    //   17: monitorexit
    //   18: return
    //   19: astore_0
    //   20: ldc com/amazon/ags/api/AmazonGamesClient
    //   22: monitorexit
    //   23: aload_0
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   3	15	19	finally
  }
  
  private void shutdown_internal() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   5: ifnull -> 118
    //   8: getstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   11: iconst_0
    //   12: putfield initialized : Z
    //   15: aload_0
    //   16: getfield achievementsClient : Lcom/amazon/ags/client/achievements/AchievementsClientImpl;
    //   19: invokevirtual shutdown : ()V
    //   22: aload_0
    //   23: getfield leaderboardsClient : Lcom/amazon/ags/client/leaderboards/LeaderboardsClientImpl;
    //   26: invokevirtual shutdown : ()V
    //   29: aload_0
    //   30: getfield playerClient : Lcom/amazon/ags/client/player/PlayerClientImpl;
    //   33: invokevirtual shutdown : ()V
    //   36: aload_0
    //   37: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   40: ifnull -> 55
    //   43: aload_0
    //   44: getfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   47: invokevirtual pauseInsightsSession : ()V
    //   50: aload_0
    //   51: aconst_null
    //   52: putfield eventCollectorClient : Lcom/amazon/ags/client/metrics/EventCollectorClient;
    //   55: aload_0
    //   56: invokespecial release_internal : ()V
    //   59: aload_0
    //   60: getfield serviceFactory : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   63: invokevirtual shutdown : ()V
    //   66: aload_0
    //   67: aconst_null
    //   68: putfield serviceFactory : Lcom/amazon/ags/html5/factory/ServiceFactory;
    //   71: aload_0
    //   72: aconst_null
    //   73: putfield achievementsClient : Lcom/amazon/ags/client/achievements/AchievementsClientImpl;
    //   76: aload_0
    //   77: aconst_null
    //   78: putfield leaderboardsClient : Lcom/amazon/ags/client/leaderboards/LeaderboardsClientImpl;
    //   81: aload_0
    //   82: aconst_null
    //   83: putfield playerClient : Lcom/amazon/ags/client/player/PlayerClientImpl;
    //   86: aload_0
    //   87: aconst_null
    //   88: putfield sessionEventQueue : Lcom/amazon/ags/client/session/SessionEventQueue;
    //   91: aload_0
    //   92: aconst_null
    //   93: putfield executorService : Ljava/util/concurrent/ExecutorService;
    //   96: aload_0
    //   97: aconst_null
    //   98: putfield uiThreadHandler : Landroid/os/Handler;
    //   101: aload_0
    //   102: aconst_null
    //   103: putfield sessionStartTime : Ljava/util/Date;
    //   106: aload_0
    //   107: getfield contentManager : Lcom/amazon/ags/html5/content/ContentManager;
    //   110: invokevirtual shutdown : ()V
    //   113: aload_0
    //   114: aconst_null
    //   115: putfield contentManager : Lcom/amazon/ags/html5/content/ContentManager;
    //   118: aconst_null
    //   119: putstatic com/amazon/ags/api/AmazonGamesClient.INSTANCE : Lcom/amazon/ags/api/AmazonGamesClient;
    //   122: aload_0
    //   123: monitorexit
    //   124: return
    //   125: astore_1
    //   126: aload_0
    //   127: monitorexit
    //   128: aload_1
    //   129: athrow
    // Exception table:
    //   from	to	target	type
    //   2	55	125	finally
    //   55	118	125	finally
    //   118	122	125	finally
  }
  
  public AchievementsClient getAchievementsClient() {
    return (AchievementsClient)this.achievementsClient;
  }
  
  public LeaderboardsClient getLeaderboardsClient() {
    return (LeaderboardsClient)this.leaderboardsClient;
  }
  
  public PlayerClient getPlayerClient() {
    return (PlayerClient)this.playerClient;
  }
  
  public void initializeJni() {
    AGSJniHandler.initializeJni(this);
  }
  
  public void setPopUpLocation(PopUpLocation paramPopUpLocation) {
    PopUpPrefs.INSTANCE.setLocation(paramPopUpLocation);
  }
  
  public AGResponseHandle<RequestResponse> showGameCircle(Object... paramVarArgs) {
    if (isInitialized() && this.serviceFactory != null)
      return this.serviceFactory.getOverlayClient().showGameCircle(paramVarArgs); 
    AGResponseHandleImpl aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
    aGResponseHandleImpl.setResponse((RequestResponse)new RequestResponseImpl(24, ErrorCode.UNRECOVERABLE));
    return (AGResponseHandle<RequestResponse>)aGResponseHandleImpl;
  }
  
  public AGResponseHandle<RequestResponse> showSignInPage(Object... paramVarArgs) {
    if (isInitialized() && this.serviceFactory != null)
      return this.serviceFactory.getOverlayClient().showSignInPage(paramVarArgs); 
    AGResponseHandleImpl aGResponseHandleImpl = new AGResponseHandleImpl(paramVarArgs);
    aGResponseHandleImpl.setResponse((RequestResponse)new RequestResponseImpl(24, ErrorCode.UNRECOVERABLE));
    return (AGResponseHandle<RequestResponse>)aGResponseHandleImpl;
  }
  
  static {
    AGSJniHandler.loadLibrary();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\AmazonGamesClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */