package com.amazon.ags.api;

import com.amazon.ags.api.achievements.AchievementsClient;
import com.amazon.ags.api.leaderboards.LeaderboardsClient;
import com.amazon.ags.api.overlay.PopUpLocation;
import com.amazon.ags.api.player.PlayerClient;

public interface AmazonGames {
  AchievementsClient getAchievementsClient();
  
  LeaderboardsClient getLeaderboardsClient();
  
  PlayerClient getPlayerClient();
  
  void initializeJni();
  
  void setPopUpLocation(PopUpLocation paramPopUpLocation);
  
  AGResponseHandle<RequestResponse> showGameCircle(Object... paramVarArgs);
  
  AGResponseHandle<RequestResponse> showSignInPage(Object... paramVarArgs);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\AmazonGames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */