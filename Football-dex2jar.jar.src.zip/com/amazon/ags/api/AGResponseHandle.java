package com.amazon.ags.api;

public interface AGResponseHandle<T extends RequestResponse> {
  T getResponse();
  
  AGHandleStatus getStatus();
  
  void setCallback(AGResponseCallback<T> paramAGResponseCallback);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\AGResponseHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */