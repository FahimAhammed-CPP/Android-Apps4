package com.amazon.ags.api;

public interface AmazonGamesCallback {
  void onServiceNotReady(AmazonGamesStatus paramAmazonGamesStatus);
  
  void onServiceReady(AmazonGamesClient paramAmazonGamesClient);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\api\AmazonGamesCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */