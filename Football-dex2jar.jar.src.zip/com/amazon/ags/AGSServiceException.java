package com.amazon.ags;

public class AGSServiceException extends Exception {
  private static final long serialVersionUID = -3280294300463989372L;
  
  public AGSServiceException(String paramString) {
    super(paramString);
  }
  
  public AGSServiceException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\AGSServiceException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */