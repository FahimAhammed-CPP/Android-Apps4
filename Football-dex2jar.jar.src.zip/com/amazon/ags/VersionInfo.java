package com.amazon.ags;

public class VersionInfo {
  private static final int GAMECIRCLE_MAJOR_VERSION = 2;
  
  private static final int GAMECIRCLE_MINOR_VERSION = 4;
  
  private static final int GAMECIRCLE_PATCH_VERSION = 2;
  
  private static final int SDK_MAJOR_VERSION = 2;
  
  private static final int SDK_MINOR_VERSION = 4;
  
  private static final int SDK_PATCH_VERSION = 2;
  
  private static final String SDK_VERSION_QUALIFIER = null;
  
  private static final String SEPARATOR = ".";
  
  private int majorVersion;
  
  private int minorVersion;
  
  private int patchVersion;
  
  public VersionInfo(int paramInt1, int paramInt2, int paramInt3) {
    this.majorVersion = paramInt1;
    this.minorVersion = paramInt2;
    this.patchVersion = paramInt3;
  }
  
  public static VersionInfo getGameCircleVersion() {
    return new VersionInfo(2, 4, 2);
  }
  
  public static VersionInfo getSDKVersion() {
    return new VersionInfo(2, 4, 2);
  }
  
  public int getMajorVersion() {
    return this.majorVersion;
  }
  
  public int getMinorVersion() {
    return this.minorVersion;
  }
  
  public int getPatchVersion() {
    return this.patchVersion;
  }
  
  public String getVersion() {
    String str2 = this.majorVersion + "." + this.minorVersion + "." + this.patchVersion;
    String str1 = str2;
    if (SDK_VERSION_QUALIFIER != null)
      str1 = str2 + "-" + SDK_VERSION_QUALIFIER; 
    return str1;
  }
  
  public String toString() {
    return getVersion();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\VersionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */