package com.amazon.ags.jni;

import android.util.Log;
import com.amazon.ags.api.AmazonGames;
import com.amazon.ags.api.AmazonGamesClient;
import com.amazon.ags.jni.achievements.AchievementsNativeHandler;
import com.amazon.ags.jni.gamecircle.GameCircleNativeHandler;
import com.amazon.ags.jni.leaderboards.LeaderboardsNativeHandler;
import com.amazon.ags.jni.player.ProfilesNativeHandler;
import com.amazon.ags.jni.whispersync.WhispersyncNativeHandler;

public class AGSJniHandler {
  private static final String JNI_LIBRARY_NAME = "AmazonGamesJni";
  
  public static final String TAG = "AGSJniHandler";
  
  private static boolean libraryLoaded = false;
  
  public static void initializeJni(AmazonGamesClient paramAmazonGamesClient) {
    Log.i("AGSJniHandler", "Initializing Native Handlers");
    GameCircleNativeHandler.initializeNativeHandler((AmazonGames)paramAmazonGamesClient);
    LeaderboardsNativeHandler.initializeNativeHandler(paramAmazonGamesClient);
    AchievementsNativeHandler.initializeNativeHandler(paramAmazonGamesClient);
    ProfilesNativeHandler.initializeNativeHandler(paramAmazonGamesClient);
    WhispersyncNativeHandler.initializeNativeHandler();
  }
  
  public static boolean isLibraryLoaded() {
    return libraryLoaded;
  }
  
  public static native void isLoaded();
  
  public static void loadLibrary() {
    try {
      isLoaded();
      libraryLoaded = true;
      Log.i("AGSJniHandler", "AmazonGamesJni is already loaded");
      return;
    } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
      Log.i("AGSJniHandler", "AmazonGamesJni is not loaded, trying to load library");
      try {
        System.loadLibrary("AmazonGamesJni");
        libraryLoaded = true;
        return;
      } catch (UnsatisfiedLinkError unsatisfiedLinkError1) {
        Log.w("AGSJniHandler", "AmazonGamesJni not found.  Java Native Interface will not be available");
        return;
      } 
    } 
  }
  
  public static native void showGameCircleResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void showGameCircleResponseSuccess(long paramLong, int paramInt);
  
  public static native void showSignInPageResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void showSignInPageResponseSuccess(long paramLong, int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\AGSJniHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */