package com.amazon.ags.jni.player;

import android.util.Log;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.AmazonGamesClient;
import com.amazon.ags.api.player.PlayerClient;
import com.amazon.ags.api.player.RequestFriendIdsResponse;
import com.amazon.ags.api.player.RequestFriendsResponse;
import com.amazon.ags.api.player.RequestPlayerResponse;
import java.util.ArrayList;

public class ProfilesNativeHandler {
  private static final String TAG = ProfilesNativeHandler.class.getSimpleName();
  
  private static PlayerClient m_PlayerClient = null;
  
  public static void getBatchFriends(String[] paramArrayOfString, int paramInt, long paramLong) {
    if (m_PlayerClient == null) {
      Log.e(TAG, "requestBatchFriends - initializeJni was not called beforehand.");
      return;
    } 
    ArrayList<String> arrayList = new ArrayList();
    int j = paramArrayOfString.length;
    int i;
    for (i = 0; i < j; i++)
      arrayList.add(paramArrayOfString[i]); 
    m_PlayerClient.getBatchFriends(arrayList, new Object[] { Integer.valueOf(paramInt) }).setCallback(new RequestBatchFriendsJniResponseHandler(paramInt, paramLong));
  }
  
  public static AGResponseHandle<RequestFriendsResponse> getBatchFriendsHandle(String[] paramArrayOfString, int paramInt) {
    if (m_PlayerClient == null) {
      Log.e(TAG, "requestBatchFriendsHandle - initializeJni was not called beforehand.");
      return null;
    } 
    ArrayList<String> arrayList = new ArrayList();
    int j = paramArrayOfString.length;
    for (int i = 0; i < j; i++)
      arrayList.add(paramArrayOfString[i]); 
    return m_PlayerClient.getBatchFriends(arrayList, new Object[] { Integer.valueOf(paramInt) });
  }
  
  public static void getFriendIds(int paramInt, long paramLong) {
    if (m_PlayerClient == null) {
      Log.e(TAG, "requestFriendIds - initializeJni was not called beforehand.");
      return;
    } 
    m_PlayerClient.getFriendIds(new Object[] { Integer.valueOf(paramInt) }).setCallback(new RequestFriendIdsJniResponseHandler(paramInt, paramLong));
  }
  
  public static AGResponseHandle<RequestFriendIdsResponse> getFriendIdsHandle(int paramInt) {
    if (m_PlayerClient == null) {
      Log.e(TAG, "requestFriendIdsHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_PlayerClient.getFriendIds(new Object[] { Integer.valueOf(paramInt) });
  }
  
  public static void getLocalPlayer(int paramInt, long paramLong) {
    if (m_PlayerClient == null) {
      Log.e(TAG, "requestLocalPlayerProfile - initializeJni was not called beforehand.");
      return;
    } 
    m_PlayerClient.getLocalPlayer(new Object[0]).setCallback(new RequestLocalPlayerProfileJniResponseHandler(paramInt, paramLong));
  }
  
  public static AGResponseHandle<RequestPlayerResponse> getLocalPlayerHandle(int paramInt) {
    if (m_PlayerClient == null) {
      Log.e(TAG, "requestLocalPlayerProfileHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_PlayerClient.getLocalPlayer(new Object[] { Integer.valueOf(paramInt) });
  }
  
  public static void initializeNativeHandler(AmazonGamesClient paramAmazonGamesClient) {
    m_PlayerClient = paramAmazonGamesClient.getPlayerClient();
  }
  
  public static boolean isSignedIn(int paramInt) {
    if (m_PlayerClient == null) {
      Log.e(TAG, "isSignedIn - initializeJni was not called beforehand.");
      return false;
    } 
    return m_PlayerClient.isSignedIn();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\player\ProfilesNativeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */