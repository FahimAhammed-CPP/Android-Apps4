package com.amazon.ags.jni.player;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.player.RequestPlayerResponse;
import com.amazon.ags.jni.JniResponseHandler;

public class RequestLocalPlayerProfileJniResponseHandler extends JniResponseHandler implements AGResponseCallback<RequestPlayerResponse> {
  private static final String TAG = RequestLocalPlayerProfileJniResponseHandler.class.getSimpleName();
  
  public RequestLocalPlayerProfileJniResponseHandler(int paramInt, long paramLong) {
    super(paramInt, paramLong);
  }
  
  public void onComplete(RequestPlayerResponse paramRequestPlayerResponse) {
    if (paramRequestPlayerResponse.isError()) {
      Log.d(TAG, "jniRequestPlayerProfile response - onFailure");
      ProfilesJni.getLocalPlayerProfileResponseFailure(this.m_CallbackPointer, paramRequestPlayerResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(TAG, "jniRequestPlayerProfile response - onSuccess");
    ProfilesJni.getLocalPlayerProfileResponseSuccess(paramRequestPlayerResponse, this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\player\RequestLocalPlayerProfileJniResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */