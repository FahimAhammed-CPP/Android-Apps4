package com.amazon.ags.jni.player;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.player.RequestFriendsResponse;
import com.amazon.ags.jni.JniResponseHandler;

public class RequestBatchFriendsJniResponseHandler extends JniResponseHandler implements AGResponseCallback<RequestFriendsResponse> {
  private static final String TAG = RequestBatchFriendsJniResponseHandler.class.getSimpleName();
  
  public RequestBatchFriendsJniResponseHandler(int paramInt, long paramLong) {
    super(paramInt, paramLong);
  }
  
  public void onComplete(RequestFriendsResponse paramRequestFriendsResponse) {
    if (paramRequestFriendsResponse.isError()) {
      Log.d(TAG, "jniRequestBatchFriends response - onFailure");
      ProfilesJni.getBatchFriendsResponseFailure(this.m_CallbackPointer, paramRequestFriendsResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(TAG, "jniRequestBatchFriends response - onSuccess");
    ProfilesJni.getBatchFriendsResponseSuccess(paramRequestFriendsResponse, this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\player\RequestBatchFriendsJniResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */