package com.amazon.ags.jni.player;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.player.RequestFriendIdsResponse;
import com.amazon.ags.jni.JniResponseHandler;

public class RequestFriendIdsJniResponseHandler extends JniResponseHandler implements AGResponseCallback<RequestFriendIdsResponse> {
  private static final String TAG = RequestFriendIdsJniResponseHandler.class.getSimpleName();
  
  public RequestFriendIdsJniResponseHandler(int paramInt, long paramLong) {
    super(paramInt, paramLong);
  }
  
  public void onComplete(RequestFriendIdsResponse paramRequestFriendIdsResponse) {
    if (paramRequestFriendIdsResponse.isError()) {
      Log.d(TAG, "jniRequestFriendIds response - onFailure");
      ProfilesJni.getFriendIdsResponseFailure(this.m_CallbackPointer, paramRequestFriendIdsResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(TAG, "jniRequestFriendIds response - onSuccess");
    ProfilesJni.getFriendIdsResponseSuccess(paramRequestFriendIdsResponse, this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\player\RequestFriendIdsJniResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */