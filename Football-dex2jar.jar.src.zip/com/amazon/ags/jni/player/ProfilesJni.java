package com.amazon.ags.jni.player;

import com.amazon.ags.api.player.RequestFriendIdsResponse;
import com.amazon.ags.api.player.RequestFriendsResponse;
import com.amazon.ags.api.player.RequestPlayerResponse;

public class ProfilesJni {
  public static native void callSignedInStateChangedListener(boolean paramBoolean);
  
  public static native void getBatchFriendsResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void getBatchFriendsResponseSuccess(RequestFriendsResponse paramRequestFriendsResponse, long paramLong, int paramInt);
  
  public static native void getFriendIdsResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void getFriendIdsResponseSuccess(RequestFriendIdsResponse paramRequestFriendIdsResponse, long paramLong, int paramInt);
  
  public static native void getLocalPlayerProfileResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void getLocalPlayerProfileResponseSuccess(RequestPlayerResponse paramRequestPlayerResponse, long paramLong, int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\player\ProfilesJni.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */