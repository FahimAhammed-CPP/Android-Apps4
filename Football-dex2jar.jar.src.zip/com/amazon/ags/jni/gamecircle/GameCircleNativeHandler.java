package com.amazon.ags.jni.gamecircle;

import android.util.Log;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.AmazonGames;
import com.amazon.ags.api.RequestResponse;

public class GameCircleNativeHandler {
  private static final String TAG = "GameCircleNativeHandler";
  
  private static AmazonGames amazonGames = null;
  
  public static void initializeNativeHandler(AmazonGames paramAmazonGames) {
    amazonGames = paramAmazonGames;
  }
  
  public static void showGameCircle(int paramInt, long paramLong) {
    if (amazonGames == null) {
      Log.e("GameCircleNativeHandler", "showGameCircle - initializeJni was not called beforehand.");
      return;
    } 
    amazonGames.showGameCircle(new Object[] { Integer.valueOf(paramInt) }).setCallback(new ShowGameCircleJniRespHandler(paramInt, paramLong));
  }
  
  public static AGResponseHandle<RequestResponse> showGameCircleHandle(int paramInt) {
    if (amazonGames == null) {
      Log.e("GameCircleNativeHandler", "showGameCircle - initializeJni was not called beforehand.");
      return null;
    } 
    return amazonGames.showGameCircle(new Object[] { Integer.valueOf(paramInt) });
  }
  
  public static void showSignInPage(int paramInt, long paramLong) {
    if (amazonGames == null) {
      Log.e("GameCircleNativeHandler", "showSignInPage - initializeJni was not called beforehand.");
      return;
    } 
    amazonGames.showSignInPage(new Object[] { Integer.valueOf(paramInt) }).setCallback(new ShowGameCircleJniRespHandler(paramInt, paramLong));
  }
  
  public static AGResponseHandle<RequestResponse> showSignInPageHandle(int paramInt) {
    if (amazonGames == null) {
      Log.e("GameCircleNativeHandler", "showSignInPage - initializeJni was not called beforehand.");
      return null;
    } 
    return amazonGames.showSignInPage(new Object[] { Integer.valueOf(paramInt) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\gamecircle\GameCircleNativeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */