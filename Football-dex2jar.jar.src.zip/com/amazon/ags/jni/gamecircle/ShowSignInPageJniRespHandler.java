package com.amazon.ags.jni.gamecircle;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.jni.AGSJniHandler;
import com.amazon.ags.jni.JniResponseHandler;

public class ShowSignInPageJniRespHandler extends JniResponseHandler implements AGResponseCallback<RequestResponse> {
  private static String LOG_TAG = "ShowSignInPageJniRespHandler";
  
  public ShowSignInPageJniRespHandler(int paramInt, long paramLong) {
    super(paramInt, paramLong);
  }
  
  public void onComplete(RequestResponse paramRequestResponse) {
    if (paramRequestResponse.isError()) {
      Log.d(LOG_TAG, "jniShowSignInPage response - onFailure");
      AGSJniHandler.showSignInPageResponseFailure(this.m_CallbackPointer, paramRequestResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(LOG_TAG, "jniShowSignInPage response - onSuccess");
    AGSJniHandler.showSignInPageResponseSuccess(this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\gamecircle\ShowSignInPageJniRespHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */