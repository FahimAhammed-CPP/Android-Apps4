package com.amazon.ags.jni.leaderboards;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.leaderboards.GetLeaderboardsResponse;
import com.amazon.ags.jni.JniResponseHandler;

public class GetLbsJniResponseHandler extends JniResponseHandler implements AGResponseCallback<GetLeaderboardsResponse> {
  private static String LOG_TAG = "RequestLbJniResponseHandler";
  
  public GetLbsJniResponseHandler(int paramInt, long paramLong) {
    super(paramInt, paramLong);
  }
  
  public void onComplete(GetLeaderboardsResponse paramGetLeaderboardsResponse) {
    if (paramGetLeaderboardsResponse.isError()) {
      Log.d(LOG_TAG, "jniRequestLeaderboards response - onFailure");
      LeaderboardsJni.getLeaderboardsResponseFailure(this.m_CallbackPointer, paramGetLeaderboardsResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(LOG_TAG, "jniRequestLeaderboards response - onSuccess");
    LeaderboardsJni.getLeaderboardsResponseSuccess(paramGetLeaderboardsResponse, this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\leaderboards\GetLbsJniResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */