package com.amazon.ags.jni.leaderboards;

import android.util.Log;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.AmazonGamesClient;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.leaderboards.GetLeaderboardPercentilesResponse;
import com.amazon.ags.api.leaderboards.GetLeaderboardsResponse;
import com.amazon.ags.api.leaderboards.GetPlayerScoreResponse;
import com.amazon.ags.api.leaderboards.GetScoresResponse;
import com.amazon.ags.api.leaderboards.LeaderboardsClient;
import com.amazon.ags.api.leaderboards.SubmitScoreResponse;
import com.amazon.ags.constants.LeaderboardFilter;

public class LeaderboardsNativeHandler {
  private static String TAG = "LeaderboardsNativeHandler";
  
  private static LeaderboardsClient m_LeaderboardsClient = null;
  
  public static void getPercentiles(String paramString1, String paramString2, int paramInt1, int paramInt2, long paramLong) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "getPercentiles - initializeJni was not called beforehand.");
      return;
    } 
    m_LeaderboardsClient.getPercentileRanksForPlayer(paramString1, paramString2, LeaderboardFilter.fromOrdinal(paramInt1), new Object[0]).setCallback(new GetPercentilesJniResponseHandler(paramInt2, paramLong));
  }
  
  public static AGResponseHandle<GetLeaderboardPercentilesResponse> getPercentilesHandle(String paramString1, String paramString2, int paramInt1, int paramInt2) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "getPercentilesHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_LeaderboardsClient.getPercentileRanksForPlayer(paramString1, paramString2, LeaderboardFilter.fromOrdinal(paramInt1), new Object[] { Integer.valueOf(paramInt2) });
  }
  
  public static void initializeNativeHandler(AmazonGamesClient paramAmazonGamesClient) {
    m_LeaderboardsClient = paramAmazonGamesClient.getLeaderboardsClient();
  }
  
  public static void requestLeaderboards(int paramInt, long paramLong) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "requestLeaderboards - initializeJni was not called beforehand.");
      return;
    } 
    m_LeaderboardsClient.getLeaderboards(new Object[0]).setCallback(new GetLbsJniResponseHandler(paramInt, paramLong));
  }
  
  public static AGResponseHandle<GetLeaderboardsResponse> requestLeaderboardsHandle(int paramInt) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "requestLeaderboardsHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_LeaderboardsClient.getLeaderboards(new Object[] { Integer.valueOf(paramInt) });
  }
  
  public static void requestLocalPlayerScore(String paramString1, String paramString2, int paramInt1, int paramInt2, long paramLong) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "requestLocalPlayerScore - initializeJni was not called beforehand.");
      return;
    } 
    m_LeaderboardsClient.getScoreForPlayer(paramString1, paramString2, LeaderboardFilter.fromOrdinal(paramInt1), new Object[0]).setCallback(new GetScoreJniResponseHandler(paramString1, paramInt2, paramLong));
  }
  
  public static AGResponseHandle<GetPlayerScoreResponse> requestLocalPlayerScoreHandle(String paramString1, String paramString2, int paramInt1, int paramInt2) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "requestLocalPlayerScoreHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_LeaderboardsClient.getScoreForPlayer(paramString1, paramString2, LeaderboardFilter.fromOrdinal(paramInt1), new Object[] { Integer.valueOf(paramInt2) });
  }
  
  public static void requestScores(String paramString, int paramInt1, int paramInt2, long paramLong) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "requestScores - initializeJni was not called beforehand.");
      return;
    } 
    m_LeaderboardsClient.getScores(paramString, LeaderboardFilter.fromOrdinal(paramInt1), new Object[0]).setCallback(new GetScoresJniResponseHandler(paramInt2, paramLong));
  }
  
  public static AGResponseHandle<GetScoresResponse> requestScoresHandle(String paramString, int paramInt1, int paramInt2) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "requestScoresHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_LeaderboardsClient.getScores(paramString, LeaderboardFilter.fromOrdinal(paramInt1), new Object[] { Integer.valueOf(paramInt2) });
  }
  
  public static AGResponseHandle<RequestResponse> showLeaderboardOverlay(String paramString) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "showLeaderboardOverlay - initializeJni was not called beforehand.");
      return null;
    } 
    return m_LeaderboardsClient.showLeaderboardOverlay(paramString, new Object[0]);
  }
  
  public static AGResponseHandle<RequestResponse> showLeaderboardsOverlay() {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "showLeaderboardsOverlay - initializeJni was not called beforehand.");
      return null;
    } 
    return m_LeaderboardsClient.showLeaderboardsOverlay(new Object[0]);
  }
  
  public static void submitLeaderboardScore(String paramString, long paramLong1, int paramInt, long paramLong2) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "submitLeaderboardScore - initializeJni was not called beforehand.");
      return;
    } 
    m_LeaderboardsClient.submitScore(paramString, paramLong1, new Object[0]).setCallback(new SubmitScoreJniResponseHandler(paramInt, paramLong2));
  }
  
  public static AGResponseHandle<SubmitScoreResponse> submitLeaderboardScoreHandle(String paramString, long paramLong, int paramInt) {
    if (m_LeaderboardsClient == null) {
      Log.e(TAG, "submitLeaderboardScoreHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_LeaderboardsClient.submitScore(paramString, paramLong, new Object[] { Integer.valueOf(paramInt) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\leaderboards\LeaderboardsNativeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */