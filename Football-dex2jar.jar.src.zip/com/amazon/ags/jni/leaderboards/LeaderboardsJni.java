package com.amazon.ags.jni.leaderboards;

import com.amazon.ags.api.leaderboards.GetLeaderboardPercentilesResponse;
import com.amazon.ags.api.leaderboards.GetLeaderboardsResponse;
import com.amazon.ags.api.leaderboards.GetPlayerScoreResponse;
import com.amazon.ags.api.leaderboards.GetScoresResponse;
import com.amazon.ags.api.leaderboards.SubmitScoreResponse;

public class LeaderboardsJni {
  public static native void getLeaderboardsResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void getLeaderboardsResponseSuccess(GetLeaderboardsResponse paramGetLeaderboardsResponse, long paramLong, int paramInt);
  
  public static native void getPercentilesResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void getPercentilesResponseSuccess(GetLeaderboardPercentilesResponse paramGetLeaderboardPercentilesResponse, long paramLong, int paramInt);
  
  public static native void getPlayerScoreResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void getPlayerScoreResponseSuccess(GetPlayerScoreResponse paramGetPlayerScoreResponse, String paramString, long paramLong, int paramInt);
  
  public static native void getScoresResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void getScoresResponseSuccess(GetScoresResponse paramGetScoresResponse, long paramLong, int paramInt);
  
  public static native void submitScoreResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void submitScoreResponseSuccess(SubmitScoreResponse paramSubmitScoreResponse, long paramLong, int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\leaderboards\LeaderboardsJni.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */