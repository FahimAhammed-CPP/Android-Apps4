package com.amazon.ags.jni.leaderboards;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.leaderboards.GetLeaderboardPercentilesResponse;
import com.amazon.ags.jni.JniResponseHandler;

public class GetPercentilesJniResponseHandler extends JniResponseHandler implements AGResponseCallback<GetLeaderboardPercentilesResponse> {
  private static String LOG_TAG = "GetPercentilesJniResponseHandler";
  
  public GetPercentilesJniResponseHandler(int paramInt, long paramLong) {
    super(paramInt, paramLong);
  }
  
  public void onComplete(GetLeaderboardPercentilesResponse paramGetLeaderboardPercentilesResponse) {
    if (paramGetLeaderboardPercentilesResponse.isError()) {
      Log.d(LOG_TAG, "jniGetPercentiles response - onFailure");
      LeaderboardsJni.getPercentilesResponseFailure(this.m_CallbackPointer, paramGetLeaderboardPercentilesResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(LOG_TAG, "jniGetPercentiles response - onSuccess");
    LeaderboardsJni.getPercentilesResponseSuccess(paramGetLeaderboardPercentilesResponse, this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\leaderboards\GetPercentilesJniResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */