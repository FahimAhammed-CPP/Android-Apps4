package com.amazon.ags.jni.leaderboards;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.leaderboards.GetScoresResponse;
import com.amazon.ags.jni.JniResponseHandler;

public class GetScoresJniResponseHandler extends JniResponseHandler implements AGResponseCallback<GetScoresResponse> {
  private static String LOG_TAG = "RequestScoresJniResponseHandler";
  
  public GetScoresJniResponseHandler(int paramInt, long paramLong) {
    super(paramInt, paramLong);
  }
  
  public void onComplete(GetScoresResponse paramGetScoresResponse) {
    if (paramGetScoresResponse.isError()) {
      Log.d(LOG_TAG, "jniRequestScores response - onFailure");
      LeaderboardsJni.getScoresResponseFailure(this.m_CallbackPointer, paramGetScoresResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(LOG_TAG, "jniRequestScores response - onSuccess");
    LeaderboardsJni.getScoresResponseSuccess(paramGetScoresResponse, this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\leaderboards\GetScoresJniResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */