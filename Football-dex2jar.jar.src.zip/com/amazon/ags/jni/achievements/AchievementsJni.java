package com.amazon.ags.jni.achievements;

import com.amazon.ags.api.achievements.GetAchievementResponse;
import com.amazon.ags.api.achievements.GetAchievementsResponse;
import com.amazon.ags.api.achievements.UpdateProgressResponse;

public class AchievementsJni {
  public static native void getAchievementResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void getAchievementResponseSuccess(GetAchievementResponse paramGetAchievementResponse, long paramLong, int paramInt);
  
  public static native void getAchievementsResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void getAchievementsResponseSuccess(GetAchievementsResponse paramGetAchievementsResponse, long paramLong, int paramInt);
  
  public static native void updateProgressResponseFailure(long paramLong, int paramInt1, int paramInt2);
  
  public static native void updateProgressResponseSuccess(UpdateProgressResponse paramUpdateProgressResponse, String paramString, long paramLong, int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\achievements\AchievementsJni.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */