package com.amazon.ags.jni.achievements;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.achievements.UpdateProgressResponse;
import com.amazon.ags.jni.JniResponseHandler;

public class UpdateProgressJniRespHandler extends JniResponseHandler implements AGResponseCallback<UpdateProgressResponse> {
  private static String LOG_TAG = "UpdateProgressJniRespHandler";
  
  private String m_AchievementId;
  
  public UpdateProgressJniRespHandler(String paramString, int paramInt, long paramLong) {
    super(paramInt, paramLong);
    this.m_AchievementId = paramString;
  }
  
  public void onComplete(UpdateProgressResponse paramUpdateProgressResponse) {
    if (paramUpdateProgressResponse.isError()) {
      Log.d(LOG_TAG, "jniUpdateProgress response - onFailure");
      AchievementsJni.updateProgressResponseFailure(this.m_CallbackPointer, paramUpdateProgressResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(LOG_TAG, "jniUpdateProgress response - onSuccess");
    AchievementsJni.updateProgressResponseSuccess(paramUpdateProgressResponse, this.m_AchievementId, this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\achievements\UpdateProgressJniRespHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */