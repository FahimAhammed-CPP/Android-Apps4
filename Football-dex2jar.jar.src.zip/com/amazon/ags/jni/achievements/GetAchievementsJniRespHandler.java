package com.amazon.ags.jni.achievements;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.achievements.GetAchievementsResponse;
import com.amazon.ags.jni.JniResponseHandler;

public class GetAchievementsJniRespHandler extends JniResponseHandler implements AGResponseCallback<GetAchievementsResponse> {
  private static String LOG_TAG = "ReqAchievementsJniRespHandler";
  
  public GetAchievementsJniRespHandler(int paramInt, long paramLong) {
    super(paramInt, paramLong);
  }
  
  public void onComplete(GetAchievementsResponse paramGetAchievementsResponse) {
    if (paramGetAchievementsResponse.isError()) {
      Log.d(LOG_TAG, "jniRequestAchievements response - onFailure");
      AchievementsJni.getAchievementsResponseFailure(this.m_CallbackPointer, paramGetAchievementsResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(LOG_TAG, "jniRequestAchievements response - onSuccess");
    AchievementsJni.getAchievementsResponseSuccess(paramGetAchievementsResponse, this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\achievements\GetAchievementsJniRespHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */