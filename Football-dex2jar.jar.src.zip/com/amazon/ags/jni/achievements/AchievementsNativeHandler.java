package com.amazon.ags.jni.achievements;

import android.util.Log;
import com.amazon.ags.api.AGResponseHandle;
import com.amazon.ags.api.AmazonGamesClient;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.achievements.AchievementsClient;
import com.amazon.ags.api.achievements.GetAchievementResponse;
import com.amazon.ags.api.achievements.GetAchievementsResponse;
import com.amazon.ags.api.achievements.UpdateProgressResponse;

public class AchievementsNativeHandler {
  private static String TAG = "AchievementsNativeHandler";
  
  private static AchievementsClient m_AchievementsClient = null;
  
  public static void initializeNativeHandler(AmazonGamesClient paramAmazonGamesClient) {
    m_AchievementsClient = paramAmazonGamesClient.getAchievementsClient();
  }
  
  public static void requestAchievement(String paramString1, String paramString2, int paramInt, long paramLong) {
    if (m_AchievementsClient == null) {
      Log.e(TAG, "requestAchievement - initializeJni was not called beforehand.");
      return;
    } 
    m_AchievementsClient.getAchievementForPlayer(paramString1, paramString2, new Object[] { Integer.valueOf(paramInt) }).setCallback(new GetAchievementJniRespHandler(paramInt, paramLong));
  }
  
  public static AGResponseHandle<GetAchievementResponse> requestAchievementHandle(String paramString1, String paramString2, int paramInt) {
    if (m_AchievementsClient == null) {
      Log.e(TAG, "requestAchievementHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_AchievementsClient.getAchievementForPlayer(paramString1, paramString2, new Object[] { Integer.valueOf(paramInt) });
  }
  
  public static void requestAchievements(String paramString, int paramInt, long paramLong) {
    if (m_AchievementsClient == null) {
      Log.e(TAG, "requestAchievements - initializeJni was not called beforehand.");
      return;
    } 
    m_AchievementsClient.getAchievementsForPlayer(paramString, new Object[] { Integer.valueOf(paramInt) }).setCallback(new GetAchievementsJniRespHandler(paramInt, paramLong));
  }
  
  public static AGResponseHandle<GetAchievementsResponse> requestAchievementsHandle(String paramString, int paramInt) {
    if (m_AchievementsClient == null) {
      Log.e(TAG, "requestAchievementsHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_AchievementsClient.getAchievementsForPlayer(paramString, new Object[] { Integer.valueOf(paramInt) });
  }
  
  public static AGResponseHandle<RequestResponse> showAchievementsOverlay() {
    if (m_AchievementsClient == null) {
      Log.e(TAG, "showAchievementsOverlay - initializeJni was not called beforehand.");
      return null;
    } 
    return m_AchievementsClient.showAchievementsOverlay(new Object[0]);
  }
  
  public static void updateProgress(String paramString, float paramFloat, int paramInt, long paramLong) {
    if (m_AchievementsClient == null) {
      Log.e(TAG, "updateProgress - initializeJni was not called beforehand.");
      return;
    } 
    m_AchievementsClient.updateProgress(paramString, paramFloat, new Object[0]).setCallback(new UpdateProgressJniRespHandler(paramString, paramInt, paramLong));
  }
  
  public static AGResponseHandle<UpdateProgressResponse> updateProgressHandle(String paramString, float paramFloat, int paramInt) {
    if (m_AchievementsClient == null) {
      Log.e(TAG, "updateProgressHandle - initializeJni was not called beforehand.");
      return null;
    } 
    return m_AchievementsClient.updateProgress(paramString, paramFloat, new Object[] { Integer.valueOf(paramInt) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\achievements\AchievementsNativeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */