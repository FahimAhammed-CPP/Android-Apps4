package com.amazon.ags.jni.achievements;

import android.util.Log;
import com.amazon.ags.api.AGResponseCallback;
import com.amazon.ags.api.RequestResponse;
import com.amazon.ags.api.achievements.GetAchievementResponse;
import com.amazon.ags.jni.JniResponseHandler;

public class GetAchievementJniRespHandler extends JniResponseHandler implements AGResponseCallback<GetAchievementResponse> {
  private static String LOG_TAG = "ReqAchievementJniRespHandler";
  
  public GetAchievementJniRespHandler(int paramInt, long paramLong) {
    super(paramInt, paramLong);
  }
  
  public void onComplete(GetAchievementResponse paramGetAchievementResponse) {
    if (paramGetAchievementResponse.isError()) {
      Log.d(LOG_TAG, "jniRequestAchievement response - onFailure");
      AchievementsJni.getAchievementResponseFailure(this.m_CallbackPointer, paramGetAchievementResponse.getError().ordinal(), this.m_DeveloperTag);
      return;
    } 
    Log.d(LOG_TAG, "jniRequestAchievement response - onSuccess");
    AchievementsJni.getAchievementResponseSuccess(paramGetAchievementResponse, this.m_CallbackPointer, this.m_DeveloperTag);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\achievements\GetAchievementJniRespHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */