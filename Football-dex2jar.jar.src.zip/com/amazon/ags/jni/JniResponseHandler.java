package com.amazon.ags.jni;

public abstract class JniResponseHandler {
  protected long m_CallbackPointer;
  
  protected int m_DeveloperTag;
  
  public JniResponseHandler(int paramInt, long paramLong) {
    this.m_DeveloperTag = paramInt;
    this.m_CallbackPointer = paramLong;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\JniResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */