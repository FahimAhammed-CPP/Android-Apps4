package com.amazon.ags.jni.whispersync;

import android.util.Log;
import com.amazon.ags.api.AmazonGamesClient;
import com.amazon.ags.api.whispersync.GameDataMap;
import com.amazon.ags.api.whispersync.WhispersyncClient;
import com.amazon.ags.api.whispersync.model.SyncableNumber;
import com.amazon.ags.api.whispersync.model.SyncableNumberElement;
import com.amazon.ags.api.whispersync.model.SyncableNumberList;
import com.amazon.ags.api.whispersync.model.SyncableStringElement;
import com.amazon.ags.api.whispersync.model.SyncableStringList;
import java.util.Iterator;
import java.util.Set;

public class WhispersyncNativeHandler {
  private static final String TAG = "GC_Whispersync_JNI";
  
  private static WhispersyncClient whispersyncClient;
  
  public static boolean containsNumber(String paramString, int paramInt) {
    Log.d("GC_Whispersync_JNI", "containsNumber(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumber = gameDataMap.getHighestNumber(getLowestLevelKey(paramString));
        return syncableNumber.isSet();
      case LOWEST:
        syncableNumber = gameDataMap.getLowestNumber(getLowestLevelKey((String)syncableNumber));
        return syncableNumber.isSet();
      case LATEST:
        break;
    } 
    SyncableNumber syncableNumber = gameDataMap.getLatestNumber(getLowestLevelKey((String)syncableNumber));
    return syncableNumber.isSet();
  }
  
  public static boolean containsString(String paramString) {
    Log.d("GC_Whispersync_JNI", "containsString(" + paramString + ")");
    return getLowestLevelMap(paramString).getLatestString(getLowestLevelKey(paramString)).isSet();
  }
  
  public static void decrementAccumulatingNumber(String paramString, double paramDouble) {
    Log.d("GC_Whispersync_JNI", "decrementAccumulatingNumber(" + paramString + "," + paramDouble + ")");
    getLowestLevelMap(paramString).getAccumulatingNumber(getLowestLevelKey(paramString)).decrement(paramDouble);
  }
  
  public static void decrementAccumulatingNumber(String paramString, long paramLong) {
    Log.d("GC_Whispersync_JNI", "decrementAccumulatingNumber(" + paramString + "," + paramLong + ")");
    getLowestLevelMap(paramString).getAccumulatingNumber(getLowestLevelKey(paramString)).decrement(paramLong);
  }
  
  public static void decrementAccumulatingNumber(String paramString1, String paramString2) {
    Log.d("GC_Whispersync_JNI", "decrementAccumulatingNumber(" + paramString1 + "," + paramString2 + ")");
    getLowestLevelMap(paramString1).getAccumulatingNumber(getLowestLevelKey(paramString1)).decrement(paramString2);
  }
  
  public static void flush() {
    whispersyncClient.flush();
  }
  
  public static String getAccumulatingNumberAsBigDecimal(String paramString) {
    Log.d("GC_Whispersync_JNI", "getAccumulatingNumberAsBigDecimal(" + paramString + ")");
    return getLowestLevelMap(paramString).getAccumulatingNumber(getLowestLevelKey(paramString)).asDecimal().toPlainString();
  }
  
  public static double getAccumulatingNumberAsDouble(String paramString) {
    Log.d("GC_Whispersync_JNI", "getAccumulatingNumberAsDouble(" + paramString + ")");
    return getLowestLevelMap(paramString).getAccumulatingNumber(getLowestLevelKey(paramString)).asDouble();
  }
  
  public static long getAccumulatingNumberAsLong(String paramString) {
    Log.d("GC_Whispersync_JNI", "getAccumulatingNumberAsLong(" + paramString + ")");
    return getLowestLevelMap(paramString).getAccumulatingNumber(getLowestLevelKey(paramString)).asLong();
  }
  
  protected static final GameDataMap getLowestLevelElementAsMap(String paramString) {
    String[] arrayOfString = paramString.split("/");
    GameDataMap gameDataMap = whispersyncClient.getGameData();
    for (int i = 0; i < arrayOfString.length; i++)
      gameDataMap = gameDataMap.getMap(arrayOfString[i]); 
    return gameDataMap;
  }
  
  protected static String getLowestLevelKey(String paramString) {
    String[] arrayOfString = paramString.split("/");
    return arrayOfString[arrayOfString.length - 1];
  }
  
  protected static GameDataMap getLowestLevelMap(String paramString) {
    String[] arrayOfString = paramString.split("/");
    GameDataMap gameDataMap = whispersyncClient.getGameData();
    for (int i = 0; i < arrayOfString.length - 1; i++)
      gameDataMap = gameDataMap.getMap(arrayOfString[i]); 
    return gameDataMap;
  }
  
  public static final String[] getMapKeys(String paramString) {
    Set set = getLowestLevelElementAsMap(paramString).getMapKeys();
    Log.d("GC_Whispersync_JNI", "getMapKeys(" + paramString + ") --> " + set);
    return (String[])set.toArray((Object[])new String[set.size()]);
  }
  
  public static int getMaxSizeNumberList(String paramString, int paramInt) {
    Log.d("GC_Whispersync_JNI", "getMaxSizeNumberList(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumberList = gameDataMap.getHighNumberList(getLowestLevelKey(paramString));
        return syncableNumberList.getMaxSize();
      case LOWEST:
        syncableNumberList = gameDataMap.getLowNumberList(getLowestLevelKey((String)syncableNumberList));
        return syncableNumberList.getMaxSize();
      case LATEST:
        break;
    } 
    SyncableNumberList syncableNumberList = gameDataMap.getLatestNumberList(getLowestLevelKey((String)syncableNumberList));
    return syncableNumberList.getMaxSize();
  }
  
  public static int getMaxSizeStringList(String paramString) {
    Log.d("GC_Whispersync_JNI", "getMaxSizeStringList(" + paramString + ")");
    return getLowestLevelMap(paramString).getLatestStringList(getLowestLevelKey(paramString)).getMaxSize();
  }
  
  public static String getNumberAsBigDecimal(String paramString, int paramInt) {
    Log.d("GC_Whispersync_JNI", "getNumberAsBigDecimal(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumber = gameDataMap.getHighestNumber(getLowestLevelKey(paramString));
        return syncableNumber.asDecimal().toPlainString();
      case LOWEST:
        syncableNumber = gameDataMap.getLowestNumber(getLowestLevelKey((String)syncableNumber));
        return syncableNumber.asDecimal().toPlainString();
      case LATEST:
        break;
    } 
    SyncableNumber syncableNumber = gameDataMap.getLatestNumber(getLowestLevelKey((String)syncableNumber));
    return syncableNumber.asDecimal().toPlainString();
  }
  
  public static double getNumberAsDouble(String paramString, int paramInt) {
    Log.d("GC_Whispersync_JNI", "getNumberAsDouble(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumber = gameDataMap.getHighestNumber(getLowestLevelKey(paramString));
        return syncableNumber.asDouble();
      case LOWEST:
        syncableNumber = gameDataMap.getLowestNumber(getLowestLevelKey((String)syncableNumber));
        return syncableNumber.asDouble();
      case LATEST:
        break;
    } 
    SyncableNumber syncableNumber = gameDataMap.getLatestNumber(getLowestLevelKey((String)syncableNumber));
    return syncableNumber.asDouble();
  }
  
  public static long getNumberAsLong(String paramString, int paramInt) {
    Log.d("GC_Whispersync_JNI", "getNumberAsLong(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumber = gameDataMap.getHighestNumber(getLowestLevelKey(paramString));
        return syncableNumber.asLong();
      case LOWEST:
        syncableNumber = gameDataMap.getLowestNumber(getLowestLevelKey((String)syncableNumber));
        return syncableNumber.asLong();
      case LATEST:
        break;
    } 
    SyncableNumber syncableNumber = gameDataMap.getLatestNumber(getLowestLevelKey((String)syncableNumber));
    return syncableNumber.asLong();
  }
  
  private static String[] getNumberListAsBigDecimal(SyncableNumberList paramSyncableNumberList) {
    SyncableNumberElement[] arrayOfSyncableNumberElement = paramSyncableNumberList.getValues();
    String[] arrayOfString = new String[arrayOfSyncableNumberElement.length];
    for (int i = 0; i < arrayOfSyncableNumberElement.length; i++)
      arrayOfString[i] = arrayOfSyncableNumberElement[i].asDecimal().toPlainString(); 
    return arrayOfString;
  }
  
  public static String[] getNumberListAsBigDecimals(String paramString, int paramInt) {
    Log.d("GC_Whispersync_JNI", "getNumberListAsBigDecimals(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumberList = gameDataMap.getHighNumberList(getLowestLevelKey(paramString));
        return getNumberListAsBigDecimal(syncableNumberList);
      case LOWEST:
        syncableNumberList = gameDataMap.getLowNumberList(getLowestLevelKey((String)syncableNumberList));
        return getNumberListAsBigDecimal(syncableNumberList);
      case LATEST:
        break;
    } 
    SyncableNumberList syncableNumberList = gameDataMap.getLatestNumberList(getLowestLevelKey((String)syncableNumberList));
    return getNumberListAsBigDecimal(syncableNumberList);
  }
  
  private static double[] getNumberListAsDouble(SyncableNumberList paramSyncableNumberList) {
    SyncableNumberElement[] arrayOfSyncableNumberElement = paramSyncableNumberList.getValues();
    double[] arrayOfDouble = new double[arrayOfSyncableNumberElement.length];
    for (int i = 0; i < arrayOfSyncableNumberElement.length; i++)
      arrayOfDouble[i] = arrayOfSyncableNumberElement[i].asDouble(); 
    return arrayOfDouble;
  }
  
  public static double[] getNumberListAsDoubles(String paramString, int paramInt) {
    Log.d("GC_Whispersync_JNI", "getNumberListAsDoubles(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumberList = gameDataMap.getHighNumberList(getLowestLevelKey(paramString));
        return getNumberListAsDouble(syncableNumberList);
      case LOWEST:
        syncableNumberList = gameDataMap.getLowNumberList(getLowestLevelKey((String)syncableNumberList));
        return getNumberListAsDouble(syncableNumberList);
      case LATEST:
        break;
    } 
    SyncableNumberList syncableNumberList = gameDataMap.getLatestNumberList(getLowestLevelKey((String)syncableNumberList));
    return getNumberListAsDouble(syncableNumberList);
  }
  
  private static long[] getNumberListAsLong(SyncableNumberList paramSyncableNumberList) {
    SyncableNumberElement[] arrayOfSyncableNumberElement = paramSyncableNumberList.getValues();
    long[] arrayOfLong = new long[arrayOfSyncableNumberElement.length];
    for (int i = 0; i < arrayOfSyncableNumberElement.length; i++)
      arrayOfLong[i] = arrayOfSyncableNumberElement[i].asLong(); 
    return arrayOfLong;
  }
  
  public static long[] getNumberListAsLongs(String paramString, int paramInt) {
    Log.d("GC_Whispersync_JNI", "getNumberListAsLongs(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumberList = gameDataMap.getHighNumberList(getLowestLevelKey(paramString));
        return getNumberListAsLong(syncableNumberList);
      case LOWEST:
        syncableNumberList = gameDataMap.getLowNumberList(getLowestLevelKey((String)syncableNumberList));
        return getNumberListAsLong(syncableNumberList);
      case LATEST:
        break;
    } 
    SyncableNumberList syncableNumberList = gameDataMap.getLatestNumberList(getLowestLevelKey((String)syncableNumberList));
    return getNumberListAsLong(syncableNumberList);
  }
  
  public static String getString(String paramString) {
    Log.d("GC_Whispersync_JNI", "getString(" + paramString + ")");
    return getLowestLevelMap(paramString).getLatestString(getLowestLevelKey(paramString)).getValue();
  }
  
  private static String[] getStringList(SyncableStringList paramSyncableStringList) {
    SyncableStringElement[] arrayOfSyncableStringElement = paramSyncableStringList.getValues();
    String[] arrayOfString = new String[arrayOfSyncableStringElement.length];
    for (int i = 0; i < arrayOfSyncableStringElement.length; i++)
      arrayOfString[i] = arrayOfSyncableStringElement[i].getValue(); 
    return arrayOfString;
  }
  
  public static String[] getStringList(String paramString) {
    Log.d("GC_Whispersync_JNI", "getStringList(" + paramString + ")");
    return getStringList(getLowestLevelMap(paramString).getLatestStringList(getLowestLevelKey(paramString)));
  }
  
  public static String[] getStringListKeys(String paramString) {
    Log.d("GC_Whispersync_JNI", "getStringListKeys(" + paramString + ")");
    Set set = getLowestLevelElementAsMap(paramString).getLatestStringListKeys();
    return (String[])set.toArray((Object[])new String[set.size()]);
  }
  
  public static String[] getStringSet(String paramString) {
    Log.d("GC_Whispersync_JNI", "getStringSet(" + paramString + ")");
    return getStringSet(getLowestLevelMap(paramString).getStringSet(getLowestLevelKey(paramString)).getValues());
  }
  
  private static String[] getStringSet(Set<SyncableStringElement> paramSet) {
    String[] arrayOfString = new String[paramSet.size()];
    int i = 0;
    Iterator<SyncableStringElement> iterator = paramSet.iterator();
    while (iterator.hasNext()) {
      arrayOfString[i] = ((SyncableStringElement)iterator.next()).getValue();
      i++;
    } 
    return arrayOfString;
  }
  
  public static String[] getStringSetKeys(String paramString) {
    Log.d("GC_Whispersync_JNI", "getStringSetKeys(" + paramString + ")");
    Set set = getLowestLevelElementAsMap(paramString).getStringSetKeys();
    return (String[])set.toArray((Object[])new String[set.size()]);
  }
  
  public static void incrementAccumulatingNumber(String paramString, double paramDouble) {
    Log.d("GC_Whispersync_JNI", "incrementAccumulatingNumber(" + paramString + "," + paramDouble + ")");
    getLowestLevelMap(paramString).getAccumulatingNumber(getLowestLevelKey(paramString)).increment(paramDouble);
  }
  
  public static void incrementAccumulatingNumber(String paramString, long paramLong) {
    Log.d("GC_Whispersync_JNI", "incrementAccumulatingNumber(" + paramString + ")");
    getLowestLevelMap(paramString).getAccumulatingNumber(getLowestLevelKey(paramString)).increment(paramLong);
  }
  
  public static void incrementAccumulatingNumber(String paramString1, String paramString2) {
    Log.d("GC_Whispersync_JNI", "incrementAccumulatingNumber(" + paramString1 + "," + paramString2 + ")");
    getLowestLevelMap(paramString1).getAccumulatingNumber(getLowestLevelKey(paramString1)).increment(paramString2);
  }
  
  public static void initializeNativeHandler() {
    whispersyncClient = AmazonGamesClient.getWhispersyncClient();
  }
  
  public static void insertToNumberList(String paramString, double paramDouble, int paramInt) {
    Log.d("GC_Whispersync_JNI", "insertToNumberList(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumberList = gameDataMap.getHighNumberList(getLowestLevelKey(paramString));
        syncableNumberList.add(paramDouble);
        return;
      case LOWEST:
        syncableNumberList = gameDataMap.getLowNumberList(getLowestLevelKey((String)syncableNumberList));
        syncableNumberList.add(paramDouble);
        return;
      case LATEST:
        break;
    } 
    SyncableNumberList syncableNumberList = gameDataMap.getLatestNumberList(getLowestLevelKey((String)syncableNumberList));
    syncableNumberList.add(paramDouble);
  }
  
  public static void insertToNumberList(String paramString, long paramLong, int paramInt) {
    Log.d("GC_Whispersync_JNI", "insertToNumberList(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumberList = gameDataMap.getHighNumberList(getLowestLevelKey(paramString));
        syncableNumberList.add(paramLong);
        return;
      case LOWEST:
        syncableNumberList = gameDataMap.getLowNumberList(getLowestLevelKey((String)syncableNumberList));
        syncableNumberList.add(paramLong);
        return;
      case LATEST:
        break;
    } 
    SyncableNumberList syncableNumberList = gameDataMap.getLatestNumberList(getLowestLevelKey((String)syncableNumberList));
    syncableNumberList.add(paramLong);
  }
  
  public static void insertToNumberList(String paramString1, String paramString2, int paramInt) {
    Log.d("GC_Whispersync_JNI", "insertToNumberList(" + paramString1 + "," + paramString2 + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString1);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumberList = gameDataMap.getHighNumberList(getLowestLevelKey(paramString1));
        syncableNumberList.add(paramString2);
        return;
      case LOWEST:
        syncableNumberList = gameDataMap.getLowNumberList(getLowestLevelKey((String)syncableNumberList));
        syncableNumberList.add(paramString2);
        return;
      case LATEST:
        break;
    } 
    SyncableNumberList syncableNumberList = gameDataMap.getLatestNumberList(getLowestLevelKey((String)syncableNumberList));
    syncableNumberList.add(paramString2);
  }
  
  public static void insertToStringList(String paramString1, String paramString2) {
    Log.d("GC_Whispersync_JNI", "insertToStringList(" + paramString1 + "," + paramString2 + ")");
    getLowestLevelMap(paramString1).getLatestStringList(getLowestLevelKey(paramString1)).add(paramString2);
  }
  
  public static void insertToStringSet(String paramString1, String paramString2) {
    Log.d("GC_Whispersync_JNI", "insertToStringSet(" + paramString1 + "," + paramString2 + ")");
    getLowestLevelMap(paramString1).getStringSet(getLowestLevelKey(paramString1)).add(paramString2);
  }
  
  public static void setMaxSizeNumberList(String paramString, int paramInt1, int paramInt2) {
    Log.d("GC_Whispersync_JNI", "setMaxSizeNumberList(" + paramString + "," + MergePolicy.mergePolicyFromInt(paramInt2) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt2);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt2 + "] is not supported");
      case HIGHEST:
        syncableNumberList = gameDataMap.getHighNumberList(getLowestLevelKey(paramString));
        syncableNumberList.setMaxSize(paramInt1);
        return;
      case LOWEST:
        syncableNumberList = gameDataMap.getLowNumberList(getLowestLevelKey((String)syncableNumberList));
        syncableNumberList.setMaxSize(paramInt1);
        return;
      case LATEST:
        break;
    } 
    SyncableNumberList syncableNumberList = gameDataMap.getLatestNumberList(getLowestLevelKey((String)syncableNumberList));
    syncableNumberList.setMaxSize(paramInt1);
  }
  
  public static void setMaxSizeStringList(String paramString, int paramInt) {
    Log.d("GC_Whispersync_JNI", "setMaxSizeStringList(" + paramString + ")");
    getLowestLevelMap(paramString).getLatestStringList(getLowestLevelKey(paramString)).setMaxSize(paramInt);
  }
  
  public static void setNumber(String paramString, double paramDouble, int paramInt) {
    Log.d("GC_Whispersync_JNI", "setNumber(" + paramString + "," + paramDouble + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumber = gameDataMap.getHighestNumber(getLowestLevelKey(paramString));
        syncableNumber.set(paramDouble);
        return;
      case LOWEST:
        syncableNumber = gameDataMap.getLowestNumber(getLowestLevelKey((String)syncableNumber));
        syncableNumber.set(paramDouble);
        return;
      case LATEST:
        break;
    } 
    SyncableNumber syncableNumber = gameDataMap.getLatestNumber(getLowestLevelKey((String)syncableNumber));
    syncableNumber.set(paramDouble);
  }
  
  public static void setNumber(String paramString, long paramLong, int paramInt) {
    Log.d("GC_Whispersync_JNI", "setNumber(" + paramString + "," + paramLong + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumber = gameDataMap.getHighestNumber(getLowestLevelKey(paramString));
        syncableNumber.set(paramLong);
        return;
      case LOWEST:
        syncableNumber = gameDataMap.getLowestNumber(getLowestLevelKey((String)syncableNumber));
        syncableNumber.set(paramLong);
        return;
      case LATEST:
        break;
    } 
    SyncableNumber syncableNumber = gameDataMap.getLatestNumber(getLowestLevelKey((String)syncableNumber));
    syncableNumber.set(paramLong);
  }
  
  public static void setNumber(String paramString1, String paramString2, int paramInt) {
    Log.d("GC_Whispersync_JNI", "setNumber(" + paramString1 + "," + paramString2 + "," + MergePolicy.mergePolicyFromInt(paramInt) + ")");
    GameDataMap gameDataMap = getLowestLevelMap(paramString1);
    MergePolicy mergePolicy = MergePolicy.mergePolicyFromInt(paramInt);
    switch (mergePolicy) {
      default:
        throw new UnsupportedOperationException("Merge policy [" + paramInt + "] is not supported");
      case HIGHEST:
        syncableNumber = gameDataMap.getHighestNumber(getLowestLevelKey(paramString1));
        syncableNumber.set(paramString2);
        return;
      case LOWEST:
        syncableNumber = gameDataMap.getLowestNumber(getLowestLevelKey((String)syncableNumber));
        syncableNumber.set(paramString2);
        return;
      case LATEST:
        break;
    } 
    SyncableNumber syncableNumber = gameDataMap.getLatestNumber(getLowestLevelKey((String)syncableNumber));
    syncableNumber.set(paramString2);
  }
  
  public static void setString(String paramString1, String paramString2) {
    Log.d("GC_Whispersync_JNI", "setString(" + paramString1 + "," + paramString2 + ")");
    getLowestLevelMap(paramString1).getLatestString(getLowestLevelKey(paramString1)).set(paramString2);
  }
  
  public static boolean stringSetContains(String paramString1, String paramString2) {
    Log.d("GC_Whispersync_JNI", "stringSetContains(" + paramString1 + "," + paramString2 + ")");
    return getLowestLevelMap(paramString1).getStringSet(getLowestLevelKey(paramString1)).contains(paramString2);
  }
  
  public static void synchronize() {
    whispersyncClient.synchronize();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\whispersync\WhispersyncNativeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */