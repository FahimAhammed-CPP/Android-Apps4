package com.amazon.ags.jni.whispersync;

public class WhispersyncJni {
  public static native void onNewCloudData();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\whispersync\WhispersyncJni.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */