package com.amazon.ags.jni.whispersync;

import java.util.HashMap;
import java.util.Map;

public enum MergePolicy {
  HIGHEST,
  LATEST,
  LOWEST,
  NONE(-1);
  
  private static Map<Integer, MergePolicy> mergePolicyMap;
  
  private final int value;
  
  static {
    HIGHEST = new MergePolicy("HIGHEST", 1, 0);
    LOWEST = new MergePolicy("LOWEST", 2, 1);
    LATEST = new MergePolicy("LATEST", 3, 2);
    $VALUES = new MergePolicy[] { NONE, HIGHEST, LOWEST, LATEST };
    mergePolicyMap = new HashMap<Integer, MergePolicy>();
    for (MergePolicy mergePolicy : values())
      mergePolicyMap.put(Integer.valueOf(mergePolicy.getValue()), mergePolicy); 
  }
  
  MergePolicy(int paramInt1) {
    this.value = paramInt1;
  }
  
  public static MergePolicy mergePolicyFromInt(int paramInt) {
    MergePolicy mergePolicy2 = mergePolicyMap.get(Integer.valueOf(paramInt));
    MergePolicy mergePolicy1 = mergePolicy2;
    if (mergePolicy2 == null)
      mergePolicy1 = NONE; 
    return mergePolicy1;
  }
  
  public int getValue() {
    return this.value;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\ags\jni\whispersync\MergePolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */