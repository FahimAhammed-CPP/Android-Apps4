package com.amazon.device.ads;

import java.util.Locale;

enum ForceOrientation {
  LANDSCAPE, NONE, PORTRAIT;
  
  static {
    LANDSCAPE = new ForceOrientation("LANDSCAPE", 1);
    NONE = new ForceOrientation("NONE", 2);
    $VALUES = new ForceOrientation[] { PORTRAIT, LANDSCAPE, NONE };
  }
  
  public String toString() {
    return name().toLowerCase(Locale.US);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ForceOrientation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */