package com.amazon.device.ads;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import java.util.concurrent.atomic.AtomicBoolean;

public class InterstitialAd implements Ad {
  protected static final String ACTION_INTERSTITIAL_DISMISSED = "dismissed";
  
  protected static final String ACTION_INTERSTITIAL_FINISHED_LOADING = "finished";
  
  protected static final String BROADCAST_ACTION = "action";
  
  protected static final String BROADCAST_CREATIVE = "creative";
  
  protected static final String BROADCAST_INTENT = "amazon.mobile.ads.interstitial";
  
  protected static final String BROADCAST_UNIQUE_IDENTIFIER_KEY = "uniqueIdentifier";
  
  private static final String LOG_TAG = "InterstitialAd";
  
  protected static final String MSG_PREPARE_AD_DESTROYED = "This interstitial ad has been destroyed and can no longer be used. Create a new InterstitialAd object to load a new ad.";
  
  protected static final String MSG_PREPARE_AD_LOADING = "An interstitial ad is currently loading. Please wait for the ad to finish loading and showing before loading another ad.";
  
  protected static final String MSG_PREPARE_AD_READY_TO_SHOW = "An interstitial ad is ready to show. Please call showAd() to show the ad before loading another ad.";
  
  protected static final String MSG_PREPARE_AD_SHOWING = "An interstitial ad is currently showing. Please wait for the user to dismiss the ad before loading an ad.";
  
  protected static final String MSG_SHOW_AD_ANOTHER_SHOWING = "Another interstitial ad is currently showing. Please wait for the InterstitialAdListener.onAdDismissed callback of the other ad.";
  
  protected static final String MSG_SHOW_AD_DESTROYED = "The interstitial ad cannot be shown because it has been destroyed. Create a new InterstitialAd object to load a new ad.";
  
  protected static final String MSG_SHOW_AD_DISMISSED = "The interstitial ad cannot be shown because it has already been displayed to the user. Please call loadAd(AdTargetingOptions) to load a new ad.";
  
  protected static final String MSG_SHOW_AD_EXPIRED = "This interstitial ad has expired. Please load another ad.";
  
  protected static final String MSG_SHOW_AD_LOADING = "The interstitial ad cannot be shown because it is still loading. Please wait for the AdListener.onAdLoaded() callback before showing the ad.";
  
  protected static final String MSG_SHOW_AD_READY_TO_LOAD = "The interstitial ad cannot be shown because it has not loaded successfully. Please call loadAd(AdTargetingOptions) to load an ad first.";
  
  protected static final String MSG_SHOW_AD_SHOWING = "The interstitial ad cannot be shown because it is already displayed on the screen. Please wait for the InterstitialAdListener.onAdDismissed() callback and then load a new ad.";
  
  private static final AtomicBoolean isAdShowing = new AtomicBoolean(false);
  
  private final Activity activity;
  
  private AdController adController;
  
  private AdListener adListener = null;
  
  private boolean isInitialized = false;
  
  private boolean isThisAdShowing = false;
  
  private int timeout = 20000;
  
  public InterstitialAd(Activity paramActivity) {
    if (paramActivity == null)
      throw new IllegalArgumentException("InterstitialAd requires a non-null Activity"); 
    this.activity = paramActivity;
  }
  
  private void callOnAdLoaded(AdProperties paramAdProperties) {
    this.adListener.onAdLoaded(this, paramAdProperties);
  }
  
  private void clearCachedAdController() {
    AdControllerFactory.removeCachedAdController();
  }
  
  private AdController getAdController() {
    initializeIfNecessary();
    if (this.adController == null)
      initializeAdController(); 
    return this.adController;
  }
  
  private MetricsCollector getMetricsCollector() {
    return getAdController().getMetricsCollector();
  }
  
  private void initializeAdController() {
    setAdController(createAdController(this.activity));
  }
  
  private void initializeIfNecessary() {
    if (isInitialized())
      return; 
    this.isInitialized = true;
    AmazonAdRegistration.initializeAdSDK(this.activity.getApplicationContext());
    if (this.adListener == null)
      this.adListener = new DefaultAdListener("InterstitialAd"); 
    initializeAdController();
    setAdditionalMetrics();
  }
  
  public static boolean isAdShowing() {
    return isAdShowing.get();
  }
  
  private boolean isInitialized() {
    return this.isInitialized;
  }
  
  static void resetIsAdShowing() {
    isAdShowing.set(false);
  }
  
  private void setAdController(AdController paramAdController) {
    this.adController = paramAdController;
    paramAdController.setCallback(constructAdControlCallback());
  }
  
  private void setAdditionalMetrics() {
    getMetricsCollector().setAdType(AdProperties.AdType.INTERSTITIAL);
    getMetricsCollector().incrementMetric(Metrics.MetricType.AD_IS_INTERSTITIAL);
  }
  
  void callOnAdDismissed() {
    this.adListener.onAdDismissed(this);
  }
  
  void callOnAdDismissedOnMainThread() {
    (new Handler(this.activity.getApplicationContext().getMainLooper())).post(new Runnable() {
          public void run() {
            InterstitialAd.this.callOnAdDismissed();
            InterstitialAd.this.submitAndResetMetrics();
          }
        });
  }
  
  void callOnAdFailedOnMainThread(final AdError error) {
    (new Handler(this.activity.getApplicationContext().getMainLooper())).post(new Runnable() {
          public void run() {
            InterstitialAd.this.callOnAdFailedToLoad(error);
          }
        });
  }
  
  void callOnAdFailedToLoad(AdError paramAdError) {
    this.adListener.onAdFailedToLoad(this, paramAdError);
  }
  
  void callOnAdLoadedOnMainThread(final AdProperties adProperties) {
    (new Handler(this.activity.getApplicationContext().getMainLooper())).post(new Runnable() {
          public void run() {
            InterstitialAd.this.callOnAdLoaded(adProperties);
          }
        });
  }
  
  AdControlCallback constructAdControlCallback() {
    return new InterstitialAdControlCallback();
  }
  
  AdController createAdController(Activity paramActivity) {
    return (new AdControllerFactory()).buildAdController((Context)paramActivity, AdSize.SIZE_INTERSTITIAL);
  }
  
  boolean didAdActivityFail() {
    boolean bool;
    if (this.isThisAdShowing && !isAdShowing.get()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      getMetricsCollector().incrementMetric(Metrics.MetricType.INTERSTITIAL_AD_ACTIVITY_FAILED);
      getAdController().closeAd();
    } 
    return bool;
  }
  
  AdListener getAdListener() {
    return this.adListener;
  }
  
  public int getTimeout() {
    return this.timeout;
  }
  
  void handleDismissed() {
    getMetricsCollector().stopMetric(Metrics.MetricType.AD_SHOW_DURATION);
    AdControllerFactory.removeCachedAdController();
    isAdShowing.set(false);
    this.isThisAdShowing = false;
    callOnAdDismissedOnMainThread();
  }
  
  public boolean isLoading() {
    return (getAdController().getAdState().equals(AdState.LOADING) || getAdController().getAdState().equals(AdState.LOADED) || getAdController().getAdState().equals(AdState.RENDERING));
  }
  
  boolean isReadyToLoad() {
    return getAdController().getAdState().equals(AdState.READY_TO_LOAD);
  }
  
  boolean isReadyToShow() {
    return getAdController().getAdState().equals(AdState.RENDERED);
  }
  
  public boolean isShowing() {
    return getAdController().getAdState().equals(AdState.SHOWING);
  }
  
  public boolean loadAd() {
    return loadAd(null);
  }
  
  public boolean loadAd(AdTargetingOptions paramAdTargetingOptions) {
    didAdActivityFail();
    if (!isReadyToLoad()) {
      switch (getAdController().getAdState()) {
        default:
          Log.d("InterstitialAd", "An interstitial ad is currently loading. Please wait for the ad to finish loading and showing before loading another ad.", new Object[0]);
          return false;
        case RENDERED:
          Log.d("InterstitialAd", "An interstitial ad is ready to show. Please call showAd() to show the ad before loading another ad.", new Object[0]);
          return false;
        case SHOWING:
          Log.d("InterstitialAd", "An interstitial ad is currently showing. Please wait for the user to dismiss the ad before loading an ad.", new Object[0]);
          return false;
        case INVALID:
          Log.e("InterstitialAd", "An interstitial ad could not be loaded because of an unknown issue with the web views.", new Object[0]);
          return false;
        case DESTROYED:
          break;
      } 
      Log.e("InterstitialAd", "An interstitial ad could not be loaded because the view has been destroyed.", new Object[0]);
      return false;
    } 
    AdLoader.loadAds(getTimeout(), paramAdTargetingOptions, new AdSlot[] { new AdSlot(getAdController(), paramAdTargetingOptions) });
    return getAdController().getAndResetIsPrepared();
  }
  
  public void setListener(AdListener paramAdListener) {
    if (paramAdListener == null) {
      this.adListener = new DefaultAdListener("InterstitialAd");
      return;
    } 
    this.adListener = paramAdListener;
  }
  
  public void setTimeout(int paramInt) {
    this.timeout = paramInt;
  }
  
  public boolean showAd() {
    if (didAdActivityFail()) {
      Log.e("InterstitialAd", "The ad could not be shown because it previously failed to show. Please load a new ad.", new Object[0]);
      return false;
    } 
    long l = System.nanoTime();
    if (isReadyToShow()) {
      if (getAdController().isExpired()) {
        Log.w("InterstitialAd", "This interstitial ad has expired. Please load another ad.", new Object[0]);
        getAdController().resetToReady();
        return false;
      } 
      if (isAdShowing.getAndSet(true)) {
        Log.w("InterstitialAd", "Another interstitial ad is currently showing. Please wait for the InterstitialAdListener.onAdDismissed callback of the other ad.", new Object[0]);
        return false;
      } 
      this.isThisAdShowing = true;
      getMetricsCollector().stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LOADED_TO_AD_SHOW_TIME, l);
      getMetricsCollector().startMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_SHOW_DURATION, l);
      AdControllerFactory.cacheAdController(getAdController());
      getMetricsCollector().startMetric(Metrics.MetricType.AD_SHOW_LATENCY);
      boolean bool2 = showAdInActivity();
      boolean bool1 = bool2;
      if (!bool2) {
        clearCachedAdController();
        getAdController().resetToReady();
        isAdShowing.set(false);
        this.isThisAdShowing = false;
        getMetricsCollector().stopMetric(Metrics.MetricType.AD_LATENCY_RENDER_FAILED);
        return bool2;
      } 
      return bool1;
    } 
    if (isReadyToLoad()) {
      Log.w("InterstitialAd", "The interstitial ad cannot be shown because it has not loaded successfully. Please call loadAd(AdTargetingOptions) to load an ad first.", new Object[0]);
      return false;
    } 
    if (isLoading()) {
      Log.w("InterstitialAd", "The interstitial ad cannot be shown because it is still loading. Please wait for the AdListener.onAdLoaded() callback before showing the ad.", new Object[0]);
      return false;
    } 
    if (isShowing()) {
      Log.w("InterstitialAd", "The interstitial ad cannot be shown because it is already displayed on the screen. Please wait for the InterstitialAdListener.onAdDismissed() callback and then load a new ad.", new Object[0]);
      return false;
    } 
    Log.w("InterstitialAd", "An interstitial ad is not ready to show.", new Object[0]);
    return false;
  }
  
  boolean showAdInActivity() {
    try {
      Intent intent = new Intent(this.activity.getApplicationContext(), AdActivity.class);
      intent.putExtra("adapter", InterstitialAdActivityAdapter.class.getName());
      this.activity.startActivity(intent);
      return true;
    } catch (ActivityNotFoundException activityNotFoundException) {
      Log.e("InterstitialAd", "Failed to show the interstitial ad because AdActivity could not be found.", new Object[0]);
      return false;
    } 
  }
  
  void submitAndResetMetrics() {
    if (getMetricsCollector() != null && !getMetricsCollector().isMetricsCollectorEmpty()) {
      setAdditionalMetrics();
      getAdController().submitAndResetMetricsIfNecessary(true);
    } 
  }
  
  class InterstitialAdControlCallback implements AdControlCallback {
    private AdProperties adProperties;
    
    public int adClosing() {
      InterstitialAd.this.handleDismissed();
      return 1;
    }
    
    public boolean isAdReady(boolean param1Boolean) {
      return InterstitialAd.this.isReadyToLoad();
    }
    
    public void onAdEvent(AdEvent param1AdEvent) {}
    
    public void onAdFailed(AdError param1AdError) {
      if (AdError.ErrorCode.NETWORK_TIMEOUT.equals(param1AdError.getCode()))
        InterstitialAd.access$302(InterstitialAd.this, null); 
      InterstitialAd.this.callOnAdFailedOnMainThread(param1AdError);
    }
    
    public void onAdLoaded(AdProperties param1AdProperties) {
      this.adProperties = param1AdProperties;
      InterstitialAd.this.setAdditionalMetrics();
      InterstitialAd.this.getAdController().enableNativeCloseButton(true, RelativePosition.TOP_RIGHT);
      InterstitialAd.this.getAdController().render();
    }
    
    public void onAdRendered() {
      InterstitialAd.this.callOnAdLoadedOnMainThread(this.adProperties);
    }
    
    public void postAdRendered() {
      InterstitialAd.this.getMetricsCollector().startMetric(Metrics.MetricType.AD_LOADED_TO_AD_SHOW_TIME);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\InterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */