package com.amazon.device.ads;

import org.json.JSONObject;

class SISUpdateDeviceInfoRequest extends SISDeviceRequest {
  private static final Metrics.MetricType CALL_METRIC_TYPE = Metrics.MetricType.SIS_LATENCY_UPDATE_DEVICE_INFO;
  
  private static final String LOG_TAG = "SISUpdateDeviceInfoRequest";
  
  private static final String PATH = "/update_dev_info";
  
  public SISUpdateDeviceInfoRequest() {
    setCallMetricType(CALL_METRIC_TYPE);
    setLogTag("SISUpdateDeviceInfoRequest");
    setPath("/update_dev_info");
  }
  
  public WebRequest.QueryStringParameters getQueryParameters() {
    String str = DebugProperties.getInstance().getDebugPropertyAsString("debug.adid", getAdvertisingIdentifierInfo().getSISDeviceIdentifier());
    WebRequest.QueryStringParameters queryStringParameters = super.getQueryParameters();
    if (!StringUtils.isNullOrEmpty(str))
      queryStringParameters.putUrlEncoded("adId", str); 
    return queryStringParameters;
  }
  
  public void onResponseReceived(JSONObject paramJSONObject) {
    String str = JSONUtils.getStringFromJSON(paramJSONObject, "adId", "");
    if (JSONUtils.getBooleanFromJSON(paramJSONObject, "idChanged", false))
      Metrics.getInstance().getMetricsCollector().incrementMetric(Metrics.MetricType.SIS_COUNTER_IDENTIFIED_DEVICE_CHANGED); 
    if (str.length() > 0)
      AmazonRegistration.getInstance().getRegistrationInfo().putAdId(str, getAdvertisingIdentifierInfo()); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\SISUpdateDeviceInfoRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */