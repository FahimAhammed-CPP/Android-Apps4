package com.amazon.device.ads;

import android.content.Context;

class AmazonAdRegistration {
  public static AmazonAdRegistration instance = new AmazonAdRegistration();
  
  private volatile boolean isInitialized = false;
  
  public static AmazonAdRegistration getInstance() {
    return instance;
  }
  
  public static void initializeAdSDK(Context paramContext) {
    getInstance().initializeAds(paramContext);
  }
  
  public void initializeAds(Context paramContext) {
    if (!this.isInitialized) {
      AmazonRegistration.getInstance().contextReceived(paramContext);
      AmazonRegistration.getInstance().getDeviceInfo().setUserAgentManager(new AdUserAgentManager());
      this.isInitialized = true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AmazonAdRegistration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */