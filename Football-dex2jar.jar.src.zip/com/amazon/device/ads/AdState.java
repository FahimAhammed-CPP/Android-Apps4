package com.amazon.device.ads;

enum AdState {
  DESTROYED, EXPANDED, HIDDEN, INVALID, LOADED, LOADING, READY_TO_LOAD, RENDERED, RENDERING, SHOWING;
  
  static {
    LOADING = new AdState("LOADING", 1);
    LOADED = new AdState("LOADED", 2);
    RENDERING = new AdState("RENDERING", 3);
    RENDERED = new AdState("RENDERED", 4);
    SHOWING = new AdState("SHOWING", 5);
    EXPANDED = new AdState("EXPANDED", 6);
    HIDDEN = new AdState("HIDDEN", 7);
    INVALID = new AdState("INVALID", 8);
    DESTROYED = new AdState("DESTROYED", 9);
    $VALUES = new AdState[] { READY_TO_LOAD, LOADING, LOADED, RENDERING, RENDERED, SHOWING, EXPANDED, HIDDEN, INVALID, DESTROYED };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */