package com.amazon.device.ads;

public interface Ad {
  int getTimeout();
  
  boolean isLoading();
  
  boolean loadAd();
  
  boolean loadAd(AdTargetingOptions paramAdTargetingOptions);
  
  void setListener(AdListener paramAdListener);
  
  void setTimeout(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */