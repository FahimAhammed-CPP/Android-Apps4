package com.amazon.device.ads;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;

class SISRegistration {
  private static final String LOG_TAG = SISRegistration.class.getSimpleName();
  
  protected static final long SIS_CHECKIN_INTERVAL = 86400000L;
  
  private static final String SIS_LAST_CHECKIN_PREF_NAME = "amzn-ad-sis-last-checkin";
  
  private static final ExecutorService executorService = Executors.newSingleThreadExecutor();
  
  private void putLastSISCheckin(long paramLong) {
    Settings.getInstance().putLong("amzn-ad-sis-last-checkin", paramLong);
  }
  
  protected boolean canRegister(long paramLong) {
    boolean bool = false;
    RegistrationInfo registrationInfo = AmazonRegistration.getInstance().getRegistrationInfo();
    if (exceededCheckinInterval(paramLong) || registrationInfo.shouldGetNewSISDeviceIdentifer() || registrationInfo.shouldGetNewSISRegistration() || DebugProperties.getInstance().getDebugPropertyAsBoolean("debug.shouldRegisterSIS", false))
      bool = true; 
    return bool;
  }
  
  protected AdvertisingIdentifier.Info createAdvertisingIdentifierInfo() {
    return (new AdvertisingIdentifier()).getAdvertisingIdentifierInfo();
  }
  
  protected boolean exceededCheckinInterval(long paramLong) {
    return (paramLong - getLastSISCheckin() > 86400000L);
  }
  
  protected long getLastSISCheckin() {
    return Settings.getInstance().getLong("amzn-ad-sis-last-checkin", 0L);
  }
  
  protected void register(AdvertisingIdentifier.Info paramInfo) {
    SISDeviceRequest sISDeviceRequest = (new SISGenerateDIDRequest()).setAdvertisingIdentifierInfo(paramInfo);
    (new SISRequestor(new RegisterEventsSISRequestorCallback(this), new SISRequest[] { sISDeviceRequest })).startCallSIS();
  }
  
  public void registerApp() {
    Runnable runnable = new Runnable() {
        public void run() {
          SISRegistration.this.waitForConfigurationThenBeginRegistration();
        }
      };
    executorService.submit(runnable);
  }
  
  void registerAppWorker() {
    long l = System.currentTimeMillis();
    AdvertisingIdentifier.Info info = createAdvertisingIdentifierInfo();
    if (info.canDo() && canRegister(l)) {
      putLastSISCheckin(l);
      if (shouldUpdateDeviceInfo()) {
        updateDeviceInfo(info);
        return;
      } 
    } else {
      return;
    } 
    register(info);
  }
  
  protected void registerEvents() {
    if (ThreadUtils.isOnMainThread()) {
      Log.e(LOG_TAG, "Registering events must be done on a background thread.", new Object[0]);
      return;
    } 
    AdvertisingIdentifier.Info info = (new AdvertisingIdentifier()).getAdvertisingIdentifierInfo();
    if (info.hasSISDeviceIdentifier()) {
      JSONArray jSONArray = AppEventRegistrationHandler.getInstance().getAppEventsJSONArray();
      if (jSONArray != null) {
        (new SISRequestor(new SISRequest[] { new SISRegisterEventRequest(info, jSONArray) })).startCallSIS();
        return;
      } 
    } 
  }
  
  protected boolean shouldUpdateDeviceInfo() {
    return AmazonRegistration.getInstance().getRegistrationInfo().isRegisteredWithSIS();
  }
  
  protected void updateDeviceInfo(AdvertisingIdentifier.Info paramInfo) {
    SISDeviceRequest sISDeviceRequest = (new SISUpdateDeviceInfoRequest()).setAdvertisingIdentifierInfo(paramInfo);
    (new SISRequestor(new RegisterEventsSISRequestorCallback(this), new SISRequest[] { sISDeviceRequest })).startCallSIS();
  }
  
  void waitForConfigurationThenBeginRegistration() {
    final CountDownLatch latch = new CountDownLatch(1);
    final AtomicBoolean canRegister = new AtomicBoolean(false);
    Configuration.getInstance().queueConfigurationListener(new Configuration.ConfigurationListener() {
          public void onConfigurationFailure() {
            Log.w(SISRegistration.LOG_TAG, "Configuration fetching failed so device registration will not proceed.", new Object[0]);
            latch.countDown();
          }
          
          public void onConfigurationReady() {
            canRegister.set(true);
            latch.countDown();
          }
        });
    try {
      countDownLatch.await();
    } catch (InterruptedException interruptedException) {}
    if (atomicBoolean.get())
      registerAppWorker(); 
  }
  
  protected static class RegisterEventsSISRequestorCallback implements SISRequestorCallback {
    private final SISRegistration sisRegistration;
    
    public RegisterEventsSISRequestorCallback(SISRegistration param1SISRegistration) {
      this.sisRegistration = param1SISRegistration;
    }
    
    public void onSISCallComplete() {
      this.sisRegistration.registerEvents();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\SISRegistration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */