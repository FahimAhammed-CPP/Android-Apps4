package com.amazon.device.ads;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

class ImageUtils {
  private static final String LOGTAG = ImageUtils.class.getSimpleName();
  
  private static GraphicsUtilsExecutor executor = new GraphicsUtilsExecutor();
  
  public static Bitmap createBitmapImage(InputStream paramInputStream) {
    return executor.createBitmapImage(paramInputStream);
  }
  
  public static String insertImageInMediaStore(Context paramContext, Bitmap paramBitmap, String paramString1, String paramString2) {
    return executor.insertImageInMediaStore(paramContext, paramBitmap, paramString1, paramString2);
  }
  
  public static class GraphicsUtilsExecutor {
    public Bitmap createBitmapImage(InputStream param1InputStream) {
      if (param1InputStream != null) {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(param1InputStream, 32768);
        bufferedInputStream.mark(32768);
        Bitmap bitmap = BitmapFactory.decodeStream(bufferedInputStream);
        try {
          bufferedInputStream.close();
        } catch (IOException iOException) {
          Log.e(ImageUtils.LOGTAG, "IOException while trying to close the input stream.");
        } 
        return bitmap;
      } 
      return null;
    }
    
    public String insertImageInMediaStore(Context param1Context, Bitmap param1Bitmap, String param1String1, String param1String2) {
      return MediaStore.Images.Media.insertImage(param1Context.getContentResolver(), param1Bitmap, param1String1, param1String2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ImageUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */