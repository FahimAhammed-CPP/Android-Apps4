package com.amazon.device.ads;

import android.content.Context;
import java.io.File;

class AmazonRegistration implements IAmazonRegistration {
  public static final String LOG_TAG = AmazonRegistration.class.getSimpleName();
  
  private static IAmazonRegistration instance = new AmazonRegistration(Settings.getInstance(), DebugProperties.getInstance());
  
  private AppInfo appInfo;
  
  protected Context applicationContext;
  
  private boolean contextReceived;
  
  private DeviceInfo deviceInfo;
  
  private File filesDirectory;
  
  private boolean isAppDisabled = false;
  
  private boolean isRegistered;
  
  private long noRetryTtlExpiresMillis;
  
  private int noRetryTtlMillis;
  
  private RegistrationInfo registrationInfo;
  
  private final Settings settings;
  
  private SISRegistration sisRegistration;
  
  protected AmazonRegistration(Settings paramSettings, DebugProperties paramDebugProperties) {
    this.settings = paramSettings;
    paramDebugProperties.readDebugProperties();
    this.registrationInfo = new RegistrationInfo();
  }
  
  public static IAmazonRegistration getInstance() {
    return instance;
  }
  
  static void setAmazonRegistration(IAmazonRegistration paramIAmazonRegistration) {
    instance = paramIAmazonRegistration;
  }
  
  public void contextReceived(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield contextReceived : Z
    //   6: ifne -> 50
    //   9: aload_0
    //   10: iconst_1
    //   11: putfield contextReceived : Z
    //   14: aload_0
    //   15: aload_1
    //   16: invokevirtual setApplicationContextFromContext : (Landroid/content/Context;)V
    //   19: aload_0
    //   20: aload_1
    //   21: invokevirtual setFilesDirectory : (Landroid/content/Context;)V
    //   24: aload_0
    //   25: getfield settings : Lcom/amazon/device/ads/Settings;
    //   28: aload_1
    //   29: invokevirtual contextReceived : (Landroid/content/Context;)V
    //   32: aload_0
    //   33: aload_1
    //   34: invokevirtual createAppInfo : (Landroid/content/Context;)V
    //   37: aload_0
    //   38: aload_0
    //   39: aload_1
    //   40: invokevirtual createDeviceInfo : (Landroid/content/Context;)Lcom/amazon/device/ads/DeviceInfo;
    //   43: putfield deviceInfo : Lcom/amazon/device/ads/DeviceInfo;
    //   46: aload_0
    //   47: invokevirtual createSISRegistration : ()V
    //   50: aload_0
    //   51: monitorexit
    //   52: return
    //   53: astore_1
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_1
    //   57: athrow
    // Exception table:
    //   from	to	target	type
    //   2	50	53	finally
  }
  
  protected void createAppInfo(Context paramContext) {
    this.appInfo = new AppInfo(paramContext);
  }
  
  protected DeviceInfo createDeviceInfo(Context paramContext) {
    return new DeviceInfo(paramContext, new BasicUserAgentManager());
  }
  
  protected void createSISRegistration() {
    this.sisRegistration = new SISRegistration();
  }
  
  public AppInfo getAppInfo() {
    return this.appInfo;
  }
  
  public Context getApplicationContext() {
    return this.applicationContext;
  }
  
  public DeviceInfo getDeviceInfo() {
    return this.deviceInfo;
  }
  
  public File getFilesDir() {
    return this.filesDirectory;
  }
  
  public boolean getIsAppDisabled() {
    return this.isAppDisabled;
  }
  
  public int getNoRetryTtlRemainingMillis() {
    if (this.noRetryTtlMillis == 0 || this.noRetryTtlExpiresMillis == 0L)
      return 0; 
    long l = System.currentTimeMillis();
    if (l >= this.noRetryTtlExpiresMillis) {
      this.noRetryTtlMillis = 0;
      this.noRetryTtlExpiresMillis = 0L;
      return 0;
    } 
    return (int)(this.noRetryTtlExpiresMillis - l);
  }
  
  public RegistrationInfo getRegistrationInfo() {
    return this.registrationInfo;
  }
  
  public SISRegistration getSISRegistration() {
    return this.sisRegistration;
  }
  
  public boolean isContextReceived() {
    return this.contextReceived;
  }
  
  public boolean isRegistered() {
    return this.isRegistered;
  }
  
  public void register() {
    getSISRegistration().registerApp();
    this.isRegistered = true;
  }
  
  protected void setApplicationContextFromContext(Context paramContext) {
    this.applicationContext = paramContext.getApplicationContext();
  }
  
  protected void setFilesDirectory(Context paramContext) {
    this.filesDirectory = paramContext.getFilesDir();
  }
  
  public void setIsAppDisabled(boolean paramBoolean) {
    this.isAppDisabled = paramBoolean;
  }
  
  public void setNoRetryTtl(int paramInt) {
    int j = Configuration.getMaxNoRetryTtl();
    int i = paramInt;
    if (j < paramInt)
      i = j; 
    if (i == 0) {
      this.noRetryTtlMillis = 0;
      this.noRetryTtlExpiresMillis = 0L;
      return;
    } 
    this.noRetryTtlMillis = i * 1000;
    this.noRetryTtlExpiresMillis = System.currentTimeMillis() + this.noRetryTtlMillis;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AmazonRegistration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */