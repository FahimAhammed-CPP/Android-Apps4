package com.amazon.device.ads;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

class AppEvent {
  private final String eventName;
  
  private final HashMap<String, String> properties;
  
  private final long timestamp;
  
  protected AppEvent(String paramString) {
    this(paramString, -1L);
  }
  
  public AppEvent(String paramString, long paramLong) {
    this.eventName = paramString;
    this.timestamp = paramLong;
    this.properties = new HashMap<String, String>();
  }
  
  public static AppEvent createAppEventWithTimestamp(AppEvent paramAppEvent, long paramLong) {
    return new AppEvent(paramAppEvent.eventName, paramLong);
  }
  
  public String getEventName() {
    return this.eventName;
  }
  
  public String getProperty(String paramString) {
    return this.properties.get(paramString);
  }
  
  public Set<Map.Entry<String, String>> getPropertyEntries() {
    return this.properties.entrySet();
  }
  
  public long getTimestamp() {
    return this.timestamp;
  }
  
  public AppEvent setProperty(String paramString1, String paramString2) {
    this.properties.put(paramString1, paramString2);
    return this;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(65);
    stringBuilder.append("Application Event {Name: ");
    stringBuilder.append(this.eventName);
    stringBuilder.append(", Timestamp: ");
    stringBuilder.append(this.timestamp);
    for (String str : this.properties.keySet()) {
      stringBuilder.append(", ");
      stringBuilder.append(str);
      stringBuilder.append(": ");
      stringBuilder.append(this.properties.get(str));
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AppEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */