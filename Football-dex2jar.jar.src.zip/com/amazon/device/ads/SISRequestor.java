package com.amazon.device.ads;

import java.util.Map;
import org.json.JSONObject;

class SISRequestor {
  protected static final String API_LEVEL_ENDPOINT = "/api3";
  
  private final SISRequestorCallback sisRequestorCallback;
  
  private final SISRequest[] sisRequests;
  
  public SISRequestor(SISRequestorCallback paramSISRequestorCallback, SISRequest... paramVarArgs) {
    this.sisRequestorCallback = paramSISRequestorCallback;
    this.sisRequests = paramVarArgs;
  }
  
  public SISRequestor(SISRequest... paramVarArgs) {
    this(null, paramVarArgs);
  }
  
  protected static String getEndpoint(SISRequest paramSISRequest) {
    String str2 = Configuration.getInstance().getString(Configuration.ConfigOption.SIS_URL);
    String str1 = str2;
    if (str2 != null) {
      int i = str2.indexOf("/");
      if (i > -1) {
        str1 = str2.substring(i);
        return str1 + "/api3" + paramSISRequest.getPath();
      } 
    } else {
      return str1 + "/api3" + paramSISRequest.getPath();
    } 
    str1 = "";
    return str1 + "/api3" + paramSISRequest.getPath();
  }
  
  protected static String getHostname() {
    String str2 = Configuration.getInstance().getString(Configuration.ConfigOption.SIS_URL);
    String str1 = str2;
    if (str2 != null) {
      int i = str2.indexOf("/");
      str1 = str2;
      if (i > -1)
        str1 = str2.substring(0, i); 
    } 
    return str1;
  }
  
  protected void callSIS() {
    SISRequest[] arrayOfSISRequest = this.sisRequests;
    int j = arrayOfSISRequest.length;
    for (int i = 0; i < j; i++)
      callSIS(arrayOfSISRequest[i]); 
  }
  
  protected void callSIS(SISRequest paramSISRequest) {
    JSONObject jSONObject;
    WebRequest webRequest = getWebRequest(paramSISRequest);
    try {
      WebRequest.WebResponse webResponse = webRequest.makeCall();
      jSONObject = webResponse.getResponseReader().readAsJSON();
      if (jSONObject == null)
        return; 
    } catch (WebRequestException webRequestException) {
      return;
    } 
    int i = JSONUtils.getIntegerFromJSON(jSONObject, "rcode", 0);
    String str = JSONUtils.getStringFromJSON(jSONObject, "msg", "");
    if (i == 1) {
      Log.i(webRequestException.getLogTag(), "Result - code: %d, msg: %s", new Object[] { Integer.valueOf(i), str });
      webRequestException.onResponseReceived(jSONObject);
      return;
    } 
    Log.w(webRequestException.getLogTag(), "Result - code: %d, msg: %s", new Object[] { Integer.valueOf(i), str });
  }
  
  protected SISRequestorCallback getSisRequestorCallback() {
    return this.sisRequestorCallback;
  }
  
  protected WebRequest getWebRequest(SISRequest paramSISRequest) {
    WebRequest webRequest = WebRequest.createNewWebRequest();
    webRequest.setExternalLogTag(paramSISRequest.getLogTag());
    webRequest.setHttpMethod(WebRequest.HttpMethod.POST);
    webRequest.setHost(getHostname());
    webRequest.setPath(getEndpoint(paramSISRequest));
    webRequest.enableLog(true);
    if (paramSISRequest.getPostParameters() != null)
      for (Map.Entry<String, String> entry : paramSISRequest.getPostParameters().entrySet())
        webRequest.putPostParameter((String)entry.getKey(), (String)entry.getValue());  
    WebRequest.QueryStringParameters queryStringParameters = paramSISRequest.getQueryParameters();
    queryStringParameters.putUrlEncoded("appId", AmazonRegistration.getInstance().getRegistrationInfo().getAppKey());
    queryStringParameters.putUrlEncoded("sdkVer", Version.getSDKVersion());
    webRequest.setQueryStringParameters(queryStringParameters);
    webRequest.setMetricsCollector(Metrics.getInstance().getMetricsCollector());
    webRequest.setServiceCallLatencyMetric(paramSISRequest.getCallMetricType());
    return webRequest;
  }
  
  public void startCallSIS() {
    callSIS();
    SISRequestorCallback sISRequestorCallback = getSisRequestorCallback();
    if (sISRequestorCallback != null)
      sISRequestorCallback.onSISCallComplete(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\SISRequestor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */