package com.amazon.device.ads;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

class BridgeSelector {
  private static BridgeSelector instance = new BridgeSelector();
  
  private HashMap<AAXCreative, HashSet<AdSDKBridgeFactory>> bridgesForCT;
  
  private HashMap<String, HashSet<AdSDKBridgeFactory>> bridgesForPattern;
  
  private HashMap<String, HashSet<AdSDKBridgeFactory>> bridgesForResourcePattern;
  
  private HashMap<String, Pattern> patterns;
  
  BridgeSelector() {
    initialize();
  }
  
  public static BridgeSelector getInstance() {
    return instance;
  }
  
  private Pattern getPattern(String paramString) {
    Pattern pattern2 = this.patterns.get(paramString);
    Pattern pattern1 = pattern2;
    if (pattern2 == null) {
      pattern1 = Pattern.compile(paramString);
      this.patterns.put(paramString, pattern1);
    } 
    return pattern1;
  }
  
  public void addBridgeFactory(AAXCreative paramAAXCreative, AdSDKBridgeFactory paramAdSDKBridgeFactory) {
    HashSet<AdSDKBridgeFactory> hashSet2 = this.bridgesForCT.get(paramAAXCreative);
    HashSet<AdSDKBridgeFactory> hashSet1 = hashSet2;
    if (hashSet2 == null) {
      hashSet1 = new HashSet();
      this.bridgesForCT.put(paramAAXCreative, hashSet1);
    } 
    hashSet1.add(paramAdSDKBridgeFactory);
  }
  
  public void addBridgeFactoryForHtmlScriptTag(String paramString, AdSDKBridgeFactory paramAdSDKBridgeFactory) {
    String str = String.format("<[Ss][Cc][Rr][Ii][Pp][Tt](\\s[^>]*\\s|\\s)[Ss][Rr][Cc]\\s*=\\s*[\"']%s[\"']", new Object[] { paramString });
    HashSet<AdSDKBridgeFactory> hashSet2 = this.bridgesForPattern.get(str);
    HashSet<AdSDKBridgeFactory> hashSet1 = hashSet2;
    if (hashSet2 == null) {
      hashSet1 = new HashSet();
      this.bridgesForPattern.put(str, hashSet1);
    } 
    hashSet1.add(paramAdSDKBridgeFactory);
  }
  
  public void addBridgeFactoryForResourceLoad(String paramString, AdSDKBridgeFactory paramAdSDKBridgeFactory) {
    String str = String.format(".*\\W%s$|^%s$", new Object[] { paramString, paramString });
    HashSet<AdSDKBridgeFactory> hashSet2 = this.bridgesForResourcePattern.get(str);
    HashSet<AdSDKBridgeFactory> hashSet1 = hashSet2;
    if (hashSet2 == null) {
      hashSet1 = new HashSet();
      this.bridgesForResourcePattern.put(str, hashSet1);
    } 
    hashSet1.add(paramAdSDKBridgeFactory);
  }
  
  public void addBridgeFactoryForScript(String paramString, AdSDKBridgeFactory paramAdSDKBridgeFactory) {
    addBridgeFactoryForHtmlScriptTag(paramString, paramAdSDKBridgeFactory);
    addBridgeFactoryForResourceLoad(paramString, paramAdSDKBridgeFactory);
  }
  
  public Set<AdSDKBridgeFactory> getBridgeFactories(AAXCreative paramAAXCreative) {
    return this.bridgesForCT.get(paramAAXCreative);
  }
  
  public Set<AdSDKBridgeFactory> getBridgeFactories(String paramString) {
    HashSet<AdSDKBridgeFactory> hashSet = new HashSet();
    for (String str : this.bridgesForPattern.keySet()) {
      if (getPattern(str).matcher(paramString).find())
        hashSet.addAll(this.bridgesForPattern.get(str)); 
    } 
    return hashSet;
  }
  
  public Set<AdSDKBridgeFactory> getBridgeFactoriesForResourceLoad(String paramString) {
    HashSet<AdSDKBridgeFactory> hashSet = new HashSet();
    for (String str : this.bridgesForResourcePattern.keySet()) {
      if (getPattern(str).matcher(paramString).find())
        hashSet.addAll(this.bridgesForResourcePattern.get(str)); 
    } 
    return hashSet;
  }
  
  void initialize() {
    this.bridgesForCT = new HashMap<AAXCreative, HashSet<AdSDKBridgeFactory>>();
    this.bridgesForPattern = new HashMap<String, HashSet<AdSDKBridgeFactory>>();
    this.patterns = new HashMap<String, Pattern>();
    this.bridgesForResourcePattern = new HashMap<String, HashSet<AdSDKBridgeFactory>>();
    addBridgeFactoryForScript("amazon.js", new AmazonAdSDKBridgeFactory());
    MraidAdSDKBridgeFactory mraidAdSDKBridgeFactory = new MraidAdSDKBridgeFactory();
    addBridgeFactory(AAXCreative.MRAID1, mraidAdSDKBridgeFactory);
    addBridgeFactory(AAXCreative.MRAID2, mraidAdSDKBridgeFactory);
    addBridgeFactory(AAXCreative.INTERSTITIAL, mraidAdSDKBridgeFactory);
    addBridgeFactoryForScript("mraid.js", mraidAdSDKBridgeFactory);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\BridgeSelector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */