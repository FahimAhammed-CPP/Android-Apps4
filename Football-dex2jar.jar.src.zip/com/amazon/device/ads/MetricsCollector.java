package com.amazon.device.ads;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

class MetricsCollector {
  private String adTypeMetricTag;
  
  protected Vector<MetricHit> metricHits = new Vector<MetricHit>(60);
  
  public String getAdTypeMetricTag() {
    return this.adTypeMetricTag;
  }
  
  public Vector<MetricHit> getMetricHits() {
    return this.metricHits;
  }
  
  public void incrementMetric(Metrics.MetricType paramMetricType) {
    Log.d("MetricsCollector", "METRIC Increment " + paramMetricType.toString(), new Object[0]);
    this.metricHits.add(new MetricHitIncrement(paramMetricType, 1));
  }
  
  public boolean isMetricsCollectorEmpty() {
    return this.metricHits.isEmpty();
  }
  
  public void publishMetricInMilliseconds(Metrics.MetricType paramMetricType, long paramLong) {
    Log.d("MetricsCollector", "METRIC Publish " + paramMetricType.toString(), new Object[0]);
    this.metricHits.add(new MetricHitTotalTime(paramMetricType, paramLong));
  }
  
  public void publishMetricInMillisecondsFromNanoseconds(Metrics.MetricType paramMetricType, long paramLong) {
    publishMetricInMilliseconds(paramMetricType, NumberUtils.convertToMillisecondsFromNanoseconds(paramLong));
  }
  
  public void setAdType(AdProperties.AdType paramAdType) {
    this.adTypeMetricTag = paramAdType.getAdTypeMetricTag();
  }
  
  public void setMetricString(Metrics.MetricType paramMetricType, String paramString) {
    Log.d("MetricsCollector", "METRIC Set " + paramMetricType.toString() + ": " + paramString, new Object[0]);
    this.metricHits.add(new MetricHitString(paramMetricType, paramString));
  }
  
  public void startMetric(Metrics.MetricType paramMetricType) {
    startMetricInMillisecondsFromNanoseconds(paramMetricType, System.nanoTime());
  }
  
  public void startMetricInMillisecondsFromNanoseconds(Metrics.MetricType paramMetricType, long paramLong) {
    Log.d("MetricsCollector", "METRIC Start " + paramMetricType.toString(), new Object[0]);
    paramLong = NumberUtils.convertToMillisecondsFromNanoseconds(paramLong);
    this.metricHits.add(new MetricHitStartTime(paramMetricType, paramLong));
  }
  
  public void stopMetric(Metrics.MetricType paramMetricType) {
    stopMetricInMillisecondsFromNanoseconds(paramMetricType, System.nanoTime());
  }
  
  public void stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType paramMetricType, long paramLong) {
    Log.d("MetricsCollector", "METRIC Stop " + paramMetricType.toString(), new Object[0]);
    paramLong = NumberUtils.convertToMillisecondsFromNanoseconds(paramLong);
    this.metricHits.add(new MetricHitStopTime(paramMetricType, paramLong));
  }
  
  static class CompositeMetricsCollector extends MetricsCollector {
    private final ArrayList<MetricsCollector> collectors;
    
    public CompositeMetricsCollector(ArrayList<MetricsCollector> param1ArrayList) {
      this.collectors = param1ArrayList;
    }
    
    public void incrementMetric(Metrics.MetricType param1MetricType) {
      Iterator<MetricsCollector> iterator = this.collectors.iterator();
      while (iterator.hasNext())
        ((MetricsCollector)iterator.next()).incrementMetric(param1MetricType); 
    }
    
    public void publishMetricInMilliseconds(Metrics.MetricType param1MetricType, long param1Long) {
      Iterator<MetricsCollector> iterator = this.collectors.iterator();
      while (iterator.hasNext())
        ((MetricsCollector)iterator.next()).publishMetricInMilliseconds(param1MetricType, param1Long); 
    }
    
    public void publishMetricInMillisecondsFromNanoseconds(Metrics.MetricType param1MetricType, long param1Long) {
      Iterator<MetricsCollector> iterator = this.collectors.iterator();
      while (iterator.hasNext())
        ((MetricsCollector)iterator.next()).publishMetricInMillisecondsFromNanoseconds(param1MetricType, param1Long); 
    }
    
    public void setMetricString(Metrics.MetricType param1MetricType, String param1String) {
      Iterator<MetricsCollector> iterator = this.collectors.iterator();
      while (iterator.hasNext())
        ((MetricsCollector)iterator.next()).setMetricString(param1MetricType, param1String); 
    }
    
    public void startMetric(Metrics.MetricType param1MetricType) {
      Iterator<MetricsCollector> iterator = this.collectors.iterator();
      while (iterator.hasNext())
        ((MetricsCollector)iterator.next()).startMetric(param1MetricType); 
    }
    
    public void startMetricInMillisecondsFromNanoseconds(Metrics.MetricType param1MetricType, long param1Long) {
      Iterator<MetricsCollector> iterator = this.collectors.iterator();
      while (iterator.hasNext())
        ((MetricsCollector)iterator.next()).startMetricInMillisecondsFromNanoseconds(param1MetricType, param1Long); 
    }
    
    public void stopMetric(Metrics.MetricType param1MetricType) {
      Iterator<MetricsCollector> iterator = this.collectors.iterator();
      while (iterator.hasNext())
        ((MetricsCollector)iterator.next()).stopMetric(param1MetricType); 
    }
    
    public void stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType param1MetricType, long param1Long) {
      Iterator<MetricsCollector> iterator = this.collectors.iterator();
      while (iterator.hasNext())
        ((MetricsCollector)iterator.next()).stopMetricInMillisecondsFromNanoseconds(param1MetricType, param1Long); 
    }
  }
  
  static class MetricHit {
    public final Metrics.MetricType metric;
    
    public MetricHit(Metrics.MetricType param1MetricType) {
      this.metric = param1MetricType;
    }
  }
  
  static class MetricHitIncrement extends MetricHit {
    public final int increment;
    
    public MetricHitIncrement(Metrics.MetricType param1MetricType, int param1Int) {
      super(param1MetricType);
      this.increment = param1Int;
    }
  }
  
  static class MetricHitStartTime extends MetricHit {
    public final long startTime;
    
    public MetricHitStartTime(Metrics.MetricType param1MetricType, long param1Long) {
      super(param1MetricType);
      this.startTime = param1Long;
    }
  }
  
  static class MetricHitStopTime extends MetricHit {
    public final long stopTime;
    
    public MetricHitStopTime(Metrics.MetricType param1MetricType, long param1Long) {
      super(param1MetricType);
      this.stopTime = param1Long;
    }
  }
  
  static class MetricHitString extends MetricHit {
    public final String text;
    
    public MetricHitString(Metrics.MetricType param1MetricType, String param1String) {
      super(param1MetricType);
      this.text = param1String;
    }
  }
  
  static class MetricHitTotalTime extends MetricHit {
    public final long totalTime;
    
    public MetricHitTotalTime(Metrics.MetricType param1MetricType, long param1Long) {
      super(param1MetricType);
      this.totalTime = param1Long;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\MetricsCollector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */