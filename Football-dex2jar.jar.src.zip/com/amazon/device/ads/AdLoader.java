package com.amazon.device.ads;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

@SuppressLint({"UseSparseArrays"})
class AdLoader {
  public static final int AD_FAILED = -1;
  
  public static final int AD_LOAD_DEFERRED = 1;
  
  public static final int AD_READY_TO_LOAD = 0;
  
  private static final String DISABLED_APP_SERVER_MESSAGE = "DISABLED_APP";
  
  protected static final String LOG_TAG = AdLoader.class.getSimpleName();
  
  private static AdLoaderFactory adLoaderFactory = new AdLoaderFactory();
  
  protected final AdRequest adRequest;
  
  protected MetricsCollector.CompositeMetricsCollector compositeMetricsCollector = null;
  
  protected AdError error = null;
  
  protected final Map<Integer, AdSlot> slots;
  
  protected int timeout = 20000;
  
  public AdLoader(AdRequest paramAdRequest, Map<Integer, AdSlot> paramMap) {
    this.adRequest = paramAdRequest;
    this.slots = paramMap;
  }
  
  private static void beginFetchAds(int paramInt, AdTargetingOptions paramAdTargetingOptions, List<AdSlot> paramList) {
    AdvertisingIdentifier.Info info = (new AdvertisingIdentifier()).getAdvertisingIdentifierInfo();
    if (!info.canDo()) {
      failAds(new AdError(AdError.ErrorCode.INTERNAL_ERROR, "An internal request was not made on a background thread."), paramList);
      return;
    } 
    AdTargetingOptions adTargetingOptions = paramAdTargetingOptions;
    if (paramAdTargetingOptions == null)
      adTargetingOptions = new AdTargetingOptions(); 
    AdRequest adRequest = (new AdRequest(adTargetingOptions)).setAdvertisingIdentifierInfo(info);
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    int i = 1;
    for (AdSlot adSlot : paramList) {
      if (adSlot.isValid()) {
        adSlot.setSlotNumber(i);
        hashMap.put(Integer.valueOf(i), adSlot);
        adRequest.putSlot(adSlot);
        i++;
      } 
    } 
    if (hashMap.size() > 0) {
      AdLoader adLoader = adLoaderFactory.createAdLoader(adRequest, (Map)hashMap);
      adLoader.setTimeout(paramInt);
      adLoader.beginFetchAd();
      return;
    } 
  }
  
  private void beginFinalizeFetchAd() {
    (new Handler(Looper.getMainLooper())).post(new Runnable() {
          public void run() {
            AdLoader.this.finalizeFetchAd();
          }
        });
  }
  
  private static void failAds(AdError paramAdError, List<AdSlot> paramList) {
    int i = 0;
    for (AdSlot adSlot : paramList) {
      if (adSlot.getSlotNumber() != -1) {
        adSlot.adFailed(paramAdError);
        i++;
      } 
    } 
    if (i > 0)
      Log.e(LOG_TAG, "%s; code: %s", new Object[] { paramAdError.getMessage(), paramAdError.getCode() }); 
  }
  
  private WebRequest getAdRequest() throws AdFetchException {
    getCompositeMetricsCollector().startMetric(Metrics.MetricType.AD_LOAD_LATENCY_CREATE_AAX_GET_AD_URL);
    WebRequest webRequest = this.adRequest.getWebRequest();
    getCompositeMetricsCollector().stopMetric(Metrics.MetricType.AD_LOAD_LATENCY_CREATE_AAX_GET_AD_URL);
    return webRequest;
  }
  
  private MetricsCollector getCompositeMetricsCollector() {
    if (this.compositeMetricsCollector == null) {
      ArrayList<MetricsCollector> arrayList = new ArrayList();
      Iterator<Map.Entry> iterator = this.slots.entrySet().iterator();
      while (iterator.hasNext())
        arrayList.add(((AdSlot)((Map.Entry)iterator.next()).getValue()).getMetricsCollector()); 
      this.compositeMetricsCollector = new MetricsCollector.CompositeMetricsCollector(arrayList);
    } 
    return this.compositeMetricsCollector;
  }
  
  private static boolean isNoRetry(AdSlot[] paramArrayOfAdSlot) {
    int i = AmazonRegistration.getInstance().getNoRetryTtlRemainingMillis();
    if (i > 0) {
      i /= 1000;
      if (AmazonRegistration.getInstance().getIsAppDisabled()) {
        String str1 = "SDK Message: " + "DISABLED_APP";
        AdError.ErrorCode errorCode1 = AdError.ErrorCode.INTERNAL_ERROR;
        failAds(new AdError(errorCode1, str1), new ArrayList<AdSlot>(Arrays.asList(paramArrayOfAdSlot)));
        return true;
      } 
      String str = "SDK Message: " + "no results. Try again in " + i + " seconds.";
      AdError.ErrorCode errorCode = AdError.ErrorCode.NO_FILL;
      failAds(new AdError(errorCode, str), new ArrayList<AdSlot>(Arrays.asList(paramArrayOfAdSlot)));
      return true;
    } 
    return false;
  }
  
  protected static void loadAds(final int timeout, final AdTargetingOptions requestOptions, AdSlot... paramVarArgs) {
    if (isNoRetry(paramVarArgs))
      return; 
    long l = System.nanoTime();
    final ArrayList<AdSlot> requestAdSlots = new ArrayList();
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      AdSlot adSlot = paramVarArgs[i];
      if (adSlot.prepareForAdLoad(l))
        arrayList.add(adSlot); 
    } 
    (new StartUpWaiter(Settings.getInstance(), Configuration.getInstance()) {
        protected void startUpFailed() {
          ThreadUtils.executeOnMainThread(new Runnable() {
                public void run() {
                  AdLoader.failAds(new AdError(AdError.ErrorCode.NETWORK_ERROR, "The configuration was unable to be loaded"), requestAdSlots);
                }
              });
        }
        
        protected void startUpReady() {
          AmazonRegistration.getInstance().register();
          AdLoader.beginFetchAds(timeout, requestOptions, requestAdSlots);
        }
      }).start();
  }
  
  private void parseResponse(JSONObject paramJSONObject) {
    long l = System.currentTimeMillis();
    String str2 = JSONUtils.getStringFromJSON(paramJSONObject, "status", null);
    HashSet hashSet = new HashSet(this.slots.keySet());
    AdError adError = getAdError(paramJSONObject);
    String str1 = JSONUtils.getStringFromJSON(paramJSONObject, "errorCode", "No Ad Received");
    this.adRequest.setInstrumentationPixelURL(JSONUtils.getStringFromJSON(paramJSONObject, "instrPixelURL", null));
    if (str2 != null && str2.equals("ok")) {
      JSONArray jSONArray = JSONUtils.getJSONArrayFromJSON(paramJSONObject, "ads");
      for (int i = 0; i < jSONArray.length(); i++) {
        JSONObject jSONObject = JSONUtils.getJSONObjectFromJSONArray(jSONArray, i);
        if (jSONObject == null)
          continue; 
        int j = JSONUtils.getIntegerFromJSON(jSONObject, "slotId", -1);
        AdSlot adSlot = this.slots.get(Integer.valueOf(j));
        if (adSlot != null) {
          hashSet.remove(Integer.valueOf(j));
          String str3 = JSONUtils.getStringFromJSON(jSONObject, "instrPixelURL", this.adRequest.getInstrumentationPixelURL());
          AdData adData = new AdData();
          adData.setInstrumentationPixelUrl(str3);
          adData.setImpressionPixelUrl(JSONUtils.getStringFromJSON(jSONObject, "impPixelURL", null));
          if (adSlot.getRequestedAdSize().isAuto())
            adSlot.getMetricsCollector().incrementMetric(Metrics.MetricType.AD_COUNTER_AUTO_AD_SIZE); 
          String str4 = JSONUtils.getStringFromJSON(jSONObject, "html", "");
          JSONArray jSONArray1 = JSONUtils.getJSONArrayFromJSON(jSONObject, "creativeTypes");
          HashSet<AAXCreative> hashSet1 = new HashSet();
          if (jSONArray1 != null)
            for (j = 0; j < jSONArray1.length(); j++) {
              int n = JSONUtils.getIntegerFromJSONArray(jSONArray1, j, 0);
              AAXCreative aAXCreative = AAXCreative.getCreativeType(n);
              if (aAXCreative != null) {
                hashSet1.add(aAXCreative);
              } else {
                Log.w(LOG_TAG, "%d is not a recognized creative type.", new Object[] { Integer.valueOf(n) });
              } 
            }  
          if (!AAXCreative.containsPrimaryCreativeType(hashSet1)) {
            adSlot.setAdError(new AdError(AdError.ErrorCode.INTERNAL_ERROR, "No valid creative types found"));
            Log.e(LOG_TAG, "No valid creative types found", new Object[0]);
            continue;
          } 
          str3 = JSONUtils.getStringFromJSON(jSONObject, "size", "");
          if (str3 != null && (str3.equals("9999x9999") || str3.equals("interstitial")) && !hashSet1.contains(AAXCreative.INTERSTITIAL))
            hashSet1.add(AAXCreative.INTERSTITIAL); 
          int m = 0;
          j = 0;
          boolean bool = false;
          int k = 0;
          byte b = 0;
          if (!hashSet1.contains(AAXCreative.INTERSTITIAL)) {
            boolean bool1 = false;
            if (str3 != null) {
              String[] arrayOfString = str3.split("x");
            } else {
              str3 = null;
            } 
            if (str3 == null || str3.length != 2) {
              m = 1;
              j = bool;
              k = b;
            } else {
              j = m;
              try {
                m = Integer.parseInt(str3[0]);
                j = m;
                k = Integer.parseInt(str3[1]);
                j = m;
                m = bool1;
              } catch (NumberFormatException numberFormatException) {
                m = 1;
                k = b;
              } 
            } 
            if (m != 0) {
              adSlot.setAdError(new AdError(AdError.ErrorCode.INTERNAL_ERROR, "Server returned an invalid ad size"));
              Log.e(LOG_TAG, "Server returned an invalid ad size", new Object[0]);
              continue;
            } 
          } 
          long l1 = JSONUtils.getLongFromJSON(jSONObject, "cacheTTL", -1L);
          if (l1 > -1L)
            adData.setExpirationTimeMillis(l + 1000L * l1); 
          AdProperties adProperties = new AdProperties(jSONArray1);
          adData.setHeight(k);
          adData.setWidth(j);
          adData.setCreative(str4);
          adData.setCreativeTypes(hashSet1);
          adData.setProperties(adProperties);
          adData.setFetched(true);
          adSlot.setAdData(adData);
        } 
        continue;
      } 
    } 
    for (Integer integer : hashSet) {
      ((AdSlot)this.slots.get(integer)).setAdError(adError);
      AdData adData = new AdData();
      adData.setInstrumentationPixelUrl(this.adRequest.getInstrumentationPixelURL());
      ((AdSlot)this.slots.get(integer)).setAdData(adData);
      Log.w(LOG_TAG, "%s; code: %s", new Object[] { adError.getMessage(), str1 });
    } 
  }
  
  protected static void setAdLoaderFactory(AdLoaderFactory paramAdLoaderFactory) {
    adLoaderFactory = paramAdLoaderFactory;
  }
  
  private void setErrorForAllSlots(AdError paramAdError) {
    Iterator<AdSlot> iterator = this.slots.values().iterator();
    while (iterator.hasNext())
      ((AdSlot)iterator.next()).setAdError(paramAdError); 
  }
  
  public void beginFetchAd() {
    getCompositeMetricsCollector().stopMetric(Metrics.MetricType.AD_LOAD_LATENCY_LOADAD_TO_FETCH_THREAD_REQUEST_START);
    getCompositeMetricsCollector().startMetric(Metrics.MetricType.AD_LOAD_LATENCY_FETCH_THREAD_SPIN_UP);
    startFetchAdThread();
  }
  
  protected void fetchAd() {
    getCompositeMetricsCollector().stopMetric(Metrics.MetricType.AD_LOAD_LATENCY_FETCH_THREAD_SPIN_UP);
    getCompositeMetricsCollector().startMetric(Metrics.MetricType.AD_LOAD_LATENCY_FETCH_THREAD_START_TO_AAX_GET_AD_START);
    if (!Assets.getInstance().ensureAssetsCreated()) {
      this.error = new AdError(AdError.ErrorCode.REQUEST_ERROR, "Unable to create the assets needed to display ads");
      Log.e(LOG_TAG, "Unable to create the assets needed to display ads", new Object[0]);
      setErrorForAllSlots(this.error);
      return;
    } 
    try {
      WebRequest.WebResponse webResponse = fetchResponseFromNetwork();
      if (!webResponse.isHttpStatusCodeOK()) {
        String str = webResponse.getHttpStatusCode() + " - " + webResponse.getHttpStatus();
        this.error = new AdError(AdError.ErrorCode.NETWORK_ERROR, str);
        Log.e(LOG_TAG, str, new Object[0]);
        setErrorForAllSlots(this.error);
        return;
      } 
    } catch (AdFetchException adFetchException) {
      this.error = adFetchException.getAdError();
      Log.e(LOG_TAG, adFetchException.getAdError().getMessage(), new Object[0]);
      setErrorForAllSlots(this.error);
      return;
    } 
    JSONObject jSONObject = adFetchException.getResponseReader().readAsJSON();
    if (jSONObject == null) {
      this.error = new AdError(AdError.ErrorCode.INTERNAL_ERROR, "Unable to parse response");
      Log.e(LOG_TAG, "Unable to parse response", new Object[0]);
      setErrorForAllSlots(this.error);
      return;
    } 
    parseResponse(jSONObject);
    getCompositeMetricsCollector().stopMetric(Metrics.MetricType.AD_LOAD_LATENCY_AAX_GET_AD_END_TO_FETCH_THREAD_END);
    getCompositeMetricsCollector().startMetric(Metrics.MetricType.AD_LOAD_LATENCY_FINALIZE_FETCH_SPIN_UP);
  }
  
  protected WebRequest.WebResponse fetchResponseFromNetwork() throws AdFetchException {
    AdError adError;
    WebRequest webRequest = getAdRequest();
    webRequest.setMetricsCollector(getCompositeMetricsCollector());
    webRequest.setServiceCallLatencyMetric(Metrics.MetricType.AAX_LATENCY_GET_AD);
    webRequest.setTimeout(this.timeout);
    webRequest.setDisconnectEnabled(false);
    getCompositeMetricsCollector().stopMetric(Metrics.MetricType.AD_LOAD_LATENCY_FETCH_THREAD_START_TO_AAX_GET_AD_START);
    getCompositeMetricsCollector().incrementMetric(Metrics.MetricType.TLS_ENABLED);
    try {
      WebRequest.WebResponse webResponse = webRequest.makeCall();
      getCompositeMetricsCollector().startMetric(Metrics.MetricType.AD_LOAD_LATENCY_AAX_GET_AD_END_TO_FETCH_THREAD_END);
      return webResponse;
    } catch (WebRequestException webRequestException) {
      if (webRequestException.getStatus() == WebRequest.WebRequestStatus.NETWORK_FAILURE) {
        adError = new AdError(AdError.ErrorCode.NETWORK_ERROR, "Could not contact Ad Server");
        throw new AdFetchException(adError);
      } 
    } 
    throw new AdFetchException(adError);
  }
  
  protected void finalizeFetchAd() {
    Iterator<Map.Entry> iterator = this.slots.entrySet().iterator();
    while (iterator.hasNext()) {
      AdSlot adSlot = (AdSlot)((Map.Entry)iterator.next()).getValue();
      adSlot.getMetricsCollector().stopMetric(Metrics.MetricType.AD_LOAD_LATENCY_FINALIZE_FETCH_SPIN_UP);
      if (!adSlot.isFetched()) {
        adSlot.getMetricsCollector().startMetric(Metrics.MetricType.AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_FAILURE);
        if (adSlot.getAdError() != null) {
          adSlot.adFailed(adSlot.getAdError());
          continue;
        } 
        adSlot.adFailed(new AdError(AdError.ErrorCode.INTERNAL_ERROR, "Unknown error occurred."));
        continue;
      } 
      adSlot.getMetricsCollector().startMetric(Metrics.MetricType.AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_RENDER_START);
      adSlot.initializeAd();
    } 
  }
  
  protected AdError getAdError(JSONObject paramJSONObject) {
    int i = retrieveNoRetryTtlSeconds(paramJSONObject);
    AmazonRegistration.getInstance().setNoRetryTtl(i);
    String str1 = JSONUtils.getStringFromJSON(paramJSONObject, "errorMessage", "No Ad Received");
    AmazonRegistration.getInstance().setIsAppDisabled(str1.equalsIgnoreCase("DISABLED_APP"));
    String str2 = "Server Message: " + str1;
    if (i > 0)
      getCompositeMetricsCollector().publishMetricInMilliseconds(Metrics.MetricType.AD_NO_RETRY_TTL_RECEIVED, (i * 1000)); 
    if (i > 0 && !AmazonRegistration.getInstance().getIsAppDisabled()) {
      str1 = str2 + ". Try again in " + i + " seconds";
      return new AdError(AdError.ErrorCode.NO_FILL, str1);
    } 
    return str1.equals("no results") ? new AdError(AdError.ErrorCode.NO_FILL, str2) : new AdError(AdError.ErrorCode.INTERNAL_ERROR, str2);
  }
  
  protected int retrieveNoRetryTtlSeconds(JSONObject paramJSONObject) {
    int i = JSONUtils.getIntegerFromJSON(paramJSONObject, "noretryTTL", 0);
    return DebugProperties.getInstance().getDebugPropertyAsInteger("debug.noRetryTTL", i);
  }
  
  public void setTimeout(int paramInt) {
    this.timeout = paramInt;
  }
  
  protected void startFetchAdThread() {
    ThreadUtils.executeRunnable(new Runnable() {
          public void run() {
            AdLoader.this.fetchAd();
            AdLoader.this.beginFinalizeFetchAd();
          }
        });
  }
  
  protected class AdFetchException extends Exception {
    private static final long serialVersionUID = 1L;
    
    private final AdError adError;
    
    public AdFetchException(AdError param1AdError) {
      this.adError = param1AdError;
    }
    
    public AdFetchException(AdError param1AdError, Throwable param1Throwable) {
      super(param1Throwable);
      this.adError = param1AdError;
    }
    
    public AdError getAdError() {
      return this.adError;
    }
  }
  
  protected static class AdLoaderFactory {
    public AdLoader createAdLoader(AdRequest param1AdRequest, Map<Integer, AdSlot> param1Map) {
      return new AdLoader(param1AdRequest, param1Map);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */