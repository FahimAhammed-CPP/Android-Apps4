package com.amazon.device.ads;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;

abstract class FileHandler implements Closeable {
  private static final String LOGTAG = FileHandler.class.getSimpleName();
  
  File file;
  
  private void closeStream() {
    Closeable closeable = getCloseableStream();
    if (closeable != null)
      try {
        closeable.close();
        return;
      } catch (IOException iOException) {
        Log.e(LOGTAG, "Could not close the stream. %s", new Object[] { iOException.getMessage() });
        return;
      }  
  }
  
  public abstract void close();
  
  protected void closeCloseables() {
    Closeable closeable = getCloseableReaderWriter();
    if (closeable != null)
      try {
        closeable.close();
        return;
      } catch (IOException iOException) {
        Log.e(LOGTAG, "Could not close the %s. %s", new Object[] { closeable.getClass().getSimpleName(), iOException.getMessage() });
        closeStream();
        return;
      }  
    closeStream();
  }
  
  public boolean doesFileExist() {
    if (!isFileSet())
      throw new IllegalStateException("A file has not been set, yet."); 
    return this.file.exists();
  }
  
  protected abstract Closeable getCloseableReaderWriter();
  
  protected abstract Closeable getCloseableStream();
  
  public long getFileLength() {
    if (!isFileSet())
      throw new IllegalStateException("A file has not been set, yet."); 
    return this.file.length();
  }
  
  public boolean isFileSet() {
    return (this.file != null);
  }
  
  public abstract boolean isOpen();
  
  public boolean setFile(File paramFile) {
    if (isFileSet()) {
      if (paramFile.getAbsolutePath().equals(this.file.getAbsolutePath()))
        return true; 
      Log.e(LOGTAG, "Another file is already set in this FileOutputHandler. Close the other file before opening a new one.", new Object[0]);
      return false;
    } 
    this.file = paramFile;
    return true;
  }
  
  public boolean setFile(File paramFile, String paramString) {
    return setFile(new File(paramFile, paramString));
  }
  
  public boolean setFile(String paramString) {
    return setFile(new File(paramString));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\FileHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */