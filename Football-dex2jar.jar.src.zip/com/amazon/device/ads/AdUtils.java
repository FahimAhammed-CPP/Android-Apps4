package com.amazon.device.ads;

import android.content.Context;
import android.content.pm.ActivityInfo;
import java.util.HashSet;

class AdUtils {
  public static final String LOG_TAG = AdUtils.class.getSimpleName();
  
  public static final String REQUIRED_ACTIVITY = "com.amazon.device.ads.AdActivity";
  
  private static AdUtilsExecutor executor = new AdUtilsExecutor();
  
  public static double calculateScalingMultiplier(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return executor.calculateScalingMultiplier(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  static boolean checkDefinedActivities(Context paramContext) {
    return executor.checkDefinedActivities(paramContext);
  }
  
  public static int deviceIndependentPixelToPixel(int paramInt) {
    return executor.deviceIndependentPixelToPixel(paramInt);
  }
  
  public static float getScalingFactorAsFloat() {
    return executor.getScalingFactorAsFloat();
  }
  
  public static double getViewportInitialScale(double paramDouble) {
    return executor.getViewportInitialScale(paramDouble);
  }
  
  public static int pixelToDeviceIndependentPixel(int paramInt) {
    return executor.pixelToDeviceIndependentPixel(paramInt);
  }
  
  static void setConnectionMetrics(ConnectionInfo paramConnectionInfo, MetricsCollector paramMetricsCollector) {
    executor.setConnectionMetrics(paramConnectionInfo, paramMetricsCollector);
  }
  
  static class AdUtilsExecutor {
    private boolean hasRequiredActivities = false;
    
    private final HashSet<String> requiredActivities = new HashSet<String>();
    
    AdUtilsExecutor() {
      this.requiredActivities.add("com.amazon.device.ads.AdActivity");
    }
    
    double calculateScalingMultiplier(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      double d1 = param1Int3 / param1Int1;
      double d2 = param1Int4 / param1Int2;
      if ((d2 < d1 || d1 == 0.0D) && d2 != 0.0D)
        d1 = d2; 
      d2 = d1;
      if (d1 == 0.0D)
        d2 = 1.0D; 
      return d2;
    }
    
    boolean checkDefinedActivities(Context param1Context) {
      if (this.hasRequiredActivities)
        return true; 
      HashSet<String> hashSet = new HashSet();
      try {
        if (AndroidTargetUtils.isAtLeastAndroidAPI(8)) {
          String str = AndroidTargetUtils.getPackageCodePath(param1Context);
          ActivityInfo[] arrayOfActivityInfo = (param1Context.getPackageManager().getPackageArchiveInfo(str, 1)).activities;
          int j = arrayOfActivityInfo.length;
          for (int i = 0; i < j; i++)
            hashSet.add((arrayOfActivityInfo[i]).name); 
          this.hasRequiredActivities = hashSet.containsAll(this.requiredActivities);
          return this.hasRequiredActivities;
        } 
      } catch (Exception exception) {}
      this.hasRequiredActivities = true;
      return true;
    }
    
    int deviceIndependentPixelToPixel(int param1Int) {
      return (int)(param1Int * getScalingFactorAsFloat());
    }
    
    float getScalingFactorAsFloat() {
      return AmazonRegistration.getInstance().getDeviceInfo().getScalingFactorAsFloat();
    }
    
    double getViewportInitialScale(double param1Double) {
      if (AndroidTargetUtils.isAtLeastAndroidAPI(19))
        param1Double = 1.0D; 
      return param1Double;
    }
    
    int pixelToDeviceIndependentPixel(int param1Int) {
      return (int)(param1Int / getScalingFactorAsFloat());
    }
    
    void setConnectionMetrics(ConnectionInfo param1ConnectionInfo, MetricsCollector param1MetricsCollector) {
      if (param1ConnectionInfo != null)
        if (param1ConnectionInfo.isWiFi()) {
          param1MetricsCollector.incrementMetric(Metrics.MetricType.WIFI_PRESENT);
        } else {
          param1MetricsCollector.setMetricString(Metrics.MetricType.CONNECTION_TYPE, param1ConnectionInfo.getConnectionType());
        }  
      DeviceInfo deviceInfo = AmazonRegistration.getInstance().getDeviceInfo();
      if (deviceInfo.getCarrier() != null)
        param1MetricsCollector.setMetricString(Metrics.MetricType.CARRIER_NAME, deviceInfo.getCarrier()); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */