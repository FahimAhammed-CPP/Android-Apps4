package com.amazon.device.ads;

import android.location.Location;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

abstract class AAXParameter<T> {
  static final AAXParameter<String> ADVERTISING_IDENTIFIER;
  
  static final AAXParameter<String> APP_KEY;
  
  static final AAXParameter<String> CHANNEL;
  
  static final AAXParameter<JSONObject> DEVICE_INFO;
  
  static final AAXParameter<Long> FLOOR_PRICE;
  
  static final AAXParameter<String> GEOLOCATION;
  
  private static final String LOG_TAG = AAXParameter.class.getSimpleName();
  
  static final AAXParameter<String> MAX_SIZE;
  
  static final AAXParameter<String> MD5_UDID;
  
  static final AAXParameter<Boolean> OPT_OUT;
  
  static final AAXParameter<JSONObject> PACKAGE_INFO;
  
  static final AAXParameter<String> PAGE_TYPE;
  
  static final AAXParameter<JSONArray> PUBLISHER_ASINS;
  
  static final PublisherKeywordsParameter PUBLISHER_KEYWORDS;
  
  static final AAXParameter<String> SDK_VERSION;
  
  static final AAXParameter<String> SHA1_UDID;
  
  static final AAXParameter<String> SIS_DEVICE_IDENTIFIER;
  
  static final AAXParameter<String> SIZE;
  
  static final AAXParameter<String> SLOT;
  
  static final AAXParameter<JSONArray> SLOTS;
  
  static final AAXParameter<Integer> SLOT_ID;
  
  static final AAXParameter<String> SLOT_POSITION;
  
  static final AAXParameter<JSONArray> SUPPORTED_MEDIA_TYPES;
  
  static final AAXParameter<Boolean> TEST;
  
  static final AAXParameter<String> USER_AGENT;
  
  static final AAXParameter<JSONObject> VIDEO_OPTIONS;
  
  private final String debugName;
  
  private final String name;
  
  static {
    APP_KEY = new AppKeyParameter();
    CHANNEL = new StringParameter("c", "debug.channel");
    PUBLISHER_KEYWORDS = new PublisherKeywordsParameter();
    PUBLISHER_ASINS = new JSONArrayParameter("pa", "debug.pa");
    USER_AGENT = new UserAgentParameter();
    SDK_VERSION = new SDKVersionParameter();
    GEOLOCATION = new GeoLocationParameter();
    DEVICE_INFO = new DeviceInfoParameter();
    PACKAGE_INFO = new PackageInfoParameter();
    TEST = new TestParameter();
    SIS_DEVICE_IDENTIFIER = new SISDeviceIdentifierParameter();
    SHA1_UDID = new SHA1UDIDParameter();
    MD5_UDID = new MD5UDIDParameter();
    SLOTS = new JSONArrayParameter("slots", "debug.slots");
    ADVERTISING_IDENTIFIER = new AdvertisingIdentifierParameter();
    OPT_OUT = new OptOutParameter();
    SIZE = new SizeParameter();
    PAGE_TYPE = new StringParameter("pt", "debug.pt");
    SLOT = new SlotParameter();
    SLOT_POSITION = new StringParameter("sp", "debug.sp");
    MAX_SIZE = new MaxSizeParameter();
    SLOT_ID = new SlotIdParameter();
    FLOOR_PRICE = new FloorPriceParameter();
    SUPPORTED_MEDIA_TYPES = new SupportedMediaTypesParameter();
    VIDEO_OPTIONS = new VideoOptionsParameter();
  }
  
  AAXParameter(String paramString1, String paramString2) {
    this.name = paramString1;
    this.debugName = paramString2;
  }
  
  protected T applyPostParameterProcessing(T paramT, ParameterData paramParameterData) {
    return paramT;
  }
  
  protected String getDebugName() {
    return this.debugName;
  }
  
  protected T getDerivedValue(ParameterData paramParameterData) {
    return null;
  }
  
  protected abstract T getFromDebugProperties();
  
  String getName() {
    return this.name;
  }
  
  T getValue(ParameterData paramParameterData) {
    T t1;
    if (hasDebugPropertiesValue()) {
      T t = getFromDebugProperties();
    } else if (paramParameterData.advancedOptions.containsKey(this.name)) {
      T t = parseFromString((String)paramParameterData.advancedOptions.remove(this.name));
    } else {
      t3 = getDerivedValue(paramParameterData);
    } 
    T t3 = applyPostParameterProcessing(t3, paramParameterData);
    T t2 = t3;
    if (t3 instanceof String) {
      t1 = t3;
      if (StringUtils.isNullOrWhiteSpace((String)t3))
        t1 = null; 
    } 
    return t1;
  }
  
  protected boolean hasDebugPropertiesValue() {
    return DebugProperties.getInstance().containsDebugProperty(this.debugName);
  }
  
  protected abstract T parseFromString(String paramString);
  
  static class AdvertisingIdentifierParameter extends StringParameter {
    AdvertisingIdentifierParameter() {
      super("idfa", "debug.idfa");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return param1ParameterData.adRequest.getAdvertisingIdentifierInfo().hasAdvertisingIdentifier() ? param1ParameterData.adRequest.getAdvertisingIdentifierInfo().getAdvertisingIdentifier() : null;
    }
  }
  
  static class AppKeyParameter extends StringParameter {
    AppKeyParameter() {
      super("appId", "debug.appid");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return AmazonRegistration.getInstance().getRegistrationInfo().getAppKey();
    }
  }
  
  static class BooleanParameter extends AAXParameter<Boolean> {
    BooleanParameter(String param1String1, String param1String2) {
      super(param1String1, param1String2);
    }
    
    protected Boolean getFromDebugProperties() {
      return DebugProperties.getInstance().getDebugPropertyAsBoolean(getDebugName(), (Boolean)null);
    }
    
    protected Boolean parseFromString(String param1String) {
      return Boolean.valueOf(Boolean.parseBoolean(param1String));
    }
  }
  
  static class DeviceInfoParameter extends JSONObjectParameter {
    DeviceInfoParameter() {
      super("dinfo", "debug.dinfo");
    }
    
    protected JSONObject getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return AmazonRegistration.getInstance().getDeviceInfo().toJsonObject(param1ParameterData.adRequest.getOrientation());
    }
  }
  
  static class FloorPriceParameter extends LongParameter {
    FloorPriceParameter() {
      super("ec", "debug.ec");
    }
    
    protected Long getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return param1ParameterData.loiSlot.getAdTargetingOptions().hasFloorPrice() ? Long.valueOf(param1ParameterData.loiSlot.getAdTargetingOptions().getFloorPrice()) : null;
    }
  }
  
  static class GeoLocationParameter extends StringParameter {
    GeoLocationParameter() {
      super("geoloc", "debug.geoloc");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      if (Configuration.getInstance().getBoolean(Configuration.ConfigOption.SEND_GEO) && param1ParameterData.adRequest.getAdTargetingOptions().isGeoLocationEnabled()) {
        Location location = (new AdLocation()).getLocation();
        if (location != null)
          return location.getLatitude() + "," + location.getLongitude(); 
      } 
      return null;
    }
  }
  
  static class IntegerParameter extends AAXParameter<Integer> {
    IntegerParameter(String param1String1, String param1String2) {
      super(param1String1, param1String2);
    }
    
    protected Integer getFromDebugProperties() {
      return DebugProperties.getInstance().getDebugPropertyAsInteger(getDebugName(), (Integer)null);
    }
    
    protected Integer parseFromString(String param1String) {
      return Integer.valueOf(Integer.parseInt(param1String));
    }
  }
  
  static class JSONArrayParameter extends AAXParameter<JSONArray> {
    JSONArrayParameter(String param1String1, String param1String2) {
      super(param1String1, param1String2);
    }
    
    protected JSONArray getFromDebugProperties() {
      return parseFromString(DebugProperties.getInstance().getDebugPropertyAsString(getDebugName(), null));
    }
    
    protected JSONArray parseFromString(String param1String) {
      try {
        return new JSONArray(param1String);
      } catch (JSONException jSONException) {
        Log.e(AAXParameter.LOG_TAG, "Unable to parse the following value into a JSONArray: %s", new Object[] { getName() });
        return null;
      } 
    }
  }
  
  static class JSONObjectParameter extends AAXParameter<JSONObject> {
    JSONObjectParameter(String param1String1, String param1String2) {
      super(param1String1, param1String2);
    }
    
    protected JSONObject getFromDebugProperties() {
      return parseFromString(DebugProperties.getInstance().getDebugPropertyAsString(getDebugName(), null));
    }
    
    protected JSONObject parseFromString(String param1String) {
      try {
        return new JSONObject(param1String);
      } catch (JSONException jSONException) {
        Log.e(AAXParameter.LOG_TAG, "Unable to parse the following value into a JSONObject: %s", new Object[] { getName() });
        return null;
      } 
    }
  }
  
  static class LongParameter extends AAXParameter<Long> {
    LongParameter(String param1String1, String param1String2) {
      super(param1String1, param1String2);
    }
    
    protected Long getFromDebugProperties() {
      return DebugProperties.getInstance().getDebugPropertyAsLong(getDebugName(), (Long)null);
    }
    
    protected Long parseFromString(String param1String) {
      return Long.valueOf(Long.parseLong(param1String));
    }
  }
  
  static class MD5UDIDParameter extends StringParameter {
    MD5UDIDParameter() {
      super("md5_udid", "debug.md5udid");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return !param1ParameterData.adRequest.getAdvertisingIdentifierInfo().hasAdvertisingIdentifier() ? AmazonRegistration.getInstance().getDeviceInfo().getUdidMd5() : null;
    }
  }
  
  static class MaxSizeParameter extends StringParameter {
    MaxSizeParameter() {
      super("mxsz", "debug.mxsz");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return param1ParameterData.loiSlot.getAdSlot().getMaxSize();
    }
  }
  
  static class OptOutParameter extends BooleanParameter {
    OptOutParameter() {
      super("oo", "debug.optOut");
    }
    
    protected Boolean getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return param1ParameterData.adRequest.getAdvertisingIdentifierInfo().hasAdvertisingIdentifier() ? Boolean.valueOf(param1ParameterData.adRequest.getAdvertisingIdentifierInfo().isLimitAdTrackingEnabled()) : null;
    }
  }
  
  static class PackageInfoParameter extends JSONObjectParameter {
    PackageInfoParameter() {
      super("pkg", "debug.pkg");
    }
    
    protected JSONObject getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return AmazonRegistration.getInstance().getAppInfo().getPackageInfoJSON();
    }
  }
  
  static class ParameterData {
    private AdRequest adRequest;
    
    private AdTargetingOptions adTargetingOptions;
    
    private Map<String, String> advancedOptions;
    
    private AdRequest.LOISlot loiSlot;
    
    private Map<String, String> temporaryOptions = new HashMap<String, String>();
    
    ParameterData setAdRequest(AdRequest param1AdRequest) {
      this.adRequest = param1AdRequest;
      return this;
    }
    
    ParameterData setAdTargetingOptions(AdTargetingOptions param1AdTargetingOptions) {
      this.adTargetingOptions = param1AdTargetingOptions;
      return this;
    }
    
    ParameterData setAdvancedOptions(Map<String, String> param1Map) {
      this.advancedOptions = param1Map;
      return this;
    }
    
    ParameterData setLOISlot(AdRequest.LOISlot param1LOISlot) {
      this.loiSlot = param1LOISlot;
      return this;
    }
  }
  
  static class PublisherKeywordsParameter extends JSONArrayParameter {
    PublisherKeywordsParameter() {
      super("pk", "debug.pk");
    }
    
    protected JSONArray applyPostParameterProcessing(JSONArray param1JSONArray, AAXParameter.ParameterData param1ParameterData) {
      JSONArray jSONArray = param1JSONArray;
      if (param1JSONArray == null)
        jSONArray = new JSONArray(); 
      Iterator<String> iterator = param1ParameterData.adTargetingOptions.getInternalPublisherKeywords().iterator();
      while (iterator.hasNext())
        jSONArray.put(iterator.next()); 
      return jSONArray;
    }
  }
  
  static class SDKVersionParameter extends StringParameter {
    SDKVersionParameter() {
      super("adsdk", "debug.ver");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return Version.getSDKVersion();
    }
  }
  
  static class SHA1UDIDParameter extends StringParameter {
    SHA1UDIDParameter() {
      super("sha1_udid", "debug.sha1udid");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return !param1ParameterData.adRequest.getAdvertisingIdentifierInfo().hasAdvertisingIdentifier() ? AmazonRegistration.getInstance().getDeviceInfo().getUdidSha1() : null;
    }
  }
  
  static class SISDeviceIdentifierParameter extends StringParameter {
    SISDeviceIdentifierParameter() {
      super("ad-id", "debug.adid");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return param1ParameterData.adRequest.getAdvertisingIdentifierInfo().getSISDeviceIdentifier();
    }
  }
  
  static class SizeParameter extends StringParameter {
    SizeParameter() {
      super("sz", "debug.size");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return param1ParameterData.loiSlot.getAdSlot().getRequestedAdSize().toString();
    }
  }
  
  static class SlotIdParameter extends IntegerParameter {
    SlotIdParameter() {
      super("slotId", "debug.slotId");
    }
    
    protected Integer getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return Integer.valueOf(param1ParameterData.loiSlot.getAdSlot().getSlotNumber());
    }
  }
  
  static class SlotParameter extends StringParameter {
    SlotParameter() {
      super("slot", "debug.slot");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return param1ParameterData.adRequest.getOrientation();
    }
  }
  
  static class StringParameter extends AAXParameter<String> {
    StringParameter(String param1String1, String param1String2) {
      super(param1String1, param1String2);
    }
    
    protected String getFromDebugProperties() {
      return DebugProperties.getInstance().getDebugPropertyAsString(getDebugName(), null);
    }
    
    protected String parseFromString(String param1String) {
      return param1String;
    }
  }
  
  static class SupportedMediaTypesParameter extends JSONArrayParameter {
    public SupportedMediaTypesParameter() {
      super("supportedMediaTypes", "debug.supportedMediaTypes");
    }
    
    private void addDisplay(AAXParameter.ParameterData param1ParameterData, JSONArray param1JSONArray) {
      boolean bool = param1ParameterData.loiSlot.getAdTargetingOptions().isDisplayAdsEnabled();
      if (param1ParameterData.advancedOptions.containsKey("enableDisplayAds"))
        bool = Boolean.parseBoolean((String)param1ParameterData.advancedOptions.remove("enableDisplayAds")); 
      if (bool)
        param1JSONArray.put("DISPLAY"); 
    }
    
    private void addVideo(AAXParameter.ParameterData param1ParameterData, JSONArray param1JSONArray) {
      if ((new AAXParameter.VideoAdsEnabledChecker(param1ParameterData)).isVideoAdsEnabled())
        param1JSONArray.put("VIDEO"); 
    }
    
    protected JSONArray getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      JSONArray jSONArray = new JSONArray();
      addDisplay(param1ParameterData, jSONArray);
      addVideo(param1ParameterData, jSONArray);
      return jSONArray;
    }
  }
  
  static class TestParameter extends BooleanParameter {
    TestParameter() {
      super("isTest", "debug.test");
    }
    
    protected Boolean getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return Settings.getInstance().getBoolean("testingEnabled", (Boolean)null);
    }
  }
  
  static class UserAgentParameter extends StringParameter {
    UserAgentParameter() {
      super("ua", "debug.ua");
    }
    
    protected String getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      return AmazonRegistration.getInstance().getDeviceInfo().getUserAgentString();
    }
  }
  
  private static class VideoAdsEnabledChecker {
    private final AAXParameter.ParameterData parameterData;
    
    public VideoAdsEnabledChecker(AAXParameter.ParameterData param1ParameterData) {
      this.parameterData = param1ParameterData;
    }
    
    public boolean isVideoAdsEnabled() {
      if (!this.parameterData.loiSlot.getAdTargetingOptions().isVideoEnabledSettable())
        return false; 
      if (this.parameterData.advancedOptions.containsKey("enableVideoAds")) {
        String str = (String)this.parameterData.advancedOptions.remove("enableVideoAds");
        this.parameterData.temporaryOptions.put("enableVideoAds", str);
        return Boolean.parseBoolean(str);
      } 
      return this.parameterData.temporaryOptions.containsKey("enableVideoAds") ? Boolean.parseBoolean((String)this.parameterData.temporaryOptions.get("enableVideoAds")) : this.parameterData.loiSlot.getAdTargetingOptions().isVideoAdsEnabled();
    }
  }
  
  static class VideoOptionsParameter extends JSONObjectParameter {
    private static final int MAXIMUM_DURATION_DEFAULT = 30000;
    
    private static final int MINIMUM_DURATION_DEFAULT = 0;
    
    public VideoOptionsParameter() {
      super("video", "debug.videoOptions");
    }
    
    protected JSONObject getDerivedValue(AAXParameter.ParameterData param1ParameterData) {
      JSONObject jSONObject = null;
      if ((new AAXParameter.VideoAdsEnabledChecker(param1ParameterData)).isVideoAdsEnabled()) {
        jSONObject = new JSONObject();
        int i = 0;
        if (param1ParameterData.advancedOptions.containsKey("minVideoAdDuration"))
          i = (new Parsers.IntegerParser()).setDefaultValue(0).setParseErrorLogTag(AAXParameter.LOG_TAG).setParseErrorLogMessage("The minVideoAdDuration advanced option could not be parsed properly.").parse((String)param1ParameterData.advancedOptions.remove("minVideoAdDuration")); 
        JSONUtils.put(jSONObject, "minAdDuration", i);
        i = 30000;
        if (param1ParameterData.advancedOptions.containsKey("maxVideoAdDuration"))
          i = (new Parsers.IntegerParser()).setDefaultValue(30000).setParseErrorLogTag(AAXParameter.LOG_TAG).setParseErrorLogMessage("The maxVideoAdDuration advanced option could not be parsed properly.").parse((String)param1ParameterData.advancedOptions.remove("maxVideoAdDuration")); 
        JSONUtils.put(jSONObject, "maxAdDuration", i);
      } 
      return jSONObject;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AAXParameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */