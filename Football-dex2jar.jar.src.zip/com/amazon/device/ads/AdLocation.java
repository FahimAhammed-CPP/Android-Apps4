package com.amazon.device.ads;

import android.location.Location;

class AdLocation {
  private static final String LOG_TAG = "AdLocation";
  
  private static final float MAX_DISTANCE_IN_KILOMETERS = 3.0F;
  
  private int arcminutePrecision = 6;
  
  private LocationAwareness locationAwareness = LocationAwareness.LOCATION_AWARENESS_TRUNCATED;
  
  private static double roundToArcminutes(double paramDouble) {
    return Math.round(paramDouble * 60.0D) / 60.0D;
  }
  
  public Location getLocation() {
    // Byte code:
    //   0: invokestatic getInstance : ()Lcom/amazon/device/ads/IAmazonRegistration;
    //   3: invokeinterface getApplicationContext : ()Landroid/content/Context;
    //   8: astore #5
    //   10: aload_0
    //   11: getfield locationAwareness : Lcom/amazon/device/ads/AdLocation$LocationAwareness;
    //   14: getstatic com/amazon/device/ads/AdLocation$LocationAwareness.LOCATION_AWARENESS_DISABLED : Lcom/amazon/device/ads/AdLocation$LocationAwareness;
    //   17: if_acmpne -> 22
    //   20: aconst_null
    //   21: areturn
    //   22: aload #5
    //   24: ldc 'location'
    //   26: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   29: checkcast android/location/LocationManager
    //   32: astore #7
    //   34: aconst_null
    //   35: astore #5
    //   37: aload #7
    //   39: ldc 'gps'
    //   41: invokevirtual getLastKnownLocation : (Ljava/lang/String;)Landroid/location/Location;
    //   44: astore #6
    //   46: aload #6
    //   48: astore #5
    //   50: aconst_null
    //   51: astore #6
    //   53: aload #7
    //   55: ldc 'network'
    //   57: invokevirtual getLastKnownLocation : (Ljava/lang/String;)Landroid/location/Location;
    //   60: astore #7
    //   62: aload #7
    //   64: astore #6
    //   66: aload #5
    //   68: ifnonnull -> 142
    //   71: aload #6
    //   73: ifnonnull -> 142
    //   76: aconst_null
    //   77: areturn
    //   78: astore #6
    //   80: ldc 'AdLocation'
    //   82: ldc 'Failed to retrieve GPS location: No permissions to access GPS'
    //   84: iconst_0
    //   85: anewarray java/lang/Object
    //   88: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   91: goto -> 50
    //   94: astore #6
    //   96: ldc 'AdLocation'
    //   98: ldc 'Failed to retrieve GPS location: No GPS found'
    //   100: iconst_0
    //   101: anewarray java/lang/Object
    //   104: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   107: goto -> 50
    //   110: astore #7
    //   112: ldc 'AdLocation'
    //   114: ldc 'Failed to retrieve network location: No permissions to access network location'
    //   116: iconst_0
    //   117: anewarray java/lang/Object
    //   120: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   123: goto -> 66
    //   126: astore #7
    //   128: ldc 'AdLocation'
    //   130: ldc 'Failed to retrieve network location: No network provider found'
    //   132: iconst_0
    //   133: anewarray java/lang/Object
    //   136: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   139: goto -> 66
    //   142: aload #5
    //   144: ifnull -> 391
    //   147: aload #6
    //   149: ifnull -> 391
    //   152: aload #5
    //   154: aload #6
    //   156: invokevirtual distanceTo : (Landroid/location/Location;)F
    //   159: ldc 1000.0
    //   161: fdiv
    //   162: ldc 3.0
    //   164: fcmpg
    //   165: ifgt -> 345
    //   168: aload #5
    //   170: invokevirtual hasAccuracy : ()Z
    //   173: ifeq -> 314
    //   176: aload #5
    //   178: invokevirtual getAccuracy : ()F
    //   181: fstore_3
    //   182: aload #6
    //   184: invokevirtual hasAccuracy : ()Z
    //   187: ifeq -> 320
    //   190: aload #6
    //   192: invokevirtual getAccuracy : ()F
    //   195: fstore #4
    //   197: fload_3
    //   198: fload #4
    //   200: fcmpg
    //   201: ifge -> 327
    //   204: ldc 'AdLocation'
    //   206: ldc 'Setting lat/long using GPS determined by distance'
    //   208: iconst_0
    //   209: anewarray java/lang/Object
    //   212: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   215: aload_0
    //   216: getfield locationAwareness : Lcom/amazon/device/ads/AdLocation$LocationAwareness;
    //   219: getstatic com/amazon/device/ads/AdLocation$LocationAwareness.LOCATION_AWARENESS_TRUNCATED : Lcom/amazon/device/ads/AdLocation$LocationAwareness;
    //   222: if_acmpne -> 311
    //   225: aload #5
    //   227: invokevirtual getLatitude : ()D
    //   230: invokestatic roundToArcminutes : (D)D
    //   233: dstore_1
    //   234: aload #5
    //   236: ldc2_w 10.0
    //   239: aload_0
    //   240: getfield arcminutePrecision : I
    //   243: i2d
    //   244: invokestatic pow : (DD)D
    //   247: dload_1
    //   248: dmul
    //   249: invokestatic round : (D)J
    //   252: l2d
    //   253: ldc2_w 10.0
    //   256: aload_0
    //   257: getfield arcminutePrecision : I
    //   260: i2d
    //   261: invokestatic pow : (DD)D
    //   264: ddiv
    //   265: invokevirtual setLatitude : (D)V
    //   268: aload #5
    //   270: invokevirtual getLongitude : ()D
    //   273: invokestatic roundToArcminutes : (D)D
    //   276: dstore_1
    //   277: aload #5
    //   279: ldc2_w 10.0
    //   282: aload_0
    //   283: getfield arcminutePrecision : I
    //   286: i2d
    //   287: invokestatic pow : (DD)D
    //   290: dload_1
    //   291: dmul
    //   292: invokestatic round : (D)J
    //   295: l2d
    //   296: ldc2_w 10.0
    //   299: aload_0
    //   300: getfield arcminutePrecision : I
    //   303: i2d
    //   304: invokestatic pow : (DD)D
    //   307: ddiv
    //   308: invokevirtual setLongitude : (D)V
    //   311: aload #5
    //   313: areturn
    //   314: ldc 3.4028235E38
    //   316: fstore_3
    //   317: goto -> 182
    //   320: ldc 3.4028235E38
    //   322: fstore #4
    //   324: goto -> 197
    //   327: ldc 'AdLocation'
    //   329: ldc 'Setting lat/long using network determined by distance'
    //   331: iconst_0
    //   332: anewarray java/lang/Object
    //   335: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   338: aload #6
    //   340: astore #5
    //   342: goto -> 215
    //   345: aload #5
    //   347: invokevirtual getTime : ()J
    //   350: aload #6
    //   352: invokevirtual getTime : ()J
    //   355: lcmp
    //   356: ifle -> 373
    //   359: ldc 'AdLocation'
    //   361: ldc 'Setting lat/long using GPS'
    //   363: iconst_0
    //   364: anewarray java/lang/Object
    //   367: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   370: goto -> 215
    //   373: ldc 'AdLocation'
    //   375: ldc 'Setting lat/long using network'
    //   377: iconst_0
    //   378: anewarray java/lang/Object
    //   381: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   384: aload #6
    //   386: astore #5
    //   388: goto -> 215
    //   391: aload #5
    //   393: ifnull -> 410
    //   396: ldc 'AdLocation'
    //   398: ldc 'Setting lat/long using GPS, not network'
    //   400: iconst_0
    //   401: anewarray java/lang/Object
    //   404: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   407: goto -> 215
    //   410: ldc 'AdLocation'
    //   412: ldc 'Setting lat/long using network location, not GPS'
    //   414: iconst_0
    //   415: anewarray java/lang/Object
    //   418: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   421: aload #6
    //   423: astore #5
    //   425: goto -> 215
    // Exception table:
    //   from	to	target	type
    //   37	46	78	java/lang/SecurityException
    //   37	46	94	java/lang/IllegalArgumentException
    //   53	62	110	java/lang/SecurityException
    //   53	62	126	java/lang/IllegalArgumentException
  }
  
  private enum LocationAwareness {
    LOCATION_AWARENESS_DISABLED, LOCATION_AWARENESS_NORMAL, LOCATION_AWARENESS_TRUNCATED;
    
    static {
      $VALUES = new LocationAwareness[] { LOCATION_AWARENESS_NORMAL, LOCATION_AWARENESS_TRUNCATED, LOCATION_AWARENESS_DISABLED };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */