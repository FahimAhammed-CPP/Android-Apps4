package com.amazon.device.ads;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;

class ConnectionInfo {
  private static final String LOG_TAG = ConnectionInfo.class.getSimpleName();
  
  private static final String WIFI_NAME = "Wifi";
  
  private String connectionType;
  
  private ConnectivityManager connectivityManager;
  
  public ConnectionInfo() {
    initialize((ConnectivityManager)AmazonRegistration.getInstance().getApplicationContext().getSystemService("connectivity"));
  }
  
  ConnectionInfo(ConnectivityManager paramConnectivityManager) {
    initialize(paramConnectivityManager);
  }
  
  private void generateConnectionType() {
    NetworkInfo networkInfo2 = null;
    NetworkInfo networkInfo1 = networkInfo2;
    try {
      if (this.connectivityManager != null)
        networkInfo1 = this.connectivityManager.getActiveNetworkInfo(); 
      if (networkInfo1 != null) {
        if (networkInfo1.getType() == 1) {
          this.connectionType = "Wifi";
          return;
        } 
        this.connectionType = Integer.toString(networkInfo1.getSubtype());
        return;
      } 
    } catch (SecurityException securityException) {
      Log.d(LOG_TAG, "Unable to get active network information: %s", new Object[] { securityException });
      NetworkInfo networkInfo = networkInfo2;
      if (networkInfo != null) {
        if (networkInfo.getType() == 1) {
          this.connectionType = "Wifi";
          return;
        } 
        this.connectionType = Integer.toString(networkInfo.getSubtype());
        return;
      } 
    } 
    this.connectionType = Integer.toString(0);
  }
  
  private void initialize(ConnectivityManager paramConnectivityManager) {
    this.connectivityManager = paramConnectivityManager;
    refresh();
  }
  
  public String getConnectionType() {
    return this.connectionType;
  }
  
  public boolean isWiFi() {
    return "Wifi".equals(getConnectionType());
  }
  
  public void refresh() {
    generateConnectionType();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ConnectionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */