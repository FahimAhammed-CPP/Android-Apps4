package com.amazon.device.ads;

public class AdSize {
  private static final String LOG_TAG = "AdSize";
  
  public static final AdSize SIZE_1024x50;
  
  public static final AdSize SIZE_300x250;
  
  public static final AdSize SIZE_300x50 = new AdSize(300, 50);
  
  public static final AdSize SIZE_320x50 = new AdSize(320, 50);
  
  public static final AdSize SIZE_600x90;
  
  public static final AdSize SIZE_728x90;
  
  public static final AdSize SIZE_AUTO;
  
  static final AdSize SIZE_INTERSTITIAL;
  
  static final AdSize SIZE_MODELESS_INTERSTITIAL;
  
  private int height;
  
  private Modality modality = Modality.MODELESS;
  
  private SizeType type;
  
  private int width;
  
  static {
    SIZE_300x250 = new AdSize(300, 250);
    SIZE_600x90 = new AdSize(600, 90);
    SIZE_728x90 = new AdSize(728, 90);
    SIZE_1024x50 = new AdSize(1024, 50);
    SIZE_AUTO = new AdSize(SizeType.AUTO);
    SIZE_INTERSTITIAL = new AdSize(SizeType.INTERSTITIAL, Modality.MODAL);
    SIZE_MODELESS_INTERSTITIAL = new AdSize(SizeType.INTERSTITIAL);
  }
  
  public AdSize(int paramInt1, int paramInt2) {
    initialize(paramInt1, paramInt2);
  }
  
  AdSize(SizeType paramSizeType) {
    this(paramSizeType, Modality.MODELESS);
  }
  
  AdSize(SizeType paramSizeType, Modality paramModality) {
    this.type = paramSizeType;
    this.modality = paramModality;
  }
  
  AdSize(String paramString1, String paramString2) {
    initialize(NumberUtils.parseInt(paramString1, 0), NumberUtils.parseInt(paramString2, 0));
  }
  
  static String getAsSizeString(int paramInt1, int paramInt2) {
    return Integer.toString(paramInt1) + "x" + Integer.toString(paramInt2);
  }
  
  private void initialize(int paramInt1, int paramInt2) {
    if (paramInt1 <= 0 || paramInt2 <= 0) {
      Log.e("AdSize", "The width and height must be positive integers.", new Object[0]);
      throw new IllegalArgumentException("The width and height must be positive integers.");
    } 
    this.width = paramInt1;
    this.height = paramInt2;
    this.type = SizeType.EXPLICIT;
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof AdSize) ? toString().equals(paramObject.toString()) : false;
  }
  
  public int getHeight() {
    return this.height;
  }
  
  public int getWidth() {
    return this.width;
  }
  
  public boolean isAuto() {
    return (this.type == SizeType.AUTO);
  }
  
  boolean isModal() {
    return Modality.MODAL.equals(this.modality);
  }
  
  public String toString() {
    switch (this.type) {
      default:
        return null;
      case EXPLICIT:
        return getAsSizeString(this.width, this.height);
      case AUTO:
        return "auto";
      case INTERSTITIAL:
        break;
    } 
    return "interstitial";
  }
  
  private enum Modality {
    MODAL, MODELESS;
    
    static {
    
    }
  }
  
  private enum SizeType {
    EXPLICIT, INTERSTITIAL, AUTO;
    
    static {
      $VALUES = new SizeType[] { EXPLICIT, AUTO, INTERSTITIAL };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */