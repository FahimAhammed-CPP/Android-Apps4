package com.amazon.device.ads;

import android.content.Context;

class AdUtils2 {
  private final AdUtilsStatic adUtilsAdapter = new AdUtilsStatic();
  
  double calculateScalingMultiplier(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return this.adUtilsAdapter.calculateScalingMultiplier(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  boolean checkDefinedActivities(Context paramContext) {
    return this.adUtilsAdapter.checkDefinedActivities(paramContext);
  }
  
  int deviceIndependentPixelToPixel(int paramInt) {
    return this.adUtilsAdapter.deviceIndependentPixelToPixel(paramInt);
  }
  
  float getScalingFactorAsFloat() {
    return this.adUtilsAdapter.getScalingFactorAsFloat();
  }
  
  double getViewportInitialScale(double paramDouble) {
    return this.adUtilsAdapter.getViewportInitialScale(paramDouble);
  }
  
  int pixelToDeviceIndependentPixel(int paramInt) {
    return this.adUtilsAdapter.pixelToDeviceIndependentPixel(paramInt);
  }
  
  void setConnectionMetrics(ConnectionInfo paramConnectionInfo, MetricsCollector paramMetricsCollector) {
    this.adUtilsAdapter.setConnectionMetrics(paramConnectionInfo, paramMetricsCollector);
  }
  
  private static class AdUtilsStatic {
    private AdUtilsStatic() {}
    
    double calculateScalingMultiplier(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return AdUtils.calculateScalingMultiplier(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    boolean checkDefinedActivities(Context param1Context) {
      return AdUtils.checkDefinedActivities(param1Context);
    }
    
    int deviceIndependentPixelToPixel(int param1Int) {
      return AdUtils.deviceIndependentPixelToPixel(param1Int);
    }
    
    float getScalingFactorAsFloat() {
      return AdUtils.getScalingFactorAsFloat();
    }
    
    double getViewportInitialScale(double param1Double) {
      return AdUtils.getViewportInitialScale(param1Double);
    }
    
    int pixelToDeviceIndependentPixel(int param1Int) {
      return AdUtils.pixelToDeviceIndependentPixel(param1Int);
    }
    
    void setConnectionMetrics(ConnectionInfo param1ConnectionInfo, MetricsCollector param1MetricsCollector) {
      AdUtils.setConnectionMetrics(param1ConnectionInfo, param1MetricsCollector);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdUtils2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */