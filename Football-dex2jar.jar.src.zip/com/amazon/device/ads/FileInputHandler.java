package com.amazon.device.ads;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

class FileInputHandler extends FileHandler {
  private static final String LOGTAG = FileInputHandler.class.getSimpleName();
  
  private BufferedReader bufferedReader;
  
  private InputStream inputStream;
  
  private void checkReadable() {
    if (this.bufferedReader == null)
      throw new IllegalStateException("Could not read from the file because no file has been opened yet. Please set the file, then call open() before attempting to read."); 
  }
  
  public void close() {
    closeCloseables();
    this.bufferedReader = null;
    this.inputStream = null;
  }
  
  protected Closeable getCloseableReaderWriter() {
    return this.bufferedReader;
  }
  
  protected Closeable getCloseableStream() {
    return this.inputStream;
  }
  
  public boolean isOpen() {
    return (this.inputStream != null);
  }
  
  public boolean open() {
    if (this.file == null) {
      Log.e(LOGTAG, "A file must be set before it can be opened.", new Object[0]);
      return false;
    } 
    if (this.inputStream != null) {
      Log.e(LOGTAG, "The file is already open.", new Object[0]);
      return false;
    } 
    try {
      FileInputStream fileInputStream = new FileInputStream(this.file);
      this.inputStream = new BufferedInputStream(fileInputStream);
      this.bufferedReader = new BufferedReader(new InputStreamReader(this.inputStream));
      return true;
    } catch (Exception exception) {
      return false;
    } 
  }
  
  public byte[] readAllBytesFromFileAndClose() {
    if (!isOpen() && !open()) {
      Log.e(LOGTAG, "Could not open the file for reading", new Object[0]);
      return null;
    } 
    byte[] arrayOfByte = readBytes();
    close();
    return arrayOfByte;
  }
  
  public byte[] readBytes() {
    checkReadable();
    int i = 0;
    try {
      byte[] arrayOfByte = new byte[(int)this.file.length()];
      while (true) {
        byte[] arrayOfByte1 = arrayOfByte;
        if (i < arrayOfByte.length) {
          int j = arrayOfByte.length;
          j = this.inputStream.read(arrayOfByte, i, j - i);
          if (j > 0)
            i += j; 
          continue;
        } 
        break;
      } 
    } catch (IOException iOException) {
      Log.e(LOGTAG, "Error reading bytes from input file: %s", new Object[] { iOException.getMessage() });
      iOException = null;
    } 
    return (byte[])iOException;
  }
  
  public String readLine() {
    checkReadable();
    try {
      return this.bufferedReader.readLine();
    } catch (IOException iOException) {
      Log.e(LOGTAG, "Error reading line from file.", new Object[0]);
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\FileInputHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */