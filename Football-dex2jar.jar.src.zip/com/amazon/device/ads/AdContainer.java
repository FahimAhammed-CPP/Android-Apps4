package com.amazon.device.ads;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import java.util.Iterator;

@SuppressLint({"ViewConstructor"})
class AdContainer extends FrameLayout {
  private static final String CONTENT_DESCRIPTION_AD_CONTAINER = "adContainerObject";
  
  private static final String CONTENT_DESCRITPION_NATIVE_CLOSE_BUTTON = "nativeCloseButton";
  
  private static final String CONTENT_DESCRITPION_NATIVE_CLOSE_BUTTON_CONTAINER = "nativeCloseButtonContainer";
  
  private static final String CONTENT_DESCRITPION_NATIVE_CLOSE_BUTTON_IMAGE = "nativeCloseButtonImage";
  
  private static final String LOGTAG = AdContainer.class.getSimpleName();
  
  private final int CLOSE_BUTTON_SIZE_DP = 60;
  
  private final int CLOSE_BUTTON_TAP_TARGET_SIZE_DP = 80;
  
  private final AdController adController;
  
  private AdWebViewClient adWebViewClient;
  
  private boolean allowClicks = true;
  
  private String baseUrl;
  
  private final AdSDKBridgeList bridgeList = new AdSDKBridgeList();
  
  private RelativeLayout closeButton;
  
  private RelativeLayout closeButtonContainer;
  
  private ImageView closeButtonImage;
  
  private boolean disableHardwareAcceleration = false;
  
  private String html;
  
  private final Log2 log;
  
  private PreloadCallback preloadCallback;
  
  private boolean shouldPreload;
  
  private ViewManager viewManager;
  
  private final WebUtils2 webUtils;
  
  public AdContainer(Context paramContext, AdController paramAdController, WebUtils2 paramWebUtils2, Log2 paramLog2) {
    super(paramContext);
    this.adController = paramAdController;
    this.webUtils = paramWebUtils2;
    this.log = paramLog2;
    setContentDescription("adContainerObject");
  }
  
  private String addHeadData(String paramString1, String paramString2) {
    String str3 = StringUtils.getFirstMatch("<[Hh][Ee][Aa][Dd](\\s*>|\\s[^>]*>)", paramString1);
    String str1 = "";
    if (!StringUtils.containsRegEx("<[Mm][Ee][Tt][Aa](\\s[^>]*\\s|\\s)[Nn][Aa][Mm][Ee]\\s*=\\s*[\"'][Vv][Ii][Ee][Ww][Pp][Oo][Rr][Tt][\"']", paramString1))
      if (this.adController.getScalingMultiplier() >= 0.0D) {
        str1 = "" + "<meta name=\"viewport\" content=\"width=" + this.adController.getWindowWidth() + ", height=" + this.adController.getWindowHeight() + ", initial-scale=" + AdUtils.getViewportInitialScale(this.adController.getScalingMultiplier()) + ", minimum-scale=" + this.adController.getScalingMultiplier() + ", maximum-scale=" + this.adController.getScalingMultiplier() + "\"/>";
      } else {
        str1 = "" + "<meta name=\"viewport\" content=\"width=device-width, height=device-height, user-scalable=no, initial-scale=1.0\"/>";
      }  
    String str2 = str1 + "<style>html,body{margin:0;padding:0;height:100%;border:none;}</style>";
    str1 = str2;
    if (paramString2.length() > 0)
      str1 = str2 + "<script type='text/javascript'>" + paramString2 + "</script>"; 
    return paramString1.replace(str3, str3 + str1);
  }
  
  private String ensureHtmlTags(String paramString) {
    String str3 = "";
    String str1 = "";
    if (!StringUtils.containsRegEx("\\A\\s*<![Dd][Oo][Cc][Tt][Yy][Pp][Ee]\\s+[Hh][Tt][Mm][Ll][\\s>]", paramString))
      str3 = "<!DOCTYPE html>"; 
    String str2 = str3;
    if (!StringUtils.containsRegEx("<[Hh][Tt][Mm][Ll][\\s>]", paramString)) {
      str2 = str3 + "<html>";
      str1 = "</html>";
    } 
    str3 = str2;
    if (!StringUtils.containsRegEx("<[Hh][Ee][Aa][Dd][\\s>]", paramString))
      str3 = str2 + "<head></head>"; 
    String str4 = str3;
    str2 = str1;
    if (!StringUtils.containsRegEx("<[Bb][Oo][Dd][Yy][\\s>]", paramString)) {
      str4 = str3 + "<body>";
      str2 = "</body>" + str1;
    } 
    return str4 + paramString + str2;
  }
  
  private AdWebViewClient getAdWebViewClient() {
    if (this.adWebViewClient == null)
      this.adWebViewClient = new AdWebViewClient(getContext(), this.bridgeList, this.adController.getAdControlAccessor(), this.webUtils, this.log); 
    return this.adWebViewClient;
  }
  
  private ViewManager getViewManager() {
    if (this.viewManager == null) {
      this.viewManager = createViewManager();
      setAdWebViewClient();
    } 
    return this.viewManager;
  }
  
  private void loadHtml(String paramString1, String paramString2, boolean paramBoolean, PreloadCallback paramPreloadCallback) {
    this.baseUrl = paramString1;
    this.html = paramString2;
    this.shouldPreload = paramBoolean;
    this.preloadCallback = paramPreloadCallback;
    Iterator<AdSDKBridgeFactory> iterator = BridgeSelector.getInstance().getBridgeFactories(paramString2).iterator();
    while (iterator.hasNext())
      addAdSDKBridge(((AdSDKBridgeFactory)iterator.next()).createAdSDKBridge(this.adController.getAdControlAccessor())); 
    getViewManager().removePreviousInterfaces();
    this.adController.clearSDKEventListeners();
    this.log.d(LOGTAG, "Scaling Params: scalingDensity: %f, windowWidth: %d, windowHeight: %d, adWidth: %d, adHeight: %d, scale: %f", new Object[] { Float.valueOf(AdUtils.getScalingFactorAsFloat()), Integer.valueOf(this.adController.getWindowWidth()), Integer.valueOf(this.adController.getWindowHeight()), Integer.valueOf((int)(this.adController.getAdData().getWidth() * AdUtils.getScalingFactorAsFloat())), Integer.valueOf((int)(this.adController.getAdData().getHeight() * AdUtils.getScalingFactorAsFloat())), Double.valueOf(this.adController.getScalingMultiplier()) });
    String str = "";
    for (AdSDKBridge adSDKBridge : this.bridgeList) {
      if (adSDKBridge.getSDKEventListener() != null)
        this.adController.addSDKEventListener(adSDKBridge.getSDKEventListener()); 
      String str1 = str;
      if (adSDKBridge.getJavascript() != null)
        str1 = str + adSDKBridge.getJavascript(); 
      str = str1;
      if (adSDKBridge.hasNativeExecution()) {
        this.viewManager.addJavascriptInterface(adSDKBridge.getJavascriptInteractorExecutor(), paramBoolean, adSDKBridge.getName());
        str = str1;
      } 
    } 
    paramString2 = addHeadData(ensureHtmlTags(paramString2), str);
    if (paramString1 != null) {
      this.viewManager.loadDataWithBaseURL(paramString1, paramString2, "text/html", "UTF-8", null, paramBoolean, paramPreloadCallback);
      return;
    } 
    this.viewManager.loadData(paramString2, "text/html", "UTF-8", paramBoolean, paramPreloadCallback);
  }
  
  private void loadUrl(final String url, final boolean shouldPreload, final PreloadCallback callback) {
    String str = WebUtils.getScheme(url);
    if (str.equals("http") || str.equals("https")) {
      ThreadUtils.executeRunnableWithThreadCheck(new Runnable() {
            public void run() {
              // Byte code:
              //   0: invokestatic createNewWebRequest : ()Lcom/amazon/device/ads/WebRequest;
              //   3: astore_2
              //   4: aload_2
              //   5: invokestatic access$100 : ()Ljava/lang/String;
              //   8: invokevirtual setExternalLogTag : (Ljava/lang/String;)V
              //   11: aload_2
              //   12: iconst_1
              //   13: invokevirtual enableLogUrl : (Z)V
              //   16: aload_2
              //   17: aload_0
              //   18: getfield val$url : Ljava/lang/String;
              //   21: invokevirtual setUrlString : (Ljava/lang/String;)V
              //   24: aload_2
              //   25: ldc 'User-Agent'
              //   27: invokestatic getInstance : ()Lcom/amazon/device/ads/IAmazonRegistration;
              //   30: invokeinterface getDeviceInfo : ()Lcom/amazon/device/ads/DeviceInfo;
              //   35: invokevirtual getUserAgentString : ()Ljava/lang/String;
              //   38: invokevirtual putHeader : (Ljava/lang/String;Ljava/lang/String;)V
              //   41: aconst_null
              //   42: astore_1
              //   43: aload_2
              //   44: invokevirtual makeCall : ()Lcom/amazon/device/ads/WebRequest$WebResponse;
              //   47: astore_2
              //   48: aload_2
              //   49: astore_1
              //   50: aload_1
              //   51: ifnull -> 78
              //   54: aload_1
              //   55: invokevirtual getResponseReader : ()Lcom/amazon/device/ads/ResponseReader;
              //   58: invokevirtual readAsString : ()Ljava/lang/String;
              //   61: astore_1
              //   62: aload_1
              //   63: ifnull -> 109
              //   66: new com/amazon/device/ads/AdContainer$1$1
              //   69: dup
              //   70: aload_0
              //   71: aload_1
              //   72: invokespecial <init> : (Lcom/amazon/device/ads/AdContainer$1;Ljava/lang/String;)V
              //   75: invokestatic executeOnMainThread : (Ljava/lang/Runnable;)V
              //   78: return
              //   79: astore_2
              //   80: invokestatic access$100 : ()Ljava/lang/String;
              //   83: ldc 'Could not load URL (%s) into AdContainer: %s'
              //   85: iconst_2
              //   86: anewarray java/lang/Object
              //   89: dup
              //   90: iconst_0
              //   91: aload_0
              //   92: getfield val$url : Ljava/lang/String;
              //   95: aastore
              //   96: dup
              //   97: iconst_1
              //   98: aload_2
              //   99: invokevirtual getMessage : ()Ljava/lang/String;
              //   102: aastore
              //   103: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
              //   106: goto -> 50
              //   109: invokestatic access$100 : ()Ljava/lang/String;
              //   112: ldc 'Could not load URL (%s) into AdContainer.'
              //   114: iconst_1
              //   115: anewarray java/lang/Object
              //   118: dup
              //   119: iconst_0
              //   120: aload_0
              //   121: getfield val$url : Ljava/lang/String;
              //   124: aastore
              //   125: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
              //   128: return
              // Exception table:
              //   from	to	target	type
              //   43	48	79	com/amazon/device/ads/WebRequest$WebRequestException
            }
          });
      return;
    } 
    getAdWebViewClient().shouldOverrideUrlLoading(null, url);
  }
  
  public void addAdSDKBridge(AdSDKBridge paramAdSDKBridge) {
    this.bridgeList.addBridge(paramAdSDKBridge);
  }
  
  void addJavascriptInterface(Object paramObject, boolean paramBoolean, String paramString) {
    getViewManager().addJavascriptInterface(paramObject, paramBoolean, paramString);
  }
  
  ViewManager createViewManager() {
    return new ViewManager((ViewGroup)this);
  }
  
  public void destroy() {
    getViewManager().destroy();
    this.bridgeList.clear();
  }
  
  public void disableHardwareAcceleration(boolean paramBoolean) {
    this.disableHardwareAcceleration = paramBoolean;
    if (this.viewManager != null)
      this.viewManager.disableHardwareAcceleration(this.disableHardwareAcceleration); 
  }
  
  public void enableNativeCloseButton(final boolean showImage, final RelativePosition position) {
    if (this.closeButton != null && this.closeButtonImage != null && equals(this.closeButton.getParent()) && this.closeButton.equals(this.closeButtonImage.getParent()))
      return; 
    DisplayMetrics displayMetrics = new DisplayMetrics();
    ((WindowManager)getContext().getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
    final int buttonSize = (int)(60.0F * displayMetrics.density + 0.5F);
    final int tapTargetSize = (int)(80.0F * displayMetrics.density + 0.5F);
    ThreadUtils.executeAsyncTask(new AsyncTask<Void, Void, Void>() {
          protected Void doInBackground(Void... param1VarArgs) {
            AdContainer adContainer;
            RelativeLayout.LayoutParams layoutParams;
            boolean bool = false;
            synchronized (AdContainer.this) {
              if (AdContainer.this.closeButton == null) {
                AdContainer.access$302(AdContainer.this, new RelativeLayout(AdContainer.this.getContext()));
                AdContainer.this.closeButton.setContentDescription("nativeCloseButton");
                AdContainer.access$402(AdContainer.this, (ImageView)new ImageButton(AdContainer.this.getContext()));
                AdContainer.this.closeButtonImage.setContentDescription("nativeCloseButtonImage");
                bool = true;
              } 
              if (bool) {
                AdContainer.this.closeButtonImage.setImageDrawable((Drawable)closeNormal);
                AdContainer.this.closeButtonImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
                AdContainer.this.closeButtonImage.setBackgroundDrawable(null);
                View.OnClickListener onClickListener = new View.OnClickListener() {
                    public void onClick(View param2View) {
                      AdContainer.this.adController.closeAd();
                    }
                  };
                AdContainer.this.closeButtonImage.setOnClickListener(onClickListener);
                AdContainer.this.closeButton.setOnClickListener(onClickListener);
                View.OnTouchListener onTouchListener = new View.OnTouchListener() {
                    public boolean onTouch(View param2View, MotionEvent param2MotionEvent) {
                      switch (param2MotionEvent.getAction()) {
                        default:
                          return false;
                        case 0:
                          AdContainer.this.closeButtonImage.setImageDrawable((Drawable)closePressed);
                        case 1:
                          break;
                      } 
                      AdContainer.this.closeButtonImage.setImageDrawable((Drawable)closeNormal);
                    }
                  };
                AdContainer.this.closeButton.setOnTouchListener(onTouchListener);
                AdContainer.this.closeButtonImage.setOnTouchListener(onTouchListener);
                layoutParams = new RelativeLayout.LayoutParams(tapTargetSize, tapTargetSize);
                layoutParams.addRule(11);
                layoutParams.addRule(10);
                AdContainer.access$602(AdContainer.this, new RelativeLayout(AdContainer.this.getContext()));
                AdContainer.this.closeButtonContainer.setContentDescription("nativeCloseButtonContainer");
                AdContainer.this.closeButtonContainer.addView((View)AdContainer.this.closeButton, (ViewGroup.LayoutParams)layoutParams);
              } 
              return null;
            } 
          }
          
          protected void onPostExecute(Void param1Void) {
            // Byte code:
            //   0: aload_0
            //   1: getfield val$showImage : Z
            //   4: ifeq -> 230
            //   7: aload_0
            //   8: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   11: invokestatic access$300 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/RelativeLayout;
            //   14: aload_0
            //   15: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   18: invokestatic access$400 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/ImageView;
            //   21: invokevirtual getParent : ()Landroid/view/ViewParent;
            //   24: invokevirtual equals : (Ljava/lang/Object;)Z
            //   27: ifne -> 230
            //   30: new android/widget/RelativeLayout$LayoutParams
            //   33: dup
            //   34: aload_0
            //   35: getfield val$buttonSize : I
            //   38: aload_0
            //   39: getfield val$buttonSize : I
            //   42: invokespecial <init> : (II)V
            //   45: astore_1
            //   46: aload_1
            //   47: bipush #13
            //   49: invokevirtual addRule : (I)V
            //   52: aload_0
            //   53: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   56: invokestatic access$300 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/RelativeLayout;
            //   59: aload_0
            //   60: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   63: invokestatic access$400 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/ImageView;
            //   66: aload_1
            //   67: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
            //   70: aload_0
            //   71: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   74: aload_0
            //   75: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   78: invokestatic access$600 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/RelativeLayout;
            //   81: invokevirtual getParent : ()Landroid/view/ViewParent;
            //   84: invokevirtual equals : (Ljava/lang/Object;)Z
            //   87: ifne -> 113
            //   90: aload_0
            //   91: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   94: aload_0
            //   95: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   98: invokestatic access$600 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/RelativeLayout;
            //   101: new android/widget/FrameLayout$LayoutParams
            //   104: dup
            //   105: iconst_m1
            //   106: iconst_m1
            //   107: invokespecial <init> : (II)V
            //   110: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
            //   113: new android/widget/RelativeLayout$LayoutParams
            //   116: dup
            //   117: aload_0
            //   118: getfield val$tapTargetSize : I
            //   121: aload_0
            //   122: getfield val$tapTargetSize : I
            //   125: invokespecial <init> : (II)V
            //   128: astore_2
            //   129: aload_0
            //   130: getfield val$position : Lcom/amazon/device/ads/RelativePosition;
            //   133: astore_1
            //   134: aload_0
            //   135: getfield val$position : Lcom/amazon/device/ads/RelativePosition;
            //   138: ifnonnull -> 145
            //   141: getstatic com/amazon/device/ads/RelativePosition.TOP_RIGHT : Lcom/amazon/device/ads/RelativePosition;
            //   144: astore_1
            //   145: getstatic com/amazon/device/ads/AdContainer$5.$SwitchMap$com$amazon$device$ads$RelativePosition : [I
            //   148: aload_1
            //   149: invokevirtual ordinal : ()I
            //   152: iaload
            //   153: tableswitch default -> 196, 1 -> 280, 2 -> 295, 3 -> 310, 4 -> 325, 5 -> 334, 6 -> 349, 7 -> 364
            //   196: aload_2
            //   197: bipush #10
            //   199: invokevirtual addRule : (I)V
            //   202: aload_2
            //   203: bipush #11
            //   205: invokevirtual addRule : (I)V
            //   208: aload_0
            //   209: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   212: invokestatic access$300 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/RelativeLayout;
            //   215: aload_2
            //   216: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
            //   219: aload_0
            //   220: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   223: invokestatic access$600 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/RelativeLayout;
            //   226: invokevirtual bringToFront : ()V
            //   229: return
            //   230: aload_0
            //   231: getfield val$showImage : Z
            //   234: ifne -> 70
            //   237: aload_0
            //   238: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   241: invokestatic access$300 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/RelativeLayout;
            //   244: aload_0
            //   245: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   248: invokestatic access$400 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/ImageView;
            //   251: invokevirtual getParent : ()Landroid/view/ViewParent;
            //   254: invokevirtual equals : (Ljava/lang/Object;)Z
            //   257: ifeq -> 70
            //   260: aload_0
            //   261: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   264: invokestatic access$300 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/RelativeLayout;
            //   267: aload_0
            //   268: getfield this$0 : Lcom/amazon/device/ads/AdContainer;
            //   271: invokestatic access$400 : (Lcom/amazon/device/ads/AdContainer;)Landroid/widget/ImageView;
            //   274: invokevirtual removeView : (Landroid/view/View;)V
            //   277: goto -> 70
            //   280: aload_2
            //   281: bipush #12
            //   283: invokevirtual addRule : (I)V
            //   286: aload_2
            //   287: bipush #14
            //   289: invokevirtual addRule : (I)V
            //   292: goto -> 208
            //   295: aload_2
            //   296: bipush #12
            //   298: invokevirtual addRule : (I)V
            //   301: aload_2
            //   302: bipush #9
            //   304: invokevirtual addRule : (I)V
            //   307: goto -> 208
            //   310: aload_2
            //   311: bipush #12
            //   313: invokevirtual addRule : (I)V
            //   316: aload_2
            //   317: bipush #11
            //   319: invokevirtual addRule : (I)V
            //   322: goto -> 208
            //   325: aload_2
            //   326: bipush #13
            //   328: invokevirtual addRule : (I)V
            //   331: goto -> 208
            //   334: aload_2
            //   335: bipush #10
            //   337: invokevirtual addRule : (I)V
            //   340: aload_2
            //   341: bipush #14
            //   343: invokevirtual addRule : (I)V
            //   346: goto -> 208
            //   349: aload_2
            //   350: bipush #10
            //   352: invokevirtual addRule : (I)V
            //   355: aload_2
            //   356: bipush #9
            //   358: invokevirtual addRule : (I)V
            //   361: goto -> 208
            //   364: aload_2
            //   365: bipush #10
            //   367: invokevirtual addRule : (I)V
            //   370: aload_2
            //   371: bipush #11
            //   373: invokevirtual addRule : (I)V
            //   376: goto -> 208
          }
        }new Void[0]);
  }
  
  public void initialize() throws IllegalStateException {
    getViewManager().disableHardwareAcceleration(this.disableHardwareAcceleration);
    getViewManager().initialize();
  }
  
  public void injectJavascript(String paramString, boolean paramBoolean) {
    getViewManager().loadUrl("javascript:" + paramString, paramBoolean, null);
  }
  
  public void listenForKey(View.OnKeyListener paramOnKeyListener) {
    getViewManager().listenForKey(paramOnKeyListener);
  }
  
  public void loadHtml(String paramString) {
    loadHtml((String)null, paramString);
  }
  
  public void loadHtml(String paramString1, String paramString2) {
    loadHtml(paramString1, paramString2, false, (PreloadCallback)null);
  }
  
  public void loadUrl(String paramString) {
    loadUrl(paramString, false, (PreloadCallback)null);
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return !this.allowClicks;
  }
  
  public void onPageFinished(WebView paramWebView, String paramString) {
    if (getViewManager().isCurrentView((View)paramWebView))
      this.adController.adRendered(paramString); 
  }
  
  public boolean popView() {
    return getViewManager().popView();
  }
  
  public void preloadHtml(String paramString, PreloadCallback paramPreloadCallback) {
    preloadHtml((String)null, paramString, paramPreloadCallback);
  }
  
  public void preloadHtml(String paramString1, String paramString2, PreloadCallback paramPreloadCallback) {
    loadHtml(paramString1, paramString2, true, paramPreloadCallback);
  }
  
  public void preloadUrl(String paramString, PreloadCallback paramPreloadCallback) {
    loadUrl(paramString, true, paramPreloadCallback);
  }
  
  public void putUrlExecutorInAdWebViewClient(String paramString, AdWebViewClient.UrlExecutor paramUrlExecutor) {
    getAdWebViewClient().putUrlExecutor(paramString, paramUrlExecutor);
  }
  
  void reload() {
    loadHtml(this.baseUrl, this.html, this.shouldPreload, this.preloadCallback);
  }
  
  public void removeNativeCloseButton() {
    ThreadUtils.executeOnMainThread(new Runnable() {
          public void run() {
            AdContainer.this.removeView((View)AdContainer.this.closeButtonContainer);
          }
        });
  }
  
  void setAdWebViewClient() {
    getAdWebViewClient().setListener(new AdContainerAdWebViewClientListener());
    getViewManager().setWebViewClient(getAdWebViewClient());
  }
  
  public void setAllowClicks(boolean paramBoolean) {
    this.allowClicks = paramBoolean;
  }
  
  public void setViewHeight(int paramInt) {
    getViewManager().setHeight(paramInt);
  }
  
  public void showNativeCloseButtonImage(boolean paramBoolean) {
    if (this.closeButton != null) {
      if (paramBoolean) {
        enableNativeCloseButton(true, (RelativePosition)null);
        return;
      } 
    } else {
      return;
    } 
    ThreadUtils.executeOnMainThread(new Runnable() {
          public void run() {
            AdContainer.this.closeButton.removeAllViews();
          }
        });
  }
  
  public void stashView() {
    getViewManager().stashView();
  }
  
  private class AdContainerAdWebViewClientListener implements AdWebViewClient.AdWebViewClientListener {
    private AdContainerAdWebViewClientListener() {}
    
    public void onLoadResource(WebView param1WebView, String param1String) {}
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      AdContainer.this.onPageFinished(param1WebView, param1String);
    }
    
    public void onPageStarted(WebView param1WebView, String param1String) {}
    
    public void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */