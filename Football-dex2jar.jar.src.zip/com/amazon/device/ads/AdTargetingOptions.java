package com.amazon.device.ads;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class AdTargetingOptions {
  private static final boolean DEFAULT_DISPLAY_ENABLED = true;
  
  private static final long DEFAULT_FLOOR_PRICE = 0L;
  
  private static final boolean DEFAULT_GEOTARGETING_ENABLED = false;
  
  private static final String LOGTAG = AdTargetingOptions.class.getSimpleName();
  
  private final Map<String, String> advanced = new HashMap<String, String>();
  
  private boolean displayEnabled = true;
  
  private boolean enableGeoTargeting = false;
  
  private long floorPrice = 0L;
  
  private final HashSet<String> internalPublisherKeywords;
  
  private boolean videoEnabled;
  
  private final boolean videoEnabledSettable;
  
  public AdTargetingOptions() {
    this(new AndroidBuildInfo());
  }
  
  AdTargetingOptions(AndroidBuildInfo paramAndroidBuildInfo) {
    this.videoEnabledSettable = isVideoEnabledSettable(paramAndroidBuildInfo);
    this.videoEnabled = this.videoEnabledSettable;
    this.internalPublisherKeywords = new HashSet<String>();
  }
  
  private static boolean isVideoEnabledSettable(AndroidBuildInfo paramAndroidBuildInfo) {
    return AndroidTargetUtils.isAtLeastAndroidAPI(paramAndroidBuildInfo, 14);
  }
  
  AdTargetingOptions addInternalPublisherKeyword(String paramString) {
    if (!StringUtils.isNullOrWhiteSpace(paramString))
      this.internalPublisherKeywords.add(paramString); 
    return this;
  }
  
  public boolean containsAdvancedOption(String paramString) {
    return this.advanced.containsKey(paramString);
  }
  
  AdTargetingOptions copy() {
    AdTargetingOptions adTargetingOptions = (new AdTargetingOptions()).enableGeoLocation(this.enableGeoTargeting).setFloorPrice(this.floorPrice).enableDisplayAds(this.displayEnabled);
    if (this.videoEnabledSettable)
      adTargetingOptions.enableVideoAds(this.videoEnabled); 
    adTargetingOptions.advanced.putAll(this.advanced);
    adTargetingOptions.internalPublisherKeywords.addAll(this.internalPublisherKeywords);
    return adTargetingOptions;
  }
  
  AdTargetingOptions enableDisplayAds(boolean paramBoolean) {
    this.displayEnabled = paramBoolean;
    return this;
  }
  
  public AdTargetingOptions enableGeoLocation(boolean paramBoolean) {
    this.enableGeoTargeting = paramBoolean;
    return this;
  }
  
  AdTargetingOptions enableVideoAds(boolean paramBoolean) {
    if (!this.videoEnabledSettable) {
      Log.w(LOGTAG, "Video is not allowed to be changed as this device does not support video.", new Object[0]);
      return this;
    } 
    this.videoEnabled = paramBoolean;
    return this;
  }
  
  public String getAdvancedOption(String paramString) {
    return this.advanced.get(paramString);
  }
  
  public int getAge() {
    Log.d(LOGTAG, "getAge API has been deprecated.", new Object[0]);
    return Integer.MIN_VALUE;
  }
  
  HashMap<String, String> getCopyOfAdvancedOptions() {
    return new HashMap<String, String>(this.advanced);
  }
  
  public long getFloorPrice() {
    return this.floorPrice;
  }
  
  HashSet<String> getInternalPublisherKeywords() {
    return this.internalPublisherKeywords;
  }
  
  boolean hasFloorPrice() {
    return (this.floorPrice > 0L);
  }
  
  boolean isDisplayAdsEnabled() {
    return this.displayEnabled;
  }
  
  public boolean isGeoLocationEnabled() {
    return this.enableGeoTargeting;
  }
  
  boolean isVideoAdsEnabled() {
    return this.videoEnabled;
  }
  
  boolean isVideoEnabledSettable() {
    return this.videoEnabledSettable;
  }
  
  public AdTargetingOptions setAdvancedOption(String paramString1, String paramString2) {
    if (StringUtils.isNullOrWhiteSpace(paramString1))
      throw new IllegalArgumentException("Option Key must not be null or empty string"); 
    if (paramString2 != null) {
      this.advanced.put(paramString1, paramString2);
      return this;
    } 
    this.advanced.remove(paramString1);
    return this;
  }
  
  public AdTargetingOptions setAge(int paramInt) {
    Log.d(LOGTAG, "setAge API has been deprecated.", new Object[0]);
    return this;
  }
  
  public AdTargetingOptions setFloorPrice(long paramLong) {
    this.floorPrice = paramLong;
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdTargetingOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */