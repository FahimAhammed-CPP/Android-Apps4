package com.amazon.device.ads;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import org.json.JSONObject;

class AppInfo {
  private final String applicationLabel;
  
  private final JSONObject packageInfoUrlJSON;
  
  private final PackageManager packageManager;
  
  private final String packageName;
  
  private final String versionCode;
  
  private final String versionName;
  
  protected AppInfo() {
    this.packageName = null;
    this.applicationLabel = null;
    this.versionCode = null;
    this.versionName = null;
    this.packageInfoUrlJSON = null;
    this.packageManager = null;
  }
  
  public AppInfo(Context paramContext) {
    PackageInfo packageInfo;
    String str1;
    String str2;
    this.packageName = paramContext.getPackageName();
    this.packageManager = paramContext.getPackageManager();
    ApplicationInfo applicationInfo = paramContext.getApplicationInfo();
    this.applicationLabel = (String)this.packageManager.getApplicationLabel(applicationInfo);
    applicationInfo = null;
    try {
      PackageInfo packageInfo1 = this.packageManager.getPackageInfo(this.packageName, 0);
      packageInfo = packageInfo1;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    if (packageInfo != null) {
      str2 = packageInfo.versionName;
    } else {
      str2 = "";
    } 
    this.versionName = str2;
    if (packageInfo != null) {
      str1 = Integer.toString(packageInfo.versionCode);
    } else {
      str1 = "";
    } 
    this.versionCode = str1;
    this.packageInfoUrlJSON = new JSONObject();
    JSONUtils.put(this.packageInfoUrlJSON, "lbl", this.applicationLabel);
    JSONUtils.put(this.packageInfoUrlJSON, "pn", this.packageName);
    JSONUtils.put(this.packageInfoUrlJSON, "v", this.versionCode);
    JSONUtils.put(this.packageInfoUrlJSON, "vn", this.versionName);
  }
  
  public JSONObject getPackageInfoJSON() {
    return this.packageInfoUrlJSON;
  }
  
  public String getPackageInfoJSONString() {
    return (this.packageInfoUrlJSON != null) ? this.packageInfoUrlJSON.toString() : null;
  }
  
  public PackageManager getPackageManager() {
    return this.packageManager;
  }
  
  public String getPackageName() {
    return this.packageName;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AppInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */