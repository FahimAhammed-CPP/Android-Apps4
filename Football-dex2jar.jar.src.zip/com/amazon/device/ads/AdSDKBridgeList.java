package com.amazon.device.ads;

import java.util.HashMap;
import java.util.Iterator;

class AdSDKBridgeList implements Iterable<AdSDKBridge> {
  private final HashMap<String, AdSDKBridge> bridgesByName = new HashMap<String, AdSDKBridge>();
  
  public void addBridge(AdSDKBridge paramAdSDKBridge) {
    this.bridgesByName.put(paramAdSDKBridge.getName(), paramAdSDKBridge);
  }
  
  public void clear() {
    this.bridgesByName.clear();
  }
  
  public boolean contains(AdSDKBridge paramAdSDKBridge) {
    return this.bridgesByName.containsKey(paramAdSDKBridge.getName());
  }
  
  public Iterator<AdSDKBridge> iterator() {
    return this.bridgesByName.values().iterator();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdSDKBridgeList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */