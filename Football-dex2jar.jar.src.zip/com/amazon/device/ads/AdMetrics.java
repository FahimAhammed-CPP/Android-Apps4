package com.amazon.device.ads;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONObject;

class AdMetrics {
  public static final String LOG_TAG = "AdMetrics";
  
  private MetricsCollector globalMetrics;
  
  private final Metrics.MetricsSubmitter submitter;
  
  public AdMetrics(Metrics.MetricsSubmitter paramMetricsSubmitter) {
    this.submitter = paramMetricsSubmitter;
  }
  
  protected static void addMetricsToJSON(JSONObject paramJSONObject, MetricsCollector paramMetricsCollector) {
    if (paramMetricsCollector != null) {
      HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
      HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
      String str2 = paramMetricsCollector.getAdTypeMetricTag();
      String str1 = str2;
      if (str2 != null)
        str1 = str2 + "_"; 
      for (MetricsCollector.MetricHit metricHit : (MetricsCollector.MetricHit[])paramMetricsCollector.getMetricHits().<MetricsCollector.MetricHit>toArray(new MetricsCollector.MetricHit[paramMetricsCollector.getMetricHits().size()])) {
        MetricsCollector.MetricHitStartTime metricHitStartTime;
        str2 = metricHit.metric.getAaxName();
        String str = str2;
        if (str1 != null) {
          str = str2;
          if (metricHit.metric.isAdTypeSpecific())
            str = str1 + str2; 
        } 
        if (metricHit instanceof MetricsCollector.MetricHitStartTime) {
          metricHitStartTime = (MetricsCollector.MetricHitStartTime)metricHit;
          hashMap1.put(metricHit.metric, Long.valueOf(metricHitStartTime.startTime));
        } else {
          Long long_;
          if (metricHit instanceof MetricsCollector.MetricHitStopTime) {
            MetricsCollector.MetricHitStopTime metricHitStopTime = (MetricsCollector.MetricHitStopTime)metricHit;
            long_ = (Long)hashMap1.remove(metricHit.metric);
            if (long_ != null) {
              long l = JSONUtils.getLongFromJSON(paramJSONObject, (String)metricHitStartTime, 0L);
              JSONUtils.put(paramJSONObject, (String)metricHitStartTime, metricHitStopTime.stopTime + l - long_.longValue());
            } 
          } else if (long_ instanceof MetricsCollector.MetricHitTotalTime) {
            JSONUtils.put(paramJSONObject, (String)metricHitStartTime, ((MetricsCollector.MetricHitTotalTime)long_).totalTime);
          } else {
            MetricsCollector.MetricHitIncrement metricHitIncrement;
            if (long_ instanceof MetricsCollector.MetricHitIncrement) {
              int i;
              metricHitIncrement = (MetricsCollector.MetricHitIncrement)long_;
              Integer integer = (Integer)hashMap2.get(((MetricsCollector.MetricHit)long_).metric);
              if (integer == null) {
                i = metricHitIncrement.increment;
              } else {
                i = integer.intValue() + metricHitIncrement.increment;
              } 
              hashMap2.put(((MetricsCollector.MetricHit)long_).metric, Integer.valueOf(i));
            } else if (long_ instanceof MetricsCollector.MetricHitString) {
              JSONUtils.put(paramJSONObject, (String)metricHitIncrement, ((MetricsCollector.MetricHitString)long_).text);
            } 
          } 
        } 
      } 
      Iterator<Map.Entry> iterator = hashMap2.entrySet().iterator();
      while (true) {
        if (iterator.hasNext()) {
          Map.Entry entry = iterator.next();
          str2 = ((Metrics.MetricType)entry.getKey()).getAaxName();
          String str = str2;
          if (str1 != null) {
            str = str2;
            if (((Metrics.MetricType)entry.getKey()).isAdTypeSpecific())
              str = str1 + str2; 
          } 
          JSONUtils.put(paramJSONObject, str, ((Integer)entry.getValue()).intValue());
          continue;
        } 
        return;
      } 
    } 
  }
  
  private String getAaxUrlAndResetAdMetrics() {
    String str = WebUtils.getURLEncodedString(getAaxJson());
    str = this.submitter.getInstrumentationPixelUrl() + str;
    this.submitter.resetMetricsCollector();
    return str;
  }
  
  public void addGlobalMetrics(MetricsCollector paramMetricsCollector) {
    this.globalMetrics = paramMetricsCollector;
  }
  
  public boolean canSubmit() {
    String str = this.submitter.getInstrumentationPixelUrl();
    if (str == null || str.equals(""))
      return false; 
    str = AmazonRegistration.getInstance().getRegistrationInfo().getAppKey();
    if (str == null || str.equals("123")) {
      Log.d("AdMetrics", "Not submitting metrics because the AppKey is either not set or set to a test key.", new Object[0]);
      return false;
    } 
    return true;
  }
  
  protected String getAaxJson() {
    JSONObject jSONObject = new JSONObject();
    JSONUtils.put(jSONObject, "c", "msdk");
    JSONUtils.put(jSONObject, "v", Version.getRawSDKVersion());
    addMetricsToJSON(jSONObject, this.submitter.getMetricsCollector());
    addMetricsToJSON(jSONObject, this.globalMetrics);
    String str = jSONObject.toString();
    return str.substring(1, str.length() - 1);
  }
  
  public WebRequest getAaxWebRequestAndResetAdMetrics() {
    WebRequest webRequest = WebRequest.createNewWebRequest();
    webRequest.setUrlString(getAaxUrlAndResetAdMetrics());
    return webRequest;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdMetrics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */