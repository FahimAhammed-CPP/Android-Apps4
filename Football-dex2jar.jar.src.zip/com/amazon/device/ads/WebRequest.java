package com.amazon.device.ads;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

abstract class WebRequest {
  private static final String CHARSET_KEY = "charset";
  
  public static final String CHARSET_UTF_16 = "UTF-16";
  
  public static final String CHARSET_UTF_8 = "UTF-8";
  
  public static final String CONTENT_TYPE_CSS = "text/css";
  
  public static final String CONTENT_TYPE_HTML = "text/html";
  
  public static final String CONTENT_TYPE_JAVASCRIPT = "application/javascript";
  
  public static final String CONTENT_TYPE_JSON = "application/json";
  
  public static final String CONTENT_TYPE_PLAIN_TEXT = "text/plain";
  
  public static final int DEFAULT_PORT = -1;
  
  public static final int DEFAULT_TIMEOUT = 20000;
  
  private static final String HEADER_ACCEPT_KEY = "Accept";
  
  private static final String HEADER_CONTENT_TYPE = "Content-Type";
  
  private static final String LOG_TAG = WebRequest.class.getSimpleName();
  
  private static WebRequestFactory webRequestFactory = new WebRequestFactory();
  
  String acceptContentType = null;
  
  String charset = null;
  
  String contentType = null;
  
  private boolean disconnectEnabled;
  
  protected final HashMap<String, String> headers = new HashMap<String, String>();
  
  private HttpMethod httpMethod = HttpMethod.GET;
  
  boolean logRequestBodyEnabled = false;
  
  boolean logResponseEnabled = false;
  
  private String logTag = LOG_TAG;
  
  protected boolean logUrlEnabled = false;
  
  private MetricsCollector metricsCollector;
  
  private String nonSecureHost = null;
  
  private String path = null;
  
  private int port = -1;
  
  protected HashMap<String, String> postParameters = new HashMap<String, String>();
  
  protected QueryStringParameters queryStringParameters = new QueryStringParameters();
  
  String requestBody = null;
  
  protected boolean secure = false;
  
  private String secureHost = null;
  
  protected Metrics.MetricType serviceCallLatencyMetric;
  
  private int timeout = 20000;
  
  private String urlString = null;
  
  WebRequest() {
    boolean bool = Settings.getInstance().getBoolean("tlsEnabled", false);
    this.secure = DebugProperties.getInstance().getDebugPropertyAsBoolean("debug.tlsEnabled", bool);
    this.disconnectEnabled = true;
  }
  
  public static final WebRequest createJSONGetWebRequest() {
    WebRequest webRequest = createNewWebRequest();
    webRequest.setHttpMethod(HttpMethod.GET);
    webRequest.putHeader("Accept", "application/json");
    return webRequest;
  }
  
  public static final WebRequest createJSONPostWebRequest() {
    WebRequest webRequest = createNewWebRequest();
    webRequest.convertToJSONPostRequest();
    return webRequest;
  }
  
  public static final WebRequest createNewWebRequest() {
    return webRequestFactory.createWebRequest();
  }
  
  protected void appendQuery(StringBuilder paramStringBuilder) {
    this.queryStringParameters.append(paramStringBuilder);
  }
  
  protected abstract void closeConnection();
  
  public void convertToJSONPostRequest() {
    setHttpMethod(HttpMethod.POST);
    putHeader("Accept", "application/json");
    putHeader("Content-Type", "application/json; charset=UTF-8");
  }
  
  protected URI createURI(String paramString) throws MalformedURLException, URISyntaxException {
    return createURI(createURL(paramString));
  }
  
  protected URI createURI(URL paramURL) throws URISyntaxException {
    return paramURL.toURI();
  }
  
  protected URL createURL(String paramString) throws MalformedURLException {
    return new URL(paramString);
  }
  
  protected URI createUri() throws URISyntaxException, MalformedURLException {
    return (new URL(getUrlString())).toURI();
  }
  
  protected abstract WebResponse doHttpNetworkCall(URL paramURL) throws WebRequestException;
  
  public void enableLog(boolean paramBoolean) {
    enableLogUrl(paramBoolean);
    enableLogRequestBody(paramBoolean);
    enableLogResponse(paramBoolean);
  }
  
  public void enableLogRequestBody(boolean paramBoolean) {
    this.logRequestBodyEnabled = paramBoolean;
  }
  
  public void enableLogResponse(boolean paramBoolean) {
    this.logResponseEnabled = paramBoolean;
  }
  
  public void enableLogUrl(boolean paramBoolean) {
    this.logUrlEnabled = paramBoolean;
  }
  
  public String getAcceptContentType() {
    return this.acceptContentType;
  }
  
  public String getCharset() {
    return this.charset;
  }
  
  public String getContentType() {
    return this.contentType;
  }
  
  public boolean getDisconnectEnabled() {
    return this.disconnectEnabled;
  }
  
  public String getHeader(String paramString) {
    if (StringUtils.isNullOrWhiteSpace(paramString))
      throw new IllegalArgumentException("The name must not be null or empty string."); 
    return this.headers.get(paramString);
  }
  
  public String getHost() {
    return this.secure ? this.secureHost : this.nonSecureHost;
  }
  
  public HttpMethod getHttpMethod() {
    return this.httpMethod;
  }
  
  protected String getLogTag() {
    return this.logTag;
  }
  
  public String getPath() {
    return this.path;
  }
  
  public int getPort() {
    return this.port;
  }
  
  public String getPostParameter(String paramString) {
    if (StringUtils.isNullOrWhiteSpace(paramString))
      throw new IllegalArgumentException("The name must not be null or empty string."); 
    return this.postParameters.get(paramString);
  }
  
  public String getQueryParameter(String paramString) {
    return this.queryStringParameters.get(paramString);
  }
  
  public String getRequestBody() {
    if (getRequestBodyString() != null)
      return getRequestBodyString(); 
    if (this.postParameters.isEmpty())
      return null; 
    StringBuilder stringBuilder = new StringBuilder();
    for (Map.Entry<String, String> entry : this.postParameters.entrySet())
      stringBuilder.append((String)entry.getKey()).append('=').append((String)entry.getValue()).append(";\n"); 
    return stringBuilder.toString();
  }
  
  public String getRequestBodyString() {
    return this.requestBody;
  }
  
  protected String getScheme() {
    return getUseSecure() ? "https" : "http";
  }
  
  protected abstract String getSubLogTag();
  
  public int getTimeout() {
    return this.timeout;
  }
  
  protected String getUrl() {
    if (this.urlString != null)
      return this.urlString; 
    StringBuilder stringBuilder = new StringBuilder(getScheme());
    stringBuilder.append("://");
    stringBuilder.append(getHost());
    if (getPort() != -1) {
      stringBuilder.append(":");
      stringBuilder.append(getPort());
    } 
    stringBuilder.append(getPath());
    appendQuery(stringBuilder);
    return stringBuilder.toString();
  }
  
  public String getUrlString() {
    return this.urlString;
  }
  
  public boolean getUseSecure() {
    return this.secure;
  }
  
  protected void logUrl(String paramString) {
    if (this.logUrlEnabled)
      Log.d(getLogTag(), "%s %s", new Object[] { getHttpMethod(), paramString }); 
  }
  
  public WebResponse makeCall() throws WebRequestException {
    if (ThreadUtils.isOnMainThread())
      Log.e(this.logTag, "The network request should not be performed on the main thread.", new Object[0]); 
    setContentTypeHeaders();
    String str = getUrl();
    try {
      URL uRL = createURL(str);
      writeMetricStart(this.serviceCallLatencyMetric);
      try {
        WebResponse webResponse = doHttpNetworkCall(uRL);
        writeMetricStop(this.serviceCallLatencyMetric);
        return webResponse;
      } catch (WebRequestException webRequestException) {
        throw webRequestException;
      } finally {
        writeMetricStop(this.serviceCallLatencyMetric);
      } 
    } catch (MalformedURLException malformedURLException) {
      Log.e(this.logTag, "Problem with URI syntax: %s", new Object[] { malformedURLException.getMessage() });
      throw new WebRequestException(WebRequestStatus.MALFORMED_URL, "Could not construct URL from String " + str, malformedURLException);
    } 
  }
  
  public void putHeader(String paramString1, String paramString2) {
    if (StringUtils.isNullOrWhiteSpace(paramString1))
      throw new IllegalArgumentException("The name must not be null or empty string."); 
    this.headers.put(paramString1, paramString2);
  }
  
  public void putPostParameter(String paramString1, String paramString2) {
    if (StringUtils.isNullOrWhiteSpace(paramString1))
      throw new IllegalArgumentException("The name must not be null or empty string."); 
    if (paramString2 == null) {
      this.postParameters.remove(paramString1);
      return;
    } 
    this.postParameters.put(paramString1, paramString2);
  }
  
  public String putUnencodedQueryParameter(String paramString1, String paramString2) {
    return this.queryStringParameters.putUnencoded(paramString1, paramString2);
  }
  
  public void putUrlEncodedQueryParameter(String paramString1, String paramString2) {
    this.queryStringParameters.putUrlEncoded(paramString1, paramString2);
  }
  
  public void setAcceptContentType(String paramString) {
    this.acceptContentType = this.contentType;
  }
  
  public void setAdditionalQueryParamsString(String paramString) {
    this.queryStringParameters.setRawAppendage(paramString);
  }
  
  public void setCharset(String paramString) {
    this.charset = paramString;
  }
  
  public void setContentType(String paramString) {
    this.contentType = paramString;
  }
  
  protected void setContentTypeHeaders() {
    if (this.acceptContentType != null)
      putHeader("Accept", this.contentType); 
    if (this.contentType != null) {
      String str2 = this.contentType;
      String str1 = str2;
      if (this.charset != null)
        str1 = str2 + "; charset=" + this.charset; 
      putHeader("Content-Type", str1);
    } 
  }
  
  public void setDisconnectEnabled(boolean paramBoolean) {
    this.disconnectEnabled = paramBoolean;
  }
  
  public void setExternalLogTag(String paramString) {
    if (paramString == null) {
      this.logTag = LOG_TAG + " " + getSubLogTag();
      return;
    } 
    this.logTag = paramString + " " + LOG_TAG + " " + getSubLogTag();
  }
  
  public void setHost(String paramString) {
    if (StringUtils.isNullOrWhiteSpace(paramString))
      throw new IllegalArgumentException("The host must not be null."); 
    this.secureHost = paramString;
    this.nonSecureHost = paramString;
  }
  
  public void setHttpMethod(HttpMethod paramHttpMethod) {
    if (paramHttpMethod == null)
      throw new IllegalArgumentException("The httpMethod must not be null."); 
    this.httpMethod = paramHttpMethod;
  }
  
  public void setMetricsCollector(MetricsCollector paramMetricsCollector) {
    this.metricsCollector = paramMetricsCollector;
  }
  
  public void setNonSecureHost(String paramString) {
    if (StringUtils.isNullOrWhiteSpace(paramString))
      throw new IllegalArgumentException("The host must not be null."); 
    this.nonSecureHost = paramString;
  }
  
  public void setPath(String paramString) {
    this.path = paramString;
  }
  
  public void setPort(int paramInt) {
    this.port = paramInt;
  }
  
  public void setQueryStringParameters(QueryStringParameters paramQueryStringParameters) {
    this.queryStringParameters = paramQueryStringParameters;
  }
  
  public void setRequestBodyString(String paramString) {
    this.requestBody = paramString;
  }
  
  public void setSecureHost(String paramString) {
    if (StringUtils.isNullOrWhiteSpace(paramString))
      throw new IllegalArgumentException("The host must not be null."); 
    this.secureHost = paramString;
  }
  
  public void setServiceCallLatencyMetric(Metrics.MetricType paramMetricType) {
    this.serviceCallLatencyMetric = paramMetricType;
  }
  
  public void setTimeout(int paramInt) {
    this.timeout = paramInt;
  }
  
  public void setUrlString(String paramString) {
    String str = paramString;
    if (paramString != null) {
      str = paramString;
      if (this.secure) {
        str = paramString;
        if (paramString.startsWith("http:"))
          str = paramString.replaceFirst("http", "https"); 
      } 
    } 
    this.urlString = str;
  }
  
  public void setUseSecure(boolean paramBoolean) {
    this.secure = paramBoolean;
  }
  
  public String toString() {
    return getUrl();
  }
  
  protected void writeMetricStart(Metrics.MetricType paramMetricType) {
    if (paramMetricType != null && this.metricsCollector != null)
      this.metricsCollector.startMetric(paramMetricType); 
  }
  
  protected void writeMetricStop(Metrics.MetricType paramMetricType) {
    if (paramMetricType != null && this.metricsCollector != null)
      this.metricsCollector.stopMetric(paramMetricType); 
  }
  
  public enum HttpMethod {
    GET("GET"),
    POST("POST");
    
    private final String methodString;
    
    static {
    
    }
    
    HttpMethod(String param1String1) {
      this.methodString = param1String1;
    }
    
    public String toString() {
      return this.methodString;
    }
  }
  
  static class QueryStringParameters {
    private final HashMap<String, String> params = new HashMap<String, String>();
    
    private String rawAppendage;
    
    void append(StringBuilder param1StringBuilder) {
      if (size() != 0 || !StringUtils.isNullOrEmpty(this.rawAppendage)) {
        param1StringBuilder.append("?");
        boolean bool = true;
        for (Map.Entry<String, String> entry : this.params.entrySet()) {
          if (bool) {
            bool = false;
          } else {
            param1StringBuilder.append("&");
          } 
          param1StringBuilder.append((String)entry.getKey());
          param1StringBuilder.append("=");
          param1StringBuilder.append((String)entry.getValue());
        } 
        if (this.rawAppendage != null && !this.rawAppendage.equals("")) {
          if (size() != 0)
            param1StringBuilder.append("&"); 
          param1StringBuilder.append(this.rawAppendage);
          return;
        } 
      } 
    }
    
    String get(String param1String) {
      if (StringUtils.isNullOrWhiteSpace(param1String))
        throw new IllegalArgumentException("The name must not be null or empty string."); 
      return this.params.get(param1String);
    }
    
    String putUnencoded(String param1String1, String param1String2) {
      WebUtils2 webUtils2 = new WebUtils2();
      param1String1 = webUtils2.getURLEncodedString(param1String1);
      putUrlEncoded(param1String1, webUtils2.getURLEncodedString(param1String2));
      return param1String1;
    }
    
    void putUrlEncoded(String param1String1, String param1String2) {
      if (StringUtils.isNullOrWhiteSpace(param1String1))
        throw new IllegalArgumentException("The name must not be null or empty string."); 
      if (param1String2 == null) {
        this.params.remove(param1String1);
        return;
      } 
      this.params.put(param1String1, param1String2);
    }
    
    void putUrlEncoded(String param1String, boolean param1Boolean) {
      putUrlEncoded(param1String, Boolean.toString(param1Boolean));
    }
    
    void putUrlEncodedIfNotNullOrEmpty(String param1String1, String param1String2) {
      boolean bool;
      if (!StringUtils.isNullOrEmpty(param1String2)) {
        bool = true;
      } else {
        bool = false;
      } 
      putUrlEncodedIfTrue(param1String1, param1String2, bool);
    }
    
    void putUrlEncodedIfTrue(String param1String1, String param1String2, boolean param1Boolean) {
      if (param1Boolean)
        putUrlEncoded(param1String1, param1String2); 
    }
    
    void setRawAppendage(String param1String) {
      this.rawAppendage = param1String;
    }
    
    int size() {
      return this.params.size();
    }
  }
  
  public class WebRequestException extends Exception {
    private static final long serialVersionUID = -4980265484926465548L;
    
    private final WebRequest.WebRequestStatus status;
    
    protected WebRequestException(WebRequest.WebRequestStatus param1WebRequestStatus, String param1String) {
      this(param1WebRequestStatus, param1String, null);
    }
    
    protected WebRequestException(WebRequest.WebRequestStatus param1WebRequestStatus, String param1String, Throwable param1Throwable) {
      super(param1String, param1Throwable);
      this.status = param1WebRequestStatus;
    }
    
    public WebRequest.WebRequestStatus getStatus() {
      return this.status;
    }
  }
  
  public static class WebRequestFactory {
    public WebRequest createWebRequest() {
      return (WebRequest)(AndroidTargetUtils.isAtOrBelowAndroidAPI(7) ? new HttpClientWebRequest() : new HttpURLConnectionWebRequest());
    }
  }
  
  class WebRequestInputStream extends InputStream {
    private final InputStream decoratedStream;
    
    public WebRequestInputStream(InputStream param1InputStream) {
      this.decoratedStream = param1InputStream;
    }
    
    public void close() throws IOException {
      this.decoratedStream.close();
      if (WebRequest.this.disconnectEnabled)
        WebRequest.this.closeConnection(); 
    }
    
    public int read() throws IOException {
      return this.decoratedStream.read();
    }
  }
  
  public enum WebRequestStatus {
    NETWORK_FAILURE,
    INVALID_CLIENT_PROTOCOL("POST"),
    MALFORMED_URL("POST"),
    NETWORK_TIMEOUT,
    UNSUPPORTED_ENCODING;
    
    static {
      INVALID_CLIENT_PROTOCOL = new WebRequestStatus("INVALID_CLIENT_PROTOCOL", 3);
      UNSUPPORTED_ENCODING = new WebRequestStatus("UNSUPPORTED_ENCODING", 4);
      $VALUES = new WebRequestStatus[] { NETWORK_FAILURE, NETWORK_TIMEOUT, MALFORMED_URL, INVALID_CLIENT_PROTOCOL, UNSUPPORTED_ENCODING };
    }
  }
  
  public class WebResponse {
    private String httpStatus;
    
    private int httpStatusCode;
    
    private WebRequest.WebRequestInputStream inputStream;
    
    public String getHttpStatus() {
      return this.httpStatus;
    }
    
    public int getHttpStatusCode() {
      return this.httpStatusCode;
    }
    
    public ResponseReader getResponseReader() {
      ResponseReader responseReader = new ResponseReader(this.inputStream);
      responseReader.enableLog(WebRequest.this.logResponseEnabled);
      responseReader.setExternalLogTag(WebRequest.this.getLogTag());
      return responseReader;
    }
    
    public boolean isHttpStatusCodeOK() {
      return (getHttpStatusCode() == 200);
    }
    
    protected void setHttpStatus(String param1String) {
      this.httpStatus = param1String;
    }
    
    protected void setHttpStatusCode(int param1Int) {
      this.httpStatusCode = param1Int;
    }
    
    protected void setInputStream(InputStream param1InputStream) {
      this.inputStream = new WebRequest.WebRequestInputStream(param1InputStream);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\WebRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */