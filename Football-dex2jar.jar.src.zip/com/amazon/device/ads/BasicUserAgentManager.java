package com.amazon.device.ads;

import android.content.Context;

class BasicUserAgentManager implements UserAgentManager {
  private String userAgentStringWithSDKVersion;
  
  private String userAgentStringWithoutSDKVersion;
  
  private String buildUserAgentString() {
    return "";
  }
  
  public String getUserAgentString() {
    return this.userAgentStringWithSDKVersion;
  }
  
  public void populateUserAgentString(Context paramContext) {
    if (this.userAgentStringWithSDKVersion == null) {
      if (AndroidTargetUtils.isAtLeastAndroidAPI(7)) {
        this.userAgentStringWithoutSDKVersion = System.getProperty("http.agent");
      } else {
        this.userAgentStringWithoutSDKVersion = buildUserAgentString();
      } 
      this.userAgentStringWithSDKVersion = this.userAgentStringWithoutSDKVersion + " " + Version.getUserAgentSDKVersion();
    } 
  }
  
  public void setUserAgentString(String paramString) {
    if (paramString != null && !paramString.equals(this.userAgentStringWithoutSDKVersion)) {
      this.userAgentStringWithoutSDKVersion = paramString;
      this.userAgentStringWithSDKVersion = paramString + " " + Version.getUserAgentSDKVersion();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\BasicUserAgentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */