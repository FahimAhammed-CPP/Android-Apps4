package com.amazon.device.ads;

public interface AdListener {
  void onAdCollapsed(Ad paramAd);
  
  void onAdDismissed(Ad paramAd);
  
  void onAdExpanded(Ad paramAd);
  
  void onAdFailedToLoad(Ad paramAd, AdError paramAdError);
  
  void onAdLoaded(Ad paramAd, AdProperties paramAdProperties);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */