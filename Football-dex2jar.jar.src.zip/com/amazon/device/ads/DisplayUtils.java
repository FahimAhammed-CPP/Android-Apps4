package com.amazon.device.ads;

import android.content.Context;
import android.view.WindowManager;

class DisplayUtils {
  private static int[][] rotationArray = new int[][] { { 1, 0, 9, 8 }, { 0, 9, 8, 1 } };
  
  public static int determineCanonicalScreenOrientation(Context paramContext) {
    int j = AndroidTargetUtils.getOrientation(((WindowManager)paramContext.getSystemService("window")).getDefaultDisplay());
    int i = (paramContext.getResources().getConfiguration()).orientation;
    if (i == 1) {
      if (j == 0 || j == 2) {
        i = 1;
      } else {
        i = 0;
      } 
    } else if (i == 2) {
      if (j == 1 || j == 3) {
        i = 1;
      } else {
        i = 0;
      } 
    } else {
      i = 1;
    } 
    if (i != 0) {
      i = 0;
      return rotationArray[i][j];
    } 
    i = 1;
    return rotationArray[i][j];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\DisplayUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */