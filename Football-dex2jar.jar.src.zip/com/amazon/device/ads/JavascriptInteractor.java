package com.amazon.device.ads;

import android.webkit.JavascriptInterface;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

class JavascriptInteractor {
  private static final String LOG_TAG = JavascriptInteractor.class.getSimpleName();
  
  private static String executorMethodName;
  
  private final Executor executor = new Executor(this);
  
  private final Map<String, JavascriptMethodExecutor> methodMap = new ConcurrentHashMap<String, JavascriptMethodExecutor>();
  
  private JSONObject execute(String paramString1, String paramString2) {
    JSONObject jSONObject2 = null;
    JSONObject jSONObject1 = jSONObject2;
    if (paramString2 != null) {
      jSONObject1 = jSONObject2;
      if (paramString2.length() > 2) {
        jSONObject2 = JSONUtils.getJSONObjectFromString(paramString2);
        jSONObject1 = jSONObject2;
        if (jSONObject2 == null) {
          Log.w(LOG_TAG, "The javascript object \"%s\" could not be parsed for method \"%s\".", new Object[] { paramString2, paramString1 });
          return null;
        } 
      } 
    } 
    return execute(paramString1, jSONObject1);
  }
  
  private JSONObject execute(String paramString, JSONObject paramJSONObject) {
    if (this.methodMap.containsKey(paramString))
      return ((JavascriptMethodExecutor)this.methodMap.get(paramString)).execute(paramJSONObject); 
    Log.w(LOG_TAG, "The method %s was not recongized by this javascript interface.", new Object[] { paramString });
    return null;
  }
  
  public static String getExecutorMethodName() {
    if (executorMethodName == null) {
      Method[] arrayOfMethod = Executor.class.getDeclaredMethods();
      if (arrayOfMethod != null && arrayOfMethod.length == 1) {
        executorMethodName = arrayOfMethod[0].getName();
        return executorMethodName;
      } 
    } else {
      return executorMethodName;
    } 
    Log.e(LOG_TAG, "Could not obtain the method name for javascript interfacing.", new Object[0]);
    return executorMethodName;
  }
  
  public void addMethodExecutor(JavascriptMethodExecutor paramJavascriptMethodExecutor) {
    if (this.methodMap.containsKey(paramJavascriptMethodExecutor.getMethodName()))
      throw new IllegalArgumentException("There is another executor with that method name already added."); 
    this.methodMap.put(paramJavascriptMethodExecutor.getMethodName(), paramJavascriptMethodExecutor);
  }
  
  public Executor getExecutor() {
    return this.executor;
  }
  
  public static class Executor {
    private final JavascriptInteractor interactor;
    
    private boolean proguardKeeper = false;
    
    public Executor(JavascriptInteractor param1JavascriptInteractor) {
      this.interactor = param1JavascriptInteractor;
      if (this.proguardKeeper)
        execute(null, null); 
    }
    
    @JavascriptInterface
    public String execute(String param1String1, String param1String2) {
      JSONObject jSONObject = this.interactor.execute(param1String1, param1String2);
      return (jSONObject == null) ? null : jSONObject.toString();
    }
  }
  
  public static abstract class JavascriptMethodExecutor {
    private final String methodName;
    
    protected JavascriptMethodExecutor(String param1String) {
      this.methodName = param1String;
    }
    
    protected abstract JSONObject execute(JSONObject param1JSONObject);
    
    public String getMethodName() {
      return this.methodName;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\JavascriptInteractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */