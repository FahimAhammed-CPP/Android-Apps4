package com.amazon.device.ads;

import android.graphics.Bitmap;
import java.io.InputStream;
import org.json.JSONObject;

public class ImageResponseReader extends ResponseReader {
  ImageResponseReader(ResponseReader paramResponseReader) {
    super(paramResponseReader.getInputStream());
  }
  
  public Bitmap readAsBitmap() {
    return ImageUtils.createBitmapImage(getInputStream());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ImageResponseReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */