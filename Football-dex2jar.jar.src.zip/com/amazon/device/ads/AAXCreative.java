package com.amazon.device.ads;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

enum AAXCreative {
  CAN_EXPAND1,
  CAN_EXPAND2,
  CAN_PLAY_AUDIO1,
  CAN_PLAY_AUDIO2,
  CAN_PLAY_VIDEO,
  HTML(1007),
  INTERSTITIAL(1007),
  MRAID1(1016),
  MRAID2(1017),
  REQUIRES_TRANSPARENCY(1017),
  VIDEO_INTERSTITIAL(1017);
  
  private static final HashSet<AAXCreative> primaryCreativeTypes;
  
  private final int id;
  
  static {
    INTERSTITIAL = new AAXCreative("INTERSTITIAL", 3, 1008);
    CAN_PLAY_AUDIO1 = new AAXCreative("CAN_PLAY_AUDIO1", 4, 1001);
    CAN_PLAY_AUDIO2 = new AAXCreative("CAN_PLAY_AUDIO2", 5, 1002);
    CAN_EXPAND1 = new AAXCreative("CAN_EXPAND1", 6, 1003);
    CAN_EXPAND2 = new AAXCreative("CAN_EXPAND2", 7, 1004);
    CAN_PLAY_VIDEO = new AAXCreative("CAN_PLAY_VIDEO", 8, 1014);
    VIDEO_INTERSTITIAL = new AAXCreative("VIDEO_INTERSTITIAL", 9, 1030);
    REQUIRES_TRANSPARENCY = new AAXCreative("REQUIRES_TRANSPARENCY", 10, 1031);
    $VALUES = new AAXCreative[] { 
        HTML, MRAID1, MRAID2, INTERSTITIAL, CAN_PLAY_AUDIO1, CAN_PLAY_AUDIO2, CAN_EXPAND1, CAN_EXPAND2, CAN_PLAY_VIDEO, VIDEO_INTERSTITIAL, 
        REQUIRES_TRANSPARENCY };
    primaryCreativeTypes = new HashSet<AAXCreative>();
    primaryCreativeTypes.add(HTML);
    primaryCreativeTypes.add(MRAID1);
    primaryCreativeTypes.add(MRAID2);
    primaryCreativeTypes.add(INTERSTITIAL);
    primaryCreativeTypes.add(VIDEO_INTERSTITIAL);
  }
  
  AAXCreative(int paramInt1) {
    this.id = paramInt1;
  }
  
  public static boolean containsPrimaryCreativeType(Set<AAXCreative> paramSet) {
    Iterator<AAXCreative> iterator = primaryCreativeTypes.iterator();
    while (iterator.hasNext()) {
      if (paramSet.contains(iterator.next()))
        return true; 
    } 
    return false;
  }
  
  public static AAXCreative getCreativeType(int paramInt) {
    switch (paramInt) {
      default:
        return null;
      case 1007:
        return HTML;
      case 1016:
        return MRAID1;
      case 1017:
        return MRAID2;
      case 1008:
        return INTERSTITIAL;
      case 1030:
        return VIDEO_INTERSTITIAL;
      case 1003:
        return CAN_EXPAND1;
      case 1004:
        return CAN_EXPAND2;
      case 1001:
        return CAN_PLAY_AUDIO1;
      case 1002:
        return CAN_PLAY_AUDIO2;
      case 1014:
        return CAN_PLAY_VIDEO;
      case 1031:
        break;
    } 
    return REQUIRES_TRANSPARENCY;
  }
  
  static AAXCreative getTopCreative(Set<AAXCreative> paramSet) {
    return paramSet.contains(MRAID2) ? MRAID2 : (paramSet.contains(MRAID1) ? MRAID1 : (paramSet.contains(HTML) ? HTML : null));
  }
  
  public int getId() {
    return this.id;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AAXCreative.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */