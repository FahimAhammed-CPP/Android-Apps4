package com.amazon.device.ads;

import android.annotation.SuppressLint;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class AdRequest {
  private static final String AAX_ENDPOINT = "/e/msdk/ads";
  
  private static final String LOG_TAG = AdRequest.class.getSimpleName();
  
  private static final AAXParameter<?>[] PARAMETERS = new AAXParameter[] { 
      AAXParameter.APP_KEY, AAXParameter.CHANNEL, AAXParameter.PUBLISHER_KEYWORDS, AAXParameter.PUBLISHER_ASINS, AAXParameter.USER_AGENT, AAXParameter.SDK_VERSION, AAXParameter.GEOLOCATION, AAXParameter.DEVICE_INFO, AAXParameter.PACKAGE_INFO, AAXParameter.TEST, 
      AAXParameter.SIS_DEVICE_IDENTIFIER, AAXParameter.SHA1_UDID, AAXParameter.MD5_UDID, AAXParameter.ADVERTISING_IDENTIFIER, AAXParameter.OPT_OUT };
  
  private AdvertisingIdentifier.Info advertisingIdentifierInfo;
  
  private final ConnectionInfo connectionInfo;
  
  private String instrPixelUrl;
  
  private final JSONObjectBuilder jsonObjectBuilder;
  
  private final AdTargetingOptions opt;
  
  private final String orientation;
  
  protected final Map<Integer, LOISlot> slots;
  
  @SuppressLint({"UseSparseArrays"})
  AdRequest(AdTargetingOptions paramAdTargetingOptions) {
    this.opt = paramAdTargetingOptions;
    this.slots = new HashMap<Integer, LOISlot>();
    this.orientation = AmazonRegistration.getInstance().getDeviceInfo().getOrientation();
    this.connectionInfo = new ConnectionInfo();
    HashMap<String, String> hashMap = this.opt.getCopyOfAdvancedOptions();
    AAXParameter.ParameterData parameterData = (new AAXParameter.ParameterData()).setAdTargetingOptions(this.opt).setAdvancedOptions(hashMap).setAdRequest(this);
    this.jsonObjectBuilder = (new JSONObjectBuilder()).setAAXParameters(PARAMETERS).setAdvancedOptions(hashMap).setParameterData(parameterData);
  }
  
  AdTargetingOptions getAdTargetingOptions() {
    return this.opt;
  }
  
  AdvertisingIdentifier.Info getAdvertisingIdentifierInfo() {
    return this.advertisingIdentifierInfo;
  }
  
  public String getInstrumentationPixelURL() {
    return this.instrPixelUrl;
  }
  
  String getOrientation() {
    return this.orientation;
  }
  
  protected JSONArray getSlots() {
    JSONArray jSONArray = new JSONArray();
    Iterator<LOISlot> iterator = this.slots.values().iterator();
    while (iterator.hasNext())
      jSONArray.put(((LOISlot)iterator.next()).getJSON()); 
    return jSONArray;
  }
  
  public WebRequest getWebRequest() {
    WebRequest webRequest = WebRequest.createNewWebRequest();
    webRequest.setExternalLogTag(LOG_TAG);
    webRequest.setHttpMethod(WebRequest.HttpMethod.POST);
    webRequest.setHost(Configuration.getInstance().getString(Configuration.ConfigOption.AAX_HOSTNAME));
    webRequest.setPath("/e/msdk/ads");
    webRequest.enableLog(true);
    webRequest.setContentType("application/json");
    webRequest.setDisconnectEnabled(false);
    setParametersInWebRequest(webRequest);
    return webRequest;
  }
  
  public void putSlot(AdSlot paramAdSlot) {
    if (getAdvertisingIdentifierInfo().hasSISDeviceIdentifier())
      paramAdSlot.getMetricsCollector().incrementMetric(Metrics.MetricType.AD_COUNTER_IDENTIFIED_DEVICE); 
    paramAdSlot.setConnectionInfo(this.connectionInfo);
    LOISlot lOISlot = new LOISlot(paramAdSlot, this);
    this.slots.put(Integer.valueOf(paramAdSlot.getSlotNumber()), lOISlot);
  }
  
  AdRequest setAdvertisingIdentifierInfo(AdvertisingIdentifier.Info paramInfo) {
    this.advertisingIdentifierInfo = paramInfo;
    return this;
  }
  
  public void setInstrumentationPixelURL(String paramString) {
    this.instrPixelUrl = paramString;
  }
  
  protected void setParametersInWebRequest(WebRequest paramWebRequest) {
    this.jsonObjectBuilder.build();
    JSONArray jSONArray2 = (JSONArray)AAXParameter.SLOTS.getValue(this.jsonObjectBuilder.getParameterData());
    JSONArray jSONArray1 = jSONArray2;
    if (jSONArray2 == null)
      jSONArray1 = getSlots(); 
    this.jsonObjectBuilder.putIntoJSON(AAXParameter.SLOTS, jSONArray1);
    JSONObject jSONObject = this.jsonObjectBuilder.getJSON();
    String str = DebugProperties.getInstance().getDebugPropertyAsString("debug.aaxAdParams", null);
    if (!StringUtils.isNullOrEmpty(str))
      paramWebRequest.setAdditionalQueryParamsString(str); 
    setRequestBodyString(paramWebRequest, jSONObject);
  }
  
  protected void setRequestBodyString(WebRequest paramWebRequest, JSONObject paramJSONObject) {
    paramWebRequest.setRequestBodyString(paramJSONObject.toString());
  }
  
  static class JSONObjectBuilder {
    private AAXParameter<?>[] aaxParameters;
    
    private Map<String, String> advancedOptions;
    
    private final JSONObject json = new JSONObject();
    
    private AAXParameter.ParameterData parameterData;
    
    void build() {
      for (AAXParameter<?> aAXParameter : this.aaxParameters)
        putIntoJSON(aAXParameter, aAXParameter.getValue(this.parameterData)); 
      if (this.advancedOptions != null)
        for (Map.Entry<String, String> entry : this.advancedOptions.entrySet()) {
          if (!StringUtils.isNullOrWhiteSpace((String)entry.getValue()))
            putIntoJSON((String)entry.getKey(), entry.getValue()); 
        }  
    }
    
    JSONObject getJSON() {
      return this.json;
    }
    
    AAXParameter.ParameterData getParameterData() {
      return this.parameterData;
    }
    
    void putIntoJSON(AAXParameter<?> param1AAXParameter, Object param1Object) {
      putIntoJSON(param1AAXParameter.getName(), param1Object);
    }
    
    void putIntoJSON(String param1String, Object param1Object) {
      if (param1Object != null)
        try {
          this.json.put(param1String, param1Object);
          return;
        } catch (JSONException jSONException) {
          Log.d(AdRequest.LOG_TAG, "Could not add parameter to JSON %s: %s", new Object[] { param1String, param1Object });
          return;
        }  
    }
    
    JSONObjectBuilder setAAXParameters(AAXParameter<?>[] param1ArrayOfAAXParameter) {
      this.aaxParameters = param1ArrayOfAAXParameter;
      return this;
    }
    
    JSONObjectBuilder setAdvancedOptions(Map<String, String> param1Map) {
      this.advancedOptions = param1Map;
      return this;
    }
    
    JSONObjectBuilder setParameterData(AAXParameter.ParameterData param1ParameterData) {
      this.parameterData = param1ParameterData;
      return this;
    }
  }
  
  static class LOISlot {
    static final AAXParameter<?>[] PARAMETERS = new AAXParameter[] { AAXParameter.SIZE, AAXParameter.PAGE_TYPE, AAXParameter.SLOT, AAXParameter.SLOT_POSITION, AAXParameter.MAX_SIZE, AAXParameter.SLOT_ID, AAXParameter.FLOOR_PRICE, AAXParameter.SUPPORTED_MEDIA_TYPES, AAXParameter.VIDEO_OPTIONS };
    
    private final AdSlot adSlot;
    
    private final AdRequest.JSONObjectBuilder jsonObjectBuilder;
    
    private final AdTargetingOptions opt;
    
    LOISlot(AdSlot param1AdSlot, AdRequest param1AdRequest) {
      this.opt = param1AdSlot.getAdTargetingOptions();
      this.adSlot = param1AdSlot;
      HashMap<String, String> hashMap = this.opt.getCopyOfAdvancedOptions();
      AAXParameter.ParameterData parameterData = (new AAXParameter.ParameterData()).setAdTargetingOptions(this.opt).setAdvancedOptions(hashMap).setLOISlot(this).setAdRequest(param1AdRequest);
      this.jsonObjectBuilder = (new AdRequest.JSONObjectBuilder()).setAAXParameters(PARAMETERS).setAdvancedOptions(hashMap).setParameterData(parameterData);
    }
    
    AdSlot getAdSlot() {
      return this.adSlot;
    }
    
    AdTargetingOptions getAdTargetingOptions() {
      return this.opt;
    }
    
    JSONObject getJSON() {
      this.jsonObjectBuilder.build();
      return this.jsonObjectBuilder.getJSON();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */