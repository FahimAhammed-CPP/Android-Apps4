package com.amazon.device.ads;

class NumberUtils {
  public static final long convertToMillisecondsFromNanoseconds(long paramLong) {
    return paramLong / 1000000L;
  }
  
  public static final long convertToNsFromS(long paramLong) {
    return 1000000000L * paramLong;
  }
  
  public static int parseInt(String paramString, int paramInt) {
    try {
      return Integer.parseInt(paramString);
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\NumberUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */