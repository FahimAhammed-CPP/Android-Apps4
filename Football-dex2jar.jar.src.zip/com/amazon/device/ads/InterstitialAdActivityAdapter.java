package com.amazon.device.ads;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Configuration;
import android.view.View;
import android.view.ViewGroup;

@SuppressLint({"NewApi"})
class InterstitialAdActivityAdapter implements AdActivity.IAdActivityAdapter {
  private static final String LOGTAG = InterstitialAdActivityAdapter.class.getSimpleName();
  
  private Activity activity = null;
  
  private AdController adController;
  
  Activity getActivity() {
    return this.activity;
  }
  
  AdController getAdController() {
    return AdControllerFactory.getCachedAdController();
  }
  
  public boolean onBackPressed() {
    return (this.adController != null) ? this.adController.onBackButtonPress() : false;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {}
  
  public void onCreate() {
    AndroidTargetUtils.enableHardwareAcceleration(this.activity.getWindow());
    this.adController = getAdController();
    if (this.adController == null) {
      Log.e(LOGTAG, "Failed to show interstitial ad due to an error in the Activity.", new Object[0]);
      InterstitialAd.resetIsAdShowing();
      this.activity.finish();
      return;
    } 
    this.adController.setAdActivity(this.activity);
    this.adController.addSDKEventListener(new InterstitialAdSDKEventListener());
    ViewGroup viewGroup = (ViewGroup)this.adController.getView().getParent();
    if (viewGroup != null)
      viewGroup.removeView((View)this.adController.getView()); 
    this.activity.setContentView((View)this.adController.getView());
    this.adController.adShown();
  }
  
  public void onPause() {}
  
  public void onResume() {}
  
  public void onStop() {
    if (this.activity.isFinishing() && this.adController != null)
      this.adController.closeAd(); 
  }
  
  public void preOnCreate() {
    this.activity.requestWindowFeature(1);
    this.activity.getWindow().setFlags(1024, 1024);
    AndroidTargetUtils.hideActionAndStatusBars(this.activity);
  }
  
  public void setActivity(Activity paramActivity) {
    this.activity = paramActivity;
  }
  
  class InterstitialAdSDKEventListener implements SDKEventListener {
    public void onSDKEvent(SDKEvent param1SDKEvent, AdControlAccessor param1AdControlAccessor) {
      if (param1SDKEvent.getEventType().equals(SDKEvent.SDKEventType.CLOSED) && !InterstitialAdActivityAdapter.this.activity.isFinishing()) {
        InterstitialAdActivityAdapter.access$102(InterstitialAdActivityAdapter.this, null);
        InterstitialAdActivityAdapter.this.activity.finish();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\InterstitialAdActivityAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */