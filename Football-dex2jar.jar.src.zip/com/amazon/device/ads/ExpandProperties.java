package com.amazon.device.ads;

import org.json.JSONObject;

class ExpandProperties {
  private int height;
  
  private Boolean isModal = Boolean.TRUE;
  
  private Boolean useCustomClose = Boolean.FALSE;
  
  private int width;
  
  public int getHeight() {
    return this.height;
  }
  
  public Boolean getIsModal() {
    return this.isModal;
  }
  
  public Boolean getUseCustomClose() {
    return this.useCustomClose;
  }
  
  public int getWidth() {
    return this.width;
  }
  
  public void setHeight(int paramInt) {
    this.height = paramInt;
  }
  
  public void setIsModal(Boolean paramBoolean) {
    this.isModal = paramBoolean;
  }
  
  public void setUseCustomClose(Boolean paramBoolean) {
    this.useCustomClose = paramBoolean;
  }
  
  public void setWidth(int paramInt) {
    this.width = paramInt;
  }
  
  public JSONObject toJSONObject() {
    JSONObject jSONObject = new JSONObject();
    JSONUtils.put(jSONObject, "width", this.width);
    JSONUtils.put(jSONObject, "height", this.height);
    JSONUtils.put(jSONObject, "useCustomClose", this.useCustomClose.booleanValue());
    JSONUtils.put(jSONObject, "isModal", this.isModal.booleanValue());
    return jSONObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ExpandProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */