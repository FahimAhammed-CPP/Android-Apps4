package com.amazon.device.ads;

import android.content.Context;
import java.io.File;

interface IAmazonRegistration {
  void contextReceived(Context paramContext);
  
  AppInfo getAppInfo();
  
  Context getApplicationContext();
  
  DeviceInfo getDeviceInfo();
  
  File getFilesDir();
  
  boolean getIsAppDisabled();
  
  int getNoRetryTtlRemainingMillis();
  
  RegistrationInfo getRegistrationInfo();
  
  SISRegistration getSISRegistration();
  
  boolean isRegistered();
  
  void register();
  
  void setIsAppDisabled(boolean paramBoolean);
  
  void setNoRetryTtl(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\IAmazonRegistration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */