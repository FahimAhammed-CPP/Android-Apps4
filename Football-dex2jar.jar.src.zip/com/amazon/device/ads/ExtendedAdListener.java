package com.amazon.device.ads;

import android.graphics.Rect;

public interface ExtendedAdListener extends AdListener {
  void onAdResized(Rect paramRect);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ExtendedAdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */