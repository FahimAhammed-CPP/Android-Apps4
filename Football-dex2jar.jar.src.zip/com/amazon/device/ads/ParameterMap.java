package com.amazon.device.ads;

import java.util.HashMap;

class ParameterMap {
  private final HashMap<String, Object> parameters = new HashMap<String, Object>();
  
  public Boolean getBooleanParameter(String paramString) {
    return (Boolean)this.parameters.get(paramString);
  }
  
  public Double getDoubleParameter(String paramString) {
    return (Double)this.parameters.get(paramString);
  }
  
  public Integer getIntParameter(String paramString) {
    return (Integer)this.parameters.get(paramString);
  }
  
  public Long getLongParameter(String paramString) {
    return (Long)this.parameters.get(paramString);
  }
  
  public Object getParameter(String paramString) {
    return this.parameters.get(paramString);
  }
  
  public String getStringParameter(String paramString) {
    return (String)this.parameters.get(paramString);
  }
  
  public void setParameter(String paramString, Object paramObject) {
    this.parameters.put(paramString, paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ParameterMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */