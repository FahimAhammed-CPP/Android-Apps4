package com.amazon.device.ads;

class AdvertisingIdentifier {
  private static final String GPS_ADVERTISING_IDENTIFIER_SETTING = "gpsAdId";
  
  private static final String LOG_TAG = AdvertisingIdentifier.class.getSimpleName();
  
  private static final String TRANSITION_MIGRATE = "migrate";
  
  private static final String TRANSITION_RESET = "reset";
  
  private static final String TRANSITION_REVERT = "revert";
  
  private static final String TRANSITION_SETTING = "adIdTransistion";
  
  private GooglePlayServices.AdvertisingInfo gpsAdvertisingInfo;
  
  private boolean shouldSetCurrentAdvertisingIdentifier = true;
  
  private void determineTransition() {
    String str = null;
    if (isTransitionMigrated()) {
      str = "migrate";
    } else if (isTransitionReset()) {
      str = "reset";
    } else if (isTransitionReverted()) {
      str = "revert";
    } 
    if (str != null) {
      setTransition(str);
      return;
    } 
    Log.d(LOG_TAG, "No transition detected.", new Object[0]);
  }
  
  static String getAndClearTransition() {
    Settings settings = Settings.getInstance();
    String str = settings.getString("adIdTransistion", null);
    settings.remove("adIdTransistion");
    return str;
  }
  
  private static String getCurrentGPSAID() {
    return Settings.getInstance().getString("gpsAdId", "");
  }
  
  private boolean hasCurrentGPSAID() {
    return !StringUtils.isNullOrEmpty(getCurrentGPSAID());
  }
  
  private boolean isTransitionMigrated() {
    return (AmazonRegistration.getInstance().getRegistrationInfo().hasAdId() && RegistrationInfo.isAdIdOriginatedFromNonAdvertisingIdentifier() && !hasCurrentGPSAID() && getGPSAdvertisingInfo().hasAdvertisingIdentifier());
  }
  
  private boolean isTransitionReset() {
    return (hasCurrentGPSAID() && getGPSAdvertisingInfo().hasAdvertisingIdentifier() && !getCurrentGPSAID().equals(getGPSAdvertisingInfo().getAdvertisingIdentifier()));
  }
  
  private boolean isTransitionReverted() {
    return (hasCurrentGPSAID() && !getGPSAdvertisingInfo().hasAdvertisingIdentifier());
  }
  
  private static void setCurrentGPSAID(String paramString) {
    Settings.getInstance().putString("gpsAdId", paramString);
  }
  
  private static void setTransition(String paramString) {
    Log.d(LOG_TAG, "Transition: %s", new Object[] { paramString });
    Settings.getInstance().putString("adIdTransistion", paramString);
  }
  
  protected void fetchGooglePlayServicesAdvertisingIdentifierInfo() {
    this.gpsAdvertisingInfo = (new GooglePlayServices()).getAdvertisingIdentifierInfo();
  }
  
  Info getAdvertisingIdentifierInfo() {
    if (ThreadUtils.isOnMainThread()) {
      Log.e(LOG_TAG, "You must obtain the advertising indentifier information on a background thread.", new Object[0]);
      return (new Info()).setCanDo(false);
    } 
    fetchGooglePlayServicesAdvertisingIdentifierInfo();
    if (this.shouldSetCurrentAdvertisingIdentifier)
      determineTransition(); 
    Info info = new Info();
    if (getGPSAdvertisingInfo().hasAdvertisingIdentifier()) {
      info.setAdvertisingIdentifier(getGPSAdvertisingInfo().getAdvertisingIdentifier());
      info.setLimitAdTrackingEnabled(getGPSAdvertisingInfo().isLimitAdTrackingEnabled());
      if (this.shouldSetCurrentAdvertisingIdentifier)
        setCurrentGPSAID(getGPSAdvertisingInfo().getAdvertisingIdentifier()); 
    } 
    RegistrationInfo registrationInfo = AmazonRegistration.getInstance().getRegistrationInfo();
    if (RegistrationInfo.isAdIdCurrent(info)) {
      info.setSISDeviceIdentifier(registrationInfo.getAdId());
      return info;
    } 
    registrationInfo.requestNewSISDeviceIdentifier();
    return info;
  }
  
  protected GooglePlayServices.AdvertisingInfo getGPSAdvertisingInfo() {
    return this.gpsAdvertisingInfo;
  }
  
  AdvertisingIdentifier setShouldSetCurrentAdvertisingIdentifier(boolean paramBoolean) {
    this.shouldSetCurrentAdvertisingIdentifier = paramBoolean;
    return this;
  }
  
  static class Info {
    private String advertisingIdentifier;
    
    private boolean canDo = true;
    
    private boolean limitAdTrackingEnabled;
    
    private String sisDeviceIdentifier;
    
    private Info setAdvertisingIdentifier(String param1String) {
      this.advertisingIdentifier = param1String;
      return this;
    }
    
    private Info setCanDo(boolean param1Boolean) {
      this.canDo = param1Boolean;
      return this;
    }
    
    private Info setLimitAdTrackingEnabled(boolean param1Boolean) {
      this.limitAdTrackingEnabled = param1Boolean;
      return this;
    }
    
    private Info setSISDeviceIdentifier(String param1String) {
      this.sisDeviceIdentifier = param1String;
      return this;
    }
    
    boolean canDo() {
      return this.canDo;
    }
    
    String getAdvertisingIdentifier() {
      return DebugProperties.getInstance().getDebugPropertyAsString("debug.idfa", this.advertisingIdentifier);
    }
    
    String getSISDeviceIdentifier() {
      return DebugProperties.getInstance().getDebugPropertyAsString("debug.adid", this.sisDeviceIdentifier);
    }
    
    boolean hasAdvertisingIdentifier() {
      return !StringUtils.isNullOrEmpty(getAdvertisingIdentifier());
    }
    
    boolean hasSISDeviceIdentifier() {
      return (getSISDeviceIdentifier() != null);
    }
    
    boolean isLimitAdTrackingEnabled() {
      return DebugProperties.getInstance().getDebugPropertyAsBoolean("debug.optOut", this.limitAdTrackingEnabled);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdvertisingIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */