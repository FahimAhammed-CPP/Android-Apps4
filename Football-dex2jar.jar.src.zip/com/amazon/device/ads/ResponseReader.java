package com.amazon.device.ads;

import java.io.InputStream;
import org.json.JSONObject;

class ResponseReader {
  private static final String LOGTAG = ResponseReader.class.getSimpleName();
  
  private boolean enableLog = false;
  
  private String logTag = LOGTAG;
  
  private final InputStream stream;
  
  ResponseReader(InputStream paramInputStream) {
    this.stream = paramInputStream;
  }
  
  public void enableLog(boolean paramBoolean) {
    this.enableLog = paramBoolean;
  }
  
  public InputStream getInputStream() {
    return this.stream;
  }
  
  public JSONObject readAsJSON() {
    return JSONUtils.getJSONObjectFromString(readAsString());
  }
  
  public String readAsString() {
    String str = StringUtils.readStringFromInputStream(this.stream);
    if (this.enableLog)
      Log.d(this.logTag, "Response Body: %s", new Object[] { str }); 
    return str;
  }
  
  public void setExternalLogTag(String paramString) {
    if (paramString == null) {
      this.logTag = LOGTAG;
      return;
    } 
    this.logTag = LOGTAG + " " + paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ResponseReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */