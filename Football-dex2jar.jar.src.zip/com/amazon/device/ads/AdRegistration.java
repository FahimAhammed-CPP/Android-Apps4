package com.amazon.device.ads;

import android.content.Context;

public final class AdRegistration {
  private static final String LOG_TAG = "AdRegistration";
  
  public static final void enableLogging(boolean paramBoolean) {
    Log.enableLoggingWithSetterNotification("AdRegistration", paramBoolean);
  }
  
  public static final void enableTesting(boolean paramBoolean) {
    Settings.getInstance().putTransientBoolean("testingEnabled", paramBoolean);
    Log.logSetterNotification("AdRegistration", "Test mode", Boolean.valueOf(paramBoolean));
  }
  
  public static final String getVersion() {
    return Version.getSDKVersion();
  }
  
  public static final void registerApp(Context paramContext) {
    if (!PermissionChecker.hasInternetPermission(paramContext)) {
      Log.e("AdRegistration", "Network task cannot commence because the INTERNET permission is missing from the app's manifest.", new Object[0]);
      return;
    } 
    AmazonAdRegistration.initializeAdSDK(paramContext);
    AmazonRegistration.getInstance().register();
  }
  
  public static final void setAppKey(String paramString) throws IllegalArgumentException {
    AmazonRegistration.getInstance().getRegistrationInfo().putAppKey(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdRegistration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */