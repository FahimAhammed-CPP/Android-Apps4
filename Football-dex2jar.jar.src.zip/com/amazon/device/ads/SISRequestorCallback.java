package com.amazon.device.ads;

interface SISRequestorCallback {
  void onSISCallComplete();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\SISRequestorCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */