package com.amazon.device.ads;

import org.json.JSONObject;

class Position {
  private Size size = new Size(0, 0);
  
  private int x = 0;
  
  private int y = 0;
  
  public Position() {}
  
  public Position(Size paramSize, int paramInt1, int paramInt2) {}
  
  public Size getSize() {
    return this.size;
  }
  
  public int getX() {
    return this.x;
  }
  
  public int getY() {
    return this.y;
  }
  
  public void setSize(Size paramSize) {
    this.size = paramSize;
  }
  
  public void setX(int paramInt) {
    this.x = paramInt;
  }
  
  public void setY(int paramInt) {
    this.y = paramInt;
  }
  
  public JSONObject toJSONObject() {
    JSONObject jSONObject = this.size.toJSONObject();
    JSONUtils.put(jSONObject, "x", this.x);
    JSONUtils.put(jSONObject, "y", this.y);
    return jSONObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Position.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */