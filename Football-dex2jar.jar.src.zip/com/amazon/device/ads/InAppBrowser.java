package com.amazon.device.ads;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import java.util.concurrent.atomic.AtomicBoolean;

class InAppBrowser implements AdActivity.IAdActivityAdapter {
  protected static final int BUTTON_SIZE_DP = 50;
  
  private static final String CONTENT_DESCRIPTION_BACK_BUTTON = "inAppBrowserBackButton";
  
  private static final String CONTENT_DESCRIPTION_BUTTON_LAYOUT = "inAppBrowserButtonLayout";
  
  private static final String CONTENT_DESCRIPTION_CLOSE_BUTTON = "inAppBrowserCloseButton";
  
  private static final String CONTENT_DESCRIPTION_FORWARD_BUTTON = "inAppBrowserForwardButton";
  
  private static final String CONTENT_DESCRIPTION_HORZ_RULE = "inAppBrowserHorizontalRule";
  
  private static final String CONTENT_DESCRIPTION_MAIN_LAYOUT = "inAppBrowserMainLayout";
  
  private static final String CONTENT_DESCRIPTION_OPEN_EXT_BRWSR_BUTTON = "inAppBrowserOpenExternalBrowserButton";
  
  private static final String CONTENT_DESCRIPTION_REFRESH_BUTTON = "inAppBrowserRefreshButton";
  
  private static final String CONTENT_DESCRIPTION_RELATIVE_LAYOUT = "inAppBrowserRelativeLayout";
  
  private static final String CONTENT_DESCRIPTION_WEB_VIEW = "inAppBrowserWebView";
  
  protected static final int HORIZONTAL_RULE_SIZE_DP = 3;
  
  protected static final String LOG_TAG = InAppBrowser.class.getSimpleName();
  
  protected static final String SHOW_OPEN_EXTERNAL_BROWSER_BTN = "extra_open_btn";
  
  protected static final String URL_EXTRA = "extra_url";
  
  private Activity activity;
  
  private ImageButton browserBackButton;
  
  private ImageButton browserForwardButton;
  
  private final AtomicBoolean buttonsCreated = new AtomicBoolean(false);
  
  private ImageButton closeButton;
  
  private ImageButton openExternalBrowserButton;
  
  private ImageButton refreshButton;
  
  private boolean showOpenExternalBrowserButton;
  
  private final WebUtils2 webUtils;
  
  private WebView webView;
  
  InAppBrowser() {
    this(new WebUtils2());
  }
  
  InAppBrowser(WebUtils2 paramWebUtils2) {
    this.webUtils = paramWebUtils2;
  }
  
  private ImageButton createButton(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ImageButton imageButton = new ImageButton((Context)this.activity);
    imageButton.setImageBitmap(BitmapFactory.decodeFile(paramString));
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(paramInt3, paramInt4);
    layoutParams.addRule(paramInt1, paramInt2);
    layoutParams.addRule(12);
    imageButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    imageButton.setBackgroundColor(0);
    imageButton.setScaleType(ImageView.ScaleType.FIT_CENTER);
    return imageButton;
  }
  
  private void enableCookies() {
    CookieSyncManager.createInstance((Context)this.activity);
    CookieSyncManager.getInstance().startSync();
  }
  
  @SuppressLint({"InlinedApi"})
  private void initialize(Intent paramIntent) {
    DisplayMetrics displayMetrics = new DisplayMetrics();
    getMetrics(displayMetrics);
    float f = displayMetrics.density;
    int j = (int)(50.0F * f + 0.5F);
    int k = (int)(3.0F * f + 0.5F);
    if (this.showOpenExternalBrowserButton) {
      i = 5;
    } else {
      i = 4;
    } 
    int i = Math.min(displayMetrics.widthPixels / i, j * 2);
    RelativeLayout relativeLayout2 = createRelativeLayout(this.activity);
    relativeLayout2.setContentDescription("inAppBrowserButtonLayout");
    relativeLayout2.setId(10280);
    RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, j + k);
    layoutParams2.addRule(12);
    relativeLayout2.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
    relativeLayout2.setBackgroundColor(-986896);
    ThreadUtils.executeAsyncTask(new LoadButtonsTask(paramIntent, (ViewGroup)relativeLayout2, i, j), new Void[0]);
    View view = new View((Context)this.activity);
    view.setContentDescription("inAppBrowserHorizontalRule");
    view.setBackgroundColor(-3355444);
    layoutParams2 = new RelativeLayout.LayoutParams(-1, k);
    layoutParams2.addRule(10);
    view.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
    relativeLayout2.addView(view);
    this.webView = WebViewFactory.getInstance().createWebView((Context)this.activity);
    this.webView.getSettings().setUserAgentString(AmazonRegistration.getInstance().getDeviceInfo().getUserAgentString() + "-inAppBrowser");
    this.webView.setContentDescription("inAppBrowserWebView");
    RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-1, -1);
    layoutParams1.addRule(2, relativeLayout2.getId());
    this.webView.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
    RelativeLayout relativeLayout1 = new RelativeLayout((Context)this.activity);
    relativeLayout1.setContentDescription("inAppBrowserRelativeLayout");
    relativeLayout1.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -2));
    relativeLayout1.addView((View)this.webView);
    relativeLayout1.addView((View)relativeLayout2);
    LinearLayout linearLayout = new LinearLayout((Context)this.activity);
    linearLayout.setContentDescription("inAppBrowserMainLayout");
    linearLayout.setOrientation(1);
    linearLayout.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
    linearLayout.addView((View)relativeLayout1);
    this.activity.setContentView((View)linearLayout);
  }
  
  private void initializeButtons(Intent paramIntent) {
    this.browserBackButton.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (InAppBrowser.this.webView.canGoBack())
              InAppBrowser.this.webView.goBack(); 
          }
        });
    this.browserForwardButton.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (InAppBrowser.this.webView.canGoForward())
              InAppBrowser.this.webView.goForward(); 
          }
        });
    this.refreshButton.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            InAppBrowser.this.webView.reload();
          }
        });
    this.closeButton.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            InAppBrowser.this.activity.finish();
          }
        });
    if (this.showOpenExternalBrowserButton) {
      final String originalUrl = paramIntent.getStringExtra("extra_url");
      this.openExternalBrowserButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param1View) {
              String str2 = InAppBrowser.this.webView.getUrl();
              String str1 = str2;
              if (str2 == null) {
                Log.w(InAppBrowser.LOG_TAG, "The current URL is null. Reverting to the original URL for external browser.", new Object[0]);
                str1 = originalUrl;
              } 
              InAppBrowser.this.webUtils.launchActivityForIntentLink(str1, InAppBrowser.this.webView.getContext());
            }
          });
    } 
  }
  
  private void initializeWebView(Intent paramIntent) {
    WebViewFactory.setJavaScriptEnabledForWebView(true, this.webView, LOG_TAG);
    this.webView.loadUrl(paramIntent.getStringExtra("extra_url"));
    this.webView.setWebViewClient(new WebViewClient() {
          public void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2) {
            Log.w(InAppBrowser.LOG_TAG, "InApp Browser error: %s", new Object[] { param1String1 });
          }
          
          public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
            if (!StringUtils.isNullOrWhiteSpace(param1String)) {
              String str = InAppBrowser.this.webUtils.getScheme(param1String);
              if (!str.equals("http") && !str.equals("https"))
                return InAppBrowser.this.webUtils.launchActivityForIntentLink(param1String, (Context)InAppBrowser.this.activity); 
            } 
            return false;
          }
        });
    this.webView.setWebChromeClient(new WebChromeClient() {
          public void onProgressChanged(WebView param1WebView, int param1Int) {
            Activity activity = (Activity)param1WebView.getContext();
            activity.setTitle("Loading...");
            activity.setProgress(param1Int * 100);
            if (param1Int == 100)
              activity.setTitle(param1WebView.getUrl()); 
            InAppBrowser.this.updateNavigationButtons(param1WebView);
          }
        });
  }
  
  private void updateNavigationButtons(WebView paramWebView) {
    if (this.browserBackButton != null && this.browserForwardButton != null) {
      if (paramWebView.canGoBack()) {
        AndroidTargetUtils.setImageButtonAlpha(this.browserBackButton, 255);
      } else {
        AndroidTargetUtils.setImageButtonAlpha(this.browserBackButton, 102);
      } 
      if (paramWebView.canGoForward()) {
        AndroidTargetUtils.setImageButtonAlpha(this.browserForwardButton, 255);
        return;
      } 
    } else {
      return;
    } 
    AndroidTargetUtils.setImageButtonAlpha(this.browserForwardButton, 102);
  }
  
  protected boolean canPauseWebViewTimers() {
    return (this.webView != null && getShouldPauseWebViewTimers());
  }
  
  protected boolean canResumeWebViewTimers() {
    return (this.webView != null && getShouldPauseWebViewTimers());
  }
  
  RelativeLayout createRelativeLayout(Activity paramActivity) {
    return new RelativeLayout((Context)paramActivity);
  }
  
  void getMetrics(DisplayMetrics paramDisplayMetrics) {
    ((WindowManager)this.activity.getSystemService("window")).getDefaultDisplay().getMetrics(paramDisplayMetrics);
  }
  
  protected boolean getShouldPauseWebViewTimers() {
    return Settings.getInstance().getBoolean("shouldPauseWebViewTimersInWebViewRelatedActivities", false);
  }
  
  public boolean onBackPressed() {
    return false;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    DisplayMetrics displayMetrics = new DisplayMetrics();
    getMetrics(displayMetrics);
    int j = (int)(50.0F * displayMetrics.density + 0.5F);
    if (this.showOpenExternalBrowserButton) {
      i = 5;
    } else {
      i = 4;
    } 
    int i = Math.min(displayMetrics.widthPixels / i, j * 2);
    Log.d(LOG_TAG, "Width: " + displayMetrics.widthPixels + " ButtonWidth: " + i, new Object[0]);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i, j);
    if (this.browserBackButton != null) {
      layoutParams.addRule(9);
      layoutParams.addRule(12);
      this.browserBackButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
    if (this.browserForwardButton != null) {
      layoutParams = new RelativeLayout.LayoutParams(i, j);
      layoutParams.addRule(1, this.browserBackButton.getId());
      layoutParams.addRule(12);
      this.browserForwardButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
    if (this.closeButton != null) {
      layoutParams = new RelativeLayout.LayoutParams(i, j);
      layoutParams.addRule(11);
      layoutParams.addRule(12);
      this.closeButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
    if (this.openExternalBrowserButton != null) {
      layoutParams = new RelativeLayout.LayoutParams(i, j);
      layoutParams.addRule(1, this.browserForwardButton.getId());
      layoutParams.addRule(12);
      this.openExternalBrowserButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      if (this.refreshButton != null) {
        layoutParams = new RelativeLayout.LayoutParams(i, j);
        layoutParams.addRule(1, this.openExternalBrowserButton.getId());
        layoutParams.addRule(12);
        this.refreshButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      } 
      return;
    } 
    if (this.refreshButton != null) {
      layoutParams = new RelativeLayout.LayoutParams(i, j);
      layoutParams.addRule(1, this.browserForwardButton.getId());
      layoutParams.addRule(12);
      this.refreshButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      return;
    } 
  }
  
  public void onCreate() {
    this.activity.getWindow().requestFeature(2);
    this.activity.getWindow().setFeatureInt(2, -1);
    Intent intent = this.activity.getIntent();
    this.showOpenExternalBrowserButton = intent.getBooleanExtra("extra_open_btn", false);
    initialize(intent);
    initializeWebView(intent);
    enableCookies();
  }
  
  public void onPause() {
    Log.d(LOG_TAG, "onPause", new Object[0]);
    pauseWebView();
    if (canPauseWebViewTimers())
      this.webView.pauseTimers(); 
    CookieSyncManager.getInstance().stopSync();
  }
  
  public void onResume() {
    Log.d(LOG_TAG, "onResume", new Object[0]);
    resumeWebView();
    if (canResumeWebViewTimers())
      this.webView.resumeTimers(); 
    CookieSyncManager.getInstance().startSync();
  }
  
  public void onStop() {}
  
  void pauseWebView() {
    this.webView.onPause();
  }
  
  public void preOnCreate() {}
  
  void resumeWebView() {
    this.webView.onResume();
  }
  
  public void setActivity(Activity paramActivity) {
    this.activity = paramActivity;
  }
  
  public static class InAppBrowserBuilder {
    private static final String LOGTAG = InAppBrowserBuilder.class.getSimpleName();
    
    private Context context;
    
    private boolean showOpenExternalBrowserButton;
    
    private String url;
    
    public void show() {
      if (this.context == null)
        throw new IllegalArgumentException("Context must not be null"); 
      if (StringUtils.isNullOrWhiteSpace(this.url))
        throw new IllegalArgumentException("Url must not be null or white space"); 
      if (!Assets.getInstance().ensureAssetsCreated()) {
        Log.e(LOGTAG, "Could not load application assets, failed to open URI: %s", new Object[] { this.url });
        return;
      } 
      Intent intent = new Intent(this.context, AdActivity.class);
      intent.putExtra("adapter", InAppBrowser.class.getName());
      intent.putExtra("extra_url", this.url);
      intent.putExtra("extra_open_btn", this.showOpenExternalBrowserButton);
      intent.addFlags(268435456);
      this.context.startActivity(intent);
    }
    
    public InAppBrowserBuilder withContext(Context param1Context) {
      this.context = param1Context;
      return this;
    }
    
    public InAppBrowserBuilder withExternalBrowserButton() {
      this.showOpenExternalBrowserButton = true;
      return this;
    }
    
    public InAppBrowserBuilder withUrl(String param1String) {
      this.url = param1String;
      return this;
    }
  }
  
  class LoadButtonsTask extends AsyncTask<Void, Void, Void> {
    private final int buttonHeight;
    
    private final int buttonWidth;
    
    private final Intent intent;
    
    private final ViewGroup layout;
    
    public LoadButtonsTask(Intent param1Intent, ViewGroup param1ViewGroup, int param1Int1, int param1Int2) {
      this.intent = param1Intent;
      this.layout = param1ViewGroup;
      this.buttonWidth = param1Int1;
      this.buttonHeight = param1Int2;
    }
    
    protected Void doInBackground(Void... param1VarArgs) {
      InAppBrowser.access$402(InAppBrowser.this, InAppBrowser.this.createButton(Assets.getInstance().getFilePath("amazon_ads_leftarrow.png"), 9, -1, this.buttonWidth, this.buttonHeight));
      InAppBrowser.this.browserBackButton.setContentDescription("inAppBrowserBackButton");
      InAppBrowser.this.browserBackButton.setId(10537);
      InAppBrowser.access$602(InAppBrowser.this, InAppBrowser.this.createButton(Assets.getInstance().getFilePath("amazon_ads_rightarrow.png"), 1, InAppBrowser.this.browserBackButton.getId(), this.buttonWidth, this.buttonHeight));
      InAppBrowser.this.browserForwardButton.setContentDescription("inAppBrowserForwardButton");
      InAppBrowser.this.browserForwardButton.setId(10794);
      InAppBrowser.access$702(InAppBrowser.this, InAppBrowser.this.createButton(Assets.getInstance().getFilePath("amazon_ads_close.png"), 11, -1, this.buttonWidth, this.buttonHeight));
      InAppBrowser.this.closeButton.setContentDescription("inAppBrowserCloseButton");
      if (InAppBrowser.this.showOpenExternalBrowserButton) {
        InAppBrowser.access$902(InAppBrowser.this, InAppBrowser.this.createButton(Assets.getInstance().getFilePath("amazon_ads_open_external_browser.png"), 1, InAppBrowser.this.browserForwardButton.getId(), this.buttonWidth, this.buttonHeight));
        InAppBrowser.this.openExternalBrowserButton.setContentDescription("inAppBrowserOpenExternalBrowserButton");
        InAppBrowser.this.openExternalBrowserButton.setId(10795);
        InAppBrowser.access$1002(InAppBrowser.this, InAppBrowser.this.createButton(Assets.getInstance().getFilePath("amazon_ads_refresh.png"), 1, InAppBrowser.this.openExternalBrowserButton.getId(), this.buttonWidth, this.buttonHeight));
        InAppBrowser.this.refreshButton.setContentDescription("inAppBrowserRefreshButton");
        return null;
      } 
      InAppBrowser.access$1002(InAppBrowser.this, InAppBrowser.this.createButton(Assets.getInstance().getFilePath("amazon_ads_refresh.png"), 1, InAppBrowser.this.browserForwardButton.getId(), this.buttonWidth, this.buttonHeight));
      InAppBrowser.this.refreshButton.setContentDescription("inAppBrowserRefreshButton");
      return null;
    }
    
    protected void onPostExecute(Void param1Void) {
      this.layout.addView((View)InAppBrowser.this.browserBackButton);
      this.layout.addView((View)InAppBrowser.this.browserForwardButton);
      this.layout.addView((View)InAppBrowser.this.refreshButton);
      this.layout.addView((View)InAppBrowser.this.closeButton);
      if (InAppBrowser.this.showOpenExternalBrowserButton)
        this.layout.addView((View)InAppBrowser.this.openExternalBrowserButton); 
      InAppBrowser.this.initializeButtons(this.intent);
      InAppBrowser.this.buttonsCreated.set(true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\InAppBrowser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */