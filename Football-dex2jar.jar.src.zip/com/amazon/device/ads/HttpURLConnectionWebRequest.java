package com.amazon.device.ads;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.Map;

class HttpURLConnectionWebRequest extends WebRequest {
  private static final String LOG_TAG = HttpURLConnectionWebRequest.class.getSimpleName();
  
  private HttpURLConnection connection;
  
  private void writePostBody(HttpURLConnection paramHttpURLConnection) throws WebRequest.WebRequestException {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: aload_0
    //   10: getfield requestBody : Ljava/lang/String;
    //   13: ifnull -> 96
    //   16: aload #4
    //   18: aload_0
    //   19: getfield requestBody : Ljava/lang/String;
    //   22: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   25: pop
    //   26: aload_0
    //   27: getfield logRequestBodyEnabled : Z
    //   30: ifeq -> 60
    //   33: aload_0
    //   34: invokevirtual getRequestBody : ()Ljava/lang/String;
    //   37: ifnull -> 60
    //   40: aload_0
    //   41: invokevirtual getLogTag : ()Ljava/lang/String;
    //   44: ldc 'Request Body: %s'
    //   46: iconst_1
    //   47: anewarray java/lang/Object
    //   50: dup
    //   51: iconst_0
    //   52: aload_0
    //   53: invokevirtual getRequestBody : ()Ljava/lang/String;
    //   56: aastore
    //   57: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   60: aconst_null
    //   61: astore_2
    //   62: aconst_null
    //   63: astore_3
    //   64: new java/io/OutputStreamWriter
    //   67: dup
    //   68: aload_1
    //   69: invokevirtual getOutputStream : ()Ljava/io/OutputStream;
    //   72: ldc 'UTF-8'
    //   74: invokespecial <init> : (Ljava/io/OutputStream;Ljava/lang/String;)V
    //   77: astore_1
    //   78: aload_1
    //   79: aload #4
    //   81: invokevirtual toString : ()Ljava/lang/String;
    //   84: invokevirtual write : (Ljava/lang/String;)V
    //   87: aload_1
    //   88: ifnull -> 95
    //   91: aload_1
    //   92: invokevirtual close : ()V
    //   95: return
    //   96: aload_0
    //   97: getfield postParameters : Ljava/util/HashMap;
    //   100: ifnull -> 26
    //   103: aload_0
    //   104: getfield postParameters : Ljava/util/HashMap;
    //   107: invokevirtual isEmpty : ()Z
    //   110: ifne -> 26
    //   113: aload_0
    //   114: getfield postParameters : Ljava/util/HashMap;
    //   117: invokevirtual entrySet : ()Ljava/util/Set;
    //   120: invokeinterface iterator : ()Ljava/util/Iterator;
    //   125: astore_2
    //   126: aload_2
    //   127: invokeinterface hasNext : ()Z
    //   132: ifeq -> 188
    //   135: aload_2
    //   136: invokeinterface next : ()Ljava/lang/Object;
    //   141: checkcast java/util/Map$Entry
    //   144: astore_3
    //   145: aload #4
    //   147: aload_3
    //   148: invokeinterface getKey : ()Ljava/lang/Object;
    //   153: checkcast java/lang/String
    //   156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: ldc '='
    //   161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: aload_3
    //   165: invokeinterface getValue : ()Ljava/lang/Object;
    //   170: checkcast java/lang/String
    //   173: invokestatic getURLEncodedString : (Ljava/lang/String;)Ljava/lang/String;
    //   176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: ldc '&'
    //   181: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   184: pop
    //   185: goto -> 126
    //   188: aload #4
    //   190: aload #4
    //   192: ldc '&'
    //   194: invokevirtual lastIndexOf : (Ljava/lang/String;)I
    //   197: invokevirtual deleteCharAt : (I)Ljava/lang/StringBuilder;
    //   200: pop
    //   201: goto -> 26
    //   204: astore_1
    //   205: aload_0
    //   206: invokevirtual getLogTag : ()Ljava/lang/String;
    //   209: ldc 'Problem while closing output stream writer for request body: %s'
    //   211: iconst_1
    //   212: anewarray java/lang/Object
    //   215: dup
    //   216: iconst_0
    //   217: aload_1
    //   218: invokevirtual getMessage : ()Ljava/lang/String;
    //   221: aastore
    //   222: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   225: new com/amazon/device/ads/WebRequest$WebRequestException
    //   228: dup
    //   229: aload_0
    //   230: getstatic com/amazon/device/ads/WebRequest$WebRequestStatus.NETWORK_FAILURE : Lcom/amazon/device/ads/WebRequest$WebRequestStatus;
    //   233: ldc 'Problem while closing output stream writer for request body'
    //   235: aload_1
    //   236: invokespecial <init> : (Lcom/amazon/device/ads/WebRequest;Lcom/amazon/device/ads/WebRequest$WebRequestStatus;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   239: athrow
    //   240: astore_2
    //   241: aload_3
    //   242: astore_1
    //   243: aload_2
    //   244: astore_3
    //   245: aload_1
    //   246: astore_2
    //   247: aload_0
    //   248: invokevirtual getLogTag : ()Ljava/lang/String;
    //   251: ldc 'Problem while creating output steam for request body: %s'
    //   253: iconst_1
    //   254: anewarray java/lang/Object
    //   257: dup
    //   258: iconst_0
    //   259: aload_3
    //   260: invokevirtual getMessage : ()Ljava/lang/String;
    //   263: aastore
    //   264: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   267: aload_1
    //   268: astore_2
    //   269: new com/amazon/device/ads/WebRequest$WebRequestException
    //   272: dup
    //   273: aload_0
    //   274: getstatic com/amazon/device/ads/WebRequest$WebRequestStatus.NETWORK_FAILURE : Lcom/amazon/device/ads/WebRequest$WebRequestStatus;
    //   277: ldc 'Problem while creating output steam for request body'
    //   279: aload_3
    //   280: invokespecial <init> : (Lcom/amazon/device/ads/WebRequest;Lcom/amazon/device/ads/WebRequest$WebRequestStatus;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   283: athrow
    //   284: astore_1
    //   285: aload_2
    //   286: ifnull -> 293
    //   289: aload_2
    //   290: invokevirtual close : ()V
    //   293: aload_1
    //   294: athrow
    //   295: astore_1
    //   296: aload_0
    //   297: invokevirtual getLogTag : ()Ljava/lang/String;
    //   300: ldc 'Problem while closing output stream writer for request body: %s'
    //   302: iconst_1
    //   303: anewarray java/lang/Object
    //   306: dup
    //   307: iconst_0
    //   308: aload_1
    //   309: invokevirtual getMessage : ()Ljava/lang/String;
    //   312: aastore
    //   313: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   316: new com/amazon/device/ads/WebRequest$WebRequestException
    //   319: dup
    //   320: aload_0
    //   321: getstatic com/amazon/device/ads/WebRequest$WebRequestStatus.NETWORK_FAILURE : Lcom/amazon/device/ads/WebRequest$WebRequestStatus;
    //   324: ldc 'Problem while closing output stream writer for request body'
    //   326: aload_1
    //   327: invokespecial <init> : (Lcom/amazon/device/ads/WebRequest;Lcom/amazon/device/ads/WebRequest$WebRequestStatus;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   330: athrow
    //   331: astore_3
    //   332: aload_1
    //   333: astore_2
    //   334: aload_3
    //   335: astore_1
    //   336: goto -> 285
    //   339: astore_3
    //   340: goto -> 245
    // Exception table:
    //   from	to	target	type
    //   64	78	240	java/io/IOException
    //   64	78	284	finally
    //   78	87	339	java/io/IOException
    //   78	87	331	finally
    //   91	95	204	java/io/IOException
    //   247	267	284	finally
    //   269	284	284	finally
    //   289	293	295	java/io/IOException
  }
  
  protected void closeConnection() {
    if (this.connection != null) {
      this.connection.disconnect();
      this.connection = null;
    } 
  }
  
  protected WebRequest.WebResponse doHttpNetworkCall(URL paramURL) throws WebRequest.WebRequestException {
    if (this.connection != null)
      closeConnection(); 
    try {
      this.connection = openConnection(paramURL);
      setupRequestProperties(this.connection);
      try {
        this.connection.connect();
        return prepareResponse(this.connection);
      } catch (SocketTimeoutException socketTimeoutException) {
        Log.e(getLogTag(), "Socket timed out while connecting to URL: %s", new Object[] { socketTimeoutException.getMessage() });
        throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.NETWORK_TIMEOUT, "Socket timed out while connecting to URL", socketTimeoutException);
      } catch (IOException iOException) {
        Log.e(getLogTag(), "IOException while connecting to URL: %s", new Object[] { iOException.getMessage() });
        throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.NETWORK_FAILURE, "Problem while connecting to URL", iOException);
      } catch (Exception exception) {
        Log.e(getLogTag(), "Problem while connecting to URL: %s", new Object[] { exception.getMessage() });
        throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.NETWORK_FAILURE, "Problem while connecting to URL", exception);
      } 
    } catch (IOException iOException) {
      Log.e(getLogTag(), "Problem while opening the URL connection: %s", new Object[] { iOException.getMessage() });
      throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.NETWORK_FAILURE, "Problem while opening the URL connection", iOException);
    } 
  }
  
  protected String getSubLogTag() {
    return LOG_TAG;
  }
  
  protected HttpURLConnection openConnection(URL paramURL) throws IOException {
    return (HttpURLConnection)paramURL.openConnection();
  }
  
  protected WebRequest.WebResponse prepareResponse(HttpURLConnection paramHttpURLConnection) throws WebRequest.WebRequestException {
    WebRequest.WebResponse webResponse = new WebRequest.WebResponse(this);
    try {
      webResponse.setHttpStatusCode(paramHttpURLConnection.getResponseCode());
      webResponse.setHttpStatus(paramHttpURLConnection.getResponseMessage());
      if (webResponse.getHttpStatusCode() == 200)
        try {
          webResponse.setInputStream(paramHttpURLConnection.getInputStream());
          return webResponse;
        } catch (IOException iOException) {
          Log.e(getLogTag(), "IOException while reading the input stream from response: %s", new Object[] { iOException.getMessage() });
          throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.NETWORK_FAILURE, "IOException while reading the input stream from response", iOException);
        }  
      return webResponse;
    } catch (SocketTimeoutException socketTimeoutException) {
      Log.e(getLogTag(), "Socket Timeout while getting the response status code: %s", new Object[] { socketTimeoutException.getMessage() });
      throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.NETWORK_TIMEOUT, "Socket Timeout while getting the response status code", socketTimeoutException);
    } catch (IOException iOException) {
      Log.e(getLogTag(), "IOException while getting the response status code: %s", new Object[] { iOException.getMessage() });
      throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.NETWORK_FAILURE, "IOException while getting the response status code", iOException);
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      Log.e(getLogTag(), "IndexOutOfBoundsException while getting the response status code: %s", new Object[] { indexOutOfBoundsException.getMessage() });
      throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.MALFORMED_URL, "IndexOutOfBoundsException while getting the response status code", indexOutOfBoundsException);
    } 
  }
  
  protected void setupRequestProperties(HttpURLConnection paramHttpURLConnection) throws WebRequest.WebRequestException {
    try {
      paramHttpURLConnection.setRequestMethod(getHttpMethod().name());
      for (Map.Entry<String, String> entry : this.headers.entrySet()) {
        if (entry.getValue() != null && !((String)entry.getValue()).equals(""))
          paramHttpURLConnection.setRequestProperty((String)entry.getKey(), (String)entry.getValue()); 
      } 
    } catch (ProtocolException protocolException) {
      Log.e(getLogTag(), "Invalid client protocol: %s", new Object[] { protocolException.getMessage() });
      throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.INVALID_CLIENT_PROTOCOL, "Invalid client protocol", protocolException);
    } 
    protocolException.setConnectTimeout(getTimeout());
    protocolException.setReadTimeout(getTimeout());
    logUrl(protocolException.getURL().toString());
    switch (getHttpMethod()) {
      default:
        return;
      case GET:
        protocolException.setDoOutput(false);
        return;
      case POST:
        break;
    } 
    protocolException.setDoOutput(true);
    writePostBody((HttpURLConnection)protocolException);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\HttpURLConnectionWebRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */