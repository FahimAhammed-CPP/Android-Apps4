package com.amazon.device.ads;

public class AdError {
  private final ErrorCode code;
  
  private final String message;
  
  AdError(ErrorCode paramErrorCode, String paramString) {
    this.code = paramErrorCode;
    this.message = paramString;
  }
  
  public ErrorCode getCode() {
    return this.code;
  }
  
  public String getMessage() {
    return this.message;
  }
  
  public enum ErrorCode {
    INTERNAL_ERROR, NETWORK_ERROR, NETWORK_TIMEOUT, NO_FILL, REQUEST_ERROR;
    
    static {
      $VALUES = new ErrorCode[] { NETWORK_ERROR, NETWORK_TIMEOUT, NO_FILL, INTERNAL_ERROR, REQUEST_ERROR };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */