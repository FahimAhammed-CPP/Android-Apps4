package com.amazon.device.ads;

class AdSlot {
  private final AdController adController;
  
  private AdError adError;
  
  private final AdTargetingOptions adOptions;
  
  private boolean deferredLoad = false;
  
  private int slotNumber;
  
  AdSlot(AdController paramAdController, AdTargetingOptions paramAdTargetingOptions) {
    this.adController = paramAdController;
    if (paramAdTargetingOptions == null) {
      this.adOptions = new AdTargetingOptions();
      return;
    } 
    this.adOptions = paramAdTargetingOptions;
  }
  
  void adFailed(AdError paramAdError) {
    this.adController.adFailed(paramAdError);
  }
  
  AdError getAdError() {
    return this.adError;
  }
  
  public AdTargetingOptions getAdTargetingOptions() {
    return this.adOptions;
  }
  
  String getMaxSize() {
    return this.adController.getMaxSize();
  }
  
  MetricsCollector getMetricsCollector() {
    return this.adController.getMetricsCollector();
  }
  
  public AdSize getRequestedAdSize() {
    return this.adController.getAdSize();
  }
  
  int getSlotNumber() {
    return this.slotNumber;
  }
  
  void initializeAd() {
    this.adController.initialize();
  }
  
  boolean isFetched() {
    return (this.adController.getAdData() != null && this.adController.getAdData().getIsFetched());
  }
  
  boolean isValid() {
    return this.adController.isValid();
  }
  
  boolean prepareForAdLoad(long paramLong) {
    return this.adController.prepareForAdLoad(paramLong, this.deferredLoad);
  }
  
  void setAdData(AdData paramAdData) {
    this.adController.setAdData(paramAdData);
  }
  
  void setAdError(AdError paramAdError) {
    this.adError = paramAdError;
  }
  
  void setConnectionInfo(ConnectionInfo paramConnectionInfo) {
    this.adController.setConnectionInfo(paramConnectionInfo);
  }
  
  public AdSlot setDeferredLoad(boolean paramBoolean) {
    this.deferredLoad = paramBoolean;
    return this;
  }
  
  void setSlotNumber(int paramInt) {
    this.slotNumber = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdSlot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */