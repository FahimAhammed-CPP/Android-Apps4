package com.amazon.device.ads;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

class AmazonDeviceLauncher {
  boolean isWindowshopPresent(Context paramContext) {
    return !(paramContext.getPackageManager().getLaunchIntentForPackage("com.amazon.windowshop") == null);
  }
  
  void launchWindowshopDetailPage(Context paramContext, String paramString) {
    Intent intent = paramContext.getPackageManager().getLaunchIntentForPackage("com.amazon.windowshop");
    if (intent != null) {
      intent.putExtra("com.amazon.windowshop.refinement.asin", paramString);
      paramContext.startActivity(intent);
    } 
  }
  
  void launchWindowshopSearchPage(Context paramContext, String paramString) {
    Intent intent = new Intent("android.intent.action.SEARCH");
    intent.setComponent(new ComponentName("com.amazon.windowshop", "com.amazon.windowshop.search.SearchResultsGridActivity"));
    intent.putExtra("query", paramString);
    try {
      paramContext.startActivity(intent);
      return;
    } catch (RuntimeException runtimeException) {
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AmazonDeviceLauncher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */