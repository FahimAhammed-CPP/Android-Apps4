package com.amazon.device.ads;

interface AdSDKBridge {
  String getJavascript();
  
  JavascriptInteractor.Executor getJavascriptInteractorExecutor();
  
  String getName();
  
  SDKEventListener getSDKEventListener();
  
  boolean hasNativeExecution();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdSDKBridge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */