package com.amazon.device.ads;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import java.util.HashSet;
import java.util.Set;

class ViewManager {
  private static final String CONTENT_DESCRIPTION_NEW_WEBVIEW = "newWebView";
  
  private static final String CONTENT_DESCRIPTION_ORIGINAL_WEBVIEW = "originalWebView";
  
  private static final String CONTENT_DESCRIPTION_PRELOADED_WEBVIEW = "preloadedWebView";
  
  private static final String LOGTAG = ViewManager.class.getSimpleName();
  
  private final AndroidTargetUtils.AndroidClassAdapter androidClassAdapter;
  
  private WebView currentWebView;
  
  private boolean disableHardwareAcceleration = false;
  
  private final Set<String> javascriptInterfaceNames = new HashSet<String>();
  
  private View.OnKeyListener keyListener;
  
  private final ViewGroup parent;
  
  private WebView preloadedWebView;
  
  private WebView stashedWebView;
  
  private WebViewClient webViewClient;
  
  private final WebViewFactory.WebViewFactory2 webViewFactory;
  
  private int webViewHeight = -1;
  
  public ViewManager(ViewGroup paramViewGroup) {
    this(paramViewGroup, new WebViewFactory.WebViewFactory2(), AndroidTargetUtils.getDefaultAndroidClassAdapter());
  }
  
  ViewManager(ViewGroup paramViewGroup, WebViewFactory.WebViewFactory2 paramWebViewFactory2, AndroidTargetUtils.AndroidClassAdapter paramAndroidClassAdapter) {
    this.parent = paramViewGroup;
    this.webViewFactory = paramWebViewFactory2;
    this.androidClassAdapter = paramAndroidClassAdapter;
  }
  
  private void destroyWebViews(WebView... webViews) {
    ThreadUtils.executeOnMainThread(new Runnable() {
          public void run() {
            for (WebView webView : webViews) {
              if (webView != null) {
                if (webView.getParent() != null)
                  ((ViewGroup)webView.getParent()).removeView((View)webView); 
                try {
                  webView.destroy();
                } catch (IllegalArgumentException illegalArgumentException) {
                  Log.w("Caught an IllegalArgumentException while destroying a WebView: %s", illegalArgumentException.getMessage(), new Object[0]);
                } 
              } 
            } 
          }
        });
  }
  
  private WebView getCurrentWebView() {
    if (this.currentWebView == null) {
      WebView webView = createWebView(getContext((View)this.parent));
      if (!validateWebView(webView))
        throw new IllegalStateException("Could not create WebView"); 
      webView.setContentDescription("originalWebView");
      setWebView(webView, false);
    } 
    return this.currentWebView;
  }
  
  private WebView getPreloadedWebView() {
    if (this.preloadedWebView == null) {
      this.preloadedWebView = createWebView(this.parent.getContext());
      this.preloadedWebView.setContentDescription("preloadedWebView");
    } 
    return this.preloadedWebView;
  }
  
  private boolean isInitialized() {
    return (this.currentWebView != null);
  }
  
  public void addJavascriptInterface(Object paramObject, boolean paramBoolean, String paramString) {
    Log.d(LOGTAG, "Add JavaScript Interface %s", new Object[] { paramString });
    this.javascriptInterfaceNames.add(paramString);
    if (paramBoolean) {
      getPreloadedWebView().addJavascriptInterface(paramObject, paramString);
      return;
    } 
    getCurrentWebView().addJavascriptInterface(paramObject, paramString);
  }
  
  void addViewToParent(WebView paramWebView) {
    this.parent.addView((View)paramWebView);
  }
  
  WebView createWebView(Context paramContext) {
    WebView webView2 = this.webViewFactory.createWebView(paramContext);
    if (!WebViewFactory.setJavaScriptEnabledForWebView(true, webView2, LOGTAG))
      return null; 
    WebSettings webSettings = webView2.getSettings();
    this.androidClassAdapter.withWebSettings(webSettings).setMediaPlaybackRequiresUserGesture(false);
    webView2.setScrollContainer(false);
    webView2.setBackgroundColor(0);
    webView2.setVerticalScrollBarEnabled(false);
    webView2.setHorizontalScrollBarEnabled(false);
    webView2.setWebChromeClient(new AdWebChromeClient());
    webSettings.setDomStorageEnabled(true);
    WebView webView1 = webView2;
    if (this.disableHardwareAcceleration) {
      AndroidTargetUtils.disableHardwareAcceleration((View)webView2);
      return webView2;
    } 
    return webView1;
  }
  
  public void destroy() {
    destroyWebViews(new WebView[] { this.currentWebView, this.stashedWebView, this.preloadedWebView });
    this.currentWebView = null;
    this.stashedWebView = null;
    this.preloadedWebView = null;
  }
  
  public void disableHardwareAcceleration(boolean paramBoolean) {
    this.disableHardwareAcceleration = paramBoolean;
  }
  
  Context getContext(View paramView) {
    return paramView.getContext();
  }
  
  public void initialize() throws IllegalStateException {
    getCurrentWebView();
  }
  
  public boolean isCurrentView(View paramView) {
    return paramView.equals(this.currentWebView);
  }
  
  public void listenForKey(View.OnKeyListener paramOnKeyListener) {
    this.keyListener = paramOnKeyListener;
    getCurrentWebView().requestFocus();
    getCurrentWebView().setOnKeyListener(this.keyListener);
  }
  
  public void loadData(String paramString1, String paramString2, String paramString3) {
    loadData(paramString1, paramString2, paramString3, false, null);
  }
  
  public void loadData(String paramString1, String paramString2, String paramString3, boolean paramBoolean, PreloadCallback paramPreloadCallback) {
    if (paramBoolean) {
      if (paramPreloadCallback != null)
        getPreloadedWebView().setWebViewClient(new PreloadWebViewClient(paramPreloadCallback)); 
      getPreloadedWebView().loadData(paramString1, paramString2, paramString3);
      return;
    } 
    getCurrentWebView().loadData(paramString1, paramString2, paramString3);
  }
  
  public void loadDataWithBaseURL(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    loadDataWithBaseURL(paramString1, paramString2, paramString3, paramString4, paramString5, false, null);
  }
  
  public void loadDataWithBaseURL(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean, PreloadCallback paramPreloadCallback) {
    if (paramBoolean) {
      if (paramPreloadCallback != null)
        getPreloadedWebView().setWebViewClient(new PreloadWebViewClient(paramPreloadCallback)); 
      getPreloadedWebView().loadDataWithBaseURL(paramString1, paramString2, paramString3, paramString4, paramString5);
      return;
    } 
    getCurrentWebView().loadDataWithBaseURL(paramString1, paramString2, paramString3, paramString4, paramString5);
  }
  
  public void loadUrl(String paramString) {
    loadUrl(paramString, false, null);
  }
  
  public void loadUrl(String paramString, boolean paramBoolean, PreloadCallback paramPreloadCallback) {
    if (paramBoolean) {
      if (paramPreloadCallback != null)
        getPreloadedWebView().setWebViewClient(new PreloadWebViewClient(paramPreloadCallback)); 
      getPreloadedWebView().loadUrl(paramString);
      return;
    } 
    Log.d(LOGTAG, "Loading URL: " + paramString, new Object[0]);
    getCurrentWebView().loadUrl(paramString);
  }
  
  public boolean popView() {
    if (this.stashedWebView != null) {
      WebView webView = this.stashedWebView;
      this.stashedWebView = null;
      setWebView(webView, true);
      return true;
    } 
    return false;
  }
  
  public void removePreviousInterfaces() {
    if (this.currentWebView != null)
      if (AndroidTargetUtils.isAtLeastAndroidAPI(11)) {
        for (String str : this.javascriptInterfaceNames)
          AndroidTargetUtils.removeJavascriptInterface(this.currentWebView, str); 
      } else {
        setWebView(createWebView(this.parent.getContext()), true);
        this.currentWebView.setContentDescription("originalWebView");
      }  
    this.javascriptInterfaceNames.clear();
  }
  
  public void setHeight(int paramInt) {
    this.webViewHeight = paramInt;
    if (isInitialized())
      setWebViewLayoutParams(getCurrentWebView(), -1, this.webViewHeight); 
  }
  
  void setWebView(WebView paramWebView, boolean paramBoolean) {
    WebView webView = this.currentWebView;
    if (webView != null) {
      webView.setOnKeyListener(null);
      webView.setWebViewClient(new WebViewClient());
      this.parent.removeView((View)webView);
      if (paramBoolean)
        destroyWebViews(new WebView[] { webView }); 
    } 
    paramWebView.setWebViewClient(this.webViewClient);
    this.currentWebView = paramWebView;
    setWebViewLayoutParams(this.currentWebView, -1, this.webViewHeight);
    addViewToParent(this.currentWebView);
    if (this.keyListener != null)
      listenForKey(this.keyListener); 
  }
  
  public void setWebViewClient(WebViewClient paramWebViewClient) {
    this.webViewClient = paramWebViewClient;
    if (isInitialized())
      getCurrentWebView().setWebViewClient(this.webViewClient); 
  }
  
  protected void setWebViewLayoutParams(WebView paramWebView, int paramInt1, int paramInt2) {
    if (paramWebView.getLayoutParams() == null) {
      paramWebView.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(paramInt1, paramInt2));
      return;
    } 
    (paramWebView.getLayoutParams()).width = paramInt1;
    (paramWebView.getLayoutParams()).height = paramInt2;
  }
  
  public void stashView() {
    WebView webView;
    if (this.stashedWebView != null)
      destroyWebViews(new WebView[] { this.stashedWebView }); 
    this.stashedWebView = this.currentWebView;
    if (this.preloadedWebView == null) {
      webView = createWebView(this.parent.getContext());
      webView.setContentDescription("newWebView");
    } else {
      webView = this.preloadedWebView;
      this.preloadedWebView = createWebView(this.parent.getContext());
    } 
    setWebView(webView, false);
  }
  
  boolean validateWebView(WebView paramWebView) {
    return (paramWebView != null);
  }
  
  private class AdWebChromeClient extends WebChromeClient {
    private AdWebChromeClient() {}
    
    public boolean onJsAlert(WebView param1WebView, String param1String1, String param1String2, JsResult param1JsResult) {
      Log.d(ViewManager.LOGTAG, param1String2, new Object[0]);
      return false;
    }
  }
  
  private class PreloadWebViewClient extends WebViewClient {
    private final PreloadCallback callback;
    
    public PreloadWebViewClient(PreloadCallback param1PreloadCallback) {
      this.callback = param1PreloadCallback;
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      if (this.callback != null)
        this.callback.onPreloadComplete(param1String); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ViewManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */