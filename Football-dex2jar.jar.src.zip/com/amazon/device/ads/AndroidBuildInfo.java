package com.amazon.device.ads;

import android.os.Build;

class AndroidBuildInfo {
  private String make = Build.MANUFACTURER;
  
  private String model = Build.MODEL;
  
  private String osVersion = Build.VERSION.RELEASE;
  
  private int sdkInt = Build.VERSION.SDK_INT;
  
  public String getMake() {
    return this.make;
  }
  
  public String getModel() {
    return this.model;
  }
  
  public String getOsVersion() {
    return this.osVersion;
  }
  
  public int getSDKInt() {
    return this.sdkInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AndroidBuildInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */