package com.amazon.device.ads;

class SystemTime {
  public long currentTimeMillis() {
    return System.currentTimeMillis();
  }
  
  public long nanoTime() {
    return System.nanoTime();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\SystemTime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */