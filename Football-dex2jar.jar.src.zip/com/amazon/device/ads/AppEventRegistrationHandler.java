package com.amazon.device.ads;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class AppEventRegistrationHandler {
  protected static final String APP_EVENTS_FILE = "AppEventsJsonFile";
  
  protected static final long APP_EVENTS_FILE_MAX_SIZE = 1048576L;
  
  protected static final String APP_EVENT_NAME_KEY = "evtName";
  
  protected static final String APP_EVENT_TIMESTAMP_KEY = "ts";
  
  protected static final String INSTALL_REFERRER_EVENT_NAME = "INSTALL_REFERRER";
  
  private static final String LOG_TAG = AppEventRegistrationHandler.class.getSimpleName();
  
  protected static AppEventRegistrationHandler instance = new AppEventRegistrationHandler(AmazonRegistration.getInstance(), new DefaultFileHandlerFactory());
  
  private final IAmazonRegistration amazonRegistration;
  
  protected final Object appEventsFileLock;
  
  protected final Set<String> eventsSent;
  
  private final FileHandlerFactory fileHandlerFactory;
  
  private FileInputHandler fileInputHandler;
  
  private FileOutputHandler fileOutputHandler;
  
  protected final Set<String> newEventsToSave;
  
  protected AppEventRegistrationHandler(IAmazonRegistration paramIAmazonRegistration, FileHandlerFactory paramFileHandlerFactory) {
    this.amazonRegistration = paramIAmazonRegistration;
    this.fileHandlerFactory = paramFileHandlerFactory;
    this.appEventsFileLock = new Object();
    this.newEventsToSave = Collections.synchronizedSet(new HashSet<String>());
    this.eventsSent = Collections.synchronizedSet(new HashSet<String>());
  }
  
  private boolean createFileInputHandlerIfNeeded() {
    if (this.fileInputHandler == null) {
      File file = this.amazonRegistration.getFilesDir();
      if (file == null) {
        Log.e(LOG_TAG, "No files directory has been set.", new Object[0]);
        return false;
      } 
      this.fileInputHandler = this.fileHandlerFactory.createFileInputHandler(file, "AppEventsJsonFile");
    } 
    return (this.fileInputHandler != null);
  }
  
  private boolean createFileOutputHandlerIfNeeded() {
    if (this.fileOutputHandler == null) {
      File file = this.amazonRegistration.getFilesDir();
      if (file == null) {
        Log.e(LOG_TAG, "No files directory has been set.", new Object[0]);
        return false;
      } 
      this.fileOutputHandler = this.fileHandlerFactory.createFileOutputHandler(file, "AppEventsJsonFile");
    } 
    return (this.fileOutputHandler != null);
  }
  
  public static AppEventRegistrationHandler getInstance() {
    return instance;
  }
  
  public void addEventToAppEventsCacheFile(final AppEvent appEvent) {
    ThreadUtils.executeRunnable(new Runnable() {
          public void run() {
            AppEventRegistrationHandler.this.appendAppEventToFile(appEvent);
            if (appEvent.getEventName().equals("INSTALL_REFERRER") && AppEventRegistrationHandler.this.amazonRegistration.getRegistrationInfo().isRegisteredWithSIS())
              AppEventRegistrationHandler.this.amazonRegistration.getSISRegistration().registerEvents(); 
          }
        });
  }
  
  protected void appendAppEventToFile(AppEvent paramAppEvent) {
    String str;
    if (!createFileOutputHandlerIfNeeded()) {
      Log.e(LOG_TAG, "Error creating file output handler.", new Object[0]);
      return;
    } 
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("evtName", paramAppEvent.getEventName());
      jSONObject.put("ts", paramAppEvent.getTimestamp());
      for (Map.Entry<String, String> entry : paramAppEvent.getPropertyEntries())
        jSONObject.put((String)entry.getKey(), entry.getValue()); 
    } catch (JSONException jSONException) {
      Log.w(LOG_TAG, "Internal error while persisting the application event %s.", new Object[] { paramAppEvent.toString() });
      return;
    } 
    this.newEventsToSave.add(jSONObject.toString());
    synchronized (this.appEventsFileLock) {
      str = jSONObject.toString() + "\n";
      if (this.fileOutputHandler.getFileLength() + str.length() > 1048576L) {
        Log.w(LOG_TAG, "Couldn't write the application event %s to the cache file. Maximum size limit reached.", new Object[] { paramAppEvent.toString() });
        return;
      } 
    } 
    boolean bool = this.fileOutputHandler.open(FileOutputHandler.WriteMethod.APPEND);
    if (bool)
      try {
        this.fileOutputHandler.write(str);
        Log.d(LOG_TAG, "Added the application event %s to the cache file.", new Object[] { paramAppEvent.toString() });
      } catch (IOException iOException) {} 
    this.fileOutputHandler.close();
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
  }
  
  public JSONArray getAppEventsJSONArray() {
    if (!createFileInputHandlerIfNeeded()) {
      Log.e(LOG_TAG, "Error creating file input handler.", new Object[0]);
      return null;
    } 
    synchronized (this.appEventsFileLock) {
      if (!this.fileInputHandler.doesFileExist())
        return null; 
      if (!this.fileInputHandler.open()) {
        Log.e(LOG_TAG, "App Events File could not be opened.", new Object[0]);
        return null;
      } 
      JSONArray jSONArray = new JSONArray();
      while (true) {
        String str = this.fileInputHandler.readLine();
        if (str != null) {
          JSONObject jSONObject = JSONUtils.getJSONObjectFromString(str);
          if (jSONObject == null) {
            onAppEventsRegistered();
            this.fileInputHandler.close();
            return null;
          } 
          jSONArray.put(jSONObject);
          this.eventsSent.add(jSONObject.toString());
          continue;
        } 
        this.fileInputHandler.close();
        if (jSONArray.length() > 0)
          return jSONArray; 
        return null;
      } 
    } 
  }
  
  public void onAppEventsRegistered() {
    if (!createFileOutputHandlerIfNeeded()) {
      Log.e(LOG_TAG, "Error creating file output handler.", new Object[0]);
      return;
    } 
    synchronized (this.appEventsFileLock) {
      this.newEventsToSave.removeAll(this.eventsSent);
      if (!this.newEventsToSave.isEmpty()) {
        null = new StringBuilder();
        synchronized (this.newEventsToSave) {
          Iterator<String> iterator = this.newEventsToSave.iterator();
          while (iterator.hasNext())
            null.append(iterator.next()).append("\n"); 
        } 
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
        boolean bool = this.fileOutputHandler.open(FileOutputHandler.WriteMethod.APPEND);
        if (bool)
          try {
            this.fileOutputHandler.write(SYNTHETIC_LOCAL_VARIABLE_4.toString());
            this.newEventsToSave.clear();
            this.eventsSent.clear();
          } catch (IOException iOException) {} 
      } else {
        this.amazonRegistration.getApplicationContext().deleteFile("AppEventsJsonFile");
        this.eventsSent.clear();
      } 
    } 
    this.fileOutputHandler.close();
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AppEventRegistrationHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */