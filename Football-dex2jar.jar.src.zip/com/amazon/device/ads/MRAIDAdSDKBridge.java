package com.amazon.device.ads;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.media.MediaScannerConnection;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

class MRAIDAdSDKBridge implements AdSDKBridge {
  private static final int CLOSE_BUTTON_SIZE = 50;
  
  private static final String CONTENT_DESCRIPTION_AD_CONTAINER_VIEW = "adContainerView";
  
  private static final String CONTENT_DESCRIPTION_DIMMING_VIEW = "dimmingView";
  
  private static final String CONTENT_DESCRIPTION_EXPANSION_VIEW = "expansionView";
  
  private static final String CONTENT_DESCRIPTION_RESIZED_VIEW = "resizedView";
  
  private static final String ERROR_EVENT_FORMAT = "mraidBridge.error('%s', '%s');";
  
  private static final String JAVASCRIPT;
  
  private static final String LOGTAG = MRAIDAdSDKBridge.class.getSimpleName();
  
  private static final String MRAID_BRIDGE_NAME = "mraidObject";
  
  private static final String PLACEMENT_TYPE_INLINE = "inline";
  
  private static final String PLACEMENT_TYPE_INTERSTITIAL = "interstitial";
  
  private ViewGroup adContainerView;
  
  private final AdControlAccessor adControlAccessor;
  
  private final Position defaultPosition = new Position();
  
  private final ExpandProperties expandProperties = new ExpandProperties();
  
  private boolean expandedWithUrl = true;
  
  private ViewGroup expansionView;
  
  private final JavascriptInteractor javascriptInteractor;
  
  private final OrientationProperties orientationProperties = new OrientationProperties();
  
  private ResizeProperties resizeProperties;
  
  private ViewGroup resizedView;
  
  private FrameLayout rootView;
  
  private SDKEventListener sdkEventListener;
  
  static {
    JAVASCRIPT = "(function (window, console) {\n    var is_array = function (obj) {\n        return Object.prototype.toString.call(obj) === '[object Array]';\n    },\n    forEach = function (array, fn) {\n        var i;\n        for (i = 0; i < array.length; i++) {\n            if (i in array) {\n                fn.call(null, array[i], i);\n            }\n        }\n    },\n    events = {\n            error: 'error',\n            ready: 'ready',\n            sizeChange: 'sizeChange',\n            stateChange: 'stateChange',\n            viewableChange: 'viewableChange'\n    },\n    states = [\"loading\",\"default\",\"expanded\",\"resized\",\"hidden\"],\n    placementTypes = [\"inline\", \"interstitial\"],\n    listeners = [],\n    version = '2.0',\n    currentState = \"loading\",\n    supportedFeatures = null,\n    orientationProperties = {\"allowOrientationChange\":true,\"forceOrientation\":\"none\"},\n    // Error Event fires listeners\n    invokeListeners = function(event, args) {\n        var eventListeners = listeners[event] || [];\n        // fire all the listeners\n        forEach(eventListeners, function(listener){\n            try {\n                listener.apply(null, args);\n            }catch(e){\n                debug(\"Error executing \" + event + \" listener\");\n                debug(e);\n            }\n        });\n    },\n    debug = function(msg) {\n        console.log(\"MRAID log: \" + msg);\n    },\n    readyEvent = function() {\n        debug(\"MRAID ready\");\n        invokeListeners(\"ready\");\n    },\n    errorEvent = function(message, action) {\n        debug(\"error: \" + message + \" action: \" + action);\n        var args = [message, action];\n        invokeListeners(\"error\", args);\n    },\n    stateChangeEvent = function(state) {\n        debug(\"stateChange: \" + state);\n        var args = [state];\n        currentState = state;\n        invokeListeners(\"stateChange\", args);\n    },\n    viewableChangeEvent = function(viewable) {\n        debug(\"viewableChange: \" + viewable);\n        var args = [viewable];\n        invokeListeners(\"viewableChange\", args);\n    }, \n    sizeChangeEvent = function(width, height) {\n        debug(\"sizeChange: \" + width + \"x\" + height);\n        var args = [width, height];\n        invokeListeners(\"sizeChange\", args);\n    };\n    window.mraidBridge = {\n            error : errorEvent,\n            ready : readyEvent,\n            stateChange : stateChangeEvent,\n            sizeChange : sizeChangeEvent,\n            viewableChange : viewableChangeEvent\n    };\n    // Define the mraid object\n    window.mraid = {\n            // Command Flow\n            addEventListener : function(event, listener){\n                var eventListeners = listeners[event] || [],\n                alreadyRegistered = false;\n                \n                //verify the event is one that will actually occur\n                if (!events.hasOwnProperty(event)){\n                    return;\n                }\n                \n                //register first set of listeners for this event\n                if (!is_array(listeners[event])) {\n                    listeners[event] = eventListeners;\n                }\n                \n                forEach(eventListeners, function(l){ \n                    // Listener already registered, so no need to add it.\n                        if (listener === l){\n                            alreadyRegistered = true;\n                        }\n                    }\n                );\n                if (!alreadyRegistered){\n                    listeners[event].push(listener);\n                }\n            },\n            removeEventListener : function(event, listener){\n                if (listeners.hasOwnProperty(event)) {\n                    var eventListeners = listeners[event];\n                    if (eventListeners) {\n                        var idx = eventListeners.indexOf(listener);\n                        if (idx !== -1) {\n                            eventListeners.splice(idx, 1);\n                        }\n                    }\n                }\n            },\n            useCustomClose: function(bool){\n                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"UseCustomClose\", JSON.stringify({useCustomClose: bool}));\n" + "            },\n" + "            // Support\n" + "            supports: function(feature){\n" + "                if (!supportedFeatures)\n" + "                {\n" + "                    supportedFeatures = JSON.parse(mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"Supports\", null));\n" + "                }\n" + "                return supportedFeatures[feature];\n" + "            },\n" + "            // Properties\n" + "            getVersion: function(){\n" + "                return version;\n" + "            },\n" + "            getState: function(){\n" + "                return currentState;\n" + "            },\n" + "            getPlacementType: function(){\n" + "                var json = JSON.parse(mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"GetPlacementType\", null));\n" + "                return json.placementType;\n" + "            },\n" + "            isViewable: function(){\n" + "                // TODO - should we ask the OS if the widget is visible.\n" + "                return currentState !== \"hidden\" && currentState !== \"loading\";\n" + "            },\n" + "            getExpandProperties: function(){\n" + "                return JSON.parse(mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"GetExpandProperties\", null));\n" + "            },\n" + "            setExpandProperties: function(properties){\n" + "                var currentProperties = mraid.getExpandProperties(),\n" + "                //properties aren't all required, map to existing value if not set.\n" + "                width = properties.hasOwnProperty('width') ? properties.width : currentProperties.width,\n" + "                height = properties.hasOwnProperty('height') ? properties.height : currentProperties.height,\n" + "                useClose = properties.hasOwnProperty('useCustomClose') ? properties.useCustomClose : currentProperties.useCustomClose;\n" + "                //Backwards compatibility with MRAID 1.0 creatives\n" + "                if (!!properties.lockOrientation){\n" + "                    mraid.setOrientationProperties({\"allowOrientationChange\":false});\n" + "                }\n" + "                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"SetExpandProperties\", JSON.stringify({\n" + "                        width: width, \n" + "                        height: height, \n" + "                        useClose: useClose}));\n" + "            },\n" + "            getOrientationProperties: function(){\n" + "                return orientationProperties;\n" + "            },\n" + "            setOrientationProperties: function(properties){\n" + "                if (properties.hasOwnProperty(\"allowOrientationChange\")) {\n" + "                    orientationProperties.allowOrientationChange = properties.allowOrientationChange;\n" + "                }\n" + "                if (properties.hasOwnProperty(\"forceOrientation\")) {\n" + "                    orientationProperties.forceOrientation = properties.forceOrientation;\n" + "                }\n" + "                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"SetOrientationProperties\", JSON.stringify({\n" + "                        allowOrientationChange: orientationProperties.allowOrientationChange, \n" + "                        forceOrientation: orientationProperties.forceOrientation}));\n" + "            },\n" + "            getResizeProperties: function(){\n" + "                return JSON.parse(mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"GetResizeProperties\", null));\n" + "            },\n" + "            setResizeProperties: function(properties){\n" + "                if (!properties.customClosePosition){\n" + "                   properties.customClosePosition = null;\n" + "                }\n" + "                if (!properties.hasOwnProperty('allowOffscreen')){\n" + "                   properties.allowOffscreen = true;\n" + "                }\n" + "                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"SetResizeProperties\", JSON.stringify({\n" + "                        width: properties.width, \n" + "                        height: properties.height, \n" + "                        offsetX: properties.offsetX, \n" + "                        offsetY: properties.offsetY, \n" + "                        customClosePosition: properties.customClosePosition, \n" + "                        allowOffscreen: properties.allowOffscreen}));\n" + "            },\n" + "            getCurrentPosition: function(){\n" + "                return JSON.parse(mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"GetCurrentPosition\", null));\n" + "            },\n" + "            getMaxSize: function(){\n" + "                return JSON.parse(mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"GetMaxSize\", null));\n" + "            },\n" + "            getDefaultPosition: function(){\n" + "                return JSON.parse(mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"GetDefaultPosition\", null));\n" + "            },\n" + "            getScreenSize: function(){\n" + "                return JSON.parse(mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"GetScreenSize\", null));\n" + "            },\n" + "            // Operations\n" + "            open: function(url) {\n" + "                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"Open\", JSON.stringify({url: url}));\n" + "            },\n" + "            close: function() {\n" + "                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"Close\", null);\n" + "            },\n" + "            expand: function(url) {\n" + "                if (url !== undefined) {\n" + "                    mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"Expand\", JSON.stringify({url: url}));\n" + "                } else {\n" + "                    mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"Expand\", JSON.stringify({url: \"\"}));\n" + "                }\n" + "            },\n" + "            resize: function() {\n" + "                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"Resize\", null);\n" + "            },\n" + "            createCalendarEvent: function(eventObject) {\n" + "                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"CreateCalendarEvent\", JSON.stringify({\n" + "                        description: eventObject.description || null, \n" + "                        location: eventObject.customClosePosition || null, \n" + "                        summary: eventObject.summary || null, \n" + "                        start: eventObject.start || null, \n" + "                        end: eventObject.end || null}));\n" + "            },\n" + "            playVideo: function(url){\n" + "                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"PlayVideo\", JSON.stringify({url: url}));\n" + "            },\n" + "            storePicture: function(url){\n" + "                mraidObject." + JavascriptInteractor.getExecutorMethodName() + "(\"StorePicture\", JSON.stringify({url: url}));\n" + "            }\n" + "    };\n" + "})(window, console);\n" + "";
  }
  
  MRAIDAdSDKBridge(AdControlAccessor paramAdControlAccessor, JavascriptInteractor paramJavascriptInteractor) {
    this.adControlAccessor = paramAdControlAccessor;
    this.javascriptInteractor = paramJavascriptInteractor;
    populateJavascriptExecutorsInInteractor();
  }
  
  private Size computeExpandedSizeInPixels(ExpandProperties paramExpandProperties, String paramString) {
    int i;
    Size size = this.adControlAccessor.getMaxSize();
    if (paramString != null && size != null) {
      i = size.getWidth();
    } else {
      i = paramExpandProperties.getWidth();
    } 
    if (paramString != null && size != null) {
      int k = size.getHeight();
      Log.d(LOGTAG, "Expanding Ad to " + i + "x" + k, new Object[0]);
      return new Size(AdUtils.deviceIndependentPixelToPixel(i), AdUtils.deviceIndependentPixelToPixel(k));
    } 
    int j = paramExpandProperties.getHeight();
    Log.d(LOGTAG, "Expanding Ad to " + i + "x" + j, new Object[0]);
    return new Size(AdUtils.deviceIndependentPixelToPixel(i), AdUtils.deviceIndependentPixelToPixel(j));
  }
  
  private Size computeResizeSizeInPixels(ResizeProperties paramResizeProperties) {
    int i = paramResizeProperties.getWidth();
    int j = paramResizeProperties.getHeight();
    return new Size(AdUtils.deviceIndependentPixelToPixel(i), AdUtils.deviceIndependentPixelToPixel(j));
  }
  
  @TargetApi(14)
  private void createCalendarIntent(CalendarEventParameters paramCalendarEventParameters) {
    Intent intent = (new Intent("android.intent.action.INSERT")).setType("vnd.android.cursor.item/event");
    intent.putExtra("title", paramCalendarEventParameters.getDescription());
    if (!StringUtils.isNullOrEmpty(paramCalendarEventParameters.getLocation()))
      intent.putExtra("eventLocation", paramCalendarEventParameters.getLocation()); 
    if (!StringUtils.isNullOrEmpty(paramCalendarEventParameters.getSummary()))
      intent.putExtra("description", paramCalendarEventParameters.getSummary()); 
    intent.putExtra("beginTime", paramCalendarEventParameters.getStart().getTime());
    if (paramCalendarEventParameters.getEnd() != null)
      intent.putExtra("endTime", paramCalendarEventParameters.getEnd().getTime()); 
    getContext().startActivity(intent);
  }
  
  private void createExpandedView() {
    this.rootView = (FrameLayout)((Activity)getContext()).findViewById(16908290);
    this.expansionView = (ViewGroup)new RelativeLayout(getContext());
    this.expansionView.setContentDescription("expansionView");
    View view = new View(getContext());
    view.setBackgroundColor(0);
    view.setContentDescription("dimmingView");
    view.setOnTouchListener(new View.OnTouchListener() {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            return true;
          }
        });
    this.expansionView.addView(view, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    this.adContainerView = (ViewGroup)new FrameLayout(getContext());
    this.adContainerView.setContentDescription("adContainerView");
  }
  
  private void createResizedView() {
    if (this.resizedView == null) {
      if (this.rootView == null)
        this.rootView = (FrameLayout)((Activity)getContext()).findViewById(16908290); 
      this.resizedView = (ViewGroup)new RelativeLayout(getContext());
      this.resizedView.setContentDescription("resizedView");
    } 
  }
  
  private void fetchPicture(String paramString) {
    WebRequest webRequest = WebRequest.createNewWebRequest();
    webRequest.enableLog(true);
    webRequest.setUrlString(paramString);
    try {
      WebRequest.WebResponse webResponse = webRequest.makeCall();
      if (webResponse == null) {
        fireErrorEvent("Server could not be contacted to download picture.", "storePicture");
        return;
      } 
    } catch (WebRequestException webRequestException) {
      fireErrorEvent("Server could not be contacted to download picture.", "storePicture");
      return;
    } 
    final Bitmap bitmap = (new ImageResponseReader(webRequestException.getResponseReader())).readAsBitmap();
    if (bitmap == null) {
      fireErrorEvent("Picture could not be retrieved from server.", "storePicture");
      return;
    } 
    ThreadUtils.scheduleOnMainThread(new Runnable() {
          public void run() {
            MRAIDAdSDKBridge.this.savePicture(bitmap);
          }
        });
  }
  
  private void fireErrorEvent(String paramString1, String paramString2) {
    this.adControlAccessor.injectJavascript(String.format(Locale.US, "mraidBridge.error('%s', '%s');", new Object[] { paramString1, paramString2 }));
  }
  
  private Context getContext() {
    return this.adControlAccessor.getContext();
  }
  
  private boolean isValidClosePosition(RelativePosition paramRelativePosition, int paramInt1, int paramInt2, Size paramSize, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: bipush #50
    //   2: invokestatic deviceIndependentPixelToPixel : (I)I
    //   5: istore #11
    //   7: iconst_0
    //   8: istore #8
    //   10: iconst_0
    //   11: istore #9
    //   13: iconst_0
    //   14: istore #10
    //   16: iconst_0
    //   17: istore #7
    //   19: getstatic com/amazon/device/ads/MRAIDAdSDKBridge$10.$SwitchMap$com$amazon$device$ads$RelativePosition : [I
    //   22: aload_1
    //   23: invokevirtual ordinal : ()I
    //   26: iaload
    //   27: tableswitch default -> 68, 1 -> 98, 2 -> 116, 3 -> 143, 4 -> 176, 5 -> 199, 6 -> 231, 7 -> 269
    //   68: iload #10
    //   70: istore_3
    //   71: iload #9
    //   73: istore_2
    //   74: iload #8
    //   76: iflt -> 96
    //   79: iload_3
    //   80: iflt -> 96
    //   83: iload_2
    //   84: iload #6
    //   86: if_icmpgt -> 96
    //   89: iload #7
    //   91: iload #5
    //   93: if_icmple -> 315
    //   96: iconst_0
    //   97: ireturn
    //   98: iload_2
    //   99: istore #8
    //   101: iload #8
    //   103: iload #11
    //   105: iadd
    //   106: istore_2
    //   107: iload_3
    //   108: iload #11
    //   110: iadd
    //   111: istore #7
    //   113: goto -> 74
    //   116: iload_2
    //   117: istore #8
    //   119: iload_3
    //   120: aload #4
    //   122: invokevirtual getWidth : ()I
    //   125: iadd
    //   126: istore #7
    //   128: iload #8
    //   130: iload #11
    //   132: iadd
    //   133: istore_2
    //   134: iload #7
    //   136: iload #11
    //   138: isub
    //   139: istore_3
    //   140: goto -> 74
    //   143: iload_2
    //   144: istore #8
    //   146: aload #4
    //   148: invokevirtual getWidth : ()I
    //   151: iconst_2
    //   152: idiv
    //   153: iload_3
    //   154: iadd
    //   155: iload #11
    //   157: iconst_2
    //   158: idiv
    //   159: isub
    //   160: istore_3
    //   161: iload #8
    //   163: iload #11
    //   165: iadd
    //   166: istore_2
    //   167: iload_3
    //   168: iload #11
    //   170: iadd
    //   171: istore #7
    //   173: goto -> 74
    //   176: iload_2
    //   177: aload #4
    //   179: invokevirtual getHeight : ()I
    //   182: iadd
    //   183: istore_2
    //   184: iload_2
    //   185: iload #11
    //   187: isub
    //   188: istore #8
    //   190: iload_3
    //   191: iload #11
    //   193: iadd
    //   194: istore #7
    //   196: goto -> 74
    //   199: iload_2
    //   200: aload #4
    //   202: invokevirtual getHeight : ()I
    //   205: iadd
    //   206: istore_2
    //   207: iload_3
    //   208: aload #4
    //   210: invokevirtual getWidth : ()I
    //   213: iadd
    //   214: istore #7
    //   216: iload_2
    //   217: iload #11
    //   219: isub
    //   220: istore #8
    //   222: iload #7
    //   224: iload #11
    //   226: isub
    //   227: istore_3
    //   228: goto -> 74
    //   231: iload_2
    //   232: aload #4
    //   234: invokevirtual getHeight : ()I
    //   237: iadd
    //   238: istore_2
    //   239: aload #4
    //   241: invokevirtual getWidth : ()I
    //   244: iconst_2
    //   245: idiv
    //   246: iload_3
    //   247: iadd
    //   248: iload #11
    //   250: iconst_2
    //   251: idiv
    //   252: isub
    //   253: istore_3
    //   254: iload_2
    //   255: iload #11
    //   257: isub
    //   258: istore #8
    //   260: iload_3
    //   261: iload #11
    //   263: iadd
    //   264: istore #7
    //   266: goto -> 74
    //   269: aload #4
    //   271: invokevirtual getHeight : ()I
    //   274: iconst_2
    //   275: idiv
    //   276: iload_2
    //   277: iadd
    //   278: iload #11
    //   280: iconst_2
    //   281: idiv
    //   282: isub
    //   283: istore #8
    //   285: aload #4
    //   287: invokevirtual getWidth : ()I
    //   290: iconst_2
    //   291: idiv
    //   292: iload_3
    //   293: iadd
    //   294: iload #11
    //   296: iconst_2
    //   297: idiv
    //   298: isub
    //   299: istore_3
    //   300: iload #8
    //   302: iload #11
    //   304: iadd
    //   305: istore_2
    //   306: iload_3
    //   307: iload #11
    //   309: iadd
    //   310: istore #7
    //   312: goto -> 74
    //   315: iconst_1
    //   316: ireturn
  }
  
  private boolean isVisible() {
    return this.adControlAccessor.isVisible();
  }
  
  private void lookupExpansionView() {
    if (this.expansionView == null) {
      ViewGroup viewGroup = this.adControlAccessor.getViewParentIfExpanded();
      if (viewGroup != null && "adContainerView".equals(viewGroup.getContentDescription())) {
        viewGroup = (ViewGroup)viewGroup.getParent();
        if (viewGroup != null && "expansionView".equals(viewGroup.getContentDescription()))
          this.expansionView = viewGroup; 
      } 
    } 
  }
  
  private void populateJavascriptExecutorsInInteractor() {
    this.javascriptInteractor.addMethodExecutor(new CloseJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new CreateCalendarEventJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new ExpandJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new GetCurrentPositionJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new GetDefaultPositionJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new GetExpandPropertiesJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new GetMaxSizeJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new GetPlacementTypeJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new GetResizePropertiesJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new GetScreenSizeJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new OpenJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new PlayVideoJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new ResizeJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new SetExpandPropertiesJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new SetOrientationPropertiesJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new SetResizePropertiesJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new StorePictureJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new SupportsJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new UseCustomCloseJSIF(this));
  }
  
  private void savePicture(final Bitmap bitmap) {
    AlertDialog.Builder builder = createAlertDialogBuilder(getContext());
    builder.setTitle("Would you like to save the image to your gallery?");
    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            String str = ImageUtils.insertImageInMediaStore(MRAIDAdSDKBridge.this.getContext(), bitmap, "AdImage", "Image created by rich media ad.");
            if (StringUtils.isNullOrEmpty(str)) {
              MRAIDAdSDKBridge.this.fireErrorEvent("Picture could not be stored to device.", "storePicture");
              return;
            } 
            MediaScannerConnection.scanFile(MRAIDAdSDKBridge.this.getContext(), new String[] { str }, null, null);
          }
        });
    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {}
        });
    builder.show();
  }
  
  private boolean validUrl(String paramString) {
    try {
      new URI(paramString);
      return true;
    } catch (URISyntaxException uRISyntaxException) {
      return false;
    } catch (NullPointerException nullPointerException) {
      return false;
    } 
  }
  
  public void close() {
    if (!this.adControlAccessor.closeAd())
      fireErrorEvent("Unable to close ad in its current state.", "close"); 
  }
  
  void collapseExpandedAd(final AdControlAccessor adControlAccessor) {
    Log.d(LOGTAG, "Collapsing expanded ad " + this, new Object[0]);
    ThreadUtils.executeOnMainThread(new Runnable() {
          public void run() {
            MRAIDAdSDKBridge.access$502(MRAIDAdSDKBridge.this, (FrameLayout)((Activity)MRAIDAdSDKBridge.this.getContext()).findViewById(16908290));
            if (MRAIDAdSDKBridge.this.expandedWithUrl) {
              Log.d(MRAIDAdSDKBridge.LOGTAG, "Expanded With URL", new Object[0]);
              adControlAccessor.popView();
            } else {
              Log.d(MRAIDAdSDKBridge.LOGTAG, "Not Expanded with URL", new Object[0]);
            } 
            MRAIDAdSDKBridge.this.lookupExpansionView();
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1, 17);
            adControlAccessor.moveViewBackToParent((ViewGroup.LayoutParams)layoutParams);
            adControlAccessor.removeCloseButton();
            if (MRAIDAdSDKBridge.this.expansionView != null)
              MRAIDAdSDKBridge.this.rootView.removeView((View)MRAIDAdSDKBridge.this.expansionView); 
            if (MRAIDAdSDKBridge.this.resizedView != null)
              MRAIDAdSDKBridge.this.rootView.removeView((View)MRAIDAdSDKBridge.this.resizedView); 
            MRAIDAdSDKBridge.this.rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                  private boolean triggered = false;
                  
                  public void onGlobalLayout() {
                    if (!this.triggered) {
                      this.triggered = true;
                      adControlAccessor.fireAdEvent(new AdEvent(AdEvent.AdEventType.CLOSED));
                      adControlAccessor.injectJavascript("mraidBridge.stateChange('default');");
                      MRAIDAdSDKBridge.this.reportSizeChangeEvent();
                    } 
                  }
                });
          }
        });
  }
  
  AlertDialog.Builder createAlertDialogBuilder(Context paramContext) {
    return new AlertDialog.Builder(paramContext);
  }
  
  public void createCalendarEvent(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    if (!AndroidTargetUtils.isAtLeastAndroidAPI(14)) {
      Log.d(LOGTAG, "API version does not support calendar operations.", new Object[0]);
      fireErrorEvent("API version does not support calendar operations.", "createCalendarEvent");
      return;
    } 
    try {
      CalendarEventParameters calendarEventParameters = new CalendarEventParameters(paramString1, paramString2, paramString3, paramString4, paramString5);
      createCalendarIntent(calendarEventParameters);
      return;
    } catch (IllegalArgumentException illegalArgumentException) {
      Log.d(LOGTAG, illegalArgumentException.getMessage(), new Object[0]);
      fireErrorEvent(illegalArgumentException.getMessage(), "createCalendarEvent");
      return;
    } 
  }
  
  public void expand(String paramString) {
    if (this.adControlAccessor.isInterstitial()) {
      fireErrorEvent("Unable to expand an interstitial ad placement", "expand");
      return;
    } 
    if (this.adControlAccessor.isModal()) {
      fireErrorEvent("Unable to expand while expanded.", "expand");
      return;
    } 
    if (!isVisible()) {
      fireErrorEvent("Unable to expand ad while it is not visible.", "expand");
      return;
    } 
    if (this.expandProperties.getWidth() < 50 || this.expandProperties.getHeight() < 50) {
      fireErrorEvent("Expand size is too small, must leave room for close.", "expand");
      return;
    } 
    final ExpandProperties expandProperties = this.expandProperties;
    if (!StringUtils.isNullOrWhiteSpace(paramString)) {
      if (validUrl(paramString)) {
        this.adControlAccessor.preloadUrl(paramString, new PreloadCallback() {
              public void onPreloadComplete(String param1String) {
                MRAIDAdSDKBridge.this.adControlAccessor.injectJavascriptPreload("mraidBridge.stateChange('expanded');");
                MRAIDAdSDKBridge.this.adControlAccessor.injectJavascriptPreload("mraidBridge.ready();");
                MRAIDAdSDKBridge.this.expandAd(expandProperties, param1String);
              }
            });
        return;
      } 
      fireErrorEvent("Unable to expand with invalid URL.", "expand");
      return;
    } 
    expandAd(expandProperties, null);
  }
  
  void expandAd(final ExpandProperties expandProperties, final String url) {
    ThreadUtils.executeOnMainThread(new Runnable() {
          public void run() {
            boolean bool = true;
            if (url != null) {
              MRAIDAdSDKBridge.this.adControlAccessor.stashView();
              MRAIDAdSDKBridge.access$602(MRAIDAdSDKBridge.this, true);
            } else {
              MRAIDAdSDKBridge.access$602(MRAIDAdSDKBridge.this, false);
            } 
            Size size = MRAIDAdSDKBridge.this.computeExpandedSizeInPixels(expandProperties, url);
            MRAIDAdSDKBridge.this.createExpandedView();
            MRAIDAdSDKBridge.this.adControlAccessor.moveViewToViewGroup(MRAIDAdSDKBridge.this.adContainerView, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1), true);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(size.getWidth(), size.getHeight());
            layoutParams.addRule(13);
            MRAIDAdSDKBridge.this.expansionView.addView((View)MRAIDAdSDKBridge.this.adContainerView, (ViewGroup.LayoutParams)layoutParams);
            MRAIDAdSDKBridge.this.rootView.addView((View)MRAIDAdSDKBridge.this.expansionView, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
            AdControlAccessor adControlAccessor = MRAIDAdSDKBridge.this.adControlAccessor;
            if (expandProperties.getUseCustomClose().booleanValue())
              bool = false; 
            adControlAccessor.enableCloseButton(bool);
            MRAIDAdSDKBridge.this.rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                  private boolean triggered = false;
                  
                  public void onGlobalLayout() {
                    if (!this.triggered) {
                      this.triggered = true;
                      Log.d(MRAIDAdSDKBridge.LOGTAG, "Expand ViewTreeObserver fired", new Object[0]);
                      MRAIDAdSDKBridge.this.adControlAccessor.fireAdEvent(new AdEvent(AdEvent.AdEventType.EXPANDED));
                      MRAIDAdSDKBridge.this.adControlAccessor.injectJavascript("mraidBridge.stateChange('expanded');");
                      MRAIDAdSDKBridge.this.reportSizeChangeEvent();
                      MRAIDAdSDKBridge.this.orientationPropertyChange();
                    } 
                  }
                });
          }
        });
  }
  
  public JSONObject getCurrentPosition() {
    if (this.adControlAccessor.getCurrentPosition() == null) {
      fireErrorEvent("Current position is unavailable because the ad has not yet been displayed.", "getCurrentPosition");
      return (new Position(new Size(0, 0), 0, 0)).toJSONObject();
    } 
    return this.adControlAccessor.getCurrentPosition().toJSONObject();
  }
  
  public JSONObject getDefaultPosition() {
    return this.defaultPosition.toJSONObject();
  }
  
  public JSONObject getExpandProperties() {
    return this.expandProperties.toJSONObject();
  }
  
  public String getJavascript() {
    return JAVASCRIPT;
  }
  
  public JavascriptInteractor.Executor getJavascriptInteractorExecutor() {
    return this.javascriptInteractor.getExecutor();
  }
  
  public JSONObject getMaxSize() {
    Size size = this.adControlAccessor.getMaxSize();
    return (size == null) ? (new Size(0, 0)).toJSONObject() : size.toJSONObject();
  }
  
  public String getName() {
    return "mraidObject";
  }
  
  public String getOrientationProperties() {
    return this.orientationProperties.toString();
  }
  
  public String getPlacementType() {
    return this.adControlAccessor.isInterstitial() ? "interstitial" : "inline";
  }
  
  public JSONObject getResizeProperties() {
    return this.resizeProperties.toJSONObject();
  }
  
  public SDKEventListener getSDKEventListener() {
    if (this.sdkEventListener == null)
      this.sdkEventListener = new MRAIDAdSDKEventListener(this); 
    return this.sdkEventListener;
  }
  
  public JSONObject getScreenSize() {
    Size size = this.adControlAccessor.getScreenSize();
    return (size == null) ? (new Size(0, 0)).toJSONObject() : size.toJSONObject();
  }
  
  public JSONObject getSupportedFeatures() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("sms", getContext().getPackageManager().hasSystemFeature("android.hardware.telephony"));
      jSONObject.put("tel", getContext().getPackageManager().hasSystemFeature("android.hardware.telephony"));
      jSONObject.put("calendar", AndroidTargetUtils.isAtLeastAndroidAPI(14));
      jSONObject.put("storePicture", PermissionChecker.hasWriteExternalStoragePermission(getContext()));
      jSONObject.put("inlineVideo", AndroidTargetUtils.isAtLeastAndroidAPI(11));
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
  
  public boolean hasNativeExecution() {
    return true;
  }
  
  public void open(String paramString) {
    if (!isVisible()) {
      fireErrorEvent("Unable to open a URL while the ad is not visible", "open");
      return;
    } 
    Log.d(LOGTAG, "Opening URL " + paramString, new Object[0]);
    if (validUrl(paramString)) {
      String str = WebUtils.getScheme(paramString);
      if ("http".equals(str) || "https".equals(str)) {
        (new InAppBrowser.InAppBrowserBuilder()).withContext(getContext()).withExternalBrowserButton().withUrl(paramString).show();
        return;
      } 
      this.adControlAccessor.loadUrl(paramString);
      return;
    } 
    paramString = "URL " + paramString + " is not a valid URL";
    Log.d(LOGTAG, paramString, new Object[0]);
    fireErrorEvent(paramString, "open");
  }
  
  void orientationPropertyChange() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial isVisible : ()Z
    //   4: ifeq -> 17
    //   7: aload_0
    //   8: getfield adControlAccessor : Lcom/amazon/device/ads/AdControlAccessor;
    //   11: invokevirtual isModal : ()Z
    //   14: ifne -> 18
    //   17: return
    //   18: aload_0
    //   19: invokespecial getContext : ()Landroid/content/Context;
    //   22: checkcast android/app/Activity
    //   25: astore #4
    //   27: aload #4
    //   29: invokevirtual getRequestedOrientation : ()I
    //   32: istore_1
    //   33: aload_0
    //   34: getfield adControlAccessor : Lcom/amazon/device/ads/AdControlAccessor;
    //   37: invokevirtual getCurrentPosition : ()Lcom/amazon/device/ads/Position;
    //   40: astore_3
    //   41: getstatic com/amazon/device/ads/MRAIDAdSDKBridge.LOGTAG : Ljava/lang/String;
    //   44: new java/lang/StringBuilder
    //   47: dup
    //   48: invokespecial <init> : ()V
    //   51: ldc_w 'Current Orientation: '
    //   54: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   57: iload_1
    //   58: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   61: invokevirtual toString : ()Ljava/lang/String;
    //   64: iconst_0
    //   65: anewarray java/lang/Object
    //   68: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   71: getstatic com/amazon/device/ads/AdState.EXPANDED : Lcom/amazon/device/ads/AdState;
    //   74: aload_0
    //   75: getfield adControlAccessor : Lcom/amazon/device/ads/AdControlAccessor;
    //   78: invokevirtual getAdState : ()Lcom/amazon/device/ads/AdState;
    //   81: invokevirtual equals : (Ljava/lang/Object;)Z
    //   84: ifne -> 124
    //   87: getstatic com/amazon/device/ads/MRAIDAdSDKBridge$10.$SwitchMap$com$amazon$device$ads$ForceOrientation : [I
    //   90: aload_0
    //   91: getfield orientationProperties : Lcom/amazon/device/ads/OrientationProperties;
    //   94: invokevirtual getForceOrientation : ()Lcom/amazon/device/ads/ForceOrientation;
    //   97: invokevirtual ordinal : ()I
    //   100: iaload
    //   101: tableswitch default -> 124, 1 -> 277, 2 -> 286
    //   124: getstatic com/amazon/device/ads/AdState.EXPANDED : Lcom/amazon/device/ads/AdState;
    //   127: aload_0
    //   128: getfield adControlAccessor : Lcom/amazon/device/ads/AdControlAccessor;
    //   131: invokevirtual getAdState : ()Lcom/amazon/device/ads/AdState;
    //   134: invokevirtual equals : (Ljava/lang/Object;)Z
    //   137: ifne -> 156
    //   140: getstatic com/amazon/device/ads/ForceOrientation.NONE : Lcom/amazon/device/ads/ForceOrientation;
    //   143: aload_0
    //   144: getfield orientationProperties : Lcom/amazon/device/ads/OrientationProperties;
    //   147: invokevirtual getForceOrientation : ()Lcom/amazon/device/ads/ForceOrientation;
    //   150: invokevirtual equals : (Ljava/lang/Object;)Z
    //   153: ifeq -> 200
    //   156: aload_0
    //   157: getfield orientationProperties : Lcom/amazon/device/ads/OrientationProperties;
    //   160: invokevirtual isAllowOrientationChange : ()Ljava/lang/Boolean;
    //   163: invokevirtual booleanValue : ()Z
    //   166: ifeq -> 295
    //   169: aload_0
    //   170: getfield adControlAccessor : Lcom/amazon/device/ads/AdControlAccessor;
    //   173: invokevirtual getContext : ()Landroid/content/Context;
    //   176: checkcast android/app/Activity
    //   179: invokevirtual getRequestedOrientation : ()I
    //   182: iconst_m1
    //   183: if_icmpeq -> 200
    //   186: aload_0
    //   187: getfield adControlAccessor : Lcom/amazon/device/ads/AdControlAccessor;
    //   190: invokevirtual getContext : ()Landroid/content/Context;
    //   193: checkcast android/app/Activity
    //   196: iconst_m1
    //   197: invokevirtual setRequestedOrientation : (I)V
    //   200: aload #4
    //   202: invokevirtual getRequestedOrientation : ()I
    //   205: istore_2
    //   206: getstatic com/amazon/device/ads/MRAIDAdSDKBridge.LOGTAG : Ljava/lang/String;
    //   209: new java/lang/StringBuilder
    //   212: dup
    //   213: invokespecial <init> : ()V
    //   216: ldc_w 'New Orientation: '
    //   219: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   222: iload_2
    //   223: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   226: invokevirtual toString : ()Ljava/lang/String;
    //   229: iconst_0
    //   230: anewarray java/lang/Object
    //   233: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   236: iload_2
    //   237: iload_1
    //   238: if_icmpeq -> 17
    //   241: aload_3
    //   242: ifnull -> 17
    //   245: aload_0
    //   246: getfield adControlAccessor : Lcom/amazon/device/ads/AdControlAccessor;
    //   249: invokevirtual getCurrentPosition : ()Lcom/amazon/device/ads/Position;
    //   252: astore #4
    //   254: aload_3
    //   255: invokevirtual getSize : ()Lcom/amazon/device/ads/Size;
    //   258: invokevirtual getWidth : ()I
    //   261: aload #4
    //   263: invokevirtual getSize : ()Lcom/amazon/device/ads/Size;
    //   266: invokevirtual getWidth : ()I
    //   269: if_icmpeq -> 17
    //   272: aload_0
    //   273: invokevirtual reportSizeChangeEvent : ()V
    //   276: return
    //   277: aload #4
    //   279: iconst_1
    //   280: invokevirtual setRequestedOrientation : (I)V
    //   283: goto -> 124
    //   286: aload #4
    //   288: iconst_0
    //   289: invokevirtual setRequestedOrientation : (I)V
    //   292: goto -> 124
    //   295: aload_0
    //   296: getfield adControlAccessor : Lcom/amazon/device/ads/AdControlAccessor;
    //   299: invokevirtual isModal : ()Z
    //   302: ifeq -> 200
    //   305: aload #4
    //   307: aload #4
    //   309: invokestatic determineCanonicalScreenOrientation : (Landroid/content/Context;)I
    //   312: invokevirtual setRequestedOrientation : (I)V
    //   315: goto -> 200
  }
  
  public void playVideo(String paramString) {
    if (!isVisible()) {
      fireErrorEvent("Unable to play a video while the ad is not visible", "playVideo");
      return;
    } 
    if (StringUtils.isNullOrEmpty(paramString)) {
      fireErrorEvent("Unable to play a video without a URL", "playVideo");
      return;
    } 
    try {
      Bundle bundle = new Bundle();
      bundle.putString("url", paramString);
      Intent intent = new Intent(getContext(), AdActivity.class);
      intent.putExtra("adapter", VideoActionHandler.class.getName());
      intent.putExtras(bundle);
      getContext().startActivity(intent);
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      Log.d(LOGTAG, "Failed to open VideoAction activity", new Object[0]);
      fireErrorEvent("Internal SDK Failure. Unable to launch VideoActionHandler", "playVideo");
      return;
    } 
  }
  
  void reportSizeChangeEvent() {
    Position position = this.adControlAccessor.getCurrentPosition();
    if (position != null)
      this.adControlAccessor.injectJavascript("mraidBridge.sizeChange(" + position.getSize().getWidth() + "," + position.getSize().getHeight() + ");"); 
  }
  
  public void resize() {
    if (this.adControlAccessor.isInterstitial()) {
      fireErrorEvent("Unable to resize an interstitial ad placement.", "resize");
      return;
    } 
    if (this.adControlAccessor.isModal()) {
      fireErrorEvent("Unable to resize while expanded.", "resize");
      return;
    } 
    if (!isVisible()) {
      fireErrorEvent("Unable to resize ad while it is not visible.", "resize");
      return;
    } 
    if (this.resizeProperties == null) {
      fireErrorEvent("Resize properties must be set before calling resize.", "resize");
      return;
    } 
    if (this.resizeProperties.getWidth() < 50 || this.resizeProperties.getHeight() < 50) {
      fireErrorEvent("Resize width and height must be at least 50 dp in order to fit the close button.", "resize");
      return;
    } 
    resizeAd(this.resizeProperties);
  }
  
  void resizeAd(final ResizeProperties resizeProperties) {
    ThreadUtils.executeOnMainThread(new Runnable() {
          public void run() {
            int i;
            int j;
            MRAIDAdSDKBridge.this.createResizedView();
            int k = AdUtils.deviceIndependentPixelToPixel(MRAIDAdSDKBridge.this.defaultPosition.getX() + resizeProperties.getOffsetX());
            int m = AdUtils.deviceIndependentPixelToPixel(MRAIDAdSDKBridge.this.defaultPosition.getY() + resizeProperties.getOffsetY());
            RelativePosition relativePosition = RelativePosition.fromString(resizeProperties.getCustomClosePosition());
            Size size = MRAIDAdSDKBridge.this.adControlAccessor.getMaxSize();
            int i1 = AdUtils.deviceIndependentPixelToPixel(size.getWidth());
            int n = AdUtils.deviceIndependentPixelToPixel(size.getHeight());
            if (!resizeProperties.getAllowOffscreen().booleanValue()) {
              int i2;
              if (resizeSize.getWidth() > i1)
                resizeSize.setWidth(i1); 
              if (resizeSize.getHeight() > n)
                resizeSize.setHeight(n); 
              if (k < 0) {
                i2 = 0;
              } else {
                i2 = k;
                if (resizeSize.getWidth() + k > i1)
                  i2 = i1 - resizeSize.getWidth(); 
              } 
              if (m < 0) {
                i = 0;
                j = i2;
              } else {
                i = m;
                j = i2;
                if (resizeSize.getHeight() + m > n) {
                  i = n - resizeSize.getHeight();
                  j = i2;
                } 
              } 
            } else {
              i = m;
              j = k;
              if (!MRAIDAdSDKBridge.this.isValidClosePosition(relativePosition, m, k, resizeSize, i1, n)) {
                MRAIDAdSDKBridge.this.fireErrorEvent("Resize failed because close event area must be entirely on screen.", "resize");
                return;
              } 
            } 
            RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(resizeSize.getWidth(), resizeSize.getHeight());
            MRAIDAdSDKBridge.this.adControlAccessor.moveViewToViewGroup(MRAIDAdSDKBridge.this.resizedView, (ViewGroup.LayoutParams)layoutParams1, false);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(resizeSize.getWidth(), resizeSize.getHeight());
            layoutParams.gravity = 48;
            layoutParams.leftMargin = j;
            layoutParams.topMargin = i;
            if (MRAIDAdSDKBridge.this.rootView.equals(MRAIDAdSDKBridge.this.resizedView.getParent())) {
              MRAIDAdSDKBridge.this.resizedView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            } else {
              MRAIDAdSDKBridge.this.rootView.addView((View)MRAIDAdSDKBridge.this.resizedView, (ViewGroup.LayoutParams)layoutParams);
            } 
            MRAIDAdSDKBridge.this.adControlAccessor.enableCloseButton(false, relativePosition);
            MRAIDAdSDKBridge.this.rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                  private boolean triggered = false;
                  
                  public void onGlobalLayout() {
                    if (!this.triggered) {
                      this.triggered = true;
                      int[] arrayOfInt = new int[2];
                      MRAIDAdSDKBridge.this.resizedView.getLocationOnScreen(arrayOfInt);
                      Rect rect = new Rect(arrayOfInt[0], arrayOfInt[1], arrayOfInt[0] + MRAIDAdSDKBridge.this.resizedView.getWidth(), arrayOfInt[1] + MRAIDAdSDKBridge.this.resizedView.getHeight());
                      AdEvent adEvent = new AdEvent(AdEvent.AdEventType.RESIZED);
                      adEvent.setParameter("positionOnScreen", rect);
                      MRAIDAdSDKBridge.this.adControlAccessor.fireAdEvent(adEvent);
                      MRAIDAdSDKBridge.this.adControlAccessor.injectJavascript("mraidBridge.stateChange('resized');");
                      MRAIDAdSDKBridge.this.reportSizeChangeEvent();
                    } 
                  }
                });
          }
        });
  }
  
  public void setExpandProperties(int paramInt1, int paramInt2, boolean paramBoolean) {
    this.expandProperties.setWidth(paramInt1);
    this.expandProperties.setHeight(paramInt2);
    setUseCustomClose(paramBoolean);
  }
  
  public void setOrientationProperties(boolean paramBoolean, String paramString) {
    if (this.adControlAccessor.isInterstitial() && !this.adControlAccessor.isModal())
      this.adControlAccessor.orientationChangeAttemptedWhenNotAllowed(); 
    this.orientationProperties.setAllowOrientationChange(Boolean.valueOf(paramBoolean));
    if (!StringUtils.isNullOrEmpty(paramString))
      try {
        ForceOrientation forceOrientation = ForceOrientation.valueOf(paramString.toUpperCase(Locale.US));
        this.orientationProperties.setForceOrientation(forceOrientation);
      } catch (IllegalArgumentException illegalArgumentException) {
        Log.w(LOGTAG, "Not a valid orientation to force:" + paramString, new Object[0]);
      }  
    orientationPropertyChange();
  }
  
  public void setResizeProperties(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString, boolean paramBoolean) {
    if (this.resizeProperties == null)
      this.resizeProperties = new ResizeProperties(); 
    this.resizeProperties.setAllowOffscreen(Boolean.valueOf(paramBoolean));
    this.resizeProperties.setCustomClosePosition(paramString);
    this.resizeProperties.setWidth(paramInt1);
    this.resizeProperties.setHeight(paramInt2);
    this.resizeProperties.setOffsetX(paramInt3);
    this.resizeProperties.setOffsetY(paramInt4);
  }
  
  public void setUseCustomClose(boolean paramBoolean) {
    this.expandProperties.setUseCustomClose(Boolean.valueOf(paramBoolean));
    AdControlAccessor adControlAccessor = this.adControlAccessor;
    if (!paramBoolean) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    adControlAccessor.showNativeCloseButtonImage(paramBoolean);
  }
  
  public void storePicture(final String url) {
    if (!PermissionChecker.hasWriteExternalStoragePermission(getContext())) {
      fireErrorEvent("Picture could not be stored because permission was denied.", "storePicture");
      return;
    } 
    ThreadUtils.executeRunnableWithThreadCheck(new Runnable() {
          public void run() {
            MRAIDAdSDKBridge.this.fetchPicture(url);
          }
        });
  }
  
  void updateDefaultPosition(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.defaultPosition.setSize(new Size(paramInt1, paramInt2));
    this.defaultPosition.setX(paramInt3);
    this.defaultPosition.setY(paramInt4);
  }
  
  void updateExpandProperties(int paramInt1, int paramInt2) {
    this.expandProperties.setWidth(paramInt1);
    this.expandProperties.setHeight(paramInt2);
  }
  
  private static class CloseJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "Close";
    
    private final MRAIDAdSDKBridge bridge;
    
    public CloseJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("Close");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.close();
      return null;
    }
  }
  
  private static class CreateCalendarEventJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "CreateCalendarEvent";
    
    private final MRAIDAdSDKBridge bridge;
    
    public CreateCalendarEventJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("CreateCalendarEvent");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.createCalendarEvent(JSONUtils.getStringFromJSON(param1JSONObject, "description", null), JSONUtils.getStringFromJSON(param1JSONObject, "location", null), JSONUtils.getStringFromJSON(param1JSONObject, "summary", null), JSONUtils.getStringFromJSON(param1JSONObject, "start", null), JSONUtils.getStringFromJSON(param1JSONObject, "end", null));
      return null;
    }
  }
  
  private static class ExpandJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "Expand";
    
    private final MRAIDAdSDKBridge bridge;
    
    public ExpandJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("Expand");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.expand(JSONUtils.getStringFromJSON(param1JSONObject, "url", null));
      return null;
    }
  }
  
  private static class GetCurrentPositionJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "GetCurrentPosition";
    
    private final MRAIDAdSDKBridge bridge;
    
    public GetCurrentPositionJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("GetCurrentPosition");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      return this.bridge.getCurrentPosition();
    }
  }
  
  private static class GetDefaultPositionJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "GetDefaultPosition";
    
    private final MRAIDAdSDKBridge bridge;
    
    public GetDefaultPositionJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("GetDefaultPosition");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      return this.bridge.getDefaultPosition();
    }
  }
  
  private static class GetExpandPropertiesJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "GetExpandProperties";
    
    private final MRAIDAdSDKBridge bridge;
    
    public GetExpandPropertiesJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("GetExpandProperties");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      return this.bridge.getExpandProperties();
    }
  }
  
  private static class GetMaxSizeJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "GetMaxSize";
    
    private final MRAIDAdSDKBridge bridge;
    
    public GetMaxSizeJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("GetMaxSize");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      return this.bridge.getMaxSize();
    }
  }
  
  private static class GetPlacementTypeJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "GetPlacementType";
    
    private final MRAIDAdSDKBridge bridge;
    
    public GetPlacementTypeJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("GetPlacementType");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      param1JSONObject = new JSONObject();
      JSONUtils.put(param1JSONObject, "placementType", this.bridge.getPlacementType());
      return param1JSONObject;
    }
  }
  
  private static class GetResizePropertiesJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "GetResizeProperties";
    
    private final MRAIDAdSDKBridge bridge;
    
    public GetResizePropertiesJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("GetResizeProperties");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      return this.bridge.getResizeProperties();
    }
  }
  
  private static class GetScreenSizeJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "GetScreenSize";
    
    private final MRAIDAdSDKBridge bridge;
    
    public GetScreenSizeJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("GetScreenSize");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      return this.bridge.getScreenSize();
    }
  }
  
  private static class OpenJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "Open";
    
    private final MRAIDAdSDKBridge bridge;
    
    public OpenJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("Open");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.open(JSONUtils.getStringFromJSON(param1JSONObject, "url", null));
      return null;
    }
  }
  
  private static class PlayVideoJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "PlayVideo";
    
    private final MRAIDAdSDKBridge bridge;
    
    public PlayVideoJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("PlayVideo");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.playVideo(JSONUtils.getStringFromJSON(param1JSONObject, "url", null));
      return null;
    }
  }
  
  private static class ResizeJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "Resize";
    
    private final MRAIDAdSDKBridge bridge;
    
    public ResizeJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("Resize");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.resize();
      return null;
    }
  }
  
  private static class SetExpandPropertiesJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "SetExpandProperties";
    
    private final MRAIDAdSDKBridge bridge;
    
    public SetExpandPropertiesJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("SetExpandProperties");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.setExpandProperties(JSONUtils.getIntegerFromJSON(param1JSONObject, "width", 0), JSONUtils.getIntegerFromJSON(param1JSONObject, "height", 0), JSONUtils.getBooleanFromJSON(param1JSONObject, "useCustomClose", false));
      return null;
    }
  }
  
  private static class SetOrientationPropertiesJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "SetOrientationProperties";
    
    private final MRAIDAdSDKBridge bridge;
    
    public SetOrientationPropertiesJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("SetOrientationProperties");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.setOrientationProperties(JSONUtils.getBooleanFromJSON(param1JSONObject, "allowOrientationChange", false), JSONUtils.getStringFromJSON(param1JSONObject, "forceOrientation", null));
      return null;
    }
  }
  
  private static class SetResizePropertiesJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "SetResizeProperties";
    
    private final MRAIDAdSDKBridge bridge;
    
    public SetResizePropertiesJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("SetResizeProperties");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.setResizeProperties(JSONUtils.getIntegerFromJSON(param1JSONObject, "width", 0), JSONUtils.getIntegerFromJSON(param1JSONObject, "height", 0), JSONUtils.getIntegerFromJSON(param1JSONObject, "offsetX", 0), JSONUtils.getIntegerFromJSON(param1JSONObject, "offsetY", 0), JSONUtils.getStringFromJSON(param1JSONObject, "customClosePosition", null), JSONUtils.getBooleanFromJSON(param1JSONObject, "allowOffscreen", false));
      return null;
    }
  }
  
  private static class StorePictureJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "StorePicture";
    
    private final MRAIDAdSDKBridge bridge;
    
    public StorePictureJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("StorePicture");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.storePicture(JSONUtils.getStringFromJSON(param1JSONObject, "url", null));
      return null;
    }
  }
  
  private static class SupportsJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "Supports";
    
    private final MRAIDAdSDKBridge bridge;
    
    public SupportsJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("Supports");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      return this.bridge.getSupportedFeatures();
    }
  }
  
  private static class UseCustomCloseJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "UseCustomClose";
    
    private final MRAIDAdSDKBridge bridge;
    
    public UseCustomCloseJSIF(MRAIDAdSDKBridge param1MRAIDAdSDKBridge) {
      super("UseCustomClose");
      this.bridge = param1MRAIDAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.setUseCustomClose(JSONUtils.getBooleanFromJSON(param1JSONObject, "useCustomClose", false));
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\MRAIDAdSDKBridge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */