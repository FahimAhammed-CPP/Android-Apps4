package com.amazon.device.ads;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class JSONUtils {
  public static boolean getBooleanFromJSON(JSONObject paramJSONObject, String paramString, boolean paramBoolean) {
    return paramJSONObject.isNull(paramString) ? paramBoolean : paramJSONObject.optBoolean(paramString, paramBoolean);
  }
  
  public static int getIntegerFromJSON(JSONObject paramJSONObject, String paramString, int paramInt) {
    return paramJSONObject.isNull(paramString) ? paramInt : paramJSONObject.optInt(paramString, paramInt);
  }
  
  public static int getIntegerFromJSONArray(JSONArray paramJSONArray, int paramInt1, int paramInt2) {
    return paramJSONArray.isNull(paramInt1) ? paramInt2 : paramJSONArray.optInt(paramInt1, paramInt2);
  }
  
  public static JSONArray getJSONArrayFromJSON(JSONObject paramJSONObject, String paramString) {
    return paramJSONObject.isNull(paramString) ? null : paramJSONObject.optJSONArray(paramString);
  }
  
  public static JSONObject getJSONObjectFromJSONArray(JSONArray paramJSONArray, int paramInt) {
    if (paramJSONArray.isNull(paramInt))
      return null; 
    try {
      return paramJSONArray.getJSONObject(paramInt);
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  public static JSONObject getJSONObjectFromString(String paramString) {
    try {
      return new JSONObject(paramString);
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  public static long getLongFromJSON(JSONObject paramJSONObject, String paramString, long paramLong) {
    return paramJSONObject.isNull(paramString) ? paramLong : paramJSONObject.optLong(paramString, paramLong);
  }
  
  public static String getStringFromJSON(JSONObject paramJSONObject, String paramString1, String paramString2) {
    return paramJSONObject.isNull(paramString1) ? paramString2 : paramJSONObject.optString(paramString1, paramString2);
  }
  
  public static void put(JSONObject paramJSONObject, String paramString, int paramInt) {
    try {
      paramJSONObject.put(paramString, paramInt);
      return;
    } catch (JSONException jSONException) {
      return;
    } 
  }
  
  public static void put(JSONObject paramJSONObject, String paramString, long paramLong) {
    try {
      paramJSONObject.put(paramString, paramLong);
      return;
    } catch (JSONException jSONException) {
      return;
    } 
  }
  
  public static void put(JSONObject paramJSONObject, String paramString1, String paramString2) {
    if (paramString2 != null && !paramString2.equals(""))
      try {
        paramJSONObject.put(paramString1, paramString2);
        return;
      } catch (JSONException jSONException) {
        return;
      }  
  }
  
  public static void put(JSONObject paramJSONObject, String paramString, boolean paramBoolean) {
    try {
      paramJSONObject.put(paramString, paramBoolean);
      return;
    } catch (JSONException jSONException) {
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\JSONUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */