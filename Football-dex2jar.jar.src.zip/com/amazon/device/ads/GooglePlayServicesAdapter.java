package com.amazon.device.ads;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import java.io.IOException;

class GooglePlayServicesAdapter {
  private static final String LOG_TAG = GooglePlayServicesAdapter.class.getSimpleName();
  
  public GooglePlayServices.AdvertisingInfo getAdvertisingIdentifierInfo() {
    Context context = AmazonRegistration.getInstance().getApplicationContext();
    try {
      AdvertisingIdClient.Info info = AdvertisingIdClient.getAdvertisingIdInfo(context);
      Log.v(LOG_TAG, "The Google Play Services Advertising Identifier was successfully retrieved.", new Object[0]);
      String str = info.getId();
      boolean bool = info.isLimitAdTrackingEnabled();
      return (new GooglePlayServices.AdvertisingInfo()).setAdvertisingIdentifier(str).setLimitAdTrackingEnabled(bool);
    } catch (IllegalStateException illegalStateException) {
      Log.e(LOG_TAG, "The Google Play Services Advertising Id API was called from a non-background thread.", new Object[0]);
      return new GooglePlayServices.AdvertisingInfo();
    } catch (IOException iOException) {
      Log.e(LOG_TAG, "Retrieving the Google Play Services Advertising Identifier caused an IOException.", new Object[0]);
      return new GooglePlayServices.AdvertisingInfo();
    } catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
      Log.v(LOG_TAG, "Retrieving the Google Play Services Advertising Identifier caused a GooglePlayServicesNotAvailableException.", new Object[0]);
      return GooglePlayServices.AdvertisingInfo.createNotAvailable();
    } catch (GooglePlayServicesRepairableException googlePlayServicesRepairableException) {
      Log.v(LOG_TAG, "Retrieving the Google Play Services Advertising Identifier caused a GooglePlayServicesRepairableException.", new Object[0]);
      return new GooglePlayServices.AdvertisingInfo();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\GooglePlayServicesAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */