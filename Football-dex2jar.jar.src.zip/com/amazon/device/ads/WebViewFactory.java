package com.amazon.device.ads;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewDatabase;

class WebViewFactory {
  private static WebViewFactory instance = new WebViewFactory();
  
  private static boolean isWebViewCheckedAndOk = false;
  
  private boolean cookieSyncManagerCreated = false;
  
  protected WebViewFactory() {
    shouldDebugWebViews();
  }
  
  protected static boolean doesExceptionContainLockedDatabaseMessage(Exception paramException) {
    return (paramException == null || paramException.getMessage() == null) ? false : paramException.getMessage().contains("database is locked");
  }
  
  public static final WebViewFactory getInstance() {
    return instance;
  }
  
  protected static boolean isDatabaseLocked(SQLiteException paramSQLiteException) {
    return AndroidTargetUtils.isAtLeastAndroidAPI(11) ? AndroidTargetUtils.isInstanceOfSQLiteDatabaseLockedException(paramSQLiteException) : doesExceptionContainLockedDatabaseMessage((Exception)paramSQLiteException);
  }
  
  public static boolean isWebViewOk(Context paramContext) {
    boolean bool = false;
    if (AndroidTargetUtils.isAtOrBelowAndroidAPI(8) && !isWebViewCheckedAndOk) {
      if (WebViewDatabase.getInstance(paramContext) != null)
        try {
          SQLiteDatabase sQLiteDatabase = paramContext.openOrCreateDatabase("webviewCache.db", 0, null);
          if (sQLiteDatabase != null)
            sQLiteDatabase.close(); 
          return true;
        } catch (SQLiteException sQLiteException) {
          bool = isDatabaseLocked(sQLiteException);
          return bool;
        } finally {
          if (false)
            throw new NullPointerException(); 
        }  
      return bool;
    } 
    return true;
  }
  
  @SuppressLint({"SetJavaScriptEnabled"})
  public static final boolean setJavaScriptEnabledForWebView(boolean paramBoolean, WebView paramWebView, String paramString) {
    try {
      paramWebView.getSettings().setJavaScriptEnabled(paramBoolean);
      return true;
    } catch (NullPointerException nullPointerException) {
      Log.w(paramString, "Could not set JavaScriptEnabled because a NullPointerException was encountered.", new Object[0]);
      return false;
    } 
  }
  
  private void shouldDebugWebViews() {
    if (DebugProperties.getInstance().getDebugPropertyAsBoolean("debug.webViews", false))
      AndroidTargetUtils.enableWebViewDebugging(true); 
  }
  
  private void updateAdIdCookie() {
    if (this.cookieSyncManagerCreated) {
      String str2 = AmazonRegistration.getInstance().getRegistrationInfo().getAdId();
      String str1 = str2;
      if (str2 == null)
        str1 = ""; 
      setCookie("http://amazon-adsystem.com", "ad-id=" + str1 + "; Domain=.amazon-adsystem.com");
    } 
  }
  
  public WebView createWebView(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new android/webkit/WebView
    //   5: dup
    //   6: aload_1
    //   7: invokespecial <init> : (Landroid/content/Context;)V
    //   10: astore_2
    //   11: invokestatic getInstance : ()Lcom/amazon/device/ads/IAmazonRegistration;
    //   14: invokeinterface getDeviceInfo : ()Lcom/amazon/device/ads/DeviceInfo;
    //   19: aload_2
    //   20: invokevirtual getSettings : ()Landroid/webkit/WebSettings;
    //   23: invokevirtual getUserAgentString : ()Ljava/lang/String;
    //   26: invokevirtual setUserAgentString : (Ljava/lang/String;)V
    //   29: aload_2
    //   30: invokevirtual getSettings : ()Landroid/webkit/WebSettings;
    //   33: invokestatic getInstance : ()Lcom/amazon/device/ads/IAmazonRegistration;
    //   36: invokeinterface getDeviceInfo : ()Lcom/amazon/device/ads/DeviceInfo;
    //   41: invokevirtual getUserAgentString : ()Ljava/lang/String;
    //   44: invokevirtual setUserAgentString : (Ljava/lang/String;)V
    //   47: aload_0
    //   48: getfield cookieSyncManagerCreated : Z
    //   51: ifne -> 64
    //   54: aload_1
    //   55: invokestatic createInstance : (Landroid/content/Context;)Landroid/webkit/CookieSyncManager;
    //   58: pop
    //   59: aload_0
    //   60: iconst_1
    //   61: putfield cookieSyncManagerCreated : Z
    //   64: aload_0
    //   65: invokespecial updateAdIdCookie : ()V
    //   68: aload_0
    //   69: monitorexit
    //   70: aload_2
    //   71: areturn
    //   72: astore_1
    //   73: aload_0
    //   74: monitorexit
    //   75: aload_1
    //   76: athrow
    // Exception table:
    //   from	to	target	type
    //   2	64	72	finally
    //   64	68	72	finally
  }
  
  protected void setCookie(String paramString1, String paramString2) {
    CookieManager.getInstance().setCookie(paramString1, paramString2);
  }
  
  public static class WebViewFactory2 {
    public WebView createWebView(Context param1Context) {
      return WebViewFactory.instance.createWebView(param1Context);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\WebViewFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */