package com.amazon.device.ads;

class AdEvent {
  public static final String POSITION_ON_SCREEN = "positionOnScreen";
  
  private final AdEventType adEventType;
  
  private String customType;
  
  private final ParameterMap parameters = new ParameterMap();
  
  public AdEvent(AdEventType paramAdEventType) {
    this.adEventType = paramAdEventType;
  }
  
  public AdEventType getAdEventType() {
    return this.adEventType;
  }
  
  public String getCustomType() {
    return this.customType;
  }
  
  public ParameterMap getParameters() {
    return this.parameters;
  }
  
  public void setCustomType(String paramString) {
    this.customType = paramString;
  }
  
  public AdEvent setParameter(String paramString, Object paramObject) {
    this.parameters.setParameter(paramString, paramObject);
    return this;
  }
  
  public enum AdEventType {
    CLICKED, CLOSED, EXPANDED, OTHER, RESIZED;
    
    static {
      CLICKED = new AdEventType("CLICKED", 2);
      RESIZED = new AdEventType("RESIZED", 3);
      OTHER = new AdEventType("OTHER", 4);
      $VALUES = new AdEventType[] { EXPANDED, CLOSED, CLICKED, RESIZED, OTHER };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */