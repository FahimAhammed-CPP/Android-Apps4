package com.amazon.device.ads;

class Version {
  private static String buildVersion = "5.5.102";
  
  private static String devBuild;
  
  private static String prefixVersion = "amznAdSDK-android-";
  
  private static String sdkVersion = null;
  
  private static String userAgentPrefixVersion = "AmazonAdSDK-Android/";
  
  private static String userAgentSDKVersion = null;
  
  static {
    devBuild = "(DEV)";
  }
  
  public static String getRawSDKVersion() {
    String str2 = buildVersion;
    if (str2 == null || str2.equals(""))
      return devBuild; 
    String str1 = str2;
    return str2.endsWith("x") ? (str2 + devBuild) : str1;
  }
  
  public static String getSDKVersion() {
    if (sdkVersion == null)
      sdkVersion = prefixVersion + getRawSDKVersion(); 
    return sdkVersion;
  }
  
  public static String getUserAgentSDKVersion() {
    if (userAgentSDKVersion == null)
      userAgentSDKVersion = userAgentPrefixVersion + getRawSDKVersion(); 
    return userAgentSDKVersion;
  }
  
  protected static void setSDKVersion(String paramString) {
    sdkVersion = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Version.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */