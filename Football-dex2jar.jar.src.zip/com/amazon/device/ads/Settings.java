package com.amazon.device.ads;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.ReentrantLock;

class Settings {
  private static final String LOG_TAG = Settings.class.getSimpleName();
  
  private static final String PREFS_NAME = "AmazonMobileAds";
  
  public static final String SETTING_ENABLE_WEBVIEW_PAUSE_LOGIC = "shouldPauseWebViewTimersInWebViewRelatedActivities";
  
  protected static final String SETTING_TESTING_ENABLED = "testingEnabled";
  
  protected static final String SETTING_TLS_ENABLED = "tlsEnabled";
  
  private static Settings instance = new Settings();
  
  private final ConcurrentHashMap<String, Value> cache = new ConcurrentHashMap<String, Value>();
  
  private ArrayList<SettingsListener> listeners = new ArrayList<SettingsListener>();
  
  private final ReentrantLock listenersLock = new ReentrantLock();
  
  private final CountDownLatch settingsLoadedLatch = new CountDownLatch(1);
  
  private SharedPreferences sharedPreferences;
  
  private final ReentrantLock writeToSharedPreferencesLock = new ReentrantLock();
  
  private void commit(SharedPreferences.Editor paramEditor) {
    if (ThreadUtils.isOnMainThread())
      Log.e(LOG_TAG, "Committing settings must be executed on a background thread.", new Object[0]); 
    if (AndroidTargetUtils.isAtLeastAndroidAPI(9)) {
      AndroidTargetUtils.editorApply(paramEditor);
      return;
    } 
    paramEditor.commit();
  }
  
  public static Settings getInstance() {
    return instance;
  }
  
  private void putSetting(String paramString, Value paramValue) {
    if (paramValue.value == null) {
      Log.w(LOG_TAG, "Could not set null value for setting: %s", new Object[] { paramString });
      return;
    } 
    putSettingWithNoFlush(paramString, paramValue);
    if (!paramValue.isTransientData && isSettingsLoaded()) {
      flush();
      return;
    } 
  }
  
  private void putSettingWithNoFlush(String paramString, Value paramValue) {
    if (paramValue.value == null) {
      Log.w(LOG_TAG, "Could not set null value for setting: %s", new Object[] { paramString });
      return;
    } 
    this.cache.put(paramString, paramValue);
  }
  
  private void writeCacheToSharedPreferences() {
    writeCacheToSharedPreferences(this.sharedPreferences);
  }
  
  void beginFetch(final Context context) {
    ThreadUtils.executeRunnable(new Runnable() {
          public void run() {
            Settings.this.fetchSharedPreferences(context);
          }
        });
  }
  
  void cacheAdditionalEntries(Map<String, ?> paramMap) {
    for (Map.Entry<String, ?> entry : paramMap.entrySet()) {
      String str = (String)entry.getKey();
      if (str != null && !this.cache.containsKey(str)) {
        entry = (Map.Entry<String, ?>)entry.getValue();
        if (entry != null) {
          this.cache.put(str, new Value(entry.getClass(), entry));
          continue;
        } 
        Log.w(LOG_TAG, "Could not cache null value for SharedPreferences setting: %s", new Object[] { str });
      } 
    } 
  }
  
  public boolean containsKey(String paramString) {
    return this.cache.containsKey(paramString);
  }
  
  void contextReceived(Context paramContext) {
    if (paramContext == null)
      return; 
    beginFetch(paramContext);
  }
  
  void fetchSharedPreferences(Context paramContext) {
    if (!isSettingsLoaded()) {
      SharedPreferences sharedPreferences = getSharedPreferencesFromContext(paramContext);
      readSharedPreferencesIntoCache(sharedPreferences);
      this.sharedPreferences = sharedPreferences;
      writeCacheToSharedPreferences(sharedPreferences);
    } 
    this.settingsLoadedLatch.countDown();
    notifySettingsListeners();
  }
  
  void flush() {
    writeCacheToSharedPreferences();
  }
  
  public Boolean getBoolean(String paramString, Boolean paramBoolean) {
    Value value = this.cache.get(paramString);
    return (value == null) ? paramBoolean : (Boolean)value.value;
  }
  
  public boolean getBoolean(String paramString, boolean paramBoolean) {
    Boolean bool = getBoolean(paramString, (Boolean)null);
    return (bool == null) ? paramBoolean : bool.booleanValue();
  }
  
  ConcurrentHashMap<String, Value> getCache() {
    return this.cache;
  }
  
  public int getInt(String paramString, int paramInt) {
    Value value = this.cache.get(paramString);
    return (value == null) ? paramInt : ((Integer)value.value).intValue();
  }
  
  public long getLong(String paramString, long paramLong) {
    Value value = this.cache.get(paramString);
    return (value == null) ? paramLong : ((Long)value.value).longValue();
  }
  
  SharedPreferences getSharedPreferences() {
    return this.sharedPreferences;
  }
  
  SharedPreferences getSharedPreferencesFromContext(Context paramContext) {
    return paramContext.getSharedPreferences("AmazonMobileAds", 0);
  }
  
  public String getString(String paramString1, String paramString2) {
    Value value = this.cache.get(paramString1);
    return (value == null) ? paramString2 : (String)value.value;
  }
  
  public boolean getWrittenBoolean(String paramString, boolean paramBoolean) {
    boolean bool = paramBoolean;
    if (isSettingsLoaded())
      bool = this.sharedPreferences.getBoolean(paramString, paramBoolean); 
    return bool;
  }
  
  public int getWrittenInt(String paramString, int paramInt) {
    int i = paramInt;
    if (isSettingsLoaded())
      i = this.sharedPreferences.getInt(paramString, paramInt); 
    return i;
  }
  
  public long getWrittenLong(String paramString, long paramLong) {
    long l = paramLong;
    if (isSettingsLoaded())
      l = this.sharedPreferences.getLong(paramString, paramLong); 
    return l;
  }
  
  public String getWrittenString(String paramString1, String paramString2) {
    String str = paramString2;
    if (isSettingsLoaded())
      str = this.sharedPreferences.getString(paramString1, paramString2); 
    return str;
  }
  
  public boolean isSettingsLoaded() {
    return (this.sharedPreferences != null);
  }
  
  public void listenForSettings(SettingsListener paramSettingsListener) {
    this.listenersLock.lock();
    if (isSettingsLoaded()) {
      paramSettingsListener.settingsLoaded();
    } else {
      this.listeners.add(paramSettingsListener);
    } 
    this.listenersLock.unlock();
  }
  
  void notifySettingsListeners() {
    this.listenersLock.lock();
    Iterator<SettingsListener> iterator = this.listeners.iterator();
    while (iterator.hasNext())
      ((SettingsListener)iterator.next()).settingsLoaded(); 
    this.listeners.clear();
    this.listeners = null;
    this.listenersLock.unlock();
  }
  
  void putBoolean(String paramString, boolean paramBoolean) {
    putSetting(paramString, new Value(Boolean.class, Boolean.valueOf(paramBoolean)));
  }
  
  void putBooleanWithNoFlush(String paramString, boolean paramBoolean) {
    putSettingWithNoFlush(paramString, new Value(Boolean.class, Boolean.valueOf(paramBoolean)));
  }
  
  void putInt(String paramString, int paramInt) {
    putSetting(paramString, new Value(Integer.class, Integer.valueOf(paramInt)));
  }
  
  void putIntWithNoFlush(String paramString, int paramInt) {
    putSettingWithNoFlush(paramString, new Value(Integer.class, Integer.valueOf(paramInt)));
  }
  
  void putLong(String paramString, long paramLong) {
    putSetting(paramString, new Value(Long.class, Long.valueOf(paramLong)));
  }
  
  void putLongWithNoFlush(String paramString, long paramLong) {
    putSettingWithNoFlush(paramString, new Value(Long.class, Long.valueOf(paramLong)));
  }
  
  void putString(String paramString1, String paramString2) {
    putSetting(paramString1, new Value(String.class, paramString2));
  }
  
  void putStringWithNoFlush(String paramString1, String paramString2) {
    putSettingWithNoFlush(paramString1, new Value(String.class, paramString2));
  }
  
  void putTransientBoolean(String paramString, boolean paramBoolean) {
    putSettingWithNoFlush(paramString, new TransientValue(Boolean.class, Boolean.valueOf(paramBoolean)));
  }
  
  void putTransientInt(String paramString, int paramInt) {
    putSettingWithNoFlush(paramString, new TransientValue(Integer.class, Integer.valueOf(paramInt)));
  }
  
  void putTransientLong(String paramString, long paramLong) {
    putSettingWithNoFlush(paramString, new TransientValue(Long.class, Long.valueOf(paramLong)));
  }
  
  void putTransientString(String paramString1, String paramString2) {
    putSettingWithNoFlush(paramString1, new TransientValue(String.class, paramString2));
  }
  
  void readSharedPreferencesIntoCache(SharedPreferences paramSharedPreferences) {
    cacheAdditionalEntries(paramSharedPreferences.getAll());
  }
  
  void remove(String paramString) {
    Value value = this.cache.remove(paramString);
    if (value != null && !value.isTransientData && isSettingsLoaded())
      flush(); 
  }
  
  void removeWithNoFlush(String paramString) {
    this.cache.remove(paramString);
  }
  
  void writeCacheToSharedPreferences(final SharedPreferences sharedPreferences) {
    ThreadUtils.executeRunnable(new Runnable() {
          public void run() {
            Settings.this.writeToSharedPreferencesLock.lock();
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            for (Map.Entry entry : Settings.this.cache.entrySet()) {
              Settings.Value value = (Settings.Value)entry.getValue();
              if (!value.isTransientData) {
                if (value.clazz == String.class) {
                  editor.putString((String)entry.getKey(), (String)value.value);
                  continue;
                } 
                if (value.clazz == Long.class) {
                  editor.putLong((String)entry.getKey(), ((Long)value.value).longValue());
                  continue;
                } 
                if (value.clazz == Integer.class) {
                  editor.putInt((String)entry.getKey(), ((Integer)value.value).intValue());
                  continue;
                } 
                if (value.clazz == Boolean.class)
                  editor.putBoolean((String)entry.getKey(), ((Boolean)value.value).booleanValue()); 
              } 
            } 
            Settings.this.commit(editor);
            Settings.this.writeToSharedPreferencesLock.unlock();
          }
        });
  }
  
  public static interface SettingsListener {
    void settingsLoaded();
  }
  
  class TransientValue extends Value {
    public TransientValue(Class<?> param1Class, Object param1Object) {
      super(param1Class, param1Object);
    }
  }
  
  class Value {
    public Class<?> clazz;
    
    public boolean isTransientData;
    
    public Object value;
    
    public Value(Class<?> param1Class, Object param1Object) {
      this.clazz = param1Class;
      this.value = param1Object;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Settings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */