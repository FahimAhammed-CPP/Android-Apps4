package com.amazon.device.ads;

import android.content.Context;

class PermissionChecker {
  private static PermissionCheckerExecutor executor = new PermissionCheckerExecutor();
  
  public static final boolean hasInternetPermission(Context paramContext) {
    return hasPermission(paramContext, "android.permission.INTERNET");
  }
  
  public static final boolean hasPermission(Context paramContext, String paramString) {
    return executor.hasPermission(paramContext, paramString);
  }
  
  public static final boolean hasPhonePermission(Context paramContext) {
    return hasPermission(paramContext, "android.permission.CALL_PHONE");
  }
  
  public static final boolean hasReadCalendarPermission(Context paramContext) {
    return hasPermission(paramContext, "android.permission.READ_CALENDAR");
  }
  
  public static final boolean hasSmsPermission(Context paramContext) {
    return hasPermission(paramContext, "android.permission.SEND_SMS");
  }
  
  public static final boolean hasWriteCalendarPermission(Context paramContext) {
    return hasPermission(paramContext, "android.permission.WRITE_CALENDAR");
  }
  
  public static final boolean hasWriteExternalStoragePermission(Context paramContext) {
    return hasPermission(paramContext, "android.permission.WRITE_EXTERNAL_STORAGE");
  }
  
  public static class PermissionCheckerExecutor {
    public boolean hasPermission(Context param1Context, String param1String) {
      return (param1Context.checkCallingOrSelfPermission(param1String) == 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\PermissionChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */