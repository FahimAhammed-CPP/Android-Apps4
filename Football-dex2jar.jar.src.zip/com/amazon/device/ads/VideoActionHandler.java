package com.amazon.device.ads;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

class VideoActionHandler implements AdActivity.IAdActivityAdapter {
  private Activity activity;
  
  private RelativeLayout layout;
  
  private AdVideoPlayer player;
  
  private void initPlayer(Bundle paramBundle) {
    this.player = new AdVideoPlayer((Context)this.activity);
    this.player.setPlayData(paramBundle.getString("url"));
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
    layoutParams.addRule(13);
    this.player.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.player.setViewGroup((ViewGroup)this.layout);
    setPlayerListener(this.player);
  }
  
  private void setPlayerListener(AdVideoPlayer paramAdVideoPlayer) {
    paramAdVideoPlayer.setListener(new AdVideoPlayer.AdVideoPlayerListener() {
          public void onComplete() {
            VideoActionHandler.this.activity.finish();
          }
          
          public void onError() {
            VideoActionHandler.this.activity.finish();
          }
        });
  }
  
  public boolean onBackPressed() {
    return false;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {}
  
  public void onCreate() {
    Bundle bundle = this.activity.getIntent().getExtras();
    this.layout = new RelativeLayout((Context)this.activity);
    this.layout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
    this.activity.setContentView((View)this.layout);
    initPlayer(bundle);
    this.player.playVideo();
  }
  
  public void onPause() {}
  
  public void onResume() {}
  
  public void onStop() {
    this.player.releasePlayer();
    this.player = null;
    this.activity.finish();
  }
  
  public void preOnCreate() {
    this.activity.requestWindowFeature(1);
  }
  
  public void setActivity(Activity paramActivity) {
    this.activity = paramActivity;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\VideoActionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */