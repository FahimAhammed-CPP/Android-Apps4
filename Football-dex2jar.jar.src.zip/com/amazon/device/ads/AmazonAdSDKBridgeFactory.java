package com.amazon.device.ads;

public class AmazonAdSDKBridgeFactory implements AdSDKBridgeFactory {
  public AdSDKBridge createAdSDKBridge(AdControlAccessor paramAdControlAccessor) {
    return new AmazonAdSDKBridge(paramAdControlAccessor, new JavascriptInteractor());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AmazonAdSDKBridgeFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */