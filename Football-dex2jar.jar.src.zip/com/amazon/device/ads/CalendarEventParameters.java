package com.amazon.device.ads;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

class CalendarEventParameters {
  public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mmZZZZZ";
  
  public static final List<String> DATE_FORMATS = Collections.unmodifiableList(new ArrayList<String>() {
      
      });
  
  private String description;
  
  private Date end;
  
  private String location;
  
  private Date start;
  
  private String summary;
  
  public CalendarEventParameters(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    if (StringUtils.isNullOrEmpty(paramString1))
      throw new IllegalArgumentException("No description for event"); 
    this.description = paramString1;
    this.location = paramString2;
    this.summary = paramString3;
    if (StringUtils.isNullOrEmpty(paramString4))
      throw new IllegalArgumentException("No start date for event"); 
    this.start = convertToDate(paramString4);
    if (StringUtils.isNullOrEmpty(paramString5)) {
      this.end = null;
      return;
    } 
    this.end = convertToDate(paramString5);
  }
  
  private Date convertToDate(String paramString) {
    String str = null;
    Iterator<String> iterator = DATE_FORMATS.iterator();
    while (true) {
      String str1 = str;
      if (iterator.hasNext()) {
        str1 = iterator.next();
        try {
          Date date = (new SimpleDateFormat(str1, Locale.US)).parse(paramString);
          if (date == null)
            throw new IllegalArgumentException("Could not parse datetime string " + paramString); 
        } catch (ParseException parseException) {
          continue;
        } 
        return (Date)parseException;
      } 
      if (parseException == null)
        throw new IllegalArgumentException("Could not parse datetime string " + paramString); 
    } 
  }
  
  public String getDescription() {
    return this.description;
  }
  
  public Date getEnd() {
    return this.end;
  }
  
  public String getLocation() {
    return this.location;
  }
  
  public Date getStart() {
    return this.start;
  }
  
  public String getSummary() {
    return this.summary;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\CalendarEventParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */