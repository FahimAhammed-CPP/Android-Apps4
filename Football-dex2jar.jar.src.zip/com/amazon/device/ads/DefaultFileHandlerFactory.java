package com.amazon.device.ads;

import java.io.File;

class DefaultFileHandlerFactory implements FileHandlerFactory {
  public FileInputHandler createFileInputHandler(File paramFile) {
    FileInputHandler fileInputHandler = new FileInputHandler();
    fileInputHandler.setFile(paramFile);
    return fileInputHandler;
  }
  
  public FileInputHandler createFileInputHandler(File paramFile, String paramString) {
    FileInputHandler fileInputHandler = new FileInputHandler();
    fileInputHandler.setFile(paramFile, paramString);
    return fileInputHandler;
  }
  
  public FileInputHandler createFileInputHandler(String paramString) {
    FileInputHandler fileInputHandler = new FileInputHandler();
    fileInputHandler.setFile(paramString);
    return fileInputHandler;
  }
  
  public FileOutputHandler createFileOutputHandler(File paramFile) {
    FileOutputHandler fileOutputHandler = new FileOutputHandler();
    fileOutputHandler.setFile(paramFile);
    return fileOutputHandler;
  }
  
  public FileOutputHandler createFileOutputHandler(File paramFile, String paramString) {
    FileOutputHandler fileOutputHandler = new FileOutputHandler();
    fileOutputHandler.setFile(paramFile, paramString);
    return fileOutputHandler;
  }
  
  public FileOutputHandler createFileOutputHandler(String paramString) {
    FileOutputHandler fileOutputHandler = new FileOutputHandler();
    fileOutputHandler.setFile(paramString);
    return fileOutputHandler;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\DefaultFileHandlerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */