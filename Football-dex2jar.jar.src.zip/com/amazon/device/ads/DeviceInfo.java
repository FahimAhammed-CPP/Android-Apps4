package com.amazon.device.ads;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.util.Locale;
import java.util.regex.Pattern;
import org.json.JSONObject;

class DeviceInfo {
  private static final String LOG_TAG = DeviceInfo.class.getSimpleName();
  
  public static final String ORIENTATION_LANDSCAPE = "landscape";
  
  public static final String ORIENTATION_PORTRAIT = "portrait";
  
  public static final String ORIENTATION_UNKNOWN = "unknown";
  
  private static final String dt = "android";
  
  private static final String os = "Android";
  
  private boolean bad_mac;
  
  private boolean bad_serial;
  
  private boolean bad_udid;
  
  private String carrier;
  
  private String country;
  
  private Size landscapeScreenSize;
  
  private String language;
  
  private boolean macFetched;
  
  private String make = Build.MANUFACTURER;
  
  private String md5_mac;
  
  private String md5_serial;
  
  private String md5_udid;
  
  private String model = Build.MODEL;
  
  private String osVersion = Build.VERSION.RELEASE;
  
  private Size portraitScreenSize;
  
  private float scalingFactor;
  
  private String scalingFactorAsString;
  
  private boolean serialFetched;
  
  private String sha1_mac;
  
  private String sha1_serial;
  
  private String sha1_udid;
  
  private String udid;
  
  private boolean udidFetched;
  
  private UserAgentManager userAgentManager;
  
  protected DeviceInfo() {}
  
  public DeviceInfo(Context paramContext, UserAgentManager paramUserAgentManager) {
    setCountry();
    setCarrier(paramContext);
    setLanguage();
    setScalingFactor(paramContext);
    this.userAgentManager = paramUserAgentManager;
  }
  
  public static String getDeviceType() {
    return "android";
  }
  
  public static String getOS() {
    return "Android";
  }
  
  private void setCarrier(Context paramContext) {
    TelephonyManager telephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
    if (telephonyManager != null) {
      String str = telephonyManager.getNetworkOperatorName();
      if (str == null || str.length() <= 0)
        str = null; 
      this.carrier = str;
    } 
  }
  
  private void setCountry() {
    String str = Locale.getDefault().getCountry();
    if (str == null || str.length() <= 0)
      str = null; 
    this.country = str;
  }
  
  private void setLanguage() {
    String str = Locale.getDefault().getLanguage();
    if (str == null || str.length() <= 0)
      str = null; 
    this.language = str;
  }
  
  private void setMacAddressIfNotFetched() {
    if (!this.macFetched)
      setMacAddress(); 
  }
  
  private void setScalingFactor(Context paramContext) {
    if (this.make.equals("motorola") && this.model.equals("MB502")) {
      this.scalingFactor = 1.0F;
    } else {
      WindowManager windowManager = (WindowManager)paramContext.getSystemService("window");
      DisplayMetrics displayMetrics = new DisplayMetrics();
      windowManager.getDefaultDisplay().getMetrics(displayMetrics);
      this.scalingFactor = displayMetrics.scaledDensity;
    } 
    this.scalingFactorAsString = Float.toString(this.scalingFactor);
  }
  
  private void setSerial() {
    String str = null;
    try {
      String str1 = (String)Build.class.getDeclaredField("SERIAL").get(Build.class);
      str = str1;
    } catch (Exception exception) {}
    if (str == null || str.length() == 0 || str.equalsIgnoreCase("unknown")) {
      this.bad_serial = true;
    } else {
      this.sha1_serial = WebUtils.getURLEncodedString(StringUtils.sha1(str));
    } 
    this.serialFetched = true;
  }
  
  private void setSerialIfNotFetched() {
    if (!this.serialFetched)
      setSerial(); 
  }
  
  private void setUdid() {
    String str = Settings.Secure.getString(AmazonRegistration.getInstance().getApplicationContext().getContentResolver(), "android_id");
    if (StringUtils.isNullOrEmpty(str) || str.equalsIgnoreCase("9774d56d682e549c")) {
      this.udid = null;
      this.sha1_udid = null;
      this.bad_udid = true;
    } else {
      this.udid = WebUtils.getURLEncodedString(str);
      this.sha1_udid = WebUtils.getURLEncodedString(StringUtils.sha1(str));
    } 
    this.udidFetched = true;
  }
  
  private void setUdidIfNotFetched() {
    if (!this.udidFetched)
      setUdid(); 
  }
  
  public String getCarrier() {
    return this.carrier;
  }
  
  public String getCountry() {
    return this.country;
  }
  
  public JSONObject getDInfoProperty() {
    JSONObject jSONObject = new JSONObject();
    JSONUtils.put(jSONObject, "make", getMake());
    JSONUtils.put(jSONObject, "model", getModel());
    JSONUtils.put(jSONObject, "os", getOS());
    JSONUtils.put(jSONObject, "osVersion", getOSVersion());
    JSONUtils.put(jSONObject, "scalingFactor", getScalingFactorAsString());
    JSONUtils.put(jSONObject, "language", getLanguage());
    JSONUtils.put(jSONObject, "country", getCountry());
    JSONUtils.put(jSONObject, "carrier", getCarrier());
    return jSONObject;
  }
  
  public String getLanguage() {
    return this.language;
  }
  
  public String getMacMd5() {
    setMacAddressIfNotFetched();
    return this.md5_mac;
  }
  
  public String getMacSha1() {
    setMacAddressIfNotFetched();
    return this.sha1_mac;
  }
  
  public String getMake() {
    return this.make;
  }
  
  public String getModel() {
    return this.model;
  }
  
  public String getOSVersion() {
    return this.osVersion;
  }
  
  public String getOrientation() {
    switch (DisplayUtils.determineCanonicalScreenOrientation(AmazonRegistration.getInstance().getApplicationContext())) {
      default:
        return "unknown";
      case 1:
      case 9:
        return "portrait";
      case 0:
      case 8:
        break;
    } 
    return "landscape";
  }
  
  public float getScalingFactorAsFloat() {
    return this.scalingFactor;
  }
  
  public String getScalingFactorAsString() {
    return this.scalingFactorAsString;
  }
  
  public Size getScreenSize(String paramString) {
    if (paramString.equals("portrait") && this.portraitScreenSize != null)
      return this.portraitScreenSize; 
    if (paramString.equals("landscape") && this.landscapeScreenSize != null)
      return this.landscapeScreenSize; 
    WindowManager windowManager = (WindowManager)AmazonRegistration.getInstance().getApplicationContext().getSystemService("window");
    DisplayMetrics displayMetrics = new DisplayMetrics();
    windowManager.getDefaultDisplay().getMetrics(displayMetrics);
    String str = String.valueOf(displayMetrics.widthPixels) + "x" + String.valueOf(displayMetrics.heightPixels);
    if (paramString.equals("portrait")) {
      this.portraitScreenSize = new Size(str);
      return this.portraitScreenSize;
    } 
    if (paramString.equals("landscape")) {
      this.landscapeScreenSize = new Size(str);
      return this.landscapeScreenSize;
    } 
    return new Size(str);
  }
  
  public String getSerialMd5() {
    setSerialIfNotFetched();
    return this.md5_serial;
  }
  
  public String getSerialSha1() {
    setSerialIfNotFetched();
    return this.sha1_serial;
  }
  
  public String getUdid() {
    setUdidIfNotFetched();
    return this.udid;
  }
  
  public String getUdidMd5() {
    setUdidIfNotFetched();
    return this.md5_udid;
  }
  
  public String getUdidSha1() {
    setUdidIfNotFetched();
    return this.sha1_udid;
  }
  
  public String getUserAgentString() {
    return this.userAgentManager.getUserAgentString();
  }
  
  public boolean isMacBad() {
    setMacAddressIfNotFetched();
    return this.bad_mac;
  }
  
  public boolean isSerialBad() {
    setSerialIfNotFetched();
    return this.bad_serial;
  }
  
  public boolean isUdidBad() {
    setUdidIfNotFetched();
    return this.bad_udid;
  }
  
  public void populateUserAgentString(Context paramContext) {
    this.userAgentManager.populateUserAgentString(paramContext);
  }
  
  protected void setMacAddress() {
    WifiManager wifiManager = (WifiManager)AmazonRegistration.getInstance().getApplicationContext().getSystemService("wifi");
    WifiInfo wifiInfo2 = null;
    WifiInfo wifiInfo1 = wifiInfo2;
    if (wifiManager != null)
      try {
        wifiInfo1 = wifiManager.getConnectionInfo();
      } catch (SecurityException securityException) {
        Log.d(LOG_TAG, "Unable to get Wifi connection information: %s", new Object[] { securityException });
        WifiInfo wifiInfo = wifiInfo2;
      } catch (ExceptionInInitializerError exceptionInInitializerError) {
        Log.d(LOG_TAG, "Unable to get Wifi connection information: %s", new Object[] { exceptionInInitializerError });
        wifiInfo1 = wifiInfo2;
      }  
    if (wifiInfo1 == null) {
      this.sha1_mac = null;
    } else {
      String str = wifiInfo1.getMacAddress();
      if (str == null || str.length() == 0) {
        this.sha1_mac = null;
        this.bad_mac = true;
      } else if (!Pattern.compile("((([0-9a-fA-F]){1,2}[-:]){5}([0-9a-fA-F]){1,2})").matcher(str).find()) {
        this.sha1_mac = null;
        this.bad_mac = true;
      } else {
        this.sha1_mac = WebUtils.getURLEncodedString(StringUtils.sha1(str));
      } 
    } 
    this.macFetched = true;
  }
  
  public void setUserAgentManager(UserAgentManager paramUserAgentManager) {
    this.userAgentManager = paramUserAgentManager;
  }
  
  public void setUserAgentString(String paramString) {
    this.userAgentManager.setUserAgentString(paramString);
  }
  
  JSONObject toJsonObject(String paramString) {
    JSONObject jSONObject = getDInfoProperty();
    JSONUtils.put(jSONObject, "orientation", paramString);
    JSONUtils.put(jSONObject, "screenSize", getScreenSize(paramString).toString());
    JSONUtils.put(jSONObject, "connectionType", (new ConnectionInfo()).getConnectionType());
    return jSONObject;
  }
  
  public String toJsonString() {
    return toJsonObject(getOrientation()).toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\DeviceInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */