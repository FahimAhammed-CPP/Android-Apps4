package com.amazon.device.ads;

import android.content.Context;

class AdControllerFactory {
  private static AdController cachedAdController = null;
  
  public static void cacheAdController(AdController paramAdController) {
    cachedAdController = paramAdController;
  }
  
  public static AdController getCachedAdController() {
    return cachedAdController;
  }
  
  public static AdController removeCachedAdController() {
    AdController adController = cachedAdController;
    cachedAdController = null;
    return adController;
  }
  
  public AdController buildAdController(Context paramContext, AdSize paramAdSize) {
    try {
      return new AdController(paramContext, paramAdSize);
    } catch (IllegalStateException illegalStateException) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdControllerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */