package com.amazon.device.ads;

import java.util.HashMap;
import org.json.JSONObject;

interface SISRequest {
  Metrics.MetricType getCallMetricType();
  
  String getLogTag();
  
  String getPath();
  
  HashMap<String, String> getPostParameters();
  
  WebRequest.QueryStringParameters getQueryParameters();
  
  void onResponseReceived(JSONObject paramJSONObject);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\SISRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */