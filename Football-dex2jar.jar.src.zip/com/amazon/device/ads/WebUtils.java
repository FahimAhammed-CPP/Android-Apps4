package com.amazon.device.ads;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Locale;

class WebUtils {
  private static final String LOGTAG = WebUtils.class.getSimpleName();
  
  public static final String encloseHtml(String paramString, boolean paramBoolean) {
    String str = paramString;
    if (paramString != null) {
      String str1 = paramString;
      if (paramString.indexOf("<html>") == -1)
        str1 = "<html>" + paramString + "</html>"; 
      str = str1;
      if (paramBoolean) {
        str = str1;
        if (str1.indexOf("<!DOCTYPE html>") == -1)
          str = "<!DOCTYPE html>" + str1; 
      } 
    } 
    return str;
  }
  
  public static final void executeWebRequestInThread(final String url, final boolean disconnectEnabled) {
    ThreadUtils.executeRunnable(new Runnable() {
          public void run() {
            WebRequest webRequest = WebRequest.createNewWebRequest();
            webRequest.enableLog(true);
            webRequest.setUrlString(url);
            webRequest.setDisconnectEnabled(disconnectEnabled);
            try {
              webRequest.makeCall();
              return;
            } catch (WebRequestException webRequestException) {
              return;
            } 
          }
        });
  }
  
  public static final String getScheme(String paramString) {
    String str = Uri.parse(paramString).getScheme();
    paramString = str;
    if (str != null)
      paramString = str.toLowerCase(Locale.US); 
    return paramString;
  }
  
  public static final String getURLDecodedString(String paramString) {
    if (paramString == null)
      return null; 
    try {
      return URLDecoder.decode(paramString, "UTF-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      Log.d(LOGTAG, "getURLDecodedString threw: %s", unsupportedEncodingException);
      return paramString;
    } 
  }
  
  public static final String getURLEncodedString(String paramString) {
    if (paramString == null)
      return null; 
    try {
      return URLEncoder.encode(paramString, "UTF-8").replace("+", "%20").replace("*", "%2A").replace("%7E", "~");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      Log.d(LOGTAG, "getURLEncodedString threw: %s", unsupportedEncodingException);
      return paramString;
    } 
  }
  
  public static boolean launchActivityForIntentLink(String paramString, Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 15
    //   4: aload_0
    //   5: astore_2
    //   6: aload_0
    //   7: ldc ''
    //   9: invokevirtual equals : (Ljava/lang/Object;)Z
    //   12: ifeq -> 18
    //   15: ldc 'about:blank'
    //   17: astore_2
    //   18: getstatic com/amazon/device/ads/WebUtils.LOGTAG : Ljava/lang/String;
    //   21: new java/lang/StringBuilder
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: ldc 'Launch Intent: '
    //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   33: aload_2
    //   34: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: invokevirtual toString : ()Ljava/lang/String;
    //   40: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   43: pop
    //   44: new android/content/Intent
    //   47: dup
    //   48: invokespecial <init> : ()V
    //   51: astore_0
    //   52: aload_2
    //   53: ldc 'intent:'
    //   55: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   58: ifeq -> 91
    //   61: aload_2
    //   62: iconst_1
    //   63: invokestatic parseUri : (Ljava/lang/String;I)Landroid/content/Intent;
    //   66: astore_0
    //   67: aload_0
    //   68: ldc 'android.intent.action.VIEW'
    //   70: invokevirtual setAction : (Ljava/lang/String;)Landroid/content/Intent;
    //   73: pop
    //   74: aload_0
    //   75: ldc 268435456
    //   77: invokevirtual setFlags : (I)Landroid/content/Intent;
    //   80: pop
    //   81: aload_1
    //   82: aload_0
    //   83: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   86: iconst_1
    //   87: ireturn
    //   88: astore_0
    //   89: iconst_0
    //   90: ireturn
    //   91: aload_0
    //   92: aload_2
    //   93: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   96: invokevirtual setData : (Landroid/net/Uri;)Landroid/content/Intent;
    //   99: pop
    //   100: goto -> 67
    //   103: astore_1
    //   104: aload_0
    //   105: invokevirtual getAction : ()Ljava/lang/String;
    //   108: astore_1
    //   109: getstatic com/amazon/device/ads/WebUtils.LOGTAG : Ljava/lang/String;
    //   112: astore_2
    //   113: new java/lang/StringBuilder
    //   116: dup
    //   117: invokespecial <init> : ()V
    //   120: ldc 'Could not handle '
    //   122: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: astore_3
    //   126: aload_1
    //   127: ldc 'market://'
    //   129: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   132: ifeq -> 162
    //   135: ldc 'market'
    //   137: astore_0
    //   138: aload_2
    //   139: aload_3
    //   140: aload_0
    //   141: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   144: ldc ' action: '
    //   146: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: aload_1
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: invokevirtual toString : ()Ljava/lang/String;
    //   156: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   159: pop
    //   160: iconst_0
    //   161: ireturn
    //   162: ldc 'intent'
    //   164: astore_0
    //   165: goto -> 138
    // Exception table:
    //   from	to	target	type
    //   61	67	88	java/net/URISyntaxException
    //   81	86	103	android/content/ActivityNotFoundException
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\WebUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */