package com.amazon.device.ads;

import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;

class SISRegisterEventRequest implements SISRequest {
  private static final Metrics.MetricType CALL_METRIC_TYPE = Metrics.MetricType.SIS_LATENCY_REGISTER_EVENT;
  
  private static final String LOG_TAG = "SISRegisterEventRequest";
  
  private static final String PATH = "/register_event";
  
  private final AdvertisingIdentifier.Info advertisingIdentifierInfo;
  
  private final JSONArray appEvents;
  
  public SISRegisterEventRequest(AdvertisingIdentifier.Info paramInfo, JSONArray paramJSONArray) {
    this.advertisingIdentifierInfo = paramInfo;
    this.appEvents = paramJSONArray;
  }
  
  public Metrics.MetricType getCallMetricType() {
    return CALL_METRIC_TYPE;
  }
  
  public String getLogTag() {
    return "SISRegisterEventRequest";
  }
  
  public String getPath() {
    return "/register_event";
  }
  
  public HashMap<String, String> getPostParameters() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("events", this.appEvents.toString());
    return (HashMap)hashMap;
  }
  
  public WebRequest.QueryStringParameters getQueryParameters() {
    WebRequest.QueryStringParameters queryStringParameters = new WebRequest.QueryStringParameters();
    queryStringParameters.putUrlEncoded("adId", this.advertisingIdentifierInfo.getSISDeviceIdentifier());
    queryStringParameters.putUrlEncoded("dt", DeviceInfo.getDeviceType());
    RegistrationInfo registrationInfo = AmazonRegistration.getInstance().getRegistrationInfo();
    queryStringParameters.putUrlEncoded("app", registrationInfo.getAppName());
    queryStringParameters.putUrlEncoded("appId", registrationInfo.getAppKey());
    queryStringParameters.putUrlEncoded("aud", Configuration.getInstance().getString(Configuration.ConfigOption.SIS_DOMAIN));
    return queryStringParameters;
  }
  
  public void onResponseReceived(JSONObject paramJSONObject) {
    int i = JSONUtils.getIntegerFromJSON(paramJSONObject, "rcode", 0);
    if (i == 1) {
      Log.d("SISRegisterEventRequest", "Application events registered successfully.", new Object[0]);
      AppEventRegistrationHandler.getInstance().onAppEventsRegistered();
      return;
    } 
    Log.d("SISRegisterEventRequest", "Application events not registered. rcode:" + i, new Object[0]);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\SISRegisterEventRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */