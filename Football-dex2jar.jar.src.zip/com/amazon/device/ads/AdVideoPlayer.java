package com.amazon.device.ads;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.MediaController;
import android.widget.VideoView;

final class AdVideoPlayer implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener {
  private static String LOG_TAG = AdVideoPlayer.class.getSimpleName();
  
  private String contentUrl_;
  
  private Context context_;
  
  private ViewGroup.LayoutParams layoutParams_ = null;
  
  private AdVideoPlayerListener listener_;
  
  private boolean released_ = false;
  
  private VideoView videoView_ = null;
  
  private ViewGroup viewGroup_ = null;
  
  public AdVideoPlayer(Context paramContext) {
    this.context_ = paramContext;
  }
  
  private void displayPlayerControls() {
    Log.d(LOG_TAG, "in displayPlayerControls", new Object[0]);
    MediaController mediaController = new MediaController(this.context_);
    this.videoView_.setMediaController(mediaController);
    mediaController.setAnchorView((View)this.videoView_);
    mediaController.requestFocus();
  }
  
  private void initializeVideoView() {
    VideoView videoView = new VideoView(this.context_);
    videoView.setOnCompletionListener(this);
    videoView.setOnErrorListener(this);
    videoView.setLayoutParams(this.layoutParams_);
    this.videoView_ = videoView;
    this.viewGroup_.addView((View)this.videoView_);
  }
  
  private void loadPlayerContent() {
    Uri uri = Uri.parse(this.contentUrl_);
    this.videoView_.setVideoURI(uri);
  }
  
  private void removePlayerFromParent() {
    Log.d(LOG_TAG, "in removePlayerFromParent", new Object[0]);
    this.viewGroup_.removeView((View)this.videoView_);
  }
  
  public void onCompletion(MediaPlayer paramMediaPlayer) {
    releasePlayer();
    if (this.listener_ != null)
      this.listener_.onComplete(); 
  }
  
  public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2) {
    removePlayerFromParent();
    if (this.listener_ != null)
      this.listener_.onError(); 
    return false;
  }
  
  public void playVideo() {
    Log.d(LOG_TAG, "in playVideo", new Object[0]);
    initializeVideoView();
    loadPlayerContent();
    startPlaying();
  }
  
  public void releasePlayer() {
    Log.d(LOG_TAG, "in releasePlayer", new Object[0]);
    if (this.released_)
      return; 
    this.released_ = true;
    this.videoView_.stopPlayback();
    removePlayerFromParent();
  }
  
  public void setLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    this.layoutParams_ = paramLayoutParams;
  }
  
  public void setListener(AdVideoPlayerListener paramAdVideoPlayerListener) {
    this.listener_ = paramAdVideoPlayerListener;
  }
  
  public void setPlayData(String paramString) {
    this.released_ = false;
    this.contentUrl_ = paramString;
  }
  
  public void setViewGroup(ViewGroup paramViewGroup) {
    this.viewGroup_ = paramViewGroup;
  }
  
  public void startPlaying() {
    Log.d(LOG_TAG, "in startPlaying", new Object[0]);
    displayPlayerControls();
    this.videoView_.start();
  }
  
  public static interface AdVideoPlayerListener {
    void onComplete();
    
    void onError();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdVideoPlayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */