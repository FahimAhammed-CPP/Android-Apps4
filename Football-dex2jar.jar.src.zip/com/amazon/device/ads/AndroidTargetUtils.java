package com.amazon.device.ads;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewDatabase;
import android.widget.ImageButton;

class AndroidTargetUtils {
  public static final AndroidClassAdapter defaultAndroidClassAdapter;
  
  private static boolean isWebViewCheckedAndOk = false;
  
  static {
    defaultAndroidClassAdapter = new AndroidClassAdapter(new AndroidBuildInfo());
  }
  
  public static final void disableHardwareAcceleration(View paramView) {
    HoneycombTargetUtils.disableHardwareAcceleration(paramView);
  }
  
  public static void editorApply(SharedPreferences.Editor paramEditor) {
    GingerbreadTargetUtils.editorApply(paramEditor);
  }
  
  public static void enableHardwareAcceleration(Window paramWindow) {
    if (isAtLeastAndroidAPI(11))
      HoneycombTargetUtils.enableHardwareAcceleration(paramWindow); 
  }
  
  public static void enableWebViewDebugging(boolean paramBoolean) {
    if (isAtLeastAndroidAPI(19))
      KitKatTargetUtils.enableWebViewDebugging(paramBoolean); 
  }
  
  public static <T> void executeAsyncTask(AsyncTask<T, ?, ?> paramAsyncTask, T... paramVarArgs) {
    if (isAtLeastAndroidAPI(11)) {
      HoneycombTargetUtils.executeAsyncTaskWithThreadPooling(paramAsyncTask, paramVarArgs);
      return;
    } 
    paramAsyncTask.execute((Object[])paramVarArgs);
  }
  
  public static AndroidClassAdapter getDefaultAndroidClassAdapter() {
    return defaultAndroidClassAdapter;
  }
  
  public static BitmapDrawable getNewBitmapDrawable(Resources paramResources, String paramString) {
    return isAtLeastAndroidAPI(5) ? EclairTargetUtils.getNewBitmapDrawable(paramResources, paramString) : new BitmapDrawable(paramString);
  }
  
  public static int getOrientation(Display paramDisplay) {
    return isAtLeastAndroidAPI(8) ? FroyoTargetUtils.getRotation(paramDisplay) : paramDisplay.getOrientation();
  }
  
  public static String getPackageCodePath(Context paramContext) {
    return FroyoTargetUtils.getPackageCodePath(paramContext);
  }
  
  public static void hideActionAndStatusBars(Activity paramActivity) {
    if (isAtLeastAndroidAPI(11))
      HoneycombTargetUtils.hideActionBar(paramActivity); 
    if (isAtLeastAndroidAPI(16))
      JellyBeanTargetUtils.hideStatusBar(paramActivity); 
  }
  
  public static boolean isAndroidAPI(int paramInt) {
    return (Build.VERSION.SDK_INT == paramInt);
  }
  
  public static boolean isAtLeastAndroidAPI(int paramInt) {
    return (Build.VERSION.SDK_INT >= paramInt);
  }
  
  public static boolean isAtLeastAndroidAPI(AndroidBuildInfo paramAndroidBuildInfo, int paramInt) {
    return (paramAndroidBuildInfo.getSDKInt() >= paramInt);
  }
  
  public static boolean isAtOrBelowAndroidAPI(int paramInt) {
    return (Build.VERSION.SDK_INT <= paramInt);
  }
  
  public static boolean isBetweenAndroidAPIs(int paramInt1, int paramInt2) {
    return (isAtLeastAndroidAPI(paramInt1) && isAtOrBelowAndroidAPI(paramInt2));
  }
  
  protected static boolean isDatabaseLocked(SQLiteException paramSQLiteException) {
    return isAtLeastAndroidAPI(11) ? isInstanceOfSQLiteDatabaseLockedException(paramSQLiteException) : StringUtils.doesExceptionContainLockedDatabaseMessage((Exception)paramSQLiteException);
  }
  
  public static boolean isInstanceOfSQLiteDatabaseLockedException(SQLiteException paramSQLiteException) {
    return HoneycombTargetUtils.isInstanceOfSQLiteDatabaseLockedException(paramSQLiteException);
  }
  
  public static boolean isWebViewOk(Context paramContext) {
    boolean bool = false;
    if (isAtOrBelowAndroidAPI(8) && !isWebViewCheckedAndOk) {
      if (WebViewDatabase.getInstance(paramContext) != null)
        try {
          SQLiteDatabase sQLiteDatabase = paramContext.openOrCreateDatabase("webviewCache.db", 0, null);
          if (sQLiteDatabase != null)
            sQLiteDatabase.close(); 
          return true;
        } catch (SQLiteException sQLiteException) {
          bool = isDatabaseLocked(sQLiteException);
          return bool;
        } finally {
          if (false)
            throw new NullPointerException(); 
        }  
      return bool;
    } 
    return true;
  }
  
  public static void removeJavascriptInterface(WebView paramWebView, String paramString) {
    HoneycombTargetUtils.removeJavascriptInterface(paramWebView, paramString);
  }
  
  public static void setBackgroundDrawable(View paramView, Drawable paramDrawable) {
    if (isAtLeastAndroidAPI(16)) {
      JellyBeanTargetUtils.setBackgroundForLinerLayout(paramView, paramDrawable);
      return;
    } 
    paramView.setBackgroundDrawable(paramDrawable);
  }
  
  public static void setImageButtonAlpha(ImageButton paramImageButton, int paramInt) {
    if (isAtLeastAndroidAPI(16)) {
      JellyBeanTargetUtils.setImageButtonAlpha(paramImageButton, paramInt);
      return;
    } 
    paramImageButton.setAlpha(paramInt);
  }
  
  public static class AndroidClassAdapter {
    private final AndroidBuildInfo androidBuildInfo;
    
    public AndroidClassAdapter(AndroidBuildInfo param1AndroidBuildInfo) {
      this.androidBuildInfo = param1AndroidBuildInfo;
    }
    
    private boolean isAtLeastAndroidAPI(int param1Int) {
      return AndroidTargetUtils.isAtLeastAndroidAPI(this.androidBuildInfo, param1Int);
    }
    
    public WebSettingsAdapter withWebSettings(WebSettings param1WebSettings) {
      return new WebSettingsAdapter(param1WebSettings);
    }
    
    public class WebSettingsAdapter {
      private final WebSettings webSettings;
      
      public WebSettingsAdapter(WebSettings param2WebSettings) {
        this.webSettings = param2WebSettings;
      }
      
      public void setMediaPlaybackRequiresUserGesture(boolean param2Boolean) {
        if (AndroidTargetUtils.AndroidClassAdapter.this.isAtLeastAndroidAPI(17))
          AndroidTargetUtils.JellyBeanMR1TargetUtils.setMediaPlaybackRequiresUserGesture(this.webSettings, param2Boolean); 
      }
    }
  }
  
  public class WebSettingsAdapter {
    private final WebSettings webSettings;
    
    public WebSettingsAdapter(WebSettings param1WebSettings) {
      this.webSettings = param1WebSettings;
    }
    
    public void setMediaPlaybackRequiresUserGesture(boolean param1Boolean) {
      if (this.this$0.isAtLeastAndroidAPI(17))
        AndroidTargetUtils.JellyBeanMR1TargetUtils.setMediaPlaybackRequiresUserGesture(this.webSettings, param1Boolean); 
    }
  }
  
  @TargetApi(5)
  private static class EclairTargetUtils {
    protected static BitmapDrawable getNewBitmapDrawable(Resources param1Resources, String param1String) {
      return new BitmapDrawable(param1Resources, param1String);
    }
  }
  
  @TargetApi(8)
  private static class FroyoTargetUtils {
    protected static String getPackageCodePath(Context param1Context) {
      return param1Context.getPackageCodePath();
    }
    
    protected static int getRotation(Display param1Display) {
      return param1Display.getRotation();
    }
  }
  
  @TargetApi(9)
  private static class GingerbreadTargetUtils {
    protected static void editorApply(SharedPreferences.Editor param1Editor) {
      param1Editor.apply();
    }
  }
  
  @TargetApi(11)
  private static class HoneycombTargetUtils {
    public static final void disableHardwareAcceleration(View param1View) {
      param1View.setLayerType(1, null);
    }
    
    protected static void enableHardwareAcceleration(Window param1Window) {
      param1Window.setFlags(16777216, 16777216);
    }
    
    protected static final <T> void executeAsyncTaskWithThreadPooling(AsyncTask<T, ?, ?> param1AsyncTask, T... param1VarArgs) {
      param1AsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])param1VarArgs);
    }
    
    protected static void hideActionBar(Activity param1Activity) {
      ActionBar actionBar = param1Activity.getActionBar();
      if (actionBar != null)
        actionBar.hide(); 
    }
    
    public static boolean isInstanceOfSQLiteDatabaseLockedException(SQLiteException param1SQLiteException) {
      return param1SQLiteException instanceof android.database.sqlite.SQLiteDatabaseLockedException;
    }
    
    protected static void removeJavascriptInterface(WebView param1WebView, String param1String) {
      param1WebView.removeJavascriptInterface(param1String);
    }
  }
  
  @TargetApi(17)
  private static class JellyBeanMR1TargetUtils {
    public static void setMediaPlaybackRequiresUserGesture(WebSettings param1WebSettings, boolean param1Boolean) {
      param1WebSettings.setMediaPlaybackRequiresUserGesture(param1Boolean);
    }
  }
  
  @TargetApi(16)
  private static class JellyBeanTargetUtils {
    public static void hideStatusBar(Activity param1Activity) {
      param1Activity.getWindow().getDecorView().setSystemUiVisibility(4);
    }
    
    public static void setBackgroundForLinerLayout(View param1View, Drawable param1Drawable) {
      param1View.setBackground(param1Drawable);
    }
    
    protected static void setImageButtonAlpha(ImageButton param1ImageButton, int param1Int) {
      param1ImageButton.setImageAlpha(param1Int);
    }
  }
  
  @TargetApi(19)
  private static class KitKatTargetUtils {
    public static void enableWebViewDebugging(final boolean enable) {
      ThreadUtils.executeOnMainThread(new Runnable() {
            public void run() {
              WebView.setWebContentsDebuggingEnabled(enable);
            }
          });
    }
  }
  
  static final class null implements Runnable {
    public void run() {
      WebView.setWebContentsDebuggingEnabled(enable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AndroidTargetUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */