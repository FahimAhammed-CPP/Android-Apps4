package com.amazon.device.ads;

class Metrics {
  private static final String LOG_TAG = Metrics.class.getSimpleName();
  
  private static final boolean TYPED_METRIC = true;
  
  private static Metrics instance = new Metrics();
  
  private MetricsCollector metricsCollector = new MetricsCollector();
  
  public static Metrics getInstance() {
    return instance;
  }
  
  private void sendMetrics(final WebRequest webRequest) {
    ThreadUtils.executeRunnable(new Runnable() {
          public void run() {
            // Byte code:
            //   0: aload_0
            //   1: getfield val$webRequest : Lcom/amazon/device/ads/WebRequest;
            //   4: iconst_1
            //   5: invokevirtual enableLog : (Z)V
            //   8: aload_0
            //   9: getfield val$webRequest : Lcom/amazon/device/ads/WebRequest;
            //   12: invokevirtual makeCall : ()Lcom/amazon/device/ads/WebRequest$WebResponse;
            //   15: pop
            //   16: return
            //   17: astore_1
            //   18: getstatic com/amazon/device/ads/Metrics$2.$SwitchMap$com$amazon$device$ads$WebRequest$WebRequestStatus : [I
            //   21: aload_1
            //   22: invokevirtual getStatus : ()Lcom/amazon/device/ads/WebRequest$WebRequestStatus;
            //   25: invokevirtual ordinal : ()I
            //   28: iaload
            //   29: tableswitch default -> 60, 1 -> 61, 2 -> 81, 3 -> 101, 4 -> 120
            //   60: return
            //   61: invokestatic access$000 : ()Ljava/lang/String;
            //   64: ldc 'Unable to submit metrics for ad due to an Invalid Client Protocol, msg: %s'
            //   66: iconst_1
            //   67: anewarray java/lang/Object
            //   70: dup
            //   71: iconst_0
            //   72: aload_1
            //   73: invokevirtual getMessage : ()Ljava/lang/String;
            //   76: aastore
            //   77: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
            //   80: return
            //   81: invokestatic access$000 : ()Ljava/lang/String;
            //   84: ldc 'Unable to submit metrics for ad due to Network Failure, msg: %s'
            //   86: iconst_1
            //   87: anewarray java/lang/Object
            //   90: dup
            //   91: iconst_0
            //   92: aload_1
            //   93: invokevirtual getMessage : ()Ljava/lang/String;
            //   96: aastore
            //   97: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
            //   100: return
            //   101: invokestatic access$000 : ()Ljava/lang/String;
            //   104: ldc 'Unable to submit metrics for ad due to a Malformed Pixel URL, msg: %s'
            //   106: iconst_1
            //   107: anewarray java/lang/Object
            //   110: dup
            //   111: iconst_0
            //   112: aload_1
            //   113: invokevirtual getMessage : ()Ljava/lang/String;
            //   116: aastore
            //   117: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
            //   120: invokestatic access$000 : ()Ljava/lang/String;
            //   123: ldc 'Unable to submit metrics for ad because of unsupported character encoding, msg: %s'
            //   125: iconst_1
            //   126: anewarray java/lang/Object
            //   129: dup
            //   130: iconst_0
            //   131: aload_1
            //   132: invokevirtual getMessage : ()Ljava/lang/String;
            //   135: aastore
            //   136: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
            //   139: return
            // Exception table:
            //   from	to	target	type
            //   8	16	17	com/amazon/device/ads/WebRequest$WebRequestException
          }
        });
  }
  
  public MetricsCollector getMetricsCollector() {
    return this.metricsCollector;
  }
  
  public void submitAndResetMetrics(MetricsSubmitter paramMetricsSubmitter) {
    MetricsCollector metricsCollector;
    Log.d(LOG_TAG, "METRIC Submit and Reset", new Object[0]);
    AdMetrics adMetrics = new AdMetrics(paramMetricsSubmitter);
    if (adMetrics.canSubmit()) {
      metricsCollector = this.metricsCollector;
      this.metricsCollector = new MetricsCollector();
      adMetrics.addGlobalMetrics(metricsCollector);
      sendMetrics(adMetrics.getAaxWebRequestAndResetAdMetrics());
      return;
    } 
    metricsCollector.resetMetricsCollector();
  }
  
  enum MetricType {
    AAX_CONFIG_DOWNLOAD_FAILED,
    AAX_CONFIG_DOWNLOAD_LATENCY,
    AAX_LATENCY_GET_AD,
    ADLAYOUT_HEIGHT_ZERO,
    AD_ASPECT_RATIO_LESS_THAN_SCREEN_ASPECT_RATIO,
    AD_COUNTER_AUTO_AD_SIZE,
    AD_COUNTER_FAILED_DUE_TO_NO_RETRY,
    AD_COUNTER_IDENTIFIED_DEVICE,
    AD_COUNTER_PARENT_VIEW_MISSING,
    AD_COUNTER_RENDERING_FATAL,
    AD_COUNTER_RESHOWN,
    AD_FAILED_INVALID_AUTO_AD_SIZE,
    AD_FAILED_LAYOUT_NOT_RUN,
    AD_FAILED_NULL_LAYOUT_PARAMS,
    AD_FAILED_UNKNOWN_WEBVIEW_ISSUE,
    AD_IS_INTERSTITIAL,
    AD_LATENCY_RENDER,
    AD_LATENCY_RENDER_FAILED,
    AD_LATENCY_TOTAL("tl", true),
    AD_LATENCY_TOTAL_FAILURE("tl", true),
    AD_LATENCY_TOTAL_SUCCESS("tsl", true),
    AD_LAYOUT_INITIALIZATION("tsl", true),
    AD_LOADED_TO_AD_SHOW_TIME("tsl", true),
    AD_LOAD_FAILED("tsl", true),
    AD_LOAD_FAILED_ON_AAX_CALL_TIMEOUT("tsl", true),
    AD_LOAD_FAILED_ON_PRERENDERING_TIMEOUT("tsl", true),
    AD_LOAD_LATENCY_AAX_GET_AD_END_TO_FETCH_THREAD_END("tsl", true),
    AD_LOAD_LATENCY_CREATE_AAX_GET_AD_URL("tsl", true),
    AD_LOAD_LATENCY_FETCH_THREAD_SPIN_UP("tsl", true),
    AD_LOAD_LATENCY_FETCH_THREAD_START_TO_AAX_GET_AD_START("tsl", true),
    AD_LOAD_LATENCY_FINALIZE_FETCH_SPIN_UP("tsl", true),
    AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_FAILURE("tsl", true),
    AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_RENDER_START("tsl", true),
    AD_LOAD_LATENCY_LOADAD_TO_FETCH_THREAD_REQUEST_START("tsl", true),
    AD_NO_RETRY_TTL_RECEIVED("tsl", true),
    AD_SHOW_DURATION("tsl", true),
    AD_SHOW_LATENCY("tsl", true),
    ASSETS_CREATED_LATENCY("tsl", true),
    ASSETS_ENSURED_LATENCY("tsl", true),
    ASSETS_FAILED("tsl", true),
    CARRIER_NAME("tsl", true),
    CONFIG_DOWNLOAD_ERROR("tsl", true),
    CONFIG_DOWNLOAD_LATENCY("tsl", true),
    CONFIG_PARSE_ERROR("tsl", true),
    CONNECTION_TYPE("tsl", true),
    CUSTOM_RENDER_HANDLED("tsl", true),
    EXPIRED_AD_CALL("tsl", true),
    INTERSTITIAL_AD_ACTIVITY_FAILED("tsl", true),
    RENDER_REQUIREMENT_CHECK_FAILURE("tsl", true),
    SET_ORIENTATION_FAILURE("tsl", true),
    SIS_COUNTER_IDENTIFIED_DEVICE_CHANGED("tsl", true),
    SIS_LATENCY_REGISTER("tsl", true),
    SIS_LATENCY_REGISTER_EVENT("tsl", true),
    SIS_LATENCY_UPDATE_DEVICE_INFO("tsl", true),
    TLS_ENABLED("tsl", true),
    VIEWPORT_SCALE("tsl", true),
    WIFI_PRESENT("tsl", true);
    
    private final String aaxName;
    
    private final boolean isAdTypeSpecific;
    
    static {
      AD_LOAD_LATENCY_FETCH_THREAD_SPIN_UP = new MetricType("AD_LOAD_LATENCY_FETCH_THREAD_SPIN_UP", 4, "lfsul");
      AD_LOAD_LATENCY_FETCH_THREAD_START_TO_AAX_GET_AD_START = new MetricType("AD_LOAD_LATENCY_FETCH_THREAD_START_TO_AAX_GET_AD_START", 5, "lfsasl");
      AD_LOAD_LATENCY_AAX_GET_AD_END_TO_FETCH_THREAD_END = new MetricType("AD_LOAD_LATENCY_AAX_GET_AD_END_TO_FETCH_THREAD_END", 6, "laefel");
      AD_LOAD_LATENCY_FINALIZE_FETCH_SPIN_UP = new MetricType("AD_LOAD_LATENCY_FINALIZE_FETCH_SPIN_UP", 7, "lffsul");
      AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_RENDER_START = new MetricType("AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_RENDER_START", 8, "lffsrsl", true);
      AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_FAILURE = new MetricType("AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_FAILURE", 9, "lffsfl", true);
      AD_LOAD_LATENCY_CREATE_AAX_GET_AD_URL = new MetricType("AD_LOAD_LATENCY_CREATE_AAX_GET_AD_URL", 10, "lcaul");
      ASSETS_CREATED_LATENCY = new MetricType("ASSETS_CREATED_LATENCY", 11, "lacl");
      ASSETS_ENSURED_LATENCY = new MetricType("ASSETS_ENSURED_LATENCY", 12, "lael");
      ASSETS_FAILED = new MetricType("ASSETS_FAILED", 13, "af");
      AD_LOADED_TO_AD_SHOW_TIME = new MetricType("AD_LOADED_TO_AD_SHOW_TIME", 14, "alast");
      AD_SHOW_LATENCY = new MetricType("AD_SHOW_LATENCY", 15, "lsa");
      AD_SHOW_DURATION = new MetricType("AD_SHOW_DURATION", 16, "sd", true);
      AD_LAYOUT_INITIALIZATION = new MetricType("AD_LAYOUT_INITIALIZATION", 17, "ali");
      AAX_LATENCY_GET_AD = new MetricType("AAX_LATENCY_GET_AD", 18, "al");
      AD_LOAD_FAILED = new MetricType("AD_LOAD_FAILED", 19, "lf");
      AD_LOAD_FAILED_ON_AAX_CALL_TIMEOUT = new MetricType("AD_LOAD_FAILED_ON_AAX_CALL_TIMEOUT", 20, "lfat");
      AD_LOAD_FAILED_ON_PRERENDERING_TIMEOUT = new MetricType("AD_LOAD_FAILED_ON_PRERENDERING_TIMEOUT", 21, "lfpt");
      AD_COUNTER_IDENTIFIED_DEVICE = new MetricType("AD_COUNTER_IDENTIFIED_DEVICE", 22, "id");
      AD_COUNTER_RENDERING_FATAL = new MetricType("AD_COUNTER_RENDERING_FATAL", 23, "rf", true);
      AD_LATENCY_RENDER = new MetricType("AD_LATENCY_RENDER", 24, "rl", true);
      AD_LATENCY_RENDER_FAILED = new MetricType("AD_LATENCY_RENDER_FAILED", 25, "rlf", true);
      AD_COUNTER_FAILED_DUE_TO_NO_RETRY = new MetricType("AD_COUNTER_FAILED_DUE_TO_NO_RETRY", 26, "nrtf");
      AD_NO_RETRY_TTL_RECEIVED = new MetricType("AD_NO_RETRY_TTL_RECEIVED", 27, "nrtr");
      AD_COUNTER_AUTO_AD_SIZE = new MetricType("AD_COUNTER_AUTO_AD_SIZE", 28, "aas");
      AD_COUNTER_PARENT_VIEW_MISSING = new MetricType("AD_COUNTER_PARENT_VIEW_MISSING", 29, "pvm");
      ADLAYOUT_HEIGHT_ZERO = new MetricType("ADLAYOUT_HEIGHT_ZERO", 30, "ahz");
      VIEWPORT_SCALE = new MetricType("VIEWPORT_SCALE", 31, "vs");
      AD_COUNTER_RESHOWN = new MetricType("AD_COUNTER_RESHOWN", 32, "rs", true);
      AD_FAILED_UNKNOWN_WEBVIEW_ISSUE = new MetricType("AD_FAILED_UNKNOWN_WEBVIEW_ISSUE", 33, "fuwi");
      AD_FAILED_NULL_LAYOUT_PARAMS = new MetricType("AD_FAILED_NULL_LAYOUT_PARAMS", 34, "fnlp");
      AD_FAILED_LAYOUT_NOT_RUN = new MetricType("AD_FAILED_LAYOUT_NOT_RUN", 35, "flnr");
      AD_FAILED_INVALID_AUTO_AD_SIZE = new MetricType("AD_FAILED_INVALID_AUTO_AD_SIZE", 36, "faas");
      SIS_COUNTER_IDENTIFIED_DEVICE_CHANGED = new MetricType("SIS_COUNTER_IDENTIFIED_DEVICE_CHANGED", 37, "sid");
      SIS_LATENCY_REGISTER = new MetricType("SIS_LATENCY_REGISTER", 38, "srl");
      SIS_LATENCY_UPDATE_DEVICE_INFO = new MetricType("SIS_LATENCY_UPDATE_DEVICE_INFO", 39, "sul");
      SIS_LATENCY_REGISTER_EVENT = new MetricType("SIS_LATENCY_REGISTER_EVENT", 40, "srel");
      CONFIG_DOWNLOAD_ERROR = new MetricType("CONFIG_DOWNLOAD_ERROR", 41, "cde");
      CONFIG_DOWNLOAD_LATENCY = new MetricType("CONFIG_DOWNLOAD_LATENCY", 42, "cdt");
      CONFIG_PARSE_ERROR = new MetricType("CONFIG_PARSE_ERROR", 43, "cpe");
      AAX_CONFIG_DOWNLOAD_LATENCY = new MetricType("AAX_CONFIG_DOWNLOAD_LATENCY", 44, "acl");
      AAX_CONFIG_DOWNLOAD_FAILED = new MetricType("AAX_CONFIG_DOWNLOAD_FAILED", 45, "acf");
      CUSTOM_RENDER_HANDLED = new MetricType("CUSTOM_RENDER_HANDLED", 46, "crh");
      TLS_ENABLED = new MetricType("TLS_ENABLED", 47, "tls");
      WIFI_PRESENT = new MetricType("WIFI_PRESENT", 48, "wifi");
      CARRIER_NAME = new MetricType("CARRIER_NAME", 49, "car");
      CONNECTION_TYPE = new MetricType("CONNECTION_TYPE", 50, "ct");
      AD_IS_INTERSTITIAL = new MetricType("AD_IS_INTERSTITIAL", 51, "i");
      INTERSTITIAL_AD_ACTIVITY_FAILED = new MetricType("INTERSTITIAL_AD_ACTIVITY_FAILED", 52, "iaaf");
      RENDER_REQUIREMENT_CHECK_FAILURE = new MetricType("RENDER_REQUIREMENT_CHECK_FAILURE", 53, "rrcfc", true);
      EXPIRED_AD_CALL = new MetricType("EXPIRED_AD_CALL", 54, "eac", true);
      AD_ASPECT_RATIO_LESS_THAN_SCREEN_ASPECT_RATIO = new MetricType("AD_ASPECT_RATIO_LESS_THAN_SCREEN_ASPECT_RATIO", 55, "rarfc", true);
      SET_ORIENTATION_FAILURE = new MetricType("SET_ORIENTATION_FAILURE", 56, "rsofc", true);
      $VALUES = new MetricType[] { 
          AD_LATENCY_TOTAL, AD_LATENCY_TOTAL_SUCCESS, AD_LATENCY_TOTAL_FAILURE, AD_LOAD_LATENCY_LOADAD_TO_FETCH_THREAD_REQUEST_START, AD_LOAD_LATENCY_FETCH_THREAD_SPIN_UP, AD_LOAD_LATENCY_FETCH_THREAD_START_TO_AAX_GET_AD_START, AD_LOAD_LATENCY_AAX_GET_AD_END_TO_FETCH_THREAD_END, AD_LOAD_LATENCY_FINALIZE_FETCH_SPIN_UP, AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_RENDER_START, AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_FAILURE, 
          AD_LOAD_LATENCY_CREATE_AAX_GET_AD_URL, ASSETS_CREATED_LATENCY, ASSETS_ENSURED_LATENCY, ASSETS_FAILED, AD_LOADED_TO_AD_SHOW_TIME, AD_SHOW_LATENCY, AD_SHOW_DURATION, AD_LAYOUT_INITIALIZATION, AAX_LATENCY_GET_AD, AD_LOAD_FAILED, 
          AD_LOAD_FAILED_ON_AAX_CALL_TIMEOUT, AD_LOAD_FAILED_ON_PRERENDERING_TIMEOUT, AD_COUNTER_IDENTIFIED_DEVICE, AD_COUNTER_RENDERING_FATAL, AD_LATENCY_RENDER, AD_LATENCY_RENDER_FAILED, AD_COUNTER_FAILED_DUE_TO_NO_RETRY, AD_NO_RETRY_TTL_RECEIVED, AD_COUNTER_AUTO_AD_SIZE, AD_COUNTER_PARENT_VIEW_MISSING, 
          ADLAYOUT_HEIGHT_ZERO, VIEWPORT_SCALE, AD_COUNTER_RESHOWN, AD_FAILED_UNKNOWN_WEBVIEW_ISSUE, AD_FAILED_NULL_LAYOUT_PARAMS, AD_FAILED_LAYOUT_NOT_RUN, AD_FAILED_INVALID_AUTO_AD_SIZE, SIS_COUNTER_IDENTIFIED_DEVICE_CHANGED, SIS_LATENCY_REGISTER, SIS_LATENCY_UPDATE_DEVICE_INFO, 
          SIS_LATENCY_REGISTER_EVENT, CONFIG_DOWNLOAD_ERROR, CONFIG_DOWNLOAD_LATENCY, CONFIG_PARSE_ERROR, AAX_CONFIG_DOWNLOAD_LATENCY, AAX_CONFIG_DOWNLOAD_FAILED, CUSTOM_RENDER_HANDLED, TLS_ENABLED, WIFI_PRESENT, CARRIER_NAME, 
          CONNECTION_TYPE, AD_IS_INTERSTITIAL, INTERSTITIAL_AD_ACTIVITY_FAILED, RENDER_REQUIREMENT_CHECK_FAILURE, EXPIRED_AD_CALL, AD_ASPECT_RATIO_LESS_THAN_SCREEN_ASPECT_RATIO, SET_ORIENTATION_FAILURE };
    }
    
    MetricType(String param1String1, boolean param1Boolean) {
      this.aaxName = param1String1;
      this.isAdTypeSpecific = param1Boolean;
    }
    
    public String getAaxName() {
      return this.aaxName;
    }
    
    public boolean isAdTypeSpecific() {
      return this.isAdTypeSpecific;
    }
  }
  
  static interface MetricsSubmitter {
    String getInstrumentationPixelUrl();
    
    MetricsCollector getMetricsCollector();
    
    void resetMetricsCollector();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Metrics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */