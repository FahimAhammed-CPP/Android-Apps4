package com.amazon.device.ads;

import android.app.Activity;
import android.content.Context;
import android.view.ViewGroup;

class AdControlAccessor {
  private final AdController adController;
  
  public AdControlAccessor(AdController paramAdController) {
    this.adController = paramAdController;
  }
  
  public void addJavascriptInterface(Object paramObject, boolean paramBoolean, String paramString) {
    this.adController.addJavascriptInterface(paramObject, paramBoolean, paramString);
  }
  
  public void addSDKEventListener(SDKEventListener paramSDKEventListener) {
    this.adController.addSDKEventListener(paramSDKEventListener);
  }
  
  public boolean closeAd() {
    return this.adController.closeAd();
  }
  
  public void enableCloseButton(boolean paramBoolean) {
    enableCloseButton(paramBoolean, null);
  }
  
  public void enableCloseButton(boolean paramBoolean, RelativePosition paramRelativePosition) {
    this.adController.enableNativeCloseButton(paramBoolean, paramRelativePosition);
  }
  
  public void fireAdEvent(AdEvent paramAdEvent) {
    this.adController.fireAdEvent(paramAdEvent);
  }
  
  public AdState getAdState() {
    return this.adController.getAdState();
  }
  
  public Context getContext() {
    return this.adController.getContext();
  }
  
  public Position getCurrentPosition() {
    return this.adController.getAdPosition();
  }
  
  public Size getMaxSize() {
    return this.adController.getMaxExpandableSize();
  }
  
  public int getOriginalOrientation() {
    return this.adController.getOriginalOrientation();
  }
  
  public Size getScreenSize() {
    return this.adController.getScreenSize();
  }
  
  public int getViewHeight() {
    return this.adController.getViewHeight();
  }
  
  public ViewGroup getViewParentIfExpanded() {
    return this.adController.getViewParentIfExpanded();
  }
  
  public int getViewWidth() {
    return this.adController.getViewWidth();
  }
  
  public void injectJavascript(String paramString) {
    this.adController.injectJavascript(paramString, false);
  }
  
  public void injectJavascriptPreload(String paramString) {
    this.adController.injectJavascript(paramString, true);
  }
  
  public boolean isInterstitial() {
    return this.adController.isInterstitial();
  }
  
  public boolean isModal() {
    return this.adController.isModal();
  }
  
  public boolean isVisible() {
    return this.adController.isVisible();
  }
  
  public void loadHtml(String paramString1, String paramString2) {
    this.adController.loadHtml(paramString1, paramString2);
  }
  
  public void loadUrl(String paramString) {
    this.adController.loadUrl(paramString);
  }
  
  public void moveViewBackToParent(ViewGroup.LayoutParams paramLayoutParams) {
    this.adController.moveViewBackToParent(paramLayoutParams);
  }
  
  public void moveViewToViewGroup(ViewGroup paramViewGroup, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    this.adController.moveViewToViewGroup(paramViewGroup, paramLayoutParams, paramBoolean);
  }
  
  public void orientationChangeAttemptedWhenNotAllowed() {
    this.adController.orientationChangeAttemptedWhenNotAllowed();
  }
  
  public void overrideBackButton(boolean paramBoolean) {
    this.adController.overrideBackButton(paramBoolean);
  }
  
  public boolean popView() {
    return this.adController.popView();
  }
  
  public void preloadHtml(String paramString1, String paramString2, PreloadCallback paramPreloadCallback) {
    this.adController.preloadHtml(paramString1, paramString2, paramPreloadCallback);
  }
  
  public void preloadUrl(String paramString, PreloadCallback paramPreloadCallback) {
    this.adController.preloadUrl(paramString, paramPreloadCallback);
  }
  
  public void reload() {
    this.adController.reload();
  }
  
  public void removeCloseButton() {
    this.adController.removeNativeCloseButton();
  }
  
  public void setExpanded(boolean paramBoolean) {
    this.adController.setExpanded(paramBoolean);
  }
  
  public void setOriginalOrientation(Activity paramActivity) {
    this.adController.setOriginalOrientation(paramActivity);
  }
  
  public void showNativeCloseButtonImage(boolean paramBoolean) {
    this.adController.showNativeCloseButtonImage(paramBoolean);
  }
  
  public void stashView() {
    this.adController.stashView();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdControlAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */