package com.amazon.device.ads;

import org.json.JSONObject;

class AmazonAdSDKBridge implements AdSDKBridge {
  private static final String BRIDGE_NAME = "amazonObject";
  
  private static final String JAVASCRIPT = "(function (window, console){\n    var version = '1.0',\n    debug = function(msg) {\n        console.log(\"Amazon Javascript log: \" + msg);\n    },\n    is_array = function (obj) {\n        return Object.prototype.toString.call(obj) === '[object Array]';\n    },\n    forEach = function (array, fn) {\n        var i;\n        for (i = 0; i < array.length; i++) {\n            if (i in array) {\n                fn.call(null, array[i], i);\n            }\n        }\n    },\n    listeners = [],\n    events = {\n        backButton: 'backButton'\n    },\n    invokeListeners = function(event, args) {\n        var eventListeners = listeners[event] || [];\n        // fire all the listeners\n        forEach(eventListeners, function(listener){\n            try {\n                listener.apply(null, args);\n            }catch(e){\n                debug(\"Error executing \" + event + \" listener\");\n                debug(e);\n            }\n        });\n    },\n    backButtonEvent = function() {\n        invokeListeners(\"backButton\");\n    };\n    window.amazonBridge = {\n        backButton : backButtonEvent\n    };\n    window.amazon = {\n        // Command Flow\n        addEventListener : function(event, listener){\n            var eventListeners = listeners[event] || [],\n            alreadyRegistered = false;\n            \n            //verify the event is one that will actually occur\n            if (!events.hasOwnProperty(event)){\n                return;\n            }\n            \n            //register first set of listeners for this event\n            if (!is_array(listeners[event])) {\n                listeners[event] = eventListeners;\n            }\n            \n            forEach(eventListeners, function(l){ \n                // Listener already registered, so no need to add it.\n                    if (listener === l){\n                        alreadyRegistered = true;\n                    }\n                }\n            );\n            if (!alreadyRegistered){\n                listeners[event].push(listener);\n            }\n        },\n        removeEventListener : function(event, listener){\n            if (listeners.hasOwnProperty(event)) {\n                var eventListeners = listeners[event];\n                if (eventListeners) {\n                    var idx = eventListeners.indexOf(listener);\n                    if (idx !== -1) {\n                        eventListeners.splice(idx, 1);\n                    }\n                }\n            }\n        },\n        enableCloseButton: function(enable){\n            amazonObject." + JavascriptInteractor.getExecutorMethodName() + "(\"EnableCloseButton\", JSON.stringify({\"enable\": enable}));\n" + "        },\n" + "        overrideBackButton: function(override){\n" + "            amazonObject." + JavascriptInteractor.getExecutorMethodName() + "(\"OverrideBackButton\", JSON.stringify({\"override\": override}));\n" + "        },\n" + "        getVersion: function(){\n" + "            return version;\n" + "        },\n" + "    };\n" + "})(window, console);";
  
  private final AdControlAccessor adControlAccessor;
  
  private final JavascriptInteractor javascriptInteractor;
  
  private final AmazonAdSDKEventListener listener = new AmazonAdSDKEventListener(this);
  
  public AmazonAdSDKBridge(AdControlAccessor paramAdControlAccessor, JavascriptInteractor paramJavascriptInteractor) {
    this.adControlAccessor = paramAdControlAccessor;
    this.javascriptInteractor = paramJavascriptInteractor;
    this.javascriptInteractor.addMethodExecutor(new EnableCloseButtonJSIF(this));
    this.javascriptInteractor.addMethodExecutor(new OverrideBackButtonJSIF(this));
  }
  
  private boolean canHaveCloseButton() {
    return this.adControlAccessor.isModal();
  }
  
  private void enableCloseButton(boolean paramBoolean) {
    if (!canHaveCloseButton())
      return; 
    if (paramBoolean) {
      this.adControlAccessor.enableCloseButton(true);
      return;
    } 
    this.adControlAccessor.removeCloseButton();
  }
  
  private void onBackButton() {
    this.adControlAccessor.injectJavascript("amazonBridge.backButton();");
  }
  
  private void overrideBackButton(boolean paramBoolean) {
    this.adControlAccessor.overrideBackButton(paramBoolean);
  }
  
  public String getJavascript() {
    return JAVASCRIPT;
  }
  
  public JavascriptInteractor.Executor getJavascriptInteractorExecutor() {
    return this.javascriptInteractor.getExecutor();
  }
  
  public String getName() {
    return "amazonObject";
  }
  
  public SDKEventListener getSDKEventListener() {
    return this.listener;
  }
  
  public boolean hasNativeExecution() {
    return true;
  }
  
  private static class AmazonAdSDKEventListener implements SDKEventListener {
    private final AmazonAdSDKBridge bridge;
    
    public AmazonAdSDKEventListener(AmazonAdSDKBridge param1AmazonAdSDKBridge) {
      this.bridge = param1AmazonAdSDKBridge;
    }
    
    public void onSDKEvent(SDKEvent param1SDKEvent, AdControlAccessor param1AdControlAccessor) {
      if (param1SDKEvent.getEventType().equals(SDKEvent.SDKEventType.BACK_BUTTON_PRESSED))
        this.bridge.onBackButton(); 
    }
  }
  
  private static class EnableCloseButtonJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "EnableCloseButton";
    
    private final AmazonAdSDKBridge bridge;
    
    public EnableCloseButtonJSIF(AmazonAdSDKBridge param1AmazonAdSDKBridge) {
      super("EnableCloseButton");
      this.bridge = param1AmazonAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.enableCloseButton(JSONUtils.getBooleanFromJSON(param1JSONObject, "enable", true));
      return null;
    }
  }
  
  private static class OverrideBackButtonJSIF extends JavascriptInteractor.JavascriptMethodExecutor {
    private static final String name = "OverrideBackButton";
    
    private final AmazonAdSDKBridge bridge;
    
    public OverrideBackButtonJSIF(AmazonAdSDKBridge param1AmazonAdSDKBridge) {
      super("OverrideBackButton");
      this.bridge = param1AmazonAdSDKBridge;
    }
    
    public JSONObject execute(JSONObject param1JSONObject) {
      this.bridge.overrideBackButton(JSONUtils.getBooleanFromJSON(param1JSONObject, "override", false));
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AmazonAdSDKBridge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */