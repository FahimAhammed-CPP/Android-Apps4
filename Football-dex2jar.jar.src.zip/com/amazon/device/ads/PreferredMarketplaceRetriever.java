package com.amazon.device.ads;

import android.content.Context;

interface PreferredMarketplaceRetriever {
  String retrievePreferredMarketplace(Context paramContext);
  
  public static class NullPreferredMarketplaceRetriever implements PreferredMarketplaceRetriever {
    public String retrievePreferredMarketplace(Context param1Context) {
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\PreferredMarketplaceRetriever.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */