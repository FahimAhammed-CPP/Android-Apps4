package com.amazon.device.ads;

import java.util.HashMap;

enum RelativePosition {
  BOTTOM_CENTER, BOTTOM_LEFT, BOTTOM_RIGHT, CENTER, TOP_CENTER, TOP_LEFT, TOP_RIGHT;
  
  private static final HashMap<String, RelativePosition> POSITIONS;
  
  static {
    CENTER = new RelativePosition("CENTER", 2);
    BOTTOM_LEFT = new RelativePosition("BOTTOM_LEFT", 3);
    BOTTOM_RIGHT = new RelativePosition("BOTTOM_RIGHT", 4);
    TOP_CENTER = new RelativePosition("TOP_CENTER", 5);
    BOTTOM_CENTER = new RelativePosition("BOTTOM_CENTER", 6);
    $VALUES = new RelativePosition[] { TOP_LEFT, TOP_RIGHT, CENTER, BOTTOM_LEFT, BOTTOM_RIGHT, TOP_CENTER, BOTTOM_CENTER };
    POSITIONS = new HashMap<String, RelativePosition>();
    POSITIONS.put("top-left", TOP_LEFT);
    POSITIONS.put("top-right", TOP_RIGHT);
    POSITIONS.put("top-center", TOP_CENTER);
    POSITIONS.put("bottom-left", BOTTOM_LEFT);
    POSITIONS.put("bottom-right", BOTTOM_RIGHT);
    POSITIONS.put("bottom-center", BOTTOM_CENTER);
    POSITIONS.put("center", CENTER);
  }
  
  public static RelativePosition fromString(String paramString) {
    return POSITIONS.get(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\RelativePosition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */