package com.amazon.device.ads;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

class Configuration {
  private static final String AAX_MSDK_CONFIG_ENDPOINT = "/msdk/getConfig";
  
  private static final String AAX_PROD_US_HOSTNAME = "mads.amazon-adsystem.com";
  
  protected static final String CONFIG_APP_DEFINED_MARKETPLACE = "config-appDefinedMarketplace";
  
  protected static final String CONFIG_LASTFETCHTIME = "config-lastFetchTime";
  
  protected static final String CONFIG_TTL = "config-ttl";
  
  protected static final String CONFIG_VERSION_NAME = "configVersion";
  
  protected static final int CURRENT_CONFIG_VERSION = 1;
  
  private static final String LOG_TAG = Configuration.class.getSimpleName();
  
  protected static final int MAX_CONFIG_TTL = 172800;
  
  protected static final int MAX_NO_RETRY_TTL = 300000;
  
  private static Configuration instance = new Configuration();
  
  private String appDefinedMarketplace = null;
  
  private boolean isAppDefinedMarketplaceSet = false;
  
  private AtomicBoolean isFetching = null;
  
  private boolean isFirstParty = false;
  
  private Boolean lastTestModeValue = null;
  
  private List<ConfigurationListener> listeners = null;
  
  private PreferredMarketplaceRetriever pfmRetriever = new PreferredMarketplaceRetriever.NullPreferredMarketplaceRetriever();
  
  protected Configuration() {
    this.listeners = new ArrayList<ConfigurationListener>(5);
    this.isFetching = new AtomicBoolean(false);
  }
  
  public static final Configuration getInstance() {
    return instance;
  }
  
  public static int getMaxNoRetryTtl() {
    return DebugProperties.getInstance().getDebugPropertyAsInteger("debug.noRetryTTLMax", 300000);
  }
  
  private String getPreferredMarketplace() {
    return this.pfmRetriever.retrievePreferredMarketplace(AmazonRegistration.getInstance().getApplicationContext());
  }
  
  private boolean hasAppDefinedMarketplaceChanged() {
    Settings settings = Settings.getInstance();
    String str = settings.getString("config-appDefinedMarketplace", null);
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (this.isAppDefinedMarketplaceSet) {
      this.isAppDefinedMarketplaceSet = false;
      if (this.appDefinedMarketplace != null && !this.appDefinedMarketplace.equals(str)) {
        settings.putLongWithNoFlush("config-lastFetchTime", 0L);
        settings.putStringWithNoFlush("config-appDefinedMarketplace", this.appDefinedMarketplace);
        settings.flush();
        AmazonRegistration.getInstance().getRegistrationInfo().requestNewSISDeviceIdentifier();
        Log.d(LOG_TAG, "New application-defined marketplace set. A new configuration will be retrieved.", new Object[0]);
        return true;
      } 
    } else {
      return bool1;
    } 
    bool1 = bool2;
    if (str != null) {
      bool1 = bool2;
      if (this.appDefinedMarketplace == null) {
        settings.remove("config-appDefinedMarketplace");
        AmazonRegistration.getInstance().getRegistrationInfo().requestNewSISDeviceIdentifier();
        Log.d(LOG_TAG, "Application-defined marketplace removed. A new configuration will be retrieved.", new Object[0]);
        return true;
      } 
    } 
    return bool1;
  }
  
  private void writeSettingFromConfigOption(ConfigOption paramConfigOption, JSONObject paramJSONObject) throws Exception {
    String str;
    if (paramConfigOption.getDataType().equals(String.class)) {
      str = paramJSONObject.getString(paramConfigOption.getResponseKey());
      if (!paramConfigOption.getAllowEmpty() && StringUtils.isNullOrWhiteSpace(str))
        throw new IllegalArgumentException("The configuration value must not be empty or contain only white spaces."); 
      Settings.getInstance().putStringWithNoFlush(paramConfigOption.getSettingsName(), str);
      return;
    } 
    if (paramConfigOption.getDataType().equals(Boolean.class)) {
      boolean bool = str.getBoolean(paramConfigOption.getResponseKey());
      Settings.getInstance().putBooleanWithNoFlush(paramConfigOption.getSettingsName(), bool);
      return;
    } 
    throw new IllegalArgumentException("Undefined configuration option type.");
  }
  
  protected void beginFetch() {
    ThreadUtils.executeRunnable(new Runnable() {
          public void run() {
            Configuration.this.fetchConfigurationOnBackgroundThread();
          }
        });
  }
  
  AdvertisingIdentifier.Info createAdvertisingIdentifierInfo() {
    boolean bool = false;
    AdvertisingIdentifier advertisingIdentifier = new AdvertisingIdentifier();
    if (Settings.getInstance().getInt("configVersion", 0) != 0)
      bool = true; 
    return advertisingIdentifier.setShouldSetCurrentAdvertisingIdentifier(bool).getAdvertisingIdentifierInfo();
  }
  
  protected WebRequest createWebRequest(AdvertisingIdentifier.Info paramInfo) {
    WebRequest webRequest = WebRequest.createJSONGetWebRequest();
    webRequest.setExternalLogTag(LOG_TAG);
    webRequest.enableLog(true);
    webRequest.setHost(DebugProperties.getInstance().getDebugPropertyAsString("debug.aaxConfigHostname", "mads.amazon-adsystem.com"));
    webRequest.setPath("/msdk/getConfig");
    webRequest.setMetricsCollector(Metrics.getInstance().getMetricsCollector());
    webRequest.setServiceCallLatencyMetric(Metrics.MetricType.AAX_CONFIG_DOWNLOAD_LATENCY);
    webRequest.setUseSecure(DebugProperties.getInstance().getDebugPropertyAsBoolean("debug.aaxConfigUseSecure", true));
    RegistrationInfo registrationInfo = AmazonRegistration.getInstance().getRegistrationInfo();
    DeviceInfo deviceInfo = AmazonRegistration.getInstance().getDeviceInfo();
    webRequest.putUnencodedQueryParameter("appId", registrationInfo.getAppKey());
    webRequest.putUnencodedQueryParameter("dinfo", deviceInfo.getDInfoProperty().toString());
    webRequest.putUnencodedQueryParameter("adId", paramInfo.getSISDeviceIdentifier());
    webRequest.putUnencodedQueryParameter("sdkVer", Version.getSDKVersion());
    webRequest.putUnencodedQueryParameter("fp", Boolean.toString(this.isFirstParty));
    webRequest.putUnencodedQueryParameter("mkt", Settings.getInstance().getString("config-appDefinedMarketplace", null));
    webRequest.putUnencodedQueryParameter("pfm", getPreferredMarketplace());
    boolean bool = Settings.getInstance().getBoolean("testingEnabled", false);
    setLastTestModeValue(bool);
    if (bool)
      webRequest.putUnencodedQueryParameter("testMode", "true"); 
    webRequest.setAdditionalQueryParamsString(DebugProperties.getInstance().getDebugPropertyAsString("debug.aaxConfigParams", null));
    return webRequest;
  }
  
  protected void fetchConfigurationOnBackgroundThread() {
    Log.d(LOG_TAG, "In configuration fetcher background thread.", new Object[0]);
    if (!PermissionChecker.hasInternetPermission(AmazonRegistration.getInstance().getApplicationContext())) {
      Log.e(LOG_TAG, "Network task cannot commence because the INTERNET permission is missing from the app's manifest.", new Object[0]);
      onFetchFailure();
      return;
    } 
    AdvertisingIdentifier.Info info = createAdvertisingIdentifierInfo();
    if (!info.canDo()) {
      onFetchFailure();
      return;
    } 
    WebRequest webRequest = createWebRequest(info);
    try {
      WebRequest.WebResponse webResponse = webRequest.makeCall();
      JSONObject jSONObject = webResponse.getResponseReader().readAsJSON();
      Settings settings = Settings.getInstance();
      try {
        ConfigOption[] arrayOfConfigOption = getConfigOptions();
        int j = arrayOfConfigOption.length;
        for (int i = 0;; i++) {
          if (i < j) {
            ConfigOption configOption = arrayOfConfigOption[i];
            if (jSONObject.isNull(configOption.getResponseKey())) {
              if (!configOption.getAllowEmpty())
                throw new Exception("The configuration value must be present and not null."); 
              settings.removeWithNoFlush(configOption.getSettingsName());
            } else {
              writeSettingFromConfigOption(configOption, jSONObject);
            } 
          } else {
            if (jSONObject.isNull("ttl"))
              throw new Exception("The configuration value must be present and not null."); 
            i = jSONObject.getInt("ttl");
            j = i;
            if (i > 172800)
              j = 172800; 
            settings.putIntWithNoFlush("config-ttl", j);
            settings.putLongWithNoFlush("config-lastFetchTime", nanoTime());
            settings.putIntWithNoFlush("configVersion", 1);
            settings.flush();
            Log.d(LOG_TAG, "Configuration fetched and saved.", new Object[0]);
            onFetchSuccess();
            return;
          } 
        } 
      } catch (JSONException jSONException) {
        Log.e(LOG_TAG, "Unable to parse JSON response: %s", new Object[] { jSONException.getMessage() });
        onFetchFailure();
        return;
      } catch (Exception exception) {
        Log.e(LOG_TAG, "Unexpected error during parsing: %s", new Object[] { exception.getMessage() });
        onFetchFailure();
      } 
    } catch (WebRequestException webRequestException) {
      onFetchFailure();
      return;
    } 
  }
  
  protected ConfigurationListener[] getAndClearListeners() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield listeners : Ljava/util/List;
    //   6: invokeinterface size : ()I
    //   11: anewarray com/amazon/device/ads/Configuration$ConfigurationListener
    //   14: astore_1
    //   15: aload_0
    //   16: getfield listeners : Ljava/util/List;
    //   19: aload_1
    //   20: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   25: checkcast [Lcom/amazon/device/ads/Configuration$ConfigurationListener;
    //   28: astore_1
    //   29: aload_0
    //   30: getfield listeners : Ljava/util/List;
    //   33: invokeinterface clear : ()V
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   2	38	42	finally
  }
  
  public String getAppDefinedMarketplace() {
    return this.appDefinedMarketplace;
  }
  
  public boolean getBoolean(ConfigOption paramConfigOption) {
    return getBooleanWithDefault(paramConfigOption, false);
  }
  
  public boolean getBooleanWithDefault(ConfigOption paramConfigOption, boolean paramBoolean) {
    return DebugProperties.getInstance().containsDebugProperty(paramConfigOption.getDebugProperty()) ? DebugProperties.getInstance().getDebugPropertyAsBoolean(paramConfigOption.getDebugProperty(), paramBoolean) : Settings.getInstance().getBoolean(paramConfigOption.getSettingsName(), paramBoolean);
  }
  
  protected ConfigOption[] getConfigOptions() {
    return ConfigOption.configOptions;
  }
  
  PreferredMarketplaceRetriever getPreferredMarketplaceRetriever() {
    return this.pfmRetriever;
  }
  
  public String getString(ConfigOption paramConfigOption) {
    String str2 = DebugProperties.getInstance().getDebugPropertyAsString(paramConfigOption.getDebugProperty(), null);
    String str1 = str2;
    if (str2 == null)
      str1 = Settings.getInstance().getString(paramConfigOption.getSettingsName(), null); 
    return str1;
  }
  
  public boolean hasValue(ConfigOption paramConfigOption) {
    return !StringUtils.isNullOrWhiteSpace(getString(paramConfigOption));
  }
  
  protected boolean isFetching() {
    return this.isFetching.get();
  }
  
  boolean isFirstParty() {
    return this.isFirstParty;
  }
  
  protected long nanoTime() {
    return System.nanoTime();
  }
  
  protected void onFetchFailure() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic getInstance : ()Lcom/amazon/device/ads/Metrics;
    //   5: invokevirtual getMetricsCollector : ()Lcom/amazon/device/ads/MetricsCollector;
    //   8: getstatic com/amazon/device/ads/Metrics$MetricType.AAX_CONFIG_DOWNLOAD_FAILED : Lcom/amazon/device/ads/Metrics$MetricType;
    //   11: invokevirtual incrementMetric : (Lcom/amazon/device/ads/Metrics$MetricType;)V
    //   14: aload_0
    //   15: iconst_0
    //   16: invokevirtual setIsFetching : (Z)V
    //   19: aload_0
    //   20: invokevirtual getAndClearListeners : ()[Lcom/amazon/device/ads/Configuration$ConfigurationListener;
    //   23: astore_3
    //   24: aload_3
    //   25: arraylength
    //   26: istore_2
    //   27: iconst_0
    //   28: istore_1
    //   29: iload_1
    //   30: iload_2
    //   31: if_icmpge -> 49
    //   34: aload_3
    //   35: iload_1
    //   36: aaload
    //   37: invokeinterface onConfigurationFailure : ()V
    //   42: iload_1
    //   43: iconst_1
    //   44: iadd
    //   45: istore_1
    //   46: goto -> 29
    //   49: aload_0
    //   50: monitorexit
    //   51: return
    //   52: astore_3
    //   53: aload_0
    //   54: monitorexit
    //   55: aload_3
    //   56: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	52	finally
    //   34	42	52	finally
  }
  
  protected void onFetchSuccess() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: invokevirtual setIsFetching : (Z)V
    //   7: aload_0
    //   8: invokevirtual getAndClearListeners : ()[Lcom/amazon/device/ads/Configuration$ConfigurationListener;
    //   11: astore_3
    //   12: aload_3
    //   13: arraylength
    //   14: istore_2
    //   15: iconst_0
    //   16: istore_1
    //   17: iload_1
    //   18: iload_2
    //   19: if_icmpge -> 37
    //   22: aload_3
    //   23: iload_1
    //   24: aaload
    //   25: invokeinterface onConfigurationReady : ()V
    //   30: iload_1
    //   31: iconst_1
    //   32: iadd
    //   33: istore_1
    //   34: goto -> 17
    //   37: aload_0
    //   38: monitorexit
    //   39: return
    //   40: astore_3
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_3
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	40	finally
    //   22	30	40	finally
  }
  
  public void queueConfigurationListener(ConfigurationListener paramConfigurationListener) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iconst_1
    //   5: invokevirtual queueConfigurationListener : (Lcom/amazon/device/ads/Configuration$ConfigurationListener;Z)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
  }
  
  public void queueConfigurationListener(ConfigurationListener paramConfigurationListener, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual isFetching : ()Z
    //   6: ifeq -> 23
    //   9: aload_0
    //   10: getfield listeners : Ljava/util/List;
    //   13: aload_1
    //   14: invokeinterface add : (Ljava/lang/Object;)Z
    //   19: pop
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: aload_0
    //   24: invokevirtual shouldFetch : ()Z
    //   27: ifeq -> 75
    //   30: aload_0
    //   31: getfield listeners : Ljava/util/List;
    //   34: aload_1
    //   35: invokeinterface add : (Ljava/lang/Object;)Z
    //   40: pop
    //   41: iload_2
    //   42: ifeq -> 20
    //   45: getstatic com/amazon/device/ads/Configuration.LOG_TAG : Ljava/lang/String;
    //   48: ldc_w 'Starting configuration fetching...'
    //   51: iconst_0
    //   52: anewarray java/lang/Object
    //   55: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   58: aload_0
    //   59: iconst_1
    //   60: invokevirtual setIsFetching : (Z)V
    //   63: aload_0
    //   64: invokevirtual beginFetch : ()V
    //   67: goto -> 20
    //   70: astore_1
    //   71: aload_0
    //   72: monitorexit
    //   73: aload_1
    //   74: athrow
    //   75: aload_1
    //   76: invokeinterface onConfigurationReady : ()V
    //   81: goto -> 20
    // Exception table:
    //   from	to	target	type
    //   2	20	70	finally
    //   23	41	70	finally
    //   45	67	70	finally
    //   75	81	70	finally
  }
  
  public void setAppDefinedMarketplace(String paramString) {
    this.appDefinedMarketplace = paramString;
    this.isAppDefinedMarketplaceSet = true;
  }
  
  protected void setIsFetching(boolean paramBoolean) {
    this.isFetching.set(paramBoolean);
  }
  
  public void setIsFirstParty(boolean paramBoolean) {
    this.isFirstParty = paramBoolean;
  }
  
  protected void setLastTestModeValue(boolean paramBoolean) {
    this.lastTestModeValue = Boolean.valueOf(paramBoolean);
  }
  
  public void setPreferredMarketplaceRetriever(PreferredMarketplaceRetriever paramPreferredMarketplaceRetriever) {
    this.pfmRetriever = paramPreferredMarketplaceRetriever;
  }
  
  protected boolean shouldFetch() {
    Settings settings = Settings.getInstance();
    if (!hasAppDefinedMarketplaceChanged() && Settings.getInstance().getInt("configVersion", 0) == 1) {
      long l1 = nanoTime();
      long l2 = settings.getLong("config-lastFetchTime", 0L);
      long l3 = settings.getInt("config-ttl", 172800);
      if (l2 == 0L) {
        Log.d(LOG_TAG, "No configuration found. A new configuration will be retrieved.", new Object[0]);
        return true;
      } 
      if (l1 - l2 > NumberUtils.convertToNsFromS(l3)) {
        Log.d(LOG_TAG, "The configuration has expired. A new configuration will be retrieved.", new Object[0]);
        return true;
      } 
      if (this.lastTestModeValue != null && this.lastTestModeValue.booleanValue() != settings.getBoolean("testingEnabled", false)) {
        Log.d(LOG_TAG, "The testing mode has changed. A new configuration will be retrieved.", new Object[0]);
        return true;
      } 
      if (!DebugProperties.getInstance().getDebugPropertyAsBoolean("debug.shouldFetchConfig", false))
        return false; 
    } 
    return true;
  }
  
  public static class ConfigOption {
    public static final ConfigOption AAX_HOSTNAME = new ConfigOption("config-aaxHostname", String.class, "aaxHostname", "debug.aaxHostname");
    
    public static final ConfigOption AD_PREF_URL = new ConfigOption("config-adPrefURL", String.class, "adPrefURL", "debug.adPrefURL");
    
    public static final ConfigOption MADS_HOSTNAME = new ConfigOption("config-madsHostname", String.class, "madsHostname", "debug.madsHostname", true);
    
    public static final ConfigOption SEND_GEO;
    
    public static final ConfigOption SIS_DOMAIN = new ConfigOption("config-sisDomain", String.class, "sisDomain", "debug.sisDomain");
    
    public static final ConfigOption SIS_URL = new ConfigOption("config-sisURL", String.class, "sisURL", "debug.sisURL");
    
    public static final ConfigOption[] configOptions;
    
    private final boolean allowEmpty;
    
    private final Class<?> dataType;
    
    private final String debugProperty;
    
    private final String responseKey;
    
    private final String settingsName;
    
    static {
      SEND_GEO = new ConfigOption("config-sendGeo", Boolean.class, "sendGeo", "debug.sendGeo");
      configOptions = new ConfigOption[] { AAX_HOSTNAME, SIS_URL, AD_PREF_URL, MADS_HOSTNAME, SIS_DOMAIN, SEND_GEO };
    }
    
    protected ConfigOption(String param1String1, Class<?> param1Class, String param1String2, String param1String3) {
      this(param1String1, param1Class, param1String2, param1String3, false);
    }
    
    protected ConfigOption(String param1String1, Class<?> param1Class, String param1String2, String param1String3, boolean param1Boolean) {
      this.settingsName = param1String1;
      this.responseKey = param1String2;
      this.dataType = param1Class;
      this.debugProperty = param1String3;
      this.allowEmpty = param1Boolean;
    }
    
    boolean getAllowEmpty() {
      return this.allowEmpty;
    }
    
    Class<?> getDataType() {
      return this.dataType;
    }
    
    String getDebugProperty() {
      return this.debugProperty;
    }
    
    String getResponseKey() {
      return this.responseKey;
    }
    
    String getSettingsName() {
      return this.settingsName;
    }
  }
  
  static interface ConfigurationListener {
    void onConfigurationFailure();
    
    void onConfigurationReady();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Configuration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */