package com.amazon.device.ads;

class Base64 {
  private static final String ENCODE_CHARSET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  
  public static byte[] decode(String paramString) {
    if (StringUtils.isNullOrWhiteSpace(paramString))
      throw new IllegalArgumentException("Encoded String must not be null or white space"); 
    int k = getDecodedLength(paramString);
    if (k <= 0)
      throw new IllegalArgumentException("Encoded String decodes to zero bytes"); 
    byte[] arrayOfByte = new byte[k];
    int i = 0;
    int j = 0;
    while (true) {
      if (j < paramString.length() && i < k && (j % 4 != 0 || paramString.length() >= j + 4)) {
        int m = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".indexOf(paramString.charAt(j));
        if (m != -1) {
          int n;
          switch (j % 4) {
            case 0:
              arrayOfByte[i] = (byte)(m << 2);
              j++;
              break;
            case 1:
              n = i + 1;
              arrayOfByte[i] = (byte)(arrayOfByte[i] | (byte)(m >> 4 & 0x3));
              i = n;
              if (n < k) {
                arrayOfByte[n] = (byte)(m << 4);
                i = n;
              } 
              j++;
              break;
            case 2:
              n = i + 1;
              arrayOfByte[i] = (byte)(arrayOfByte[i] | (byte)(m >> 2 & 0xF));
              i = n;
              if (n < k) {
                arrayOfByte[n] = (byte)(m << 6);
                i = n;
              } 
              j++;
              break;
            case 3:
              n = i + 1;
              arrayOfByte[i] = (byte)(arrayOfByte[i] | (byte)(m & 0x3F));
              i = n;
              j++;
              break;
          } 
          continue;
        } 
      } 
      return arrayOfByte;
    } 
  }
  
  private static int getDecodedLength(String paramString) {
    int j = paramString.indexOf("=");
    int i = 0;
    if (j > -1)
      i = paramString.length() - j; 
    return (paramString.length() + 3) / 4 * 3 - i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Base64.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */