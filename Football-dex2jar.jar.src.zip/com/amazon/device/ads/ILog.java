package com.amazon.device.ads;

interface ILog {
  void d(String paramString1, String paramString2, Object... paramVarArgs);
  
  void e(String paramString1, String paramString2, Object... paramVarArgs);
  
  void i(String paramString1, String paramString2, Object... paramVarArgs);
  
  void v(String paramString1, String paramString2, Object... paramVarArgs);
  
  void w(String paramString1, String paramString2, Object... paramVarArgs);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ILog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */