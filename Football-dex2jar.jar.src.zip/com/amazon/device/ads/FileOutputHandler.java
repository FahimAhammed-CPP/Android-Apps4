package com.amazon.device.ads;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

class FileOutputHandler extends FileHandler {
  private static final String LOGTAG = FileOutputHandler.class.getSimpleName();
  
  private BufferedWriter bufferedWriter;
  
  private OutputStream outputStream;
  
  private WriteMethod writeMethod;
  
  private void checkWritable() {
    if (this.bufferedWriter == null)
      throw new IllegalStateException("Could not write to the file because no file has been opened yet. Please set the file, then call open() before attempting to write."); 
  }
  
  private boolean writeToFile(String paramString, WriteMethod paramWriteMethod) {
    if (isOpen()) {
      if (!paramWriteMethod.equals(this.writeMethod)) {
        close();
        if (!open(paramWriteMethod)) {
          Log.e(LOGTAG, "Could not reopen the file for %s.", new Object[] { paramWriteMethod.toString() });
          return false;
        } 
      } 
    } else if (!open(paramWriteMethod)) {
      Log.e(LOGTAG, "Could not open the file for writing.", new Object[0]);
      return false;
    } 
    try {
      write(paramString);
      close();
      return true;
    } catch (IOException iOException) {
      Log.e(LOGTAG, "Failed to write data to the file.", new Object[0]);
      return false;
    } 
  }
  
  public boolean appendToFile(String paramString) {
    return writeToFile(paramString, WriteMethod.APPEND);
  }
  
  public void close() {
    flush();
    closeCloseables();
    this.bufferedWriter = null;
    this.outputStream = null;
  }
  
  public void flush() {
    if (this.outputStream != null)
      try {
        this.outputStream.flush();
      } catch (IOException iOException) {
        Log.e(LOGTAG, "Could not flush the OutputStream. %s", new Object[] { iOException.getMessage() });
      }  
    if (this.bufferedWriter != null)
      try {
        this.bufferedWriter.flush();
        return;
      } catch (IOException iOException) {
        Log.e(LOGTAG, "Could not flush the BufferedWriter. %s", new Object[] { iOException.getMessage() });
        return;
      }  
  }
  
  protected Closeable getCloseableReaderWriter() {
    return this.bufferedWriter;
  }
  
  protected Closeable getCloseableStream() {
    return this.outputStream;
  }
  
  public boolean isOpen() {
    return (this.outputStream != null);
  }
  
  public boolean open(WriteMethod paramWriteMethod) {
    if (this.file == null) {
      Log.e(LOGTAG, "A file must be set before it can be opened.", new Object[0]);
      return false;
    } 
    if (this.outputStream != null) {
      Log.e(LOGTAG, "The file is already open.", new Object[0]);
      return false;
    } 
    try {
      FileOutputStream fileOutputStream = new FileOutputStream(this.file, WriteMethod.APPEND.equals(paramWriteMethod));
      this.writeMethod = paramWriteMethod;
      this.outputStream = new BufferedOutputStream(fileOutputStream);
      this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(this.outputStream));
      return true;
    } catch (Exception exception) {
      return false;
    } 
  }
  
  public boolean overwriteFile(String paramString) {
    return writeToFile(paramString, WriteMethod.OVERWRITE);
  }
  
  public void write(String paramString) throws IOException {
    checkWritable();
    this.bufferedWriter.write(paramString);
  }
  
  public void write(byte[] paramArrayOfbyte) throws IOException {
    checkWritable();
    this.outputStream.write(paramArrayOfbyte);
  }
  
  public enum WriteMethod {
    APPEND, OVERWRITE;
    
    static {
    
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\FileOutputHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */