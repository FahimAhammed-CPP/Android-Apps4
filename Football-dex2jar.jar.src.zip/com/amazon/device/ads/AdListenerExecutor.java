package com.amazon.device.ads;

class AdListenerExecutor {
  private final AdListener adListener;
  
  private final ThreadUtils.RunnableExecutor runnableExecutor;
  
  public AdListenerExecutor(AdListener paramAdListener) {
    this(paramAdListener, new ThreadUtils.MainThreadRunnableExecutor());
  }
  
  AdListenerExecutor(AdListener paramAdListener, ThreadUtils.RunnableExecutor paramRunnableExecutor) {
    this.adListener = paramAdListener;
    this.runnableExecutor = paramRunnableExecutor;
  }
  
  private void execute(Runnable paramRunnable) {
    this.runnableExecutor.execute(paramRunnable);
  }
  
  public void onAdFailedToLoad(final Ad ad, final AdError adError) {
    execute(new Runnable() {
          public void run() {
            AdListenerExecutor.this.adListener.onAdFailedToLoad(ad, adError);
          }
        });
  }
  
  public void onAdLoaded(final Ad ad, final AdProperties adProperties) {
    execute(new Runnable() {
          public void run() {
            AdListenerExecutor.this.adListener.onAdLoaded(ad, adProperties);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdListenerExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */