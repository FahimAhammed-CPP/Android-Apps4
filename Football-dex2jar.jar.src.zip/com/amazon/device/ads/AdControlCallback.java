package com.amazon.device.ads;

interface AdControlCallback {
  public static final int CLOSE_EVENT_ONLY = 0;
  
  public static final int CLOSE_FULL = 1;
  
  public static final int NO_CLOSE = 2;
  
  int adClosing();
  
  boolean isAdReady(boolean paramBoolean);
  
  void onAdEvent(AdEvent paramAdEvent);
  
  void onAdFailed(AdError paramAdError);
  
  void onAdLoaded(AdProperties paramAdProperties);
  
  void onAdRendered();
  
  void postAdRendered();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdControlCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */