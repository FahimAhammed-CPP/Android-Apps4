package com.amazon.device.ads;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class AdActivity extends Activity {
  static final String ADAPTER_KEY = "adapter";
  
  private static final String LOG_TAG = "AdAdapter";
  
  private IAdActivityAdapter adapter;
  
  IAdActivityAdapter createAdapter() {
    String str = getIntent().getStringExtra("adapter");
    if (str == null) {
      Log.e("AdAdapter", "Unable to launch the AdActivity due to an internal error.", new Object[0]);
      return null;
    } 
    try {
      Class<?> clazz = Class.forName(str);
      try {
        Constructor<?> constructor = clazz.getDeclaredConstructor(new Class[0]);
        try {
          return (IAdActivityAdapter)constructor.newInstance(new Object[0]);
        } catch (IllegalArgumentException illegalArgumentException) {
          Log.e("AdAdapter", "Illegal arguments given to the default constructor.", new Object[0]);
          return null;
        } catch (InstantiationException instantiationException) {
          Log.e("AdAdapter", "Instantiation exception when instantiating the adapter.", new Object[0]);
          return null;
        } catch (IllegalAccessException illegalAccessException) {
          Log.e("AdAdapter", "Illegal access exception when instantiating the adapter.", new Object[0]);
          return null;
        } catch (InvocationTargetException invocationTargetException) {
          Log.e("AdAdapter", "Invocation target exception when instantiating the adapter.", new Object[0]);
          return null;
        } 
      } catch (SecurityException securityException) {
        Log.e("AdAdapter", "Security exception when trying to get the default constructor.", new Object[0]);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("AdAdapter", "No default constructor exists for the adapter.", new Object[0]);
        return null;
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      Log.e("AdAdapter", "Unable to get the adapter class.", new Object[0]);
      return null;
    } 
  }
  
  public void onBackPressed() {
    if (!this.adapter.onBackPressed())
      super.onBackPressed(); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.adapter.onConfigurationChanged(paramConfiguration);
  }
  
  public void onCreate(Bundle paramBundle) {
    AmazonAdRegistration.initializeAdSDK(getApplicationContext());
    this.adapter = createAdapter();
    if (this.adapter == null) {
      super.onCreate(paramBundle);
      finish();
      return;
    } 
    this.adapter.setActivity(this);
    this.adapter.preOnCreate();
    super.onCreate(paramBundle);
    this.adapter.onCreate();
  }
  
  public void onPause() {
    super.onPause();
    this.adapter.onPause();
  }
  
  public void onResume() {
    super.onResume();
    this.adapter.onResume();
  }
  
  public void onStop() {
    this.adapter.onStop();
    super.onStop();
  }
  
  public static interface IAdActivityAdapter {
    boolean onBackPressed();
    
    void onConfigurationChanged(Configuration param1Configuration);
    
    void onCreate();
    
    void onPause();
    
    void onResume();
    
    void onStop();
    
    void preOnCreate();
    
    void setActivity(Activity param1Activity);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */