package com.amazon.device.ads;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

public class ModelessInterstitialAd implements Ad {
  private static final String LOG_TAG = ModelessInterstitialAd.class.getSimpleName();
  
  private static final String PUBLISHER_KEYWORD = "modeless-interstitial";
  
  private static final int minPixels = 380;
  
  private static final double minScreenCoveragePercentage = 0.75D;
  
  private AdController adController;
  
  private final AdControllerFactory adControllerFactory;
  
  private AdListenerExecutor adListenerExecutor;
  
  private AdProperties adProperties;
  
  private final AmazonAdRegistration amazonAdRegistration;
  
  private final Context context;
  
  private final ViewGroup hostedViewGroup;
  
  private final Log2 log;
  
  private MetricsCollector metricsCollector;
  
  private int timeout;
  
  public ModelessInterstitialAd(ViewGroup paramViewGroup) {
    this(paramViewGroup, AmazonAdRegistration.getInstance(), new AdControllerFactory(), new Log2());
  }
  
  ModelessInterstitialAd(ViewGroup paramViewGroup, AmazonAdRegistration paramAmazonAdRegistration, AdControllerFactory paramAdControllerFactory, Log2 paramLog2) {
    if (paramViewGroup == null)
      throw new IllegalArgumentException("The hostedViewGroup must not be null."); 
    this.hostedViewGroup = paramViewGroup;
    this.context = this.hostedViewGroup.getContext();
    this.amazonAdRegistration = paramAmazonAdRegistration;
    this.adControllerFactory = paramAdControllerFactory;
    this.log = paramLog2;
    initialize();
  }
  
  private void buildAdController() {
    this.adController = this.adControllerFactory.buildAdController(this.context, AdSize.SIZE_MODELESS_INTERSTITIAL);
    this.adController.setCallback(new ModelessInterstitialAdControlCallback());
    this.metricsCollector = this.adController.getMetricsCollector();
    this.metricsCollector.setAdType(AdProperties.AdType.MODELESS_INTERSTITIAL);
    this.metricsCollector.incrementMetric(Metrics.MetricType.AD_IS_INTERSTITIAL);
  }
  
  private void checkIfAdAspectRatioLessThanScreenAspectRatio(Size paramSize1, Size paramSize2) {
    boolean bool2 = true;
    boolean bool1 = true;
    float f1 = paramSize1.getWidth();
    float f2 = paramSize1.getHeight();
    float f3 = paramSize2.getWidth();
    float f4 = paramSize2.getHeight();
    if (f1 <= f2) {
      if (f1 / f2 >= f3 / f4)
        bool1 = false; 
    } else if (f2 / f1 < f4 / f3) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    if (bool1) {
      this.metricsCollector.incrementMetric(Metrics.MetricType.AD_ASPECT_RATIO_LESS_THAN_SCREEN_ASPECT_RATIO);
      this.log.w(LOG_TAG, "For an optimal ad experience, the aspect ratio of the ModelessInterstitialAd should be greater than or equal to the aspect ratio of the screen.", new Object[0]);
    } 
  }
  
  private boolean doesAdSizeHaveOneSideWithAtLeastMinPixels(Size paramSize) {
    if (paramSize.getHeight() >= 380 || paramSize.getWidth() >= 380)
      return true; 
    this.log.e(LOG_TAG, "The ModelessInterstitialAd with height %d and width %d does not meet the requirement of one side being at least %d device independent pixels in order to fire impression pixel and receive clicks.", new Object[] { Integer.valueOf(paramSize.getHeight()), Integer.valueOf(paramSize.getWidth()), Integer.valueOf(380) });
    return false;
  }
  
  private boolean doesAdSizeMeetRequiredScreenPercentage(Size paramSize1, Size paramSize2) {
    double d = paramSize1.getHeight() * paramSize1.getWidth() / paramSize2.getHeight() * paramSize2.getWidth();
    if (d >= 0.75D)
      return true; 
    this.log.e(LOG_TAG, "The ModelessInterstitialAd has a screen coverage percentage of %f which does not meet the requirement of being at least %d to fire impression pixel and receive clicks.", new Object[] { Double.valueOf(100.0D * d), Integer.valueOf(75) });
    return false;
  }
  
  private void initialize() {
    this.amazonAdRegistration.initializeAds(this.context.getApplicationContext());
    setListener(null);
    buildAdController();
  }
  
  private boolean isAdOnScreen(Position paramPosition, Size paramSize) {
    if (paramPosition.getX() >= 0 && paramPosition.getX() + paramPosition.getSize().getWidth() <= paramSize.getWidth() && paramPosition.getY() >= 0 && paramPosition.getY() + paramPosition.getSize().getHeight() <= paramSize.getHeight())
      return true; 
    this.log.e(LOG_TAG, "The ModelessInterstitialAd does not meet the requirement being fully on screen to fire impression pixel and receive clicks.", new Object[0]);
    return false;
  }
  
  private boolean isReadyToLoad() {
    AdState adState = this.adController.getAdState();
    return (this.adController.isExpired() || adState.equals(AdState.READY_TO_LOAD) || adState.equals(AdState.HIDDEN));
  }
  
  private void onAdFailedToLoadOrRender(AdError paramAdError) {
    if (paramAdError.getCode().equals(AdError.ErrorCode.NETWORK_TIMEOUT)) {
      submitMetrics();
      buildAdController();
    } 
    this.adListenerExecutor.onAdFailedToLoad(this, paramAdError);
  }
  
  private void onAdFetched(AdProperties paramAdProperties) {
    this.adProperties = paramAdProperties;
    this.adController.render();
  }
  
  private void onAdRenderMetricsRecorded() {
    this.metricsCollector.startMetric(Metrics.MetricType.AD_LOADED_TO_AD_SHOW_TIME);
  }
  
  private void onAdRendered() {
    this.hostedViewGroup.addView((View)this.adController.getView());
    setRenderedViewClickable(false);
    this.adListenerExecutor.onAdLoaded(this, this.adProperties);
  }
  
  private void setRenderedViewClickable(boolean paramBoolean) {
    this.adController.setAllowClicks(paramBoolean);
  }
  
  private void submitMetrics() {
    if (!this.adController.getMetricsCollector().isMetricsCollectorEmpty())
      this.adController.submitAndResetMetrics(); 
  }
  
  public void adHidden() {
    AdState adState = this.adController.getAdState();
    if (adState.equals(AdState.HIDDEN)) {
      this.log.d(LOG_TAG, "The ad is already hidden from view.", new Object[0]);
      return;
    } 
    if (adState.equals(AdState.SHOWING)) {
      this.adController.getMetricsCollector().stopMetric(Metrics.MetricType.AD_SHOW_DURATION);
      setRenderedViewClickable(false);
      this.adController.adHidden();
      return;
    } 
    this.log.w(LOG_TAG, "The ad must be shown before it can be hidden.", new Object[0]);
  }
  
  public boolean adShown() {
    Position position;
    AdState adState = this.adController.getAdState();
    if (adState.equals(AdState.LOADING)) {
      this.log.w(LOG_TAG, "The adShown call failed because the ad cannot be shown until it has completed loading.", new Object[0]);
      return false;
    } 
    if (adState.equals(AdState.SHOWING)) {
      this.log.w(LOG_TAG, "The adShown call failed because adShown was previously called on this ad.", new Object[0]);
      return false;
    } 
    if (!adState.equals(AdState.HIDDEN) && this.adController.isExpired()) {
      this.log.e(LOG_TAG, "The ad is unable to be shown because it has expired.", new Object[0]);
      this.metricsCollector.stopMetric(Metrics.MetricType.AD_LOADED_TO_AD_SHOW_TIME);
      this.metricsCollector.incrementMetric(Metrics.MetricType.EXPIRED_AD_CALL);
      return false;
    } 
    if (adState.equals(AdState.RENDERED) || adState.equals(AdState.HIDDEN)) {
      if (adState.equals(AdState.RENDERED))
        this.metricsCollector.stopMetric(Metrics.MetricType.AD_LOADED_TO_AD_SHOW_TIME); 
      position = this.adController.getAdPosition();
      Size size1 = position.getSize();
      Size size2 = this.adController.getScreenSize();
      if (doesAdSizeHaveOneSideWithAtLeastMinPixels(size1) && isAdOnScreen(position, size2) && doesAdSizeMeetRequiredScreenPercentage(size1, size2)) {
        checkIfAdAspectRatioLessThanScreenAspectRatio(size1, size2);
        if (this.adController.getAdState().equals(AdState.HIDDEN))
          this.metricsCollector.incrementMetric(Metrics.MetricType.AD_COUNTER_RESHOWN); 
        setRenderedViewClickable(true);
        this.adController.adShown();
        this.metricsCollector.startMetric(Metrics.MetricType.AD_SHOW_DURATION);
        return true;
      } 
      this.metricsCollector.incrementMetric(Metrics.MetricType.RENDER_REQUIREMENT_CHECK_FAILURE);
      return false;
    } 
    this.log.w(LOG_TAG, "The adShown call failed because the ad is not in a state to be shown. The ad is currently in the %s state.", new Object[] { position });
    return false;
  }
  
  public void destroy() {
    Log.d(LOG_TAG, "Destroying the Modeless Interstitial Ad", new Object[0]);
    if (this.adController.getAdState().equals(AdState.SHOWING))
      adHidden(); 
    submitMetrics();
    this.adController.destroy();
  }
  
  public int getTimeout() {
    return this.timeout;
  }
  
  public boolean isLoading() {
    AdState adState = this.adController.getAdState();
    return (adState.equals(AdState.LOADING) || adState.equals(AdState.LOADED) || adState.equals(AdState.RENDERING));
  }
  
  public boolean loadAd() {
    return loadAd(null);
  }
  
  public boolean loadAd(AdTargetingOptions paramAdTargetingOptions) {
    if (!isReadyToLoad()) {
      switch (this.adController.getAdState()) {
        default:
          this.metricsCollector.incrementMetric(Metrics.MetricType.AD_LOAD_FAILED);
          return false;
        case RENDERED:
        case LOADED:
          Log.w(LOG_TAG, "The modeless interstitial ad has already been loaded. Please call adShown once the ad is shown.", new Object[0]);
        case RENDERING:
        case LOADING:
          Log.w(LOG_TAG, "The modeless interstitial ad is already loading. Please wait for the loading operation to complete.", new Object[0]);
        case DESTROYED:
          break;
      } 
      Log.w(LOG_TAG, "The modeless interstitial ad has been destroyed. Please create a new ModelessInterstitialAd.", new Object[0]);
    } 
    if (paramAdTargetingOptions == null) {
      paramAdTargetingOptions = new AdTargetingOptions();
      paramAdTargetingOptions.addInternalPublisherKeyword("modeless-interstitial");
      submitMetrics();
      AdLoader.loadAds(this.timeout, paramAdTargetingOptions, new AdSlot[] { new AdSlot(this.adController, paramAdTargetingOptions) });
      return this.adController.getAndResetIsPrepared();
    } 
    paramAdTargetingOptions = paramAdTargetingOptions.copy();
    paramAdTargetingOptions.addInternalPublisherKeyword("modeless-interstitial");
    submitMetrics();
    AdLoader.loadAds(this.timeout, paramAdTargetingOptions, new AdSlot[] { new AdSlot(this.adController, paramAdTargetingOptions) });
    return this.adController.getAndResetIsPrepared();
  }
  
  public void setListener(AdListener paramAdListener) {
    AdListener adListener = paramAdListener;
    if (paramAdListener == null)
      adListener = new DefaultAdListener(LOG_TAG); 
    this.adListenerExecutor = new AdListenerExecutor(adListener);
  }
  
  public void setTimeout(int paramInt) {
    this.timeout = paramInt;
  }
  
  private class ModelessInterstitialAdControlCallback implements AdControlCallback {
    private ModelessInterstitialAdControlCallback() {}
    
    public int adClosing() {
      return 2;
    }
    
    public boolean isAdReady(boolean param1Boolean) {
      return ModelessInterstitialAd.this.isReadyToLoad();
    }
    
    public void onAdEvent(AdEvent param1AdEvent) {}
    
    public void onAdFailed(AdError param1AdError) {
      ModelessInterstitialAd.this.onAdFailedToLoadOrRender(param1AdError);
    }
    
    public void onAdLoaded(AdProperties param1AdProperties) {
      ModelessInterstitialAd.this.onAdFetched(param1AdProperties);
    }
    
    public void onAdRendered() {
      ModelessInterstitialAd.this.onAdRendered();
    }
    
    public void postAdRendered() {
      ModelessInterstitialAd.this.onAdRenderMetricsRecorded();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ModelessInterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */