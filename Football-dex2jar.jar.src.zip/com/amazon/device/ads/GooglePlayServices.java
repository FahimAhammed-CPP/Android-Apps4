package com.amazon.device.ads;

class GooglePlayServices {
  private static final String GPS_AVAILABLE_SETTING = "gps-available";
  
  private static final String LOG_TAG = GooglePlayServices.class.getSimpleName();
  
  private boolean isGPSAvailable() {
    return Settings.getInstance().getBoolean("gps-available", true);
  }
  
  private boolean isGPSAvailableSet() {
    return Settings.getInstance().containsKey("gps-available");
  }
  
  private void setGooglePlayServicesAvailable(boolean paramBoolean) {
    Settings.getInstance().putTransientBoolean("gps-available", paramBoolean);
  }
  
  protected GooglePlayServicesAdapter createGooglePlayServicesAdapter() {
    return new GooglePlayServicesAdapter();
  }
  
  public AdvertisingInfo getAdvertisingIdentifierInfo() {
    if (!isGPSAvailable()) {
      Log.v(LOG_TAG, "The Google Play Services Advertising Identifier feature is not available.", new Object[0]);
      return AdvertisingInfo.createNotAvailable();
    } 
    if (!isGPSAvailableSet() && !ReflectionUtils.isClassAvailable("com.google.android.gms.ads.identifier.AdvertisingIdClient")) {
      Log.v(LOG_TAG, "The Google Play Services Advertising Identifier feature is not available.", new Object[0]);
      setGooglePlayServicesAvailable(false);
      return AdvertisingInfo.createNotAvailable();
    } 
    AdvertisingInfo advertisingInfo = createGooglePlayServicesAdapter().getAdvertisingIdentifierInfo();
    setGooglePlayServicesAvailable(advertisingInfo.isGPSAvailable());
    return advertisingInfo;
  }
  
  static class AdvertisingInfo {
    private String advertisingIdentifier;
    
    private boolean gpsAvailable = true;
    
    private boolean limitAdTrackingEnabled;
    
    static AdvertisingInfo createNotAvailable() {
      return (new AdvertisingInfo()).setGPSAvailable(false);
    }
    
    private AdvertisingInfo setGPSAvailable(boolean param1Boolean) {
      this.gpsAvailable = param1Boolean;
      return this;
    }
    
    String getAdvertisingIdentifier() {
      return this.advertisingIdentifier;
    }
    
    boolean hasAdvertisingIdentifier() {
      return (getAdvertisingIdentifier() != null);
    }
    
    boolean isGPSAvailable() {
      return this.gpsAvailable;
    }
    
    boolean isLimitAdTrackingEnabled() {
      return this.limitAdTrackingEnabled;
    }
    
    AdvertisingInfo setAdvertisingIdentifier(String param1String) {
      this.advertisingIdentifier = param1String;
      return this;
    }
    
    AdvertisingInfo setLimitAdTrackingEnabled(boolean param1Boolean) {
      this.limitAdTrackingEnabled = param1Boolean;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\GooglePlayServices.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */