package com.amazon.device.ads;

import java.util.Iterator;
import java.util.Set;

class AdData implements Iterable<AAXCreative> {
  private int adHeight;
  
  private int adWidth;
  
  private String creative;
  
  private Set<AAXCreative> creativeTypes;
  
  private long expirationTimeMs = -1L;
  
  private boolean fetched;
  
  private String impPixelUrl;
  
  private String instrPixelUrl;
  
  private AdProperties properties;
  
  protected String getCreative() {
    return this.creative;
  }
  
  protected Set<AAXCreative> getCreativeTypes() {
    return this.creativeTypes;
  }
  
  public int getHeight() {
    return this.adHeight;
  }
  
  protected String getImpressionPixelUrl() {
    return this.impPixelUrl;
  }
  
  protected String getInstrumentationPixelUrl() {
    return this.instrPixelUrl;
  }
  
  public boolean getIsFetched() {
    return this.fetched;
  }
  
  protected AdProperties getProperties() {
    return this.properties;
  }
  
  public int getWidth() {
    return this.adWidth;
  }
  
  public boolean isExpired() {
    return (this.expirationTimeMs >= 0L && System.currentTimeMillis() > this.expirationTimeMs);
  }
  
  public Iterator<AAXCreative> iterator() {
    return this.creativeTypes.iterator();
  }
  
  protected void setCreative(String paramString) {
    this.creative = paramString;
  }
  
  protected void setCreativeTypes(Set<AAXCreative> paramSet) {
    this.creativeTypes = paramSet;
  }
  
  protected void setExpirationTimeMillis(long paramLong) {
    this.expirationTimeMs = paramLong;
  }
  
  public void setFetched(boolean paramBoolean) {
    this.fetched = paramBoolean;
  }
  
  protected void setHeight(int paramInt) {
    this.adHeight = paramInt;
  }
  
  protected void setImpressionPixelUrl(String paramString) {
    this.impPixelUrl = paramString;
  }
  
  protected void setInstrumentationPixelUrl(String paramString) {
    this.instrPixelUrl = paramString;
  }
  
  protected void setProperties(AdProperties paramAdProperties) {
    this.properties = paramAdProperties;
  }
  
  protected void setWidth(int paramInt) {
    this.adWidth = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */