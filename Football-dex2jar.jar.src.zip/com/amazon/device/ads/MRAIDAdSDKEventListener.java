package com.amazon.device.ads;

import android.app.Activity;
import android.util.Log;

class MRAIDAdSDKEventListener implements SDKEventListener {
  private static final String LOGTAG = MRAIDAdSDKEventListener.class.getSimpleName();
  
  private MRAIDAdSDKBridge mraidAdSDKBridge;
  
  MRAIDAdSDKEventListener(MRAIDAdSDKBridge paramMRAIDAdSDKBridge) {
    this.mraidAdSDKBridge = paramMRAIDAdSDKBridge;
  }
  
  private void handleBridgeAddedEvent(SDKEvent paramSDKEvent, AdControlAccessor paramAdControlAccessor) {
    String str = paramSDKEvent.getParameter("bridgeName");
    if (str != null && str.equals(this.mraidAdSDKBridge.getName())) {
      switch (paramAdControlAccessor.getAdState()) {
        default:
          return;
        case EXPANDED:
        case SHOWING:
          handleReadyEvent(paramAdControlAccessor);
          handleVisibleEvent(paramAdControlAccessor);
          return;
        case RENDERED:
          break;
      } 
      handleReadyEvent(paramAdControlAccessor);
      return;
    } 
  }
  
  private void handleClosedEvent(AdControlAccessor paramAdControlAccessor) {
    if (paramAdControlAccessor.getAdState().equals(AdState.EXPANDED)) {
      this.mraidAdSDKBridge.collapseExpandedAd(paramAdControlAccessor);
      if (((Activity)paramAdControlAccessor.getContext()).getRequestedOrientation() != paramAdControlAccessor.getOriginalOrientation())
        ((Activity)paramAdControlAccessor.getContext()).setRequestedOrientation(paramAdControlAccessor.getOriginalOrientation()); 
      return;
    } 
    if (paramAdControlAccessor.getAdState().equals(AdState.SHOWING)) {
      if (((Activity)paramAdControlAccessor.getContext()).getRequestedOrientation() != paramAdControlAccessor.getOriginalOrientation())
        ((Activity)paramAdControlAccessor.getContext()).setRequestedOrientation(paramAdControlAccessor.getOriginalOrientation()); 
      paramAdControlAccessor.injectJavascript("mraidBridge.stateChange('hidden');");
      paramAdControlAccessor.injectJavascript("mraidBridge.viewableChange('false');");
      return;
    } 
  }
  
  private void handleReadyEvent(AdControlAccessor paramAdControlAccessor) {
    paramAdControlAccessor.injectJavascript("mraidBridge.ready();");
  }
  
  private void handleVisibleEvent(AdControlAccessor paramAdControlAccessor) {
    paramAdControlAccessor.setOriginalOrientation((Activity)paramAdControlAccessor.getContext());
    Size size = paramAdControlAccessor.getMaxSize();
    this.mraidAdSDKBridge.updateExpandProperties(size.getWidth(), size.getHeight());
    Position position = paramAdControlAccessor.getCurrentPosition();
    this.mraidAdSDKBridge.updateDefaultPosition(position.getSize().getWidth(), position.getSize().getHeight(), position.getX(), position.getY());
    this.mraidAdSDKBridge.orientationPropertyChange();
    paramAdControlAccessor.injectJavascript("mraidBridge.stateChange('default');");
    paramAdControlAccessor.injectJavascript("mraidBridge.viewableChange('true');");
  }
  
  public void onSDKEvent(SDKEvent paramSDKEvent, AdControlAccessor paramAdControlAccessor) {
    Log.d(LOGTAG, paramSDKEvent.getEventType().toString());
    switch (paramSDKEvent.getEventType()) {
      default:
        return;
      case EXPANDED:
        handleReadyEvent(paramAdControlAccessor);
        return;
      case SHOWING:
        handleVisibleEvent(paramAdControlAccessor);
        return;
      case RENDERED:
        handleClosedEvent(paramAdControlAccessor);
        return;
      case null:
        this.mraidAdSDKBridge.reportSizeChangeEvent();
        return;
      case null:
      case null:
        paramAdControlAccessor.injectJavascript("mraidBridge.stateChange('hidden');");
        paramAdControlAccessor.injectJavascript("mraidBridge.viewableChange('false');");
        return;
      case null:
        break;
    } 
    handleBridgeAddedEvent(paramSDKEvent, paramAdControlAccessor);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\MRAIDAdSDKEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */