package com.amazon.device.ads;

import android.content.Context;

class WebUtils2 {
  private final WebUtilsStatic webUtilsAdapter = new WebUtilsStatic();
  
  String encloseHtml(String paramString, boolean paramBoolean) {
    return this.webUtilsAdapter.encloseHtml(paramString, paramBoolean);
  }
  
  void executeWebRequestInThread(String paramString, boolean paramBoolean) {
    this.webUtilsAdapter.executeWebRequestInThread(paramString, paramBoolean);
  }
  
  String getScheme(String paramString) {
    return this.webUtilsAdapter.getScheme(paramString);
  }
  
  String getURLDecodedString(String paramString) {
    return this.webUtilsAdapter.getURLDecodedString(paramString);
  }
  
  String getURLEncodedString(String paramString) {
    return this.webUtilsAdapter.getURLEncodedString(paramString);
  }
  
  boolean launchActivityForIntentLink(String paramString, Context paramContext) {
    return this.webUtilsAdapter.launchActivityForIntentLink(paramString, paramContext);
  }
  
  private static class WebUtilsStatic {
    private WebUtilsStatic() {}
    
    String encloseHtml(String param1String, boolean param1Boolean) {
      return WebUtils.encloseHtml(param1String, param1Boolean);
    }
    
    void executeWebRequestInThread(String param1String, boolean param1Boolean) {
      WebUtils.executeWebRequestInThread(param1String, param1Boolean);
    }
    
    String getScheme(String param1String) {
      return WebUtils.getScheme(param1String);
    }
    
    String getURLDecodedString(String param1String) {
      return WebUtils.getURLDecodedString(param1String);
    }
    
    String getURLEncodedString(String param1String) {
      return WebUtils.getURLEncodedString(param1String);
    }
    
    boolean launchActivityForIntentLink(String param1String, Context param1Context) {
      return WebUtils.launchActivityForIntentLink(param1String, param1Context);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\WebUtils2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */