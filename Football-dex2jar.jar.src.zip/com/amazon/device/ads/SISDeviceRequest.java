package com.amazon.device.ads;

import java.util.HashMap;

abstract class SISDeviceRequest implements SISRequest {
  private AdvertisingIdentifier.Info advertisingIdentifierInfo;
  
  private Metrics.MetricType callMetricType;
  
  private String logTag;
  
  private String path;
  
  private static String convertOptOutBooleanToStringInt(boolean paramBoolean) {
    return paramBoolean ? "1" : "0";
  }
  
  public static String getDInfoProperty() {
    DeviceInfo deviceInfo = AmazonRegistration.getInstance().getDeviceInfo();
    return String.format("{\"make\":\"%s\",\"model\":\"%s\",\"os\":\"%s\",\"osVersion\":\"%s\"}", new Object[] { deviceInfo.getMake(), deviceInfo.getModel(), DeviceInfo.getOS(), deviceInfo.getOSVersion() });
  }
  
  protected AdvertisingIdentifier.Info getAdvertisingIdentifierInfo() {
    return this.advertisingIdentifierInfo;
  }
  
  public Metrics.MetricType getCallMetricType() {
    return this.callMetricType;
  }
  
  public String getLogTag() {
    return this.logTag;
  }
  
  public String getPath() {
    return this.path;
  }
  
  public HashMap<String, String> getPostParameters() {
    return null;
  }
  
  public WebRequest.QueryStringParameters getQueryParameters() {
    WebRequest.QueryStringParameters queryStringParameters = new WebRequest.QueryStringParameters();
    queryStringParameters.putUrlEncoded("dt", DeviceInfo.getDeviceType());
    queryStringParameters.putUrlEncoded("app", AmazonRegistration.getInstance().getRegistrationInfo().getAppName());
    queryStringParameters.putUrlEncoded("aud", Configuration.getInstance().getString(Configuration.ConfigOption.SIS_DOMAIN));
    queryStringParameters.putUrlEncoded("ua", WebUtils.getURLEncodedString(AmazonRegistration.getInstance().getDeviceInfo().getUserAgentString()));
    queryStringParameters.putUrlEncoded("dinfo", WebUtils.getURLEncodedString(getDInfoProperty()));
    queryStringParameters.putUrlEncoded("pkg", WebUtils.getURLEncodedString(AmazonRegistration.getInstance().getAppInfo().getPackageInfoJSONString()));
    if (this.advertisingIdentifierInfo.hasAdvertisingIdentifier()) {
      queryStringParameters.putUrlEncoded("idfa", this.advertisingIdentifierInfo.getAdvertisingIdentifier());
      queryStringParameters.putUrlEncoded("oo", convertOptOutBooleanToStringInt(this.advertisingIdentifierInfo.isLimitAdTrackingEnabled()));
    } else {
      DeviceInfo deviceInfo = AmazonRegistration.getInstance().getDeviceInfo();
      queryStringParameters.putUrlEncoded("sha1_mac", deviceInfo.getMacSha1());
      queryStringParameters.putUrlEncoded("sha1_serial", deviceInfo.getSerialSha1());
      queryStringParameters.putUrlEncoded("sha1_udid", deviceInfo.getUdidSha1());
      queryStringParameters.putUrlEncodedIfTrue("badMac", "true", deviceInfo.isMacBad());
      queryStringParameters.putUrlEncodedIfTrue("badSerial", "true", deviceInfo.isSerialBad());
      queryStringParameters.putUrlEncodedIfTrue("badUdid", "true", deviceInfo.isUdidBad());
    } 
    String str = AdvertisingIdentifier.getAndClearTransition();
    if (str != null) {
      boolean bool1 = true;
      queryStringParameters.putUrlEncodedIfTrue("aidts", str, bool1);
      return queryStringParameters;
    } 
    boolean bool = false;
    queryStringParameters.putUrlEncodedIfTrue("aidts", str, bool);
    return queryStringParameters;
  }
  
  public SISDeviceRequest setAdvertisingIdentifierInfo(AdvertisingIdentifier.Info paramInfo) {
    this.advertisingIdentifierInfo = paramInfo;
    return this;
  }
  
  public SISDeviceRequest setCallMetricType(Metrics.MetricType paramMetricType) {
    this.callMetricType = paramMetricType;
    return this;
  }
  
  public SISDeviceRequest setLogTag(String paramString) {
    this.logTag = paramString;
    return this;
  }
  
  public SISDeviceRequest setPath(String paramString) {
    this.path = paramString;
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\SISDeviceRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */