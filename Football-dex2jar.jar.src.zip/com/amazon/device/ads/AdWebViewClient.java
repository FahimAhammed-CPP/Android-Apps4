package com.amazon.device.ads;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

class AdWebViewClient extends WebViewClient {
  protected static final String AAX_REDIRECT_BETA = "aax-beta.integ.amazon.com";
  
  protected static final String AAX_REDIRECT_GAMMA = "aax-us-east.amazon-adsystem.com";
  
  protected static final String AAX_REDIRECT_PROD = "aax-us-east.amazon-adsystem.com";
  
  public static final String AMAZON_MOBILE = "amazonmobile";
  
  protected static final String CORNERSTONE_BEST_ENDPOINT_BETA = "d16g-cornerstone-bes.integ.amazon.com";
  
  protected static final String CORNERSTONE_BEST_ENDPOINT_PROD = "pda-bes.amazon.com";
  
  public static final String GEO = "geo";
  
  public static final String GOOGLE_STREETVIEW = "google.streetview";
  
  private static final String LOG_TAG = AdWebViewClient.class.getSimpleName();
  
  public static final String MAILTO = "mailto";
  
  public static final String SMS = "sms";
  
  public static final String TELEPHONE = "tel";
  
  public static final String VOICEMAIL = "voicemail";
  
  protected static final HashSet<String> intentSchemes = new HashSet<String>();
  
  protected static Set<String> redirectHosts = new HashSet<String>();
  
  private final AdControlAccessor adControlAccessor;
  
  private final AdSDKBridgeList bridgeList;
  
  private final Context context;
  
  private AdWebViewClientListener listener;
  
  private final Log2 log;
  
  private CopyOnWriteArrayList<String> resourceList = new CopyOnWriteArrayList<String>();
  
  private final HashMap<String, UrlExecutor> urlExecutors;
  
  private final WebUtils2 webUtils;
  
  static {
    redirectHosts.add("aax-us-east.amazon-adsystem.com");
    redirectHosts.add("aax-us-east.amazon-adsystem.com");
    redirectHosts.add("aax-beta.integ.amazon.com");
    redirectHosts.add("pda-bes.amazon.com");
    redirectHosts.add("d16g-cornerstone-bes.integ.amazon.com");
  }
  
  public AdWebViewClient(Context paramContext, AdSDKBridgeList paramAdSDKBridgeList, AdControlAccessor paramAdControlAccessor, WebUtils2 paramWebUtils2, Log2 paramLog2) {
    this.context = paramContext;
    this.urlExecutors = new HashMap<String, UrlExecutor>();
    this.bridgeList = paramAdSDKBridgeList;
    this.adControlAccessor = paramAdControlAccessor;
    this.webUtils = paramWebUtils2;
    this.log = paramLog2;
    setupUrlExecutors();
  }
  
  private boolean checkResources() {
    boolean bool = false;
    label17: for (String str : this.resourceList) {
      Set<AdSDKBridgeFactory> set = BridgeSelector.getInstance().getBridgeFactoriesForResourceLoad(str);
      if (set.size() > 0) {
        Iterator<AdSDKBridgeFactory> iterator = set.iterator();
        boolean bool1 = bool;
        while (true) {
          bool = bool1;
          if (iterator.hasNext()) {
            AdSDKBridge adSDKBridge = ((AdSDKBridgeFactory)iterator.next()).createAdSDKBridge(this.adControlAccessor);
            if (!this.bridgeList.contains(adSDKBridge)) {
              bool1 = true;
              this.bridgeList.addBridge(adSDKBridge);
            } 
            continue;
          } 
          continue label17;
        } 
      } 
    } 
    if (bool)
      ThreadUtils.executeOnMainThread(new Runnable() {
            public void run() {
              AdWebViewClient.this.adControlAccessor.reload();
            }
          }); 
    return bool;
  }
  
  static boolean isHoneycombVersion() {
    return AndroidTargetUtils.isBetweenAndroidAPIs(11, 13);
  }
  
  private void setupUrlExecutors() {
    this.urlExecutors.put("amazonmobile", new AmazonMobileExecutor(this.context, this.log, new AmazonDeviceLauncher(), this.webUtils));
    DefaultExecutor defaultExecutor = new DefaultExecutor(this.context);
    Iterator<String> iterator = intentSchemes.iterator();
    while (iterator.hasNext())
      putUrlExecutor(iterator.next(), defaultExecutor); 
  }
  
  protected String getScheme(String paramString) {
    return this.webUtils.getScheme(paramString);
  }
  
  protected boolean interpretScheme(String paramString1, String paramString2) {
    if (paramString2 == null || (paramString2.equals("about") && paramString1.equalsIgnoreCase("about:blank")))
      return false; 
    if (this.urlExecutors.containsKey(paramString2))
      return ((UrlExecutor)this.urlExecutors.get(paramString2)).execute(paramString1); 
    this.log.d(LOG_TAG, "Scheme %s unrecognized. Launching as intent.", new Object[] { paramString2 });
    return this.webUtils.launchActivityForIntentLink(paramString1, this.context);
  }
  
  public void onLoadResource(WebView paramWebView, String paramString) {
    this.resourceList.add(paramString);
    this.log.d(LOG_TAG, "Loading resource: %s", new Object[] { paramString });
    this.listener.onLoadResource(paramWebView, paramString);
  }
  
  public void onPageFinished(WebView paramWebView, String paramString) {
    this.log.d(LOG_TAG, "Page Finished %s", new Object[] { paramString });
    if (checkResources())
      return; 
    if (this.listener == null) {
      this.log.w(LOG_TAG, "Call to onPageFinished() ignored because listener is null.", new Object[0]);
      return;
    } 
    this.listener.onPageFinished(paramWebView, paramString);
  }
  
  public void onPageStarted(WebView paramWebView, String paramString, Bitmap paramBitmap) {
    super.onPageStarted(paramWebView, paramString, paramBitmap);
    this.listener.onPageStarted(paramWebView, paramString);
  }
  
  public void onReceivedError(WebView paramWebView, int paramInt, String paramString1, String paramString2) {
    this.log.e(LOG_TAG, "Error: %s", new Object[] { paramString1 });
    super.onReceivedError(paramWebView, paramInt, paramString1, paramString2);
    this.listener.onReceivedError(paramWebView, paramInt, paramString1, paramString2);
  }
  
  public void putUrlExecutor(String paramString, UrlExecutor paramUrlExecutor) {
    this.urlExecutors.put(paramString, paramUrlExecutor);
  }
  
  public void setListener(AdWebViewClientListener paramAdWebViewClientListener) {
    this.listener = paramAdWebViewClientListener;
  }
  
  public boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString) {
    Uri uri = Uri.parse(paramString);
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (redirectHosts.contains(uri.getHost())) {
      bool1 = bool2;
      if (!isHoneycombVersion())
        bool1 = false; 
    } 
    if (interpretScheme(paramString, getScheme(paramString)))
      bool1 = true; 
    return bool1;
  }
  
  static {
    intentSchemes.add("tel");
    intentSchemes.add("voicemail");
    intentSchemes.add("sms");
    intentSchemes.add("mailto");
    intentSchemes.add("geo");
    intentSchemes.add("google.streetview");
  }
  
  static interface AdWebViewClientListener {
    void onLoadResource(WebView param1WebView, String param1String);
    
    void onPageFinished(WebView param1WebView, String param1String);
    
    void onPageStarted(WebView param1WebView, String param1String);
    
    void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2);
  }
  
  static class AmazonMobileExecutor implements UrlExecutor {
    private final Context context;
    
    private final AmazonDeviceLauncher launcher;
    
    private final Log2 log;
    
    private final WebUtils2 webUtils;
    
    AmazonMobileExecutor(Context param1Context) {
      this(param1Context, new Log2(), new AmazonDeviceLauncher(), new WebUtils2());
    }
    
    AmazonMobileExecutor(Context param1Context, Log2 param1Log2, AmazonDeviceLauncher param1AmazonDeviceLauncher, WebUtils2 param1WebUtils2) {
      this.context = param1Context;
      this.log = param1Log2;
      this.launcher = param1AmazonDeviceLauncher;
      this.webUtils = param1WebUtils2;
    }
    
    public boolean execute(String param1String) {
      specialUrlClicked(param1String);
      return true;
    }
    
    protected void handleApplicationDefinedSpecialURL(String param1String) {
      this.log.i(AdWebViewClient.LOG_TAG, "Special url clicked, but was not handled by SDK. Url: %s", new Object[] { param1String });
    }
    
    protected boolean launchExternalActivity(String param1String) {
      return this.webUtils.launchActivityForIntentLink(param1String, this.context);
    }
    
    public void specialUrlClicked(String param1String) {
      // Byte code:
      //   0: aload_0
      //   1: getfield log : Lcom/amazon/device/ads/Log2;
      //   4: invokestatic access$100 : ()Ljava/lang/String;
      //   7: ldc 'Executing AmazonMobile Intent'
      //   9: iconst_0
      //   10: anewarray java/lang/Object
      //   13: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
      //   16: aload_1
      //   17: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
      //   20: astore_3
      //   21: aload_3
      //   22: ldc 'intent'
      //   24: invokevirtual getQueryParameters : (Ljava/lang/String;)Ljava/util/List;
      //   27: astore_2
      //   28: aload_2
      //   29: ifnull -> 86
      //   32: aload_2
      //   33: invokeinterface size : ()I
      //   38: ifle -> 86
      //   41: aload_2
      //   42: invokeinterface iterator : ()Ljava/util/Iterator;
      //   47: astore_2
      //   48: aload_2
      //   49: invokeinterface hasNext : ()Z
      //   54: ifeq -> 80
      //   57: aload_0
      //   58: aload_2
      //   59: invokeinterface next : ()Ljava/lang/Object;
      //   64: checkcast java/lang/String
      //   67: invokevirtual launchExternalActivity : (Ljava/lang/String;)Z
      //   70: ifeq -> 48
      //   73: return
      //   74: astore_2
      //   75: aconst_null
      //   76: astore_2
      //   77: goto -> 28
      //   80: aload_0
      //   81: aload_1
      //   82: invokevirtual handleApplicationDefinedSpecialURL : (Ljava/lang/String;)V
      //   85: return
      //   86: aload_0
      //   87: getfield launcher : Lcom/amazon/device/ads/AmazonDeviceLauncher;
      //   90: aload_0
      //   91: getfield context : Landroid/content/Context;
      //   94: invokevirtual isWindowshopPresent : (Landroid/content/Context;)Z
      //   97: ifeq -> 225
      //   100: aload_3
      //   101: invokevirtual getHost : ()Ljava/lang/String;
      //   104: ldc 'shopping'
      //   106: invokevirtual equals : (Ljava/lang/Object;)Z
      //   109: ifeq -> 73
      //   112: aload_3
      //   113: ldc 'app-action'
      //   115: invokevirtual getQueryParameter : (Ljava/lang/String;)Ljava/lang/String;
      //   118: astore_2
      //   119: aload_2
      //   120: ifnull -> 73
      //   123: aload_2
      //   124: invokevirtual length : ()I
      //   127: ifeq -> 73
      //   130: aload_2
      //   131: ldc 'detail'
      //   133: invokevirtual equals : (Ljava/lang/Object;)Z
      //   136: ifeq -> 170
      //   139: aload_3
      //   140: ldc 'asin'
      //   142: invokevirtual getQueryParameter : (Ljava/lang/String;)Ljava/lang/String;
      //   145: astore_1
      //   146: aload_1
      //   147: ifnull -> 73
      //   150: aload_1
      //   151: invokevirtual length : ()I
      //   154: ifeq -> 73
      //   157: aload_0
      //   158: getfield launcher : Lcom/amazon/device/ads/AmazonDeviceLauncher;
      //   161: aload_0
      //   162: getfield context : Landroid/content/Context;
      //   165: aload_1
      //   166: invokevirtual launchWindowshopDetailPage : (Landroid/content/Context;Ljava/lang/String;)V
      //   169: return
      //   170: aload_2
      //   171: ldc 'search'
      //   173: invokevirtual equals : (Ljava/lang/Object;)Z
      //   176: ifeq -> 210
      //   179: aload_3
      //   180: ldc 'keyword'
      //   182: invokevirtual getQueryParameter : (Ljava/lang/String;)Ljava/lang/String;
      //   185: astore_1
      //   186: aload_1
      //   187: ifnull -> 73
      //   190: aload_1
      //   191: invokevirtual length : ()I
      //   194: ifeq -> 73
      //   197: aload_0
      //   198: getfield launcher : Lcom/amazon/device/ads/AmazonDeviceLauncher;
      //   201: aload_0
      //   202: getfield context : Landroid/content/Context;
      //   205: aload_1
      //   206: invokevirtual launchWindowshopSearchPage : (Landroid/content/Context;Ljava/lang/String;)V
      //   209: return
      //   210: aload_2
      //   211: ldc 'webview'
      //   213: invokevirtual equals : (Ljava/lang/Object;)Z
      //   216: ifeq -> 73
      //   219: aload_0
      //   220: aload_1
      //   221: invokevirtual handleApplicationDefinedSpecialURL : (Ljava/lang/String;)V
      //   224: return
      //   225: aload_0
      //   226: aload_1
      //   227: invokevirtual handleApplicationDefinedSpecialURL : (Ljava/lang/String;)V
      //   230: return
      // Exception table:
      //   from	to	target	type
      //   21	28	74	java/lang/UnsupportedOperationException
    }
  }
  
  static class DefaultExecutor implements UrlExecutor {
    private final Context context;
    
    public DefaultExecutor(Context param1Context) {
      this.context = param1Context;
    }
    
    public boolean execute(String param1String) {
      WebUtils.launchActivityForIntentLink(param1String, this.context);
      return true;
    }
  }
  
  static interface UrlExecutor {
    boolean execute(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdWebViewClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */