package com.amazon.device.ads;

import java.io.File;

interface FileHandlerFactory {
  FileInputHandler createFileInputHandler(File paramFile);
  
  FileInputHandler createFileInputHandler(File paramFile, String paramString);
  
  FileInputHandler createFileInputHandler(String paramString);
  
  FileOutputHandler createFileOutputHandler(File paramFile);
  
  FileOutputHandler createFileOutputHandler(File paramFile, String paramString);
  
  FileOutputHandler createFileOutputHandler(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\FileHandlerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */