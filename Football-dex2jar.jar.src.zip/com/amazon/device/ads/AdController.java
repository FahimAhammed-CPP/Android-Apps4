package com.amazon.device.ads;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

class AdController implements Metrics.MetricsSubmitter {
  private static final String LOGTAG = "AdController";
  
  protected static final String MSG_PREPARE_AD_LOADING = "An ad is currently loading. Please wait for the ad to finish loading and showing before loading another ad.";
  
  protected static final String MSG_PREPARE_AD_READY_TO_SHOW = "An ad is ready to show. Please call showAd() to show the ad before loading another ad.";
  
  protected static final String MSG_PREPARE_AD_SHOWING = "An ad is currently showing. Please wait for the user to dismiss the ad before loading an ad.";
  
  protected static final String MSG_SHOW_AD_ANOTHER_SHOWING = "Another ad is currently showing. Please wait for the AdListener.onAdDismissed callback of the other ad.";
  
  protected static final String MSG_SHOW_AD_DESTROYED = "The ad cannot be shown because it has been destroyed. Create a new Ad object to load a new ad.";
  
  protected static final String MSG_SHOW_AD_DISMISSED = "The ad cannot be shown because it has already been displayed to the user. Please call loadAd(AdTargetingOptions) to load a new ad.";
  
  protected static final String MSG_SHOW_AD_EXPIRED = "This ad has expired. Please load another ad.";
  
  protected static final String MSG_SHOW_AD_LOADING = "The ad cannot be shown because it is still loading. Please wait for the AdListener.onAdLoaded() callback before showing the ad.";
  
  protected static final String MSG_SHOW_AD_READY_TO_LOAD = "The ad cannot be shown because it has not loaded successfully. Please call loadAd(AdTargetingOptions) to load an ad first.";
  
  protected static final String MSG_SHOW_AD_SHOWING = "The ad cannot be shown because it is already displayed on the screen. Please wait for the AdListener.onAdDismissed() callback and then load a new ad.";
  
  private Activity adActivity;
  
  private AdContainer adContainer;
  
  private AdControlAccessor adControlAccessor;
  
  private AdControlCallback adControlCallback;
  
  private AdData adData;
  
  private final AdSize adSize;
  
  private AdState adState = AdState.READY_TO_LOAD;
  
  private final AdUtils2 adUtils;
  
  private int adWindowHeight = 0;
  
  private int adWindowWidth = 0;
  
  private boolean backButtonOverridden = false;
  
  private ConnectionInfo connectionInfo;
  
  private final Context context;
  
  private ViewGroup defaultParent = null;
  
  private boolean disableHardwareAccelerationRequest = false;
  
  private boolean forceDisableHardwareAcceleration = false;
  
  private final AtomicBoolean hasFinishedLoading = new AtomicBoolean(false);
  
  private boolean hasNativeCloseButton = false;
  
  private final AtomicBoolean isClosing = new AtomicBoolean(false);
  
  private boolean isModallyExpanded = false;
  
  private boolean isPrepared = false;
  
  private final AtomicBoolean isRendering = new AtomicBoolean(false);
  
  private final Log2 log;
  
  private MetricsCollector metricsCollector;
  
  private boolean orientationFailureMetricRecorded = false;
  
  private int originalOrientation;
  
  private double scalingMultiplier = 1.0D;
  
  private final ArrayList<SDKEventListener> sdkEventListeners = new ArrayList<SDKEventListener>();
  
  private int timeout = 20000;
  
  private Timer timer;
  
  protected final WebUtils2 webUtils;
  
  private boolean windowDimensionsSet = false;
  
  AdController(Context paramContext, AdSize paramAdSize) {
    this(paramContext, paramAdSize, new WebUtils2(), new MetricsCollector(), new Log2(), new AdUtils2(), null);
  }
  
  AdController(Context paramContext, AdSize paramAdSize, WebUtils2 paramWebUtils2, MetricsCollector paramMetricsCollector, Log2 paramLog2, AdUtils2 paramAdUtils2, AdContainer paramAdContainer) {
    this.context = paramContext;
    this.adSize = paramAdSize;
    this.webUtils = paramWebUtils2;
    this.metricsCollector = paramMetricsCollector;
    this.log = paramLog2;
    this.adUtils = paramAdUtils2;
    this.adContainer = paramAdContainer;
  }
  
  private void adFailedAfterTimerCheck(AdError paramAdError) {
    if (getMetricsCollector() == null || getMetricsCollector().isMetricsCollectorEmpty()) {
      adFailedBeforeAdMetricsStart(paramAdError);
      return;
    } 
    adFailedAfterAdMetricsStart(paramAdError);
  }
  
  private void adLoaded() {
    if (!canBeUsed())
      return; 
    setAdState(AdState.LOADED);
    callOnAdLoaded(this.adData.getProperties());
  }
  
  private boolean canFireImpressionPixel() {
    return !getAdState().equals(AdState.HIDDEN);
  }
  
  private void determineShouldForceDisableHardwareAcceleration() {
    if ((AndroidTargetUtils.isAndroidAPI(14) || AndroidTargetUtils.isAndroidAPI(15)) && this.adData.getCreativeTypes().contains(AAXCreative.REQUIRES_TRANSPARENCY)) {
      this.forceDisableHardwareAcceleration = true;
      return;
    } 
    this.forceDisableHardwareAcceleration = false;
  }
  
  private boolean isReadyToLoad(boolean paramBoolean) {
    return getAdControlCallback().isAdReady(paramBoolean);
  }
  
  private void reset() {
    if (!canBeUsed())
      return; 
    this.isPrepared = false;
    resetMetricsCollector();
    this.orientationFailureMetricRecorded = false;
    if (this.adContainer != null) {
      this.adContainer.destroy();
      this.adContainer = null;
    } 
    this.adData = null;
  }
  
  private boolean shouldDisableHardwareAcceleration() {
    return (this.forceDisableHardwareAcceleration || this.disableHardwareAccelerationRequest);
  }
  
  void accumulateAdFailureMetrics(AdError paramAdError) {
    long l = System.nanoTime();
    getMetricsCollector().stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LATENCY_TOTAL, l);
    getMetricsCollector().stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_FAILURE, l);
    getMetricsCollector().stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LATENCY_TOTAL_FAILURE, l);
    if (paramAdError != null && (AdError.ErrorCode.NO_FILL.equals(paramAdError.getCode()) || AdError.ErrorCode.NETWORK_ERROR.equals(paramAdError.getCode()) || AdError.ErrorCode.NETWORK_TIMEOUT.equals(paramAdError.getCode()) || AdError.ErrorCode.INTERNAL_ERROR.equals(paramAdError.getCode()))) {
      getMetricsCollector().incrementMetric(Metrics.MetricType.AD_LOAD_FAILED);
      if (paramAdError.getCode() == AdError.ErrorCode.NETWORK_TIMEOUT)
        if (this.isRendering.get()) {
          getMetricsCollector().incrementMetric(Metrics.MetricType.AD_LOAD_FAILED_ON_PRERENDERING_TIMEOUT);
        } else {
          getMetricsCollector().incrementMetric(Metrics.MetricType.AD_LOAD_FAILED_ON_AAX_CALL_TIMEOUT);
        }  
    } 
    getMetricsCollector().stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LATENCY_RENDER_FAILED, l);
    if (getAdState().equals(AdState.RENDERING))
      getMetricsCollector().incrementMetric(Metrics.MetricType.AD_COUNTER_RENDERING_FATAL); 
    setAdditionalMetrics();
  }
  
  void adFailed(AdError paramAdError) {
    if (canBeUsed() && !getAndSetHasFinishedLoading(true)) {
      cancelTimer();
      adFailedAfterTimerCheck(paramAdError);
      setAdState(AdState.READY_TO_LOAD);
      return;
    } 
  }
  
  void adFailedAfterAdMetricsStart(AdError paramAdError) {
    accumulateAdFailureMetrics(paramAdError);
    callOnAdFailedToLoad(paramAdError, true);
  }
  
  void adFailedBeforeAdMetricsStart(AdError paramAdError) {
    callOnAdFailedToLoad(paramAdError, false);
  }
  
  public void adHidden() {
    setAdState(AdState.HIDDEN);
    fireSDKEvent(new SDKEvent(SDKEvent.SDKEventType.HIDDEN));
  }
  
  public void adRendered(String paramString) {
    if (!canBeUsed())
      return; 
    this.log.d("AdController", "Ad Rendered", new Object[0]);
    if (getAdState().equals(AdState.RENDERING) && !getAndSetHasFinishedLoading(true)) {
      this.isRendering.set(false);
      cancelTimer();
      setAdState(AdState.RENDERED);
      callOnAdRendered();
      long l = System.nanoTime();
      if (getMetricsCollector() != null) {
        getMetricsCollector().stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LATENCY_RENDER, l);
        getMetricsCollector().stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LATENCY_TOTAL, l);
        getMetricsCollector().stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LATENCY_TOTAL_SUCCESS, l);
        setAdditionalMetrics();
        submitAndResetMetricsIfNecessary(true);
      } 
      callPostAdRendered();
    } 
    fireSDKEvent((new SDKEvent(SDKEvent.SDKEventType.RENDERED)).setParameter("url", paramString));
  }
  
  public void adShown() {
    if (!canBeUsed())
      return; 
    getMetricsCollector().stopMetric(Metrics.MetricType.AD_SHOW_LATENCY);
    if (canFireImpressionPixel())
      this.webUtils.executeWebRequestInThread(getAdData().getImpressionPixelUrl(), false); 
    setAdState(AdState.SHOWING);
    if (!areWindowDimensionsSet())
      setWindowDimensions(getView().getWidth(), getView().getHeight()); 
    fireSDKEvent(new SDKEvent(SDKEvent.SDKEventType.VISIBLE));
  }
  
  void addJavascriptInterface(Object paramObject, boolean paramBoolean, String paramString) {
    getAdContainer().addJavascriptInterface(paramObject, paramBoolean, paramString);
  }
  
  public void addSDKEventListener(SDKEventListener paramSDKEventListener) {
    this.log.d("AdController", "Add SDKEventListener %s", new Object[] { paramSDKEventListener });
    this.sdkEventListeners.add(paramSDKEventListener);
  }
  
  public boolean areWindowDimensionsSet() {
    return this.windowDimensionsSet;
  }
  
  void callOnAdEvent(final AdEvent adEvent) {
    ThreadUtils.scheduleOnMainThread(new Runnable() {
          public void run() {
            if (!AdController.this.canBeUsed())
              return; 
            AdController.this.getAdControlCallback().onAdEvent(adEvent);
          }
        });
  }
  
  void callOnAdFailedToLoad(final AdError error, final boolean shouldSubmitMetrics) {
    ThreadUtils.scheduleOnMainThread(new Runnable() {
          public void run() {
            AdController.this.getAdControlCallback().onAdFailed(error);
            AdController.this.submitAndResetMetricsIfNecessary(shouldSubmitMetrics);
          }
        });
  }
  
  void callOnAdLoaded(final AdProperties adProperties) {
    ThreadUtils.scheduleOnMainThread(new Runnable() {
          public void run() {
            if (!AdController.this.canBeUsed())
              return; 
            AdController.this.getAdControlCallback().onAdLoaded(adProperties);
          }
        });
  }
  
  void callOnAdRendered() {
    ThreadUtils.scheduleOnMainThread(new Runnable() {
          public void run() {
            if (!AdController.this.canBeUsed())
              return; 
            AdController.this.getAdControlCallback().onAdRendered();
          }
        });
  }
  
  void callPostAdRendered() {
    ThreadUtils.scheduleOnMainThread(new Runnable() {
          public void run() {
            if (!AdController.this.canBeUsed())
              return; 
            AdController.this.getAdControlCallback().postAdRendered();
          }
        });
  }
  
  public boolean canBeUsed() {
    return (!AdState.DESTROYED.equals(getAdState()) && !AdState.INVALID.equals(getAdState()));
  }
  
  void cancelTimer() {
    if (this.timer != null)
      this.timer.cancel(); 
  }
  
  public void captureBackButton() {
    getAdContainer().listenForKey(new View.OnKeyListener() {
          public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
            if (param1Int == 4 && param1KeyEvent.getRepeatCount() == 0) {
              AdController.this.onBackButtonPress();
              return true;
            } 
            return false;
          }
        });
  }
  
  boolean checkDefinedActivities() {
    return this.adUtils.checkDefinedActivities(getContext().getApplicationContext());
  }
  
  public void clearSDKEventListeners() {
    this.sdkEventListeners.clear();
  }
  
  public boolean closeAd() {
    this.log.d("AdController", "Ad is attempting to close.", new Object[0]);
    boolean bool4 = false;
    boolean bool3 = false;
    boolean bool2 = bool4;
    if (!getAdState().equals(AdState.READY_TO_LOAD)) {
      bool2 = bool4;
      if (!this.isClosing.getAndSet(true)) {
        boolean bool6 = false;
        boolean bool5 = false;
        switch (getAdControlCallback().adClosing()) {
          default:
            bool2 = bool3;
            if (bool5) {
              fireSDKEvent(new SDKEvent(SDKEvent.SDKEventType.CLOSED));
              bool2 = true;
            } 
            if (bool6)
              resetToReady(); 
            this.isClosing.set(false);
            return bool2;
          case 1:
            bool6 = true;
            bool5 = true;
          case 0:
            break;
        } 
      } else {
        return bool2;
      } 
    } else {
      return bool2;
    } 
    boolean bool1 = true;
  }
  
  AdContainer createAdContainer() {
    return new AdContainer(this.context, this, this.webUtils, this.log);
  }
  
  public void destroy() {
    if (!canBeUsed()) {
      this.log.e("AdController", "The ad cannot be destroyed because it has already been destroyed.", new Object[0]);
      return;
    } 
    closeAd();
    this.adState = AdState.DESTROYED;
    if (this.adContainer != null) {
      getAdContainer().destroy();
      this.adContainer = null;
    } 
    this.isPrepared = false;
    this.metricsCollector = null;
    this.adData = null;
  }
  
  public void enableNativeCloseButton(boolean paramBoolean, RelativePosition paramRelativePosition) {
    this.hasNativeCloseButton = true;
    getAdContainer().enableNativeCloseButton(paramBoolean, paramRelativePosition);
  }
  
  public void fireAdEvent(AdEvent paramAdEvent) {
    this.log.d("AdController", "Firing AdEvent of type %s", new Object[] { paramAdEvent.getAdEventType() });
    callOnAdEvent(paramAdEvent);
  }
  
  public void fireSDKEvent(SDKEvent paramSDKEvent) {
    this.log.d("AdController", "Firing SDK Event of type %s", new Object[] { paramSDKEvent.getEventType() });
    Iterator<SDKEventListener> iterator = this.sdkEventListeners.iterator();
    while (iterator.hasNext())
      ((SDKEventListener)iterator.next()).onSDKEvent(paramSDKEvent, getAdControlAccessor()); 
  }
  
  AdContainer getAdContainer() {
    if (this.adContainer == null) {
      this.adContainer = createAdContainer();
      this.adContainer.disableHardwareAcceleration(shouldDisableHardwareAcceleration());
    } 
    return this.adContainer;
  }
  
  public AdControlAccessor getAdControlAccessor() {
    if (this.adControlAccessor == null)
      this.adControlAccessor = new AdControlAccessor(this); 
    return this.adControlAccessor;
  }
  
  AdControlCallback getAdControlCallback() {
    if (this.adControlCallback == null)
      this.adControlCallback = new DefaultAdControlCallback(); 
    return this.adControlCallback;
  }
  
  public AdData getAdData() {
    return this.adData;
  }
  
  Position getAdPosition() {
    int k = getViewWidth();
    int m = getViewHeight();
    int i = m;
    int j = k;
    if (k == 0) {
      i = m;
      j = k;
      if (m == 0) {
        j = getWindowWidth();
        i = getWindowHeight();
      } 
    } 
    j = AdUtils.pixelToDeviceIndependentPixel(j);
    i = AdUtils.pixelToDeviceIndependentPixel(i);
    int[] arrayOfInt1 = new int[2];
    getAdContainer().getLocationOnScreen(arrayOfInt1);
    View view = ((Activity)getContext()).findViewById(16908290);
    if (view == null) {
      this.log.w("AdController", "Could not find the activity's root view while determining ad position.", new Object[0]);
      return null;
    } 
    int[] arrayOfInt2 = new int[2];
    view.getLocationOnScreen(arrayOfInt2);
    k = AdUtils.pixelToDeviceIndependentPixel(arrayOfInt1[0]);
    m = AdUtils.pixelToDeviceIndependentPixel(arrayOfInt1[1] - arrayOfInt2[1]);
    return new Position(new Size(j, i), k, m);
  }
  
  public AdSize getAdSize() {
    return this.adSize;
  }
  
  public AdState getAdState() {
    return this.adState;
  }
  
  public boolean getAndResetIsPrepared() {
    boolean bool = this.isPrepared;
    this.isPrepared = false;
    return bool;
  }
  
  boolean getAndSetHasFinishedLoading(boolean paramBoolean) {
    return this.hasFinishedLoading.getAndSet(paramBoolean);
  }
  
  public ConnectionInfo getConnectionInfo() {
    return this.connectionInfo;
  }
  
  int getContentViewTop(Window paramWindow) {
    return paramWindow.findViewById(16908290).getTop();
  }
  
  protected Context getContext() {
    return (Context)((this.adActivity == null) ? this.context : this.adActivity);
  }
  
  public String getInstrumentationPixelUrl() {
    return (this.adData != null) ? this.adData.getInstrumentationPixelUrl() : null;
  }
  
  Size getMaxExpandableSize() {
    FrameLayout frameLayout = (FrameLayout)((Activity)getContext()).findViewById(16908290);
    if (frameLayout == null) {
      this.log.w("AdController", "Could not find the activity's root view while determining max expandable size.", new Object[0]);
      return null;
    } 
    int i = frameLayout.getWidth();
    int j = frameLayout.getHeight();
    return new Size(AdUtils.pixelToDeviceIndependentPixel(i), AdUtils.pixelToDeviceIndependentPixel(j));
  }
  
  public String getMaxSize() {
    return !getAdSize().isAuto() ? null : AdSize.getAsSizeString(getWindowWidth(), getWindowHeight());
  }
  
  void getMetrics(DisplayMetrics paramDisplayMetrics) {
    ((WindowManager)this.context.getSystemService("window")).getDefaultDisplay().getMetrics(paramDisplayMetrics);
  }
  
  public MetricsCollector getMetricsCollector() {
    return this.metricsCollector;
  }
  
  public int getOriginalOrientation() {
    return this.originalOrientation;
  }
  
  public double getScalingMultiplier() {
    return this.scalingMultiplier;
  }
  
  public String getScalingMultiplierDescription() {
    return (getScalingMultiplier() > 1.0D) ? "u" : ((getScalingMultiplier() < 1.0D && getScalingMultiplier() > 0.0D) ? "d" : "n");
  }
  
  Size getScreenSize() {
    DisplayMetrics displayMetrics = new DisplayMetrics();
    getMetrics(displayMetrics);
    int i = displayMetrics.widthPixels;
    int j = displayMetrics.heightPixels;
    return new Size(AdUtils.pixelToDeviceIndependentPixel(i), AdUtils.pixelToDeviceIndependentPixel(j));
  }
  
  public int getTimeout() {
    return this.timeout;
  }
  
  public AdContainer getView() {
    return getAdContainer();
  }
  
  public int getViewHeight() {
    return getAdContainer().getHeight();
  }
  
  ViewGroup getViewParent() {
    return (ViewGroup)getView().getParent();
  }
  
  ViewGroup getViewParentIfExpanded() {
    return (this.defaultParent != null && this.defaultParent != getView().getParent()) ? getViewParent() : null;
  }
  
  public int getViewWidth() {
    return getAdContainer().getWidth();
  }
  
  public int getWindowHeight() {
    return this.adWindowHeight;
  }
  
  public int getWindowWidth() {
    return this.adWindowWidth;
  }
  
  public void initialize() {
    if (canBeUsed()) {
      determineShouldForceDisableHardwareAcceleration();
      if (initializeAdContainer()) {
        if (!getAdSize().equals(AdSize.SIZE_INTERSTITIAL)) {
          float f = AmazonRegistration.getInstance().getDeviceInfo().getScalingFactorAsFloat();
          this.scalingMultiplier = AdUtils.calculateScalingMultiplier((int)(this.adData.getWidth() * f), (int)(this.adData.getHeight() * f), getWindowWidth(), getWindowHeight());
          setViewHeightToAdHeight();
        } else {
          this.scalingMultiplier = -1.0D;
        } 
        for (AAXCreative aAXCreative : this.adData) {
          Set<AdSDKBridgeFactory> set = BridgeSelector.getInstance().getBridgeFactories(aAXCreative);
          if (set != null)
            for (AdSDKBridgeFactory adSDKBridgeFactory : set)
              getAdContainer().addAdSDKBridge(adSDKBridgeFactory.createAdSDKBridge(getAdControlAccessor()));  
        } 
        adLoaded();
        return;
      } 
    } 
  }
  
  boolean initializeAdContainer() {
    try {
      getAdContainer().initialize();
      return true;
    } catch (IllegalStateException illegalStateException) {
      adFailed(new AdError(AdError.ErrorCode.INTERNAL_ERROR, "An unknown error occurred when attempting to create the web view."));
      setAdState(AdState.INVALID);
      this.log.e("AdController", "An unknown error occurred when attempting to create the web view.", new Object[0]);
      return false;
    } 
  }
  
  public void injectJavascript(final String javascript, final boolean preload) {
    ThreadUtils.executeOnMainThread(new Runnable() {
          public void run() {
            AdController.this.getAdContainer().injectJavascript(javascript, preload);
          }
        });
  }
  
  public boolean isExpired() {
    return (this.adData != null && this.adData.isExpired());
  }
  
  boolean isInterstitial() {
    return AdSize.SIZE_INTERSTITIAL.equals(this.adSize);
  }
  
  public boolean isModal() {
    return (getAdSize().isModal() || (AdState.EXPANDED.equals(getAdState()) && this.isModallyExpanded));
  }
  
  public boolean isValid() {
    return !getAdState().equals(AdState.INVALID);
  }
  
  boolean isValidAppKey() {
    return (AmazonRegistration.getInstance().getRegistrationInfo().getAppKey() != null);
  }
  
  public boolean isVisible() {
    return (AdState.SHOWING.equals(getAdState()) || AdState.EXPANDED.equals(getAdState()));
  }
  
  public boolean isWebViewOk() {
    return WebViewFactory.isWebViewOk(getContext());
  }
  
  public void loadHtml(String paramString1, String paramString2) {
    getAdContainer().loadHtml(paramString1, paramString2);
  }
  
  public void loadUrl(String paramString) {
    getAdContainer().loadUrl(paramString);
  }
  
  public void moveViewBackToParent(ViewGroup.LayoutParams paramLayoutParams) {
    ViewGroup viewGroup = (ViewGroup)getView().getParent();
    if (viewGroup != null)
      viewGroup.removeView((View)getView()); 
    setViewHeightToAdHeight();
    if (this.defaultParent != null)
      this.defaultParent.addView((View)getView(), paramLayoutParams); 
    getAdContainer().listenForKey((View.OnKeyListener)null);
    setExpanded(false);
  }
  
  public void moveViewToViewGroup(ViewGroup paramViewGroup, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    ViewGroup viewGroup = getViewParent();
    if (this.defaultParent == null)
      this.defaultParent = viewGroup; 
    if (viewGroup != null)
      viewGroup.removeView((View)getView()); 
    setViewHeightToMatchParent();
    paramViewGroup.addView((View)getView(), paramLayoutParams);
    this.isModallyExpanded = paramBoolean;
    setExpanded(true);
    if (this.isModallyExpanded)
      captureBackButton(); 
  }
  
  void onAdTimedOut() {
    if (!getAndSetHasFinishedLoading(true)) {
      adFailedAfterTimerCheck(new AdError(AdError.ErrorCode.NETWORK_TIMEOUT, "Ad Load Timed Out"));
      setAdState(AdState.INVALID);
    } 
  }
  
  boolean onBackButtonPress() {
    if (this.backButtonOverridden) {
      fireSDKEvent(new SDKEvent(SDKEvent.SDKEventType.BACK_BUTTON_PRESSED));
      return true;
    } 
    closeAd();
    return false;
  }
  
  public void onRequestError(String paramString) {
    this.log.e("AdController", paramString, new Object[0]);
    adFailed(new AdError(AdError.ErrorCode.REQUEST_ERROR, paramString));
  }
  
  public void orientationChangeAttemptedWhenNotAllowed() {
    if (!this.orientationFailureMetricRecorded) {
      this.orientationFailureMetricRecorded = true;
      getMetricsCollector().incrementMetric(Metrics.MetricType.SET_ORIENTATION_FAILURE);
    } 
  }
  
  public void overrideBackButton(boolean paramBoolean) {
    this.backButtonOverridden = paramBoolean;
  }
  
  protected boolean passesInternetPermissionCheck(Context paramContext) {
    return PermissionChecker.hasInternetPermission(paramContext);
  }
  
  public boolean popView() {
    return getAdContainer().popView();
  }
  
  public void preloadHtml(String paramString1, String paramString2, PreloadCallback paramPreloadCallback) {
    getAdContainer().preloadHtml(paramString1, paramString2, paramPreloadCallback);
  }
  
  public void preloadUrl(String paramString, PreloadCallback paramPreloadCallback) {
    getAdContainer().preloadUrl(paramString, paramPreloadCallback);
  }
  
  public boolean prepareForAdLoad(long paramLong, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual canBeUsed : ()Z
    //   4: ifne -> 16
    //   7: aload_0
    //   8: ldc_w 'An ad could not be loaded because the view has been destroyed or was not created properly.'
    //   11: invokevirtual onRequestError : (Ljava/lang/String;)V
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_0
    //   17: invokevirtual checkDefinedActivities : ()Z
    //   20: ifne -> 32
    //   23: aload_0
    //   24: ldc_w 'Ads cannot load unless "com.amazon.device.ads.AdActivity" is correctly declared as an activity in AndroidManifest.xml. Consult the online documentation for more info.'
    //   27: invokevirtual onRequestError : (Ljava/lang/String;)V
    //   30: iconst_0
    //   31: ireturn
    //   32: aload_0
    //   33: aload_0
    //   34: getfield context : Landroid/content/Context;
    //   37: invokevirtual passesInternetPermissionCheck : (Landroid/content/Context;)Z
    //   40: ifne -> 52
    //   43: aload_0
    //   44: ldc_w 'Ads cannot load because the INTERNET permission is missing from the app's manifest.'
    //   47: invokevirtual onRequestError : (Ljava/lang/String;)V
    //   50: iconst_0
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual isValidAppKey : ()Z
    //   56: ifne -> 68
    //   59: aload_0
    //   60: ldc_w 'Can't load an ad because Application Key has not been set. Did you forget to call AdRegistration.setAppKey( ... )?'
    //   63: invokevirtual onRequestError : (Ljava/lang/String;)V
    //   66: iconst_0
    //   67: ireturn
    //   68: aload_0
    //   69: invokevirtual isWebViewOk : ()Z
    //   72: ifne -> 96
    //   75: invokestatic getInstance : ()Lcom/amazon/device/ads/Metrics;
    //   78: invokevirtual getMetricsCollector : ()Lcom/amazon/device/ads/MetricsCollector;
    //   81: getstatic com/amazon/device/ads/Metrics$MetricType.AD_FAILED_UNKNOWN_WEBVIEW_ISSUE : Lcom/amazon/device/ads/Metrics$MetricType;
    //   84: invokevirtual incrementMetric : (Lcom/amazon/device/ads/Metrics$MetricType;)V
    //   87: aload_0
    //   88: ldc_w 'We will be unable to create a WebView for rendering an ad due to an unknown issue with the WebView.'
    //   91: invokevirtual onRequestError : (Ljava/lang/String;)V
    //   94: iconst_0
    //   95: ireturn
    //   96: aload_0
    //   97: iload_3
    //   98: invokespecial isReadyToLoad : (Z)Z
    //   101: ifne -> 135
    //   104: iconst_1
    //   105: istore #4
    //   107: aload_0
    //   108: invokevirtual getAdState : ()Lcom/amazon/device/ads/AdState;
    //   111: getstatic com/amazon/device/ads/AdState.RENDERED : Lcom/amazon/device/ads/AdState;
    //   114: invokevirtual equals : (Ljava/lang/Object;)Z
    //   117: ifeq -> 289
    //   120: aload_0
    //   121: invokevirtual isExpired : ()Z
    //   124: ifeq -> 271
    //   127: iconst_0
    //   128: istore #4
    //   130: iload #4
    //   132: ifne -> 14
    //   135: aload_0
    //   136: invokespecial reset : ()V
    //   139: aload_0
    //   140: invokevirtual getMetricsCollector : ()Lcom/amazon/device/ads/MetricsCollector;
    //   143: getstatic com/amazon/device/ads/Metrics$MetricType.AD_LATENCY_TOTAL : Lcom/amazon/device/ads/Metrics$MetricType;
    //   146: lload_1
    //   147: invokevirtual startMetricInMillisecondsFromNanoseconds : (Lcom/amazon/device/ads/Metrics$MetricType;J)V
    //   150: aload_0
    //   151: invokevirtual getMetricsCollector : ()Lcom/amazon/device/ads/MetricsCollector;
    //   154: getstatic com/amazon/device/ads/Metrics$MetricType.AD_LATENCY_TOTAL_FAILURE : Lcom/amazon/device/ads/Metrics$MetricType;
    //   157: lload_1
    //   158: invokevirtual startMetricInMillisecondsFromNanoseconds : (Lcom/amazon/device/ads/Metrics$MetricType;J)V
    //   161: aload_0
    //   162: invokevirtual getMetricsCollector : ()Lcom/amazon/device/ads/MetricsCollector;
    //   165: getstatic com/amazon/device/ads/Metrics$MetricType.AD_LATENCY_TOTAL_SUCCESS : Lcom/amazon/device/ads/Metrics$MetricType;
    //   168: lload_1
    //   169: invokevirtual startMetricInMillisecondsFromNanoseconds : (Lcom/amazon/device/ads/Metrics$MetricType;J)V
    //   172: aload_0
    //   173: invokevirtual getMetricsCollector : ()Lcom/amazon/device/ads/MetricsCollector;
    //   176: getstatic com/amazon/device/ads/Metrics$MetricType.AD_LOAD_LATENCY_LOADAD_TO_FETCH_THREAD_REQUEST_START : Lcom/amazon/device/ads/Metrics$MetricType;
    //   179: lload_1
    //   180: invokevirtual startMetricInMillisecondsFromNanoseconds : (Lcom/amazon/device/ads/Metrics$MetricType;J)V
    //   183: aload_0
    //   184: getstatic com/amazon/device/ads/AdState.LOADING : Lcom/amazon/device/ads/AdState;
    //   187: invokevirtual setAdState : (Lcom/amazon/device/ads/AdState;)V
    //   190: aload_0
    //   191: getfield isRendering : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   194: iconst_0
    //   195: invokevirtual set : (Z)V
    //   198: aload_0
    //   199: iconst_0
    //   200: invokevirtual setHasFinishedLoading : (Z)V
    //   203: aload_0
    //   204: getfield timer : Ljava/util/Timer;
    //   207: ifnull -> 218
    //   210: aload_0
    //   211: getfield timer : Ljava/util/Timer;
    //   214: invokevirtual purge : ()I
    //   217: pop
    //   218: aload_0
    //   219: new java/util/Timer
    //   222: dup
    //   223: invokespecial <init> : ()V
    //   226: putfield timer : Ljava/util/Timer;
    //   229: aload_0
    //   230: getfield timer : Ljava/util/Timer;
    //   233: new com/amazon/device/ads/AdController$1
    //   236: dup
    //   237: aload_0
    //   238: invokespecial <init> : (Lcom/amazon/device/ads/AdController;)V
    //   241: aload_0
    //   242: invokevirtual getTimeout : ()I
    //   245: i2l
    //   246: invokevirtual schedule : (Ljava/util/TimerTask;J)V
    //   249: invokestatic getInstance : ()Lcom/amazon/device/ads/IAmazonRegistration;
    //   252: invokeinterface getDeviceInfo : ()Lcom/amazon/device/ads/DeviceInfo;
    //   257: aload_0
    //   258: getfield context : Landroid/content/Context;
    //   261: invokevirtual populateUserAgentString : (Landroid/content/Context;)V
    //   264: aload_0
    //   265: iconst_1
    //   266: putfield isPrepared : Z
    //   269: iconst_1
    //   270: ireturn
    //   271: aload_0
    //   272: getfield log : Lcom/amazon/device/ads/Log2;
    //   275: ldc 'AdController'
    //   277: ldc 'An ad is ready to show. Please call showAd() to show the ad before loading another ad.'
    //   279: iconst_0
    //   280: anewarray java/lang/Object
    //   283: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   286: goto -> 130
    //   289: aload_0
    //   290: invokevirtual getAdState : ()Lcom/amazon/device/ads/AdState;
    //   293: getstatic com/amazon/device/ads/AdState.EXPANDED : Lcom/amazon/device/ads/AdState;
    //   296: invokevirtual equals : (Ljava/lang/Object;)Z
    //   299: ifeq -> 321
    //   302: aload_0
    //   303: getfield log : Lcom/amazon/device/ads/Log2;
    //   306: ldc 'AdController'
    //   308: ldc_w 'An ad could not be loaded because another ad is currently expanded.'
    //   311: iconst_0
    //   312: anewarray java/lang/Object
    //   315: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   318: goto -> 130
    //   321: aload_0
    //   322: getfield log : Lcom/amazon/device/ads/Log2;
    //   325: ldc 'AdController'
    //   327: ldc 'An ad is currently loading. Please wait for the ad to finish loading and showing before loading another ad.'
    //   329: iconst_0
    //   330: anewarray java/lang/Object
    //   333: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   336: goto -> 130
  }
  
  void putUrlExecutorInAdWebViewClient(String paramString, AdWebViewClient.UrlExecutor paramUrlExecutor) {
    getAdContainer().putUrlExecutorInAdWebViewClient(paramString, paramUrlExecutor);
  }
  
  void reload() {
    getAdContainer().reload();
  }
  
  public void removeNativeCloseButton() {
    this.hasNativeCloseButton = false;
    getAdContainer().removeNativeCloseButton();
  }
  
  public void render() {
    if (!canBeUsed())
      return; 
    setAdState(AdState.RENDERING);
    long l = System.nanoTime();
    getMetricsCollector().stopMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LOAD_LATENCY_FINALIZE_FETCH_START_TO_RENDER_START, l);
    getMetricsCollector().startMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LATENCY_RENDER, l);
    this.isRendering.set(true);
    String str = this.adData.getCreative();
    getAdContainer().loadHtml("http://amazon-adsystem.amazon.com/", str);
  }
  
  public void requestDisableHardwareAcceleration(boolean paramBoolean) {
    this.disableHardwareAccelerationRequest = paramBoolean;
    if (this.adContainer != null)
      this.adContainer.disableHardwareAcceleration(shouldDisableHardwareAcceleration()); 
  }
  
  public void resetMetricsCollector() {
    this.metricsCollector = new MetricsCollector();
  }
  
  public void resetToReady() {
    if (!canBeUsed())
      return; 
    this.adActivity = null;
    this.isPrepared = false;
    resetMetricsCollector();
    this.orientationFailureMetricRecorded = false;
    getAdContainer().destroy();
    this.adData = null;
    setAdState(AdState.READY_TO_LOAD);
  }
  
  void setAdActivity(Activity paramActivity) {
    this.adActivity = paramActivity;
  }
  
  protected void setAdData(AdData paramAdData) {
    this.adData = paramAdData;
  }
  
  void setAdState(AdState paramAdState) {
    this.log.d("AdController", "Changing AdState from %s to %s", new Object[] { this.adState, paramAdState });
    this.adState = paramAdState;
  }
  
  protected void setAdditionalMetrics() {
    this.adUtils.setConnectionMetrics(getConnectionInfo(), getMetricsCollector());
    if (getWindowHeight() == 0)
      getMetricsCollector().incrementMetric(Metrics.MetricType.ADLAYOUT_HEIGHT_ZERO); 
    getMetricsCollector().setMetricString(Metrics.MetricType.VIEWPORT_SCALE, getScalingMultiplierDescription());
  }
  
  public void setAllowClicks(boolean paramBoolean) {
    getAdContainer().setAllowClicks(paramBoolean);
  }
  
  public void setCallback(AdControlCallback paramAdControlCallback) {
    this.adControlCallback = paramAdControlCallback;
  }
  
  public void setConnectionInfo(ConnectionInfo paramConnectionInfo) {
    this.connectionInfo = paramConnectionInfo;
  }
  
  public void setExpanded(boolean paramBoolean) {
    if (paramBoolean) {
      setAdState(AdState.EXPANDED);
      return;
    } 
    setAdState(AdState.SHOWING);
  }
  
  void setHasFinishedLoading(boolean paramBoolean) {
    this.hasFinishedLoading.set(paramBoolean);
  }
  
  public void setOriginalOrientation(Activity paramActivity) {
    this.originalOrientation = paramActivity.getRequestedOrientation();
  }
  
  public void setTimeout(int paramInt) {
    this.timeout = paramInt;
  }
  
  public void setViewHeightToAdHeight() {
    if (this.adData != null) {
      int i = (int)(this.adData.getHeight() * getScalingMultiplier() * AdUtils.getScalingFactorAsFloat());
      if (i > 0)
        getAdContainer().setViewHeight(i); 
    } 
  }
  
  public void setViewHeightToMatchParent() {
    getAdContainer().setViewHeight(-1);
  }
  
  public void setWindowDimensions(int paramInt1, int paramInt2) {
    this.adWindowWidth = paramInt1;
    this.adWindowHeight = paramInt2;
    this.windowDimensionsSet = true;
  }
  
  public void showNativeCloseButtonImage(boolean paramBoolean) {
    if (this.hasNativeCloseButton)
      getAdContainer().showNativeCloseButtonImage(paramBoolean); 
  }
  
  public void stashView() {
    getAdContainer().stashView();
  }
  
  public void submitAndResetMetrics() {
    Metrics.getInstance().submitAndResetMetrics(this);
  }
  
  public void submitAndResetMetricsIfNecessary(boolean paramBoolean) {
    if (paramBoolean)
      submitAndResetMetrics(); 
  }
  
  class DefaultAdControlCallback implements AdControlCallback {
    public int adClosing() {
      Log.d("AdController", "DefaultAdControlCallback adClosing called", new Object[0]);
      return 1;
    }
    
    public boolean isAdReady(boolean param1Boolean) {
      param1Boolean = false;
      Log.d("AdController", "DefaultAdControlCallback isAdReady called", new Object[0]);
      if (AdController.this.getAdState().equals(AdState.READY_TO_LOAD) || AdController.this.getAdState().equals(AdState.SHOWING))
        param1Boolean = true; 
      return param1Boolean;
    }
    
    public void onAdEvent(AdEvent param1AdEvent) {
      Log.d("AdController", "DefaultAdControlCallback onAdEvent called", new Object[0]);
    }
    
    public void onAdFailed(AdError param1AdError) {
      Log.d("AdController", "DefaultAdControlCallback onAdFailed called", new Object[0]);
    }
    
    public void onAdLoaded(AdProperties param1AdProperties) {
      Log.d("AdController", "DefaultAdControlCallback onAdLoaded called", new Object[0]);
    }
    
    public void onAdRendered() {
      Log.d("AdController", "DefaultAdControlCallback onAdRendered called", new Object[0]);
    }
    
    public void postAdRendered() {
      Log.d("AdController", "DefaultAdControlCallback postAdRendered called", new Object[0]);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */