package com.amazon.device.ads;

import java.util.Locale;

class OrientationProperties {
  private static final String FORMAT = "{\"allowOrientationChange\":%s,\"forceOrientation\":\"%s\"}";
  
  private Boolean allowOrientationChange = Boolean.valueOf(true);
  
  private ForceOrientation forceOrientation = ForceOrientation.NONE;
  
  public ForceOrientation getForceOrientation() {
    return this.forceOrientation;
  }
  
  public Boolean isAllowOrientationChange() {
    return this.allowOrientationChange;
  }
  
  public void setAllowOrientationChange(Boolean paramBoolean) {
    this.allowOrientationChange = paramBoolean;
  }
  
  public void setForceOrientation(ForceOrientation paramForceOrientation) {
    this.forceOrientation = paramForceOrientation;
  }
  
  public String toString() {
    return String.format(Locale.US, "{\"allowOrientationChange\":%s,\"forceOrientation\":\"%s\"}", new Object[] { this.allowOrientationChange.toString(), this.forceOrientation.toString() });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\OrientationProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */