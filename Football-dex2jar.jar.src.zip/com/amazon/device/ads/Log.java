package com.amazon.device.ads;

import java.util.ArrayList;
import java.util.Iterator;

class Log {
  protected static final String LOGTAG = "AmazonMobileAds ";
  
  private static ILog logger;
  
  private static boolean loggingEnabled = false;
  
  static {
    logger = new LogcatLogger();
  }
  
  public static boolean canLog() {
    return (logger == null) ? false : DebugProperties.getInstance().getDebugPropertyAsBoolean("debug.logging", loggingEnabled);
  }
  
  public static void d(String paramString1, String paramString2, Object... paramVarArgs) {
    if (canLog())
      logger.d("AmazonMobileAds " + paramString1, paramString2, paramVarArgs); 
  }
  
  private static void doLog(boolean paramBoolean, Level paramLevel, String paramString1, String paramString2, Object... paramVarArgs) {
    if (canLog() || paramBoolean) {
      switch (paramLevel.level) {
        default:
          return;
        case 3:
          logger.d("AmazonMobileAds " + paramString1, paramString2, paramVarArgs);
          return;
        case 6:
          logger.e("AmazonMobileAds " + paramString1, paramString2, paramVarArgs);
          return;
        case 4:
          logger.i("AmazonMobileAds " + paramString1, paramString2, paramVarArgs);
          return;
        case 2:
          logger.v("AmazonMobileAds " + paramString1, paramString2, paramVarArgs);
          return;
        case 5:
          break;
      } 
      logger.w("AmazonMobileAds " + paramString1, paramString2, paramVarArgs);
      return;
    } 
  }
  
  public static void e(String paramString1, String paramString2, Object... paramVarArgs) {
    if (canLog())
      logger.e("AmazonMobileAds " + paramString1, paramString2, paramVarArgs); 
  }
  
  public static void enableLogging(boolean paramBoolean) {
    loggingEnabled = paramBoolean;
  }
  
  public static final void enableLoggingWithSetterNotification(String paramString, boolean paramBoolean) {
    if (!paramBoolean)
      logSetterNotification(paramString, "Debug logging", Boolean.valueOf(paramBoolean)); 
    enableLogging(paramBoolean);
    if (paramBoolean) {
      logSetterNotification(paramString, "Debug logging", Boolean.valueOf(paramBoolean));
      d(paramString, "Amazon Mobile Ads API Version: %s", new Object[] { Version.getRawSDKVersion() });
    } 
  }
  
  public static void forceLog(Level paramLevel, String paramString1, String paramString2, Object... paramVarArgs) {
    doLog(true, paramLevel, paramString1, paramString2, paramVarArgs);
  }
  
  public static ILog getLogger() {
    return logger;
  }
  
  public static void i(String paramString1, String paramString2, Object... paramVarArgs) {
    if (canLog())
      logger.i("AmazonMobileAds " + paramString1, paramString2, paramVarArgs); 
  }
  
  public static void log(Level paramLevel, String paramString1, String paramString2, Object... paramVarArgs) {
    doLog(false, paramLevel, paramString1, paramString2, paramVarArgs);
  }
  
  public static final void logSetterNotification(String paramString1, String paramString2, Object paramObject) {
    if (!canLog())
      return; 
    if (paramObject instanceof Boolean) {
      if (((Boolean)paramObject).booleanValue()) {
        paramObject = "enabled";
      } else {
        paramObject = "disabled";
      } 
      d(paramString1, "%s has been %s.", new Object[] { paramString2, paramObject });
      return;
    } 
    d(paramString1, "%s has been set: %s", new Object[] { paramString2, String.valueOf(paramObject) });
  }
  
  public static void setLogger(ILog paramILog) {
    logger = paramILog;
  }
  
  static Iterable<String> split(String paramString, int paramInt) {
    ArrayList<String> arrayList = new ArrayList();
    if (paramString != null && paramString.length() != 0) {
      int i = 0;
      while (true) {
        if (i < paramString.length()) {
          arrayList.add(paramString.substring(i, Math.min(paramString.length(), i + paramInt)));
          i += paramInt;
          continue;
        } 
        return arrayList;
      } 
    } 
    return arrayList;
  }
  
  public static void v(String paramString1, String paramString2, Object... paramVarArgs) {
    if (canLog())
      logger.v("AmazonMobileAds " + paramString1, paramString2, paramVarArgs); 
  }
  
  public static void w(String paramString1, String paramString2, Object... paramVarArgs) {
    if (canLog())
      logger.w("AmazonMobileAds " + paramString1, paramString2, paramVarArgs); 
  }
  
  public enum Level {
    DEBUG(3),
    ERROR(6),
    INFO(4),
    VERBOSE(2),
    WARN(5);
    
    private final int level;
    
    static {
    
    }
    
    Level(int param1Int1) {
      this.level = param1Int1;
    }
  }
  
  private static class LogcatLogger implements ILog {
    private static final int MAX_LENGTH = 1000;
    
    private LogcatLogger() {}
    
    private Iterable<String> formatAndSplit(String param1String, Object... param1VarArgs) {
      String str = param1String;
      if (param1VarArgs != null) {
        str = param1String;
        if (param1VarArgs.length > 0)
          str = String.format(param1String, param1VarArgs); 
      } 
      return Log.split(str, 1000);
    }
    
    public void d(String param1String1, String param1String2, Object... param1VarArgs) {
      Iterator<String> iterator = formatAndSplit(param1String2, param1VarArgs).iterator();
      while (iterator.hasNext())
        android.util.Log.d(param1String1, iterator.next()); 
    }
    
    public void e(String param1String1, String param1String2, Object... param1VarArgs) {
      Iterator<String> iterator = formatAndSplit(param1String2, param1VarArgs).iterator();
      while (iterator.hasNext())
        android.util.Log.e(param1String1, iterator.next()); 
    }
    
    public void i(String param1String1, String param1String2, Object... param1VarArgs) {
      Iterator<String> iterator = formatAndSplit(param1String2, param1VarArgs).iterator();
      while (iterator.hasNext())
        android.util.Log.i(param1String1, iterator.next()); 
    }
    
    public void v(String param1String1, String param1String2, Object... param1VarArgs) {
      Iterator<String> iterator = formatAndSplit(param1String2, param1VarArgs).iterator();
      while (iterator.hasNext())
        android.util.Log.v(param1String1, iterator.next()); 
    }
    
    public void w(String param1String1, String param1String2, Object... param1VarArgs) {
      Iterator<String> iterator = formatAndSplit(param1String2, param1VarArgs).iterator();
      while (iterator.hasNext())
        android.util.Log.w(param1String1, iterator.next()); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Log.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */