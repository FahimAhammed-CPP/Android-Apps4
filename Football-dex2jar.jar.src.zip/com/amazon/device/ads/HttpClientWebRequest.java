package com.amazon.device.ads;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

class HttpClientWebRequest extends WebRequest {
  private static final int DEFAULT_SOCKET_BUFFER_SIZE = 8192;
  
  private static final String LOG_TAG = HttpClientWebRequest.class.getSimpleName();
  
  private HttpClient client;
  
  private void prepareFormRequestBody(HttpPost paramHttpPost, String paramString) throws WebRequest.WebRequestException {
    ArrayList<BasicNameValuePair> arrayList = new ArrayList();
    for (Map.Entry<String, String> entry : this.postParameters.entrySet())
      arrayList.add(new BasicNameValuePair((String)entry.getKey(), (String)entry.getValue())); 
    try {
      paramHttpPost.setEntity((HttpEntity)new UrlEncodedFormEntity(arrayList, "UTF-8"));
      return;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      Log.e(getLogTag(), "Unsupported character encoding used while creating the request: %s", new Object[] { unsupportedEncodingException.getMessage() });
      throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.UNSUPPORTED_ENCODING, "Unsupported character encoding used while creating the request", unsupportedEncodingException);
    } 
  }
  
  private void prepareRequestBody(HttpPost paramHttpPost) throws WebRequest.WebRequestException {
    String str2 = this.charset;
    String str1 = str2;
    if (str2 == null)
      str1 = "UTF-8"; 
    String str3 = this.contentType;
    str2 = str3;
    if (str3 == null)
      str2 = "text/plain"; 
    if (this.requestBody != null) {
      prepareStringRequestBody(paramHttpPost, str2, str1);
      return;
    } 
    prepareFormRequestBody(paramHttpPost, str1);
  }
  
  private void prepareStringRequestBody(HttpPost paramHttpPost, String paramString1, String paramString2) throws WebRequest.WebRequestException {
    try {
      StringEntity stringEntity = new StringEntity(this.requestBody, paramString2);
      stringEntity.setContentType(paramString1);
      paramHttpPost.setEntity((HttpEntity)stringEntity);
      return;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      Log.e(getLogTag(), "Unsupported character encoding used while creating the request. ", new Object[] { unsupportedEncodingException.getMessage() });
      throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.UNSUPPORTED_ENCODING, "Unsupported character encoding used while creating the request.", unsupportedEncodingException);
    } 
  }
  
  protected void closeConnection() {
    if (this.client != null) {
      this.client.getConnectionManager().closeIdleConnections(0L, TimeUnit.MILLISECONDS);
      this.client.getConnectionManager().closeExpiredConnections();
      this.client = null;
    } 
  }
  
  protected HttpParams createHttpParams() {
    BasicHttpParams basicHttpParams = new BasicHttpParams();
    HttpConnectionParams.setConnectionTimeout((HttpParams)basicHttpParams, getTimeout());
    HttpConnectionParams.setSoTimeout((HttpParams)basicHttpParams, getTimeout());
    HttpConnectionParams.setSocketBufferSize((HttpParams)basicHttpParams, 8192);
    return (HttpParams)basicHttpParams;
  }
  
  protected HttpRequestBase createHttpRequest(URL paramURL) throws WebRequest.WebRequestException {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual createURI : (Ljava/net/URL;)Ljava/net/URI;
    //   7: astore_3
    //   8: getstatic com/amazon/device/ads/HttpClientWebRequest$1.$SwitchMap$com$amazon$device$ads$WebRequest$HttpMethod : [I
    //   11: aload_0
    //   12: invokevirtual getHttpMethod : ()Lcom/amazon/device/ads/WebRequest$HttpMethod;
    //   15: invokevirtual ordinal : ()I
    //   18: iaload
    //   19: tableswitch default -> 40, 1 -> 166, 2 -> 178
    //   40: aload_2
    //   41: astore_1
    //   42: aload_0
    //   43: getfield headers : Ljava/util/HashMap;
    //   46: invokevirtual entrySet : ()Ljava/util/Set;
    //   49: invokeinterface iterator : ()Ljava/util/Iterator;
    //   54: astore_2
    //   55: aload_2
    //   56: invokeinterface hasNext : ()Z
    //   61: ifeq -> 198
    //   64: aload_2
    //   65: invokeinterface next : ()Ljava/lang/Object;
    //   70: checkcast java/util/Map$Entry
    //   73: astore #4
    //   75: aload #4
    //   77: invokeinterface getValue : ()Ljava/lang/Object;
    //   82: ifnull -> 55
    //   85: aload #4
    //   87: invokeinterface getValue : ()Ljava/lang/Object;
    //   92: checkcast java/lang/String
    //   95: ldc ''
    //   97: invokevirtual equals : (Ljava/lang/Object;)Z
    //   100: ifne -> 55
    //   103: aload_1
    //   104: aload #4
    //   106: invokeinterface getKey : ()Ljava/lang/Object;
    //   111: checkcast java/lang/String
    //   114: aload #4
    //   116: invokeinterface getValue : ()Ljava/lang/Object;
    //   121: checkcast java/lang/String
    //   124: invokevirtual addHeader : (Ljava/lang/String;Ljava/lang/String;)V
    //   127: goto -> 55
    //   130: astore_1
    //   131: aload_0
    //   132: invokevirtual getLogTag : ()Ljava/lang/String;
    //   135: ldc 'Problem with URI syntax: %s'
    //   137: iconst_1
    //   138: anewarray java/lang/Object
    //   141: dup
    //   142: iconst_0
    //   143: aload_1
    //   144: invokevirtual getMessage : ()Ljava/lang/String;
    //   147: aastore
    //   148: invokestatic e : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   151: new com/amazon/device/ads/WebRequest$WebRequestException
    //   154: dup
    //   155: aload_0
    //   156: getstatic com/amazon/device/ads/WebRequest$WebRequestStatus.MALFORMED_URL : Lcom/amazon/device/ads/WebRequest$WebRequestStatus;
    //   159: ldc 'Problem with URI syntax'
    //   161: aload_1
    //   162: invokespecial <init> : (Lcom/amazon/device/ads/WebRequest;Lcom/amazon/device/ads/WebRequest$WebRequestStatus;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   165: athrow
    //   166: new org/apache/http/client/methods/HttpGet
    //   169: dup
    //   170: aload_3
    //   171: invokespecial <init> : (Ljava/net/URI;)V
    //   174: astore_1
    //   175: goto -> 42
    //   178: new org/apache/http/client/methods/HttpPost
    //   181: dup
    //   182: aload_3
    //   183: invokespecial <init> : (Ljava/net/URI;)V
    //   186: astore_1
    //   187: aload_0
    //   188: aload_1
    //   189: checkcast org/apache/http/client/methods/HttpPost
    //   192: invokespecial prepareRequestBody : (Lorg/apache/http/client/methods/HttpPost;)V
    //   195: goto -> 42
    //   198: aload_0
    //   199: aload_3
    //   200: invokevirtual toString : ()Ljava/lang/String;
    //   203: invokevirtual logUrl : (Ljava/lang/String;)V
    //   206: aload_0
    //   207: getfield logRequestBodyEnabled : Z
    //   210: ifeq -> 241
    //   213: aload_0
    //   214: invokevirtual getRequestBody : ()Ljava/lang/String;
    //   217: ifnull -> 241
    //   220: aload_0
    //   221: invokevirtual getLogTag : ()Ljava/lang/String;
    //   224: ldc_w 'Request Body: %s'
    //   227: iconst_1
    //   228: anewarray java/lang/Object
    //   231: dup
    //   232: iconst_0
    //   233: aload_0
    //   234: invokevirtual getRequestBody : ()Ljava/lang/String;
    //   237: aastore
    //   238: invokestatic d : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   241: aload_1
    //   242: areturn
    // Exception table:
    //   from	to	target	type
    //   2	8	130	java/net/URISyntaxException
  }
  
  protected WebRequest.WebResponse doHttpNetworkCall(URL paramURL) throws WebRequest.WebRequestException {
    HttpRequestBase httpRequestBase = createHttpRequest(paramURL);
    HttpParams httpParams = createHttpParams();
    if (this.client != null)
      closeConnection(); 
    this.client = (HttpClient)new DefaultHttpClient(httpParams);
    try {
      HttpResponse httpResponse = this.client.execute((HttpUriRequest)httpRequestBase);
      return parseResponse(httpResponse);
    } catch (ClientProtocolException clientProtocolException) {
      Log.e(getLogTag(), "Invalid client protocol: %s", new Object[] { clientProtocolException.getMessage() });
      throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.INVALID_CLIENT_PROTOCOL, "Invalid client protocol", clientProtocolException);
    } catch (IOException iOException) {
      Log.e(getLogTag(), "IOException during client execution: %s", new Object[] { iOException.getMessage() });
      throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.NETWORK_FAILURE, "IOException during client execution", iOException);
    } 
  }
  
  protected String getSubLogTag() {
    return LOG_TAG;
  }
  
  protected WebRequest.WebResponse parseResponse(HttpResponse paramHttpResponse) throws WebRequest.WebRequestException {
    WebRequest.WebResponse webResponse = new WebRequest.WebResponse(this);
    webResponse.setHttpStatusCode(paramHttpResponse.getStatusLine().getStatusCode());
    webResponse.setHttpStatus(paramHttpResponse.getStatusLine().getReasonPhrase());
    if (webResponse.getHttpStatusCode() == 200) {
      HttpEntity httpEntity = paramHttpResponse.getEntity();
      if (httpEntity != null && httpEntity.getContentLength() != 0L)
        try {
          webResponse.setInputStream(httpEntity.getContent());
          return webResponse;
        } catch (IOException iOException) {
          Log.e(getLogTag(), "IOException while reading the input stream from response: %s", new Object[] { iOException.getMessage() });
          throw new WebRequest.WebRequestException(this, WebRequest.WebRequestStatus.NETWORK_FAILURE, "IOException while reading the input stream from response", iOException);
        }  
    } 
    return webResponse;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\HttpClientWebRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */