package com.amazon.device.ads;

import java.util.HashMap;
import java.util.Set;

class SDKEvent {
  public static final String BRIDGE_NAME = "bridgeName";
  
  private final SDKEventType eventType;
  
  private final HashMap<String, String> parameters = new HashMap<String, String>();
  
  public SDKEvent(SDKEventType paramSDKEventType) {
    this.eventType = paramSDKEventType;
  }
  
  public SDKEventType getEventType() {
    return this.eventType;
  }
  
  public String getParameter(String paramString) {
    return this.parameters.get(paramString);
  }
  
  public Set<String> getParameterNames() {
    return this.parameters.keySet();
  }
  
  public SDKEvent setParameter(String paramString1, String paramString2) {
    this.parameters.put(paramString1, paramString2);
    return this;
  }
  
  public enum SDKEventType {
    BACK_BUTTON_PRESSED, BRIDGE_ADDED, CLOSED, DESTROYED, HIDDEN, READY, RENDERED, RESIZED, VISIBLE;
    
    static {
      DESTROYED = new SDKEventType("DESTROYED", 3);
      CLOSED = new SDKEventType("CLOSED", 4);
      READY = new SDKEventType("READY", 5);
      RESIZED = new SDKEventType("RESIZED", 6);
      BRIDGE_ADDED = new SDKEventType("BRIDGE_ADDED", 7);
      BACK_BUTTON_PRESSED = new SDKEventType("BACK_BUTTON_PRESSED", 8);
      $VALUES = new SDKEventType[] { RENDERED, VISIBLE, HIDDEN, DESTROYED, CLOSED, READY, RESIZED, BRIDGE_ADDED, BACK_BUTTON_PRESSED };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\SDKEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */