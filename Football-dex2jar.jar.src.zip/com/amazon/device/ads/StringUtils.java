package com.amazon.device.ads;

import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class StringUtils {
  private static final String LOGTAG = StringUtils.class.getSimpleName();
  
  public static boolean containsRegEx(String paramString1, String paramString2) {
    return Pattern.compile(paramString1).matcher(paramString2).find();
  }
  
  protected static boolean doesExceptionContainLockedDatabaseMessage(Exception paramException) {
    return (paramException == null || paramException.getMessage() == null) ? false : paramException.getMessage().contains("database is locked");
  }
  
  public static String getFirstMatch(String paramString1, String paramString2) {
    Matcher matcher = Pattern.compile(paramString1).matcher(paramString2);
    return matcher.find() ? matcher.group() : null;
  }
  
  public static final boolean isNullOrEmpty(String paramString) {
    return (paramString == null || paramString.equals(""));
  }
  
  public static final boolean isNullOrWhiteSpace(String paramString) {
    return (isNullOrEmpty(paramString) || paramString.trim().equals(""));
  }
  
  public static String readStringFromInputStream(InputStream paramInputStream) {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull -> 6
    //   4: aconst_null
    //   5: areturn
    //   6: new java/lang/StringBuilder
    //   9: dup
    //   10: invokespecial <init> : ()V
    //   13: astore_2
    //   14: sipush #4096
    //   17: newarray byte
    //   19: astore_3
    //   20: aload_0
    //   21: aload_3
    //   22: invokevirtual read : ([B)I
    //   25: istore_1
    //   26: iload_1
    //   27: iconst_m1
    //   28: if_icmpeq -> 68
    //   31: aload_2
    //   32: new java/lang/String
    //   35: dup
    //   36: aload_3
    //   37: iconst_0
    //   38: iload_1
    //   39: invokespecial <init> : ([BII)V
    //   42: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: pop
    //   46: goto -> 20
    //   49: astore_3
    //   50: getstatic com/amazon/device/ads/StringUtils.LOGTAG : Ljava/lang/String;
    //   53: ldc 'Unable to read the stream.'
    //   55: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   58: pop
    //   59: aload_0
    //   60: invokevirtual close : ()V
    //   63: aload_2
    //   64: invokevirtual toString : ()Ljava/lang/String;
    //   67: areturn
    //   68: aload_0
    //   69: invokevirtual close : ()V
    //   72: goto -> 63
    //   75: astore_0
    //   76: getstatic com/amazon/device/ads/StringUtils.LOGTAG : Ljava/lang/String;
    //   79: ldc 'IOException while trying to close the stream.'
    //   81: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   84: pop
    //   85: goto -> 63
    //   88: astore_0
    //   89: getstatic com/amazon/device/ads/StringUtils.LOGTAG : Ljava/lang/String;
    //   92: ldc 'IOException while trying to close the stream.'
    //   94: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   97: pop
    //   98: goto -> 63
    //   101: astore_2
    //   102: aload_0
    //   103: invokevirtual close : ()V
    //   106: aload_2
    //   107: athrow
    //   108: astore_0
    //   109: getstatic com/amazon/device/ads/StringUtils.LOGTAG : Ljava/lang/String;
    //   112: ldc 'IOException while trying to close the stream.'
    //   114: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   117: pop
    //   118: goto -> 106
    // Exception table:
    //   from	to	target	type
    //   20	26	49	java/io/IOException
    //   20	26	101	finally
    //   31	46	49	java/io/IOException
    //   31	46	101	finally
    //   50	59	101	finally
    //   59	63	88	java/io/IOException
    //   68	72	75	java/io/IOException
    //   102	106	108	java/io/IOException
  }
  
  public static String sha1(String paramString) {
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
      messageDigest.update(paramString.getBytes());
      byte[] arrayOfByte = messageDigest.digest();
      StringBuilder stringBuilder = new StringBuilder();
      for (int i = 0; i < arrayOfByte.length; i++)
        stringBuilder.append(Integer.toHexString(arrayOfByte[i] & 0xFF | 0x100).substring(1)); 
      return stringBuilder.toString();
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      return "";
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\StringUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */