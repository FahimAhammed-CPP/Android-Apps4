package com.amazon.device.ads;

import org.json.JSONObject;

class ResizeProperties {
  private final Boolean allowOffscreenDefault = Boolean.TRUE;
  
  private final String customClosePositionDefault = "top-right";
  
  private final JSONObject json = new JSONObject();
  
  public ResizeProperties() {
    JSONObject jSONObject = this.json;
    getClass();
    JSONUtils.put(jSONObject, "customClosePosition", "top-right");
    JSONUtils.put(this.json, "allowOffscreen", this.allowOffscreenDefault.booleanValue());
  }
  
  public Boolean getAllowOffscreen() {
    return Boolean.valueOf(JSONUtils.getBooleanFromJSON(this.json, "allowOffscreen", this.allowOffscreenDefault.booleanValue()));
  }
  
  public String getCustomClosePosition() {
    JSONObject jSONObject = this.json;
    getClass();
    return JSONUtils.getStringFromJSON(jSONObject, "customClosePosition", "top-right");
  }
  
  public int getHeight() {
    return JSONUtils.getIntegerFromJSON(this.json, "height", 0);
  }
  
  public int getOffsetX() {
    return JSONUtils.getIntegerFromJSON(this.json, "offsetX", 0);
  }
  
  public int getOffsetY() {
    return JSONUtils.getIntegerFromJSON(this.json, "offsetY", 0);
  }
  
  public int getWidth() {
    return JSONUtils.getIntegerFromJSON(this.json, "width", 0);
  }
  
  public void setAllowOffscreen(Boolean paramBoolean) {
    if (paramBoolean != null)
      JSONUtils.put(this.json, "allowOffscreen", paramBoolean.booleanValue()); 
  }
  
  public void setCustomClosePosition(String paramString) {
    if (paramString != null)
      JSONUtils.put(this.json, "customClosePosition", paramString); 
  }
  
  public void setHeight(int paramInt) {
    JSONUtils.put(this.json, "height", paramInt);
  }
  
  public void setOffsetX(int paramInt) {
    JSONUtils.put(this.json, "offsetX", paramInt);
  }
  
  public void setOffsetY(int paramInt) {
    JSONUtils.put(this.json, "offsetY", paramInt);
  }
  
  public void setWidth(int paramInt) {
    JSONUtils.put(this.json, "width", paramInt);
  }
  
  public JSONObject toJSONObject() {
    return this.json;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ResizeProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */