package com.amazon.device.ads;

import android.os.AsyncTask;

class AdMetricsSubmitAaxTask extends AsyncTask<WebRequest, Void, Void> {
  private static final String LOG_TAG = "AdMetricsSubmitTask";
  
  public Void doInBackground(WebRequest... paramVarArgs) {
    int j = paramVarArgs.length;
    int i = 0;
    while (i < j) {
      WebRequest webRequest = paramVarArgs[i];
      try {
        webRequest.makeCall();
      } catch (WebRequestException webRequestException) {
        switch (webRequestException.getStatus()) {
          default:
            i++;
            continue;
          case INVALID_CLIENT_PROTOCOL:
            Log.e("AdMetricsSubmitTask", "Unable to submit metrics for ad due to an Invalid Client Protocol, msg: %s", new Object[] { webRequestException.getMessage() });
          case NETWORK_FAILURE:
            Log.e("AdMetricsSubmitTask", "Unable to submit metrics for ad due to Network Failure, msg: %s", new Object[] { webRequestException.getMessage() });
          case MALFORMED_URL:
            Log.e("AdMetricsSubmitTask", "Unable to submit metrics for ad due to a Malformed Pixel URL, msg: %s", new Object[] { webRequestException.getMessage() });
            break;
          case UNSUPPORTED_ENCODING:
            break;
        } 
        Log.e("AdMetricsSubmitTask", "Unable to submit metrics for ad because of unsupported character encoding, msg: %s", new Object[] { webRequestException.getMessage() });
      } 
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdMetricsSubmitAaxTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */