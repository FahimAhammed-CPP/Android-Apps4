package com.amazon.device.ads;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebViewDatabase;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.util.Locale;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class AdLayout extends FrameLayout implements Ad {
  private static final String CONTENT_DESCRIPTION_AD_LAYOUT = "adLayoutObject";
  
  public static final int DEFAULT_TIMEOUT = 20000;
  
  static final String LAYOUT_NOT_RUN_ERR_MSG = "Can't load an ad because the view size cannot be determined.";
  
  static final String LAYOUT_PARAMS_NULL_ERR_MSG = "Can't load an ad because layout parameters are blank. Use setLayoutParams() to specify dimensions for this AdLayout.";
  
  static final String LOADING_IN_PROGRESS_LOG_MSG = "Can't load an ad because ad loading is already in progress";
  
  private static final String LOG_TAG = "AdLayout";
  
  private static ScheduledThreadPoolExecutor threadPool = new ScheduledThreadPoolExecutor(1);
  
  private View activityRootView = null;
  
  private AdController adController;
  
  private AdListener adListener;
  
  private final AdSize adSize;
  
  private AdTargetingOptions adTargetingOptions = null;
  
  private boolean attached = false;
  
  private final Context context;
  
  private AdContainer currentView;
  
  private boolean hasRegisterBroadcastReciever = false;
  
  private boolean isDestroyed = false;
  
  private boolean isInForeground;
  
  private boolean isInitialized = false;
  
  private boolean isParentViewMissingAtLoadTime = false;
  
  private int lastVisibility = 8;
  
  private AtomicBoolean needsToLoadAdOnLayout = new AtomicBoolean(false);
  
  private BroadcastReceiver screenStateReceiver;
  
  private boolean shouldDisableWebViewHardwareAcceleration;
  
  static {
    threadPool.setKeepAliveTime(60L, TimeUnit.SECONDS);
  }
  
  public AdLayout(Activity paramActivity) {
    this(paramActivity, AdSize.SIZE_AUTO);
  }
  
  public AdLayout(Activity paramActivity, AdSize paramAdSize) {
    super((Context)paramActivity);
    this.context = (Context)paramActivity;
    this.adSize = paramAdSize;
  }
  
  public AdLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.context = paramContext;
    this.adSize = determineAdSize(paramAttributeSet);
  }
  
  public AdLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    this.context = paramContext;
    this.adSize = determineAdSize(paramAttributeSet);
  }
  
  private void collapseAd() {
    if (getAdController().getAdState().equals(AdState.EXPANDED))
      ThreadUtils.scheduleOnMainThread(new Runnable() {
            public void run() {
              if (AdLayout.this.getAdController().getAdState().equals(AdState.EXPANDED))
                AdLayout.this.getAdController().closeAd(); 
            }
          }); 
  }
  
  private AdSize determineAdSize(AttributeSet paramAttributeSet) {
    String str2 = getAttributeValue(paramAttributeSet, "http://schemas.android.com/apk/lib/com.amazon.device.ads", "adSize");
    String str1 = str2;
    if (str2 == null) {
      String str = getAttributeValue(paramAttributeSet, "http://schemas.android.com/apk/res/" + this.context.getPackageName(), "adSize");
      str1 = str;
      if (str != null) {
        Log.forceLog(Log.Level.WARN, "AdLayout", "DEPRECATED - Please use the XML namespace \"http://schemas.android.com/apk/lib/com.amazon.device.ads\" for specifying AdLayout properties.", new Object[0]);
        str1 = str;
        if (str.toLowerCase(Locale.US).equals("custom")) {
          Log.forceLog(Log.Level.ERROR, "AdLayout", "Using \"custom\" or \"CUSTOM\" for the \"adSize\" property is no longer supported. Please specifiy a size or remove the property to use Auto Ad Size.", new Object[0]);
          throw new IllegalArgumentException("Using \"custom\" or \"CUSTOM\" for the \"adSize\" property is no longer supported. Please specifiy a size or remove the property to use Auto Ad Size.");
        } 
      } 
    } 
    return parseAdSize(str1);
  }
  
  private AdController getAdController() {
    initializeIfNecessary();
    if (this.adController == null)
      initializeAdController(); 
    return this.adController;
  }
  
  private static String getAttributeValue(AttributeSet paramAttributeSet, String paramString1, String paramString2) {
    return paramAttributeSet.getAttributeValue(paramString1, paramString2);
  }
  
  private void initializeAdController() {
    if (this.adController == null) {
      AdSize adSize;
      if (this.adSize == null) {
        adSize = AdSize.SIZE_AUTO;
      } else {
        adSize = this.adSize;
      } 
      setAdController(createAdController(adSize, this.context));
      this.adController.requestDisableHardwareAcceleration(this.shouldDisableWebViewHardwareAcceleration);
    } 
  }
  
  private boolean isReadyToLoad() {
    return (AdState.READY_TO_LOAD.equals(getAdController().getAdState()) || AdState.SHOWING.equals(getAdController().getAdState()));
  }
  
  private boolean loadAdWhenParentViewMissing() {
    if (getLayoutParams() == null) {
      Metrics.getInstance().getMetricsCollector().incrementMetric(Metrics.MetricType.AD_FAILED_NULL_LAYOUT_PARAMS);
      onRequestError("Can't load an ad because layout parameters are blank. Use setLayoutParams() to specify dimensions for this AdLayout.");
      return false;
    } 
    if (AndroidTargetUtils.isAtLeastAndroidAPI(11)) {
      setActivityRootView();
      if (isActivityRootViewNull()) {
        onRequestError("Ad load failed because root view could not be obtained from the activity.");
        return false;
      } 
      if (isActivityRootViewLayoutRequested()) {
        Log.d("AdLayout", "Activity root view layout is requested.", new Object[0]);
        deferAdLoadToLayoutEvent();
        setOnLayoutChangeListenerForRoot();
        return false;
      } 
      setFloatingWindowDimensions();
      return true;
    } 
    setFloatingWindowDimensions();
    return true;
  }
  
  private void onRequestError(String paramString) {
    getAdController().onRequestError(paramString);
  }
  
  private static AdSize parseAdSize(String paramString) {
    AdSize adSize2 = AdSize.SIZE_AUTO;
    AdSize adSize1 = adSize2;
    if (paramString != null) {
      paramString = paramString.toLowerCase(Locale.US);
      adSize1 = adSize2;
      if (!paramString.equals("auto")) {
        String[] arrayOfString = paramString.split("x");
        int j = 0;
        int i = 0;
        if (arrayOfString.length == 2) {
          j = NumberUtils.parseInt(arrayOfString[0], 0);
          i = NumberUtils.parseInt(arrayOfString[1], 0);
        } 
        adSize1 = new AdSize(j, i);
      } 
    } 
    return adSize1;
  }
  
  private void registerScreenStateBroadcastReceiver() {
    if (this.hasRegisterBroadcastReciever)
      return; 
    this.hasRegisterBroadcastReciever = true;
    this.screenStateReceiver = new BroadcastReceiver() {
        public void onReceive(Context param1Context, Intent param1Intent) {
          if (param1Intent.getAction().equals("android.intent.action.SCREEN_OFF") && AdLayout.this.isInForeground)
            AdLayout.this.getAdController().closeAd(); 
        }
      };
    IntentFilter intentFilter = new IntentFilter("android.intent.action.SCREEN_OFF");
    intentFilter.addAction("android.intent.action.USER_PRESENT");
    this.context.getApplicationContext().registerReceiver(this.screenStateReceiver, intentFilter);
  }
  
  private void setAdController(AdController paramAdController) {
    this.adController = paramAdController;
    this.adController.setCallback(createAdControlCallback());
  }
  
  private void startAdLoadUponLayout() {
    AdTargetingOptions adTargetingOptions = this.adTargetingOptions;
    AdSlot adSlot = (new AdSlot(getAdController(), adTargetingOptions)).setDeferredLoad(true);
    AdLoader.loadAds(getAdController().getTimeout(), adTargetingOptions, new AdSlot[] { adSlot });
    if (!getAndResetIsPrepared())
      onRequestError("Could not load ad on layout."); 
  }
  
  private void unregisterScreenStateBroadcastReceiver() {
    if (this.hasRegisterBroadcastReciever) {
      this.hasRegisterBroadcastReciever = false;
      this.context.getApplicationContext().unregisterReceiver(this.screenStateReceiver);
    } 
  }
  
  void adFailed(AdError paramAdError) {
    getAdController().adFailed(paramAdError);
  }
  
  void adShown() {
    getAdController().adShown();
  }
  
  void bypassAdRenderingProcess() {
    getAdController().setAdState(AdState.RENDERING);
    getAdController().adRendered("custom-render");
  }
  
  AdControlCallback createAdControlCallback() {
    return new AdLayoutAdControlCallback();
  }
  
  AdController createAdController(AdSize paramAdSize, Context paramContext) {
    return (new AdControllerFactory()).buildAdController(paramContext, paramAdSize);
  }
  
  void deferAdLoadToLayoutEvent() {
    setNeedsToLoadAdOnLayout(true);
    scheduleTaskForCheckingIfLayoutHasRun();
  }
  
  public void destroy() {
    if (!isInitialized())
      return; 
    Log.d("AdLayout", "Destroying the AdLayout", new Object[0]);
    this.isDestroyed = true;
    unregisterScreenStateBroadcastReceiver();
    getAdController().destroy();
  }
  
  void failLoadIfLayoutHasNotRun() {
    if (getAndSetNeedsToLoadAdOnLayout(false)) {
      Metrics.getInstance().getMetricsCollector().incrementMetric(Metrics.MetricType.AD_FAILED_LAYOUT_NOT_RUN);
      onRequestError("Can't load an ad because the view size cannot be determined.");
    } 
  }
  
  View getActivityRootView() {
    return this.activityRootView;
  }
  
  int getActivityRootViewDimension(boolean paramBoolean) {
    return paramBoolean ? this.activityRootView.getWidth() : this.activityRootView.getHeight();
  }
  
  AdData getAdData() {
    return getAdController().getAdData();
  }
  
  AdListener getAdListener() {
    return this.adListener;
  }
  
  public AdSize getAdSize() {
    AdController adController = getAdController();
    return (adController == null) ? null : adController.getAdSize();
  }
  
  boolean getAndResetIsPrepared() {
    return getAdController().getAndResetIsPrepared();
  }
  
  boolean getAndSetNeedsToLoadAdOnLayout(boolean paramBoolean) {
    return this.needsToLoadAdOnLayout.getAndSet(paramBoolean);
  }
  
  boolean getNeedsToLoadAdOnLayout() {
    return this.needsToLoadAdOnLayout.get();
  }
  
  int getRawScreenDimension(boolean paramBoolean) {
    WindowManager windowManager = (WindowManager)this.context.getSystemService("window");
    DisplayMetrics displayMetrics = new DisplayMetrics();
    windowManager.getDefaultDisplay().getMetrics(displayMetrics);
    return paramBoolean ? displayMetrics.widthPixels : displayMetrics.heightPixels;
  }
  
  public int getTimeout() {
    return (getAdController() == null) ? -1 : getAdController().getTimeout();
  }
  
  void initializeIfNecessary() {
    boolean bool;
    if (isInitialized())
      return; 
    long l = System.nanoTime();
    Log.d("AdLayout", "Initializing AdLayout.", new Object[0]);
    AmazonAdRegistration.initializeAdSDK(this.context);
    setContentDescription("adLayoutObject");
    if (isInEditMode()) {
      TextView textView = new TextView(this.context);
      textView.setText("AdLayout");
      textView.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
      textView.setGravity(17);
      addView((View)textView);
      this.isInitialized = true;
      return;
    } 
    if (getVisibility() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.isInForeground = bool;
    setHorizontalScrollBarEnabled(false);
    setVerticalScrollBarEnabled(false);
    if (isWebViewDatabaseNull(this.context)) {
      Log.forceLog(Log.Level.ERROR, "AdLayout", "Disabling ads. Local cache file is inaccessible so ads will fail if we try to create a WebView. Details of this Android bug found at: http://code.google.com/p/android/issues/detail?id=10789", new Object[0]);
      return;
    } 
    this.isInitialized = true;
    if (this.adListener == null)
      this.adListener = new DefaultAdListener("AdLayout"); 
    initializeAdController();
    this.adController.getMetricsCollector().startMetricInMillisecondsFromNanoseconds(Metrics.MetricType.AD_LAYOUT_INITIALIZATION, l);
    this.adController.getMetricsCollector().stopMetric(Metrics.MetricType.AD_LAYOUT_INITIALIZATION);
  }
  
  boolean isActivityRootViewLayoutRequested() {
    return this.activityRootView.isLayoutRequested();
  }
  
  boolean isActivityRootViewNull() {
    return (this.activityRootView == null);
  }
  
  public boolean isAdLoading() {
    return isLoading();
  }
  
  boolean isInitialized() {
    return this.isInitialized;
  }
  
  public boolean isLoading() {
    return (getAdController() == null) ? false : getAdController().getAdState().equals(AdState.LOADING);
  }
  
  boolean isParentViewMissingAtLoadTime() {
    return this.isParentViewMissingAtLoadTime;
  }
  
  boolean isWebViewDatabaseNull(Context paramContext) {
    return (WebViewDatabase.getInstance(paramContext) == null);
  }
  
  public boolean loadAd() {
    return loadAd(new AdTargetingOptions());
  }
  
  public boolean loadAd(AdTargetingOptions paramAdTargetingOptions) {
    AdTargetingOptions adTargetingOptions = paramAdTargetingOptions;
    if (paramAdTargetingOptions == null)
      adTargetingOptions = new AdTargetingOptions(); 
    this.adTargetingOptions = adTargetingOptions;
    if (getNeedsToLoadAdOnLayout()) {
      Log.e("AdLayout", "Can't load an ad because ad loading is already in progress", new Object[0]);
      return false;
    } 
    initializeIfNecessary();
    if (!isInitialized()) {
      Log.e("AdLayout", "The ad could not be initialized properly.", new Object[0]);
      return false;
    } 
    if (!isReadyToLoad()) {
      switch (getAdController().getAdState()) {
        default:
          Log.e("AdLayout", "Can't load an ad because ad loading is already in progress", new Object[0]);
          return false;
        case EXPANDED:
          Log.e("AdLayout", "An ad could not be loaded because of an unknown issue with web views.", new Object[0]);
          return false;
        case CLOSED:
          Log.e("AdLayout", "An ad could not be loaded because the AdLayout has been destroyed.", new Object[0]);
          return false;
        case RESIZED:
          break;
      } 
      Log.e("AdLayout", "An ad could not be loaded because another ad is currently expanded.", new Object[0]);
      return false;
    } 
    AdLoader.loadAds(getAdController().getTimeout(), adTargetingOptions, new AdSlot[] { new AdSlot(getAdController(), adTargetingOptions) });
    return getNeedsToLoadAdOnLayout() ? true : getAndResetIsPrepared();
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (isInEditMode())
      return; 
    this.attached = true;
    registerScreenStateBroadcastReceiver();
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.attached = false;
    collapseAd();
    unregisterScreenStateBroadcastReceiver();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.isDestroyed) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      if (!isInEditMode()) {
        getAdController().setWindowDimensions(paramInt3 - paramInt1, paramInt4 - paramInt2);
        if (getAndSetNeedsToLoadAdOnLayout(false)) {
          startAdLoadUponLayout();
          return;
        } 
      } 
    } 
  }
  
  protected void onWindowVisibilityChanged(int paramInt) {
    if (this.attached && this.lastVisibility != paramInt) {
      if (paramInt != 0) {
        this.isInForeground = false;
        collapseAd();
        unregisterScreenStateBroadcastReceiver();
        return;
      } 
    } else {
      return;
    } 
    if (paramInt == 0) {
      this.isInForeground = true;
      return;
    } 
  }
  
  boolean prepareAd(boolean paramBoolean) {
    if (paramBoolean) {
      Log.d("AdLayout", "Skipping ad layout preparation steps because the layout is already prepared.", new Object[0]);
      return true;
    } 
    if (!isReadyToLoad())
      return false; 
    if (getNeedsToLoadAdOnLayout()) {
      Log.e("AdLayout", "Can't load an ad because ad loading is already in progress", new Object[0]);
      return false;
    } 
    if (getAdSize().isAuto())
      Log.d("AdLayout", "Ad size to be determined automatically.", new Object[0]); 
    setIsParentViewMissingAtLoadTime();
    if (!getAdSize().isAuto() || !getAdController().areWindowDimensionsSet()) {
      if (isLayoutRequested() && getAdSize().isAuto() && !isParentViewMissingAtLoadTime()) {
        deferAdLoadToLayoutEvent();
        return false;
      } 
      if (isParentViewMissingAtLoadTime()) {
        Log.d("AdLayout", "The ad's parent view is missing at load time.", new Object[0]);
        return loadAdWhenParentViewMissing();
      } 
    } 
    return true;
  }
  
  int resolveLayoutParamForFloatingAd(boolean paramBoolean) {
    int i;
    if (paramBoolean) {
      i = (getLayoutParams()).width;
    } else {
      i = (getLayoutParams()).height;
    } 
    if (i == -1)
      return isActivityRootViewNull() ? getRawScreenDimension(paramBoolean) : getActivityRootViewDimension(paramBoolean); 
    int j = i;
    return (i == -2) ? 0 : j;
  }
  
  void scheduleTaskForCheckingIfLayoutHasRun() {
    Runnable runnable = new Runnable() {
        public void run() {
          AdLayout.this.failLoadIfLayoutHasNotRun();
        }
      };
    threadPool.schedule(runnable, getTimeout(), TimeUnit.MILLISECONDS);
  }
  
  void setActivityRootView() {
    this.activityRootView = ((Activity)this.context).getWindow().getDecorView().findViewById(16908290).getRootView();
  }
  
  void setFloatingWindowDimensions() {
    if ((getLayoutParams()).width == -1 || (getLayoutParams()).height == -1)
      Log.d("AdLayout", "The requested ad will scale based on the screen's dimensions because at least one AdLayout dimension is set to MATCH_PARENT but the AdLayout is currently missing a fixed-size parent view.", new Object[0]); 
    int i = resolveLayoutParamForFloatingAd(true);
    int j = resolveLayoutParamForFloatingAd(false);
    getAdController().setWindowDimensions(i, j);
  }
  
  void setIsParentViewMissingAtLoadTime() {
    boolean bool;
    if (getParent() == null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.isParentViewMissingAtLoadTime = bool;
  }
  
  void setIsParentViewMissingAtLoadTime(boolean paramBoolean) {
    this.isParentViewMissingAtLoadTime = paramBoolean;
  }
  
  public void setListener(AdListener paramAdListener) {
    if (paramAdListener == null) {
      this.adListener = new DefaultAdListener("AdLayout");
      return;
    } 
    this.adListener = paramAdListener;
  }
  
  void setNeedsToLoadAdOnLayout(boolean paramBoolean) {
    this.needsToLoadAdOnLayout.set(paramBoolean);
  }
  
  void setOnLayoutChangeListenerForRoot() {
    OnLayoutChangeListenerUtil.setOnLayoutChangeListenerForRoot(this);
  }
  
  void setShouldDisableWebViewHardwareAcceleration(boolean paramBoolean) {
    this.shouldDisableWebViewHardwareAcceleration = paramBoolean;
    if (this.adController != null)
      this.adController.requestDisableHardwareAcceleration(this.shouldDisableWebViewHardwareAcceleration); 
  }
  
  public void setTimeout(int paramInt) {
    AdController adController = getAdController();
    if (adController != null)
      adController.setTimeout(paramInt); 
  }
  
  boolean shouldDisableWebViewHardwareAcceleration() {
    return this.shouldDisableWebViewHardwareAcceleration;
  }
  
  class AdLayoutAdControlCallback implements AdControlCallback {
    private AdProperties properties;
    
    public int adClosing() {
      return AdLayout.this.getAdController().getAdState().equals(AdState.EXPANDED) ? 0 : 2;
    }
    
    boolean handleAdEvent(AdEvent param1AdEvent) {
      switch (param1AdEvent.getAdEventType()) {
        default:
          return false;
        case EXPANDED:
          AdLayout.this.adListener.onAdExpanded(AdLayout.this);
          return true;
        case CLOSED:
          AdLayout.this.adListener.onAdCollapsed(AdLayout.this);
          return true;
        case RESIZED:
          break;
      } 
      if (AdLayout.this.adListener instanceof ExtendedAdListener) {
        Rect rect = (Rect)param1AdEvent.getParameters().getParameter("positionOnScreen");
        ((ExtendedAdListener)AdLayout.this.adListener).onAdResized(rect);
      } 
      return true;
    }
    
    public boolean isAdReady(boolean param1Boolean) {
      return AdLayout.this.prepareAd(param1Boolean);
    }
    
    void notifyAdShowing(AdProperties param1AdProperties) {
      AdLayout.this.adShown();
      AdLayout.this.adListener.onAdLoaded(AdLayout.this, param1AdProperties);
    }
    
    public void onAdEvent(AdEvent param1AdEvent) {
      handleAdEvent(param1AdEvent);
    }
    
    public void onAdFailed(AdError param1AdError) {
      if (AdError.ErrorCode.NETWORK_TIMEOUT.equals(param1AdError.getCode()))
        AdLayout.access$602(AdLayout.this, (AdController)null); 
      AdLayout.this.adListener.onAdFailedToLoad(AdLayout.this, param1AdError);
    }
    
    public void onAdLoaded(AdProperties param1AdProperties) {
      this.properties = param1AdProperties;
      AdLayout.this.getAdController().render();
    }
    
    public void onAdRendered() {
      AdLayout.this.getAdController().getMetricsCollector().startMetric(Metrics.MetricType.AD_SHOW_LATENCY);
      if (AdLayout.this.currentView != null) {
        AdLayout.this.removeView((View)AdLayout.this.currentView);
        AdLayout.this.currentView.destroy();
      } 
      AdLayout.access$402(AdLayout.this, AdLayout.this.getAdController().getView());
      FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1, 17);
      AdLayout.this.addView((View)AdLayout.this.currentView, (ViewGroup.LayoutParams)layoutParams);
      notifyAdShowing(this.properties);
    }
    
    public void postAdRendered() {}
  }
  
  private static class OnLayoutChangeListenerUtil {
    @TargetApi(11)
    protected static void setOnLayoutChangeListenerForRoot(final AdLayout adLayout) {
      View.OnLayoutChangeListener onLayoutChangeListener = new View.OnLayoutChangeListener() {
          public void onLayoutChange(View param2View, int param2Int1, int param2Int2, int param2Int3, int param2Int4, int param2Int5, int param2Int6, int param2Int7, int param2Int8) {
            if (adLayout.getAndSetNeedsToLoadAdOnLayout(false)) {
              adLayout.setFloatingWindowDimensions();
              adLayout.startAdLoadUponLayout();
              adLayout.activityRootView.removeOnLayoutChangeListener(this);
            } 
          }
        };
      adLayout.activityRootView.addOnLayoutChangeListener(onLayoutChangeListener);
    }
  }
  
  static final class null implements View.OnLayoutChangeListener {
    public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      if (adLayout.getAndSetNeedsToLoadAdOnLayout(false)) {
        adLayout.setFloatingWindowDimensions();
        adLayout.startAdLoadUponLayout();
        adLayout.activityRootView.removeOnLayoutChangeListener(this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */