package com.amazon.device.ads;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

class ThreadUtils {
  private static RunnableExecutor mainThreadExecutor;
  
  private static RunnableExecutor runnableExecutor = new ThreadPoolRunnableExecutor();
  
  static {
    mainThreadExecutor = new MainThreadRunnableExecutor();
  }
  
  public static final <T> void executeAsyncTask(final AsyncTask<T, ?, ?> task, T... params) {
    if (Looper.myLooper() == Looper.getMainLooper()) {
      AndroidTargetUtils.executeAsyncTask(task, params);
      return;
    } 
    (new Handler(Looper.getMainLooper())).post(new Runnable() {
          public void run() {
            AndroidTargetUtils.executeAsyncTask(task, params);
          }
        });
  }
  
  public static void executeOnMainThread(Runnable paramRunnable) {
    if (isOnMainThread()) {
      paramRunnable.run();
      return;
    } 
    scheduleOnMainThread(paramRunnable);
  }
  
  public static void executeRunnable(Runnable paramRunnable) {
    runnableExecutor.execute(paramRunnable);
  }
  
  public static void executeRunnableWithThreadCheck(Runnable paramRunnable) {
    if (isOnMainThread()) {
      executeRunnable(paramRunnable);
      return;
    } 
    paramRunnable.run();
  }
  
  public static boolean isOnMainThread() {
    return ThreadVerify.getInstance().isOnMainThread();
  }
  
  public static void scheduleOnMainThread(Runnable paramRunnable) {
    mainThreadExecutor.execute(paramRunnable);
  }
  
  static void setRunnableExecutor(RunnableExecutor paramRunnableExecutor) {
    runnableExecutor = paramRunnableExecutor;
  }
  
  public static class MainThreadRunnableExecutor implements RunnableExecutor {
    public void execute(Runnable param1Runnable) {
      (new Handler(Looper.getMainLooper())).post(param1Runnable);
    }
  }
  
  public static interface RunnableExecutor {
    void execute(Runnable param1Runnable);
  }
  
  public static class ThreadPoolRunnableExecutor implements RunnableExecutor {
    private static final int keepAliveTimeSeconds = 30;
    
    private static final int maxNumberThreads = 3;
    
    private static final int numberThreads = 1;
    
    private ExecutorService executorService = new ThreadPoolExecutor(1, 3, 30L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
    
    public void execute(Runnable param1Runnable) {
      this.executorService.submit(param1Runnable);
    }
  }
  
  static class ThreadVerify {
    private static ThreadVerify instance = new ThreadVerify();
    
    static ThreadVerify getInstance() {
      return instance;
    }
    
    boolean isOnMainThread() {
      return (Looper.getMainLooper().getThread() == Thread.currentThread());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ThreadUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */