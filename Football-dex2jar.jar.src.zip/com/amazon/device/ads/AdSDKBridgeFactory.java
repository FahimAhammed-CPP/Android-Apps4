package com.amazon.device.ads;

interface AdSDKBridgeFactory {
  AdSDKBridge createAdSDKBridge(AdControlAccessor paramAdControlAccessor);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdSDKBridgeFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */