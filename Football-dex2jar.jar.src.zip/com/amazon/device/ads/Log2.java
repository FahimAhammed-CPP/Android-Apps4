package com.amazon.device.ads;

class Log2 {
  private final LogStatic logAdapter = new LogStatic();
  
  public void d(String paramString1, String paramString2, Object... paramVarArgs) {
    this.logAdapter.d(paramString1, paramString2, paramVarArgs);
  }
  
  public void e(String paramString1, String paramString2, Object... paramVarArgs) {
    this.logAdapter.e(paramString1, paramString2, paramVarArgs);
  }
  
  public void i(String paramString1, String paramString2, Object... paramVarArgs) {
    this.logAdapter.i(paramString1, paramString2, paramVarArgs);
  }
  
  public void v(String paramString1, String paramString2, Object... paramVarArgs) {
    this.logAdapter.v(paramString1, paramString2, paramVarArgs);
  }
  
  public void w(String paramString1, String paramString2, Object... paramVarArgs) {
    this.logAdapter.w(paramString1, paramString2, paramVarArgs);
  }
  
  private static class LogStatic {
    private LogStatic() {}
    
    public void d(String param1String1, String param1String2, Object... param1VarArgs) {
      Log.d(param1String1, param1String2, param1VarArgs);
    }
    
    public void e(String param1String1, String param1String2, Object... param1VarArgs) {
      Log.e(param1String1, param1String2, param1VarArgs);
    }
    
    public void i(String param1String1, String param1String2, Object... param1VarArgs) {
      Log.i(param1String1, param1String2, param1VarArgs);
    }
    
    public void v(String param1String1, String param1String2, Object... param1VarArgs) {
      Log.v(param1String1, param1String2, param1VarArgs);
    }
    
    public void w(String param1String1, String param1String2, Object... param1VarArgs) {
      Log.w(param1String1, param1String2, param1VarArgs);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Log2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */