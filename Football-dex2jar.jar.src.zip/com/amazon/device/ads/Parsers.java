package com.amazon.device.ads;

class Parsers {
  public static class IntegerParser {
    private int defaultValue;
    
    private String parseErrorLogMessage;
    
    private String parseErrorLogTag;
    
    public int parse(String param1String) {
      int j = this.defaultValue;
      int i = j;
      if (!StringUtils.isNullOrWhiteSpace(param1String))
        try {
          i = Integer.parseInt(param1String);
        } catch (NumberFormatException numberFormatException) {
          i = j;
        }  
      return i;
    }
    
    public IntegerParser setDefaultValue(int param1Int) {
      this.defaultValue = param1Int;
      return this;
    }
    
    public IntegerParser setParseErrorLogMessage(String param1String) {
      this.parseErrorLogMessage = param1String;
      return this;
    }
    
    public IntegerParser setParseErrorLogTag(String param1String) {
      this.parseErrorLogTag = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Parsers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */