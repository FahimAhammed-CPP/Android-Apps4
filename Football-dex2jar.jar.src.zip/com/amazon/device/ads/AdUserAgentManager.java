package com.amazon.device.ads;

import android.content.Context;
import android.os.Looper;

class AdUserAgentManager implements UserAgentManager {
  private String userAgentStringWithSDKVersion;
  
  private String userAgentStringWithoutSDKVersion;
  
  public String getUserAgentString() {
    return this.userAgentStringWithSDKVersion;
  }
  
  public void populateUserAgentString(final Context context) {
    if (this.userAgentStringWithSDKVersion == null) {
      if (AndroidTargetUtils.isAtLeastAndroidAPI(7)) {
        this.userAgentStringWithoutSDKVersion = System.getProperty("http.agent");
        this.userAgentStringWithSDKVersion = this.userAgentStringWithoutSDKVersion + " " + Version.getUserAgentSDKVersion();
        return;
      } 
    } else {
      return;
    } 
    if (Thread.currentThread() == Looper.getMainLooper().getThread()) {
      this.userAgentStringWithoutSDKVersion = WebViewFactory.getInstance().createWebView(context).getSettings().getUserAgentString();
      this.userAgentStringWithSDKVersion = this.userAgentStringWithoutSDKVersion + " " + Version.getUserAgentSDKVersion();
      return;
    } 
    ThreadUtils.executeOnMainThread(new Runnable() {
          public void run() {
            AdUserAgentManager.access$002(AdUserAgentManager.this, WebViewFactory.getInstance().createWebView(context).getSettings().getUserAgentString());
            AdUserAgentManager.access$102(AdUserAgentManager.this, AdUserAgentManager.this.userAgentStringWithoutSDKVersion + " " + Version.getUserAgentSDKVersion());
          }
        });
  }
  
  public void setUserAgentString(String paramString) {
    if (paramString != null && !paramString.equals(this.userAgentStringWithoutSDKVersion)) {
      this.userAgentStringWithoutSDKVersion = paramString;
      this.userAgentStringWithSDKVersion = paramString + " " + Version.getUserAgentSDKVersion();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdUserAgentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */