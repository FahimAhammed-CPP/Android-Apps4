package com.amazon.device.ads;

import org.json.JSONArray;
import org.json.JSONException;

public class AdProperties {
  public static final int CAN_EXPAND1 = 1003;
  
  public static final int CAN_EXPAND2 = 1004;
  
  public static final int CAN_PLAY_AUDIO1 = 1001;
  
  public static final int CAN_PLAY_AUDIO2 = 1002;
  
  public static final int CAN_PLAY_VIDEO = 1014;
  
  public static final int HTML = 1007;
  
  public static final int INTERSTITIAL = 1008;
  
  private static final String LOG_TAG = "AdProperties";
  
  public static final int MRAID1 = 1016;
  
  public static final int MRAID2 = 1017;
  
  public static final int REQUIRES_TRANSPARENCY = 1031;
  
  public static final int VIDEO_INTERSTITIAL = 1030;
  
  private AdType adType_;
  
  private boolean canExpand_ = false;
  
  private boolean canPlayAudio_ = false;
  
  private boolean canPlayVideo_ = false;
  
  protected AdProperties() {}
  
  AdProperties(JSONArray paramJSONArray) {
    if (paramJSONArray != null)
      for (int i = 0;; i++) {
        if (i < paramJSONArray.length()) {
          try {
            switch (paramJSONArray.getInt(i)) {
              case 1001:
              case 1002:
                this.canPlayAudio_ = true;
                break;
              case 1003:
              case 1004:
                this.canExpand_ = true;
                break;
              case 1007:
                this.adType_ = AdType.IMAGE_BANNER;
                break;
              case 1008:
                this.adType_ = AdType.INTERSTITIAL;
                break;
              case 1014:
                this.canPlayVideo_ = true;
                break;
              case 1016:
                this.adType_ = AdType.MRAID_1;
                break;
              case 1017:
                this.adType_ = AdType.MRAID_2;
                break;
            } 
          } catch (JSONException jSONException) {
            Log.w("AdProperties", "Unable to parse creative type: %s", new Object[] { jSONException.getMessage() });
          } 
        } else {
          return;
        } 
      }  
  }
  
  public boolean canExpand() {
    return this.canExpand_;
  }
  
  public boolean canPlayAudio() {
    return this.canPlayAudio_;
  }
  
  public boolean canPlayVideo() {
    return this.canPlayVideo_;
  }
  
  public AdType getAdType() {
    return this.adType_;
  }
  
  void setAdType(AdType paramAdType) {
    this.adType_ = paramAdType;
  }
  
  void setCanExpand(boolean paramBoolean) {
    this.canExpand_ = paramBoolean;
  }
  
  void setCanPlayAudio(boolean paramBoolean) {
    this.canPlayAudio_ = paramBoolean;
  }
  
  void setCanPlayVideo(boolean paramBoolean) {
    this.canPlayVideo_ = paramBoolean;
  }
  
  public enum AdType {
    IMAGE_BANNER("Image Banner"),
    INTERSTITIAL("Image Banner"),
    MODELESS_INTERSTITIAL("Image Banner"),
    MRAID_1("MRAID 1.0"),
    MRAID_2("MRAID 2.0");
    
    private final String adTypeMetricTag;
    
    private final String type;
    
    static {
      $VALUES = new AdType[] { IMAGE_BANNER, MRAID_1, MRAID_2, INTERSTITIAL, MODELESS_INTERSTITIAL };
    }
    
    AdType(String param1String1, String param1String2) {
      this.type = param1String1;
      this.adTypeMetricTag = param1String2;
    }
    
    String getAdTypeMetricTag() {
      return this.adTypeMetricTag;
    }
    
    public String toString() {
      return this.type;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\AdProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */