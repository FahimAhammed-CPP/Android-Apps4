package com.amazon.device.ads;

class ReflectionUtils {
  public static boolean isClassAvailable(String paramString) {
    try {
      Class.forName(paramString);
      return true;
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\ReflectionUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */