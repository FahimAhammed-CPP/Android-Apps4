package com.amazon.device.ads;

import org.json.JSONObject;

class Size {
  private int height;
  
  private int width;
  
  public Size(int paramInt1, int paramInt2) {
    this.width = paramInt1;
    this.height = paramInt2;
  }
  
  public Size(String paramString) {
    byte b1 = 0;
    byte b2 = 0;
    int j = b2;
    int i = b1;
    if (paramString != null) {
      String[] arrayOfString = paramString.split("x");
      j = b2;
      i = b1;
      if (arrayOfString != null) {
        j = b2;
        i = b1;
        if (arrayOfString.length == 2) {
          i = Math.max(parseInt(arrayOfString[0], 0), 0);
          j = Math.max(parseInt(arrayOfString[1], 0), 0);
        } 
      } 
    } 
    this.width = i;
    this.height = j;
  }
  
  private static int parseInt(String paramString, int paramInt) {
    try {
      return Integer.parseInt(paramString);
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
  
  public int getHeight() {
    return this.height;
  }
  
  public int getWidth() {
    return this.width;
  }
  
  public void setHeight(int paramInt) {
    this.height = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.width = paramInt;
  }
  
  public JSONObject toJSONObject() {
    JSONObject jSONObject = new JSONObject();
    JSONUtils.put(jSONObject, "width", this.width);
    JSONUtils.put(jSONObject, "height", this.height);
    return jSONObject;
  }
  
  public String toString() {
    return this.width + "x" + this.height;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\ads\Size.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */