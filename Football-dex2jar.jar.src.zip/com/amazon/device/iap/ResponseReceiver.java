package com.amazon.device.iap;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.amazon.device.iap.internal.d;
import com.amazon.device.iap.internal.util.e;

public final class ResponseReceiver extends BroadcastReceiver {
  private static final String TAG = ResponseReceiver.class.getSimpleName();
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    try {
      d.d().a(paramContext, paramIntent);
      return;
    } catch (Exception exception) {
      e.b(TAG, "Error in onReceive: " + exception);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\ResponseReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */