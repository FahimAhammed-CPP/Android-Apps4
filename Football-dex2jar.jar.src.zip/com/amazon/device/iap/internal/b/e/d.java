package com.amazon.device.iap.internal.b.e;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.internal.model.UserDataResponseBuilder;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.UserData;
import com.amazon.device.iap.model.UserDataResponse;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;

public final class d extends b {
  private static final String b = d.class.getSimpleName();
  
  public d(e parame) {
    super(parame, "1.0");
  }
  
  protected boolean a(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    e.a(b, "onSuccessInternal: result = " + paramSuccessResult);
    Map map = paramSuccessResult.getData();
    e.a(b, "data: " + map);
    String str = (String)map.get("userId");
    e e = b();
    if (com.amazon.device.iap.internal.util.d.a(str)) {
      e.d().a((new UserDataResponseBuilder()).setRequestId(e.c()).setRequestStatus(UserDataResponse.RequestStatus.FAILED).build());
      return false;
    } 
    UserData userData = (new UserDataBuilder()).setUserId(str).setMarketplace(a).build();
    UserDataResponse userDataResponse = (new UserDataResponseBuilder()).setRequestId(e.c()).setRequestStatus(UserDataResponse.RequestStatus.SUCCESSFUL).setUserData(userData).build();
    e.d().a("userId", userData.getUserId());
    e.d().a(userDataResponse);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\e\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */