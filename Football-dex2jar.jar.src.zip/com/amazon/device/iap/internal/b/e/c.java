package com.amazon.device.iap.internal.b.e;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.internal.model.UserDataResponseBuilder;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.UserData;
import com.amazon.device.iap.model.UserDataResponse;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;

public final class c extends b {
  private static final String b = c.class.getSimpleName();
  
  public c(e parame) {
    super(parame, "2.0");
  }
  
  protected boolean a(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    e.a(b, "onResult: result = " + paramSuccessResult);
    Map map = paramSuccessResult.getData();
    e.a(b, "data: " + map);
    String str1 = (String)map.get("userId");
    String str2 = (String)map.get("marketplace");
    e e = b();
    if (d.a(str1) || d.a(str2)) {
      e.d().a((new UserDataResponseBuilder()).setRequestId(e.c()).setRequestStatus(UserDataResponse.RequestStatus.FAILED).build());
      return false;
    } 
    UserData userData = (new UserDataBuilder()).setUserId(str1).setMarketplace(str2).build();
    UserDataResponse userDataResponse = (new UserDataResponseBuilder()).setRequestId(e.c()).setRequestStatus(UserDataResponse.RequestStatus.SUCCESSFUL).setUserData(userData).build();
    e.d().a("userId", userData.getUserId());
    e.d().a(userDataResponse);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\e\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */