package com.amazon.device.iap.internal.b.e;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.i;

abstract class b extends i {
  protected static final String a = null;
  
  public b(e parame, String paramString) {
    super(parame, "get_userId", paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\e\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */