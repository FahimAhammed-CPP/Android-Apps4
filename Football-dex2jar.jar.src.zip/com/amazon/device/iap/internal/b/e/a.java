package com.amazon.device.iap.internal.b.e;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.model.UserDataResponseBuilder;
import com.amazon.device.iap.model.RequestId;
import com.amazon.device.iap.model.UserDataResponse;

public final class a extends e {
  public a(RequestId paramRequestId) {
    super(paramRequestId);
    c c = new c(this);
    c.b(new d(this));
    a(c);
  }
  
  public void a() {
    a(d().a());
  }
  
  public void b() {
    UserDataResponse userDataResponse2 = (UserDataResponse)d().a();
    UserDataResponse userDataResponse1 = userDataResponse2;
    if (userDataResponse2 == null)
      userDataResponse1 = (new UserDataResponseBuilder()).setRequestId(c()).setRequestStatus(UserDataResponse.RequestStatus.FAILED).build(); 
    a(userDataResponse1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\e\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */