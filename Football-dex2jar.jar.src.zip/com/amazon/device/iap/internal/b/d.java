package com.amazon.device.iap.internal.b;

public class d extends RuntimeException {
  private final String a;
  
  private final String b;
  
  private final String c;
  
  public d(String paramString1, String paramString2, String paramString3) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
  }
  
  public String a() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */