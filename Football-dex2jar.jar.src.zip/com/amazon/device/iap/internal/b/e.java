package com.amazon.device.iap.internal.b;

import android.content.Context;
import android.os.Handler;
import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.internal.d;
import com.amazon.device.iap.internal.util.b;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.RequestId;
import com.amazon.device.iap.model.UserDataResponse;

public class e {
  private static final String a = e.class.getSimpleName();
  
  private final RequestId b;
  
  private final h c;
  
  private i d;
  
  public e(RequestId paramRequestId) {
    this.b = paramRequestId;
    this.c = new h();
    this.d = null;
  }
  
  public void a() {}
  
  protected void a(i parami) {
    this.d = parami;
  }
  
  protected void a(Object paramObject) {
    a(paramObject, null);
  }
  
  protected void a(Object paramObject, i parami) {
    d.a(paramObject, "response");
    Context context = d.d().b();
    PurchasingListener purchasingListener = d.d().a();
    if (context == null || purchasingListener == null) {
      com.amazon.device.iap.internal.util.e.a(a, "PurchasingListener is not set. Dropping response: " + paramObject);
      return;
    } 
    paramObject = new Runnable(this, paramObject, purchasingListener, parami) {
        public void run() {
          this.d.d().a("notifyListenerResult", Boolean.FALSE);
          try {
            if (this.a instanceof ProductDataResponse) {
              this.b.onProductDataResponse((ProductDataResponse)this.a);
            } else if (this.a instanceof UserDataResponse) {
              this.b.onUserDataResponse((UserDataResponse)this.a);
            } else if (this.a instanceof PurchaseUpdatesResponse) {
              PurchaseUpdatesResponse purchaseUpdatesResponse = (PurchaseUpdatesResponse)this.a;
              this.b.onPurchaseUpdatesResponse(purchaseUpdatesResponse);
              Object object = this.d.d().a("newCursor");
              if (object != null && object instanceof String)
                b.a(purchaseUpdatesResponse.getUserData().getUserId(), object.toString()); 
            } else if (this.a instanceof PurchaseResponse) {
              this.b.onPurchaseResponse((PurchaseResponse)this.a);
            } else {
              com.amazon.device.iap.internal.util.e.b(e.f(), "Unknown response type:" + this.a.getClass().getName());
            } 
            this.d.d().a("notifyListenerResult", Boolean.TRUE);
          } catch (Throwable throwable) {
            com.amazon.device.iap.internal.util.e.b(e.f(), "Error in sendResponse: " + throwable);
          } 
          if (this.c != null) {
            this.c.a(true);
            this.c.a_();
          } 
        }
      };
    (new Handler(context.getMainLooper())).post((Runnable)paramObject);
  }
  
  public void b() {}
  
  public RequestId c() {
    return this.b;
  }
  
  public h d() {
    return this.c;
  }
  
  public void e() {
    if (this.d != null) {
      this.d.a_();
      return;
    } 
    a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */