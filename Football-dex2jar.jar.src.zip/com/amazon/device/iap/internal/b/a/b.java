package com.amazon.device.iap.internal.b.a;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.c.a;
import com.amazon.device.iap.internal.model.PurchaseResponseBuilder;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.internal.util.a;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.UserData;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;
import org.json.JSONObject;

public final class b extends c {
  private static final String a = b.class.getSimpleName();
  
  public b(e parame) {
    super(parame, "1.0");
  }
  
  private void a(String paramString1, String paramString2, String paramString3) {
    if (paramString1 != null && paramString2 != null && paramString3 != null)
      try {
        JSONObject jSONObject = new JSONObject(paramString3);
        if (PurchaseResponse.RequestStatus.safeValueOf(jSONObject.getString("orderStatus")) == PurchaseResponse.RequestStatus.SUCCESSFUL) {
          Receipt receipt = a.a(jSONObject, paramString2, paramString1);
          a.a().a(paramString1, paramString2, receipt.getReceiptId(), paramString3);
          return;
        } 
        return;
      } catch (Throwable throwable) {
        e.b(a, "Error in savePendingReceipt: " + throwable);
        return;
      }  
  }
  
  protected boolean a(SuccessResult paramSuccessResult) throws Exception {
    Map map = paramSuccessResult.getData();
    e.a(a, "data: " + map);
    String str3 = (String)getCommandData().get("requestId");
    String str1 = (String)map.get("userId");
    String str2 = (String)map.get("marketplace");
    String str4 = (String)map.get("receipt");
    if (str3 == null || !com.amazon.device.iap.internal.c.b.a().a(str3)) {
      b().d().b();
      return true;
    } 
    if (d.a(str4)) {
      a(str1, str2, str3, PurchaseResponse.RequestStatus.FAILED);
      return false;
    } 
    JSONObject jSONObject = new JSONObject(str4);
    PurchaseResponse.RequestStatus requestStatus = PurchaseResponse.RequestStatus.safeValueOf(jSONObject.getString("orderStatus"));
    if (requestStatus == PurchaseResponse.RequestStatus.SUCCESSFUL) {
      e e1;
      try {
        Receipt receipt = a.a(jSONObject, str1, str3);
        if (ProductType.CONSUMABLE == receipt.getProductType())
          a(str3, str1, str4); 
        e1 = b();
        userData = (new UserDataBuilder()).setUserId(str1).setMarketplace(str2).build();
        PurchaseResponse purchaseResponse1 = (new PurchaseResponseBuilder()).setRequestId(e1.c()).setRequestStatus(requestStatus).setUserData(userData).setReceipt(receipt).build();
        e1.d().a(purchaseResponse1);
        return true;
      } catch (Throwable throwable) {
        a((String)userData, str2, (String)e1, PurchaseResponse.RequestStatus.FAILED);
        return false;
      } 
    } 
    jSONObject = null;
    e e = b();
    UserData userData = (new UserDataBuilder()).setUserId((String)userData).setMarketplace(str2).build();
    PurchaseResponse purchaseResponse = (new PurchaseResponseBuilder()).setRequestId(e.c()).setRequestStatus(requestStatus).setUserData(userData).setReceipt((Receipt)jSONObject).build();
    e.d().a(purchaseResponse);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */