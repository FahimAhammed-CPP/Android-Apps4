package com.amazon.device.iap.internal.b.a;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.f.b;
import com.amazon.device.iap.internal.b.f.c;
import com.amazon.device.iap.internal.b.i;
import com.amazon.device.iap.internal.model.PurchaseResponseBuilder;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.RequestId;

public final class d extends e {
  public d(RequestId paramRequestId) {
    super(paramRequestId);
    a a = new a(this);
    a.b(new b(this));
    a(a);
  }
  
  public void a() {
    boolean bool;
    PurchaseResponse purchaseResponse = (PurchaseResponse)d().a();
    if (purchaseResponse == null)
      return; 
    Receipt receipt = purchaseResponse.getReceipt();
    if (receipt != null) {
      bool = true;
    } else {
      bool = false;
    } 
    c c = new c(this, bool);
    if (bool && (ProductType.ENTITLED == receipt.getProductType() || ProductType.SUBSCRIPTION == receipt.getProductType()))
      c.b((i)new b(this, c().toString())); 
    a(purchaseResponse, (i)c);
  }
  
  public void b() {
    PurchaseResponse purchaseResponse2 = (PurchaseResponse)d().a();
    PurchaseResponse purchaseResponse1 = purchaseResponse2;
    if (purchaseResponse2 == null)
      purchaseResponse1 = (new PurchaseResponseBuilder()).setRequestId(c()).setRequestStatus(PurchaseResponse.RequestStatus.FAILED).build(); 
    a(purchaseResponse1, (i)new c(this, false));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */