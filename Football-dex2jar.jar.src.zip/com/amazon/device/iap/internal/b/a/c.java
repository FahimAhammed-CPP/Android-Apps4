package com.amazon.device.iap.internal.b.a;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.i;
import com.amazon.device.iap.internal.model.PurchaseResponseBuilder;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.UserData;

abstract class c extends i {
  c(e parame, String paramString) {
    super(parame, "purchase_response", paramString);
  }
  
  protected void a(String paramString1, String paramString2, String paramString3, PurchaseResponse.RequestStatus paramRequestStatus) {
    e e = b();
    UserData userData = (new UserDataBuilder()).setUserId(paramString1).setMarketplace(paramString2).build();
    PurchaseResponse purchaseResponse = (new PurchaseResponseBuilder()).setRequestId(e.c()).setRequestStatus(paramRequestStatus).setUserData(userData).setReceipt(null).build();
    e.d().a(purchaseResponse);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */