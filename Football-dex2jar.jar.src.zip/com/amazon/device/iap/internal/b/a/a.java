package com.amazon.device.iap.internal.b.a;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.model.PurchaseResponseBuilder;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.UserData;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;
import org.json.JSONObject;

public final class a extends c {
  private static final String a = a.class.getSimpleName();
  
  public a(e parame) {
    super(parame, "2.0");
  }
  
  protected boolean a(SuccessResult paramSuccessResult) throws Exception {
    Map map = paramSuccessResult.getData();
    e.a(a, "data: " + map);
    String str4 = (String)getCommandData().get("requestId");
    String str2 = (String)map.get("userId");
    String str3 = (String)map.get("marketplace");
    String str1 = (String)map.get("receipt");
    if (d.a(str1)) {
      a(str2, str3, str4, PurchaseResponse.RequestStatus.FAILED);
      return false;
    } 
    JSONObject jSONObject = new JSONObject(str1);
    PurchaseResponse.RequestStatus requestStatus = PurchaseResponse.RequestStatus.safeValueOf(jSONObject.getString("orderStatus"));
    if (requestStatus == PurchaseResponse.RequestStatus.SUCCESSFUL) {
      e e1;
      try {
        Receipt receipt = com.amazon.device.iap.internal.util.a.a(jSONObject, str2, str4);
        e1 = b();
        userData = (new UserDataBuilder()).setUserId(str2).setMarketplace(str3).build();
        PurchaseResponse purchaseResponse1 = (new PurchaseResponseBuilder()).setRequestId(e1.c()).setRequestStatus(requestStatus).setUserData(userData).setReceipt(receipt).build();
        e1.d().a(purchaseResponse1);
        return true;
      } catch (Throwable throwable) {
        a((String)userData, str3, (String)e1, PurchaseResponse.RequestStatus.FAILED);
        return false;
      } 
    } 
    jSONObject = null;
    e e = b();
    UserData userData = (new UserDataBuilder()).setUserId((String)userData).setMarketplace(str3).build();
    PurchaseResponse purchaseResponse = (new PurchaseResponseBuilder()).setRequestId(e.c()).setRequestStatus(requestStatus).setUserData(userData).setReceipt((Receipt)jSONObject).build();
    e.d().a(purchaseResponse);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */