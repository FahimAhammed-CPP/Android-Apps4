package com.amazon.device.iap.internal.b.f;

import com.amazon.device.iap.internal.b.e;

public final class b extends a {
  public b(e parame, String paramString) {
    super(parame, "1.0");
    getCommandData().put("requestId", paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */