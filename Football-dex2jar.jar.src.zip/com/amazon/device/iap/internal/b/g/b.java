package com.amazon.device.iap.internal.b.g;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.c.a;
import com.amazon.device.iap.model.FulfillmentResult;
import com.amazon.device.iap.model.RequestId;
import java.util.HashSet;

public final class b extends e {
  private final String a;
  
  private final FulfillmentResult b;
  
  public b(RequestId paramRequestId, String paramString, FulfillmentResult paramFulfillmentResult) {
    super(paramRequestId);
    HashSet<String> hashSet = new HashSet();
    hashSet.add(paramString);
    this.a = paramString;
    this.b = paramFulfillmentResult;
    a(new a(this, hashSet, paramFulfillmentResult.toString()));
  }
  
  public void a() {}
  
  public void b() {
    if (FulfillmentResult.FULFILLED == this.b || FulfillmentResult.UNAVAILABLE == this.b) {
      String str = a.a().c(this.a);
      if (str != null) {
        (new com.amazon.device.iap.internal.b.f.b(this, str)).a_();
        a.a().a(this.a);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\g\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */