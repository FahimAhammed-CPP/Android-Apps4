package com.amazon.device.iap.internal.b.b;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.model.PurchaseResponseBuilder;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.RequestId;

public final class d extends e {
  public d(RequestId paramRequestId, String paramString) {
    super(paramRequestId);
    c c = new c(this, paramString);
    c.b(new b(this, paramString));
    a(c);
  }
  
  public void a() {}
  
  public void b() {
    PurchaseResponse purchaseResponse2 = (PurchaseResponse)d().a();
    PurchaseResponse purchaseResponse1 = purchaseResponse2;
    if (purchaseResponse2 == null)
      purchaseResponse1 = (new PurchaseResponseBuilder()).setRequestId(c()).setRequestStatus(PurchaseResponse.RequestStatus.FAILED).build(); 
    a(purchaseResponse1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\b\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */