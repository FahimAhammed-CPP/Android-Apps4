package com.amazon.device.iap.internal.b.b;

import android.app.Activity;
import android.content.Intent;
import android.os.RemoteException;
import com.amazon.android.framework.context.ContextManager;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.android.framework.resource.Resource;
import com.amazon.android.framework.task.Task;
import com.amazon.android.framework.task.TaskManager;
import com.amazon.android.framework.task.pipeline.TaskPipelineId;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.i;
import com.amazon.device.iap.internal.util.MetricsHelper;
import com.amazon.device.iap.internal.util.e;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;

abstract class a extends i {
  private static final String d = a.class.getSimpleName();
  
  @Resource
  protected TaskManager a;
  
  @Resource
  protected ContextManager b;
  
  protected final String c;
  
  a(e parame, String paramString1, String paramString2) {
    super(parame, "purchase_item", paramString1);
    this.c = paramString2;
    a("sku", this.c);
  }
  
  protected boolean a(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    Map map = paramSuccessResult.getData();
    e.a(d, "data: " + map);
    if (!map.containsKey("purchaseItemIntent")) {
      e.b(d, "did not find intent");
      return false;
    } 
    e.a(d, "found intent");
    Intent intent = (Intent)map.remove("purchaseItemIntent");
    this.a.enqueueAtFront(TaskPipelineId.FOREGROUND, new Task(this, intent) {
          public void execute() {
            try {
              Activity activity2 = this.b.b.getVisible();
              Activity activity1 = activity2;
              if (activity2 == null)
                activity1 = this.b.b.getRoot(); 
              e.a(a.a(), "About to fire intent with activity " + activity1);
              activity1.startActivity(this.a);
              return;
            } catch (Exception exception) {
              MetricsHelper.submitExceptionMetrics(a.a(this.b), a.a() + ".onResult().execute()", exception);
              e.b(a.a(), "Exception when attempting to fire intent: " + exception);
              return;
            } 
          }
        });
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */