package com.amazon.device.iap.internal.b;

import com.amazon.device.iap.internal.a;
import com.amazon.device.iap.internal.b;
import com.amazon.device.iap.internal.c;
import java.util.HashMap;
import java.util.Map;

public final class g implements b {
  private static final Map<Class, Class> a = (Map)new HashMap<Class<?>, Class<?>>();
  
  static {
    a.put(c.class, c.class);
    a.put(a.class, f.class);
  }
  
  public <T> Class<T> a(Class<T> paramClass) {
    return a.get(paramClass);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */