package com.amazon.device.iap.internal.b;

import android.os.RemoteException;
import com.amazon.android.Kiwi;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.android.framework.prompt.Prompt;
import com.amazon.android.framework.prompt.PromptContent;
import com.amazon.android.framework.task.command.AbstractCommandTask;
import com.amazon.android.licensing.LicenseFailurePromptContentMapper;
import com.amazon.device.iap.internal.util.e;
import com.amazon.venezia.command.FailureResult;
import com.amazon.venezia.command.SuccessResult;
import java.util.HashMap;
import java.util.Map;

public abstract class i extends AbstractCommandTask {
  private static final String a = i.class.getSimpleName();
  
  private final e b;
  
  private final String c;
  
  private final String d;
  
  private final String e;
  
  private final Map<String, Object> f;
  
  private final LicenseFailurePromptContentMapper g = new LicenseFailurePromptContentMapper();
  
  private boolean h;
  
  private i i;
  
  private i j;
  
  private boolean k = false;
  
  public i(e parame, String paramString1, String paramString2) {
    this.b = parame;
    this.c = parame.c().toString();
    this.d = paramString1;
    this.e = paramString2;
    this.f = new HashMap<String, Object>();
    this.f.put("requestId", this.c);
    this.f.put("sdkVersion", "2.0.61.0");
    this.h = true;
    this.i = null;
    this.j = null;
  }
  
  private void a(PromptContent paramPromptContent) {
    if (paramPromptContent == null)
      return; 
    b b = new b(paramPromptContent);
    Kiwi.getPromptManager().present((Prompt)b);
  }
  
  public i a(boolean paramBoolean) {
    this.k = paramBoolean;
    return this;
  }
  
  public void a(i parami) {
    this.i = parami;
  }
  
  protected void a(String paramString, Object paramObject) {
    this.f.put(paramString, paramObject);
  }
  
  protected abstract boolean a(SuccessResult paramSuccessResult) throws Exception;
  
  public void a_() {
    Kiwi.addCommandToCommandTaskPipeline(this);
  }
  
  protected e b() {
    return this.b;
  }
  
  public void b(i parami) {
    this.j = parami;
  }
  
  protected void b(boolean paramBoolean) {
    this.h = paramBoolean;
  }
  
  protected String c() {
    return this.c;
  }
  
  protected Map<String, Object> getCommandData() {
    return this.f;
  }
  
  protected String getCommandName() {
    return this.d;
  }
  
  protected String getCommandVersion() {
    return this.e;
  }
  
  protected boolean isExecutionNeeded() {
    return true;
  }
  
  protected final void onException(KiwiException paramKiwiException) {
    e.a(a, "onException: exception = " + paramKiwiException.getMessage());
    if ("UNHANDLED_EXCEPTION".equals(paramKiwiException.getType()) && "2.0".equals(this.e) && this.j != null) {
      this.j.a(this.k);
      this.j.a_();
      return;
    } 
    if (this.h)
      a(this.g.map(paramKiwiException)); 
    if (!this.k) {
      this.b.b();
      return;
    } 
  }
  
  protected final void onFailure(FailureResult paramFailureResult) throws RemoteException, KiwiException {
    // Byte code:
    //   0: getstatic com/amazon/device/iap/internal/b/i.a : Ljava/lang/String;
    //   3: new java/lang/StringBuilder
    //   6: dup
    //   7: invokespecial <init> : ()V
    //   10: ldc 'onFailure: result = '
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: aload_1
    //   16: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   19: invokevirtual toString : ()Ljava/lang/String;
    //   22: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   25: aload_1
    //   26: ifnull -> 149
    //   29: aload_1
    //   30: invokeinterface getExtensionData : ()Ljava/util/Map;
    //   35: ldc 'maxVersion'
    //   37: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   42: checkcast java/lang/String
    //   45: astore_3
    //   46: aload_3
    //   47: ifnull -> 149
    //   50: aload_3
    //   51: ldc '1.0'
    //   53: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   56: ifeq -> 149
    //   59: iconst_1
    //   60: istore_2
    //   61: iload_2
    //   62: ifeq -> 92
    //   65: aload_0
    //   66: getfield j : Lcom/amazon/device/iap/internal/b/i;
    //   69: ifnull -> 92
    //   72: aload_0
    //   73: getfield j : Lcom/amazon/device/iap/internal/b/i;
    //   76: aload_0
    //   77: getfield k : Z
    //   80: invokevirtual a : (Z)Lcom/amazon/device/iap/internal/b/i;
    //   83: pop
    //   84: aload_0
    //   85: getfield j : Lcom/amazon/device/iap/internal/b/i;
    //   88: invokevirtual a_ : ()V
    //   91: return
    //   92: aload_0
    //   93: getfield h : Z
    //   96: ifeq -> 134
    //   99: aload_0
    //   100: new com/amazon/android/framework/prompt/PromptContent
    //   103: dup
    //   104: aload_1
    //   105: invokeinterface getDisplayableName : ()Ljava/lang/String;
    //   110: aload_1
    //   111: invokeinterface getDisplayableMessage : ()Ljava/lang/String;
    //   116: aload_1
    //   117: invokeinterface getButtonLabel : ()Ljava/lang/String;
    //   122: aload_1
    //   123: invokeinterface show : ()Z
    //   128: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    //   131: invokespecial a : (Lcom/amazon/android/framework/prompt/PromptContent;)V
    //   134: aload_0
    //   135: getfield k : Z
    //   138: ifne -> 91
    //   141: aload_0
    //   142: getfield b : Lcom/amazon/device/iap/internal/b/e;
    //   145: invokevirtual b : ()V
    //   148: return
    //   149: iconst_0
    //   150: istore_2
    //   151: goto -> 61
  }
  
  protected final void onSuccess(SuccessResult paramSuccessResult) throws RemoteException {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface getData : ()Ljava/util/Map;
    //   6: ldc 'errorMessage'
    //   8: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   13: checkcast java/lang/String
    //   16: astore #4
    //   18: getstatic com/amazon/device/iap/internal/b/i.a : Ljava/lang/String;
    //   21: new java/lang/StringBuilder
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: ldc 'onSuccess: result = '
    //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   33: aload_1
    //   34: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   37: ldc ', errorMessage: '
    //   39: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   42: aload #4
    //   44: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   47: invokevirtual toString : ()Ljava/lang/String;
    //   50: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   53: aload #4
    //   55: invokestatic a : (Ljava/lang/String;)Z
    //   58: ifeq -> 146
    //   61: iconst_0
    //   62: istore_2
    //   63: aload_0
    //   64: aload_1
    //   65: invokevirtual a : (Lcom/amazon/venezia/command/SuccessResult;)Z
    //   68: istore_3
    //   69: iload_3
    //   70: istore_2
    //   71: iload_2
    //   72: ifeq -> 119
    //   75: aload_0
    //   76: getfield i : Lcom/amazon/device/iap/internal/b/i;
    //   79: ifnull -> 119
    //   82: aload_0
    //   83: getfield i : Lcom/amazon/device/iap/internal/b/i;
    //   86: invokevirtual a_ : ()V
    //   89: return
    //   90: astore_1
    //   91: getstatic com/amazon/device/iap/internal/b/i.a : Ljava/lang/String;
    //   94: new java/lang/StringBuilder
    //   97: dup
    //   98: invokespecial <init> : ()V
    //   101: ldc 'Error calling onResult: '
    //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: aload_1
    //   107: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   110: invokevirtual toString : ()Ljava/lang/String;
    //   113: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   116: goto -> 71
    //   119: aload_0
    //   120: getfield k : Z
    //   123: ifne -> 89
    //   126: iload_2
    //   127: ifeq -> 138
    //   130: aload_0
    //   131: getfield b : Lcom/amazon/device/iap/internal/b/e;
    //   134: invokevirtual a : ()V
    //   137: return
    //   138: aload_0
    //   139: getfield b : Lcom/amazon/device/iap/internal/b/e;
    //   142: invokevirtual b : ()V
    //   145: return
    //   146: aload_0
    //   147: getfield k : Z
    //   150: ifne -> 89
    //   153: aload_0
    //   154: getfield b : Lcom/amazon/device/iap/internal/b/e;
    //   157: invokevirtual b : ()V
    //   160: return
    // Exception table:
    //   from	to	target	type
    //   63	69	90	java/lang/Exception
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */