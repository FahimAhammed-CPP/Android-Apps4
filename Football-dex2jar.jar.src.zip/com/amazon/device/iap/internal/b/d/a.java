package com.amazon.device.iap.internal.b.d;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.e.c;
import com.amazon.device.iap.internal.b.e.d;
import com.amazon.device.iap.internal.b.i;
import com.amazon.device.iap.internal.model.PurchaseUpdatesResponseBuilder;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.RequestId;
import java.util.HashSet;

public final class a extends e {
  public a(RequestId paramRequestId, boolean paramBoolean) {
    super(paramRequestId);
    c c = new c(this);
    c.a(new c(this, paramBoolean));
    d d = new d(this);
    d.a(new d(this));
    c.b((i)d);
    a((i)c);
  }
  
  public void a() {
    com.amazon.device.iap.internal.b.g.a a1;
    HashSet<String> hashSet2 = null;
    PurchaseUpdatesResponse purchaseUpdatesResponse = (PurchaseUpdatesResponse)d().a();
    HashSet<String> hashSet1 = hashSet2;
    if (purchaseUpdatesResponse.getReceipts() != null) {
      hashSet1 = hashSet2;
      if (purchaseUpdatesResponse.getReceipts().size() > 0) {
        hashSet1 = new HashSet();
        for (Receipt receipt : purchaseUpdatesResponse.getReceipts()) {
          if (!d.a(receipt.getReceiptId()))
            hashSet1.add(receipt.getReceiptId()); 
        } 
        a1 = new com.amazon.device.iap.internal.b.g.a(this, hashSet1, com.amazon.device.iap.internal.model.a.a.toString());
      } 
    } 
    a(purchaseUpdatesResponse, (i)a1);
  }
  
  public void b() {
    Object object = d().a();
    if (object == null || !(object instanceof PurchaseUpdatesResponse)) {
      object = (new PurchaseUpdatesResponseBuilder()).setRequestId(c()).setRequestStatus(PurchaseUpdatesResponse.RequestStatus.FAILED).build();
    } else {
      object = object;
    } 
    a(object);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\d\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */