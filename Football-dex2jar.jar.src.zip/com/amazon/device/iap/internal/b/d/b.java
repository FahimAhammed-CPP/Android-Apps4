package com.amazon.device.iap.internal.b.d;

import com.amazon.android.framework.exception.KiwiException;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.i;

abstract class b extends i {
  protected final boolean a;
  
  b(e parame, String paramString, boolean paramBoolean) {
    super(parame, "purchase_updates", paramString);
    this.a = paramBoolean;
  }
  
  protected void preExecution() throws KiwiException {
    super.preExecution();
    String str = (String)b().d().a("userId");
    if (this.a) {
      str = null;
    } else {
      str = com.amazon.device.iap.internal.util.b.a(str);
    } 
    a("cursor", str);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\d\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */