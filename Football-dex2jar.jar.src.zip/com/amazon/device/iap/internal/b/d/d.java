package com.amazon.device.iap.internal.b.d;

import com.amazon.device.iap.internal.b.a;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.c.a;
import com.amazon.device.iap.internal.c.c;
import com.amazon.device.iap.internal.model.PurchaseUpdatesResponseBuilder;
import com.amazon.device.iap.internal.model.ReceiptBuilder;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.internal.util.a;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.UserData;
import com.amazon.venezia.command.SuccessResult;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;

public final class d extends b {
  private static final String b = d.class.getSimpleName();
  
  private static final Date c = new Date(0L);
  
  public d(e parame) {
    super(parame, "1.0", true);
  }
  
  protected boolean a(SuccessResult paramSuccessResult) throws Exception {
    boolean bool = false;
    Map map = paramSuccessResult.getData();
    e.a(b, "data: " + map);
    String str1 = (String)map.get("userId");
    String str2 = (String)map.get("requestId");
    String str3 = (String)map.get("marketplace");
    ArrayList<Receipt> arrayList = new ArrayList();
    JSONArray jSONArray = new JSONArray((String)map.get("receipts"));
    int i;
    for (i = 0; i < jSONArray.length(); i++) {
      try {
        Receipt receipt = a.a(jSONArray.getJSONObject(i), str1, null);
        arrayList.add(receipt);
        if (ProductType.ENTITLED == receipt.getProductType())
          c.a().a(str1, receipt.getReceiptId(), receipt.getSku()); 
      } catch (a a) {
        e.b(b, "fail to parse receipt, requestId:" + a.a());
      } catch (com.amazon.device.iap.internal.b.d d1) {
        e.b(b, "fail to verify receipt, requestId:" + d1.a());
      } catch (Throwable throwable) {
        e.b(b, "fail to verify receipt, requestId:" + throwable.getMessage());
      } 
    } 
    jSONArray = new JSONArray((String)map.get("revocations"));
    for (i = bool; i < jSONArray.length(); i++) {
      try {
        String str5 = jSONArray.getString(i);
        String str6 = c.a().a(str1, str5);
        arrayList.add((new ReceiptBuilder()).setSku(str5).setProductType(ProductType.ENTITLED).setPurchaseDate(null).setCancelDate(c).setReceiptId(str6).build());
      } catch (JSONException jSONException) {
        e.b(b, "fail to parse JSON[" + i + "] in \"" + jSONArray + "\"");
      } 
    } 
    String str4 = (String)map.get("cursor");
    boolean bool1 = "true".equalsIgnoreCase((String)map.get("hasMore"));
    e e = b();
    UserData userData = (new UserDataBuilder()).setUserId(str1).setMarketplace(str3).build();
    PurchaseUpdatesResponse purchaseUpdatesResponse = (new PurchaseUpdatesResponseBuilder()).setRequestId(e.c()).setRequestStatus(PurchaseUpdatesResponse.RequestStatus.SUCCESSFUL).setUserData(userData).setReceipts(arrayList).setHasMore(bool1).build();
    Set set = a.a().b(purchaseUpdatesResponse.getUserData().getUserId());
    purchaseUpdatesResponse.getReceipts().addAll(set);
    e.d().a(purchaseUpdatesResponse);
    e.d().a("newCursor", str4);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\d\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */