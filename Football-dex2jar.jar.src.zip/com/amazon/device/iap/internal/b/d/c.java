package com.amazon.device.iap.internal.b.d;

import com.amazon.device.iap.internal.b.a;
import com.amazon.device.iap.internal.b.d;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.model.PurchaseUpdatesResponseBuilder;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.internal.util.a;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.UserData;
import com.amazon.venezia.command.SuccessResult;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;

public final class c extends b {
  private static final String b = c.class.getSimpleName();
  
  public c(e parame, boolean paramBoolean) {
    super(parame, "2.0", paramBoolean);
  }
  
  private List<Receipt> a(String paramString1, String paramString2, String paramString3) throws JSONException {
    ArrayList<Receipt> arrayList = new ArrayList();
    JSONArray jSONArray = new JSONArray(paramString2);
    for (int i = 0; i < jSONArray.length(); i++) {
      try {
        arrayList.add(a.a(jSONArray.getJSONObject(i), paramString1, paramString3));
      } catch (a a) {
        e.b(b, "fail to parse receipt, requestId:" + a.a());
      } catch (d d) {
        e.b(b, "fail to verify receipt, requestId:" + d.a());
      } catch (Throwable throwable) {
        e.b(b, "fail to verify receipt, requestId:" + throwable.getMessage());
      } 
    } 
    return arrayList;
  }
  
  protected boolean a(SuccessResult paramSuccessResult) throws Exception {
    Map map = paramSuccessResult.getData();
    e.a(b, "data: " + map);
    String str2 = (String)map.get("userId");
    String str3 = (String)map.get("marketplace");
    String str1 = (String)map.get("requestId");
    List<Receipt> list = a(str2, (String)map.get("receipts"), str1);
    str1 = (String)map.get("cursor");
    boolean bool = Boolean.valueOf((String)map.get("hasMore")).booleanValue();
    e e = b();
    UserData userData = (new UserDataBuilder()).setUserId(str2).setMarketplace(str3).build();
    PurchaseUpdatesResponse purchaseUpdatesResponse = (new PurchaseUpdatesResponseBuilder()).setRequestId(e.c()).setRequestStatus(PurchaseUpdatesResponse.RequestStatus.SUCCESSFUL).setUserData(userData).setReceipts(list).setHasMore(bool).build();
    e.d().a("newCursor", str1);
    e.d().a(purchaseUpdatesResponse);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\d\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */