package com.amazon.device.iap.internal.b.c;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.model.ProductDataResponseBuilder;
import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.RequestId;
import java.util.Set;

public final class d extends e {
  public d(RequestId paramRequestId, Set<String> paramSet) {
    super(paramRequestId);
    a a = new a(this, paramSet);
    a.b(new b(this, paramSet));
    a(a);
  }
  
  public void a() {
    a(d().a());
  }
  
  public void b() {
    ProductDataResponse productDataResponse2 = (ProductDataResponse)d().a();
    ProductDataResponse productDataResponse1 = productDataResponse2;
    if (productDataResponse2 == null)
      productDataResponse1 = (new ProductDataResponseBuilder()).setRequestId(c()).setRequestStatus(ProductDataResponse.RequestStatus.FAILED).build(); 
    a(productDataResponse1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\c\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */