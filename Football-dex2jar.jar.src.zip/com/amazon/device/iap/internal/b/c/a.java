package com.amazon.device.iap.internal.b.c;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.model.ProductBuilder;
import com.amazon.device.iap.internal.model.ProductDataResponseBuilder;
import com.amazon.device.iap.internal.util.MetricsHelper;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.Product;
import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.ProductType;
import com.amazon.venezia.command.SuccessResult;
import java.math.BigDecimal;
import java.util.Currency;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public final class a extends c {
  private static final String b = a.class.getSimpleName();
  
  public a(e parame, Set<String> paramSet) {
    super(parame, "2.0", paramSet);
  }
  
  private Product a(String paramString, Map paramMap) throws IllegalArgumentException {
    String str = (String)paramMap.get(paramString);
    try {
      JSONObject jSONObject = new JSONObject(str);
      ProductType productType = ProductType.valueOf(jSONObject.getString("itemType").toUpperCase());
      String str3 = jSONObject.getString("description");
      String str2 = jSONObject.optString("price", null);
      String str1 = str2;
      if (d.a(str2)) {
        JSONObject jSONObject1 = jSONObject.optJSONObject("priceJson");
        str1 = str2;
        if (jSONObject1 != null) {
          Currency currency = Currency.getInstance(jSONObject1.getString("currency"));
          BigDecimal bigDecimal = new BigDecimal(jSONObject1.getString("value"));
          str1 = currency.getSymbol() + bigDecimal;
        } 
      } 
      str2 = jSONObject.getString("title");
      String str4 = jSONObject.getString("iconUrl");
      return (new ProductBuilder()).setSku(paramString).setProductType(productType).setDescription(str3).setPrice(str1).setSmallIconUrl(str4).setTitle(str2).build();
    } catch (JSONException jSONException) {
      throw new IllegalArgumentException("error in parsing json string" + str);
    } 
  }
  
  protected boolean a(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    Map map = paramSuccessResult.getData();
    e.a(b, "data: " + map);
    LinkedHashSet<String> linkedHashSet = new LinkedHashSet();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (String str : this.a) {
      if (!map.containsKey(str)) {
        linkedHashSet.add(str);
        continue;
      } 
      try {
        hashMap.put(str, a(str, map));
      } catch (IllegalArgumentException illegalArgumentException) {
        linkedHashSet.add(str);
        String str1 = (String)map.get(str);
        MetricsHelper.submitJsonParsingExceptionMetrics(c(), str1, b + ".onResult()");
        e.b(b, "Error parsing JSON for SKU " + str + ": " + illegalArgumentException.getMessage());
      } 
    } 
    e e = b();
    ProductDataResponse productDataResponse = (new ProductDataResponseBuilder()).setRequestId(e.c()).setRequestStatus(ProductDataResponse.RequestStatus.SUCCESSFUL).setUnavailableSkus(linkedHashSet).setProductData(hashMap).build();
    e.d().a(productDataResponse);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\c\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */