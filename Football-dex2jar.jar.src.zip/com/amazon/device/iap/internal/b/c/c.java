package com.amazon.device.iap.internal.b.c;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.i;
import java.util.Set;

abstract class c extends i {
  protected final Set<String> a;
  
  c(e parame, String paramString, Set<String> paramSet) {
    super(parame, "getItem_data", paramString);
    this.a = paramSet;
    a("skus", paramSet);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\c\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */