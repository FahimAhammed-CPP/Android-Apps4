package com.amazon.device.iap.internal.b;

import android.content.Context;
import android.content.Intent;
import com.amazon.device.iap.internal.b.a.d;
import com.amazon.device.iap.internal.b.b.d;
import com.amazon.device.iap.internal.b.c.d;
import com.amazon.device.iap.internal.b.d.a;
import com.amazon.device.iap.internal.b.e.a;
import com.amazon.device.iap.internal.b.g.b;
import com.amazon.device.iap.internal.c;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.FulfillmentResult;
import com.amazon.device.iap.model.RequestId;
import java.util.Set;

public final class c implements c {
  private static final String a = c.class.getSimpleName();
  
  public void a(Context paramContext, Intent paramIntent) {
    e.a(a, "handleResponse");
    String str = paramIntent.getStringExtra("response_type");
    if (str == null) {
      e.a(a, "Invalid response type: null");
      return;
    } 
    e.a(a, "Found response type: " + str);
    if ("purchase_response".equals(str)) {
      (new d(RequestId.fromString(paramIntent.getStringExtra("requestId")))).e();
      return;
    } 
  }
  
  public void a(RequestId paramRequestId) {
    e.a(a, "sendGetUserData");
    (new a(paramRequestId)).e();
  }
  
  public void a(RequestId paramRequestId, String paramString) {
    e.a(a, "sendPurchaseRequest");
    (new d(paramRequestId, paramString)).e();
  }
  
  public void a(RequestId paramRequestId, String paramString, FulfillmentResult paramFulfillmentResult) {
    e.a(a, "sendNotifyFulfillment");
    (new b(paramRequestId, paramString, paramFulfillmentResult)).e();
  }
  
  public void a(RequestId paramRequestId, Set<String> paramSet) {
    e.a(a, "sendGetProductDataRequest");
    (new d(paramRequestId, paramSet)).e();
  }
  
  public void a(RequestId paramRequestId, boolean paramBoolean) {
    e.a(a, "sendGetPurchaseUpdates");
    (new a(paramRequestId, paramBoolean)).e();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */