package com.amazon.device.iap.internal;

import android.content.Context;
import android.content.Intent;
import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.FulfillmentResult;
import com.amazon.device.iap.model.RequestId;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class d {
  private static String a = d.class.getSimpleName();
  
  private static String b = "sku";
  
  private static d c = new d();
  
  private final c d = e.b();
  
  private Context e;
  
  private PurchasingListener f;
  
  public static d d() {
    return c;
  }
  
  private void e() {
    if (this.f == null)
      throw new IllegalStateException("You must register a PurchasingListener before invoking this operation"); 
  }
  
  public PurchasingListener a() {
    return this.f;
  }
  
  public RequestId a(String paramString) {
    d.a(paramString, b);
    e();
    RequestId requestId = new RequestId();
    this.d.a(requestId, paramString);
    return requestId;
  }
  
  public RequestId a(Set<String> paramSet) {
    d.a(paramSet, "skus");
    d.a(paramSet, "skus");
    Iterator<String> iterator = paramSet.iterator();
    while (iterator.hasNext()) {
      if (((String)iterator.next()).trim().length() == 0)
        throw new IllegalArgumentException("Empty SKU values are not allowed"); 
    } 
    if (paramSet.size() > 100)
      throw new IllegalArgumentException(paramSet.size() + " SKUs were provided, but no more than " + 'd' + " SKUs are allowed"); 
    e();
    RequestId requestId = new RequestId();
    paramSet = new LinkedHashSet<String>(paramSet);
    this.d.a(requestId, paramSet);
    return requestId;
  }
  
  public RequestId a(boolean paramBoolean) {
    e();
    RequestId requestId = new RequestId();
    this.d.a(requestId, paramBoolean);
    return requestId;
  }
  
  public void a(Context paramContext, Intent paramIntent) {
    try {
      this.d.a(paramContext, paramIntent);
      return;
    } catch (Exception exception) {
      e.b(a, "Error in onReceive: " + exception);
      return;
    } 
  }
  
  public void a(Context paramContext, PurchasingListener paramPurchasingListener) {
    e.a(a, "PurchasingListener registered: " + paramPurchasingListener);
    e.a(a, "PurchasingListener Context: " + paramContext);
    if (paramPurchasingListener == null || paramContext == null)
      throw new IllegalArgumentException("Neither PurchasingListener or its Context can be null"); 
    this.e = paramContext.getApplicationContext();
    this.f = paramPurchasingListener;
  }
  
  public void a(String paramString, FulfillmentResult paramFulfillmentResult) {
    if (d.a(paramString))
      throw new IllegalArgumentException("Empty receiptId is not allowed"); 
    d.a(paramFulfillmentResult, "fulfillmentResult");
    e();
    RequestId requestId = new RequestId();
    this.d.a(requestId, paramString, paramFulfillmentResult);
  }
  
  public Context b() {
    return this.e;
  }
  
  public RequestId c() {
    e();
    RequestId requestId = new RequestId();
    this.d.a(requestId);
    return requestId;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */