package com.amazon.device.iap.internal;

import android.util.Log;

public final class e {
  private static final String a = e.class.getName();
  
  private static volatile boolean b;
  
  private static volatile boolean c;
  
  private static volatile c d;
  
  private static volatile a e;
  
  private static volatile b f;
  
  private static <T> T a(Class<T> paramClass) {
    try {
      return (T)d().<Object>a((Class)paramClass).newInstance();
    } catch (Exception exception) {
      Log.e(a, "error getting instance for " + paramClass, exception);
      return null;
    } 
  }
  
  public static boolean a() {
    // Byte code:
    //   0: getstatic com/amazon/device/iap/internal/e.c : Z
    //   3: ifeq -> 10
    //   6: getstatic com/amazon/device/iap/internal/e.b : Z
    //   9: ireturn
    //   10: ldc com/amazon/device/iap/internal/e
    //   12: monitorenter
    //   13: getstatic com/amazon/device/iap/internal/e.c : Z
    //   16: ifeq -> 34
    //   19: getstatic com/amazon/device/iap/internal/e.b : Z
    //   22: istore_0
    //   23: ldc com/amazon/device/iap/internal/e
    //   25: monitorexit
    //   26: iload_0
    //   27: ireturn
    //   28: astore_1
    //   29: ldc com/amazon/device/iap/internal/e
    //   31: monitorexit
    //   32: aload_1
    //   33: athrow
    //   34: ldc com/amazon/device/iap/internal/e
    //   36: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   39: ldc 'com.amazon.android.Kiwi'
    //   41: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
    //   44: pop
    //   45: iconst_0
    //   46: putstatic com/amazon/device/iap/internal/e.b : Z
    //   49: iconst_1
    //   50: putstatic com/amazon/device/iap/internal/e.c : Z
    //   53: ldc com/amazon/device/iap/internal/e
    //   55: monitorexit
    //   56: getstatic com/amazon/device/iap/internal/e.b : Z
    //   59: ireturn
    //   60: astore_1
    //   61: iconst_1
    //   62: putstatic com/amazon/device/iap/internal/e.b : Z
    //   65: goto -> 49
    // Exception table:
    //   from	to	target	type
    //   13	26	28	finally
    //   29	32	28	finally
    //   34	49	60	java/lang/Throwable
    //   34	49	28	finally
    //   49	56	28	finally
    //   61	65	28	finally
  }
  
  public static c b() {
    // Byte code:
    //   0: getstatic com/amazon/device/iap/internal/e.d : Lcom/amazon/device/iap/internal/c;
    //   3: ifnonnull -> 29
    //   6: ldc com/amazon/device/iap/internal/e
    //   8: monitorenter
    //   9: getstatic com/amazon/device/iap/internal/e.d : Lcom/amazon/device/iap/internal/c;
    //   12: ifnonnull -> 26
    //   15: ldc com/amazon/device/iap/internal/c
    //   17: invokestatic a : (Ljava/lang/Class;)Ljava/lang/Object;
    //   20: checkcast com/amazon/device/iap/internal/c
    //   23: putstatic com/amazon/device/iap/internal/e.d : Lcom/amazon/device/iap/internal/c;
    //   26: ldc com/amazon/device/iap/internal/e
    //   28: monitorexit
    //   29: getstatic com/amazon/device/iap/internal/e.d : Lcom/amazon/device/iap/internal/c;
    //   32: areturn
    //   33: astore_0
    //   34: ldc com/amazon/device/iap/internal/e
    //   36: monitorexit
    //   37: aload_0
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   9	26	33	finally
    //   26	29	33	finally
    //   34	37	33	finally
  }
  
  public static a c() {
    // Byte code:
    //   0: getstatic com/amazon/device/iap/internal/e.e : Lcom/amazon/device/iap/internal/a;
    //   3: ifnonnull -> 29
    //   6: ldc com/amazon/device/iap/internal/e
    //   8: monitorenter
    //   9: getstatic com/amazon/device/iap/internal/e.e : Lcom/amazon/device/iap/internal/a;
    //   12: ifnonnull -> 26
    //   15: ldc com/amazon/device/iap/internal/a
    //   17: invokestatic a : (Ljava/lang/Class;)Ljava/lang/Object;
    //   20: checkcast com/amazon/device/iap/internal/a
    //   23: putstatic com/amazon/device/iap/internal/e.e : Lcom/amazon/device/iap/internal/a;
    //   26: ldc com/amazon/device/iap/internal/e
    //   28: monitorexit
    //   29: getstatic com/amazon/device/iap/internal/e.e : Lcom/amazon/device/iap/internal/a;
    //   32: areturn
    //   33: astore_0
    //   34: ldc com/amazon/device/iap/internal/e
    //   36: monitorexit
    //   37: aload_0
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   9	26	33	finally
    //   26	29	33	finally
    //   34	37	33	finally
  }
  
  private static b d() {
    // Byte code:
    //   0: getstatic com/amazon/device/iap/internal/e.f : Lcom/amazon/device/iap/internal/b;
    //   3: ifnonnull -> 34
    //   6: ldc com/amazon/device/iap/internal/e
    //   8: monitorenter
    //   9: getstatic com/amazon/device/iap/internal/e.f : Lcom/amazon/device/iap/internal/b;
    //   12: ifnonnull -> 31
    //   15: invokestatic a : ()Z
    //   18: ifeq -> 38
    //   21: new com/amazon/device/iap/internal/a/d
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: putstatic com/amazon/device/iap/internal/e.f : Lcom/amazon/device/iap/internal/b;
    //   31: ldc com/amazon/device/iap/internal/e
    //   33: monitorexit
    //   34: getstatic com/amazon/device/iap/internal/e.f : Lcom/amazon/device/iap/internal/b;
    //   37: areturn
    //   38: new com/amazon/device/iap/internal/b/g
    //   41: dup
    //   42: invokespecial <init> : ()V
    //   45: putstatic com/amazon/device/iap/internal/e.f : Lcom/amazon/device/iap/internal/b;
    //   48: goto -> 31
    //   51: astore_0
    //   52: ldc com/amazon/device/iap/internal/e
    //   54: monitorexit
    //   55: aload_0
    //   56: athrow
    // Exception table:
    //   from	to	target	type
    //   9	31	51	finally
    //   31	34	51	finally
    //   38	48	51	finally
    //   52	55	51	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */