package com.amazon.device.iap.internal.model;

public enum a {
  a, b;
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\model\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */