package com.amazon.device.iap.internal;

public interface a {
  void a(String paramString1, String paramString2);
  
  boolean a();
  
  void b(String paramString1, String paramString2);
  
  boolean b();
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */