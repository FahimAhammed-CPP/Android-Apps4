package com.amazon.device.iap.internal.c;

import org.json.JSONException;
import org.json.JSONObject;

class d {
  private final String a;
  
  private final String b;
  
  private final long c;
  
  private final String d;
  
  public d(String paramString1, String paramString2, String paramString3, long paramLong) {
    this.a = paramString1;
    this.b = paramString2;
    this.d = paramString3;
    this.c = paramLong;
  }
  
  public static d a(String paramString) throws e {
    try {
      JSONObject jSONObject = new JSONObject(paramString);
      return new d(jSONObject.getString("KEY_USER_ID"), jSONObject.getString("KEY_RECEIPT_STRING"), jSONObject.getString("KEY_REQUEST_ID"), jSONObject.getLong("KEY_TIMESTAMP"));
    } catch (Throwable throwable) {
      throw new e("Input invalid for PendingReceipt Object:" + paramString, throwable);
    } 
  }
  
  public String a() {
    return this.d;
  }
  
  public String b() {
    return this.b;
  }
  
  public long c() {
    return this.c;
  }
  
  public String d() throws JSONException {
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("KEY_USER_ID", this.a);
    jSONObject.put("KEY_RECEIPT_STRING", this.b);
    jSONObject.put("KEY_REQUEST_ID", this.d);
    jSONObject.put("KEY_TIMESTAMP", this.c);
    return jSONObject.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\c\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */