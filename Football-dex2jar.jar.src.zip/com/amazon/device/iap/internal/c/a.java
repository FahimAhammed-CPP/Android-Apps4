package com.amazon.device.iap.internal.c;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import com.amazon.device.iap.internal.b.d;
import com.amazon.device.iap.internal.d;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.Receipt;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class a {
  private static final String a = a.class.getSimpleName();
  
  private static final String b = a.class.getName() + "_PREFS";
  
  private static final String c = a.class.getName() + "_CLEANER_PREFS";
  
  private static int d = 604800000;
  
  private static final a e = new a();
  
  public static a a() {
    return e;
  }
  
  private void a(long paramLong) {
    Context context = d.d().b();
    d.a(context, "context");
    SharedPreferences.Editor editor = context.getSharedPreferences(c, 0).edit();
    editor.putLong("LAST_CLEANING_TIME", paramLong);
    editor.commit();
  }
  
  private void e() {
    e.a(a, "enter old receipts cleanup! ");
    Context context = d.d().b();
    d.a(context, "context");
    a(System.currentTimeMillis());
    Runnable runnable = new Runnable(this, context) {
        public void run() {
          try {
            e.a(a.b(), "perform house keeping! ");
            SharedPreferences sharedPreferences = this.a.getSharedPreferences(a.c(), 0);
            for (String str : sharedPreferences.getAll().keySet()) {
              try {
                d d = d.a(sharedPreferences.getString(str, null));
                if (System.currentTimeMillis() - d.c() > a.d()) {
                  e.a(a.b(), "house keeping - try remove Receipt:" + str + " since it's too old");
                  this.b.a(str);
                } 
              } catch (e e) {
                e.a(a.b(), "house keeping - try remove Receipt:" + str + " since it's invalid ");
                this.b.a(str);
              } 
            } 
          } catch (Throwable throwable) {
            e.a(a.b(), "Error in running cleaning job:" + throwable);
          } 
        }
      };
    (new Handler()).post(runnable);
  }
  
  private long f() {
    Context context = d.d().b();
    d.a(context, "context");
    long l1 = System.currentTimeMillis();
    long l2 = context.getSharedPreferences(c, 0).getLong("LAST_CLEANING_TIME", 0L);
    if (l2 == 0L) {
      a(l1);
      return l1;
    } 
    return l2;
  }
  
  public void a(String paramString) {
    e.a(a, "enter removeReceipt for receipt[" + paramString + "]");
    Context context = d.d().b();
    d.a(context, "context");
    SharedPreferences.Editor editor = context.getSharedPreferences(b, 0).edit();
    editor.remove(paramString);
    editor.commit();
    e.a(a, "leave removeReceipt for receipt[" + paramString + "]");
  }
  
  public void a(String paramString1, String paramString2, String paramString3, String paramString4) {
    e.a(a, "enter saveReceipt for receipt [" + paramString4 + "]");
    try {
      d.a(paramString2, "userId");
      d.a(paramString3, "receiptId");
      d.a(paramString4, "receiptString");
      Context context = d.d().b();
      d.a(context, "context");
      d d = new d(paramString2, paramString4, paramString1, System.currentTimeMillis());
      SharedPreferences.Editor editor = context.getSharedPreferences(b, 0).edit();
      editor.putString(paramString3, d.d());
      editor.commit();
    } catch (Throwable throwable) {
      e.a(a, "error in saving pending receipt:" + paramString1 + "/" + paramString4 + ":" + throwable.getMessage());
    } 
    e.a(a, "leaving saveReceipt for receipt id [" + paramString3 + "]");
  }
  
  public Set<Receipt> b(String paramString) {
    Context context = d.d().b();
    d.a(context, "context");
    e.a(a, "enter getLocalReceipts for user[" + paramString + "]");
    HashSet<Receipt> hashSet = new HashSet();
    if (d.a(paramString)) {
      e.b(a, "empty UserId: " + paramString);
      throw new RuntimeException("Invalid UserId:" + paramString);
    } 
    Map map = context.getSharedPreferences(b, 0).getAll();
    for (String str2 : map.keySet()) {
      String str1 = (String)map.get(str2);
      try {
        d d = d.a(str1);
        hashSet.add(com.amazon.device.iap.internal.util.a.a(new JSONObject(d.b()), paramString, d.a()));
      } catch (d d) {
        a(str2);
        e.b(a, "failed to verify signature:[" + str1 + "]");
      } catch (JSONException jSONException) {
        a(str2);
        e.b(a, "failed to convert string to JSON object:[" + str1 + "]");
      } catch (Throwable throwable) {
        e.b(a, "failed to load the receipt from SharedPreference:[" + str1 + "]");
      } 
    } 
    e.a(a, "leaving getLocalReceipts for user[" + paramString + "], " + hashSet.size() + " local receipts found.");
    if (System.currentTimeMillis() - f() > d)
      e(); 
    return hashSet;
  }
  
  public String c(String paramString) {
    String str1 = null;
    Context context = d.d().b();
    d.a(context, "context");
    if (d.a(paramString)) {
      e.b(a, "empty receiptId: " + paramString);
      throw new RuntimeException("Invalid ReceiptId:" + paramString);
    } 
    String str2 = context.getSharedPreferences(b, 0).getString(paramString, null);
    paramString = str1;
    if (str2 != null)
      try {
        return d.a(str2).a();
      } catch (e e) {
        return null;
      }  
    return (String)e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\c\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */