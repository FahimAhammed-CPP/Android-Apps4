package com.amazon.device.iap.internal.c;

import android.content.Context;
import android.content.SharedPreferences;
import com.amazon.device.iap.internal.d;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.internal.util.e;

public class c {
  private static c a = new c();
  
  private static final String b = c.class.getSimpleName();
  
  private static final String c = c.class.getName() + "_PREFS_";
  
  public static c a() {
    return a;
  }
  
  public String a(String paramString1, String paramString2) {
    String str = null;
    e.a(b, "enter getReceiptIdFromSku for sku [" + paramString2 + "], user [" + paramString1 + "]");
    try {
      d.a(paramString1, "userId");
      d.a(paramString2, "sku");
      Context context = d.d().b();
      d.a(context, "context");
      String str1 = context.getSharedPreferences(c + paramString1, 0).getString(paramString2, null);
      str = str1;
    } catch (Throwable throwable) {
      e.a(b, "error in saving v1 Entitlement:" + paramString2 + ":" + throwable.getMessage());
    } 
    e.a(b, "leaving saveEntitlementRecord for sku [" + paramString2 + "], user [" + paramString1 + "]");
    return str;
  }
  
  public void a(String paramString1, String paramString2, String paramString3) {
    e.a(b, "enter saveEntitlementRecord for v1 Entitlement [" + paramString2 + "/" + paramString3 + "], user [" + paramString1 + "]");
    try {
      d.a(paramString1, "userId");
      d.a(paramString2, "receiptId");
      d.a(paramString3, "sku");
      Context context = d.d().b();
      d.a(context, "context");
      SharedPreferences.Editor editor = context.getSharedPreferences(c + paramString1, 0).edit();
      editor.putString(paramString3, paramString2);
      editor.commit();
    } catch (Throwable throwable) {
      e.a(b, "error in saving v1 Entitlement:" + paramString2 + "/" + paramString3 + ":" + throwable.getMessage());
    } 
    e.a(b, "leaving saveEntitlementRecord for v1 Entitlement [" + paramString2 + "/" + paramString3 + "], user [" + paramString1 + "]");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\c\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */