package com.amazon.device.iap.internal.c;

class e extends Exception {
  public e(String paramString) {
    super(paramString);
  }
  
  public e(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public e(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\c\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */