package com.amazon.device.iap.internal.c;

import com.amazon.device.iap.internal.util.d;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

public class b {
  private static final b b = new b();
  
  private final Set<String> a = new ConcurrentSkipListSet<String>();
  
  public static b a() {
    return b;
  }
  
  public boolean a(String paramString) {
    return !d.a(paramString) ? this.a.remove(paramString) : false;
  }
  
  public void b(String paramString) {
    if (!d.a(paramString))
      this.a.add(paramString); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\c\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */