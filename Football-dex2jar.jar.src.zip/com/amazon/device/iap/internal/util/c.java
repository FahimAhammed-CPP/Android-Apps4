package com.amazon.device.iap.internal.util;

public enum c {
  a(0),
  b(1),
  c(2);
  
  private int d;
  
  c(int paramInt1) {
    this.d = paramInt1;
  }
  
  public static c[] a() {
    return (c[])e.clone();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\interna\\util\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */