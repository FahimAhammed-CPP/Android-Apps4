package com.amazon.device.iap.internal.util;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.h.a;
import com.amazon.device.iap.model.RequestId;
import org.json.JSONObject;

public class MetricsHelper {
  private static final String DESCRIPTION = "description";
  
  private static final String EXCEPTION_MESSAGE = "exceptionMessage";
  
  private static final String EXCEPTION_METRIC = "GenericException";
  
  private static final String JSON_PARSING_EXCEPTION_METRIC = "JsonParsingFailed";
  
  private static final String JSON_STRING = "jsonString";
  
  private static final String RECEIPT_VERIFICATION_FAILED_METRIC = "IapReceiptVerificationFailed";
  
  private static final String SIGNATURE = "signature";
  
  private static final String STRING_TO_SIGN = "stringToSign";
  
  private static final String TAG = MetricsHelper.class.getSimpleName();
  
  public static void submitExceptionMetrics(String paramString1, String paramString2, Exception paramException) {
    try {
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("exceptionMessage", paramException.getMessage());
      jSONObject.put("description", paramString2);
      submitMetric(paramString1, "GenericException", jSONObject);
      return;
    } catch (Exception exception) {
      e.b(TAG, "error calling submitMetric: " + exception);
      return;
    } 
  }
  
  public static void submitJsonParsingExceptionMetrics(String paramString1, String paramString2, String paramString3) {
    try {
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("jsonString", paramString2);
      jSONObject.put("description", paramString3);
      submitMetric(paramString1, "JsonParsingFailed", jSONObject);
      return;
    } catch (Exception exception) {
      e.b(TAG, "error calling submitMetric: " + exception);
      return;
    } 
  }
  
  protected static void submitMetric(String paramString1, String paramString2, JSONObject paramJSONObject) {
    (new a(new e(RequestId.fromString(paramString1)), paramString2, paramJSONObject.toString())).a_();
  }
  
  public static void submitReceiptVerificationFailureMetrics(String paramString1, String paramString2, String paramString3) {
    try {
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("stringToSign", paramString2);
      jSONObject.put("signature", paramString3);
      submitMetric(paramString1, "IapReceiptVerificationFailed", jSONObject);
      return;
    } catch (Exception exception) {
      e.b(TAG, "error calling submitMetric: " + exception);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\interna\\util\MetricsHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */