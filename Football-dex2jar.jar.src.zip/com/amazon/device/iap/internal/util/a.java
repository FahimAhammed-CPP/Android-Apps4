package com.amazon.device.iap.internal.util;

import com.amazon.android.Kiwi;
import com.amazon.device.iap.internal.b.d;
import com.amazon.device.iap.internal.model.ReceiptBuilder;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.Receipt;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;

public class a {
  private static final String a = a.class.getSimpleName();
  
  private static Receipt a(JSONObject paramJSONObject) throws JSONException {
    Date date2;
    String str3 = null;
    String str4 = paramJSONObject.optString("token");
    String str5 = paramJSONObject.getString("sku");
    ProductType productType = ProductType.valueOf(paramJSONObject.getString("itemType").toUpperCase());
    String str2 = paramJSONObject.optString("startDate");
    if (a(str2)) {
      str2 = null;
    } else {
      date2 = b(str2);
    } 
    String str1 = paramJSONObject.optString("endDate");
    if (a(str1)) {
      str1 = str3;
      return (new ReceiptBuilder()).setReceiptId(str4).setSku(str5).setProductType(productType).setPurchaseDate(date2).setCancelDate((Date)str1).build();
    } 
    Date date1 = b(str1);
    return (new ReceiptBuilder()).setReceiptId(str4).setSku(str5).setProductType(productType).setPurchaseDate(date2).setCancelDate(date1).build();
  }
  
  public static Receipt a(JSONObject paramJSONObject, String paramString1, String paramString2) throws com.amazon.device.iap.internal.b.a, d, IllegalArgumentException {
    c c = b(paramJSONObject);
    switch (null.a[c.ordinal()]) {
      default:
        return d(paramJSONObject, paramString1, paramString2);
      case 1:
        return c(paramJSONObject, paramString1, paramString2);
      case 2:
        break;
    } 
    return b(paramJSONObject, paramString1, paramString2);
  }
  
  protected static boolean a(String paramString) {
    return (paramString == null || paramString.trim().length() == 0);
  }
  
  private static c b(JSONObject paramJSONObject) {
    String str = paramJSONObject.optString("DeviceId");
    return !d.a(paramJSONObject.optString("receiptId")) ? c.c : (d.a(str) ? c.a : c.b);
  }
  
  private static Receipt b(JSONObject paramJSONObject, String paramString1, String paramString2) throws com.amazon.device.iap.internal.b.a, d {
    String str1;
    Receipt receipt;
    String str2 = paramJSONObject.optString("signature");
    if (d.a(str2)) {
      e.b(a, "a signature was not found in the receipt for request ID " + paramString2);
      MetricsHelper.submitReceiptVerificationFailureMetrics(paramString2, "NO Signature found", str2);
      throw new d(paramString2, null, str2);
    } 
    try {
      receipt = a(paramJSONObject);
      str1 = paramString1 + "-" + receipt.getReceiptId();
      boolean bool = Kiwi.isSignedByKiwi(str1, str2);
      e.a(a, "stringToVerify/legacy:\n" + str1 + "\nsignature:\n" + str2);
      if (!bool) {
        MetricsHelper.submitReceiptVerificationFailureMetrics(paramString2, str1, str2);
        throw new d(paramString2, str1, str2);
      } 
    } catch (JSONException jSONException) {
      throw new com.amazon.device.iap.internal.b.a(paramString2, str1.toString(), jSONException);
    } 
    return receipt;
  }
  
  protected static Date b(String paramString) throws JSONException {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    try {
      Date date = simpleDateFormat.parse(paramString);
      long l = date.getTime();
      if (0L == l)
        date = null; 
      return date;
    } catch (ParseException parseException) {
      throw new JSONException(parseException.getMessage());
    } 
  }
  
  private static Receipt c(JSONObject paramJSONObject, String paramString1, String paramString2) throws com.amazon.device.iap.internal.b.a, d {
    String str1;
    Receipt receipt;
    Date date = null;
    String str3 = paramJSONObject.optString("DeviceId");
    String str2 = paramJSONObject.optString("signature");
    if (d.a(str2)) {
      e.b(a, "a signature was not found in the receipt for request ID " + paramString2);
      MetricsHelper.submitReceiptVerificationFailureMetrics(paramString2, "NO Signature found", str2);
      throw new d(paramString2, null, str2);
    } 
    try {
      receipt = a(paramJSONObject);
      ProductType productType = receipt.getProductType();
      String str4 = receipt.getSku();
      String str5 = receipt.getReceiptId();
      if (ProductType.SUBSCRIPTION == receipt.getProductType()) {
        Date date1 = receipt.getPurchaseDate();
      } else {
        paramJSONObject = null;
      } 
      if (ProductType.SUBSCRIPTION == receipt.getProductType())
        date = receipt.getCancelDate(); 
      str1 = String.format("%s|%s|%s|%s|%s|%s|%s|%tQ|%tQ", new Object[] { "2.0.61.0", paramString1, str3, productType, str4, str5, paramString2, paramJSONObject, date });
      e.a(a, "stringToVerify/v1:\n" + str1 + "\nsignature:\n" + str2);
      if (!Kiwi.isSignedByKiwi(str1, str2)) {
        MetricsHelper.submitReceiptVerificationFailureMetrics(paramString2, str1, str2);
        throw new d(paramString2, str1, str2);
      } 
    } catch (JSONException jSONException) {
      throw new com.amazon.device.iap.internal.b.a(paramString2, str1.toString(), jSONException);
    } 
    return receipt;
  }
  
  private static Receipt d(JSONObject paramJSONObject, String paramString1, String paramString2) throws com.amazon.device.iap.internal.b.a, d {
    String str1;
    Receipt receipt;
    Date date = null;
    String str3 = paramJSONObject.optString("DeviceId");
    String str2 = paramJSONObject.optString("signature");
    if (d.a(str2)) {
      e.b(a, "a signature was not found in the receipt for request ID " + paramString2);
      MetricsHelper.submitReceiptVerificationFailureMetrics(paramString2, "NO Signature found", str2);
      throw new d(paramString2, null, str2);
    } 
    try {
      Date date1;
      String str5 = paramJSONObject.getString("receiptId");
      String str6 = paramJSONObject.getString("sku");
      ProductType productType = ProductType.valueOf(paramJSONObject.getString("itemType").toUpperCase());
      String str4 = paramJSONObject.optString("purchaseDate");
      if (a(str4)) {
        str4 = null;
      } else {
        date1 = b(str4);
      } 
      String str7 = paramJSONObject.optString("cancelDate");
      if (!a(str7))
        date = b(str7); 
      receipt = (new ReceiptBuilder()).setReceiptId(str5).setSku(str6).setProductType(productType).setPurchaseDate(date1).setCancelDate(date).build();
      str1 = String.format("%s|%s|%s|%s|%s|%tQ|%tQ", new Object[] { paramString1, str3, receipt.getProductType(), receipt.getSku(), receipt.getReceiptId(), receipt.getPurchaseDate(), receipt.getCancelDate() });
      e.a(a, "stringToVerify/v2:\n" + str1 + "\nsignature:\n" + str2);
      if (!Kiwi.isSignedByKiwi(str1, str2)) {
        MetricsHelper.submitReceiptVerificationFailureMetrics(paramString2, str1, str2);
        throw new d(paramString2, str1, str2);
      } 
    } catch (JSONException jSONException) {
      throw new com.amazon.device.iap.internal.b.a(paramString2, str1.toString(), jSONException);
    } 
    return receipt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\interna\\util\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */