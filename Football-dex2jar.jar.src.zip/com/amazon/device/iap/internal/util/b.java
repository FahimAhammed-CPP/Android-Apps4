package com.amazon.device.iap.internal.util;

import android.content.Context;
import android.content.SharedPreferences;
import com.amazon.device.iap.internal.d;

public class b {
  private static final String a = b.class.getName() + "_PREFS";
  
  public static String a(String paramString) {
    d.a(paramString, "userId");
    Context context = d.d().b();
    d.a(context, "context");
    return context.getSharedPreferences(a, 0).getString(paramString, null);
  }
  
  public static void a(String paramString1, String paramString2) {
    d.a(paramString1, "userId");
    Context context = d.d().b();
    d.a(context, "context");
    SharedPreferences.Editor editor = context.getSharedPreferences(a, 0).edit();
    editor.putString(paramString1, paramString2);
    editor.commit();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\interna\\util\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */