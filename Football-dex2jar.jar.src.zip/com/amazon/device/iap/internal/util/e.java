package com.amazon.device.iap.internal.util;

public class e {
  public static void a(String paramString1, String paramString2) {
    if (a())
      com.amazon.device.iap.internal.e.c().a(paramString1, paramString2); 
  }
  
  public static boolean a() {
    return com.amazon.device.iap.internal.e.c().a();
  }
  
  public static void b(String paramString1, String paramString2) {
    if (b())
      com.amazon.device.iap.internal.e.c().b(paramString1, paramString2); 
  }
  
  public static boolean b() {
    return com.amazon.device.iap.internal.e.c().b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\interna\\util\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */