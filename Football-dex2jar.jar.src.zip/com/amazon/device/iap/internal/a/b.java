package com.amazon.device.iap.internal.a;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public final class b {
  static final DateFormat a = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */