package com.amazon.device.iap.internal.a;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.internal.c;
import com.amazon.device.iap.internal.d;
import com.amazon.device.iap.internal.model.ProductBuilder;
import com.amazon.device.iap.internal.model.ProductDataResponseBuilder;
import com.amazon.device.iap.internal.model.PurchaseResponseBuilder;
import com.amazon.device.iap.internal.model.PurchaseUpdatesResponseBuilder;
import com.amazon.device.iap.internal.model.ReceiptBuilder;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.internal.model.UserDataResponseBuilder;
import com.amazon.device.iap.internal.util.b;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.internal.util.e;
import com.amazon.device.iap.model.FulfillmentResult;
import com.amazon.device.iap.model.Product;
import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.RequestId;
import com.amazon.device.iap.model.UserData;
import com.amazon.device.iap.model.UserDataResponse;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class c implements c {
  private static final String a = c.class.getSimpleName();
  
  private Intent a(String paramString) {
    Intent intent = new Intent(paramString);
    intent.setComponent(new ComponentName("com.amazon.sdktestclient", "com.amazon.sdktestclient.command.CommandBroker"));
    return intent;
  }
  
  private Product a(String paramString, JSONObject paramJSONObject) throws JSONException {
    ProductType productType = ProductType.valueOf(paramJSONObject.optString("itemType"));
    JSONObject jSONObject = paramJSONObject.getJSONObject("priceJson");
    Currency currency = Currency.getInstance(jSONObject.optString("currency"));
    BigDecimal bigDecimal = new BigDecimal(jSONObject.optString("value"));
    String str2 = currency.getSymbol() + bigDecimal;
    String str3 = paramJSONObject.optString("title");
    String str4 = paramJSONObject.optString("description");
    String str1 = paramJSONObject.optString("smallIconUrl");
    return (new ProductBuilder()).setSku(paramString).setProductType(productType).setDescription(str4).setPrice(str2).setSmallIconUrl(str1).setTitle(str3).build();
  }
  
  private Receipt a(JSONObject paramJSONObject) throws ParseException {
    String str2 = paramJSONObject.optString("receiptId");
    String str3 = paramJSONObject.optString("sku");
    ProductType productType = ProductType.valueOf(paramJSONObject.optString("itemType"));
    String str4 = paramJSONObject.optString("purchaseDate");
    Date date2 = b.a.parse(str4);
    String str1 = paramJSONObject.optString("cancelDate");
    if (str1 == null || str1.length() == 0) {
      str1 = null;
      return (new ReceiptBuilder()).setReceiptId(str2).setSku(str3).setProductType(productType).setPurchaseDate(date2).setCancelDate((Date)str1).build();
    } 
    Date date1 = b.a.parse(str1);
    return (new ReceiptBuilder()).setReceiptId(str2).setSku(str3).setProductType(productType).setPurchaseDate(date2).setCancelDate(date1).build();
  }
  
  private void a(Intent paramIntent) throws JSONException {
    PurchaseUpdatesResponse purchaseUpdatesResponse = b(paramIntent);
    if (purchaseUpdatesResponse.getRequestStatus() == PurchaseUpdatesResponse.RequestStatus.SUCCESSFUL) {
      String str = (new JSONObject(paramIntent.getStringExtra("purchaseUpdatesOutput"))).optString("offset");
      Log.i(a, "Offset for PurchaseUpdatesResponse:" + str);
      b.a(purchaseUpdatesResponse.getUserData().getUserId(), str);
    } 
    a(purchaseUpdatesResponse);
  }
  
  private void a(String paramString1, String paramString2, boolean paramBoolean) {
    try {
      Context context = d.d().b();
      String str = b.a(paramString2);
      Log.i(a, "send PurchaseUpdates with user id:" + paramString2 + ";reset flag:" + paramBoolean + ", local cursor:" + str + ", parsed from old requestId:" + paramString1);
      Bundle bundle = new Bundle();
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("requestId", paramString1.toString());
      paramString1 = str;
      if (paramBoolean)
        paramString1 = null; 
      jSONObject.put("offset", paramString1);
      jSONObject.put("sdkVersion", "2.0.61.0");
      jSONObject.put("packageName", context.getPackageName());
      bundle.putString("purchaseUpdatesInput", jSONObject.toString());
      Intent intent = a("com.amazon.testclient.iap.purchaseUpdates");
      intent.addFlags(268435456);
      intent.putExtras(bundle);
      context.startService(intent);
      return;
    } catch (JSONException jSONException) {
      e.b(a, "Error in sendPurchaseUpdatesRequest.");
      return;
    } 
  }
  
  private void a(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
    try {
      Context context = d.d().b();
      Bundle bundle = new Bundle();
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("requestId", paramString);
      jSONObject.put("packageName", context.getPackageName());
      jSONObject.put("sdkVersion", "2.0.61.0");
      jSONObject.put("isPurchaseUpdates", paramBoolean1);
      jSONObject.put("reset", paramBoolean2);
      bundle.putString("userInput", jSONObject.toString());
      Intent intent = a("com.amazon.testclient.iap.appUserId");
      intent.addFlags(268435456);
      intent.putExtras(bundle);
      context.startService(intent);
      return;
    } catch (JSONException jSONException) {
      e.b(a, "Error in sendGetUserDataRequest.");
      return;
    } 
  }
  
  private PurchaseUpdatesResponse b(Intent paramIntent) {
    boolean bool;
    PurchaseUpdatesResponse.RequestStatus requestStatus3;
    RequestId requestId;
    int i = 0;
    PurchaseUpdatesResponse.RequestStatus requestStatus1 = PurchaseUpdatesResponse.RequestStatus.FAILED;
    try {
      JSONObject jSONObject = new JSONObject(paramIntent.getStringExtra("purchaseUpdatesOutput"));
      requestId = RequestId.fromString(jSONObject.optString("requestId"));
      try {
        requestStatus3 = PurchaseUpdatesResponse.RequestStatus.valueOf(jSONObject.optString("status"));
        requestStatus1 = requestStatus3;
        bool = jSONObject.optBoolean("isMore");
        try {
          String str1 = jSONObject.optString("userId");
          String str2 = jSONObject.optString("marketplace");
          UserData userData = (new UserDataBuilder()).setUserId(str1).setMarketplace(str2).build();
          try {
            if (requestStatus3 == PurchaseUpdatesResponse.RequestStatus.SUCCESSFUL) {
              ArrayList<Receipt> arrayList = new ArrayList();
              try {
                JSONArray jSONArray = jSONObject.optJSONArray("receipts");
                ArrayList<Receipt> arrayList1 = arrayList;
                if (jSONArray != null)
                  while (true) {
                    arrayList1 = arrayList;
                    if (i < jSONArray.length()) {
                      JSONObject jSONObject1 = jSONArray.optJSONObject(i);
                      try {
                        arrayList.add(a(jSONObject1));
                      } catch (Exception exception1) {}
                    } else {
                      break;
                    } 
                    i++;
                  }  
              } catch (Exception exception1) {
                ArrayList<Receipt> arrayList1 = arrayList;
                Log.e(a, "Error parsing purchase updates output", exception1);
                PurchaseUpdatesResponse.RequestStatus requestStatus4 = requestStatus3;
                return (new PurchaseUpdatesResponseBuilder()).setRequestId(requestId).setRequestStatus(requestStatus4).setUserData(userData).setReceipts(arrayList1).setHasMore(bool).build();
              } 
            } else {
              jSONObject = null;
            } 
            PurchaseUpdatesResponse.RequestStatus requestStatus = requestStatus3;
            return (new PurchaseUpdatesResponseBuilder()).setRequestId(requestId).setRequestStatus(requestStatus).setUserData(userData).setReceipts((List)jSONObject).setHasMore(bool).build();
          } catch (Exception null) {
            jSONObject = null;
          } 
        } catch (Exception null) {
          jSONObject = null;
          requestStatus1 = null;
        } 
      } catch (Exception null) {
        jSONObject = null;
        bool = false;
        PurchaseUpdatesResponse.RequestStatus requestStatus = null;
        requestStatus3 = requestStatus1;
        requestStatus1 = requestStatus;
      } 
    } catch (Exception exception) {
      paramIntent = null;
      bool = false;
      PurchaseUpdatesResponse.RequestStatus requestStatus = null;
      requestId = null;
      requestStatus3 = requestStatus1;
      requestStatus1 = requestStatus;
    } 
    Log.e(a, "Error parsing purchase updates output", exception);
    PurchaseUpdatesResponse.RequestStatus requestStatus2 = requestStatus3;
    return (new PurchaseUpdatesResponseBuilder()).setRequestId(requestId).setRequestStatus(requestStatus2).setUserData((UserData)requestStatus1).setReceipts((List)paramIntent).setHasMore(bool).build();
  }
  
  private void c(Intent paramIntent) {
    a(d(paramIntent));
  }
  
  private ProductDataResponse d(Intent paramIntent) {
    Exception exception1;
    HashMap<Object, Object> hashMap;
    ProductDataResponse.RequestStatus requestStatus = ProductDataResponse.RequestStatus.FAILED;
    try {
      HashMap<Object, Object> hashMap1;
      JSONObject jSONObject = new JSONObject(paramIntent.getStringExtra("itemDataOutput"));
      exception3 = (Exception)RequestId.fromString(jSONObject.optString("requestId"));
      ProductDataResponse.RequestStatus requestStatus1 = requestStatus;
      try {
        HashMap<Object, Object> hashMap2;
        requestStatus = ProductDataResponse.RequestStatus.valueOf(jSONObject.optString("status"));
        requestStatus1 = requestStatus;
        if (requestStatus != ProductDataResponse.RequestStatus.FAILED) {
          requestStatus1 = requestStatus;
          exception1 = (Exception)new LinkedHashSet();
          try {
            LinkedHashSet<String> linkedHashSet2;
            HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>();
            try {
              JSONArray jSONArray = jSONObject.optJSONArray("unavailableSkus");
              if (jSONArray != null)
                for (int i = 0; i < jSONArray.length(); i++)
                  exception1.add(jSONArray.getString(i));  
              JSONObject jSONObject1 = jSONObject.optJSONObject("items");
              if (jSONObject1 != null) {
                Iterator<String> iterator = jSONObject1.keys();
                while (iterator.hasNext()) {
                  String str = iterator.next();
                  hashMap3.put(str, a(str, jSONObject1.optJSONObject(str)));
                } 
              } 
            } catch (Exception exception) {
              Log.e(a, "Error parsing item data output", exception);
              RequestId requestId = (RequestId)exception3;
              linkedHashSet2 = (LinkedHashSet<String>)exception1;
              hashMap4 = hashMap3;
              return (new ProductDataResponseBuilder()).setRequestId(requestId).setRequestStatus(requestStatus).setProductData(hashMap4).setUnavailableSkus(linkedHashSet2).build();
            } 
            HashMap<Object, Object> hashMap5 = hashMap3;
            hashMap3 = hashMap4;
            HashMap<Object, Object> hashMap4 = hashMap5;
            LinkedHashSet<String> linkedHashSet1 = linkedHashSet2;
            hashMap2 = hashMap3;
          } catch (Exception null) {
            paramIntent = null;
          } 
        } else {
          exception1 = null;
          paramIntent = null;
          hashMap1 = hashMap2;
          Intent intent1 = paramIntent;
        } 
      } catch (Exception exception) {
        paramIntent = null;
        exception1 = null;
        hashMap = hashMap1;
        exception2 = exception;
      } 
    } catch (Exception exception2) {
      paramIntent = null;
      exception1 = null;
      exception3 = null;
    } 
    Log.e(a, "Error parsing item data output", exception2);
    exception2 = exception3;
    Exception exception3 = exception1;
    Intent intent = paramIntent;
    return (new ProductDataResponseBuilder()).setRequestId((RequestId)exception2).setRequestStatus((ProductDataResponse.RequestStatus)hashMap).setProductData((Map)intent).setUnavailableSkus((Set)exception3).build();
  }
  
  private void e(Intent paramIntent) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial f : (Landroid/content/Intent;)Lcom/amazon/device/iap/model/UserDataResponse;
    //   5: astore_3
    //   6: aload_3
    //   7: invokevirtual getRequestId : ()Lcom/amazon/device/iap/model/RequestId;
    //   10: astore #4
    //   12: aload_1
    //   13: ldc_w 'userInput'
    //   16: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   19: astore #5
    //   21: new org/json/JSONObject
    //   24: dup
    //   25: aload #5
    //   27: invokespecial <init> : (Ljava/lang/String;)V
    //   30: astore_1
    //   31: aload #4
    //   33: ifnull -> 40
    //   36: aload_1
    //   37: ifnonnull -> 81
    //   40: aload_0
    //   41: aload_3
    //   42: invokevirtual a : (Ljava/lang/Object;)V
    //   45: return
    //   46: astore_1
    //   47: getstatic com/amazon/device/iap/internal/a/c.a : Ljava/lang/String;
    //   50: new java/lang/StringBuilder
    //   53: dup
    //   54: invokespecial <init> : ()V
    //   57: ldc_w 'Unable to parse request data: '
    //   60: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: aload #5
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: invokevirtual toString : ()Ljava/lang/String;
    //   71: aload_1
    //   72: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   75: pop
    //   76: aconst_null
    //   77: astore_1
    //   78: goto -> 31
    //   81: aload_1
    //   82: ldc_w 'isPurchaseUpdates'
    //   85: iconst_0
    //   86: invokevirtual optBoolean : (Ljava/lang/String;Z)Z
    //   89: ifne -> 98
    //   92: aload_0
    //   93: aload_3
    //   94: invokevirtual a : (Ljava/lang/Object;)V
    //   97: return
    //   98: aload_3
    //   99: invokevirtual getUserData : ()Lcom/amazon/device/iap/model/UserData;
    //   102: ifnull -> 118
    //   105: aload_3
    //   106: invokevirtual getUserData : ()Lcom/amazon/device/iap/model/UserData;
    //   109: invokevirtual getUserId : ()Ljava/lang/String;
    //   112: invokestatic a : (Ljava/lang/String;)Z
    //   115: ifeq -> 192
    //   118: getstatic com/amazon/device/iap/internal/a/c.a : Ljava/lang/String;
    //   121: new java/lang/StringBuilder
    //   124: dup
    //   125: invokespecial <init> : ()V
    //   128: ldc_w 'No Userid found in userDataResponse'
    //   131: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   134: aload_3
    //   135: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   138: invokevirtual toString : ()Ljava/lang/String;
    //   141: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   144: pop
    //   145: aload_0
    //   146: new com/amazon/device/iap/internal/model/PurchaseUpdatesResponseBuilder
    //   149: dup
    //   150: invokespecial <init> : ()V
    //   153: aload #4
    //   155: invokevirtual setRequestId : (Lcom/amazon/device/iap/model/RequestId;)Lcom/amazon/device/iap/internal/model/PurchaseUpdatesResponseBuilder;
    //   158: getstatic com/amazon/device/iap/model/PurchaseUpdatesResponse$RequestStatus.FAILED : Lcom/amazon/device/iap/model/PurchaseUpdatesResponse$RequestStatus;
    //   161: invokevirtual setRequestStatus : (Lcom/amazon/device/iap/model/PurchaseUpdatesResponse$RequestStatus;)Lcom/amazon/device/iap/internal/model/PurchaseUpdatesResponseBuilder;
    //   164: aload_3
    //   165: invokevirtual getUserData : ()Lcom/amazon/device/iap/model/UserData;
    //   168: invokevirtual setUserData : (Lcom/amazon/device/iap/model/UserData;)Lcom/amazon/device/iap/internal/model/PurchaseUpdatesResponseBuilder;
    //   171: new java/util/ArrayList
    //   174: dup
    //   175: invokespecial <init> : ()V
    //   178: invokevirtual setReceipts : (Ljava/util/List;)Lcom/amazon/device/iap/internal/model/PurchaseUpdatesResponseBuilder;
    //   181: iconst_0
    //   182: invokevirtual setHasMore : (Z)Lcom/amazon/device/iap/internal/model/PurchaseUpdatesResponseBuilder;
    //   185: invokevirtual build : ()Lcom/amazon/device/iap/model/PurchaseUpdatesResponse;
    //   188: invokevirtual a : (Ljava/lang/Object;)V
    //   191: return
    //   192: getstatic com/amazon/device/iap/internal/a/c.a : Ljava/lang/String;
    //   195: new java/lang/StringBuilder
    //   198: dup
    //   199: invokespecial <init> : ()V
    //   202: ldc_w 'sendGetPurchaseUpdates with user id'
    //   205: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: aload_3
    //   209: invokevirtual getUserData : ()Lcom/amazon/device/iap/model/UserData;
    //   212: invokevirtual getUserId : ()Ljava/lang/String;
    //   215: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   218: invokevirtual toString : ()Ljava/lang/String;
    //   221: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   224: pop
    //   225: aload_1
    //   226: ldc_w 'reset'
    //   229: iconst_1
    //   230: invokevirtual optBoolean : (Ljava/lang/String;Z)Z
    //   233: istore_2
    //   234: aload_0
    //   235: aload #4
    //   237: invokevirtual toString : ()Ljava/lang/String;
    //   240: aload_3
    //   241: invokevirtual getUserData : ()Lcom/amazon/device/iap/model/UserData;
    //   244: invokevirtual getUserId : ()Ljava/lang/String;
    //   247: iload_2
    //   248: invokespecial a : (Ljava/lang/String;Ljava/lang/String;Z)V
    //   251: return
    // Exception table:
    //   from	to	target	type
    //   21	31	46	org/json/JSONException
  }
  
  private UserDataResponse f(Intent paramIntent) {
    String str2 = null;
    UserDataResponse.RequestStatus requestStatus1 = UserDataResponse.RequestStatus.FAILED;
    try {
      JSONObject jSONObject = new JSONObject(paramIntent.getStringExtra("userOutput"));
      RequestId requestId = RequestId.fromString(jSONObject.optString("requestId"));
      try {
        UserData userData;
        UserDataResponse.RequestStatus requestStatus3 = UserDataResponse.RequestStatus.valueOf(jSONObject.optString("status"));
        String str = str2;
        UserDataResponse.RequestStatus requestStatus4 = requestStatus3;
        RequestId requestId1 = requestId;
        requestStatus1 = requestStatus3;
        if (requestStatus3 == UserDataResponse.RequestStatus.SUCCESSFUL) {
          requestStatus1 = requestStatus3;
          str = jSONObject.optString("userId");
          requestStatus1 = requestStatus3;
          String str3 = jSONObject.optString("marketplace");
          requestStatus1 = requestStatus3;
          userData = (new UserDataBuilder()).setUserId(str).setMarketplace(str3).build();
          requestId1 = requestId;
          requestStatus4 = requestStatus3;
        } 
        return (new UserDataResponseBuilder()).setRequestId(requestId1).setRequestStatus(requestStatus4).setUserData(userData).build();
      } catch (Exception null) {}
    } catch (Exception exception) {
      paramIntent = null;
    } 
    Log.e(a, "Error parsing userid output", exception);
    String str1 = str2;
    UserDataResponse.RequestStatus requestStatus2 = requestStatus1;
    Intent intent = paramIntent;
    return (new UserDataResponseBuilder()).setRequestId((RequestId)intent).setRequestStatus(requestStatus2).setUserData((UserData)str1).build();
  }
  
  private void g(Intent paramIntent) {
    a(h(paramIntent));
  }
  
  private PurchaseResponse h(Intent paramIntent) {
    RequestId requestId1;
    JSONObject jSONObject2 = null;
    PurchaseResponse.RequestStatus requestStatus = PurchaseResponse.RequestStatus.FAILED;
    try {
      JSONObject jSONObject = new JSONObject(paramIntent.getStringExtra("purchaseOutput"));
      requestId1 = RequestId.fromString(jSONObject.optString("requestId"));
      try {
        String str1 = jSONObject.optString("userId");
        String str2 = jSONObject.optString("marketplace");
        UserData userData = (new UserDataBuilder()).setUserId(str1).setMarketplace(str2).build();
        try {
          Receipt receipt;
          PurchaseResponse.RequestStatus requestStatus1 = PurchaseResponse.RequestStatus.safeValueOf(jSONObject.optString("purchaseStatus"));
          requestStatus = requestStatus1;
          JSONObject jSONObject3 = jSONObject.optJSONObject("receipt");
          jSONObject = jSONObject2;
          requestStatus = requestStatus1;
          UserData userData1 = userData;
          RequestId requestId = requestId1;
          if (jSONObject3 != null) {
            requestStatus = requestStatus1;
            receipt = a(jSONObject3);
            requestId = requestId1;
            userData1 = userData;
            requestStatus = requestStatus1;
          } 
          return (new PurchaseResponseBuilder()).setRequestId(requestId).setRequestStatus(requestStatus).setUserData(userData1).setReceipt(receipt).build();
        } catch (Exception null) {}
      } catch (Exception null) {
        paramIntent = null;
      } 
    } catch (Exception exception) {
      paramIntent = null;
      requestId1 = null;
    } 
    Log.e(a, "Error parsing purchase output", exception);
    JSONObject jSONObject1 = jSONObject2;
    Intent intent = paramIntent;
    RequestId requestId2 = requestId1;
    return (new PurchaseResponseBuilder()).setRequestId(requestId2).setRequestStatus(requestStatus).setUserData((UserData)intent).setReceipt((Receipt)jSONObject1).build();
  }
  
  public void a(Context paramContext, Intent paramIntent) {
    e.a(a, "handleResponse");
    paramIntent.setComponent(new ComponentName("com.amazon.sdktestclient", "com.amazon.sdktestclient.command.CommandBroker"));
    try {
      String str = paramIntent.getExtras().getString("responseType");
      if (str.equalsIgnoreCase("com.amazon.testclient.iap.purchase")) {
        g(paramIntent);
        return;
      } 
      if (str.equalsIgnoreCase("com.amazon.testclient.iap.appUserId")) {
        e(paramIntent);
        return;
      } 
    } catch (Exception exception) {
      Log.e(a, "Error handling response.", exception);
      return;
    } 
    if (exception.equalsIgnoreCase("com.amazon.testclient.iap.itemData")) {
      c(paramIntent);
      return;
    } 
    if (exception.equalsIgnoreCase("com.amazon.testclient.iap.purchaseUpdates"))
      a(paramIntent); 
  }
  
  public void a(RequestId paramRequestId) {
    e.a(a, "sendGetUserDataRequest");
    a(paramRequestId.toString(), false, false);
  }
  
  public void a(RequestId paramRequestId, String paramString) {
    e.a(a, "sendPurchaseRequest");
    try {
      Context context = d.d().b();
      Bundle bundle = new Bundle();
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("sku", paramString);
      jSONObject.put("requestId", paramRequestId.toString());
      jSONObject.put("packageName", context.getPackageName());
      jSONObject.put("sdkVersion", "2.0.61.0");
      bundle.putString("purchaseInput", jSONObject.toString());
      Intent intent = a("com.amazon.testclient.iap.purchase");
      intent.addFlags(268435456);
      intent.putExtras(bundle);
      context.startService(intent);
      return;
    } catch (JSONException jSONException) {
      e.b(a, "Error in sendPurchaseRequest.");
      return;
    } 
  }
  
  public void a(RequestId paramRequestId, String paramString, FulfillmentResult paramFulfillmentResult) {
    e.a(a, "sendNotifyPurchaseFulfilled");
    try {
      Context context = d.d().b();
      Bundle bundle = new Bundle();
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("requestId", paramRequestId.toString());
      jSONObject.put("packageName", context.getPackageName());
      jSONObject.put("receiptId", paramString);
      jSONObject.put("fulfillmentResult", paramFulfillmentResult);
      jSONObject.put("sdkVersion", "2.0.61.0");
      bundle.putString("purchaseFulfilledInput", jSONObject.toString());
      Intent intent = a("com.amazon.testclient.iap.purchaseFulfilled");
      intent.addFlags(268435456);
      intent.putExtras(bundle);
      context.startService(intent);
      return;
    } catch (JSONException jSONException) {
      e.b(a, "Error in sendNotifyPurchaseFulfilled.");
      return;
    } 
  }
  
  public void a(RequestId paramRequestId, Set<String> paramSet) {
    e.a(a, "sendItemDataRequest");
    try {
      Context context = d.d().b();
      Bundle bundle = new Bundle();
      JSONObject jSONObject = new JSONObject();
      JSONArray jSONArray = new JSONArray(paramSet);
      jSONObject.put("requestId", paramRequestId.toString());
      jSONObject.put("packageName", context.getPackageName());
      jSONObject.put("skus", jSONArray);
      jSONObject.put("sdkVersion", "2.0.61.0");
      bundle.putString("itemDataInput", jSONObject.toString());
      Intent intent = a("com.amazon.testclient.iap.itemData");
      intent.addFlags(268435456);
      intent.putExtras(bundle);
      context.startService(intent);
      return;
    } catch (JSONException jSONException) {
      e.b(a, "Error in sendItemDataRequest.");
      return;
    } 
  }
  
  public void a(RequestId paramRequestId, boolean paramBoolean) {
    RequestId requestId = paramRequestId;
    if (paramRequestId == null)
      requestId = new RequestId(); 
    e.a(a, "sendPurchaseUpdatesRequest/sendGetUserData first:" + requestId);
    a(requestId.toString(), true, paramBoolean);
  }
  
  protected void a(Object paramObject) {
    d.a(paramObject, "response");
    Context context = d.d().b();
    PurchasingListener purchasingListener = d.d().a();
    if (context == null || purchasingListener == null) {
      e.a(a, "PurchasingListener is not set. Dropping response: " + paramObject);
      return;
    } 
    paramObject = new Runnable(this, paramObject, purchasingListener) {
        public void run() {
          try {
            if (this.a instanceof ProductDataResponse) {
              this.b.onProductDataResponse((ProductDataResponse)this.a);
              return;
            } 
            if (this.a instanceof UserDataResponse) {
              this.b.onUserDataResponse((UserDataResponse)this.a);
              return;
            } 
          } catch (Exception exception) {
            e.b(c.a(), "Error in sendResponse: " + exception);
            return;
          } 
          if (this.a instanceof PurchaseUpdatesResponse) {
            this.b.onPurchaseUpdatesResponse((PurchaseUpdatesResponse)this.a);
            return;
          } 
          if (this.a instanceof PurchaseResponse) {
            this.b.onPurchaseResponse((PurchaseResponse)this.a);
            return;
          } 
          e.b(c.a(), "Unknown response type:" + this.a.getClass().getName());
        }
      };
    (new Handler(context.getMainLooper())).post((Runnable)paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */