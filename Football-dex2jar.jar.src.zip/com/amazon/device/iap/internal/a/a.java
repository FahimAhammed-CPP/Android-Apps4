package com.amazon.device.iap.internal.a;

import android.util.Log;
import com.amazon.device.iap.internal.a;

public class a implements a {
  private static String a(String paramString) {
    return "In App Purchasing SDK - Sandbox Mode: " + paramString;
  }
  
  public void a(String paramString1, String paramString2) {
    Log.d(paramString1, a(paramString2));
  }
  
  public boolean a() {
    return true;
  }
  
  public void b(String paramString1, String paramString2) {
    Log.e(paramString1, a(paramString2));
  }
  
  public boolean b() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */