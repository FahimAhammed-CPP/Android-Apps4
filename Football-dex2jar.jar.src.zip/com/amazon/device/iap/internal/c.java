package com.amazon.device.iap.internal;

import android.content.Context;
import android.content.Intent;
import com.amazon.device.iap.model.FulfillmentResult;
import com.amazon.device.iap.model.RequestId;
import java.util.Set;

public interface c {
  void a(Context paramContext, Intent paramIntent);
  
  void a(RequestId paramRequestId);
  
  void a(RequestId paramRequestId, String paramString);
  
  void a(RequestId paramRequestId, String paramString, FulfillmentResult paramFulfillmentResult);
  
  void a(RequestId paramRequestId, Set<String> paramSet);
  
  void a(RequestId paramRequestId, boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\internal\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */