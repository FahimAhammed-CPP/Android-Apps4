package com.amazon.device.iap.model;

public enum FulfillmentResult {
  FULFILLED, UNAVAILABLE;
  
  static {
    $VALUES = new FulfillmentResult[] { FULFILLED, UNAVAILABLE };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\model\FulfillmentResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */