package com.amazon.device.iap.model;

import com.amazon.device.iap.internal.model.PurchaseResponseBuilder;
import com.amazon.device.iap.internal.util.d;
import org.json.JSONException;
import org.json.JSONObject;

public final class PurchaseResponse {
  private static final String RECEIPT = "receipt";
  
  private static final String REQUEST_ID = "requestId";
  
  private static final String REQUEST_STATUS = "requestStatus";
  
  private static final String TO_STRING_FORMAT = "(%s, requestId: \"%s\", purchaseRequestStatus: \"%s\", userId: \"%s\", receipt: %s)";
  
  private static final String USER_DATA = "userData";
  
  private final Receipt receipt;
  
  private final RequestId requestId;
  
  private final RequestStatus requestStatus;
  
  private final UserData userData;
  
  public PurchaseResponse(PurchaseResponseBuilder paramPurchaseResponseBuilder) {
    d.a(paramPurchaseResponseBuilder.getRequestId(), "requestId");
    d.a(paramPurchaseResponseBuilder.getRequestStatus(), "requestStatus");
    if (paramPurchaseResponseBuilder.getRequestStatus() == RequestStatus.SUCCESSFUL) {
      d.a(paramPurchaseResponseBuilder.getReceipt(), "receipt");
      d.a(paramPurchaseResponseBuilder.getUserData(), "userData");
    } 
    this.requestId = paramPurchaseResponseBuilder.getRequestId();
    this.userData = paramPurchaseResponseBuilder.getUserData();
    this.receipt = paramPurchaseResponseBuilder.getReceipt();
    this.requestStatus = paramPurchaseResponseBuilder.getRequestStatus();
  }
  
  public Receipt getReceipt() {
    return this.receipt;
  }
  
  public RequestId getRequestId() {
    return this.requestId;
  }
  
  public RequestStatus getRequestStatus() {
    return this.requestStatus;
  }
  
  public UserData getUserData() {
    return this.userData;
  }
  
  public JSONObject toJSON() throws JSONException {
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("requestId", this.requestId);
    jSONObject.put("requestStatus", this.requestStatus);
    if (this.userData != null) {
      JSONObject jSONObject1 = this.userData.toJSON();
    } else {
      str = "";
    } 
    jSONObject.put("userData", str);
    if (getReceipt() != null) {
      JSONObject jSONObject1 = getReceipt().toJSON();
      jSONObject.put("receipt", jSONObject1);
      return jSONObject;
    } 
    String str = "";
    jSONObject.put("receipt", str);
    return jSONObject;
  }
  
  public String toString() {
    String str2 = super.toString();
    RequestId requestId = this.requestId;
    if (this.requestStatus != null) {
      String str = this.requestStatus.toString();
      return String.format("(%s, requestId: \"%s\", purchaseRequestStatus: \"%s\", userId: \"%s\", receipt: %s)", new Object[] { str2, requestId, str, this.userData, this.receipt });
    } 
    String str1 = "null";
    return String.format("(%s, requestId: \"%s\", purchaseRequestStatus: \"%s\", userId: \"%s\", receipt: %s)", new Object[] { str2, requestId, str1, this.userData, this.receipt });
  }
  
  public enum RequestStatus {
    ALREADY_PURCHASED, FAILED, INVALID_SKU, NOT_SUPPORTED, SUCCESSFUL;
    
    static {
      ALREADY_PURCHASED = new RequestStatus("ALREADY_PURCHASED", 3);
      NOT_SUPPORTED = new RequestStatus("NOT_SUPPORTED", 4);
      $VALUES = new RequestStatus[] { SUCCESSFUL, FAILED, INVALID_SKU, ALREADY_PURCHASED, NOT_SUPPORTED };
    }
    
    public static RequestStatus safeValueOf(String param1String) {
      return d.a(param1String) ? null : ("ALREADY_ENTITLED".equalsIgnoreCase(param1String) ? ALREADY_PURCHASED : valueOf(param1String.toUpperCase()));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\model\PurchaseResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */