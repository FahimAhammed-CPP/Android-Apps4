package com.amazon.device.iap.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.amazon.device.iap.internal.util.d;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public final class RequestId implements Parcelable {
  public static final Parcelable.Creator<RequestId> CREATOR = new Parcelable.Creator<RequestId>() {
      public RequestId createFromParcel(Parcel param1Parcel) {
        return new RequestId(param1Parcel);
      }
      
      public RequestId[] newArray(int param1Int) {
        return new RequestId[param1Int];
      }
    };
  
  private static final String ENCODED_ID = "encodedId";
  
  private final String encodedId;
  
  public RequestId() {
    this.encodedId = UUID.randomUUID().toString();
  }
  
  private RequestId(Parcel paramParcel) {
    this.encodedId = paramParcel.readString();
  }
  
  private RequestId(String paramString) {
    d.a(paramString, "encodedId");
    this.encodedId = paramString;
  }
  
  public static RequestId fromString(String paramString) {
    return new RequestId(paramString);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject == null || getClass() != paramObject.getClass()) ? false : this.encodedId.equals(((RequestId)paramObject).encodedId);
  }
  
  public int hashCode() {
    if (this.encodedId == null) {
      byte b = 0;
      return b + 31;
    } 
    int i = this.encodedId.hashCode();
    return i + 31;
  }
  
  public JSONObject toJSON() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("encodedId", this.encodedId);
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
  
  public String toString() {
    return this.encodedId;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.encodedId);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\model\RequestId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */