package com.amazon.device.iap.model;

import com.amazon.device.iap.internal.model.UserDataResponseBuilder;
import com.amazon.device.iap.internal.util.d;
import org.json.JSONException;
import org.json.JSONObject;

public final class UserDataResponse {
  private static final String REQUEST_ID = "REQUEST_ID";
  
  private static final String REQUEST_STATUS = "REQUEST_STATUS";
  
  private static final String TO_STRING_FORMAT = "(%s, requestId: \"%s\", requestStatus: \"%s\", userData: \"%s\")";
  
  private static final String USER_DATA = "USER_DATA";
  
  private final RequestId requestId;
  
  private final RequestStatus requestStatus;
  
  private final UserData userData;
  
  public UserDataResponse(UserDataResponseBuilder paramUserDataResponseBuilder) {
    d.a(paramUserDataResponseBuilder.getRequestId(), "requestId");
    d.a(paramUserDataResponseBuilder.getRequestStatus(), "requestStatus");
    this.requestId = paramUserDataResponseBuilder.getRequestId();
    this.requestStatus = paramUserDataResponseBuilder.getRequestStatus();
    this.userData = paramUserDataResponseBuilder.getUserData();
  }
  
  public RequestId getRequestId() {
    return this.requestId;
  }
  
  public RequestStatus getRequestStatus() {
    return this.requestStatus;
  }
  
  public UserData getUserData() {
    return this.userData;
  }
  
  public JSONObject toJSON() throws JSONException {
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("REQUEST_ID", this.requestId);
    jSONObject.put("REQUEST_STATUS", this.requestStatus);
    if (this.userData != null) {
      JSONObject jSONObject1 = this.userData.toJSON();
      jSONObject.put("USER_DATA", jSONObject1);
      return jSONObject;
    } 
    String str = "";
    jSONObject.put("USER_DATA", str);
    return jSONObject;
  }
  
  public String toString() {
    String str1;
    String str3 = super.toString();
    RequestId requestId = this.requestId;
    if (this.requestStatus != null) {
      str1 = this.requestStatus.toString();
    } else {
      str1 = "null";
    } 
    if (this.userData != null) {
      String str = this.userData.toString();
      return String.format("(%s, requestId: \"%s\", requestStatus: \"%s\", userData: \"%s\")", new Object[] { str3, requestId, str1, str });
    } 
    String str2 = "null";
    return String.format("(%s, requestId: \"%s\", requestStatus: \"%s\", userData: \"%s\")", new Object[] { str3, requestId, str1, str2 });
  }
  
  public enum RequestStatus {
    FAILED, NOT_SUPPORTED, SUCCESSFUL;
    
    static {
      $VALUES = new RequestStatus[] { SUCCESSFUL, FAILED, NOT_SUPPORTED };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\model\UserDataResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */