package com.amazon.device.iap.model;

import com.amazon.device.iap.internal.model.ProductDataResponseBuilder;
import com.amazon.device.iap.internal.util.d;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class ProductDataResponse {
  private static final String PRODUCT_DATA = "productData";
  
  private static final String REQUEST_ID = "requestId";
  
  private static final String REQUEST_STATUS = "requestStatus";
  
  private static final String TO_STRING_FORMAT = "(%s, requestId: \"%s\", unavailableSkus: %s, requestStatus: \"%s\", productData: %s)";
  
  private static final String UNAVAILABLE_SKUS = "UNAVAILABLE_SKUS";
  
  private final Map<String, Product> productData;
  
  private final RequestId requestId;
  
  private final RequestStatus requestStatus;
  
  private final Set<String> unavailableSkus;
  
  public ProductDataResponse(ProductDataResponseBuilder paramProductDataResponseBuilder) {
    d.a(paramProductDataResponseBuilder.getRequestId(), "requestId");
    d.a(paramProductDataResponseBuilder.getRequestStatus(), "requestStatus");
    if (paramProductDataResponseBuilder.getUnavailableSkus() == null)
      paramProductDataResponseBuilder.setUnavailableSkus(new HashSet()); 
    if (RequestStatus.SUCCESSFUL == paramProductDataResponseBuilder.getRequestStatus())
      d.a(paramProductDataResponseBuilder.getProductData(), "productData"); 
    this.requestId = paramProductDataResponseBuilder.getRequestId();
    this.requestStatus = paramProductDataResponseBuilder.getRequestStatus();
    this.unavailableSkus = paramProductDataResponseBuilder.getUnavailableSkus();
    this.productData = paramProductDataResponseBuilder.getProductData();
  }
  
  public Map<String, Product> getProductData() {
    return this.productData;
  }
  
  public RequestId getRequestId() {
    return this.requestId;
  }
  
  public RequestStatus getRequestStatus() {
    return this.requestStatus;
  }
  
  public Set<String> getUnavailableSkus() {
    return this.unavailableSkus;
  }
  
  public JSONObject toJSON() throws JSONException {
    JSONObject jSONObject1 = new JSONObject();
    jSONObject1.put("requestId", this.requestId);
    jSONObject1.put("UNAVAILABLE_SKUS", this.unavailableSkus);
    jSONObject1.put("requestStatus", this.requestStatus);
    JSONObject jSONObject2 = new JSONObject();
    if (this.productData != null)
      for (String str : this.productData.keySet())
        jSONObject2.put(str, ((Product)this.productData.get(str)).toJSON());  
    jSONObject1.put("productData", jSONObject2);
    return jSONObject1;
  }
  
  public String toString() {
    String str1;
    String str2;
    String str4 = super.toString();
    RequestId requestId = this.requestId;
    if (this.unavailableSkus != null) {
      str1 = this.unavailableSkus.toString();
    } else {
      str1 = "null";
    } 
    if (this.requestStatus != null) {
      str2 = this.requestStatus.toString();
    } else {
      str2 = "null";
    } 
    if (this.productData != null) {
      String str = this.productData.toString();
      return String.format("(%s, requestId: \"%s\", unavailableSkus: %s, requestStatus: \"%s\", productData: %s)", new Object[] { str4, requestId, str1, str2, str });
    } 
    String str3 = "null";
    return String.format("(%s, requestId: \"%s\", unavailableSkus: %s, requestStatus: \"%s\", productData: %s)", new Object[] { str4, requestId, str1, str2, str3 });
  }
  
  public enum RequestStatus {
    FAILED, NOT_SUPPORTED, SUCCESSFUL;
    
    static {
      $VALUES = new RequestStatus[] { SUCCESSFUL, FAILED, NOT_SUPPORTED };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\model\ProductDataResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */