package com.amazon.device.iap.model;

import com.amazon.device.iap.internal.model.ReceiptBuilder;
import com.amazon.device.iap.internal.util.d;
import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;

public final class Receipt {
  private static final String CANCEL_DATE = "endDate";
  
  private static final Date DATE_CANCELED = new Date(1L);
  
  private static final String PRODUCT_TYPE = "itemType";
  
  private static final String PURCHASE_DATE = "purchaseDate";
  
  private static final String RECEIPT_ID = "receiptId";
  
  private static final String SKU = "sku";
  
  private final Date cancelDate;
  
  private final ProductType productType;
  
  private final Date purchaseDate;
  
  private final String receiptId;
  
  private final String sku;
  
  public Receipt(ReceiptBuilder paramReceiptBuilder) {
    d.a(paramReceiptBuilder.getSku(), "sku");
    d.a(paramReceiptBuilder.getProductType(), "productType");
    if (ProductType.SUBSCRIPTION == paramReceiptBuilder.getProductType())
      d.a(paramReceiptBuilder.getPurchaseDate(), "purchaseDate"); 
    this.receiptId = paramReceiptBuilder.getReceiptId();
    this.sku = paramReceiptBuilder.getSku();
    this.productType = paramReceiptBuilder.getProductType();
    this.purchaseDate = paramReceiptBuilder.getPurchaseDate();
    this.cancelDate = paramReceiptBuilder.getCancelDate();
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject == null)
        return false; 
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      if (this.cancelDate == null) {
        if (((Receipt)paramObject).cancelDate != null)
          return false; 
      } else if (!this.cancelDate.equals(((Receipt)paramObject).cancelDate)) {
        return false;
      } 
      if (this.productType != ((Receipt)paramObject).productType)
        return false; 
      if (this.purchaseDate == null) {
        if (((Receipt)paramObject).purchaseDate != null)
          return false; 
      } else if (!this.purchaseDate.equals(((Receipt)paramObject).purchaseDate)) {
        return false;
      } 
      if (this.receiptId == null) {
        if (((Receipt)paramObject).receiptId != null)
          return false; 
      } else if (!this.receiptId.equals(((Receipt)paramObject).receiptId)) {
        return false;
      } 
      if (this.sku == null)
        return !(((Receipt)paramObject).sku != null); 
      if (!this.sku.equals(((Receipt)paramObject).sku))
        return false; 
    } 
    return true;
  }
  
  public Date getCancelDate() {
    return this.cancelDate;
  }
  
  public ProductType getProductType() {
    return this.productType;
  }
  
  public Date getPurchaseDate() {
    return this.purchaseDate;
  }
  
  public String getReceiptId() {
    return this.receiptId;
  }
  
  public String getSku() {
    return this.sku;
  }
  
  public int hashCode() {
    int i;
    int j;
    int k;
    int m;
    int n = 0;
    if (this.cancelDate == null) {
      i = 0;
    } else {
      i = this.cancelDate.hashCode();
    } 
    if (this.productType == null) {
      j = 0;
    } else {
      j = this.productType.hashCode();
    } 
    if (this.purchaseDate == null) {
      k = 0;
    } else {
      k = this.purchaseDate.hashCode();
    } 
    if (this.receiptId == null) {
      m = 0;
    } else {
      m = this.receiptId.hashCode();
    } 
    if (this.sku != null)
      n = this.sku.hashCode(); 
    return (m + (k + (j + (i + 31) * 31) * 31) * 31) * 31 + n;
  }
  
  public boolean isCanceled() {
    return (this.cancelDate != null);
  }
  
  public JSONObject toJSON() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("receiptId", this.receiptId);
      jSONObject.put("sku", this.sku);
      jSONObject.put("itemType", this.productType);
      jSONObject.put("purchaseDate", this.purchaseDate);
      jSONObject.put("endDate", this.cancelDate);
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
  
  public String toString() {
    try {
      return toJSON().toString(4);
    } catch (JSONException jSONException) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\model\Receipt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */