package com.amazon.device.iap.model;

import com.amazon.device.iap.internal.model.PurchaseUpdatesResponseBuilder;
import com.amazon.device.iap.internal.util.d;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class PurchaseUpdatesResponse {
  private static final String HAS_MORE = "HAS_MORE";
  
  private static final String RECEIPTS = "RECEIPTS";
  
  private static final String REQUEST_ID = "REQUEST_ID";
  
  private static final String REQUEST_STATUS = "REQUEST_STATUS";
  
  private static final String TO_STRING_FORMAT = "(%s, requestId: \"%s\", requestStatus: \"%s\", userData: \"%s\", receipts: %s, hasMore: \"%b\")";
  
  private static final String USER_DATA = "USER_DATA";
  
  private final boolean hasMore;
  
  private final List<Receipt> receipts;
  
  private final RequestId requestId;
  
  private final RequestStatus requestStatus;
  
  private final UserData userData;
  
  public PurchaseUpdatesResponse(PurchaseUpdatesResponseBuilder paramPurchaseUpdatesResponseBuilder) {
    List<Receipt> list;
    d.a(paramPurchaseUpdatesResponseBuilder.getRequestId(), "requestId");
    d.a(paramPurchaseUpdatesResponseBuilder.getRequestStatus(), "requestStatus");
    if (RequestStatus.SUCCESSFUL == paramPurchaseUpdatesResponseBuilder.getRequestStatus()) {
      d.a(paramPurchaseUpdatesResponseBuilder.getUserData(), "userData");
      d.a(paramPurchaseUpdatesResponseBuilder.getReceipts(), "receipts");
    } 
    this.requestId = paramPurchaseUpdatesResponseBuilder.getRequestId();
    this.requestStatus = paramPurchaseUpdatesResponseBuilder.getRequestStatus();
    this.userData = paramPurchaseUpdatesResponseBuilder.getUserData();
    if (paramPurchaseUpdatesResponseBuilder.getReceipts() == null) {
      list = new ArrayList();
    } else {
      list = paramPurchaseUpdatesResponseBuilder.getReceipts();
    } 
    this.receipts = list;
    this.hasMore = paramPurchaseUpdatesResponseBuilder.hasMore();
  }
  
  public List<Receipt> getReceipts() {
    return this.receipts;
  }
  
  public RequestId getRequestId() {
    return this.requestId;
  }
  
  public RequestStatus getRequestStatus() {
    return this.requestStatus;
  }
  
  public UserData getUserData() {
    return this.userData;
  }
  
  public boolean hasMore() {
    return this.hasMore;
  }
  
  public JSONObject toJSON() throws JSONException {
    String str;
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("REQUEST_ID", this.requestId);
    jSONObject.put("REQUEST_STATUS", this.requestStatus);
    if (this.userData != null) {
      JSONObject jSONObject1 = this.userData.toJSON();
    } else {
      str = "";
    } 
    jSONObject.put("USER_DATA", str);
    JSONArray jSONArray = new JSONArray();
    if (this.receipts != null) {
      Iterator<Receipt> iterator = this.receipts.iterator();
      while (iterator.hasNext())
        jSONArray.put(((Receipt)iterator.next()).toJSON()); 
    } 
    jSONObject.put("RECEIPTS", jSONArray);
    jSONObject.put("HAS_MORE", this.hasMore);
    return jSONObject;
  }
  
  public String toString() {
    String str2 = super.toString();
    RequestId requestId = this.requestId;
    RequestStatus requestStatus = this.requestStatus;
    UserData userData = this.userData;
    if (this.receipts != null) {
      String str = Arrays.toString(this.receipts.toArray());
      return String.format("(%s, requestId: \"%s\", requestStatus: \"%s\", userData: \"%s\", receipts: %s, hasMore: \"%b\")", new Object[] { str2, requestId, requestStatus, userData, str, Boolean.valueOf(this.hasMore) });
    } 
    String str1 = "null";
    return String.format("(%s, requestId: \"%s\", requestStatus: \"%s\", userData: \"%s\", receipts: %s, hasMore: \"%b\")", new Object[] { str2, requestId, requestStatus, userData, str1, Boolean.valueOf(this.hasMore) });
  }
  
  public enum RequestStatus {
    FAILED, NOT_SUPPORTED, SUCCESSFUL;
    
    static {
      $VALUES = new RequestStatus[] { SUCCESSFUL, FAILED, NOT_SUPPORTED };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\model\PurchaseUpdatesResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */