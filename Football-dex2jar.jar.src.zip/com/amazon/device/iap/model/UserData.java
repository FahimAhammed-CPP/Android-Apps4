package com.amazon.device.iap.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import org.json.JSONException;
import org.json.JSONObject;

public final class UserData implements Parcelable {
  public static final Parcelable.Creator<UserData> CREATOR = new Parcelable.Creator<UserData>() {
      public UserData createFromParcel(Parcel param1Parcel) {
        return new UserData(param1Parcel);
      }
      
      public UserData[] newArray(int param1Int) {
        return new UserData[param1Int];
      }
    };
  
  private static final String MARKETPLACE = "marketplace";
  
  private static final String USER_ID = "userId";
  
  private final String marketplace;
  
  private final String userId;
  
  private UserData(Parcel paramParcel) {
    this.userId = paramParcel.readString();
    this.marketplace = paramParcel.readString();
  }
  
  public UserData(UserDataBuilder paramUserDataBuilder) {
    this.userId = paramUserDataBuilder.getUserId();
    this.marketplace = paramUserDataBuilder.getMarketplace();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String getMarketplace() {
    return this.marketplace;
  }
  
  public String getUserId() {
    return this.userId;
  }
  
  public JSONObject toJSON() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("userId", this.userId);
      jSONObject.put("marketplace", this.marketplace);
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
  
  public String toString() {
    try {
      return toJSON().toString(4);
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeStringArray(new String[] { this.userId, this.marketplace });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\model\UserData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */