package com.amazon.device.iap;

import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.UserDataResponse;

public interface PurchasingListener {
  void onProductDataResponse(ProductDataResponse paramProductDataResponse);
  
  void onPurchaseResponse(PurchaseResponse paramPurchaseResponse);
  
  void onPurchaseUpdatesResponse(PurchaseUpdatesResponse paramPurchaseUpdatesResponse);
  
  void onUserDataResponse(UserDataResponse paramUserDataResponse);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\device\iap\PurchasingListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */