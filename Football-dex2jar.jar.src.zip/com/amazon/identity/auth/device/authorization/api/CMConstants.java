package com.amazon.identity.auth.device.authorization.api;

public final class CMConstants {
  private static final String CONSTANT_PREFIX = "com.amazon.identity.auth.device.authorization";
  
  public enum BUNDLE_KEY {
    APPS_WITH_PERMISSION_LIST,
    APPS_WITH_SCOPE_LIST,
    APP_ID,
    APP_VARIANT_ID,
    HAS_PERMISSION,
    HAS_SCOPE,
    PACKAGE_NAME("com.amazon.identity.auth.device.authorization.packageName"),
    PACKAGE_NAMES("com.amazon.identity.auth.device.authorization.packageName"),
    PERMISSION_LIST("com.amazon.identity.auth.device.authorization.packageName"),
    SCOPE_LIST("com.amazon.identity.auth.device.authorization.packageName"),
    USER_ID("com.amazon.identity.auth.device.authorization.packageName");
    
    public final String val;
    
    static {
      APPS_WITH_SCOPE_LIST = new BUNDLE_KEY("APPS_WITH_SCOPE_LIST", 3, "com.amazon.identity.auth.device.authorization.appsWithScopeList");
      SCOPE_LIST = new BUNDLE_KEY("SCOPE_LIST", 4, "com.amazon.identity.auth.device.authorization.scopeList");
      HAS_SCOPE = new BUNDLE_KEY("HAS_SCOPE", 5, "com.amazon.identity.auth.device.authorization.hasScope");
      PERMISSION_LIST = new BUNDLE_KEY("PERMISSION_LIST", 6, "com.amazon.identity.auth.device.authorization.permissionList");
      HAS_PERMISSION = new BUNDLE_KEY("HAS_PERMISSION", 7, "com.amazon.identity.auth.device.authorization.hasPermission");
      APPS_WITH_PERMISSION_LIST = new BUNDLE_KEY("APPS_WITH_PERMISSION_LIST", 8, "com.amazon.identity.auth.device.authorization.appsWithPermissionList");
      APP_VARIANT_ID = new BUNDLE_KEY("APP_VARIANT_ID", 9, "com.amazon.identity.auth.device.authorization.appVariantid");
      PACKAGE_NAMES = new BUNDLE_KEY("PACKAGE_NAMES", 10, "com.amazon.identity.auth.device.authorization.packageNames");
      $VALUES = new BUNDLE_KEY[] { 
          PACKAGE_NAME, APP_ID, USER_ID, APPS_WITH_SCOPE_LIST, SCOPE_LIST, HAS_SCOPE, PERMISSION_LIST, HAS_PERMISSION, APPS_WITH_PERMISSION_LIST, APP_VARIANT_ID, 
          PACKAGE_NAMES };
    }
    
    BUNDLE_KEY(String param1String1) {
      this.val = param1String1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\identity\auth\device\authorization\api\CMConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */