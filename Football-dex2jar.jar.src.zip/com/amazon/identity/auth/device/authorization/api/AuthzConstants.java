package com.amazon.identity.auth.device.authorization.api;

public final class AuthzConstants {
  public static final int CAUSE_FAILED_AUTHENTICATION = 0;
  
  public static final int CAUSE_REJECTED_SCOPES = 1;
  
  private static final String CONSTANT_PREFIX = "com.amazon.identity.auth.device.authorization";
  
  public enum BUNDLE_KEY {
    APP_ID,
    AUTHORIZATION_CODE,
    AUTHORIZE,
    BROWSER_AUTHORIZATION,
    CAUSE_ID,
    CLIENT_ID,
    DEVICE_ID,
    DIRECTED_ID,
    FUTURE,
    ON_CANCEL_DESCRIPTION,
    ON_CANCEL_TYPE,
    PROFILE,
    REJECTED_SCOPE_LIST,
    TOKEN("com.amazon.identity.auth.device.authorization.token");
    
    public final String val;
    
    static {
      DEVICE_ID = new BUNDLE_KEY("DEVICE_ID", 3, "com.amazon.identity.auth.device.authorization.deviceId");
      APP_ID = new BUNDLE_KEY("APP_ID", 4, "com.amazon.identity.auth.device.authorization.appId");
      CAUSE_ID = new BUNDLE_KEY("CAUSE_ID", 5, "com.amazon.identity.auth.device.authorization.causeId");
      REJECTED_SCOPE_LIST = new BUNDLE_KEY("REJECTED_SCOPE_LIST", 6, "com.amazon.identity.auth.device.authorization.ungrantedScopes");
      AUTHORIZE = new BUNDLE_KEY("AUTHORIZE", 7, "com.amazon.identity.auth.device.authorization.authorize");
      CLIENT_ID = new BUNDLE_KEY("CLIENT_ID", 8, "com.amazon.identity.auth.device.authorization.clietId");
      ON_CANCEL_TYPE = new BUNDLE_KEY("ON_CANCEL_TYPE", 9, "com.amazon.identity.auth.device.authorization.onCancelType");
      ON_CANCEL_DESCRIPTION = new BUNDLE_KEY("ON_CANCEL_DESCRIPTION", 10, "com.amazon.identity.auth.device.authorization.onCancelDescription");
      BROWSER_AUTHORIZATION = new BUNDLE_KEY("BROWSER_AUTHORIZATION", 11, "com.amazon.identity.auth.device.authorization.useBrowserForAuthorization");
      PROFILE = new BUNDLE_KEY("PROFILE", 12, "com.amazon.identity.auth.device.authorization.profile");
      FUTURE = new BUNDLE_KEY("FUTURE", 13, "com.amazon.identity.auth.device.authorization.future.type");
      $VALUES = new BUNDLE_KEY[] { 
          TOKEN, AUTHORIZATION_CODE, DIRECTED_ID, DEVICE_ID, APP_ID, CAUSE_ID, REJECTED_SCOPE_LIST, AUTHORIZE, CLIENT_ID, ON_CANCEL_TYPE, 
          ON_CANCEL_DESCRIPTION, BROWSER_AUTHORIZATION, PROFILE, FUTURE };
    }
    
    BUNDLE_KEY(String param1String1) {
      this.val = param1String1;
    }
  }
  
  public enum FUTURE_TYPE {
    CANCEL("com.amazon.identity.auth.device.authorization.token"),
    ERROR("com.amazon.identity.auth.device.authorization.token"),
    SUCCESS;
    
    static {
      CANCEL = new FUTURE_TYPE("CANCEL", 2);
      $VALUES = new FUTURE_TYPE[] { SUCCESS, ERROR, CANCEL };
    }
  }
  
  public enum PROFILE_KEY {
    EMAIL,
    NAME("name"),
    POSTAL_CODE("name"),
    USER_ID("name");
    
    public final String val;
    
    static {
      POSTAL_CODE = new PROFILE_KEY("POSTAL_CODE", 3, "postal_code");
      $VALUES = new PROFILE_KEY[] { NAME, EMAIL, USER_ID, POSTAL_CODE };
    }
    
    PROFILE_KEY(String param1String1) {
      this.val = param1String1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\identity\auth\device\authorization\api\AuthzConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */