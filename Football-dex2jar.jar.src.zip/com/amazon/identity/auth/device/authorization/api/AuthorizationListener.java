package com.amazon.identity.auth.device.authorization.api;

import android.os.Bundle;
import com.amazon.identity.auth.device.shared.APIListener;

public interface AuthorizationListener extends APIListener {
  void onCancel(Bundle paramBundle);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\identity\auth\device\authorization\api\AuthorizationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */