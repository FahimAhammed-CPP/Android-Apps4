package com.amazon.identity.auth.device.authorization.api;

import android.content.Context;
import com.amazon.identity.auth.device.appid.ThirdPartyAppIdentifier;
import com.amazon.identity.auth.device.dataobject.AppInfo;

public final class AppIdentifierHelper {
  public static AppInfo getAppInfo(String paramString, Context paramContext) {
    return (new ThirdPartyAppIdentifier()).getAppInfo(paramString, paramContext);
  }
  
  public static boolean isAPIKeyValid(String paramString, Context paramContext) {
    return (new ThirdPartyAppIdentifier()).isAPIKeyValid(paramString, paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\identity\auth\device\authorization\api\AppIdentifierHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */