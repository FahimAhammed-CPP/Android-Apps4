package com.amazon.identity.auth.device.authorization.api;

import android.content.Context;
import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.appid.ThirdPartyAppIdentifier;
import com.amazon.identity.auth.device.authorization.AuthorizationHelper;
import com.amazon.identity.auth.device.authorization.ProfileHelper;
import com.amazon.identity.auth.device.authorization.TokenHelper;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.datastore.DatabaseHelper;
import com.amazon.identity.auth.device.shared.APIListener;
import com.amazon.identity.auth.device.thread.AuthzCallbackFuture;
import com.amazon.identity.auth.device.thread.ThreadUtils;
import com.amazon.identity.auth.device.utils.MAPLog;
import java.util.Arrays;
import java.util.concurrent.Future;

public class AmazonAuthorizationManager {
  private static final String LOG_TAG = AmazonAuthorizationManager.class.getName();
  
  private final String SDK_VERSION = "1.0.0";
  
  private final ThirdPartyAppIdentifier mAppIdentifier = new ThirdPartyAppIdentifier();
  
  private final String mClientId;
  
  private final Context mContext;
  
  public AmazonAuthorizationManager(Context paramContext, Bundle paramBundle) {
    MAPLog.pii(LOG_TAG, "AmazonAuthorizationManager:sdkVer=1.0.0 libVer=3.3.0", "options=" + paramBundle);
    if (paramContext == null)
      throw new IllegalArgumentException("context must not be null!"); 
    this.mContext = paramContext;
    if (paramBundle == null)
      MAPLog.i(LOG_TAG, "Options bundle is null"); 
    AppInfo appInfo = this.mAppIdentifier.getAppInfo(this.mContext.getPackageName(), this.mContext);
    if (appInfo == null || appInfo.getClientId() == null)
      throw new IllegalArgumentException("Invalid API Key"); 
    this.mClientId = appInfo.getClientId();
  }
  
  private Future<Bundle> authorizeWithBrowser(final String[] scopes, final AuthorizationListener listener) {
    MAPLog.i(LOG_TAG, this.mContext.getPackageName() + " calling authorize with Activity: scopes=" + Arrays.toString((Object[])scopes));
    ThreadUtils.THREAD_POOL.execute(new Runnable() {
          public void run() {
            if (!AmazonAuthorizationManager.this.isAPIKeyValid()) {
              listener.onError(new AuthError("APIKey is invalid", AuthError.ERROR_TYPE.ERROR_ACCESS_DENIED));
              return;
            } 
            AuthorizationHelper authorizationHelper = new AuthorizationHelper();
            try {
              authorizationHelper.authorize(AmazonAuthorizationManager.this.mContext, AmazonAuthorizationManager.this.mContext.getPackageName(), AmazonAuthorizationManager.this.mClientId, scopes, true, listener);
              return;
            } catch (AuthError authError) {
              listener.onError(authError);
              return;
            } 
          }
        });
    return null;
  }
  
  private boolean isAPIKeyValid() {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (this.mAppIdentifier.isAPIKeyValid(this.mContext)) {
      bool1 = bool2;
      if (this.mClientId != null)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public Future<Bundle> authorize(String[] paramArrayOfString, Bundle paramBundle, AuthorizationListener paramAuthorizationListener) {
    if (paramArrayOfString == null || paramArrayOfString.length == 0)
      throw new IllegalArgumentException("scopes must not be null or empty!"); 
    return authorizeWithBrowser(paramArrayOfString, paramAuthorizationListener);
  }
  
  public Future<Bundle> clearAuthorizationState(APIListener paramAPIListener) {
    final AuthzCallbackFuture callbackFuture = new AuthzCallbackFuture(paramAPIListener);
    if (!isAPIKeyValid())
      authzCallbackFuture.onError(new AuthError("APIKey is invalid", AuthError.ERROR_TYPE.ERROR_ACCESS_DENIED)); 
    MAPLog.i(LOG_TAG, this.mContext.getPackageName() + " calling clearAuthorizationState");
    ThreadUtils.THREAD_POOL.execute(new Runnable() {
          public void run() {
            Exception exception;
            try {
              DatabaseHelper.clearServiceAuthorizationState(AmazonAuthorizationManager.this.mContext);
              DatabaseHelper.clearAuthorizationState(AmazonAuthorizationManager.this.mContext);
              return;
            } catch (AuthError authError) {
              DatabaseHelper.clearAuthorizationState(AmazonAuthorizationManager.this.mContext);
              return;
            } finally {
              exception = null;
              DatabaseHelper.clearAuthorizationState(AmazonAuthorizationManager.this.mContext);
            } 
            throw exception;
          }
        });
    return (Future<Bundle>)authzCallbackFuture;
  }
  
  public String getAppId() throws AuthError {
    if (!isAPIKeyValid())
      throw new AuthError("APIKey is invalid", AuthError.ERROR_TYPE.ERROR_ACCESS_DENIED); 
    MAPLog.i(LOG_TAG, this.mContext.getPackageName() + " calling getAppId");
    AppInfo appInfo = (new ThirdPartyAppIdentifier()).getAppInfo(this.mContext.getPackageName(), this.mContext);
    return (appInfo == null) ? null : appInfo.getAppFamilyId();
  }
  
  public String getAppVariantId() throws AuthError {
    if (!isAPIKeyValid())
      throw new AuthError("APIKey is invalid", AuthError.ERROR_TYPE.ERROR_ACCESS_DENIED); 
    MAPLog.i(LOG_TAG, this.mContext.getPackageName() + " calling getAppId");
    AppInfo appInfo = (new ThirdPartyAppIdentifier()).getAppInfo(this.mContext.getPackageName(), this.mContext);
    return (appInfo == null) ? null : appInfo.getAppVariantId();
  }
  
  public Future<Bundle> getProfile(APIListener paramAPIListener) {
    MAPLog.i(LOG_TAG, this.mContext.getPackageName() + " calling getProfile");
    final AuthzCallbackFuture callbackFuture = new AuthzCallbackFuture(paramAPIListener);
    ThreadUtils.THREAD_POOL.execute(new Runnable() {
          public void run() {
            if (!AmazonAuthorizationManager.this.isAPIKeyValid()) {
              callbackFuture.onError(new AuthError("APIKey is invalid", AuthError.ERROR_TYPE.ERROR_ACCESS_DENIED));
              return;
            } 
            ProfileHelper.getProfile(AmazonAuthorizationManager.this.mContext, AmazonAuthorizationManager.this.mContext.getPackageName(), new APIListener() {
                  public void onError(AuthError param2AuthError) {
                    callbackFuture.onError(param2AuthError);
                  }
                  
                  public void onSuccess(Bundle param2Bundle) {
                    callbackFuture.onSuccess(param2Bundle);
                  }
                });
          }
        });
    return (Future<Bundle>)authzCallbackFuture;
  }
  
  public Future<Bundle> getToken(final String[] scopes, APIListener paramAPIListener) {
    if (scopes == null || scopes.length == 0)
      throw new IllegalArgumentException("scopes must not be null or empty!"); 
    MAPLog.i(LOG_TAG, this.mContext.getPackageName() + " calling getToken : scopes=" + Arrays.toString((Object[])scopes));
    final AuthzCallbackFuture callbackFuture = new AuthzCallbackFuture(paramAPIListener);
    ThreadUtils.THREAD_POOL.execute(new Runnable() {
          public void run() {
            try {
              if (!AmazonAuthorizationManager.this.isAPIKeyValid()) {
                callbackFuture.onError(new AuthError("APIKey is invalid", AuthError.ERROR_TYPE.ERROR_ACCESS_DENIED));
                return;
              } 
              TokenHelper.getToken(AmazonAuthorizationManager.this.mContext, AmazonAuthorizationManager.this.mContext.getPackageName(), AmazonAuthorizationManager.this.mClientId, scopes, new APIListener() {
                    public void onError(AuthError param2AuthError) {
                      callbackFuture.onError(param2AuthError);
                    }
                    
                    public void onSuccess(Bundle param2Bundle) {
                      callbackFuture.onSuccess(param2Bundle);
                    }
                  });
              return;
            } catch (AuthError authError) {
              callbackFuture.onError(authError);
              return;
            } 
          }
        });
    return (Future<Bundle>)authzCallbackFuture;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\identity\auth\device\authorization\api\AmazonAuthorizationManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */