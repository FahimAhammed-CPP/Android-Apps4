package com.amazon.identity.auth.device.appid;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.utils.MAPLog;
import com.amazon.identity.auth.device.utils.ThirdPartyResourceParser;

public abstract class AbstractAppIdentifier implements AppIdentifier {
  private static final String LOG_TAG = AbstractAppIdentifier.class.getName();
  
  private String getAPIKey(String paramString, Context paramContext) {
    MAPLog.i(LOG_TAG, "Finding API Key for " + paramString);
    assert paramString != null;
    return (new ThirdPartyResourceParser(paramContext, paramString)).getApiKey();
  }
  
  public abstract String getAppFamilyId(String paramString, Context paramContext);
  
  public AppInfo getAppInfo(String paramString, Context paramContext) {
    MAPLog.i(LOG_TAG, "getAppInfo : packageName=" + paramString);
    if (paramString == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return null;
    } 
    return APIKeyDecoder.decode(paramString, getAPIKey(paramString, paramContext), paramContext);
  }
  
  public String getAppLabel(String paramString, Context paramContext) {
    MAPLog.i(LOG_TAG, "getAppLabel : packageName=" + paramString);
    if (paramString == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return null;
    } 
    try {
      ApplicationInfo applicationInfo = paramContext.getPackageManager().getApplicationInfo(paramString, 0);
      return (String)paramContext.getPackageManager().getApplicationLabel(applicationInfo);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      MAPLog.e(LOG_TAG, "" + nameNotFoundException.getMessage(), (Throwable)nameNotFoundException);
      return null;
    } 
  }
  
  public abstract String getAppVariantId(String paramString, Context paramContext);
  
  public abstract String getPackageName(String paramString, Context paramContext);
  
  public abstract String getPackageNameByVariant(String paramString, Context paramContext);
  
  public abstract String[] getPackageNames(String paramString, Context paramContext);
  
  public boolean isAPIKeyValid(Context paramContext) {
    if (paramContext == null) {
      MAPLog.w(LOG_TAG, "context can't be null!");
      return false;
    } 
    return isAPIKeyValid(paramContext.getPackageName(), paramContext);
  }
  
  public boolean isAPIKeyValid(String paramString, Context paramContext) {
    MAPLog.i(LOG_TAG, "isAPIKeyValid : packageName=" + paramString);
    if (paramString == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return false;
    } 
    return (getAppInfo(paramString, paramContext) != null);
  }
  
  public boolean isAPIKeyValid(String paramString1, String paramString2, Context paramContext) {
    MAPLog.pii(LOG_TAG, "isAPIKeyValid : packageName=" + paramString1, "apiKey=" + paramString2);
    if (paramString1 == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return false;
    } 
    if (paramString2 == null) {
      MAPLog.w(LOG_TAG, "apiKey can't be null!");
      return false;
    } 
    return (APIKeyDecoder.decode(paramString1, paramString2, paramContext) != null);
  }
  
  static {
    boolean bool;
    if (!AbstractAppIdentifier.class.desiredAssertionStatus()) {
      bool = true;
    } else {
      bool = false;
    } 
    $assertionsDisabled = bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\identity\auth\device\appid\AbstractAppIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */