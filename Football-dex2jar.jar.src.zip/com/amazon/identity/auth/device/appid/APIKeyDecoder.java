package com.amazon.identity.auth.device.appid;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Base64;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.utils.MAPLog;
import com.amazon.identity.auth.device.utils.MAPUtils;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class APIKeyDecoder {
  private static final String AMAZON_PUBLIC_CERT = "-----BEGIN CERTIFICATE-----\nMIIEiTCCA3GgAwIBAgIJANVIFteXvjkPMA0GCSqGSIb3DQEBBQUAMIGJMQswCQYD\nVQQGEwJVUzEQMA4GA1UEBxMHU2VhdHRsZTETMBEGA1UEChMKQW1hem9uLmNvbTEZ\nMBcGA1UECxMQSWRlbnRpdHkgYW5kIFRheDETMBEGA1UEAxMKQW1hem9uLmNvbTEj\nMCEGCSqGSIb3DQEJARYUYXV0aC10ZWFtQGFtYXpvbi5jb20wHhcNMTIwODE0MDY1\nMDM5WhcNNzYwNjE0MDAyMjIzWjCBiTELMAkGA1UEBhMCVVMxEDAOBgNVBAcTB1Nl\nYXR0bGUxEzARBgNVBAoTCkFtYXpvbi5jb20xGTAXBgNVBAsTEElkZW50aXR5IGFu\nZCBUYXgxEzARBgNVBAMTCkFtYXpvbi5jb20xIzAhBgkqhkiG9w0BCQEWFGF1dGgt\ndGVhbUBhbWF6b24uY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA\nr4LlDpmlK1+mYGXqhvY3Kcd093eUwOQhQM0cb5Y9FjkXvJiCCoLSR9L8QYm2Jz06\nL/546eF/eMegvej93VGjz9JsW+guUIGkDuyCPwBn3u/PvTVKZD67Cep66qT3xnB3\nLfMFt5ln4T5LuoqJ95s8t9P0fULBU52kPR1hwdSo7G4KRVgyXtMmqjp3PK4EbrPB\ndvXCYxVeR31yDPS0BRENC3SGrzlVzrSWYFhxuxRcfyoMJYsOt/9T5QlO2KmJoTy2\nJQtqo7rlc6rORiJH7i2x+QW14bV3miJe/p4ZHWpOT5Z4hAqMBldc0FufaED1YH/Y\nnNCethI/GrXkgzCJRU5asQIDAQABo4HxMIHuMB0GA1UdDgQWBBQBvx8zbG7Sg/MZ\nOuZ31GeYDkhqozCBvgYDVR0jBIG2MIGzgBQBvx8zbG7Sg/MZOuZ31GeYDkhqo6GB\nj6SBjDCBiTELMAkGA1UEBhMCVVMxEDAOBgNVBAcTB1NlYXR0bGUxEzARBgNVBAoT\nCkFtYXpvbi5jb20xGTAXBgNVBAsTEElkZW50aXR5IGFuZCBUYXgxEzARBgNVBAMT\nCkFtYXpvbi5jb20xIzAhBgkqhkiG9w0BCQEWFGF1dGgtdGVhbUBhbWF6b24uY29t\nggkA1UgW15e+OQ8wDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOCAQEAjOV/\nVDxeAuBqdPgoBGz8AyDtMR4Qyxpe7P0M9umtr8S0PmvYOVs5YuMbEAPUYGsBnWVJ\nn7ErwCF20bkd4x0gHzkOpEzQJnjlO9vJzJcnZH4ZwhVs5jF4IkPN8N68jawPvh5/\nLyWJuwyNY5nGvN5nEecTdUQqT1aa7+Vv3Y1ZQlTEKQtdaoXUjLG86jq9xpanNj/G\nX4VYW+m7mY7Kv7mdfAE4zeECqOY5yAqSfP1M/a5fSfHLQiCTt3mrZfOuj8Hd3Pp5\nVn1e4/UxQQCwZcvAFljEYie6CXD3U1AgzIFiv4/r2M+rDo0T7eqIqCsyG6VCgRAb\ndry4esK8/BdPhyuiZg==\n-----END CERTIFICATE-----\n";
  
  private static Certificate CERTIFICATE;
  
  public static final String CERTIFICATE_TYPE = "X.509";
  
  private static final String CHAR_SET = "UTF-8";
  
  private static final String ENCRYPTION_SCHEME = "RSA-SHA256";
  
  private static final String EXPECTED_ISSUER = "Amazon";
  
  private static final String FAILED_TO_DECODE = "Failed to decode: ";
  
  private static final String HASH_ALGORITHM = "MD5";
  
  private static final char HASH_SEPARATOR = ':';
  
  private static final int HEADER_LOC = 0;
  
  private static final String KEY_ALGORITHM = "alg";
  
  private static final String KEY_API_KEY_VER = "ver";
  
  private static final String KEY_APP_FAMILY_ID = "appFamilyId";
  
  private static final String KEY_APP_ID = "appId";
  
  private static final String KEY_APP_VARIANT_ID = "appVariantId";
  
  private static final String KEY_CLIENT_ID = "clientId";
  
  private static final String KEY_ISSUER = "iss";
  
  private static final String KEY_PACKAGE_NAME = "pkg";
  
  private static final String KEY_PERMISSIONS = "perm";
  
  private static final String KEY_SCOPES = "scopes";
  
  private static final String KEY_SIGNATURE = "appsig";
  
  private static final String KEY_SPLITTER = "[.]";
  
  private static final String LOG_TAG = APIKeyDecoder.class.getName();
  
  private static final int PAYLOD_LOC = 1;
  
  private static final String VER_1 = "1";
  
  static {
    CERTIFICATE = null;
  }
  
  private APIKeyDecoder() throws Exception {
    throw new Exception("This class is not instantiable!");
  }
  
  public static AppInfo decode(String paramString1, String paramString2, Context paramContext) {
    return doDecode(paramString1, paramString2, true, paramContext);
  }
  
  private static byte[] decodeBase64ToBytes(String paramString) throws UnsupportedEncodingException {
    return Base64.decode(paramString.trim().getBytes("UTF-8"), 0);
  }
  
  private static String decodeBase64ToString(String paramString) throws UnsupportedEncodingException {
    return new String(decodeBase64ToBytes(paramString), "UTF-8");
  }
  
  static AppInfo doDecode(String paramString1, String paramString2, boolean paramBoolean, Context paramContext) {
    String[] arrayOfString;
    MAPLog.i(LOG_TAG, "Begin decoding API Key for packageName=" + paramString1);
    assert paramString1 != null && paramString2 != null;
    if (paramString2 != null && paramString1 != null) {
      try {
        arrayOfString = getKeyParts(paramString2);
        JSONObject jSONObject1 = new JSONObject(decodeBase64ToString(arrayOfString[0]));
        JSONObject jSONObject2 = new JSONObject(decodeBase64ToString(arrayOfString[1]));
        verifySignature(arrayOfString, jSONObject1.getString("alg"), paramContext);
        MAPLog.pii(LOG_TAG, "APIKey", "payload=" + jSONObject2);
        if (paramBoolean)
          verifyPayload(paramString1, jSONObject2, paramContext); 
        return extractAppInfo(jSONObject2);
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + unsupportedEncodingException.getMessage(), unsupportedEncodingException);
      } catch (JSONException jSONException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + jSONException.getMessage(), (Throwable)jSONException);
      } catch (InvalidKeyException invalidKeyException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + invalidKeyException.getMessage(), invalidKeyException);
      } catch (NoSuchProviderException noSuchProviderException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + noSuchProviderException.getMessage(), noSuchProviderException);
      } catch (SignatureException signatureException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + signatureException.getMessage(), signatureException);
      } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + noSuchAlgorithmException.getMessage(), noSuchAlgorithmException);
      } catch (CertificateException certificateException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + certificateException.getMessage(), certificateException);
      } catch (IOException iOException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + iOException.getMessage(), iOException);
      } catch (SecurityException securityException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + securityException.getMessage(), securityException);
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + nameNotFoundException.getMessage(), (Throwable)nameNotFoundException);
      } catch (IllegalArgumentException illegalArgumentException) {
        MAPLog.w(LOG_TAG, "Failed to decode: " + illegalArgumentException.getMessage(), illegalArgumentException);
      } 
      return null;
    } 
    MAPLog.pii(LOG_TAG, "ApiKey/PackageName is null. pkg=" + illegalArgumentException, "apiKey=" + arrayOfString + "");
    return null;
  }
  
  private static AppInfo extractAppInfo(JSONObject paramJSONObject) throws JSONException {
    String str1;
    String str2;
    if (paramJSONObject.getString("ver").equals("1")) {
      str1 = paramJSONObject.getString("appId");
      str2 = str1;
    } else {
      str1 = paramJSONObject.getString("appFamilyId");
      str2 = paramJSONObject.getString("appVariantId");
    } 
    String str3 = paramJSONObject.getString("pkg");
    String[] arrayOfString = getStringArray(paramJSONObject, "scopes");
    try {
      String str = paramJSONObject.getString("clientId");
    } catch (JSONException jSONException) {
      MAPLog.w(LOG_TAG, "APIKey does not contain a client id", (Throwable)jSONException);
      jSONException = null;
    } 
    return new AppInfo(str1, str2, str3, arrayOfString, getStringArray(paramJSONObject, "perm"), (String)jSONException, paramJSONObject);
  }
  
  private static Certificate getCertificate(Context paramContext) throws CertificateException, IOException {
    // Byte code:
    //   0: ldc com/amazon/identity/auth/device/appid/APIKeyDecoder
    //   2: monitorenter
    //   3: getstatic com/amazon/identity/auth/device/appid/APIKeyDecoder.CERTIFICATE : Ljava/security/cert/Certificate;
    //   6: ifnonnull -> 37
    //   9: new java/io/ByteArrayInputStream
    //   12: dup
    //   13: ldc '-----BEGIN CERTIFICATE-----\\nMIIEiTCCA3GgAwIBAgIJANVIFteXvjkPMA0GCSqGSIb3DQEBBQUAMIGJMQswCQYD\\nVQQGEwJVUzEQMA4GA1UEBxMHU2VhdHRsZTETMBEGA1UEChMKQW1hem9uLmNvbTEZ\\nMBcGA1UECxMQSWRlbnRpdHkgYW5kIFRheDETMBEGA1UEAxMKQW1hem9uLmNvbTEj\\nMCEGCSqGSIb3DQEJARYUYXV0aC10ZWFtQGFtYXpvbi5jb20wHhcNMTIwODE0MDY1\\nMDM5WhcNNzYwNjE0MDAyMjIzWjCBiTELMAkGA1UEBhMCVVMxEDAOBgNVBAcTB1Nl\\nYXR0bGUxEzARBgNVBAoTCkFtYXpvbi5jb20xGTAXBgNVBAsTEElkZW50aXR5IGFu\\nZCBUYXgxEzARBgNVBAMTCkFtYXpvbi5jb20xIzAhBgkqhkiG9w0BCQEWFGF1dGgt\\ndGVhbUBhbWF6b24uY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA\\nr4LlDpmlK1+mYGXqhvY3Kcd093eUwOQhQM0cb5Y9FjkXvJiCCoLSR9L8QYm2Jz06\\nL/546eF/eMegvej93VGjz9JsW+guUIGkDuyCPwBn3u/PvTVKZD67Cep66qT3xnB3\\nLfMFt5ln4T5LuoqJ95s8t9P0fULBU52kPR1hwdSo7G4KRVgyXtMmqjp3PK4EbrPB\\ndvXCYxVeR31yDPS0BRENC3SGrzlVzrSWYFhxuxRcfyoMJYsOt/9T5QlO2KmJoTy2\\nJQtqo7rlc6rORiJH7i2x+QW14bV3miJe/p4ZHWpOT5Z4hAqMBldc0FufaED1YH/Y\\nnNCethI/GrXkgzCJRU5asQIDAQABo4HxMIHuMB0GA1UdDgQWBBQBvx8zbG7Sg/MZ\\nOuZ31GeYDkhqozCBvgYDVR0jBIG2MIGzgBQBvx8zbG7Sg/MZOuZ31GeYDkhqo6GB\\nj6SBjDCBiTELMAkGA1UEBhMCVVMxEDAOBgNVBAcTB1NlYXR0bGUxEzARBgNVBAoT\\nCkFtYXpvbi5jb20xGTAXBgNVBAsTEElkZW50aXR5IGFuZCBUYXgxEzARBgNVBAMT\\nCkFtYXpvbi5jb20xIzAhBgkqhkiG9w0BCQEWFGF1dGgtdGVhbUBhbWF6b24uY29t\\nggkA1UgW15e+OQ8wDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOCAQEAjOV/\\nVDxeAuBqdPgoBGz8AyDtMR4Qyxpe7P0M9umtr8S0PmvYOVs5YuMbEAPUYGsBnWVJ\\nn7ErwCF20bkd4x0gHzkOpEzQJnjlO9vJzJcnZH4ZwhVs5jF4IkPN8N68jawPvh5/\\nLyWJuwyNY5nGvN5nEecTdUQqT1aa7+Vv3Y1ZQlTEKQtdaoXUjLG86jq9xpanNj/G\\nX4VYW+m7mY7Kv7mdfAE4zeECqOY5yAqSfP1M/a5fSfHLQiCTt3mrZfOuj8Hd3Pp5\\nVn1e4/UxQQCwZcvAFljEYie6CXD3U1AgzIFiv4/r2M+rDo0T7eqIqCsyG6VCgRAb\\ndry4esK8/BdPhyuiZg==\\n-----END CERTIFICATE-----\\n'
    //   15: ldc 'UTF-8'
    //   17: invokevirtual getBytes : (Ljava/lang/String;)[B
    //   20: invokespecial <init> : ([B)V
    //   23: astore_0
    //   24: ldc 'X.509'
    //   26: aload_0
    //   27: invokestatic getCertificate : (Ljava/lang/String;Ljava/io/InputStream;)Ljava/security/cert/Certificate;
    //   30: putstatic com/amazon/identity/auth/device/appid/APIKeyDecoder.CERTIFICATE : Ljava/security/cert/Certificate;
    //   33: aload_0
    //   34: invokevirtual close : ()V
    //   37: getstatic com/amazon/identity/auth/device/appid/APIKeyDecoder.CERTIFICATE : Ljava/security/cert/Certificate;
    //   40: astore_0
    //   41: ldc com/amazon/identity/auth/device/appid/APIKeyDecoder
    //   43: monitorexit
    //   44: aload_0
    //   45: areturn
    //   46: astore_0
    //   47: ldc com/amazon/identity/auth/device/appid/APIKeyDecoder
    //   49: monitorexit
    //   50: aload_0
    //   51: athrow
    // Exception table:
    //   from	to	target	type
    //   3	37	46	finally
    //   37	41	46	finally
  }
  
  private static Certificate getCertificate(String paramString, InputStream paramInputStream) throws CertificateException {
    return CertificateFactory.getInstance(paramString).generateCertificate(paramInputStream);
  }
  
  private static byte[] getFingerprint(String paramString, byte[] paramArrayOfbyte) throws NoSuchAlgorithmException {
    assert paramArrayOfbyte != null;
    return MessageDigest.getInstance(paramString).digest(paramArrayOfbyte);
  }
  
  private static String[] getKeyParts(String paramString) {
    assert paramString != null;
    String[] arrayOfString = paramString.split("[.]");
    if (arrayOfString.length != 3)
      throw new IllegalArgumentException("Decoding fails: API Key must have 3 parts {header}.{payload}.{signature}"); 
    return arrayOfString;
  }
  
  public static String getSignatureFingerprint(String paramString, Signature paramSignature) throws IOException, CertificateException, NoSuchAlgorithmException {
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramSignature.toByteArray());
    Certificate certificate = getCertificate(paramString, byteArrayInputStream);
    byteArrayInputStream.close();
    return MAPUtils.toHexString(getFingerprint("MD5", certificate.getEncoded()));
  }
  
  private static String[] getStringArray(JSONObject paramJSONObject, String paramString) throws JSONException {
    String[] arrayOfString;
    try {
      JSONArray jSONArray = paramJSONObject.getJSONArray(paramString);
      arrayOfString = new String[jSONArray.length()];
      int i = 0;
      while (true) {
        String[] arrayOfString1 = arrayOfString;
        if (i < jSONArray.length()) {
          arrayOfString[i] = jSONArray.getString(i);
          i++;
          continue;
        } 
        break;
      } 
    } catch (JSONException jSONException) {
      MAPLog.i(LOG_TAG, arrayOfString + " has no mapping in json, returning null array");
      jSONException = null;
    } 
    return (String[])jSONException;
  }
  
  private static void verifyPayload(String paramString, JSONObject paramJSONObject, Context paramContext) throws SecurityException, JSONException, PackageManager.NameNotFoundException, CertificateException, NoSuchAlgorithmException, IOException {
    Context context;
    if (!paramJSONObject.getString("iss").equals("Amazon"))
      throw new SecurityException("Decoding fails: issuer (" + paramJSONObject.getString("iss") + ") is not = " + "Amazon"); 
    if (!paramString.equals(paramJSONObject.getString("pkg")))
      throw new SecurityException("Decoding fails: package names don't match! - " + paramString + " != " + paramJSONObject.getString("pkg")); 
    PackageManager packageManager = paramContext.getPackageManager();
    paramContext = null;
    if (packageManager != null) {
      PackageInfo packageInfo = packageManager.getPackageInfo(paramString, 64);
    } else {
      MAPLog.d(LOG_TAG, " pkgMgr is null ");
      context = paramContext;
    } 
    if (context != null) {
      Signature[] arrayOfSignature = ((PackageInfo)context).signatures;
      if (arrayOfSignature != null) {
        MAPLog.i(LOG_TAG, " num sigs = " + arrayOfSignature.length);
        String str = paramJSONObject.getString("appsig");
        if (str != null) {
          str = str.replace(":", "");
          MAPLog.pii(LOG_TAG, "Signature checking.", "appSignature = " + str);
          int j = arrayOfSignature.length;
          for (int i = 0; i < j; i++) {
            String str1 = getSignatureFingerprint("X.509", arrayOfSignature[i]);
            MAPLog.pii(LOG_TAG, "Fingerpirint checking", "fingerprint = " + str1);
            if (str.equalsIgnoreCase(str1))
              return; 
          } 
        } else {
          MAPLog.d(LOG_TAG, " appSignature is null");
        } 
        throw new SecurityException("Decoding fails: certificate fingerprint can't be verified!");
      } 
    } else {
      throw new SecurityException("Decoding fails: certificate fingerprint can't be verified!");
    } 
    MAPLog.d(LOG_TAG, " signatures is null");
    throw new SecurityException("Decoding fails: certificate fingerprint can't be verified!");
  }
  
  private static void verifySignature(String[] paramArrayOfString, String paramString, Context paramContext) throws InvalidKeyException, NoSuchProviderException, SignatureException, NoSuchAlgorithmException, CertificateException, IOException {
    if (!paramString.equalsIgnoreCase("RSA-SHA256"))
      throw new NoSuchAlgorithmException("Unsupported algorithm : " + paramString); 
    byte[] arrayOfByte = (paramArrayOfString[0].trim() + "." + paramArrayOfString[1].trim()).getBytes("UTF-8");
    if (!verifySignatureWithRsaSha256(decodeBase64ToBytes(paramArrayOfString[2]), arrayOfByte, getCertificate(paramContext)))
      throw new SecurityException("Decoding fails: signature mismatch!"); 
  }
  
  private static boolean verifySignatureWithRsaSha256(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, Certificate paramCertificate) throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException, SignatureException {
    Signature signature = Signature.getInstance("SHA256withRSA", "BC");
    signature.initVerify(paramCertificate);
    signature.update(paramArrayOfbyte2);
    return signature.verify(paramArrayOfbyte1);
  }
  
  static {
    boolean bool;
    if (!APIKeyDecoder.class.desiredAssertionStatus()) {
      bool = true;
    } else {
      bool = false;
    } 
    $assertionsDisabled = bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\identity\auth\device\appid\APIKeyDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */