package com.amazon.identity.auth.device.appid;

import android.content.Context;
import com.amazon.identity.auth.device.dataobject.AppInfo;

public interface AppIdentifier {
  String[] getAllowedScopes(String paramString, Context paramContext);
  
  String getAppFamilyId(String paramString, Context paramContext);
  
  AppInfo getAppInfo(String paramString, Context paramContext);
  
  String getAppLabel(String paramString, Context paramContext);
  
  String[] getAppPermissions(String paramString, Context paramContext);
  
  String getAppVariantId(String paramString, Context paramContext);
  
  String getPackageName(String paramString, Context paramContext);
  
  String getPackageNameByVariant(String paramString, Context paramContext);
  
  String[] getPackageNames(String paramString, Context paramContext);
  
  boolean isAPIKeyValid(Context paramContext);
  
  boolean isAPIKeyValid(String paramString, Context paramContext);
  
  boolean isAPIKeyValid(String paramString1, String paramString2, Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\identity\auth\device\appid\AppIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */