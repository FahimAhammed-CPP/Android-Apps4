package com.amazon.identity.auth.device.appid;

import android.content.Context;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.utils.MAPLog;

public final class ThirdPartyAppIdentifier extends AbstractAppIdentifier {
  private static final String LOG_TAG = ThirdPartyAppIdentifier.class.getName();
  
  public String[] getAllowedScopes(String paramString, Context paramContext) {
    MAPLog.i(LOG_TAG, "getAllowedScopes : packageName=" + paramString);
    if (paramString == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return null;
    } 
    AppInfo appInfo = getAppInfo(paramString, paramContext);
    return (appInfo != null) ? appInfo.getAllowedScopes() : null;
  }
  
  public String getAppFamilyId(String paramString, Context paramContext) {
    MAPLog.i(LOG_TAG, "getAppFamilyId : packageName=" + paramString);
    if (paramString == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return null;
    } 
    AppInfo appInfo = getAppInfo(paramString, paramContext);
    return (appInfo != null) ? appInfo.getAppFamilyId() : null;
  }
  
  public AppInfo getAppInfoByApiKey(String paramString1, String paramString2, Context paramContext) {
    MAPLog.i(LOG_TAG, "getAppInfo : packageName=" + paramString1);
    if (paramString1 == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return null;
    } 
    return APIKeyDecoder.doDecode(paramString1, paramString2, false, paramContext);
  }
  
  public String[] getAppPermissions(String paramString, Context paramContext) {
    MAPLog.i(LOG_TAG, "getAppPermissions : packageName=" + paramString);
    if (paramString == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return null;
    } 
    AppInfo appInfo = getAppInfo(paramString, paramContext);
    return (appInfo != null) ? appInfo.getGrantedPermissions() : null;
  }
  
  public String getAppVariantId(String paramString, Context paramContext) {
    MAPLog.i(LOG_TAG, "getAppVariantId : packageName=" + paramString);
    if (paramString == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return null;
    } 
    AppInfo appInfo = getAppInfo(paramString, paramContext);
    return (appInfo != null) ? appInfo.getAppVariantId() : null;
  }
  
  public String getPackageName(String paramString, Context paramContext) {
    return null;
  }
  
  public String getPackageNameByVariant(String paramString, Context paramContext) {
    return null;
  }
  
  public String[] getPackageNames(String paramString, Context paramContext) {
    return null;
  }
  
  public boolean isAPIKeyValidFormat(String paramString1, String paramString2, Context paramContext) {
    MAPLog.pii(LOG_TAG, "isAPIKeyValid : packageName=" + paramString1, "apiKey=" + paramString2);
    if (paramString1 == null) {
      MAPLog.w(LOG_TAG, "packageName can't be null!");
      return false;
    } 
    if (paramString2 == null) {
      MAPLog.w(LOG_TAG, "apiKey can't be null!");
      return false;
    } 
    return (APIKeyDecoder.doDecode(paramString1, paramString2, false, paramContext) != null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Football-dex2jar.jar!\com\amazon\identity\auth\device\appid\ThirdPartyAppIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */