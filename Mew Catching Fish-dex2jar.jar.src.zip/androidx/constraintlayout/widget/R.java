package androidx.constraintlayout.widget;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
  }
  
  public static final class attr {
    public static final int ConstraintRotate = 2130903040;
    
    public static final int SharedValue = 2130903041;
    
    public static final int SharedValueId = 2130903042;
    
    public static final int actionBarDivider = 2130903043;
    
    public static final int actionBarItemBackground = 2130903044;
    
    public static final int actionBarPopupTheme = 2130903045;
    
    public static final int actionBarSize = 2130903046;
    
    public static final int actionBarSplitStyle = 2130903047;
    
    public static final int actionBarStyle = 2130903048;
    
    public static final int actionBarTabBarStyle = 2130903049;
    
    public static final int actionBarTabStyle = 2130903050;
    
    public static final int actionBarTabTextStyle = 2130903051;
    
    public static final int actionBarTheme = 2130903052;
    
    public static final int actionBarWidgetTheme = 2130903053;
    
    public static final int actionButtonStyle = 2130903054;
    
    public static final int actionDropDownStyle = 2130903055;
    
    public static final int actionLayout = 2130903056;
    
    public static final int actionMenuTextAppearance = 2130903057;
    
    public static final int actionMenuTextColor = 2130903058;
    
    public static final int actionModeBackground = 2130903059;
    
    public static final int actionModeCloseButtonStyle = 2130903060;
    
    public static final int actionModeCloseDrawable = 2130903061;
    
    public static final int actionModeCopyDrawable = 2130903062;
    
    public static final int actionModeCutDrawable = 2130903063;
    
    public static final int actionModeFindDrawable = 2130903064;
    
    public static final int actionModePasteDrawable = 2130903065;
    
    public static final int actionModePopupWindowStyle = 2130903066;
    
    public static final int actionModeSelectAllDrawable = 2130903067;
    
    public static final int actionModeShareDrawable = 2130903068;
    
    public static final int actionModeSplitBackground = 2130903069;
    
    public static final int actionModeStyle = 2130903070;
    
    public static final int actionModeWebSearchDrawable = 2130903071;
    
    public static final int actionOverflowButtonStyle = 2130903072;
    
    public static final int actionOverflowMenuStyle = 2130903073;
    
    public static final int actionProviderClass = 2130903074;
    
    public static final int actionViewClass = 2130903075;
    
    public static final int activityChooserViewStyle = 2130903076;
    
    public static final int alertDialogButtonGroupStyle = 2130903119;
    
    public static final int alertDialogCenterButtons = 2130903120;
    
    public static final int alertDialogStyle = 2130903121;
    
    public static final int alertDialogTheme = 2130903122;
    
    public static final int allowStacking = 2130903123;
    
    public static final int alpha = 2130903124;
    
    public static final int alphabeticModifiers = 2130903125;
    
    public static final int altSrc = 2130903126;
    
    public static final int animateCircleAngleTo = 2130903127;
    
    public static final int animateRelativeTo = 2130903128;
    
    public static final int applyMotionScene = 2130903129;
    
    public static final int arcMode = 2130903130;
    
    public static final int arrowHeadLength = 2130903131;
    
    public static final int arrowShaftLength = 2130903132;
    
    public static final int attributeName = 2130903133;
    
    public static final int autoCompleteMode = 2130903134;
    
    public static final int autoCompleteTextViewStyle = 2130903135;
    
    public static final int autoSizeMaxTextSize = 2130903136;
    
    public static final int autoSizeMinTextSize = 2130903137;
    
    public static final int autoSizePresetSizes = 2130903138;
    
    public static final int autoSizeStepGranularity = 2130903139;
    
    public static final int autoSizeTextType = 2130903140;
    
    public static final int autoTransition = 2130903141;
    
    public static final int background = 2130903142;
    
    public static final int backgroundSplit = 2130903143;
    
    public static final int backgroundStacked = 2130903144;
    
    public static final int backgroundTint = 2130903145;
    
    public static final int backgroundTintMode = 2130903146;
    
    public static final int barLength = 2130903147;
    
    public static final int barrierAllowsGoneWidgets = 2130903148;
    
    public static final int barrierDirection = 2130903149;
    
    public static final int barrierMargin = 2130903150;
    
    public static final int blendSrc = 2130903151;
    
    public static final int borderRound = 2130903152;
    
    public static final int borderRoundPercent = 2130903153;
    
    public static final int borderlessButtonStyle = 2130903154;
    
    public static final int brightness = 2130903155;
    
    public static final int buttonBarButtonStyle = 2130903156;
    
    public static final int buttonBarNegativeButtonStyle = 2130903157;
    
    public static final int buttonBarNeutralButtonStyle = 2130903158;
    
    public static final int buttonBarPositiveButtonStyle = 2130903159;
    
    public static final int buttonBarStyle = 2130903160;
    
    public static final int buttonCompat = 2130903161;
    
    public static final int buttonGravity = 2130903162;
    
    public static final int buttonIconDimen = 2130903163;
    
    public static final int buttonPanelSideLayout = 2130903164;
    
    public static final int buttonStyle = 2130903166;
    
    public static final int buttonStyleSmall = 2130903167;
    
    public static final int buttonTint = 2130903168;
    
    public static final int buttonTintMode = 2130903169;
    
    public static final int carousel_backwardTransition = 2130903177;
    
    public static final int carousel_emptyViewsBehavior = 2130903178;
    
    public static final int carousel_firstView = 2130903179;
    
    public static final int carousel_forwardTransition = 2130903180;
    
    public static final int carousel_infinite = 2130903181;
    
    public static final int carousel_nextState = 2130903182;
    
    public static final int carousel_previousState = 2130903183;
    
    public static final int carousel_touchUpMode = 2130903184;
    
    public static final int carousel_touchUp_dampeningFactor = 2130903185;
    
    public static final int carousel_touchUp_velocityThreshold = 2130903186;
    
    public static final int chainUseRtl = 2130903187;
    
    public static final int checkboxStyle = 2130903188;
    
    public static final int checkedTextViewStyle = 2130903189;
    
    public static final int circleRadius = 2130903191;
    
    public static final int circularflow_angles = 2130903192;
    
    public static final int circularflow_defaultAngle = 2130903193;
    
    public static final int circularflow_defaultRadius = 2130903194;
    
    public static final int circularflow_radiusInDP = 2130903195;
    
    public static final int circularflow_viewCenter = 2130903196;
    
    public static final int clearsTag = 2130903197;
    
    public static final int clickAction = 2130903198;
    
    public static final int closeIcon = 2130903199;
    
    public static final int closeItemLayout = 2130903200;
    
    public static final int collapseContentDescription = 2130903201;
    
    public static final int collapseIcon = 2130903202;
    
    public static final int color = 2130903203;
    
    public static final int colorAccent = 2130903204;
    
    public static final int colorBackgroundFloating = 2130903205;
    
    public static final int colorButtonNormal = 2130903206;
    
    public static final int colorControlActivated = 2130903207;
    
    public static final int colorControlHighlight = 2130903208;
    
    public static final int colorControlNormal = 2130903209;
    
    public static final int colorError = 2130903210;
    
    public static final int colorPrimary = 2130903211;
    
    public static final int colorPrimaryDark = 2130903212;
    
    public static final int colorSwitchThumbNormal = 2130903214;
    
    public static final int commitIcon = 2130903227;
    
    public static final int constraintSet = 2130903228;
    
    public static final int constraintSetEnd = 2130903229;
    
    public static final int constraintSetStart = 2130903230;
    
    public static final int constraint_referenced_ids = 2130903231;
    
    public static final int constraint_referenced_tags = 2130903232;
    
    public static final int constraints = 2130903233;
    
    public static final int content = 2130903234;
    
    public static final int contentDescription = 2130903235;
    
    public static final int contentInsetEnd = 2130903236;
    
    public static final int contentInsetEndWithActions = 2130903237;
    
    public static final int contentInsetLeft = 2130903238;
    
    public static final int contentInsetRight = 2130903239;
    
    public static final int contentInsetStart = 2130903240;
    
    public static final int contentInsetStartWithNavigation = 2130903241;
    
    public static final int contrast = 2130903247;
    
    public static final int controlBackground = 2130903248;
    
    public static final int crossfade = 2130903251;
    
    public static final int currentState = 2130903252;
    
    public static final int curveFit = 2130903253;
    
    public static final int customBoolean = 2130903254;
    
    public static final int customColorDrawableValue = 2130903255;
    
    public static final int customColorValue = 2130903256;
    
    public static final int customDimension = 2130903257;
    
    public static final int customFloatValue = 2130903258;
    
    public static final int customIntegerValue = 2130903259;
    
    public static final int customNavigationLayout = 2130903260;
    
    public static final int customPixelDimension = 2130903261;
    
    public static final int customReference = 2130903262;
    
    public static final int customStringValue = 2130903263;
    
    public static final int defaultDuration = 2130903264;
    
    public static final int defaultQueryHint = 2130903265;
    
    public static final int defaultState = 2130903266;
    
    public static final int deltaPolarAngle = 2130903267;
    
    public static final int deltaPolarRadius = 2130903268;
    
    public static final int deriveConstraintsFrom = 2130903269;
    
    public static final int dialogCornerRadius = 2130903270;
    
    public static final int dialogPreferredPadding = 2130903271;
    
    public static final int dialogTheme = 2130903272;
    
    public static final int displayOptions = 2130903273;
    
    public static final int divider = 2130903274;
    
    public static final int dividerHorizontal = 2130903275;
    
    public static final int dividerPadding = 2130903276;
    
    public static final int dividerVertical = 2130903277;
    
    public static final int dragDirection = 2130903278;
    
    public static final int dragScale = 2130903279;
    
    public static final int dragThreshold = 2130903280;
    
    public static final int drawPath = 2130903281;
    
    public static final int drawableBottomCompat = 2130903282;
    
    public static final int drawableEndCompat = 2130903283;
    
    public static final int drawableLeftCompat = 2130903284;
    
    public static final int drawableRightCompat = 2130903285;
    
    public static final int drawableSize = 2130903286;
    
    public static final int drawableStartCompat = 2130903287;
    
    public static final int drawableTint = 2130903288;
    
    public static final int drawableTintMode = 2130903289;
    
    public static final int drawableTopCompat = 2130903290;
    
    public static final int drawerArrowStyle = 2130903291;
    
    public static final int dropDownListViewStyle = 2130903292;
    
    public static final int dropdownListPreferredItemHeight = 2130903293;
    
    public static final int duration = 2130903294;
    
    public static final int editTextBackground = 2130903295;
    
    public static final int editTextColor = 2130903296;
    
    public static final int editTextStyle = 2130903297;
    
    public static final int elevation = 2130903298;
    
    public static final int expandActivityOverflowButtonDrawable = 2130903299;
    
    public static final int firstBaselineToTopHeight = 2130903305;
    
    public static final int flow_firstHorizontalBias = 2130903306;
    
    public static final int flow_firstHorizontalStyle = 2130903307;
    
    public static final int flow_firstVerticalBias = 2130903308;
    
    public static final int flow_firstVerticalStyle = 2130903309;
    
    public static final int flow_horizontalAlign = 2130903310;
    
    public static final int flow_horizontalBias = 2130903311;
    
    public static final int flow_horizontalGap = 2130903312;
    
    public static final int flow_horizontalStyle = 2130903313;
    
    public static final int flow_lastHorizontalBias = 2130903314;
    
    public static final int flow_lastHorizontalStyle = 2130903315;
    
    public static final int flow_lastVerticalBias = 2130903316;
    
    public static final int flow_lastVerticalStyle = 2130903317;
    
    public static final int flow_maxElementsWrap = 2130903318;
    
    public static final int flow_padding = 2130903319;
    
    public static final int flow_verticalAlign = 2130903320;
    
    public static final int flow_verticalBias = 2130903321;
    
    public static final int flow_verticalGap = 2130903322;
    
    public static final int flow_verticalStyle = 2130903323;
    
    public static final int flow_wrapMode = 2130903324;
    
    public static final int font = 2130903325;
    
    public static final int fontFamily = 2130903326;
    
    public static final int fontProviderAuthority = 2130903327;
    
    public static final int fontProviderCerts = 2130903328;
    
    public static final int fontProviderFetchStrategy = 2130903329;
    
    public static final int fontProviderFetchTimeout = 2130903330;
    
    public static final int fontProviderPackage = 2130903331;
    
    public static final int fontProviderQuery = 2130903332;
    
    public static final int fontStyle = 2130903334;
    
    public static final int fontVariationSettings = 2130903335;
    
    public static final int fontWeight = 2130903336;
    
    public static final int framePosition = 2130903337;
    
    public static final int gapBetweenBars = 2130903338;
    
    public static final int goIcon = 2130903339;
    
    public static final int height = 2130903340;
    
    public static final int hideOnContentScroll = 2130903341;
    
    public static final int homeAsUpIndicator = 2130903342;
    
    public static final int homeLayout = 2130903343;
    
    public static final int icon = 2130903346;
    
    public static final int iconTint = 2130903347;
    
    public static final int iconTintMode = 2130903348;
    
    public static final int iconifiedByDefault = 2130903349;
    
    public static final int ifTagNotSet = 2130903350;
    
    public static final int ifTagSet = 2130903351;
    
    public static final int imageButtonStyle = 2130903354;
    
    public static final int imagePanX = 2130903355;
    
    public static final int imagePanY = 2130903356;
    
    public static final int imageRotate = 2130903357;
    
    public static final int imageZoom = 2130903358;
    
    public static final int indeterminateProgressStyle = 2130903359;
    
    public static final int initialActivityCount = 2130903360;
    
    public static final int isLightTheme = 2130903361;
    
    public static final int itemPadding = 2130903362;
    
    public static final int keyPositionType = 2130903363;
    
    public static final int lastBaselineToBottomHeight = 2130903366;
    
    public static final int layout = 2130903367;
    
    public static final int layoutDescription = 2130903368;
    
    public static final int layoutDuringTransition = 2130903369;
    
    public static final int layout_constrainedHeight = 2130903374;
    
    public static final int layout_constrainedWidth = 2130903375;
    
    public static final int layout_constraintBaseline_creator = 2130903376;
    
    public static final int layout_constraintBaseline_toBaselineOf = 2130903377;
    
    public static final int layout_constraintBaseline_toBottomOf = 2130903378;
    
    public static final int layout_constraintBaseline_toTopOf = 2130903379;
    
    public static final int layout_constraintBottom_creator = 2130903380;
    
    public static final int layout_constraintBottom_toBottomOf = 2130903381;
    
    public static final int layout_constraintBottom_toTopOf = 2130903382;
    
    public static final int layout_constraintCircle = 2130903383;
    
    public static final int layout_constraintCircleAngle = 2130903384;
    
    public static final int layout_constraintCircleRadius = 2130903385;
    
    public static final int layout_constraintDimensionRatio = 2130903386;
    
    public static final int layout_constraintEnd_toEndOf = 2130903387;
    
    public static final int layout_constraintEnd_toStartOf = 2130903388;
    
    public static final int layout_constraintGuide_begin = 2130903389;
    
    public static final int layout_constraintGuide_end = 2130903390;
    
    public static final int layout_constraintGuide_percent = 2130903391;
    
    public static final int layout_constraintHeight = 2130903392;
    
    public static final int layout_constraintHeight_default = 2130903393;
    
    public static final int layout_constraintHeight_max = 2130903394;
    
    public static final int layout_constraintHeight_min = 2130903395;
    
    public static final int layout_constraintHeight_percent = 2130903396;
    
    public static final int layout_constraintHorizontal_bias = 2130903397;
    
    public static final int layout_constraintHorizontal_chainStyle = 2130903398;
    
    public static final int layout_constraintHorizontal_weight = 2130903399;
    
    public static final int layout_constraintLeft_creator = 2130903400;
    
    public static final int layout_constraintLeft_toLeftOf = 2130903401;
    
    public static final int layout_constraintLeft_toRightOf = 2130903402;
    
    public static final int layout_constraintRight_creator = 2130903403;
    
    public static final int layout_constraintRight_toLeftOf = 2130903404;
    
    public static final int layout_constraintRight_toRightOf = 2130903405;
    
    public static final int layout_constraintStart_toEndOf = 2130903406;
    
    public static final int layout_constraintStart_toStartOf = 2130903407;
    
    public static final int layout_constraintTag = 2130903408;
    
    public static final int layout_constraintTop_creator = 2130903409;
    
    public static final int layout_constraintTop_toBottomOf = 2130903410;
    
    public static final int layout_constraintTop_toTopOf = 2130903411;
    
    public static final int layout_constraintVertical_bias = 2130903412;
    
    public static final int layout_constraintVertical_chainStyle = 2130903413;
    
    public static final int layout_constraintVertical_weight = 2130903414;
    
    public static final int layout_constraintWidth = 2130903415;
    
    public static final int layout_constraintWidth_default = 2130903416;
    
    public static final int layout_constraintWidth_max = 2130903417;
    
    public static final int layout_constraintWidth_min = 2130903418;
    
    public static final int layout_constraintWidth_percent = 2130903419;
    
    public static final int layout_editor_absoluteX = 2130903421;
    
    public static final int layout_editor_absoluteY = 2130903422;
    
    public static final int layout_goneMarginBaseline = 2130903423;
    
    public static final int layout_goneMarginBottom = 2130903424;
    
    public static final int layout_goneMarginEnd = 2130903425;
    
    public static final int layout_goneMarginLeft = 2130903426;
    
    public static final int layout_goneMarginRight = 2130903427;
    
    public static final int layout_goneMarginStart = 2130903428;
    
    public static final int layout_goneMarginTop = 2130903429;
    
    public static final int layout_marginBaseline = 2130903432;
    
    public static final int layout_optimizationLevel = 2130903433;
    
    public static final int layout_wrapBehaviorInParent = 2130903434;
    
    public static final int limitBoundsTo = 2130903435;
    
    public static final int lineHeight = 2130903436;
    
    public static final int listChoiceBackgroundIndicator = 2130903437;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130903438;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130903439;
    
    public static final int listDividerAlertDialog = 2130903440;
    
    public static final int listItemLayout = 2130903441;
    
    public static final int listLayout = 2130903442;
    
    public static final int listMenuViewStyle = 2130903443;
    
    public static final int listPopupWindowStyle = 2130903444;
    
    public static final int listPreferredItemHeight = 2130903445;
    
    public static final int listPreferredItemHeightLarge = 2130903446;
    
    public static final int listPreferredItemHeightSmall = 2130903447;
    
    public static final int listPreferredItemPaddingEnd = 2130903448;
    
    public static final int listPreferredItemPaddingLeft = 2130903449;
    
    public static final int listPreferredItemPaddingRight = 2130903450;
    
    public static final int listPreferredItemPaddingStart = 2130903451;
    
    public static final int logo = 2130903452;
    
    public static final int logoDescription = 2130903453;
    
    public static final int maxAcceleration = 2130903454;
    
    public static final int maxButtonHeight = 2130903455;
    
    public static final int maxHeight = 2130903456;
    
    public static final int maxVelocity = 2130903457;
    
    public static final int maxWidth = 2130903458;
    
    public static final int measureWithLargestChild = 2130903465;
    
    public static final int menu = 2130903466;
    
    public static final int methodName = 2130903467;
    
    public static final int minHeight = 2130903468;
    
    public static final int minWidth = 2130903469;
    
    public static final int mock_diagonalsColor = 2130903470;
    
    public static final int mock_label = 2130903471;
    
    public static final int mock_labelBackgroundColor = 2130903472;
    
    public static final int mock_labelColor = 2130903473;
    
    public static final int mock_showDiagonals = 2130903474;
    
    public static final int mock_showLabel = 2130903475;
    
    public static final int motionDebug = 2130903476;
    
    public static final int motionEffect_alpha = 2130903477;
    
    public static final int motionEffect_end = 2130903478;
    
    public static final int motionEffect_move = 2130903479;
    
    public static final int motionEffect_start = 2130903480;
    
    public static final int motionEffect_strict = 2130903481;
    
    public static final int motionEffect_translationX = 2130903482;
    
    public static final int motionEffect_translationY = 2130903483;
    
    public static final int motionEffect_viewTransition = 2130903484;
    
    public static final int motionInterpolator = 2130903485;
    
    public static final int motionPathRotate = 2130903486;
    
    public static final int motionProgress = 2130903487;
    
    public static final int motionStagger = 2130903488;
    
    public static final int motionTarget = 2130903489;
    
    public static final int motion_postLayoutCollision = 2130903490;
    
    public static final int motion_triggerOnCollision = 2130903491;
    
    public static final int moveWhenScrollAtTop = 2130903492;
    
    public static final int multiChoiceItemLayout = 2130903493;
    
    public static final int navigationContentDescription = 2130903494;
    
    public static final int navigationIcon = 2130903495;
    
    public static final int navigationMode = 2130903496;
    
    public static final int nestedScrollFlags = 2130903497;
    
    public static final int numericModifiers = 2130903499;
    
    public static final int onCross = 2130903500;
    
    public static final int onHide = 2130903501;
    
    public static final int onNegativeCross = 2130903502;
    
    public static final int onPositiveCross = 2130903503;
    
    public static final int onShow = 2130903504;
    
    public static final int onStateTransition = 2130903505;
    
    public static final int onTouchUp = 2130903506;
    
    public static final int overlapAnchor = 2130903507;
    
    public static final int overlay = 2130903508;
    
    public static final int paddingBottomNoButtons = 2130903509;
    
    public static final int paddingEnd = 2130903510;
    
    public static final int paddingStart = 2130903511;
    
    public static final int paddingTopNoTitle = 2130903512;
    
    public static final int panelBackground = 2130903513;
    
    public static final int panelMenuListTheme = 2130903514;
    
    public static final int panelMenuListWidth = 2130903515;
    
    public static final int pathMotionArc = 2130903516;
    
    public static final int path_percent = 2130903517;
    
    public static final int percentHeight = 2130903518;
    
    public static final int percentWidth = 2130903519;
    
    public static final int percentX = 2130903520;
    
    public static final int percentY = 2130903521;
    
    public static final int perpendicularPath_percent = 2130903522;
    
    public static final int pivotAnchor = 2130903523;
    
    public static final int placeholder_emptyVisibility = 2130903524;
    
    public static final int polarRelativeTo = 2130903525;
    
    public static final int popupMenuStyle = 2130903526;
    
    public static final int popupTheme = 2130903527;
    
    public static final int popupWindowStyle = 2130903528;
    
    public static final int preserveIconSpacing = 2130903529;
    
    public static final int progressBarPadding = 2130903530;
    
    public static final int progressBarStyle = 2130903531;
    
    public static final int quantizeMotionInterpolator = 2130903532;
    
    public static final int quantizeMotionPhase = 2130903533;
    
    public static final int quantizeMotionSteps = 2130903534;
    
    public static final int queryBackground = 2130903535;
    
    public static final int queryHint = 2130903536;
    
    public static final int radioButtonStyle = 2130903538;
    
    public static final int ratingBarStyle = 2130903539;
    
    public static final int ratingBarStyleIndicator = 2130903540;
    
    public static final int ratingBarStyleSmall = 2130903541;
    
    public static final int reactiveGuide_animateChange = 2130903542;
    
    public static final int reactiveGuide_applyToAllConstraintSets = 2130903543;
    
    public static final int reactiveGuide_applyToConstraintSet = 2130903544;
    
    public static final int reactiveGuide_valueId = 2130903545;
    
    public static final int region_heightLessThan = 2130903547;
    
    public static final int region_heightMoreThan = 2130903548;
    
    public static final int region_widthLessThan = 2130903549;
    
    public static final int region_widthMoreThan = 2130903550;
    
    public static final int rotationCenterId = 2130903552;
    
    public static final int round = 2130903553;
    
    public static final int roundPercent = 2130903554;
    
    public static final int saturation = 2130903555;
    
    public static final int scaleFromTextSize = 2130903556;
    
    public static final int searchHintIcon = 2130903558;
    
    public static final int searchIcon = 2130903559;
    
    public static final int searchViewStyle = 2130903560;
    
    public static final int seekBarStyle = 2130903561;
    
    public static final int selectableItemBackground = 2130903562;
    
    public static final int selectableItemBackgroundBorderless = 2130903563;
    
    public static final int setsTag = 2130903564;
    
    public static final int showAsAction = 2130903566;
    
    public static final int showDividers = 2130903567;
    
    public static final int showPaths = 2130903568;
    
    public static final int showText = 2130903569;
    
    public static final int showTitle = 2130903570;
    
    public static final int singleChoiceItemLayout = 2130903571;
    
    public static final int sizePercent = 2130903572;
    
    public static final int spinBars = 2130903574;
    
    public static final int spinnerDropDownItemStyle = 2130903575;
    
    public static final int spinnerStyle = 2130903576;
    
    public static final int splitTrack = 2130903577;
    
    public static final int springBoundary = 2130903578;
    
    public static final int springDamping = 2130903579;
    
    public static final int springMass = 2130903580;
    
    public static final int springStiffness = 2130903581;
    
    public static final int springStopThreshold = 2130903582;
    
    public static final int srcCompat = 2130903583;
    
    public static final int staggered = 2130903585;
    
    public static final int state_above_anchor = 2130903586;
    
    public static final int subMenuArrow = 2130903588;
    
    public static final int submitBackground = 2130903589;
    
    public static final int subtitle = 2130903590;
    
    public static final int subtitleTextAppearance = 2130903591;
    
    public static final int subtitleTextColor = 2130903592;
    
    public static final int subtitleTextStyle = 2130903593;
    
    public static final int suggestionRowLayout = 2130903594;
    
    public static final int switchMinWidth = 2130903595;
    
    public static final int switchPadding = 2130903596;
    
    public static final int switchStyle = 2130903597;
    
    public static final int switchTextAppearance = 2130903598;
    
    public static final int targetId = 2130903599;
    
    public static final int telltales_tailColor = 2130903600;
    
    public static final int telltales_tailScale = 2130903601;
    
    public static final int telltales_velocityMode = 2130903602;
    
    public static final int textAllCaps = 2130903603;
    
    public static final int textAppearanceLargePopupMenu = 2130903604;
    
    public static final int textAppearanceListItem = 2130903605;
    
    public static final int textAppearanceListItemSecondary = 2130903606;
    
    public static final int textAppearanceListItemSmall = 2130903607;
    
    public static final int textAppearancePopupMenuHeader = 2130903608;
    
    public static final int textAppearanceSearchResultSubtitle = 2130903609;
    
    public static final int textAppearanceSearchResultTitle = 2130903610;
    
    public static final int textAppearanceSmallPopupMenu = 2130903611;
    
    public static final int textBackground = 2130903612;
    
    public static final int textBackgroundPanX = 2130903613;
    
    public static final int textBackgroundPanY = 2130903614;
    
    public static final int textBackgroundRotate = 2130903615;
    
    public static final int textBackgroundZoom = 2130903616;
    
    public static final int textColorAlertDialogListItem = 2130903617;
    
    public static final int textColorSearchUrl = 2130903618;
    
    public static final int textFillColor = 2130903619;
    
    public static final int textLocale = 2130903620;
    
    public static final int textOutlineColor = 2130903621;
    
    public static final int textOutlineThickness = 2130903622;
    
    public static final int textPanX = 2130903623;
    
    public static final int textPanY = 2130903624;
    
    public static final int textureBlurFactor = 2130903625;
    
    public static final int textureEffect = 2130903626;
    
    public static final int textureHeight = 2130903627;
    
    public static final int textureWidth = 2130903628;
    
    public static final int theme = 2130903629;
    
    public static final int thickness = 2130903630;
    
    public static final int thumbTextPadding = 2130903631;
    
    public static final int thumbTint = 2130903632;
    
    public static final int thumbTintMode = 2130903633;
    
    public static final int tickMark = 2130903634;
    
    public static final int tickMarkTint = 2130903635;
    
    public static final int tickMarkTintMode = 2130903636;
    
    public static final int tint = 2130903637;
    
    public static final int tintMode = 2130903638;
    
    public static final int title = 2130903639;
    
    public static final int titleMargin = 2130903640;
    
    public static final int titleMarginBottom = 2130903641;
    
    public static final int titleMarginEnd = 2130903642;
    
    public static final int titleMarginStart = 2130903643;
    
    public static final int titleMarginTop = 2130903644;
    
    public static final int titleMargins = 2130903645;
    
    public static final int titleTextAppearance = 2130903646;
    
    public static final int titleTextColor = 2130903647;
    
    public static final int titleTextStyle = 2130903648;
    
    public static final int toolbarNavigationButtonStyle = 2130903649;
    
    public static final int toolbarStyle = 2130903650;
    
    public static final int tooltipForegroundColor = 2130903651;
    
    public static final int tooltipFrameBackground = 2130903652;
    
    public static final int tooltipText = 2130903653;
    
    public static final int touchAnchorId = 2130903654;
    
    public static final int touchAnchorSide = 2130903655;
    
    public static final int touchRegionId = 2130903656;
    
    public static final int track = 2130903657;
    
    public static final int trackTint = 2130903658;
    
    public static final int trackTintMode = 2130903659;
    
    public static final int transformPivotTarget = 2130903660;
    
    public static final int transitionDisable = 2130903661;
    
    public static final int transitionEasing = 2130903662;
    
    public static final int transitionFlags = 2130903663;
    
    public static final int transitionPathRotate = 2130903664;
    
    public static final int triggerId = 2130903665;
    
    public static final int triggerReceiver = 2130903666;
    
    public static final int triggerSlack = 2130903667;
    
    public static final int ttcIndex = 2130903668;
    
    public static final int upDuration = 2130903669;
    
    public static final int viewInflaterClass = 2130903670;
    
    public static final int viewTransitionMode = 2130903671;
    
    public static final int viewTransitionOnCross = 2130903672;
    
    public static final int viewTransitionOnNegativeCross = 2130903673;
    
    public static final int viewTransitionOnPositiveCross = 2130903674;
    
    public static final int visibilityMode = 2130903675;
    
    public static final int voiceIcon = 2130903676;
    
    public static final int warmth = 2130903677;
    
    public static final int waveDecay = 2130903678;
    
    public static final int waveOffset = 2130903679;
    
    public static final int wavePeriod = 2130903680;
    
    public static final int wavePhase = 2130903681;
    
    public static final int waveShape = 2130903682;
    
    public static final int waveVariesBy = 2130903683;
    
    public static final int windowActionBar = 2130903684;
    
    public static final int windowActionBarOverlay = 2130903685;
    
    public static final int windowActionModeOverlay = 2130903686;
    
    public static final int windowFixedHeightMajor = 2130903687;
    
    public static final int windowFixedHeightMinor = 2130903688;
    
    public static final int windowFixedWidthMajor = 2130903689;
    
    public static final int windowFixedWidthMinor = 2130903690;
    
    public static final int windowMinWidthMajor = 2130903691;
    
    public static final int windowMinWidthMinor = 2130903692;
    
    public static final int windowNoTitle = 2130903693;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2130968576;
    
    public static final int abc_allow_stacked_button_bar = 2130968577;
    
    public static final int abc_config_actionMenuItemAllCaps = 2130968578;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131034112;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131034113;
    
    public static final int abc_btn_colored_borderless_text_material = 2131034114;
    
    public static final int abc_btn_colored_text_material = 2131034115;
    
    public static final int abc_color_highlight_material = 2131034116;
    
    public static final int abc_decor_view_status_guard = 2131034117;
    
    public static final int abc_decor_view_status_guard_light = 2131034118;
    
    public static final int abc_hint_foreground_material_dark = 2131034119;
    
    public static final int abc_hint_foreground_material_light = 2131034120;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131034121;
    
    public static final int abc_primary_text_disable_only_material_light = 2131034122;
    
    public static final int abc_primary_text_material_dark = 2131034123;
    
    public static final int abc_primary_text_material_light = 2131034124;
    
    public static final int abc_search_url_text = 2131034125;
    
    public static final int abc_search_url_text_normal = 2131034126;
    
    public static final int abc_search_url_text_pressed = 2131034127;
    
    public static final int abc_search_url_text_selected = 2131034128;
    
    public static final int abc_secondary_text_material_dark = 2131034129;
    
    public static final int abc_secondary_text_material_light = 2131034130;
    
    public static final int abc_tint_btn_checkable = 2131034131;
    
    public static final int abc_tint_default = 2131034132;
    
    public static final int abc_tint_edittext = 2131034133;
    
    public static final int abc_tint_seek_thumb = 2131034134;
    
    public static final int abc_tint_spinner = 2131034135;
    
    public static final int abc_tint_switch_track = 2131034136;
    
    public static final int accent_material_dark = 2131034137;
    
    public static final int accent_material_light = 2131034138;
    
    public static final int androidx_core_ripple_material_light = 2131034152;
    
    public static final int androidx_core_secondary_text_default_material_light = 2131034153;
    
    public static final int background_floating_material_dark = 2131034178;
    
    public static final int background_floating_material_light = 2131034179;
    
    public static final int background_material_dark = 2131034180;
    
    public static final int background_material_light = 2131034181;
    
    public static final int bright_foreground_disabled_material_dark = 2131034183;
    
    public static final int bright_foreground_disabled_material_light = 2131034184;
    
    public static final int bright_foreground_inverse_material_dark = 2131034185;
    
    public static final int bright_foreground_inverse_material_light = 2131034186;
    
    public static final int bright_foreground_material_dark = 2131034187;
    
    public static final int bright_foreground_material_light = 2131034188;
    
    public static final int button_material_dark = 2131034193;
    
    public static final int button_material_light = 2131034194;
    
    public static final int dim_foreground_disabled_material_dark = 2131034232;
    
    public static final int dim_foreground_disabled_material_light = 2131034233;
    
    public static final int dim_foreground_material_dark = 2131034234;
    
    public static final int dim_foreground_material_light = 2131034235;
    
    public static final int error_color_material_dark = 2131034236;
    
    public static final int error_color_material_light = 2131034237;
    
    public static final int foreground_material_dark = 2131034238;
    
    public static final int foreground_material_light = 2131034239;
    
    public static final int highlighted_text_material_dark = 2131034243;
    
    public static final int highlighted_text_material_light = 2131034244;
    
    public static final int material_blue_grey_800 = 2131034266;
    
    public static final int material_blue_grey_900 = 2131034267;
    
    public static final int material_blue_grey_950 = 2131034268;
    
    public static final int material_deep_teal_200 = 2131034269;
    
    public static final int material_deep_teal_500 = 2131034270;
    
    public static final int material_grey_100 = 2131034271;
    
    public static final int material_grey_300 = 2131034272;
    
    public static final int material_grey_50 = 2131034273;
    
    public static final int material_grey_600 = 2131034274;
    
    public static final int material_grey_800 = 2131034275;
    
    public static final int material_grey_850 = 2131034276;
    
    public static final int material_grey_900 = 2131034277;
    
    public static final int notification_action_color_filter = 2131034328;
    
    public static final int notification_icon_bg_color = 2131034329;
    
    public static final int primary_dark_material_dark = 2131034331;
    
    public static final int primary_dark_material_light = 2131034332;
    
    public static final int primary_material_dark = 2131034333;
    
    public static final int primary_material_light = 2131034334;
    
    public static final int primary_text_default_material_dark = 2131034335;
    
    public static final int primary_text_default_material_light = 2131034336;
    
    public static final int primary_text_disabled_material_dark = 2131034337;
    
    public static final int primary_text_disabled_material_light = 2131034338;
    
    public static final int ripple_material_dark = 2131034339;
    
    public static final int ripple_material_light = 2131034340;
    
    public static final int secondary_text_default_material_dark = 2131034341;
    
    public static final int secondary_text_default_material_light = 2131034342;
    
    public static final int secondary_text_disabled_material_dark = 2131034343;
    
    public static final int secondary_text_disabled_material_light = 2131034344;
    
    public static final int switch_thumb_disabled_material_dark = 2131034345;
    
    public static final int switch_thumb_disabled_material_light = 2131034346;
    
    public static final int switch_thumb_material_dark = 2131034347;
    
    public static final int switch_thumb_material_light = 2131034348;
    
    public static final int switch_thumb_normal_material_dark = 2131034349;
    
    public static final int switch_thumb_normal_material_light = 2131034350;
    
    public static final int tooltip_background_dark = 2131034351;
    
    public static final int tooltip_background_light = 2131034352;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131099648;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131099649;
    
    public static final int abc_action_bar_default_height_material = 2131099650;
    
    public static final int abc_action_bar_default_padding_end_material = 2131099651;
    
    public static final int abc_action_bar_default_padding_start_material = 2131099652;
    
    public static final int abc_action_bar_elevation_material = 2131099653;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131099655;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131099656;
    
    public static final int abc_action_bar_stacked_max_height = 2131099657;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131099658;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;
    
    public static final int abc_action_button_min_height_material = 2131099661;
    
    public static final int abc_action_button_min_width_material = 2131099662;
    
    public static final int abc_action_button_min_width_overflow_material = 2131099663;
    
    public static final int abc_alert_dialog_button_bar_height = 2131099664;
    
    public static final int abc_alert_dialog_button_dimen = 2131099665;
    
    public static final int abc_button_inset_horizontal_material = 2131099666;
    
    public static final int abc_button_inset_vertical_material = 2131099667;
    
    public static final int abc_button_padding_horizontal_material = 2131099668;
    
    public static final int abc_button_padding_vertical_material = 2131099669;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131099670;
    
    public static final int abc_config_prefDialogWidth = 2131099671;
    
    public static final int abc_control_corner_material = 2131099672;
    
    public static final int abc_control_inset_material = 2131099673;
    
    public static final int abc_control_padding_material = 2131099674;
    
    public static final int abc_dialog_corner_radius_material = 2131099675;
    
    public static final int abc_dialog_fixed_height_major = 2131099676;
    
    public static final int abc_dialog_fixed_height_minor = 2131099677;
    
    public static final int abc_dialog_fixed_width_major = 2131099678;
    
    public static final int abc_dialog_fixed_width_minor = 2131099679;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131099681;
    
    public static final int abc_dialog_min_width_major = 2131099682;
    
    public static final int abc_dialog_min_width_minor = 2131099683;
    
    public static final int abc_dialog_padding_material = 2131099684;
    
    public static final int abc_dialog_padding_top_material = 2131099685;
    
    public static final int abc_dialog_title_divider_material = 2131099686;
    
    public static final int abc_disabled_alpha_material_dark = 2131099687;
    
    public static final int abc_disabled_alpha_material_light = 2131099688;
    
    public static final int abc_dropdownitem_icon_width = 2131099689;
    
    public static final int abc_dropdownitem_text_padding_left = 2131099690;
    
    public static final int abc_dropdownitem_text_padding_right = 2131099691;
    
    public static final int abc_edit_text_inset_bottom_material = 2131099692;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131099693;
    
    public static final int abc_edit_text_inset_top_material = 2131099694;
    
    public static final int abc_floating_window_z = 2131099695;
    
    public static final int abc_list_item_height_large_material = 2131099696;
    
    public static final int abc_list_item_height_material = 2131099697;
    
    public static final int abc_list_item_height_small_material = 2131099698;
    
    public static final int abc_list_item_padding_horizontal_material = 2131099699;
    
    public static final int abc_panel_menu_list_width = 2131099700;
    
    public static final int abc_progress_bar_height_material = 2131099701;
    
    public static final int abc_search_view_preferred_height = 2131099702;
    
    public static final int abc_search_view_preferred_width = 2131099703;
    
    public static final int abc_seekbar_track_background_height_material = 2131099704;
    
    public static final int abc_seekbar_track_progress_height_material = 2131099705;
    
    public static final int abc_select_dialog_padding_start_material = 2131099706;
    
    public static final int abc_switch_padding = 2131099707;
    
    public static final int abc_text_size_body_1_material = 2131099708;
    
    public static final int abc_text_size_body_2_material = 2131099709;
    
    public static final int abc_text_size_button_material = 2131099710;
    
    public static final int abc_text_size_caption_material = 2131099711;
    
    public static final int abc_text_size_display_1_material = 2131099712;
    
    public static final int abc_text_size_display_2_material = 2131099713;
    
    public static final int abc_text_size_display_3_material = 2131099714;
    
    public static final int abc_text_size_display_4_material = 2131099715;
    
    public static final int abc_text_size_headline_material = 2131099716;
    
    public static final int abc_text_size_large_material = 2131099717;
    
    public static final int abc_text_size_medium_material = 2131099718;
    
    public static final int abc_text_size_menu_header_material = 2131099719;
    
    public static final int abc_text_size_menu_material = 2131099720;
    
    public static final int abc_text_size_small_material = 2131099721;
    
    public static final int abc_text_size_subhead_material = 2131099722;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131099723;
    
    public static final int abc_text_size_title_material = 2131099724;
    
    public static final int abc_text_size_title_material_toolbar = 2131099725;
    
    public static final int compat_button_inset_horizontal_material = 2131099805;
    
    public static final int compat_button_inset_vertical_material = 2131099806;
    
    public static final int compat_button_padding_horizontal_material = 2131099807;
    
    public static final int compat_button_padding_vertical_material = 2131099808;
    
    public static final int compat_control_corner_material = 2131099809;
    
    public static final int compat_notification_large_icon_max_height = 2131099810;
    
    public static final int compat_notification_large_icon_max_width = 2131099811;
    
    public static final int disabled_alpha_material_dark = 2131099813;
    
    public static final int disabled_alpha_material_light = 2131099814;
    
    public static final int highlight_alpha_material_colored = 2131099818;
    
    public static final int highlight_alpha_material_dark = 2131099819;
    
    public static final int highlight_alpha_material_light = 2131099820;
    
    public static final int hint_alpha_material_dark = 2131099821;
    
    public static final int hint_alpha_material_light = 2131099822;
    
    public static final int hint_pressed_alpha_material_dark = 2131099823;
    
    public static final int hint_pressed_alpha_material_light = 2131099824;
    
    public static final int notification_action_icon_size = 2131099899;
    
    public static final int notification_action_text_size = 2131099900;
    
    public static final int notification_big_circle_margin = 2131099901;
    
    public static final int notification_content_margin_start = 2131099902;
    
    public static final int notification_large_icon_height = 2131099903;
    
    public static final int notification_large_icon_width = 2131099904;
    
    public static final int notification_main_column_padding_top = 2131099905;
    
    public static final int notification_media_narrow_margin = 2131099906;
    
    public static final int notification_right_icon_size = 2131099907;
    
    public static final int notification_right_side_padding_top = 2131099908;
    
    public static final int notification_small_icon_background_padding = 2131099909;
    
    public static final int notification_small_icon_size_as_large = 2131099910;
    
    public static final int notification_subtext_size = 2131099911;
    
    public static final int notification_top_pad = 2131099912;
    
    public static final int notification_top_pad_large_text = 2131099913;
    
    public static final int tooltip_corner_radius = 2131099919;
    
    public static final int tooltip_horizontal_padding = 2131099920;
    
    public static final int tooltip_margin = 2131099921;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131099922;
    
    public static final int tooltip_precise_anchor_threshold = 2131099923;
    
    public static final int tooltip_vertical_padding = 2131099924;
    
    public static final int tooltip_y_offset_non_touch = 2131099925;
    
    public static final int tooltip_y_offset_touch = 2131099926;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131165194;
    
    public static final int abc_action_bar_item_background_material = 2131165195;
    
    public static final int abc_btn_borderless_material = 2131165196;
    
    public static final int abc_btn_check_material = 2131165197;
    
    public static final int abc_btn_check_material_anim = 2131165198;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131165199;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131165200;
    
    public static final int abc_btn_colored_material = 2131165201;
    
    public static final int abc_btn_default_mtrl_shape = 2131165202;
    
    public static final int abc_btn_radio_material = 2131165203;
    
    public static final int abc_btn_radio_material_anim = 2131165204;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131165205;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131165206;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131165207;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131165208;
    
    public static final int abc_cab_background_internal_bg = 2131165209;
    
    public static final int abc_cab_background_top_material = 2131165210;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131165211;
    
    public static final int abc_control_background_material = 2131165212;
    
    public static final int abc_dialog_material_background = 2131165213;
    
    public static final int abc_edit_text_material = 2131165214;
    
    public static final int abc_ic_ab_back_material = 2131165215;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131165216;
    
    public static final int abc_ic_clear_material = 2131165217;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131165218;
    
    public static final int abc_ic_go_search_api_material = 2131165219;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165220;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131165221;
    
    public static final int abc_ic_menu_overflow_material = 2131165222;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165223;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165224;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131165225;
    
    public static final int abc_ic_search_api_material = 2131165226;
    
    public static final int abc_ic_star_black_16dp = 2131165227;
    
    public static final int abc_ic_star_black_36dp = 2131165228;
    
    public static final int abc_ic_star_black_48dp = 2131165229;
    
    public static final int abc_ic_star_half_black_16dp = 2131165230;
    
    public static final int abc_ic_star_half_black_36dp = 2131165231;
    
    public static final int abc_ic_star_half_black_48dp = 2131165232;
    
    public static final int abc_ic_voice_search_api_material = 2131165233;
    
    public static final int abc_item_background_holo_dark = 2131165234;
    
    public static final int abc_item_background_holo_light = 2131165235;
    
    public static final int abc_list_divider_material = 2131165236;
    
    public static final int abc_list_divider_mtrl_alpha = 2131165237;
    
    public static final int abc_list_focused_holo = 2131165238;
    
    public static final int abc_list_longpressed_holo = 2131165239;
    
    public static final int abc_list_pressed_holo_dark = 2131165240;
    
    public static final int abc_list_pressed_holo_light = 2131165241;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131165242;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131165243;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131165244;
    
    public static final int abc_list_selector_disabled_holo_light = 2131165245;
    
    public static final int abc_list_selector_holo_dark = 2131165246;
    
    public static final int abc_list_selector_holo_light = 2131165247;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131165248;
    
    public static final int abc_popup_background_mtrl_mult = 2131165249;
    
    public static final int abc_ratingbar_indicator_material = 2131165250;
    
    public static final int abc_ratingbar_material = 2131165251;
    
    public static final int abc_ratingbar_small_material = 2131165252;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131165253;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131165254;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131165255;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131165256;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131165257;
    
    public static final int abc_seekbar_thumb_material = 2131165258;
    
    public static final int abc_seekbar_tick_mark_material = 2131165259;
    
    public static final int abc_seekbar_track_material = 2131165260;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131165261;
    
    public static final int abc_spinner_textfield_background_material = 2131165262;
    
    public static final int abc_switch_thumb_material = 2131165263;
    
    public static final int abc_switch_track_mtrl_alpha = 2131165264;
    
    public static final int abc_tab_indicator_material = 2131165265;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131165266;
    
    public static final int abc_text_cursor_material = 2131165267;
    
    public static final int abc_text_select_handle_left_mtrl_dark = 2131165268;
    
    public static final int abc_text_select_handle_left_mtrl_light = 2131165269;
    
    public static final int abc_text_select_handle_middle_mtrl_dark = 2131165270;
    
    public static final int abc_text_select_handle_middle_mtrl_light = 2131165271;
    
    public static final int abc_text_select_handle_right_mtrl_dark = 2131165272;
    
    public static final int abc_text_select_handle_right_mtrl_light = 2131165273;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131165274;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131165275;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131165276;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131165277;
    
    public static final int abc_textfield_search_material = 2131165278;
    
    public static final int abc_vector_test = 2131165279;
    
    public static final int btn_checkbox_checked_mtrl = 2131165429;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131165430;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131165431;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131165432;
    
    public static final int btn_radio_off_mtrl = 2131165433;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131165434;
    
    public static final int btn_radio_on_mtrl = 2131165435;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131165436;
    
    public static final int notification_action_background = 2131165626;
    
    public static final int notification_bg = 2131165627;
    
    public static final int notification_bg_low = 2131165628;
    
    public static final int notification_bg_low_normal = 2131165629;
    
    public static final int notification_bg_low_pressed = 2131165630;
    
    public static final int notification_bg_normal = 2131165631;
    
    public static final int notification_bg_normal_pressed = 2131165632;
    
    public static final int notification_icon_background = 2131165633;
    
    public static final int notification_template_icon_bg = 2131165634;
    
    public static final int notification_template_icon_low_bg = 2131165635;
    
    public static final int notification_tile_bg = 2131165636;
    
    public static final int notify_panel_notification_icon_bg = 2131165637;
    
    public static final int tooltip_frame_dark = 2131165641;
    
    public static final int tooltip_frame_light = 2131165642;
  }
  
  public static final class id {
    public static final int NO_DEBUG = 2131296266;
    
    public static final int SHOW_ALL = 2131296268;
    
    public static final int SHOW_PATH = 2131296269;
    
    public static final int SHOW_PROGRESS = 2131296270;
    
    public static final int accelerate = 2131296272;
    
    public static final int accessibility_action_clickable_span = 2131296273;
    
    public static final int accessibility_custom_action_0 = 2131296274;
    
    public static final int accessibility_custom_action_1 = 2131296275;
    
    public static final int accessibility_custom_action_10 = 2131296276;
    
    public static final int accessibility_custom_action_11 = 2131296277;
    
    public static final int accessibility_custom_action_12 = 2131296278;
    
    public static final int accessibility_custom_action_13 = 2131296279;
    
    public static final int accessibility_custom_action_14 = 2131296280;
    
    public static final int accessibility_custom_action_15 = 2131296281;
    
    public static final int accessibility_custom_action_16 = 2131296282;
    
    public static final int accessibility_custom_action_17 = 2131296283;
    
    public static final int accessibility_custom_action_18 = 2131296284;
    
    public static final int accessibility_custom_action_19 = 2131296285;
    
    public static final int accessibility_custom_action_2 = 2131296286;
    
    public static final int accessibility_custom_action_20 = 2131296287;
    
    public static final int accessibility_custom_action_21 = 2131296288;
    
    public static final int accessibility_custom_action_22 = 2131296289;
    
    public static final int accessibility_custom_action_23 = 2131296290;
    
    public static final int accessibility_custom_action_24 = 2131296291;
    
    public static final int accessibility_custom_action_25 = 2131296292;
    
    public static final int accessibility_custom_action_26 = 2131296293;
    
    public static final int accessibility_custom_action_27 = 2131296294;
    
    public static final int accessibility_custom_action_28 = 2131296295;
    
    public static final int accessibility_custom_action_29 = 2131296296;
    
    public static final int accessibility_custom_action_3 = 2131296297;
    
    public static final int accessibility_custom_action_30 = 2131296298;
    
    public static final int accessibility_custom_action_31 = 2131296299;
    
    public static final int accessibility_custom_action_4 = 2131296300;
    
    public static final int accessibility_custom_action_5 = 2131296301;
    
    public static final int accessibility_custom_action_6 = 2131296302;
    
    public static final int accessibility_custom_action_7 = 2131296303;
    
    public static final int accessibility_custom_action_8 = 2131296304;
    
    public static final int accessibility_custom_action_9 = 2131296305;
    
    public static final int actionDown = 2131296307;
    
    public static final int actionDownUp = 2131296308;
    
    public static final int actionUp = 2131296309;
    
    public static final int action_bar = 2131296310;
    
    public static final int action_bar_activity_content = 2131296311;
    
    public static final int action_bar_container = 2131296312;
    
    public static final int action_bar_root = 2131296313;
    
    public static final int action_bar_spinner = 2131296314;
    
    public static final int action_bar_subtitle = 2131296315;
    
    public static final int action_bar_title = 2131296316;
    
    public static final int action_container = 2131296317;
    
    public static final int action_context_bar = 2131296318;
    
    public static final int action_divider = 2131296319;
    
    public static final int action_image = 2131296320;
    
    public static final int action_menu_divider = 2131296321;
    
    public static final int action_menu_presenter = 2131296322;
    
    public static final int action_mode_bar = 2131296323;
    
    public static final int action_mode_bar_stub = 2131296324;
    
    public static final int action_mode_close_button = 2131296325;
    
    public static final int action_text = 2131296327;
    
    public static final int actions = 2131296328;
    
    public static final int activity_chooser_view_content = 2131296329;
    
    public static final int add = 2131296341;
    
    public static final int alertTitle = 2131296386;
    
    public static final int aligned = 2131296387;
    
    public static final int allStates = 2131296389;
    
    public static final int animateToEnd = 2131296393;
    
    public static final int animateToStart = 2131296394;
    
    public static final int antiClockwise = 2131296395;
    
    public static final int anticipate = 2131296396;
    
    public static final int asConfigured = 2131296417;
    
    public static final int async = 2131296418;
    
    public static final int auto = 2131296419;
    
    public static final int autoComplete = 2131296420;
    
    public static final int autoCompleteToEnd = 2131296421;
    
    public static final int autoCompleteToStart = 2131296422;
    
    public static final int baseline = 2131296430;
    
    public static final int bestChoice = 2131296433;
    
    public static final int blocking = 2131296434;
    
    public static final int bottom = 2131296435;
    
    public static final int bounce = 2131296436;
    
    public static final int buttonPanel = 2131296447;
    
    public static final int carryVelocity = 2131296451;
    
    public static final int center = 2131296452;
    
    public static final int chain = 2131296455;
    
    public static final int checkbox = 2131296457;
    
    public static final int checked = 2131296458;
    
    public static final int chronometer = 2131296459;
    
    public static final int clockwise = 2131296462;
    
    public static final int closest = 2131296465;
    
    public static final int constraint = 2131296478;
    
    public static final int content = 2131296480;
    
    public static final int contentPanel = 2131296481;
    
    public static final int continuousVelocity = 2131296483;
    
    public static final int cos = 2131296485;
    
    public static final int currentState = 2131296486;
    
    public static final int custom = 2131296487;
    
    public static final int customPanel = 2131296488;
    
    public static final int decelerate = 2131296490;
    
    public static final int decelerateAndComplete = 2131296491;
    
    public static final int decor_content_parent = 2131296492;
    
    public static final int default_activity_button = 2131296493;
    
    public static final int deltaRelative = 2131296494;
    
    public static final int dialog_button = 2131296497;
    
    public static final int dragAnticlockwise = 2131296506;
    
    public static final int dragClockwise = 2131296507;
    
    public static final int dragDown = 2131296508;
    
    public static final int dragEnd = 2131296509;
    
    public static final int dragLeft = 2131296510;
    
    public static final int dragRight = 2131296511;
    
    public static final int dragStart = 2131296512;
    
    public static final int dragUp = 2131296513;
    
    public static final int easeIn = 2131296514;
    
    public static final int easeInOut = 2131296515;
    
    public static final int easeOut = 2131296516;
    
    public static final int east = 2131296517;
    
    public static final int edit_query = 2131296518;
    
    public static final int end = 2131296520;
    
    public static final int expand_activities_button = 2131296529;
    
    public static final int expanded_menu = 2131296530;
    
    public static final int flip = 2131296537;
    
    public static final int forever = 2131296538;
    
    public static final int frost = 2131296539;
    
    public static final int gone = 2131296543;
    
    public static final int group_divider = 2131296546;
    
    public static final int home = 2131296551;
    
    public static final int honorRequest = 2131296553;
    
    public static final int horizontal_only = 2131296554;
    
    public static final int icon = 2131296642;
    
    public static final int icon_group = 2131296643;
    
    public static final int ignore = 2131296646;
    
    public static final int ignoreRequest = 2131296647;
    
    public static final int image = 2131296648;
    
    public static final int immediateStop = 2131296651;
    
    public static final int included = 2131296652;
    
    public static final int info = 2131296653;
    
    public static final int invisible = 2131296668;
    
    public static final int italic = 2131296669;
    
    public static final int jumpToEnd = 2131296672;
    
    public static final int jumpToStart = 2131296673;
    
    public static final int layout = 2131296676;
    
    public static final int left = 2131296678;
    
    public static final int line1 = 2131296681;
    
    public static final int line3 = 2131296682;
    
    public static final int linear = 2131296683;
    
    public static final int listMode = 2131296684;
    
    public static final int list_item = 2131296686;
    
    public static final int match_constraint = 2131296688;
    
    public static final int match_parent = 2131296689;
    
    public static final int message = 2131296819;
    
    public static final int middle = 2131296821;
    
    public static final int motion_base = 2131296822;
    
    public static final int multiply = 2131296827;
    
    public static final int neverCompleteToEnd = 2131296833;
    
    public static final int neverCompleteToStart = 2131296834;
    
    public static final int noState = 2131296836;
    
    public static final int none = 2131296837;
    
    public static final int normal = 2131296838;
    
    public static final int north = 2131296839;
    
    public static final int notification_background = 2131296840;
    
    public static final int notification_main_column = 2131296841;
    
    public static final int notification_main_column_container = 2131296842;
    
    public static final int off = 2131296843;
    
    public static final int on = 2131296845;
    
    public static final int overshoot = 2131296848;
    
    public static final int packed = 2131296849;
    
    public static final int parent = 2131296852;
    
    public static final int parentPanel = 2131296853;
    
    public static final int parentRelative = 2131296854;
    
    public static final int path = 2131296857;
    
    public static final int pathRelative = 2131296858;
    
    public static final int percent = 2131296859;
    
    public static final int position = 2131296862;
    
    public static final int postLayout = 2131296863;
    
    public static final int progress_circular = 2131296867;
    
    public static final int progress_horizontal = 2131296868;
    
    public static final int radio = 2131296869;
    
    public static final int rectangles = 2131296871;
    
    public static final int reverseSawtooth = 2131296873;
    
    public static final int right = 2131296878;
    
    public static final int right_icon = 2131296879;
    
    public static final int right_side = 2131296880;
    
    public static final int sawtooth = 2131296881;
    
    public static final int screen = 2131296882;
    
    public static final int scrollIndicatorDown = 2131296883;
    
    public static final int scrollIndicatorUp = 2131296884;
    
    public static final int scrollView = 2131296885;
    
    public static final int search_badge = 2131296887;
    
    public static final int search_bar = 2131296888;
    
    public static final int search_button = 2131296889;
    
    public static final int search_close_btn = 2131296890;
    
    public static final int search_edit_frame = 2131296891;
    
    public static final int search_go_btn = 2131296892;
    
    public static final int search_mag_icon = 2131296893;
    
    public static final int search_plate = 2131296894;
    
    public static final int search_src_text = 2131296895;
    
    public static final int search_voice_btn = 2131296896;
    
    public static final int select_dialog_listview = 2131296897;
    
    public static final int sharedValueSet = 2131296898;
    
    public static final int sharedValueUnset = 2131296899;
    
    public static final int shortcut = 2131296900;
    
    public static final int sin = 2131296906;
    
    public static final int skipped = 2131296909;
    
    public static final int south = 2131296911;
    
    public static final int spacer = 2131296912;
    
    public static final int spline = 2131296914;
    
    public static final int split_action_bar = 2131296915;
    
    public static final int spread = 2131296916;
    
    public static final int spread_inside = 2131296917;
    
    public static final int spring = 2131296918;
    
    public static final int square = 2131296919;
    
    public static final int src_atop = 2131296920;
    
    public static final int src_in = 2131296921;
    
    public static final int src_over = 2131296922;
    
    public static final int standard = 2131296923;
    
    public static final int start = 2131296924;
    
    public static final int startHorizontal = 2131296925;
    
    public static final int startVertical = 2131296926;
    
    public static final int staticLayout = 2131296927;
    
    public static final int staticPostLayout = 2131296928;
    
    public static final int stop = 2131296931;
    
    public static final int submenuarrow = 2131296932;
    
    public static final int submit_area = 2131296933;
    
    public static final int tabMode = 2131296936;
    
    public static final int tag_accessibility_actions = 2131296937;
    
    public static final int tag_accessibility_clickable_spans = 2131296938;
    
    public static final int tag_accessibility_heading = 2131296939;
    
    public static final int tag_accessibility_pane_title = 2131296940;
    
    public static final int tag_screen_reader_focusable = 2131296944;
    
    public static final int tag_transition_group = 2131296946;
    
    public static final int tag_unhandled_key_event_manager = 2131296947;
    
    public static final int tag_unhandled_key_listeners = 2131296948;
    
    public static final int text = 2131296950;
    
    public static final int text2 = 2131296951;
    
    public static final int textSpacerNoButtons = 2131296952;
    
    public static final int textSpacerNoTitle = 2131296953;
    
    public static final int time = 2131296955;
    
    public static final int title = 2131296956;
    
    public static final int titleDividerNoCustom = 2131296957;
    
    public static final int title_template = 2131296958;
    
    public static final int top = 2131296961;
    
    public static final int topPanel = 2131296962;
    
    public static final int triangle = 2131296965;
    
    public static final int unchecked = 2131297259;
    
    public static final int uniform = 2131297261;
    
    public static final int up = 2131297264;
    
    public static final int vertical_only = 2131297266;
    
    public static final int view_transition = 2131297268;
    
    public static final int visible = 2131297270;
    
    public static final int west = 2131297273;
    
    public static final int wrap = 2131297277;
    
    public static final int wrap_content = 2131297278;
    
    public static final int wrap_content_constrained = 2131297279;
    
    public static final int x_left = 2131297280;
    
    public static final int x_right = 2131297281;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131361792;
    
    public static final int abc_config_activityShortDur = 2131361793;
    
    public static final int cancel_button_image_alpha = 2131361796;
    
    public static final int config_tooltipAnimTime = 2131361797;
    
    public static final int status_bar_notification_info_maxnum = 2131361801;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131427328;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131427329;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131427330;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131427331;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131427332;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131427333;
    
    public static final int fast_out_slow_in = 2131427334;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131492864;
    
    public static final int abc_action_bar_up_container = 2131492865;
    
    public static final int abc_action_menu_item_layout = 2131492866;
    
    public static final int abc_action_menu_layout = 2131492867;
    
    public static final int abc_action_mode_bar = 2131492868;
    
    public static final int abc_action_mode_close_item_material = 2131492869;
    
    public static final int abc_activity_chooser_view = 2131492870;
    
    public static final int abc_activity_chooser_view_list_item = 2131492871;
    
    public static final int abc_alert_dialog_button_bar_material = 2131492872;
    
    public static final int abc_alert_dialog_material = 2131492873;
    
    public static final int abc_alert_dialog_title_material = 2131492874;
    
    public static final int abc_cascading_menu_item_layout = 2131492875;
    
    public static final int abc_dialog_title_material = 2131492876;
    
    public static final int abc_expanded_menu_layout = 2131492877;
    
    public static final int abc_list_menu_item_checkbox = 2131492878;
    
    public static final int abc_list_menu_item_icon = 2131492879;
    
    public static final int abc_list_menu_item_layout = 2131492880;
    
    public static final int abc_list_menu_item_radio = 2131492881;
    
    public static final int abc_popup_menu_header_item_layout = 2131492882;
    
    public static final int abc_popup_menu_item_layout = 2131492883;
    
    public static final int abc_screen_content_include = 2131492884;
    
    public static final int abc_screen_simple = 2131492885;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131492886;
    
    public static final int abc_screen_toolbar = 2131492887;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131492888;
    
    public static final int abc_search_view = 2131492889;
    
    public static final int abc_select_dialog_material = 2131492890;
    
    public static final int abc_tooltip = 2131492891;
    
    public static final int custom_dialog = 2131492923;
    
    public static final int notification_action = 2131492999;
    
    public static final int notification_action_tombstone = 2131493000;
    
    public static final int notification_template_custom_big = 2131493007;
    
    public static final int notification_template_icon_group = 2131493008;
    
    public static final int notification_template_part_chronometer = 2131493012;
    
    public static final int notification_template_part_time = 2131493013;
    
    public static final int select_dialog_item_material = 2131493014;
    
    public static final int select_dialog_multichoice_material = 2131493015;
    
    public static final int select_dialog_singlechoice_material = 2131493016;
    
    public static final int support_simple_spinner_dropdown_item = 2131493018;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131820549;
    
    public static final int abc_action_bar_up_description = 2131820550;
    
    public static final int abc_action_menu_overflow_description = 2131820551;
    
    public static final int abc_action_mode_done = 2131820552;
    
    public static final int abc_activity_chooser_view_see_all = 2131820553;
    
    public static final int abc_activitychooserview_choose_application = 2131820554;
    
    public static final int abc_capital_off = 2131820555;
    
    public static final int abc_capital_on = 2131820556;
    
    public static final int abc_menu_alt_shortcut_label = 2131820557;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131820558;
    
    public static final int abc_menu_delete_shortcut_label = 2131820559;
    
    public static final int abc_menu_enter_shortcut_label = 2131820560;
    
    public static final int abc_menu_function_shortcut_label = 2131820561;
    
    public static final int abc_menu_meta_shortcut_label = 2131820562;
    
    public static final int abc_menu_shift_shortcut_label = 2131820563;
    
    public static final int abc_menu_space_shortcut_label = 2131820564;
    
    public static final int abc_menu_sym_shortcut_label = 2131820565;
    
    public static final int abc_prepend_shortcut_label = 2131820566;
    
    public static final int abc_search_hint = 2131820567;
    
    public static final int abc_searchview_description_clear = 2131820568;
    
    public static final int abc_searchview_description_query = 2131820569;
    
    public static final int abc_searchview_description_search = 2131820570;
    
    public static final int abc_searchview_description_submit = 2131820571;
    
    public static final int abc_searchview_description_voice = 2131820572;
    
    public static final int abc_shareactionprovider_share_with = 2131820573;
    
    public static final int abc_shareactionprovider_share_with_application = 2131820574;
    
    public static final int abc_toolbar_collapse_description = 2131820575;
    
    public static final int search_menu_title = 2131820816;
    
    public static final int status_bar_notification_info_overflow = 2131820821;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2131886080;
    
    public static final int AlertDialog_AppCompat_Light = 2131886081;
    
    public static final int Animation_AppCompat_Dialog = 2131886082;
    
    public static final int Animation_AppCompat_DropDownUp = 2131886083;
    
    public static final int Animation_AppCompat_Tooltip = 2131886084;
    
    public static final int Base_AlertDialog_AppCompat = 2131886119;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131886120;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131886121;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131886122;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2131886123;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131886126;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131886125;
    
    public static final int Base_TextAppearance_AppCompat = 2131886127;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131886128;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131886129;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131886130;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131886131;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131886132;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131886133;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131886134;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131886135;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131886136;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131886137;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131886138;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131886139;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131886140;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131886141;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131886142;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131886143;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131886144;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131886145;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131886146;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131886147;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131886148;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131886149;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131886150;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131886151;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131886152;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131886153;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2131886154;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131886155;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131886156;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131886157;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131886158;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131886159;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131886160;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131886161;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131886162;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131886163;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131886164;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131886165;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131886166;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131886167;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131886168;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131886169;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131886170;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131886171;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131886172;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131886173;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131886174;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131886189;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131886190;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131886191;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131886192;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131886193;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131886194;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131886195;
    
    public static final int Base_Theme_AppCompat = 2131886175;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131886176;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131886177;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131886181;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131886178;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131886179;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131886180;
    
    public static final int Base_Theme_AppCompat_Light = 2131886182;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131886183;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131886184;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131886188;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131886185;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131886186;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131886187;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131886200;
    
    public static final int Base_V21_Theme_AppCompat = 2131886196;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131886197;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131886198;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131886199;
    
    public static final int Base_V22_Theme_AppCompat = 2131886201;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131886202;
    
    public static final int Base_V23_Theme_AppCompat = 2131886203;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131886204;
    
    public static final int Base_V26_Theme_AppCompat = 2131886205;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2131886206;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2131886207;
    
    public static final int Base_V28_Theme_AppCompat = 2131886208;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2131886209;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131886214;
    
    public static final int Base_V7_Theme_AppCompat = 2131886210;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131886211;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131886212;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131886213;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131886215;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131886216;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2131886217;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131886218;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131886219;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131886220;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131886221;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131886222;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131886223;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131886224;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131886225;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131886226;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131886227;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131886228;
    
    public static final int Base_Widget_AppCompat_Button = 2131886229;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131886235;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131886236;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131886230;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131886231;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131886232;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131886233;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131886234;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131886237;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131886238;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131886239;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131886240;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131886241;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131886242;
    
    public static final int Base_Widget_AppCompat_EditText = 2131886243;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131886244;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131886245;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131886246;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131886247;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131886248;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131886249;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131886250;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131886251;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131886252;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2131886253;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131886254;
    
    public static final int Base_Widget_AppCompat_ListView = 2131886255;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131886256;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131886257;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131886258;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131886259;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131886260;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131886261;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131886262;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131886263;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131886264;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131886265;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131886266;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131886267;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131886268;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131886269;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131886270;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131886271;
    
    public static final int Base_Widget_AppCompat_TextView = 2131886272;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131886273;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131886274;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131886275;
    
    public static final int Platform_AppCompat = 2131886284;
    
    public static final int Platform_AppCompat_Light = 2131886285;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131886286;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131886287;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131886288;
    
    public static final int Platform_V21_AppCompat = 2131886289;
    
    public static final int Platform_V21_AppCompat_Light = 2131886290;
    
    public static final int Platform_V25_AppCompat = 2131886291;
    
    public static final int Platform_V25_AppCompat_Light = 2131886292;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131886293;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131886294;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131886295;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131886296;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131886297;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131886298;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131886299;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131886300;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131886301;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131886302;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131886308;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131886303;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131886304;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131886305;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131886306;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131886307;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131886309;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131886310;
    
    public static final int TextAppearance_AppCompat = 2131886312;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131886313;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131886314;
    
    public static final int TextAppearance_AppCompat_Button = 2131886315;
    
    public static final int TextAppearance_AppCompat_Caption = 2131886316;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131886317;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131886318;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131886319;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131886320;
    
    public static final int TextAppearance_AppCompat_Headline = 2131886321;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131886322;
    
    public static final int TextAppearance_AppCompat_Large = 2131886323;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131886324;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131886325;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131886326;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131886327;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131886328;
    
    public static final int TextAppearance_AppCompat_Medium = 2131886329;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131886330;
    
    public static final int TextAppearance_AppCompat_Menu = 2131886331;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131886332;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131886333;
    
    public static final int TextAppearance_AppCompat_Small = 2131886334;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131886335;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131886336;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131886337;
    
    public static final int TextAppearance_AppCompat_Title = 2131886338;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131886339;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2131886340;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131886341;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131886342;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131886343;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131886344;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131886345;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131886346;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131886347;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131886348;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131886349;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131886350;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131886351;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131886352;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131886353;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131886354;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131886355;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131886356;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131886357;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131886358;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131886359;
    
    public static final int TextAppearance_Compat_Notification = 2131886360;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131886361;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131886363;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131886366;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131886368;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131886370;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131886371;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131886372;
    
    public static final int ThemeOverlay_AppCompat = 2131886397;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131886398;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131886399;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131886400;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2131886401;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131886402;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2131886403;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131886404;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131886405;
    
    public static final int Theme_AppCompat = 2131886373;
    
    public static final int Theme_AppCompat_CompactMenu = 2131886374;
    
    public static final int Theme_AppCompat_DayNight = 2131886375;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131886376;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131886377;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131886380;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131886378;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131886379;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131886381;
    
    public static final int Theme_AppCompat_Dialog = 2131886382;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131886385;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131886383;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131886384;
    
    public static final int Theme_AppCompat_Empty = 2131886386;
    
    public static final int Theme_AppCompat_Light = 2131886387;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131886388;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131886389;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131886392;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131886390;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131886391;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131886393;
    
    public static final int Theme_AppCompat_NoActionBar = 2131886394;
    
    public static final int Widget_AppCompat_ActionBar = 2131886408;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131886409;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131886410;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131886411;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131886412;
    
    public static final int Widget_AppCompat_ActionButton = 2131886413;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131886414;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131886415;
    
    public static final int Widget_AppCompat_ActionMode = 2131886416;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131886417;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131886418;
    
    public static final int Widget_AppCompat_Button = 2131886419;
    
    public static final int Widget_AppCompat_ButtonBar = 2131886425;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131886426;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131886420;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131886421;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131886422;
    
    public static final int Widget_AppCompat_Button_Colored = 2131886423;
    
    public static final int Widget_AppCompat_Button_Small = 2131886424;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131886427;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131886428;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131886429;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131886430;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131886431;
    
    public static final int Widget_AppCompat_EditText = 2131886432;
    
    public static final int Widget_AppCompat_ImageButton = 2131886433;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131886434;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131886435;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131886436;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131886437;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131886438;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131886439;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131886440;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131886441;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131886442;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131886443;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131886444;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131886445;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131886446;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131886447;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131886448;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131886449;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131886450;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131886451;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131886452;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131886453;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131886454;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131886455;
    
    public static final int Widget_AppCompat_ListMenuView = 2131886456;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131886457;
    
    public static final int Widget_AppCompat_ListView = 2131886458;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131886459;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131886460;
    
    public static final int Widget_AppCompat_PopupMenu = 2131886461;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131886462;
    
    public static final int Widget_AppCompat_PopupWindow = 2131886463;
    
    public static final int Widget_AppCompat_ProgressBar = 2131886464;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131886465;
    
    public static final int Widget_AppCompat_RatingBar = 2131886466;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131886467;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131886468;
    
    public static final int Widget_AppCompat_SearchView = 2131886469;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131886470;
    
    public static final int Widget_AppCompat_SeekBar = 2131886471;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2131886472;
    
    public static final int Widget_AppCompat_Spinner = 2131886473;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131886474;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131886475;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131886476;
    
    public static final int Widget_AppCompat_TextView = 2131886477;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131886478;
    
    public static final int Widget_AppCompat_Toolbar = 2131886479;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131886480;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131886481;
    
    public static final int Widget_Compat_NotificationActionText = 2131886482;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130903142, 2130903143, 2130903144, 2130903236, 2130903237, 2130903238, 2130903239, 2130903240, 2130903241, 2130903260, 
        2130903273, 2130903274, 2130903298, 2130903340, 2130903341, 2130903342, 2130903343, 2130903346, 2130903359, 2130903362, 
        2130903452, 2130903496, 2130903527, 2130903530, 2130903531, 2130903590, 2130903593, 2130903639, 2130903648 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130903142, 2130903143, 2130903200, 2130903340, 2130903593, 2130903648 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130903299, 2130903360 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130903163, 2130903164, 2130903441, 2130903442, 2130903493, 2130903570, 2130903571 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130903583, 2130903637, 2130903638 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130903634, 2130903635, 2130903636 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130903136, 2130903137, 2130903138, 2130903139, 2130903140, 2130903282, 2130903283, 2130903284, 2130903285, 
        2130903287, 2130903288, 2130903289, 2130903290, 2130903305, 2130903326, 2130903335, 2130903366, 2130903436, 2130903603, 
        2130903620 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 14;
    
    public static final int AppCompatTextView_fontFamily = 15;
    
    public static final int AppCompatTextView_fontVariationSettings = 16;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 17;
    
    public static final int AppCompatTextView_lineHeight = 18;
    
    public static final int AppCompatTextView_textAllCaps = 19;
    
    public static final int AppCompatTextView_textLocale = 20;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130903043, 2130903044, 2130903045, 2130903046, 2130903047, 2130903048, 2130903049, 2130903050, 
        2130903051, 2130903052, 2130903053, 2130903054, 2130903055, 2130903057, 2130903058, 2130903059, 2130903060, 2130903061, 
        2130903062, 2130903063, 2130903064, 2130903065, 2130903066, 2130903067, 2130903068, 2130903069, 2130903070, 2130903071, 
        2130903072, 2130903073, 2130903076, 2130903119, 2130903120, 2130903121, 2130903122, 2130903135, 2130903154, 2130903156, 
        2130903157, 2130903158, 2130903159, 2130903160, 2130903166, 2130903167, 2130903188, 2130903189, 2130903204, 2130903205, 
        2130903206, 2130903207, 2130903208, 2130903209, 2130903210, 2130903211, 2130903212, 2130903214, 2130903248, 2130903270, 
        2130903271, 2130903272, 2130903275, 2130903277, 2130903292, 2130903293, 2130903295, 2130903296, 2130903297, 2130903342, 
        2130903354, 2130903437, 2130903438, 2130903439, 2130903440, 2130903443, 2130903444, 2130903445, 2130903446, 2130903447, 
        2130903448, 2130903449, 2130903450, 2130903451, 2130903513, 2130903514, 2130903515, 2130903526, 2130903528, 2130903538, 
        2130903539, 2130903540, 2130903541, 2130903560, 2130903561, 2130903562, 2130903563, 2130903575, 2130903576, 2130903597, 
        2130903604, 2130903605, 2130903606, 2130903607, 2130903608, 2130903609, 2130903610, 2130903611, 2130903617, 2130903618, 
        2130903649, 2130903650, 2130903651, 2130903652, 2130903670, 2130903684, 2130903685, 2130903686, 2130903687, 2130903688, 
        2130903689, 2130903690, 2130903691, 2130903692, 2130903693 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 19;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 21;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 22;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 23;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 26;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 27;
    
    public static final int AppCompatTheme_actionModeStyle = 28;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 32;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 34;
    
    public static final int AppCompatTheme_alertDialogStyle = 35;
    
    public static final int AppCompatTheme_alertDialogTheme = 36;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 38;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 39;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarStyle = 43;
    
    public static final int AppCompatTheme_buttonStyle = 44;
    
    public static final int AppCompatTheme_buttonStyleSmall = 45;
    
    public static final int AppCompatTheme_checkboxStyle = 46;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 47;
    
    public static final int AppCompatTheme_colorAccent = 48;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 49;
    
    public static final int AppCompatTheme_colorButtonNormal = 50;
    
    public static final int AppCompatTheme_colorControlActivated = 51;
    
    public static final int AppCompatTheme_colorControlHighlight = 52;
    
    public static final int AppCompatTheme_colorControlNormal = 53;
    
    public static final int AppCompatTheme_colorError = 54;
    
    public static final int AppCompatTheme_colorPrimary = 55;
    
    public static final int AppCompatTheme_colorPrimaryDark = 56;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 57;
    
    public static final int AppCompatTheme_controlBackground = 58;
    
    public static final int AppCompatTheme_dialogCornerRadius = 59;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 60;
    
    public static final int AppCompatTheme_dialogTheme = 61;
    
    public static final int AppCompatTheme_dividerHorizontal = 62;
    
    public static final int AppCompatTheme_dividerVertical = 63;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 64;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 65;
    
    public static final int AppCompatTheme_editTextBackground = 66;
    
    public static final int AppCompatTheme_editTextColor = 67;
    
    public static final int AppCompatTheme_editTextStyle = 68;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 69;
    
    public static final int AppCompatTheme_imageButtonStyle = 70;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 71;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 72;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 73;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 74;
    
    public static final int AppCompatTheme_listMenuViewStyle = 75;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 76;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 77;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 79;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 80;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 83;
    
    public static final int AppCompatTheme_panelBackground = 84;
    
    public static final int AppCompatTheme_panelMenuListTheme = 85;
    
    public static final int AppCompatTheme_panelMenuListWidth = 86;
    
    public static final int AppCompatTheme_popupMenuStyle = 87;
    
    public static final int AppCompatTheme_popupWindowStyle = 88;
    
    public static final int AppCompatTheme_radioButtonStyle = 89;
    
    public static final int AppCompatTheme_ratingBarStyle = 90;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 91;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 92;
    
    public static final int AppCompatTheme_searchViewStyle = 93;
    
    public static final int AppCompatTheme_seekBarStyle = 94;
    
    public static final int AppCompatTheme_selectableItemBackground = 95;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 96;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 97;
    
    public static final int AppCompatTheme_spinnerStyle = 98;
    
    public static final int AppCompatTheme_switchStyle = 99;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 100;
    
    public static final int AppCompatTheme_textAppearanceListItem = 101;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 102;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 103;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 104;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 105;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 106;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 107;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 108;
    
    public static final int AppCompatTheme_textColorSearchUrl = 109;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 110;
    
    public static final int AppCompatTheme_toolbarStyle = 111;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 112;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 113;
    
    public static final int AppCompatTheme_viewInflaterClass = 114;
    
    public static final int AppCompatTheme_windowActionBar = 115;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 116;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 117;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 118;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 119;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 120;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 121;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 122;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 123;
    
    public static final int AppCompatTheme_windowNoTitle = 124;
    
    public static final int[] ButtonBarLayout = new int[] { 2130903123 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] Carousel = new int[] { 2130903177, 2130903178, 2130903179, 2130903180, 2130903181, 2130903182, 2130903183, 2130903184, 2130903185, 2130903186 };
    
    public static final int Carousel_carousel_backwardTransition = 0;
    
    public static final int Carousel_carousel_emptyViewsBehavior = 1;
    
    public static final int Carousel_carousel_firstView = 2;
    
    public static final int Carousel_carousel_forwardTransition = 3;
    
    public static final int Carousel_carousel_infinite = 4;
    
    public static final int Carousel_carousel_nextState = 5;
    
    public static final int Carousel_carousel_previousState = 6;
    
    public static final int Carousel_carousel_touchUpMode = 7;
    
    public static final int Carousel_carousel_touchUp_dampeningFactor = 8;
    
    public static final int Carousel_carousel_touchUp_velocityThreshold = 9;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130903124, 2130903365 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130903161, 2130903168, 2130903169 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] Constraint = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
        16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130903127, 2130903128, 2130903148, 
        2130903149, 2130903150, 2130903187, 2130903231, 2130903232, 2130903281, 2130903306, 2130903307, 2130903308, 2130903309, 
        2130903310, 2130903311, 2130903312, 2130903313, 2130903314, 2130903315, 2130903316, 2130903317, 2130903318, 2130903320, 
        2130903321, 2130903322, 2130903323, 2130903324, 2130903374, 2130903375, 2130903376, 2130903377, 2130903378, 2130903379, 
        2130903380, 2130903381, 2130903382, 2130903383, 2130903384, 2130903385, 2130903386, 2130903387, 2130903388, 2130903389, 
        2130903390, 2130903391, 2130903392, 2130903393, 2130903394, 2130903395, 2130903396, 2130903397, 2130903398, 2130903399, 
        2130903400, 2130903401, 2130903402, 2130903403, 2130903404, 2130903405, 2130903406, 2130903407, 2130903408, 2130903409, 
        2130903410, 2130903411, 2130903412, 2130903413, 2130903414, 2130903415, 2130903416, 2130903417, 2130903418, 2130903419, 
        2130903421, 2130903422, 2130903423, 2130903424, 2130903425, 2130903426, 2130903427, 2130903428, 2130903429, 2130903432, 
        2130903434, 2130903487, 2130903488, 2130903516, 2130903523, 2130903525, 2130903532, 2130903533, 2130903534, 2130903660, 
        2130903662, 2130903664, 2130903675 };
    
    public static final int[] ConstraintLayout_Layout = new int[] { 
        16842948, 16842965, 16842966, 16842967, 16842968, 16842969, 16842972, 16842996, 16842997, 16842998, 
        16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843699, 16843700, 
        16843701, 16843702, 16843840, 16844091, 16844092, 2130903148, 2130903149, 2130903150, 2130903187, 2130903192, 
        2130903193, 2130903194, 2130903195, 2130903196, 2130903228, 2130903231, 2130903232, 2130903306, 2130903307, 2130903308, 
        2130903309, 2130903310, 2130903311, 2130903312, 2130903313, 2130903314, 2130903315, 2130903316, 2130903317, 2130903318, 
        2130903320, 2130903321, 2130903322, 2130903323, 2130903324, 2130903368, 2130903374, 2130903375, 2130903376, 2130903377, 
        2130903378, 2130903379, 2130903380, 2130903381, 2130903382, 2130903383, 2130903384, 2130903385, 2130903386, 2130903387, 
        2130903388, 2130903389, 2130903390, 2130903391, 2130903392, 2130903393, 2130903394, 2130903395, 2130903396, 2130903397, 
        2130903398, 2130903399, 2130903400, 2130903401, 2130903402, 2130903403, 2130903404, 2130903405, 2130903406, 2130903407, 
        2130903408, 2130903409, 2130903410, 2130903411, 2130903412, 2130903413, 2130903414, 2130903415, 2130903416, 2130903417, 
        2130903418, 2130903419, 2130903421, 2130903422, 2130903423, 2130903424, 2130903425, 2130903426, 2130903427, 2130903428, 
        2130903429, 2130903432, 2130903433, 2130903434 };
    
    public static final int ConstraintLayout_Layout_android_elevation = 22;
    
    public static final int ConstraintLayout_Layout_android_layout_height = 8;
    
    public static final int ConstraintLayout_Layout_android_layout_margin = 9;
    
    public static final int ConstraintLayout_Layout_android_layout_marginBottom = 13;
    
    public static final int ConstraintLayout_Layout_android_layout_marginEnd = 21;
    
    public static final int ConstraintLayout_Layout_android_layout_marginHorizontal = 23;
    
    public static final int ConstraintLayout_Layout_android_layout_marginLeft = 10;
    
    public static final int ConstraintLayout_Layout_android_layout_marginRight = 12;
    
    public static final int ConstraintLayout_Layout_android_layout_marginStart = 20;
    
    public static final int ConstraintLayout_Layout_android_layout_marginTop = 11;
    
    public static final int ConstraintLayout_Layout_android_layout_marginVertical = 24;
    
    public static final int ConstraintLayout_Layout_android_layout_width = 7;
    
    public static final int ConstraintLayout_Layout_android_maxHeight = 15;
    
    public static final int ConstraintLayout_Layout_android_maxWidth = 14;
    
    public static final int ConstraintLayout_Layout_android_minHeight = 17;
    
    public static final int ConstraintLayout_Layout_android_minWidth = 16;
    
    public static final int ConstraintLayout_Layout_android_orientation = 0;
    
    public static final int ConstraintLayout_Layout_android_padding = 1;
    
    public static final int ConstraintLayout_Layout_android_paddingBottom = 5;
    
    public static final int ConstraintLayout_Layout_android_paddingEnd = 19;
    
    public static final int ConstraintLayout_Layout_android_paddingLeft = 2;
    
    public static final int ConstraintLayout_Layout_android_paddingRight = 4;
    
    public static final int ConstraintLayout_Layout_android_paddingStart = 18;
    
    public static final int ConstraintLayout_Layout_android_paddingTop = 3;
    
    public static final int ConstraintLayout_Layout_android_visibility = 6;
    
    public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 25;
    
    public static final int ConstraintLayout_Layout_barrierDirection = 26;
    
    public static final int ConstraintLayout_Layout_barrierMargin = 27;
    
    public static final int ConstraintLayout_Layout_chainUseRtl = 28;
    
    public static final int ConstraintLayout_Layout_circularflow_angles = 29;
    
    public static final int ConstraintLayout_Layout_circularflow_defaultAngle = 30;
    
    public static final int ConstraintLayout_Layout_circularflow_defaultRadius = 31;
    
    public static final int ConstraintLayout_Layout_circularflow_radiusInDP = 32;
    
    public static final int ConstraintLayout_Layout_circularflow_viewCenter = 33;
    
    public static final int ConstraintLayout_Layout_constraintSet = 34;
    
    public static final int ConstraintLayout_Layout_constraint_referenced_ids = 35;
    
    public static final int ConstraintLayout_Layout_constraint_referenced_tags = 36;
    
    public static final int ConstraintLayout_Layout_flow_firstHorizontalBias = 37;
    
    public static final int ConstraintLayout_Layout_flow_firstHorizontalStyle = 38;
    
    public static final int ConstraintLayout_Layout_flow_firstVerticalBias = 39;
    
    public static final int ConstraintLayout_Layout_flow_firstVerticalStyle = 40;
    
    public static final int ConstraintLayout_Layout_flow_horizontalAlign = 41;
    
    public static final int ConstraintLayout_Layout_flow_horizontalBias = 42;
    
    public static final int ConstraintLayout_Layout_flow_horizontalGap = 43;
    
    public static final int ConstraintLayout_Layout_flow_horizontalStyle = 44;
    
    public static final int ConstraintLayout_Layout_flow_lastHorizontalBias = 45;
    
    public static final int ConstraintLayout_Layout_flow_lastHorizontalStyle = 46;
    
    public static final int ConstraintLayout_Layout_flow_lastVerticalBias = 47;
    
    public static final int ConstraintLayout_Layout_flow_lastVerticalStyle = 48;
    
    public static final int ConstraintLayout_Layout_flow_maxElementsWrap = 49;
    
    public static final int ConstraintLayout_Layout_flow_verticalAlign = 50;
    
    public static final int ConstraintLayout_Layout_flow_verticalBias = 51;
    
    public static final int ConstraintLayout_Layout_flow_verticalGap = 52;
    
    public static final int ConstraintLayout_Layout_flow_verticalStyle = 53;
    
    public static final int ConstraintLayout_Layout_flow_wrapMode = 54;
    
    public static final int ConstraintLayout_Layout_layoutDescription = 55;
    
    public static final int ConstraintLayout_Layout_layout_constrainedHeight = 56;
    
    public static final int ConstraintLayout_Layout_layout_constrainedWidth = 57;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 58;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 59;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf = 60;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toTopOf = 61;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 62;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 63;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 64;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircle = 65;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 66;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 67;
    
    public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 68;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 69;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 70;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 71;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 72;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 73;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight = 74;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 75;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 76;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 77;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 78;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 79;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 80;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 81;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 82;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 83;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 84;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 85;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 86;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 87;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 88;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 89;
    
    public static final int ConstraintLayout_Layout_layout_constraintTag = 90;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 91;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 92;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 93;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 94;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 95;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 96;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth = 97;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 98;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 99;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 100;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 101;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 102;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 103;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginBaseline = 104;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 105;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 106;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 107;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginRight = 108;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginStart = 109;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginTop = 110;
    
    public static final int ConstraintLayout_Layout_layout_marginBaseline = 111;
    
    public static final int ConstraintLayout_Layout_layout_optimizationLevel = 112;
    
    public static final int ConstraintLayout_Layout_layout_wrapBehaviorInParent = 113;
    
    public static final int[] ConstraintLayout_ReactiveGuide = new int[] { 2130903542, 2130903543, 2130903544, 2130903545 };
    
    public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_animateChange = 0;
    
    public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_applyToAllConstraintSets = 1;
    
    public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_applyToConstraintSet = 2;
    
    public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_valueId = 3;
    
    public static final int[] ConstraintLayout_placeholder = new int[] { 2130903234, 2130903524 };
    
    public static final int ConstraintLayout_placeholder_content = 0;
    
    public static final int ConstraintLayout_placeholder_placeholder_emptyVisibility = 1;
    
    public static final int[] ConstraintOverride = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
        16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130903127, 2130903128, 2130903148, 
        2130903149, 2130903150, 2130903187, 2130903231, 2130903281, 2130903306, 2130903307, 2130903308, 2130903309, 2130903310, 
        2130903311, 2130903312, 2130903313, 2130903314, 2130903315, 2130903316, 2130903317, 2130903318, 2130903320, 2130903321, 
        2130903322, 2130903323, 2130903324, 2130903374, 2130903375, 2130903376, 2130903380, 2130903384, 2130903385, 2130903386, 
        2130903389, 2130903390, 2130903391, 2130903392, 2130903393, 2130903394, 2130903395, 2130903396, 2130903397, 2130903398, 
        2130903399, 2130903400, 2130903403, 2130903408, 2130903409, 2130903412, 2130903413, 2130903414, 2130903415, 2130903416, 
        2130903417, 2130903418, 2130903419, 2130903421, 2130903422, 2130903423, 2130903424, 2130903425, 2130903426, 2130903427, 
        2130903428, 2130903429, 2130903432, 2130903434, 2130903487, 2130903488, 2130903489, 2130903516, 2130903523, 2130903525, 
        2130903532, 2130903533, 2130903534, 2130903660, 2130903662, 2130903664, 2130903675 };
    
    public static final int ConstraintOverride_android_alpha = 13;
    
    public static final int ConstraintOverride_android_elevation = 26;
    
    public static final int ConstraintOverride_android_id = 1;
    
    public static final int ConstraintOverride_android_layout_height = 4;
    
    public static final int ConstraintOverride_android_layout_marginBottom = 8;
    
    public static final int ConstraintOverride_android_layout_marginEnd = 24;
    
    public static final int ConstraintOverride_android_layout_marginLeft = 5;
    
    public static final int ConstraintOverride_android_layout_marginRight = 7;
    
    public static final int ConstraintOverride_android_layout_marginStart = 23;
    
    public static final int ConstraintOverride_android_layout_marginTop = 6;
    
    public static final int ConstraintOverride_android_layout_width = 3;
    
    public static final int ConstraintOverride_android_maxHeight = 10;
    
    public static final int ConstraintOverride_android_maxWidth = 9;
    
    public static final int ConstraintOverride_android_minHeight = 12;
    
    public static final int ConstraintOverride_android_minWidth = 11;
    
    public static final int ConstraintOverride_android_orientation = 0;
    
    public static final int ConstraintOverride_android_rotation = 20;
    
    public static final int ConstraintOverride_android_rotationX = 21;
    
    public static final int ConstraintOverride_android_rotationY = 22;
    
    public static final int ConstraintOverride_android_scaleX = 18;
    
    public static final int ConstraintOverride_android_scaleY = 19;
    
    public static final int ConstraintOverride_android_transformPivotX = 14;
    
    public static final int ConstraintOverride_android_transformPivotY = 15;
    
    public static final int ConstraintOverride_android_translationX = 16;
    
    public static final int ConstraintOverride_android_translationY = 17;
    
    public static final int ConstraintOverride_android_translationZ = 25;
    
    public static final int ConstraintOverride_android_visibility = 2;
    
    public static final int ConstraintOverride_animateCircleAngleTo = 27;
    
    public static final int ConstraintOverride_animateRelativeTo = 28;
    
    public static final int ConstraintOverride_barrierAllowsGoneWidgets = 29;
    
    public static final int ConstraintOverride_barrierDirection = 30;
    
    public static final int ConstraintOverride_barrierMargin = 31;
    
    public static final int ConstraintOverride_chainUseRtl = 32;
    
    public static final int ConstraintOverride_constraint_referenced_ids = 33;
    
    public static final int ConstraintOverride_drawPath = 34;
    
    public static final int ConstraintOverride_flow_firstHorizontalBias = 35;
    
    public static final int ConstraintOverride_flow_firstHorizontalStyle = 36;
    
    public static final int ConstraintOverride_flow_firstVerticalBias = 37;
    
    public static final int ConstraintOverride_flow_firstVerticalStyle = 38;
    
    public static final int ConstraintOverride_flow_horizontalAlign = 39;
    
    public static final int ConstraintOverride_flow_horizontalBias = 40;
    
    public static final int ConstraintOverride_flow_horizontalGap = 41;
    
    public static final int ConstraintOverride_flow_horizontalStyle = 42;
    
    public static final int ConstraintOverride_flow_lastHorizontalBias = 43;
    
    public static final int ConstraintOverride_flow_lastHorizontalStyle = 44;
    
    public static final int ConstraintOverride_flow_lastVerticalBias = 45;
    
    public static final int ConstraintOverride_flow_lastVerticalStyle = 46;
    
    public static final int ConstraintOverride_flow_maxElementsWrap = 47;
    
    public static final int ConstraintOverride_flow_verticalAlign = 48;
    
    public static final int ConstraintOverride_flow_verticalBias = 49;
    
    public static final int ConstraintOverride_flow_verticalGap = 50;
    
    public static final int ConstraintOverride_flow_verticalStyle = 51;
    
    public static final int ConstraintOverride_flow_wrapMode = 52;
    
    public static final int ConstraintOverride_layout_constrainedHeight = 53;
    
    public static final int ConstraintOverride_layout_constrainedWidth = 54;
    
    public static final int ConstraintOverride_layout_constraintBaseline_creator = 55;
    
    public static final int ConstraintOverride_layout_constraintBottom_creator = 56;
    
    public static final int ConstraintOverride_layout_constraintCircleAngle = 57;
    
    public static final int ConstraintOverride_layout_constraintCircleRadius = 58;
    
    public static final int ConstraintOverride_layout_constraintDimensionRatio = 59;
    
    public static final int ConstraintOverride_layout_constraintGuide_begin = 60;
    
    public static final int ConstraintOverride_layout_constraintGuide_end = 61;
    
    public static final int ConstraintOverride_layout_constraintGuide_percent = 62;
    
    public static final int ConstraintOverride_layout_constraintHeight = 63;
    
    public static final int ConstraintOverride_layout_constraintHeight_default = 64;
    
    public static final int ConstraintOverride_layout_constraintHeight_max = 65;
    
    public static final int ConstraintOverride_layout_constraintHeight_min = 66;
    
    public static final int ConstraintOverride_layout_constraintHeight_percent = 67;
    
    public static final int ConstraintOverride_layout_constraintHorizontal_bias = 68;
    
    public static final int ConstraintOverride_layout_constraintHorizontal_chainStyle = 69;
    
    public static final int ConstraintOverride_layout_constraintHorizontal_weight = 70;
    
    public static final int ConstraintOverride_layout_constraintLeft_creator = 71;
    
    public static final int ConstraintOverride_layout_constraintRight_creator = 72;
    
    public static final int ConstraintOverride_layout_constraintTag = 73;
    
    public static final int ConstraintOverride_layout_constraintTop_creator = 74;
    
    public static final int ConstraintOverride_layout_constraintVertical_bias = 75;
    
    public static final int ConstraintOverride_layout_constraintVertical_chainStyle = 76;
    
    public static final int ConstraintOverride_layout_constraintVertical_weight = 77;
    
    public static final int ConstraintOverride_layout_constraintWidth = 78;
    
    public static final int ConstraintOverride_layout_constraintWidth_default = 79;
    
    public static final int ConstraintOverride_layout_constraintWidth_max = 80;
    
    public static final int ConstraintOverride_layout_constraintWidth_min = 81;
    
    public static final int ConstraintOverride_layout_constraintWidth_percent = 82;
    
    public static final int ConstraintOverride_layout_editor_absoluteX = 83;
    
    public static final int ConstraintOverride_layout_editor_absoluteY = 84;
    
    public static final int ConstraintOverride_layout_goneMarginBaseline = 85;
    
    public static final int ConstraintOverride_layout_goneMarginBottom = 86;
    
    public static final int ConstraintOverride_layout_goneMarginEnd = 87;
    
    public static final int ConstraintOverride_layout_goneMarginLeft = 88;
    
    public static final int ConstraintOverride_layout_goneMarginRight = 89;
    
    public static final int ConstraintOverride_layout_goneMarginStart = 90;
    
    public static final int ConstraintOverride_layout_goneMarginTop = 91;
    
    public static final int ConstraintOverride_layout_marginBaseline = 92;
    
    public static final int ConstraintOverride_layout_wrapBehaviorInParent = 93;
    
    public static final int ConstraintOverride_motionProgress = 94;
    
    public static final int ConstraintOverride_motionStagger = 95;
    
    public static final int ConstraintOverride_motionTarget = 96;
    
    public static final int ConstraintOverride_pathMotionArc = 97;
    
    public static final int ConstraintOverride_pivotAnchor = 98;
    
    public static final int ConstraintOverride_polarRelativeTo = 99;
    
    public static final int ConstraintOverride_quantizeMotionInterpolator = 100;
    
    public static final int ConstraintOverride_quantizeMotionPhase = 101;
    
    public static final int ConstraintOverride_quantizeMotionSteps = 102;
    
    public static final int ConstraintOverride_transformPivotTarget = 103;
    
    public static final int ConstraintOverride_transitionEasing = 104;
    
    public static final int ConstraintOverride_transitionPathRotate = 105;
    
    public static final int ConstraintOverride_visibilityMode = 106;
    
    public static final int[] ConstraintSet = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843189, 16843190, 16843551, 16843552, 16843553, 16843554, 16843555, 
        16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130903040, 
        2130903127, 2130903128, 2130903148, 2130903149, 2130903150, 2130903187, 2130903231, 2130903232, 2130903269, 2130903281, 
        2130903306, 2130903307, 2130903308, 2130903309, 2130903310, 2130903311, 2130903312, 2130903313, 2130903314, 2130903315, 
        2130903316, 2130903317, 2130903318, 2130903320, 2130903321, 2130903322, 2130903323, 2130903324, 2130903374, 2130903375, 
        2130903376, 2130903377, 2130903378, 2130903379, 2130903380, 2130903381, 2130903382, 2130903383, 2130903384, 2130903385, 
        2130903386, 2130903387, 2130903388, 2130903389, 2130903390, 2130903391, 2130903393, 2130903394, 2130903395, 2130903396, 
        2130903397, 2130903398, 2130903399, 2130903400, 2130903401, 2130903402, 2130903403, 2130903404, 2130903405, 2130903406, 
        2130903407, 2130903408, 2130903409, 2130903410, 2130903411, 2130903412, 2130903413, 2130903414, 2130903416, 2130903417, 
        2130903418, 2130903419, 2130903421, 2130903422, 2130903423, 2130903424, 2130903425, 2130903426, 2130903427, 2130903428, 
        2130903429, 2130903432, 2130903434, 2130903487, 2130903488, 2130903516, 2130903523, 2130903525, 2130903534, 2130903662, 
        2130903664 };
    
    public static final int ConstraintSet_ConstraintRotate = 29;
    
    public static final int ConstraintSet_android_alpha = 15;
    
    public static final int ConstraintSet_android_elevation = 28;
    
    public static final int ConstraintSet_android_id = 1;
    
    public static final int ConstraintSet_android_layout_height = 4;
    
    public static final int ConstraintSet_android_layout_marginBottom = 8;
    
    public static final int ConstraintSet_android_layout_marginEnd = 26;
    
    public static final int ConstraintSet_android_layout_marginLeft = 5;
    
    public static final int ConstraintSet_android_layout_marginRight = 7;
    
    public static final int ConstraintSet_android_layout_marginStart = 25;
    
    public static final int ConstraintSet_android_layout_marginTop = 6;
    
    public static final int ConstraintSet_android_layout_width = 3;
    
    public static final int ConstraintSet_android_maxHeight = 10;
    
    public static final int ConstraintSet_android_maxWidth = 9;
    
    public static final int ConstraintSet_android_minHeight = 12;
    
    public static final int ConstraintSet_android_minWidth = 11;
    
    public static final int ConstraintSet_android_orientation = 0;
    
    public static final int ConstraintSet_android_pivotX = 13;
    
    public static final int ConstraintSet_android_pivotY = 14;
    
    public static final int ConstraintSet_android_rotation = 22;
    
    public static final int ConstraintSet_android_rotationX = 23;
    
    public static final int ConstraintSet_android_rotationY = 24;
    
    public static final int ConstraintSet_android_scaleX = 20;
    
    public static final int ConstraintSet_android_scaleY = 21;
    
    public static final int ConstraintSet_android_transformPivotX = 16;
    
    public static final int ConstraintSet_android_transformPivotY = 17;
    
    public static final int ConstraintSet_android_translationX = 18;
    
    public static final int ConstraintSet_android_translationY = 19;
    
    public static final int ConstraintSet_android_translationZ = 27;
    
    public static final int ConstraintSet_android_visibility = 2;
    
    public static final int ConstraintSet_animateCircleAngleTo = 30;
    
    public static final int ConstraintSet_animateRelativeTo = 31;
    
    public static final int ConstraintSet_barrierAllowsGoneWidgets = 32;
    
    public static final int ConstraintSet_barrierDirection = 33;
    
    public static final int ConstraintSet_barrierMargin = 34;
    
    public static final int ConstraintSet_chainUseRtl = 35;
    
    public static final int ConstraintSet_constraint_referenced_ids = 36;
    
    public static final int ConstraintSet_constraint_referenced_tags = 37;
    
    public static final int ConstraintSet_deriveConstraintsFrom = 38;
    
    public static final int ConstraintSet_drawPath = 39;
    
    public static final int ConstraintSet_flow_firstHorizontalBias = 40;
    
    public static final int ConstraintSet_flow_firstHorizontalStyle = 41;
    
    public static final int ConstraintSet_flow_firstVerticalBias = 42;
    
    public static final int ConstraintSet_flow_firstVerticalStyle = 43;
    
    public static final int ConstraintSet_flow_horizontalAlign = 44;
    
    public static final int ConstraintSet_flow_horizontalBias = 45;
    
    public static final int ConstraintSet_flow_horizontalGap = 46;
    
    public static final int ConstraintSet_flow_horizontalStyle = 47;
    
    public static final int ConstraintSet_flow_lastHorizontalBias = 48;
    
    public static final int ConstraintSet_flow_lastHorizontalStyle = 49;
    
    public static final int ConstraintSet_flow_lastVerticalBias = 50;
    
    public static final int ConstraintSet_flow_lastVerticalStyle = 51;
    
    public static final int ConstraintSet_flow_maxElementsWrap = 52;
    
    public static final int ConstraintSet_flow_verticalAlign = 53;
    
    public static final int ConstraintSet_flow_verticalBias = 54;
    
    public static final int ConstraintSet_flow_verticalGap = 55;
    
    public static final int ConstraintSet_flow_verticalStyle = 56;
    
    public static final int ConstraintSet_flow_wrapMode = 57;
    
    public static final int ConstraintSet_layout_constrainedHeight = 58;
    
    public static final int ConstraintSet_layout_constrainedWidth = 59;
    
    public static final int ConstraintSet_layout_constraintBaseline_creator = 60;
    
    public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 61;
    
    public static final int ConstraintSet_layout_constraintBaseline_toBottomOf = 62;
    
    public static final int ConstraintSet_layout_constraintBaseline_toTopOf = 63;
    
    public static final int ConstraintSet_layout_constraintBottom_creator = 64;
    
    public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 65;
    
    public static final int ConstraintSet_layout_constraintBottom_toTopOf = 66;
    
    public static final int ConstraintSet_layout_constraintCircle = 67;
    
    public static final int ConstraintSet_layout_constraintCircleAngle = 68;
    
    public static final int ConstraintSet_layout_constraintCircleRadius = 69;
    
    public static final int ConstraintSet_layout_constraintDimensionRatio = 70;
    
    public static final int ConstraintSet_layout_constraintEnd_toEndOf = 71;
    
    public static final int ConstraintSet_layout_constraintEnd_toStartOf = 72;
    
    public static final int ConstraintSet_layout_constraintGuide_begin = 73;
    
    public static final int ConstraintSet_layout_constraintGuide_end = 74;
    
    public static final int ConstraintSet_layout_constraintGuide_percent = 75;
    
    public static final int ConstraintSet_layout_constraintHeight_default = 76;
    
    public static final int ConstraintSet_layout_constraintHeight_max = 77;
    
    public static final int ConstraintSet_layout_constraintHeight_min = 78;
    
    public static final int ConstraintSet_layout_constraintHeight_percent = 79;
    
    public static final int ConstraintSet_layout_constraintHorizontal_bias = 80;
    
    public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 81;
    
    public static final int ConstraintSet_layout_constraintHorizontal_weight = 82;
    
    public static final int ConstraintSet_layout_constraintLeft_creator = 83;
    
    public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 84;
    
    public static final int ConstraintSet_layout_constraintLeft_toRightOf = 85;
    
    public static final int ConstraintSet_layout_constraintRight_creator = 86;
    
    public static final int ConstraintSet_layout_constraintRight_toLeftOf = 87;
    
    public static final int ConstraintSet_layout_constraintRight_toRightOf = 88;
    
    public static final int ConstraintSet_layout_constraintStart_toEndOf = 89;
    
    public static final int ConstraintSet_layout_constraintStart_toStartOf = 90;
    
    public static final int ConstraintSet_layout_constraintTag = 91;
    
    public static final int ConstraintSet_layout_constraintTop_creator = 92;
    
    public static final int ConstraintSet_layout_constraintTop_toBottomOf = 93;
    
    public static final int ConstraintSet_layout_constraintTop_toTopOf = 94;
    
    public static final int ConstraintSet_layout_constraintVertical_bias = 95;
    
    public static final int ConstraintSet_layout_constraintVertical_chainStyle = 96;
    
    public static final int ConstraintSet_layout_constraintVertical_weight = 97;
    
    public static final int ConstraintSet_layout_constraintWidth_default = 98;
    
    public static final int ConstraintSet_layout_constraintWidth_max = 99;
    
    public static final int ConstraintSet_layout_constraintWidth_min = 100;
    
    public static final int ConstraintSet_layout_constraintWidth_percent = 101;
    
    public static final int ConstraintSet_layout_editor_absoluteX = 102;
    
    public static final int ConstraintSet_layout_editor_absoluteY = 103;
    
    public static final int ConstraintSet_layout_goneMarginBaseline = 104;
    
    public static final int ConstraintSet_layout_goneMarginBottom = 105;
    
    public static final int ConstraintSet_layout_goneMarginEnd = 106;
    
    public static final int ConstraintSet_layout_goneMarginLeft = 107;
    
    public static final int ConstraintSet_layout_goneMarginRight = 108;
    
    public static final int ConstraintSet_layout_goneMarginStart = 109;
    
    public static final int ConstraintSet_layout_goneMarginTop = 110;
    
    public static final int ConstraintSet_layout_marginBaseline = 111;
    
    public static final int ConstraintSet_layout_wrapBehaviorInParent = 112;
    
    public static final int ConstraintSet_motionProgress = 113;
    
    public static final int ConstraintSet_motionStagger = 114;
    
    public static final int ConstraintSet_pathMotionArc = 115;
    
    public static final int ConstraintSet_pivotAnchor = 116;
    
    public static final int ConstraintSet_polarRelativeTo = 117;
    
    public static final int ConstraintSet_quantizeMotionSteps = 118;
    
    public static final int ConstraintSet_transitionEasing = 119;
    
    public static final int ConstraintSet_transitionPathRotate = 120;
    
    public static final int Constraint_android_alpha = 13;
    
    public static final int Constraint_android_elevation = 26;
    
    public static final int Constraint_android_id = 1;
    
    public static final int Constraint_android_layout_height = 4;
    
    public static final int Constraint_android_layout_marginBottom = 8;
    
    public static final int Constraint_android_layout_marginEnd = 24;
    
    public static final int Constraint_android_layout_marginLeft = 5;
    
    public static final int Constraint_android_layout_marginRight = 7;
    
    public static final int Constraint_android_layout_marginStart = 23;
    
    public static final int Constraint_android_layout_marginTop = 6;
    
    public static final int Constraint_android_layout_width = 3;
    
    public static final int Constraint_android_maxHeight = 10;
    
    public static final int Constraint_android_maxWidth = 9;
    
    public static final int Constraint_android_minHeight = 12;
    
    public static final int Constraint_android_minWidth = 11;
    
    public static final int Constraint_android_orientation = 0;
    
    public static final int Constraint_android_rotation = 20;
    
    public static final int Constraint_android_rotationX = 21;
    
    public static final int Constraint_android_rotationY = 22;
    
    public static final int Constraint_android_scaleX = 18;
    
    public static final int Constraint_android_scaleY = 19;
    
    public static final int Constraint_android_transformPivotX = 14;
    
    public static final int Constraint_android_transformPivotY = 15;
    
    public static final int Constraint_android_translationX = 16;
    
    public static final int Constraint_android_translationY = 17;
    
    public static final int Constraint_android_translationZ = 25;
    
    public static final int Constraint_android_visibility = 2;
    
    public static final int Constraint_animateCircleAngleTo = 27;
    
    public static final int Constraint_animateRelativeTo = 28;
    
    public static final int Constraint_barrierAllowsGoneWidgets = 29;
    
    public static final int Constraint_barrierDirection = 30;
    
    public static final int Constraint_barrierMargin = 31;
    
    public static final int Constraint_chainUseRtl = 32;
    
    public static final int Constraint_constraint_referenced_ids = 33;
    
    public static final int Constraint_constraint_referenced_tags = 34;
    
    public static final int Constraint_drawPath = 35;
    
    public static final int Constraint_flow_firstHorizontalBias = 36;
    
    public static final int Constraint_flow_firstHorizontalStyle = 37;
    
    public static final int Constraint_flow_firstVerticalBias = 38;
    
    public static final int Constraint_flow_firstVerticalStyle = 39;
    
    public static final int Constraint_flow_horizontalAlign = 40;
    
    public static final int Constraint_flow_horizontalBias = 41;
    
    public static final int Constraint_flow_horizontalGap = 42;
    
    public static final int Constraint_flow_horizontalStyle = 43;
    
    public static final int Constraint_flow_lastHorizontalBias = 44;
    
    public static final int Constraint_flow_lastHorizontalStyle = 45;
    
    public static final int Constraint_flow_lastVerticalBias = 46;
    
    public static final int Constraint_flow_lastVerticalStyle = 47;
    
    public static final int Constraint_flow_maxElementsWrap = 48;
    
    public static final int Constraint_flow_verticalAlign = 49;
    
    public static final int Constraint_flow_verticalBias = 50;
    
    public static final int Constraint_flow_verticalGap = 51;
    
    public static final int Constraint_flow_verticalStyle = 52;
    
    public static final int Constraint_flow_wrapMode = 53;
    
    public static final int Constraint_layout_constrainedHeight = 54;
    
    public static final int Constraint_layout_constrainedWidth = 55;
    
    public static final int Constraint_layout_constraintBaseline_creator = 56;
    
    public static final int Constraint_layout_constraintBaseline_toBaselineOf = 57;
    
    public static final int Constraint_layout_constraintBaseline_toBottomOf = 58;
    
    public static final int Constraint_layout_constraintBaseline_toTopOf = 59;
    
    public static final int Constraint_layout_constraintBottom_creator = 60;
    
    public static final int Constraint_layout_constraintBottom_toBottomOf = 61;
    
    public static final int Constraint_layout_constraintBottom_toTopOf = 62;
    
    public static final int Constraint_layout_constraintCircle = 63;
    
    public static final int Constraint_layout_constraintCircleAngle = 64;
    
    public static final int Constraint_layout_constraintCircleRadius = 65;
    
    public static final int Constraint_layout_constraintDimensionRatio = 66;
    
    public static final int Constraint_layout_constraintEnd_toEndOf = 67;
    
    public static final int Constraint_layout_constraintEnd_toStartOf = 68;
    
    public static final int Constraint_layout_constraintGuide_begin = 69;
    
    public static final int Constraint_layout_constraintGuide_end = 70;
    
    public static final int Constraint_layout_constraintGuide_percent = 71;
    
    public static final int Constraint_layout_constraintHeight = 72;
    
    public static final int Constraint_layout_constraintHeight_default = 73;
    
    public static final int Constraint_layout_constraintHeight_max = 74;
    
    public static final int Constraint_layout_constraintHeight_min = 75;
    
    public static final int Constraint_layout_constraintHeight_percent = 76;
    
    public static final int Constraint_layout_constraintHorizontal_bias = 77;
    
    public static final int Constraint_layout_constraintHorizontal_chainStyle = 78;
    
    public static final int Constraint_layout_constraintHorizontal_weight = 79;
    
    public static final int Constraint_layout_constraintLeft_creator = 80;
    
    public static final int Constraint_layout_constraintLeft_toLeftOf = 81;
    
    public static final int Constraint_layout_constraintLeft_toRightOf = 82;
    
    public static final int Constraint_layout_constraintRight_creator = 83;
    
    public static final int Constraint_layout_constraintRight_toLeftOf = 84;
    
    public static final int Constraint_layout_constraintRight_toRightOf = 85;
    
    public static final int Constraint_layout_constraintStart_toEndOf = 86;
    
    public static final int Constraint_layout_constraintStart_toStartOf = 87;
    
    public static final int Constraint_layout_constraintTag = 88;
    
    public static final int Constraint_layout_constraintTop_creator = 89;
    
    public static final int Constraint_layout_constraintTop_toBottomOf = 90;
    
    public static final int Constraint_layout_constraintTop_toTopOf = 91;
    
    public static final int Constraint_layout_constraintVertical_bias = 92;
    
    public static final int Constraint_layout_constraintVertical_chainStyle = 93;
    
    public static final int Constraint_layout_constraintVertical_weight = 94;
    
    public static final int Constraint_layout_constraintWidth = 95;
    
    public static final int Constraint_layout_constraintWidth_default = 96;
    
    public static final int Constraint_layout_constraintWidth_max = 97;
    
    public static final int Constraint_layout_constraintWidth_min = 98;
    
    public static final int Constraint_layout_constraintWidth_percent = 99;
    
    public static final int Constraint_layout_editor_absoluteX = 100;
    
    public static final int Constraint_layout_editor_absoluteY = 101;
    
    public static final int Constraint_layout_goneMarginBaseline = 102;
    
    public static final int Constraint_layout_goneMarginBottom = 103;
    
    public static final int Constraint_layout_goneMarginEnd = 104;
    
    public static final int Constraint_layout_goneMarginLeft = 105;
    
    public static final int Constraint_layout_goneMarginRight = 106;
    
    public static final int Constraint_layout_goneMarginStart = 107;
    
    public static final int Constraint_layout_goneMarginTop = 108;
    
    public static final int Constraint_layout_marginBaseline = 109;
    
    public static final int Constraint_layout_wrapBehaviorInParent = 110;
    
    public static final int Constraint_motionProgress = 111;
    
    public static final int Constraint_motionStagger = 112;
    
    public static final int Constraint_pathMotionArc = 113;
    
    public static final int Constraint_pivotAnchor = 114;
    
    public static final int Constraint_polarRelativeTo = 115;
    
    public static final int Constraint_quantizeMotionInterpolator = 116;
    
    public static final int Constraint_quantizeMotionPhase = 117;
    
    public static final int Constraint_quantizeMotionSteps = 118;
    
    public static final int Constraint_transformPivotTarget = 119;
    
    public static final int Constraint_transitionEasing = 120;
    
    public static final int Constraint_transitionPathRotate = 121;
    
    public static final int Constraint_visibilityMode = 122;
    
    public static final int[] CustomAttribute = new int[] { 
        2130903133, 2130903254, 2130903255, 2130903256, 2130903257, 2130903258, 2130903259, 2130903261, 2130903262, 2130903263, 
        2130903467 };
    
    public static final int CustomAttribute_attributeName = 0;
    
    public static final int CustomAttribute_customBoolean = 1;
    
    public static final int CustomAttribute_customColorDrawableValue = 2;
    
    public static final int CustomAttribute_customColorValue = 3;
    
    public static final int CustomAttribute_customDimension = 4;
    
    public static final int CustomAttribute_customFloatValue = 5;
    
    public static final int CustomAttribute_customIntegerValue = 6;
    
    public static final int CustomAttribute_customPixelDimension = 7;
    
    public static final int CustomAttribute_customReference = 8;
    
    public static final int CustomAttribute_customStringValue = 9;
    
    public static final int CustomAttribute_methodName = 10;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130903131, 2130903132, 2130903147, 2130903203, 2130903286, 2130903338, 2130903574, 2130903630 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130903327, 2130903328, 2130903329, 2130903330, 2130903331, 2130903332, 2130903333 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903325, 2130903334, 2130903335, 2130903336, 2130903668 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] ImageFilterView = new int[] { 
        2130903126, 2130903151, 2130903155, 2130903247, 2130903251, 2130903355, 2130903356, 2130903357, 2130903358, 2130903508, 
        2130903553, 2130903554, 2130903555, 2130903677 };
    
    public static final int ImageFilterView_altSrc = 0;
    
    public static final int ImageFilterView_blendSrc = 1;
    
    public static final int ImageFilterView_brightness = 2;
    
    public static final int ImageFilterView_contrast = 3;
    
    public static final int ImageFilterView_crossfade = 4;
    
    public static final int ImageFilterView_imagePanX = 5;
    
    public static final int ImageFilterView_imagePanY = 6;
    
    public static final int ImageFilterView_imageRotate = 7;
    
    public static final int ImageFilterView_imageZoom = 8;
    
    public static final int ImageFilterView_overlay = 9;
    
    public static final int ImageFilterView_round = 10;
    
    public static final int ImageFilterView_roundPercent = 11;
    
    public static final int ImageFilterView_saturation = 12;
    
    public static final int ImageFilterView_warmth = 13;
    
    public static final int[] KeyAttribute = new int[] { 
        16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 
        16843770, 16843840, 2130903253, 2130903337, 2130903487, 2130903489, 2130903660, 2130903662, 2130903664 };
    
    public static final int KeyAttribute_android_alpha = 0;
    
    public static final int KeyAttribute_android_elevation = 11;
    
    public static final int KeyAttribute_android_rotation = 7;
    
    public static final int KeyAttribute_android_rotationX = 8;
    
    public static final int KeyAttribute_android_rotationY = 9;
    
    public static final int KeyAttribute_android_scaleX = 5;
    
    public static final int KeyAttribute_android_scaleY = 6;
    
    public static final int KeyAttribute_android_transformPivotX = 1;
    
    public static final int KeyAttribute_android_transformPivotY = 2;
    
    public static final int KeyAttribute_android_translationX = 3;
    
    public static final int KeyAttribute_android_translationY = 4;
    
    public static final int KeyAttribute_android_translationZ = 10;
    
    public static final int KeyAttribute_curveFit = 12;
    
    public static final int KeyAttribute_framePosition = 13;
    
    public static final int KeyAttribute_motionProgress = 14;
    
    public static final int KeyAttribute_motionTarget = 15;
    
    public static final int KeyAttribute_transformPivotTarget = 16;
    
    public static final int KeyAttribute_transitionEasing = 17;
    
    public static final int KeyAttribute_transitionPathRotate = 18;
    
    public static final int[] KeyCycle = new int[] { 
        16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, 
        2130903253, 2130903337, 2130903487, 2130903489, 2130903662, 2130903664, 2130903679, 2130903680, 2130903681, 2130903682, 
        2130903683 };
    
    public static final int KeyCycle_android_alpha = 0;
    
    public static final int KeyCycle_android_elevation = 9;
    
    public static final int KeyCycle_android_rotation = 5;
    
    public static final int KeyCycle_android_rotationX = 6;
    
    public static final int KeyCycle_android_rotationY = 7;
    
    public static final int KeyCycle_android_scaleX = 3;
    
    public static final int KeyCycle_android_scaleY = 4;
    
    public static final int KeyCycle_android_translationX = 1;
    
    public static final int KeyCycle_android_translationY = 2;
    
    public static final int KeyCycle_android_translationZ = 8;
    
    public static final int KeyCycle_curveFit = 10;
    
    public static final int KeyCycle_framePosition = 11;
    
    public static final int KeyCycle_motionProgress = 12;
    
    public static final int KeyCycle_motionTarget = 13;
    
    public static final int KeyCycle_transitionEasing = 14;
    
    public static final int KeyCycle_transitionPathRotate = 15;
    
    public static final int KeyCycle_waveOffset = 16;
    
    public static final int KeyCycle_wavePeriod = 17;
    
    public static final int KeyCycle_wavePhase = 18;
    
    public static final int KeyCycle_waveShape = 19;
    
    public static final int KeyCycle_waveVariesBy = 20;
    
    public static final int[] KeyFrame = new int[0];
    
    public static final int[] KeyFramesAcceleration = new int[0];
    
    public static final int[] KeyFramesVelocity = new int[0];
    
    public static final int[] KeyPosition = new int[] { 
        2130903253, 2130903281, 2130903337, 2130903363, 2130903489, 2130903516, 2130903518, 2130903519, 2130903520, 2130903521, 
        2130903572, 2130903662 };
    
    public static final int KeyPosition_curveFit = 0;
    
    public static final int KeyPosition_drawPath = 1;
    
    public static final int KeyPosition_framePosition = 2;
    
    public static final int KeyPosition_keyPositionType = 3;
    
    public static final int KeyPosition_motionTarget = 4;
    
    public static final int KeyPosition_pathMotionArc = 5;
    
    public static final int KeyPosition_percentHeight = 6;
    
    public static final int KeyPosition_percentWidth = 7;
    
    public static final int KeyPosition_percentX = 8;
    
    public static final int KeyPosition_percentY = 9;
    
    public static final int KeyPosition_sizePercent = 10;
    
    public static final int KeyPosition_transitionEasing = 11;
    
    public static final int[] KeyTimeCycle = new int[] { 
        16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, 
        2130903253, 2130903337, 2130903487, 2130903489, 2130903662, 2130903664, 2130903678, 2130903679, 2130903680, 2130903681, 
        2130903682 };
    
    public static final int KeyTimeCycle_android_alpha = 0;
    
    public static final int KeyTimeCycle_android_elevation = 9;
    
    public static final int KeyTimeCycle_android_rotation = 5;
    
    public static final int KeyTimeCycle_android_rotationX = 6;
    
    public static final int KeyTimeCycle_android_rotationY = 7;
    
    public static final int KeyTimeCycle_android_scaleX = 3;
    
    public static final int KeyTimeCycle_android_scaleY = 4;
    
    public static final int KeyTimeCycle_android_translationX = 1;
    
    public static final int KeyTimeCycle_android_translationY = 2;
    
    public static final int KeyTimeCycle_android_translationZ = 8;
    
    public static final int KeyTimeCycle_curveFit = 10;
    
    public static final int KeyTimeCycle_framePosition = 11;
    
    public static final int KeyTimeCycle_motionProgress = 12;
    
    public static final int KeyTimeCycle_motionTarget = 13;
    
    public static final int KeyTimeCycle_transitionEasing = 14;
    
    public static final int KeyTimeCycle_transitionPathRotate = 15;
    
    public static final int KeyTimeCycle_waveDecay = 16;
    
    public static final int KeyTimeCycle_waveOffset = 17;
    
    public static final int KeyTimeCycle_wavePeriod = 18;
    
    public static final int KeyTimeCycle_wavePhase = 19;
    
    public static final int KeyTimeCycle_waveShape = 20;
    
    public static final int[] KeyTrigger = new int[] { 
        2130903337, 2130903489, 2130903490, 2130903491, 2130903500, 2130903502, 2130903503, 2130903665, 2130903666, 2130903667, 
        2130903672, 2130903673, 2130903674 };
    
    public static final int KeyTrigger_framePosition = 0;
    
    public static final int KeyTrigger_motionTarget = 1;
    
    public static final int KeyTrigger_motion_postLayoutCollision = 2;
    
    public static final int KeyTrigger_motion_triggerOnCollision = 3;
    
    public static final int KeyTrigger_onCross = 4;
    
    public static final int KeyTrigger_onNegativeCross = 5;
    
    public static final int KeyTrigger_onPositiveCross = 6;
    
    public static final int KeyTrigger_triggerId = 7;
    
    public static final int KeyTrigger_triggerReceiver = 8;
    
    public static final int KeyTrigger_triggerSlack = 9;
    
    public static final int KeyTrigger_viewTransitionOnCross = 10;
    
    public static final int KeyTrigger_viewTransitionOnNegativeCross = 11;
    
    public static final int KeyTrigger_viewTransitionOnPositiveCross = 12;
    
    public static final int[] Layout = new int[] { 
        16842948, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843701, 16843702, 2130903148, 
        2130903149, 2130903150, 2130903187, 2130903231, 2130903232, 2130903374, 2130903375, 2130903376, 2130903377, 2130903378, 
        2130903379, 2130903380, 2130903381, 2130903382, 2130903383, 2130903384, 2130903385, 2130903386, 2130903387, 2130903388, 
        2130903389, 2130903390, 2130903391, 2130903392, 2130903393, 2130903394, 2130903395, 2130903396, 2130903397, 2130903398, 
        2130903399, 2130903400, 2130903401, 2130903402, 2130903403, 2130903404, 2130903405, 2130903406, 2130903407, 2130903409, 
        2130903410, 2130903411, 2130903412, 2130903413, 2130903414, 2130903415, 2130903416, 2130903417, 2130903418, 2130903419, 
        2130903421, 2130903422, 2130903423, 2130903424, 2130903425, 2130903426, 2130903427, 2130903428, 2130903429, 2130903432, 
        2130903434, 2130903456, 2130903458, 2130903468, 2130903469 };
    
    public static final int Layout_android_layout_height = 2;
    
    public static final int Layout_android_layout_marginBottom = 6;
    
    public static final int Layout_android_layout_marginEnd = 8;
    
    public static final int Layout_android_layout_marginLeft = 3;
    
    public static final int Layout_android_layout_marginRight = 5;
    
    public static final int Layout_android_layout_marginStart = 7;
    
    public static final int Layout_android_layout_marginTop = 4;
    
    public static final int Layout_android_layout_width = 1;
    
    public static final int Layout_android_orientation = 0;
    
    public static final int Layout_barrierAllowsGoneWidgets = 9;
    
    public static final int Layout_barrierDirection = 10;
    
    public static final int Layout_barrierMargin = 11;
    
    public static final int Layout_chainUseRtl = 12;
    
    public static final int Layout_constraint_referenced_ids = 13;
    
    public static final int Layout_constraint_referenced_tags = 14;
    
    public static final int Layout_layout_constrainedHeight = 15;
    
    public static final int Layout_layout_constrainedWidth = 16;
    
    public static final int Layout_layout_constraintBaseline_creator = 17;
    
    public static final int Layout_layout_constraintBaseline_toBaselineOf = 18;
    
    public static final int Layout_layout_constraintBaseline_toBottomOf = 19;
    
    public static final int Layout_layout_constraintBaseline_toTopOf = 20;
    
    public static final int Layout_layout_constraintBottom_creator = 21;
    
    public static final int Layout_layout_constraintBottom_toBottomOf = 22;
    
    public static final int Layout_layout_constraintBottom_toTopOf = 23;
    
    public static final int Layout_layout_constraintCircle = 24;
    
    public static final int Layout_layout_constraintCircleAngle = 25;
    
    public static final int Layout_layout_constraintCircleRadius = 26;
    
    public static final int Layout_layout_constraintDimensionRatio = 27;
    
    public static final int Layout_layout_constraintEnd_toEndOf = 28;
    
    public static final int Layout_layout_constraintEnd_toStartOf = 29;
    
    public static final int Layout_layout_constraintGuide_begin = 30;
    
    public static final int Layout_layout_constraintGuide_end = 31;
    
    public static final int Layout_layout_constraintGuide_percent = 32;
    
    public static final int Layout_layout_constraintHeight = 33;
    
    public static final int Layout_layout_constraintHeight_default = 34;
    
    public static final int Layout_layout_constraintHeight_max = 35;
    
    public static final int Layout_layout_constraintHeight_min = 36;
    
    public static final int Layout_layout_constraintHeight_percent = 37;
    
    public static final int Layout_layout_constraintHorizontal_bias = 38;
    
    public static final int Layout_layout_constraintHorizontal_chainStyle = 39;
    
    public static final int Layout_layout_constraintHorizontal_weight = 40;
    
    public static final int Layout_layout_constraintLeft_creator = 41;
    
    public static final int Layout_layout_constraintLeft_toLeftOf = 42;
    
    public static final int Layout_layout_constraintLeft_toRightOf = 43;
    
    public static final int Layout_layout_constraintRight_creator = 44;
    
    public static final int Layout_layout_constraintRight_toLeftOf = 45;
    
    public static final int Layout_layout_constraintRight_toRightOf = 46;
    
    public static final int Layout_layout_constraintStart_toEndOf = 47;
    
    public static final int Layout_layout_constraintStart_toStartOf = 48;
    
    public static final int Layout_layout_constraintTop_creator = 49;
    
    public static final int Layout_layout_constraintTop_toBottomOf = 50;
    
    public static final int Layout_layout_constraintTop_toTopOf = 51;
    
    public static final int Layout_layout_constraintVertical_bias = 52;
    
    public static final int Layout_layout_constraintVertical_chainStyle = 53;
    
    public static final int Layout_layout_constraintVertical_weight = 54;
    
    public static final int Layout_layout_constraintWidth = 55;
    
    public static final int Layout_layout_constraintWidth_default = 56;
    
    public static final int Layout_layout_constraintWidth_max = 57;
    
    public static final int Layout_layout_constraintWidth_min = 58;
    
    public static final int Layout_layout_constraintWidth_percent = 59;
    
    public static final int Layout_layout_editor_absoluteX = 60;
    
    public static final int Layout_layout_editor_absoluteY = 61;
    
    public static final int Layout_layout_goneMarginBaseline = 62;
    
    public static final int Layout_layout_goneMarginBottom = 63;
    
    public static final int Layout_layout_goneMarginEnd = 64;
    
    public static final int Layout_layout_goneMarginLeft = 65;
    
    public static final int Layout_layout_goneMarginRight = 66;
    
    public static final int Layout_layout_goneMarginStart = 67;
    
    public static final int Layout_layout_goneMarginTop = 68;
    
    public static final int Layout_layout_marginBaseline = 69;
    
    public static final int Layout_layout_wrapBehaviorInParent = 70;
    
    public static final int Layout_maxHeight = 71;
    
    public static final int Layout_maxWidth = 72;
    
    public static final int Layout_minHeight = 73;
    
    public static final int Layout_minWidth = 74;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130903274, 2130903276, 2130903465, 2130903567 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130903056, 2130903074, 2130903075, 2130903125, 2130903235, 2130903347, 2130903348, 
        2130903499, 2130903566, 2130903653 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130903529, 2130903588 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] MockView = new int[] { 2130903470, 2130903471, 2130903472, 2130903473, 2130903474, 2130903475 };
    
    public static final int MockView_mock_diagonalsColor = 0;
    
    public static final int MockView_mock_label = 1;
    
    public static final int MockView_mock_labelBackgroundColor = 2;
    
    public static final int MockView_mock_labelColor = 3;
    
    public static final int MockView_mock_showDiagonals = 4;
    
    public static final int MockView_mock_showLabel = 5;
    
    public static final int[] Motion = new int[] { 2130903127, 2130903128, 2130903281, 2130903486, 2130903488, 2130903516, 2130903532, 2130903533, 2130903534, 2130903662 };
    
    public static final int[] MotionEffect = new int[] { 2130903477, 2130903478, 2130903479, 2130903480, 2130903481, 2130903482, 2130903483, 2130903484 };
    
    public static final int MotionEffect_motionEffect_alpha = 0;
    
    public static final int MotionEffect_motionEffect_end = 1;
    
    public static final int MotionEffect_motionEffect_move = 2;
    
    public static final int MotionEffect_motionEffect_start = 3;
    
    public static final int MotionEffect_motionEffect_strict = 4;
    
    public static final int MotionEffect_motionEffect_translationX = 5;
    
    public static final int MotionEffect_motionEffect_translationY = 6;
    
    public static final int MotionEffect_motionEffect_viewTransition = 7;
    
    public static final int[] MotionHelper = new int[] { 2130903501, 2130903504 };
    
    public static final int MotionHelper_onHide = 0;
    
    public static final int MotionHelper_onShow = 1;
    
    public static final int[] MotionLabel = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842927, 16843087, 16843108, 16843692, 16844085, 2130903152, 
        2130903153, 2130903556, 2130903612, 2130903613, 2130903614, 2130903615, 2130903616, 2130903621, 2130903622, 2130903623, 
        2130903624, 2130903625, 2130903626, 2130903627, 2130903628 };
    
    public static final int MotionLabel_android_autoSizeTextType = 8;
    
    public static final int MotionLabel_android_fontFamily = 7;
    
    public static final int MotionLabel_android_gravity = 4;
    
    public static final int MotionLabel_android_shadowRadius = 6;
    
    public static final int MotionLabel_android_text = 5;
    
    public static final int MotionLabel_android_textColor = 3;
    
    public static final int MotionLabel_android_textSize = 0;
    
    public static final int MotionLabel_android_textStyle = 2;
    
    public static final int MotionLabel_android_typeface = 1;
    
    public static final int MotionLabel_borderRound = 9;
    
    public static final int MotionLabel_borderRoundPercent = 10;
    
    public static final int MotionLabel_scaleFromTextSize = 11;
    
    public static final int MotionLabel_textBackground = 12;
    
    public static final int MotionLabel_textBackgroundPanX = 13;
    
    public static final int MotionLabel_textBackgroundPanY = 14;
    
    public static final int MotionLabel_textBackgroundRotate = 15;
    
    public static final int MotionLabel_textBackgroundZoom = 16;
    
    public static final int MotionLabel_textOutlineColor = 17;
    
    public static final int MotionLabel_textOutlineThickness = 18;
    
    public static final int MotionLabel_textPanX = 19;
    
    public static final int MotionLabel_textPanY = 20;
    
    public static final int MotionLabel_textureBlurFactor = 21;
    
    public static final int MotionLabel_textureEffect = 22;
    
    public static final int MotionLabel_textureHeight = 23;
    
    public static final int MotionLabel_textureWidth = 24;
    
    public static final int[] MotionLayout = new int[] { 2130903129, 2130903252, 2130903368, 2130903476, 2130903487, 2130903568 };
    
    public static final int MotionLayout_applyMotionScene = 0;
    
    public static final int MotionLayout_currentState = 1;
    
    public static final int MotionLayout_layoutDescription = 2;
    
    public static final int MotionLayout_motionDebug = 3;
    
    public static final int MotionLayout_motionProgress = 4;
    
    public static final int MotionLayout_showPaths = 5;
    
    public static final int[] MotionScene = new int[] { 2130903264, 2130903369 };
    
    public static final int MotionScene_defaultDuration = 0;
    
    public static final int MotionScene_layoutDuringTransition = 1;
    
    public static final int[] MotionTelltales = new int[] { 2130903600, 2130903601, 2130903602 };
    
    public static final int MotionTelltales_telltales_tailColor = 0;
    
    public static final int MotionTelltales_telltales_tailScale = 1;
    
    public static final int MotionTelltales_telltales_velocityMode = 2;
    
    public static final int Motion_animateCircleAngleTo = 0;
    
    public static final int Motion_animateRelativeTo = 1;
    
    public static final int Motion_drawPath = 2;
    
    public static final int Motion_motionPathRotate = 3;
    
    public static final int Motion_motionStagger = 4;
    
    public static final int Motion_pathMotionArc = 5;
    
    public static final int Motion_quantizeMotionInterpolator = 6;
    
    public static final int Motion_quantizeMotionPhase = 7;
    
    public static final int Motion_quantizeMotionSteps = 8;
    
    public static final int Motion_transitionEasing = 9;
    
    public static final int[] OnClick = new int[] { 2130903198, 2130903599 };
    
    public static final int OnClick_clickAction = 0;
    
    public static final int OnClick_targetId = 1;
    
    public static final int[] OnSwipe = new int[] { 
        2130903134, 2130903278, 2130903279, 2130903280, 2130903435, 2130903454, 2130903457, 2130903492, 2130903497, 2130903506, 
        2130903552, 2130903578, 2130903579, 2130903580, 2130903581, 2130903582, 2130903654, 2130903655, 2130903656 };
    
    public static final int OnSwipe_autoCompleteMode = 0;
    
    public static final int OnSwipe_dragDirection = 1;
    
    public static final int OnSwipe_dragScale = 2;
    
    public static final int OnSwipe_dragThreshold = 3;
    
    public static final int OnSwipe_limitBoundsTo = 4;
    
    public static final int OnSwipe_maxAcceleration = 5;
    
    public static final int OnSwipe_maxVelocity = 6;
    
    public static final int OnSwipe_moveWhenScrollAtTop = 7;
    
    public static final int OnSwipe_nestedScrollFlags = 8;
    
    public static final int OnSwipe_onTouchUp = 9;
    
    public static final int OnSwipe_rotationCenterId = 10;
    
    public static final int OnSwipe_springBoundary = 11;
    
    public static final int OnSwipe_springDamping = 12;
    
    public static final int OnSwipe_springMass = 13;
    
    public static final int OnSwipe_springStiffness = 14;
    
    public static final int OnSwipe_springStopThreshold = 15;
    
    public static final int OnSwipe_touchAnchorId = 16;
    
    public static final int OnSwipe_touchAnchorSide = 17;
    
    public static final int OnSwipe_touchRegionId = 18;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130903507 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130903586 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] PropertySet = new int[] { 16842972, 16843551, 2130903408, 2130903487, 2130903675 };
    
    public static final int PropertySet_android_alpha = 1;
    
    public static final int PropertySet_android_visibility = 0;
    
    public static final int PropertySet_layout_constraintTag = 2;
    
    public static final int PropertySet_motionProgress = 3;
    
    public static final int PropertySet_visibilityMode = 4;
    
    public static final int[] RecycleListView = new int[] { 2130903509, 2130903512 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130903199, 2130903227, 2130903265, 2130903339, 2130903349, 2130903367, 
        2130903535, 2130903536, 2130903558, 2130903559, 2130903589, 2130903594, 2130903676 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130903527 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] State = new int[] { 16842960, 2130903233 };
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] StateSet = new int[] { 2130903266 };
    
    public static final int StateSet_defaultState = 0;
    
    public static final int State_android_id = 0;
    
    public static final int State_constraints = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130903569, 2130903577, 2130903595, 2130903596, 2130903598, 2130903631, 2130903632, 
        2130903633, 2130903657, 2130903658, 2130903659 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130903326, 2130903335, 2130903603, 2130903620 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] TextEffects = new int[] { 
        16842901, 16842902, 16842903, 16843087, 16843105, 16843106, 16843107, 16843108, 16843692, 2130903152, 
        2130903153, 2130903619, 2130903621, 2130903622 };
    
    public static final int TextEffects_android_fontFamily = 8;
    
    public static final int TextEffects_android_shadowColor = 4;
    
    public static final int TextEffects_android_shadowDx = 5;
    
    public static final int TextEffects_android_shadowDy = 6;
    
    public static final int TextEffects_android_shadowRadius = 7;
    
    public static final int TextEffects_android_text = 3;
    
    public static final int TextEffects_android_textSize = 0;
    
    public static final int TextEffects_android_textStyle = 2;
    
    public static final int TextEffects_android_typeface = 1;
    
    public static final int TextEffects_borderRound = 9;
    
    public static final int TextEffects_borderRoundPercent = 10;
    
    public static final int TextEffects_textFillColor = 11;
    
    public static final int TextEffects_textOutlineColor = 12;
    
    public static final int TextEffects_textOutlineThickness = 13;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130903162, 2130903201, 2130903202, 2130903236, 2130903237, 2130903238, 2130903239, 2130903240, 
        2130903241, 2130903452, 2130903453, 2130903455, 2130903466, 2130903494, 2130903495, 2130903527, 2130903590, 2130903591, 
        2130903592, 2130903639, 2130903640, 2130903641, 2130903642, 2130903643, 2130903644, 2130903645, 2130903646, 2130903647 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] Transform = new int[] { 
        16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 
        16843840, 2130903660 };
    
    public static final int Transform_android_elevation = 10;
    
    public static final int Transform_android_rotation = 6;
    
    public static final int Transform_android_rotationX = 7;
    
    public static final int Transform_android_rotationY = 8;
    
    public static final int Transform_android_scaleX = 4;
    
    public static final int Transform_android_scaleY = 5;
    
    public static final int Transform_android_transformPivotX = 0;
    
    public static final int Transform_android_transformPivotY = 1;
    
    public static final int Transform_android_translationX = 2;
    
    public static final int Transform_android_translationY = 3;
    
    public static final int Transform_android_translationZ = 9;
    
    public static final int Transform_transformPivotTarget = 11;
    
    public static final int[] Transition = new int[] { 
        16842960, 2130903141, 2130903229, 2130903230, 2130903294, 2130903369, 2130903485, 2130903516, 2130903585, 2130903661, 
        2130903663 };
    
    public static final int Transition_android_id = 0;
    
    public static final int Transition_autoTransition = 1;
    
    public static final int Transition_constraintSetEnd = 2;
    
    public static final int Transition_constraintSetStart = 3;
    
    public static final int Transition_duration = 4;
    
    public static final int Transition_layoutDuringTransition = 5;
    
    public static final int Transition_motionInterpolator = 6;
    
    public static final int Transition_pathMotionArc = 7;
    
    public static final int Transition_staggered = 8;
    
    public static final int Transition_transitionDisable = 9;
    
    public static final int Transition_transitionFlags = 10;
    
    public static final int[] Variant = new int[] { 2130903233, 2130903547, 2130903548, 2130903549, 2130903550 };
    
    public static final int Variant_constraints = 0;
    
    public static final int Variant_region_heightLessThan = 1;
    
    public static final int Variant_region_heightMoreThan = 2;
    
    public static final int Variant_region_widthLessThan = 3;
    
    public static final int Variant_region_widthMoreThan = 4;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130903510, 2130903511, 2130903629 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130903145, 2130903146 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int[] ViewTransition = new int[] { 
        16842960, 2130903041, 2130903042, 2130903197, 2130903294, 2130903350, 2130903351, 2130903485, 2130903489, 2130903505, 
        2130903516, 2130903564, 2130903661, 2130903669, 2130903671 };
    
    public static final int ViewTransition_SharedValue = 1;
    
    public static final int ViewTransition_SharedValueId = 2;
    
    public static final int ViewTransition_android_id = 0;
    
    public static final int ViewTransition_clearsTag = 3;
    
    public static final int ViewTransition_duration = 4;
    
    public static final int ViewTransition_ifTagNotSet = 5;
    
    public static final int ViewTransition_ifTagSet = 6;
    
    public static final int ViewTransition_motionInterpolator = 7;
    
    public static final int ViewTransition_motionTarget = 8;
    
    public static final int ViewTransition_onStateTransition = 9;
    
    public static final int ViewTransition_pathMotionArc = 10;
    
    public static final int ViewTransition_setsTag = 11;
    
    public static final int ViewTransition_transitionDisable = 12;
    
    public static final int ViewTransition_upDuration = 13;
    
    public static final int ViewTransition_viewTransitionMode = 14;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
    
    public static final int[] include = new int[] { 2130903228 };
    
    public static final int include_constraintSet = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\widget\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */