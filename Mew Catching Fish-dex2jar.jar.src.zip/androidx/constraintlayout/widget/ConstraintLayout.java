package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.core.Metrics;
import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.core.widgets.Guideline;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUG_DRAW_CONSTRAINTS = false;
  
  public static final int DESIGN_INFO_ID = 0;
  
  private static final boolean MEASURE = false;
  
  private static final boolean OPTIMIZE_HEIGHT_CHANGE = false;
  
  private static final String TAG = "ConstraintLayout";
  
  private static final boolean USE_CONSTRAINTS_HELPER = true;
  
  public static final String VERSION = "ConstraintLayout-2.1.0";
  
  private static SharedValues sSharedValues;
  
  SparseArray<View> mChildrenByIds = new SparseArray();
  
  private ArrayList<ConstraintHelper> mConstraintHelpers = new ArrayList<ConstraintHelper>(4);
  
  protected ConstraintLayoutStates mConstraintLayoutSpec = null;
  
  private ConstraintSet mConstraintSet = null;
  
  private int mConstraintSetId = -1;
  
  private ConstraintsChangedListener mConstraintsChangedListener;
  
  private HashMap<String, Integer> mDesignIds = new HashMap<String, Integer>();
  
  protected boolean mDirtyHierarchy = true;
  
  private int mLastMeasureHeight = -1;
  
  int mLastMeasureHeightMode = 0;
  
  int mLastMeasureHeightSize = -1;
  
  private int mLastMeasureWidth = -1;
  
  int mLastMeasureWidthMode = 0;
  
  int mLastMeasureWidthSize = -1;
  
  protected ConstraintWidgetContainer mLayoutWidget = new ConstraintWidgetContainer();
  
  private int mMaxHeight = Integer.MAX_VALUE;
  
  private int mMaxWidth = Integer.MAX_VALUE;
  
  Measurer mMeasurer = new Measurer(this);
  
  private Metrics mMetrics;
  
  private int mMinHeight = 0;
  
  private int mMinWidth = 0;
  
  private int mOnMeasureHeightMeasureSpec = 0;
  
  private int mOnMeasureWidthMeasureSpec = 0;
  
  private int mOptimizationLevel = 257;
  
  private SparseArray<ConstraintWidget> mTempMapIdToWidget = new SparseArray();
  
  public ConstraintLayout(Context paramContext) {
    super(paramContext);
    init((AttributeSet)null, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet, paramInt, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    init(paramAttributeSet, paramInt1, paramInt2);
  }
  
  private int getPaddingWidth() {
    int j = getPaddingLeft();
    int i = 0;
    j = Math.max(0, j) + Math.max(0, getPaddingRight());
    if (Build.VERSION.SDK_INT >= 17) {
      i = Math.max(0, getPaddingStart());
      i = Math.max(0, getPaddingEnd()) + i;
    } 
    if (i > 0)
      j = i; 
    return j;
  }
  
  public static SharedValues getSharedValues() {
    if (sSharedValues == null)
      sSharedValues = new SharedValues(); 
    return sSharedValues;
  }
  
  private final ConstraintWidget getTargetWidget(int paramInt) {
    if (paramInt == 0)
      return (ConstraintWidget)this.mLayoutWidget; 
    View view2 = (View)this.mChildrenByIds.get(paramInt);
    View view1 = view2;
    if (view2 == null) {
      view2 = findViewById(paramInt);
      view1 = view2;
      if (view2 != null) {
        view1 = view2;
        if (view2 != this) {
          view1 = view2;
          if (view2.getParent() == this) {
            onViewAdded(view2);
            view1 = view2;
          } 
        } 
      } 
    } 
    return (ConstraintWidget)((view1 == this) ? this.mLayoutWidget : ((view1 == null) ? null : ((LayoutParams)view1.getLayoutParams()).widget));
  }
  
  private void init(AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.mLayoutWidget.setCompanionWidget(this);
    this.mLayoutWidget.setMeasurer(this.mMeasurer);
    this.mChildrenByIds.put(getId(), this);
    this.mConstraintSet = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.ConstraintLayout_Layout, paramInt1, paramInt2);
      paramInt2 = typedArray.getIndexCount();
      paramInt1 = 0;
      while (true) {
        if (paramInt1 < paramInt2) {
          int i = typedArray.getIndex(paramInt1);
          if (i == R.styleable.ConstraintLayout_Layout_android_minWidth) {
            this.mMinWidth = typedArray.getDimensionPixelOffset(i, this.mMinWidth);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_minHeight) {
            this.mMinHeight = typedArray.getDimensionPixelOffset(i, this.mMinHeight);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_maxWidth) {
            this.mMaxWidth = typedArray.getDimensionPixelOffset(i, this.mMaxWidth);
          } else if (i == R.styleable.ConstraintLayout_Layout_android_maxHeight) {
            this.mMaxHeight = typedArray.getDimensionPixelOffset(i, this.mMaxHeight);
          } else if (i == R.styleable.ConstraintLayout_Layout_layout_optimizationLevel) {
            this.mOptimizationLevel = typedArray.getInt(i, this.mOptimizationLevel);
          } else if (i == R.styleable.ConstraintLayout_Layout_layoutDescription) {
            i = typedArray.getResourceId(i, 0);
            if (i != 0)
              try {
                parseLayoutDescription(i);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                this.mConstraintLayoutSpec = null;
              }  
          } else if (i == R.styleable.ConstraintLayout_Layout_constraintSet) {
            i = typedArray.getResourceId(i, 0);
            try {
              ConstraintSet constraintSet = new ConstraintSet();
              this.mConstraintSet = constraintSet;
              constraintSet.load(getContext(), i);
            } catch (android.content.res.Resources.NotFoundException notFoundException) {
              this.mConstraintSet = null;
            } 
            this.mConstraintSetId = i;
          } 
          paramInt1++;
          continue;
        } 
        typedArray.recycle();
        this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
        return;
      } 
    } 
    this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
  }
  
  private void markHierarchyDirty() {
    this.mDirtyHierarchy = true;
    this.mLastMeasureWidth = -1;
    this.mLastMeasureHeight = -1;
    this.mLastMeasureWidthSize = -1;
    this.mLastMeasureHeightSize = -1;
    this.mLastMeasureWidthMode = 0;
    this.mLastMeasureHeightMode = 0;
  }
  
  private void setChildrenConstraints() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getChildCount : ()I
    //   10: istore_2
    //   11: iconst_0
    //   12: istore_1
    //   13: iload_1
    //   14: iload_2
    //   15: if_icmpge -> 49
    //   18: aload_0
    //   19: aload_0
    //   20: iload_1
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   27: astore #5
    //   29: aload #5
    //   31: ifnonnull -> 37
    //   34: goto -> 42
    //   37: aload #5
    //   39: invokevirtual reset : ()V
    //   42: iload_1
    //   43: iconst_1
    //   44: iadd
    //   45: istore_1
    //   46: goto -> 13
    //   49: iload #4
    //   51: ifeq -> 145
    //   54: iconst_0
    //   55: istore_1
    //   56: iload_1
    //   57: iload_2
    //   58: if_icmpge -> 145
    //   61: aload_0
    //   62: iload_1
    //   63: invokevirtual getChildAt : (I)Landroid/view/View;
    //   66: astore #7
    //   68: aload_0
    //   69: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   72: aload #7
    //   74: invokevirtual getId : ()I
    //   77: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   80: astore #6
    //   82: aload_0
    //   83: iconst_0
    //   84: aload #6
    //   86: aload #7
    //   88: invokevirtual getId : ()I
    //   91: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   94: invokevirtual setDesignInformation : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   97: aload #6
    //   99: bipush #47
    //   101: invokevirtual indexOf : (I)I
    //   104: istore_3
    //   105: aload #6
    //   107: astore #5
    //   109: iload_3
    //   110: iconst_m1
    //   111: if_icmpeq -> 124
    //   114: aload #6
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: invokevirtual substring : (I)Ljava/lang/String;
    //   122: astore #5
    //   124: aload_0
    //   125: aload #7
    //   127: invokevirtual getId : ()I
    //   130: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   133: aload #5
    //   135: invokevirtual setDebugName : (Ljava/lang/String;)V
    //   138: iload_1
    //   139: iconst_1
    //   140: iadd
    //   141: istore_1
    //   142: goto -> 56
    //   145: aload_0
    //   146: getfield mConstraintSetId : I
    //   149: iconst_m1
    //   150: if_icmpeq -> 206
    //   153: iconst_0
    //   154: istore_1
    //   155: iload_1
    //   156: iload_2
    //   157: if_icmpge -> 206
    //   160: aload_0
    //   161: iload_1
    //   162: invokevirtual getChildAt : (I)Landroid/view/View;
    //   165: astore #5
    //   167: aload #5
    //   169: invokevirtual getId : ()I
    //   172: aload_0
    //   173: getfield mConstraintSetId : I
    //   176: if_icmpne -> 199
    //   179: aload #5
    //   181: instanceof androidx/constraintlayout/widget/Constraints
    //   184: ifeq -> 199
    //   187: aload_0
    //   188: aload #5
    //   190: checkcast androidx/constraintlayout/widget/Constraints
    //   193: invokevirtual getConstraintSet : ()Landroidx/constraintlayout/widget/ConstraintSet;
    //   196: putfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   199: iload_1
    //   200: iconst_1
    //   201: iadd
    //   202: istore_1
    //   203: goto -> 155
    //   206: aload_0
    //   207: getfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   210: astore #5
    //   212: aload #5
    //   214: ifnull -> 224
    //   217: aload #5
    //   219: aload_0
    //   220: iconst_1
    //   221: invokevirtual applyToInternal : (Landroidx/constraintlayout/widget/ConstraintLayout;Z)V
    //   224: aload_0
    //   225: getfield mLayoutWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   228: invokevirtual removeAllChildren : ()V
    //   231: aload_0
    //   232: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   235: invokevirtual size : ()I
    //   238: istore_3
    //   239: iload_3
    //   240: ifle -> 272
    //   243: iconst_0
    //   244: istore_1
    //   245: iload_1
    //   246: iload_3
    //   247: if_icmpge -> 272
    //   250: aload_0
    //   251: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   254: iload_1
    //   255: invokevirtual get : (I)Ljava/lang/Object;
    //   258: checkcast androidx/constraintlayout/widget/ConstraintHelper
    //   261: aload_0
    //   262: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   265: iload_1
    //   266: iconst_1
    //   267: iadd
    //   268: istore_1
    //   269: goto -> 245
    //   272: iconst_0
    //   273: istore_1
    //   274: iload_1
    //   275: iload_2
    //   276: if_icmpge -> 310
    //   279: aload_0
    //   280: iload_1
    //   281: invokevirtual getChildAt : (I)Landroid/view/View;
    //   284: astore #5
    //   286: aload #5
    //   288: instanceof androidx/constraintlayout/widget/Placeholder
    //   291: ifeq -> 303
    //   294: aload #5
    //   296: checkcast androidx/constraintlayout/widget/Placeholder
    //   299: aload_0
    //   300: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   303: iload_1
    //   304: iconst_1
    //   305: iadd
    //   306: istore_1
    //   307: goto -> 274
    //   310: aload_0
    //   311: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   314: invokevirtual clear : ()V
    //   317: aload_0
    //   318: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   321: iconst_0
    //   322: aload_0
    //   323: getfield mLayoutWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   326: invokevirtual put : (ILjava/lang/Object;)V
    //   329: aload_0
    //   330: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   333: aload_0
    //   334: invokevirtual getId : ()I
    //   337: aload_0
    //   338: getfield mLayoutWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   341: invokevirtual put : (ILjava/lang/Object;)V
    //   344: iconst_0
    //   345: istore_1
    //   346: iload_1
    //   347: iload_2
    //   348: if_icmpge -> 387
    //   351: aload_0
    //   352: iload_1
    //   353: invokevirtual getChildAt : (I)Landroid/view/View;
    //   356: astore #5
    //   358: aload_0
    //   359: aload #5
    //   361: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   364: astore #6
    //   366: aload_0
    //   367: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   370: aload #5
    //   372: invokevirtual getId : ()I
    //   375: aload #6
    //   377: invokevirtual put : (ILjava/lang/Object;)V
    //   380: iload_1
    //   381: iconst_1
    //   382: iadd
    //   383: istore_1
    //   384: goto -> 346
    //   387: iconst_0
    //   388: istore_1
    //   389: iload_1
    //   390: iload_2
    //   391: if_icmpge -> 459
    //   394: aload_0
    //   395: iload_1
    //   396: invokevirtual getChildAt : (I)Landroid/view/View;
    //   399: astore #5
    //   401: aload_0
    //   402: aload #5
    //   404: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   407: astore #6
    //   409: aload #6
    //   411: ifnonnull -> 417
    //   414: goto -> 452
    //   417: aload #5
    //   419: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   422: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   425: astore #7
    //   427: aload_0
    //   428: getfield mLayoutWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   431: aload #6
    //   433: invokevirtual add : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;)V
    //   436: aload_0
    //   437: iload #4
    //   439: aload #5
    //   441: aload #6
    //   443: aload #7
    //   445: aload_0
    //   446: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   449: invokevirtual applyConstraintsFromLayoutParams : (ZLandroid/view/View;Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;Landroid/util/SparseArray;)V
    //   452: iload_1
    //   453: iconst_1
    //   454: iadd
    //   455: istore_1
    //   456: goto -> 389
    //   459: return
    //   460: astore #5
    //   462: goto -> 138
    // Exception table:
    //   from	to	target	type
    //   68	105	460	android/content/res/Resources$NotFoundException
    //   114	124	460	android/content/res/Resources$NotFoundException
    //   124	138	460	android/content/res/Resources$NotFoundException
  }
  
  private void setWidgetBaseline(ConstraintWidget paramConstraintWidget, LayoutParams paramLayoutParams, SparseArray<ConstraintWidget> paramSparseArray, int paramInt, ConstraintAnchor.Type paramType) {
    View view = (View)this.mChildrenByIds.get(paramInt);
    ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramInt);
    if (constraintWidget != null && view != null && view.getLayoutParams() instanceof LayoutParams) {
      paramLayoutParams.needsBaseline = true;
      if (paramType == ConstraintAnchor.Type.BASELINE) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        layoutParams.needsBaseline = true;
        layoutParams.widget.setHasBaseline(true);
      } 
      paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BASELINE).connect(constraintWidget.getAnchor(paramType), paramLayoutParams.baselineMargin, paramLayoutParams.goneBaselineMargin, true);
      paramConstraintWidget.setHasBaseline(true);
      paramConstraintWidget.getAnchor(ConstraintAnchor.Type.TOP).reset();
      paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).reset();
    } 
  }
  
  private boolean updateHierarchy() {
    boolean bool1;
    int j = getChildCount();
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < j) {
        if (getChildAt(i).isLayoutRequested()) {
          bool1 = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    if (bool1)
      setChildrenConstraints(); 
    return bool1;
  }
  
  protected void applyConstraintsFromLayoutParams(boolean paramBoolean, View paramView, ConstraintWidget paramConstraintWidget, LayoutParams paramLayoutParams, SparseArray<ConstraintWidget> paramSparseArray) {
    paramLayoutParams.validate();
    paramLayoutParams.helped = false;
    paramConstraintWidget.setVisibility(paramView.getVisibility());
    if (paramLayoutParams.isInPlaceholder) {
      paramConstraintWidget.setInPlaceholder(true);
      paramConstraintWidget.setVisibility(8);
    } 
    paramConstraintWidget.setCompanionWidget(paramView);
    if (paramView instanceof ConstraintHelper)
      ((ConstraintHelper)paramView).resolveRtl(paramConstraintWidget, this.mLayoutWidget.isRtl()); 
    if (paramLayoutParams.isGuideline) {
      Guideline guideline = (Guideline)paramConstraintWidget;
      int i = paramLayoutParams.resolvedGuideBegin;
      int j = paramLayoutParams.resolvedGuideEnd;
      float f = paramLayoutParams.resolvedGuidePercent;
      if (Build.VERSION.SDK_INT < 17) {
        i = paramLayoutParams.guideBegin;
        j = paramLayoutParams.guideEnd;
        f = paramLayoutParams.guidePercent;
      } 
      if (f != -1.0F) {
        guideline.setGuidePercent(f);
        return;
      } 
      if (i != -1) {
        guideline.setGuideBegin(i);
        return;
      } 
      if (j != -1) {
        guideline.setGuideEnd(j);
        return;
      } 
    } else {
      int i = paramLayoutParams.resolvedLeftToLeft;
      int j = paramLayoutParams.resolvedLeftToRight;
      int n = paramLayoutParams.resolvedRightToLeft;
      int k = paramLayoutParams.resolvedRightToRight;
      int i1 = paramLayoutParams.resolveGoneLeftMargin;
      int m = paramLayoutParams.resolveGoneRightMargin;
      float f = paramLayoutParams.resolvedHorizontalBias;
      if (Build.VERSION.SDK_INT < 17) {
        k = paramLayoutParams.leftToLeft;
        m = paramLayoutParams.leftToRight;
        n = paramLayoutParams.rightToLeft;
        int i3 = paramLayoutParams.rightToRight;
        i1 = paramLayoutParams.goneLeftMargin;
        int i2 = paramLayoutParams.goneRightMargin;
        f = paramLayoutParams.horizontalBias;
        i = k;
        j = m;
        if (k == -1) {
          i = k;
          j = m;
          if (m == -1)
            if (paramLayoutParams.startToStart != -1) {
              i = paramLayoutParams.startToStart;
              j = m;
            } else {
              i = k;
              j = m;
              if (paramLayoutParams.startToEnd != -1) {
                j = paramLayoutParams.startToEnd;
                i = k;
              } 
            }  
        } 
        m = n;
        k = i3;
        if (n == -1) {
          m = n;
          k = i3;
          if (i3 == -1)
            if (paramLayoutParams.endToStart != -1) {
              m = paramLayoutParams.endToStart;
              k = i3;
            } else {
              m = n;
              k = i3;
              if (paramLayoutParams.endToEnd != -1) {
                k = paramLayoutParams.endToEnd;
                m = n;
              } 
            }  
        } 
        n = m;
        m = i2;
      } 
      if (paramLayoutParams.circleConstraint != -1) {
        ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.circleConstraint);
        if (constraintWidget != null)
          paramConstraintWidget.connectCircularConstraint(constraintWidget, paramLayoutParams.circleAngle, paramLayoutParams.circleRadius); 
      } else {
        if (i != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(i);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.LEFT, constraintWidget, ConstraintAnchor.Type.LEFT, paramLayoutParams.leftMargin, i1); 
        } else if (j != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(j);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.LEFT, constraintWidget, ConstraintAnchor.Type.RIGHT, paramLayoutParams.leftMargin, i1); 
        } 
        if (n != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(n);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.RIGHT, constraintWidget, ConstraintAnchor.Type.LEFT, paramLayoutParams.rightMargin, m); 
        } else if (k != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(k);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.RIGHT, constraintWidget, ConstraintAnchor.Type.RIGHT, paramLayoutParams.rightMargin, m); 
        } 
        if (paramLayoutParams.topToTop != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.topToTop);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.TOP, constraintWidget, ConstraintAnchor.Type.TOP, paramLayoutParams.topMargin, paramLayoutParams.goneTopMargin); 
        } else if (paramLayoutParams.topToBottom != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.topToBottom);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.TOP, constraintWidget, ConstraintAnchor.Type.BOTTOM, paramLayoutParams.topMargin, paramLayoutParams.goneTopMargin); 
        } 
        if (paramLayoutParams.bottomToTop != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.bottomToTop);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.BOTTOM, constraintWidget, ConstraintAnchor.Type.TOP, paramLayoutParams.bottomMargin, paramLayoutParams.goneBottomMargin); 
        } else if (paramLayoutParams.bottomToBottom != -1) {
          ConstraintWidget constraintWidget = (ConstraintWidget)paramSparseArray.get(paramLayoutParams.bottomToBottom);
          if (constraintWidget != null)
            paramConstraintWidget.immediateConnect(ConstraintAnchor.Type.BOTTOM, constraintWidget, ConstraintAnchor.Type.BOTTOM, paramLayoutParams.bottomMargin, paramLayoutParams.goneBottomMargin); 
        } 
        if (paramLayoutParams.baselineToBaseline != -1) {
          setWidgetBaseline(paramConstraintWidget, paramLayoutParams, paramSparseArray, paramLayoutParams.baselineToBaseline, ConstraintAnchor.Type.BASELINE);
        } else if (paramLayoutParams.baselineToTop != -1) {
          setWidgetBaseline(paramConstraintWidget, paramLayoutParams, paramSparseArray, paramLayoutParams.baselineToTop, ConstraintAnchor.Type.TOP);
        } else if (paramLayoutParams.baselineToBottom != -1) {
          setWidgetBaseline(paramConstraintWidget, paramLayoutParams, paramSparseArray, paramLayoutParams.baselineToBottom, ConstraintAnchor.Type.BOTTOM);
        } 
        if (f >= 0.0F)
          paramConstraintWidget.setHorizontalBiasPercent(f); 
        if (paramLayoutParams.verticalBias >= 0.0F)
          paramConstraintWidget.setVerticalBiasPercent(paramLayoutParams.verticalBias); 
      } 
      if (paramBoolean && (paramLayoutParams.editorAbsoluteX != -1 || paramLayoutParams.editorAbsoluteY != -1))
        paramConstraintWidget.setOrigin(paramLayoutParams.editorAbsoluteX, paramLayoutParams.editorAbsoluteY); 
      if (!paramLayoutParams.horizontalDimensionFixed) {
        if (paramLayoutParams.width == -1) {
          if (paramLayoutParams.constrainedWidth) {
            paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          } else {
            paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
          } 
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.LEFT)).mMargin = paramLayoutParams.leftMargin;
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT)).mMargin = paramLayoutParams.rightMargin;
        } else {
          paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          paramConstraintWidget.setWidth(0);
        } 
      } else {
        paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        paramConstraintWidget.setWidth(paramLayoutParams.width);
        if (paramLayoutParams.width == -2)
          paramConstraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT); 
      } 
      if (!paramLayoutParams.verticalDimensionFixed) {
        if (paramLayoutParams.height == -1) {
          if (paramLayoutParams.constrainedHeight) {
            paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          } else {
            paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
          } 
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.TOP)).mMargin = paramLayoutParams.topMargin;
          (paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM)).mMargin = paramLayoutParams.bottomMargin;
        } else {
          paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
          paramConstraintWidget.setHeight(0);
        } 
      } else {
        paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        paramConstraintWidget.setHeight(paramLayoutParams.height);
        if (paramLayoutParams.height == -2)
          paramConstraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT); 
      } 
      paramConstraintWidget.setDimensionRatio(paramLayoutParams.dimensionRatio);
      paramConstraintWidget.setHorizontalWeight(paramLayoutParams.horizontalWeight);
      paramConstraintWidget.setVerticalWeight(paramLayoutParams.verticalWeight);
      paramConstraintWidget.setHorizontalChainStyle(paramLayoutParams.horizontalChainStyle);
      paramConstraintWidget.setVerticalChainStyle(paramLayoutParams.verticalChainStyle);
      paramConstraintWidget.setWrapBehaviorInParent(paramLayoutParams.wrapBehaviorInParent);
      paramConstraintWidget.setHorizontalMatchStyle(paramLayoutParams.matchConstraintDefaultWidth, paramLayoutParams.matchConstraintMinWidth, paramLayoutParams.matchConstraintMaxWidth, paramLayoutParams.matchConstraintPercentWidth);
      paramConstraintWidget.setVerticalMatchStyle(paramLayoutParams.matchConstraintDefaultHeight, paramLayoutParams.matchConstraintMinHeight, paramLayoutParams.matchConstraintMaxHeight, paramLayoutParams.matchConstraintPercentHeight);
    } 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList<ConstraintHelper> arrayList = this.mConstraintHelpers;
    if (arrayList != null) {
      int i = arrayList.size();
      if (i > 0) {
        int j;
        for (j = 0; j < i; j++)
          ((ConstraintHelper)this.mConstraintHelpers.get(j)).updatePreDraw(this); 
      } 
    } 
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      float f1 = getWidth();
      float f2 = getHeight();
      int j = getChildCount();
      int i;
      for (i = 0; i < j; i++) {
        View view = getChildAt(i);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(",");
            if (object.length == 4) {
              int m = Integer.parseInt((String)object[0]);
              int i1 = Integer.parseInt((String)object[1]);
              int n = Integer.parseInt((String)object[2]);
              int k = Integer.parseInt((String)object[3]);
              m = (int)(m / 1080.0F * f1);
              i1 = (int)(i1 / 1920.0F * f2);
              n = (int)(n / 1080.0F * f1);
              k = (int)(k / 1920.0F * f2);
              object = new Paint();
              object.setColor(-65536);
              float f3 = m;
              float f4 = i1;
              float f5 = (m + n);
              paramCanvas.drawLine(f3, f4, f5, f4, (Paint)object);
              float f6 = (i1 + k);
              paramCanvas.drawLine(f5, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f5, f6, f3, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f3, f4, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(f3, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f5, f4, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mLayoutWidget.fillMetrics(paramMetrics);
  }
  
  public void forceLayout() {
    markHierarchyDirty();
    super.forceLayout();
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-2, -2);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new LayoutParams(paramLayoutParams);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  public Object getDesignInformation(int paramInt, Object paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      paramObject = paramObject;
      HashMap<String, Integer> hashMap = this.mDesignIds;
      if (hashMap != null && hashMap.containsKey(paramObject))
        return this.mDesignIds.get(paramObject); 
    } 
    return null;
  }
  
  public int getMaxHeight() {
    return this.mMaxHeight;
  }
  
  public int getMaxWidth() {
    return this.mMaxWidth;
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public int getOptimizationLevel() {
    return this.mLayoutWidget.getOptimizationLevel();
  }
  
  public View getViewById(int paramInt) {
    return (View)this.mChildrenByIds.get(paramInt);
  }
  
  public final ConstraintWidget getViewWidget(View paramView) {
    if (paramView == this)
      return (ConstraintWidget)this.mLayoutWidget; 
    if (paramView != null) {
      if (paramView.getLayoutParams() instanceof LayoutParams)
        return ((LayoutParams)paramView.getLayoutParams()).widget; 
      paramView.setLayoutParams(generateLayoutParams(paramView.getLayoutParams()));
      if (paramView.getLayoutParams() instanceof LayoutParams)
        return ((LayoutParams)paramView.getLayoutParams()).widget; 
    } 
    return null;
  }
  
  protected boolean isRtl() {
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i >= 17) {
      if (((getContext().getApplicationInfo()).flags & 0x400000) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      bool1 = bool2;
      if (i != 0) {
        bool1 = bool2;
        if (1 == getLayoutDirection())
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public void loadLayoutDescription(int paramInt) {
    if (paramInt != 0)
      try {
        this.mConstraintLayoutSpec = new ConstraintLayoutStates(getContext(), this, paramInt);
        return;
      } catch (android.content.res.Resources.NotFoundException notFoundException) {
        this.mConstraintLayoutSpec = null;
        return;
      }  
    this.mConstraintLayoutSpec = null;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt2 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      ConstraintWidget constraintWidget = layoutParams.widget;
      if ((view.getVisibility() != 8 || layoutParams.isGuideline || layoutParams.isHelper || layoutParams.isVirtualGroup || paramBoolean) && !layoutParams.isInPlaceholder) {
        paramInt4 = constraintWidget.getX();
        int i = constraintWidget.getY();
        int j = constraintWidget.getWidth() + paramInt4;
        int k = constraintWidget.getHeight() + i;
        view.layout(paramInt4, i, j, k);
        if (view instanceof Placeholder) {
          view = ((Placeholder)view).getContent();
          if (view != null) {
            view.setVisibility(0);
            view.layout(paramInt4, i, j, k);
          } 
        } 
      } 
    } 
    paramInt3 = this.mConstraintHelpers.size();
    if (paramInt3 > 0)
      for (paramInt1 = paramInt2; paramInt1 < paramInt3; paramInt1++)
        ((ConstraintHelper)this.mConstraintHelpers.get(paramInt1)).updatePostLayout(this);  
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.mOnMeasureWidthMeasureSpec == paramInt1)
      int i = this.mOnMeasureHeightMeasureSpec; 
    if (!this.mDirtyHierarchy) {
      int j = getChildCount();
      for (int i = 0; i < j; i++) {
        if (getChildAt(i).isLayoutRequested()) {
          this.mDirtyHierarchy = true;
          break;
        } 
      } 
    } 
    boolean bool = this.mDirtyHierarchy;
    this.mOnMeasureWidthMeasureSpec = paramInt1;
    this.mOnMeasureHeightMeasureSpec = paramInt2;
    this.mLayoutWidget.setRtl(isRtl());
    if (this.mDirtyHierarchy) {
      this.mDirtyHierarchy = false;
      if (updateHierarchy())
        this.mLayoutWidget.updateHierarchy(); 
    } 
    resolveSystem(this.mLayoutWidget, this.mOptimizationLevel, paramInt1, paramInt2);
    resolveMeasuredDimension(paramInt1, paramInt2, this.mLayoutWidget.getWidth(), this.mLayoutWidget.getHeight(), this.mLayoutWidget.isWidthMeasuredTooSmall(), this.mLayoutWidget.isHeightMeasuredTooSmall());
  }
  
  public void onViewAdded(View paramView) {
    super.onViewAdded(paramView);
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    if (paramView instanceof Guideline && !(constraintWidget instanceof Guideline)) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      layoutParams.widget = (ConstraintWidget)new Guideline();
      layoutParams.isGuideline = true;
      ((Guideline)layoutParams.widget).setOrientation(layoutParams.orientation);
    } 
    if (paramView instanceof ConstraintHelper) {
      ConstraintHelper constraintHelper = (ConstraintHelper)paramView;
      constraintHelper.validateParams();
      ((LayoutParams)paramView.getLayoutParams()).isHelper = true;
      if (!this.mConstraintHelpers.contains(constraintHelper))
        this.mConstraintHelpers.add(constraintHelper); 
    } 
    this.mChildrenByIds.put(paramView.getId(), paramView);
    this.mDirtyHierarchy = true;
  }
  
  public void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    this.mChildrenByIds.remove(paramView.getId());
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    this.mLayoutWidget.remove(constraintWidget);
    this.mConstraintHelpers.remove(paramView);
    this.mDirtyHierarchy = true;
  }
  
  protected void parseLayoutDescription(int paramInt) {
    this.mConstraintLayoutSpec = new ConstraintLayoutStates(getContext(), this, paramInt);
  }
  
  public void requestLayout() {
    markHierarchyDirty();
    super.requestLayout();
  }
  
  protected void resolveMeasuredDimension(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2) {
    int i = this.mMeasurer.paddingHeight;
    paramInt1 = resolveSizeAndState(paramInt3 + this.mMeasurer.paddingWidth, paramInt1, 0);
    paramInt3 = resolveSizeAndState(paramInt4 + i, paramInt2, 0);
    paramInt2 = Math.min(this.mMaxWidth, paramInt1 & 0xFFFFFF);
    paramInt3 = Math.min(this.mMaxHeight, paramInt3 & 0xFFFFFF);
    paramInt1 = paramInt2;
    if (paramBoolean1)
      paramInt1 = paramInt2 | 0x1000000; 
    paramInt2 = paramInt3;
    if (paramBoolean2)
      paramInt2 = paramInt3 | 0x1000000; 
    setMeasuredDimension(paramInt1, paramInt2);
    this.mLastMeasureWidth = paramInt1;
    this.mLastMeasureHeight = paramInt2;
  }
  
  protected void resolveSystem(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3) {
    int i = View.MeasureSpec.getMode(paramInt2);
    int i1 = View.MeasureSpec.getSize(paramInt2);
    int j = View.MeasureSpec.getMode(paramInt3);
    int m = View.MeasureSpec.getSize(paramInt3);
    int k = Math.max(0, getPaddingTop());
    int i3 = Math.max(0, getPaddingBottom());
    int n = k + i3;
    int i2 = getPaddingWidth();
    this.mMeasurer.captureLayoutInfo(paramInt2, paramInt3, k, i3, i2, n);
    if (Build.VERSION.SDK_INT >= 17) {
      paramInt2 = Math.max(0, getPaddingStart());
      paramInt3 = Math.max(0, getPaddingEnd());
      if (paramInt2 > 0 || paramInt3 > 0) {
        if (isRtl())
          paramInt2 = paramInt3; 
      } else {
        paramInt2 = Math.max(0, getPaddingLeft());
      } 
    } else {
      paramInt2 = Math.max(0, getPaddingLeft());
    } 
    paramInt3 = i1 - i2;
    m -= n;
    setSelfDimensionBehaviour(paramConstraintWidgetContainer, i, paramInt3, j, m);
    paramConstraintWidgetContainer.measure(paramInt1, i, paramInt3, j, m, this.mLastMeasureWidth, this.mLastMeasureHeight, paramInt2, k);
  }
  
  public void setConstraintSet(ConstraintSet paramConstraintSet) {
    this.mConstraintSet = paramConstraintSet;
  }
  
  public void setDesignInformation(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.mDesignIds == null)
        this.mDesignIds = new HashMap<String, Integer>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramInt = ((Integer)paramObject2).intValue();
      this.mDesignIds.put(paramObject1, Integer.valueOf(paramInt));
    } 
  }
  
  public void setId(int paramInt) {
    this.mChildrenByIds.remove(getId());
    super.setId(paramInt);
    this.mChildrenByIds.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.mMaxHeight)
      return; 
    this.mMaxHeight = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.mMaxWidth)
      return; 
    this.mMaxWidth = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.mMinHeight)
      return; 
    this.mMinHeight = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.mMinWidth)
      return; 
    this.mMinWidth = paramInt;
    requestLayout();
  }
  
  public void setOnConstraintsChanged(ConstraintsChangedListener paramConstraintsChangedListener) {
    this.mConstraintsChangedListener = paramConstraintsChangedListener;
    ConstraintLayoutStates constraintLayoutStates = this.mConstraintLayoutSpec;
    if (constraintLayoutStates != null)
      constraintLayoutStates.setOnConstraintsChanged(paramConstraintsChangedListener); 
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    this.mLayoutWidget.setOptimizationLevel(paramInt);
  }
  
  protected void setSelfDimensionBehaviour(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMeasurer : Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;
    //   4: getfield paddingHeight : I
    //   7: istore #6
    //   9: aload_0
    //   10: getfield mMeasurer : Landroidx/constraintlayout/widget/ConstraintLayout$Measurer;
    //   13: getfield paddingWidth : I
    //   16: istore #7
    //   18: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   21: astore #9
    //   23: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   26: astore #10
    //   28: aload_0
    //   29: invokevirtual getChildCount : ()I
    //   32: istore #8
    //   34: iload_2
    //   35: ldc_w -2147483648
    //   38: if_icmpeq -> 102
    //   41: iload_2
    //   42: ifeq -> 72
    //   45: iload_2
    //   46: ldc_w 1073741824
    //   49: if_icmpeq -> 57
    //   52: iconst_0
    //   53: istore_3
    //   54: goto -> 129
    //   57: aload_0
    //   58: getfield mMaxWidth : I
    //   61: iload #7
    //   63: isub
    //   64: iload_3
    //   65: invokestatic min : (II)I
    //   68: istore_3
    //   69: goto -> 129
    //   72: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   75: astore #11
    //   77: aload #11
    //   79: astore #9
    //   81: iload #8
    //   83: ifne -> 52
    //   86: iconst_0
    //   87: aload_0
    //   88: getfield mMinWidth : I
    //   91: invokestatic max : (II)I
    //   94: istore_3
    //   95: aload #11
    //   97: astore #9
    //   99: goto -> 129
    //   102: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   105: astore #11
    //   107: aload #11
    //   109: astore #9
    //   111: iload #8
    //   113: ifne -> 129
    //   116: iconst_0
    //   117: aload_0
    //   118: getfield mMinWidth : I
    //   121: invokestatic max : (II)I
    //   124: istore_3
    //   125: aload #11
    //   127: astore #9
    //   129: iload #4
    //   131: ldc_w -2147483648
    //   134: if_icmpeq -> 204
    //   137: iload #4
    //   139: ifeq -> 173
    //   142: iload #4
    //   144: ldc_w 1073741824
    //   147: if_icmpeq -> 156
    //   150: iconst_0
    //   151: istore #5
    //   153: goto -> 232
    //   156: aload_0
    //   157: getfield mMaxHeight : I
    //   160: iload #6
    //   162: isub
    //   163: iload #5
    //   165: invokestatic min : (II)I
    //   168: istore #5
    //   170: goto -> 232
    //   173: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   176: astore #11
    //   178: aload #11
    //   180: astore #10
    //   182: iload #8
    //   184: ifne -> 150
    //   187: iconst_0
    //   188: aload_0
    //   189: getfield mMinHeight : I
    //   192: invokestatic max : (II)I
    //   195: istore #5
    //   197: aload #11
    //   199: astore #10
    //   201: goto -> 232
    //   204: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   207: astore #11
    //   209: aload #11
    //   211: astore #10
    //   213: iload #8
    //   215: ifne -> 232
    //   218: iconst_0
    //   219: aload_0
    //   220: getfield mMinHeight : I
    //   223: invokestatic max : (II)I
    //   226: istore #5
    //   228: aload #11
    //   230: astore #10
    //   232: iload_3
    //   233: aload_1
    //   234: invokevirtual getWidth : ()I
    //   237: if_icmpne -> 249
    //   240: iload #5
    //   242: aload_1
    //   243: invokevirtual getHeight : ()I
    //   246: if_icmpeq -> 253
    //   249: aload_1
    //   250: invokevirtual invalidateMeasures : ()V
    //   253: aload_1
    //   254: iconst_0
    //   255: invokevirtual setX : (I)V
    //   258: aload_1
    //   259: iconst_0
    //   260: invokevirtual setY : (I)V
    //   263: aload_1
    //   264: aload_0
    //   265: getfield mMaxWidth : I
    //   268: iload #7
    //   270: isub
    //   271: invokevirtual setMaxWidth : (I)V
    //   274: aload_1
    //   275: aload_0
    //   276: getfield mMaxHeight : I
    //   279: iload #6
    //   281: isub
    //   282: invokevirtual setMaxHeight : (I)V
    //   285: aload_1
    //   286: iconst_0
    //   287: invokevirtual setMinWidth : (I)V
    //   290: aload_1
    //   291: iconst_0
    //   292: invokevirtual setMinHeight : (I)V
    //   295: aload_1
    //   296: aload #9
    //   298: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   301: aload_1
    //   302: iload_3
    //   303: invokevirtual setWidth : (I)V
    //   306: aload_1
    //   307: aload #10
    //   309: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   312: aload_1
    //   313: iload #5
    //   315: invokevirtual setHeight : (I)V
    //   318: aload_1
    //   319: aload_0
    //   320: getfield mMinWidth : I
    //   323: iload #7
    //   325: isub
    //   326: invokevirtual setMinWidth : (I)V
    //   329: aload_1
    //   330: aload_0
    //   331: getfield mMinHeight : I
    //   334: iload #6
    //   336: isub
    //   337: invokevirtual setMinHeight : (I)V
    //   340: return
  }
  
  public void setState(int paramInt1, int paramInt2, int paramInt3) {
    ConstraintLayoutStates constraintLayoutStates = this.mConstraintLayoutSpec;
    if (constraintLayoutStates != null)
      constraintLayoutStates.updateConstraints(paramInt1, paramInt2, paramInt3); 
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public static final int BASELINE = 5;
    
    public static final int BOTTOM = 4;
    
    public static final int CHAIN_PACKED = 2;
    
    public static final int CHAIN_SPREAD = 0;
    
    public static final int CHAIN_SPREAD_INSIDE = 1;
    
    public static final int CIRCLE = 8;
    
    public static final int END = 7;
    
    public static final int GONE_UNSET = -2147483648;
    
    public static final int HORIZONTAL = 0;
    
    public static final int LEFT = 1;
    
    public static final int MATCH_CONSTRAINT = 0;
    
    public static final int MATCH_CONSTRAINT_PERCENT = 2;
    
    public static final int MATCH_CONSTRAINT_SPREAD = 0;
    
    public static final int MATCH_CONSTRAINT_WRAP = 1;
    
    public static final int PARENT_ID = 0;
    
    public static final int RIGHT = 2;
    
    public static final int START = 6;
    
    public static final int TOP = 3;
    
    public static final int UNSET = -1;
    
    public static final int VERTICAL = 1;
    
    public static final int WRAP_BEHAVIOR_HORIZONTAL_ONLY = 1;
    
    public static final int WRAP_BEHAVIOR_INCLUDED = 0;
    
    public static final int WRAP_BEHAVIOR_SKIPPED = 3;
    
    public static final int WRAP_BEHAVIOR_VERTICAL_ONLY = 2;
    
    public int baselineMargin = 0;
    
    public int baselineToBaseline = -1;
    
    public int baselineToBottom = -1;
    
    public int baselineToTop = -1;
    
    public int bottomToBottom = -1;
    
    public int bottomToTop = -1;
    
    public float circleAngle = 0.0F;
    
    public int circleConstraint = -1;
    
    public int circleRadius = 0;
    
    public boolean constrainedHeight = false;
    
    public boolean constrainedWidth = false;
    
    public String constraintTag = null;
    
    public String dimensionRatio = null;
    
    int dimensionRatioSide = 1;
    
    float dimensionRatioValue = 0.0F;
    
    public int editorAbsoluteX = -1;
    
    public int editorAbsoluteY = -1;
    
    public int endToEnd = -1;
    
    public int endToStart = -1;
    
    public int goneBaselineMargin = Integer.MIN_VALUE;
    
    public int goneBottomMargin = Integer.MIN_VALUE;
    
    public int goneEndMargin = Integer.MIN_VALUE;
    
    public int goneLeftMargin = Integer.MIN_VALUE;
    
    public int goneRightMargin = Integer.MIN_VALUE;
    
    public int goneStartMargin = Integer.MIN_VALUE;
    
    public int goneTopMargin = Integer.MIN_VALUE;
    
    public int guideBegin = -1;
    
    public int guideEnd = -1;
    
    public float guidePercent = -1.0F;
    
    boolean heightSet = true;
    
    public boolean helped = false;
    
    public float horizontalBias = 0.5F;
    
    public int horizontalChainStyle = 0;
    
    boolean horizontalDimensionFixed = true;
    
    public float horizontalWeight = -1.0F;
    
    boolean isGuideline = false;
    
    boolean isHelper = false;
    
    boolean isInPlaceholder = false;
    
    boolean isVirtualGroup = false;
    
    public int leftToLeft = -1;
    
    public int leftToRight = -1;
    
    public int matchConstraintDefaultHeight = 0;
    
    public int matchConstraintDefaultWidth = 0;
    
    public int matchConstraintMaxHeight = 0;
    
    public int matchConstraintMaxWidth = 0;
    
    public int matchConstraintMinHeight = 0;
    
    public int matchConstraintMinWidth = 0;
    
    public float matchConstraintPercentHeight = 1.0F;
    
    public float matchConstraintPercentWidth = 1.0F;
    
    boolean needsBaseline = false;
    
    public int orientation = -1;
    
    int resolveGoneLeftMargin = Integer.MIN_VALUE;
    
    int resolveGoneRightMargin = Integer.MIN_VALUE;
    
    int resolvedGuideBegin;
    
    int resolvedGuideEnd;
    
    float resolvedGuidePercent;
    
    float resolvedHorizontalBias = 0.5F;
    
    int resolvedLeftToLeft = -1;
    
    int resolvedLeftToRight = -1;
    
    int resolvedRightToLeft = -1;
    
    int resolvedRightToRight = -1;
    
    public int rightToLeft = -1;
    
    public int rightToRight = -1;
    
    public int startToEnd = -1;
    
    public int startToStart = -1;
    
    public int topToBottom = -1;
    
    public int topToTop = -1;
    
    public float verticalBias = 0.5F;
    
    public int verticalChainStyle = 0;
    
    boolean verticalDimensionFixed = true;
    
    public float verticalWeight = -1.0F;
    
    ConstraintWidget widget = new ConstraintWidget();
    
    boolean widthSet = true;
    
    public int wrapBehaviorInParent = 0;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_m1
      //   8: putfield guideBegin : I
      //   11: aload_0
      //   12: iconst_m1
      //   13: putfield guideEnd : I
      //   16: aload_0
      //   17: ldc -1.0
      //   19: putfield guidePercent : F
      //   22: aload_0
      //   23: iconst_m1
      //   24: putfield leftToLeft : I
      //   27: aload_0
      //   28: iconst_m1
      //   29: putfield leftToRight : I
      //   32: aload_0
      //   33: iconst_m1
      //   34: putfield rightToLeft : I
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield rightToRight : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield topToTop : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield topToBottom : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield bottomToTop : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield bottomToBottom : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield baselineToBaseline : I
      //   67: aload_0
      //   68: iconst_m1
      //   69: putfield baselineToTop : I
      //   72: aload_0
      //   73: iconst_m1
      //   74: putfield baselineToBottom : I
      //   77: aload_0
      //   78: iconst_m1
      //   79: putfield circleConstraint : I
      //   82: aload_0
      //   83: iconst_0
      //   84: putfield circleRadius : I
      //   87: aload_0
      //   88: fconst_0
      //   89: putfield circleAngle : F
      //   92: aload_0
      //   93: iconst_m1
      //   94: putfield startToEnd : I
      //   97: aload_0
      //   98: iconst_m1
      //   99: putfield startToStart : I
      //   102: aload_0
      //   103: iconst_m1
      //   104: putfield endToStart : I
      //   107: aload_0
      //   108: iconst_m1
      //   109: putfield endToEnd : I
      //   112: aload_0
      //   113: ldc -2147483648
      //   115: putfield goneLeftMargin : I
      //   118: aload_0
      //   119: ldc -2147483648
      //   121: putfield goneTopMargin : I
      //   124: aload_0
      //   125: ldc -2147483648
      //   127: putfield goneRightMargin : I
      //   130: aload_0
      //   131: ldc -2147483648
      //   133: putfield goneBottomMargin : I
      //   136: aload_0
      //   137: ldc -2147483648
      //   139: putfield goneStartMargin : I
      //   142: aload_0
      //   143: ldc -2147483648
      //   145: putfield goneEndMargin : I
      //   148: aload_0
      //   149: ldc -2147483648
      //   151: putfield goneBaselineMargin : I
      //   154: aload_0
      //   155: iconst_0
      //   156: putfield baselineMargin : I
      //   159: aload_0
      //   160: iconst_1
      //   161: putfield widthSet : Z
      //   164: aload_0
      //   165: iconst_1
      //   166: putfield heightSet : Z
      //   169: aload_0
      //   170: ldc 0.5
      //   172: putfield horizontalBias : F
      //   175: aload_0
      //   176: ldc 0.5
      //   178: putfield verticalBias : F
      //   181: aload_0
      //   182: aconst_null
      //   183: putfield dimensionRatio : Ljava/lang/String;
      //   186: aload_0
      //   187: fconst_0
      //   188: putfield dimensionRatioValue : F
      //   191: aload_0
      //   192: iconst_1
      //   193: putfield dimensionRatioSide : I
      //   196: aload_0
      //   197: ldc -1.0
      //   199: putfield horizontalWeight : F
      //   202: aload_0
      //   203: ldc -1.0
      //   205: putfield verticalWeight : F
      //   208: aload_0
      //   209: iconst_0
      //   210: putfield horizontalChainStyle : I
      //   213: aload_0
      //   214: iconst_0
      //   215: putfield verticalChainStyle : I
      //   218: aload_0
      //   219: iconst_0
      //   220: putfield matchConstraintDefaultWidth : I
      //   223: aload_0
      //   224: iconst_0
      //   225: putfield matchConstraintDefaultHeight : I
      //   228: aload_0
      //   229: iconst_0
      //   230: putfield matchConstraintMinWidth : I
      //   233: aload_0
      //   234: iconst_0
      //   235: putfield matchConstraintMinHeight : I
      //   238: aload_0
      //   239: iconst_0
      //   240: putfield matchConstraintMaxWidth : I
      //   243: aload_0
      //   244: iconst_0
      //   245: putfield matchConstraintMaxHeight : I
      //   248: aload_0
      //   249: fconst_1
      //   250: putfield matchConstraintPercentWidth : F
      //   253: aload_0
      //   254: fconst_1
      //   255: putfield matchConstraintPercentHeight : F
      //   258: aload_0
      //   259: iconst_m1
      //   260: putfield editorAbsoluteX : I
      //   263: aload_0
      //   264: iconst_m1
      //   265: putfield editorAbsoluteY : I
      //   268: aload_0
      //   269: iconst_m1
      //   270: putfield orientation : I
      //   273: aload_0
      //   274: iconst_0
      //   275: putfield constrainedWidth : Z
      //   278: aload_0
      //   279: iconst_0
      //   280: putfield constrainedHeight : Z
      //   283: aload_0
      //   284: aconst_null
      //   285: putfield constraintTag : Ljava/lang/String;
      //   288: aload_0
      //   289: iconst_0
      //   290: putfield wrapBehaviorInParent : I
      //   293: aload_0
      //   294: iconst_1
      //   295: putfield horizontalDimensionFixed : Z
      //   298: aload_0
      //   299: iconst_1
      //   300: putfield verticalDimensionFixed : Z
      //   303: aload_0
      //   304: iconst_0
      //   305: putfield needsBaseline : Z
      //   308: aload_0
      //   309: iconst_0
      //   310: putfield isGuideline : Z
      //   313: aload_0
      //   314: iconst_0
      //   315: putfield isHelper : Z
      //   318: aload_0
      //   319: iconst_0
      //   320: putfield isInPlaceholder : Z
      //   323: aload_0
      //   324: iconst_0
      //   325: putfield isVirtualGroup : Z
      //   328: aload_0
      //   329: iconst_m1
      //   330: putfield resolvedLeftToLeft : I
      //   333: aload_0
      //   334: iconst_m1
      //   335: putfield resolvedLeftToRight : I
      //   338: aload_0
      //   339: iconst_m1
      //   340: putfield resolvedRightToLeft : I
      //   343: aload_0
      //   344: iconst_m1
      //   345: putfield resolvedRightToRight : I
      //   348: aload_0
      //   349: ldc -2147483648
      //   351: putfield resolveGoneLeftMargin : I
      //   354: aload_0
      //   355: ldc -2147483648
      //   357: putfield resolveGoneRightMargin : I
      //   360: aload_0
      //   361: ldc 0.5
      //   363: putfield resolvedHorizontalBias : F
      //   366: aload_0
      //   367: new androidx/constraintlayout/core/widgets/ConstraintWidget
      //   370: dup
      //   371: invokespecial <init> : ()V
      //   374: putfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   377: aload_0
      //   378: iconst_0
      //   379: putfield helped : Z
      //   382: aload_1
      //   383: aload_2
      //   384: getstatic androidx/constraintlayout/widget/R$styleable.ConstraintLayout_Layout : [I
      //   387: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   390: astore_1
      //   391: aload_1
      //   392: invokevirtual getIndexCount : ()I
      //   395: istore #5
      //   397: iconst_0
      //   398: istore #4
      //   400: iload #4
      //   402: iload #5
      //   404: if_icmpge -> 2087
      //   407: aload_1
      //   408: iload #4
      //   410: invokevirtual getIndex : (I)I
      //   413: istore #6
      //   415: getstatic androidx/constraintlayout/widget/ConstraintLayout$LayoutParams$Table.map : Landroid/util/SparseIntArray;
      //   418: iload #6
      //   420: invokevirtual get : (I)I
      //   423: istore #7
      //   425: iload #7
      //   427: tableswitch default -> 592, 1 -> 2064, 2 -> 2026, 3 -> 2009, 4 -> 1967, 5 -> 1950, 6 -> 1933, 7 -> 1916, 8 -> 1878, 9 -> 1840, 10 -> 1802, 11 -> 1764, 12 -> 1726, 13 -> 1688, 14 -> 1650, 15 -> 1612, 16 -> 1574, 17 -> 1536, 18 -> 1498, 19 -> 1460, 20 -> 1422, 21 -> 1405, 22 -> 1388, 23 -> 1371, 24 -> 1354, 25 -> 1337, 26 -> 1320, 27 -> 1303, 28 -> 1286, 29 -> 1269, 30 -> 1252, 31 -> 1218, 32 -> 1184, 33 -> 1143, 34 -> 1102, 35 -> 1076, 36 -> 1035, 37 -> 994, 38 -> 968
      //   592: iload #7
      //   594: tableswitch default -> 656, 44 -> 955, 45 -> 938, 46 -> 921, 47 -> 907, 48 -> 893, 49 -> 876, 50 -> 859, 51 -> 846, 52 -> 808, 53 -> 770, 54 -> 753, 55 -> 736
      //   656: iload #7
      //   658: tableswitch default -> 684, 64 -> 720, 65 -> 704, 66 -> 687
      //   684: goto -> 2078
      //   687: aload_0
      //   688: aload_1
      //   689: iload #6
      //   691: aload_0
      //   692: getfield wrapBehaviorInParent : I
      //   695: invokevirtual getInt : (II)I
      //   698: putfield wrapBehaviorInParent : I
      //   701: goto -> 2078
      //   704: aload_0
      //   705: aload_1
      //   706: iload #6
      //   708: iconst_1
      //   709: invokestatic parseDimensionConstraints : (Ljava/lang/Object;Landroid/content/res/TypedArray;II)V
      //   712: aload_0
      //   713: iconst_1
      //   714: putfield heightSet : Z
      //   717: goto -> 2078
      //   720: aload_0
      //   721: aload_1
      //   722: iload #6
      //   724: iconst_0
      //   725: invokestatic parseDimensionConstraints : (Ljava/lang/Object;Landroid/content/res/TypedArray;II)V
      //   728: aload_0
      //   729: iconst_1
      //   730: putfield widthSet : Z
      //   733: goto -> 2078
      //   736: aload_0
      //   737: aload_1
      //   738: iload #6
      //   740: aload_0
      //   741: getfield goneBaselineMargin : I
      //   744: invokevirtual getDimensionPixelSize : (II)I
      //   747: putfield goneBaselineMargin : I
      //   750: goto -> 2078
      //   753: aload_0
      //   754: aload_1
      //   755: iload #6
      //   757: aload_0
      //   758: getfield baselineMargin : I
      //   761: invokevirtual getDimensionPixelSize : (II)I
      //   764: putfield baselineMargin : I
      //   767: goto -> 2078
      //   770: aload_1
      //   771: iload #6
      //   773: aload_0
      //   774: getfield baselineToBottom : I
      //   777: invokevirtual getResourceId : (II)I
      //   780: istore #7
      //   782: aload_0
      //   783: iload #7
      //   785: putfield baselineToBottom : I
      //   788: iload #7
      //   790: iconst_m1
      //   791: if_icmpne -> 2078
      //   794: aload_0
      //   795: aload_1
      //   796: iload #6
      //   798: iconst_m1
      //   799: invokevirtual getInt : (II)I
      //   802: putfield baselineToBottom : I
      //   805: goto -> 2078
      //   808: aload_1
      //   809: iload #6
      //   811: aload_0
      //   812: getfield baselineToTop : I
      //   815: invokevirtual getResourceId : (II)I
      //   818: istore #7
      //   820: aload_0
      //   821: iload #7
      //   823: putfield baselineToTop : I
      //   826: iload #7
      //   828: iconst_m1
      //   829: if_icmpne -> 2078
      //   832: aload_0
      //   833: aload_1
      //   834: iload #6
      //   836: iconst_m1
      //   837: invokevirtual getInt : (II)I
      //   840: putfield baselineToTop : I
      //   843: goto -> 2078
      //   846: aload_0
      //   847: aload_1
      //   848: iload #6
      //   850: invokevirtual getString : (I)Ljava/lang/String;
      //   853: putfield constraintTag : Ljava/lang/String;
      //   856: goto -> 2078
      //   859: aload_0
      //   860: aload_1
      //   861: iload #6
      //   863: aload_0
      //   864: getfield editorAbsoluteY : I
      //   867: invokevirtual getDimensionPixelOffset : (II)I
      //   870: putfield editorAbsoluteY : I
      //   873: goto -> 2078
      //   876: aload_0
      //   877: aload_1
      //   878: iload #6
      //   880: aload_0
      //   881: getfield editorAbsoluteX : I
      //   884: invokevirtual getDimensionPixelOffset : (II)I
      //   887: putfield editorAbsoluteX : I
      //   890: goto -> 2078
      //   893: aload_0
      //   894: aload_1
      //   895: iload #6
      //   897: iconst_0
      //   898: invokevirtual getInt : (II)I
      //   901: putfield verticalChainStyle : I
      //   904: goto -> 2078
      //   907: aload_0
      //   908: aload_1
      //   909: iload #6
      //   911: iconst_0
      //   912: invokevirtual getInt : (II)I
      //   915: putfield horizontalChainStyle : I
      //   918: goto -> 2078
      //   921: aload_0
      //   922: aload_1
      //   923: iload #6
      //   925: aload_0
      //   926: getfield verticalWeight : F
      //   929: invokevirtual getFloat : (IF)F
      //   932: putfield verticalWeight : F
      //   935: goto -> 2078
      //   938: aload_0
      //   939: aload_1
      //   940: iload #6
      //   942: aload_0
      //   943: getfield horizontalWeight : F
      //   946: invokevirtual getFloat : (IF)F
      //   949: putfield horizontalWeight : F
      //   952: goto -> 2078
      //   955: aload_0
      //   956: aload_1
      //   957: iload #6
      //   959: invokevirtual getString : (I)Ljava/lang/String;
      //   962: invokestatic parseDimensionRatioString : (Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;Ljava/lang/String;)V
      //   965: goto -> 2078
      //   968: aload_0
      //   969: fconst_0
      //   970: aload_1
      //   971: iload #6
      //   973: aload_0
      //   974: getfield matchConstraintPercentHeight : F
      //   977: invokevirtual getFloat : (IF)F
      //   980: invokestatic max : (FF)F
      //   983: putfield matchConstraintPercentHeight : F
      //   986: aload_0
      //   987: iconst_2
      //   988: putfield matchConstraintDefaultHeight : I
      //   991: goto -> 2078
      //   994: aload_0
      //   995: aload_1
      //   996: iload #6
      //   998: aload_0
      //   999: getfield matchConstraintMaxHeight : I
      //   1002: invokevirtual getDimensionPixelSize : (II)I
      //   1005: putfield matchConstraintMaxHeight : I
      //   1008: goto -> 2078
      //   1011: aload_1
      //   1012: iload #6
      //   1014: aload_0
      //   1015: getfield matchConstraintMaxHeight : I
      //   1018: invokevirtual getInt : (II)I
      //   1021: bipush #-2
      //   1023: if_icmpne -> 2078
      //   1026: aload_0
      //   1027: bipush #-2
      //   1029: putfield matchConstraintMaxHeight : I
      //   1032: goto -> 2078
      //   1035: aload_0
      //   1036: aload_1
      //   1037: iload #6
      //   1039: aload_0
      //   1040: getfield matchConstraintMinHeight : I
      //   1043: invokevirtual getDimensionPixelSize : (II)I
      //   1046: putfield matchConstraintMinHeight : I
      //   1049: goto -> 2078
      //   1052: aload_1
      //   1053: iload #6
      //   1055: aload_0
      //   1056: getfield matchConstraintMinHeight : I
      //   1059: invokevirtual getInt : (II)I
      //   1062: bipush #-2
      //   1064: if_icmpne -> 2078
      //   1067: aload_0
      //   1068: bipush #-2
      //   1070: putfield matchConstraintMinHeight : I
      //   1073: goto -> 2078
      //   1076: aload_0
      //   1077: fconst_0
      //   1078: aload_1
      //   1079: iload #6
      //   1081: aload_0
      //   1082: getfield matchConstraintPercentWidth : F
      //   1085: invokevirtual getFloat : (IF)F
      //   1088: invokestatic max : (FF)F
      //   1091: putfield matchConstraintPercentWidth : F
      //   1094: aload_0
      //   1095: iconst_2
      //   1096: putfield matchConstraintDefaultWidth : I
      //   1099: goto -> 2078
      //   1102: aload_0
      //   1103: aload_1
      //   1104: iload #6
      //   1106: aload_0
      //   1107: getfield matchConstraintMaxWidth : I
      //   1110: invokevirtual getDimensionPixelSize : (II)I
      //   1113: putfield matchConstraintMaxWidth : I
      //   1116: goto -> 2078
      //   1119: aload_1
      //   1120: iload #6
      //   1122: aload_0
      //   1123: getfield matchConstraintMaxWidth : I
      //   1126: invokevirtual getInt : (II)I
      //   1129: bipush #-2
      //   1131: if_icmpne -> 2078
      //   1134: aload_0
      //   1135: bipush #-2
      //   1137: putfield matchConstraintMaxWidth : I
      //   1140: goto -> 2078
      //   1143: aload_0
      //   1144: aload_1
      //   1145: iload #6
      //   1147: aload_0
      //   1148: getfield matchConstraintMinWidth : I
      //   1151: invokevirtual getDimensionPixelSize : (II)I
      //   1154: putfield matchConstraintMinWidth : I
      //   1157: goto -> 2078
      //   1160: aload_1
      //   1161: iload #6
      //   1163: aload_0
      //   1164: getfield matchConstraintMinWidth : I
      //   1167: invokevirtual getInt : (II)I
      //   1170: bipush #-2
      //   1172: if_icmpne -> 2078
      //   1175: aload_0
      //   1176: bipush #-2
      //   1178: putfield matchConstraintMinWidth : I
      //   1181: goto -> 2078
      //   1184: aload_1
      //   1185: iload #6
      //   1187: iconst_0
      //   1188: invokevirtual getInt : (II)I
      //   1191: istore #6
      //   1193: aload_0
      //   1194: iload #6
      //   1196: putfield matchConstraintDefaultHeight : I
      //   1199: iload #6
      //   1201: iconst_1
      //   1202: if_icmpne -> 2078
      //   1205: ldc_w 'ConstraintLayout'
      //   1208: ldc_w 'layout_constraintHeight_default="wrap" is deprecated.\\nUse layout_height="WRAP_CONTENT" and layout_constrainedHeight="true" instead.'
      //   1211: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1214: pop
      //   1215: goto -> 2078
      //   1218: aload_1
      //   1219: iload #6
      //   1221: iconst_0
      //   1222: invokevirtual getInt : (II)I
      //   1225: istore #6
      //   1227: aload_0
      //   1228: iload #6
      //   1230: putfield matchConstraintDefaultWidth : I
      //   1233: iload #6
      //   1235: iconst_1
      //   1236: if_icmpne -> 2078
      //   1239: ldc_w 'ConstraintLayout'
      //   1242: ldc_w 'layout_constraintWidth_default="wrap" is deprecated.\\nUse layout_width="WRAP_CONTENT" and layout_constrainedWidth="true" instead.'
      //   1245: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1248: pop
      //   1249: goto -> 2078
      //   1252: aload_0
      //   1253: aload_1
      //   1254: iload #6
      //   1256: aload_0
      //   1257: getfield verticalBias : F
      //   1260: invokevirtual getFloat : (IF)F
      //   1263: putfield verticalBias : F
      //   1266: goto -> 2078
      //   1269: aload_0
      //   1270: aload_1
      //   1271: iload #6
      //   1273: aload_0
      //   1274: getfield horizontalBias : F
      //   1277: invokevirtual getFloat : (IF)F
      //   1280: putfield horizontalBias : F
      //   1283: goto -> 2078
      //   1286: aload_0
      //   1287: aload_1
      //   1288: iload #6
      //   1290: aload_0
      //   1291: getfield constrainedHeight : Z
      //   1294: invokevirtual getBoolean : (IZ)Z
      //   1297: putfield constrainedHeight : Z
      //   1300: goto -> 2078
      //   1303: aload_0
      //   1304: aload_1
      //   1305: iload #6
      //   1307: aload_0
      //   1308: getfield constrainedWidth : Z
      //   1311: invokevirtual getBoolean : (IZ)Z
      //   1314: putfield constrainedWidth : Z
      //   1317: goto -> 2078
      //   1320: aload_0
      //   1321: aload_1
      //   1322: iload #6
      //   1324: aload_0
      //   1325: getfield goneEndMargin : I
      //   1328: invokevirtual getDimensionPixelSize : (II)I
      //   1331: putfield goneEndMargin : I
      //   1334: goto -> 2078
      //   1337: aload_0
      //   1338: aload_1
      //   1339: iload #6
      //   1341: aload_0
      //   1342: getfield goneStartMargin : I
      //   1345: invokevirtual getDimensionPixelSize : (II)I
      //   1348: putfield goneStartMargin : I
      //   1351: goto -> 2078
      //   1354: aload_0
      //   1355: aload_1
      //   1356: iload #6
      //   1358: aload_0
      //   1359: getfield goneBottomMargin : I
      //   1362: invokevirtual getDimensionPixelSize : (II)I
      //   1365: putfield goneBottomMargin : I
      //   1368: goto -> 2078
      //   1371: aload_0
      //   1372: aload_1
      //   1373: iload #6
      //   1375: aload_0
      //   1376: getfield goneRightMargin : I
      //   1379: invokevirtual getDimensionPixelSize : (II)I
      //   1382: putfield goneRightMargin : I
      //   1385: goto -> 2078
      //   1388: aload_0
      //   1389: aload_1
      //   1390: iload #6
      //   1392: aload_0
      //   1393: getfield goneTopMargin : I
      //   1396: invokevirtual getDimensionPixelSize : (II)I
      //   1399: putfield goneTopMargin : I
      //   1402: goto -> 2078
      //   1405: aload_0
      //   1406: aload_1
      //   1407: iload #6
      //   1409: aload_0
      //   1410: getfield goneLeftMargin : I
      //   1413: invokevirtual getDimensionPixelSize : (II)I
      //   1416: putfield goneLeftMargin : I
      //   1419: goto -> 2078
      //   1422: aload_1
      //   1423: iload #6
      //   1425: aload_0
      //   1426: getfield endToEnd : I
      //   1429: invokevirtual getResourceId : (II)I
      //   1432: istore #7
      //   1434: aload_0
      //   1435: iload #7
      //   1437: putfield endToEnd : I
      //   1440: iload #7
      //   1442: iconst_m1
      //   1443: if_icmpne -> 2078
      //   1446: aload_0
      //   1447: aload_1
      //   1448: iload #6
      //   1450: iconst_m1
      //   1451: invokevirtual getInt : (II)I
      //   1454: putfield endToEnd : I
      //   1457: goto -> 2078
      //   1460: aload_1
      //   1461: iload #6
      //   1463: aload_0
      //   1464: getfield endToStart : I
      //   1467: invokevirtual getResourceId : (II)I
      //   1470: istore #7
      //   1472: aload_0
      //   1473: iload #7
      //   1475: putfield endToStart : I
      //   1478: iload #7
      //   1480: iconst_m1
      //   1481: if_icmpne -> 2078
      //   1484: aload_0
      //   1485: aload_1
      //   1486: iload #6
      //   1488: iconst_m1
      //   1489: invokevirtual getInt : (II)I
      //   1492: putfield endToStart : I
      //   1495: goto -> 2078
      //   1498: aload_1
      //   1499: iload #6
      //   1501: aload_0
      //   1502: getfield startToStart : I
      //   1505: invokevirtual getResourceId : (II)I
      //   1508: istore #7
      //   1510: aload_0
      //   1511: iload #7
      //   1513: putfield startToStart : I
      //   1516: iload #7
      //   1518: iconst_m1
      //   1519: if_icmpne -> 2078
      //   1522: aload_0
      //   1523: aload_1
      //   1524: iload #6
      //   1526: iconst_m1
      //   1527: invokevirtual getInt : (II)I
      //   1530: putfield startToStart : I
      //   1533: goto -> 2078
      //   1536: aload_1
      //   1537: iload #6
      //   1539: aload_0
      //   1540: getfield startToEnd : I
      //   1543: invokevirtual getResourceId : (II)I
      //   1546: istore #7
      //   1548: aload_0
      //   1549: iload #7
      //   1551: putfield startToEnd : I
      //   1554: iload #7
      //   1556: iconst_m1
      //   1557: if_icmpne -> 2078
      //   1560: aload_0
      //   1561: aload_1
      //   1562: iload #6
      //   1564: iconst_m1
      //   1565: invokevirtual getInt : (II)I
      //   1568: putfield startToEnd : I
      //   1571: goto -> 2078
      //   1574: aload_1
      //   1575: iload #6
      //   1577: aload_0
      //   1578: getfield baselineToBaseline : I
      //   1581: invokevirtual getResourceId : (II)I
      //   1584: istore #7
      //   1586: aload_0
      //   1587: iload #7
      //   1589: putfield baselineToBaseline : I
      //   1592: iload #7
      //   1594: iconst_m1
      //   1595: if_icmpne -> 2078
      //   1598: aload_0
      //   1599: aload_1
      //   1600: iload #6
      //   1602: iconst_m1
      //   1603: invokevirtual getInt : (II)I
      //   1606: putfield baselineToBaseline : I
      //   1609: goto -> 2078
      //   1612: aload_1
      //   1613: iload #6
      //   1615: aload_0
      //   1616: getfield bottomToBottom : I
      //   1619: invokevirtual getResourceId : (II)I
      //   1622: istore #7
      //   1624: aload_0
      //   1625: iload #7
      //   1627: putfield bottomToBottom : I
      //   1630: iload #7
      //   1632: iconst_m1
      //   1633: if_icmpne -> 2078
      //   1636: aload_0
      //   1637: aload_1
      //   1638: iload #6
      //   1640: iconst_m1
      //   1641: invokevirtual getInt : (II)I
      //   1644: putfield bottomToBottom : I
      //   1647: goto -> 2078
      //   1650: aload_1
      //   1651: iload #6
      //   1653: aload_0
      //   1654: getfield bottomToTop : I
      //   1657: invokevirtual getResourceId : (II)I
      //   1660: istore #7
      //   1662: aload_0
      //   1663: iload #7
      //   1665: putfield bottomToTop : I
      //   1668: iload #7
      //   1670: iconst_m1
      //   1671: if_icmpne -> 2078
      //   1674: aload_0
      //   1675: aload_1
      //   1676: iload #6
      //   1678: iconst_m1
      //   1679: invokevirtual getInt : (II)I
      //   1682: putfield bottomToTop : I
      //   1685: goto -> 2078
      //   1688: aload_1
      //   1689: iload #6
      //   1691: aload_0
      //   1692: getfield topToBottom : I
      //   1695: invokevirtual getResourceId : (II)I
      //   1698: istore #7
      //   1700: aload_0
      //   1701: iload #7
      //   1703: putfield topToBottom : I
      //   1706: iload #7
      //   1708: iconst_m1
      //   1709: if_icmpne -> 2078
      //   1712: aload_0
      //   1713: aload_1
      //   1714: iload #6
      //   1716: iconst_m1
      //   1717: invokevirtual getInt : (II)I
      //   1720: putfield topToBottom : I
      //   1723: goto -> 2078
      //   1726: aload_1
      //   1727: iload #6
      //   1729: aload_0
      //   1730: getfield topToTop : I
      //   1733: invokevirtual getResourceId : (II)I
      //   1736: istore #7
      //   1738: aload_0
      //   1739: iload #7
      //   1741: putfield topToTop : I
      //   1744: iload #7
      //   1746: iconst_m1
      //   1747: if_icmpne -> 2078
      //   1750: aload_0
      //   1751: aload_1
      //   1752: iload #6
      //   1754: iconst_m1
      //   1755: invokevirtual getInt : (II)I
      //   1758: putfield topToTop : I
      //   1761: goto -> 2078
      //   1764: aload_1
      //   1765: iload #6
      //   1767: aload_0
      //   1768: getfield rightToRight : I
      //   1771: invokevirtual getResourceId : (II)I
      //   1774: istore #7
      //   1776: aload_0
      //   1777: iload #7
      //   1779: putfield rightToRight : I
      //   1782: iload #7
      //   1784: iconst_m1
      //   1785: if_icmpne -> 2078
      //   1788: aload_0
      //   1789: aload_1
      //   1790: iload #6
      //   1792: iconst_m1
      //   1793: invokevirtual getInt : (II)I
      //   1796: putfield rightToRight : I
      //   1799: goto -> 2078
      //   1802: aload_1
      //   1803: iload #6
      //   1805: aload_0
      //   1806: getfield rightToLeft : I
      //   1809: invokevirtual getResourceId : (II)I
      //   1812: istore #7
      //   1814: aload_0
      //   1815: iload #7
      //   1817: putfield rightToLeft : I
      //   1820: iload #7
      //   1822: iconst_m1
      //   1823: if_icmpne -> 2078
      //   1826: aload_0
      //   1827: aload_1
      //   1828: iload #6
      //   1830: iconst_m1
      //   1831: invokevirtual getInt : (II)I
      //   1834: putfield rightToLeft : I
      //   1837: goto -> 2078
      //   1840: aload_1
      //   1841: iload #6
      //   1843: aload_0
      //   1844: getfield leftToRight : I
      //   1847: invokevirtual getResourceId : (II)I
      //   1850: istore #7
      //   1852: aload_0
      //   1853: iload #7
      //   1855: putfield leftToRight : I
      //   1858: iload #7
      //   1860: iconst_m1
      //   1861: if_icmpne -> 2078
      //   1864: aload_0
      //   1865: aload_1
      //   1866: iload #6
      //   1868: iconst_m1
      //   1869: invokevirtual getInt : (II)I
      //   1872: putfield leftToRight : I
      //   1875: goto -> 2078
      //   1878: aload_1
      //   1879: iload #6
      //   1881: aload_0
      //   1882: getfield leftToLeft : I
      //   1885: invokevirtual getResourceId : (II)I
      //   1888: istore #7
      //   1890: aload_0
      //   1891: iload #7
      //   1893: putfield leftToLeft : I
      //   1896: iload #7
      //   1898: iconst_m1
      //   1899: if_icmpne -> 2078
      //   1902: aload_0
      //   1903: aload_1
      //   1904: iload #6
      //   1906: iconst_m1
      //   1907: invokevirtual getInt : (II)I
      //   1910: putfield leftToLeft : I
      //   1913: goto -> 2078
      //   1916: aload_0
      //   1917: aload_1
      //   1918: iload #6
      //   1920: aload_0
      //   1921: getfield guidePercent : F
      //   1924: invokevirtual getFloat : (IF)F
      //   1927: putfield guidePercent : F
      //   1930: goto -> 2078
      //   1933: aload_0
      //   1934: aload_1
      //   1935: iload #6
      //   1937: aload_0
      //   1938: getfield guideEnd : I
      //   1941: invokevirtual getDimensionPixelOffset : (II)I
      //   1944: putfield guideEnd : I
      //   1947: goto -> 2078
      //   1950: aload_0
      //   1951: aload_1
      //   1952: iload #6
      //   1954: aload_0
      //   1955: getfield guideBegin : I
      //   1958: invokevirtual getDimensionPixelOffset : (II)I
      //   1961: putfield guideBegin : I
      //   1964: goto -> 2078
      //   1967: aload_1
      //   1968: iload #6
      //   1970: aload_0
      //   1971: getfield circleAngle : F
      //   1974: invokevirtual getFloat : (IF)F
      //   1977: ldc_w 360.0
      //   1980: frem
      //   1981: fstore_3
      //   1982: aload_0
      //   1983: fload_3
      //   1984: putfield circleAngle : F
      //   1987: fload_3
      //   1988: fconst_0
      //   1989: fcmpg
      //   1990: ifge -> 2078
      //   1993: aload_0
      //   1994: ldc_w 360.0
      //   1997: fload_3
      //   1998: fsub
      //   1999: ldc_w 360.0
      //   2002: frem
      //   2003: putfield circleAngle : F
      //   2006: goto -> 2078
      //   2009: aload_0
      //   2010: aload_1
      //   2011: iload #6
      //   2013: aload_0
      //   2014: getfield circleRadius : I
      //   2017: invokevirtual getDimensionPixelSize : (II)I
      //   2020: putfield circleRadius : I
      //   2023: goto -> 2078
      //   2026: aload_1
      //   2027: iload #6
      //   2029: aload_0
      //   2030: getfield circleConstraint : I
      //   2033: invokevirtual getResourceId : (II)I
      //   2036: istore #7
      //   2038: aload_0
      //   2039: iload #7
      //   2041: putfield circleConstraint : I
      //   2044: iload #7
      //   2046: iconst_m1
      //   2047: if_icmpne -> 2078
      //   2050: aload_0
      //   2051: aload_1
      //   2052: iload #6
      //   2054: iconst_m1
      //   2055: invokevirtual getInt : (II)I
      //   2058: putfield circleConstraint : I
      //   2061: goto -> 2078
      //   2064: aload_0
      //   2065: aload_1
      //   2066: iload #6
      //   2068: aload_0
      //   2069: getfield orientation : I
      //   2072: invokevirtual getInt : (II)I
      //   2075: putfield orientation : I
      //   2078: iload #4
      //   2080: iconst_1
      //   2081: iadd
      //   2082: istore #4
      //   2084: goto -> 400
      //   2087: aload_1
      //   2088: invokevirtual recycle : ()V
      //   2091: aload_0
      //   2092: invokevirtual validate : ()V
      //   2095: return
      //   2096: astore_2
      //   2097: goto -> 1011
      //   2100: astore_2
      //   2101: goto -> 1052
      //   2104: astore_2
      //   2105: goto -> 1119
      //   2108: astore_2
      //   2109: goto -> 1160
      // Exception table:
      //   from	to	target	type
      //   994	1008	2096	java/lang/Exception
      //   1035	1049	2100	java/lang/Exception
      //   1102	1116	2104	java/lang/Exception
      //   1143	1157	2108	java/lang/Exception
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.guideBegin = param1LayoutParams.guideBegin;
      this.guideEnd = param1LayoutParams.guideEnd;
      this.guidePercent = param1LayoutParams.guidePercent;
      this.leftToLeft = param1LayoutParams.leftToLeft;
      this.leftToRight = param1LayoutParams.leftToRight;
      this.rightToLeft = param1LayoutParams.rightToLeft;
      this.rightToRight = param1LayoutParams.rightToRight;
      this.topToTop = param1LayoutParams.topToTop;
      this.topToBottom = param1LayoutParams.topToBottom;
      this.bottomToTop = param1LayoutParams.bottomToTop;
      this.bottomToBottom = param1LayoutParams.bottomToBottom;
      this.baselineToBaseline = param1LayoutParams.baselineToBaseline;
      this.baselineToTop = param1LayoutParams.baselineToTop;
      this.baselineToBottom = param1LayoutParams.baselineToBottom;
      this.circleConstraint = param1LayoutParams.circleConstraint;
      this.circleRadius = param1LayoutParams.circleRadius;
      this.circleAngle = param1LayoutParams.circleAngle;
      this.startToEnd = param1LayoutParams.startToEnd;
      this.startToStart = param1LayoutParams.startToStart;
      this.endToStart = param1LayoutParams.endToStart;
      this.endToEnd = param1LayoutParams.endToEnd;
      this.goneLeftMargin = param1LayoutParams.goneLeftMargin;
      this.goneTopMargin = param1LayoutParams.goneTopMargin;
      this.goneRightMargin = param1LayoutParams.goneRightMargin;
      this.goneBottomMargin = param1LayoutParams.goneBottomMargin;
      this.goneStartMargin = param1LayoutParams.goneStartMargin;
      this.goneEndMargin = param1LayoutParams.goneEndMargin;
      this.goneBaselineMargin = param1LayoutParams.goneBaselineMargin;
      this.baselineMargin = param1LayoutParams.baselineMargin;
      this.horizontalBias = param1LayoutParams.horizontalBias;
      this.verticalBias = param1LayoutParams.verticalBias;
      this.dimensionRatio = param1LayoutParams.dimensionRatio;
      this.dimensionRatioValue = param1LayoutParams.dimensionRatioValue;
      this.dimensionRatioSide = param1LayoutParams.dimensionRatioSide;
      this.horizontalWeight = param1LayoutParams.horizontalWeight;
      this.verticalWeight = param1LayoutParams.verticalWeight;
      this.horizontalChainStyle = param1LayoutParams.horizontalChainStyle;
      this.verticalChainStyle = param1LayoutParams.verticalChainStyle;
      this.constrainedWidth = param1LayoutParams.constrainedWidth;
      this.constrainedHeight = param1LayoutParams.constrainedHeight;
      this.matchConstraintDefaultWidth = param1LayoutParams.matchConstraintDefaultWidth;
      this.matchConstraintDefaultHeight = param1LayoutParams.matchConstraintDefaultHeight;
      this.matchConstraintMinWidth = param1LayoutParams.matchConstraintMinWidth;
      this.matchConstraintMaxWidth = param1LayoutParams.matchConstraintMaxWidth;
      this.matchConstraintMinHeight = param1LayoutParams.matchConstraintMinHeight;
      this.matchConstraintMaxHeight = param1LayoutParams.matchConstraintMaxHeight;
      this.matchConstraintPercentWidth = param1LayoutParams.matchConstraintPercentWidth;
      this.matchConstraintPercentHeight = param1LayoutParams.matchConstraintPercentHeight;
      this.editorAbsoluteX = param1LayoutParams.editorAbsoluteX;
      this.editorAbsoluteY = param1LayoutParams.editorAbsoluteY;
      this.orientation = param1LayoutParams.orientation;
      this.horizontalDimensionFixed = param1LayoutParams.horizontalDimensionFixed;
      this.verticalDimensionFixed = param1LayoutParams.verticalDimensionFixed;
      this.needsBaseline = param1LayoutParams.needsBaseline;
      this.isGuideline = param1LayoutParams.isGuideline;
      this.resolvedLeftToLeft = param1LayoutParams.resolvedLeftToLeft;
      this.resolvedLeftToRight = param1LayoutParams.resolvedLeftToRight;
      this.resolvedRightToLeft = param1LayoutParams.resolvedRightToLeft;
      this.resolvedRightToRight = param1LayoutParams.resolvedRightToRight;
      this.resolveGoneLeftMargin = param1LayoutParams.resolveGoneLeftMargin;
      this.resolveGoneRightMargin = param1LayoutParams.resolveGoneRightMargin;
      this.resolvedHorizontalBias = param1LayoutParams.resolvedHorizontalBias;
      this.constraintTag = param1LayoutParams.constraintTag;
      this.wrapBehaviorInParent = param1LayoutParams.wrapBehaviorInParent;
      this.widget = param1LayoutParams.widget;
      this.widthSet = param1LayoutParams.widthSet;
      this.heightSet = param1LayoutParams.heightSet;
    }
    
    public String getConstraintTag() {
      return this.constraintTag;
    }
    
    public ConstraintWidget getConstraintWidget() {
      return this.widget;
    }
    
    public void reset() {
      ConstraintWidget constraintWidget = this.widget;
      if (constraintWidget != null)
        constraintWidget.reset(); 
    }
    
    public void resolveLayoutDirection(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield leftMargin : I
      //   4: istore #4
      //   6: aload_0
      //   7: getfield rightMargin : I
      //   10: istore #5
      //   12: getstatic android/os/Build$VERSION.SDK_INT : I
      //   15: istore #6
      //   17: iconst_0
      //   18: istore_3
      //   19: iload #6
      //   21: bipush #17
      //   23: if_icmplt -> 44
      //   26: aload_0
      //   27: iload_1
      //   28: invokespecial resolveLayoutDirection : (I)V
      //   31: iconst_1
      //   32: aload_0
      //   33: invokevirtual getLayoutDirection : ()I
      //   36: if_icmpne -> 44
      //   39: iconst_1
      //   40: istore_1
      //   41: goto -> 46
      //   44: iconst_0
      //   45: istore_1
      //   46: aload_0
      //   47: iconst_m1
      //   48: putfield resolvedRightToLeft : I
      //   51: aload_0
      //   52: iconst_m1
      //   53: putfield resolvedRightToRight : I
      //   56: aload_0
      //   57: iconst_m1
      //   58: putfield resolvedLeftToLeft : I
      //   61: aload_0
      //   62: iconst_m1
      //   63: putfield resolvedLeftToRight : I
      //   66: aload_0
      //   67: iconst_m1
      //   68: putfield resolveGoneLeftMargin : I
      //   71: aload_0
      //   72: iconst_m1
      //   73: putfield resolveGoneRightMargin : I
      //   76: aload_0
      //   77: aload_0
      //   78: getfield goneLeftMargin : I
      //   81: putfield resolveGoneLeftMargin : I
      //   84: aload_0
      //   85: aload_0
      //   86: getfield goneRightMargin : I
      //   89: putfield resolveGoneRightMargin : I
      //   92: aload_0
      //   93: aload_0
      //   94: getfield horizontalBias : F
      //   97: putfield resolvedHorizontalBias : F
      //   100: aload_0
      //   101: aload_0
      //   102: getfield guideBegin : I
      //   105: putfield resolvedGuideBegin : I
      //   108: aload_0
      //   109: aload_0
      //   110: getfield guideEnd : I
      //   113: putfield resolvedGuideEnd : I
      //   116: aload_0
      //   117: aload_0
      //   118: getfield guidePercent : F
      //   121: putfield resolvedGuidePercent : F
      //   124: iload_1
      //   125: ifeq -> 356
      //   128: aload_0
      //   129: getfield startToEnd : I
      //   132: istore_1
      //   133: iload_1
      //   134: iconst_m1
      //   135: if_icmpeq -> 148
      //   138: aload_0
      //   139: iload_1
      //   140: putfield resolvedRightToLeft : I
      //   143: iconst_1
      //   144: istore_1
      //   145: goto -> 171
      //   148: aload_0
      //   149: getfield startToStart : I
      //   152: istore #6
      //   154: iload_3
      //   155: istore_1
      //   156: iload #6
      //   158: iconst_m1
      //   159: if_icmpeq -> 171
      //   162: aload_0
      //   163: iload #6
      //   165: putfield resolvedRightToRight : I
      //   168: goto -> 143
      //   171: aload_0
      //   172: getfield endToStart : I
      //   175: istore_3
      //   176: iload_3
      //   177: iconst_m1
      //   178: if_icmpeq -> 188
      //   181: aload_0
      //   182: iload_3
      //   183: putfield resolvedLeftToRight : I
      //   186: iconst_1
      //   187: istore_1
      //   188: aload_0
      //   189: getfield endToEnd : I
      //   192: istore_3
      //   193: iload_3
      //   194: iconst_m1
      //   195: if_icmpeq -> 205
      //   198: aload_0
      //   199: iload_3
      //   200: putfield resolvedLeftToLeft : I
      //   203: iconst_1
      //   204: istore_1
      //   205: aload_0
      //   206: getfield goneStartMargin : I
      //   209: istore_3
      //   210: iload_3
      //   211: ldc -2147483648
      //   213: if_icmpeq -> 221
      //   216: aload_0
      //   217: iload_3
      //   218: putfield resolveGoneRightMargin : I
      //   221: aload_0
      //   222: getfield goneEndMargin : I
      //   225: istore_3
      //   226: iload_3
      //   227: ldc -2147483648
      //   229: if_icmpeq -> 237
      //   232: aload_0
      //   233: iload_3
      //   234: putfield resolveGoneLeftMargin : I
      //   237: iload_1
      //   238: ifeq -> 251
      //   241: aload_0
      //   242: fconst_1
      //   243: aload_0
      //   244: getfield horizontalBias : F
      //   247: fsub
      //   248: putfield resolvedHorizontalBias : F
      //   251: aload_0
      //   252: getfield isGuideline : Z
      //   255: ifeq -> 448
      //   258: aload_0
      //   259: getfield orientation : I
      //   262: iconst_1
      //   263: if_icmpne -> 448
      //   266: aload_0
      //   267: getfield guidePercent : F
      //   270: fstore_2
      //   271: fload_2
      //   272: ldc -1.0
      //   274: fcmpl
      //   275: ifeq -> 298
      //   278: aload_0
      //   279: fconst_1
      //   280: fload_2
      //   281: fsub
      //   282: putfield resolvedGuidePercent : F
      //   285: aload_0
      //   286: iconst_m1
      //   287: putfield resolvedGuideBegin : I
      //   290: aload_0
      //   291: iconst_m1
      //   292: putfield resolvedGuideEnd : I
      //   295: goto -> 448
      //   298: aload_0
      //   299: getfield guideBegin : I
      //   302: istore_1
      //   303: iload_1
      //   304: iconst_m1
      //   305: if_icmpeq -> 327
      //   308: aload_0
      //   309: iload_1
      //   310: putfield resolvedGuideEnd : I
      //   313: aload_0
      //   314: iconst_m1
      //   315: putfield resolvedGuideBegin : I
      //   318: aload_0
      //   319: ldc -1.0
      //   321: putfield resolvedGuidePercent : F
      //   324: goto -> 448
      //   327: aload_0
      //   328: getfield guideEnd : I
      //   331: istore_1
      //   332: iload_1
      //   333: iconst_m1
      //   334: if_icmpeq -> 448
      //   337: aload_0
      //   338: iload_1
      //   339: putfield resolvedGuideBegin : I
      //   342: aload_0
      //   343: iconst_m1
      //   344: putfield resolvedGuideEnd : I
      //   347: aload_0
      //   348: ldc -1.0
      //   350: putfield resolvedGuidePercent : F
      //   353: goto -> 448
      //   356: aload_0
      //   357: getfield startToEnd : I
      //   360: istore_1
      //   361: iload_1
      //   362: iconst_m1
      //   363: if_icmpeq -> 371
      //   366: aload_0
      //   367: iload_1
      //   368: putfield resolvedLeftToRight : I
      //   371: aload_0
      //   372: getfield startToStart : I
      //   375: istore_1
      //   376: iload_1
      //   377: iconst_m1
      //   378: if_icmpeq -> 386
      //   381: aload_0
      //   382: iload_1
      //   383: putfield resolvedLeftToLeft : I
      //   386: aload_0
      //   387: getfield endToStart : I
      //   390: istore_1
      //   391: iload_1
      //   392: iconst_m1
      //   393: if_icmpeq -> 401
      //   396: aload_0
      //   397: iload_1
      //   398: putfield resolvedRightToLeft : I
      //   401: aload_0
      //   402: getfield endToEnd : I
      //   405: istore_1
      //   406: iload_1
      //   407: iconst_m1
      //   408: if_icmpeq -> 416
      //   411: aload_0
      //   412: iload_1
      //   413: putfield resolvedRightToRight : I
      //   416: aload_0
      //   417: getfield goneStartMargin : I
      //   420: istore_1
      //   421: iload_1
      //   422: ldc -2147483648
      //   424: if_icmpeq -> 432
      //   427: aload_0
      //   428: iload_1
      //   429: putfield resolveGoneLeftMargin : I
      //   432: aload_0
      //   433: getfield goneEndMargin : I
      //   436: istore_1
      //   437: iload_1
      //   438: ldc -2147483648
      //   440: if_icmpeq -> 448
      //   443: aload_0
      //   444: iload_1
      //   445: putfield resolveGoneRightMargin : I
      //   448: aload_0
      //   449: getfield endToStart : I
      //   452: iconst_m1
      //   453: if_icmpne -> 616
      //   456: aload_0
      //   457: getfield endToEnd : I
      //   460: iconst_m1
      //   461: if_icmpne -> 616
      //   464: aload_0
      //   465: getfield startToStart : I
      //   468: iconst_m1
      //   469: if_icmpne -> 616
      //   472: aload_0
      //   473: getfield startToEnd : I
      //   476: iconst_m1
      //   477: if_icmpne -> 616
      //   480: aload_0
      //   481: getfield rightToLeft : I
      //   484: istore_1
      //   485: iload_1
      //   486: iconst_m1
      //   487: if_icmpeq -> 516
      //   490: aload_0
      //   491: iload_1
      //   492: putfield resolvedRightToLeft : I
      //   495: aload_0
      //   496: getfield rightMargin : I
      //   499: ifgt -> 549
      //   502: iload #5
      //   504: ifle -> 549
      //   507: aload_0
      //   508: iload #5
      //   510: putfield rightMargin : I
      //   513: goto -> 549
      //   516: aload_0
      //   517: getfield rightToRight : I
      //   520: istore_1
      //   521: iload_1
      //   522: iconst_m1
      //   523: if_icmpeq -> 549
      //   526: aload_0
      //   527: iload_1
      //   528: putfield resolvedRightToRight : I
      //   531: aload_0
      //   532: getfield rightMargin : I
      //   535: ifgt -> 549
      //   538: iload #5
      //   540: ifle -> 549
      //   543: aload_0
      //   544: iload #5
      //   546: putfield rightMargin : I
      //   549: aload_0
      //   550: getfield leftToLeft : I
      //   553: istore_1
      //   554: iload_1
      //   555: iconst_m1
      //   556: if_icmpeq -> 583
      //   559: aload_0
      //   560: iload_1
      //   561: putfield resolvedLeftToLeft : I
      //   564: aload_0
      //   565: getfield leftMargin : I
      //   568: ifgt -> 616
      //   571: iload #4
      //   573: ifle -> 616
      //   576: aload_0
      //   577: iload #4
      //   579: putfield leftMargin : I
      //   582: return
      //   583: aload_0
      //   584: getfield leftToRight : I
      //   587: istore_1
      //   588: iload_1
      //   589: iconst_m1
      //   590: if_icmpeq -> 616
      //   593: aload_0
      //   594: iload_1
      //   595: putfield resolvedLeftToRight : I
      //   598: aload_0
      //   599: getfield leftMargin : I
      //   602: ifgt -> 616
      //   605: iload #4
      //   607: ifle -> 616
      //   610: aload_0
      //   611: iload #4
      //   613: putfield leftMargin : I
      //   616: return
    }
    
    public void setWidgetDebugName(String param1String) {
      this.widget.setDebugName(param1String);
    }
    
    public void validate() {
      this.isGuideline = false;
      this.horizontalDimensionFixed = true;
      this.verticalDimensionFixed = true;
      if (this.width == -2 && this.constrainedWidth) {
        this.horizontalDimensionFixed = false;
        if (this.matchConstraintDefaultWidth == 0)
          this.matchConstraintDefaultWidth = 1; 
      } 
      if (this.height == -2 && this.constrainedHeight) {
        this.verticalDimensionFixed = false;
        if (this.matchConstraintDefaultHeight == 0)
          this.matchConstraintDefaultHeight = 1; 
      } 
      if (this.width == 0 || this.width == -1) {
        this.horizontalDimensionFixed = false;
        if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
          this.width = -2;
          this.constrainedWidth = true;
        } 
      } 
      if (this.height == 0 || this.height == -1) {
        this.verticalDimensionFixed = false;
        if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
          this.height = -2;
          this.constrainedHeight = true;
        } 
      } 
      if (this.guidePercent != -1.0F || this.guideBegin != -1 || this.guideEnd != -1) {
        this.isGuideline = true;
        this.horizontalDimensionFixed = true;
        this.verticalDimensionFixed = true;
        if (!(this.widget instanceof Guideline))
          this.widget = (ConstraintWidget)new Guideline(); 
        ((Guideline)this.widget).setOrientation(this.orientation);
      } 
    }
    
    private static class Table {
      public static final int ANDROID_ORIENTATION = 1;
      
      public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
      
      public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BOTTOM_OF = 53;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_TO_TOP_OF = 52;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
      
      public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT = 65;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
      
      public static final int LAYOUT_CONSTRAINT_TAG = 51;
      
      public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH = 64;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
      
      public static final int LAYOUT_GONE_MARGIN_BASELINE = 55;
      
      public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
      
      public static final int LAYOUT_GONE_MARGIN_END = 26;
      
      public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
      
      public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
      
      public static final int LAYOUT_GONE_MARGIN_START = 25;
      
      public static final int LAYOUT_GONE_MARGIN_TOP = 22;
      
      public static final int LAYOUT_MARGIN_BASELINE = 54;
      
      public static final int LAYOUT_WRAP_BEHAVIOR_IN_PARENT = 66;
      
      public static final int UNUSED = 0;
      
      public static final SparseIntArray map;
      
      static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        map = sparseIntArray;
        sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth, 64);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight, 65);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toTopOf, 52);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf, 53);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBaseline, 55);
        map.append(R.styleable.ConstraintLayout_Layout_layout_marginBaseline, 54);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTag, 51);
        map.append(R.styleable.ConstraintLayout_Layout_layout_wrapBehaviorInParent, 66);
      }
    }
  }
  
  private static class Table {
    public static final int ANDROID_ORIENTATION = 1;
    
    public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
    
    public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BOTTOM_OF = 53;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_TO_TOP_OF = 52;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
    
    public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT = 65;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
    
    public static final int LAYOUT_CONSTRAINT_TAG = 51;
    
    public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH = 64;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
    
    public static final int LAYOUT_GONE_MARGIN_BASELINE = 55;
    
    public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
    
    public static final int LAYOUT_GONE_MARGIN_END = 26;
    
    public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
    
    public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
    
    public static final int LAYOUT_GONE_MARGIN_START = 25;
    
    public static final int LAYOUT_GONE_MARGIN_TOP = 22;
    
    public static final int LAYOUT_MARGIN_BASELINE = 54;
    
    public static final int LAYOUT_WRAP_BEHAVIOR_IN_PARENT = 66;
    
    public static final int UNUSED = 0;
    
    public static final SparseIntArray map;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      map = sparseIntArray;
      sparseIntArray.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth, 64);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight, 65);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toTopOf, 52);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf, 53);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBaseline, 55);
      map.append(R.styleable.ConstraintLayout_Layout_layout_marginBaseline, 54);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTag, 51);
      map.append(R.styleable.ConstraintLayout_Layout_layout_wrapBehaviorInParent, 66);
    }
  }
  
  class Measurer implements BasicMeasure.Measurer {
    ConstraintLayout layout;
    
    int layoutHeightSpec;
    
    int layoutWidthSpec;
    
    int paddingBottom;
    
    int paddingHeight;
    
    int paddingTop;
    
    int paddingWidth;
    
    public Measurer(ConstraintLayout param1ConstraintLayout1) {
      this.layout = param1ConstraintLayout1;
    }
    
    private boolean isSimilarSpec(int param1Int1, int param1Int2, int param1Int3) {
      if (param1Int1 == param1Int2)
        return true; 
      int i = View.MeasureSpec.getMode(param1Int1);
      View.MeasureSpec.getSize(param1Int1);
      param1Int1 = View.MeasureSpec.getMode(param1Int2);
      param1Int2 = View.MeasureSpec.getSize(param1Int2);
      return (param1Int1 == 1073741824 && (i == Integer.MIN_VALUE || i == 0) && param1Int3 == param1Int2);
    }
    
    public void captureLayoutInfo(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.paddingTop = param1Int3;
      this.paddingBottom = param1Int4;
      this.paddingWidth = param1Int5;
      this.paddingHeight = param1Int6;
      this.layoutWidthSpec = param1Int1;
      this.layoutHeightSpec = param1Int2;
    }
    
    public final void didMeasures() {
      int j = this.layout.getChildCount();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++) {
        View view = this.layout.getChildAt(i);
        if (view instanceof Placeholder)
          ((Placeholder)view).updatePostMeasure(this.layout); 
      } 
      j = this.layout.mConstraintHelpers.size();
      if (j > 0)
        for (i = bool; i < j; i++)
          ((ConstraintHelper)this.layout.mConstraintHelpers.get(i)).updatePostMeasure(this.layout);  
    }
    
    public final void measure(ConstraintWidget param1ConstraintWidget, BasicMeasure.Measure param1Measure) {
      // Byte code:
      //   0: aload_1
      //   1: ifnonnull -> 5
      //   4: return
      //   5: aload_1
      //   6: invokevirtual getVisibility : ()I
      //   9: bipush #8
      //   11: if_icmpne -> 37
      //   14: aload_1
      //   15: invokevirtual isInPlaceholder : ()Z
      //   18: ifne -> 37
      //   21: aload_2
      //   22: iconst_0
      //   23: putfield measuredWidth : I
      //   26: aload_2
      //   27: iconst_0
      //   28: putfield measuredHeight : I
      //   31: aload_2
      //   32: iconst_0
      //   33: putfield measuredBaseline : I
      //   36: return
      //   37: aload_1
      //   38: invokevirtual getParent : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   41: ifnonnull -> 45
      //   44: return
      //   45: aload_2
      //   46: getfield horizontalBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
      //   49: astore #20
      //   51: aload_2
      //   52: getfield verticalBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
      //   55: astore #21
      //   57: aload_2
      //   58: getfield horizontalDimension : I
      //   61: istore #4
      //   63: aload_2
      //   64: getfield verticalDimension : I
      //   67: istore #7
      //   69: aload_0
      //   70: getfield paddingTop : I
      //   73: aload_0
      //   74: getfield paddingBottom : I
      //   77: iadd
      //   78: istore #8
      //   80: aload_0
      //   81: getfield paddingWidth : I
      //   84: istore #5
      //   86: aload_1
      //   87: invokevirtual getCompanionWidget : ()Ljava/lang/Object;
      //   90: checkcast android/view/View
      //   93: astore #19
      //   95: getstatic androidx/constraintlayout/widget/ConstraintLayout$1.$SwitchMap$androidx$constraintlayout$core$widgets$ConstraintWidget$DimensionBehaviour : [I
      //   98: aload #20
      //   100: invokevirtual ordinal : ()I
      //   103: iaload
      //   104: istore #6
      //   106: iload #6
      //   108: iconst_1
      //   109: if_icmpeq -> 322
      //   112: iload #6
      //   114: iconst_2
      //   115: if_icmpeq -> 306
      //   118: iload #6
      //   120: iconst_3
      //   121: if_icmpeq -> 286
      //   124: iload #6
      //   126: iconst_4
      //   127: if_icmpeq -> 136
      //   130: iconst_0
      //   131: istore #4
      //   133: goto -> 331
      //   136: aload_0
      //   137: getfield layoutWidthSpec : I
      //   140: iload #5
      //   142: bipush #-2
      //   144: invokestatic getChildMeasureSpec : (III)I
      //   147: istore #6
      //   149: aload_1
      //   150: getfield mMatchConstraintDefaultWidth : I
      //   153: iconst_1
      //   154: if_icmpne -> 163
      //   157: iconst_1
      //   158: istore #5
      //   160: goto -> 166
      //   163: iconst_0
      //   164: istore #5
      //   166: aload_2
      //   167: getfield measureStrategy : I
      //   170: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.TRY_GIVEN_DIMENSIONS : I
      //   173: if_icmpeq -> 190
      //   176: iload #6
      //   178: istore #4
      //   180: aload_2
      //   181: getfield measureStrategy : I
      //   184: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   187: if_icmpne -> 331
      //   190: aload #19
      //   192: invokevirtual getMeasuredHeight : ()I
      //   195: aload_1
      //   196: invokevirtual getHeight : ()I
      //   199: if_icmpne -> 208
      //   202: iconst_1
      //   203: istore #4
      //   205: goto -> 211
      //   208: iconst_0
      //   209: istore #4
      //   211: aload_2
      //   212: getfield measureStrategy : I
      //   215: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   218: if_icmpeq -> 260
      //   221: iload #5
      //   223: ifeq -> 260
      //   226: iload #5
      //   228: ifeq -> 236
      //   231: iload #4
      //   233: ifne -> 260
      //   236: aload #19
      //   238: instanceof androidx/constraintlayout/widget/Placeholder
      //   241: ifne -> 260
      //   244: aload_1
      //   245: invokevirtual isResolvedHorizontally : ()Z
      //   248: ifeq -> 254
      //   251: goto -> 260
      //   254: iconst_0
      //   255: istore #5
      //   257: goto -> 263
      //   260: iconst_1
      //   261: istore #5
      //   263: iload #6
      //   265: istore #4
      //   267: iload #5
      //   269: ifeq -> 331
      //   272: aload_1
      //   273: invokevirtual getWidth : ()I
      //   276: ldc 1073741824
      //   278: invokestatic makeMeasureSpec : (II)I
      //   281: istore #4
      //   283: goto -> 331
      //   286: aload_0
      //   287: getfield layoutWidthSpec : I
      //   290: iload #5
      //   292: aload_1
      //   293: invokevirtual getHorizontalMargin : ()I
      //   296: iadd
      //   297: iconst_m1
      //   298: invokestatic getChildMeasureSpec : (III)I
      //   301: istore #4
      //   303: goto -> 331
      //   306: aload_0
      //   307: getfield layoutWidthSpec : I
      //   310: iload #5
      //   312: bipush #-2
      //   314: invokestatic getChildMeasureSpec : (III)I
      //   317: istore #4
      //   319: goto -> 331
      //   322: iload #4
      //   324: ldc 1073741824
      //   326: invokestatic makeMeasureSpec : (II)I
      //   329: istore #4
      //   331: getstatic androidx/constraintlayout/widget/ConstraintLayout$1.$SwitchMap$androidx$constraintlayout$core$widgets$ConstraintWidget$DimensionBehaviour : [I
      //   334: aload #21
      //   336: invokevirtual ordinal : ()I
      //   339: iaload
      //   340: istore #5
      //   342: iload #5
      //   344: iconst_1
      //   345: if_icmpeq -> 558
      //   348: iload #5
      //   350: iconst_2
      //   351: if_icmpeq -> 542
      //   354: iload #5
      //   356: iconst_3
      //   357: if_icmpeq -> 522
      //   360: iload #5
      //   362: iconst_4
      //   363: if_icmpeq -> 372
      //   366: iconst_0
      //   367: istore #5
      //   369: goto -> 567
      //   372: aload_0
      //   373: getfield layoutHeightSpec : I
      //   376: iload #8
      //   378: bipush #-2
      //   380: invokestatic getChildMeasureSpec : (III)I
      //   383: istore #7
      //   385: aload_1
      //   386: getfield mMatchConstraintDefaultHeight : I
      //   389: iconst_1
      //   390: if_icmpne -> 399
      //   393: iconst_1
      //   394: istore #6
      //   396: goto -> 402
      //   399: iconst_0
      //   400: istore #6
      //   402: aload_2
      //   403: getfield measureStrategy : I
      //   406: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.TRY_GIVEN_DIMENSIONS : I
      //   409: if_icmpeq -> 426
      //   412: iload #7
      //   414: istore #5
      //   416: aload_2
      //   417: getfield measureStrategy : I
      //   420: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   423: if_icmpne -> 567
      //   426: aload #19
      //   428: invokevirtual getMeasuredWidth : ()I
      //   431: aload_1
      //   432: invokevirtual getWidth : ()I
      //   435: if_icmpne -> 444
      //   438: iconst_1
      //   439: istore #5
      //   441: goto -> 447
      //   444: iconst_0
      //   445: istore #5
      //   447: aload_2
      //   448: getfield measureStrategy : I
      //   451: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   454: if_icmpeq -> 496
      //   457: iload #6
      //   459: ifeq -> 496
      //   462: iload #6
      //   464: ifeq -> 472
      //   467: iload #5
      //   469: ifne -> 496
      //   472: aload #19
      //   474: instanceof androidx/constraintlayout/widget/Placeholder
      //   477: ifne -> 496
      //   480: aload_1
      //   481: invokevirtual isResolvedVertically : ()Z
      //   484: ifeq -> 490
      //   487: goto -> 496
      //   490: iconst_0
      //   491: istore #6
      //   493: goto -> 499
      //   496: iconst_1
      //   497: istore #6
      //   499: iload #7
      //   501: istore #5
      //   503: iload #6
      //   505: ifeq -> 567
      //   508: aload_1
      //   509: invokevirtual getHeight : ()I
      //   512: ldc 1073741824
      //   514: invokestatic makeMeasureSpec : (II)I
      //   517: istore #5
      //   519: goto -> 567
      //   522: aload_0
      //   523: getfield layoutHeightSpec : I
      //   526: iload #8
      //   528: aload_1
      //   529: invokevirtual getVerticalMargin : ()I
      //   532: iadd
      //   533: iconst_m1
      //   534: invokestatic getChildMeasureSpec : (III)I
      //   537: istore #5
      //   539: goto -> 567
      //   542: aload_0
      //   543: getfield layoutHeightSpec : I
      //   546: iload #8
      //   548: bipush #-2
      //   550: invokestatic getChildMeasureSpec : (III)I
      //   553: istore #5
      //   555: goto -> 567
      //   558: iload #7
      //   560: ldc 1073741824
      //   562: invokestatic makeMeasureSpec : (II)I
      //   565: istore #5
      //   567: aload_1
      //   568: invokevirtual getParent : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   571: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
      //   574: astore #22
      //   576: aload #22
      //   578: ifnull -> 739
      //   581: aload_0
      //   582: getfield this$0 : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   585: invokestatic access$000 : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   588: sipush #256
      //   591: invokestatic enabled : (II)Z
      //   594: ifeq -> 739
      //   597: aload #19
      //   599: invokevirtual getMeasuredWidth : ()I
      //   602: aload_1
      //   603: invokevirtual getWidth : ()I
      //   606: if_icmpne -> 739
      //   609: aload #19
      //   611: invokevirtual getMeasuredWidth : ()I
      //   614: aload #22
      //   616: invokevirtual getWidth : ()I
      //   619: if_icmpge -> 739
      //   622: aload #19
      //   624: invokevirtual getMeasuredHeight : ()I
      //   627: aload_1
      //   628: invokevirtual getHeight : ()I
      //   631: if_icmpne -> 739
      //   634: aload #19
      //   636: invokevirtual getMeasuredHeight : ()I
      //   639: aload #22
      //   641: invokevirtual getHeight : ()I
      //   644: if_icmpge -> 739
      //   647: aload #19
      //   649: invokevirtual getBaseline : ()I
      //   652: aload_1
      //   653: invokevirtual getBaselineDistance : ()I
      //   656: if_icmpne -> 739
      //   659: aload_1
      //   660: invokevirtual isMeasureRequested : ()Z
      //   663: ifne -> 739
      //   666: aload_0
      //   667: aload_1
      //   668: invokevirtual getLastHorizontalMeasureSpec : ()I
      //   671: iload #4
      //   673: aload_1
      //   674: invokevirtual getWidth : ()I
      //   677: invokespecial isSimilarSpec : (III)Z
      //   680: ifeq -> 706
      //   683: aload_0
      //   684: aload_1
      //   685: invokevirtual getLastVerticalMeasureSpec : ()I
      //   688: iload #5
      //   690: aload_1
      //   691: invokevirtual getHeight : ()I
      //   694: invokespecial isSimilarSpec : (III)Z
      //   697: ifeq -> 706
      //   700: iconst_1
      //   701: istore #6
      //   703: goto -> 709
      //   706: iconst_0
      //   707: istore #6
      //   709: iload #6
      //   711: ifeq -> 739
      //   714: aload_2
      //   715: aload_1
      //   716: invokevirtual getWidth : ()I
      //   719: putfield measuredWidth : I
      //   722: aload_2
      //   723: aload_1
      //   724: invokevirtual getHeight : ()I
      //   727: putfield measuredHeight : I
      //   730: aload_2
      //   731: aload_1
      //   732: invokevirtual getBaselineDistance : ()I
      //   735: putfield measuredBaseline : I
      //   738: return
      //   739: aload #20
      //   741: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
      //   744: if_acmpne -> 753
      //   747: iconst_1
      //   748: istore #6
      //   750: goto -> 756
      //   753: iconst_0
      //   754: istore #6
      //   756: aload #21
      //   758: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
      //   761: if_acmpne -> 770
      //   764: iconst_1
      //   765: istore #7
      //   767: goto -> 773
      //   770: iconst_0
      //   771: istore #7
      //   773: aload #21
      //   775: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
      //   778: if_acmpeq -> 798
      //   781: aload #21
      //   783: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
      //   786: if_acmpne -> 792
      //   789: goto -> 798
      //   792: iconst_0
      //   793: istore #10
      //   795: goto -> 801
      //   798: iconst_1
      //   799: istore #10
      //   801: aload #20
      //   803: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
      //   806: if_acmpeq -> 826
      //   809: aload #20
      //   811: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
      //   814: if_acmpne -> 820
      //   817: goto -> 826
      //   820: iconst_0
      //   821: istore #11
      //   823: goto -> 829
      //   826: iconst_1
      //   827: istore #11
      //   829: iload #6
      //   831: ifeq -> 849
      //   834: aload_1
      //   835: getfield mDimensionRatio : F
      //   838: fconst_0
      //   839: fcmpl
      //   840: ifle -> 849
      //   843: iconst_1
      //   844: istore #12
      //   846: goto -> 852
      //   849: iconst_0
      //   850: istore #12
      //   852: iload #7
      //   854: ifeq -> 872
      //   857: aload_1
      //   858: getfield mDimensionRatio : F
      //   861: fconst_0
      //   862: fcmpl
      //   863: ifle -> 872
      //   866: iconst_1
      //   867: istore #13
      //   869: goto -> 875
      //   872: iconst_0
      //   873: istore #13
      //   875: aload #19
      //   877: ifnonnull -> 881
      //   880: return
      //   881: aload #19
      //   883: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   886: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
      //   889: astore #20
      //   891: aload_2
      //   892: getfield measureStrategy : I
      //   895: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.TRY_GIVEN_DIMENSIONS : I
      //   898: if_icmpeq -> 950
      //   901: aload_2
      //   902: getfield measureStrategy : I
      //   905: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.USE_GIVEN_DIMENSIONS : I
      //   908: if_icmpeq -> 950
      //   911: iload #6
      //   913: ifeq -> 950
      //   916: aload_1
      //   917: getfield mMatchConstraintDefaultWidth : I
      //   920: ifne -> 950
      //   923: iload #7
      //   925: ifeq -> 950
      //   928: aload_1
      //   929: getfield mMatchConstraintDefaultHeight : I
      //   932: ifeq -> 938
      //   935: goto -> 950
      //   938: iconst_0
      //   939: istore #6
      //   941: iconst_0
      //   942: istore #9
      //   944: iconst_0
      //   945: istore #10
      //   947: goto -> 1331
      //   950: aload #19
      //   952: instanceof androidx/constraintlayout/widget/VirtualLayout
      //   955: ifeq -> 988
      //   958: aload_1
      //   959: instanceof androidx/constraintlayout/core/widgets/VirtualLayout
      //   962: ifeq -> 988
      //   965: aload_1
      //   966: checkcast androidx/constraintlayout/core/widgets/VirtualLayout
      //   969: astore #21
      //   971: aload #19
      //   973: checkcast androidx/constraintlayout/widget/VirtualLayout
      //   976: aload #21
      //   978: iload #4
      //   980: iload #5
      //   982: invokevirtual onMeasure : (Landroidx/constraintlayout/core/widgets/VirtualLayout;II)V
      //   985: goto -> 997
      //   988: aload #19
      //   990: iload #4
      //   992: iload #5
      //   994: invokevirtual measure : (II)V
      //   997: aload_1
      //   998: iload #4
      //   1000: iload #5
      //   1002: invokevirtual setLastMeasureSpec : (II)V
      //   1005: aload #19
      //   1007: invokevirtual getMeasuredWidth : ()I
      //   1010: istore #15
      //   1012: aload #19
      //   1014: invokevirtual getMeasuredHeight : ()I
      //   1017: istore #14
      //   1019: aload #19
      //   1021: invokevirtual getBaseline : ()I
      //   1024: istore #16
      //   1026: aload_1
      //   1027: getfield mMatchConstraintMinWidth : I
      //   1030: ifle -> 1047
      //   1033: aload_1
      //   1034: getfield mMatchConstraintMinWidth : I
      //   1037: iload #15
      //   1039: invokestatic max : (II)I
      //   1042: istore #7
      //   1044: goto -> 1051
      //   1047: iload #15
      //   1049: istore #7
      //   1051: iload #7
      //   1053: istore #6
      //   1055: aload_1
      //   1056: getfield mMatchConstraintMaxWidth : I
      //   1059: ifle -> 1073
      //   1062: aload_1
      //   1063: getfield mMatchConstraintMaxWidth : I
      //   1066: iload #7
      //   1068: invokestatic min : (II)I
      //   1071: istore #6
      //   1073: aload_1
      //   1074: getfield mMatchConstraintMinHeight : I
      //   1077: ifle -> 1094
      //   1080: aload_1
      //   1081: getfield mMatchConstraintMinHeight : I
      //   1084: iload #14
      //   1086: invokestatic max : (II)I
      //   1089: istore #7
      //   1091: goto -> 1098
      //   1094: iload #14
      //   1096: istore #7
      //   1098: iload #7
      //   1100: istore #9
      //   1102: aload_1
      //   1103: getfield mMatchConstraintMaxHeight : I
      //   1106: ifle -> 1120
      //   1109: aload_1
      //   1110: getfield mMatchConstraintMaxHeight : I
      //   1113: iload #7
      //   1115: invokestatic min : (II)I
      //   1118: istore #9
      //   1120: iload #6
      //   1122: istore #8
      //   1124: iload #9
      //   1126: istore #7
      //   1128: aload_0
      //   1129: getfield this$0 : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   1132: invokestatic access$000 : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   1135: iconst_1
      //   1136: invokestatic enabled : (II)Z
      //   1139: ifne -> 1223
      //   1142: iload #12
      //   1144: ifeq -> 1176
      //   1147: iload #10
      //   1149: ifeq -> 1176
      //   1152: aload_1
      //   1153: getfield mDimensionRatio : F
      //   1156: fstore_3
      //   1157: iload #9
      //   1159: i2f
      //   1160: fload_3
      //   1161: fmul
      //   1162: ldc_w 0.5
      //   1165: fadd
      //   1166: f2i
      //   1167: istore #8
      //   1169: iload #9
      //   1171: istore #7
      //   1173: goto -> 1223
      //   1176: iload #6
      //   1178: istore #8
      //   1180: iload #9
      //   1182: istore #7
      //   1184: iload #13
      //   1186: ifeq -> 1223
      //   1189: iload #6
      //   1191: istore #8
      //   1193: iload #9
      //   1195: istore #7
      //   1197: iload #11
      //   1199: ifeq -> 1223
      //   1202: aload_1
      //   1203: getfield mDimensionRatio : F
      //   1206: fstore_3
      //   1207: iload #6
      //   1209: i2f
      //   1210: fload_3
      //   1211: fdiv
      //   1212: ldc_w 0.5
      //   1215: fadd
      //   1216: f2i
      //   1217: istore #7
      //   1219: iload #6
      //   1221: istore #8
      //   1223: iload #15
      //   1225: iload #8
      //   1227: if_icmpne -> 1255
      //   1230: iload #16
      //   1232: istore #6
      //   1234: iload #8
      //   1236: istore #9
      //   1238: iload #7
      //   1240: istore #10
      //   1242: iload #14
      //   1244: iload #7
      //   1246: if_icmpeq -> 1252
      //   1249: goto -> 1255
      //   1252: goto -> 1331
      //   1255: iload #15
      //   1257: iload #8
      //   1259: if_icmpeq -> 1271
      //   1262: iload #8
      //   1264: ldc 1073741824
      //   1266: invokestatic makeMeasureSpec : (II)I
      //   1269: istore #4
      //   1271: iload #14
      //   1273: iload #7
      //   1275: if_icmpeq -> 1290
      //   1278: iload #7
      //   1280: ldc 1073741824
      //   1282: invokestatic makeMeasureSpec : (II)I
      //   1285: istore #5
      //   1287: goto -> 1290
      //   1290: aload #19
      //   1292: iload #4
      //   1294: iload #5
      //   1296: invokevirtual measure : (II)V
      //   1299: aload_1
      //   1300: iload #4
      //   1302: iload #5
      //   1304: invokevirtual setLastMeasureSpec : (II)V
      //   1307: aload #19
      //   1309: invokevirtual getMeasuredWidth : ()I
      //   1312: istore #9
      //   1314: aload #19
      //   1316: invokevirtual getMeasuredHeight : ()I
      //   1319: istore #10
      //   1321: aload #19
      //   1323: invokevirtual getBaseline : ()I
      //   1326: istore #6
      //   1328: goto -> 1252
      //   1331: iload #6
      //   1333: iconst_m1
      //   1334: if_icmpeq -> 1343
      //   1337: iconst_1
      //   1338: istore #17
      //   1340: goto -> 1346
      //   1343: iconst_0
      //   1344: istore #17
      //   1346: iload #9
      //   1348: aload_2
      //   1349: getfield horizontalDimension : I
      //   1352: if_icmpne -> 1373
      //   1355: iload #10
      //   1357: aload_2
      //   1358: getfield verticalDimension : I
      //   1361: if_icmpeq -> 1367
      //   1364: goto -> 1373
      //   1367: iconst_0
      //   1368: istore #18
      //   1370: goto -> 1376
      //   1373: iconst_1
      //   1374: istore #18
      //   1376: aload_2
      //   1377: iload #18
      //   1379: putfield measuredNeedsSolverPass : Z
      //   1382: aload #20
      //   1384: getfield needsBaseline : Z
      //   1387: ifeq -> 1393
      //   1390: iconst_1
      //   1391: istore #17
      //   1393: iload #17
      //   1395: ifeq -> 1418
      //   1398: iload #6
      //   1400: iconst_m1
      //   1401: if_icmpeq -> 1418
      //   1404: aload_1
      //   1405: invokevirtual getBaselineDistance : ()I
      //   1408: iload #6
      //   1410: if_icmpeq -> 1418
      //   1413: aload_2
      //   1414: iconst_1
      //   1415: putfield measuredNeedsSolverPass : Z
      //   1418: aload_2
      //   1419: iload #9
      //   1421: putfield measuredWidth : I
      //   1424: aload_2
      //   1425: iload #10
      //   1427: putfield measuredHeight : I
      //   1430: aload_2
      //   1431: iload #17
      //   1433: putfield measuredHasBaseline : Z
      //   1436: aload_2
      //   1437: iload #6
      //   1439: putfield measuredBaseline : I
      //   1442: return
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */