package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class StateSet {
  private static final boolean DEBUG = false;
  
  public static final String TAG = "ConstraintLayoutStates";
  
  private SparseArray<ConstraintSet> mConstraintSetMap = new SparseArray();
  
  private ConstraintsChangedListener mConstraintsChangedListener = null;
  
  int mCurrentConstraintNumber = -1;
  
  int mCurrentStateId = -1;
  
  ConstraintSet mDefaultConstraintSet;
  
  int mDefaultState = -1;
  
  private SparseArray<State> mStateList = new SparseArray();
  
  public StateSet(Context paramContext, XmlPullParser paramXmlPullParser) {
    load(paramContext, paramXmlPullParser);
  }
  
  private void load(Context paramContext, XmlPullParser paramXmlPullParser) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(Xml.asAttributeSet(paramXmlPullParser), R.styleable.StateSet);
    int j = typedArray.getIndexCount();
    int i;
    for (i = 0; i < j; i++) {
      int k = typedArray.getIndex(i);
      if (k == R.styleable.StateSet_defaultState)
        this.mDefaultState = typedArray.getResourceId(k, this.mDefaultState); 
    } 
    typedArray.recycle();
    typedArray = null;
    try {
      i = paramXmlPullParser.getEventType();
      while (true) {
        j = 1;
        if (i != 1) {
          TypedArray typedArray1;
          if (i != 0) {
            if (i != 2) {
              if (i != 3) {
                typedArray1 = typedArray;
              } else {
                typedArray1 = typedArray;
                if ("StateSet".equals(paramXmlPullParser.getName()))
                  return; 
              } 
            } else {
              String str = paramXmlPullParser.getName();
              switch (str.hashCode()) {
                case 1901439077:
                  if (str.equals("Variant")) {
                    i = 3;
                    break;
                  } 
                case 1382829617:
                  if (str.equals("StateSet")) {
                    i = j;
                    break;
                  } 
                case 1301459538:
                  if (str.equals("LayoutDescription")) {
                    i = 0;
                    break;
                  } 
                case 80204913:
                  if (str.equals("State")) {
                    i = 2;
                    break;
                  } 
                default:
                  i = -1;
                  break;
              } 
              if (i != 2) {
                if (i != 3) {
                  typedArray1 = typedArray;
                } else {
                  Variant variant = new Variant(paramContext, paramXmlPullParser);
                  typedArray1 = typedArray;
                  if (typedArray != null) {
                    typedArray.add(variant);
                    typedArray1 = typedArray;
                  } 
                } 
              } else {
                State state = new State(paramContext, paramXmlPullParser);
                this.mStateList.put(state.mId, state);
              } 
            } 
          } else {
            paramXmlPullParser.getName();
            typedArray1 = typedArray;
          } 
          i = paramXmlPullParser.next();
          typedArray = typedArray1;
          continue;
        } 
        return;
      } 
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
  }
  
  public int convertToConstraintSet(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    State state = (State)this.mStateList.get(paramInt2);
    if (state == null)
      return paramInt2; 
    if (paramFloat1 == -1.0F || paramFloat2 == -1.0F) {
      if (state.mConstraintID == paramInt1)
        return paramInt1; 
      Iterator<Variant> iterator = state.mVariants.iterator();
      while (iterator.hasNext()) {
        if (paramInt1 == ((Variant)iterator.next()).mConstraintID)
          return paramInt1; 
      } 
      return state.mConstraintID;
    } 
    Variant variant = null;
    for (Variant variant1 : state.mVariants) {
      if (variant1.match(paramFloat1, paramFloat2)) {
        if (paramInt1 == variant1.mConstraintID)
          return paramInt1; 
        variant = variant1;
      } 
    } 
    return (variant != null) ? variant.mConstraintID : state.mConstraintID;
  }
  
  public boolean needsToChange(int paramInt, float paramFloat1, float paramFloat2) {
    int i = this.mCurrentStateId;
    if (i != paramInt)
      return true; 
    if (paramInt == -1) {
      object = this.mStateList.valueAt(0);
    } else {
      object = this.mStateList.get(i);
    } 
    Object object = object;
    return (this.mCurrentConstraintNumber != -1 && ((Variant)((State)object).mVariants.get(this.mCurrentConstraintNumber)).match(paramFloat1, paramFloat2)) ? false : (!(this.mCurrentConstraintNumber == object.findMatch(paramFloat1, paramFloat2)));
  }
  
  public void setOnConstraintsChanged(ConstraintsChangedListener paramConstraintsChangedListener) {
    this.mConstraintsChangedListener = paramConstraintsChangedListener;
  }
  
  public int stateGetConstraintID(int paramInt1, int paramInt2, int paramInt3) {
    return updateConstraints(-1, paramInt1, paramInt2, paramInt3);
  }
  
  public int updateConstraints(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    if (paramInt1 == paramInt2) {
      State state1;
      if (paramInt2 == -1) {
        state1 = (State)this.mStateList.valueAt(0);
      } else {
        state1 = (State)this.mStateList.get(this.mCurrentStateId);
      } 
      if (state1 == null)
        return -1; 
      if (this.mCurrentConstraintNumber != -1 && ((Variant)state1.mVariants.get(paramInt1)).match(paramFloat1, paramFloat2))
        return paramInt1; 
      paramInt2 = state1.findMatch(paramFloat1, paramFloat2);
      return (paramInt1 == paramInt2) ? paramInt1 : ((paramInt2 == -1) ? state1.mConstraintID : ((Variant)state1.mVariants.get(paramInt2)).mConstraintID);
    } 
    State state = (State)this.mStateList.get(paramInt2);
    if (state == null)
      return -1; 
    paramInt1 = state.findMatch(paramFloat1, paramFloat2);
    return (paramInt1 == -1) ? state.mConstraintID : ((Variant)state.mVariants.get(paramInt1)).mConstraintID;
  }
  
  static class State {
    int mConstraintID = -1;
    
    int mId;
    
    boolean mIsLayout;
    
    ArrayList<StateSet.Variant> mVariants = new ArrayList<StateSet.Variant>();
    
    public State(Context param1Context, XmlPullParser param1XmlPullParser) {
      int i = 0;
      this.mIsLayout = false;
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), R.styleable.State);
      int j = typedArray.getIndexCount();
      while (i < j) {
        int k = typedArray.getIndex(i);
        if (k == R.styleable.State_android_id) {
          this.mId = typedArray.getResourceId(k, this.mId);
        } else if (k == R.styleable.State_constraints) {
          this.mConstraintID = typedArray.getResourceId(k, this.mConstraintID);
          String str = param1Context.getResources().getResourceTypeName(this.mConstraintID);
          param1Context.getResources().getResourceName(this.mConstraintID);
          if ("layout".equals(str))
            this.mIsLayout = true; 
        } 
        i++;
      } 
      typedArray.recycle();
    }
    
    void add(StateSet.Variant param1Variant) {
      this.mVariants.add(param1Variant);
    }
    
    public int findMatch(float param1Float1, float param1Float2) {
      for (int i = 0; i < this.mVariants.size(); i++) {
        if (((StateSet.Variant)this.mVariants.get(i)).match(param1Float1, param1Float2))
          return i; 
      } 
      return -1;
    }
  }
  
  static class Variant {
    int mConstraintID = -1;
    
    int mId;
    
    boolean mIsLayout;
    
    float mMaxHeight = Float.NaN;
    
    float mMaxWidth = Float.NaN;
    
    float mMinHeight = Float.NaN;
    
    float mMinWidth = Float.NaN;
    
    public Variant(Context param1Context, XmlPullParser param1XmlPullParser) {
      int i = 0;
      this.mIsLayout = false;
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), R.styleable.Variant);
      int j = typedArray.getIndexCount();
      while (i < j) {
        int k = typedArray.getIndex(i);
        if (k == R.styleable.Variant_constraints) {
          this.mConstraintID = typedArray.getResourceId(k, this.mConstraintID);
          String str = param1Context.getResources().getResourceTypeName(this.mConstraintID);
          param1Context.getResources().getResourceName(this.mConstraintID);
          if ("layout".equals(str))
            this.mIsLayout = true; 
        } else if (k == R.styleable.Variant_region_heightLessThan) {
          this.mMaxHeight = typedArray.getDimension(k, this.mMaxHeight);
        } else if (k == R.styleable.Variant_region_heightMoreThan) {
          this.mMinHeight = typedArray.getDimension(k, this.mMinHeight);
        } else if (k == R.styleable.Variant_region_widthLessThan) {
          this.mMaxWidth = typedArray.getDimension(k, this.mMaxWidth);
        } else if (k == R.styleable.Variant_region_widthMoreThan) {
          this.mMinWidth = typedArray.getDimension(k, this.mMinWidth);
        } else {
          Log.v("ConstraintLayoutStates", "Unknown tag");
        } 
        i++;
      } 
      typedArray.recycle();
    }
    
    boolean match(float param1Float1, float param1Float2) {
      return (!Float.isNaN(this.mMinWidth) && param1Float1 < this.mMinWidth) ? false : ((!Float.isNaN(this.mMinHeight) && param1Float2 < this.mMinHeight) ? false : ((!Float.isNaN(this.mMaxWidth) && param1Float1 > this.mMaxWidth) ? false : (!(!Float.isNaN(this.mMaxHeight) && param1Float2 > this.mMaxHeight))));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\widget\StateSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */