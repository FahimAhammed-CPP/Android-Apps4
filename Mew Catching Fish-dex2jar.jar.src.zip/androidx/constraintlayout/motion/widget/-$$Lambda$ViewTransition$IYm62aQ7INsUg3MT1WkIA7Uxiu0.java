package androidx.constraintlayout.motion.widget;

import android.view.View;



/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\motion\widget\-$$Lambda$ViewTransition$IYm62aQ7INsUg3MT1WkIA7Uxiu0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */