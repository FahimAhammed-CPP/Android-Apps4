package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.util.Log;
import android.util.Xml;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class KeyFrames {
  private static final String CUSTOM_ATTRIBUTE = "CustomAttribute";
  
  private static final String CUSTOM_METHOD = "CustomMethod";
  
  private static final String TAG = "KeyFrames";
  
  public static final int UNSET = -1;
  
  static HashMap<String, Constructor<? extends Key>> sKeyMakers;
  
  private HashMap<Integer, ArrayList<Key>> mFramesMap;
  
  static {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    sKeyMakers = (HashMap)hashMap;
    try {
      hashMap.put("KeyAttribute", KeyAttributes.class.getConstructor(new Class[0]));
      sKeyMakers.put("KeyPosition", KeyPosition.class.getConstructor(new Class[0]));
      sKeyMakers.put("KeyCycle", KeyCycle.class.getConstructor(new Class[0]));
      sKeyMakers.put("KeyTimeCycle", KeyTimeCycle.class.getConstructor(new Class[0]));
      sKeyMakers.put("KeyTrigger", KeyTrigger.class.getConstructor(new Class[0]));
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.e("KeyFrames", "unable to load", noSuchMethodException);
      return;
    } 
  }
  
  public KeyFrames() {
    this.mFramesMap = new HashMap<Integer, ArrayList<Key>>();
  }
  
  public KeyFrames(Context paramContext, XmlPullParser paramXmlPullParser) {
    int i;
    this.mFramesMap = new HashMap<Integer, ArrayList<Key>>();
    Key key = null;
    try {
      i = paramXmlPullParser.getEventType();
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      Key key1;
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            key1 = key;
          } else {
            key1 = key;
            if ("KeyFrameSet".equals(paramXmlPullParser.getName()))
              return; 
          } 
        } else {
          Exception exception;
          String str = paramXmlPullParser.getName();
          boolean bool = sKeyMakers.containsKey(str);
          if (bool) {
            try {
              Constructor<Key> constructor = (Constructor)sKeyMakers.get(str);
              if (constructor != null) {
                Key key2 = constructor.newInstance(new Object[0]);
                try {
                  key2.load((Context)iOException, Xml.asAttributeSet(paramXmlPullParser));
                  addKey(key2);
                  key = key2;
                } catch (Exception null) {
                  key = key2;
                  Log.e("KeyFrames", "unable to create ", exception);
                } 
              } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Keymaker for ");
                stringBuilder.append((String)exception);
                stringBuilder.append(" not found");
                throw new NullPointerException(stringBuilder.toString());
              } 
            } catch (Exception exception1) {
              exception = exception1;
              Log.e("KeyFrames", "unable to create ", exception);
            } 
          } else {
            Key key2;
            if (exception.equalsIgnoreCase("CustomAttribute")) {
              key2 = key;
              if (key != null) {
                key2 = key;
                if (key.mCustomConstraints != null) {
                  ConstraintAttribute.parse((Context)iOException, paramXmlPullParser, key.mCustomConstraints);
                  key2 = key;
                } 
              } 
            } else {
              key2 = key;
              if (exception.equalsIgnoreCase("CustomMethod")) {
                key2 = key;
                if (key != null) {
                  key2 = key;
                  if (key.mCustomConstraints != null) {
                    ConstraintAttribute.parse((Context)iOException, paramXmlPullParser, key.mCustomConstraints);
                    key2 = key;
                  } 
                } 
              } 
            } 
            i = paramXmlPullParser.next();
            key = key2;
          } 
          key1 = key;
        } 
      } else {
        return;
      } 
      i = paramXmlPullParser.next();
      key = key1;
    } 
  }
  
  static String name(int paramInt, Context paramContext) {
    return paramContext.getResources().getResourceEntryName(paramInt);
  }
  
  public void addAllFrames(MotionController paramMotionController) {
    ArrayList<Key> arrayList = this.mFramesMap.get(Integer.valueOf(-1));
    if (arrayList != null)
      paramMotionController.addKeys(arrayList); 
  }
  
  public void addFrames(MotionController paramMotionController) {
    ArrayList<Key> arrayList = this.mFramesMap.get(Integer.valueOf(paramMotionController.mId));
    if (arrayList != null)
      paramMotionController.addKeys(arrayList); 
    arrayList = this.mFramesMap.get(Integer.valueOf(-1));
    if (arrayList != null)
      for (Key key : arrayList) {
        if (key.matches(((ConstraintLayout.LayoutParams)paramMotionController.mView.getLayoutParams()).constraintTag))
          paramMotionController.addKey(key); 
      }  
  }
  
  public void addKey(Key paramKey) {
    if (!this.mFramesMap.containsKey(Integer.valueOf(paramKey.mTargetId)))
      this.mFramesMap.put(Integer.valueOf(paramKey.mTargetId), new ArrayList<Key>()); 
    ArrayList<Key> arrayList = this.mFramesMap.get(Integer.valueOf(paramKey.mTargetId));
    if (arrayList != null)
      arrayList.add(paramKey); 
  }
  
  public ArrayList<Key> getKeyFramesForView(int paramInt) {
    return this.mFramesMap.get(Integer.valueOf(paramInt));
  }
  
  public Set<Integer> getKeys() {
    return this.mFramesMap.keySet();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\motion\widget\KeyFrames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */