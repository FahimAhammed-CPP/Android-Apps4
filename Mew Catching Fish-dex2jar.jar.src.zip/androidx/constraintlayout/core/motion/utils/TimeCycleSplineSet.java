package androidx.constraintlayout.core.motion.utils;

import androidx.constraintlayout.core.motion.CustomAttribute;
import androidx.constraintlayout.core.motion.CustomVariable;
import androidx.constraintlayout.core.motion.MotionWidget;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.text.DecimalFormat;

public abstract class TimeCycleSplineSet {
  protected static final int CURVE_OFFSET = 2;
  
  protected static final int CURVE_PERIOD = 1;
  
  protected static final int CURVE_VALUE = 0;
  
  private static final String TAG = "SplineSet";
  
  protected static float VAL_2PI = 6.2831855F;
  
  protected int count;
  
  protected float last_cycle = Float.NaN;
  
  protected long last_time;
  
  protected float[] mCache = new float[3];
  
  protected boolean mContinue = false;
  
  protected CurveFit mCurveFit;
  
  protected int[] mTimePoints = new int[10];
  
  protected String mType;
  
  protected float[][] mValues = (float[][])Array.newInstance(float.class, new int[] { 10, 3 });
  
  protected int mWaveShape = 0;
  
  protected float calcWave(float paramFloat) {
    switch (this.mWaveShape) {
      default:
        return (float)Math.sin((paramFloat * VAL_2PI));
      case 6:
        paramFloat = 1.0F - Math.abs(paramFloat * 4.0F % 4.0F - 2.0F);
        paramFloat *= paramFloat;
        return 1.0F - paramFloat;
      case 5:
        return (float)Math.cos((paramFloat * VAL_2PI));
      case 4:
        paramFloat = (paramFloat * 2.0F + 1.0F) % 2.0F;
        return 1.0F - paramFloat;
      case 3:
        return (paramFloat * 2.0F + 1.0F) % 2.0F - 1.0F;
      case 2:
        paramFloat = Math.abs(paramFloat);
        return 1.0F - paramFloat;
      case 1:
        break;
    } 
    return Math.signum(paramFloat * VAL_2PI);
  }
  
  public CurveFit getCurveFit() {
    return this.mCurveFit;
  }
  
  public void setPoint(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, float paramFloat3) {
    int[] arrayOfInt = this.mTimePoints;
    int i = this.count;
    arrayOfInt[i] = paramInt1;
    float[][] arrayOfFloat = this.mValues;
    arrayOfFloat[i][0] = paramFloat1;
    arrayOfFloat[i][1] = paramFloat2;
    arrayOfFloat[i][2] = paramFloat3;
    this.mWaveShape = Math.max(this.mWaveShape, paramInt2);
    this.count++;
  }
  
  protected void setStartTime(long paramLong) {
    this.last_time = paramLong;
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setup(int paramInt) {
    int i = this.count;
    if (i == 0) {
      PrintStream printStream = System.err;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Error no points added to ");
      stringBuilder.append(this.mType);
      printStream.println(stringBuilder.toString());
      return;
    } 
    Sort.doubleQuickSort(this.mTimePoints, this.mValues, 0, i - 1);
    int j = 1;
    i = 0;
    while (true) {
      int[] arrayOfInt = this.mTimePoints;
      if (j < arrayOfInt.length) {
        int k = i;
        if (arrayOfInt[j] != arrayOfInt[j - 1])
          k = i + 1; 
        j++;
        i = k;
        continue;
      } 
      j = i;
      if (i == 0)
        j = 1; 
      double[] arrayOfDouble = new double[j];
      double[][] arrayOfDouble1 = (double[][])Array.newInstance(double.class, new int[] { j, 3 });
      i = 0;
      j = 0;
      while (i < this.count) {
        if (i > 0) {
          int[] arrayOfInt1 = this.mTimePoints;
          if (arrayOfInt1[i] == arrayOfInt1[i - 1])
            continue; 
        } 
        arrayOfDouble[j] = this.mTimePoints[i] * 0.01D;
        double[] arrayOfDouble2 = arrayOfDouble1[j];
        float[][] arrayOfFloat = this.mValues;
        arrayOfDouble2[0] = arrayOfFloat[i][0];
        arrayOfDouble1[j][1] = arrayOfFloat[i][1];
        arrayOfDouble1[j][2] = arrayOfFloat[i][2];
        j++;
        continue;
        i++;
      } 
      this.mCurveFit = CurveFit.get(paramInt, arrayOfDouble, arrayOfDouble1);
      return;
    } 
  }
  
  public String toString() {
    String str = this.mType;
    DecimalFormat decimalFormat = new DecimalFormat("##.##");
    for (int i = 0; i < this.count; i++) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append("[");
      stringBuilder.append(this.mTimePoints[i]);
      stringBuilder.append(" , ");
      stringBuilder.append(decimalFormat.format(this.mValues[i]));
      stringBuilder.append("] ");
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  public static class CustomSet extends TimeCycleSplineSet {
    String mAttributeName;
    
    float[] mCache;
    
    KeyFrameArray.CustomArray mConstraintAttributeList;
    
    float[] mTempValues;
    
    KeyFrameArray.FloatArray mWaveProperties = new KeyFrameArray.FloatArray();
    
    public CustomSet(String param1String, KeyFrameArray.CustomArray param1CustomArray) {
      this.mAttributeName = param1String.split(",")[1];
      this.mConstraintAttributeList = param1CustomArray;
    }
    
    public void setPoint(int param1Int1, float param1Float1, float param1Float2, int param1Int2, float param1Float3) {
      throw new RuntimeException("don't call for custom attribute call setPoint(pos, ConstraintAttribute,...)");
    }
    
    public void setPoint(int param1Int1, CustomAttribute param1CustomAttribute, float param1Float1, int param1Int2, float param1Float2) {
      this.mConstraintAttributeList.append(param1Int1, param1CustomAttribute);
      this.mWaveProperties.append(param1Int1, new float[] { param1Float1, param1Float2 });
      this.mWaveShape = Math.max(this.mWaveShape, param1Int2);
    }
    
    public boolean setProperty(MotionWidget param1MotionWidget, float param1Float, long param1Long, KeyCache param1KeyCache) {
      this.mCurveFit.getPos(param1Float, this.mTempValues);
      float[] arrayOfFloat = this.mTempValues;
      param1Float = arrayOfFloat[arrayOfFloat.length - 2];
      float f1 = arrayOfFloat[arrayOfFloat.length - 1];
      long l = this.last_time;
      if (Float.isNaN(this.last_cycle)) {
        this.last_cycle = param1KeyCache.getFloatValue(param1MotionWidget, this.mAttributeName, 0);
        if (Float.isNaN(this.last_cycle))
          this.last_cycle = 0.0F; 
      } 
      this.last_cycle = (float)((this.last_cycle + (param1Long - l) * 1.0E-9D * param1Float) % 1.0D);
      this.last_time = param1Long;
      float f2 = calcWave(this.last_cycle);
      this.mContinue = false;
      int i;
      for (i = 0; i < this.mCache.length; i++) {
        boolean bool1;
        boolean bool2 = this.mContinue;
        if (this.mTempValues[i] != 0.0D) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        this.mContinue = bool2 | bool1;
        this.mCache[i] = this.mTempValues[i] * f2 + f1;
      } 
      this.mConstraintAttributeList.valueAt(0).setInterpolatedValue(param1MotionWidget, this.mCache);
      if (param1Float != 0.0F)
        this.mContinue = true; 
      return this.mContinue;
    }
    
    public void setup(int param1Int) {
      int j = this.mConstraintAttributeList.size();
      int k = this.mConstraintAttributeList.valueAt(0).numberOfInterpolatedValues();
      double[] arrayOfDouble = new double[j];
      int i = k + 2;
      this.mTempValues = new float[i];
      this.mCache = new float[k];
      double[][] arrayOfDouble1 = (double[][])Array.newInstance(double.class, new int[] { j, i });
      i = 0;
      while (i < j) {
        int m = this.mConstraintAttributeList.keyAt(i);
        CustomAttribute customAttribute = this.mConstraintAttributeList.valueAt(i);
        float[] arrayOfFloat = this.mWaveProperties.valueAt(i);
        arrayOfDouble[i] = m * 0.01D;
        customAttribute.getValuesToInterpolate(this.mTempValues);
        m = 0;
        while (true) {
          float[] arrayOfFloat1 = this.mTempValues;
          if (m < arrayOfFloat1.length) {
            arrayOfDouble1[i][m] = arrayOfFloat1[m];
            m++;
            continue;
          } 
          arrayOfDouble1[i][k] = arrayOfFloat[0];
          arrayOfDouble1[i][k + 1] = arrayOfFloat[1];
          i++;
        } 
      } 
      this.mCurveFit = CurveFit.get(param1Int, arrayOfDouble, arrayOfDouble1);
    }
  }
  
  public static class CustomVarSet extends TimeCycleSplineSet {
    String mAttributeName;
    
    float[] mCache;
    
    KeyFrameArray.CustomVar mConstraintAttributeList;
    
    float[] mTempValues;
    
    KeyFrameArray.FloatArray mWaveProperties = new KeyFrameArray.FloatArray();
    
    public CustomVarSet(String param1String, KeyFrameArray.CustomVar param1CustomVar) {
      this.mAttributeName = param1String.split(",")[1];
      this.mConstraintAttributeList = param1CustomVar;
    }
    
    public void setPoint(int param1Int1, float param1Float1, float param1Float2, int param1Int2, float param1Float3) {
      throw new RuntimeException("don't call for custom attribute call setPoint(pos, ConstraintAttribute,...)");
    }
    
    public void setPoint(int param1Int1, CustomVariable param1CustomVariable, float param1Float1, int param1Int2, float param1Float2) {
      this.mConstraintAttributeList.append(param1Int1, param1CustomVariable);
      this.mWaveProperties.append(param1Int1, new float[] { param1Float1, param1Float2 });
      this.mWaveShape = Math.max(this.mWaveShape, param1Int2);
    }
    
    public boolean setProperty(MotionWidget param1MotionWidget, float param1Float, long param1Long, KeyCache param1KeyCache) {
      this.mCurveFit.getPos(param1Float, this.mTempValues);
      float[] arrayOfFloat = this.mTempValues;
      param1Float = arrayOfFloat[arrayOfFloat.length - 2];
      float f1 = arrayOfFloat[arrayOfFloat.length - 1];
      long l = this.last_time;
      if (Float.isNaN(this.last_cycle)) {
        this.last_cycle = param1KeyCache.getFloatValue(param1MotionWidget, this.mAttributeName, 0);
        if (Float.isNaN(this.last_cycle))
          this.last_cycle = 0.0F; 
      } 
      this.last_cycle = (float)((this.last_cycle + (param1Long - l) * 1.0E-9D * param1Float) % 1.0D);
      this.last_time = param1Long;
      float f2 = calcWave(this.last_cycle);
      this.mContinue = false;
      int i;
      for (i = 0; i < this.mCache.length; i++) {
        boolean bool1;
        boolean bool2 = this.mContinue;
        if (this.mTempValues[i] != 0.0D) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        this.mContinue = bool2 | bool1;
        this.mCache[i] = this.mTempValues[i] * f2 + f1;
      } 
      this.mConstraintAttributeList.valueAt(0).setInterpolatedValue(param1MotionWidget, this.mCache);
      if (param1Float != 0.0F)
        this.mContinue = true; 
      return this.mContinue;
    }
    
    public void setup(int param1Int) {
      int j = this.mConstraintAttributeList.size();
      int k = this.mConstraintAttributeList.valueAt(0).numberOfInterpolatedValues();
      double[] arrayOfDouble = new double[j];
      int i = k + 2;
      this.mTempValues = new float[i];
      this.mCache = new float[k];
      double[][] arrayOfDouble1 = (double[][])Array.newInstance(double.class, new int[] { j, i });
      i = 0;
      while (i < j) {
        int m = this.mConstraintAttributeList.keyAt(i);
        CustomVariable customVariable = this.mConstraintAttributeList.valueAt(i);
        float[] arrayOfFloat = this.mWaveProperties.valueAt(i);
        arrayOfDouble[i] = m * 0.01D;
        customVariable.getValuesToInterpolate(this.mTempValues);
        m = 0;
        while (true) {
          float[] arrayOfFloat1 = this.mTempValues;
          if (m < arrayOfFloat1.length) {
            arrayOfDouble1[i][m] = arrayOfFloat1[m];
            m++;
            continue;
          } 
          arrayOfDouble1[i][k] = arrayOfFloat[0];
          arrayOfDouble1[i][k + 1] = arrayOfFloat[1];
          i++;
        } 
      } 
      this.mCurveFit = CurveFit.get(param1Int, arrayOfDouble, arrayOfDouble1);
    }
  }
  
  protected static class Sort {
    static void doubleQuickSort(int[] param1ArrayOfint, float[][] param1ArrayOffloat, int param1Int1, int param1Int2) {
      int[] arrayOfInt = new int[param1ArrayOfint.length + 10];
      arrayOfInt[0] = param1Int2;
      arrayOfInt[1] = param1Int1;
      param1Int1 = 2;
      while (param1Int1 > 0) {
        int i = arrayOfInt[--param1Int1];
        param1Int2 = param1Int1 - 1;
        int j = arrayOfInt[param1Int2];
        param1Int1 = param1Int2;
        if (i < j) {
          int k = partition(param1ArrayOfint, param1ArrayOffloat, i, j);
          param1Int1 = param1Int2 + 1;
          arrayOfInt[param1Int2] = k - 1;
          param1Int2 = param1Int1 + 1;
          arrayOfInt[param1Int1] = i;
          i = param1Int2 + 1;
          arrayOfInt[param1Int2] = j;
          param1Int1 = i + 1;
          arrayOfInt[i] = k + 1;
        } 
      } 
    }
    
    private static int partition(int[] param1ArrayOfint, float[][] param1ArrayOffloat, int param1Int1, int param1Int2) {
      int j = param1ArrayOfint[param1Int2];
      int i;
      for (i = param1Int1; param1Int1 < param1Int2; i = k) {
        int k = i;
        if (param1ArrayOfint[param1Int1] <= j) {
          swap(param1ArrayOfint, param1ArrayOffloat, i, param1Int1);
          k = i + 1;
        } 
        param1Int1++;
      } 
      swap(param1ArrayOfint, param1ArrayOffloat, i, param1Int2);
      return i;
    }
    
    private static void swap(int[] param1ArrayOfint, float[][] param1ArrayOffloat, int param1Int1, int param1Int2) {
      int i = param1ArrayOfint[param1Int1];
      param1ArrayOfint[param1Int1] = param1ArrayOfint[param1Int2];
      param1ArrayOfint[param1Int2] = i;
      float[] arrayOfFloat = param1ArrayOffloat[param1Int1];
      param1ArrayOffloat[param1Int1] = param1ArrayOffloat[param1Int2];
      param1ArrayOffloat[param1Int2] = arrayOfFloat;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\TimeCycleSplineSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */