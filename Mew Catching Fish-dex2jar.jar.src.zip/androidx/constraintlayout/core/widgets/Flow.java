package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import java.util.ArrayList;
import java.util.HashMap;

public class Flow extends VirtualLayout {
  public static final int HORIZONTAL_ALIGN_CENTER = 2;
  
  public static final int HORIZONTAL_ALIGN_END = 1;
  
  public static final int HORIZONTAL_ALIGN_START = 0;
  
  public static final int VERTICAL_ALIGN_BASELINE = 3;
  
  public static final int VERTICAL_ALIGN_BOTTOM = 1;
  
  public static final int VERTICAL_ALIGN_CENTER = 2;
  
  public static final int VERTICAL_ALIGN_TOP = 0;
  
  public static final int WRAP_ALIGNED = 2;
  
  public static final int WRAP_CHAIN = 1;
  
  public static final int WRAP_NONE = 0;
  
  private ConstraintWidget[] mAlignedBiggestElementsInCols = null;
  
  private ConstraintWidget[] mAlignedBiggestElementsInRows = null;
  
  private int[] mAlignedDimensions = null;
  
  private ArrayList<WidgetsList> mChainList = new ArrayList<WidgetsList>();
  
  private ConstraintWidget[] mDisplayedWidgets;
  
  private int mDisplayedWidgetsCount = 0;
  
  private float mFirstHorizontalBias = 0.5F;
  
  private int mFirstHorizontalStyle = -1;
  
  private float mFirstVerticalBias = 0.5F;
  
  private int mFirstVerticalStyle = -1;
  
  private int mHorizontalAlign = 2;
  
  private float mHorizontalBias = 0.5F;
  
  private int mHorizontalGap = 0;
  
  private int mHorizontalStyle = -1;
  
  private float mLastHorizontalBias = 0.5F;
  
  private int mLastHorizontalStyle = -1;
  
  private float mLastVerticalBias = 0.5F;
  
  private int mLastVerticalStyle = -1;
  
  private int mMaxElementsWrap = -1;
  
  private int mOrientation = 0;
  
  private int mVerticalAlign = 2;
  
  private float mVerticalBias = 0.5F;
  
  private int mVerticalGap = 0;
  
  private int mVerticalStyle = -1;
  
  private int mWrapMode = 0;
  
  private void createAlignedConstraints(boolean paramBoolean) {
    if (this.mAlignedDimensions != null && this.mAlignedBiggestElementsInCols != null) {
      ConstraintWidget constraintWidget;
      if (this.mAlignedBiggestElementsInRows == null)
        return; 
      int i;
      for (i = 0; i < this.mDisplayedWidgetsCount; i++)
        this.mDisplayedWidgets[i].resetAnchors(); 
      int[] arrayOfInt = this.mAlignedDimensions;
      int j = arrayOfInt[0];
      int k = arrayOfInt[1];
      arrayOfInt = null;
      float f = this.mHorizontalBias;
      i = 0;
      while (i < j) {
        int m;
        ConstraintWidget constraintWidget1;
        if (paramBoolean) {
          m = j - i - 1;
          f = 1.0F - this.mHorizontalBias;
        } else {
          m = i;
        } 
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[m];
        int[] arrayOfInt1 = arrayOfInt;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            arrayOfInt1 = arrayOfInt;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mLeft, this.mLeft, getPaddingLeft());
              constraintWidget2.setHorizontalChainStyle(this.mHorizontalStyle);
              constraintWidget2.setHorizontalBiasPercent(f);
            } 
            if (i == j - 1)
              constraintWidget2.connect(constraintWidget2.mRight, this.mRight, getPaddingRight()); 
            if (i > 0 && arrayOfInt != null) {
              constraintWidget2.connect(constraintWidget2.mLeft, ((ConstraintWidget)arrayOfInt).mRight, this.mHorizontalGap);
              arrayOfInt.connect(((ConstraintWidget)arrayOfInt).mRight, constraintWidget2.mLeft, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      i = 0;
      while (i < k) {
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInRows[i];
        ConstraintWidget constraintWidget1 = constraintWidget;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            constraintWidget1 = constraintWidget;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mTop, this.mTop, getPaddingTop());
              constraintWidget2.setVerticalChainStyle(this.mVerticalStyle);
              constraintWidget2.setVerticalBiasPercent(this.mVerticalBias);
            } 
            if (i == k - 1)
              constraintWidget2.connect(constraintWidget2.mBottom, this.mBottom, getPaddingBottom()); 
            if (i > 0 && constraintWidget != null) {
              constraintWidget2.connect(constraintWidget2.mTop, constraintWidget.mBottom, this.mVerticalGap);
              constraintWidget.connect(constraintWidget.mBottom, constraintWidget2.mTop, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      for (i = 0; i < j; i++) {
        int m;
        for (m = 0; m < k; m++) {
          int n = m * j + i;
          if (this.mOrientation == 1)
            n = i * k + m; 
          ConstraintWidget[] arrayOfConstraintWidget = this.mDisplayedWidgets;
          if (n < arrayOfConstraintWidget.length) {
            ConstraintWidget constraintWidget1 = arrayOfConstraintWidget[n];
            if (constraintWidget1 != null && constraintWidget1.getVisibility() != 8) {
              ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[i];
              ConstraintWidget constraintWidget3 = this.mAlignedBiggestElementsInRows[m];
              if (constraintWidget1 != constraintWidget2) {
                constraintWidget1.connect(constraintWidget1.mLeft, constraintWidget2.mLeft, 0);
                constraintWidget1.connect(constraintWidget1.mRight, constraintWidget2.mRight, 0);
              } 
              if (constraintWidget1 != constraintWidget3) {
                constraintWidget1.connect(constraintWidget1.mTop, constraintWidget3.mTop, 0);
                constraintWidget1.connect(constraintWidget1.mBottom, constraintWidget3.mBottom, 0);
              } 
            } 
          } 
        } 
      } 
    } 
  }
  
  private final int getWidgetHeight(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
        return 0; 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentHeight * paramInt);
        if (paramInt != paramConstraintWidget.getHeight()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, paramConstraintWidget.getHorizontalDimensionBehaviour(), paramConstraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, paramInt);
        } 
        return paramInt;
      } 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 1)
        return paramConstraintWidget.getHeight(); 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 3)
        return (int)(paramConstraintWidget.getWidth() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getHeight();
  }
  
  private final int getWidgetWidth(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
        return 0; 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentWidth * paramInt);
        if (paramInt != paramConstraintWidget.getWidth()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, paramInt, paramConstraintWidget.getVerticalDimensionBehaviour(), paramConstraintWidget.getHeight());
        } 
        return paramInt;
      } 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 1)
        return paramConstraintWidget.getWidth(); 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 3)
        return (int)(paramConstraintWidget.getHeight() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getWidth();
  }
  
  private void measureAligned(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    // Byte code:
    //   0: iload_3
    //   1: ifne -> 126
    //   4: aload_0
    //   5: getfield mMaxElementsWrap : I
    //   8: istore #6
    //   10: iload #6
    //   12: istore #8
    //   14: iload #6
    //   16: ifgt -> 116
    //   19: iconst_0
    //   20: istore #6
    //   22: iconst_0
    //   23: istore #9
    //   25: iconst_0
    //   26: istore #7
    //   28: iload #6
    //   30: istore #8
    //   32: iload #9
    //   34: iload_2
    //   35: if_icmpge -> 116
    //   38: iload #7
    //   40: istore #8
    //   42: iload #9
    //   44: ifle -> 56
    //   47: iload #7
    //   49: aload_0
    //   50: getfield mHorizontalGap : I
    //   53: iadd
    //   54: istore #8
    //   56: aload_1
    //   57: iload #9
    //   59: aaload
    //   60: astore #13
    //   62: aload #13
    //   64: ifnonnull -> 74
    //   67: iload #8
    //   69: istore #7
    //   71: goto -> 107
    //   74: iload #8
    //   76: aload_0
    //   77: aload #13
    //   79: iload #4
    //   81: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   84: iadd
    //   85: istore #7
    //   87: iload #7
    //   89: iload #4
    //   91: if_icmple -> 101
    //   94: iload #6
    //   96: istore #8
    //   98: goto -> 116
    //   101: iload #6
    //   103: iconst_1
    //   104: iadd
    //   105: istore #6
    //   107: iload #9
    //   109: iconst_1
    //   110: iadd
    //   111: istore #9
    //   113: goto -> 28
    //   116: iload #8
    //   118: istore #7
    //   120: iconst_0
    //   121: istore #6
    //   123: goto -> 245
    //   126: aload_0
    //   127: getfield mMaxElementsWrap : I
    //   130: istore #6
    //   132: iload #6
    //   134: istore #8
    //   136: iload #6
    //   138: ifgt -> 238
    //   141: iconst_0
    //   142: istore #6
    //   144: iconst_0
    //   145: istore #9
    //   147: iconst_0
    //   148: istore #7
    //   150: iload #6
    //   152: istore #8
    //   154: iload #9
    //   156: iload_2
    //   157: if_icmpge -> 238
    //   160: iload #7
    //   162: istore #8
    //   164: iload #9
    //   166: ifle -> 178
    //   169: iload #7
    //   171: aload_0
    //   172: getfield mVerticalGap : I
    //   175: iadd
    //   176: istore #8
    //   178: aload_1
    //   179: iload #9
    //   181: aaload
    //   182: astore #13
    //   184: aload #13
    //   186: ifnonnull -> 196
    //   189: iload #8
    //   191: istore #7
    //   193: goto -> 229
    //   196: iload #8
    //   198: aload_0
    //   199: aload #13
    //   201: iload #4
    //   203: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   206: iadd
    //   207: istore #7
    //   209: iload #7
    //   211: iload #4
    //   213: if_icmple -> 223
    //   216: iload #6
    //   218: istore #8
    //   220: goto -> 238
    //   223: iload #6
    //   225: iconst_1
    //   226: iadd
    //   227: istore #6
    //   229: iload #9
    //   231: iconst_1
    //   232: iadd
    //   233: istore #9
    //   235: goto -> 150
    //   238: iconst_0
    //   239: istore #7
    //   241: iload #8
    //   243: istore #6
    //   245: aload_0
    //   246: getfield mAlignedDimensions : [I
    //   249: ifnonnull -> 259
    //   252: aload_0
    //   253: iconst_2
    //   254: newarray int
    //   256: putfield mAlignedDimensions : [I
    //   259: iload #6
    //   261: ifne -> 277
    //   264: iload #6
    //   266: istore #11
    //   268: iload #7
    //   270: istore #9
    //   272: iload_3
    //   273: iconst_1
    //   274: if_icmpeq -> 294
    //   277: iload #7
    //   279: ifne -> 308
    //   282: iload_3
    //   283: ifne -> 308
    //   286: iload #7
    //   288: istore #9
    //   290: iload #6
    //   292: istore #11
    //   294: iconst_1
    //   295: istore #12
    //   297: iload #11
    //   299: istore #6
    //   301: iload #9
    //   303: istore #7
    //   305: goto -> 311
    //   308: iconst_0
    //   309: istore #12
    //   311: iload #12
    //   313: ifne -> 850
    //   316: iload_3
    //   317: ifne -> 336
    //   320: iload_2
    //   321: i2f
    //   322: iload #7
    //   324: i2f
    //   325: fdiv
    //   326: f2d
    //   327: invokestatic ceil : (D)D
    //   330: d2i
    //   331: istore #6
    //   333: goto -> 349
    //   336: iload_2
    //   337: i2f
    //   338: iload #6
    //   340: i2f
    //   341: fdiv
    //   342: f2d
    //   343: invokestatic ceil : (D)D
    //   346: d2i
    //   347: istore #7
    //   349: aload_0
    //   350: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   353: astore #13
    //   355: aload #13
    //   357: ifnull -> 380
    //   360: aload #13
    //   362: arraylength
    //   363: iload #7
    //   365: if_icmpge -> 371
    //   368: goto -> 380
    //   371: aload #13
    //   373: aconst_null
    //   374: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   377: goto -> 389
    //   380: aload_0
    //   381: iload #7
    //   383: anewarray androidx/constraintlayout/core/widgets/ConstraintWidget
    //   386: putfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   389: aload_0
    //   390: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   393: astore #13
    //   395: aload #13
    //   397: ifnull -> 420
    //   400: aload #13
    //   402: arraylength
    //   403: iload #6
    //   405: if_icmpge -> 411
    //   408: goto -> 420
    //   411: aload #13
    //   413: aconst_null
    //   414: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   417: goto -> 429
    //   420: aload_0
    //   421: iload #6
    //   423: anewarray androidx/constraintlayout/core/widgets/ConstraintWidget
    //   426: putfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   429: iconst_0
    //   430: istore #8
    //   432: iload #8
    //   434: iload #7
    //   436: if_icmpge -> 608
    //   439: iconst_0
    //   440: istore #9
    //   442: iload #9
    //   444: iload #6
    //   446: if_icmpge -> 599
    //   449: iload #9
    //   451: iload #7
    //   453: imul
    //   454: iload #8
    //   456: iadd
    //   457: istore #10
    //   459: iload_3
    //   460: iconst_1
    //   461: if_icmpne -> 474
    //   464: iload #8
    //   466: iload #6
    //   468: imul
    //   469: iload #9
    //   471: iadd
    //   472: istore #10
    //   474: iload #10
    //   476: aload_1
    //   477: arraylength
    //   478: if_icmplt -> 484
    //   481: goto -> 590
    //   484: aload_1
    //   485: iload #10
    //   487: aaload
    //   488: astore #13
    //   490: aload #13
    //   492: ifnonnull -> 498
    //   495: goto -> 590
    //   498: aload_0
    //   499: aload #13
    //   501: iload #4
    //   503: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   506: istore #10
    //   508: aload_0
    //   509: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   512: astore #14
    //   514: aload #14
    //   516: iload #8
    //   518: aaload
    //   519: ifnull -> 535
    //   522: aload #14
    //   524: iload #8
    //   526: aaload
    //   527: invokevirtual getWidth : ()I
    //   530: iload #10
    //   532: if_icmpge -> 544
    //   535: aload_0
    //   536: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   539: iload #8
    //   541: aload #13
    //   543: aastore
    //   544: aload_0
    //   545: aload #13
    //   547: iload #4
    //   549: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   552: istore #10
    //   554: aload_0
    //   555: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   558: astore #14
    //   560: aload #14
    //   562: iload #9
    //   564: aaload
    //   565: ifnull -> 581
    //   568: aload #14
    //   570: iload #9
    //   572: aaload
    //   573: invokevirtual getHeight : ()I
    //   576: iload #10
    //   578: if_icmpge -> 590
    //   581: aload_0
    //   582: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   585: iload #9
    //   587: aload #13
    //   589: aastore
    //   590: iload #9
    //   592: iconst_1
    //   593: iadd
    //   594: istore #9
    //   596: goto -> 442
    //   599: iload #8
    //   601: iconst_1
    //   602: iadd
    //   603: istore #8
    //   605: goto -> 432
    //   608: iconst_0
    //   609: istore #9
    //   611: iconst_0
    //   612: istore #8
    //   614: iload #9
    //   616: iload #7
    //   618: if_icmpge -> 683
    //   621: aload_0
    //   622: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   625: iload #9
    //   627: aaload
    //   628: astore #13
    //   630: iload #8
    //   632: istore #10
    //   634: aload #13
    //   636: ifnull -> 670
    //   639: iload #8
    //   641: istore #10
    //   643: iload #9
    //   645: ifle -> 657
    //   648: iload #8
    //   650: aload_0
    //   651: getfield mHorizontalGap : I
    //   654: iadd
    //   655: istore #10
    //   657: iload #10
    //   659: aload_0
    //   660: aload #13
    //   662: iload #4
    //   664: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   667: iadd
    //   668: istore #10
    //   670: iload #9
    //   672: iconst_1
    //   673: iadd
    //   674: istore #9
    //   676: iload #10
    //   678: istore #8
    //   680: goto -> 614
    //   683: iconst_0
    //   684: istore #9
    //   686: iconst_0
    //   687: istore #10
    //   689: iload #9
    //   691: iload #6
    //   693: if_icmpge -> 758
    //   696: aload_0
    //   697: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   700: iload #9
    //   702: aaload
    //   703: astore #13
    //   705: iload #10
    //   707: istore #11
    //   709: aload #13
    //   711: ifnull -> 745
    //   714: iload #10
    //   716: istore #11
    //   718: iload #9
    //   720: ifle -> 732
    //   723: iload #10
    //   725: aload_0
    //   726: getfield mVerticalGap : I
    //   729: iadd
    //   730: istore #11
    //   732: iload #11
    //   734: aload_0
    //   735: aload #13
    //   737: iload #4
    //   739: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   742: iadd
    //   743: istore #11
    //   745: iload #9
    //   747: iconst_1
    //   748: iadd
    //   749: istore #9
    //   751: iload #11
    //   753: istore #10
    //   755: goto -> 689
    //   758: aload #5
    //   760: iconst_0
    //   761: iload #8
    //   763: iastore
    //   764: aload #5
    //   766: iconst_1
    //   767: iload #10
    //   769: iastore
    //   770: iload_3
    //   771: ifne -> 812
    //   774: iload #6
    //   776: istore #11
    //   778: iload #7
    //   780: istore #9
    //   782: iload #8
    //   784: iload #4
    //   786: if_icmple -> 294
    //   789: iload #6
    //   791: istore #11
    //   793: iload #7
    //   795: istore #9
    //   797: iload #7
    //   799: iconst_1
    //   800: if_icmple -> 294
    //   803: iload #7
    //   805: iconst_1
    //   806: isub
    //   807: istore #7
    //   809: goto -> 311
    //   812: iload #6
    //   814: istore #11
    //   816: iload #7
    //   818: istore #9
    //   820: iload #10
    //   822: iload #4
    //   824: if_icmple -> 294
    //   827: iload #6
    //   829: istore #11
    //   831: iload #7
    //   833: istore #9
    //   835: iload #6
    //   837: iconst_1
    //   838: if_icmple -> 294
    //   841: iload #6
    //   843: iconst_1
    //   844: isub
    //   845: istore #6
    //   847: goto -> 311
    //   850: aload_0
    //   851: getfield mAlignedDimensions : [I
    //   854: astore_1
    //   855: aload_1
    //   856: iconst_0
    //   857: iload #7
    //   859: iastore
    //   860: aload_1
    //   861: iconst_1
    //   862: iload #6
    //   864: iastore
    //   865: return
  }
  
  private void measureChainWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    ConstraintWidget constraintWidget;
    if (paramInt1 == 0)
      return; 
    this.mChainList.clear();
    WidgetsList widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
    this.mChainList.add(widgetsList);
    if (paramInt2 == 0) {
      Object object;
      boolean bool = false;
      int i3 = 0;
      int i4 = 0;
      while (true) {
        Object object1 = object;
        if (i4 < paramInt1) {
          boolean bool1;
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i4];
          int i5 = getWidgetWidth(constraintWidget, paramInt3);
          object1 = object;
          if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = object + 1; 
          if ((i3 == paramInt3 || this.mHorizontalGap + i3 + i5 > paramInt3) && widgetsList.biggest != null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          boolean bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (i4 > 0) {
              int i6 = this.mMaxElementsWrap;
              bool2 = bool1;
              if (i6 > 0) {
                bool2 = bool1;
                if (i4 % i6 == 0)
                  bool2 = true; 
              } 
            } 
          } 
          if (bool2) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i4);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i4 > 0) {
              i3 += this.mHorizontalGap + i5;
              continue;
            } 
          } 
          i3 = i5;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_16);
        i4++;
        object = SYNTHETIC_LOCAL_VARIABLE_7;
      } 
    } else {
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      while (true) {
        i = i3;
        if (i5 < paramInt1) {
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i5];
          int i7 = getWidgetHeight(constraintWidget, paramInt3);
          i = i3;
          if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = i3 + 1; 
          if ((i4 == paramInt3 || this.mVerticalGap + i4 + i7 > paramInt3) && widgetsList.biggest != null) {
            i3 = 1;
          } else {
            i3 = 0;
          } 
          int i6 = i3;
          if (i3 == 0) {
            i6 = i3;
            if (i5 > 0) {
              int i8 = this.mMaxElementsWrap;
              i6 = i3;
              if (i8 > 0) {
                i6 = i3;
                if (i5 % i8 == 0)
                  i6 = 1; 
              } 
            } 
          } 
          if (i6 != 0) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i5);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i5 > 0) {
              i4 += this.mVerticalGap + i7;
              continue;
            } 
          } 
          i4 = i7;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add(constraintWidget);
        i5++;
        i3 = i;
      } 
    } 
    int i2 = this.mChainList.size();
    ConstraintAnchor constraintAnchor1 = this.mLeft;
    ConstraintAnchor constraintAnchor4 = this.mTop;
    ConstraintAnchor constraintAnchor2 = this.mRight;
    ConstraintAnchor constraintAnchor3 = this.mBottom;
    int j = getPaddingLeft();
    int k = getPaddingTop();
    int n = getPaddingRight();
    int m = getPaddingBottom();
    if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (i > 0 && paramInt1 != 0)
      for (paramInt1 = 0; paramInt1 < i2; paramInt1++) {
        WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
        if (paramInt2 == 0) {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getWidth());
        } else {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getHeight());
        } 
      }  
    int i = 0;
    int i1 = 0;
    paramInt1 = 0;
    while (paramInt1 < i2) {
      int i3;
      WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
      if (paramInt2 == 0) {
        if (paramInt1 < i2 - 1) {
          constraintAnchor3 = ((WidgetsList)this.mChainList.get(paramInt1 + 1)).biggest.mTop;
          i3 = 0;
        } else {
          constraintAnchor3 = this.mBottom;
          i3 = getPaddingBottom();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mBottom;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, n, i3, paramInt3);
        k = Math.max(i1, widgetsList1.getWidth());
        m = i + widgetsList1.getHeight();
        i = m;
        if (paramInt1 > 0)
          i = m + this.mVerticalGap; 
        constraintAnchor4 = constraintAnchor;
        i1 = 0;
        m = i3;
        i3 = k;
        k = i1;
      } else {
        n = paramInt1;
        if (n < i2 - 1) {
          constraintAnchor2 = ((WidgetsList)this.mChainList.get(n + 1)).biggest.mLeft;
          i3 = 0;
        } else {
          constraintAnchor2 = this.mRight;
          i3 = getPaddingRight();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mRight;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, i3, m, paramInt3);
        j = i1 + widgetsList1.getWidth();
        i1 = Math.max(i, widgetsList1.getHeight());
        i = j;
        if (n > 0)
          i = j + this.mHorizontalGap; 
        j = i1;
        n = i3;
        constraintAnchor1 = constraintAnchor;
        i1 = 0;
        i3 = i;
        i = j;
        j = i1;
      } 
      paramInt1++;
      i1 = i3;
    } 
    paramArrayOfint[0] = i1;
    paramArrayOfint[1] = i;
  }
  
  private void measureNoWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    WidgetsList widgetsList;
    if (paramInt1 == 0)
      return; 
    if (this.mChainList.size() == 0) {
      widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
      this.mChainList.add(widgetsList);
    } else {
      widgetsList = this.mChainList.get(0);
      widgetsList.clear();
      ConstraintAnchor constraintAnchor1 = this.mLeft;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      ConstraintAnchor constraintAnchor3 = this.mRight;
      ConstraintAnchor constraintAnchor4 = this.mBottom;
      int i = getPaddingLeft();
      int j = getPaddingTop();
      int k = getPaddingRight();
      int m = getPaddingBottom();
      widgetsList.setup(paramInt2, constraintAnchor1, constraintAnchor2, constraintAnchor3, constraintAnchor4, i, j, k, m, paramInt3);
    } 
    for (paramInt2 = 0; paramInt2 < paramInt1; paramInt2++)
      widgetsList.add(paramArrayOfConstraintWidget[paramInt2]); 
    paramArrayOfint[0] = widgetsList.getWidth();
    paramArrayOfint[1] = widgetsList.getHeight();
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    super.addToSolver(paramLinearSystem, paramBoolean);
    if (getParent() != null && ((ConstraintWidgetContainer)getParent()).isRtl()) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    int i = this.mWrapMode;
    if (i != 0) {
      if (i != 1) {
        if (i == 2)
          createAlignedConstraints(paramBoolean); 
      } else {
        int j = this.mChainList.size();
        for (i = 0; i < j; i++) {
          boolean bool;
          WidgetsList widgetsList = this.mChainList.get(i);
          if (i == j - 1) {
            bool = true;
          } else {
            bool = false;
          } 
          widgetsList.createConstraints(paramBoolean, i, bool);
        } 
      } 
    } else if (this.mChainList.size() > 0) {
      ((WidgetsList)this.mChainList.get(0)).createConstraints(paramBoolean, 0, true);
    } 
    needsCallbackFromSolver(false);
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    this.mHorizontalStyle = ((Flow)paramConstraintWidget).mHorizontalStyle;
    this.mVerticalStyle = ((Flow)paramConstraintWidget).mVerticalStyle;
    this.mFirstHorizontalStyle = ((Flow)paramConstraintWidget).mFirstHorizontalStyle;
    this.mFirstVerticalStyle = ((Flow)paramConstraintWidget).mFirstVerticalStyle;
    this.mLastHorizontalStyle = ((Flow)paramConstraintWidget).mLastHorizontalStyle;
    this.mLastVerticalStyle = ((Flow)paramConstraintWidget).mLastVerticalStyle;
    this.mHorizontalBias = ((Flow)paramConstraintWidget).mHorizontalBias;
    this.mVerticalBias = ((Flow)paramConstraintWidget).mVerticalBias;
    this.mFirstHorizontalBias = ((Flow)paramConstraintWidget).mFirstHorizontalBias;
    this.mFirstVerticalBias = ((Flow)paramConstraintWidget).mFirstVerticalBias;
    this.mLastHorizontalBias = ((Flow)paramConstraintWidget).mLastHorizontalBias;
    this.mLastVerticalBias = ((Flow)paramConstraintWidget).mLastVerticalBias;
    this.mHorizontalGap = ((Flow)paramConstraintWidget).mHorizontalGap;
    this.mVerticalGap = ((Flow)paramConstraintWidget).mVerticalGap;
    this.mHorizontalAlign = ((Flow)paramConstraintWidget).mHorizontalAlign;
    this.mVerticalAlign = ((Flow)paramConstraintWidget).mVerticalAlign;
    this.mWrapMode = ((Flow)paramConstraintWidget).mWrapMode;
    this.mMaxElementsWrap = ((Flow)paramConstraintWidget).mMaxElementsWrap;
    this.mOrientation = ((Flow)paramConstraintWidget).mOrientation;
  }
  
  public void measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mWidgetsCount > 0 && !measureChildren()) {
      setMeasure(0, 0);
      needsCallbackFromSolver(false);
      return;
    } 
    int i1 = getPaddingLeft();
    int i2 = getPaddingRight();
    int m = getPaddingTop();
    int n = getPaddingBottom();
    int[] arrayOfInt = new int[2];
    int j = paramInt2 - i1 - i2;
    if (this.mOrientation == 1)
      j = paramInt4 - m - n; 
    if (this.mOrientation == 0) {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } else {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } 
    ConstraintWidget[] arrayOfConstraintWidget = this.mWidgets;
    int k = 0;
    int i;
    for (i = 0; k < this.mWidgetsCount; i = i3) {
      int i3 = i;
      if (this.mWidgets[k].getVisibility() == 8)
        i3 = i + 1; 
      k++;
    } 
    k = this.mWidgetsCount;
    if (i > 0) {
      arrayOfConstraintWidget = new ConstraintWidget[this.mWidgetsCount - i];
      k = 0;
      for (i = 0; k < this.mWidgetsCount; i = i3) {
        ConstraintWidget constraintWidget = this.mWidgets[k];
        int i3 = i;
        if (constraintWidget.getVisibility() != 8) {
          arrayOfConstraintWidget[i] = constraintWidget;
          i3 = i + 1;
        } 
        k++;
      } 
      k = i;
    } 
    this.mDisplayedWidgets = arrayOfConstraintWidget;
    this.mDisplayedWidgetsCount = k;
    i = this.mWrapMode;
    if (i != 0) {
      if (i != 1) {
        if (i == 2)
          measureAligned(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt); 
      } else {
        measureChainWrap(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
      } 
    } else {
      measureNoWrap(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
    } 
    boolean bool = true;
    j = arrayOfInt[0] + i1 + i2;
    i = arrayOfInt[1] + m + n;
    if (paramInt1 == 1073741824) {
      paramInt1 = paramInt2;
    } else if (paramInt1 == Integer.MIN_VALUE) {
      paramInt1 = Math.min(j, paramInt2);
    } else if (paramInt1 == 0) {
      paramInt1 = j;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt3 == 1073741824) {
      paramInt2 = paramInt4;
    } else if (paramInt3 == Integer.MIN_VALUE) {
      paramInt2 = Math.min(i, paramInt4);
    } else if (paramInt3 == 0) {
      paramInt2 = i;
    } else {
      paramInt2 = 0;
    } 
    setMeasure(paramInt1, paramInt2);
    setWidth(paramInt1);
    setHeight(paramInt2);
    if (this.mWidgetsCount <= 0)
      bool = false; 
    needsCallbackFromSolver(bool);
  }
  
  public void setFirstHorizontalBias(float paramFloat) {
    this.mFirstHorizontalBias = paramFloat;
  }
  
  public void setFirstHorizontalStyle(int paramInt) {
    this.mFirstHorizontalStyle = paramInt;
  }
  
  public void setFirstVerticalBias(float paramFloat) {
    this.mFirstVerticalBias = paramFloat;
  }
  
  public void setFirstVerticalStyle(int paramInt) {
    this.mFirstVerticalStyle = paramInt;
  }
  
  public void setHorizontalAlign(int paramInt) {
    this.mHorizontalAlign = paramInt;
  }
  
  public void setHorizontalBias(float paramFloat) {
    this.mHorizontalBias = paramFloat;
  }
  
  public void setHorizontalGap(int paramInt) {
    this.mHorizontalGap = paramInt;
  }
  
  public void setHorizontalStyle(int paramInt) {
    this.mHorizontalStyle = paramInt;
  }
  
  public void setLastHorizontalBias(float paramFloat) {
    this.mLastHorizontalBias = paramFloat;
  }
  
  public void setLastHorizontalStyle(int paramInt) {
    this.mLastHorizontalStyle = paramInt;
  }
  
  public void setLastVerticalBias(float paramFloat) {
    this.mLastVerticalBias = paramFloat;
  }
  
  public void setLastVerticalStyle(int paramInt) {
    this.mLastVerticalStyle = paramInt;
  }
  
  public void setMaxElementsWrap(int paramInt) {
    this.mMaxElementsWrap = paramInt;
  }
  
  public void setOrientation(int paramInt) {
    this.mOrientation = paramInt;
  }
  
  public void setVerticalAlign(int paramInt) {
    this.mVerticalAlign = paramInt;
  }
  
  public void setVerticalBias(float paramFloat) {
    this.mVerticalBias = paramFloat;
  }
  
  public void setVerticalGap(int paramInt) {
    this.mVerticalGap = paramInt;
  }
  
  public void setVerticalStyle(int paramInt) {
    this.mVerticalStyle = paramInt;
  }
  
  public void setWrapMode(int paramInt) {
    this.mWrapMode = paramInt;
  }
  
  private class WidgetsList {
    private ConstraintWidget biggest = null;
    
    int biggestDimension = 0;
    
    private ConstraintAnchor mBottom;
    
    private int mCount = 0;
    
    private int mHeight = 0;
    
    private ConstraintAnchor mLeft;
    
    private int mMax = 0;
    
    private int mNbMatchConstraintsWidgets = 0;
    
    private int mOrientation = 0;
    
    private int mPaddingBottom = 0;
    
    private int mPaddingLeft = 0;
    
    private int mPaddingRight = 0;
    
    private int mPaddingTop = 0;
    
    private ConstraintAnchor mRight;
    
    private int mStartIndex = 0;
    
    private ConstraintAnchor mTop;
    
    private int mWidth = 0;
    
    public WidgetsList(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = Flow.this.getPaddingLeft();
      this.mPaddingTop = Flow.this.getPaddingTop();
      this.mPaddingRight = Flow.this.getPaddingRight();
      this.mPaddingBottom = Flow.this.getPaddingBottom();
      this.mMax = param1Int2;
    }
    
    private void recomputeDimensions() {
      this.mWidth = 0;
      this.mHeight = 0;
      this.biggest = null;
      this.biggestDimension = 0;
      int j = this.mCount;
      for (int i = 0; i < j; i++) {
        if (this.mStartIndex + i >= Flow.this.mDisplayedWidgetsCount)
          return; 
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + i];
        if (this.mOrientation == 0) {
          int m = constraintWidget.getWidth();
          int k = Flow.this.mHorizontalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mWidth += m + k;
          k = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          if (this.biggest == null || this.biggestDimension < k) {
            this.biggest = constraintWidget;
            this.biggestDimension = k;
            this.mHeight = k;
          } 
        } else {
          int m = Flow.this.getWidgetWidth(constraintWidget, this.mMax);
          int n = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          int k = Flow.this.mVerticalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mHeight += n + k;
          if (this.biggest == null || this.biggestDimension < m) {
            this.biggest = constraintWidget;
            this.biggestDimension = m;
            this.mWidth = m;
          } 
        } 
      } 
    }
    
    public void add(ConstraintWidget param1ConstraintWidget) {
      int i = this.mOrientation;
      int j = 0;
      int k = 0;
      if (i == 0) {
        i = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        j = Flow.this.mHorizontalGap;
        if (param1ConstraintWidget.getVisibility() == 8)
          j = k; 
        this.mWidth += i + j;
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (this.biggest == null || this.biggestDimension < i) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = i;
          this.mHeight = i;
        } 
      } else {
        int m = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        k = Flow.this.mVerticalGap;
        if (param1ConstraintWidget.getVisibility() != 8)
          j = k; 
        this.mHeight += i + j;
        if (this.biggest == null || this.biggestDimension < m) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = m;
          this.mWidth = m;
        } 
      } 
      this.mCount++;
    }
    
    public void clear() {
      this.biggestDimension = 0;
      this.biggest = null;
      this.mWidth = 0;
      this.mHeight = 0;
      this.mStartIndex = 0;
      this.mCount = 0;
      this.mNbMatchConstraintsWidgets = 0;
    }
    
    public void createConstraints(boolean param1Boolean1, int param1Int, boolean param1Boolean2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield mCount : I
      //   4: istore #13
      //   6: iconst_0
      //   7: istore #6
      //   9: iload #6
      //   11: iload #13
      //   13: if_icmpge -> 72
      //   16: aload_0
      //   17: getfield mStartIndex : I
      //   20: iload #6
      //   22: iadd
      //   23: aload_0
      //   24: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   27: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   30: if_icmplt -> 36
      //   33: goto -> 72
      //   36: aload_0
      //   37: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   40: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   43: aload_0
      //   44: getfield mStartIndex : I
      //   47: iload #6
      //   49: iadd
      //   50: aaload
      //   51: astore #14
      //   53: aload #14
      //   55: ifnull -> 63
      //   58: aload #14
      //   60: invokevirtual resetAnchors : ()V
      //   63: iload #6
      //   65: iconst_1
      //   66: iadd
      //   67: istore #6
      //   69: goto -> 9
      //   72: iload #13
      //   74: ifeq -> 1733
      //   77: aload_0
      //   78: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   81: ifnonnull -> 85
      //   84: return
      //   85: iload_3
      //   86: ifeq -> 99
      //   89: iload_2
      //   90: ifne -> 99
      //   93: iconst_1
      //   94: istore #9
      //   96: goto -> 102
      //   99: iconst_0
      //   100: istore #9
      //   102: iconst_0
      //   103: istore #6
      //   105: iconst_m1
      //   106: istore #7
      //   108: iconst_m1
      //   109: istore #8
      //   111: iload #6
      //   113: iload #13
      //   115: if_icmpge -> 226
      //   118: iload_1
      //   119: ifeq -> 134
      //   122: iload #13
      //   124: iconst_1
      //   125: isub
      //   126: iload #6
      //   128: isub
      //   129: istore #12
      //   131: goto -> 138
      //   134: iload #6
      //   136: istore #12
      //   138: aload_0
      //   139: getfield mStartIndex : I
      //   142: iload #12
      //   144: iadd
      //   145: aload_0
      //   146: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   149: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   152: if_icmplt -> 158
      //   155: goto -> 226
      //   158: iload #7
      //   160: istore #10
      //   162: iload #8
      //   164: istore #11
      //   166: aload_0
      //   167: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   170: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   173: aload_0
      //   174: getfield mStartIndex : I
      //   177: iload #12
      //   179: iadd
      //   180: aaload
      //   181: invokevirtual getVisibility : ()I
      //   184: ifne -> 209
      //   187: iload #7
      //   189: istore #8
      //   191: iload #7
      //   193: iconst_m1
      //   194: if_icmpne -> 201
      //   197: iload #6
      //   199: istore #8
      //   201: iload #6
      //   203: istore #11
      //   205: iload #8
      //   207: istore #10
      //   209: iload #6
      //   211: iconst_1
      //   212: iadd
      //   213: istore #6
      //   215: iload #10
      //   217: istore #7
      //   219: iload #11
      //   221: istore #8
      //   223: goto -> 111
      //   226: aconst_null
      //   227: astore #14
      //   229: aconst_null
      //   230: astore #15
      //   232: aload_0
      //   233: getfield mOrientation : I
      //   236: ifne -> 1017
      //   239: aload_0
      //   240: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   243: astore #16
      //   245: aload #16
      //   247: aload_0
      //   248: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   251: invokestatic access$600 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   254: invokevirtual setVerticalChainStyle : (I)V
      //   257: aload_0
      //   258: getfield mPaddingTop : I
      //   261: istore #10
      //   263: iload #10
      //   265: istore #6
      //   267: iload_2
      //   268: ifle -> 283
      //   271: iload #10
      //   273: aload_0
      //   274: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   277: invokestatic access$100 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   280: iadd
      //   281: istore #6
      //   283: aload #16
      //   285: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   288: aload_0
      //   289: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   292: iload #6
      //   294: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   297: pop
      //   298: iload_3
      //   299: ifeq -> 319
      //   302: aload #16
      //   304: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   307: aload_0
      //   308: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   311: aload_0
      //   312: getfield mPaddingBottom : I
      //   315: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   318: pop
      //   319: iload_2
      //   320: ifle -> 343
      //   323: aload_0
      //   324: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   327: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   330: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   333: aload #16
      //   335: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   338: iconst_0
      //   339: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   342: pop
      //   343: aload_0
      //   344: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   347: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   350: iconst_3
      //   351: if_icmpne -> 443
      //   354: aload #16
      //   356: invokevirtual hasBaseline : ()Z
      //   359: ifne -> 443
      //   362: iconst_0
      //   363: istore_2
      //   364: iload_2
      //   365: iload #13
      //   367: if_icmpge -> 443
      //   370: iload_1
      //   371: ifeq -> 385
      //   374: iload #13
      //   376: iconst_1
      //   377: isub
      //   378: iload_2
      //   379: isub
      //   380: istore #6
      //   382: goto -> 388
      //   385: iload_2
      //   386: istore #6
      //   388: aload_0
      //   389: getfield mStartIndex : I
      //   392: iload #6
      //   394: iadd
      //   395: aload_0
      //   396: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   399: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   402: if_icmplt -> 408
      //   405: goto -> 443
      //   408: aload_0
      //   409: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   412: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   415: aload_0
      //   416: getfield mStartIndex : I
      //   419: iload #6
      //   421: iadd
      //   422: aaload
      //   423: astore #14
      //   425: aload #14
      //   427: invokevirtual hasBaseline : ()Z
      //   430: ifeq -> 436
      //   433: goto -> 447
      //   436: iload_2
      //   437: iconst_1
      //   438: iadd
      //   439: istore_2
      //   440: goto -> 364
      //   443: aload #16
      //   445: astore #14
      //   447: iconst_0
      //   448: istore #6
      //   450: iload #6
      //   452: iload #13
      //   454: if_icmpge -> 1733
      //   457: iload_1
      //   458: ifeq -> 472
      //   461: iload #13
      //   463: iconst_1
      //   464: isub
      //   465: iload #6
      //   467: isub
      //   468: istore_2
      //   469: goto -> 475
      //   472: iload #6
      //   474: istore_2
      //   475: aload_0
      //   476: getfield mStartIndex : I
      //   479: iload_2
      //   480: iadd
      //   481: aload_0
      //   482: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   485: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   488: if_icmplt -> 492
      //   491: return
      //   492: aload_0
      //   493: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   496: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   499: aload_0
      //   500: getfield mStartIndex : I
      //   503: iload_2
      //   504: iadd
      //   505: aaload
      //   506: astore #17
      //   508: iload #6
      //   510: ifne -> 531
      //   513: aload #17
      //   515: aload #17
      //   517: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   520: aload_0
      //   521: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   524: aload_0
      //   525: getfield mPaddingLeft : I
      //   528: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   531: iload_2
      //   532: ifne -> 709
      //   535: aload_0
      //   536: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   539: invokestatic access$800 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   542: istore #10
      //   544: aload_0
      //   545: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   548: invokestatic access$900 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   551: fstore #5
      //   553: fload #5
      //   555: fstore #4
      //   557: iload_1
      //   558: ifeq -> 567
      //   561: fconst_1
      //   562: fload #5
      //   564: fsub
      //   565: fstore #4
      //   567: aload_0
      //   568: getfield mStartIndex : I
      //   571: ifne -> 631
      //   574: aload_0
      //   575: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   578: invokestatic access$1000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   581: iconst_m1
      //   582: if_icmpeq -> 631
      //   585: aload_0
      //   586: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   589: invokestatic access$1000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   592: istore_2
      //   593: iload_1
      //   594: ifeq -> 615
      //   597: aload_0
      //   598: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   601: invokestatic access$1100 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   604: fstore #4
      //   606: fconst_1
      //   607: fload #4
      //   609: fsub
      //   610: fstore #4
      //   612: goto -> 624
      //   615: aload_0
      //   616: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   619: invokestatic access$1100 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   622: fstore #4
      //   624: fload #4
      //   626: fstore #5
      //   628: goto -> 696
      //   631: iload #10
      //   633: istore_2
      //   634: fload #4
      //   636: fstore #5
      //   638: iload_3
      //   639: ifeq -> 696
      //   642: iload #10
      //   644: istore_2
      //   645: fload #4
      //   647: fstore #5
      //   649: aload_0
      //   650: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   653: invokestatic access$1200 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   656: iconst_m1
      //   657: if_icmpeq -> 696
      //   660: aload_0
      //   661: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   664: invokestatic access$1200 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   667: istore_2
      //   668: iload_1
      //   669: ifeq -> 684
      //   672: aload_0
      //   673: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   676: invokestatic access$1300 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   679: fstore #4
      //   681: goto -> 606
      //   684: aload_0
      //   685: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   688: invokestatic access$1300 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   691: fstore #4
      //   693: goto -> 624
      //   696: aload #17
      //   698: iload_2
      //   699: invokevirtual setHorizontalChainStyle : (I)V
      //   702: aload #17
      //   704: fload #5
      //   706: invokevirtual setHorizontalBiasPercent : (F)V
      //   709: iload #6
      //   711: iload #13
      //   713: iconst_1
      //   714: isub
      //   715: if_icmpne -> 736
      //   718: aload #17
      //   720: aload #17
      //   722: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   725: aload_0
      //   726: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   729: aload_0
      //   730: getfield mPaddingRight : I
      //   733: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   736: aload #15
      //   738: ifnull -> 817
      //   741: aload #17
      //   743: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   746: aload #15
      //   748: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   751: aload_0
      //   752: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   755: invokestatic access$000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   758: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   761: pop
      //   762: iload #6
      //   764: iload #7
      //   766: if_icmpne -> 781
      //   769: aload #17
      //   771: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   774: aload_0
      //   775: getfield mPaddingLeft : I
      //   778: invokevirtual setGoneMargin : (I)V
      //   781: aload #15
      //   783: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   786: aload #17
      //   788: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   791: iconst_0
      //   792: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   795: pop
      //   796: iload #6
      //   798: iload #8
      //   800: iconst_1
      //   801: iadd
      //   802: if_icmpne -> 817
      //   805: aload #15
      //   807: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   810: aload_0
      //   811: getfield mPaddingRight : I
      //   814: invokevirtual setGoneMargin : (I)V
      //   817: aload #17
      //   819: aload #16
      //   821: if_acmpeq -> 1004
      //   824: aload_0
      //   825: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   828: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   831: iconst_3
      //   832: if_icmpne -> 876
      //   835: aload #14
      //   837: invokevirtual hasBaseline : ()Z
      //   840: ifeq -> 876
      //   843: aload #17
      //   845: aload #14
      //   847: if_acmpeq -> 876
      //   850: aload #17
      //   852: invokevirtual hasBaseline : ()Z
      //   855: ifeq -> 876
      //   858: aload #17
      //   860: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   863: aload #14
      //   865: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   868: iconst_0
      //   869: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   872: pop
      //   873: goto -> 1004
      //   876: aload_0
      //   877: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   880: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   883: istore_2
      //   884: iload_2
      //   885: ifeq -> 986
      //   888: iload_2
      //   889: iconst_1
      //   890: if_icmpeq -> 968
      //   893: iload #9
      //   895: ifeq -> 935
      //   898: aload #17
      //   900: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   903: aload_0
      //   904: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   907: aload_0
      //   908: getfield mPaddingTop : I
      //   911: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   914: pop
      //   915: aload #17
      //   917: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   920: aload_0
      //   921: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   924: aload_0
      //   925: getfield mPaddingBottom : I
      //   928: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   931: pop
      //   932: goto -> 1004
      //   935: aload #17
      //   937: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   940: aload #16
      //   942: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   945: iconst_0
      //   946: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   949: pop
      //   950: aload #17
      //   952: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   955: aload #16
      //   957: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   960: iconst_0
      //   961: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   964: pop
      //   965: goto -> 1004
      //   968: aload #17
      //   970: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   973: aload #16
      //   975: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   978: iconst_0
      //   979: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   982: pop
      //   983: goto -> 1004
      //   986: aload #17
      //   988: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   991: aload #16
      //   993: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   996: iconst_0
      //   997: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1000: pop
      //   1001: goto -> 1004
      //   1004: iload #6
      //   1006: iconst_1
      //   1007: iadd
      //   1008: istore #6
      //   1010: aload #17
      //   1012: astore #15
      //   1014: goto -> 450
      //   1017: aload_0
      //   1018: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1021: astore #16
      //   1023: aload #16
      //   1025: aload_0
      //   1026: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1029: invokestatic access$800 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1032: invokevirtual setHorizontalChainStyle : (I)V
      //   1035: aload_0
      //   1036: getfield mPaddingLeft : I
      //   1039: istore #10
      //   1041: iload #10
      //   1043: istore #6
      //   1045: iload_2
      //   1046: ifle -> 1061
      //   1049: iload #10
      //   1051: aload_0
      //   1052: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1055: invokestatic access$000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1058: iadd
      //   1059: istore #6
      //   1061: iload_1
      //   1062: ifeq -> 1128
      //   1065: aload #16
      //   1067: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1070: aload_0
      //   1071: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1074: iload #6
      //   1076: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1079: pop
      //   1080: iload_3
      //   1081: ifeq -> 1101
      //   1084: aload #16
      //   1086: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1089: aload_0
      //   1090: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1093: aload_0
      //   1094: getfield mPaddingRight : I
      //   1097: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1100: pop
      //   1101: iload_2
      //   1102: ifle -> 1188
      //   1105: aload_0
      //   1106: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1109: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1112: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1115: aload #16
      //   1117: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1120: iconst_0
      //   1121: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1124: pop
      //   1125: goto -> 1188
      //   1128: aload #16
      //   1130: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1133: aload_0
      //   1134: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1137: iload #6
      //   1139: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1142: pop
      //   1143: iload_3
      //   1144: ifeq -> 1164
      //   1147: aload #16
      //   1149: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1152: aload_0
      //   1153: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1156: aload_0
      //   1157: getfield mPaddingRight : I
      //   1160: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1163: pop
      //   1164: iload_2
      //   1165: ifle -> 1188
      //   1168: aload_0
      //   1169: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1172: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1175: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1178: aload #16
      //   1180: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1183: iconst_0
      //   1184: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1187: pop
      //   1188: iconst_0
      //   1189: istore #6
      //   1191: iload #6
      //   1193: iload #13
      //   1195: if_icmpge -> 1733
      //   1198: aload_0
      //   1199: getfield mStartIndex : I
      //   1202: iload #6
      //   1204: iadd
      //   1205: aload_0
      //   1206: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1209: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1212: if_icmplt -> 1216
      //   1215: return
      //   1216: aload_0
      //   1217: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1220: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1223: aload_0
      //   1224: getfield mStartIndex : I
      //   1227: iload #6
      //   1229: iadd
      //   1230: aaload
      //   1231: astore #15
      //   1233: iload #6
      //   1235: ifne -> 1371
      //   1238: aload #15
      //   1240: aload #15
      //   1242: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1245: aload_0
      //   1246: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1249: aload_0
      //   1250: getfield mPaddingTop : I
      //   1253: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   1256: aload_0
      //   1257: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1260: invokestatic access$600 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1263: istore #10
      //   1265: aload_0
      //   1266: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1269: invokestatic access$1400 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1272: fstore #5
      //   1274: aload_0
      //   1275: getfield mStartIndex : I
      //   1278: ifne -> 1312
      //   1281: aload_0
      //   1282: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1285: invokestatic access$1500 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1288: iconst_m1
      //   1289: if_icmpeq -> 1312
      //   1292: aload_0
      //   1293: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1296: invokestatic access$1500 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1299: istore_2
      //   1300: aload_0
      //   1301: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1304: invokestatic access$1600 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1307: fstore #4
      //   1309: goto -> 1358
      //   1312: iload #10
      //   1314: istore_2
      //   1315: fload #5
      //   1317: fstore #4
      //   1319: iload_3
      //   1320: ifeq -> 1358
      //   1323: iload #10
      //   1325: istore_2
      //   1326: fload #5
      //   1328: fstore #4
      //   1330: aload_0
      //   1331: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1334: invokestatic access$1700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1337: iconst_m1
      //   1338: if_icmpeq -> 1358
      //   1341: aload_0
      //   1342: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1345: invokestatic access$1700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1348: istore_2
      //   1349: aload_0
      //   1350: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1353: invokestatic access$1800 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1356: fstore #4
      //   1358: aload #15
      //   1360: iload_2
      //   1361: invokevirtual setVerticalChainStyle : (I)V
      //   1364: aload #15
      //   1366: fload #4
      //   1368: invokevirtual setVerticalBiasPercent : (F)V
      //   1371: iload #6
      //   1373: iload #13
      //   1375: iconst_1
      //   1376: isub
      //   1377: if_icmpne -> 1398
      //   1380: aload #15
      //   1382: aload #15
      //   1384: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1387: aload_0
      //   1388: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1391: aload_0
      //   1392: getfield mPaddingBottom : I
      //   1395: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   1398: aload #14
      //   1400: ifnull -> 1479
      //   1403: aload #15
      //   1405: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1408: aload #14
      //   1410: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1413: aload_0
      //   1414: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1417: invokestatic access$100 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1420: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1423: pop
      //   1424: iload #6
      //   1426: iload #7
      //   1428: if_icmpne -> 1443
      //   1431: aload #15
      //   1433: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1436: aload_0
      //   1437: getfield mPaddingTop : I
      //   1440: invokevirtual setGoneMargin : (I)V
      //   1443: aload #14
      //   1445: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1448: aload #15
      //   1450: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1453: iconst_0
      //   1454: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1457: pop
      //   1458: iload #6
      //   1460: iload #8
      //   1462: iconst_1
      //   1463: iadd
      //   1464: if_icmpne -> 1479
      //   1467: aload #14
      //   1469: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1472: aload_0
      //   1473: getfield mPaddingBottom : I
      //   1476: invokevirtual setGoneMargin : (I)V
      //   1479: aload #15
      //   1481: aload #16
      //   1483: if_acmpeq -> 1720
      //   1486: iload_1
      //   1487: ifeq -> 1584
      //   1490: aload_0
      //   1491: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1494: invokestatic access$1900 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1497: istore_2
      //   1498: iload_2
      //   1499: ifeq -> 1566
      //   1502: iload_2
      //   1503: iconst_1
      //   1504: if_icmpeq -> 1548
      //   1507: iload_2
      //   1508: iconst_2
      //   1509: if_icmpeq -> 1515
      //   1512: goto -> 1720
      //   1515: aload #15
      //   1517: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1520: aload #16
      //   1522: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1525: iconst_0
      //   1526: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1529: pop
      //   1530: aload #15
      //   1532: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1535: aload #16
      //   1537: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1540: iconst_0
      //   1541: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1544: pop
      //   1545: goto -> 1720
      //   1548: aload #15
      //   1550: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1553: aload #16
      //   1555: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1558: iconst_0
      //   1559: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1562: pop
      //   1563: goto -> 1720
      //   1566: aload #15
      //   1568: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1571: aload #16
      //   1573: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1576: iconst_0
      //   1577: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1580: pop
      //   1581: goto -> 1720
      //   1584: aload_0
      //   1585: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1588: invokestatic access$1900 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1591: istore_2
      //   1592: iload_2
      //   1593: ifeq -> 1702
      //   1596: iload_2
      //   1597: iconst_1
      //   1598: if_icmpeq -> 1684
      //   1601: iload_2
      //   1602: iconst_2
      //   1603: if_icmpeq -> 1609
      //   1606: goto -> 1720
      //   1609: iload #9
      //   1611: ifeq -> 1651
      //   1614: aload #15
      //   1616: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1619: aload_0
      //   1620: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1623: aload_0
      //   1624: getfield mPaddingLeft : I
      //   1627: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1630: pop
      //   1631: aload #15
      //   1633: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1636: aload_0
      //   1637: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1640: aload_0
      //   1641: getfield mPaddingRight : I
      //   1644: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1647: pop
      //   1648: goto -> 1720
      //   1651: aload #15
      //   1653: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1656: aload #16
      //   1658: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1661: iconst_0
      //   1662: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1665: pop
      //   1666: aload #15
      //   1668: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1671: aload #16
      //   1673: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1676: iconst_0
      //   1677: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1680: pop
      //   1681: goto -> 1720
      //   1684: aload #15
      //   1686: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1689: aload #16
      //   1691: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1694: iconst_0
      //   1695: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1698: pop
      //   1699: goto -> 1720
      //   1702: aload #15
      //   1704: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1707: aload #16
      //   1709: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1712: iconst_0
      //   1713: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1716: pop
      //   1717: goto -> 1720
      //   1720: iload #6
      //   1722: iconst_1
      //   1723: iadd
      //   1724: istore #6
      //   1726: aload #15
      //   1728: astore #14
      //   1730: goto -> 1191
      //   1733: return
    }
    
    public int getHeight() {
      return (this.mOrientation == 1) ? (this.mHeight - Flow.this.mVerticalGap) : this.mHeight;
    }
    
    public int getWidth() {
      return (this.mOrientation == 0) ? (this.mWidth - Flow.this.mHorizontalGap) : this.mWidth;
    }
    
    public void measureMatchConstraints(int param1Int) {
      int j = this.mNbMatchConstraintsWidgets;
      if (j == 0)
        return; 
      int i = this.mCount;
      j = param1Int / j;
      for (param1Int = 0; param1Int < i && this.mStartIndex + param1Int < Flow.this.mDisplayedWidgetsCount; param1Int++) {
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + param1Int];
        if (this.mOrientation == 0) {
          if (constraintWidget != null && constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultWidth == 0)
            Flow.this.measure(constraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, j, constraintWidget.getVerticalDimensionBehaviour(), constraintWidget.getHeight()); 
        } else if (constraintWidget != null && constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultHeight == 0) {
          Flow.this.measure(constraintWidget, constraintWidget.getHorizontalDimensionBehaviour(), constraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, j);
        } 
      } 
      recomputeDimensions();
    }
    
    public void setStartIndex(int param1Int) {
      this.mStartIndex = param1Int;
    }
    
    public void setup(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = param1Int2;
      this.mPaddingTop = param1Int3;
      this.mPaddingRight = param1Int4;
      this.mPaddingBottom = param1Int5;
      this.mMax = param1Int6;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\core\widgets\Flow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */