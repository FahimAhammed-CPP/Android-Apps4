package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.Barrier;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import java.util.Iterator;

class HelperReferences extends WidgetRun {
  public HelperReferences(ConstraintWidget paramConstraintWidget) {
    super(paramConstraintWidget);
  }
  
  private void addDependency(DependencyNode paramDependencyNode) {
    this.start.dependencies.add(paramDependencyNode);
    paramDependencyNode.targets.add(this.start);
  }
  
  void apply() {
    if (this.widget instanceof Barrier) {
      this.start.delegateToWidgetRun = true;
      Barrier barrier = (Barrier)this.widget;
      int j = barrier.getBarrierType();
      boolean bool = barrier.getAllowsGoneWidget();
      boolean bool1 = false;
      boolean bool2 = false;
      boolean bool3 = false;
      int i = 0;
      if (j != 0) {
        if (j != 1) {
          if (j != 2) {
            if (j != 3)
              return; 
            this.start.type = DependencyNode.Type.BOTTOM;
            while (i < barrier.mWidgetsCount) {
              ConstraintWidget constraintWidget = barrier.mWidgets[i];
              if (bool || constraintWidget.getVisibility() != 8) {
                DependencyNode dependencyNode = constraintWidget.verticalRun.end;
                dependencyNode.dependencies.add(this.start);
                this.start.targets.add(dependencyNode);
              } 
              i++;
            } 
            addDependency(this.widget.verticalRun.start);
            addDependency(this.widget.verticalRun.end);
            return;
          } 
          this.start.type = DependencyNode.Type.TOP;
          for (i = bool1; i < barrier.mWidgetsCount; i++) {
            ConstraintWidget constraintWidget = barrier.mWidgets[i];
            if (bool || constraintWidget.getVisibility() != 8) {
              DependencyNode dependencyNode = constraintWidget.verticalRun.start;
              dependencyNode.dependencies.add(this.start);
              this.start.targets.add(dependencyNode);
            } 
          } 
          addDependency(this.widget.verticalRun.start);
          addDependency(this.widget.verticalRun.end);
          return;
        } 
        this.start.type = DependencyNode.Type.RIGHT;
        for (i = bool2; i < barrier.mWidgetsCount; i++) {
          ConstraintWidget constraintWidget = barrier.mWidgets[i];
          if (bool || constraintWidget.getVisibility() != 8) {
            DependencyNode dependencyNode = constraintWidget.horizontalRun.end;
            dependencyNode.dependencies.add(this.start);
            this.start.targets.add(dependencyNode);
          } 
        } 
        addDependency(this.widget.horizontalRun.start);
        addDependency(this.widget.horizontalRun.end);
        return;
      } 
      this.start.type = DependencyNode.Type.LEFT;
      for (i = bool3; i < barrier.mWidgetsCount; i++) {
        ConstraintWidget constraintWidget = barrier.mWidgets[i];
        if (bool || constraintWidget.getVisibility() != 8) {
          DependencyNode dependencyNode = constraintWidget.horizontalRun.start;
          dependencyNode.dependencies.add(this.start);
          this.start.targets.add(dependencyNode);
        } 
      } 
      addDependency(this.widget.horizontalRun.start);
      addDependency(this.widget.horizontalRun.end);
    } 
  }
  
  public void applyToWidget() {
    if (this.widget instanceof Barrier) {
      int i = ((Barrier)this.widget).getBarrierType();
      if (i == 0 || i == 1) {
        this.widget.setX(this.start.value);
        return;
      } 
      this.widget.setY(this.start.value);
      return;
    } 
  }
  
  void clear() {
    this.runGroup = null;
    this.start.clear();
  }
  
  void reset() {
    this.start.resolved = false;
  }
  
  boolean supportsWrapComputation() {
    return false;
  }
  
  public void update(Dependency paramDependency) {
    Object object1;
    Object object2;
    Barrier barrier = (Barrier)this.widget;
    int i = barrier.getBarrierType();
    Iterator<DependencyNode> iterator = this.start.targets.iterator();
    byte b = 0;
    byte b1 = -1;
    while (true) {
      while (true)
        break; 
      if (b < SYNTHETIC_LOCAL_VARIABLE_4) {
        object1 = SYNTHETIC_LOCAL_VARIABLE_4;
        object2 = SYNTHETIC_LOCAL_VARIABLE_5;
      } 
    } 
    if (i == 0 || i == 2) {
      this.start.resolve(object2 + barrier.getMargin());
      return;
    } 
    this.start.resolve(object1 + barrier.getMargin());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\core\widgets\analyzer\HelperReferences.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */