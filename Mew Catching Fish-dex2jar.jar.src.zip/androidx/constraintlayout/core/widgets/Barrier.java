package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import java.util.HashMap;

public class Barrier extends HelperWidget {
  public static final int BOTTOM = 3;
  
  public static final int LEFT = 0;
  
  public static final int RIGHT = 1;
  
  public static final int TOP = 2;
  
  private static final boolean USE_RELAX_GONE = false;
  
  private static final boolean USE_RESOLUTION = true;
  
  private boolean mAllowsGoneWidget = true;
  
  private int mBarrierType = 0;
  
  private int mMargin = 0;
  
  boolean resolved = false;
  
  public Barrier() {}
  
  public Barrier(String paramString) {
    setDebugName(paramString);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   4: iconst_0
    //   5: aload_0
    //   6: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   9: aastore
    //   10: aload_0
    //   11: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   14: iconst_2
    //   15: aload_0
    //   16: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   19: aastore
    //   20: aload_0
    //   21: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   24: iconst_1
    //   25: aload_0
    //   26: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   29: aastore
    //   30: aload_0
    //   31: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   34: iconst_3
    //   35: aload_0
    //   36: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   39: aastore
    //   40: iconst_0
    //   41: istore_3
    //   42: iload_3
    //   43: aload_0
    //   44: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   47: arraylength
    //   48: if_icmpge -> 77
    //   51: aload_0
    //   52: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   55: iload_3
    //   56: aaload
    //   57: aload_1
    //   58: aload_0
    //   59: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   62: iload_3
    //   63: aaload
    //   64: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   67: putfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   70: iload_3
    //   71: iconst_1
    //   72: iadd
    //   73: istore_3
    //   74: goto -> 42
    //   77: aload_0
    //   78: getfield mBarrierType : I
    //   81: istore_3
    //   82: iload_3
    //   83: iflt -> 1028
    //   86: iload_3
    //   87: iconst_4
    //   88: if_icmpge -> 1028
    //   91: aload_0
    //   92: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   95: aload_0
    //   96: getfield mBarrierType : I
    //   99: aaload
    //   100: astore #7
    //   102: aload_0
    //   103: getfield resolved : Z
    //   106: ifne -> 114
    //   109: aload_0
    //   110: invokevirtual allSolved : ()Z
    //   113: pop
    //   114: aload_0
    //   115: getfield resolved : Z
    //   118: ifeq -> 215
    //   121: aload_0
    //   122: iconst_0
    //   123: putfield resolved : Z
    //   126: aload_0
    //   127: getfield mBarrierType : I
    //   130: istore_3
    //   131: iload_3
    //   132: ifeq -> 184
    //   135: iload_3
    //   136: iconst_1
    //   137: if_icmpne -> 143
    //   140: goto -> 184
    //   143: iload_3
    //   144: iconst_2
    //   145: if_icmpeq -> 153
    //   148: iload_3
    //   149: iconst_3
    //   150: if_icmpne -> 214
    //   153: aload_1
    //   154: aload_0
    //   155: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   158: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   161: aload_0
    //   162: getfield mY : I
    //   165: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   168: aload_1
    //   169: aload_0
    //   170: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   173: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   176: aload_0
    //   177: getfield mY : I
    //   180: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   183: return
    //   184: aload_1
    //   185: aload_0
    //   186: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   189: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   192: aload_0
    //   193: getfield mX : I
    //   196: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   199: aload_1
    //   200: aload_0
    //   201: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   204: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   207: aload_0
    //   208: getfield mX : I
    //   211: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   214: return
    //   215: iconst_0
    //   216: istore_3
    //   217: iload_3
    //   218: aload_0
    //   219: getfield mWidgetsCount : I
    //   222: if_icmpge -> 367
    //   225: aload_0
    //   226: getfield mWidgets : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   229: iload_3
    //   230: aaload
    //   231: astore #8
    //   233: aload_0
    //   234: getfield mAllowsGoneWidget : Z
    //   237: ifne -> 251
    //   240: aload #8
    //   242: invokevirtual allowedInBarrier : ()Z
    //   245: ifne -> 251
    //   248: goto -> 360
    //   251: aload_0
    //   252: getfield mBarrierType : I
    //   255: istore #4
    //   257: iload #4
    //   259: ifeq -> 268
    //   262: iload #4
    //   264: iconst_1
    //   265: if_icmpne -> 306
    //   268: aload #8
    //   270: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   273: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   276: if_acmpne -> 306
    //   279: aload #8
    //   281: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   284: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   287: ifnull -> 306
    //   290: aload #8
    //   292: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   295: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   298: ifnull -> 306
    //   301: iconst_1
    //   302: istore_2
    //   303: goto -> 369
    //   306: aload_0
    //   307: getfield mBarrierType : I
    //   310: istore #4
    //   312: iload #4
    //   314: iconst_2
    //   315: if_icmpeq -> 324
    //   318: iload #4
    //   320: iconst_3
    //   321: if_icmpne -> 360
    //   324: aload #8
    //   326: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   329: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   332: if_acmpne -> 360
    //   335: aload #8
    //   337: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   340: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   343: ifnull -> 360
    //   346: aload #8
    //   348: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   351: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   354: ifnull -> 360
    //   357: goto -> 301
    //   360: iload_3
    //   361: iconst_1
    //   362: iadd
    //   363: istore_3
    //   364: goto -> 217
    //   367: iconst_0
    //   368: istore_2
    //   369: aload_0
    //   370: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   373: invokevirtual hasCenteredDependents : ()Z
    //   376: ifne -> 397
    //   379: aload_0
    //   380: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   383: invokevirtual hasCenteredDependents : ()Z
    //   386: ifeq -> 392
    //   389: goto -> 397
    //   392: iconst_0
    //   393: istore_3
    //   394: goto -> 399
    //   397: iconst_1
    //   398: istore_3
    //   399: aload_0
    //   400: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   403: invokevirtual hasCenteredDependents : ()Z
    //   406: ifne -> 428
    //   409: aload_0
    //   410: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   413: invokevirtual hasCenteredDependents : ()Z
    //   416: ifeq -> 422
    //   419: goto -> 428
    //   422: iconst_0
    //   423: istore #4
    //   425: goto -> 431
    //   428: iconst_1
    //   429: istore #4
    //   431: iload_2
    //   432: ifne -> 490
    //   435: aload_0
    //   436: getfield mBarrierType : I
    //   439: ifne -> 446
    //   442: iload_3
    //   443: ifne -> 484
    //   446: aload_0
    //   447: getfield mBarrierType : I
    //   450: iconst_2
    //   451: if_icmpne -> 459
    //   454: iload #4
    //   456: ifne -> 484
    //   459: aload_0
    //   460: getfield mBarrierType : I
    //   463: iconst_1
    //   464: if_icmpne -> 471
    //   467: iload_3
    //   468: ifne -> 484
    //   471: aload_0
    //   472: getfield mBarrierType : I
    //   475: iconst_3
    //   476: if_icmpne -> 490
    //   479: iload #4
    //   481: ifeq -> 490
    //   484: iconst_1
    //   485: istore #4
    //   487: goto -> 493
    //   490: iconst_0
    //   491: istore #4
    //   493: iconst_5
    //   494: istore_3
    //   495: iload #4
    //   497: ifne -> 502
    //   500: iconst_4
    //   501: istore_3
    //   502: iconst_0
    //   503: istore #4
    //   505: iload #4
    //   507: aload_0
    //   508: getfield mWidgetsCount : I
    //   511: if_icmpge -> 721
    //   514: aload_0
    //   515: getfield mWidgets : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   518: iload #4
    //   520: aaload
    //   521: astore #8
    //   523: aload_0
    //   524: getfield mAllowsGoneWidget : Z
    //   527: ifne -> 541
    //   530: aload #8
    //   532: invokevirtual allowedInBarrier : ()Z
    //   535: ifne -> 541
    //   538: goto -> 712
    //   541: aload_1
    //   542: aload #8
    //   544: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   547: aload_0
    //   548: getfield mBarrierType : I
    //   551: aaload
    //   552: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   555: astore #9
    //   557: aload #8
    //   559: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   562: aload_0
    //   563: getfield mBarrierType : I
    //   566: aaload
    //   567: aload #9
    //   569: putfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   572: aload #8
    //   574: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   577: aload_0
    //   578: getfield mBarrierType : I
    //   581: aaload
    //   582: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   585: ifnull -> 628
    //   588: aload #8
    //   590: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   593: aload_0
    //   594: getfield mBarrierType : I
    //   597: aaload
    //   598: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   601: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   604: aload_0
    //   605: if_acmpne -> 628
    //   608: aload #8
    //   610: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   613: aload_0
    //   614: getfield mBarrierType : I
    //   617: aaload
    //   618: getfield mMargin : I
    //   621: iconst_0
    //   622: iadd
    //   623: istore #5
    //   625: goto -> 631
    //   628: iconst_0
    //   629: istore #5
    //   631: aload_0
    //   632: getfield mBarrierType : I
    //   635: istore #6
    //   637: iload #6
    //   639: ifeq -> 673
    //   642: iload #6
    //   644: iconst_2
    //   645: if_icmpne -> 651
    //   648: goto -> 673
    //   651: aload_1
    //   652: aload #7
    //   654: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   657: aload #9
    //   659: aload_0
    //   660: getfield mMargin : I
    //   663: iload #5
    //   665: iadd
    //   666: iload_2
    //   667: invokevirtual addGreaterBarrier : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IZ)V
    //   670: goto -> 692
    //   673: aload_1
    //   674: aload #7
    //   676: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   679: aload #9
    //   681: aload_0
    //   682: getfield mMargin : I
    //   685: iload #5
    //   687: isub
    //   688: iload_2
    //   689: invokevirtual addLowerBarrier : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IZ)V
    //   692: aload_1
    //   693: aload #7
    //   695: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   698: aload #9
    //   700: aload_0
    //   701: getfield mMargin : I
    //   704: iload #5
    //   706: iadd
    //   707: iload_3
    //   708: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   711: pop
    //   712: iload #4
    //   714: iconst_1
    //   715: iadd
    //   716: istore #4
    //   718: goto -> 505
    //   721: aload_0
    //   722: getfield mBarrierType : I
    //   725: istore_3
    //   726: iload_3
    //   727: ifne -> 801
    //   730: aload_1
    //   731: aload_0
    //   732: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   735: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   738: aload_0
    //   739: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   742: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   745: iconst_0
    //   746: bipush #8
    //   748: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   751: pop
    //   752: aload_1
    //   753: aload_0
    //   754: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   757: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   760: aload_0
    //   761: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   764: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   767: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   770: iconst_0
    //   771: iconst_4
    //   772: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   775: pop
    //   776: aload_1
    //   777: aload_0
    //   778: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   781: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   784: aload_0
    //   785: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   788: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   791: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   794: iconst_0
    //   795: iconst_0
    //   796: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   799: pop
    //   800: return
    //   801: iload_3
    //   802: iconst_1
    //   803: if_icmpne -> 877
    //   806: aload_1
    //   807: aload_0
    //   808: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   811: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   814: aload_0
    //   815: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   818: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   821: iconst_0
    //   822: bipush #8
    //   824: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   827: pop
    //   828: aload_1
    //   829: aload_0
    //   830: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   833: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   836: aload_0
    //   837: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   840: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   843: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   846: iconst_0
    //   847: iconst_4
    //   848: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   851: pop
    //   852: aload_1
    //   853: aload_0
    //   854: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   857: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   860: aload_0
    //   861: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   864: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   867: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   870: iconst_0
    //   871: iconst_0
    //   872: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   875: pop
    //   876: return
    //   877: iload_3
    //   878: iconst_2
    //   879: if_icmpne -> 953
    //   882: aload_1
    //   883: aload_0
    //   884: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   887: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   890: aload_0
    //   891: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   894: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   897: iconst_0
    //   898: bipush #8
    //   900: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   903: pop
    //   904: aload_1
    //   905: aload_0
    //   906: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   909: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   912: aload_0
    //   913: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   916: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   919: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   922: iconst_0
    //   923: iconst_4
    //   924: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   927: pop
    //   928: aload_1
    //   929: aload_0
    //   930: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   933: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   936: aload_0
    //   937: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   940: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   943: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   946: iconst_0
    //   947: iconst_0
    //   948: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   951: pop
    //   952: return
    //   953: iload_3
    //   954: iconst_3
    //   955: if_icmpne -> 1028
    //   958: aload_1
    //   959: aload_0
    //   960: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   963: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   966: aload_0
    //   967: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   970: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   973: iconst_0
    //   974: bipush #8
    //   976: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   979: pop
    //   980: aload_1
    //   981: aload_0
    //   982: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   985: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   988: aload_0
    //   989: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   992: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   995: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   998: iconst_0
    //   999: iconst_4
    //   1000: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1003: pop
    //   1004: aload_1
    //   1005: aload_0
    //   1006: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1009: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1012: aload_0
    //   1013: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1016: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1019: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1022: iconst_0
    //   1023: iconst_0
    //   1024: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1027: pop
    //   1028: return
  }
  
  public boolean allSolved() {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_0
    //   4: istore_1
    //   5: iconst_1
    //   6: istore_2
    //   7: iload_1
    //   8: aload_0
    //   9: getfield mWidgetsCount : I
    //   12: if_icmpge -> 112
    //   15: aload_0
    //   16: getfield mWidgets : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   19: iload_1
    //   20: aaload
    //   21: astore #7
    //   23: aload_0
    //   24: getfield mAllowsGoneWidget : Z
    //   27: ifne -> 43
    //   30: aload #7
    //   32: invokevirtual allowedInBarrier : ()Z
    //   35: ifne -> 43
    //   38: iload_2
    //   39: istore_3
    //   40: goto -> 103
    //   43: aload_0
    //   44: getfield mBarrierType : I
    //   47: istore_3
    //   48: iload_3
    //   49: ifeq -> 57
    //   52: iload_3
    //   53: iconst_1
    //   54: if_icmpne -> 70
    //   57: aload #7
    //   59: invokevirtual isResolvedHorizontally : ()Z
    //   62: ifne -> 70
    //   65: iconst_0
    //   66: istore_3
    //   67: goto -> 103
    //   70: aload_0
    //   71: getfield mBarrierType : I
    //   74: istore #4
    //   76: iload #4
    //   78: iconst_2
    //   79: if_icmpeq -> 90
    //   82: iload_2
    //   83: istore_3
    //   84: iload #4
    //   86: iconst_3
    //   87: if_icmpne -> 103
    //   90: iload_2
    //   91: istore_3
    //   92: aload #7
    //   94: invokevirtual isResolvedVertically : ()Z
    //   97: ifne -> 103
    //   100: goto -> 65
    //   103: iload_1
    //   104: iconst_1
    //   105: iadd
    //   106: istore_1
    //   107: iload_3
    //   108: istore_2
    //   109: goto -> 7
    //   112: iload_2
    //   113: ifeq -> 432
    //   116: aload_0
    //   117: getfield mWidgetsCount : I
    //   120: ifle -> 432
    //   123: iconst_0
    //   124: istore_1
    //   125: iconst_0
    //   126: istore_3
    //   127: iload #5
    //   129: aload_0
    //   130: getfield mWidgetsCount : I
    //   133: if_icmpge -> 386
    //   136: aload_0
    //   137: getfield mWidgets : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   140: iload #5
    //   142: aaload
    //   143: astore #7
    //   145: aload_0
    //   146: getfield mAllowsGoneWidget : Z
    //   149: ifne -> 163
    //   152: aload #7
    //   154: invokevirtual allowedInBarrier : ()Z
    //   157: ifne -> 163
    //   160: goto -> 377
    //   163: iload_1
    //   164: istore #4
    //   166: iload_3
    //   167: istore_2
    //   168: iload_3
    //   169: ifne -> 258
    //   172: aload_0
    //   173: getfield mBarrierType : I
    //   176: istore_2
    //   177: iload_2
    //   178: ifne -> 196
    //   181: aload #7
    //   183: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   186: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   189: invokevirtual getFinalValue : ()I
    //   192: istore_1
    //   193: goto -> 253
    //   196: iload_2
    //   197: iconst_1
    //   198: if_icmpne -> 216
    //   201: aload #7
    //   203: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   206: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   209: invokevirtual getFinalValue : ()I
    //   212: istore_1
    //   213: goto -> 253
    //   216: iload_2
    //   217: iconst_2
    //   218: if_icmpne -> 236
    //   221: aload #7
    //   223: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   226: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   229: invokevirtual getFinalValue : ()I
    //   232: istore_1
    //   233: goto -> 253
    //   236: iload_2
    //   237: iconst_3
    //   238: if_icmpne -> 253
    //   241: aload #7
    //   243: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   246: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   249: invokevirtual getFinalValue : ()I
    //   252: istore_1
    //   253: iconst_1
    //   254: istore_2
    //   255: iload_1
    //   256: istore #4
    //   258: aload_0
    //   259: getfield mBarrierType : I
    //   262: istore #6
    //   264: iload #6
    //   266: ifne -> 291
    //   269: iload #4
    //   271: aload #7
    //   273: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   276: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   279: invokevirtual getFinalValue : ()I
    //   282: invokestatic min : (II)I
    //   285: istore_1
    //   286: iload_2
    //   287: istore_3
    //   288: goto -> 377
    //   291: iload #6
    //   293: iconst_1
    //   294: if_icmpne -> 319
    //   297: iload #4
    //   299: aload #7
    //   301: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   304: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   307: invokevirtual getFinalValue : ()I
    //   310: invokestatic max : (II)I
    //   313: istore_1
    //   314: iload_2
    //   315: istore_3
    //   316: goto -> 377
    //   319: iload #6
    //   321: iconst_2
    //   322: if_icmpne -> 347
    //   325: iload #4
    //   327: aload #7
    //   329: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   332: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   335: invokevirtual getFinalValue : ()I
    //   338: invokestatic min : (II)I
    //   341: istore_1
    //   342: iload_2
    //   343: istore_3
    //   344: goto -> 377
    //   347: iload #4
    //   349: istore_1
    //   350: iload_2
    //   351: istore_3
    //   352: iload #6
    //   354: iconst_3
    //   355: if_icmpne -> 377
    //   358: iload #4
    //   360: aload #7
    //   362: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   365: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   368: invokevirtual getFinalValue : ()I
    //   371: invokestatic max : (II)I
    //   374: istore_1
    //   375: iload_2
    //   376: istore_3
    //   377: iload #5
    //   379: iconst_1
    //   380: iadd
    //   381: istore #5
    //   383: goto -> 127
    //   386: iload_1
    //   387: aload_0
    //   388: getfield mMargin : I
    //   391: iadd
    //   392: istore_1
    //   393: aload_0
    //   394: getfield mBarrierType : I
    //   397: istore_2
    //   398: iload_2
    //   399: ifeq -> 419
    //   402: iload_2
    //   403: iconst_1
    //   404: if_icmpne -> 410
    //   407: goto -> 419
    //   410: aload_0
    //   411: iload_1
    //   412: iload_1
    //   413: invokevirtual setFinalVertical : (II)V
    //   416: goto -> 425
    //   419: aload_0
    //   420: iload_1
    //   421: iload_1
    //   422: invokevirtual setFinalHorizontal : (II)V
    //   425: aload_0
    //   426: iconst_1
    //   427: putfield resolved : Z
    //   430: iconst_1
    //   431: ireturn
    //   432: iconst_0
    //   433: ireturn
  }
  
  public boolean allowedInBarrier() {
    return true;
  }
  
  @Deprecated
  public boolean allowsGoneWidget() {
    return this.mAllowsGoneWidget;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    this.mBarrierType = ((Barrier)paramConstraintWidget).mBarrierType;
    this.mAllowsGoneWidget = ((Barrier)paramConstraintWidget).mAllowsGoneWidget;
    this.mMargin = ((Barrier)paramConstraintWidget).mMargin;
  }
  
  public boolean getAllowsGoneWidget() {
    return this.mAllowsGoneWidget;
  }
  
  public int getBarrierType() {
    return this.mBarrierType;
  }
  
  public int getMargin() {
    return this.mMargin;
  }
  
  public int getOrientation() {
    int i = this.mBarrierType;
    return (i != 0 && i != 1) ? ((i != 2 && i != 3) ? -1 : 1) : 0;
  }
  
  public boolean isResolvedHorizontally() {
    return this.resolved;
  }
  
  public boolean isResolvedVertically() {
    return this.resolved;
  }
  
  protected void markWidgets() {
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      if (this.mAllowsGoneWidget || constraintWidget.allowedInBarrier()) {
        int j = this.mBarrierType;
        if (j == 0 || j == 1) {
          constraintWidget.setInBarrier(0, true);
        } else if (j == 2 || j == 3) {
          constraintWidget.setInBarrier(1, true);
        } 
      } 
    } 
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.mAllowsGoneWidget = paramBoolean;
  }
  
  public void setBarrierType(int paramInt) {
    this.mBarrierType = paramInt;
  }
  
  public void setMargin(int paramInt) {
    this.mMargin = paramInt;
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("[Barrier] ");
    stringBuilder1.append(getDebugName());
    stringBuilder1.append(" {");
    String str = stringBuilder1.toString();
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      String str1 = str;
      if (i > 0) {
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append(", ");
        str1 = stringBuilder3.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append(constraintWidget.getDebugName());
      str = stringBuilder.toString();
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str);
    stringBuilder2.append("}");
    return stringBuilder2.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\core\widgets\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */