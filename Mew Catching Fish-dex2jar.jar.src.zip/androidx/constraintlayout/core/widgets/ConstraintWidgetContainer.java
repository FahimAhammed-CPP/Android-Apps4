package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.Metrics;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;
import androidx.constraintlayout.core.widgets.analyzer.DependencyGraph;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidgetContainer extends WidgetContainer {
  private static final boolean DEBUG = false;
  
  static final boolean DEBUG_GRAPH = false;
  
  private static final boolean DEBUG_LAYOUT = false;
  
  private static final int MAX_ITERATIONS = 8;
  
  static int myCounter;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMin = null;
  
  BasicMeasure mBasicMeasureSolver = new BasicMeasure(this);
  
  int mDebugSolverPassCount = 0;
  
  public DependencyGraph mDependencyGraph = new DependencyGraph(this);
  
  public boolean mGroupsWrapOptimized = false;
  
  private boolean mHeightMeasuredTooSmall = false;
  
  ChainHead[] mHorizontalChainsArray = new ChainHead[4];
  
  public int mHorizontalChainsSize = 0;
  
  public boolean mHorizontalWrapOptimized = false;
  
  private boolean mIsRtl = false;
  
  public BasicMeasure.Measure mMeasure = new BasicMeasure.Measure();
  
  protected BasicMeasure.Measurer mMeasurer = null;
  
  public Metrics mMetrics;
  
  private int mOptimizationLevel = 257;
  
  int mPaddingBottom;
  
  int mPaddingLeft;
  
  int mPaddingRight;
  
  int mPaddingTop;
  
  public boolean mSkipSolver = false;
  
  protected LinearSystem mSystem = new LinearSystem();
  
  ChainHead[] mVerticalChainsArray = new ChainHead[4];
  
  public int mVerticalChainsSize = 0;
  
  public boolean mVerticalWrapOptimized = false;
  
  private boolean mWidthMeasuredTooSmall = false;
  
  public int mWrapFixedHeight = 0;
  
  public int mWrapFixedWidth = 0;
  
  private int pass;
  
  private WeakReference<ConstraintAnchor> verticalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> verticalWrapMin = null;
  
  HashSet<ConstraintWidget> widgetsToAdd = new HashSet<ConstraintWidget>();
  
  public ConstraintWidgetContainer() {}
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public ConstraintWidgetContainer(String paramString, int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  private void addHorizontalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mHorizontalChainsSize;
    ChainHead[] arrayOfChainHead = this.mHorizontalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mHorizontalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mHorizontalChainsArray[this.mHorizontalChainsSize] = new ChainHead(paramConstraintWidget, 0, isRtl());
    this.mHorizontalChainsSize++;
  }
  
  private void addMaxWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(paramSolverVariable, solverVariable, 0, 5);
  }
  
  private void addMinWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(solverVariable, paramSolverVariable, 0, 5);
  }
  
  private void addVerticalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mVerticalChainsSize;
    ChainHead[] arrayOfChainHead = this.mVerticalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mVerticalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mVerticalChainsArray[this.mVerticalChainsSize] = new ChainHead(paramConstraintWidget, 1, isRtl());
    this.mVerticalChainsSize++;
  }
  
  public static boolean measure(int paramInt1, ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer, BasicMeasure.Measure paramMeasure, int paramInt2) {
    boolean bool1;
    boolean bool2;
    if (paramMeasurer == null)
      return false; 
    if (paramConstraintWidget.getVisibility() == 8 || paramConstraintWidget instanceof Guideline || paramConstraintWidget instanceof Barrier) {
      paramMeasure.measuredWidth = 0;
      paramMeasure.measuredHeight = 0;
      return false;
    } 
    paramMeasure.horizontalBehavior = paramConstraintWidget.getHorizontalDimensionBehaviour();
    paramMeasure.verticalBehavior = paramConstraintWidget.getVerticalDimensionBehaviour();
    paramMeasure.horizontalDimension = paramConstraintWidget.getWidth();
    paramMeasure.verticalDimension = paramConstraintWidget.getHeight();
    paramMeasure.measuredNeedsSolverPass = false;
    paramMeasure.measureStrategy = paramInt2;
    if (paramMeasure.horizontalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramMeasure.verticalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    if (paramInt1 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramInt2 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int i = paramInt1;
    if (paramInt1 != 0) {
      i = paramInt1;
      if (paramConstraintWidget.hasDanglingDimension(0)) {
        i = paramInt1;
        if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0) {
          i = paramInt1;
          if (!bool2) {
            paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (paramInt2 != 0 && paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
              paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            i = 0;
          } 
        } 
      } 
    } 
    paramInt1 = paramInt2;
    if (paramInt2 != 0) {
      paramInt1 = paramInt2;
      if (paramConstraintWidget.hasDanglingDimension(1)) {
        paramInt1 = paramInt2;
        if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0) {
          paramInt1 = paramInt2;
          if (!bool1) {
            paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (i != 0 && paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
              paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            paramInt1 = 0;
          } 
        } 
      } 
    } 
    if (paramConstraintWidget.isResolvedHorizontally()) {
      paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      i = 0;
    } 
    if (paramConstraintWidget.isResolvedVertically()) {
      paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      paramInt1 = 0;
    } 
    if (bool2)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[0] == 4) {
        paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (paramInt1 == 0) {
        if (paramMeasure.verticalBehavior == ConstraintWidget.DimensionBehaviour.FIXED) {
          paramInt1 = paramMeasure.verticalDimension;
        } else {
          paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredHeight;
        } 
        paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
        paramMeasure.horizontalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
      }  
    if (bool1)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[1] == 4) {
        paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (i == 0) {
        if (paramMeasure.horizontalBehavior == ConstraintWidget.DimensionBehaviour.FIXED) {
          paramInt1 = paramMeasure.horizontalDimension;
        } else {
          paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredWidth;
        } 
        paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
        if (paramConstraintWidget.getDimensionRatioSide() == -1) {
          paramMeasure.verticalDimension = (int)(paramInt1 / paramConstraintWidget.getDimensionRatio());
        } else {
          paramMeasure.verticalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
        } 
      }  
    paramMeasurer.measure(paramConstraintWidget, paramMeasure);
    paramConstraintWidget.setWidth(paramMeasure.measuredWidth);
    paramConstraintWidget.setHeight(paramMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(paramMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(paramMeasure.measuredBaseline);
    paramMeasure.measureStrategy = BasicMeasure.Measure.SELF_DIMENSIONS;
    return paramMeasure.measuredNeedsSolverPass;
  }
  
  private void resetChains() {
    this.mHorizontalChainsSize = 0;
    this.mVerticalChainsSize = 0;
  }
  
  void addChain(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramInt == 0) {
      addHorizontalChain(paramConstraintWidget);
      return;
    } 
    if (paramInt == 1)
      addVerticalChain(paramConstraintWidget); 
  }
  
  public boolean addChildrenToSolver(LinearSystem paramLinearSystem) {
    boolean bool1 = optimizeFor(64);
    addToSolver(paramLinearSystem, bool1);
    int j = this.mChildren.size();
    int i = 0;
    boolean bool = false;
    while (i < j) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.setInBarrier(0, false);
      constraintWidget.setInBarrier(1, false);
      if (constraintWidget instanceof Barrier)
        bool = true; 
      i++;
    } 
    if (bool)
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof Barrier)
          ((Barrier)constraintWidget).markWidgets(); 
      }  
    this.widgetsToAdd.clear();
    for (i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget.addFirst())
        if (constraintWidget instanceof VirtualLayout) {
          this.widgetsToAdd.add(constraintWidget);
        } else {
          constraintWidget.addToSolver(paramLinearSystem, bool1);
        }  
    } 
    while (this.widgetsToAdd.size() > 0) {
      i = this.widgetsToAdd.size();
      for (VirtualLayout virtualLayout : this.widgetsToAdd) {
        if (virtualLayout.contains(this.widgetsToAdd)) {
          virtualLayout.addToSolver(paramLinearSystem, bool1);
          this.widgetsToAdd.remove(virtualLayout);
          break;
        } 
      } 
      if (i == this.widgetsToAdd.size()) {
        Iterator<ConstraintWidget> iterator = this.widgetsToAdd.iterator();
        while (iterator.hasNext())
          ((ConstraintWidget)iterator.next()).addToSolver(paramLinearSystem, bool1); 
        this.widgetsToAdd.clear();
      } 
    } 
    if (LinearSystem.USE_DEPENDENCY_ORDERING) {
      HashSet<ConstraintWidget> hashSet = new HashSet();
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (!constraintWidget.addFirst())
          hashSet.add(constraintWidget); 
      } 
      if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        i = 0;
      } else {
        i = 1;
      } 
      addChildrenToSolverByDependency(this, paramLinearSystem, hashSet, i, false);
      for (ConstraintWidget constraintWidget : hashSet) {
        Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
        constraintWidget.addToSolver(paramLinearSystem, bool1);
      } 
    } else {
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof ConstraintWidgetContainer) {
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = constraintWidget.mListDimensionBehaviors[0];
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = constraintWidget.mListDimensionBehaviors[1];
          if (dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          constraintWidget.addToSolver(paramLinearSystem, bool1);
          if (dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setHorizontalDimensionBehaviour(dimensionBehaviour1); 
          if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setVerticalDimensionBehaviour(dimensionBehaviour2); 
        } else {
          Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
          if (!constraintWidget.addFirst())
            constraintWidget.addToSolver(paramLinearSystem, bool1); 
        } 
      } 
    } 
    if (this.mHorizontalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 0); 
    if (this.mVerticalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 1); 
    return true;
  }
  
  public void addHorizontalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMax.get()).getFinalValue())
      this.horizontalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void addHorizontalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMin.get()).getFinalValue())
      this.horizontalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMax.get()).getFinalValue())
      this.verticalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMin.get()).getFinalValue())
      this.verticalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void defineTerminalWidgets() {
    this.mDependencyGraph.defineTerminalWidgets(getHorizontalDimensionBehaviour(), getVerticalDimensionBehaviour());
  }
  
  public boolean directMeasure(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasure(paramBoolean);
  }
  
  public boolean directMeasureSetup(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasureSetup(paramBoolean);
  }
  
  public boolean directMeasureWithOrientation(boolean paramBoolean, int paramInt) {
    return this.mDependencyGraph.directMeasureWithOrientation(paramBoolean, paramInt);
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mSystem.fillMetrics(paramMetrics);
  }
  
  public ArrayList<Guideline> getHorizontalGuidelines() {
    ArrayList<ConstraintWidget> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        constraintWidget = constraintWidget;
        if (constraintWidget.getOrientation() == 0)
          arrayList.add(constraintWidget); 
      } 
    } 
    return (ArrayList)arrayList;
  }
  
  public BasicMeasure.Measurer getMeasurer() {
    return this.mMeasurer;
  }
  
  public int getOptimizationLevel() {
    return this.mOptimizationLevel;
  }
  
  public LinearSystem getSystem() {
    return this.mSystem;
  }
  
  public String getType() {
    return "ConstraintLayout";
  }
  
  public ArrayList<Guideline> getVerticalGuidelines() {
    ArrayList<ConstraintWidget> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        constraintWidget = constraintWidget;
        if (constraintWidget.getOrientation() == 1)
          arrayList.add(constraintWidget); 
      } 
    } 
    return (ArrayList)arrayList;
  }
  
  public boolean handlesInternalConstraints() {
    return false;
  }
  
  public void invalidateGraph() {
    this.mDependencyGraph.invalidateGraph();
  }
  
  public void invalidateMeasures() {
    this.mDependencyGraph.invalidateMeasures();
  }
  
  public boolean isHeightMeasuredTooSmall() {
    return this.mHeightMeasuredTooSmall;
  }
  
  public boolean isRtl() {
    return this.mIsRtl;
  }
  
  public boolean isWidthMeasuredTooSmall() {
    return this.mWidthMeasuredTooSmall;
  }
  
  public void layout() {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mX : I
    //   5: aload_0
    //   6: iconst_0
    //   7: putfield mY : I
    //   10: aload_0
    //   11: iconst_0
    //   12: putfield mWidthMeasuredTooSmall : Z
    //   15: aload_0
    //   16: iconst_0
    //   17: putfield mHeightMeasuredTooSmall : Z
    //   20: aload_0
    //   21: getfield mChildren : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #9
    //   29: iconst_0
    //   30: aload_0
    //   31: invokevirtual getWidth : ()I
    //   34: invokestatic max : (II)I
    //   37: istore_2
    //   38: iconst_0
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: invokestatic max : (II)I
    //   46: istore_3
    //   47: aload_0
    //   48: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   51: iconst_1
    //   52: aaload
    //   53: astore #14
    //   55: aload_0
    //   56: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   59: iconst_0
    //   60: aaload
    //   61: astore #15
    //   63: aload_0
    //   64: getfield mMetrics : Landroidx/constraintlayout/core/Metrics;
    //   67: astore #16
    //   69: aload #16
    //   71: ifnull -> 86
    //   74: aload #16
    //   76: aload #16
    //   78: getfield layouts : J
    //   81: lconst_1
    //   82: ladd
    //   83: putfield layouts : J
    //   86: aload_0
    //   87: getfield pass : I
    //   90: ifne -> 269
    //   93: aload_0
    //   94: getfield mOptimizationLevel : I
    //   97: iconst_1
    //   98: invokestatic enabled : (II)Z
    //   101: ifeq -> 269
    //   104: aload_0
    //   105: aload_0
    //   106: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   109: invokestatic solvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V
    //   112: iconst_0
    //   113: istore_1
    //   114: iload_1
    //   115: iload #9
    //   117: if_icmpge -> 269
    //   120: aload_0
    //   121: getfield mChildren : Ljava/util/ArrayList;
    //   124: iload_1
    //   125: invokevirtual get : (I)Ljava/lang/Object;
    //   128: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   131: astore #16
    //   133: aload #16
    //   135: invokevirtual isMeasureRequested : ()Z
    //   138: ifeq -> 262
    //   141: aload #16
    //   143: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   146: ifne -> 262
    //   149: aload #16
    //   151: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   154: ifne -> 262
    //   157: aload #16
    //   159: instanceof androidx/constraintlayout/core/widgets/VirtualLayout
    //   162: ifne -> 262
    //   165: aload #16
    //   167: invokevirtual isInVirtualLayout : ()Z
    //   170: ifne -> 262
    //   173: aload #16
    //   175: iconst_0
    //   176: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   179: astore #17
    //   181: aload #16
    //   183: iconst_1
    //   184: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   187: astore #18
    //   189: aload #17
    //   191: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   194: if_acmpne -> 229
    //   197: aload #16
    //   199: getfield mMatchConstraintDefaultWidth : I
    //   202: iconst_1
    //   203: if_icmpeq -> 229
    //   206: aload #18
    //   208: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   211: if_acmpne -> 229
    //   214: aload #16
    //   216: getfield mMatchConstraintDefaultHeight : I
    //   219: iconst_1
    //   220: if_icmpeq -> 229
    //   223: iconst_1
    //   224: istore #4
    //   226: goto -> 232
    //   229: iconst_0
    //   230: istore #4
    //   232: iload #4
    //   234: ifne -> 262
    //   237: new androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure
    //   240: dup
    //   241: invokespecial <init> : ()V
    //   244: astore #17
    //   246: iconst_0
    //   247: aload #16
    //   249: aload_0
    //   250: getfield mMeasurer : Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   253: aload #17
    //   255: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   258: invokestatic measure : (ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   261: pop
    //   262: iload_1
    //   263: iconst_1
    //   264: iadd
    //   265: istore_1
    //   266: goto -> 114
    //   269: iload #9
    //   271: iconst_2
    //   272: if_icmple -> 410
    //   275: aload #15
    //   277: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   280: if_acmpeq -> 291
    //   283: aload #14
    //   285: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   288: if_acmpne -> 410
    //   291: aload_0
    //   292: getfield mOptimizationLevel : I
    //   295: sipush #1024
    //   298: invokestatic enabled : (II)Z
    //   301: ifeq -> 410
    //   304: aload_0
    //   305: aload_0
    //   306: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   309: invokestatic simpleSolvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)Z
    //   312: ifeq -> 410
    //   315: iload_2
    //   316: istore_1
    //   317: aload #15
    //   319: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   322: if_acmpne -> 357
    //   325: iload_2
    //   326: aload_0
    //   327: invokevirtual getWidth : ()I
    //   330: if_icmpge -> 352
    //   333: iload_2
    //   334: ifle -> 352
    //   337: aload_0
    //   338: iload_2
    //   339: invokevirtual setWidth : (I)V
    //   342: aload_0
    //   343: iconst_1
    //   344: putfield mWidthMeasuredTooSmall : Z
    //   347: iload_2
    //   348: istore_1
    //   349: goto -> 357
    //   352: aload_0
    //   353: invokevirtual getWidth : ()I
    //   356: istore_1
    //   357: iload_3
    //   358: istore_2
    //   359: aload #14
    //   361: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   364: if_acmpne -> 399
    //   367: iload_3
    //   368: aload_0
    //   369: invokevirtual getHeight : ()I
    //   372: if_icmpge -> 394
    //   375: iload_3
    //   376: ifle -> 394
    //   379: aload_0
    //   380: iload_3
    //   381: invokevirtual setHeight : (I)V
    //   384: aload_0
    //   385: iconst_1
    //   386: putfield mHeightMeasuredTooSmall : Z
    //   389: iload_3
    //   390: istore_2
    //   391: goto -> 399
    //   394: aload_0
    //   395: invokevirtual getHeight : ()I
    //   398: istore_2
    //   399: iload_1
    //   400: istore #4
    //   402: iconst_1
    //   403: istore_1
    //   404: iload_2
    //   405: istore #5
    //   407: goto -> 418
    //   410: iconst_0
    //   411: istore_1
    //   412: iload_3
    //   413: istore #5
    //   415: iload_2
    //   416: istore #4
    //   418: aload_0
    //   419: bipush #64
    //   421: invokevirtual optimizeFor : (I)Z
    //   424: ifne -> 445
    //   427: aload_0
    //   428: sipush #128
    //   431: invokevirtual optimizeFor : (I)Z
    //   434: ifeq -> 440
    //   437: goto -> 445
    //   440: iconst_0
    //   441: istore_2
    //   442: goto -> 447
    //   445: iconst_1
    //   446: istore_2
    //   447: aload_0
    //   448: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   451: iconst_0
    //   452: putfield graphOptimizer : Z
    //   455: aload_0
    //   456: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   459: iconst_0
    //   460: putfield newgraphOptimizer : Z
    //   463: aload_0
    //   464: getfield mOptimizationLevel : I
    //   467: ifeq -> 482
    //   470: iload_2
    //   471: ifeq -> 482
    //   474: aload_0
    //   475: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   478: iconst_1
    //   479: putfield newgraphOptimizer : Z
    //   482: aload_0
    //   483: getfield mChildren : Ljava/util/ArrayList;
    //   486: astore #16
    //   488: aload_0
    //   489: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   492: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   495: if_acmpeq -> 517
    //   498: aload_0
    //   499: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   502: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   505: if_acmpne -> 511
    //   508: goto -> 517
    //   511: iconst_0
    //   512: istore #6
    //   514: goto -> 520
    //   517: iconst_1
    //   518: istore #6
    //   520: aload_0
    //   521: invokespecial resetChains : ()V
    //   524: iconst_0
    //   525: istore_2
    //   526: iload_2
    //   527: iload #9
    //   529: if_icmpge -> 568
    //   532: aload_0
    //   533: getfield mChildren : Ljava/util/ArrayList;
    //   536: iload_2
    //   537: invokevirtual get : (I)Ljava/lang/Object;
    //   540: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   543: astore #17
    //   545: aload #17
    //   547: instanceof androidx/constraintlayout/core/widgets/WidgetContainer
    //   550: ifeq -> 561
    //   553: aload #17
    //   555: checkcast androidx/constraintlayout/core/widgets/WidgetContainer
    //   558: invokevirtual layout : ()V
    //   561: iload_2
    //   562: iconst_1
    //   563: iadd
    //   564: istore_2
    //   565: goto -> 526
    //   568: aload_0
    //   569: bipush #64
    //   571: invokevirtual optimizeFor : (I)Z
    //   574: istore #13
    //   576: iconst_0
    //   577: istore_2
    //   578: iconst_1
    //   579: istore #11
    //   581: iload #11
    //   583: ifeq -> 1536
    //   586: iload_2
    //   587: iconst_1
    //   588: iadd
    //   589: istore #8
    //   591: iload #11
    //   593: istore #10
    //   595: aload_0
    //   596: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   599: invokevirtual reset : ()V
    //   602: iload #11
    //   604: istore #10
    //   606: aload_0
    //   607: invokespecial resetChains : ()V
    //   610: iload #11
    //   612: istore #10
    //   614: aload_0
    //   615: aload_0
    //   616: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   619: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   622: iconst_0
    //   623: istore_2
    //   624: iload_2
    //   625: iload #9
    //   627: if_icmpge -> 659
    //   630: iload #11
    //   632: istore #10
    //   634: aload_0
    //   635: getfield mChildren : Ljava/util/ArrayList;
    //   638: iload_2
    //   639: invokevirtual get : (I)Ljava/lang/Object;
    //   642: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   645: aload_0
    //   646: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   649: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   652: iload_2
    //   653: iconst_1
    //   654: iadd
    //   655: istore_2
    //   656: goto -> 624
    //   659: iload #11
    //   661: istore #10
    //   663: aload_0
    //   664: aload_0
    //   665: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   668: invokevirtual addChildrenToSolver : (Landroidx/constraintlayout/core/LinearSystem;)Z
    //   671: istore #11
    //   673: iload #11
    //   675: istore #10
    //   677: aload_0
    //   678: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   681: ifnull -> 736
    //   684: iload #11
    //   686: istore #10
    //   688: aload_0
    //   689: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   692: invokevirtual get : ()Ljava/lang/Object;
    //   695: ifnull -> 736
    //   698: iload #11
    //   700: istore #10
    //   702: aload_0
    //   703: aload_0
    //   704: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   707: invokevirtual get : ()Ljava/lang/Object;
    //   710: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   713: aload_0
    //   714: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   717: aload_0
    //   718: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   721: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   724: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   727: iload #11
    //   729: istore #10
    //   731: aload_0
    //   732: aconst_null
    //   733: putfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   736: iload #11
    //   738: istore #10
    //   740: aload_0
    //   741: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   744: ifnull -> 799
    //   747: iload #11
    //   749: istore #10
    //   751: aload_0
    //   752: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   755: invokevirtual get : ()Ljava/lang/Object;
    //   758: ifnull -> 799
    //   761: iload #11
    //   763: istore #10
    //   765: aload_0
    //   766: aload_0
    //   767: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   770: invokevirtual get : ()Ljava/lang/Object;
    //   773: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   776: aload_0
    //   777: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   780: aload_0
    //   781: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   784: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   787: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   790: iload #11
    //   792: istore #10
    //   794: aload_0
    //   795: aconst_null
    //   796: putfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   799: iload #11
    //   801: istore #10
    //   803: aload_0
    //   804: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   807: ifnull -> 862
    //   810: iload #11
    //   812: istore #10
    //   814: aload_0
    //   815: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   818: invokevirtual get : ()Ljava/lang/Object;
    //   821: ifnull -> 862
    //   824: iload #11
    //   826: istore #10
    //   828: aload_0
    //   829: aload_0
    //   830: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   833: invokevirtual get : ()Ljava/lang/Object;
    //   836: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   839: aload_0
    //   840: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   843: aload_0
    //   844: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   847: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   850: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   853: iload #11
    //   855: istore #10
    //   857: aload_0
    //   858: aconst_null
    //   859: putfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   862: iload #11
    //   864: istore #10
    //   866: aload_0
    //   867: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   870: ifnull -> 925
    //   873: iload #11
    //   875: istore #10
    //   877: aload_0
    //   878: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   881: invokevirtual get : ()Ljava/lang/Object;
    //   884: ifnull -> 925
    //   887: iload #11
    //   889: istore #10
    //   891: aload_0
    //   892: aload_0
    //   893: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   896: invokevirtual get : ()Ljava/lang/Object;
    //   899: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   902: aload_0
    //   903: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   906: aload_0
    //   907: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   910: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   913: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   916: iload #11
    //   918: istore #10
    //   920: aload_0
    //   921: aconst_null
    //   922: putfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   925: iload #11
    //   927: istore #10
    //   929: iload #11
    //   931: ifeq -> 1000
    //   934: iload #11
    //   936: istore #10
    //   938: aload_0
    //   939: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   942: invokevirtual minimize : ()V
    //   945: iload #11
    //   947: istore #10
    //   949: goto -> 1000
    //   952: astore #17
    //   954: aload #17
    //   956: invokevirtual printStackTrace : ()V
    //   959: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   962: astore #18
    //   964: new java/lang/StringBuilder
    //   967: dup
    //   968: invokespecial <init> : ()V
    //   971: astore #19
    //   973: aload #19
    //   975: ldc_w 'EXCEPTION : '
    //   978: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   981: pop
    //   982: aload #19
    //   984: aload #17
    //   986: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   989: pop
    //   990: aload #18
    //   992: aload #19
    //   994: invokevirtual toString : ()Ljava/lang/String;
    //   997: invokevirtual println : (Ljava/lang/String;)V
    //   1000: iload #10
    //   1002: ifeq -> 1021
    //   1005: aload_0
    //   1006: aload_0
    //   1007: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1010: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1013: invokevirtual updateChildrenFromSolver : (Landroidx/constraintlayout/core/LinearSystem;[Z)Z
    //   1016: istore #10
    //   1018: goto -> 1069
    //   1021: aload_0
    //   1022: aload_0
    //   1023: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1026: iload #13
    //   1028: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1031: iconst_0
    //   1032: istore_2
    //   1033: iload_2
    //   1034: iload #9
    //   1036: if_icmpge -> 1066
    //   1039: aload_0
    //   1040: getfield mChildren : Ljava/util/ArrayList;
    //   1043: iload_2
    //   1044: invokevirtual get : (I)Ljava/lang/Object;
    //   1047: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1050: aload_0
    //   1051: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1054: iload #13
    //   1056: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1059: iload_2
    //   1060: iconst_1
    //   1061: iadd
    //   1062: istore_2
    //   1063: goto -> 1033
    //   1066: iconst_0
    //   1067: istore #10
    //   1069: iload #6
    //   1071: ifeq -> 1275
    //   1074: iload #8
    //   1076: bipush #8
    //   1078: if_icmpge -> 1275
    //   1081: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1084: iconst_2
    //   1085: baload
    //   1086: ifeq -> 1275
    //   1089: iconst_0
    //   1090: istore_3
    //   1091: iconst_0
    //   1092: istore_2
    //   1093: iconst_0
    //   1094: istore #7
    //   1096: iload_3
    //   1097: iload #9
    //   1099: if_icmpge -> 1156
    //   1102: aload_0
    //   1103: getfield mChildren : Ljava/util/ArrayList;
    //   1106: iload_3
    //   1107: invokevirtual get : (I)Ljava/lang/Object;
    //   1110: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1113: astore #17
    //   1115: iload #7
    //   1117: aload #17
    //   1119: getfield mX : I
    //   1122: aload #17
    //   1124: invokevirtual getWidth : ()I
    //   1127: iadd
    //   1128: invokestatic max : (II)I
    //   1131: istore #7
    //   1133: iload_2
    //   1134: aload #17
    //   1136: getfield mY : I
    //   1139: aload #17
    //   1141: invokevirtual getHeight : ()I
    //   1144: iadd
    //   1145: invokestatic max : (II)I
    //   1148: istore_2
    //   1149: iload_3
    //   1150: iconst_1
    //   1151: iadd
    //   1152: istore_3
    //   1153: goto -> 1096
    //   1156: aload_0
    //   1157: getfield mMinWidth : I
    //   1160: iload #7
    //   1162: invokestatic max : (II)I
    //   1165: istore #7
    //   1167: aload_0
    //   1168: getfield mMinHeight : I
    //   1171: iload_2
    //   1172: invokestatic max : (II)I
    //   1175: istore_3
    //   1176: iload_1
    //   1177: istore_2
    //   1178: iload #10
    //   1180: istore #11
    //   1182: aload #15
    //   1184: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1187: if_acmpne -> 1225
    //   1190: iload_1
    //   1191: istore_2
    //   1192: iload #10
    //   1194: istore #11
    //   1196: aload_0
    //   1197: invokevirtual getWidth : ()I
    //   1200: iload #7
    //   1202: if_icmpge -> 1225
    //   1205: aload_0
    //   1206: iload #7
    //   1208: invokevirtual setWidth : (I)V
    //   1211: aload_0
    //   1212: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1215: iconst_0
    //   1216: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1219: aastore
    //   1220: iconst_1
    //   1221: istore_2
    //   1222: iconst_1
    //   1223: istore #11
    //   1225: iload_2
    //   1226: istore_1
    //   1227: iload #11
    //   1229: istore #10
    //   1231: aload #14
    //   1233: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1236: if_acmpne -> 1275
    //   1239: iload_2
    //   1240: istore_1
    //   1241: iload #11
    //   1243: istore #10
    //   1245: aload_0
    //   1246: invokevirtual getHeight : ()I
    //   1249: iload_3
    //   1250: if_icmpge -> 1275
    //   1253: aload_0
    //   1254: iload_3
    //   1255: invokevirtual setHeight : (I)V
    //   1258: aload_0
    //   1259: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1262: iconst_1
    //   1263: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1266: aastore
    //   1267: iconst_1
    //   1268: istore_1
    //   1269: iconst_1
    //   1270: istore #10
    //   1272: goto -> 1275
    //   1275: aload_0
    //   1276: getfield mMinWidth : I
    //   1279: aload_0
    //   1280: invokevirtual getWidth : ()I
    //   1283: invokestatic max : (II)I
    //   1286: istore_2
    //   1287: iload_2
    //   1288: aload_0
    //   1289: invokevirtual getWidth : ()I
    //   1292: if_icmple -> 1314
    //   1295: aload_0
    //   1296: iload_2
    //   1297: invokevirtual setWidth : (I)V
    //   1300: aload_0
    //   1301: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1304: iconst_0
    //   1305: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1308: aastore
    //   1309: iconst_1
    //   1310: istore_1
    //   1311: iconst_1
    //   1312: istore #10
    //   1314: aload_0
    //   1315: getfield mMinHeight : I
    //   1318: aload_0
    //   1319: invokevirtual getHeight : ()I
    //   1322: invokestatic max : (II)I
    //   1325: istore_2
    //   1326: iload_2
    //   1327: aload_0
    //   1328: invokevirtual getHeight : ()I
    //   1331: if_icmple -> 1356
    //   1334: aload_0
    //   1335: iload_2
    //   1336: invokevirtual setHeight : (I)V
    //   1339: aload_0
    //   1340: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1343: iconst_1
    //   1344: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1347: aastore
    //   1348: iconst_1
    //   1349: istore_1
    //   1350: iconst_1
    //   1351: istore #10
    //   1353: goto -> 1356
    //   1356: iload_1
    //   1357: istore_3
    //   1358: iload #10
    //   1360: istore #12
    //   1362: iload_1
    //   1363: ifne -> 1507
    //   1366: iload_1
    //   1367: istore_2
    //   1368: iload #10
    //   1370: istore #11
    //   1372: aload_0
    //   1373: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1376: iconst_0
    //   1377: aaload
    //   1378: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1381: if_acmpne -> 1435
    //   1384: iload_1
    //   1385: istore_2
    //   1386: iload #10
    //   1388: istore #11
    //   1390: iload #4
    //   1392: ifle -> 1435
    //   1395: iload_1
    //   1396: istore_2
    //   1397: iload #10
    //   1399: istore #11
    //   1401: aload_0
    //   1402: invokevirtual getWidth : ()I
    //   1405: iload #4
    //   1407: if_icmple -> 1435
    //   1410: aload_0
    //   1411: iconst_1
    //   1412: putfield mWidthMeasuredTooSmall : Z
    //   1415: aload_0
    //   1416: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1419: iconst_0
    //   1420: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1423: aastore
    //   1424: aload_0
    //   1425: iload #4
    //   1427: invokevirtual setWidth : (I)V
    //   1430: iconst_1
    //   1431: istore_2
    //   1432: iconst_1
    //   1433: istore #11
    //   1435: iload_2
    //   1436: istore_3
    //   1437: iload #11
    //   1439: istore #12
    //   1441: aload_0
    //   1442: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1445: iconst_1
    //   1446: aaload
    //   1447: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1450: if_acmpne -> 1507
    //   1453: iload_2
    //   1454: istore_3
    //   1455: iload #11
    //   1457: istore #12
    //   1459: iload #5
    //   1461: ifle -> 1507
    //   1464: iload_2
    //   1465: istore_3
    //   1466: iload #11
    //   1468: istore #12
    //   1470: aload_0
    //   1471: invokevirtual getHeight : ()I
    //   1474: iload #5
    //   1476: if_icmple -> 1507
    //   1479: aload_0
    //   1480: iconst_1
    //   1481: putfield mHeightMeasuredTooSmall : Z
    //   1484: aload_0
    //   1485: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1488: iconst_1
    //   1489: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1492: aastore
    //   1493: aload_0
    //   1494: iload #5
    //   1496: invokevirtual setHeight : (I)V
    //   1499: iconst_1
    //   1500: istore #10
    //   1502: iconst_1
    //   1503: istore_1
    //   1504: goto -> 1513
    //   1507: iload #12
    //   1509: istore #10
    //   1511: iload_3
    //   1512: istore_1
    //   1513: iload #8
    //   1515: bipush #8
    //   1517: if_icmple -> 1526
    //   1520: iconst_0
    //   1521: istore #11
    //   1523: goto -> 1530
    //   1526: iload #10
    //   1528: istore #11
    //   1530: iload #8
    //   1532: istore_2
    //   1533: goto -> 581
    //   1536: aload_0
    //   1537: aload #16
    //   1539: checkcast java/util/ArrayList
    //   1542: putfield mChildren : Ljava/util/ArrayList;
    //   1545: iload_1
    //   1546: ifeq -> 1565
    //   1549: aload_0
    //   1550: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1553: iconst_0
    //   1554: aload #15
    //   1556: aastore
    //   1557: aload_0
    //   1558: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1561: iconst_1
    //   1562: aload #14
    //   1564: aastore
    //   1565: aload_0
    //   1566: aload_0
    //   1567: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1570: invokevirtual getCache : ()Landroidx/constraintlayout/core/Cache;
    //   1573: invokevirtual resetSolverVariables : (Landroidx/constraintlayout/core/Cache;)V
    //   1576: return
    // Exception table:
    //   from	to	target	type
    //   595	602	952	java/lang/Exception
    //   606	610	952	java/lang/Exception
    //   614	622	952	java/lang/Exception
    //   634	652	952	java/lang/Exception
    //   663	673	952	java/lang/Exception
    //   677	684	952	java/lang/Exception
    //   688	698	952	java/lang/Exception
    //   702	727	952	java/lang/Exception
    //   731	736	952	java/lang/Exception
    //   740	747	952	java/lang/Exception
    //   751	761	952	java/lang/Exception
    //   765	790	952	java/lang/Exception
    //   794	799	952	java/lang/Exception
    //   803	810	952	java/lang/Exception
    //   814	824	952	java/lang/Exception
    //   828	853	952	java/lang/Exception
    //   857	862	952	java/lang/Exception
    //   866	873	952	java/lang/Exception
    //   877	887	952	java/lang/Exception
    //   891	916	952	java/lang/Exception
    //   920	925	952	java/lang/Exception
    //   938	945	952	java/lang/Exception
  }
  
  public long measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    this.mPaddingLeft = paramInt8;
    this.mPaddingTop = paramInt9;
    return this.mBasicMeasureSolver.solverMeasure(this, paramInt1, paramInt8, paramInt9, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
  }
  
  public boolean optimizeFor(int paramInt) {
    return ((this.mOptimizationLevel & paramInt) == paramInt);
  }
  
  public void reset() {
    this.mSystem.reset();
    this.mPaddingLeft = 0;
    this.mPaddingRight = 0;
    this.mPaddingTop = 0;
    this.mPaddingBottom = 0;
    this.mSkipSolver = false;
    super.reset();
  }
  
  public void setMeasurer(BasicMeasure.Measurer paramMeasurer) {
    this.mMeasurer = paramMeasurer;
    this.mDependencyGraph.setMeasurer(paramMeasurer);
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    LinearSystem.USE_DEPENDENCY_ORDERING = optimizeFor(512);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mPaddingLeft = paramInt1;
    this.mPaddingTop = paramInt2;
    this.mPaddingRight = paramInt3;
    this.mPaddingBottom = paramInt4;
  }
  
  public void setPass(int paramInt) {
    this.pass = paramInt;
  }
  
  public void setRtl(boolean paramBoolean) {
    this.mIsRtl = paramBoolean;
  }
  
  public boolean updateChildrenFromSolver(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    int i = 0;
    paramArrayOfboolean[2] = false;
    boolean bool1 = optimizeFor(64);
    updateFromSolver(paramLinearSystem, bool1);
    int j = this.mChildren.size();
    boolean bool = false;
    while (i < j) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.updateFromSolver(paramLinearSystem, bool1);
      if (constraintWidget.hasDimensionOverride())
        bool = true; 
      i++;
    } 
    return bool;
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    super.updateFromRuns(paramBoolean1, paramBoolean2);
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++)
      ((ConstraintWidget)this.mChildren.get(i)).updateFromRuns(paramBoolean1, paramBoolean2); 
  }
  
  public void updateHierarchy() {
    this.mBasicMeasureSolver.updateHierarchy(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintWidgetContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */