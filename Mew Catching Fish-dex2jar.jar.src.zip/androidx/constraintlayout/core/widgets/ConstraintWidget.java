package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.Cache;
import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.state.WidgetFrame;
import androidx.constraintlayout.core.widgets.analyzer.ChainRun;
import androidx.constraintlayout.core.widgets.analyzer.HorizontalWidgetRun;
import androidx.constraintlayout.core.widgets.analyzer.VerticalWidgetRun;
import androidx.constraintlayout.core.widgets.analyzer.WidgetRun;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidget {
  public static final int ANCHOR_BASELINE = 4;
  
  public static final int ANCHOR_BOTTOM = 3;
  
  public static final int ANCHOR_LEFT = 0;
  
  public static final int ANCHOR_RIGHT = 1;
  
  public static final int ANCHOR_TOP = 2;
  
  private static final boolean AUTOTAG_CENTER = false;
  
  public static final int BOTH = 2;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static float DEFAULT_BIAS = 0.5F;
  
  static final int DIMENSION_HORIZONTAL = 0;
  
  static final int DIMENSION_VERTICAL = 1;
  
  protected static final int DIRECT = 2;
  
  public static final int GONE = 8;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVISIBLE = 4;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_RATIO = 3;
  
  public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  protected static final int SOLVER = 1;
  
  public static final int UNKNOWN = -1;
  
  private static final boolean USE_WRAP_DIMENSION_FOR_SPREAD = false;
  
  public static final int VERTICAL = 1;
  
  public static final int VISIBLE = 0;
  
  private static final int WRAP = -2;
  
  public static final int WRAP_BEHAVIOR_HORIZONTAL_ONLY = 1;
  
  public static final int WRAP_BEHAVIOR_INCLUDED = 0;
  
  public static final int WRAP_BEHAVIOR_SKIPPED = 3;
  
  public static final int WRAP_BEHAVIOR_VERTICAL_ONLY = 2;
  
  private boolean OPTIMIZE_WRAP = false;
  
  private boolean OPTIMIZE_WRAP_ON_RESOLVED = true;
  
  public WidgetFrame frame = new WidgetFrame(this);
  
  private boolean hasBaseline = false;
  
  public ChainRun horizontalChainRun;
  
  public int horizontalGroup;
  
  public HorizontalWidgetRun horizontalRun = null;
  
  private boolean horizontalSolvingPass = false;
  
  private boolean inPlaceholder;
  
  public boolean[] isTerminalWidget = new boolean[] { true, true };
  
  protected ArrayList<ConstraintAnchor> mAnchors;
  
  public ConstraintAnchor mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
  
  int mBaselineDistance;
  
  public ConstraintAnchor mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
  
  boolean mBottomHasCentered;
  
  public ConstraintAnchor mCenter;
  
  ConstraintAnchor mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
  
  ConstraintAnchor mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
  
  private float mCircleConstraintAngle = 0.0F;
  
  private Object mCompanionWidget;
  
  private int mContainerItemSkip;
  
  private String mDebugName;
  
  public float mDimensionRatio;
  
  protected int mDimensionRatioSide;
  
  int mDistToBottom;
  
  int mDistToLeft;
  
  int mDistToRight;
  
  int mDistToTop;
  
  boolean mGroupsToSolver;
  
  int mHeight;
  
  private int mHeightOverride = -1;
  
  float mHorizontalBiasPercent;
  
  boolean mHorizontalChainFixedPosition;
  
  int mHorizontalChainStyle;
  
  ConstraintWidget mHorizontalNextWidget;
  
  public int mHorizontalResolution = -1;
  
  boolean mHorizontalWrapVisited;
  
  private boolean mInVirtualLayout = false;
  
  public boolean mIsHeightWrapContent;
  
  private boolean[] mIsInBarrier;
  
  public boolean mIsWidthWrapContent;
  
  private int mLastHorizontalMeasureSpec = 0;
  
  private int mLastVerticalMeasureSpec = 0;
  
  public ConstraintAnchor mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
  
  boolean mLeftHasCentered;
  
  public ConstraintAnchor[] mListAnchors;
  
  public DimensionBehaviour[] mListDimensionBehaviors;
  
  protected ConstraintWidget[] mListNextMatchConstraintsWidget;
  
  public int mMatchConstraintDefaultHeight = 0;
  
  public int mMatchConstraintDefaultWidth = 0;
  
  public int mMatchConstraintMaxHeight = 0;
  
  public int mMatchConstraintMaxWidth = 0;
  
  public int mMatchConstraintMinHeight = 0;
  
  public int mMatchConstraintMinWidth = 0;
  
  public float mMatchConstraintPercentHeight = 1.0F;
  
  public float mMatchConstraintPercentWidth = 1.0F;
  
  private int[] mMaxDimension = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  private boolean mMeasureRequested = true;
  
  protected int mMinHeight;
  
  protected int mMinWidth;
  
  protected ConstraintWidget[] mNextChainWidget;
  
  protected int mOffsetX;
  
  protected int mOffsetY;
  
  public ConstraintWidget mParent;
  
  int mRelX;
  
  int mRelY;
  
  float mResolvedDimensionRatio = 1.0F;
  
  int mResolvedDimensionRatioSide = -1;
  
  boolean mResolvedHasRatio = false;
  
  public int[] mResolvedMatchConstraintDefault = new int[2];
  
  public ConstraintAnchor mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
  
  boolean mRightHasCentered;
  
  public ConstraintAnchor mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
  
  boolean mTopHasCentered;
  
  private String mType;
  
  float mVerticalBiasPercent;
  
  boolean mVerticalChainFixedPosition;
  
  int mVerticalChainStyle;
  
  ConstraintWidget mVerticalNextWidget;
  
  public int mVerticalResolution = -1;
  
  boolean mVerticalWrapVisited;
  
  private int mVisibility;
  
  public float[] mWeight;
  
  int mWidth;
  
  private int mWidthOverride = -1;
  
  private int mWrapBehaviorInParent = 0;
  
  protected int mX;
  
  protected int mY;
  
  public boolean measured = false;
  
  private boolean resolvedHorizontal = false;
  
  private boolean resolvedVertical = false;
  
  public WidgetRun[] run = new WidgetRun[2];
  
  public String stringId;
  
  public ChainRun verticalChainRun;
  
  public int verticalGroup;
  
  public VerticalWidgetRun verticalRun = null;
  
  private boolean verticalSolvingPass = false;
  
  public ConstraintWidget() {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    this.mX = paramInt1;
    this.mY = paramInt2;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    addAnchors();
  }
  
  public ConstraintWidget(String paramString) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2) {
    this(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this(paramInt1, paramInt2, paramInt3, paramInt4);
    setDebugName(paramString);
  }
  
  private void addAnchors() {
    this.mAnchors.add(this.mLeft);
    this.mAnchors.add(this.mTop);
    this.mAnchors.add(this.mRight);
    this.mAnchors.add(this.mBottom);
    this.mAnchors.add(this.mCenterX);
    this.mAnchors.add(this.mCenterY);
    this.mAnchors.add(this.mCenter);
    this.mAnchors.add(this.mBaseline);
  }
  
  private void applyConstraints(LinearSystem paramLinearSystem, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean5, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, boolean paramBoolean10, int paramInt5, int paramInt6, int paramInt7, int paramInt8, float paramFloat2, boolean paramBoolean11) {
    // Byte code:
    //   0: aload_1
    //   1: aload #10
    //   3: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   6: astore #39
    //   8: aload_1
    //   9: aload #11
    //   11: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   14: astore #38
    //   16: aload_1
    //   17: aload #10
    //   19: invokevirtual getTarget : ()Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   22: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   25: astore #41
    //   27: aload_1
    //   28: aload #11
    //   30: invokevirtual getTarget : ()Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   33: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   36: astore #36
    //   38: invokestatic getMetrics : ()Landroidx/constraintlayout/core/Metrics;
    //   41: ifnull -> 61
    //   44: invokestatic getMetrics : ()Landroidx/constraintlayout/core/Metrics;
    //   47: astore #37
    //   49: aload #37
    //   51: aload #37
    //   53: getfield nonresolvedWidgets : J
    //   56: lconst_1
    //   57: ladd
    //   58: putfield nonresolvedWidgets : J
    //   61: aload #10
    //   63: invokevirtual isConnected : ()Z
    //   66: istore #33
    //   68: aload #11
    //   70: invokevirtual isConnected : ()Z
    //   73: istore #34
    //   75: aload_0
    //   76: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   79: invokevirtual isConnected : ()Z
    //   82: istore #35
    //   84: iload #33
    //   86: ifeq -> 95
    //   89: iconst_1
    //   90: istore #29
    //   92: goto -> 98
    //   95: iconst_0
    //   96: istore #29
    //   98: iload #29
    //   100: istore #28
    //   102: iload #34
    //   104: ifeq -> 113
    //   107: iload #29
    //   109: iconst_1
    //   110: iadd
    //   111: istore #28
    //   113: iload #28
    //   115: istore #30
    //   117: iload #35
    //   119: ifeq -> 128
    //   122: iload #28
    //   124: iconst_1
    //   125: iadd
    //   126: istore #30
    //   128: iload #17
    //   130: ifeq -> 139
    //   133: iconst_3
    //   134: istore #22
    //   136: goto -> 139
    //   139: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$1.$SwitchMap$androidx$constraintlayout$core$widgets$ConstraintWidget$DimensionBehaviour : [I
    //   142: aload #8
    //   144: invokevirtual ordinal : ()I
    //   147: iaload
    //   148: istore #28
    //   150: iload #28
    //   152: iconst_1
    //   153: if_icmpeq -> 174
    //   156: iload #28
    //   158: iconst_2
    //   159: if_icmpeq -> 174
    //   162: iload #28
    //   164: iconst_3
    //   165: if_icmpeq -> 174
    //   168: iload #28
    //   170: iconst_4
    //   171: if_icmpeq -> 180
    //   174: iconst_0
    //   175: istore #28
    //   177: goto -> 189
    //   180: iload #22
    //   182: iconst_4
    //   183: if_icmpeq -> 174
    //   186: iconst_1
    //   187: istore #28
    //   189: iload #22
    //   191: istore #31
    //   193: aload_0
    //   194: getfield mWidthOverride : I
    //   197: istore #22
    //   199: iload #22
    //   201: iconst_m1
    //   202: if_icmpeq -> 220
    //   205: iload_2
    //   206: ifeq -> 220
    //   209: aload_0
    //   210: iconst_m1
    //   211: putfield mWidthOverride : I
    //   214: iconst_0
    //   215: istore #28
    //   217: goto -> 224
    //   220: iload #13
    //   222: istore #22
    //   224: aload #36
    //   226: astore #8
    //   228: aload_0
    //   229: getfield mHeightOverride : I
    //   232: istore #32
    //   234: iload #22
    //   236: istore #29
    //   238: iload #28
    //   240: istore #13
    //   242: iload #32
    //   244: iconst_m1
    //   245: if_icmpeq -> 272
    //   248: iload #22
    //   250: istore #29
    //   252: iload #28
    //   254: istore #13
    //   256: iload_2
    //   257: ifne -> 272
    //   260: aload_0
    //   261: iconst_m1
    //   262: putfield mHeightOverride : I
    //   265: iload #32
    //   267: istore #29
    //   269: iconst_0
    //   270: istore #13
    //   272: iload #29
    //   274: istore #22
    //   276: aload_0
    //   277: getfield mVisibility : I
    //   280: bipush #8
    //   282: if_icmpne -> 291
    //   285: iconst_0
    //   286: istore #22
    //   288: iconst_0
    //   289: istore #13
    //   291: iload #27
    //   293: ifeq -> 348
    //   296: iload #33
    //   298: ifne -> 322
    //   301: iload #34
    //   303: ifne -> 322
    //   306: iload #35
    //   308: ifne -> 322
    //   311: aload_1
    //   312: aload #39
    //   314: iload #12
    //   316: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   319: goto -> 348
    //   322: iload #33
    //   324: ifeq -> 348
    //   327: iload #34
    //   329: ifne -> 348
    //   332: aload_1
    //   333: aload #39
    //   335: aload #41
    //   337: aload #10
    //   339: invokevirtual getMargin : ()I
    //   342: bipush #8
    //   344: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   347: pop
    //   348: iload #13
    //   350: ifne -> 436
    //   353: iload #9
    //   355: ifeq -> 408
    //   358: aload_1
    //   359: aload #38
    //   361: aload #39
    //   363: iconst_0
    //   364: iconst_3
    //   365: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   368: pop
    //   369: iload #14
    //   371: ifle -> 386
    //   374: aload_1
    //   375: aload #38
    //   377: aload #39
    //   379: iload #14
    //   381: bipush #8
    //   383: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   386: iload #15
    //   388: ldc 2147483647
    //   390: if_icmpge -> 421
    //   393: aload_1
    //   394: aload #38
    //   396: aload #39
    //   398: iload #15
    //   400: bipush #8
    //   402: invokevirtual addLowerThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   405: goto -> 421
    //   408: aload_1
    //   409: aload #38
    //   411: aload #39
    //   413: iload #22
    //   415: bipush #8
    //   417: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   420: pop
    //   421: iload #25
    //   423: istore #12
    //   425: iload #24
    //   427: istore #25
    //   429: iload #13
    //   431: istore #28
    //   433: goto -> 905
    //   436: iload #30
    //   438: iconst_2
    //   439: if_icmpeq -> 512
    //   442: iload #17
    //   444: ifne -> 512
    //   447: iload #31
    //   449: iconst_1
    //   450: if_icmpeq -> 458
    //   453: iload #31
    //   455: ifne -> 512
    //   458: iload #24
    //   460: iload #22
    //   462: invokestatic max : (II)I
    //   465: istore #13
    //   467: iload #13
    //   469: istore #12
    //   471: iload #25
    //   473: ifle -> 485
    //   476: iload #25
    //   478: iload #13
    //   480: invokestatic min : (II)I
    //   483: istore #12
    //   485: aload_1
    //   486: aload #38
    //   488: aload #39
    //   490: iload #12
    //   492: bipush #8
    //   494: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   497: pop
    //   498: iconst_0
    //   499: istore #28
    //   501: iload #25
    //   503: istore #12
    //   505: iload #24
    //   507: istore #25
    //   509: goto -> 905
    //   512: iload #24
    //   514: istore #12
    //   516: iload #24
    //   518: bipush #-2
    //   520: if_icmpne -> 527
    //   523: iload #22
    //   525: istore #12
    //   527: iload #25
    //   529: bipush #-2
    //   531: if_icmpne -> 541
    //   534: iload #22
    //   536: istore #15
    //   538: goto -> 545
    //   541: iload #25
    //   543: istore #15
    //   545: iload #22
    //   547: istore #24
    //   549: iload #22
    //   551: ifle -> 567
    //   554: iload #22
    //   556: istore #24
    //   558: iload #31
    //   560: iconst_1
    //   561: if_icmpeq -> 567
    //   564: iconst_0
    //   565: istore #24
    //   567: iload #24
    //   569: istore #22
    //   571: iload #12
    //   573: ifle -> 597
    //   576: aload_1
    //   577: aload #38
    //   579: aload #39
    //   581: iload #12
    //   583: bipush #8
    //   585: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   588: iload #24
    //   590: iload #12
    //   592: invokestatic max : (II)I
    //   595: istore #22
    //   597: iload #15
    //   599: ifle -> 653
    //   602: iload_3
    //   603: ifeq -> 618
    //   606: iload #31
    //   608: iconst_1
    //   609: if_icmpne -> 618
    //   612: iconst_0
    //   613: istore #24
    //   615: goto -> 621
    //   618: iconst_1
    //   619: istore #24
    //   621: iload #24
    //   623: ifeq -> 641
    //   626: aload_1
    //   627: aload #38
    //   629: aload #39
    //   631: iload #15
    //   633: bipush #8
    //   635: invokevirtual addLowerThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   638: goto -> 641
    //   641: iload #22
    //   643: iload #15
    //   645: invokestatic min : (II)I
    //   648: istore #22
    //   650: goto -> 653
    //   653: iload #31
    //   655: iconst_1
    //   656: if_icmpne -> 746
    //   659: iload_3
    //   660: ifeq -> 679
    //   663: aload_1
    //   664: aload #38
    //   666: aload #39
    //   668: iload #22
    //   670: bipush #8
    //   672: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   675: pop
    //   676: goto -> 735
    //   679: iload #19
    //   681: ifeq -> 711
    //   684: aload_1
    //   685: aload #38
    //   687: aload #39
    //   689: iload #22
    //   691: iconst_5
    //   692: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   695: pop
    //   696: aload_1
    //   697: aload #38
    //   699: aload #39
    //   701: iload #22
    //   703: bipush #8
    //   705: invokevirtual addLowerThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   708: goto -> 735
    //   711: aload_1
    //   712: aload #38
    //   714: aload #39
    //   716: iload #22
    //   718: iconst_5
    //   719: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   722: pop
    //   723: aload_1
    //   724: aload #38
    //   726: aload #39
    //   728: iload #22
    //   730: bipush #8
    //   732: invokevirtual addLowerThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   735: iload #12
    //   737: istore #24
    //   739: iload #15
    //   741: istore #12
    //   743: goto -> 425
    //   746: iload #31
    //   748: iconst_2
    //   749: if_icmpne -> 890
    //   752: aload #10
    //   754: invokevirtual getType : ()Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   757: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   760: if_acmpeq -> 812
    //   763: aload #10
    //   765: invokevirtual getType : ()Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   768: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   771: if_acmpne -> 777
    //   774: goto -> 812
    //   777: aload_1
    //   778: aload_0
    //   779: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   782: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   785: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   788: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   791: astore #36
    //   793: aload_1
    //   794: aload_0
    //   795: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   798: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   801: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   804: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   807: astore #37
    //   809: goto -> 844
    //   812: aload_1
    //   813: aload_0
    //   814: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   817: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   820: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   823: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   826: astore #36
    //   828: aload_1
    //   829: aload_0
    //   830: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   833: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   836: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   839: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   842: astore #37
    //   844: aload_1
    //   845: aload_1
    //   846: invokevirtual createRow : ()Landroidx/constraintlayout/core/ArrayRow;
    //   849: aload #38
    //   851: aload #39
    //   853: aload #37
    //   855: aload #36
    //   857: fload #26
    //   859: invokevirtual createRowDimensionRatio : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;F)Landroidx/constraintlayout/core/ArrayRow;
    //   862: invokevirtual addConstraint : (Landroidx/constraintlayout/core/ArrayRow;)V
    //   865: iload_3
    //   866: ifeq -> 875
    //   869: iconst_0
    //   870: istore #13
    //   872: goto -> 875
    //   875: iload #12
    //   877: istore #25
    //   879: iload #15
    //   881: istore #12
    //   883: iload #13
    //   885: istore #28
    //   887: goto -> 905
    //   890: iconst_1
    //   891: istore #5
    //   893: iload #13
    //   895: istore #28
    //   897: iload #12
    //   899: istore #25
    //   901: iload #15
    //   903: istore #12
    //   905: iload #31
    //   907: istore #29
    //   909: aload #8
    //   911: astore #40
    //   913: aload #41
    //   915: astore #8
    //   917: iload #27
    //   919: ifeq -> 2417
    //   922: iload #19
    //   924: ifeq -> 930
    //   927: goto -> 2417
    //   930: iload #33
    //   932: ifne -> 948
    //   935: iload #34
    //   937: ifne -> 948
    //   940: iload #35
    //   942: ifne -> 948
    //   945: goto -> 2314
    //   948: iload #33
    //   950: ifeq -> 993
    //   953: iload #34
    //   955: ifne -> 993
    //   958: aload #10
    //   960: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   963: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   966: astore #6
    //   968: iload_3
    //   969: ifeq -> 987
    //   972: aload #6
    //   974: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   977: ifeq -> 987
    //   980: bipush #8
    //   982: istore #12
    //   984: goto -> 990
    //   987: iconst_5
    //   988: istore #12
    //   990: goto -> 2317
    //   993: iload #33
    //   995: ifne -> 1094
    //   998: iload #34
    //   1000: ifeq -> 1094
    //   1003: aload_1
    //   1004: aload #38
    //   1006: aload #40
    //   1008: aload #11
    //   1010: invokevirtual getMargin : ()I
    //   1013: ineg
    //   1014: bipush #8
    //   1016: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1019: pop
    //   1020: iload_3
    //   1021: ifeq -> 2314
    //   1024: aload_0
    //   1025: getfield OPTIMIZE_WRAP : Z
    //   1028: ifeq -> 1081
    //   1031: aload #39
    //   1033: getfield isFinalValue : Z
    //   1036: ifeq -> 1081
    //   1039: aload_0
    //   1040: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1043: astore #8
    //   1045: aload #8
    //   1047: ifnull -> 1081
    //   1050: aload #8
    //   1052: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   1055: astore #6
    //   1057: iload_2
    //   1058: ifeq -> 1071
    //   1061: aload #6
    //   1063: aload #10
    //   1065: invokevirtual addHorizontalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   1068: goto -> 2314
    //   1071: aload #6
    //   1073: aload #10
    //   1075: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   1078: goto -> 2314
    //   1081: aload_1
    //   1082: aload #39
    //   1084: aload #6
    //   1086: iconst_0
    //   1087: iconst_5
    //   1088: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1091: goto -> 2314
    //   1094: iload #33
    //   1096: ifeq -> 2314
    //   1099: iload #34
    //   1101: ifeq -> 2314
    //   1104: aload #10
    //   1106: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1109: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1112: astore #43
    //   1114: aload #11
    //   1116: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1119: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1122: astore #36
    //   1124: aload_0
    //   1125: invokevirtual getParent : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1128: astore #42
    //   1130: bipush #6
    //   1132: istore #31
    //   1134: iload #28
    //   1136: ifeq -> 1607
    //   1139: iload #29
    //   1141: istore #13
    //   1143: iload #13
    //   1145: ifne -> 1292
    //   1148: iload #12
    //   1150: ifne -> 1228
    //   1153: iload #25
    //   1155: ifne -> 1228
    //   1158: aload #8
    //   1160: getfield isFinalValue : Z
    //   1163: ifeq -> 1208
    //   1166: aload #40
    //   1168: getfield isFinalValue : Z
    //   1171: ifeq -> 1208
    //   1174: aload_1
    //   1175: aload #39
    //   1177: aload #8
    //   1179: aload #10
    //   1181: invokevirtual getMargin : ()I
    //   1184: bipush #8
    //   1186: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1189: pop
    //   1190: aload_1
    //   1191: aload #38
    //   1193: aload #40
    //   1195: aload #11
    //   1197: invokevirtual getMargin : ()I
    //   1200: ineg
    //   1201: bipush #8
    //   1203: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1206: pop
    //   1207: return
    //   1208: iconst_0
    //   1209: istore #24
    //   1211: iconst_1
    //   1212: istore #23
    //   1214: iconst_0
    //   1215: istore #13
    //   1217: bipush #8
    //   1219: istore #12
    //   1221: bipush #8
    //   1223: istore #15
    //   1225: goto -> 1243
    //   1228: iconst_1
    //   1229: istore #24
    //   1231: iconst_0
    //   1232: istore #23
    //   1234: iconst_1
    //   1235: istore #13
    //   1237: iconst_5
    //   1238: istore #12
    //   1240: iconst_5
    //   1241: istore #15
    //   1243: aload #43
    //   1245: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   1248: ifne -> 1285
    //   1251: aload #36
    //   1253: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   1256: ifeq -> 1262
    //   1259: goto -> 1285
    //   1262: iload #13
    //   1264: istore #22
    //   1266: iload #15
    //   1268: istore #13
    //   1270: bipush #6
    //   1272: istore #30
    //   1274: iload #22
    //   1276: istore #15
    //   1278: iload #30
    //   1280: istore #22
    //   1282: goto -> 1717
    //   1285: iload #13
    //   1287: istore #15
    //   1289: goto -> 1710
    //   1292: iload #13
    //   1294: iconst_2
    //   1295: if_icmpne -> 1342
    //   1298: aload #43
    //   1300: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   1303: ifne -> 1339
    //   1306: aload #36
    //   1308: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   1311: ifeq -> 1317
    //   1314: goto -> 1339
    //   1317: iconst_0
    //   1318: istore #23
    //   1320: iconst_5
    //   1321: istore #12
    //   1323: bipush #6
    //   1325: istore #22
    //   1327: iconst_1
    //   1328: istore #15
    //   1330: iconst_1
    //   1331: istore #24
    //   1333: iconst_5
    //   1334: istore #13
    //   1336: goto -> 1717
    //   1339: goto -> 1698
    //   1342: iload #13
    //   1344: iconst_1
    //   1345: if_icmpne -> 1364
    //   1348: iconst_1
    //   1349: istore #24
    //   1351: iconst_1
    //   1352: istore #15
    //   1354: iconst_0
    //   1355: istore #23
    //   1357: bipush #8
    //   1359: istore #12
    //   1361: goto -> 1710
    //   1364: iload #13
    //   1366: iconst_3
    //   1367: if_icmpne -> 1598
    //   1370: aload_0
    //   1371: getfield mResolvedDimensionRatioSide : I
    //   1374: iconst_m1
    //   1375: if_icmpne -> 1420
    //   1378: iload #20
    //   1380: ifeq -> 1406
    //   1383: iconst_1
    //   1384: istore #23
    //   1386: bipush #8
    //   1388: istore #12
    //   1390: iload_3
    //   1391: ifeq -> 1400
    //   1394: iconst_5
    //   1395: istore #22
    //   1397: goto -> 1327
    //   1400: iconst_4
    //   1401: istore #22
    //   1403: goto -> 1327
    //   1406: iconst_1
    //   1407: istore #23
    //   1409: bipush #8
    //   1411: istore #12
    //   1413: bipush #8
    //   1415: istore #22
    //   1417: goto -> 1327
    //   1420: iload #17
    //   1422: ifeq -> 1502
    //   1425: iload #23
    //   1427: iconst_2
    //   1428: if_icmpeq -> 1446
    //   1431: iload #23
    //   1433: iconst_1
    //   1434: if_icmpne -> 1440
    //   1437: goto -> 1446
    //   1440: iconst_0
    //   1441: istore #12
    //   1443: goto -> 1449
    //   1446: iconst_1
    //   1447: istore #12
    //   1449: iload #12
    //   1451: ifne -> 1464
    //   1454: bipush #8
    //   1456: istore #13
    //   1458: iconst_5
    //   1459: istore #12
    //   1461: goto -> 1470
    //   1464: iconst_5
    //   1465: istore #13
    //   1467: iconst_4
    //   1468: istore #12
    //   1470: iload #13
    //   1472: istore #22
    //   1474: iload #12
    //   1476: istore #13
    //   1478: iconst_1
    //   1479: istore #24
    //   1481: iconst_1
    //   1482: istore #15
    //   1484: iconst_1
    //   1485: istore #23
    //   1487: bipush #6
    //   1489: istore #30
    //   1491: iload #22
    //   1493: istore #12
    //   1495: iload #30
    //   1497: istore #22
    //   1499: goto -> 1717
    //   1502: iload #12
    //   1504: ifle -> 1513
    //   1507: iconst_1
    //   1508: istore #23
    //   1510: goto -> 1320
    //   1513: iload #12
    //   1515: ifne -> 1586
    //   1518: iload #25
    //   1520: ifne -> 1586
    //   1523: iload #20
    //   1525: ifne -> 1551
    //   1528: iconst_1
    //   1529: istore #24
    //   1531: iconst_1
    //   1532: istore #15
    //   1534: iconst_1
    //   1535: istore #23
    //   1537: iconst_5
    //   1538: istore #12
    //   1540: bipush #6
    //   1542: istore #22
    //   1544: bipush #8
    //   1546: istore #13
    //   1548: goto -> 1717
    //   1551: aload #43
    //   1553: aload #42
    //   1555: if_acmpeq -> 1571
    //   1558: aload #36
    //   1560: aload #42
    //   1562: if_acmpeq -> 1571
    //   1565: iconst_4
    //   1566: istore #12
    //   1568: goto -> 1574
    //   1571: iconst_5
    //   1572: istore #12
    //   1574: iconst_1
    //   1575: istore #24
    //   1577: iconst_1
    //   1578: istore #15
    //   1580: iconst_1
    //   1581: istore #23
    //   1583: goto -> 1710
    //   1586: iconst_1
    //   1587: istore #24
    //   1589: iconst_1
    //   1590: istore #15
    //   1592: iconst_1
    //   1593: istore #23
    //   1595: goto -> 1707
    //   1598: iconst_0
    //   1599: istore #24
    //   1601: iconst_0
    //   1602: istore #15
    //   1604: goto -> 1704
    //   1607: aload #8
    //   1609: getfield isFinalValue : Z
    //   1612: ifeq -> 1698
    //   1615: aload #40
    //   1617: getfield isFinalValue : Z
    //   1620: ifeq -> 1698
    //   1623: aload_1
    //   1624: aload #39
    //   1626: aload #8
    //   1628: aload #10
    //   1630: invokevirtual getMargin : ()I
    //   1633: fload #16
    //   1635: aload #40
    //   1637: aload #38
    //   1639: aload #11
    //   1641: invokevirtual getMargin : ()I
    //   1644: bipush #8
    //   1646: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1649: iload_3
    //   1650: ifeq -> 1697
    //   1653: iload #5
    //   1655: ifeq -> 1697
    //   1658: aload #11
    //   1660: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1663: ifnull -> 1676
    //   1666: aload #11
    //   1668: invokevirtual getMargin : ()I
    //   1671: istore #12
    //   1673: goto -> 1679
    //   1676: iconst_0
    //   1677: istore #12
    //   1679: aload #40
    //   1681: aload #7
    //   1683: if_acmpeq -> 1697
    //   1686: aload_1
    //   1687: aload #7
    //   1689: aload #38
    //   1691: iload #12
    //   1693: iconst_5
    //   1694: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1697: return
    //   1698: iconst_1
    //   1699: istore #24
    //   1701: iconst_1
    //   1702: istore #15
    //   1704: iconst_0
    //   1705: istore #23
    //   1707: iconst_5
    //   1708: istore #12
    //   1710: bipush #6
    //   1712: istore #22
    //   1714: iconst_4
    //   1715: istore #13
    //   1717: iload #29
    //   1719: istore #32
    //   1721: iload #15
    //   1723: ifeq -> 1749
    //   1726: aload #8
    //   1728: aload #40
    //   1730: if_acmpne -> 1749
    //   1733: aload #43
    //   1735: aload #42
    //   1737: if_acmpeq -> 1749
    //   1740: iconst_0
    //   1741: istore #30
    //   1743: iconst_0
    //   1744: istore #29
    //   1746: goto -> 1756
    //   1749: iconst_1
    //   1750: istore #29
    //   1752: iload #15
    //   1754: istore #30
    //   1756: iload #24
    //   1758: ifeq -> 1839
    //   1761: iload #28
    //   1763: ifne -> 1806
    //   1766: iload #18
    //   1768: ifne -> 1806
    //   1771: iload #20
    //   1773: ifne -> 1806
    //   1776: aload #8
    //   1778: aload #6
    //   1780: if_acmpne -> 1806
    //   1783: aload #40
    //   1785: aload #7
    //   1787: if_acmpne -> 1806
    //   1790: iconst_0
    //   1791: istore_3
    //   1792: bipush #8
    //   1794: istore #22
    //   1796: iconst_0
    //   1797: istore #29
    //   1799: bipush #8
    //   1801: istore #12
    //   1803: goto -> 1806
    //   1806: aload_1
    //   1807: aload #39
    //   1809: aload #8
    //   1811: aload #10
    //   1813: invokevirtual getMargin : ()I
    //   1816: fload #16
    //   1818: aload #40
    //   1820: aload #38
    //   1822: aload #11
    //   1824: invokevirtual getMargin : ()I
    //   1827: iload #22
    //   1829: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1832: iload #29
    //   1834: istore #15
    //   1836: goto -> 1843
    //   1839: iload #29
    //   1841: istore #15
    //   1843: aload #8
    //   1845: astore #41
    //   1847: aload #39
    //   1849: astore #37
    //   1851: aload #42
    //   1853: astore #8
    //   1855: aload_0
    //   1856: getfield mVisibility : I
    //   1859: bipush #8
    //   1861: if_icmpne -> 1873
    //   1864: aload #11
    //   1866: invokevirtual hasDependents : ()Z
    //   1869: ifne -> 1873
    //   1872: return
    //   1873: iload #30
    //   1875: ifeq -> 1954
    //   1878: iload_3
    //   1879: ifeq -> 1920
    //   1882: aload #41
    //   1884: aload #40
    //   1886: if_acmpeq -> 1920
    //   1889: iload #28
    //   1891: ifne -> 1920
    //   1894: aload #43
    //   1896: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   1899: ifne -> 1913
    //   1902: aload #36
    //   1904: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   1907: ifeq -> 1920
    //   1910: goto -> 1913
    //   1913: bipush #6
    //   1915: istore #12
    //   1917: goto -> 1920
    //   1920: aload_1
    //   1921: aload #37
    //   1923: aload #41
    //   1925: aload #10
    //   1927: invokevirtual getMargin : ()I
    //   1930: iload #12
    //   1932: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1935: aload_1
    //   1936: aload #38
    //   1938: aload #40
    //   1940: aload #11
    //   1942: invokevirtual getMargin : ()I
    //   1945: ineg
    //   1946: iload #12
    //   1948: invokevirtual addLowerThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1951: goto -> 1954
    //   1954: iload_3
    //   1955: ifeq -> 2000
    //   1958: iload #21
    //   1960: ifeq -> 2000
    //   1963: aload #43
    //   1965: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   1968: ifne -> 2000
    //   1971: aload #36
    //   1973: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   1976: ifne -> 2000
    //   1979: aload #36
    //   1981: aload #8
    //   1983: if_acmpeq -> 2000
    //   1986: bipush #6
    //   1988: istore #12
    //   1990: iconst_1
    //   1991: istore #15
    //   1993: bipush #6
    //   1995: istore #22
    //   1997: goto -> 2008
    //   2000: iload #12
    //   2002: istore #22
    //   2004: iload #13
    //   2006: istore #12
    //   2008: iload #15
    //   2010: ifeq -> 2212
    //   2013: iload #12
    //   2015: istore #13
    //   2017: iload #23
    //   2019: ifeq -> 2123
    //   2022: iload #20
    //   2024: ifeq -> 2036
    //   2027: iload #12
    //   2029: istore #13
    //   2031: iload #4
    //   2033: ifeq -> 2123
    //   2036: iload #31
    //   2038: istore #13
    //   2040: aload #43
    //   2042: aload #8
    //   2044: if_acmpeq -> 2065
    //   2047: aload #36
    //   2049: aload #8
    //   2051: if_acmpne -> 2061
    //   2054: iload #31
    //   2056: istore #13
    //   2058: goto -> 2065
    //   2061: iload #12
    //   2063: istore #13
    //   2065: aload #43
    //   2067: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   2070: ifne -> 2081
    //   2073: aload #36
    //   2075: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   2078: ifeq -> 2084
    //   2081: iconst_5
    //   2082: istore #13
    //   2084: aload #43
    //   2086: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   2089: ifne -> 2100
    //   2092: aload #36
    //   2094: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   2097: ifeq -> 2103
    //   2100: iconst_5
    //   2101: istore #13
    //   2103: iload #20
    //   2105: ifeq -> 2114
    //   2108: iconst_5
    //   2109: istore #13
    //   2111: goto -> 2114
    //   2114: iload #13
    //   2116: iload #12
    //   2118: invokestatic max : (II)I
    //   2121: istore #13
    //   2123: iload #13
    //   2125: istore #12
    //   2127: iload_3
    //   2128: ifeq -> 2179
    //   2131: iload #22
    //   2133: iload #13
    //   2135: invokestatic min : (II)I
    //   2138: istore #13
    //   2140: iload #13
    //   2142: istore #12
    //   2144: iload #17
    //   2146: ifeq -> 2179
    //   2149: iload #13
    //   2151: istore #12
    //   2153: iload #20
    //   2155: ifne -> 2179
    //   2158: aload #43
    //   2160: aload #8
    //   2162: if_acmpeq -> 2176
    //   2165: iload #13
    //   2167: istore #12
    //   2169: aload #36
    //   2171: aload #8
    //   2173: if_acmpne -> 2179
    //   2176: iconst_4
    //   2177: istore #12
    //   2179: aload_1
    //   2180: aload #37
    //   2182: aload #41
    //   2184: aload #10
    //   2186: invokevirtual getMargin : ()I
    //   2189: iload #12
    //   2191: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2194: pop
    //   2195: aload_1
    //   2196: aload #38
    //   2198: aload #40
    //   2200: aload #11
    //   2202: invokevirtual getMargin : ()I
    //   2205: ineg
    //   2206: iload #12
    //   2208: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2211: pop
    //   2212: iload_3
    //   2213: ifeq -> 2254
    //   2216: aload #6
    //   2218: aload #41
    //   2220: if_acmpne -> 2233
    //   2223: aload #10
    //   2225: invokevirtual getMargin : ()I
    //   2228: istore #12
    //   2230: goto -> 2236
    //   2233: iconst_0
    //   2234: istore #12
    //   2236: aload #41
    //   2238: aload #6
    //   2240: if_acmpeq -> 2254
    //   2243: aload_1
    //   2244: aload #37
    //   2246: aload #6
    //   2248: iload #12
    //   2250: iconst_5
    //   2251: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2254: iload_3
    //   2255: ifeq -> 2311
    //   2258: iload #28
    //   2260: ifeq -> 2311
    //   2263: iload #14
    //   2265: ifne -> 2311
    //   2268: iload #25
    //   2270: ifne -> 2311
    //   2273: iload #28
    //   2275: ifeq -> 2298
    //   2278: iload #32
    //   2280: iconst_3
    //   2281: if_icmpne -> 2298
    //   2284: aload_1
    //   2285: aload #38
    //   2287: aload #37
    //   2289: iconst_0
    //   2290: bipush #8
    //   2292: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2295: goto -> 2311
    //   2298: aload_1
    //   2299: aload #38
    //   2301: aload #37
    //   2303: iconst_0
    //   2304: iconst_5
    //   2305: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2308: goto -> 2314
    //   2311: goto -> 2314
    //   2314: iconst_5
    //   2315: istore #12
    //   2317: iload_3
    //   2318: ifeq -> 2416
    //   2321: iload #5
    //   2323: ifeq -> 2416
    //   2326: aload #11
    //   2328: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2331: ifnull -> 2344
    //   2334: aload #11
    //   2336: invokevirtual getMargin : ()I
    //   2339: istore #13
    //   2341: goto -> 2347
    //   2344: iconst_0
    //   2345: istore #13
    //   2347: aload #40
    //   2349: aload #7
    //   2351: if_acmpeq -> 2416
    //   2354: aload_0
    //   2355: getfield OPTIMIZE_WRAP : Z
    //   2358: ifeq -> 2404
    //   2361: aload #38
    //   2363: getfield isFinalValue : Z
    //   2366: ifeq -> 2404
    //   2369: aload_0
    //   2370: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2373: astore #6
    //   2375: aload #6
    //   2377: ifnull -> 2404
    //   2380: aload #6
    //   2382: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   2385: astore_1
    //   2386: iload_2
    //   2387: ifeq -> 2397
    //   2390: aload_1
    //   2391: aload #11
    //   2393: invokevirtual addHorizontalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   2396: return
    //   2397: aload_1
    //   2398: aload #11
    //   2400: invokevirtual addVerticalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   2403: return
    //   2404: aload_1
    //   2405: aload #7
    //   2407: aload #38
    //   2409: iload #13
    //   2411: iload #12
    //   2413: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2416: return
    //   2417: iconst_1
    //   2418: istore #13
    //   2420: iload #30
    //   2422: iconst_2
    //   2423: if_icmpge -> 2563
    //   2426: iload_3
    //   2427: ifeq -> 2563
    //   2430: iload #5
    //   2432: ifeq -> 2563
    //   2435: aload_1
    //   2436: aload #39
    //   2438: aload #6
    //   2440: iconst_0
    //   2441: bipush #8
    //   2443: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2446: iload_2
    //   2447: ifne -> 2469
    //   2450: aload_0
    //   2451: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2454: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2457: ifnonnull -> 2463
    //   2460: goto -> 2469
    //   2463: iconst_0
    //   2464: istore #12
    //   2466: goto -> 2472
    //   2469: iconst_1
    //   2470: istore #12
    //   2472: iload_2
    //   2473: ifne -> 2547
    //   2476: aload_0
    //   2477: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2480: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2483: ifnull -> 2547
    //   2486: aload_0
    //   2487: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2490: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2493: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2496: astore #6
    //   2498: aload #6
    //   2500: getfield mDimensionRatio : F
    //   2503: fconst_0
    //   2504: fcmpl
    //   2505: ifeq -> 2541
    //   2508: aload #6
    //   2510: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2513: iconst_0
    //   2514: aaload
    //   2515: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2518: if_acmpne -> 2541
    //   2521: aload #6
    //   2523: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2526: iconst_1
    //   2527: aaload
    //   2528: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2531: if_acmpne -> 2541
    //   2534: iload #13
    //   2536: istore #12
    //   2538: goto -> 2547
    //   2541: iconst_0
    //   2542: istore #12
    //   2544: goto -> 2547
    //   2547: iload #12
    //   2549: ifeq -> 2563
    //   2552: aload_1
    //   2553: aload #7
    //   2555: aload #38
    //   2557: iconst_0
    //   2558: bipush #8
    //   2560: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2563: return
  }
  
  private boolean isChainHead(int paramInt) {
    paramInt *= 2;
    if ((this.mListAnchors[paramInt]).mTarget != null) {
      ConstraintAnchor constraintAnchor = (this.mListAnchors[paramInt]).mTarget.mTarget;
      ConstraintAnchor[] arrayOfConstraintAnchor = this.mListAnchors;
      if (constraintAnchor != arrayOfConstraintAnchor[paramInt])
        if ((arrayOfConstraintAnchor[++paramInt]).mTarget != null && (this.mListAnchors[paramInt]).mTarget.mTarget == this.mListAnchors[paramInt])
          return true;  
    } 
    return false;
  }
  
  private void serializeAnchor(StringBuilder paramStringBuilder, String paramString, ConstraintAnchor paramConstraintAnchor) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("',");
    paramStringBuilder.append(paramConstraintAnchor.mMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramConstraintAnchor.mGoneMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(" ] ,\n");
  }
  
  private void serializeAttribute(StringBuilder paramStringBuilder, String paramString, float paramFloat1, float paramFloat2) {
    if (paramFloat1 == paramFloat2)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :   ");
    paramStringBuilder.append(paramFloat2);
    paramStringBuilder.append(",\n");
  }
  
  private void serializeCircle(StringBuilder paramStringBuilder, ConstraintAnchor paramConstraintAnchor, float paramFloat) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append("circle : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("',");
    paramStringBuilder.append(paramConstraintAnchor.mMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramFloat);
    paramStringBuilder.append(",");
    paramStringBuilder.append(" ] ,\n");
  }
  
  private void serializeDimensionRatio(StringBuilder paramStringBuilder, String paramString, float paramFloat, int paramInt) {
    if (paramFloat == 0.0F)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  [");
    paramStringBuilder.append(paramFloat);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramInt);
    paramStringBuilder.append("");
    paramStringBuilder.append("],\n");
  }
  
  private void serializeSize(StringBuilder paramStringBuilder, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  {\n");
    serializeAttribute(paramStringBuilder, "size", paramInt1, -2.1474836E9F);
    serializeAttribute(paramStringBuilder, "min", paramInt2, 0.0F);
    serializeAttribute(paramStringBuilder, "max", paramInt3, 2.1474836E9F);
    serializeAttribute(paramStringBuilder, "matchMin", paramInt5, 0.0F);
    paramFloat1 = paramInt6;
    serializeAttribute(paramStringBuilder, "matchDef", paramFloat1, 0.0F);
    serializeAttribute(paramStringBuilder, "matchPercent", paramFloat1, 1.0F);
    paramStringBuilder.append("},\n");
  }
  
  public void addChildrenToSolverByDependency(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, HashSet<ConstraintWidget> paramHashSet, int paramInt, boolean paramBoolean) {
    if (paramBoolean) {
      if (!paramHashSet.contains(this))
        return; 
      Optimizer.checkMatchParent(paramConstraintWidgetContainer, paramLinearSystem, this);
      paramHashSet.remove(this);
      addToSolver(paramLinearSystem, paramConstraintWidgetContainer.optimizeFor(64));
    } 
    if (paramInt == 0) {
      HashSet<ConstraintAnchor> hashSet = this.mLeft.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mRight.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
    } else {
      HashSet<ConstraintAnchor> hashSet = this.mTop.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBottom.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBaseline.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (true) {
          if (iterator.hasNext()) {
            ConstraintWidget constraintWidget = ((ConstraintAnchor)iterator.next()).mOwner;
            try {
              constraintWidget.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true);
            } finally {}
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  boolean addFirst() {
    return (this instanceof VirtualLayout || this instanceof Guideline);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   5: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   8: astore #28
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   15: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   18: astore #27
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   25: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   28: astore #30
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   35: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   38: astore #29
    //   40: aload_1
    //   41: aload_0
    //   42: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   45: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   48: astore #26
    //   50: aload_0
    //   51: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   54: astore #24
    //   56: aload #24
    //   58: ifnull -> 173
    //   61: aload #24
    //   63: ifnull -> 85
    //   66: aload #24
    //   68: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   71: iconst_0
    //   72: aaload
    //   73: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   76: if_acmpne -> 85
    //   79: iconst_1
    //   80: istore #11
    //   82: goto -> 88
    //   85: iconst_0
    //   86: istore #11
    //   88: aload_0
    //   89: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   92: astore #24
    //   94: aload #24
    //   96: ifnull -> 118
    //   99: aload #24
    //   101: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   104: iconst_1
    //   105: aaload
    //   106: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   109: if_acmpne -> 118
    //   112: iconst_1
    //   113: istore #12
    //   115: goto -> 121
    //   118: iconst_0
    //   119: istore #12
    //   121: aload_0
    //   122: getfield mWrapBehaviorInParent : I
    //   125: istore #4
    //   127: iload #4
    //   129: iconst_1
    //   130: if_icmpeq -> 166
    //   133: iload #4
    //   135: iconst_2
    //   136: if_icmpeq -> 156
    //   139: iload #4
    //   141: iconst_3
    //   142: if_icmpeq -> 173
    //   145: iload #11
    //   147: istore #13
    //   149: iload #12
    //   151: istore #11
    //   153: goto -> 179
    //   156: iload #12
    //   158: istore #11
    //   160: iconst_0
    //   161: istore #13
    //   163: goto -> 179
    //   166: iload #11
    //   168: istore #13
    //   170: goto -> 176
    //   173: iconst_0
    //   174: istore #13
    //   176: iconst_0
    //   177: istore #11
    //   179: aload_0
    //   180: getfield mVisibility : I
    //   183: bipush #8
    //   185: if_icmpne -> 216
    //   188: aload_0
    //   189: invokevirtual hasDependencies : ()Z
    //   192: ifne -> 216
    //   195: aload_0
    //   196: getfield mIsInBarrier : [Z
    //   199: astore #24
    //   201: aload #24
    //   203: iconst_0
    //   204: baload
    //   205: ifne -> 216
    //   208: aload #24
    //   210: iconst_1
    //   211: baload
    //   212: ifne -> 216
    //   215: return
    //   216: aload_0
    //   217: getfield resolvedHorizontal : Z
    //   220: ifne -> 230
    //   223: aload_0
    //   224: getfield resolvedVertical : Z
    //   227: ifeq -> 480
    //   230: aload_0
    //   231: getfield resolvedHorizontal : Z
    //   234: ifeq -> 330
    //   237: aload_1
    //   238: aload #28
    //   240: aload_0
    //   241: getfield mX : I
    //   244: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   247: aload_1
    //   248: aload #27
    //   250: aload_0
    //   251: getfield mX : I
    //   254: aload_0
    //   255: getfield mWidth : I
    //   258: iadd
    //   259: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   262: iload #13
    //   264: ifeq -> 330
    //   267: aload_0
    //   268: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   271: astore #24
    //   273: aload #24
    //   275: ifnull -> 330
    //   278: aload_0
    //   279: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   282: ifeq -> 313
    //   285: aload #24
    //   287: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   290: astore #24
    //   292: aload #24
    //   294: aload_0
    //   295: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   298: invokevirtual addHorizontalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   301: aload #24
    //   303: aload_0
    //   304: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   307: invokevirtual addHorizontalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   310: goto -> 330
    //   313: aload_1
    //   314: aload_1
    //   315: aload #24
    //   317: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   320: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   323: aload #27
    //   325: iconst_0
    //   326: iconst_5
    //   327: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   330: aload_0
    //   331: getfield resolvedVertical : Z
    //   334: ifeq -> 455
    //   337: aload_1
    //   338: aload #30
    //   340: aload_0
    //   341: getfield mY : I
    //   344: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   347: aload_1
    //   348: aload #29
    //   350: aload_0
    //   351: getfield mY : I
    //   354: aload_0
    //   355: getfield mHeight : I
    //   358: iadd
    //   359: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   362: aload_0
    //   363: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   366: invokevirtual hasDependents : ()Z
    //   369: ifeq -> 387
    //   372: aload_1
    //   373: aload #26
    //   375: aload_0
    //   376: getfield mY : I
    //   379: aload_0
    //   380: getfield mBaselineDistance : I
    //   383: iadd
    //   384: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   387: iload #11
    //   389: ifeq -> 455
    //   392: aload_0
    //   393: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   396: astore #24
    //   398: aload #24
    //   400: ifnull -> 455
    //   403: aload_0
    //   404: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   407: ifeq -> 438
    //   410: aload #24
    //   412: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   415: astore #24
    //   417: aload #24
    //   419: aload_0
    //   420: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   423: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   426: aload #24
    //   428: aload_0
    //   429: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   432: invokevirtual addVerticalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   435: goto -> 455
    //   438: aload_1
    //   439: aload_1
    //   440: aload #24
    //   442: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   445: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   448: aload #29
    //   450: iconst_0
    //   451: iconst_5
    //   452: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   455: aload_0
    //   456: getfield resolvedHorizontal : Z
    //   459: ifeq -> 480
    //   462: aload_0
    //   463: getfield resolvedVertical : Z
    //   466: ifeq -> 480
    //   469: aload_0
    //   470: iconst_0
    //   471: putfield resolvedHorizontal : Z
    //   474: aload_0
    //   475: iconst_0
    //   476: putfield resolvedVertical : Z
    //   479: return
    //   480: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   483: ifnull -> 503
    //   486: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   489: astore #24
    //   491: aload #24
    //   493: aload #24
    //   495: getfield widgets : J
    //   498: lconst_1
    //   499: ladd
    //   500: putfield widgets : J
    //   503: iload_2
    //   504: ifeq -> 778
    //   507: aload_0
    //   508: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   511: astore #24
    //   513: aload #24
    //   515: ifnull -> 778
    //   518: aload_0
    //   519: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   522: ifnull -> 778
    //   525: aload #24
    //   527: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   530: getfield resolved : Z
    //   533: ifeq -> 778
    //   536: aload_0
    //   537: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   540: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   543: getfield resolved : Z
    //   546: ifeq -> 778
    //   549: aload_0
    //   550: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   553: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   556: getfield resolved : Z
    //   559: ifeq -> 778
    //   562: aload_0
    //   563: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   566: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   569: getfield resolved : Z
    //   572: ifeq -> 778
    //   575: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   578: ifnull -> 598
    //   581: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   584: astore #24
    //   586: aload #24
    //   588: aload #24
    //   590: getfield graphSolved : J
    //   593: lconst_1
    //   594: ladd
    //   595: putfield graphSolved : J
    //   598: aload_1
    //   599: aload #28
    //   601: aload_0
    //   602: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   605: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   608: getfield value : I
    //   611: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   614: aload_1
    //   615: aload #27
    //   617: aload_0
    //   618: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   621: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   624: getfield value : I
    //   627: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   630: aload_1
    //   631: aload #30
    //   633: aload_0
    //   634: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   637: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   640: getfield value : I
    //   643: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   646: aload_1
    //   647: aload #29
    //   649: aload_0
    //   650: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   653: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   656: getfield value : I
    //   659: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   662: aload_1
    //   663: aload #26
    //   665: aload_0
    //   666: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   669: getfield baseline : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   672: getfield value : I
    //   675: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   678: aload_0
    //   679: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   682: ifnull -> 767
    //   685: iload #13
    //   687: ifeq -> 726
    //   690: aload_0
    //   691: getfield isTerminalWidget : [Z
    //   694: iconst_0
    //   695: baload
    //   696: ifeq -> 726
    //   699: aload_0
    //   700: invokevirtual isInHorizontalChain : ()Z
    //   703: ifne -> 726
    //   706: aload_1
    //   707: aload_1
    //   708: aload_0
    //   709: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   712: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   715: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   718: aload #27
    //   720: iconst_0
    //   721: bipush #8
    //   723: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   726: iload #11
    //   728: ifeq -> 767
    //   731: aload_0
    //   732: getfield isTerminalWidget : [Z
    //   735: iconst_1
    //   736: baload
    //   737: ifeq -> 767
    //   740: aload_0
    //   741: invokevirtual isInVerticalChain : ()Z
    //   744: ifne -> 767
    //   747: aload_1
    //   748: aload_1
    //   749: aload_0
    //   750: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   753: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   756: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   759: aload #29
    //   761: iconst_0
    //   762: bipush #8
    //   764: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   767: aload_0
    //   768: iconst_0
    //   769: putfield resolvedHorizontal : Z
    //   772: aload_0
    //   773: iconst_0
    //   774: putfield resolvedVertical : Z
    //   777: return
    //   778: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   781: ifnull -> 801
    //   784: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   787: astore #24
    //   789: aload #24
    //   791: aload #24
    //   793: getfield linearSolved : J
    //   796: lconst_1
    //   797: ladd
    //   798: putfield linearSolved : J
    //   801: aload_0
    //   802: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   805: ifnull -> 1002
    //   808: aload_0
    //   809: iconst_0
    //   810: invokespecial isChainHead : (I)Z
    //   813: ifeq -> 834
    //   816: aload_0
    //   817: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   820: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   823: aload_0
    //   824: iconst_0
    //   825: invokevirtual addChain : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)V
    //   828: iconst_1
    //   829: istore #12
    //   831: goto -> 840
    //   834: aload_0
    //   835: invokevirtual isInHorizontalChain : ()Z
    //   838: istore #12
    //   840: aload_0
    //   841: iconst_1
    //   842: invokespecial isChainHead : (I)Z
    //   845: ifeq -> 866
    //   848: aload_0
    //   849: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   852: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   855: aload_0
    //   856: iconst_1
    //   857: invokevirtual addChain : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)V
    //   860: iconst_1
    //   861: istore #14
    //   863: goto -> 872
    //   866: aload_0
    //   867: invokevirtual isInVerticalChain : ()Z
    //   870: istore #14
    //   872: iload #12
    //   874: ifne -> 930
    //   877: iload #13
    //   879: ifeq -> 930
    //   882: aload_0
    //   883: getfield mVisibility : I
    //   886: bipush #8
    //   888: if_icmpeq -> 930
    //   891: aload_0
    //   892: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   895: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   898: ifnonnull -> 930
    //   901: aload_0
    //   902: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   905: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   908: ifnonnull -> 930
    //   911: aload_1
    //   912: aload_1
    //   913: aload_0
    //   914: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   917: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   920: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   923: aload #27
    //   925: iconst_0
    //   926: iconst_1
    //   927: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   930: iload #14
    //   932: ifne -> 995
    //   935: iload #11
    //   937: ifeq -> 995
    //   940: aload_0
    //   941: getfield mVisibility : I
    //   944: bipush #8
    //   946: if_icmpeq -> 995
    //   949: aload_0
    //   950: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   953: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   956: ifnonnull -> 995
    //   959: aload_0
    //   960: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   963: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   966: ifnonnull -> 995
    //   969: aload_0
    //   970: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   973: ifnonnull -> 995
    //   976: aload_1
    //   977: aload_1
    //   978: aload_0
    //   979: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   982: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   985: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   988: aload #29
    //   990: iconst_0
    //   991: iconst_1
    //   992: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   995: iload #12
    //   997: istore #15
    //   999: goto -> 1008
    //   1002: iconst_0
    //   1003: istore #14
    //   1005: iconst_0
    //   1006: istore #15
    //   1008: aload_0
    //   1009: getfield mWidth : I
    //   1012: istore #5
    //   1014: aload_0
    //   1015: getfield mMinWidth : I
    //   1018: istore #6
    //   1020: iload #5
    //   1022: istore #4
    //   1024: iload #5
    //   1026: iload #6
    //   1028: if_icmpge -> 1035
    //   1031: iload #6
    //   1033: istore #4
    //   1035: aload_0
    //   1036: getfield mHeight : I
    //   1039: istore #6
    //   1041: aload_0
    //   1042: getfield mMinHeight : I
    //   1045: istore #7
    //   1047: iload #6
    //   1049: istore #5
    //   1051: iload #6
    //   1053: iload #7
    //   1055: if_icmpge -> 1062
    //   1058: iload #7
    //   1060: istore #5
    //   1062: aload_0
    //   1063: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1066: iconst_0
    //   1067: aaload
    //   1068: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1071: if_acmpeq -> 1080
    //   1074: iconst_1
    //   1075: istore #12
    //   1077: goto -> 1083
    //   1080: iconst_0
    //   1081: istore #12
    //   1083: aload_0
    //   1084: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1087: iconst_1
    //   1088: aaload
    //   1089: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1092: if_acmpeq -> 1101
    //   1095: iconst_1
    //   1096: istore #16
    //   1098: goto -> 1104
    //   1101: iconst_0
    //   1102: istore #16
    //   1104: aload_0
    //   1105: aload_0
    //   1106: getfield mDimensionRatioSide : I
    //   1109: putfield mResolvedDimensionRatioSide : I
    //   1112: aload_0
    //   1113: getfield mDimensionRatio : F
    //   1116: fstore_3
    //   1117: aload_0
    //   1118: fload_3
    //   1119: putfield mResolvedDimensionRatio : F
    //   1122: aload_0
    //   1123: getfield mMatchConstraintDefaultWidth : I
    //   1126: istore #7
    //   1128: aload_0
    //   1129: getfield mMatchConstraintDefaultHeight : I
    //   1132: istore #8
    //   1134: fload_3
    //   1135: fconst_0
    //   1136: fcmpl
    //   1137: ifle -> 1477
    //   1140: aload_0
    //   1141: getfield mVisibility : I
    //   1144: bipush #8
    //   1146: if_icmpeq -> 1477
    //   1149: iload #7
    //   1151: istore #6
    //   1153: aload_0
    //   1154: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1157: iconst_0
    //   1158: aaload
    //   1159: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1162: if_acmpne -> 1177
    //   1165: iload #7
    //   1167: istore #6
    //   1169: iload #7
    //   1171: ifne -> 1177
    //   1174: iconst_3
    //   1175: istore #6
    //   1177: iload #8
    //   1179: istore #7
    //   1181: aload_0
    //   1182: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1185: iconst_1
    //   1186: aaload
    //   1187: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1190: if_acmpne -> 1205
    //   1193: iload #8
    //   1195: istore #7
    //   1197: iload #8
    //   1199: ifne -> 1205
    //   1202: iconst_3
    //   1203: istore #7
    //   1205: aload_0
    //   1206: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1209: iconst_0
    //   1210: aaload
    //   1211: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1214: if_acmpne -> 1260
    //   1217: aload_0
    //   1218: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1221: iconst_1
    //   1222: aaload
    //   1223: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1226: if_acmpne -> 1260
    //   1229: iload #6
    //   1231: iconst_3
    //   1232: if_icmpne -> 1260
    //   1235: iload #7
    //   1237: iconst_3
    //   1238: if_icmpne -> 1260
    //   1241: aload_0
    //   1242: iload #13
    //   1244: iload #11
    //   1246: iload #12
    //   1248: iload #16
    //   1250: invokevirtual setupDimensionRatio : (ZZZZ)V
    //   1253: iload #5
    //   1255: istore #8
    //   1257: goto -> 1451
    //   1260: aload_0
    //   1261: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1264: iconst_0
    //   1265: aaload
    //   1266: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1269: if_acmpne -> 1348
    //   1272: iload #6
    //   1274: iconst_3
    //   1275: if_icmpne -> 1348
    //   1278: aload_0
    //   1279: iconst_0
    //   1280: putfield mResolvedDimensionRatioSide : I
    //   1283: aload_0
    //   1284: getfield mResolvedDimensionRatio : F
    //   1287: aload_0
    //   1288: getfield mHeight : I
    //   1291: i2f
    //   1292: fmul
    //   1293: f2i
    //   1294: istore #9
    //   1296: aload_0
    //   1297: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1300: iconst_1
    //   1301: aaload
    //   1302: astore #24
    //   1304: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1307: astore #25
    //   1309: iload #5
    //   1311: istore #4
    //   1313: iload #7
    //   1315: istore #8
    //   1317: aload #24
    //   1319: aload #25
    //   1321: if_acmpeq -> 1341
    //   1324: iconst_0
    //   1325: istore #12
    //   1327: iconst_4
    //   1328: istore #7
    //   1330: iload #9
    //   1332: istore #5
    //   1334: iload #8
    //   1336: istore #6
    //   1338: goto -> 1496
    //   1341: iload #9
    //   1343: istore #5
    //   1345: goto -> 1459
    //   1348: iload #5
    //   1350: istore #8
    //   1352: aload_0
    //   1353: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1356: iconst_1
    //   1357: aaload
    //   1358: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1361: if_acmpne -> 1451
    //   1364: iload #5
    //   1366: istore #8
    //   1368: iload #7
    //   1370: iconst_3
    //   1371: if_icmpne -> 1451
    //   1374: aload_0
    //   1375: iconst_1
    //   1376: putfield mResolvedDimensionRatioSide : I
    //   1379: aload_0
    //   1380: getfield mDimensionRatioSide : I
    //   1383: iconst_m1
    //   1384: if_icmpne -> 1397
    //   1387: aload_0
    //   1388: fconst_1
    //   1389: aload_0
    //   1390: getfield mResolvedDimensionRatio : F
    //   1393: fdiv
    //   1394: putfield mResolvedDimensionRatio : F
    //   1397: aload_0
    //   1398: getfield mResolvedDimensionRatio : F
    //   1401: aload_0
    //   1402: getfield mWidth : I
    //   1405: i2f
    //   1406: fmul
    //   1407: f2i
    //   1408: istore #5
    //   1410: iload #5
    //   1412: istore #8
    //   1414: aload_0
    //   1415: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1418: iconst_0
    //   1419: aaload
    //   1420: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1423: if_acmpeq -> 1451
    //   1426: iload #5
    //   1428: istore #8
    //   1430: iload #6
    //   1432: istore #7
    //   1434: iconst_0
    //   1435: istore #12
    //   1437: iconst_4
    //   1438: istore #6
    //   1440: iload #4
    //   1442: istore #5
    //   1444: iload #8
    //   1446: istore #4
    //   1448: goto -> 1496
    //   1451: iload #4
    //   1453: istore #5
    //   1455: iload #8
    //   1457: istore #4
    //   1459: iload #6
    //   1461: istore #8
    //   1463: iload #7
    //   1465: istore #6
    //   1467: iconst_1
    //   1468: istore #12
    //   1470: iload #8
    //   1472: istore #7
    //   1474: goto -> 1496
    //   1477: iload #8
    //   1479: istore #6
    //   1481: iload #4
    //   1483: istore #8
    //   1485: iconst_0
    //   1486: istore #12
    //   1488: iload #5
    //   1490: istore #4
    //   1492: iload #8
    //   1494: istore #5
    //   1496: aload_0
    //   1497: getfield mResolvedMatchConstraintDefault : [I
    //   1500: astore #24
    //   1502: aload #24
    //   1504: iconst_0
    //   1505: iload #7
    //   1507: iastore
    //   1508: aload #24
    //   1510: iconst_1
    //   1511: iload #6
    //   1513: iastore
    //   1514: aload_0
    //   1515: iload #12
    //   1517: putfield mResolvedHasRatio : Z
    //   1520: iload #12
    //   1522: ifeq -> 1548
    //   1525: aload_0
    //   1526: getfield mResolvedDimensionRatioSide : I
    //   1529: istore #8
    //   1531: iload #8
    //   1533: ifeq -> 1542
    //   1536: iload #8
    //   1538: iconst_m1
    //   1539: if_icmpne -> 1548
    //   1542: iconst_1
    //   1543: istore #17
    //   1545: goto -> 1551
    //   1548: iconst_0
    //   1549: istore #17
    //   1551: iload #12
    //   1553: ifeq -> 1580
    //   1556: aload_0
    //   1557: getfield mResolvedDimensionRatioSide : I
    //   1560: istore #8
    //   1562: iload #8
    //   1564: iconst_1
    //   1565: if_icmpeq -> 1574
    //   1568: iload #8
    //   1570: iconst_m1
    //   1571: if_icmpne -> 1580
    //   1574: iconst_1
    //   1575: istore #16
    //   1577: goto -> 1583
    //   1580: iconst_0
    //   1581: istore #16
    //   1583: aload_0
    //   1584: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1587: iconst_0
    //   1588: aaload
    //   1589: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1592: if_acmpne -> 1608
    //   1595: aload_0
    //   1596: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   1599: ifeq -> 1608
    //   1602: iconst_1
    //   1603: istore #18
    //   1605: goto -> 1611
    //   1608: iconst_0
    //   1609: istore #18
    //   1611: iload #18
    //   1613: ifeq -> 1622
    //   1616: iconst_0
    //   1617: istore #5
    //   1619: goto -> 1622
    //   1622: aload_0
    //   1623: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1626: invokevirtual isConnected : ()Z
    //   1629: iconst_1
    //   1630: ixor
    //   1631: istore #20
    //   1633: aload_0
    //   1634: getfield mIsInBarrier : [Z
    //   1637: astore #24
    //   1639: aload #24
    //   1641: iconst_0
    //   1642: baload
    //   1643: istore #22
    //   1645: aload #24
    //   1647: iconst_1
    //   1648: baload
    //   1649: istore #21
    //   1651: aload_0
    //   1652: getfield mHorizontalResolution : I
    //   1655: iconst_2
    //   1656: if_icmpeq -> 1991
    //   1659: aload_0
    //   1660: getfield resolvedHorizontal : Z
    //   1663: ifne -> 1991
    //   1666: iload_2
    //   1667: ifeq -> 1795
    //   1670: aload_0
    //   1671: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1674: astore #24
    //   1676: aload #24
    //   1678: ifnull -> 1795
    //   1681: aload #24
    //   1683: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1686: getfield resolved : Z
    //   1689: ifeq -> 1795
    //   1692: aload_0
    //   1693: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1696: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1699: getfield resolved : Z
    //   1702: ifne -> 1708
    //   1705: goto -> 1795
    //   1708: iload_2
    //   1709: ifeq -> 1991
    //   1712: aload_1
    //   1713: aload #28
    //   1715: aload_0
    //   1716: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1719: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1722: getfield value : I
    //   1725: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   1728: aload_1
    //   1729: aload #27
    //   1731: aload_0
    //   1732: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1735: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1738: getfield value : I
    //   1741: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   1744: aload_0
    //   1745: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1748: ifnull -> 1991
    //   1751: iload #13
    //   1753: ifeq -> 1991
    //   1756: aload_0
    //   1757: getfield isTerminalWidget : [Z
    //   1760: iconst_0
    //   1761: baload
    //   1762: ifeq -> 1991
    //   1765: aload_0
    //   1766: invokevirtual isInHorizontalChain : ()Z
    //   1769: ifne -> 1991
    //   1772: aload_1
    //   1773: aload_1
    //   1774: aload_0
    //   1775: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1778: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1781: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1784: aload #27
    //   1786: iconst_0
    //   1787: bipush #8
    //   1789: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1792: goto -> 1991
    //   1795: aload_0
    //   1796: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1799: astore #24
    //   1801: aload #24
    //   1803: ifnull -> 1820
    //   1806: aload_1
    //   1807: aload #24
    //   1809: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1812: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1815: astore #24
    //   1817: goto -> 1823
    //   1820: aconst_null
    //   1821: astore #24
    //   1823: aload_0
    //   1824: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1827: astore #25
    //   1829: aload #25
    //   1831: ifnull -> 1848
    //   1834: aload_1
    //   1835: aload #25
    //   1837: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1840: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1843: astore #25
    //   1845: goto -> 1851
    //   1848: aconst_null
    //   1849: astore #25
    //   1851: aload_0
    //   1852: getfield isTerminalWidget : [Z
    //   1855: iconst_0
    //   1856: baload
    //   1857: istore #23
    //   1859: aload_0
    //   1860: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1863: astore #31
    //   1865: aload #31
    //   1867: iconst_0
    //   1868: aaload
    //   1869: astore #32
    //   1871: aload_0
    //   1872: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1875: astore #33
    //   1877: aload_0
    //   1878: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1881: astore #34
    //   1883: aload_0
    //   1884: getfield mX : I
    //   1887: istore #8
    //   1889: aload_0
    //   1890: getfield mMinWidth : I
    //   1893: istore #9
    //   1895: aload_0
    //   1896: getfield mMaxDimension : [I
    //   1899: iconst_0
    //   1900: iaload
    //   1901: istore #10
    //   1903: aload_0
    //   1904: getfield mHorizontalBiasPercent : F
    //   1907: fstore_3
    //   1908: aload #31
    //   1910: iconst_1
    //   1911: aaload
    //   1912: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1915: if_acmpne -> 1924
    //   1918: iconst_1
    //   1919: istore #19
    //   1921: goto -> 1927
    //   1924: iconst_0
    //   1925: istore #19
    //   1927: aload_0
    //   1928: aload_1
    //   1929: iconst_1
    //   1930: iload #13
    //   1932: iload #11
    //   1934: iload #23
    //   1936: aload #25
    //   1938: aload #24
    //   1940: aload #32
    //   1942: iload #18
    //   1944: aload #33
    //   1946: aload #34
    //   1948: iload #8
    //   1950: iload #5
    //   1952: iload #9
    //   1954: iload #10
    //   1956: fload_3
    //   1957: iload #17
    //   1959: iload #19
    //   1961: iload #15
    //   1963: iload #14
    //   1965: iload #22
    //   1967: iload #7
    //   1969: iload #6
    //   1971: aload_0
    //   1972: getfield mMatchConstraintMinWidth : I
    //   1975: aload_0
    //   1976: getfield mMatchConstraintMaxWidth : I
    //   1979: aload_0
    //   1980: getfield mMatchConstraintPercentWidth : F
    //   1983: iload #20
    //   1985: invokespecial applyConstraints : (Landroidx/constraintlayout/core/LinearSystem;ZZZZLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   1988: goto -> 1991
    //   1991: aload #30
    //   1993: astore #25
    //   1995: aload #29
    //   1997: astore #24
    //   1999: iload #11
    //   2001: istore #18
    //   2003: aload #27
    //   2005: astore #29
    //   2007: iload_2
    //   2008: ifeq -> 2187
    //   2011: aload_0
    //   2012: astore #27
    //   2014: aload #27
    //   2016: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2019: astore #30
    //   2021: aload #30
    //   2023: ifnull -> 2184
    //   2026: aload #30
    //   2028: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2031: getfield resolved : Z
    //   2034: ifeq -> 2184
    //   2037: aload #27
    //   2039: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2042: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2045: getfield resolved : Z
    //   2048: ifeq -> 2184
    //   2051: aload #27
    //   2053: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2056: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2059: getfield value : I
    //   2062: istore #5
    //   2064: aload_1
    //   2065: astore #30
    //   2067: aload #30
    //   2069: aload #25
    //   2071: iload #5
    //   2073: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2076: aload #27
    //   2078: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2081: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2084: getfield value : I
    //   2087: istore #5
    //   2089: aload #24
    //   2091: astore #31
    //   2093: aload #30
    //   2095: aload #31
    //   2097: iload #5
    //   2099: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2102: aload #30
    //   2104: aload #26
    //   2106: aload #27
    //   2108: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2111: getfield baseline : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2114: getfield value : I
    //   2117: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2120: aload #27
    //   2122: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2125: astore #32
    //   2127: aload #32
    //   2129: ifnull -> 2178
    //   2132: iload #14
    //   2134: ifne -> 2178
    //   2137: iload #18
    //   2139: ifeq -> 2178
    //   2142: aload #27
    //   2144: getfield isTerminalWidget : [Z
    //   2147: iconst_1
    //   2148: baload
    //   2149: ifeq -> 2175
    //   2152: aload #30
    //   2154: aload #30
    //   2156: aload #32
    //   2158: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2161: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2164: aload #31
    //   2166: iconst_0
    //   2167: bipush #8
    //   2169: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2172: goto -> 2178
    //   2175: goto -> 2178
    //   2178: iconst_0
    //   2179: istore #5
    //   2181: goto -> 2190
    //   2184: goto -> 2187
    //   2187: iconst_1
    //   2188: istore #5
    //   2190: aload_0
    //   2191: astore #30
    //   2193: aload_1
    //   2194: astore #31
    //   2196: aload #26
    //   2198: astore #32
    //   2200: aload #30
    //   2202: getfield mVerticalResolution : I
    //   2205: iconst_2
    //   2206: if_icmpne -> 2215
    //   2209: iconst_0
    //   2210: istore #5
    //   2212: goto -> 2215
    //   2215: iload #5
    //   2217: ifeq -> 2632
    //   2220: aload #30
    //   2222: getfield resolvedVertical : Z
    //   2225: ifne -> 2632
    //   2228: aload #30
    //   2230: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2233: iconst_1
    //   2234: aaload
    //   2235: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2238: if_acmpne -> 2254
    //   2241: aload #30
    //   2243: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   2246: ifeq -> 2254
    //   2249: iconst_1
    //   2250: istore_2
    //   2251: goto -> 2256
    //   2254: iconst_0
    //   2255: istore_2
    //   2256: iload_2
    //   2257: ifeq -> 2263
    //   2260: iconst_0
    //   2261: istore #4
    //   2263: aload #30
    //   2265: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2268: astore #26
    //   2270: aload #26
    //   2272: ifnull -> 2290
    //   2275: aload #31
    //   2277: aload #26
    //   2279: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2282: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2285: astore #26
    //   2287: goto -> 2293
    //   2290: aconst_null
    //   2291: astore #26
    //   2293: aload #30
    //   2295: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2298: astore #27
    //   2300: aload #27
    //   2302: ifnull -> 2320
    //   2305: aload #31
    //   2307: aload #27
    //   2309: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2312: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2315: astore #27
    //   2317: goto -> 2323
    //   2320: aconst_null
    //   2321: astore #27
    //   2323: aload #30
    //   2325: getfield mBaselineDistance : I
    //   2328: ifgt -> 2341
    //   2331: aload #30
    //   2333: getfield mVisibility : I
    //   2336: bipush #8
    //   2338: if_icmpne -> 2478
    //   2341: aload #30
    //   2343: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2346: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2349: ifnull -> 2429
    //   2352: aload #31
    //   2354: aload #32
    //   2356: aload #25
    //   2358: aload_0
    //   2359: invokevirtual getBaselineDistance : ()I
    //   2362: bipush #8
    //   2364: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2367: pop
    //   2368: aload #31
    //   2370: aload #32
    //   2372: aload #31
    //   2374: aload #30
    //   2376: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2379: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2382: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2385: aload #30
    //   2387: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2390: invokevirtual getMargin : ()I
    //   2393: bipush #8
    //   2395: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2398: pop
    //   2399: iload #18
    //   2401: ifeq -> 2423
    //   2404: aload #31
    //   2406: aload #26
    //   2408: aload #31
    //   2410: aload #30
    //   2412: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2415: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2418: iconst_0
    //   2419: iconst_5
    //   2420: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2423: iconst_0
    //   2424: istore #11
    //   2426: goto -> 2482
    //   2429: aload #30
    //   2431: getfield mVisibility : I
    //   2434: bipush #8
    //   2436: if_icmpne -> 2462
    //   2439: aload #31
    //   2441: aload #32
    //   2443: aload #25
    //   2445: aload #30
    //   2447: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2450: invokevirtual getMargin : ()I
    //   2453: bipush #8
    //   2455: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2458: pop
    //   2459: goto -> 2478
    //   2462: aload #31
    //   2464: aload #32
    //   2466: aload #25
    //   2468: aload_0
    //   2469: invokevirtual getBaselineDistance : ()I
    //   2472: bipush #8
    //   2474: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2477: pop
    //   2478: iload #20
    //   2480: istore #11
    //   2482: aload #30
    //   2484: getfield isTerminalWidget : [Z
    //   2487: iconst_1
    //   2488: baload
    //   2489: istore #19
    //   2491: aload #30
    //   2493: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2496: astore #31
    //   2498: aload #31
    //   2500: iconst_1
    //   2501: aaload
    //   2502: astore #32
    //   2504: aload #30
    //   2506: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2509: astore #33
    //   2511: aload #30
    //   2513: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2516: astore #34
    //   2518: aload #30
    //   2520: getfield mY : I
    //   2523: istore #5
    //   2525: aload #30
    //   2527: getfield mMinHeight : I
    //   2530: istore #8
    //   2532: aload #30
    //   2534: getfield mMaxDimension : [I
    //   2537: iconst_1
    //   2538: iaload
    //   2539: istore #9
    //   2541: aload #30
    //   2543: getfield mVerticalBiasPercent : F
    //   2546: fstore_3
    //   2547: aload #31
    //   2549: iconst_0
    //   2550: aaload
    //   2551: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2554: if_acmpne -> 2563
    //   2557: iconst_1
    //   2558: istore #17
    //   2560: goto -> 2566
    //   2563: iconst_0
    //   2564: istore #17
    //   2566: aload_0
    //   2567: aload_1
    //   2568: iconst_0
    //   2569: iload #18
    //   2571: iload #13
    //   2573: iload #19
    //   2575: aload #27
    //   2577: aload #26
    //   2579: aload #32
    //   2581: iload_2
    //   2582: aload #33
    //   2584: aload #34
    //   2586: iload #5
    //   2588: iload #4
    //   2590: iload #8
    //   2592: iload #9
    //   2594: fload_3
    //   2595: iload #16
    //   2597: iload #17
    //   2599: iload #14
    //   2601: iload #15
    //   2603: iload #21
    //   2605: iload #6
    //   2607: iload #7
    //   2609: aload #30
    //   2611: getfield mMatchConstraintMinHeight : I
    //   2614: aload #30
    //   2616: getfield mMatchConstraintMaxHeight : I
    //   2619: aload #30
    //   2621: getfield mMatchConstraintPercentHeight : F
    //   2624: iload #11
    //   2626: invokespecial applyConstraints : (Landroidx/constraintlayout/core/LinearSystem;ZZZZLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   2629: goto -> 2632
    //   2632: iload #12
    //   2634: ifeq -> 2693
    //   2637: aload_0
    //   2638: astore #26
    //   2640: aload #26
    //   2642: getfield mResolvedDimensionRatioSide : I
    //   2645: iconst_1
    //   2646: if_icmpne -> 2671
    //   2649: aload_1
    //   2650: aload #24
    //   2652: aload #25
    //   2654: aload #29
    //   2656: aload #28
    //   2658: aload #26
    //   2660: getfield mResolvedDimensionRatio : F
    //   2663: bipush #8
    //   2665: invokevirtual addRatio : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;FI)V
    //   2668: goto -> 2693
    //   2671: aload_1
    //   2672: aload #29
    //   2674: aload #28
    //   2676: aload #24
    //   2678: aload #25
    //   2680: aload #26
    //   2682: getfield mResolvedDimensionRatio : F
    //   2685: bipush #8
    //   2687: invokevirtual addRatio : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;FI)V
    //   2690: goto -> 2693
    //   2693: aload_0
    //   2694: astore #24
    //   2696: aload #24
    //   2698: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2701: invokevirtual isConnected : ()Z
    //   2704: ifeq -> 2746
    //   2707: aload_1
    //   2708: aload #24
    //   2710: aload #24
    //   2712: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2715: invokevirtual getTarget : ()Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2718: invokevirtual getOwner : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2721: aload #24
    //   2723: getfield mCircleConstraintAngle : F
    //   2726: ldc_w 90.0
    //   2729: fadd
    //   2730: f2d
    //   2731: invokestatic toRadians : (D)D
    //   2734: d2f
    //   2735: aload #24
    //   2737: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2740: invokevirtual getMargin : ()I
    //   2743: invokevirtual addCenterPoint : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget;FI)V
    //   2746: aload #24
    //   2748: iconst_0
    //   2749: putfield resolvedHorizontal : Z
    //   2752: aload #24
    //   2754: iconst_0
    //   2755: putfield resolvedVertical : Z
    //   2758: return
  }
  
  public boolean allowedInBarrier() {
    return (this.mVisibility != 8);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2) {
    connect(paramType1, paramConstraintWidget, paramType2, 0);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt) {
    ConstraintAnchor constraintAnchor;
    if (paramType1 == ConstraintAnchor.Type.CENTER) {
      if (paramType2 == ConstraintAnchor.Type.CENTER) {
        ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.RIGHT);
        ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.TOP);
        ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.BOTTOM);
        boolean bool = true;
        if ((constraintAnchor1 != null && constraintAnchor1.isConnected()) || (constraintAnchor != null && constraintAnchor.isConnected())) {
          paramInt = 0;
        } else {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, ConstraintAnchor.Type.LEFT, 0);
          connect(ConstraintAnchor.Type.RIGHT, paramConstraintWidget, ConstraintAnchor.Type.RIGHT, 0);
          paramInt = 1;
        } 
        if ((constraintAnchor2 != null && constraintAnchor2.isConnected()) || (constraintAnchor3 != null && constraintAnchor3.isConnected())) {
          bool = false;
        } else {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, ConstraintAnchor.Type.TOP, 0);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, ConstraintAnchor.Type.BOTTOM, 0);
        } 
        if (paramInt != 0 && bool) {
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER), 0);
          return;
        } 
        if (paramInt != 0) {
          getAnchor(ConstraintAnchor.Type.CENTER_X).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_X), 0);
          return;
        } 
        if (bool) {
          getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_Y), 0);
          return;
        } 
      } else {
        if (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT) {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          paramType1 = ConstraintAnchor.Type.RIGHT;
          try {
            connect(paramType1, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
            getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
            return;
          } finally {}
        } 
        if (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM) {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
          return;
        } 
      } 
    } else {
      ConstraintAnchor constraintAnchor1;
      if (paramType1 == ConstraintAnchor.Type.CENTER_X && (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT)) {
        constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor2 = paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.RIGHT);
        constraintAnchor1.connect(constraintAnchor2, 0);
        constraintAnchor.connect(constraintAnchor2, 0);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2, 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM)) {
        constraintAnchor1 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor1, 0);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor1, 0);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor1, 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_X && constraintAnchor == ConstraintAnchor.Type.CENTER_X) {
        getAnchor(ConstraintAnchor.Type.LEFT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.LEFT), 0);
        getAnchor(ConstraintAnchor.Type.RIGHT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.RIGHT), 0);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && constraintAnchor == ConstraintAnchor.Type.CENTER_Y) {
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.TOP), 0);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.BOTTOM), 0);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
        return;
      } 
      ConstraintAnchor constraintAnchor3 = getAnchor((ConstraintAnchor.Type)constraintAnchor1);
      ConstraintAnchor constraintAnchor2 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
      if (constraintAnchor3.isValidConnection(constraintAnchor2)) {
        if (constraintAnchor1 == ConstraintAnchor.Type.BASELINE) {
          constraintAnchor1 = getAnchor(ConstraintAnchor.Type.TOP);
          constraintAnchor = getAnchor(ConstraintAnchor.Type.BOTTOM);
          if (constraintAnchor1 != null)
            constraintAnchor1.reset(); 
          if (constraintAnchor != null)
            constraintAnchor.reset(); 
        } else if (constraintAnchor1 == ConstraintAnchor.Type.TOP || constraintAnchor1 == ConstraintAnchor.Type.BOTTOM) {
          constraintAnchor = getAnchor(ConstraintAnchor.Type.BASELINE);
          if (constraintAnchor != null)
            constraintAnchor.reset(); 
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
          if (constraintAnchor.getTarget() != constraintAnchor2)
            constraintAnchor.reset(); 
          constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_Y);
          if (constraintAnchor.isConnected()) {
            constraintAnchor1.reset();
            constraintAnchor.reset();
          } 
        } else if (constraintAnchor1 == ConstraintAnchor.Type.LEFT || constraintAnchor1 == ConstraintAnchor.Type.RIGHT) {
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
          if (constraintAnchor.getTarget() != constraintAnchor2)
            constraintAnchor.reset(); 
          constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_X);
          if (constraintAnchor.isConnected()) {
            constraintAnchor1.reset();
            constraintAnchor.reset();
          } 
        } 
        constraintAnchor3.connect(constraintAnchor2, paramInt);
      } 
    } 
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    if (paramConstraintAnchor1.getOwner() == this)
      connect(paramConstraintAnchor1.getType(), paramConstraintAnchor2.getOwner(), paramConstraintAnchor2.getType(), paramInt); 
  }
  
  public void connectCircularConstraint(ConstraintWidget paramConstraintWidget, float paramFloat, int paramInt) {
    immediateConnect(ConstraintAnchor.Type.CENTER, paramConstraintWidget, ConstraintAnchor.Type.CENTER, paramInt, 0);
    this.mCircleConstraintAngle = paramFloat;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    int[] arrayOfInt1;
    ConstraintWidget constraintWidget1;
    this.mHorizontalResolution = paramConstraintWidget.mHorizontalResolution;
    this.mVerticalResolution = paramConstraintWidget.mVerticalResolution;
    this.mMatchConstraintDefaultWidth = paramConstraintWidget.mMatchConstraintDefaultWidth;
    this.mMatchConstraintDefaultHeight = paramConstraintWidget.mMatchConstraintDefaultHeight;
    int[] arrayOfInt2 = this.mResolvedMatchConstraintDefault;
    int[] arrayOfInt3 = paramConstraintWidget.mResolvedMatchConstraintDefault;
    arrayOfInt2[0] = arrayOfInt3[0];
    arrayOfInt2[1] = arrayOfInt3[1];
    this.mMatchConstraintMinWidth = paramConstraintWidget.mMatchConstraintMinWidth;
    this.mMatchConstraintMaxWidth = paramConstraintWidget.mMatchConstraintMaxWidth;
    this.mMatchConstraintMinHeight = paramConstraintWidget.mMatchConstraintMinHeight;
    this.mMatchConstraintMaxHeight = paramConstraintWidget.mMatchConstraintMaxHeight;
    this.mMatchConstraintPercentHeight = paramConstraintWidget.mMatchConstraintPercentHeight;
    this.mIsWidthWrapContent = paramConstraintWidget.mIsWidthWrapContent;
    this.mIsHeightWrapContent = paramConstraintWidget.mIsHeightWrapContent;
    this.mResolvedDimensionRatioSide = paramConstraintWidget.mResolvedDimensionRatioSide;
    this.mResolvedDimensionRatio = paramConstraintWidget.mResolvedDimensionRatio;
    arrayOfInt2 = paramConstraintWidget.mMaxDimension;
    this.mMaxDimension = Arrays.copyOf(arrayOfInt2, arrayOfInt2.length);
    this.mCircleConstraintAngle = paramConstraintWidget.mCircleConstraintAngle;
    this.hasBaseline = paramConstraintWidget.hasBaseline;
    this.inPlaceholder = paramConstraintWidget.inPlaceholder;
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mListDimensionBehaviors = Arrays.<DimensionBehaviour>copyOf(this.mListDimensionBehaviors, 2);
    ConstraintWidget constraintWidget3 = this.mParent;
    arrayOfInt3 = null;
    if (constraintWidget3 == null) {
      constraintWidget3 = null;
    } else {
      constraintWidget3 = paramHashMap.get(paramConstraintWidget.mParent);
    } 
    this.mParent = constraintWidget3;
    this.mWidth = paramConstraintWidget.mWidth;
    this.mHeight = paramConstraintWidget.mHeight;
    this.mDimensionRatio = paramConstraintWidget.mDimensionRatio;
    this.mDimensionRatioSide = paramConstraintWidget.mDimensionRatioSide;
    this.mX = paramConstraintWidget.mX;
    this.mY = paramConstraintWidget.mY;
    this.mRelX = paramConstraintWidget.mRelX;
    this.mRelY = paramConstraintWidget.mRelY;
    this.mOffsetX = paramConstraintWidget.mOffsetX;
    this.mOffsetY = paramConstraintWidget.mOffsetY;
    this.mBaselineDistance = paramConstraintWidget.mBaselineDistance;
    this.mMinWidth = paramConstraintWidget.mMinWidth;
    this.mMinHeight = paramConstraintWidget.mMinHeight;
    this.mHorizontalBiasPercent = paramConstraintWidget.mHorizontalBiasPercent;
    this.mVerticalBiasPercent = paramConstraintWidget.mVerticalBiasPercent;
    this.mCompanionWidget = paramConstraintWidget.mCompanionWidget;
    this.mContainerItemSkip = paramConstraintWidget.mContainerItemSkip;
    this.mVisibility = paramConstraintWidget.mVisibility;
    this.mDebugName = paramConstraintWidget.mDebugName;
    this.mType = paramConstraintWidget.mType;
    this.mDistToTop = paramConstraintWidget.mDistToTop;
    this.mDistToLeft = paramConstraintWidget.mDistToLeft;
    this.mDistToRight = paramConstraintWidget.mDistToRight;
    this.mDistToBottom = paramConstraintWidget.mDistToBottom;
    this.mLeftHasCentered = paramConstraintWidget.mLeftHasCentered;
    this.mRightHasCentered = paramConstraintWidget.mRightHasCentered;
    this.mTopHasCentered = paramConstraintWidget.mTopHasCentered;
    this.mBottomHasCentered = paramConstraintWidget.mBottomHasCentered;
    this.mHorizontalWrapVisited = paramConstraintWidget.mHorizontalWrapVisited;
    this.mVerticalWrapVisited = paramConstraintWidget.mVerticalWrapVisited;
    this.mHorizontalChainStyle = paramConstraintWidget.mHorizontalChainStyle;
    this.mVerticalChainStyle = paramConstraintWidget.mVerticalChainStyle;
    this.mHorizontalChainFixedPosition = paramConstraintWidget.mHorizontalChainFixedPosition;
    this.mVerticalChainFixedPosition = paramConstraintWidget.mVerticalChainFixedPosition;
    float[] arrayOfFloat1 = this.mWeight;
    float[] arrayOfFloat2 = paramConstraintWidget.mWeight;
    arrayOfFloat1[0] = arrayOfFloat2[0];
    arrayOfFloat1[1] = arrayOfFloat2[1];
    ConstraintWidget[] arrayOfConstraintWidget1 = this.mListNextMatchConstraintsWidget;
    ConstraintWidget[] arrayOfConstraintWidget2 = paramConstraintWidget.mListNextMatchConstraintsWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    arrayOfConstraintWidget1 = this.mNextChainWidget;
    arrayOfConstraintWidget2 = paramConstraintWidget.mNextChainWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    ConstraintWidget constraintWidget2 = paramConstraintWidget.mHorizontalNextWidget;
    if (constraintWidget2 == null) {
      constraintWidget2 = null;
    } else {
      constraintWidget2 = paramHashMap.get(constraintWidget2);
    } 
    this.mHorizontalNextWidget = constraintWidget2;
    paramConstraintWidget = paramConstraintWidget.mVerticalNextWidget;
    if (paramConstraintWidget == null) {
      arrayOfInt1 = arrayOfInt3;
    } else {
      constraintWidget1 = paramHashMap.get(arrayOfInt1);
    } 
    this.mVerticalNextWidget = constraintWidget1;
  }
  
  public void createObjectVariables(LinearSystem paramLinearSystem) {
    paramLinearSystem.createObjectVariable(this.mLeft);
    paramLinearSystem.createObjectVariable(this.mTop);
    paramLinearSystem.createObjectVariable(this.mRight);
    paramLinearSystem.createObjectVariable(this.mBottom);
    if (this.mBaselineDistance > 0)
      paramLinearSystem.createObjectVariable(this.mBaseline); 
  }
  
  public void ensureMeasureRequested() {
    this.mMeasureRequested = true;
  }
  
  public void ensureWidgetRuns() {
    if (this.horizontalRun == null)
      this.horizontalRun = new HorizontalWidgetRun(this); 
    if (this.verticalRun == null)
      this.verticalRun = new VerticalWidgetRun(this); 
  }
  
  public ConstraintAnchor getAnchor(ConstraintAnchor.Type paramType) {
    switch (paramType) {
      default:
        throw new AssertionError(paramType.name());
      case null:
        return null;
      case null:
        return this.mCenterY;
      case null:
        return this.mCenterX;
      case null:
        return this.mCenter;
      case null:
        return this.mBaseline;
      case null:
        return this.mBottom;
      case null:
        return this.mRight;
      case null:
        return this.mTop;
      case null:
        break;
    } 
    return this.mLeft;
  }
  
  public ArrayList<ConstraintAnchor> getAnchors() {
    return this.mAnchors;
  }
  
  public int getBaselineDistance() {
    return this.mBaselineDistance;
  }
  
  public float getBiasPercent(int paramInt) {
    return (paramInt == 0) ? this.mHorizontalBiasPercent : ((paramInt == 1) ? this.mVerticalBiasPercent : -1.0F);
  }
  
  public int getBottom() {
    return getY() + this.mHeight;
  }
  
  public Object getCompanionWidget() {
    return this.mCompanionWidget;
  }
  
  public int getContainerItemSkip() {
    return this.mContainerItemSkip;
  }
  
  public String getDebugName() {
    return this.mDebugName;
  }
  
  public DimensionBehaviour getDimensionBehaviour(int paramInt) {
    return (paramInt == 0) ? getHorizontalDimensionBehaviour() : ((paramInt == 1) ? getVerticalDimensionBehaviour() : null);
  }
  
  public float getDimensionRatio() {
    return this.mDimensionRatio;
  }
  
  public int getDimensionRatioSide() {
    return this.mDimensionRatioSide;
  }
  
  public boolean getHasBaseline() {
    return this.hasBaseline;
  }
  
  public int getHeight() {
    return (this.mVisibility == 8) ? 0 : this.mHeight;
  }
  
  public float getHorizontalBiasPercent() {
    return this.mHorizontalBiasPercent;
  }
  
  public ConstraintWidget getHorizontalChainControlWidget() {
    boolean bool = isInHorizontalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.LEFT);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getHorizontalChainStyle() {
    return this.mHorizontalChainStyle;
  }
  
  public DimensionBehaviour getHorizontalDimensionBehaviour() {
    return this.mListDimensionBehaviors[0];
  }
  
  public int getHorizontalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + constraintAnchor.mMargin; 
    constraintAnchor = this.mRight;
    int j = i;
    if (constraintAnchor != null)
      j = i + constraintAnchor.mMargin; 
    return j;
  }
  
  public int getLastHorizontalMeasureSpec() {
    return this.mLastHorizontalMeasureSpec;
  }
  
  public int getLastVerticalMeasureSpec() {
    return this.mLastVerticalMeasureSpec;
  }
  
  public int getLeft() {
    return getX();
  }
  
  public int getLength(int paramInt) {
    return (paramInt == 0) ? getWidth() : ((paramInt == 1) ? getHeight() : 0);
  }
  
  public int getMaxHeight() {
    return this.mMaxDimension[1];
  }
  
  public int getMaxWidth() {
    return this.mMaxDimension[0];
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public ConstraintWidget getNextChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mRight.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mRight.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mRight;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mBottom.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mBottom.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mBottom;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  public int getOptimizerWrapHeight() {
    int i = this.mHeight;
    int j = i;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultHeight == 1) {
        i = Math.max(this.mMatchConstraintMinHeight, i);
      } else {
        i = this.mMatchConstraintMinHeight;
        if (i > 0) {
          this.mHeight = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxHeight;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public int getOptimizerWrapWidth() {
    int i = this.mWidth;
    int j = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultWidth == 1) {
        i = Math.max(this.mMatchConstraintMinWidth, i);
      } else {
        i = this.mMatchConstraintMinWidth;
        if (i > 0) {
          this.mWidth = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxWidth;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public ConstraintWidget getParent() {
    return this.mParent;
  }
  
  public ConstraintWidget getPreviousChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mLeft.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mLeft;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mTop.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mTop.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  int getRelativePositioning(int paramInt) {
    return (paramInt == 0) ? this.mRelX : ((paramInt == 1) ? this.mRelY : 0);
  }
  
  public int getRight() {
    return getX() + this.mWidth;
  }
  
  protected int getRootX() {
    return this.mX + this.mOffsetX;
  }
  
  protected int getRootY() {
    return this.mY + this.mOffsetY;
  }
  
  public WidgetRun getRun(int paramInt) {
    return (WidgetRun)((paramInt == 0) ? this.horizontalRun : ((paramInt == 1) ? this.verticalRun : null));
  }
  
  public int getTop() {
    return getY();
  }
  
  public String getType() {
    return this.mType;
  }
  
  public float getVerticalBiasPercent() {
    return this.mVerticalBiasPercent;
  }
  
  public ConstraintWidget getVerticalChainControlWidget() {
    boolean bool = isInVerticalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.TOP);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getVerticalChainStyle() {
    return this.mVerticalChainStyle;
  }
  
  public DimensionBehaviour getVerticalDimensionBehaviour() {
    return this.mListDimensionBehaviors[1];
  }
  
  public int getVerticalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + this.mTop.mMargin; 
    int j = i;
    if (this.mRight != null)
      j = i + this.mBottom.mMargin; 
    return j;
  }
  
  public int getVisibility() {
    return this.mVisibility;
  }
  
  public int getWidth() {
    return (this.mVisibility == 8) ? 0 : this.mWidth;
  }
  
  public int getWrapBehaviorInParent() {
    return this.mWrapBehaviorInParent;
  }
  
  public int getX() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingLeft + this.mX) : this.mX;
  }
  
  public int getY() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingTop + this.mY) : this.mY;
  }
  
  public boolean hasBaseline() {
    return this.hasBaseline;
  }
  
  public boolean hasDanglingDimension(int paramInt) {
    byte b1;
    byte b2;
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if (this.mRight.mTarget != null) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      return (paramInt + b1 < 2);
    } 
    if (this.mTop.mTarget != null) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (this.mBottom.mTarget != null) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    if (this.mBaseline.mTarget != null) {
      b2 = 1;
    } else {
      b2 = 0;
    } 
    return (paramInt + b1 + b2 < 2);
  }
  
  public boolean hasDependencies() {
    int j = this.mAnchors.size();
    for (int i = 0; i < j; i++) {
      if (((ConstraintAnchor)this.mAnchors.get(i)).hasDependents())
        return true; 
    } 
    return false;
  }
  
  public boolean hasDimensionOverride() {
    return (this.mWidthOverride != -1 || this.mHeightOverride != -1);
  }
  
  public boolean hasResolvedTargets(int paramInt1, int paramInt2) {
    if (paramInt1 == 0) {
      if (this.mLeft.mTarget != null && this.mLeft.mTarget.hasFinalValue() && this.mRight.mTarget != null && this.mRight.mTarget.hasFinalValue())
        return (this.mRight.mTarget.getFinalValue() - this.mRight.getMargin() - this.mLeft.mTarget.getFinalValue() + this.mLeft.getMargin() >= paramInt2); 
    } else if (this.mTop.mTarget != null && this.mTop.mTarget.hasFinalValue() && this.mBottom.mTarget != null && this.mBottom.mTarget.hasFinalValue()) {
      return (this.mBottom.mTarget.getFinalValue() - this.mBottom.getMargin() - this.mTop.mTarget.getFinalValue() + this.mTop.getMargin() >= paramInt2);
    } 
    return false;
  }
  
  public void immediateConnect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, int paramInt2) {
    getAnchor(paramType1).connect(paramConstraintWidget.getAnchor(paramType2), paramInt1, paramInt2, true);
  }
  
  public boolean isHeightWrapContent() {
    return this.mIsHeightWrapContent;
  }
  
  public boolean isHorizontalSolvingPassDone() {
    return this.horizontalSolvingPass;
  }
  
  public boolean isInBarrier(int paramInt) {
    return this.mIsInBarrier[paramInt];
  }
  
  public boolean isInHorizontalChain() {
    return ((this.mLeft.mTarget != null && this.mLeft.mTarget.mTarget == this.mLeft) || (this.mRight.mTarget != null && this.mRight.mTarget.mTarget == this.mRight));
  }
  
  public boolean isInPlaceholder() {
    return this.inPlaceholder;
  }
  
  public boolean isInVerticalChain() {
    return ((this.mTop.mTarget != null && this.mTop.mTarget.mTarget == this.mTop) || (this.mBottom.mTarget != null && this.mBottom.mTarget.mTarget == this.mBottom));
  }
  
  public boolean isInVirtualLayout() {
    return this.mInVirtualLayout;
  }
  
  public boolean isMeasureRequested() {
    return (this.mMeasureRequested && this.mVisibility != 8);
  }
  
  public boolean isResolvedHorizontally() {
    return (this.resolvedHorizontal || (this.mLeft.hasFinalValue() && this.mRight.hasFinalValue()));
  }
  
  public boolean isResolvedVertically() {
    return (this.resolvedVertical || (this.mTop.hasFinalValue() && this.mBottom.hasFinalValue()));
  }
  
  public boolean isRoot() {
    return (this.mParent == null);
  }
  
  public boolean isSpreadHeight() {
    return (this.mMatchConstraintDefaultHeight == 0 && this.mDimensionRatio == 0.0F && this.mMatchConstraintMinHeight == 0 && this.mMatchConstraintMaxHeight == 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean isSpreadWidth() {
    int i = this.mMatchConstraintDefaultWidth;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.mDimensionRatio == 0.0F) {
        bool1 = bool2;
        if (this.mMatchConstraintMinWidth == 0) {
          bool1 = bool2;
          if (this.mMatchConstraintMaxWidth == 0) {
            bool1 = bool2;
            if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public boolean isVerticalSolvingPassDone() {
    return this.verticalSolvingPass;
  }
  
  public boolean isWidthWrapContent() {
    return this.mIsWidthWrapContent;
  }
  
  public void markHorizontalSolvingPassDone() {
    this.horizontalSolvingPass = true;
  }
  
  public void markVerticalSolvingPassDone() {
    this.verticalSolvingPass = true;
  }
  
  public boolean oppositeDimensionDependsOn(int paramInt) {
    boolean bool;
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[paramInt];
    DimensionBehaviour dimensionBehaviour2 = arrayOfDimensionBehaviour[bool];
    return (dimensionBehaviour1 == DimensionBehaviour.MATCH_CONSTRAINT && dimensionBehaviour2 == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean oppositeDimensionsTied() {
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (arrayOfDimensionBehaviour[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      bool1 = bool2;
      if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void reset() {
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mParent = null;
    this.mCircleConstraintAngle = 0.0F;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    this.mMinWidth = 0;
    this.mMinHeight = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors[1] = DimensionBehaviour.FIXED;
    this.mCompanionWidget = null;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mType = null;
    this.mHorizontalWrapVisited = false;
    this.mVerticalWrapVisited = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mHorizontalChainFixedPosition = false;
    this.mVerticalChainFixedPosition = false;
    float[] arrayOfFloat = this.mWeight;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.mHorizontalResolution = -1;
    this.mVerticalResolution = -1;
    int[] arrayOfInt2 = this.mMaxDimension;
    arrayOfInt2[0] = Integer.MAX_VALUE;
    arrayOfInt2[1] = Integer.MAX_VALUE;
    this.mMatchConstraintDefaultWidth = 0;
    this.mMatchConstraintDefaultHeight = 0;
    this.mMatchConstraintPercentWidth = 1.0F;
    this.mMatchConstraintPercentHeight = 1.0F;
    this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
    this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
    this.mMatchConstraintMinWidth = 0;
    this.mMatchConstraintMinHeight = 0;
    this.mResolvedHasRatio = false;
    this.mResolvedDimensionRatioSide = -1;
    this.mResolvedDimensionRatio = 1.0F;
    this.mGroupsToSolver = false;
    boolean[] arrayOfBoolean = this.isTerminalWidget;
    arrayOfBoolean[0] = true;
    arrayOfBoolean[1] = true;
    this.mInVirtualLayout = false;
    arrayOfBoolean = this.mIsInBarrier;
    arrayOfBoolean[0] = false;
    arrayOfBoolean[1] = false;
    this.mMeasureRequested = true;
    int[] arrayOfInt1 = this.mResolvedMatchConstraintDefault;
    arrayOfInt1[0] = 0;
    arrayOfInt1[1] = 0;
    this.mWidthOverride = -1;
    this.mHeightOverride = -1;
  }
  
  public void resetAllConstraints() {
    resetAnchors();
    setVerticalBiasPercent(DEFAULT_BIAS);
    setHorizontalBiasPercent(DEFAULT_BIAS);
  }
  
  public void resetAnchor(ConstraintAnchor paramConstraintAnchor) {
    if (getParent() != null && getParent() instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
    ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor constraintAnchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
    ConstraintAnchor constraintAnchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor constraintAnchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
    if (paramConstraintAnchor == constraintAnchor5) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor6) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget().getOwner() == constraintAnchor2.getTarget().getOwner()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor7) {
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget().getOwner() == constraintAnchor4.getTarget().getOwner()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor1 || paramConstraintAnchor == constraintAnchor2) {
      if (constraintAnchor1.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget())
        constraintAnchor5.reset(); 
    } else if ((paramConstraintAnchor == constraintAnchor3 || paramConstraintAnchor == constraintAnchor4) && constraintAnchor3.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
      constraintAnchor5.reset();
    } 
    paramConstraintAnchor.reset();
  }
  
  public void resetAnchors() {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    int i = 0;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).reset();
      i++;
    } 
  }
  
  public void resetFinalResolution() {
    int i = 0;
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
    this.horizontalSolvingPass = false;
    this.verticalSolvingPass = false;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).resetFinalResolution();
      i++;
    } 
  }
  
  public void resetSolverVariables(Cache paramCache) {
    this.mLeft.resetSolverVariable(paramCache);
    this.mTop.resetSolverVariable(paramCache);
    this.mRight.resetSolverVariable(paramCache);
    this.mBottom.resetSolverVariable(paramCache);
    this.mBaseline.resetSolverVariable(paramCache);
    this.mCenter.resetSolverVariable(paramCache);
    this.mCenterX.resetSolverVariable(paramCache);
    this.mCenterY.resetSolverVariable(paramCache);
  }
  
  public void resetSolvingPassFlag() {
    this.horizontalSolvingPass = false;
    this.verticalSolvingPass = false;
  }
  
  public StringBuilder serialize(StringBuilder paramStringBuilder) {
    paramStringBuilder.append("{\n");
    serializeAnchor(paramStringBuilder, "left", this.mLeft);
    serializeAnchor(paramStringBuilder, "top", this.mTop);
    serializeAnchor(paramStringBuilder, "right", this.mRight);
    serializeAnchor(paramStringBuilder, "bottom", this.mBottom);
    serializeAnchor(paramStringBuilder, "baseline", this.mBaseline);
    serializeAnchor(paramStringBuilder, "centerX", this.mCenterX);
    serializeAnchor(paramStringBuilder, "centerY", this.mCenterY);
    serializeCircle(paramStringBuilder, this.mCenter, this.mCircleConstraintAngle);
    serializeSize(paramStringBuilder, "width", this.mWidth, this.mMinWidth, this.mMaxDimension[0], this.mWidthOverride, this.mMatchConstraintMinWidth, this.mMatchConstraintDefaultWidth, this.mMatchConstraintPercentWidth, this.mWeight[0]);
    serializeSize(paramStringBuilder, "height", this.mHeight, this.mMinHeight, this.mMaxDimension[1], this.mHeightOverride, this.mMatchConstraintMinHeight, this.mMatchConstraintDefaultHeight, this.mMatchConstraintPercentHeight, this.mWeight[1]);
    serializeDimensionRatio(paramStringBuilder, "dimensionRatio", this.mDimensionRatio, this.mDimensionRatioSide);
    serializeAttribute(paramStringBuilder, "horizontalBias", this.mHorizontalBiasPercent, DEFAULT_BIAS);
    serializeAttribute(paramStringBuilder, "verticalBias", this.mVerticalBiasPercent, DEFAULT_BIAS);
    paramStringBuilder.append("}\n");
    return paramStringBuilder;
  }
  
  public void setBaselineDistance(int paramInt) {
    boolean bool;
    this.mBaselineDistance = paramInt;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.hasBaseline = bool;
  }
  
  public void setCompanionWidget(Object paramObject) {
    this.mCompanionWidget = paramObject;
  }
  
  public void setContainerItemSkip(int paramInt) {
    if (paramInt >= 0) {
      this.mContainerItemSkip = paramInt;
      return;
    } 
    this.mContainerItemSkip = 0;
  }
  
  public void setDebugName(String paramString) {
    this.mDebugName = paramString;
  }
  
  public void setDebugSolverName(LinearSystem paramLinearSystem, String paramString) {
    this.mDebugName = paramString;
    SolverVariable solverVariable5 = paramLinearSystem.createObjectVariable(this.mLeft);
    SolverVariable solverVariable4 = paramLinearSystem.createObjectVariable(this.mTop);
    SolverVariable solverVariable3 = paramLinearSystem.createObjectVariable(this.mRight);
    SolverVariable solverVariable2 = paramLinearSystem.createObjectVariable(this.mBottom);
    StringBuilder stringBuilder5 = new StringBuilder();
    stringBuilder5.append(paramString);
    stringBuilder5.append(".left");
    solverVariable5.setName(stringBuilder5.toString());
    StringBuilder stringBuilder4 = new StringBuilder();
    stringBuilder4.append(paramString);
    stringBuilder4.append(".top");
    solverVariable4.setName(stringBuilder4.toString());
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".right");
    solverVariable3.setName(stringBuilder3.toString());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(".bottom");
    solverVariable2.setName(stringBuilder2.toString());
    SolverVariable solverVariable1 = paramLinearSystem.createObjectVariable(this.mBaseline);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append(".baseline");
    solverVariable1.setName(stringBuilder1.toString());
  }
  
  public void setDimension(int paramInt1, int paramInt2) {
    this.mWidth = paramInt1;
    int i = this.mMinWidth;
    if (paramInt1 < i)
      this.mWidth = i; 
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
  }
  
  public void setDimensionRatio(float paramFloat, int paramInt) {
    this.mDimensionRatio = paramFloat;
    this.mDimensionRatioSide = paramInt;
  }
  
  public void setDimensionRatio(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 261
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: ifne -> 14
    //   11: goto -> 261
    //   14: iconst_m1
    //   15: istore #6
    //   17: aload_1
    //   18: invokevirtual length : ()I
    //   21: istore #8
    //   23: aload_1
    //   24: bipush #44
    //   26: invokevirtual indexOf : (I)I
    //   29: istore #9
    //   31: iconst_0
    //   32: istore #7
    //   34: iload #6
    //   36: istore #4
    //   38: iload #7
    //   40: istore #5
    //   42: iload #9
    //   44: ifle -> 114
    //   47: iload #6
    //   49: istore #4
    //   51: iload #7
    //   53: istore #5
    //   55: iload #9
    //   57: iload #8
    //   59: iconst_1
    //   60: isub
    //   61: if_icmpge -> 114
    //   64: aload_1
    //   65: iconst_0
    //   66: iload #9
    //   68: invokevirtual substring : (II)Ljava/lang/String;
    //   71: astore #10
    //   73: aload #10
    //   75: ldc_w 'W'
    //   78: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   81: ifeq -> 90
    //   84: iconst_0
    //   85: istore #4
    //   87: goto -> 108
    //   90: iload #6
    //   92: istore #4
    //   94: aload #10
    //   96: ldc_w 'H'
    //   99: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   102: ifeq -> 108
    //   105: iconst_1
    //   106: istore #4
    //   108: iload #9
    //   110: iconst_1
    //   111: iadd
    //   112: istore #5
    //   114: aload_1
    //   115: bipush #58
    //   117: invokevirtual indexOf : (I)I
    //   120: istore #6
    //   122: iload #6
    //   124: iflt -> 219
    //   127: iload #6
    //   129: iload #8
    //   131: iconst_1
    //   132: isub
    //   133: if_icmpge -> 219
    //   136: aload_1
    //   137: iload #5
    //   139: iload #6
    //   141: invokevirtual substring : (II)Ljava/lang/String;
    //   144: astore #10
    //   146: aload_1
    //   147: iload #6
    //   149: iconst_1
    //   150: iadd
    //   151: invokevirtual substring : (I)Ljava/lang/String;
    //   154: astore_1
    //   155: aload #10
    //   157: invokevirtual length : ()I
    //   160: ifle -> 241
    //   163: aload_1
    //   164: invokevirtual length : ()I
    //   167: ifle -> 241
    //   170: aload #10
    //   172: invokestatic parseFloat : (Ljava/lang/String;)F
    //   175: fstore_2
    //   176: aload_1
    //   177: invokestatic parseFloat : (Ljava/lang/String;)F
    //   180: fstore_3
    //   181: fload_2
    //   182: fconst_0
    //   183: fcmpl
    //   184: ifle -> 241
    //   187: fload_3
    //   188: fconst_0
    //   189: fcmpl
    //   190: ifle -> 241
    //   193: iload #4
    //   195: iconst_1
    //   196: if_icmpne -> 209
    //   199: fload_3
    //   200: fload_2
    //   201: fdiv
    //   202: invokestatic abs : (F)F
    //   205: fstore_2
    //   206: goto -> 243
    //   209: fload_2
    //   210: fload_3
    //   211: fdiv
    //   212: invokestatic abs : (F)F
    //   215: fstore_2
    //   216: goto -> 243
    //   219: aload_1
    //   220: iload #5
    //   222: invokevirtual substring : (I)Ljava/lang/String;
    //   225: astore_1
    //   226: aload_1
    //   227: invokevirtual length : ()I
    //   230: ifle -> 241
    //   233: aload_1
    //   234: invokestatic parseFloat : (Ljava/lang/String;)F
    //   237: fstore_2
    //   238: goto -> 243
    //   241: fconst_0
    //   242: fstore_2
    //   243: fload_2
    //   244: fconst_0
    //   245: fcmpl
    //   246: ifle -> 260
    //   249: aload_0
    //   250: fload_2
    //   251: putfield mDimensionRatio : F
    //   254: aload_0
    //   255: iload #4
    //   257: putfield mDimensionRatioSide : I
    //   260: return
    //   261: aload_0
    //   262: fconst_0
    //   263: putfield mDimensionRatio : F
    //   266: return
    //   267: astore_1
    //   268: goto -> 241
    // Exception table:
    //   from	to	target	type
    //   170	181	267	java/lang/NumberFormatException
    //   199	206	267	java/lang/NumberFormatException
    //   209	216	267	java/lang/NumberFormatException
    //   233	238	267	java/lang/NumberFormatException
  }
  
  public void setFinalBaseline(int paramInt) {
    if (!this.hasBaseline)
      return; 
    int i = paramInt - this.mBaselineDistance;
    int j = this.mHeight;
    this.mY = i;
    this.mTop.setFinalValue(i);
    this.mBottom.setFinalValue(j + i);
    this.mBaseline.setFinalValue(paramInt);
    this.resolvedVertical = true;
  }
  
  public void setFinalFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    setFrame(paramInt1, paramInt2, paramInt3, paramInt4);
    setBaselineDistance(paramInt5);
    if (paramInt6 == 0) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = false;
      return;
    } 
    if (paramInt6 == 1) {
      this.resolvedHorizontal = false;
      this.resolvedVertical = true;
      return;
    } 
    if (paramInt6 == 2) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = true;
      return;
    } 
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
  }
  
  public void setFinalHorizontal(int paramInt1, int paramInt2) {
    if (this.resolvedHorizontal)
      return; 
    this.mLeft.setFinalValue(paramInt1);
    this.mRight.setFinalValue(paramInt2);
    this.mX = paramInt1;
    this.mWidth = paramInt2 - paramInt1;
    this.resolvedHorizontal = true;
  }
  
  public void setFinalLeft(int paramInt) {
    this.mLeft.setFinalValue(paramInt);
    this.mX = paramInt;
  }
  
  public void setFinalTop(int paramInt) {
    this.mTop.setFinalValue(paramInt);
    this.mY = paramInt;
  }
  
  public void setFinalVertical(int paramInt1, int paramInt2) {
    if (this.resolvedVertical)
      return; 
    this.mTop.setFinalValue(paramInt1);
    this.mBottom.setFinalValue(paramInt2);
    this.mY = paramInt1;
    this.mHeight = paramInt2 - paramInt1;
    if (this.hasBaseline)
      this.mBaseline.setFinalValue(paramInt1 + this.mBaselineDistance); 
    this.resolvedVertical = true;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      setHorizontalDimension(paramInt1, paramInt2);
      return;
    } 
    if (paramInt3 == 1)
      setVerticalDimension(paramInt1, paramInt2); 
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    this.mX = paramInt1;
    this.mY = paramInt2;
    if (this.mVisibility == 8) {
      this.mWidth = 0;
      this.mHeight = 0;
      return;
    } 
    paramInt1 = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.FIXED) {
      paramInt2 = this.mWidth;
      paramInt1 = i;
      if (i < paramInt2)
        paramInt1 = paramInt2; 
    } 
    paramInt2 = paramInt3;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.FIXED) {
      paramInt4 = this.mHeight;
      paramInt2 = paramInt3;
      if (paramInt3 < paramInt4)
        paramInt2 = paramInt4; 
    } 
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
    paramInt3 = this.mMinHeight;
    if (paramInt2 < paramInt3)
      this.mHeight = paramInt3; 
    paramInt3 = this.mWidth;
    paramInt4 = this.mMinWidth;
    if (paramInt3 < paramInt4)
      this.mWidth = paramInt4; 
    if (this.mMatchConstraintMaxWidth > 0 && this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
      this.mWidth = Math.min(this.mWidth, this.mMatchConstraintMaxWidth); 
    if (this.mMatchConstraintMaxHeight > 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT)
      this.mHeight = Math.min(this.mHeight, this.mMatchConstraintMaxHeight); 
    paramInt3 = this.mWidth;
    if (paramInt1 != paramInt3)
      this.mWidthOverride = paramInt3; 
    paramInt1 = this.mHeight;
    if (paramInt2 != paramInt1)
      this.mHeightOverride = paramInt1; 
  }
  
  public void setGoneMargin(ConstraintAnchor.Type paramType, int paramInt) {
    int i = null.$SwitchMap$androidx$constraintlayout$core$widgets$ConstraintAnchor$Type[paramType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5)
              return; 
            this.mBaseline.mGoneMargin = paramInt;
            return;
          } 
          this.mBottom.mGoneMargin = paramInt;
          return;
        } 
        this.mRight.mGoneMargin = paramInt;
        return;
      } 
      this.mTop.mGoneMargin = paramInt;
      return;
    } 
    this.mLeft.mGoneMargin = paramInt;
  }
  
  public void setHasBaseline(boolean paramBoolean) {
    this.hasBaseline = paramBoolean;
  }
  
  public void setHeight(int paramInt) {
    this.mHeight = paramInt;
    int i = this.mMinHeight;
    if (paramInt < i)
      this.mHeight = i; 
  }
  
  public void setHeightWrapContent(boolean paramBoolean) {
    this.mIsHeightWrapContent = paramBoolean;
  }
  
  public void setHorizontalBiasPercent(float paramFloat) {
    this.mHorizontalBiasPercent = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt) {
    this.mHorizontalChainStyle = paramInt;
  }
  
  public void setHorizontalDimension(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mWidth = paramInt1;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setHorizontalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[0] = paramDimensionBehaviour;
  }
  
  public void setHorizontalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultWidth = paramInt1;
    this.mMatchConstraintMinWidth = paramInt2;
    paramInt1 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt1 = 0; 
    this.mMatchConstraintMaxWidth = paramInt1;
    this.mMatchConstraintPercentWidth = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && this.mMatchConstraintDefaultWidth == 0)
      this.mMatchConstraintDefaultWidth = 2; 
  }
  
  public void setHorizontalWeight(float paramFloat) {
    this.mWeight[0] = paramFloat;
  }
  
  protected void setInBarrier(int paramInt, boolean paramBoolean) {
    this.mIsInBarrier[paramInt] = paramBoolean;
  }
  
  public void setInPlaceholder(boolean paramBoolean) {
    this.inPlaceholder = paramBoolean;
  }
  
  public void setInVirtualLayout(boolean paramBoolean) {
    this.mInVirtualLayout = paramBoolean;
  }
  
  public void setLastMeasureSpec(int paramInt1, int paramInt2) {
    this.mLastHorizontalMeasureSpec = paramInt1;
    this.mLastVerticalMeasureSpec = paramInt2;
    setMeasureRequested(false);
  }
  
  public void setLength(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      setWidth(paramInt1);
      return;
    } 
    if (paramInt2 == 1)
      setHeight(paramInt1); 
  }
  
  public void setMaxHeight(int paramInt) {
    this.mMaxDimension[1] = paramInt;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxDimension[0] = paramInt;
  }
  
  public void setMeasureRequested(boolean paramBoolean) {
    this.mMeasureRequested = paramBoolean;
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt < 0) {
      this.mMinHeight = 0;
      return;
    } 
    this.mMinHeight = paramInt;
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt < 0) {
      this.mMinWidth = 0;
      return;
    } 
    this.mMinWidth = paramInt;
  }
  
  public void setOffset(int paramInt1, int paramInt2) {
    this.mOffsetX = paramInt1;
    this.mOffsetY = paramInt2;
  }
  
  public void setOrigin(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setParent(ConstraintWidget paramConstraintWidget) {
    this.mParent = paramConstraintWidget;
  }
  
  void setRelativePositioning(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      this.mRelX = paramInt1;
      return;
    } 
    if (paramInt2 == 1)
      this.mRelY = paramInt1; 
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setVerticalBiasPercent(float paramFloat) {
    this.mVerticalBiasPercent = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt) {
    this.mVerticalChainStyle = paramInt;
  }
  
  public void setVerticalDimension(int paramInt1, int paramInt2) {
    this.mY = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mHeight = paramInt1;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setVerticalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[1] = paramDimensionBehaviour;
  }
  
  public void setVerticalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultHeight = paramInt1;
    this.mMatchConstraintMinHeight = paramInt2;
    paramInt1 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt1 = 0; 
    this.mMatchConstraintMaxHeight = paramInt1;
    this.mMatchConstraintPercentHeight = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && this.mMatchConstraintDefaultHeight == 0)
      this.mMatchConstraintDefaultHeight = 2; 
  }
  
  public void setVerticalWeight(float paramFloat) {
    this.mWeight[1] = paramFloat;
  }
  
  public void setVisibility(int paramInt) {
    this.mVisibility = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.mWidth = paramInt;
    int i = this.mMinWidth;
    if (paramInt < i)
      this.mWidth = i; 
  }
  
  public void setWidthWrapContent(boolean paramBoolean) {
    this.mIsWidthWrapContent = paramBoolean;
  }
  
  public void setWrapBehaviorInParent(int paramInt) {
    if (paramInt >= 0 && paramInt <= 3)
      this.mWrapBehaviorInParent = paramInt; 
  }
  
  public void setX(int paramInt) {
    this.mX = paramInt;
  }
  
  public void setY(int paramInt) {
    this.mY = paramInt;
  }
  
  public void setupDimensionRatio(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.mResolvedDimensionRatioSide = 1;
        if (this.mDimensionRatioSide == -1)
          this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio; 
      }  
    if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
      this.mResolvedDimensionRatioSide = 1;
    } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
      this.mResolvedDimensionRatioSide = 0;
    } 
    if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected()))
      if (this.mTop.isConnected() && this.mBottom.isConnected()) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1) {
      if (this.mMatchConstraintMinWidth > 0 && this.mMatchConstraintMinHeight == 0) {
        this.mResolvedDimensionRatioSide = 0;
        return;
      } 
      if (this.mMatchConstraintMinWidth == 0 && this.mMatchConstraintMinHeight > 0) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.mType;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("type: ");
      stringBuilder1.append(this.mType);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.mDebugName != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("id: ");
      stringBuilder1.append(this.mDebugName);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.mX);
    stringBuilder.append(", ");
    stringBuilder.append(this.mY);
    stringBuilder.append(") - (");
    stringBuilder.append(this.mWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mHeight);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   5: invokevirtual isResolved : ()Z
    //   8: iand
    //   9: istore #9
    //   11: iload_2
    //   12: aload_0
    //   13: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   16: invokevirtual isResolved : ()Z
    //   19: iand
    //   20: istore #8
    //   22: aload_0
    //   23: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   26: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   29: getfield value : I
    //   32: istore_3
    //   33: aload_0
    //   34: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   37: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   40: getfield value : I
    //   43: istore #4
    //   45: aload_0
    //   46: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   49: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   52: getfield value : I
    //   55: istore #6
    //   57: aload_0
    //   58: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   61: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   64: getfield value : I
    //   67: istore #7
    //   69: iload #6
    //   71: iload_3
    //   72: isub
    //   73: iflt -> 146
    //   76: iload #7
    //   78: iload #4
    //   80: isub
    //   81: iflt -> 146
    //   84: iload_3
    //   85: ldc_w -2147483648
    //   88: if_icmpeq -> 146
    //   91: iload_3
    //   92: ldc 2147483647
    //   94: if_icmpeq -> 146
    //   97: iload #4
    //   99: ldc_w -2147483648
    //   102: if_icmpeq -> 146
    //   105: iload #4
    //   107: ldc 2147483647
    //   109: if_icmpeq -> 146
    //   112: iload #6
    //   114: ldc_w -2147483648
    //   117: if_icmpeq -> 146
    //   120: iload #6
    //   122: ldc 2147483647
    //   124: if_icmpeq -> 146
    //   127: iload #7
    //   129: ldc_w -2147483648
    //   132: if_icmpeq -> 146
    //   135: iload #7
    //   137: istore #5
    //   139: iload #7
    //   141: ldc 2147483647
    //   143: if_icmpne -> 157
    //   146: iconst_0
    //   147: istore_3
    //   148: iconst_0
    //   149: istore #4
    //   151: iconst_0
    //   152: istore #6
    //   154: iconst_0
    //   155: istore #5
    //   157: iload #6
    //   159: iload_3
    //   160: isub
    //   161: istore #6
    //   163: iload #5
    //   165: iload #4
    //   167: isub
    //   168: istore #5
    //   170: iload #9
    //   172: ifeq -> 180
    //   175: aload_0
    //   176: iload_3
    //   177: putfield mX : I
    //   180: iload #8
    //   182: ifeq -> 191
    //   185: aload_0
    //   186: iload #4
    //   188: putfield mY : I
    //   191: aload_0
    //   192: getfield mVisibility : I
    //   195: bipush #8
    //   197: if_icmpne -> 211
    //   200: aload_0
    //   201: iconst_0
    //   202: putfield mWidth : I
    //   205: aload_0
    //   206: iconst_0
    //   207: putfield mHeight : I
    //   210: return
    //   211: iload #9
    //   213: ifeq -> 273
    //   216: iload #6
    //   218: istore_3
    //   219: aload_0
    //   220: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   223: iconst_0
    //   224: aaload
    //   225: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   228: if_acmpne -> 250
    //   231: aload_0
    //   232: getfield mWidth : I
    //   235: istore #4
    //   237: iload #6
    //   239: istore_3
    //   240: iload #6
    //   242: iload #4
    //   244: if_icmpge -> 250
    //   247: iload #4
    //   249: istore_3
    //   250: aload_0
    //   251: iload_3
    //   252: putfield mWidth : I
    //   255: aload_0
    //   256: getfield mMinWidth : I
    //   259: istore #4
    //   261: iload_3
    //   262: iload #4
    //   264: if_icmpge -> 273
    //   267: aload_0
    //   268: iload #4
    //   270: putfield mWidth : I
    //   273: iload #8
    //   275: ifeq -> 335
    //   278: iload #5
    //   280: istore_3
    //   281: aload_0
    //   282: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   285: iconst_1
    //   286: aaload
    //   287: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   290: if_acmpne -> 312
    //   293: aload_0
    //   294: getfield mHeight : I
    //   297: istore #4
    //   299: iload #5
    //   301: istore_3
    //   302: iload #5
    //   304: iload #4
    //   306: if_icmpge -> 312
    //   309: iload #4
    //   311: istore_3
    //   312: aload_0
    //   313: iload_3
    //   314: putfield mHeight : I
    //   317: aload_0
    //   318: getfield mMinHeight : I
    //   321: istore #4
    //   323: iload_3
    //   324: iload #4
    //   326: if_icmpge -> 335
    //   329: aload_0
    //   330: iload #4
    //   332: putfield mHeight : I
    //   335: return
  }
  
  public void updateFromSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   5: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   8: istore #4
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   15: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   18: istore #7
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   25: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   28: istore #6
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   35: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   38: istore #8
    //   40: iload #4
    //   42: istore #5
    //   44: iload #6
    //   46: istore_3
    //   47: iload_2
    //   48: ifeq -> 127
    //   51: aload_0
    //   52: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   55: astore_1
    //   56: iload #4
    //   58: istore #5
    //   60: iload #6
    //   62: istore_3
    //   63: aload_1
    //   64: ifnull -> 127
    //   67: iload #4
    //   69: istore #5
    //   71: iload #6
    //   73: istore_3
    //   74: aload_1
    //   75: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   78: getfield resolved : Z
    //   81: ifeq -> 127
    //   84: iload #4
    //   86: istore #5
    //   88: iload #6
    //   90: istore_3
    //   91: aload_0
    //   92: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   95: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   98: getfield resolved : Z
    //   101: ifeq -> 127
    //   104: aload_0
    //   105: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   108: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   111: getfield value : I
    //   114: istore #5
    //   116: aload_0
    //   117: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   120: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   123: getfield value : I
    //   126: istore_3
    //   127: iload #7
    //   129: istore #6
    //   131: iload #8
    //   133: istore #4
    //   135: iload_2
    //   136: ifeq -> 219
    //   139: aload_0
    //   140: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   143: astore_1
    //   144: iload #7
    //   146: istore #6
    //   148: iload #8
    //   150: istore #4
    //   152: aload_1
    //   153: ifnull -> 219
    //   156: iload #7
    //   158: istore #6
    //   160: iload #8
    //   162: istore #4
    //   164: aload_1
    //   165: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   168: getfield resolved : Z
    //   171: ifeq -> 219
    //   174: iload #7
    //   176: istore #6
    //   178: iload #8
    //   180: istore #4
    //   182: aload_0
    //   183: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   186: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   189: getfield resolved : Z
    //   192: ifeq -> 219
    //   195: aload_0
    //   196: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   199: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   202: getfield value : I
    //   205: istore #6
    //   207: aload_0
    //   208: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   211: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   214: getfield value : I
    //   217: istore #4
    //   219: iload_3
    //   220: iload #5
    //   222: isub
    //   223: iflt -> 298
    //   226: iload #4
    //   228: iload #6
    //   230: isub
    //   231: iflt -> 298
    //   234: iload #5
    //   236: ldc_w -2147483648
    //   239: if_icmpeq -> 298
    //   242: iload #5
    //   244: ldc 2147483647
    //   246: if_icmpeq -> 298
    //   249: iload #6
    //   251: ldc_w -2147483648
    //   254: if_icmpeq -> 298
    //   257: iload #6
    //   259: ldc 2147483647
    //   261: if_icmpeq -> 298
    //   264: iload_3
    //   265: ldc_w -2147483648
    //   268: if_icmpeq -> 298
    //   271: iload_3
    //   272: ldc 2147483647
    //   274: if_icmpeq -> 298
    //   277: iload #4
    //   279: ldc_w -2147483648
    //   282: if_icmpeq -> 298
    //   285: iload_3
    //   286: istore #7
    //   288: iload #4
    //   290: istore_3
    //   291: iload #4
    //   293: ldc 2147483647
    //   295: if_icmpne -> 309
    //   298: iconst_0
    //   299: istore_3
    //   300: iconst_0
    //   301: istore #5
    //   303: iconst_0
    //   304: istore #6
    //   306: iconst_0
    //   307: istore #7
    //   309: aload_0
    //   310: iload #5
    //   312: iload #6
    //   314: iload #7
    //   316: iload_3
    //   317: invokevirtual setFrame : (IIII)V
    //   320: return
  }
  
  public enum DimensionBehaviour {
    FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
    
    static {
      DimensionBehaviour dimensionBehaviour = new DimensionBehaviour("MATCH_PARENT", 3);
      MATCH_PARENT = dimensionBehaviour;
      $VALUES = new DimensionBehaviour[] { FIXED, WRAP_CONTENT, MATCH_CONSTRAINT, dimensionBehaviour };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */