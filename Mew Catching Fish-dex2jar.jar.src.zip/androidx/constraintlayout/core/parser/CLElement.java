package androidx.constraintlayout.core.parser;

import java.io.PrintStream;

public class CLElement {
  protected static int BASE_INDENT = 2;
  
  protected static int MAX_LINE = 80;
  
  protected long end = Long.MAX_VALUE;
  
  private int line;
  
  protected CLContainer mContainer;
  
  private final char[] mContent;
  
  protected long start = -1L;
  
  public CLElement(char[] paramArrayOfchar) {
    this.mContent = paramArrayOfchar;
  }
  
  protected void addIndent(StringBuilder paramStringBuilder, int paramInt) {
    for (int i = 0; i < paramInt; i++)
      paramStringBuilder.append(' '); 
  }
  
  public String content() {
    String str = new String(this.mContent);
    long l = this.end;
    if (l != Long.MAX_VALUE) {
      long l1 = this.start;
      if (l >= l1)
        return str.substring((int)l1, (int)l + 1); 
    } 
    l = this.start;
    return str.substring((int)l, (int)l + 1);
  }
  
  public CLElement getContainer() {
    return this.mContainer;
  }
  
  protected String getDebugName() {
    if (CLParser.DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(getStrClass());
      stringBuilder.append(" -> ");
      return stringBuilder.toString();
    } 
    return "";
  }
  
  public long getEnd() {
    return this.end;
  }
  
  public float getFloat() {
    return (this instanceof CLNumber) ? ((CLNumber)this).getFloat() : Float.NaN;
  }
  
  public int getInt() {
    return (this instanceof CLNumber) ? ((CLNumber)this).getInt() : 0;
  }
  
  public int getLine() {
    return this.line;
  }
  
  public long getStart() {
    return this.start;
  }
  
  protected String getStrClass() {
    String str = getClass().toString();
    return str.substring(str.lastIndexOf('.') + 1);
  }
  
  public boolean isDone() {
    return (this.end != Long.MAX_VALUE);
  }
  
  public boolean isStarted() {
    return (this.start > -1L);
  }
  
  public boolean notStarted() {
    return (this.start == -1L);
  }
  
  public void setContainer(CLContainer paramCLContainer) {
    this.mContainer = paramCLContainer;
  }
  
  public void setEnd(long paramLong) {
    if (this.end != Long.MAX_VALUE)
      return; 
    this.end = paramLong;
    if (CLParser.DEBUG) {
      PrintStream printStream = System.out;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("closing ");
      stringBuilder.append(hashCode());
      stringBuilder.append(" -> ");
      stringBuilder.append(this);
      printStream.println(stringBuilder.toString());
    } 
    CLContainer cLContainer = this.mContainer;
    if (cLContainer != null)
      cLContainer.add(this); 
  }
  
  public void setLine(int paramInt) {
    this.line = paramInt;
  }
  
  public void setStart(long paramLong) {
    this.start = paramLong;
  }
  
  protected String toFormattedJSON(int paramInt1, int paramInt2) {
    return "";
  }
  
  protected String toJSON() {
    return "";
  }
  
  public String toString() {
    long l1 = this.start;
    long l2 = this.end;
    if (l1 > l2 || l2 == Long.MAX_VALUE) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getClass());
      stringBuilder1.append(" (INVALID, ");
      stringBuilder1.append(this.start);
      stringBuilder1.append("-");
      stringBuilder1.append(this.end);
      stringBuilder1.append(")");
      return stringBuilder1.toString();
    } 
    String str = (new String(this.mContent)).substring((int)this.start, (int)this.end + 1);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getStrClass());
    stringBuilder.append(" (");
    stringBuilder.append(this.start);
    stringBuilder.append(" : ");
    stringBuilder.append(this.end);
    stringBuilder.append(") <<");
    stringBuilder.append(str);
    stringBuilder.append(">>");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\constraintlayout\core\parser\CLElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */