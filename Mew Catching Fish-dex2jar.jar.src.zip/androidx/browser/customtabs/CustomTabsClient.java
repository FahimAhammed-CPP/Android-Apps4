package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.customtabs.ICustomTabsCallback;
import android.support.customtabs.ICustomTabsService;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

public class CustomTabsClient {
  private static final String TAG = "CustomTabsClient";
  
  private final Context mApplicationContext;
  
  private final ICustomTabsService mService;
  
  private final ComponentName mServiceComponentName;
  
  CustomTabsClient(ICustomTabsService paramICustomTabsService, ComponentName paramComponentName, Context paramContext) {
    this.mService = paramICustomTabsService;
    this.mServiceComponentName = paramComponentName;
    this.mApplicationContext = paramContext;
  }
  
  public static boolean bindCustomTabsService(Context paramContext, String paramString, CustomTabsServiceConnection paramCustomTabsServiceConnection) {
    paramCustomTabsServiceConnection.setApplicationContext(paramContext.getApplicationContext());
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, paramCustomTabsServiceConnection, 33);
  }
  
  public static boolean bindCustomTabsServicePreservePriority(Context paramContext, String paramString, CustomTabsServiceConnection paramCustomTabsServiceConnection) {
    paramCustomTabsServiceConnection.setApplicationContext(paramContext.getApplicationContext());
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, paramCustomTabsServiceConnection, 1);
  }
  
  public static boolean connectAndInitialize(final Context applicationContext, String paramString) {
    if (paramString == null)
      return false; 
    applicationContext = applicationContext.getApplicationContext();
    CustomTabsServiceConnection customTabsServiceConnection = new CustomTabsServiceConnection() {
        public final void onCustomTabsServiceConnected(ComponentName param1ComponentName, CustomTabsClient param1CustomTabsClient) {
          param1CustomTabsClient.warmup(0L);
          applicationContext.unbindService(this);
        }
        
        public void onServiceDisconnected(ComponentName param1ComponentName) {}
      };
    try {
      return bindCustomTabsService(applicationContext, paramString, customTabsServiceConnection);
    } catch (SecurityException securityException) {
      return false;
    } 
  }
  
  private ICustomTabsCallback.Stub createCallbackWrapper(final CustomTabsCallback callback) {
    return new ICustomTabsCallback.Stub() {
        private Handler mHandler = new Handler(Looper.getMainLooper());
        
        public void extraCallback(final String callbackName, final Bundle args) throws RemoteException {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.extraCallback(callbackName, args);
                }
              });
        }
        
        public Bundle extraCallbackWithResult(String param1String, Bundle param1Bundle) throws RemoteException {
          CustomTabsCallback customTabsCallback = callback;
          return (customTabsCallback == null) ? null : customTabsCallback.extraCallbackWithResult(param1String, param1Bundle);
        }
        
        public void onMessageChannelReady(final Bundle extras) throws RemoteException {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onMessageChannelReady(extras);
                }
              });
        }
        
        public void onNavigationEvent(final int navigationEvent, final Bundle extras) {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onNavigationEvent(navigationEvent, extras);
                }
              });
        }
        
        public void onPostMessage(final String message, final Bundle extras) throws RemoteException {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onPostMessage(message, extras);
                }
              });
        }
        
        public void onRelationshipValidationResult(final int relation, final Uri requestedOrigin, final boolean result, final Bundle extras) throws RemoteException {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onRelationshipValidationResult(relation, requestedOrigin, result, extras);
                }
              });
        }
      };
  }
  
  private static PendingIntent createSessionId(Context paramContext, int paramInt) {
    return PendingIntent.getActivity(paramContext, paramInt, new Intent(), 67108864);
  }
  
  public static String getPackageName(Context paramContext, List<String> paramList) {
    return getPackageName(paramContext, paramList, false);
  }
  
  public static String getPackageName(Context paramContext, List<String> paramList, boolean paramBoolean) {
    List<String> list1;
    PackageManager packageManager = paramContext.getPackageManager();
    if (paramList == null) {
      list1 = new ArrayList();
    } else {
      list1 = paramList;
    } 
    Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse("http://"));
    List<String> list2 = list1;
    if (!paramBoolean) {
      ResolveInfo resolveInfo = packageManager.resolveActivity(intent2, 0);
      list2 = list1;
      if (resolveInfo != null) {
        String str = resolveInfo.activityInfo.packageName;
        list2 = new ArrayList<String>(list1.size() + 1);
        list2.add(str);
        if (paramList != null)
          list2.addAll(paramList); 
      } 
    } 
    Intent intent1 = new Intent("android.support.customtabs.action.CustomTabsService");
    for (String str : list2) {
      intent1.setPackage(str);
      if (packageManager.resolveService(intent1, 0) != null)
        return str; 
    } 
    if (Build.VERSION.SDK_INT >= 30)
      Log.w("CustomTabsClient", "Unable to find any Custom Tabs packages, you may need to add a <queries> element to your manifest. See the docs for CustomTabsClient#getPackageName."); 
    return null;
  }
  
  public static CustomTabsSession.PendingSession newPendingSession(Context paramContext, CustomTabsCallback paramCustomTabsCallback, int paramInt) {
    return new CustomTabsSession.PendingSession(paramCustomTabsCallback, createSessionId(paramContext, paramInt));
  }
  
  private CustomTabsSession newSessionInternal(CustomTabsCallback paramCustomTabsCallback, PendingIntent paramPendingIntent) {
    ICustomTabsCallback.Stub stub = createCallbackWrapper(paramCustomTabsCallback);
    if (paramPendingIntent != null)
      try {
        Bundle bundle = new Bundle();
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)paramPendingIntent);
        boolean bool1 = this.mService.newSessionWithExtras((ICustomTabsCallback)stub, bundle);
        return !bool1 ? null : new CustomTabsSession(this.mService, (ICustomTabsCallback)stub, this.mServiceComponentName, paramPendingIntent);
      } catch (RemoteException remoteException) {
        return null;
      }  
    boolean bool = this.mService.newSession((ICustomTabsCallback)remoteException);
    return !bool ? null : new CustomTabsSession(this.mService, (ICustomTabsCallback)remoteException, this.mServiceComponentName, paramPendingIntent);
  }
  
  public CustomTabsSession attachSession(CustomTabsSession.PendingSession paramPendingSession) {
    return newSessionInternal(paramPendingSession.getCallback(), paramPendingSession.getId());
  }
  
  public Bundle extraCommand(String paramString, Bundle paramBundle) {
    try {
      return this.mService.extraCommand(paramString, paramBundle);
    } catch (RemoteException remoteException) {
      return null;
    } 
  }
  
  public CustomTabsSession newSession(CustomTabsCallback paramCustomTabsCallback) {
    return newSessionInternal(paramCustomTabsCallback, null);
  }
  
  public CustomTabsSession newSession(CustomTabsCallback paramCustomTabsCallback, int paramInt) {
    return newSessionInternal(paramCustomTabsCallback, createSessionId(this.mApplicationContext, paramInt));
  }
  
  public boolean warmup(long paramLong) {
    try {
      return this.mService.warmup(paramLong);
    } catch (RemoteException remoteException) {
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\browser\customtabs\CustomTabsClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */