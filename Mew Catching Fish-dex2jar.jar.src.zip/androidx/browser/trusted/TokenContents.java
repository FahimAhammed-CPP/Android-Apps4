package androidx.browser.trusted;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class TokenContents {
  private final byte[] mContents;
  
  private List<byte[]> mFingerprints;
  
  private String mPackageName;
  
  private TokenContents(byte[] paramArrayOfbyte) {
    this.mContents = paramArrayOfbyte;
  }
  
  private TokenContents(byte[] paramArrayOfbyte, String paramString, List<byte[]> paramList) {
    this.mContents = paramArrayOfbyte;
    this.mPackageName = paramString;
    this.mFingerprints = (List)new ArrayList<byte>(paramList.size());
    for (byte[] arrayOfByte : paramList)
      this.mFingerprints.add(Arrays.copyOf(arrayOfByte, arrayOfByte.length)); 
  }
  
  private static int compareByteArrays(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    if (paramArrayOfbyte1 == paramArrayOfbyte2)
      return 0; 
    if (paramArrayOfbyte1 == null)
      return -1; 
    if (paramArrayOfbyte2 == null)
      return 1; 
    int i;
    for (i = 0; i < Math.min(paramArrayOfbyte1.length, paramArrayOfbyte2.length); i++) {
      if (paramArrayOfbyte1[i] != paramArrayOfbyte2[i]) {
        byte b2 = paramArrayOfbyte1[i];
        byte b1 = paramArrayOfbyte2[i];
        i = b2;
        return i - b1;
      } 
    } 
    if (paramArrayOfbyte1.length != paramArrayOfbyte2.length) {
      i = paramArrayOfbyte1.length;
      int j = paramArrayOfbyte2.length;
      return i - j;
    } 
    return 0;
  }
  
  static TokenContents create(String paramString, List<byte[]> paramList) throws IOException {
    return new TokenContents(createToken(paramString, paramList), paramString, paramList);
  }
  
  private static byte[] createToken(String paramString, List<byte[]> paramList) throws IOException {
    Collections.sort((List)paramList, -$$Lambda$TokenContents$EhAh0EiAbuzFn6siY46Fy8sz2WQ.INSTANCE);
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
    dataOutputStream.writeUTF(paramString);
    dataOutputStream.writeInt(paramList.size());
    for (byte[] arrayOfByte : paramList) {
      dataOutputStream.writeInt(arrayOfByte.length);
      dataOutputStream.write(arrayOfByte);
    } 
    dataOutputStream.flush();
    return byteArrayOutputStream.toByteArray();
  }
  
  static TokenContents deserialize(byte[] paramArrayOfbyte) {
    return new TokenContents(paramArrayOfbyte);
  }
  
  private void parseIfNeeded() throws IOException {
    if (this.mPackageName != null)
      return; 
    DataInputStream dataInputStream = new DataInputStream(new ByteArrayInputStream(this.mContents));
    this.mPackageName = dataInputStream.readUTF();
    int j = dataInputStream.readInt();
    this.mFingerprints = (List)new ArrayList<byte>(j);
    int i = 0;
    while (i < j) {
      int k = dataInputStream.readInt();
      byte[] arrayOfByte = new byte[k];
      if (dataInputStream.read(arrayOfByte) == k) {
        this.mFingerprints.add(arrayOfByte);
        i++;
        continue;
      } 
      throw new IllegalStateException("Could not read fingerprint");
    } 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || getClass() != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return Arrays.equals(this.mContents, ((TokenContents)paramObject).mContents);
  }
  
  public byte[] getFingerprint(int paramInt) throws IOException {
    parseIfNeeded();
    List<byte[]> list = this.mFingerprints;
    if (list != null)
      return Arrays.copyOf(list.get(paramInt), ((byte[])this.mFingerprints.get(paramInt)).length); 
    throw new IllegalStateException();
  }
  
  public int getFingerprintCount() throws IOException {
    parseIfNeeded();
    List<byte[]> list = this.mFingerprints;
    if (list != null)
      return list.size(); 
    throw new IllegalStateException();
  }
  
  public String getPackageName() throws IOException {
    parseIfNeeded();
    String str = this.mPackageName;
    if (str != null)
      return str; 
    throw new IllegalStateException();
  }
  
  public int hashCode() {
    return Arrays.hashCode(this.mContents);
  }
  
  public byte[] serialize() {
    byte[] arrayOfByte = this.mContents;
    return Arrays.copyOf(arrayOfByte, arrayOfByte.length);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\browser\trusted\TokenContents.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */