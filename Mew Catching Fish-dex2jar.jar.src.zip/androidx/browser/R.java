package androidx.browser;

public final class R {
  public static final class color {
    public static final int browser_actions_bg_grey = 2131034189;
    
    public static final int browser_actions_divider_color = 2131034190;
    
    public static final int browser_actions_text_color = 2131034191;
    
    public static final int browser_actions_title_color = 2131034192;
  }
  
  public static final class dimen {
    public static final int browser_actions_context_menu_max_width = 2131099784;
    
    public static final int browser_actions_context_menu_min_padding = 2131099785;
  }
  
  public static final class id {
    public static final int browser_actions_header_text = 2131296441;
    
    public static final int browser_actions_menu_item_icon = 2131296442;
    
    public static final int browser_actions_menu_item_text = 2131296443;
    
    public static final int browser_actions_menu_items = 2131296444;
    
    public static final int browser_actions_menu_view = 2131296445;
  }
  
  public static final class layout {
    public static final int browser_actions_context_menu_page = 2131492915;
    
    public static final int browser_actions_context_menu_row = 2131492916;
  }
  
  public static final class string {
    public static final int copy_toast_msg = 2131820713;
    
    public static final int fallback_menu_item_copy_link = 2131820733;
    
    public static final int fallback_menu_item_open_in_browser = 2131820734;
    
    public static final int fallback_menu_item_share_link = 2131820735;
  }
  
  public static final class xml {
    public static final int image_share_filepaths = 2132017153;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\browser\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */