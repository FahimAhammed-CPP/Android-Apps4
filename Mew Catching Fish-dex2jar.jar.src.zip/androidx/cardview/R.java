package androidx.cardview;

public final class R {
  public static final class attr {
    public static final int cardBackgroundColor = 2130903170;
    
    public static final int cardCornerRadius = 2130903171;
    
    public static final int cardElevation = 2130903172;
    
    public static final int cardMaxElevation = 2130903173;
    
    public static final int cardPreventCornerOverlap = 2130903174;
    
    public static final int cardUseCompatPadding = 2130903175;
    
    public static final int cardViewStyle = 2130903176;
    
    public static final int contentPadding = 2130903242;
    
    public static final int contentPaddingBottom = 2130903243;
    
    public static final int contentPaddingLeft = 2130903244;
    
    public static final int contentPaddingRight = 2130903245;
    
    public static final int contentPaddingTop = 2130903246;
  }
  
  public static final class color {
    public static final int cardview_dark_background = 2131034195;
    
    public static final int cardview_light_background = 2131034196;
    
    public static final int cardview_shadow_end_color = 2131034197;
    
    public static final int cardview_shadow_start_color = 2131034198;
  }
  
  public static final class dimen {
    public static final int cardview_compat_inset_shadow = 2131099786;
    
    public static final int cardview_default_elevation = 2131099787;
    
    public static final int cardview_default_radius = 2131099788;
  }
  
  public static final class style {
    public static final int Base_CardView = 2131886124;
    
    public static final int CardView = 2131886277;
    
    public static final int CardView_Dark = 2131886278;
    
    public static final int CardView_Light = 2131886279;
  }
  
  public static final class styleable {
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130903170, 2130903171, 2130903172, 2130903173, 2130903174, 2130903175, 2130903242, 2130903243, 
        2130903244, 2130903245, 2130903246 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\cardview\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */