package androidx.activity;

import androidx.lifecycle.LifecycleOwner;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv = {1, 0, 3}, d1 = {"\000&\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\020\002\n\002\030\002\n\000\0329\020\000\032\0020\001*\0020\0022\n\b\002\020\003\032\004\030\0010\0042\b\b\002\020\005\032\0020\0062\027\020\007\032\023\022\004\022\0020\001\022\004\022\0020\t0\b¢\006\002\b\n¨\006\013"}, d2 = {"addCallback", "Landroidx/activity/OnBackPressedCallback;", "Landroidx/activity/OnBackPressedDispatcher;", "owner", "Landroidx/lifecycle/LifecycleOwner;", "enabled", "", "onBackPressed", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "activity-ktx_release"}, k = 2, mv = {1, 1, 15})
public final class OnBackPressedDispatcherKt {
  public static final OnBackPressedCallback addCallback(OnBackPressedDispatcher paramOnBackPressedDispatcher, LifecycleOwner paramLifecycleOwner, boolean paramBoolean, Function1<? super OnBackPressedCallback, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramOnBackPressedDispatcher, "$this$addCallback");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "onBackPressed");
    OnBackPressedDispatcherKt$addCallback$callback$1 onBackPressedDispatcherKt$addCallback$callback$1 = new OnBackPressedDispatcherKt$addCallback$callback$1(paramFunction1, paramBoolean, paramBoolean);
    if (paramLifecycleOwner != null) {
      paramOnBackPressedDispatcher.addCallback(paramLifecycleOwner, onBackPressedDispatcherKt$addCallback$callback$1);
    } else {
      paramOnBackPressedDispatcher.addCallback(onBackPressedDispatcherKt$addCallback$callback$1);
    } 
    return onBackPressedDispatcherKt$addCallback$callback$1;
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\021\n\000\n\002\030\002\n\000\n\002\020\002\n\000*\001\000\b\n\030\0002\0020\001J\b\020\002\032\0020\003H\026¨\006\004"}, d2 = {"androidx/activity/OnBackPressedDispatcherKt$addCallback$callback$1", "Landroidx/activity/OnBackPressedCallback;", "handleOnBackPressed", "", "activity-ktx_release"}, k = 1, mv = {1, 1, 15})
  public static final class OnBackPressedDispatcherKt$addCallback$callback$1 extends OnBackPressedCallback {
    OnBackPressedDispatcherKt$addCallback$callback$1(Function1 param1Function1, boolean param1Boolean1, boolean param1Boolean2) {
      super(param1Boolean2);
    }
    
    public void handleOnBackPressed() {
      this.$onBackPressed.invoke(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\activity\OnBackPressedDispatcherKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */