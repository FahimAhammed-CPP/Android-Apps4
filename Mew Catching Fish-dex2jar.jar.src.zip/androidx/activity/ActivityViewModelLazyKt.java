package androidx.activity;

import android.app.Application;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Reflection;

@Metadata(bv = {1, 0, 3}, d1 = {"\000\034\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\0321\020\000\032\b\022\004\022\002H\0020\001\"\n\b\000\020\002\030\001*\0020\003*\0020\0042\020\b\n\020\005\032\n\022\004\022\0020\007\030\0010\006H\b¨\006\b"}, d2 = {"viewModels", "Lkotlin/Lazy;", "VM", "Landroidx/lifecycle/ViewModel;", "Landroidx/activity/ComponentActivity;", "factoryProducer", "Lkotlin/Function0;", "Landroidx/lifecycle/ViewModelProvider$Factory;", "activity-ktx_release"}, k = 2, mv = {1, 1, 15})
public final class ActivityViewModelLazyKt {
  private static final <VM extends ViewModel> Lazy<VM> viewModels(ComponentActivity paramComponentActivity, Function0<? extends ViewModelProvider.Factory> paramFunction0) {
    if (paramFunction0 == null)
      paramFunction0 = new ActivityViewModelLazyKt$viewModels$factoryPromise$1(paramComponentActivity); 
    Intrinsics.reifiedOperationMarker(4, "VM");
    return (Lazy<VM>)new ViewModelLazy(Reflection.getOrCreateKotlinClass(ViewModel.class), new ActivityViewModelLazyKt$viewModels$1(paramComponentActivity), paramFunction0);
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/lifecycle/ViewModelStore;", "VM", "Landroidx/lifecycle/ViewModel;", "invoke"}, k = 3, mv = {1, 1, 15})
  public static final class ActivityViewModelLazyKt$viewModels$1 extends Lambda implements Function0<ViewModelStore> {
    public ActivityViewModelLazyKt$viewModels$1(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final ViewModelStore invoke() {
      ViewModelStore viewModelStore = this.$this_viewModels.getViewModelStore();
      Intrinsics.checkExpressionValueIsNotNull(viewModelStore, "viewModelStore");
      return viewModelStore;
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;", "VM", "Landroidx/lifecycle/ViewModel;", "invoke"}, k = 3, mv = {1, 1, 15})
  public static final class ActivityViewModelLazyKt$viewModels$factoryPromise$1 extends Lambda implements Function0<ViewModelProvider.AndroidViewModelFactory> {
    public ActivityViewModelLazyKt$viewModels$factoryPromise$1(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final ViewModelProvider.AndroidViewModelFactory invoke() {
      Application application = this.$this_viewModels.getApplication();
      if (application != null) {
        ViewModelProvider.AndroidViewModelFactory androidViewModelFactory = ViewModelProvider.AndroidViewModelFactory.getInstance(application);
        Intrinsics.checkExpressionValueIsNotNull(androidViewModelFactory, "AndroidViewModelFactory.getInstance(application)");
        return androidViewModelFactory;
      } 
      throw (Throwable)new IllegalArgumentException("ViewModel can be accessed only when Activity is attached");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Mew Catching Fish-dex2jar.jar!\androidx\activity\ActivityViewModelLazyKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */