package a3;

import android.content.Context;
import com.google.android.gms.internal.ads.a00;
import com.google.android.gms.internal.ads.cy;
import com.google.android.gms.internal.ads.le0;
import com.google.android.gms.internal.ads.ly;
import com.google.android.gms.internal.ads.xk0;
import j2.f;
import r2.b3;
import r2.o2;
import r2.t;

public class b {
  private final b3 a;
  
  public b(b3 paramb3) {
    this.a = paramb3;
  }
  
  public static void a(Context paramContext, j2.b paramb, f paramf, c paramc) {
    o2 o2;
    ly.c(paramContext);
    if (((Boolean)a00.k.e()).booleanValue()) {
      cy cy = ly.M8;
      if (((Boolean)t.c().b(cy)).booleanValue()) {
        xk0.b.execute(new d(paramContext, paramb, paramf, paramc));
        return;
      } 
    } 
    if (paramf == null) {
      paramf = null;
    } else {
      o2 = paramf.a();
    } 
    (new le0(paramContext, paramb, o2)).b(paramc);
  }
  
  public String b() {
    return this.a.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a3\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */