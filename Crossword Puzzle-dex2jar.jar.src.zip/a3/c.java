package a3;

public abstract class c {
  public abstract void a(String paramString);
  
  public abstract void b(b paramb);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a3\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */