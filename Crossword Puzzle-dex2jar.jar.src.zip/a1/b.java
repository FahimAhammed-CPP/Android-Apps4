package a1;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.PersistableBundle;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemjob.SystemJobService;
import f1.g;
import f1.p;
import f1.q;
import g1.c;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import x0.j;
import x0.s;
import y0.e;
import y0.i;

public class b implements e {
  private static final String s = j.f("SystemJobScheduler");
  
  private final Context o;
  
  private final JobScheduler p;
  
  private final i q;
  
  private final a r;
  
  public b(Context paramContext, i parami) {
    this(paramContext, parami, (JobScheduler)paramContext.getSystemService("jobscheduler"), new a(paramContext));
  }
  
  public b(Context paramContext, i parami, JobScheduler paramJobScheduler, a parama) {
    this.o = paramContext;
    this.q = parami;
    this.p = paramJobScheduler;
    this.r = parama;
  }
  
  public static void a(Context paramContext) {
    JobScheduler jobScheduler = (JobScheduler)paramContext.getSystemService("jobscheduler");
    if (jobScheduler != null) {
      List<JobInfo> list = g(paramContext, jobScheduler);
      if (list != null && !list.isEmpty()) {
        Iterator<JobInfo> iterator = list.iterator();
        while (iterator.hasNext())
          c(jobScheduler, ((JobInfo)iterator.next()).getId()); 
      } 
    } 
  }
  
  private static void c(JobScheduler paramJobScheduler, int paramInt) {
    try {
      return;
    } finally {
      paramJobScheduler = null;
      j.c().b(s, String.format(Locale.getDefault(), "Exception while trying to cancel job (%d)", new Object[] { Integer.valueOf(paramInt) }), new Throwable[] { (Throwable)paramJobScheduler });
    } 
  }
  
  private static List<Integer> d(Context paramContext, JobScheduler paramJobScheduler, String paramString) {
    List<JobInfo> list = g(paramContext, paramJobScheduler);
    if (list == null)
      return null; 
    ArrayList<Integer> arrayList = new ArrayList(2);
    for (JobInfo jobInfo : list) {
      if (paramString.equals(h(jobInfo)))
        arrayList.add(Integer.valueOf(jobInfo.getId())); 
    } 
    return arrayList;
  }
  
  private static List<JobInfo> g(Context paramContext, JobScheduler paramJobScheduler) {
    ArrayList<JobInfo> arrayList;
    try {
      List list = paramJobScheduler.getAllPendingJobs();
    } finally {
      paramJobScheduler = null;
      j.c().b(s, "getAllPendingJobs() is not reliable on this device.", new Throwable[] { (Throwable)paramJobScheduler });
    } 
    ComponentName componentName = new ComponentName(paramContext, SystemJobService.class);
    for (JobInfo jobInfo : paramJobScheduler) {
      if (componentName.equals(jobInfo.getService()))
        arrayList.add(jobInfo); 
    } 
    return arrayList;
  }
  
  private static String h(JobInfo paramJobInfo) {
    PersistableBundle persistableBundle = paramJobInfo.getExtras();
    if (persistableBundle != null)
      try {
        if (persistableBundle.containsKey("EXTRA_WORK_SPEC_ID"))
          return persistableBundle.getString("EXTRA_WORK_SPEC_ID"); 
      } catch (NullPointerException nullPointerException) {} 
    return null;
  }
  
  public static boolean i(Context paramContext, i parami) {
    boolean bool1;
    boolean bool2;
    JobScheduler jobScheduler = (JobScheduler)paramContext.getSystemService("jobscheduler");
    List<JobInfo> list1 = g(paramContext, jobScheduler);
    List list = parami.o().y().b();
    boolean bool3 = false;
    if (list1 != null) {
      bool1 = list1.size();
    } else {
      bool1 = false;
    } 
    HashSet<String> hashSet = new HashSet(bool1);
    if (list1 != null && !list1.isEmpty())
      for (JobInfo jobInfo : list1) {
        String str = h(jobInfo);
        if (!TextUtils.isEmpty(str)) {
          hashSet.add(str);
          continue;
        } 
        c(jobScheduler, jobInfo.getId());
      }  
    Iterator<String> iterator = list.iterator();
    while (true) {
      bool2 = bool3;
      if (iterator.hasNext()) {
        if (!hashSet.contains(iterator.next())) {
          j.c().a(s, "Reconciling jobs", new Throwable[0]);
          bool2 = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    if (bool2) {
      WorkDatabase workDatabase = parami.o();
      workDatabase.c();
      try {
        q q = workDatabase.B();
        Iterator<String> iterator1 = list.iterator();
        while (iterator1.hasNext())
          q.d(iterator1.next(), -1L); 
        workDatabase.r();
        return bool2;
      } finally {
        workDatabase.g();
      } 
    } 
    return bool2;
  }
  
  public void b(String paramString) {
    List<Integer> list = d(this.o, this.p, paramString);
    if (list != null && !list.isEmpty()) {
      Iterator<Integer> iterator = list.iterator();
      while (iterator.hasNext()) {
        int j = ((Integer)iterator.next()).intValue();
        c(this.p, j);
      } 
      this.q.o().y().d(paramString);
    } 
  }
  
  public boolean e() {
    return true;
  }
  
  public void f(p... paramVarArgs) {
    WorkDatabase workDatabase = this.q.o();
    c c = new c(workDatabase);
    int k = paramVarArgs.length;
    int j = 0;
    while (j < k) {
      p p1 = paramVarArgs[j];
      workDatabase.c();
      try {
        j j1;
        p p2 = workDatabase.B().k(p1.a);
        if (p2 == null) {
          j1 = j.c();
          String str = s;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Skipping scheduling ");
          stringBuilder.append(p1.a);
          stringBuilder.append(" because it's no longer in the DB");
          j1.h(str, stringBuilder.toString(), new Throwable[0]);
          workDatabase.r();
        } else if (((p)j1).b != s.o) {
          j1 = j.c();
          String str = s;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Skipping scheduling ");
          stringBuilder.append(p1.a);
          stringBuilder.append(" because it is no longer enqueued");
          j1.h(str, stringBuilder.toString(), new Throwable[0]);
          workDatabase.r();
        } else {
          int m;
          g g = workDatabase.y().c(p1.a);
          if (g != null) {
            m = g.b;
          } else {
            m = c.d(this.q.i().i(), this.q.i().g());
          } 
          if (g == null) {
            g = new g(p1.a, m);
            this.q.o().y().a(g);
          } 
          j(p1, m);
          if (Build.VERSION.SDK_INT == 23) {
            List<Integer> list = d(this.o, this.p, p1.a);
            if (list != null) {
              m = list.indexOf(Integer.valueOf(m));
              if (m >= 0)
                list.remove(m); 
              if (!list.isEmpty()) {
                m = ((Integer)list.get(0)).intValue();
              } else {
                m = c.d(this.q.i().i(), this.q.i().g());
              } 
              j(p1, m);
            } 
          } 
          workDatabase.r();
        } 
        workDatabase.g();
      } finally {
        workDatabase.g();
      } 
    } 
  }
  
  public void j(p paramp, int paramInt) {
    JobInfo jobInfo = this.r.a(paramp, paramInt);
    j j = j.c();
    String str = s;
    j.a(str, String.format("Scheduling work ID %s Job ID %s", new Object[] { paramp.a, Integer.valueOf(paramInt) }), new Throwable[0]);
    try {
      return;
    } catch (IllegalStateException illegalStateException) {
      List<JobInfo> list = g(this.o, this.p);
      if (list != null) {
        paramInt = list.size();
      } else {
        paramInt = 0;
      } 
      String str1 = String.format(Locale.getDefault(), "JobScheduler 100 job limit exceeded.  We count %d WorkManager jobs in JobScheduler; we have %d tracked jobs in our DB; our Configuration limit is %d.", new Object[] { Integer.valueOf(paramInt), Integer.valueOf(this.q.o().B().r().size()), Integer.valueOf(this.q.i().h()) });
      j.c().b(s, str1, new Throwable[0]);
      throw new IllegalStateException(str1, illegalStateException);
    } finally {
      str = null;
      j.c().b(s, String.format("Unable to schedule %s", new Object[] { illegalStateException }), new Throwable[] { (Throwable)str });
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */