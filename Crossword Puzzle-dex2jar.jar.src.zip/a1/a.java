package a1;

import android.app.job.JobInfo;
import android.content.ComponentName;
import android.content.Context;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.PersistableBundle;
import androidx.work.impl.background.systemjob.SystemJobService;
import f1.p;
import java.util.Iterator;
import x0.b;
import x0.c;
import x0.j;
import x0.k;

class a {
  private static final String b = j.f("SystemJobInfoConverter");
  
  private final ComponentName a;
  
  a(Context paramContext) {
    this.a = new ComponentName(paramContext.getApplicationContext(), SystemJobService.class);
  }
  
  private static JobInfo.TriggerContentUri b(c.a parama) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  static int c(k paramk) {
    int i = a.a[paramk.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i == 5 && Build.VERSION.SDK_INT >= 26)
              return 4; 
          } else if (Build.VERSION.SDK_INT >= 24) {
            return 3;
          } 
          j.c().a(b, String.format("API version too low. Cannot convert network type value %s", new Object[] { paramk }), new Throwable[0]);
          return 1;
        } 
        return 2;
      } 
      return 1;
    } 
    return 0;
  }
  
  static void d(JobInfo.Builder paramBuilder, k paramk) {
    if (Build.VERSION.SDK_INT >= 30 && paramk == k.t) {
      paramBuilder.setRequiredNetwork((new NetworkRequest.Builder()).addCapability(25).build());
      return;
    } 
    paramBuilder.setRequiredNetworkType(c(paramk));
  }
  
  JobInfo a(p paramp, int paramInt) {
    b b = paramp.j;
    PersistableBundle persistableBundle = new PersistableBundle();
    persistableBundle.putString("EXTRA_WORK_SPEC_ID", paramp.a);
    persistableBundle.putBoolean("EXTRA_IS_PERIODIC", paramp.d());
    JobInfo.Builder builder = (new JobInfo.Builder(paramInt, this.a)).setRequiresCharging(b.g()).setRequiresDeviceIdle(b.h()).setExtras(persistableBundle);
    d(builder, b.b());
    boolean bool1 = b.h();
    boolean bool = false;
    if (!bool1) {
      if (paramp.l == x0.a.p) {
        paramInt = 0;
      } else {
        paramInt = 1;
      } 
      builder.setBackoffCriteria(paramp.m, paramInt);
    } 
    long l = Math.max(paramp.a() - System.currentTimeMillis(), 0L);
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt <= 28) {
      builder.setMinimumLatency(l);
    } else if (l > 0L) {
      builder.setMinimumLatency(l);
    } else if (!paramp.q) {
      builder.setImportantWhileForeground(true);
    } 
    if (paramInt >= 24 && b.e()) {
      Iterator<c.a> iterator = b.a().b().iterator();
      while (iterator.hasNext())
        builder.addTriggerContentUri(b(iterator.next())); 
      builder.setTriggerContentUpdateDelay(b.c());
      builder.setTriggerContentMaxDelay(b.d());
    } 
    builder.setPersisted(false);
    if (Build.VERSION.SDK_INT >= 26) {
      builder.setRequiresBatteryNotLow(b.f());
      builder.setRequiresStorageNotLow(b.i());
    } 
    paramInt = bool;
    if (paramp.k > 0)
      paramInt = 1; 
    if (androidx.core.os.a.c() && paramp.q && paramInt == 0)
      builder.setExpedited(true); 
    return builder.build();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */