package a;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface a extends IInterface {
  Bundle I3(String paramString, Bundle paramBundle);
  
  void T4(Bundle paramBundle);
  
  void d5(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle);
  
  void k3(int paramInt, Bundle paramBundle);
  
  void n2(String paramString, Bundle paramBundle);
  
  void y4(String paramString, Bundle paramBundle);
  
  public static abstract class a extends Binder implements a {
    public a() {
      attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      if (param1Int1 != 1598968902) {
        Bundle bundle1;
        Bundle bundle3;
        String str1;
        boolean bool = false;
        String str2 = null;
        Bundle bundle4 = null;
        Bundle bundle6 = null;
        Bundle bundle5 = null;
        Bundle bundle7 = null;
        Bundle bundle2 = null;
        switch (param1Int1) {
          default:
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
          case 7:
            param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            str2 = param1Parcel1.readString();
            if (param1Parcel1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
            bundle1 = I3(str2, bundle2);
            param1Parcel2.writeNoException();
            if (bundle1 != null) {
              param1Parcel2.writeInt(1);
              bundle1.writeToParcel(param1Parcel2, 1);
              return true;
            } 
            param1Parcel2.writeInt(0);
            return true;
          case 6:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            param1Int1 = bundle1.readInt();
            if (bundle1.readInt() != 0) {
              Uri uri = (Uri)Uri.CREATOR.createFromParcel((Parcel)bundle1);
            } else {
              bundle2 = null;
            } 
            if (bundle1.readInt() != 0)
              bool = true; 
            if (bundle1.readInt() != 0)
              bundle3 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            d5(param1Int1, (Uri)bundle2, bool, bundle3);
            param1Parcel2.writeNoException();
            return true;
          case 5:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            str1 = bundle1.readString();
            bundle2 = bundle4;
            if (bundle1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            y4(str1, bundle2);
            param1Parcel2.writeNoException();
            return true;
          case 4:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            bundle2 = bundle6;
            if (bundle1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            T4(bundle2);
            param1Parcel2.writeNoException();
            return true;
          case 3:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            str1 = bundle1.readString();
            bundle2 = bundle5;
            if (bundle1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            n2(str1, bundle2);
            param1Parcel2.writeNoException();
            return true;
          case 2:
            break;
        } 
        bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
        param1Int1 = bundle1.readInt();
        bundle2 = bundle7;
        if (bundle1.readInt() != 0)
          bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
        k3(param1Int1, bundle2);
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel2.writeString("android.support.customtabs.ICustomTabsCallback");
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */