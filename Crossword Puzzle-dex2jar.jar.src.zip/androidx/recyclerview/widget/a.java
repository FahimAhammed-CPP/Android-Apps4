package androidx.recyclerview.widget;

import androidx.core.util.e;
import androidx.core.util.f;
import java.util.ArrayList;
import java.util.List;

class a implements h.a {
  private e<b> a = (e<b>)new f(30);
  
  final ArrayList<b> b = new ArrayList<b>();
  
  final ArrayList<b> c = new ArrayList<b>();
  
  final a d;
  
  Runnable e;
  
  final boolean f;
  
  final h g;
  
  private int h = 0;
  
  a(a parama) {
    this(parama, false);
  }
  
  a(a parama, boolean paramBoolean) {
    this.d = parama;
    this.f = paramBoolean;
    this.g = new h(this);
  }
  
  private void c(b paramb) {
    r(paramb);
  }
  
  private void d(b paramb) {
    r(paramb);
  }
  
  private void f(b paramb) {
    int m = paramb.b;
    int j = paramb.d + m;
    byte b1 = -1;
    int i = m;
    int k;
    for (k = 0; i < j; k = n) {
      int n;
      if (this.d.c(i) != null || h(i)) {
        if (b1 == 0) {
          k(b(2, m, k, null));
          n = 1;
        } else {
          n = 0;
        } 
        b1 = 1;
      } else {
        if (b1 == 1) {
          r(b(2, m, k, null));
          b1 = 1;
        } else {
          b1 = 0;
        } 
        boolean bool = false;
        n = b1;
        b1 = bool;
      } 
      if (n != 0) {
        i -= k;
        j -= k;
        n = 1;
      } else {
        n = k + 1;
      } 
      i++;
    } 
    b b2 = paramb;
    if (k != paramb.d) {
      a(paramb);
      b2 = b(2, m, k, null);
    } 
    if (b1 == 0) {
      k(b2);
      return;
    } 
    r(b2);
  }
  
  private void g(b paramb) {
    int m = paramb.b;
    int i1 = paramb.d;
    int i = m;
    int n = -1;
    int j = 0;
    int k = m;
    while (k < i1 + m) {
      int i3;
      if (this.d.c(k) != null || h(k)) {
        int i4 = i;
        i3 = j;
        if (n == 0) {
          k(b(4, i, j, paramb.c));
          i4 = k;
          i3 = 0;
        } 
        j = 1;
        i = i4;
      } else {
        i3 = i;
        int i4 = j;
        if (n == 1) {
          r(b(4, i, j, paramb.c));
          i3 = k;
          i4 = 0;
        } 
        j = 0;
        i = i3;
        i3 = i4;
      } 
      int i2 = i3 + 1;
      k++;
      n = j;
      j = i2;
    } 
    Object object = paramb;
    if (j != paramb.d) {
      object = paramb.c;
      a(paramb);
      object = b(4, i, j, object);
    } 
    if (n == 0) {
      k((b)object);
      return;
    } 
    r((b)object);
  }
  
  private boolean h(int paramInt) {
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      b b = this.c.get(i);
      int k = b.a;
      if (k == 8) {
        if (n(b.d, i + 1) == paramInt)
          return true; 
      } else if (k == 1) {
        int m = b.b;
        int n = b.d;
        for (k = m; k < n + m; k++) {
          if (n(k, i + 1) == paramInt)
            return true; 
        } 
      } 
    } 
    return false;
  }
  
  private void k(b paramb) {
    int i = paramb.a;
    if (i != 1 && i != 8) {
      byte b1;
      int k = v(paramb.b, i);
      i = paramb.b;
      int j = paramb.a;
      if (j != 2) {
        if (j == 4) {
          b1 = 1;
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("op should be remove or update.");
          stringBuilder.append(paramb);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        b1 = 0;
      } 
      int m = 1;
      j = 1;
      while (m < paramb.d) {
        int n;
        int i1 = v(paramb.b + b1 * m, paramb.a);
        int i2 = paramb.a;
        if ((i2 != 2) ? (i2 == 4 && i1 == k + 1) : (i1 == k)) {
          n = 1;
        } else {
          n = 0;
        } 
        if (n) {
          j++;
        } else {
          b b2 = b(i2, k, j, paramb.c);
          l(b2, i);
          a(b2);
          k = i;
          if (paramb.a == 4)
            k = i + j; 
          n = i1;
          j = 1;
          i = k;
          k = n;
        } 
        m++;
      } 
      Object object = paramb.c;
      a(paramb);
      if (j > 0) {
        paramb = b(paramb.a, k, j, object);
        l(paramb, i);
        a(paramb);
      } 
      return;
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("should not dispatch add or move for pre layout");
    throw illegalArgumentException;
  }
  
  private void r(b paramb) {
    this.c.add(paramb);
    int i = paramb.a;
    if (i != 1) {
      if (i != 2) {
        if (i != 4) {
          if (i == 8) {
            this.d.a(paramb.b, paramb.d);
            return;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown update op type for ");
          stringBuilder.append(paramb);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        this.d.h(paramb.b, paramb.d, paramb.c);
        return;
      } 
      this.d.d(paramb.b, paramb.d);
      return;
    } 
    this.d.e(paramb.b, paramb.d);
  }
  
  private int v(int paramInt1, int paramInt2) {
    int j = this.c.size() - 1;
    int i;
    for (i = paramInt1; j >= 0; i = paramInt1) {
      b b = this.c.get(j);
      int k = b.a;
      if (k == 8) {
        int n;
        int i1;
        k = b.b;
        int m = b.d;
        if (k < m) {
          n = k;
          paramInt1 = m;
          i1 = paramInt1;
        } else {
          i1 = k;
          paramInt1 = m;
          n = paramInt1;
        } 
        if (i >= n && i <= i1) {
          if (n == k) {
            if (paramInt2 == 1) {
              b.d = m + 1;
            } else if (paramInt2 == 2) {
              b.d = m - 1;
            } 
            paramInt1 = i + 1;
          } else {
            if (paramInt2 == 1) {
              b.b = k + 1;
            } else if (paramInt2 == 2) {
              b.b = k - 1;
            } 
            paramInt1 = i - 1;
          } 
        } else {
          paramInt1 = i;
          if (i < k)
            if (paramInt2 == 1) {
              b.b = k + 1;
              b.d = m + 1;
              paramInt1 = i;
            } else {
              paramInt1 = i;
              if (paramInt2 == 2) {
                b.b = k - 1;
                b.d = m - 1;
                paramInt1 = i;
              } 
            }  
        } 
      } else {
        int m = b.b;
        if (m <= i) {
          if (k == 1) {
            paramInt1 = i - b.d;
          } else {
            paramInt1 = i;
            if (k == 2)
              paramInt1 = i + b.d; 
          } 
        } else if (paramInt2 == 1) {
          b.b = m + 1;
          paramInt1 = i;
        } else {
          paramInt1 = i;
          if (paramInt2 == 2) {
            b.b = m - 1;
            paramInt1 = i;
          } 
        } 
      } 
      j--;
    } 
    for (paramInt1 = this.c.size() - 1; paramInt1 >= 0; paramInt1--) {
      b b = this.c.get(paramInt1);
      if (b.a == 8) {
        paramInt2 = b.d;
        if (paramInt2 == b.b || paramInt2 < 0) {
          this.c.remove(paramInt1);
          a(b);
        } 
      } else if (b.d <= 0) {
        this.c.remove(paramInt1);
        a(b);
      } 
    } 
    return i;
  }
  
  public void a(b paramb) {
    if (!this.f) {
      paramb.c = null;
      this.a.a(paramb);
    } 
  }
  
  public b b(int paramInt1, int paramInt2, int paramInt3, Object paramObject) {
    b b = (b)this.a.b();
    if (b == null)
      return new b(paramInt1, paramInt2, paramInt3, paramObject); 
    b.a = paramInt1;
    b.b = paramInt2;
    b.d = paramInt3;
    b.c = paramObject;
    return b;
  }
  
  public int e(int paramInt) {
    int k = this.b.size();
    int j = 0;
    int i;
    for (i = paramInt; j < k; i = paramInt) {
      b b = this.b.get(j);
      paramInt = b.a;
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 8) {
            paramInt = i;
          } else {
            paramInt = b.b;
            if (paramInt == i) {
              paramInt = b.d;
            } else {
              int m = i;
              if (paramInt < i)
                m = i - 1; 
              paramInt = m;
              if (b.d <= m)
                paramInt = m + 1; 
            } 
          } 
        } else {
          int m = b.b;
          paramInt = i;
          if (m <= i) {
            paramInt = b.d;
            if (m + paramInt > i)
              return -1; 
            paramInt = i - paramInt;
          } 
        } 
      } else {
        paramInt = i;
        if (b.b <= i)
          paramInt = i + b.d; 
      } 
      j++;
    } 
    return i;
  }
  
  void i() {
    int j = this.c.size();
    for (int i = 0; i < j; i++)
      this.d.b(this.c.get(i)); 
    t(this.c);
    this.h = 0;
  }
  
  void j() {
    i();
    int j = this.b.size();
    for (int i = 0; i < j; i++) {
      b b = this.b.get(i);
      int k = b.a;
      if (k != 1) {
        if (k != 2) {
          if (k != 4) {
            if (k == 8) {
              this.d.b(b);
              this.d.a(b.b, b.d);
            } 
          } else {
            this.d.b(b);
            this.d.h(b.b, b.d, b.c);
          } 
        } else {
          this.d.b(b);
          this.d.f(b.b, b.d);
        } 
      } else {
        this.d.b(b);
        this.d.e(b.b, b.d);
      } 
      Runnable runnable = this.e;
      if (runnable != null)
        runnable.run(); 
    } 
    t(this.b);
    this.h = 0;
  }
  
  void l(b paramb, int paramInt) {
    this.d.g(paramb);
    int i = paramb.a;
    if (i != 2) {
      if (i == 4) {
        this.d.h(paramInt, paramb.d, paramb.c);
        return;
      } 
      throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
    } 
    this.d.f(paramInt, paramb.d);
  }
  
  int m(int paramInt) {
    return n(paramInt, 0);
  }
  
  int n(int paramInt1, int paramInt2) {
    int j = this.c.size();
    int i = paramInt2;
    for (paramInt2 = paramInt1; i < j; paramInt2 = paramInt1) {
      b b = this.c.get(i);
      int k = b.a;
      if (k == 8) {
        paramInt1 = b.b;
        if (paramInt1 == paramInt2) {
          paramInt1 = b.d;
        } else {
          int m = paramInt2;
          if (paramInt1 < paramInt2)
            m = paramInt2 - 1; 
          paramInt1 = m;
          if (b.d <= m)
            paramInt1 = m + 1; 
        } 
      } else {
        int m = b.b;
        paramInt1 = paramInt2;
        if (m <= paramInt2)
          if (k == 2) {
            paramInt1 = b.d;
            if (paramInt2 < m + paramInt1)
              return -1; 
            paramInt1 = paramInt2 - paramInt1;
          } else {
            paramInt1 = paramInt2;
            if (k == 1)
              paramInt1 = paramInt2 + b.d; 
          }  
      } 
      i++;
    } 
    return paramInt2;
  }
  
  boolean o(int paramInt) {
    return ((paramInt & this.h) != 0);
  }
  
  boolean p() {
    return (this.b.size() > 0);
  }
  
  boolean q() {
    return (!this.c.isEmpty() && !this.b.isEmpty());
  }
  
  void s() {
    this.g.b(this.b);
    int j = this.b.size();
    for (int i = 0; i < j; i++) {
      b b = this.b.get(i);
      int k = b.a;
      if (k != 1) {
        if (k != 2) {
          if (k != 4) {
            if (k == 8)
              d(b); 
          } else {
            g(b);
          } 
        } else {
          f(b);
        } 
      } else {
        c(b);
      } 
      Runnable runnable = this.e;
      if (runnable != null)
        runnable.run(); 
    } 
    this.b.clear();
  }
  
  void t(List<b> paramList) {
    int j = paramList.size();
    for (int i = 0; i < j; i++)
      a(paramList.get(i)); 
    paramList.clear();
  }
  
  void u() {
    t(this.b);
    t(this.c);
    this.h = 0;
  }
  
  static interface a {
    void a(int param1Int1, int param1Int2);
    
    void b(a.b param1b);
    
    RecyclerView.d0 c(int param1Int);
    
    void d(int param1Int1, int param1Int2);
    
    void e(int param1Int1, int param1Int2);
    
    void f(int param1Int1, int param1Int2);
    
    void g(a.b param1b);
    
    void h(int param1Int1, int param1Int2, Object param1Object);
  }
  
  static class b {
    int a;
    
    int b;
    
    Object c;
    
    int d;
    
    b(int param1Int1, int param1Int2, int param1Int3, Object param1Object) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.d = param1Int3;
      this.c = param1Object;
    }
    
    String a() {
      int i = this.a;
      return (i != 1) ? ((i != 2) ? ((i != 4) ? ((i != 8) ? "??" : "mv") : "up") : "rm") : "add";
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        int i = this.a;
        if (i != ((b)param1Object).a)
          return false; 
        if (i == 8 && Math.abs(this.d - this.b) == 1 && this.d == ((b)param1Object).b && this.b == ((b)param1Object).d)
          return true; 
        if (this.d != ((b)param1Object).d)
          return false; 
        if (this.b != ((b)param1Object).b)
          return false; 
        Object object = this.c;
        if (object != null) {
          if (!object.equals(((b)param1Object).c))
            return false; 
        } else if (((b)param1Object).c != null) {
          return false;
        } 
        return true;
      } 
      return false;
    }
    
    public int hashCode() {
      return (this.a * 31 + this.b) * 31 + this.d;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append("[");
      stringBuilder.append(a());
      stringBuilder.append(",s:");
      stringBuilder.append(this.b);
      stringBuilder.append("c:");
      stringBuilder.append(this.d);
      stringBuilder.append(",p:");
      stringBuilder.append(this.c);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\recyclerview\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */