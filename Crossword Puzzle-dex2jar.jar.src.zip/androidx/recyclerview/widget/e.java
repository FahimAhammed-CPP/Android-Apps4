package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import androidx.core.os.l;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

final class e implements Runnable {
  static final ThreadLocal<e> s = new ThreadLocal<e>();
  
  static Comparator<c> t = new a();
  
  ArrayList<RecyclerView> o = new ArrayList<RecyclerView>();
  
  long p;
  
  long q;
  
  private ArrayList<c> r = new ArrayList<c>();
  
  private void b() {
    int k = this.o.size();
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      RecyclerView recyclerView = this.o.get(i);
      int m = j;
      if (recyclerView.getWindowVisibility() == 0) {
        recyclerView.u0.c(recyclerView, false);
        m = j + recyclerView.u0.d;
      } 
      i++;
    } 
    this.r.ensureCapacity(j);
    j = 0;
    for (i = 0; j < k; i = m) {
      int m;
      RecyclerView recyclerView = this.o.get(j);
      if (recyclerView.getWindowVisibility() != 0) {
        m = i;
      } else {
        b b = recyclerView.u0;
        int i1 = Math.abs(b.a) + Math.abs(b.b);
        int n = 0;
        while (true) {
          m = i;
          if (n < b.d * 2) {
            boolean bool;
            c c;
            if (i >= this.r.size()) {
              c = new c();
              this.r.add(c);
            } else {
              c = this.r.get(i);
            } 
            int[] arrayOfInt = b.c;
            m = arrayOfInt[n + 1];
            if (m <= i1) {
              bool = true;
            } else {
              bool = false;
            } 
            c.a = bool;
            c.b = i1;
            c.c = m;
            c.d = recyclerView;
            c.e = arrayOfInt[n];
            i++;
            n += 2;
            continue;
          } 
          break;
        } 
      } 
      j++;
    } 
    Collections.sort(this.r, t);
  }
  
  private void c(c paramc, long paramLong) {
    long l;
    if (paramc.a) {
      l = Long.MAX_VALUE;
    } else {
      l = paramLong;
    } 
    RecyclerView.d0 d0 = i(paramc.d, paramc.e, l);
    if (d0 != null && d0.b != null && d0.s() && !d0.t())
      h(d0.b.get(), paramLong); 
  }
  
  private void d(long paramLong) {
    for (int i = 0; i < this.r.size(); i++) {
      c c = this.r.get(i);
      if (c.d == null)
        return; 
      c(c, paramLong);
      c.a();
    } 
  }
  
  static boolean e(RecyclerView paramRecyclerView, int paramInt) {
    int j = paramRecyclerView.s.j();
    for (int i = 0; i < j; i++) {
      RecyclerView.d0 d0 = RecyclerView.f0(paramRecyclerView.s.i(i));
      if (d0.c == paramInt && !d0.t())
        return true; 
    } 
    return false;
  }
  
  private void h(RecyclerView paramRecyclerView, long paramLong) {
    if (paramRecyclerView == null)
      return; 
    if (paramRecyclerView.R && paramRecyclerView.s.j() != 0)
      paramRecyclerView.T0(); 
    b b = paramRecyclerView.u0;
    b.c(paramRecyclerView, true);
    if (b.d != 0)
      try {
        l.a("RV Nested Prefetch");
        paramRecyclerView.v0.f(paramRecyclerView.z);
        int i;
        for (i = 0; i < b.d * 2; i += 2)
          i(paramRecyclerView, b.c[i], paramLong); 
        return;
      } finally {
        l.b();
      }  
  }
  
  private RecyclerView.d0 i(RecyclerView paramRecyclerView, int paramInt, long paramLong) {
    if (e(paramRecyclerView, paramInt))
      return null; 
    null = paramRecyclerView.p;
    try {
      paramRecyclerView.F0();
      RecyclerView.d0 d0 = null.I(paramInt, false, paramLong);
      if (d0 != null)
        if (d0.s() && !d0.t()) {
          null.B(d0.a);
        } else {
          null.a(d0, false);
        }  
      return d0;
    } finally {
      paramRecyclerView.H0(false);
    } 
  }
  
  public void a(RecyclerView paramRecyclerView) {
    this.o.add(paramRecyclerView);
  }
  
  void f(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    if (paramRecyclerView.isAttachedToWindow() && this.p == 0L) {
      this.p = paramRecyclerView.getNanoTime();
      paramRecyclerView.post(this);
    } 
    paramRecyclerView.u0.e(paramInt1, paramInt2);
  }
  
  void g(long paramLong) {
    b();
    d(paramLong);
  }
  
  public void j(RecyclerView paramRecyclerView) {
    this.o.remove(paramRecyclerView);
  }
  
  public void run() {
    try {
      l.a("RV Prefetch");
      boolean bool = this.o.isEmpty();
      if (!bool) {
        int j = this.o.size();
        int i = 0;
        long l;
        for (l = 0L; i < j; l = l1) {
          RecyclerView recyclerView = this.o.get(i);
          long l1 = l;
          if (recyclerView.getWindowVisibility() == 0)
            l1 = Math.max(recyclerView.getDrawingTime(), l); 
          i++;
        } 
        if (l != 0L) {
          g(TimeUnit.MILLISECONDS.toNanos(l) + this.q);
          return;
        } 
      } 
      return;
    } finally {
      this.p = 0L;
      l.b();
    } 
  }
  
  static final class a implements Comparator<c> {
    public int a(e.c param1c1, e.c param1c2) {
      byte b1;
      RecyclerView recyclerView = param1c1.d;
      byte b2 = 1;
      if (recyclerView == null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (param1c2.d == null) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      if (i != b1)
        return (recyclerView == null) ? 1 : -1; 
      boolean bool = param1c1.a;
      if (bool != param1c2.a) {
        i = b2;
        if (bool)
          i = -1; 
        return i;
      } 
      int i = param1c2.b - param1c1.b;
      if (i != 0)
        return i; 
      i = param1c1.c - param1c2.c;
      return (i != 0) ? i : 0;
    }
  }
  
  @SuppressLint({"VisibleForTests"})
  static class b implements RecyclerView.o.c {
    int a;
    
    int b;
    
    int[] c;
    
    int d;
    
    public void a(int param1Int1, int param1Int2) {
      if (param1Int1 >= 0) {
        if (param1Int2 >= 0) {
          int i = this.d * 2;
          int[] arrayOfInt = this.c;
          if (arrayOfInt == null) {
            arrayOfInt = new int[4];
            this.c = arrayOfInt;
            Arrays.fill(arrayOfInt, -1);
          } else if (i >= arrayOfInt.length) {
            int[] arrayOfInt1 = new int[i * 2];
            this.c = arrayOfInt1;
            System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
          } 
          arrayOfInt = this.c;
          arrayOfInt[i] = param1Int1;
          arrayOfInt[i + 1] = param1Int2;
          this.d++;
          return;
        } 
        throw new IllegalArgumentException("Pixel distance must be non-negative");
      } 
      throw new IllegalArgumentException("Layout positions must be non-negative");
    }
    
    void b() {
      int[] arrayOfInt = this.c;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.d = 0;
    }
    
    void c(RecyclerView param1RecyclerView, boolean param1Boolean) {
      this.d = 0;
      int[] arrayOfInt = this.c;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      RecyclerView.o o = param1RecyclerView.A;
      if (param1RecyclerView.z != null && o != null && o.u0()) {
        if (param1Boolean) {
          if (!param1RecyclerView.r.p())
            o.p(param1RecyclerView.z.c(), this); 
        } else if (!param1RecyclerView.l0()) {
          o.o(this.a, this.b, param1RecyclerView.v0, this);
        } 
        int i = this.d;
        if (i > o.m) {
          o.m = i;
          o.n = param1Boolean;
          param1RecyclerView.p.K();
        } 
      } 
    }
    
    boolean d(int param1Int) {
      if (this.c != null) {
        int j = this.d;
        for (int i = 0; i < j * 2; i += 2) {
          if (this.c[i] == param1Int)
            return true; 
        } 
      } 
      return false;
    }
    
    void e(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
  }
  
  static class c {
    public boolean a;
    
    public int b;
    
    public int c;
    
    public RecyclerView d;
    
    public int e;
    
    public void a() {
      this.a = false;
      this.b = 0;
      this.c = 0;
      this.d = null;
      this.e = 0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\recyclerview\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */