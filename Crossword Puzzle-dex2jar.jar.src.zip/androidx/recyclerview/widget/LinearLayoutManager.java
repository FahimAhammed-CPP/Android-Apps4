package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;

public class LinearLayoutManager extends RecyclerView.o implements RecyclerView.z.b {
  int A = -1;
  
  int B = Integer.MIN_VALUE;
  
  private boolean C;
  
  d D = null;
  
  final a E = new a();
  
  private final b F = new b();
  
  private int G = 2;
  
  private int[] H = new int[2];
  
  int s = 1;
  
  private c t;
  
  i u;
  
  private boolean v;
  
  private boolean w = false;
  
  boolean x = false;
  
  private boolean y = false;
  
  private boolean z = true;
  
  public LinearLayoutManager(Context paramContext, int paramInt, boolean paramBoolean) {
    C2(paramInt);
    D2(paramBoolean);
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.o.d d1 = RecyclerView.o.i0(paramContext, paramAttributeSet, paramInt1, paramInt2);
    C2(d1.a);
    D2(d1.c);
    E2(d1.d);
  }
  
  private void A2() {
    if (this.s == 1 || !q2()) {
      this.x = this.w;
      return;
    } 
    this.x = this.w ^ true;
  }
  
  private boolean F2(RecyclerView.v paramv, RecyclerView.a0 parama0, a parama) {
    View view1;
    int k = J();
    int j = 0;
    if (k == 0)
      return false; 
    View view2 = V();
    if (view2 != null && parama.d(view2, parama0)) {
      parama.c(view2, h0(view2));
      return true;
    } 
    if (this.v != this.y)
      return false; 
    if (parama.d) {
      view1 = i2(paramv, parama0);
    } else {
      view1 = j2((RecyclerView.v)view1, parama0);
    } 
    if (view1 != null) {
      parama.b(view1, h0(view1));
      if (!parama0.e() && L1()) {
        if (this.u.g(view1) >= this.u.i() || this.u.d(view1) < this.u.m())
          j = 1; 
        if (j) {
          if (parama.d) {
            j = this.u.i();
          } else {
            j = this.u.m();
          } 
          parama.c = j;
        } 
      } 
      return true;
    } 
    return false;
  }
  
  private boolean G2(RecyclerView.a0 parama0, a parama) {
    boolean bool = parama0.e();
    boolean bool1 = false;
    if (!bool) {
      int j = this.A;
      if (j == -1)
        return false; 
      if (j < 0 || j >= parama0.b()) {
        this.A = -1;
        this.B = Integer.MIN_VALUE;
        return false;
      } 
      parama.b = this.A;
      d d1 = this.D;
      if (d1 != null && d1.i()) {
        bool = this.D.q;
        parama.d = bool;
        if (bool) {
          parama.c = this.u.i() - this.D.p;
          return true;
        } 
        parama.c = this.u.m() + this.D.p;
        return true;
      } 
      if (this.B == Integer.MIN_VALUE) {
        View view = C(this.A);
        if (view != null) {
          if (this.u.e(view) > this.u.n()) {
            parama.a();
            return true;
          } 
          if (this.u.g(view) - this.u.m() < 0) {
            parama.c = this.u.m();
            parama.d = false;
            return true;
          } 
          if (this.u.i() - this.u.d(view) < 0) {
            parama.c = this.u.i();
            parama.d = true;
            return true;
          } 
          if (parama.d) {
            j = this.u.d(view) + this.u.o();
          } else {
            j = this.u.g(view);
          } 
          parama.c = j;
          return true;
        } 
        if (J() > 0) {
          j = h0(I(0));
          if (this.A < j) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool == this.x)
            bool1 = true; 
          parama.d = bool1;
        } 
        parama.a();
        return true;
      } 
      bool = this.x;
      parama.d = bool;
      if (bool) {
        parama.c = this.u.i() - this.B;
        return true;
      } 
      parama.c = this.u.m() + this.B;
      return true;
    } 
    return false;
  }
  
  private void H2(RecyclerView.v paramv, RecyclerView.a0 parama0, a parama) {
    boolean bool;
    if (G2(parama0, parama))
      return; 
    if (F2(paramv, parama0, parama))
      return; 
    parama.a();
    if (this.y) {
      bool = parama0.b() - 1;
    } else {
      bool = false;
    } 
    parama.b = bool;
  }
  
  private void I2(int paramInt1, int paramInt2, boolean paramBoolean, RecyclerView.a0 parama0) {
    this.t.m = z2();
    this.t.f = paramInt1;
    int[] arrayOfInt = this.H;
    boolean bool1 = false;
    arrayOfInt[0] = 0;
    boolean bool3 = true;
    boolean bool2 = true;
    arrayOfInt[1] = 0;
    M1(parama0, arrayOfInt);
    int j = Math.max(0, this.H[0]);
    int k = Math.max(0, this.H[1]);
    if (paramInt1 == 1)
      bool1 = true; 
    c c1 = this.t;
    if (bool1) {
      paramInt1 = k;
    } else {
      paramInt1 = j;
    } 
    c1.h = paramInt1;
    if (!bool1)
      j = k; 
    c1.i = j;
    if (bool1) {
      c1.h = paramInt1 + this.u.j();
      View view = m2();
      c c2 = this.t;
      paramInt1 = bool2;
      if (this.x)
        paramInt1 = -1; 
      c2.e = paramInt1;
      paramInt1 = h0(view);
      c c3 = this.t;
      c2.d = paramInt1 + c3.e;
      c3.b = this.u.d(view);
      paramInt1 = this.u.d(view) - this.u.i();
    } else {
      View view = n2();
      c c2 = this.t;
      c2.h += this.u.m();
      c2 = this.t;
      if (this.x) {
        paramInt1 = bool3;
      } else {
        paramInt1 = -1;
      } 
      c2.e = paramInt1;
      paramInt1 = h0(view);
      c c3 = this.t;
      c2.d = paramInt1 + c3.e;
      c3.b = this.u.g(view);
      paramInt1 = -this.u.g(view) + this.u.m();
    } 
    c1 = this.t;
    c1.c = paramInt2;
    if (paramBoolean)
      c1.c = paramInt2 - paramInt1; 
    c1.g = paramInt1;
  }
  
  private void J2(int paramInt1, int paramInt2) {
    boolean bool;
    this.t.c = this.u.i() - paramInt2;
    c c1 = this.t;
    if (this.x) {
      bool = true;
    } else {
      bool = true;
    } 
    c1.e = bool;
    c1.d = paramInt1;
    c1.f = 1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  private void K2(a parama) {
    J2(parama.b, parama.c);
  }
  
  private void L2(int paramInt1, int paramInt2) {
    this.t.c = paramInt2 - this.u.m();
    c c1 = this.t;
    c1.d = paramInt1;
    if (this.x) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    } 
    c1.e = paramInt1;
    c1.f = -1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  private void M2(a parama) {
    L2(parama.b, parama.c);
  }
  
  private int O1(RecyclerView.a0 parama0) {
    if (J() == 0)
      return 0; 
    T1();
    return l.a(parama0, this.u, Y1(this.z ^ true, true), X1(this.z ^ true, true), this, this.z);
  }
  
  private int P1(RecyclerView.a0 parama0) {
    if (J() == 0)
      return 0; 
    T1();
    return l.b(parama0, this.u, Y1(this.z ^ true, true), X1(this.z ^ true, true), this, this.z, this.x);
  }
  
  private int Q1(RecyclerView.a0 parama0) {
    if (J() == 0)
      return 0; 
    T1();
    return l.c(parama0, this.u, Y1(this.z ^ true, true), X1(this.z ^ true, true), this, this.z);
  }
  
  private View V1() {
    return d2(0, J());
  }
  
  private View W1(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return h2(paramv, parama0, 0, J(), parama0.b());
  }
  
  private View a2() {
    return d2(J() - 1, -1);
  }
  
  private View b2(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return h2(paramv, parama0, J() - 1, -1, parama0.b());
  }
  
  private View f2() {
    return this.x ? V1() : a2();
  }
  
  private View g2() {
    return this.x ? a2() : V1();
  }
  
  private View i2(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return this.x ? W1(paramv, parama0) : b2(paramv, parama0);
  }
  
  private View j2(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return this.x ? b2(paramv, parama0) : W1(paramv, parama0);
  }
  
  private int k2(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int j = this.u.i() - paramInt;
    if (j > 0) {
      j = -B2(-j, paramv, parama0);
      if (paramBoolean) {
        paramInt = this.u.i() - paramInt + j;
        if (paramInt > 0) {
          this.u.r(paramInt);
          return paramInt + j;
        } 
      } 
      return j;
    } 
    return 0;
  }
  
  private int l2(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int j = paramInt - this.u.m();
    if (j > 0) {
      int k = -B2(j, paramv, parama0);
      j = k;
      if (paramBoolean) {
        paramInt = paramInt + k - this.u.m();
        j = k;
        if (paramInt > 0) {
          this.u.r(-paramInt);
          j = k - paramInt;
        } 
      } 
      return j;
    } 
    return 0;
  }
  
  private View m2() {
    int j;
    if (this.x) {
      j = 0;
    } else {
      j = J() - 1;
    } 
    return I(j);
  }
  
  private View n2() {
    boolean bool;
    if (this.x) {
      bool = J() - 1;
    } else {
      bool = false;
    } 
    return I(bool);
  }
  
  private void t2(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt1, int paramInt2) {
    if (parama0.g() && J() != 0 && !parama0.e()) {
      if (!L1())
        return; 
      List<RecyclerView.d0> list = paramv.k();
      int n = list.size();
      int i1 = h0(I(0));
      int j = 0;
      int m = 0;
      int k = 0;
      while (j < n) {
        RecyclerView.d0 d0 = list.get(j);
        if (!d0.v()) {
          boolean bool;
          int i2 = d0.m();
          byte b1 = 1;
          if (i2 < i1) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool != this.x)
            b1 = -1; 
          if (b1 == -1) {
            m += this.u.e(d0.a);
          } else {
            k += this.u.e(d0.a);
          } 
        } 
        j++;
      } 
      this.t.l = list;
      if (m > 0) {
        L2(h0(n2()), paramInt1);
        c c1 = this.t;
        c1.h = m;
        c1.c = 0;
        c1.a();
        U1(paramv, this.t, parama0, false);
      } 
      if (k > 0) {
        J2(h0(m2()), paramInt2);
        c c1 = this.t;
        c1.h = k;
        c1.c = 0;
        c1.a();
        U1(paramv, this.t, parama0, false);
      } 
      this.t.l = null;
    } 
  }
  
  private void v2(RecyclerView.v paramv, c paramc) {
    if (paramc.a) {
      if (paramc.m)
        return; 
      int j = paramc.g;
      int k = paramc.i;
      if (paramc.f == -1) {
        x2(paramv, j, k);
        return;
      } 
      y2(paramv, j, k);
    } 
  }
  
  private void w2(RecyclerView.v paramv, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    int j = paramInt1;
    if (paramInt2 > paramInt1) {
      while (--paramInt2 >= paramInt1) {
        n1(paramInt2, paramv);
        paramInt2--;
      } 
    } else {
      while (j > paramInt2) {
        n1(j, paramv);
        j--;
      } 
    } 
  }
  
  private void x2(RecyclerView.v paramv, int paramInt1, int paramInt2) {
    int k = J();
    if (paramInt1 < 0)
      return; 
    int j = this.u.h() - paramInt1 + paramInt2;
    if (this.x) {
      for (paramInt1 = 0; paramInt1 < k; paramInt1++) {
        View view = I(paramInt1);
        if (this.u.g(view) < j || this.u.q(view) < j) {
          w2(paramv, 0, paramInt1);
          return;
        } 
      } 
    } else {
      paramInt2 = k - 1;
      for (paramInt1 = paramInt2; paramInt1 >= 0; paramInt1--) {
        View view = I(paramInt1);
        if (this.u.g(view) < j || this.u.q(view) < j) {
          w2(paramv, paramInt2, paramInt1);
          break;
        } 
      } 
    } 
  }
  
  private void y2(RecyclerView.v paramv, int paramInt1, int paramInt2) {
    if (paramInt1 < 0)
      return; 
    int j = paramInt1 - paramInt2;
    paramInt2 = J();
    if (this.x) {
      for (paramInt1 = --paramInt2; paramInt1 >= 0; paramInt1--) {
        View view = I(paramInt1);
        if (this.u.d(view) > j || this.u.p(view) > j) {
          w2(paramv, paramInt2, paramInt1);
          return;
        } 
      } 
    } else {
      for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
        View view = I(paramInt1);
        if (this.u.d(view) > j || this.u.p(view) > j) {
          w2(paramv, 0, paramInt1);
          break;
        } 
      } 
    } 
  }
  
  int B2(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    if (J() != 0) {
      byte b1;
      if (paramInt == 0)
        return 0; 
      T1();
      this.t.a = true;
      if (paramInt > 0) {
        b1 = 1;
      } else {
        b1 = -1;
      } 
      int j = Math.abs(paramInt);
      I2(b1, j, true, parama0);
      c c1 = this.t;
      int k = c1.g + U1(paramv, c1, parama0, false);
      if (k < 0)
        return 0; 
      if (j > k)
        paramInt = b1 * k; 
      this.u.r(-paramInt);
      this.t.k = paramInt;
      return paramInt;
    } 
    return 0;
  }
  
  public View C(int paramInt) {
    int j = J();
    if (j == 0)
      return null; 
    int k = paramInt - h0(I(0));
    if (k >= 0 && k < j) {
      View view = I(k);
      if (h0(view) == paramInt)
        return view; 
    } 
    return super.C(paramInt);
  }
  
  public void C2(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      g(null);
      if (paramInt != this.s || this.u == null) {
        i i1 = i.b(this, paramInt);
        this.u = i1;
        this.E.a = i1;
        this.s = paramInt;
        t1();
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("invalid orientation:");
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public RecyclerView.p D() {
    return new RecyclerView.p(-2, -2);
  }
  
  public void D2(boolean paramBoolean) {
    g(null);
    if (paramBoolean == this.w)
      return; 
    this.w = paramBoolean;
    t1();
  }
  
  public void E2(boolean paramBoolean) {
    g(null);
    if (this.y == paramBoolean)
      return; 
    this.y = paramBoolean;
    t1();
  }
  
  boolean G1() {
    return (X() != 1073741824 && p0() != 1073741824 && q0());
  }
  
  public void I0(RecyclerView paramRecyclerView, RecyclerView.v paramv) {
    super.I0(paramRecyclerView, paramv);
    if (this.C) {
      k1(paramv);
      paramv.c();
    } 
  }
  
  public void I1(RecyclerView paramRecyclerView, RecyclerView.a0 parama0, int paramInt) {
    g g = new g(paramRecyclerView.getContext());
    g.p(paramInt);
    J1(g);
  }
  
  public View J0(View paramView, int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    View view1;
    View view2;
    A2();
    if (J() == 0)
      return null; 
    paramInt = R1(paramInt);
    if (paramInt == Integer.MIN_VALUE)
      return null; 
    T1();
    I2(paramInt, (int)(this.u.n() * 0.33333334F), false, parama0);
    c c1 = this.t;
    c1.g = Integer.MIN_VALUE;
    c1.a = false;
    U1(paramv, c1, parama0, true);
    if (paramInt == -1) {
      view1 = g2();
    } else {
      view1 = f2();
    } 
    if (paramInt == -1) {
      view2 = n2();
    } else {
      view2 = m2();
    } 
    return view2.hasFocusable() ? ((view1 == null) ? null : view2) : view1;
  }
  
  public void K0(AccessibilityEvent paramAccessibilityEvent) {
    super.K0(paramAccessibilityEvent);
    if (J() > 0) {
      paramAccessibilityEvent.setFromIndex(Z1());
      paramAccessibilityEvent.setToIndex(c2());
    } 
  }
  
  public boolean L1() {
    return (this.D == null && this.v == this.y);
  }
  
  protected void M1(RecyclerView.a0 parama0, int[] paramArrayOfint) {
    int k;
    boolean bool;
    int j = o2(parama0);
    if (this.t.f == -1) {
      k = 0;
      bool = j;
    } else {
      bool = false;
      k = j;
    } 
    paramArrayOfint[0] = bool;
    paramArrayOfint[1] = k;
  }
  
  void N1(RecyclerView.a0 parama0, c paramc, RecyclerView.o.c paramc1) {
    int j = paramc.d;
    if (j >= 0 && j < parama0.b())
      paramc1.a(j, Math.max(0, paramc.g)); 
  }
  
  int R1(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 17) ? ((paramInt != 33) ? ((paramInt != 66) ? ((paramInt != 130) ? Integer.MIN_VALUE : ((this.s == 1) ? 1 : Integer.MIN_VALUE)) : ((this.s == 0) ? 1 : Integer.MIN_VALUE)) : ((this.s == 1) ? -1 : Integer.MIN_VALUE)) : ((this.s == 0) ? -1 : Integer.MIN_VALUE)) : ((this.s == 1) ? 1 : (q2() ? -1 : 1))) : ((this.s == 1) ? -1 : (q2() ? 1 : -1));
  }
  
  c S1() {
    return new c();
  }
  
  void T1() {
    if (this.t == null)
      this.t = S1(); 
  }
  
  int U1(RecyclerView.v paramv, c paramc, RecyclerView.a0 parama0, boolean paramBoolean) {
    int m = paramc.c;
    int j = paramc.g;
    if (j != Integer.MIN_VALUE) {
      if (m < 0)
        paramc.g = j + m; 
      v2(paramv, paramc);
    } 
    int k = paramc.c + paramc.h;
    b b1 = this.F;
    while (true) {
      while (true)
        break; 
      if (paramBoolean) {
        k = j;
        if (b1.d)
          break; 
      } 
    } 
    return m - paramc.c;
  }
  
  public void X0(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    a a2;
    c c1;
    d d1 = this.D;
    int m = -1;
    if ((d1 != null || this.A != -1) && parama0.b() == 0) {
      k1(paramv);
      return;
    } 
    d1 = this.D;
    if (d1 != null && d1.i())
      this.A = this.D.o; 
    T1();
    this.t.a = false;
    A2();
    View view = V();
    a a3 = this.E;
    if (!a3.e || this.A != -1 || this.D != null) {
      a3.e();
      a2 = this.E;
      a2.d = this.x ^ this.y;
      H2(paramv, parama0, a2);
      this.E.e = true;
    } else if (a2 != null && (this.u.g((View)a2) >= this.u.i() || this.u.d((View)a2) <= this.u.m())) {
      this.E.c((View)a2, h0((View)a2));
    } 
    c c2 = this.t;
    if (c2.k >= 0) {
      j = 1;
    } else {
      j = -1;
    } 
    c2.f = j;
    int[] arrayOfInt = this.H;
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    M1(parama0, arrayOfInt);
    int n = Math.max(0, this.H[0]) + this.u.m();
    int i1 = Math.max(0, this.H[1]) + this.u.j();
    int j = n;
    int k = i1;
    if (parama0.e()) {
      int i2 = this.A;
      j = n;
      k = i1;
      if (i2 != -1) {
        j = n;
        k = i1;
        if (this.B != Integer.MIN_VALUE) {
          View view1 = C(i2);
          j = n;
          k = i1;
          if (view1 != null) {
            if (this.x) {
              k = this.u.i() - this.u.d(view1);
              j = this.B;
            } else {
              j = this.u.g(view1) - this.u.m();
              k = this.B;
            } 
            j = k - j;
            if (j > 0) {
              j = n + j;
              k = i1;
            } else {
              k = i1 - j;
              j = n;
            } 
          } 
        } 
      } 
    } 
    a a1 = this.E;
    if (a1.d ? this.x : !this.x)
      m = 1; 
    u2(paramv, parama0, a1, m);
    w(paramv);
    this.t.m = z2();
    this.t.j = parama0.e();
    this.t.i = 0;
    a1 = this.E;
    if (a1.d) {
      M2(a1);
      c1 = this.t;
      c1.h = j;
      U1(paramv, c1, parama0, false);
      c1 = this.t;
      m = c1.b;
      i1 = c1.d;
      n = c1.c;
      j = k;
      if (n > 0)
        j = k + n; 
      K2(this.E);
      c1 = this.t;
      c1.h = j;
      c1.d += c1.e;
      U1(paramv, c1, parama0, false);
      c1 = this.t;
      n = c1.b;
      int i2 = c1.c;
      k = m;
      j = n;
      if (i2 > 0) {
        L2(i1, m);
        c1 = this.t;
        c1.h = i2;
        U1(paramv, c1, parama0, false);
        k = this.t.b;
        j = n;
      } 
    } else {
      K2((a)c1);
      c1 = this.t;
      c1.h = k;
      U1(paramv, c1, parama0, false);
      c1 = this.t;
      m = c1.b;
      i1 = c1.d;
      n = c1.c;
      k = j;
      if (n > 0)
        k = j + n; 
      M2(this.E);
      c1 = this.t;
      c1.h = k;
      c1.d += c1.e;
      U1(paramv, c1, parama0, false);
      c1 = this.t;
      n = c1.b;
      int i2 = c1.c;
      k = n;
      j = m;
      if (i2 > 0) {
        J2(i1, m);
        c1 = this.t;
        c1.h = i2;
        U1(paramv, c1, parama0, false);
        j = this.t.b;
        k = n;
      } 
    } 
    n = k;
    m = j;
    if (J() > 0) {
      if ((this.x ^ this.y) != 0) {
        n = k2(j, paramv, parama0, true);
        m = k + n;
        k = j + n;
        j = l2(m, paramv, parama0, false);
      } else {
        n = l2(k, paramv, parama0, true);
        m = k + n;
        k = j + n;
        j = k2(k, paramv, parama0, false);
      } 
      n = m + j;
      m = k + j;
    } 
    t2(paramv, parama0, n, m);
    if (!parama0.e()) {
      this.u.s();
    } else {
      this.E.e();
    } 
    this.v = this.y;
  }
  
  View X1(boolean paramBoolean1, boolean paramBoolean2) {
    return this.x ? e2(0, J(), paramBoolean1, paramBoolean2) : e2(J() - 1, -1, paramBoolean1, paramBoolean2);
  }
  
  public void Y0(RecyclerView.a0 parama0) {
    super.Y0(parama0);
    this.D = null;
    this.A = -1;
    this.B = Integer.MIN_VALUE;
    this.E.e();
  }
  
  View Y1(boolean paramBoolean1, boolean paramBoolean2) {
    return this.x ? e2(J() - 1, -1, paramBoolean1, paramBoolean2) : e2(0, J(), paramBoolean1, paramBoolean2);
  }
  
  public int Z1() {
    View view = e2(0, J(), false, true);
    return (view == null) ? -1 : h0(view);
  }
  
  public PointF a(int paramInt) {
    if (J() == 0)
      return null; 
    boolean bool1 = false;
    int j = h0(I(0));
    boolean bool = true;
    if (paramInt < j)
      bool1 = true; 
    paramInt = bool;
    if (bool1 != this.x)
      paramInt = -1; 
    return (this.s == 0) ? new PointF(paramInt, 0.0F) : new PointF(0.0F, paramInt);
  }
  
  public void c1(Parcelable paramParcelable) {
    if (paramParcelable instanceof d) {
      this.D = (d)paramParcelable;
      t1();
    } 
  }
  
  public int c2() {
    View view = e2(J() - 1, -1, false, true);
    return (view == null) ? -1 : h0(view);
  }
  
  public Parcelable d1() {
    if (this.D != null)
      return new d(this.D); 
    d d1 = new d();
    if (J() > 0) {
      T1();
      int j = this.v ^ this.x;
      d1.q = j;
      if (j != 0) {
        View view1 = m2();
        d1.p = this.u.i() - this.u.d(view1);
        d1.o = h0(view1);
        return d1;
      } 
      View view = n2();
      d1.o = h0(view);
      d1.p = this.u.g(view) - this.u.m();
      return d1;
    } 
    d1.j();
    return d1;
  }
  
  View d2(int paramInt1, int paramInt2) {
    char c1;
    char c2;
    T1();
    if (paramInt2 > paramInt1) {
      c1 = '\001';
    } else if (paramInt2 < paramInt1) {
      c1 = '￿';
    } else {
      c1 = Character.MIN_VALUE;
    } 
    if (!c1)
      return I(paramInt1); 
    if (this.u.g(I(paramInt1)) < this.u.m()) {
      c1 = '䄄';
      c2 = '䀄';
    } else {
      c1 = '၁';
      c2 = 'ခ';
    } 
    return (this.s == 0) ? this.e.a(paramInt1, paramInt2, c1, c2) : this.f.a(paramInt1, paramInt2, c1, c2);
  }
  
  View e2(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    char c1;
    T1();
    char c2 = 'ŀ';
    if (paramBoolean1) {
      c1 = '怃';
    } else {
      c1 = 'ŀ';
    } 
    if (!paramBoolean2)
      c2 = Character.MIN_VALUE; 
    return (this.s == 0) ? this.e.a(paramInt1, paramInt2, c1, c2) : this.f.a(paramInt1, paramInt2, c1, c2);
  }
  
  public void g(String paramString) {
    if (this.D == null)
      super.g(paramString); 
  }
  
  View h2(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt1, int paramInt2, int paramInt3) {
    View view;
    byte b1;
    T1();
    int j = this.u.m();
    int k = this.u.i();
    if (paramInt2 > paramInt1) {
      b1 = 1;
    } else {
      b1 = -1;
    } 
    parama0 = null;
    for (paramv = null; paramInt1 != paramInt2; paramv = v1) {
      View view1;
      View view2 = I(paramInt1);
      int m = h0(view2);
      RecyclerView.a0 a01 = parama0;
      RecyclerView.v v1 = paramv;
      if (m >= 0) {
        a01 = parama0;
        v1 = paramv;
        if (m < paramInt3)
          if (((RecyclerView.p)view2.getLayoutParams()).c()) {
            a01 = parama0;
            v1 = paramv;
            if (paramv == null) {
              View view3 = view2;
              a01 = parama0;
            } 
          } else if (this.u.g(view2) >= k || this.u.d(view2) < j) {
            a01 = parama0;
            v1 = paramv;
            if (parama0 == null) {
              view1 = view2;
              v1 = paramv;
            } 
          } else {
            return view2;
          }  
      } 
      paramInt1 += b1;
      view = view1;
    } 
    return (View)((view != null) ? view : paramv);
  }
  
  public boolean k() {
    return (this.s == 0);
  }
  
  public boolean l() {
    return (this.s == 1);
  }
  
  public void o(int paramInt1, int paramInt2, RecyclerView.a0 parama0, RecyclerView.o.c paramc) {
    if (this.s != 0)
      paramInt1 = paramInt2; 
    if (J() != 0) {
      if (paramInt1 == 0)
        return; 
      T1();
      if (paramInt1 > 0) {
        paramInt2 = 1;
      } else {
        paramInt2 = -1;
      } 
      I2(paramInt2, Math.abs(paramInt1), true, parama0);
      N1(parama0, this.t, paramc);
    } 
  }
  
  @Deprecated
  protected int o2(RecyclerView.a0 parama0) {
    return parama0.d() ? this.u.n() : 0;
  }
  
  public void p(int paramInt, RecyclerView.o.c paramc) {
    int j;
    boolean bool;
    d d1 = this.D;
    byte b1 = -1;
    if (d1 != null && d1.i()) {
      d1 = this.D;
      bool = d1.q;
      j = d1.o;
    } else {
      A2();
      boolean bool1 = this.x;
      int m = this.A;
      j = m;
      bool = bool1;
      if (m == -1)
        if (bool1) {
          j = paramInt - 1;
          bool = bool1;
        } else {
          j = 0;
          bool = bool1;
        }  
    } 
    if (!bool)
      b1 = 1; 
    int k;
    for (k = 0; k < this.G && j >= 0 && j < paramInt; k++) {
      paramc.a(j, 0);
      j += b1;
    } 
  }
  
  public int p2() {
    return this.s;
  }
  
  public int q(RecyclerView.a0 parama0) {
    return O1(parama0);
  }
  
  protected boolean q2() {
    return (Z() == 1);
  }
  
  public int r(RecyclerView.a0 parama0) {
    return P1(parama0);
  }
  
  public boolean r2() {
    return this.z;
  }
  
  public int s(RecyclerView.a0 parama0) {
    return Q1(parama0);
  }
  
  public boolean s0() {
    return true;
  }
  
  void s2(RecyclerView.v paramv, RecyclerView.a0 parama0, c paramc, b paramb) {
    int j;
    int k;
    int m;
    int n;
    View view = paramc.d(paramv);
    if (view == null) {
      paramb.b = true;
      return;
    } 
    RecyclerView.p p = (RecyclerView.p)view.getLayoutParams();
    if (paramc.l == null) {
      boolean bool1;
      boolean bool2 = this.x;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        d(view);
      } else {
        e(view, 0);
      } 
    } else {
      boolean bool1;
      boolean bool2 = this.x;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        b(view);
      } else {
        c(view, 0);
      } 
    } 
    A0(view, 0, 0);
    paramb.a = this.u.e(view);
    if (this.s == 1) {
      if (q2()) {
        j = o0() - f0();
        k = j - this.u.f(view);
      } else {
        k = e0();
        j = this.u.f(view) + k;
      } 
      if (paramc.f == -1) {
        n = paramc.b;
        int i2 = paramb.a;
        m = n;
        int i1 = j;
        j = n - i2;
        n = k;
        k = i1;
      } else {
        n = paramc.b;
        int i2 = paramb.a;
        m = n;
        int i1 = j;
        i2 += n;
        n = k;
        j = m;
        k = i1;
        m = i2;
      } 
    } else {
      n = g0();
      j = this.u.f(view) + n;
      if (paramc.f == -1) {
        int i2 = paramc.b;
        int i3 = paramb.a;
        k = i2;
        int i1 = n;
        m = j;
        n = i2 - i3;
        j = i1;
      } else {
        int i1 = paramc.b;
        k = paramb.a;
        k += i1;
        m = j;
        j = n;
        n = i1;
      } 
    } 
    z0(view, n, j, k, m);
    if (p.c() || p.b())
      paramb.c = true; 
    paramb.d = view.hasFocusable();
  }
  
  public int t(RecyclerView.a0 parama0) {
    return O1(parama0);
  }
  
  public int u(RecyclerView.a0 parama0) {
    return P1(parama0);
  }
  
  void u2(RecyclerView.v paramv, RecyclerView.a0 parama0, a parama, int paramInt) {}
  
  public int v(RecyclerView.a0 parama0) {
    return Q1(parama0);
  }
  
  public int w1(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.s == 1) ? 0 : B2(paramInt, paramv, parama0);
  }
  
  public void x1(int paramInt) {
    this.A = paramInt;
    this.B = Integer.MIN_VALUE;
    d d1 = this.D;
    if (d1 != null)
      d1.j(); 
    t1();
  }
  
  public int y1(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.s == 0) ? 0 : B2(paramInt, paramv, parama0);
  }
  
  boolean z2() {
    return (this.u.k() == 0 && this.u.h() == 0);
  }
  
  static class a {
    i a;
    
    int b;
    
    int c;
    
    boolean d;
    
    boolean e;
    
    a() {
      e();
    }
    
    void a() {
      int j;
      if (this.d) {
        j = this.a.i();
      } else {
        j = this.a.m();
      } 
      this.c = j;
    }
    
    public void b(View param1View, int param1Int) {
      if (this.d) {
        this.c = this.a.d(param1View) + this.a.o();
      } else {
        this.c = this.a.g(param1View);
      } 
      this.b = param1Int;
    }
    
    public void c(View param1View, int param1Int) {
      int j = this.a.o();
      if (j >= 0) {
        b(param1View, param1Int);
        return;
      } 
      this.b = param1Int;
      if (this.d) {
        param1Int = this.a.i() - j - this.a.d(param1View);
        this.c = this.a.i() - param1Int;
        if (param1Int > 0) {
          j = this.a.e(param1View);
          int k = this.c;
          int m = this.a.m();
          j = k - j - m + Math.min(this.a.g(param1View) - m, 0);
          if (j < 0) {
            this.c += Math.min(param1Int, -j);
            return;
          } 
        } 
      } else {
        int k = this.a.g(param1View);
        param1Int = k - this.a.m();
        this.c = k;
        if (param1Int > 0) {
          int m = this.a.e(param1View);
          int n = this.a.i();
          int i1 = this.a.d(param1View);
          j = this.a.i() - Math.min(0, n - j - i1) - k + m;
          if (j < 0)
            this.c -= Math.min(param1Int, -j); 
        } 
      } 
    }
    
    boolean d(View param1View, RecyclerView.a0 param1a0) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      return (!p.c() && p.a() >= 0 && p.a() < param1a0.b());
    }
    
    void e() {
      this.b = -1;
      this.c = Integer.MIN_VALUE;
      this.d = false;
      this.e = false;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AnchorInfo{mPosition=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mCoordinate=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mLayoutFromEnd=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mValid=");
      stringBuilder.append(this.e);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  protected static class b {
    public int a;
    
    public boolean b;
    
    public boolean c;
    
    public boolean d;
    
    void a() {
      this.a = 0;
      this.b = false;
      this.c = false;
      this.d = false;
    }
  }
  
  static class c {
    boolean a = true;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    int g;
    
    int h = 0;
    
    int i = 0;
    
    boolean j = false;
    
    int k;
    
    List<RecyclerView.d0> l = null;
    
    boolean m;
    
    private View e() {
      int j = this.l.size();
      for (int i = 0; i < j; i++) {
        View view = ((RecyclerView.d0)this.l.get(i)).a;
        RecyclerView.p p = (RecyclerView.p)view.getLayoutParams();
        if (!p.c() && this.d == p.a()) {
          b(view);
          return view;
        } 
      } 
      return null;
    }
    
    public void a() {
      b(null);
    }
    
    public void b(View param1View) {
      param1View = f(param1View);
      if (param1View == null) {
        this.d = -1;
        return;
      } 
      this.d = ((RecyclerView.p)param1View.getLayoutParams()).a();
    }
    
    boolean c(RecyclerView.a0 param1a0) {
      int i = this.d;
      return (i >= 0 && i < param1a0.b());
    }
    
    View d(RecyclerView.v param1v) {
      if (this.l != null)
        return e(); 
      View view = param1v.o(this.d);
      this.d += this.e;
      return view;
    }
    
    public View f(View param1View) {
      int k = this.l.size();
      View view = null;
      int j = Integer.MAX_VALUE;
      int i = 0;
      while (i < k) {
        View view2 = ((RecyclerView.d0)this.l.get(i)).a;
        RecyclerView.p p = (RecyclerView.p)view2.getLayoutParams();
        View view1 = view;
        int m = j;
        if (view2 != param1View)
          if (p.c()) {
            view1 = view;
            m = j;
          } else {
            int n = (p.a() - this.d) * this.e;
            if (n < 0) {
              view1 = view;
              m = j;
            } else {
              view1 = view;
              m = j;
              if (n < j) {
                view1 = view2;
                if (n == 0)
                  return view1; 
                m = n;
              } 
            } 
          }  
        i++;
        view = view1;
        j = m;
      } 
      return view;
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = new a();
    
    int o;
    
    int p;
    
    boolean q;
    
    public d() {}
    
    d(Parcel param1Parcel) {
      this.o = param1Parcel.readInt();
      this.p = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.q = bool;
    }
    
    public d(d param1d) {
      this.o = param1d.o;
      this.p = param1d.p;
      this.q = param1d.q;
    }
    
    public int describeContents() {
      return 0;
    }
    
    boolean i() {
      return (this.o >= 0);
    }
    
    void j() {
      this.o = -1;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    static final class a implements Parcelable.Creator<d> {
      public LinearLayoutManager.d a(Parcel param2Parcel) {
        return new LinearLayoutManager.d(param2Parcel);
      }
      
      public LinearLayoutManager.d[] b(int param2Int) {
        return new LinearLayoutManager.d[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<d> {
    public LinearLayoutManager.d a(Parcel param1Parcel) {
      return new LinearLayoutManager.d(param1Parcel);
    }
    
    public LinearLayoutManager.d[] b(int param1Int) {
      return new LinearLayoutManager.d[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\recyclerview\widget\LinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */