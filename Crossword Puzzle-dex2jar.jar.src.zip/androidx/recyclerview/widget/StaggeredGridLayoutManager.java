package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

public class StaggeredGridLayoutManager extends RecyclerView.o implements RecyclerView.z.b {
  boolean A = false;
  
  private BitSet B;
  
  int C = -1;
  
  int D = Integer.MIN_VALUE;
  
  d E = new d();
  
  private int F = 2;
  
  private boolean G;
  
  private boolean H;
  
  private e I;
  
  private int J;
  
  private final Rect K = new Rect();
  
  private final b L = new b(this);
  
  private boolean M = false;
  
  private boolean N = true;
  
  private int[] O;
  
  private final Runnable P = new a(this);
  
  private int s = -1;
  
  f[] t;
  
  i u;
  
  i v;
  
  private int w;
  
  private int x;
  
  private final f y;
  
  boolean z = false;
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.o.d d1 = RecyclerView.o.i0(paramContext, paramAttributeSet, paramInt1, paramInt2);
    H2(d1.a);
    J2(d1.b);
    I2(d1.c);
    this.y = new f();
    a2();
  }
  
  private void A2(RecyclerView.v paramv, f paramf) {
    if (paramf.a) {
      if (paramf.i)
        return; 
      if (paramf.b == 0) {
        if (paramf.e == -1) {
          B2(paramv, paramf.g);
          return;
        } 
        C2(paramv, paramf.f);
        return;
      } 
      if (paramf.e == -1) {
        int k = paramf.f;
        k -= m2(k);
        if (k < 0) {
          k = paramf.g;
        } else {
          k = paramf.g - Math.min(k, paramf.b);
        } 
        B2(paramv, k);
        return;
      } 
      int j = n2(paramf.g) - paramf.g;
      if (j < 0) {
        j = paramf.f;
      } else {
        int k = paramf.f;
        j = Math.min(j, paramf.b) + k;
      } 
      C2(paramv, j);
    } 
  }
  
  private void B2(RecyclerView.v paramv, int paramInt) {
    int j = J() - 1;
    while (j >= 0) {
      View view = I(j);
      if (this.u.g(view) >= paramInt && this.u.q(view) >= paramInt) {
        c c = (c)view.getLayoutParams();
        if (c.f) {
          int m;
          byte b1 = 0;
          int k = 0;
          while (true) {
            m = b1;
            if (k < this.s) {
              if ((this.t[k]).a.size() == 1)
                return; 
              k++;
              continue;
            } 
            break;
          } 
          while (m < this.s) {
            this.t[m].s();
            m++;
          } 
        } else {
          if (c.e.a.size() == 1)
            return; 
          c.e.s();
        } 
        m1(view, paramv);
        j--;
      } 
    } 
  }
  
  private void C2(RecyclerView.v paramv, int paramInt) {
    while (J() > 0) {
      byte b1 = 0;
      View view = I(0);
      if (this.u.d(view) <= paramInt && this.u.p(view) <= paramInt) {
        c c = (c)view.getLayoutParams();
        if (c.f) {
          int k;
          int j = 0;
          while (true) {
            k = b1;
            if (j < this.s) {
              if ((this.t[j]).a.size() == 1)
                return; 
              j++;
              continue;
            } 
            break;
          } 
          while (k < this.s) {
            this.t[k].t();
            k++;
          } 
        } else {
          if (c.e.a.size() == 1)
            return; 
          c.e.t();
        } 
        m1(view, paramv);
      } 
    } 
  }
  
  private void D2() {
    if (this.v.k() == 1073741824)
      return; 
    float f1 = 0.0F;
    int n = J();
    int k = 0;
    int j;
    for (j = 0; j < n; j++) {
      View view = I(j);
      float f2 = this.v.e(view);
      if (f2 >= f1) {
        float f3 = f2;
        if (((c)view.getLayoutParams()).f())
          f3 = f2 * 1.0F / this.s; 
        f1 = Math.max(f1, f3);
      } 
    } 
    int i1 = this.x;
    int m = Math.round(f1 * this.s);
    j = m;
    if (this.v.k() == Integer.MIN_VALUE)
      j = Math.min(m, this.v.n()); 
    P2(j);
    j = k;
    if (this.x == i1)
      return; 
    while (j < n) {
      View view = I(j);
      c c = (c)view.getLayoutParams();
      if (!c.f)
        if (t2() && this.w == 1) {
          k = this.s;
          m = c.e.e;
          view.offsetLeftAndRight(-(k - 1 - m) * this.x - -(k - 1 - m) * i1);
        } else {
          m = c.e.e;
          k = this.x * m;
          m *= i1;
          if (this.w == 1) {
            view.offsetLeftAndRight(k - m);
          } else {
            view.offsetTopAndBottom(k - m);
          } 
        }  
      j++;
    } 
  }
  
  private void E2() {
    if (this.w == 1 || !t2()) {
      this.A = this.z;
      return;
    } 
    this.A = this.z ^ true;
  }
  
  private void G2(int paramInt) {
    boolean bool1;
    f f1 = this.y;
    f1.e = paramInt;
    boolean bool2 = this.A;
    boolean bool = true;
    if (paramInt == -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 == bool1) {
      paramInt = bool;
    } else {
      paramInt = -1;
    } 
    f1.d = paramInt;
  }
  
  private void K2(int paramInt1, int paramInt2) {
    for (int j = 0; j < this.s; j++) {
      if (!(this.t[j]).a.isEmpty())
        Q2(this.t[j], paramInt1, paramInt2); 
    } 
  }
  
  private boolean L2(RecyclerView.a0 parama0, b paramb) {
    int j;
    if (this.G) {
      j = g2(parama0.b());
    } else {
      j = c2(parama0.b());
    } 
    paramb.a = j;
    paramb.b = Integer.MIN_VALUE;
    return true;
  }
  
  private void M1(View paramView) {
    for (int j = this.s - 1; j >= 0; j--)
      this.t[j].a(paramView); 
  }
  
  private void N1(b paramb) {
    e e1 = this.I;
    int j = e1.q;
    if (j > 0)
      if (j == this.s) {
        for (j = 0; j < this.s; j++) {
          this.t[j].e();
          e1 = this.I;
          int m = e1.r[j];
          int k = m;
          if (m != Integer.MIN_VALUE) {
            if (e1.w) {
              k = this.u.i();
            } else {
              k = this.u.m();
            } 
            k = m + k;
          } 
          this.t[j].v(k);
        } 
      } else {
        e1.j();
        e1 = this.I;
        e1.o = e1.p;
      }  
    e1 = this.I;
    this.H = e1.x;
    I2(e1.v);
    E2();
    e1 = this.I;
    j = e1.o;
    if (j != -1) {
      this.C = j;
      paramb.c = e1.w;
    } else {
      paramb.c = this.A;
    } 
    if (e1.s > 1) {
      d d1 = this.E;
      d1.a = e1.t;
      d1.b = e1.u;
    } 
  }
  
  private void O2(int paramInt, RecyclerView.a0 parama0) {
    // Byte code:
    //   0: aload_0
    //   1: getfield y : Landroidx/recyclerview/widget/f;
    //   4: astore #7
    //   6: iconst_0
    //   7: istore #5
    //   9: aload #7
    //   11: iconst_0
    //   12: putfield b : I
    //   15: aload #7
    //   17: iload_1
    //   18: putfield c : I
    //   21: aload_0
    //   22: invokevirtual x0 : ()Z
    //   25: ifeq -> 89
    //   28: aload_2
    //   29: invokevirtual c : ()I
    //   32: istore_3
    //   33: iload_3
    //   34: iconst_m1
    //   35: if_icmpeq -> 89
    //   38: aload_0
    //   39: getfield A : Z
    //   42: istore #6
    //   44: iload_3
    //   45: iload_1
    //   46: if_icmpge -> 55
    //   49: iconst_1
    //   50: istore #4
    //   52: goto -> 58
    //   55: iconst_0
    //   56: istore #4
    //   58: iload #6
    //   60: iload #4
    //   62: if_icmpne -> 76
    //   65: aload_0
    //   66: getfield u : Landroidx/recyclerview/widget/i;
    //   69: invokevirtual n : ()I
    //   72: istore_1
    //   73: goto -> 91
    //   76: aload_0
    //   77: getfield u : Landroidx/recyclerview/widget/i;
    //   80: invokevirtual n : ()I
    //   83: istore_3
    //   84: iconst_0
    //   85: istore_1
    //   86: goto -> 93
    //   89: iconst_0
    //   90: istore_1
    //   91: iconst_0
    //   92: istore_3
    //   93: aload_0
    //   94: invokevirtual M : ()Z
    //   97: ifeq -> 135
    //   100: aload_0
    //   101: getfield y : Landroidx/recyclerview/widget/f;
    //   104: aload_0
    //   105: getfield u : Landroidx/recyclerview/widget/i;
    //   108: invokevirtual m : ()I
    //   111: iload_3
    //   112: isub
    //   113: putfield f : I
    //   116: aload_0
    //   117: getfield y : Landroidx/recyclerview/widget/f;
    //   120: aload_0
    //   121: getfield u : Landroidx/recyclerview/widget/i;
    //   124: invokevirtual i : ()I
    //   127: iload_1
    //   128: iadd
    //   129: putfield g : I
    //   132: goto -> 160
    //   135: aload_0
    //   136: getfield y : Landroidx/recyclerview/widget/f;
    //   139: aload_0
    //   140: getfield u : Landroidx/recyclerview/widget/i;
    //   143: invokevirtual h : ()I
    //   146: iload_1
    //   147: iadd
    //   148: putfield g : I
    //   151: aload_0
    //   152: getfield y : Landroidx/recyclerview/widget/f;
    //   155: iload_3
    //   156: ineg
    //   157: putfield f : I
    //   160: aload_0
    //   161: getfield y : Landroidx/recyclerview/widget/f;
    //   164: astore_2
    //   165: aload_2
    //   166: iconst_0
    //   167: putfield h : Z
    //   170: aload_2
    //   171: iconst_1
    //   172: putfield a : Z
    //   175: iload #5
    //   177: istore #4
    //   179: aload_0
    //   180: getfield u : Landroidx/recyclerview/widget/i;
    //   183: invokevirtual k : ()I
    //   186: ifne -> 206
    //   189: iload #5
    //   191: istore #4
    //   193: aload_0
    //   194: getfield u : Landroidx/recyclerview/widget/i;
    //   197: invokevirtual h : ()I
    //   200: ifne -> 206
    //   203: iconst_1
    //   204: istore #4
    //   206: aload_2
    //   207: iload #4
    //   209: putfield i : Z
    //   212: return
  }
  
  private void Q1(View paramView, c paramc, f paramf) {
    if (paramf.e == 1) {
      if (paramc.f) {
        M1(paramView);
        return;
      } 
      paramc.e.a(paramView);
      return;
    } 
    if (paramc.f) {
      z2(paramView);
      return;
    } 
    paramc.e.u(paramView);
  }
  
  private void Q2(f paramf, int paramInt1, int paramInt2) {
    int j = paramf.j();
    if (paramInt1 == -1) {
      if (paramf.o() + j <= paramInt2) {
        this.B.set(paramf.e, false);
        return;
      } 
    } else if (paramf.k() - j >= paramInt2) {
      this.B.set(paramf.e, false);
    } 
  }
  
  private int R1(int paramInt) {
    boolean bool;
    int j = J();
    byte b1 = -1;
    if (j == 0) {
      paramInt = b1;
      if (this.A)
        paramInt = 1; 
      return paramInt;
    } 
    if (paramInt < j2()) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool != this.A) ? -1 : 1;
  }
  
  private int R2(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0 && paramInt3 == 0)
      return paramInt1; 
    int j = View.MeasureSpec.getMode(paramInt1);
    return (j == Integer.MIN_VALUE || j == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), j) : paramInt1;
  }
  
  private boolean T1(f paramf) {
    if (this.A) {
      if (paramf.k() < this.u.i()) {
        ArrayList<View> arrayList = paramf.a;
        return (paramf.n((View)arrayList.get(arrayList.size() - 1))).f ^ true;
      } 
    } else if (paramf.o() > this.u.m()) {
      return (paramf.n((View)paramf.a.get(0))).f ^ true;
    } 
    return false;
  }
  
  private int U1(RecyclerView.a0 parama0) {
    return (J() == 0) ? 0 : l.a(parama0, this.u, e2(this.N ^ true), d2(this.N ^ true), this, this.N);
  }
  
  private int V1(RecyclerView.a0 parama0) {
    return (J() == 0) ? 0 : l.b(parama0, this.u, e2(this.N ^ true), d2(this.N ^ true), this, this.N, this.A);
  }
  
  private int W1(RecyclerView.a0 parama0) {
    return (J() == 0) ? 0 : l.c(parama0, this.u, e2(this.N ^ true), d2(this.N ^ true), this, this.N);
  }
  
  private int X1(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 17) ? ((paramInt != 33) ? ((paramInt != 66) ? ((paramInt != 130) ? Integer.MIN_VALUE : ((this.w == 1) ? 1 : Integer.MIN_VALUE)) : ((this.w == 0) ? 1 : Integer.MIN_VALUE)) : ((this.w == 1) ? -1 : Integer.MIN_VALUE)) : ((this.w == 0) ? -1 : Integer.MIN_VALUE)) : ((this.w == 1) ? 1 : (t2() ? -1 : 1))) : ((this.w == 1) ? -1 : (t2() ? 1 : -1));
  }
  
  private d.a Y1(int paramInt) {
    d.a a = new d.a();
    a.q = new int[this.s];
    for (int j = 0; j < this.s; j++)
      a.q[j] = paramInt - this.t[j].l(paramInt); 
    return a;
  }
  
  private d.a Z1(int paramInt) {
    d.a a = new d.a();
    a.q = new int[this.s];
    for (int j = 0; j < this.s; j++)
      a.q[j] = this.t[j].p(paramInt) - paramInt; 
    return a;
  }
  
  private void a2() {
    this.u = i.b(this, this.w);
    this.v = i.b(this, 1 - this.w);
  }
  
  private int b2(RecyclerView.v paramv, f paramf, RecyclerView.a0 parama0) {
    int j;
    int m;
    this.B.set(0, this.s, true);
    if (this.y.i) {
      if (paramf.e == 1) {
        j = Integer.MAX_VALUE;
      } else {
        j = Integer.MIN_VALUE;
      } 
    } else if (paramf.e == 1) {
      j = paramf.g + paramf.b;
    } else {
      j = paramf.f - paramf.b;
    } 
    K2(paramf.e, j);
    if (this.A) {
      m = this.u.i();
    } else {
      m = this.u.m();
    } 
    int k;
    for (k = 0; paramf.a(parama0) && (this.y.i || !this.B.isEmpty()); k = 1) {
      int n;
      int i1;
      int i2;
      f f1;
      View view = paramf.b(paramv);
      c c = (c)view.getLayoutParams();
      int i3 = c.a();
      k = this.E.g(i3);
      if (k == -1) {
        i2 = 1;
      } else {
        i2 = 0;
      } 
      if (i2) {
        if (c.f) {
          f1 = this.t[0];
        } else {
          f1 = p2(paramf);
        } 
        this.E.n(i3, f1);
      } else {
        f1 = this.t[k];
      } 
      c.e = f1;
      if (paramf.e == 1) {
        d(view);
      } else {
        e(view, 0);
      } 
      v2(view, c, false);
      if (paramf.e == 1) {
        if (c.f) {
          k = l2(m);
        } else {
          k = f1.l(m);
        } 
        n = this.u.e(view);
        if (i2 && c.f) {
          d.a a = Y1(k);
          a.p = -1;
          a.o = i3;
          this.E.a(a);
        } 
        i1 = n + k;
        n = k;
      } else {
        if (c.f) {
          k = o2(m);
        } else {
          k = f1.p(m);
        } 
        n = k - this.u.e(view);
        if (i2 && c.f) {
          d.a a = Z1(k);
          a.p = 1;
          a.o = i3;
          this.E.a(a);
        } 
        i1 = k;
      } 
      if (c.f && paramf.d == -1)
        if (i2) {
          this.M = true;
        } else {
          boolean bool;
          if (paramf.e == 1) {
            bool = O1();
          } else {
            bool = P1();
          } 
          if ((bool ^ true) != 0) {
            d.a a = this.E.f(i3);
            if (a != null)
              a.r = true; 
            this.M = true;
          } 
        }  
      Q1(view, c, paramf);
      if (t2() && this.w == 1) {
        if (c.f) {
          k = this.v.i();
        } else {
          k = this.v.i() - (this.s - 1 - f1.e) * this.x;
        } 
        i3 = this.v.e(view);
        i2 = k;
        k -= i3;
        i3 = i2;
      } else {
        if (c.f) {
          k = this.v.m();
        } else {
          k = f1.e * this.x + this.v.m();
        } 
        i3 = this.v.e(view);
        i2 = k;
        i3 += k;
        k = i2;
      } 
      if (this.w == 1) {
        z0(view, k, n, i3, i1);
      } else {
        z0(view, n, k, i1, i3);
      } 
      if (c.f) {
        K2(this.y.e, j);
      } else {
        Q2(f1, this.y.e, j);
      } 
      A2(paramv, this.y);
      if (this.y.h && view.hasFocusable())
        if (c.f) {
          this.B.clear();
        } else {
          this.B.set(f1.e, false);
        }  
    } 
    if (k == 0)
      A2(paramv, this.y); 
    if (this.y.e == -1) {
      j = o2(this.u.m());
      j = this.u.m() - j;
    } else {
      j = l2(this.u.i()) - this.u.i();
    } 
    return (j > 0) ? Math.min(paramf.b, j) : 0;
  }
  
  private int c2(int paramInt) {
    int k = J();
    for (int j = 0; j < k; j++) {
      int m = h0(I(j));
      if (m >= 0 && m < paramInt)
        return m; 
    } 
    return 0;
  }
  
  private int g2(int paramInt) {
    for (int j = J() - 1; j >= 0; j--) {
      int k = h0(I(j));
      if (k >= 0 && k < paramInt)
        return k; 
    } 
    return 0;
  }
  
  private void h2(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int j = l2(-2147483648);
    if (j == Integer.MIN_VALUE)
      return; 
    j = this.u.i() - j;
    if (j > 0) {
      j -= -F2(-j, paramv, parama0);
      if (paramBoolean && j > 0)
        this.u.r(j); 
    } 
  }
  
  private void i2(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int j = o2(2147483647);
    if (j == Integer.MAX_VALUE)
      return; 
    j -= this.u.m();
    if (j > 0) {
      j -= F2(j, paramv, parama0);
      if (paramBoolean && j > 0)
        this.u.r(-j); 
    } 
  }
  
  private int l2(int paramInt) {
    int k = this.t[0].l(paramInt);
    int j = 1;
    while (j < this.s) {
      int n = this.t[j].l(paramInt);
      int m = k;
      if (n > k)
        m = n; 
      j++;
      k = m;
    } 
    return k;
  }
  
  private int m2(int paramInt) {
    int k = this.t[0].p(paramInt);
    int j = 1;
    while (j < this.s) {
      int n = this.t[j].p(paramInt);
      int m = k;
      if (n > k)
        m = n; 
      j++;
      k = m;
    } 
    return k;
  }
  
  private int n2(int paramInt) {
    int k = this.t[0].l(paramInt);
    int j = 1;
    while (j < this.s) {
      int n = this.t[j].l(paramInt);
      int m = k;
      if (n < k)
        m = n; 
      j++;
      k = m;
    } 
    return k;
  }
  
  private int o2(int paramInt) {
    int k = this.t[0].p(paramInt);
    int j = 1;
    while (j < this.s) {
      int n = this.t[j].p(paramInt);
      int m = k;
      if (n < k)
        m = n; 
      j++;
      k = m;
    } 
    return k;
  }
  
  private f p2(f paramf) {
    int j;
    byte b1;
    boolean bool = x2(paramf.e);
    int k = -1;
    if (bool) {
      j = this.s - 1;
      b1 = -1;
    } else {
      j = 0;
      k = this.s;
      b1 = 1;
    } 
    int m = paramf.e;
    f f2 = null;
    paramf = null;
    if (m == 1) {
      f f3;
      m = Integer.MAX_VALUE;
      int i1 = this.u.m();
      while (j != k) {
        f2 = this.t[j];
        int i3 = f2.l(i1);
        int i2 = m;
        if (i3 < m) {
          f3 = f2;
          i2 = i3;
        } 
        j += b1;
        m = i2;
      } 
      return f3;
    } 
    m = Integer.MIN_VALUE;
    int n = this.u.i();
    f f1 = f2;
    while (j != k) {
      f2 = this.t[j];
      int i2 = f2.p(n);
      int i1 = m;
      if (i2 > m) {
        f1 = f2;
        i1 = i2;
      } 
      j += b1;
      m = i1;
    } 
    return f1;
  }
  
  private void q2(int paramInt1, int paramInt2, int paramInt3) {
    if (this.A) {
      int k = k2();
    } else {
      int k = j2();
    } 
    if (paramInt3 == 8) {
      if (paramInt1 < paramInt2) {
        int k = paramInt2 + 1;
      } else {
        int k = paramInt1 + 1;
        int m = paramInt2;
        this.E.h(m);
      } 
    } else {
      int k = paramInt1 + paramInt2;
    } 
    int j = paramInt1;
    this.E.h(j);
  }
  
  private void u2(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    j(paramView, this.K);
    c c = (c)paramView.getLayoutParams();
    int j = c.leftMargin;
    Rect rect = this.K;
    paramInt1 = R2(paramInt1, j + rect.left, c.rightMargin + rect.right);
    j = c.topMargin;
    rect = this.K;
    paramInt2 = R2(paramInt2, j + rect.top, c.bottomMargin + rect.bottom);
    if (paramBoolean) {
      paramBoolean = H1(paramView, paramInt1, paramInt2, c);
    } else {
      paramBoolean = F1(paramView, paramInt1, paramInt2, c);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  private void v2(View paramView, c paramc, boolean paramBoolean) {
    if (paramc.f) {
      if (this.w == 1) {
        u2(paramView, this.J, RecyclerView.o.K(W(), X(), g0() + d0(), paramc.height, true), paramBoolean);
        return;
      } 
      u2(paramView, RecyclerView.o.K(o0(), p0(), e0() + f0(), paramc.width, true), this.J, paramBoolean);
      return;
    } 
    if (this.w == 1) {
      u2(paramView, RecyclerView.o.K(this.x, p0(), 0, paramc.width, false), RecyclerView.o.K(W(), X(), g0() + d0(), paramc.height, true), paramBoolean);
      return;
    } 
    u2(paramView, RecyclerView.o.K(o0(), p0(), e0() + f0(), paramc.width, true), RecyclerView.o.K(this.x, X(), 0, paramc.height, false), paramBoolean);
  }
  
  private void w2(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield L : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   4: astore #8
    //   6: aload_0
    //   7: getfield I : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   10: ifnonnull -> 21
    //   13: aload_0
    //   14: getfield C : I
    //   17: iconst_m1
    //   18: if_icmpeq -> 39
    //   21: aload_2
    //   22: invokevirtual b : ()I
    //   25: ifne -> 39
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual k1 : (Landroidx/recyclerview/widget/RecyclerView$v;)V
    //   33: aload #8
    //   35: invokevirtual c : ()V
    //   38: return
    //   39: aload #8
    //   41: getfield e : Z
    //   44: istore #7
    //   46: iconst_1
    //   47: istore #5
    //   49: iload #7
    //   51: ifeq -> 78
    //   54: aload_0
    //   55: getfield C : I
    //   58: iconst_m1
    //   59: if_icmpne -> 78
    //   62: aload_0
    //   63: getfield I : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   66: ifnull -> 72
    //   69: goto -> 78
    //   72: iconst_0
    //   73: istore #4
    //   75: goto -> 81
    //   78: iconst_1
    //   79: istore #4
    //   81: iload #4
    //   83: ifeq -> 133
    //   86: aload #8
    //   88: invokevirtual c : ()V
    //   91: aload_0
    //   92: getfield I : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   95: ifnull -> 107
    //   98: aload_0
    //   99: aload #8
    //   101: invokespecial N1 : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;)V
    //   104: goto -> 120
    //   107: aload_0
    //   108: invokespecial E2 : ()V
    //   111: aload #8
    //   113: aload_0
    //   114: getfield A : Z
    //   117: putfield c : Z
    //   120: aload_0
    //   121: aload_2
    //   122: aload #8
    //   124: invokevirtual N2 : (Landroidx/recyclerview/widget/RecyclerView$a0;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;)V
    //   127: aload #8
    //   129: iconst_1
    //   130: putfield e : Z
    //   133: aload_0
    //   134: getfield I : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   137: ifnonnull -> 184
    //   140: aload_0
    //   141: getfield C : I
    //   144: iconst_m1
    //   145: if_icmpne -> 184
    //   148: aload #8
    //   150: getfield c : Z
    //   153: aload_0
    //   154: getfield G : Z
    //   157: if_icmpne -> 171
    //   160: aload_0
    //   161: invokevirtual t2 : ()Z
    //   164: aload_0
    //   165: getfield H : Z
    //   168: if_icmpeq -> 184
    //   171: aload_0
    //   172: getfield E : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   175: invokevirtual b : ()V
    //   178: aload #8
    //   180: iconst_1
    //   181: putfield d : Z
    //   184: aload_0
    //   185: invokevirtual J : ()I
    //   188: ifle -> 395
    //   191: aload_0
    //   192: getfield I : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   195: astore #9
    //   197: aload #9
    //   199: ifnull -> 211
    //   202: aload #9
    //   204: getfield q : I
    //   207: iconst_1
    //   208: if_icmpge -> 395
    //   211: aload #8
    //   213: getfield d : Z
    //   216: ifeq -> 276
    //   219: iconst_0
    //   220: istore #4
    //   222: iload #4
    //   224: aload_0
    //   225: getfield s : I
    //   228: if_icmpge -> 395
    //   231: aload_0
    //   232: getfield t : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   235: iload #4
    //   237: aaload
    //   238: invokevirtual e : ()V
    //   241: aload #8
    //   243: getfield b : I
    //   246: istore #6
    //   248: iload #6
    //   250: ldc -2147483648
    //   252: if_icmpeq -> 267
    //   255: aload_0
    //   256: getfield t : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   259: iload #4
    //   261: aaload
    //   262: iload #6
    //   264: invokevirtual v : (I)V
    //   267: iload #4
    //   269: iconst_1
    //   270: iadd
    //   271: istore #4
    //   273: goto -> 222
    //   276: iload #4
    //   278: ifne -> 344
    //   281: aload_0
    //   282: getfield L : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   285: getfield f : [I
    //   288: ifnonnull -> 294
    //   291: goto -> 344
    //   294: iconst_0
    //   295: istore #4
    //   297: iload #4
    //   299: aload_0
    //   300: getfield s : I
    //   303: if_icmpge -> 395
    //   306: aload_0
    //   307: getfield t : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   310: iload #4
    //   312: aaload
    //   313: astore #9
    //   315: aload #9
    //   317: invokevirtual e : ()V
    //   320: aload #9
    //   322: aload_0
    //   323: getfield L : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   326: getfield f : [I
    //   329: iload #4
    //   331: iaload
    //   332: invokevirtual v : (I)V
    //   335: iload #4
    //   337: iconst_1
    //   338: iadd
    //   339: istore #4
    //   341: goto -> 297
    //   344: iconst_0
    //   345: istore #4
    //   347: iload #4
    //   349: aload_0
    //   350: getfield s : I
    //   353: if_icmpge -> 384
    //   356: aload_0
    //   357: getfield t : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   360: iload #4
    //   362: aaload
    //   363: aload_0
    //   364: getfield A : Z
    //   367: aload #8
    //   369: getfield b : I
    //   372: invokevirtual b : (ZI)V
    //   375: iload #4
    //   377: iconst_1
    //   378: iadd
    //   379: istore #4
    //   381: goto -> 347
    //   384: aload_0
    //   385: getfield L : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   388: aload_0
    //   389: getfield t : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   392: invokevirtual d : ([Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;)V
    //   395: aload_0
    //   396: aload_1
    //   397: invokevirtual w : (Landroidx/recyclerview/widget/RecyclerView$v;)V
    //   400: aload_0
    //   401: getfield y : Landroidx/recyclerview/widget/f;
    //   404: iconst_0
    //   405: putfield a : Z
    //   408: aload_0
    //   409: iconst_0
    //   410: putfield M : Z
    //   413: aload_0
    //   414: aload_0
    //   415: getfield v : Landroidx/recyclerview/widget/i;
    //   418: invokevirtual n : ()I
    //   421: invokevirtual P2 : (I)V
    //   424: aload_0
    //   425: aload #8
    //   427: getfield a : I
    //   430: aload_2
    //   431: invokespecial O2 : (ILandroidx/recyclerview/widget/RecyclerView$a0;)V
    //   434: aload #8
    //   436: getfield c : Z
    //   439: ifeq -> 497
    //   442: aload_0
    //   443: iconst_m1
    //   444: invokespecial G2 : (I)V
    //   447: aload_0
    //   448: aload_1
    //   449: aload_0
    //   450: getfield y : Landroidx/recyclerview/widget/f;
    //   453: aload_2
    //   454: invokespecial b2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/f;Landroidx/recyclerview/widget/RecyclerView$a0;)I
    //   457: pop
    //   458: aload_0
    //   459: iconst_1
    //   460: invokespecial G2 : (I)V
    //   463: aload_0
    //   464: getfield y : Landroidx/recyclerview/widget/f;
    //   467: astore #9
    //   469: aload #9
    //   471: aload #8
    //   473: getfield a : I
    //   476: aload #9
    //   478: getfield d : I
    //   481: iadd
    //   482: putfield c : I
    //   485: aload_0
    //   486: aload_1
    //   487: aload #9
    //   489: aload_2
    //   490: invokespecial b2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/f;Landroidx/recyclerview/widget/RecyclerView$a0;)I
    //   493: pop
    //   494: goto -> 549
    //   497: aload_0
    //   498: iconst_1
    //   499: invokespecial G2 : (I)V
    //   502: aload_0
    //   503: aload_1
    //   504: aload_0
    //   505: getfield y : Landroidx/recyclerview/widget/f;
    //   508: aload_2
    //   509: invokespecial b2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/f;Landroidx/recyclerview/widget/RecyclerView$a0;)I
    //   512: pop
    //   513: aload_0
    //   514: iconst_m1
    //   515: invokespecial G2 : (I)V
    //   518: aload_0
    //   519: getfield y : Landroidx/recyclerview/widget/f;
    //   522: astore #9
    //   524: aload #9
    //   526: aload #8
    //   528: getfield a : I
    //   531: aload #9
    //   533: getfield d : I
    //   536: iadd
    //   537: putfield c : I
    //   540: aload_0
    //   541: aload_1
    //   542: aload #9
    //   544: aload_2
    //   545: invokespecial b2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/f;Landroidx/recyclerview/widget/RecyclerView$a0;)I
    //   548: pop
    //   549: aload_0
    //   550: invokespecial D2 : ()V
    //   553: aload_0
    //   554: invokevirtual J : ()I
    //   557: ifle -> 598
    //   560: aload_0
    //   561: getfield A : Z
    //   564: ifeq -> 584
    //   567: aload_0
    //   568: aload_1
    //   569: aload_2
    //   570: iconst_1
    //   571: invokespecial h2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   574: aload_0
    //   575: aload_1
    //   576: aload_2
    //   577: iconst_0
    //   578: invokespecial i2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   581: goto -> 598
    //   584: aload_0
    //   585: aload_1
    //   586: aload_2
    //   587: iconst_1
    //   588: invokespecial i2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   591: aload_0
    //   592: aload_1
    //   593: aload_2
    //   594: iconst_0
    //   595: invokespecial h2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   598: iload_3
    //   599: ifeq -> 674
    //   602: aload_2
    //   603: invokevirtual e : ()Z
    //   606: ifne -> 674
    //   609: aload_0
    //   610: getfield F : I
    //   613: ifeq -> 643
    //   616: aload_0
    //   617: invokevirtual J : ()I
    //   620: ifle -> 643
    //   623: aload_0
    //   624: getfield M : Z
    //   627: ifne -> 637
    //   630: aload_0
    //   631: invokevirtual r2 : ()Landroid/view/View;
    //   634: ifnull -> 643
    //   637: iconst_1
    //   638: istore #4
    //   640: goto -> 646
    //   643: iconst_0
    //   644: istore #4
    //   646: iload #4
    //   648: ifeq -> 674
    //   651: aload_0
    //   652: aload_0
    //   653: getfield P : Ljava/lang/Runnable;
    //   656: invokevirtual o1 : (Ljava/lang/Runnable;)Z
    //   659: pop
    //   660: aload_0
    //   661: invokevirtual S1 : ()Z
    //   664: ifeq -> 674
    //   667: iload #5
    //   669: istore #4
    //   671: goto -> 677
    //   674: iconst_0
    //   675: istore #4
    //   677: aload_2
    //   678: invokevirtual e : ()Z
    //   681: ifeq -> 691
    //   684: aload_0
    //   685: getfield L : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   688: invokevirtual c : ()V
    //   691: aload_0
    //   692: aload #8
    //   694: getfield c : Z
    //   697: putfield G : Z
    //   700: aload_0
    //   701: aload_0
    //   702: invokevirtual t2 : ()Z
    //   705: putfield H : Z
    //   708: iload #4
    //   710: ifeq -> 727
    //   713: aload_0
    //   714: getfield L : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   717: invokevirtual c : ()V
    //   720: aload_0
    //   721: aload_1
    //   722: aload_2
    //   723: iconst_0
    //   724: invokespecial w2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   727: return
  }
  
  private boolean x2(int paramInt) {
    boolean bool;
    if (this.w == 0) {
      if (paramInt == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return (bool != this.A);
    } 
    if (paramInt == -1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.A) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool == t2());
  }
  
  private void z2(View paramView) {
    for (int j = this.s - 1; j >= 0; j--)
      this.t[j].u(paramView); 
  }
  
  public void C0(int paramInt) {
    super.C0(paramInt);
    for (int j = 0; j < this.s; j++)
      this.t[j].r(paramInt); 
  }
  
  public void C1(Rect paramRect, int paramInt1, int paramInt2) {
    int j = e0() + f0();
    int k = g0() + d0();
    if (this.w == 1) {
      paramInt2 = RecyclerView.o.n(paramInt2, paramRect.height() + k, b0());
      j = RecyclerView.o.n(paramInt1, this.x * this.s + j, c0());
      paramInt1 = paramInt2;
      paramInt2 = j;
    } else {
      paramInt1 = RecyclerView.o.n(paramInt1, paramRect.width() + j, c0());
      j = RecyclerView.o.n(paramInt2, this.x * this.s + k, b0());
      paramInt2 = paramInt1;
      paramInt1 = j;
    } 
    B1(paramInt2, paramInt1);
  }
  
  public RecyclerView.p D() {
    return (this.w == 0) ? new c(-2, -1) : new c(-1, -2);
  }
  
  public void D0(int paramInt) {
    super.D0(paramInt);
    for (int j = 0; j < this.s; j++)
      this.t[j].r(paramInt); 
  }
  
  public RecyclerView.p E(Context paramContext, AttributeSet paramAttributeSet) {
    return new c(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.p F(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new c((ViewGroup.MarginLayoutParams)paramLayoutParams) : new c(paramLayoutParams);
  }
  
  int F2(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    if (J() != 0) {
      if (paramInt == 0)
        return 0; 
      y2(paramInt, parama0);
      int j = b2(paramv, this.y, parama0);
      if (this.y.b >= j)
        if (paramInt < 0) {
          paramInt = -j;
        } else {
          paramInt = j;
        }  
      this.u.r(-paramInt);
      this.G = this.A;
      f f1 = this.y;
      f1.b = 0;
      A2(paramv, f1);
      return paramInt;
    } 
    return 0;
  }
  
  public void H2(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      g(null);
      if (paramInt == this.w)
        return; 
      this.w = paramInt;
      i i1 = this.u;
      this.u = this.v;
      this.v = i1;
      t1();
      return;
    } 
    throw new IllegalArgumentException("invalid orientation.");
  }
  
  public void I0(RecyclerView paramRecyclerView, RecyclerView.v paramv) {
    super.I0(paramRecyclerView, paramv);
    o1(this.P);
    for (int j = 0; j < this.s; j++)
      this.t[j].e(); 
    paramRecyclerView.requestLayout();
  }
  
  public void I1(RecyclerView paramRecyclerView, RecyclerView.a0 parama0, int paramInt) {
    g g = new g(paramRecyclerView.getContext());
    g.p(paramInt);
    J1(g);
  }
  
  public void I2(boolean paramBoolean) {
    g(null);
    e e1 = this.I;
    if (e1 != null && e1.v != paramBoolean)
      e1.v = paramBoolean; 
    this.z = paramBoolean;
    t1();
  }
  
  public View J0(View paramView, int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    if (J() == 0)
      return null; 
    paramView = B(paramView);
    if (paramView == null)
      return null; 
    E2();
    int m = X1(paramInt);
    if (m == Integer.MIN_VALUE)
      return null; 
    c c = (c)paramView.getLayoutParams();
    boolean bool1 = c.f;
    f f1 = c.e;
    if (m == 1) {
      paramInt = k2();
    } else {
      paramInt = j2();
    } 
    O2(paramInt, parama0);
    G2(m);
    f f2 = this.y;
    f2.c = f2.d + paramInt;
    f2.b = (int)(this.u.n() * 0.33333334F);
    f2 = this.y;
    f2.h = true;
    int k = 0;
    f2.a = false;
    b2(paramv, f2, parama0);
    this.G = this.A;
    if (!bool1) {
      View view = f1.m(paramInt, m);
      if (view != null && view != paramView)
        return view; 
    } 
    if (x2(m)) {
      int n;
      for (n = this.s - 1; n >= 0; n--) {
        View view = this.t[n].m(paramInt, m);
        if (view != null && view != paramView)
          return view; 
      } 
    } else {
      int n;
      for (n = 0; n < this.s; n++) {
        View view = this.t[n].m(paramInt, m);
        if (view != null && view != paramView)
          return view; 
      } 
    } 
    boolean bool2 = this.z;
    if (m == -1) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if ((bool2 ^ true) == paramInt) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (!bool1) {
      int n;
      if (paramInt != 0) {
        n = f1.f();
      } else {
        n = f1.g();
      } 
      View view = C(n);
      if (view != null && view != paramView)
        return view; 
    } 
    int j = k;
    if (x2(m)) {
      for (j = this.s - 1; j >= 0; j--) {
        if (j != f1.e) {
          if (paramInt != 0) {
            k = this.t[j].f();
          } else {
            k = this.t[j].g();
          } 
          View view = C(k);
          if (view != null && view != paramView)
            return view; 
        } 
      } 
    } else {
      while (j < this.s) {
        if (paramInt != 0) {
          k = this.t[j].f();
        } else {
          k = this.t[j].g();
        } 
        View view = C(k);
        if (view != null && view != paramView)
          return view; 
        j++;
      } 
    } 
    return null;
  }
  
  public void J2(int paramInt) {
    g(null);
    if (paramInt != this.s) {
      s2();
      this.s = paramInt;
      this.B = new BitSet(this.s);
      this.t = new f[this.s];
      for (paramInt = 0; paramInt < this.s; paramInt++)
        this.t[paramInt] = new f(this, paramInt); 
      t1();
    } 
  }
  
  public void K0(AccessibilityEvent paramAccessibilityEvent) {
    super.K0(paramAccessibilityEvent);
    if (J() > 0) {
      View view1 = e2(false);
      View view2 = d2(false);
      if (view1 != null) {
        if (view2 == null)
          return; 
        int j = h0(view1);
        int k = h0(view2);
        if (j < k) {
          paramAccessibilityEvent.setFromIndex(j);
          paramAccessibilityEvent.setToIndex(k);
          return;
        } 
        paramAccessibilityEvent.setFromIndex(k);
        paramAccessibilityEvent.setToIndex(j);
      } 
    } 
  }
  
  public boolean L1() {
    return (this.I == null);
  }
  
  boolean M2(RecyclerView.a0 parama0, b paramb) {
    boolean bool1 = parama0.e();
    boolean bool = false;
    if (!bool1) {
      int j = this.C;
      if (j == -1)
        return false; 
      if (j < 0 || j >= parama0.b()) {
        this.C = -1;
        this.D = Integer.MIN_VALUE;
        return false;
      } 
      e e1 = this.I;
      if (e1 == null || e1.o == -1 || e1.q < 1) {
        View view = C(this.C);
        if (view != null) {
          if (this.A) {
            j = k2();
          } else {
            j = j2();
          } 
          paramb.a = j;
          if (this.D != Integer.MIN_VALUE) {
            if (paramb.c) {
              paramb.b = this.u.i() - this.D - this.u.d(view);
              return true;
            } 
            paramb.b = this.u.m() + this.D - this.u.g(view);
            return true;
          } 
          if (this.u.e(view) > this.u.n()) {
            if (paramb.c) {
              j = this.u.i();
            } else {
              j = this.u.m();
            } 
            paramb.b = j;
            return true;
          } 
          j = this.u.g(view) - this.u.m();
          if (j < 0) {
            paramb.b = -j;
            return true;
          } 
          j = this.u.i() - this.u.d(view);
          if (j < 0) {
            paramb.b = j;
            return true;
          } 
          paramb.b = Integer.MIN_VALUE;
          return true;
        } 
        j = this.C;
        paramb.a = j;
        int k = this.D;
        if (k == Integer.MIN_VALUE) {
          if (R1(j) == 1)
            bool = true; 
          paramb.c = bool;
          paramb.a();
        } else {
          paramb.b(k);
        } 
        paramb.d = true;
        return true;
      } 
      paramb.b = Integer.MIN_VALUE;
      paramb.a = this.C;
      return true;
    } 
    return false;
  }
  
  public int N(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.w == 1) ? this.s : super.N(paramv, parama0);
  }
  
  void N2(RecyclerView.a0 parama0, b paramb) {
    if (M2(parama0, paramb))
      return; 
    if (L2(parama0, paramb))
      return; 
    paramb.a();
    paramb.a = 0;
  }
  
  boolean O1() {
    int k = this.t[0].l(-2147483648);
    for (int j = 1; j < this.s; j++) {
      if (this.t[j].l(-2147483648) != k)
        return false; 
    } 
    return true;
  }
  
  public void P0(RecyclerView.v paramv, RecyclerView.a0 parama0, View paramView, androidx.core.view.accessibility.d paramd) {
    boolean bool;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof c)) {
      O0(paramView, paramd);
      return;
    } 
    c c = (c)layoutParams;
    if (this.w == 0) {
      int k = c.e();
      if (c.f) {
        bool = this.s;
      } else {
        bool = true;
      } 
      paramd.Z(androidx.core.view.accessibility.d.c.a(k, bool, -1, -1, false, false));
      return;
    } 
    int j = c.e();
    if (c.f) {
      bool = this.s;
    } else {
      bool = true;
    } 
    paramd.Z(androidx.core.view.accessibility.d.c.a(-1, -1, j, bool, false, false));
  }
  
  boolean P1() {
    int k = this.t[0].p(-2147483648);
    for (int j = 1; j < this.s; j++) {
      if (this.t[j].p(-2147483648) != k)
        return false; 
    } 
    return true;
  }
  
  void P2(int paramInt) {
    this.x = paramInt / this.s;
    this.J = View.MeasureSpec.makeMeasureSpec(paramInt, this.v.k());
  }
  
  public void R0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    q2(paramInt1, paramInt2, 1);
  }
  
  public void S0(RecyclerView paramRecyclerView) {
    this.E.b();
    t1();
  }
  
  boolean S1() {
    if (J() != 0 && this.F != 0) {
      int j;
      int k;
      byte b1;
      if (!r0())
        return false; 
      if (this.A) {
        j = k2();
        k = j2();
      } else {
        j = j2();
        k = k2();
      } 
      if (j == 0 && r2() != null) {
        this.E.b();
        u1();
        t1();
        return true;
      } 
      if (!this.M)
        return false; 
      if (this.A) {
        b1 = -1;
      } else {
        b1 = 1;
      } 
      d d1 = this.E;
      d.a a1 = d1.e(j, ++k, b1, true);
      if (a1 == null) {
        this.M = false;
        this.E.d(k);
        return false;
      } 
      d.a a2 = this.E.e(j, a1.o, b1 * -1, true);
      if (a2 == null) {
        this.E.d(a1.o);
      } else {
        this.E.d(a2.o + 1);
      } 
      u1();
      t1();
      return true;
    } 
    return false;
  }
  
  public void T0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    q2(paramInt1, paramInt2, 8);
  }
  
  public void U0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    q2(paramInt1, paramInt2, 2);
  }
  
  public void W0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    q2(paramInt1, paramInt2, 4);
  }
  
  public void X0(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    w2(paramv, parama0, true);
  }
  
  public void Y0(RecyclerView.a0 parama0) {
    super.Y0(parama0);
    this.C = -1;
    this.D = Integer.MIN_VALUE;
    this.I = null;
    this.L.c();
  }
  
  public PointF a(int paramInt) {
    paramInt = R1(paramInt);
    PointF pointF = new PointF();
    if (paramInt == 0)
      return null; 
    if (this.w == 0) {
      pointF.x = paramInt;
      pointF.y = 0.0F;
      return pointF;
    } 
    pointF.x = 0.0F;
    pointF.y = paramInt;
    return pointF;
  }
  
  public void c1(Parcelable paramParcelable) {
    if (paramParcelable instanceof e) {
      this.I = (e)paramParcelable;
      t1();
    } 
  }
  
  public Parcelable d1() {
    // Byte code:
    //   0: aload_0
    //   1: getfield I : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   4: ifnull -> 19
    //   7: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   10: dup
    //   11: aload_0
    //   12: getfield I : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   15: invokespecial <init> : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;)V
    //   18: areturn
    //   19: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: astore #4
    //   28: aload #4
    //   30: aload_0
    //   31: getfield z : Z
    //   34: putfield v : Z
    //   37: aload #4
    //   39: aload_0
    //   40: getfield G : Z
    //   43: putfield w : Z
    //   46: aload #4
    //   48: aload_0
    //   49: getfield H : Z
    //   52: putfield x : Z
    //   55: aload_0
    //   56: getfield E : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   59: astore #5
    //   61: iconst_0
    //   62: istore_2
    //   63: aload #5
    //   65: ifnull -> 108
    //   68: aload #5
    //   70: getfield a : [I
    //   73: astore #6
    //   75: aload #6
    //   77: ifnull -> 108
    //   80: aload #4
    //   82: aload #6
    //   84: putfield t : [I
    //   87: aload #4
    //   89: aload #6
    //   91: arraylength
    //   92: putfield s : I
    //   95: aload #4
    //   97: aload #5
    //   99: getfield b : Ljava/util/List;
    //   102: putfield u : Ljava/util/List;
    //   105: goto -> 114
    //   108: aload #4
    //   110: iconst_0
    //   111: putfield s : I
    //   114: aload_0
    //   115: invokevirtual J : ()I
    //   118: ifle -> 268
    //   121: aload_0
    //   122: getfield G : Z
    //   125: ifeq -> 136
    //   128: aload_0
    //   129: invokevirtual k2 : ()I
    //   132: istore_1
    //   133: goto -> 141
    //   136: aload_0
    //   137: invokevirtual j2 : ()I
    //   140: istore_1
    //   141: aload #4
    //   143: iload_1
    //   144: putfield o : I
    //   147: aload #4
    //   149: aload_0
    //   150: invokevirtual f2 : ()I
    //   153: putfield p : I
    //   156: aload_0
    //   157: getfield s : I
    //   160: istore_1
    //   161: aload #4
    //   163: iload_1
    //   164: putfield q : I
    //   167: aload #4
    //   169: iload_1
    //   170: newarray int
    //   172: putfield r : [I
    //   175: iload_2
    //   176: aload_0
    //   177: getfield s : I
    //   180: if_icmpge -> 286
    //   183: aload_0
    //   184: getfield G : Z
    //   187: ifeq -> 221
    //   190: aload_0
    //   191: getfield t : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   194: iload_2
    //   195: aaload
    //   196: ldc -2147483648
    //   198: invokevirtual l : (I)I
    //   201: istore_3
    //   202: iload_3
    //   203: istore_1
    //   204: iload_3
    //   205: ldc -2147483648
    //   207: if_icmpeq -> 253
    //   210: aload_0
    //   211: getfield u : Landroidx/recyclerview/widget/i;
    //   214: invokevirtual i : ()I
    //   217: istore_1
    //   218: goto -> 249
    //   221: aload_0
    //   222: getfield t : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   225: iload_2
    //   226: aaload
    //   227: ldc -2147483648
    //   229: invokevirtual p : (I)I
    //   232: istore_3
    //   233: iload_3
    //   234: istore_1
    //   235: iload_3
    //   236: ldc -2147483648
    //   238: if_icmpeq -> 253
    //   241: aload_0
    //   242: getfield u : Landroidx/recyclerview/widget/i;
    //   245: invokevirtual m : ()I
    //   248: istore_1
    //   249: iload_3
    //   250: iload_1
    //   251: isub
    //   252: istore_1
    //   253: aload #4
    //   255: getfield r : [I
    //   258: iload_2
    //   259: iload_1
    //   260: iastore
    //   261: iload_2
    //   262: iconst_1
    //   263: iadd
    //   264: istore_2
    //   265: goto -> 175
    //   268: aload #4
    //   270: iconst_m1
    //   271: putfield o : I
    //   274: aload #4
    //   276: iconst_m1
    //   277: putfield p : I
    //   280: aload #4
    //   282: iconst_0
    //   283: putfield q : I
    //   286: aload #4
    //   288: areturn
  }
  
  View d2(boolean paramBoolean) {
    int k = this.u.m();
    int m = this.u.i();
    int j = J() - 1;
    View view;
    for (view = null; j >= 0; view = view1) {
      View view2 = I(j);
      int n = this.u.g(view2);
      int i1 = this.u.d(view2);
      View view1 = view;
      if (i1 > k)
        if (n >= m) {
          view1 = view;
        } else if (i1 > m) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      j--;
    } 
    return view;
  }
  
  public void e1(int paramInt) {
    if (paramInt == 0)
      S1(); 
  }
  
  View e2(boolean paramBoolean) {
    int k = this.u.m();
    int m = this.u.i();
    int n = J();
    View view = null;
    int j = 0;
    while (j < n) {
      View view2 = I(j);
      int i1 = this.u.g(view2);
      View view1 = view;
      if (this.u.d(view2) > k)
        if (i1 >= m) {
          view1 = view;
        } else if (i1 < k) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      j++;
      view = view1;
    } 
    return view;
  }
  
  int f2() {
    View view;
    if (this.A) {
      view = d2(true);
    } else {
      view = e2(true);
    } 
    return (view == null) ? -1 : h0(view);
  }
  
  public void g(String paramString) {
    if (this.I == null)
      super.g(paramString); 
  }
  
  int j2() {
    return (J() == 0) ? 0 : h0(I(0));
  }
  
  public boolean k() {
    return (this.w == 0);
  }
  
  public int k0(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.w == 0) ? this.s : super.k0(paramv, parama0);
  }
  
  int k2() {
    int j = J();
    return (j == 0) ? 0 : h0(I(j - 1));
  }
  
  public boolean l() {
    return (this.w == 1);
  }
  
  public boolean m(RecyclerView.p paramp) {
    return paramp instanceof c;
  }
  
  public void o(int paramInt1, int paramInt2, RecyclerView.a0 parama0, RecyclerView.o.c paramc) {
    if (this.w != 0)
      paramInt1 = paramInt2; 
    if (J() != 0) {
      if (paramInt1 == 0)
        return; 
      y2(paramInt1, parama0);
      int[] arrayOfInt = this.O;
      if (arrayOfInt == null || arrayOfInt.length < this.s)
        this.O = new int[this.s]; 
      boolean bool = false;
      paramInt2 = 0;
      for (paramInt1 = 0; paramInt2 < this.s; paramInt1 = j) {
        f f1 = this.y;
        if (f1.d == -1) {
          j = f1.f;
          k = this.t[paramInt2].p(j);
        } else {
          j = this.t[paramInt2].l(f1.g);
          k = this.y.g;
        } 
        int k = j - k;
        int j = paramInt1;
        if (k >= 0) {
          this.O[paramInt1] = k;
          j = paramInt1 + 1;
        } 
        paramInt2++;
      } 
      Arrays.sort(this.O, 0, paramInt1);
      for (paramInt2 = bool; paramInt2 < paramInt1 && this.y.a(parama0); paramInt2++) {
        paramc.a(this.y.c, this.O[paramInt2]);
        f f1 = this.y;
        f1.c += f1.d;
      } 
    } 
  }
  
  public int q(RecyclerView.a0 parama0) {
    return U1(parama0);
  }
  
  public int r(RecyclerView.a0 parama0) {
    return V1(parama0);
  }
  
  View r2() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual J : ()I
    //   4: iconst_1
    //   5: isub
    //   6: istore_1
    //   7: new java/util/BitSet
    //   10: dup
    //   11: aload_0
    //   12: getfield s : I
    //   15: invokespecial <init> : (I)V
    //   18: astore #7
    //   20: aload #7
    //   22: iconst_0
    //   23: aload_0
    //   24: getfield s : I
    //   27: iconst_1
    //   28: invokevirtual set : (IIZ)V
    //   31: aload_0
    //   32: getfield w : I
    //   35: istore_2
    //   36: iconst_m1
    //   37: istore #5
    //   39: iload_2
    //   40: iconst_1
    //   41: if_icmpne -> 56
    //   44: aload_0
    //   45: invokevirtual t2 : ()Z
    //   48: ifeq -> 56
    //   51: iconst_1
    //   52: istore_2
    //   53: goto -> 58
    //   56: iconst_m1
    //   57: istore_2
    //   58: aload_0
    //   59: getfield A : Z
    //   62: ifeq -> 70
    //   65: iconst_m1
    //   66: istore_3
    //   67: goto -> 76
    //   70: iload_1
    //   71: iconst_1
    //   72: iadd
    //   73: istore_3
    //   74: iconst_0
    //   75: istore_1
    //   76: iload_1
    //   77: istore #4
    //   79: iload_1
    //   80: iload_3
    //   81: if_icmpge -> 90
    //   84: iconst_1
    //   85: istore #5
    //   87: iload_1
    //   88: istore #4
    //   90: iload #4
    //   92: iload_3
    //   93: if_icmpeq -> 349
    //   96: aload_0
    //   97: iload #4
    //   99: invokevirtual I : (I)Landroid/view/View;
    //   102: astore #8
    //   104: aload #8
    //   106: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   109: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   112: astore #9
    //   114: aload #7
    //   116: aload #9
    //   118: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   121: getfield e : I
    //   124: invokevirtual get : (I)Z
    //   127: ifeq -> 158
    //   130: aload_0
    //   131: aload #9
    //   133: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   136: invokespecial T1 : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;)Z
    //   139: ifeq -> 145
    //   142: aload #8
    //   144: areturn
    //   145: aload #7
    //   147: aload #9
    //   149: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   152: getfield e : I
    //   155: invokevirtual clear : (I)V
    //   158: aload #9
    //   160: getfield f : Z
    //   163: ifeq -> 169
    //   166: goto -> 339
    //   169: iload #4
    //   171: iload #5
    //   173: iadd
    //   174: istore_1
    //   175: iload_1
    //   176: iload_3
    //   177: if_icmpeq -> 339
    //   180: aload_0
    //   181: iload_1
    //   182: invokevirtual I : (I)Landroid/view/View;
    //   185: astore #10
    //   187: aload_0
    //   188: getfield A : Z
    //   191: ifeq -> 233
    //   194: aload_0
    //   195: getfield u : Landroidx/recyclerview/widget/i;
    //   198: aload #8
    //   200: invokevirtual d : (Landroid/view/View;)I
    //   203: istore_1
    //   204: aload_0
    //   205: getfield u : Landroidx/recyclerview/widget/i;
    //   208: aload #10
    //   210: invokevirtual d : (Landroid/view/View;)I
    //   213: istore #6
    //   215: iload_1
    //   216: iload #6
    //   218: if_icmpge -> 224
    //   221: aload #8
    //   223: areturn
    //   224: iload_1
    //   225: iload #6
    //   227: if_icmpne -> 274
    //   230: goto -> 269
    //   233: aload_0
    //   234: getfield u : Landroidx/recyclerview/widget/i;
    //   237: aload #8
    //   239: invokevirtual g : (Landroid/view/View;)I
    //   242: istore_1
    //   243: aload_0
    //   244: getfield u : Landroidx/recyclerview/widget/i;
    //   247: aload #10
    //   249: invokevirtual g : (Landroid/view/View;)I
    //   252: istore #6
    //   254: iload_1
    //   255: iload #6
    //   257: if_icmple -> 263
    //   260: aload #8
    //   262: areturn
    //   263: iload_1
    //   264: iload #6
    //   266: if_icmpne -> 274
    //   269: iconst_1
    //   270: istore_1
    //   271: goto -> 276
    //   274: iconst_0
    //   275: istore_1
    //   276: iload_1
    //   277: ifeq -> 339
    //   280: aload #10
    //   282: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   285: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   288: astore #10
    //   290: aload #9
    //   292: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   295: getfield e : I
    //   298: aload #10
    //   300: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   303: getfield e : I
    //   306: isub
    //   307: ifge -> 315
    //   310: iconst_1
    //   311: istore_1
    //   312: goto -> 317
    //   315: iconst_0
    //   316: istore_1
    //   317: iload_2
    //   318: ifge -> 327
    //   321: iconst_1
    //   322: istore #6
    //   324: goto -> 330
    //   327: iconst_0
    //   328: istore #6
    //   330: iload_1
    //   331: iload #6
    //   333: if_icmpeq -> 339
    //   336: aload #8
    //   338: areturn
    //   339: iload #4
    //   341: iload #5
    //   343: iadd
    //   344: istore #4
    //   346: goto -> 90
    //   349: aconst_null
    //   350: areturn
  }
  
  public int s(RecyclerView.a0 parama0) {
    return W1(parama0);
  }
  
  public boolean s0() {
    return (this.F != 0);
  }
  
  public void s2() {
    this.E.b();
    t1();
  }
  
  public int t(RecyclerView.a0 parama0) {
    return U1(parama0);
  }
  
  boolean t2() {
    return (Z() == 1);
  }
  
  public int u(RecyclerView.a0 parama0) {
    return V1(parama0);
  }
  
  public int v(RecyclerView.a0 parama0) {
    return W1(parama0);
  }
  
  public int w1(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return F2(paramInt, paramv, parama0);
  }
  
  public void x1(int paramInt) {
    e e1 = this.I;
    if (e1 != null && e1.o != paramInt)
      e1.i(); 
    this.C = paramInt;
    this.D = Integer.MIN_VALUE;
    t1();
  }
  
  public int y1(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return F2(paramInt, paramv, parama0);
  }
  
  void y2(int paramInt, RecyclerView.a0 parama0) {
    int j;
    byte b1;
    if (paramInt > 0) {
      j = k2();
      b1 = 1;
    } else {
      j = j2();
      b1 = -1;
    } 
    this.y.a = true;
    O2(j, parama0);
    G2(b1);
    f f1 = this.y;
    f1.c = j + f1.d;
    f1.b = Math.abs(paramInt);
  }
  
  class a implements Runnable {
    a(StaggeredGridLayoutManager this$0) {}
    
    public void run() {
      this.o.S1();
    }
  }
  
  class b {
    int a;
    
    int b;
    
    boolean c;
    
    boolean d;
    
    boolean e;
    
    int[] f;
    
    b(StaggeredGridLayoutManager this$0) {
      c();
    }
    
    void a() {
      int i;
      if (this.c) {
        i = this.g.u.i();
      } else {
        i = this.g.u.m();
      } 
      this.b = i;
    }
    
    void b(int param1Int) {
      if (this.c) {
        this.b = this.g.u.i() - param1Int;
        return;
      } 
      this.b = this.g.u.m() + param1Int;
    }
    
    void c() {
      this.a = -1;
      this.b = Integer.MIN_VALUE;
      this.c = false;
      this.d = false;
      this.e = false;
      int[] arrayOfInt = this.f;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
    }
    
    void d(StaggeredGridLayoutManager.f[] param1ArrayOff) {
      int j = param1ArrayOff.length;
      int[] arrayOfInt = this.f;
      if (arrayOfInt == null || arrayOfInt.length < j)
        this.f = new int[this.g.t.length]; 
      for (int i = 0; i < j; i++)
        this.f[i] = param1ArrayOff[i].p(-2147483648); 
    }
  }
  
  public static class c extends RecyclerView.p {
    StaggeredGridLayoutManager.f e;
    
    boolean f;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public final int e() {
      StaggeredGridLayoutManager.f f1 = this.e;
      return (f1 == null) ? -1 : f1.e;
    }
    
    public boolean f() {
      return this.f;
    }
  }
  
  static class d {
    int[] a;
    
    List<a> b;
    
    private int i(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield b : Ljava/util/List;
      //   4: ifnonnull -> 9
      //   7: iconst_m1
      //   8: ireturn
      //   9: aload_0
      //   10: iload_1
      //   11: invokevirtual f : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d$a;
      //   14: astore #4
      //   16: aload #4
      //   18: ifnull -> 33
      //   21: aload_0
      //   22: getfield b : Ljava/util/List;
      //   25: aload #4
      //   27: invokeinterface remove : (Ljava/lang/Object;)Z
      //   32: pop
      //   33: aload_0
      //   34: getfield b : Ljava/util/List;
      //   37: invokeinterface size : ()I
      //   42: istore_3
      //   43: iconst_0
      //   44: istore_2
      //   45: iload_2
      //   46: iload_3
      //   47: if_icmpge -> 80
      //   50: aload_0
      //   51: getfield b : Ljava/util/List;
      //   54: iload_2
      //   55: invokeinterface get : (I)Ljava/lang/Object;
      //   60: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   63: getfield o : I
      //   66: iload_1
      //   67: if_icmplt -> 73
      //   70: goto -> 82
      //   73: iload_2
      //   74: iconst_1
      //   75: iadd
      //   76: istore_2
      //   77: goto -> 45
      //   80: iconst_m1
      //   81: istore_2
      //   82: iload_2
      //   83: iconst_m1
      //   84: if_icmpeq -> 119
      //   87: aload_0
      //   88: getfield b : Ljava/util/List;
      //   91: iload_2
      //   92: invokeinterface get : (I)Ljava/lang/Object;
      //   97: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   100: astore #4
      //   102: aload_0
      //   103: getfield b : Ljava/util/List;
      //   106: iload_2
      //   107: invokeinterface remove : (I)Ljava/lang/Object;
      //   112: pop
      //   113: aload #4
      //   115: getfield o : I
      //   118: ireturn
      //   119: iconst_m1
      //   120: ireturn
    }
    
    private void l(int param1Int1, int param1Int2) {
      List<a> list = this.b;
      if (list == null)
        return; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        int j = a.o;
        if (j >= param1Int1)
          a.o = j + param1Int2; 
      } 
    }
    
    private void m(int param1Int1, int param1Int2) {
      List<a> list = this.b;
      if (list == null)
        return; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        int j = a.o;
        if (j >= param1Int1)
          if (j < param1Int1 + param1Int2) {
            this.b.remove(i);
          } else {
            a.o = j - param1Int2;
          }  
      } 
    }
    
    public void a(a param1a) {
      if (this.b == null)
        this.b = new ArrayList<a>(); 
      int j = this.b.size();
      for (int i = 0; i < j; i++) {
        a a1 = this.b.get(i);
        if (a1.o == param1a.o)
          this.b.remove(i); 
        if (a1.o >= param1a.o) {
          this.b.add(i, param1a);
          return;
        } 
      } 
      this.b.add(param1a);
    }
    
    void b() {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.b = null;
    }
    
    void c(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null) {
        arrayOfInt = new int[Math.max(param1Int, 10) + 1];
        this.a = arrayOfInt;
        Arrays.fill(arrayOfInt, -1);
        return;
      } 
      if (param1Int >= arrayOfInt.length) {
        int[] arrayOfInt1 = new int[o(param1Int)];
        this.a = arrayOfInt1;
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
        arrayOfInt1 = this.a;
        Arrays.fill(arrayOfInt1, arrayOfInt.length, arrayOfInt1.length, -1);
      } 
    }
    
    int d(int param1Int) {
      List<a> list = this.b;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--) {
          if (((a)this.b.get(i)).o >= param1Int)
            this.b.remove(i); 
        }  
      return h(param1Int);
    }
    
    public a e(int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      List<a> list = this.b;
      if (list == null)
        return null; 
      int j = list.size();
      int i;
      for (i = 0; i < j; i++) {
        a a = this.b.get(i);
        int k = a.o;
        if (k >= param1Int2)
          return null; 
        if (k >= param1Int1 && (param1Int3 == 0 || a.p == param1Int3 || (param1Boolean && a.r)))
          return a; 
      } 
      return null;
    }
    
    public a f(int param1Int) {
      List<a> list = this.b;
      if (list == null)
        return null; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        if (a.o == param1Int)
          return a; 
      } 
      return null;
    }
    
    int g(int param1Int) {
      int[] arrayOfInt = this.a;
      return (arrayOfInt == null || param1Int >= arrayOfInt.length) ? -1 : arrayOfInt[param1Int];
    }
    
    int h(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null)
        return -1; 
      if (param1Int >= arrayOfInt.length)
        return -1; 
      int i = i(param1Int);
      if (i == -1) {
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, param1Int, arrayOfInt.length, -1);
        return this.a.length;
      } 
      arrayOfInt = this.a;
      Arrays.fill(arrayOfInt, param1Int, ++i, -1);
      return i;
    }
    
    void j(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int i = param1Int1 + param1Int2;
        c(i);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, param1Int1, arrayOfInt, i, arrayOfInt.length - param1Int1 - param1Int2);
        Arrays.fill(this.a, param1Int1, i, -1);
        l(param1Int1, param1Int2);
      } 
    }
    
    void k(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int i = param1Int1 + param1Int2;
        c(i);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, i, arrayOfInt, param1Int1, arrayOfInt.length - param1Int1 - param1Int2);
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, arrayOfInt.length - param1Int2, arrayOfInt.length, -1);
        m(param1Int1, param1Int2);
      } 
    }
    
    void n(int param1Int, StaggeredGridLayoutManager.f param1f) {
      c(param1Int);
      this.a[param1Int] = param1f.e;
    }
    
    int o(int param1Int) {
      int i;
      for (i = this.a.length; i <= param1Int; i *= 2);
      return i;
    }
    
    @SuppressLint({"BanParcelableUsage"})
    static class a implements Parcelable {
      public static final Parcelable.Creator<a> CREATOR = new a();
      
      int o;
      
      int p;
      
      int[] q;
      
      boolean r;
      
      a() {}
      
      a(Parcel param2Parcel) {
        this.o = param2Parcel.readInt();
        this.p = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        this.r = bool;
        i = param2Parcel.readInt();
        if (i > 0) {
          int[] arrayOfInt = new int[i];
          this.q = arrayOfInt;
          param2Parcel.readIntArray(arrayOfInt);
        } 
      }
      
      public int describeContents() {
        return 0;
      }
      
      int i(int param2Int) {
        int[] arrayOfInt = this.q;
        return (arrayOfInt == null) ? 0 : arrayOfInt[param2Int];
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FullSpanItem{mPosition=");
        stringBuilder.append(this.o);
        stringBuilder.append(", mGapDir=");
        stringBuilder.append(this.p);
        stringBuilder.append(", mHasUnwantedGapAfter=");
        stringBuilder.append(this.r);
        stringBuilder.append(", mGapPerSpan=");
        stringBuilder.append(Arrays.toString(this.q));
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
      }
      
      static final class a implements Parcelable.Creator<a> {
        public StaggeredGridLayoutManager.d.a a(Parcel param3Parcel) {
          return new StaggeredGridLayoutManager.d.a(param3Parcel);
        }
        
        public StaggeredGridLayoutManager.d.a[] b(int param3Int) {
          return new StaggeredGridLayoutManager.d.a[param3Int];
        }
      }
    }
    
    static final class a implements Parcelable.Creator<a> {
      public StaggeredGridLayoutManager.d.a a(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.d.a(param2Parcel);
      }
      
      public StaggeredGridLayoutManager.d.a[] b(int param2Int) {
        return new StaggeredGridLayoutManager.d.a[param2Int];
      }
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  static class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new a();
    
    int o;
    
    int p;
    
    int[] q;
    
    boolean r;
    
    a() {}
    
    a(Parcel param1Parcel) {
      this.o = param1Parcel.readInt();
      this.p = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.r = bool;
      i = param1Parcel.readInt();
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.q = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
    }
    
    public int describeContents() {
      return 0;
    }
    
    int i(int param1Int) {
      int[] arrayOfInt = this.q;
      return (arrayOfInt == null) ? 0 : arrayOfInt[param1Int];
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("FullSpanItem{mPosition=");
      stringBuilder.append(this.o);
      stringBuilder.append(", mGapDir=");
      stringBuilder.append(this.p);
      stringBuilder.append(", mHasUnwantedGapAfter=");
      stringBuilder.append(this.r);
      stringBuilder.append(", mGapPerSpan=");
      stringBuilder.append(Arrays.toString(this.q));
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    static final class a implements Parcelable.Creator<a> {
      public StaggeredGridLayoutManager.d.a a(Parcel param3Parcel) {
        return new StaggeredGridLayoutManager.d.a(param3Parcel);
      }
      
      public StaggeredGridLayoutManager.d.a[] b(int param3Int) {
        return new StaggeredGridLayoutManager.d.a[param3Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<d.a> {
    public StaggeredGridLayoutManager.d.a a(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.d.a(param1Parcel);
    }
    
    public StaggeredGridLayoutManager.d.a[] b(int param1Int) {
      return new StaggeredGridLayoutManager.d.a[param1Int];
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class e implements Parcelable {
    public static final Parcelable.Creator<e> CREATOR = new a();
    
    int o;
    
    int p;
    
    int q;
    
    int[] r;
    
    int s;
    
    int[] t;
    
    List<StaggeredGridLayoutManager.d.a> u;
    
    boolean v;
    
    boolean w;
    
    boolean x;
    
    public e() {}
    
    e(Parcel param1Parcel) {
      this.o = param1Parcel.readInt();
      this.p = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      this.q = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.r = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      this.s = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.t = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      boolean bool2 = false;
      if (i == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.v = bool1;
      if (param1Parcel.readInt() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.w = bool1;
      boolean bool1 = bool2;
      if (param1Parcel.readInt() == 1)
        bool1 = true; 
      this.x = bool1;
      this.u = param1Parcel.readArrayList(StaggeredGridLayoutManager.d.a.class.getClassLoader());
    }
    
    public e(e param1e) {
      this.q = param1e.q;
      this.o = param1e.o;
      this.p = param1e.p;
      this.r = param1e.r;
      this.s = param1e.s;
      this.t = param1e.t;
      this.v = param1e.v;
      this.w = param1e.w;
      this.x = param1e.x;
      this.u = param1e.u;
    }
    
    public int describeContents() {
      return 0;
    }
    
    void i() {
      this.r = null;
      this.q = 0;
      this.o = -1;
      this.p = -1;
    }
    
    void j() {
      this.r = null;
      this.q = 0;
      this.s = 0;
      this.t = null;
      this.u = null;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    static final class a implements Parcelable.Creator<e> {
      public StaggeredGridLayoutManager.e a(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.e(param2Parcel);
      }
      
      public StaggeredGridLayoutManager.e[] b(int param2Int) {
        return new StaggeredGridLayoutManager.e[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<e> {
    public StaggeredGridLayoutManager.e a(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.e(param1Parcel);
    }
    
    public StaggeredGridLayoutManager.e[] b(int param1Int) {
      return new StaggeredGridLayoutManager.e[param1Int];
    }
  }
  
  class f {
    ArrayList<View> a = new ArrayList<View>();
    
    int b = Integer.MIN_VALUE;
    
    int c = Integer.MIN_VALUE;
    
    int d = 0;
    
    final int e;
    
    f(StaggeredGridLayoutManager this$0, int param1Int) {
      this.e = param1Int;
    }
    
    void a(View param1View) {
      StaggeredGridLayoutManager.c c = n(param1View);
      c.e = this;
      this.a.add(param1View);
      this.c = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.b = Integer.MIN_VALUE; 
      if (c.c() || c.b())
        this.d += this.f.u.e(param1View); 
    }
    
    void b(boolean param1Boolean, int param1Int) {
      int i;
      if (param1Boolean) {
        i = l(-2147483648);
      } else {
        i = p(-2147483648);
      } 
      e();
      if (i == Integer.MIN_VALUE)
        return; 
      if ((param1Boolean && i < this.f.u.i()) || (!param1Boolean && i > this.f.u.m()))
        return; 
      int j = i;
      if (param1Int != Integer.MIN_VALUE)
        j = i + param1Int; 
      this.c = j;
      this.b = j;
    }
    
    void c() {
      ArrayList<View> arrayList = this.a;
      View view = arrayList.get(arrayList.size() - 1);
      StaggeredGridLayoutManager.c c = n(view);
      this.c = this.f.u.d(view);
      if (c.f) {
        StaggeredGridLayoutManager.d.a a = this.f.E.f(c.a());
        if (a != null && a.p == 1)
          this.c += a.i(this.e); 
      } 
    }
    
    void d() {
      View view = this.a.get(0);
      StaggeredGridLayoutManager.c c = n(view);
      this.b = this.f.u.g(view);
      if (c.f) {
        StaggeredGridLayoutManager.d.a a = this.f.E.f(c.a());
        if (a != null && a.p == -1)
          this.b -= a.i(this.e); 
      } 
    }
    
    void e() {
      this.a.clear();
      q();
      this.d = 0;
    }
    
    public int f() {
      return this.f.z ? i(this.a.size() - 1, -1, true) : i(0, this.a.size(), true);
    }
    
    public int g() {
      return this.f.z ? i(0, this.a.size(), true) : i(this.a.size() - 1, -1, true);
    }
    
    int h(int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
      byte b;
      int i = this.f.u.m();
      int j = this.f.u.i();
      if (param1Int2 > param1Int1) {
        b = 1;
      } else {
        b = -1;
      } 
      while (param1Int1 != param1Int2) {
        boolean bool1;
        View view = this.a.get(param1Int1);
        int k = this.f.u.g(view);
        int m = this.f.u.d(view);
        boolean bool2 = false;
        if (param1Boolean3 ? (k <= j) : (k < j)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1Boolean3 ? (m >= i) : (m > i))
          bool2 = true; 
        if (bool1 && bool2)
          if (param1Boolean1 && param1Boolean2) {
            if (k >= i && m <= j)
              return this.f.h0(view); 
          } else {
            if (param1Boolean2)
              return this.f.h0(view); 
            if (k < i || m > j)
              return this.f.h0(view); 
          }  
        param1Int1 += b;
      } 
      return -1;
    }
    
    int i(int param1Int1, int param1Int2, boolean param1Boolean) {
      return h(param1Int1, param1Int2, false, false, param1Boolean);
    }
    
    public int j() {
      return this.d;
    }
    
    int k() {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      c();
      return this.c;
    }
    
    int l(int param1Int) {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      c();
      return this.c;
    }
    
    public View m(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #5
      //   3: aconst_null
      //   4: astore #4
      //   6: iload_2
      //   7: iconst_m1
      //   8: if_icmpne -> 123
      //   11: aload_0
      //   12: getfield a : Ljava/util/ArrayList;
      //   15: invokevirtual size : ()I
      //   18: istore_3
      //   19: iconst_0
      //   20: istore_2
      //   21: aload #4
      //   23: astore #5
      //   25: iload_2
      //   26: iload_3
      //   27: if_icmpge -> 238
      //   30: aload_0
      //   31: getfield a : Ljava/util/ArrayList;
      //   34: iload_2
      //   35: invokevirtual get : (I)Ljava/lang/Object;
      //   38: checkcast android/view/View
      //   41: astore #6
      //   43: aload_0
      //   44: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   47: astore #7
      //   49: aload #7
      //   51: getfield z : Z
      //   54: ifeq -> 72
      //   57: aload #4
      //   59: astore #5
      //   61: aload #7
      //   63: aload #6
      //   65: invokevirtual h0 : (Landroid/view/View;)I
      //   68: iload_1
      //   69: if_icmple -> 238
      //   72: aload_0
      //   73: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   76: astore #5
      //   78: aload #5
      //   80: getfield z : Z
      //   83: ifne -> 100
      //   86: aload #5
      //   88: aload #6
      //   90: invokevirtual h0 : (Landroid/view/View;)I
      //   93: iload_1
      //   94: if_icmplt -> 100
      //   97: aload #4
      //   99: areturn
      //   100: aload #4
      //   102: astore #5
      //   104: aload #6
      //   106: invokevirtual hasFocusable : ()Z
      //   109: ifeq -> 238
      //   112: iload_2
      //   113: iconst_1
      //   114: iadd
      //   115: istore_2
      //   116: aload #6
      //   118: astore #4
      //   120: goto -> 21
      //   123: aload_0
      //   124: getfield a : Ljava/util/ArrayList;
      //   127: invokevirtual size : ()I
      //   130: iconst_1
      //   131: isub
      //   132: istore_2
      //   133: aload #5
      //   135: astore #4
      //   137: aload #4
      //   139: astore #5
      //   141: iload_2
      //   142: iflt -> 238
      //   145: aload_0
      //   146: getfield a : Ljava/util/ArrayList;
      //   149: iload_2
      //   150: invokevirtual get : (I)Ljava/lang/Object;
      //   153: checkcast android/view/View
      //   156: astore #6
      //   158: aload_0
      //   159: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   162: astore #7
      //   164: aload #7
      //   166: getfield z : Z
      //   169: ifeq -> 187
      //   172: aload #4
      //   174: astore #5
      //   176: aload #7
      //   178: aload #6
      //   180: invokevirtual h0 : (Landroid/view/View;)I
      //   183: iload_1
      //   184: if_icmpge -> 238
      //   187: aload_0
      //   188: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   191: astore #5
      //   193: aload #5
      //   195: getfield z : Z
      //   198: ifne -> 215
      //   201: aload #5
      //   203: aload #6
      //   205: invokevirtual h0 : (Landroid/view/View;)I
      //   208: iload_1
      //   209: if_icmpgt -> 215
      //   212: aload #4
      //   214: areturn
      //   215: aload #4
      //   217: astore #5
      //   219: aload #6
      //   221: invokevirtual hasFocusable : ()Z
      //   224: ifeq -> 238
      //   227: iload_2
      //   228: iconst_1
      //   229: isub
      //   230: istore_2
      //   231: aload #6
      //   233: astore #4
      //   235: goto -> 137
      //   238: aload #5
      //   240: areturn
    }
    
    StaggeredGridLayoutManager.c n(View param1View) {
      return (StaggeredGridLayoutManager.c)param1View.getLayoutParams();
    }
    
    int o() {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      d();
      return this.b;
    }
    
    int p(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      d();
      return this.b;
    }
    
    void q() {
      this.b = Integer.MIN_VALUE;
      this.c = Integer.MIN_VALUE;
    }
    
    void r(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        this.b = i + param1Int; 
      i = this.c;
      if (i != Integer.MIN_VALUE)
        this.c = i + param1Int; 
    }
    
    void s() {
      int i = this.a.size();
      View view = this.a.remove(i - 1);
      StaggeredGridLayoutManager.c c = n(view);
      c.e = null;
      if (c.c() || c.b())
        this.d -= this.f.u.e(view); 
      if (i == 1)
        this.b = Integer.MIN_VALUE; 
      this.c = Integer.MIN_VALUE;
    }
    
    void t() {
      View view = this.a.remove(0);
      StaggeredGridLayoutManager.c c = n(view);
      c.e = null;
      if (this.a.size() == 0)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b())
        this.d -= this.f.u.e(view); 
      this.b = Integer.MIN_VALUE;
    }
    
    void u(View param1View) {
      StaggeredGridLayoutManager.c c = n(param1View);
      c.e = this;
      this.a.add(0, param1View);
      this.b = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b())
        this.d += this.f.u.e(param1View); 
    }
    
    void v(int param1Int) {
      this.b = param1Int;
      this.c = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\recyclerview\widget\StaggeredGridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */