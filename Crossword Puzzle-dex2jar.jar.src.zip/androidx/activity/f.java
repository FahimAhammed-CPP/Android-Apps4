package androidx.activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import androidx.lifecycle.i;
import androidx.lifecycle.m;
import androidx.lifecycle.n;
import c8.g;

public class f extends Dialog implements m, h {
  private n o;
  
  private final OnBackPressedDispatcher p = new OnBackPressedDispatcher(new e(this));
  
  public f(Context paramContext, int paramInt) {
    super(paramContext, paramInt);
  }
  
  private final n e() {
    n n2 = this.o;
    n n1 = n2;
    if (n2 == null) {
      n1 = new n(this);
      this.o = n1;
    } 
    return n1;
  }
  
  private static final void h(f paramf) {
    g.e(paramf, "this$0");
    paramf.onBackPressed();
  }
  
  public final i a() {
    return (i)e();
  }
  
  public final OnBackPressedDispatcher c() {
    return this.p;
  }
  
  public void onBackPressed() {
    this.p.c();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    e().h(i.b.ON_CREATE);
  }
  
  protected void onStart() {
    super.onStart();
    e().h(i.b.ON_RESUME);
  }
  
  protected void onStop() {
    e().h(i.b.ON_DESTROY);
    this.o = null;
    super.onStop();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\activity\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */