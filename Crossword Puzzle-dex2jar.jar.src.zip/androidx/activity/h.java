package androidx.activity;

import androidx.lifecycle.m;

public interface h extends m {
  OnBackPressedDispatcher c();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\activity\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */