package androidx.activity;

import android.annotation.SuppressLint;
import androidx.lifecycle.i;
import androidx.lifecycle.k;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  final ArrayDeque<g> b = new ArrayDeque<g>();
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  @SuppressLint({"LambdaLast"})
  public void a(m paramm, g paramg) {
    i i = paramm.a();
    if (i.b() == i.c.o)
      return; 
    paramg.a(new LifecycleOnBackPressedCancellable(this, i, paramg));
  }
  
  a b(g paramg) {
    this.b.add(paramg);
    a a = new a(this, paramg);
    paramg.a(a);
    return a;
  }
  
  public void c() {
    Iterator<g> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      g g = iterator.next();
      if (g.c()) {
        g.b();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  private class LifecycleOnBackPressedCancellable implements k, a {
    private final i a;
    
    private final g b;
    
    private a c;
    
    LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, i param1i, g param1g) {
      this.a = param1i;
      this.b = param1g;
      param1i.a((l)this);
    }
    
    public void cancel() {
      this.a.c((l)this);
      this.b.e(this);
      a a1 = this.c;
      if (a1 != null) {
        a1.cancel();
        this.c = null;
      } 
    }
    
    public void d(m param1m, i.b param1b) {
      if (param1b == i.b.ON_START) {
        this.c = this.d.b(this.b);
        return;
      } 
      if (param1b == i.b.ON_STOP) {
        a a1 = this.c;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1b == i.b.ON_DESTROY) {
        cancel();
      } 
    }
  }
  
  private class a implements a {
    private final g a;
    
    a(OnBackPressedDispatcher this$0, g param1g) {
      this.a = param1g;
    }
    
    public void cancel() {
      this.b.b.remove(this.a);
      this.a.e(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */