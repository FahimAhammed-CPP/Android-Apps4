package androidx.activity;

import android.view.View;
import c8.g;

public final class j {
  public static final void a(View paramView, h paramh) {
    g.e(paramView, "<this>");
    g.e(paramh, "onBackPressedDispatcherOwner");
    paramView.setTag(i.a, paramh);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\activity\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */