package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.b;
import androidx.activity.result.c;
import androidx.activity.result.d;
import androidx.activity.result.e;
import androidx.core.app.g;
import androidx.core.app.i;
import androidx.core.app.q;
import androidx.core.view.i;
import androidx.lifecycle.e0;
import androidx.lifecycle.h;
import androidx.lifecycle.h0;
import androidx.lifecycle.i;
import androidx.lifecycle.i0;
import androidx.lifecycle.j0;
import androidx.lifecycle.k;
import androidx.lifecycle.k0;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.n;
import androidx.lifecycle.w;
import androidx.lifecycle.z;
import java.io.Serializable;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import q0.e;
import q0.f;

public class ComponentActivity extends g implements i0, h, e, h, d {
  private final CopyOnWriteArrayList<androidx.core.util.a<Integer>> A;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Intent>> B;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<i>> C;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<q>> D;
  
  final c.a q = new c.a();
  
  private final i r = new i(new c(this));
  
  private final n s = new n(this);
  
  final q0.d t;
  
  private h0 u;
  
  private final OnBackPressedDispatcher v;
  
  private int w;
  
  private final AtomicInteger x;
  
  private final ActivityResultRegistry y;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Configuration>> z;
  
  public ComponentActivity() {
    q0.d d1 = q0.d.a(this);
    this.t = d1;
    this.v = new OnBackPressedDispatcher(new a(this));
    this.x = new AtomicInteger();
    this.y = new b(this);
    this.z = new CopyOnWriteArrayList<androidx.core.util.a<Configuration>>();
    this.A = new CopyOnWriteArrayList<androidx.core.util.a<Integer>>();
    this.B = new CopyOnWriteArrayList<androidx.core.util.a<Intent>>();
    this.C = new CopyOnWriteArrayList<androidx.core.util.a<i>>();
    this.D = new CopyOnWriteArrayList<androidx.core.util.a<q>>();
    if (a() != null) {
      int j = Build.VERSION.SDK_INT;
      a().a((l)new k(this) {
            public void d(m param1m, i.b param1b) {
              if (param1b == i.b.ON_STOP) {
                Window window = this.a.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  ComponentActivity.c.a((View)window); 
              } 
            }
          });
      a().a((l)new k(this) {
            public void d(m param1m, i.b param1b) {
              if (param1b == i.b.ON_DESTROY) {
                this.a.q.b();
                if (!this.a.isChangingConfigurations())
                  this.a.k().a(); 
              } 
            }
          });
      a().a((l)new k(this) {
            public void d(m param1m, i.b param1b) {
              this.a.q();
              this.a.a().c((l)this);
            }
          });
      d1.c();
      z.a(this);
      if (j <= 23)
        a().a((l)new ImmLeaksCleaner((Activity)this)); 
      d().h("android:support:activity-result", new d(this));
      p(new b(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  private void r() {
    j0.a(getWindow().getDecorView(), this);
    k0.a(getWindow().getDecorView(), this);
    f.a(getWindow().getDecorView(), this);
    j.a(getWindow().getDecorView(), this);
  }
  
  public i a() {
    return (i)this.s;
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    r();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public final OnBackPressedDispatcher c() {
    return this.v;
  }
  
  public final q0.c d() {
    return this.t.b();
  }
  
  public j0.a h() {
    j0.d d1 = new j0.d();
    if (getApplication() != null)
      d1.b(e0.a.e, getApplication()); 
    d1.b(z.a, this);
    d1.b(z.b, this);
    if (getIntent() != null && getIntent().getExtras() != null)
      d1.b(z.c, getIntent().getExtras()); 
    return (j0.a)d1;
  }
  
  public final ActivityResultRegistry i() {
    return this.y;
  }
  
  public h0 k() {
    if (getApplication() != null) {
      q();
      return this.u;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  @Deprecated
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.y.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.v.c();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Iterator<androidx.core.util.a<Configuration>> iterator = this.z.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(paramConfiguration); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.t.d(paramBundle);
    this.q.c((Context)this);
    super.onCreate(paramBundle);
    w.g((Activity)this);
    int j = this.w;
    if (j != 0)
      setContentView(j); 
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      this.r.a(paramMenu, getMenuInflater());
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 0) ? this.r.c(paramMenuItem) : false);
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    Iterator<androidx.core.util.a<i>> iterator = this.C.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(new i(paramBoolean)); 
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    Iterator<androidx.core.util.a<i>> iterator = this.C.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(new i(paramBoolean, paramConfiguration)); 
  }
  
  protected void onNewIntent(@SuppressLint({"UnknownNullness", "MissingNullability"}) Intent paramIntent) {
    super.onNewIntent(paramIntent);
    Iterator<androidx.core.util.a<Intent>> iterator = this.B.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    this.r.b(paramMenu);
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    Iterator<androidx.core.util.a<q>> iterator = this.D.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(new q(paramBoolean)); 
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    Iterator<androidx.core.util.a<q>> iterator = this.D.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(new q(paramBoolean, paramConfiguration)); 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      this.r.d(paramMenu);
    } 
    return true;
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.y.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = v();
    h0 h02 = this.u;
    h0 h01 = h02;
    if (h02 == null) {
      d d2 = (d)getLastNonConfigurationInstance();
      h01 = h02;
      if (d2 != null)
        h01 = d2.b; 
    } 
    if (h01 == null && object == null)
      return null; 
    d d1 = new d();
    d1.a = object;
    d1.b = h01;
    return d1;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    i i1 = a();
    if (i1 instanceof n)
      ((n)i1).o(i.c.q); 
    super.onSaveInstanceState(paramBundle);
    this.t.e(paramBundle);
  }
  
  public void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<androidx.core.util.a<Integer>> iterator = this.A.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(Integer.valueOf(paramInt)); 
  }
  
  public final void p(c.b paramb) {
    this.q.a(paramb);
  }
  
  void q() {
    if (this.u == null) {
      d d1 = (d)getLastNonConfigurationInstance();
      if (d1 != null)
        this.u = d1.b; 
      if (this.u == null)
        this.u = new h0(); 
    } 
  }
  
  public void reportFullyDrawn() {
    try {
      if (u0.a.d())
        u0.a.a("reportFullyDrawn() for ComponentActivity"); 
      int j = Build.VERSION.SDK_INT;
      if (j > 19) {
        super.reportFullyDrawn();
      } else if (j == 19 && androidx.core.content.a.a((Context)this, "android.permission.UPDATE_DEVICE_STATS") == 0) {
        super.reportFullyDrawn();
      } 
      return;
    } finally {
      u0.a.b();
    } 
  }
  
  public void s() {
    invalidateOptionsMenu();
  }
  
  public void setContentView(int paramInt) {
    r();
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    r();
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    r();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  @Deprecated
  public Object v() {
    return null;
  }
  
  public final <I, O> c<I> w(d.a<I, O> parama, b<O> paramb) {
    return x(parama, this.y, paramb);
  }
  
  public final <I, O> c<I> x(d.a<I, O> parama, ActivityResultRegistry paramActivityResultRegistry, b<O> paramb) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("activity_rq#");
    stringBuilder.append(this.x.getAndIncrement());
    return paramActivityResultRegistry.i(stringBuilder.toString(), this, parama, paramb);
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        ComponentActivity.o(this.o);
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends ActivityResultRegistry {
    b(ComponentActivity this$0) {}
    
    public <I, O> void f(int param1Int, d.a<I, O> param1a, I param1I, androidx.core.app.c param1c) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      e e;
      ComponentActivity componentActivity = this.i;
      d.a.a a1 = param1a.b((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.a((Context)componentActivity, param1I);
      param1a = null;
      if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null)
        intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        androidx.core.app.b.m((Activity)componentActivity, arrayOfString1, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayOfString2.getAction())) {
        e = (e)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          androidx.core.app.b.o((Activity)componentActivity, e.l(), param1Int, e.i(), e.j(), e.k(), 0, (Bundle)arrayOfString1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
          return;
        } 
      } 
      androidx.core.app.b.n((Activity)componentActivity, (Intent)e, param1Int, (Bundle)sendIntentException);
    }
    
    class a implements Runnable {
      a(ComponentActivity.b this$0, int param2Int, d.a.a param2a) {}
      
      public void run() {
        this.q.c(this.o, this.p.a());
      }
    }
    
    class b implements Runnable {
      b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.q.b(this.o, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.p));
      }
    }
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0, int param1Int, d.a.a param1a) {}
    
    public void run() {
      this.q.c(this.o, this.p.a());
    }
  }
  
  class b implements Runnable {
    b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.q.b(this.o, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.p));
    }
  }
  
  static class c {
    static void a(View param1View) {
      param1View.cancelPendingInputEvents();
    }
  }
  
  static final class d {
    Object a;
    
    h0 b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */