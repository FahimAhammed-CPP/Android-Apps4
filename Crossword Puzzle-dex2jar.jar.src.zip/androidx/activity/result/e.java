package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
public final class e implements Parcelable {
  public static final Parcelable.Creator<e> CREATOR = new a();
  
  private final IntentSender o;
  
  private final Intent p;
  
  private final int q;
  
  private final int r;
  
  e(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2) {
    this.o = paramIntentSender;
    this.p = paramIntent;
    this.q = paramInt1;
    this.r = paramInt2;
  }
  
  e(Parcel paramParcel) {
    this.o = (IntentSender)paramParcel.readParcelable(IntentSender.class.getClassLoader());
    this.p = (Intent)paramParcel.readParcelable(Intent.class.getClassLoader());
    this.q = paramParcel.readInt();
    this.r = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Intent i() {
    return this.p;
  }
  
  public int j() {
    return this.q;
  }
  
  public int k() {
    return this.r;
  }
  
  public IntentSender l() {
    return this.o;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeParcelable((Parcelable)this.o, paramInt);
    paramParcel.writeParcelable((Parcelable)this.p, paramInt);
    paramParcel.writeInt(this.q);
    paramParcel.writeInt(this.r);
  }
  
  class a implements Parcelable.Creator<e> {
    public e a(Parcel param1Parcel) {
      return new e(param1Parcel);
    }
    
    public e[] b(int param1Int) {
      return new e[param1Int];
    }
  }
  
  public static final class b {
    private IntentSender a;
    
    private Intent b;
    
    private int c;
    
    private int d;
    
    public b(IntentSender param1IntentSender) {
      this.a = param1IntentSender;
    }
    
    public e a() {
      return new e(this.a, this.b, this.c, this.d);
    }
    
    public b b(Intent param1Intent) {
      this.b = param1Intent;
      return this;
    }
    
    public b c(int param1Int1, int param1Int2) {
      this.d = param1Int1;
      this.c = param1Int2;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\activity\result\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */