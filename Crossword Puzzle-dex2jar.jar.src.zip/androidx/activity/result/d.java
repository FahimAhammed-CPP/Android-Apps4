package androidx.activity.result;

public interface d {
  ActivityResultRegistry i();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\activity\result\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */