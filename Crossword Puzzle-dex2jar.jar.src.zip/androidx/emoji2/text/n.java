package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.Editable;
import android.text.SpanWatcher;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import androidx.core.util.h;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public final class n extends SpannableStringBuilder {
  private final Class<?> o;
  
  private final List<a> p = new ArrayList<a>();
  
  n(Class<?> paramClass, CharSequence paramCharSequence) {
    super(paramCharSequence);
    h.g(paramClass, "watcherClass cannot be null");
    this.o = paramClass;
  }
  
  n(Class<?> paramClass, CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    super(paramCharSequence, paramInt1, paramInt2);
    h.g(paramClass, "watcherClass cannot be null");
    this.o = paramClass;
  }
  
  private void b() {
    for (int i = 0; i < this.p.size(); i++)
      ((a)this.p.get(i)).a(); 
  }
  
  public static n c(Class<?> paramClass, CharSequence paramCharSequence) {
    return new n(paramClass, paramCharSequence);
  }
  
  private void e() {
    for (int i = 0; i < this.p.size(); i++)
      ((a)this.p.get(i)).onTextChanged((CharSequence)this, 0, length(), length()); 
  }
  
  private a f(Object paramObject) {
    for (int i = 0; i < this.p.size(); i++) {
      a a = this.p.get(i);
      if (a.o == paramObject)
        return a; 
    } 
    return null;
  }
  
  private boolean g(Class<?> paramClass) {
    return (this.o == paramClass);
  }
  
  private boolean h(Object paramObject) {
    return (paramObject != null && g(paramObject.getClass()));
  }
  
  private void i() {
    for (int i = 0; i < this.p.size(); i++)
      ((a)this.p.get(i)).c(); 
  }
  
  public void a() {
    b();
  }
  
  public SpannableStringBuilder append(char paramChar) {
    super.append(paramChar);
    return this;
  }
  
  public SpannableStringBuilder append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence) {
    super.append(paramCharSequence);
    return this;
  }
  
  public SpannableStringBuilder append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    super.append(paramCharSequence, paramInt1, paramInt2);
    return this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder append(CharSequence paramCharSequence, Object paramObject, int paramInt) {
    super.append(paramCharSequence, paramObject, paramInt);
    return this;
  }
  
  public void d() {
    i();
    e();
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder delete(int paramInt1, int paramInt2) {
    super.delete(paramInt1, paramInt2);
    return this;
  }
  
  public int getSpanEnd(Object paramObject) {
    Object object = paramObject;
    if (h(paramObject)) {
      a a = f(paramObject);
      object = paramObject;
      if (a != null)
        object = a; 
    } 
    return super.getSpanEnd(object);
  }
  
  public int getSpanFlags(Object paramObject) {
    Object object = paramObject;
    if (h(paramObject)) {
      a a = f(paramObject);
      object = paramObject;
      if (a != null)
        object = a; 
    } 
    return super.getSpanFlags(object);
  }
  
  public int getSpanStart(Object paramObject) {
    Object object = paramObject;
    if (h(paramObject)) {
      a a = f(paramObject);
      object = paramObject;
      if (a != null)
        object = a; 
    } 
    return super.getSpanStart(object);
  }
  
  @SuppressLint({"UnknownNullness"})
  public <T> T[] getSpans(int paramInt1, int paramInt2, Class<T> paramClass) {
    Object[] arrayOfObject;
    if (g(paramClass)) {
      a[] arrayOfA = (a[])super.getSpans(paramInt1, paramInt2, a.class);
      arrayOfObject = (Object[])Array.newInstance(paramClass, arrayOfA.length);
      for (paramInt1 = 0; paramInt1 < arrayOfA.length; paramInt1++)
        arrayOfObject[paramInt1] = (arrayOfA[paramInt1]).o; 
      return (T[])arrayOfObject;
    } 
    return (T[])super.getSpans(paramInt1, paramInt2, (Class)arrayOfObject);
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder insert(int paramInt, CharSequence paramCharSequence) {
    super.insert(paramInt, paramCharSequence);
    return this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder insert(int paramInt1, CharSequence paramCharSequence, int paramInt2, int paramInt3) {
    super.insert(paramInt1, paramCharSequence, paramInt2, paramInt3);
    return this;
  }
  
  public int nextSpanTransition(int paramInt1, int paramInt2, Class<?> paramClass) {
    if (paramClass != null) {
      Class<?> clazz1 = paramClass;
      if (g(paramClass)) {
        clazz1 = a.class;
        return super.nextSpanTransition(paramInt1, paramInt2, clazz1);
      } 
      return super.nextSpanTransition(paramInt1, paramInt2, clazz1);
    } 
    Class<a> clazz = a.class;
    return super.nextSpanTransition(paramInt1, paramInt2, clazz);
  }
  
  public void removeSpan(Object paramObject) {
    Object object;
    if (h(paramObject)) {
      a a = f(paramObject);
      object = a;
      if (a != null) {
        paramObject = a;
        object = a;
      } 
    } else {
      object = null;
    } 
    super.removeSpan(paramObject);
    if (object != null)
      this.p.remove(object); 
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder replace(int paramInt1, int paramInt2, CharSequence paramCharSequence) {
    b();
    super.replace(paramInt1, paramInt2, paramCharSequence);
    i();
    return this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder replace(int paramInt1, int paramInt2, CharSequence paramCharSequence, int paramInt3, int paramInt4) {
    b();
    super.replace(paramInt1, paramInt2, paramCharSequence, paramInt3, paramInt4);
    i();
    return this;
  }
  
  public void setSpan(Object paramObject, int paramInt1, int paramInt2, int paramInt3) {
    Object object = paramObject;
    if (h(paramObject)) {
      object = new a(paramObject);
      this.p.add(object);
    } 
    super.setSpan(object, paramInt1, paramInt2, paramInt3);
  }
  
  @SuppressLint({"UnknownNullness"})
  public CharSequence subSequence(int paramInt1, int paramInt2) {
    return (CharSequence)new n(this.o, (CharSequence)this, paramInt1, paramInt2);
  }
  
  private static class a implements TextWatcher, SpanWatcher {
    final Object o;
    
    private final AtomicInteger p = new AtomicInteger(0);
    
    a(Object param1Object) {
      this.o = param1Object;
    }
    
    private boolean b(Object param1Object) {
      return param1Object instanceof i;
    }
    
    final void a() {
      this.p.incrementAndGet();
    }
    
    public void afterTextChanged(Editable param1Editable) {
      ((TextWatcher)this.o).afterTextChanged(param1Editable);
    }
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      ((TextWatcher)this.o).beforeTextChanged(param1CharSequence, param1Int1, param1Int2, param1Int3);
    }
    
    final void c() {
      this.p.decrementAndGet();
    }
    
    public void onSpanAdded(Spannable param1Spannable, Object param1Object, int param1Int1, int param1Int2) {
      if (this.p.get() > 0 && b(param1Object))
        return; 
      ((SpanWatcher)this.o).onSpanAdded(param1Spannable, param1Object, param1Int1, param1Int2);
    }
    
    public void onSpanChanged(Spannable param1Spannable, Object param1Object, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (this.p.get() > 0 && b(param1Object))
        return; 
      if (Build.VERSION.SDK_INT < 28) {
        if (param1Int1 > param1Int2)
          param1Int1 = 0; 
        if (param1Int3 > param1Int4)
          param1Int3 = 0; 
      } 
      ((SpanWatcher)this.o).onSpanChanged(param1Spannable, param1Object, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void onSpanRemoved(Spannable param1Spannable, Object param1Object, int param1Int1, int param1Int2) {
      if (this.p.get() > 0 && b(param1Object))
        return; 
      ((SpanWatcher)this.o).onSpanRemoved(param1Spannable, param1Object, param1Int1, param1Int2);
    }
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      ((TextWatcher)this.o).onTextChanged(param1CharSequence, param1Int1, param1Int2, param1Int3);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */