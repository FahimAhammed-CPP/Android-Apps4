package androidx.emoji2.text;

import android.graphics.Typeface;
import android.util.SparseArray;
import androidx.core.os.l;
import androidx.core.util.h;
import d0.b;
import java.nio.ByteBuffer;

public final class m {
  private final b a;
  
  private final char[] b;
  
  private final a c;
  
  private final Typeface d;
  
  private m(Typeface paramTypeface, b paramb) {
    this.d = paramTypeface;
    this.a = paramb;
    this.c = new a(1024);
    this.b = new char[paramb.k() * 2];
    a(paramb);
  }
  
  private void a(b paramb) {
    int j = paramb.k();
    for (int i = 0; i < j; i++) {
      g g = new g(this, i);
      Character.toChars(g.f(), this.b, i * 2);
      h(g);
    } 
  }
  
  public static m b(Typeface paramTypeface, ByteBuffer paramByteBuffer) {
    try {
      l.a("EmojiCompat.MetadataRepo.create");
      return new m(paramTypeface, l.b(paramByteBuffer));
    } finally {
      l.b();
    } 
  }
  
  public char[] c() {
    return this.b;
  }
  
  public b d() {
    return this.a;
  }
  
  int e() {
    return this.a.l();
  }
  
  a f() {
    return this.c;
  }
  
  Typeface g() {
    return this.d;
  }
  
  void h(g paramg) {
    boolean bool;
    h.g(paramg, "emoji metadata cannot be null");
    if (paramg.c() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    h.a(bool, "invalid metadata codepoint length");
    this.c.c(paramg, 0, paramg.c() - 1);
  }
  
  static class a {
    private final SparseArray<a> a;
    
    private g b;
    
    private a() {
      this(1);
    }
    
    a(int param1Int) {
      this.a = new SparseArray(param1Int);
    }
    
    a a(int param1Int) {
      SparseArray<a> sparseArray = this.a;
      return (sparseArray == null) ? null : (a)sparseArray.get(param1Int);
    }
    
    final g b() {
      return this.b;
    }
    
    void c(g param1g, int param1Int1, int param1Int2) {
      a a2 = a(param1g.b(param1Int1));
      a a1 = a2;
      if (a2 == null) {
        a1 = new a();
        this.a.put(param1g.b(param1Int1), a1);
      } 
      if (param1Int2 > param1Int1) {
        a1.c(param1g, param1Int1 + 1, param1Int2);
        return;
      } 
      a1.b = param1g;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */