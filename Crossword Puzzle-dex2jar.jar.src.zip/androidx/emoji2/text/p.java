package androidx.emoji2.text;

import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;

class p implements Spannable {
  private boolean o = false;
  
  private Spannable p;
  
  p(Spannable paramSpannable) {
    this.p = paramSpannable;
  }
  
  p(CharSequence paramCharSequence) {
    this.p = (Spannable)new SpannableString(paramCharSequence);
  }
  
  private void a() {
    Spannable spannable = this.p;
    if (!this.o && c().a((CharSequence)spannable))
      this.p = (Spannable)new SpannableString((CharSequence)spannable); 
    this.o = true;
  }
  
  static b c() {
    return (Build.VERSION.SDK_INT < 28) ? new b() : new c();
  }
  
  Spannable b() {
    return this.p;
  }
  
  public char charAt(int paramInt) {
    return this.p.charAt(paramInt);
  }
  
  public IntStream chars() {
    return a.a((CharSequence)this.p);
  }
  
  public IntStream codePoints() {
    return a.b((CharSequence)this.p);
  }
  
  public int getSpanEnd(Object paramObject) {
    return this.p.getSpanEnd(paramObject);
  }
  
  public int getSpanFlags(Object paramObject) {
    return this.p.getSpanFlags(paramObject);
  }
  
  public int getSpanStart(Object paramObject) {
    return this.p.getSpanStart(paramObject);
  }
  
  public <T> T[] getSpans(int paramInt1, int paramInt2, Class<T> paramClass) {
    return (T[])this.p.getSpans(paramInt1, paramInt2, paramClass);
  }
  
  public int length() {
    return this.p.length();
  }
  
  public int nextSpanTransition(int paramInt1, int paramInt2, Class paramClass) {
    return this.p.nextSpanTransition(paramInt1, paramInt2, paramClass);
  }
  
  public void removeSpan(Object paramObject) {
    a();
    this.p.removeSpan(paramObject);
  }
  
  public void setSpan(Object paramObject, int paramInt1, int paramInt2, int paramInt3) {
    a();
    this.p.setSpan(paramObject, paramInt1, paramInt2, paramInt3);
  }
  
  public CharSequence subSequence(int paramInt1, int paramInt2) {
    return this.p.subSequence(paramInt1, paramInt2);
  }
  
  public String toString() {
    return this.p.toString();
  }
  
  private static class a {
    static IntStream a(CharSequence param1CharSequence) {
      return param1CharSequence.chars();
    }
    
    static IntStream b(CharSequence param1CharSequence) {
      return param1CharSequence.codePoints();
    }
  }
  
  static class b {
    boolean a(CharSequence param1CharSequence) {
      return param1CharSequence instanceof androidx.core.text.b;
    }
  }
  
  static class c extends b {
    boolean a(CharSequence param1CharSequence) {
      return (param1CharSequence instanceof android.text.PrecomputedText || param1CharSequence instanceof androidx.core.text.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */