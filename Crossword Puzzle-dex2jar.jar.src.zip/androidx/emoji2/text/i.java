package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.graphics.Paint;
import android.text.style.ReplacementSpan;
import androidx.core.util.h;

public abstract class i extends ReplacementSpan {
  private final Paint.FontMetricsInt o = new Paint.FontMetricsInt();
  
  private final g p;
  
  private short q = -1;
  
  private short r = -1;
  
  private float s = 1.0F;
  
  i(g paramg) {
    h.g(paramg, "metadata cannot be null");
    this.p = paramg;
  }
  
  public final g a() {
    return this.p;
  }
  
  final int b() {
    return this.q;
  }
  
  public int getSize(Paint paramPaint, @SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2, Paint.FontMetricsInt paramFontMetricsInt) {
    paramPaint.getFontMetricsInt(this.o);
    Paint.FontMetricsInt fontMetricsInt = this.o;
    this.s = Math.abs(fontMetricsInt.descent - fontMetricsInt.ascent) * 1.0F / this.p.e();
    this.r = (short)(int)(this.p.e() * this.s);
    short s = (short)(int)(this.p.i() * this.s);
    this.q = s;
    if (paramFontMetricsInt != null) {
      fontMetricsInt = this.o;
      paramFontMetricsInt.ascent = fontMetricsInt.ascent;
      paramFontMetricsInt.descent = fontMetricsInt.descent;
      paramFontMetricsInt.top = fontMetricsInt.top;
      paramFontMetricsInt.bottom = fontMetricsInt.bottom;
    } 
    return s;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */