package androidx.emoji2.text;

import android.content.Context;
import androidx.core.os.l;
import androidx.lifecycle.ProcessLifecycleInitializer;
import androidx.lifecycle.i;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import t0.a;

public class EmojiCompatInitializer implements a<Boolean> {
  public List<Class<? extends a<?>>> a() {
    return (List)Collections.singletonList(ProcessLifecycleInitializer.class);
  }
  
  public Boolean c(Context paramContext) {
    e.g(new a(paramContext));
    d(paramContext);
    return Boolean.TRUE;
  }
  
  void d(Context paramContext) {
    i i = ((m)androidx.startup.a.e(paramContext).f(ProcessLifecycleInitializer.class)).a();
    i.a((l)new androidx.lifecycle.c(this, i) {
          public void a(m param1m) {
            this.b.e();
            this.a.c((l)this);
          }
        });
  }
  
  void e() {
    b.d().postDelayed(new c(), 500L);
  }
  
  static class a extends e.c {
    protected a(Context param1Context) {
      super(new EmojiCompatInitializer.b(param1Context));
      b(1);
    }
  }
  
  static class b implements e.g {
    private final Context a;
    
    b(Context param1Context) {
      this.a = param1Context.getApplicationContext();
    }
    
    public void a(e.h param1h) {
      ThreadPoolExecutor threadPoolExecutor = b.b("EmojiCompatInitializer");
      threadPoolExecutor.execute(new f(this, param1h, threadPoolExecutor));
    }
    
    void c(e.h param1h, ThreadPoolExecutor param1ThreadPoolExecutor) {
      try {
        j j = c.a(this.a);
        if (j != null)
          return; 
        throw new RuntimeException("EmojiCompat font provider not available on this device.");
      } finally {
        Exception exception = null;
        param1h.a(exception);
        param1ThreadPoolExecutor.shutdown();
      } 
    }
    
    class a extends e.h {
      a(EmojiCompatInitializer.b this$0, e.h param2h, ThreadPoolExecutor param2ThreadPoolExecutor) {}
      
      public void a(Throwable param2Throwable) {
        try {
          this.a.a(param2Throwable);
          return;
        } finally {
          this.b.shutdown();
        } 
      }
      
      public void b(m param2m) {
        try {
          this.a.b(param2m);
          return;
        } finally {
          this.b.shutdown();
        } 
      }
    }
  }
  
  class a extends e.h {
    a(EmojiCompatInitializer this$0, e.h param1h, ThreadPoolExecutor param1ThreadPoolExecutor) {}
    
    public void a(Throwable param1Throwable) {
      try {
        this.a.a(param1Throwable);
        return;
      } finally {
        this.b.shutdown();
      } 
    }
    
    public void b(m param1m) {
      try {
        this.a.b(param1m);
        return;
      } finally {
        this.b.shutdown();
      } 
    }
  }
  
  static class c implements Runnable {
    public void run() {
      try {
        l.a("EmojiCompat.EmojiCompatInitializer.run");
        if (e.h())
          e.b().k(); 
        return;
      } finally {
        l.b();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\EmojiCompatInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */