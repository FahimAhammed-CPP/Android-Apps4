package androidx.emoji2.text;


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */