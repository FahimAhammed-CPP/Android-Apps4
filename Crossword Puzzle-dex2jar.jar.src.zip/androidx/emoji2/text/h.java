package androidx.emoji2.text;

import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.inputmethod.InputConnection;
import java.util.Arrays;

final class h {
  private final e.i a;
  
  private final m b;
  
  private e.d c;
  
  private final boolean d;
  
  private final int[] e;
  
  h(m paramm, e.i parami, e.d paramd, boolean paramBoolean, int[] paramArrayOfint) {
    this.a = parami;
    this.b = paramm;
    this.c = paramd;
    this.d = paramBoolean;
    this.e = paramArrayOfint;
  }
  
  private void a(Spannable paramSpannable, g paramg, int paramInt1, int paramInt2) {
    paramSpannable.setSpan(this.a.a(paramg), paramInt1, paramInt2, 33);
  }
  
  private static boolean b(Editable paramEditable, KeyEvent paramKeyEvent, boolean paramBoolean) {
    if (g(paramKeyEvent))
      return false; 
    int k = Selection.getSelectionStart((CharSequence)paramEditable);
    int j = Selection.getSelectionEnd((CharSequence)paramEditable);
    if (f(k, j))
      return false; 
    i[] arrayOfI = (i[])paramEditable.getSpans(k, j, i.class);
    if (arrayOfI != null && arrayOfI.length > 0) {
      int n = arrayOfI.length;
      for (j = 0; j < n; j++) {
        i i3 = arrayOfI[j];
        int i1 = paramEditable.getSpanStart(i3);
        int i2 = paramEditable.getSpanEnd(i3);
        if ((paramBoolean && i1 == k) || (!paramBoolean && i2 == k) || (k > i1 && k < i2)) {
          paramEditable.delete(i1, i2);
          return true;
        } 
      } 
    } 
    return false;
  }
  
  static boolean c(InputConnection paramInputConnection, Editable paramEditable, int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramEditable != null) {
      if (paramInputConnection == null)
        return false; 
      if (paramInt1 >= 0) {
        if (paramInt2 < 0)
          return false; 
        int k = Selection.getSelectionStart((CharSequence)paramEditable);
        int j = Selection.getSelectionEnd((CharSequence)paramEditable);
        if (f(k, j))
          return false; 
        if (paramBoolean) {
          paramInt1 = a.a((CharSequence)paramEditable, k, Math.max(paramInt1, 0));
          j = a.b((CharSequence)paramEditable, j, Math.max(paramInt2, 0));
          if (paramInt1 != -1) {
            paramInt2 = j;
            if (j == -1)
              return false; 
          } else {
            return false;
          } 
        } else {
          paramInt1 = Math.max(k - paramInt1, 0);
          paramInt2 = Math.min(j + paramInt2, paramEditable.length());
        } 
        i[] arrayOfI = (i[])paramEditable.getSpans(paramInt1, paramInt2, i.class);
        if (arrayOfI != null && arrayOfI.length > 0) {
          int n = arrayOfI.length;
          k = 0;
          j = paramInt1;
          for (paramInt1 = k; paramInt1 < n; paramInt1++) {
            i i2 = arrayOfI[paramInt1];
            int i1 = paramEditable.getSpanStart(i2);
            k = paramEditable.getSpanEnd(i2);
            j = Math.min(i1, j);
            paramInt2 = Math.max(k, paramInt2);
          } 
          paramInt1 = Math.max(j, 0);
          paramInt2 = Math.min(paramInt2, paramEditable.length());
          paramInputConnection.beginBatchEdit();
          paramEditable.delete(paramInt1, paramInt2);
          paramInputConnection.endBatchEdit();
          return true;
        } 
      } 
    } 
    return false;
  }
  
  static boolean d(Editable paramEditable, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    if (paramInt != 67) {
      if (paramInt != 112) {
        bool = false;
      } else {
        bool = b(paramEditable, paramKeyEvent, true);
      } 
    } else {
      bool = b(paramEditable, paramKeyEvent, false);
    } 
    if (bool) {
      MetaKeyKeyListener.adjustMetaAfterKeypress((Spannable)paramEditable);
      return true;
    } 
    return false;
  }
  
  private boolean e(CharSequence paramCharSequence, int paramInt1, int paramInt2, g paramg) {
    if (paramg.d() == 0)
      paramg.k(this.c.a(paramCharSequence, paramInt1, paramInt2, paramg.h())); 
    return (paramg.d() == 2);
  }
  
  private static boolean f(int paramInt1, int paramInt2) {
    return (paramInt1 == -1 || paramInt2 == -1 || paramInt1 != paramInt2);
  }
  
  private static boolean g(KeyEvent paramKeyEvent) {
    return KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) ^ true;
  }
  
  CharSequence h(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/emoji2/text/n
    //   4: istore #11
    //   6: iload #11
    //   8: ifeq -> 18
    //   11: aload_1
    //   12: checkcast androidx/emoji2/text/n
    //   15: invokevirtual a : ()V
    //   18: aconst_null
    //   19: astore #13
    //   21: iload #11
    //   23: ifne -> 85
    //   26: aload_1
    //   27: instanceof android/text/Spannable
    //   30: ifeq -> 36
    //   33: goto -> 85
    //   36: aload #13
    //   38: astore #12
    //   40: aload_1
    //   41: instanceof android/text/Spanned
    //   44: ifeq -> 98
    //   47: aload #13
    //   49: astore #12
    //   51: aload_1
    //   52: checkcast android/text/Spanned
    //   55: iload_2
    //   56: iconst_1
    //   57: isub
    //   58: iload_3
    //   59: iconst_1
    //   60: iadd
    //   61: ldc androidx/emoji2/text/i
    //   63: invokeinterface nextSpanTransition : (IILjava/lang/Class;)I
    //   68: iload_3
    //   69: if_icmpgt -> 98
    //   72: new androidx/emoji2/text/p
    //   75: dup
    //   76: aload_1
    //   77: invokespecial <init> : (Ljava/lang/CharSequence;)V
    //   80: astore #12
    //   82: goto -> 98
    //   85: new androidx/emoji2/text/p
    //   88: dup
    //   89: aload_1
    //   90: checkcast android/text/Spannable
    //   93: invokespecial <init> : (Landroid/text/Spannable;)V
    //   96: astore #12
    //   98: iload_2
    //   99: istore #6
    //   101: iload_3
    //   102: istore #7
    //   104: aload #12
    //   106: ifnull -> 228
    //   109: aload #12
    //   111: iload_2
    //   112: iload_3
    //   113: ldc androidx/emoji2/text/i
    //   115: invokevirtual getSpans : (IILjava/lang/Class;)[Ljava/lang/Object;
    //   118: checkcast [Landroidx/emoji2/text/i;
    //   121: astore #13
    //   123: iload_2
    //   124: istore #6
    //   126: iload_3
    //   127: istore #7
    //   129: aload #13
    //   131: ifnull -> 228
    //   134: iload_2
    //   135: istore #6
    //   137: iload_3
    //   138: istore #7
    //   140: aload #13
    //   142: arraylength
    //   143: ifle -> 228
    //   146: aload #13
    //   148: arraylength
    //   149: istore #9
    //   151: iconst_0
    //   152: istore #8
    //   154: iload_2
    //   155: istore #6
    //   157: iload_3
    //   158: istore #7
    //   160: iload #8
    //   162: iload #9
    //   164: if_icmpge -> 228
    //   167: aload #13
    //   169: iload #8
    //   171: aaload
    //   172: astore #14
    //   174: aload #12
    //   176: aload #14
    //   178: invokevirtual getSpanStart : (Ljava/lang/Object;)I
    //   181: istore #7
    //   183: aload #12
    //   185: aload #14
    //   187: invokevirtual getSpanEnd : (Ljava/lang/Object;)I
    //   190: istore #6
    //   192: iload #7
    //   194: iload_3
    //   195: if_icmpeq -> 205
    //   198: aload #12
    //   200: aload #14
    //   202: invokevirtual removeSpan : (Ljava/lang/Object;)V
    //   205: iload #7
    //   207: iload_2
    //   208: invokestatic min : (II)I
    //   211: istore_2
    //   212: iload #6
    //   214: iload_3
    //   215: invokestatic max : (II)I
    //   218: istore_3
    //   219: iload #8
    //   221: iconst_1
    //   222: iadd
    //   223: istore #8
    //   225: goto -> 154
    //   228: iload #6
    //   230: iload #7
    //   232: if_icmpeq -> 641
    //   235: iload #6
    //   237: aload_1
    //   238: invokeinterface length : ()I
    //   243: if_icmplt -> 249
    //   246: goto -> 641
    //   249: iload #4
    //   251: istore #8
    //   253: iload #4
    //   255: ldc 2147483647
    //   257: if_icmpeq -> 291
    //   260: iload #4
    //   262: istore #8
    //   264: aload #12
    //   266: ifnull -> 291
    //   269: iload #4
    //   271: aload #12
    //   273: iconst_0
    //   274: aload #12
    //   276: invokevirtual length : ()I
    //   279: ldc androidx/emoji2/text/i
    //   281: invokevirtual getSpans : (IILjava/lang/Class;)[Ljava/lang/Object;
    //   284: checkcast [Landroidx/emoji2/text/i;
    //   287: arraylength
    //   288: isub
    //   289: istore #8
    //   291: new androidx/emoji2/text/h$b
    //   294: dup
    //   295: aload_0
    //   296: getfield b : Landroidx/emoji2/text/m;
    //   299: invokevirtual f : ()Landroidx/emoji2/text/m$a;
    //   302: aload_0
    //   303: getfield d : Z
    //   306: aload_0
    //   307: getfield e : [I
    //   310: invokespecial <init> : (Landroidx/emoji2/text/m$a;Z[I)V
    //   313: astore #14
    //   315: aload_1
    //   316: iload #6
    //   318: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
    //   321: istore #10
    //   323: iconst_0
    //   324: istore #4
    //   326: goto -> 678
    //   329: iload_3
    //   330: iload #7
    //   332: if_icmpge -> 519
    //   335: iload #4
    //   337: iload #8
    //   339: if_icmpge -> 519
    //   342: aload #14
    //   344: iload_2
    //   345: invokevirtual a : (I)I
    //   348: istore #6
    //   350: iload #6
    //   352: iconst_1
    //   353: if_icmpeq -> 488
    //   356: iload #6
    //   358: iconst_2
    //   359: if_icmpeq -> 457
    //   362: iload #6
    //   364: iconst_3
    //   365: if_icmpeq -> 371
    //   368: goto -> 329
    //   371: iload #5
    //   373: ifne -> 398
    //   376: iload_2
    //   377: istore #10
    //   379: iload_3
    //   380: istore #6
    //   382: aload_0
    //   383: aload_1
    //   384: iload #9
    //   386: iload_3
    //   387: aload #14
    //   389: invokevirtual c : ()Landroidx/emoji2/text/g;
    //   392: invokespecial e : (Ljava/lang/CharSequence;IILandroidx/emoji2/text/g;)Z
    //   395: ifne -> 678
    //   398: aload #12
    //   400: astore #13
    //   402: aload #12
    //   404: ifnonnull -> 424
    //   407: new androidx/emoji2/text/p
    //   410: dup
    //   411: new android/text/SpannableString
    //   414: dup
    //   415: aload_1
    //   416: invokespecial <init> : (Ljava/lang/CharSequence;)V
    //   419: invokespecial <init> : (Landroid/text/Spannable;)V
    //   422: astore #13
    //   424: aload_0
    //   425: aload #13
    //   427: aload #14
    //   429: invokevirtual c : ()Landroidx/emoji2/text/g;
    //   432: iload #9
    //   434: iload_3
    //   435: invokespecial a : (Landroid/text/Spannable;Landroidx/emoji2/text/g;II)V
    //   438: iload #4
    //   440: iconst_1
    //   441: iadd
    //   442: istore #4
    //   444: aload #13
    //   446: astore #12
    //   448: iload_2
    //   449: istore #10
    //   451: iload_3
    //   452: istore #6
    //   454: goto -> 678
    //   457: iload_3
    //   458: iload_2
    //   459: invokestatic charCount : (I)I
    //   462: iadd
    //   463: istore #6
    //   465: iload #6
    //   467: istore_3
    //   468: iload #6
    //   470: iload #7
    //   472: if_icmpge -> 329
    //   475: aload_1
    //   476: iload #6
    //   478: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
    //   481: istore_2
    //   482: iload #6
    //   484: istore_3
    //   485: goto -> 329
    //   488: iload #9
    //   490: aload_1
    //   491: iload #9
    //   493: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
    //   496: invokestatic charCount : (I)I
    //   499: iadd
    //   500: istore #9
    //   502: iload #9
    //   504: iload #7
    //   506: if_icmpge -> 691
    //   509: aload_1
    //   510: iload #9
    //   512: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
    //   515: istore_2
    //   516: goto -> 691
    //   519: aload #12
    //   521: astore #13
    //   523: aload #14
    //   525: invokevirtual e : ()Z
    //   528: ifeq -> 600
    //   531: aload #12
    //   533: astore #13
    //   535: iload #4
    //   537: iload #8
    //   539: if_icmpge -> 600
    //   542: iload #5
    //   544: ifne -> 567
    //   547: aload #12
    //   549: astore #13
    //   551: aload_0
    //   552: aload_1
    //   553: iload #9
    //   555: iload_3
    //   556: aload #14
    //   558: invokevirtual b : ()Landroidx/emoji2/text/g;
    //   561: invokespecial e : (Ljava/lang/CharSequence;IILandroidx/emoji2/text/g;)Z
    //   564: ifne -> 600
    //   567: aload #12
    //   569: astore #13
    //   571: aload #12
    //   573: ifnonnull -> 586
    //   576: new androidx/emoji2/text/p
    //   579: dup
    //   580: aload_1
    //   581: invokespecial <init> : (Ljava/lang/CharSequence;)V
    //   584: astore #13
    //   586: aload_0
    //   587: aload #13
    //   589: aload #14
    //   591: invokevirtual b : ()Landroidx/emoji2/text/g;
    //   594: iload #9
    //   596: iload_3
    //   597: invokespecial a : (Landroid/text/Spannable;Landroidx/emoji2/text/g;II)V
    //   600: aload #13
    //   602: ifnull -> 627
    //   605: aload #13
    //   607: invokevirtual b : ()Landroid/text/Spannable;
    //   610: astore #12
    //   612: iload #11
    //   614: ifeq -> 624
    //   617: aload_1
    //   618: checkcast androidx/emoji2/text/n
    //   621: invokevirtual d : ()V
    //   624: aload #12
    //   626: areturn
    //   627: iload #11
    //   629: ifeq -> 639
    //   632: aload_1
    //   633: checkcast androidx/emoji2/text/n
    //   636: invokevirtual d : ()V
    //   639: aload_1
    //   640: areturn
    //   641: iload #11
    //   643: ifeq -> 653
    //   646: aload_1
    //   647: checkcast androidx/emoji2/text/n
    //   650: invokevirtual d : ()V
    //   653: aload_1
    //   654: areturn
    //   655: astore #12
    //   657: iload #11
    //   659: ifeq -> 669
    //   662: aload_1
    //   663: checkcast androidx/emoji2/text/n
    //   666: invokevirtual d : ()V
    //   669: goto -> 675
    //   672: aload #12
    //   674: athrow
    //   675: goto -> 672
    //   678: iload #6
    //   680: istore #9
    //   682: iload #10
    //   684: istore_2
    //   685: iload #6
    //   687: istore_3
    //   688: goto -> 329
    //   691: iload #9
    //   693: istore_3
    //   694: goto -> 329
    // Exception table:
    //   from	to	target	type
    //   26	33	655	finally
    //   40	47	655	finally
    //   51	82	655	finally
    //   85	98	655	finally
    //   109	123	655	finally
    //   140	151	655	finally
    //   174	192	655	finally
    //   198	205	655	finally
    //   205	219	655	finally
    //   235	246	655	finally
    //   269	291	655	finally
    //   291	323	655	finally
    //   342	350	655	finally
    //   382	398	655	finally
    //   407	424	655	finally
    //   424	438	655	finally
    //   457	465	655	finally
    //   475	482	655	finally
    //   488	502	655	finally
    //   509	516	655	finally
    //   523	531	655	finally
    //   551	567	655	finally
    //   576	586	655	finally
    //   586	600	655	finally
    //   605	612	655	finally
  }
  
  private static final class a {
    static int a(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      int i = param1CharSequence.length();
      if (param1Int1 >= 0) {
        if (i < param1Int1)
          return -1; 
        if (param1Int2 < 0)
          return -1; 
        label31: while (true) {
          for (i = 0;; i = 1) {
            if (param1Int2 == 0)
              return param1Int1; 
            if (--param1Int1 < 0)
              return (i != 0) ? -1 : 0; 
            char c = param1CharSequence.charAt(param1Int1);
            if (i != 0) {
              if (!Character.isHighSurrogate(c))
                return -1; 
              param1Int2--;
              continue label31;
            } 
            if (!Character.isSurrogate(c)) {
              param1Int2--;
              continue;
            } 
            if (Character.isHighSurrogate(c))
              return -1; 
          } 
          break;
        } 
      } 
      return -1;
    }
    
    static int b(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      int i = param1CharSequence.length();
      if (param1Int1 >= 0) {
        if (i < param1Int1)
          return -1; 
        if (param1Int2 < 0)
          return -1; 
        label30: while (true) {
          boolean bool;
          for (bool = false;; bool = true) {
            if (param1Int2 == 0)
              return param1Int1; 
            if (param1Int1 >= i)
              return bool ? -1 : i; 
            char c = param1CharSequence.charAt(param1Int1);
            if (bool) {
              if (!Character.isLowSurrogate(c))
                return -1; 
              param1Int2--;
              param1Int1++;
              continue label30;
            } 
            if (!Character.isSurrogate(c)) {
              param1Int2--;
              param1Int1++;
              continue;
            } 
            if (Character.isLowSurrogate(c))
              return -1; 
            param1Int1++;
          } 
          break;
        } 
      } 
      return -1;
    }
  }
  
  static final class b {
    private int a = 1;
    
    private final m.a b;
    
    private m.a c;
    
    private m.a d;
    
    private int e;
    
    private int f;
    
    private final boolean g;
    
    private final int[] h;
    
    b(m.a param1a, boolean param1Boolean, int[] param1ArrayOfint) {
      this.b = param1a;
      this.c = param1a;
      this.g = param1Boolean;
      this.h = param1ArrayOfint;
    }
    
    private static boolean d(int param1Int) {
      return (param1Int == 65039);
    }
    
    private static boolean f(int param1Int) {
      return (param1Int == 65038);
    }
    
    private int g() {
      this.a = 1;
      this.c = this.b;
      this.f = 0;
      return 1;
    }
    
    private boolean h() {
      if (this.c.b().j())
        return true; 
      if (d(this.e))
        return true; 
      if (this.g) {
        if (this.h == null)
          return true; 
        int i = this.c.b().b(0);
        if (Arrays.binarySearch(this.h, i) < 0)
          return true; 
      } 
      return false;
    }
    
    int a(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield c : Landroidx/emoji2/text/m$a;
      //   4: iload_1
      //   5: invokevirtual a : (I)Landroidx/emoji2/text/m$a;
      //   8: astore #4
      //   10: aload_0
      //   11: getfield a : I
      //   14: istore_3
      //   15: iconst_3
      //   16: istore_2
      //   17: iload_3
      //   18: iconst_2
      //   19: if_icmpeq -> 56
      //   22: aload #4
      //   24: ifnonnull -> 35
      //   27: aload_0
      //   28: invokespecial g : ()I
      //   31: istore_2
      //   32: goto -> 175
      //   35: aload_0
      //   36: iconst_2
      //   37: putfield a : I
      //   40: aload_0
      //   41: aload #4
      //   43: putfield c : Landroidx/emoji2/text/m$a;
      //   46: aload_0
      //   47: iconst_1
      //   48: putfield f : I
      //   51: iconst_2
      //   52: istore_2
      //   53: goto -> 175
      //   56: aload #4
      //   58: ifnull -> 80
      //   61: aload_0
      //   62: aload #4
      //   64: putfield c : Landroidx/emoji2/text/m$a;
      //   67: aload_0
      //   68: aload_0
      //   69: getfield f : I
      //   72: iconst_1
      //   73: iadd
      //   74: putfield f : I
      //   77: goto -> 51
      //   80: iload_1
      //   81: invokestatic f : (I)Z
      //   84: ifeq -> 95
      //   87: aload_0
      //   88: invokespecial g : ()I
      //   91: istore_2
      //   92: goto -> 175
      //   95: iload_1
      //   96: invokestatic d : (I)Z
      //   99: ifeq -> 105
      //   102: goto -> 51
      //   105: aload_0
      //   106: getfield c : Landroidx/emoji2/text/m$a;
      //   109: invokevirtual b : ()Landroidx/emoji2/text/g;
      //   112: ifnull -> 170
      //   115: aload_0
      //   116: getfield f : I
      //   119: iconst_1
      //   120: if_icmpne -> 154
      //   123: aload_0
      //   124: invokespecial h : ()Z
      //   127: ifeq -> 146
      //   130: aload_0
      //   131: aload_0
      //   132: getfield c : Landroidx/emoji2/text/m$a;
      //   135: putfield d : Landroidx/emoji2/text/m$a;
      //   138: aload_0
      //   139: invokespecial g : ()I
      //   142: pop
      //   143: goto -> 175
      //   146: aload_0
      //   147: invokespecial g : ()I
      //   150: istore_2
      //   151: goto -> 175
      //   154: aload_0
      //   155: aload_0
      //   156: getfield c : Landroidx/emoji2/text/m$a;
      //   159: putfield d : Landroidx/emoji2/text/m$a;
      //   162: aload_0
      //   163: invokespecial g : ()I
      //   166: pop
      //   167: goto -> 175
      //   170: aload_0
      //   171: invokespecial g : ()I
      //   174: istore_2
      //   175: aload_0
      //   176: iload_1
      //   177: putfield e : I
      //   180: iload_2
      //   181: ireturn
    }
    
    g b() {
      return this.c.b();
    }
    
    g c() {
      return this.d.b();
    }
    
    boolean e() {
      int i = this.a;
      null = true;
      if (i == 2 && this.c.b() != null)
        if (this.f <= 1) {
          if (h())
            return true; 
        } else {
          return null;
        }  
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */