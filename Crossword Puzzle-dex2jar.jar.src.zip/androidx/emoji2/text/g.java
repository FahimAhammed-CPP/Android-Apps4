package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import d0.a;

public class g {
  private static final ThreadLocal<a> d = new ThreadLocal<a>();
  
  private final int a;
  
  private final m b;
  
  private volatile int c = 0;
  
  g(m paramm, int paramInt) {
    this.b = paramm;
    this.a = paramInt;
  }
  
  private a g() {
    ThreadLocal<a> threadLocal = d;
    a a2 = threadLocal.get();
    a a1 = a2;
    if (a2 == null) {
      a1 = new a();
      threadLocal.set(a1);
    } 
    this.b.d().j(a1, this.a);
    return a1;
  }
  
  public void a(Canvas paramCanvas, float paramFloat1, float paramFloat2, Paint paramPaint) {
    Typeface typeface1 = this.b.g();
    Typeface typeface2 = paramPaint.getTypeface();
    paramPaint.setTypeface(typeface1);
    int i = this.a;
    paramCanvas.drawText(this.b.c(), i * 2, 2, paramFloat1, paramFloat2, paramPaint);
    paramPaint.setTypeface(typeface2);
  }
  
  public int b(int paramInt) {
    return g().h(paramInt);
  }
  
  public int c() {
    return g().i();
  }
  
  @SuppressLint({"KotlinPropertyAccess"})
  public int d() {
    return this.c;
  }
  
  public short e() {
    return g().k();
  }
  
  public int f() {
    return g().l();
  }
  
  public short h() {
    return g().m();
  }
  
  public short i() {
    return g().n();
  }
  
  public boolean j() {
    return g().j();
  }
  
  @SuppressLint({"KotlinPropertyAccess"})
  public void k(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = true;
    } 
    this.c = bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.toString());
    stringBuilder.append(", id:");
    stringBuilder.append(Integer.toHexString(f()));
    stringBuilder.append(", codepoints:");
    int j = c();
    for (int i = 0; i < j; i++) {
      stringBuilder.append(Integer.toHexString(b(i)));
      stringBuilder.append(" ");
    } 
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */