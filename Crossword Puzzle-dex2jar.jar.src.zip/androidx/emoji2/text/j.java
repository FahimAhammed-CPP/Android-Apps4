package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.os.Handler;
import androidx.core.graphics.l;
import androidx.core.os.l;
import androidx.core.provider.e;
import androidx.core.provider.g;
import androidx.core.util.h;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

public class j extends e.c {
  private static final a j = new a();
  
  public j(Context paramContext, e parame) {
    super(new b(paramContext, parame, j));
  }
  
  public j c(Executor paramExecutor) {
    ((b)a()).f(paramExecutor);
    return this;
  }
  
  public static class a {
    public Typeface a(Context param1Context, g.b param1b) {
      return g.a(param1Context, null, new g.b[] { param1b });
    }
    
    public g.a b(Context param1Context, e param1e) {
      return g.b(param1Context, null, param1e);
    }
    
    public void c(Context param1Context, ContentObserver param1ContentObserver) {
      param1Context.getContentResolver().unregisterContentObserver(param1ContentObserver);
    }
  }
  
  private static class b implements e.g {
    private final Context a;
    
    private final e b;
    
    private final j.a c;
    
    private final Object d = new Object();
    
    private Handler e;
    
    private Executor f;
    
    private ThreadPoolExecutor g;
    
    e.h h;
    
    private ContentObserver i;
    
    private Runnable j;
    
    b(Context param1Context, e param1e, j.a param1a) {
      h.g(param1Context, "Context cannot be null");
      h.g(param1e, "FontRequest cannot be null");
      this.a = param1Context.getApplicationContext();
      this.b = param1e;
      this.c = param1a;
    }
    
    private void b() {
      synchronized (this.d) {
        this.h = null;
        ContentObserver contentObserver = this.i;
        if (contentObserver != null) {
          this.c.c(this.a, contentObserver);
          this.i = null;
        } 
        Handler handler = this.e;
        if (handler != null)
          handler.removeCallbacks(this.j); 
        this.e = null;
        ThreadPoolExecutor threadPoolExecutor = this.g;
        if (threadPoolExecutor != null)
          threadPoolExecutor.shutdown(); 
        this.f = null;
        this.g = null;
        return;
      } 
    }
    
    private g.b e() {
      try {
        g.b[] arrayOfB;
        g.a a1 = this.c.b(this.a, this.b);
        if (a1.c() == 0) {
          arrayOfB = a1.b();
          if (arrayOfB != null && arrayOfB.length != 0)
            return arrayOfB[0]; 
          throw new RuntimeException("fetchFonts failed (empty result)");
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("fetchFonts failed (");
        stringBuilder.append(arrayOfB.c());
        stringBuilder.append(")");
        throw new RuntimeException(stringBuilder.toString());
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        throw new RuntimeException("provider not found", nameNotFoundException);
      } 
    }
    
    public void a(e.h param1h) {
      h.g(param1h, "LoaderCallback cannot be null");
      synchronized (this.d) {
        this.h = param1h;
        d();
        return;
      } 
    }
    
    void c() {
      synchronized (this.d) {
        if (this.h == null)
          return; 
        try {
          null = e();
          int i = null.b();
          if (i == 2)
            synchronized (this.d) {
            
            }  
          if (i == 0)
            try {
              l.a("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
              Typeface typeface = this.c.a(this.a, (g.b)null);
              null = l.f(this.a, null, null.d());
              if (null != null && typeface != null) {
                null = m.b(typeface, (ByteBuffer)null);
                l.b();
                synchronized (this.d) {
                  e.h h1 = this.h;
                  return;
                } 
              } 
              throw new RuntimeException("Unable to open file.");
            } finally {
              l.b();
            }  
          null = new StringBuilder();
          null.append("fetchFonts result is not OK. (");
          null.append(i);
          null.append(")");
          throw new RuntimeException(null.toString());
        } finally {
          null = null;
        } 
      } 
    }
    
    void d() {
      synchronized (this.d) {
        if (this.h == null)
          return; 
        if (this.f == null) {
          ThreadPoolExecutor threadPoolExecutor = b.b("emojiCompat");
          this.g = threadPoolExecutor;
          this.f = threadPoolExecutor;
        } 
        this.f.execute(new k(this));
        return;
      } 
    }
    
    public void f(Executor param1Executor) {
      synchronized (this.d) {
        this.f = param1Executor;
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */