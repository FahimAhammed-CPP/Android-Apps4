package androidx.emoji2.text;

import java.util.concurrent.ThreadFactory;



/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */