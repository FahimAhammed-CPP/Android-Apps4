package androidx.emoji2.text;

import android.graphics.Paint;
import android.os.Build;
import android.text.TextPaint;
import androidx.core.graphics.c;

class d implements e.d {
  private static final ThreadLocal<StringBuilder> b = new ThreadLocal<StringBuilder>();
  
  private final TextPaint a;
  
  d() {
    TextPaint textPaint = new TextPaint();
    this.a = textPaint;
    textPaint.setTextSize(10.0F);
  }
  
  private static StringBuilder b() {
    ThreadLocal<StringBuilder> threadLocal = b;
    if (threadLocal.get() == null)
      threadLocal.set(new StringBuilder()); 
    return threadLocal.get();
  }
  
  public boolean a(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    int i = Build.VERSION.SDK_INT;
    if (i < 23 && paramInt3 > i)
      return false; 
    StringBuilder stringBuilder = b();
    stringBuilder.setLength(0);
    while (paramInt1 < paramInt2) {
      stringBuilder.append(paramCharSequence.charAt(paramInt1));
      paramInt1++;
    } 
    return c.a((Paint)this.a, stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */