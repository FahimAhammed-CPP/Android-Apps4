package androidx.emoji2.text;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class e {
  private static final Object n = new Object();
  
  private static final Object o = new Object();
  
  private static volatile e p;
  
  private final ReadWriteLock a = new ReentrantReadWriteLock();
  
  private final Set<e> b;
  
  private volatile int c = 3;
  
  private final Handler d;
  
  private final b e;
  
  final g f;
  
  final boolean g;
  
  final boolean h;
  
  final int[] i;
  
  private final boolean j;
  
  private final int k;
  
  private final int l;
  
  private final d m;
  
  private e(c paramc) {
    this.g = paramc.b;
    this.h = paramc.c;
    this.i = paramc.d;
    this.j = paramc.f;
    this.k = paramc.g;
    this.f = paramc.a;
    this.l = paramc.h;
    this.m = paramc.i;
    this.d = new Handler(Looper.getMainLooper());
    o.b<e> b1 = new o.b();
    this.b = (Set<e>)b1;
    Set<e> set = paramc.e;
    if (set != null && !set.isEmpty())
      b1.addAll(paramc.e); 
    this.e = new a(this);
    l();
  }
  
  public static e b() {
    synchronized (n) {
      e e1 = p;
      if (e1 != null) {
        boolean bool1 = true;
        androidx.core.util.h.h(bool1, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
        return e1;
      } 
    } 
    boolean bool = false;
    androidx.core.util.h.h(bool, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
    return (e)SYNTHETIC_LOCAL_VARIABLE_2;
  }
  
  public static boolean e(InputConnection paramInputConnection, Editable paramEditable, int paramInt1, int paramInt2, boolean paramBoolean) {
    return h.c(paramInputConnection, paramEditable, paramInt1, paramInt2, paramBoolean);
  }
  
  public static boolean f(Editable paramEditable, int paramInt, KeyEvent paramKeyEvent) {
    return h.d(paramEditable, paramInt, paramKeyEvent);
  }
  
  public static e g(c paramc) {
    e e1 = p;
    if (e1 == null)
      synchronized (n) {
        e e2 = p;
        e1 = e2;
        if (e2 == null) {
          e1 = new e(paramc);
          p = e1;
        } 
        return e1;
      }  
    return e1;
  }
  
  public static boolean h() {
    return (p != null);
  }
  
  private boolean j() {
    return (d() == 1);
  }
  
  private void l() {
    this.a.writeLock().lock();
    try {
      if (this.l == 0)
        this.c = 0; 
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public int c() {
    return this.k;
  }
  
  public int d() {
    this.a.readLock().lock();
    try {
      return this.c;
    } finally {
      this.a.readLock().unlock();
    } 
  }
  
  public boolean i() {
    return this.j;
  }
  
  public void k() {
    int i = this.l;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    androidx.core.util.h.h(bool, "Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
    if (j())
      return; 
    this.a.writeLock().lock();
    try {
      i = this.c;
      if (i == 0)
        return; 
      this.c = 0;
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  void m(Throwable paramThrowable) {
    ArrayList<e> arrayList = new ArrayList();
    this.a.writeLock().lock();
    try {
      this.c = 2;
      arrayList.addAll(this.b);
      this.b.clear();
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  void n() {
    null = new ArrayList();
    this.a.writeLock().lock();
    try {
      this.c = 1;
      null.addAll(this.b);
      this.b.clear();
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public CharSequence o(CharSequence paramCharSequence) {
    int i;
    if (paramCharSequence == null) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    return p(paramCharSequence, 0, i);
  }
  
  public CharSequence p(CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    return q(paramCharSequence, paramInt1, paramInt2, 2147483647);
  }
  
  public CharSequence q(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    return r(paramCharSequence, paramInt1, paramInt2, paramInt3, 0);
  }
  
  public CharSequence r(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    boolean bool;
    androidx.core.util.h.h(j(), "Not initialized yet");
    androidx.core.util.h.d(paramInt1, "start cannot be negative");
    androidx.core.util.h.d(paramInt2, "end cannot be negative");
    androidx.core.util.h.d(paramInt3, "maxEmojiCount cannot be negative");
    if (paramInt1 <= paramInt2) {
      bool = true;
    } else {
      bool = false;
    } 
    androidx.core.util.h.a(bool, "start should be <= than end");
    if (paramCharSequence == null)
      return null; 
    if (paramInt1 <= paramCharSequence.length()) {
      bool = true;
    } else {
      bool = false;
    } 
    androidx.core.util.h.a(bool, "start should be < than charSequence length");
    if (paramInt2 <= paramCharSequence.length()) {
      bool = true;
    } else {
      bool = false;
    } 
    androidx.core.util.h.a(bool, "end should be < than charSequence length");
    CharSequence charSequence = paramCharSequence;
    if (paramCharSequence.length() != 0) {
      if (paramInt1 == paramInt2)
        return paramCharSequence; 
      if (paramInt4 != 1) {
        if (paramInt4 != 2) {
          bool = this.g;
        } else {
          bool = false;
        } 
      } else {
        bool = true;
      } 
      charSequence = this.e.b(paramCharSequence, paramInt1, paramInt2, paramInt3, bool);
    } 
    return charSequence;
  }
  
  public void s(e parame) {
    androidx.core.util.h.g(parame, "initCallback cannot be null");
    this.a.writeLock().lock();
    try {
      if (this.c == 1 || this.c == 2) {
        this.d.post(new f(parame, this.c));
      } else {
        this.b.add(parame);
      } 
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public void t(e parame) {
    androidx.core.util.h.g(parame, "initCallback cannot be null");
    this.a.writeLock().lock();
    try {
      this.b.remove(parame);
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public void u(EditorInfo paramEditorInfo) {
    if (j()) {
      if (paramEditorInfo == null)
        return; 
      if (paramEditorInfo.extras == null)
        paramEditorInfo.extras = new Bundle(); 
      this.e.c(paramEditorInfo);
    } 
  }
  
  private static final class a extends b {
    private volatile h b;
    
    private volatile m c;
    
    a(e param1e) {
      super(param1e);
    }
    
    void a() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.a.m(exception);
      } 
    }
    
    CharSequence b(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      return this.b.h(param1CharSequence, param1Int1, param1Int2, param1Int3, param1Boolean);
    }
    
    void c(EditorInfo param1EditorInfo) {
      param1EditorInfo.extras.putInt("android.support.text.emoji.emojiCompat_metadataVersion", this.c.e());
      param1EditorInfo.extras.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", this.a.g);
    }
    
    void d(m param1m) {
      if (param1m == null) {
        this.a.m(new IllegalArgumentException("metadataRepo cannot be null"));
        return;
      } 
      this.c = param1m;
      param1m = this.c;
      e.i i = new e.i();
      e.d d = e.a(this.a);
      e e = this.a;
      this.b = new h(param1m, i, d, e.h, e.i);
      this.a.n();
    }
    
    class a extends e.h {
      a(e.a this$0) {}
      
      public void a(Throwable param2Throwable) {
        this.a.a.m(param2Throwable);
      }
      
      public void b(m param2m) {
        this.a.d(param2m);
      }
    }
  }
  
  class a extends h {
    a(e this$0) {}
    
    public void a(Throwable param1Throwable) {
      this.a.a.m(param1Throwable);
    }
    
    public void b(m param1m) {
      this.a.d(param1m);
    }
  }
  
  private static class b {
    final e a;
    
    b(e param1e) {
      this.a = param1e;
    }
    
    void a() {
      throw null;
    }
    
    CharSequence b(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      throw null;
    }
    
    void c(EditorInfo param1EditorInfo) {
      throw null;
    }
  }
  
  public static abstract class c {
    final e.g a;
    
    boolean b;
    
    boolean c;
    
    int[] d;
    
    Set<e.e> e;
    
    boolean f;
    
    int g = -16711936;
    
    int h = 0;
    
    e.d i = new d();
    
    protected c(e.g param1g) {
      androidx.core.util.h.g(param1g, "metadataLoader cannot be null.");
      this.a = param1g;
    }
    
    protected final e.g a() {
      return this.a;
    }
    
    public c b(int param1Int) {
      this.h = param1Int;
      return this;
    }
  }
  
  public static interface d {
    boolean a(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3);
  }
  
  public static abstract class e {
    public void a(Throwable param1Throwable) {}
    
    public void b() {}
  }
  
  private static class f implements Runnable {
    private final List<e.e> o;
    
    private final Throwable p;
    
    private final int q;
    
    f(e.e param1e, int param1Int) {
      this(Arrays.asList(new e.e[] { (e.e)androidx.core.util.h.g(param1e, "initCallback cannot be null") }), param1Int, null);
    }
    
    f(Collection<e.e> param1Collection, int param1Int) {
      this(param1Collection, param1Int, null);
    }
    
    f(Collection<e.e> param1Collection, int param1Int, Throwable param1Throwable) {
      androidx.core.util.h.g(param1Collection, "initCallbacks cannot be null");
      this.o = new ArrayList<e.e>(param1Collection);
      this.q = param1Int;
      this.p = param1Throwable;
    }
    
    public void run() {
      int j = this.o.size();
      int k = this.q;
      int i = 0;
      byte b = 0;
      if (k != 1) {
        for (i = b; i < j; i++)
          ((e.e)this.o.get(i)).a(this.p); 
      } else {
        while (i < j) {
          ((e.e)this.o.get(i)).b();
          i++;
        } 
      } 
    }
  }
  
  public static interface g {
    void a(e.h param1h);
  }
  
  public static abstract class h {
    public abstract void a(Throwable param1Throwable);
    
    public abstract void b(m param1m);
  }
  
  static class i {
    i a(g param1g) {
      return new o(param1g);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */