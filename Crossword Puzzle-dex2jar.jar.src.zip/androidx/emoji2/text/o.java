package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.TextPaint;

public final class o extends i {
  private static Paint t;
  
  public o(g paramg) {
    super(paramg);
  }
  
  private static Paint c() {
    if (t == null) {
      TextPaint textPaint = new TextPaint();
      t = (Paint)textPaint;
      textPaint.setColor(e.b().c());
      t.setStyle(Paint.Style.FILL);
    } 
    return t;
  }
  
  public void draw(Canvas paramCanvas, @SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2, float paramFloat, int paramInt3, int paramInt4, int paramInt5, Paint paramPaint) {
    if (e.b().i())
      paramCanvas.drawRect(paramFloat, paramInt3, paramFloat + b(), paramInt5, c()); 
    a().a(paramCanvas, paramFloat, paramInt4, paramPaint);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\emoji2\text\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */