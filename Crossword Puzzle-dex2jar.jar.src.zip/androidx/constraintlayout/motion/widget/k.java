package androidx.constraintlayout.motion.widget;

import android.view.View;
import androidx.constraintlayout.widget.a;
import java.util.LinkedHashMap;
import q.b;

class k implements Comparable<k> {
  static String[] G = new String[] { "position", "x", "y", "width", "height", "pathRotate" };
  
  float A;
  
  g B;
  
  LinkedHashMap<String, a> C;
  
  int D;
  
  double[] E;
  
  double[] F;
  
  b o;
  
  int p = 0;
  
  float q;
  
  float r;
  
  float s;
  
  float t;
  
  float u;
  
  float v;
  
  float w = Float.NaN;
  
  float x = Float.NaN;
  
  int y;
  
  int z;
  
  public k() {
    int i = d.a;
    this.y = i;
    this.z = i;
    this.A = Float.NaN;
    this.B = null;
    this.C = new LinkedHashMap<String, a>();
    this.D = 0;
    this.E = new double[18];
    this.F = new double[18];
  }
  
  public int c(k paramk) {
    return Float.compare(this.r, paramk.r);
  }
  
  void d(double paramDouble, int[] paramArrayOfint, double[] paramArrayOfdouble1, float[] paramArrayOffloat1, double[] paramArrayOfdouble2, float[] paramArrayOffloat2) {
    float f3 = this.s;
    float f4 = this.t;
    float f6 = this.u;
    float f5 = this.v;
    int i = 0;
    float f8 = 0.0F;
    float f10 = 0.0F;
    float f7 = 0.0F;
    float f9 = 0.0F;
    while (i < paramArrayOfint.length) {
      float f12 = (float)paramArrayOfdouble1[i];
      float f11 = (float)paramArrayOfdouble2[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4) {
              f5 = f12;
              f9 = f11;
            } 
          } else {
            f6 = f12;
            f10 = f11;
          } 
        } else {
          f4 = f12;
          f7 = f11;
        } 
      } else {
        f8 = f11;
        f3 = f12;
      } 
      i++;
    } 
    float f1 = f10 / 2.0F + f8;
    float f2 = f9 / 2.0F + f7;
    g g1 = this.B;
    if (g1 != null) {
      float[] arrayOfFloat1 = new float[2];
      float[] arrayOfFloat2 = new float[2];
      g1.b(paramDouble, arrayOfFloat1, arrayOfFloat2);
      f10 = arrayOfFloat1[0];
      f9 = arrayOfFloat1[1];
      f1 = arrayOfFloat2[0];
      f2 = arrayOfFloat2[1];
      double d2 = f10;
      double d1 = f3;
      paramDouble = f4;
      double d3 = Math.sin(paramDouble);
      Double.isNaN(d1);
      Double.isNaN(d2);
      double d4 = (f6 / 2.0F);
      Double.isNaN(d4);
      f3 = (float)(d2 + d3 * d1 - d4);
      d2 = f9;
      d3 = Math.cos(paramDouble);
      Double.isNaN(d1);
      Double.isNaN(d2);
      d4 = (f5 / 2.0F);
      Double.isNaN(d4);
      f4 = (float)(d2 - d1 * d3 - d4);
      d3 = f1;
      d1 = f8;
      d4 = Math.sin(paramDouble);
      Double.isNaN(d1);
      Double.isNaN(d3);
      double d5 = Math.cos(paramDouble);
      d2 = f7;
      Double.isNaN(d2);
      f1 = (float)(d3 + d4 * d1 + d5 * d2);
      d3 = f2;
      d4 = Math.cos(paramDouble);
      Double.isNaN(d1);
      Double.isNaN(d3);
      paramDouble = Math.sin(paramDouble);
      Double.isNaN(d2);
      f2 = (float)(d3 - d1 * d4 + paramDouble * d2);
    } 
    paramArrayOffloat1[0] = f3 + f6 / 2.0F + 0.0F;
    paramArrayOffloat1[1] = f4 + f5 / 2.0F + 0.0F;
    paramArrayOffloat2[0] = f1;
    paramArrayOffloat2[1] = f2;
  }
  
  void e(float paramFloat, View paramView, int[] paramArrayOfint, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield s : F
    //   4: fstore #28
    //   6: aload_0
    //   7: getfield t : F
    //   10: fstore #27
    //   12: aload_0
    //   13: getfield u : F
    //   16: fstore #29
    //   18: aload_0
    //   19: getfield v : F
    //   22: fstore #26
    //   24: aload_3
    //   25: arraylength
    //   26: ifeq -> 69
    //   29: aload_0
    //   30: getfield E : [D
    //   33: arraylength
    //   34: aload_3
    //   35: aload_3
    //   36: arraylength
    //   37: iconst_1
    //   38: isub
    //   39: iaload
    //   40: if_icmpgt -> 69
    //   43: aload_3
    //   44: aload_3
    //   45: arraylength
    //   46: iconst_1
    //   47: isub
    //   48: iaload
    //   49: iconst_1
    //   50: iadd
    //   51: istore #34
    //   53: aload_0
    //   54: iload #34
    //   56: newarray double
    //   58: putfield E : [D
    //   61: aload_0
    //   62: iload #34
    //   64: newarray double
    //   66: putfield F : [D
    //   69: aload_0
    //   70: getfield E : [D
    //   73: ldc2_w NaN
    //   76: invokestatic fill : ([DD)V
    //   79: iconst_0
    //   80: istore #34
    //   82: iload #34
    //   84: aload_3
    //   85: arraylength
    //   86: if_icmpge -> 126
    //   89: aload_0
    //   90: getfield E : [D
    //   93: aload_3
    //   94: iload #34
    //   96: iaload
    //   97: aload #4
    //   99: iload #34
    //   101: daload
    //   102: dastore
    //   103: aload_0
    //   104: getfield F : [D
    //   107: aload_3
    //   108: iload #34
    //   110: iaload
    //   111: aload #5
    //   113: iload #34
    //   115: daload
    //   116: dastore
    //   117: iload #34
    //   119: iconst_1
    //   120: iadd
    //   121: istore #34
    //   123: goto -> 82
    //   126: ldc NaN
    //   128: fstore #24
    //   130: iconst_0
    //   131: istore #34
    //   133: fconst_0
    //   134: fstore #31
    //   136: fconst_0
    //   137: fstore #30
    //   139: fconst_0
    //   140: fstore #33
    //   142: fconst_0
    //   143: fstore #32
    //   145: aload_0
    //   146: getfield E : [D
    //   149: astore_3
    //   150: iload #34
    //   152: aload_3
    //   153: arraylength
    //   154: if_icmpge -> 361
    //   157: aload_3
    //   158: iload #34
    //   160: daload
    //   161: invokestatic isNaN : (D)Z
    //   164: istore #41
    //   166: dconst_0
    //   167: dstore #8
    //   169: iload #41
    //   171: ifeq -> 192
    //   174: aload #6
    //   176: ifnull -> 189
    //   179: aload #6
    //   181: iload #34
    //   183: daload
    //   184: dconst_0
    //   185: dcmpl
    //   186: ifne -> 192
    //   189: goto -> 281
    //   192: aload #6
    //   194: ifnull -> 204
    //   197: aload #6
    //   199: iload #34
    //   201: daload
    //   202: dstore #8
    //   204: aload_0
    //   205: getfield E : [D
    //   208: iload #34
    //   210: daload
    //   211: invokestatic isNaN : (D)Z
    //   214: ifeq -> 220
    //   217: goto -> 232
    //   220: aload_0
    //   221: getfield E : [D
    //   224: iload #34
    //   226: daload
    //   227: dload #8
    //   229: dadd
    //   230: dstore #8
    //   232: fload #24
    //   234: fstore #23
    //   236: dload #8
    //   238: d2f
    //   239: fstore #22
    //   241: aload_0
    //   242: getfield F : [D
    //   245: iload #34
    //   247: daload
    //   248: d2f
    //   249: fstore #25
    //   251: iload #34
    //   253: iconst_1
    //   254: if_icmpeq -> 336
    //   257: iload #34
    //   259: iconst_2
    //   260: if_icmpeq -> 321
    //   263: iload #34
    //   265: iconst_3
    //   266: if_icmpeq -> 306
    //   269: iload #34
    //   271: iconst_4
    //   272: if_icmpeq -> 291
    //   275: iload #34
    //   277: iconst_5
    //   278: if_icmpeq -> 288
    //   281: fload #24
    //   283: fstore #22
    //   285: goto -> 348
    //   288: goto -> 348
    //   291: fload #22
    //   293: fstore #26
    //   295: fload #23
    //   297: fstore #22
    //   299: fload #25
    //   301: fstore #32
    //   303: goto -> 348
    //   306: fload #22
    //   308: fstore #29
    //   310: fload #23
    //   312: fstore #22
    //   314: fload #25
    //   316: fstore #33
    //   318: goto -> 348
    //   321: fload #22
    //   323: fstore #27
    //   325: fload #23
    //   327: fstore #22
    //   329: fload #25
    //   331: fstore #30
    //   333: goto -> 348
    //   336: fload #22
    //   338: fstore #28
    //   340: fload #25
    //   342: fstore #31
    //   344: fload #23
    //   346: fstore #22
    //   348: iload #34
    //   350: iconst_1
    //   351: iadd
    //   352: istore #34
    //   354: fload #22
    //   356: fstore #24
    //   358: goto -> 145
    //   361: aload_0
    //   362: getfield B : Landroidx/constraintlayout/motion/widget/g;
    //   365: astore_3
    //   366: aload_3
    //   367: ifnull -> 729
    //   370: iconst_2
    //   371: newarray float
    //   373: astore #4
    //   375: iconst_2
    //   376: newarray float
    //   378: astore #6
    //   380: aload_3
    //   381: fload_1
    //   382: f2d
    //   383: aload #4
    //   385: aload #6
    //   387: invokevirtual b : (D[F[F)V
    //   390: aload #4
    //   392: iconst_0
    //   393: faload
    //   394: fstore_1
    //   395: aload #4
    //   397: iconst_1
    //   398: faload
    //   399: fstore #22
    //   401: aload #6
    //   403: iconst_0
    //   404: faload
    //   405: fstore #25
    //   407: aload #6
    //   409: iconst_1
    //   410: faload
    //   411: fstore #23
    //   413: fload_1
    //   414: f2d
    //   415: dstore #12
    //   417: fload #28
    //   419: f2d
    //   420: dstore #8
    //   422: fload #27
    //   424: f2d
    //   425: dstore #10
    //   427: dload #10
    //   429: invokestatic sin : (D)D
    //   432: dstore #14
    //   434: dload #8
    //   436: invokestatic isNaN : (D)Z
    //   439: pop
    //   440: dload #12
    //   442: invokestatic isNaN : (D)Z
    //   445: pop
    //   446: fload #29
    //   448: fconst_2
    //   449: fdiv
    //   450: f2d
    //   451: dstore #16
    //   453: dload #16
    //   455: invokestatic isNaN : (D)Z
    //   458: pop
    //   459: dload #12
    //   461: dload #14
    //   463: dload #8
    //   465: dmul
    //   466: dadd
    //   467: dload #16
    //   469: dsub
    //   470: d2f
    //   471: fstore_1
    //   472: fload #22
    //   474: f2d
    //   475: dstore #12
    //   477: dload #10
    //   479: invokestatic cos : (D)D
    //   482: dstore #14
    //   484: dload #8
    //   486: invokestatic isNaN : (D)Z
    //   489: pop
    //   490: dload #12
    //   492: invokestatic isNaN : (D)Z
    //   495: pop
    //   496: fload #26
    //   498: fconst_2
    //   499: fdiv
    //   500: f2d
    //   501: dstore #16
    //   503: dload #16
    //   505: invokestatic isNaN : (D)Z
    //   508: pop
    //   509: dload #12
    //   511: dload #14
    //   513: dload #8
    //   515: dmul
    //   516: dsub
    //   517: dload #16
    //   519: dsub
    //   520: d2f
    //   521: fstore #22
    //   523: fload #25
    //   525: f2d
    //   526: dstore #16
    //   528: fload #31
    //   530: f2d
    //   531: dstore #12
    //   533: dload #10
    //   535: invokestatic sin : (D)D
    //   538: dstore #18
    //   540: dload #12
    //   542: invokestatic isNaN : (D)Z
    //   545: pop
    //   546: dload #16
    //   548: invokestatic isNaN : (D)Z
    //   551: pop
    //   552: dload #10
    //   554: invokestatic cos : (D)D
    //   557: dstore #20
    //   559: dload #8
    //   561: invokestatic isNaN : (D)Z
    //   564: pop
    //   565: fload #30
    //   567: f2d
    //   568: dstore #14
    //   570: dload #14
    //   572: invokestatic isNaN : (D)Z
    //   575: pop
    //   576: dload #16
    //   578: dload #18
    //   580: dload #12
    //   582: dmul
    //   583: dadd
    //   584: dload #20
    //   586: dload #8
    //   588: dmul
    //   589: dload #14
    //   591: dmul
    //   592: dadd
    //   593: d2f
    //   594: fstore #25
    //   596: fload #23
    //   598: f2d
    //   599: dstore #16
    //   601: dload #10
    //   603: invokestatic cos : (D)D
    //   606: dstore #18
    //   608: dload #12
    //   610: invokestatic isNaN : (D)Z
    //   613: pop
    //   614: dload #16
    //   616: invokestatic isNaN : (D)Z
    //   619: pop
    //   620: dload #10
    //   622: invokestatic sin : (D)D
    //   625: dstore #10
    //   627: dload #8
    //   629: invokestatic isNaN : (D)Z
    //   632: pop
    //   633: dload #14
    //   635: invokestatic isNaN : (D)Z
    //   638: pop
    //   639: dload #16
    //   641: dload #12
    //   643: dload #18
    //   645: dmul
    //   646: dsub
    //   647: dload #8
    //   649: dload #10
    //   651: dmul
    //   652: dload #14
    //   654: dmul
    //   655: dadd
    //   656: d2f
    //   657: fstore #23
    //   659: aload #5
    //   661: arraylength
    //   662: iconst_2
    //   663: if_icmplt -> 683
    //   666: aload #5
    //   668: iconst_0
    //   669: fload #25
    //   671: f2d
    //   672: dastore
    //   673: aload #5
    //   675: iconst_1
    //   676: fload #23
    //   678: f2d
    //   679: dastore
    //   680: goto -> 683
    //   683: fload #24
    //   685: invokestatic isNaN : (F)Z
    //   688: ifne -> 726
    //   691: fload #24
    //   693: f2d
    //   694: dstore #8
    //   696: fload #23
    //   698: f2d
    //   699: fload #25
    //   701: f2d
    //   702: invokestatic atan2 : (DD)D
    //   705: invokestatic toDegrees : (D)D
    //   708: dstore #10
    //   710: dload #8
    //   712: invokestatic isNaN : (D)Z
    //   715: pop
    //   716: aload_2
    //   717: dload #8
    //   719: dload #10
    //   721: dadd
    //   722: d2f
    //   723: invokevirtual setRotation : (F)V
    //   726: goto -> 815
    //   729: fload #28
    //   731: fstore_1
    //   732: fload #27
    //   734: fstore #22
    //   736: fload #24
    //   738: invokestatic isNaN : (F)Z
    //   741: ifne -> 815
    //   744: fload #33
    //   746: fconst_2
    //   747: fdiv
    //   748: fstore_1
    //   749: fload #32
    //   751: fconst_2
    //   752: fdiv
    //   753: fstore #22
    //   755: fconst_0
    //   756: f2d
    //   757: dstore #8
    //   759: fload #24
    //   761: f2d
    //   762: dstore #10
    //   764: fload #30
    //   766: fload #22
    //   768: fadd
    //   769: f2d
    //   770: fload #31
    //   772: fload_1
    //   773: fadd
    //   774: f2d
    //   775: invokestatic atan2 : (DD)D
    //   778: invokestatic toDegrees : (D)D
    //   781: dstore #12
    //   783: dload #10
    //   785: invokestatic isNaN : (D)Z
    //   788: pop
    //   789: dload #8
    //   791: invokestatic isNaN : (D)Z
    //   794: pop
    //   795: aload_2
    //   796: dload #8
    //   798: dload #10
    //   800: dload #12
    //   802: dadd
    //   803: dadd
    //   804: d2f
    //   805: invokevirtual setRotation : (F)V
    //   808: fload #27
    //   810: fstore #22
    //   812: fload #28
    //   814: fstore_1
    //   815: iconst_0
    //   816: istore #34
    //   818: aload_2
    //   819: instanceof androidx/constraintlayout/motion/widget/c
    //   822: ifeq -> 847
    //   825: aload_2
    //   826: checkcast androidx/constraintlayout/motion/widget/c
    //   829: fload_1
    //   830: fload #22
    //   832: fload #29
    //   834: fload_1
    //   835: fadd
    //   836: fload #22
    //   838: fload #26
    //   840: fadd
    //   841: invokeinterface a : (FFFF)V
    //   846: return
    //   847: fload_1
    //   848: ldc 0.5
    //   850: fadd
    //   851: fstore_1
    //   852: fload_1
    //   853: f2i
    //   854: istore #35
    //   856: fload #22
    //   858: ldc 0.5
    //   860: fadd
    //   861: fstore #22
    //   863: fload #22
    //   865: f2i
    //   866: istore #36
    //   868: fload_1
    //   869: fload #29
    //   871: fadd
    //   872: f2i
    //   873: istore #37
    //   875: fload #22
    //   877: fload #26
    //   879: fadd
    //   880: f2i
    //   881: istore #38
    //   883: iload #37
    //   885: iload #35
    //   887: isub
    //   888: istore #39
    //   890: iload #38
    //   892: iload #36
    //   894: isub
    //   895: istore #40
    //   897: iload #39
    //   899: aload_2
    //   900: invokevirtual getMeasuredWidth : ()I
    //   903: if_icmpne -> 915
    //   906: iload #40
    //   908: aload_2
    //   909: invokevirtual getMeasuredHeight : ()I
    //   912: if_icmpeq -> 918
    //   915: iconst_1
    //   916: istore #34
    //   918: iload #34
    //   920: ifne -> 928
    //   923: iload #7
    //   925: ifeq -> 946
    //   928: aload_2
    //   929: iload #39
    //   931: ldc 1073741824
    //   933: invokestatic makeMeasureSpec : (II)I
    //   936: iload #40
    //   938: ldc 1073741824
    //   940: invokestatic makeMeasureSpec : (II)I
    //   943: invokevirtual measure : (II)V
    //   946: aload_2
    //   947: iload #35
    //   949: iload #36
    //   951: iload #37
    //   953: iload #38
    //   955: invokevirtual layout : (IIII)V
    //   958: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\constraintlayout\motion\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */