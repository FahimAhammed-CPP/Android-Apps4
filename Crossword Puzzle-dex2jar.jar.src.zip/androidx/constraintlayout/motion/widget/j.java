package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Interpolator;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.p;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class j extends ConstraintLayout implements p {
  public static boolean I0;
  
  private Runnable A0;
  
  private int[] B0;
  
  int C0;
  
  private int D0;
  
  private boolean E0;
  
  e F0;
  
  private boolean G0;
  
  ArrayList<Integer> H0;
  
  Interpolator M;
  
  Interpolator N;
  
  float O;
  
  private int P;
  
  int Q;
  
  private int R;
  
  private boolean S;
  
  HashMap<View, g> T;
  
  private long U;
  
  private float V;
  
  float W;
  
  float a0;
  
  private long b0;
  
  float c0;
  
  private boolean d0;
  
  boolean e0;
  
  private d f0;
  
  int g0;
  
  private boolean h0;
  
  private b i0;
  
  boolean j0;
  
  float k0;
  
  float l0;
  
  long m0;
  
  float n0;
  
  private boolean o0;
  
  private ArrayList<h> p0;
  
  private ArrayList<h> q0;
  
  private ArrayList<h> r0;
  
  private CopyOnWriteArrayList<d> s0;
  
  private int t0;
  
  private float u0;
  
  boolean v0;
  
  protected boolean w0;
  
  float x0;
  
  private boolean y0;
  
  private c z0;
  
  private void G() {
    // Byte code:
    //   0: aload_0
    //   1: getfield f0 : Landroidx/constraintlayout/motion/widget/j$d;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield s0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   11: astore_2
    //   12: aload_2
    //   13: ifnull -> 219
    //   16: aload_2
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 219
    //   23: aload_0
    //   24: getfield u0 : F
    //   27: aload_0
    //   28: getfield W : F
    //   31: fcmpl
    //   32: ifeq -> 219
    //   35: aload_0
    //   36: getfield t0 : I
    //   39: iconst_m1
    //   40: if_icmpeq -> 121
    //   43: aload_0
    //   44: getfield f0 : Landroidx/constraintlayout/motion/widget/j$d;
    //   47: astore_2
    //   48: aload_2
    //   49: ifnull -> 67
    //   52: aload_2
    //   53: aload_0
    //   54: aload_0
    //   55: getfield P : I
    //   58: aload_0
    //   59: getfield R : I
    //   62: invokeinterface b : (Landroidx/constraintlayout/motion/widget/j;II)V
    //   67: aload_0
    //   68: getfield s0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   71: astore_2
    //   72: aload_2
    //   73: ifnull -> 116
    //   76: aload_2
    //   77: invokevirtual iterator : ()Ljava/util/Iterator;
    //   80: astore_2
    //   81: aload_2
    //   82: invokeinterface hasNext : ()Z
    //   87: ifeq -> 116
    //   90: aload_2
    //   91: invokeinterface next : ()Ljava/lang/Object;
    //   96: checkcast androidx/constraintlayout/motion/widget/j$d
    //   99: aload_0
    //   100: aload_0
    //   101: getfield P : I
    //   104: aload_0
    //   105: getfield R : I
    //   108: invokeinterface b : (Landroidx/constraintlayout/motion/widget/j;II)V
    //   113: goto -> 81
    //   116: aload_0
    //   117: iconst_1
    //   118: putfield v0 : Z
    //   121: aload_0
    //   122: iconst_m1
    //   123: putfield t0 : I
    //   126: aload_0
    //   127: getfield W : F
    //   130: fstore_1
    //   131: aload_0
    //   132: fload_1
    //   133: putfield u0 : F
    //   136: aload_0
    //   137: getfield f0 : Landroidx/constraintlayout/motion/widget/j$d;
    //   140: astore_2
    //   141: aload_2
    //   142: ifnull -> 161
    //   145: aload_2
    //   146: aload_0
    //   147: aload_0
    //   148: getfield P : I
    //   151: aload_0
    //   152: getfield R : I
    //   155: fload_1
    //   156: invokeinterface a : (Landroidx/constraintlayout/motion/widget/j;IIF)V
    //   161: aload_0
    //   162: getfield s0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   165: astore_2
    //   166: aload_2
    //   167: ifnull -> 214
    //   170: aload_2
    //   171: invokevirtual iterator : ()Ljava/util/Iterator;
    //   174: astore_2
    //   175: aload_2
    //   176: invokeinterface hasNext : ()Z
    //   181: ifeq -> 214
    //   184: aload_2
    //   185: invokeinterface next : ()Ljava/lang/Object;
    //   190: checkcast androidx/constraintlayout/motion/widget/j$d
    //   193: aload_0
    //   194: aload_0
    //   195: getfield P : I
    //   198: aload_0
    //   199: getfield R : I
    //   202: aload_0
    //   203: getfield W : F
    //   206: invokeinterface a : (Landroidx/constraintlayout/motion/widget/j;IIF)V
    //   211: goto -> 175
    //   214: aload_0
    //   215: iconst_1
    //   216: putfield v0 : Z
    //   219: return
  }
  
  private void J() {
    if (this.f0 == null) {
      CopyOnWriteArrayList<d> copyOnWriteArrayList = this.s0;
      if (copyOnWriteArrayList == null || copyOnWriteArrayList.isEmpty())
        return; 
    } 
    this.v0 = false;
    for (Integer integer : this.H0) {
      d d1 = this.f0;
      if (d1 != null)
        d1.c(this, integer.intValue()); 
      CopyOnWriteArrayList<d> copyOnWriteArrayList = this.s0;
      if (copyOnWriteArrayList != null) {
        Iterator<d> iterator = copyOnWriteArrayList.iterator();
        while (iterator.hasNext())
          ((d)iterator.next()).c(this, integer.intValue()); 
      } 
    } 
    this.H0.clear();
  }
  
  void E(float paramFloat) {}
  
  void F(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b0 : J
    //   4: ldc2_w -1
    //   7: lcmp
    //   8: ifne -> 19
    //   11: aload_0
    //   12: aload_0
    //   13: invokevirtual getNanoTime : ()J
    //   16: putfield b0 : J
    //   19: aload_0
    //   20: getfield a0 : F
    //   23: fstore_2
    //   24: fload_2
    //   25: fconst_0
    //   26: fcmpl
    //   27: ifle -> 41
    //   30: fload_2
    //   31: fconst_1
    //   32: fcmpg
    //   33: ifge -> 41
    //   36: aload_0
    //   37: iconst_m1
    //   38: putfield Q : I
    //   41: aload_0
    //   42: getfield o0 : Z
    //   45: istore #12
    //   47: iconst_1
    //   48: istore #8
    //   50: iconst_1
    //   51: istore #9
    //   53: iconst_0
    //   54: istore #10
    //   56: iload #12
    //   58: ifne -> 81
    //   61: aload_0
    //   62: getfield e0 : Z
    //   65: ifeq -> 982
    //   68: iload_1
    //   69: ifne -> 81
    //   72: aload_0
    //   73: getfield c0 : F
    //   76: fload_2
    //   77: fcmpl
    //   78: ifeq -> 982
    //   81: aload_0
    //   82: getfield c0 : F
    //   85: fload_2
    //   86: fsub
    //   87: invokestatic signum : (F)F
    //   90: fstore #5
    //   92: aload_0
    //   93: invokevirtual getNanoTime : ()J
    //   96: lstore #13
    //   98: aload_0
    //   99: getfield M : Landroid/view/animation/Interpolator;
    //   102: astore #15
    //   104: aload #15
    //   106: instanceof androidx/constraintlayout/motion/widget/i
    //   109: ifne -> 135
    //   112: lload #13
    //   114: aload_0
    //   115: getfield b0 : J
    //   118: lsub
    //   119: l2f
    //   120: fload #5
    //   122: fmul
    //   123: ldc 1.0E-9
    //   125: fmul
    //   126: aload_0
    //   127: getfield V : F
    //   130: fdiv
    //   131: fstore_3
    //   132: goto -> 137
    //   135: fconst_0
    //   136: fstore_3
    //   137: aload_0
    //   138: getfield a0 : F
    //   141: fload_3
    //   142: fadd
    //   143: fstore_2
    //   144: aload_0
    //   145: getfield d0 : Z
    //   148: ifeq -> 156
    //   151: aload_0
    //   152: getfield c0 : F
    //   155: fstore_2
    //   156: fload #5
    //   158: fconst_0
    //   159: fcmpl
    //   160: ifle -> 172
    //   163: fload_2
    //   164: aload_0
    //   165: getfield c0 : F
    //   168: fcmpl
    //   169: ifge -> 188
    //   172: fload #5
    //   174: fconst_0
    //   175: fcmpg
    //   176: ifgt -> 204
    //   179: fload_2
    //   180: aload_0
    //   181: getfield c0 : F
    //   184: fcmpg
    //   185: ifgt -> 204
    //   188: aload_0
    //   189: getfield c0 : F
    //   192: fstore_2
    //   193: aload_0
    //   194: iconst_0
    //   195: putfield e0 : Z
    //   198: iconst_1
    //   199: istore #7
    //   201: goto -> 207
    //   204: iconst_0
    //   205: istore #7
    //   207: aload_0
    //   208: fload_2
    //   209: putfield a0 : F
    //   212: aload_0
    //   213: fload_2
    //   214: putfield W : F
    //   217: aload_0
    //   218: lload #13
    //   220: putfield b0 : J
    //   223: aload #15
    //   225: ifnull -> 456
    //   228: iload #7
    //   230: ifne -> 456
    //   233: aload_0
    //   234: getfield h0 : Z
    //   237: ifeq -> 386
    //   240: aload #15
    //   242: lload #13
    //   244: aload_0
    //   245: getfield U : J
    //   248: lsub
    //   249: l2f
    //   250: ldc 1.0E-9
    //   252: fmul
    //   253: invokeinterface getInterpolation : (F)F
    //   258: fstore #4
    //   260: aload_0
    //   261: getfield M : Landroid/view/animation/Interpolator;
    //   264: astore #15
    //   266: aload #15
    //   268: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   271: pop
    //   272: aload_0
    //   273: fload #4
    //   275: putfield a0 : F
    //   278: aload_0
    //   279: lload #13
    //   281: putfield b0 : J
    //   284: fload #4
    //   286: fstore_2
    //   287: aload #15
    //   289: instanceof androidx/constraintlayout/motion/widget/i
    //   292: ifeq -> 453
    //   295: aload #15
    //   297: checkcast androidx/constraintlayout/motion/widget/i
    //   300: invokevirtual a : ()F
    //   303: fstore #6
    //   305: aload_0
    //   306: fload #6
    //   308: putfield O : F
    //   311: fload #6
    //   313: invokestatic abs : (F)F
    //   316: pop
    //   317: aload_0
    //   318: getfield V : F
    //   321: fstore_2
    //   322: fload #4
    //   324: fstore_3
    //   325: fload #6
    //   327: fconst_0
    //   328: fcmpl
    //   329: ifle -> 354
    //   332: fload #4
    //   334: fstore_3
    //   335: fload #4
    //   337: fconst_1
    //   338: fcmpl
    //   339: iflt -> 354
    //   342: aload_0
    //   343: fconst_1
    //   344: putfield a0 : F
    //   347: aload_0
    //   348: iconst_0
    //   349: putfield e0 : Z
    //   352: fconst_1
    //   353: fstore_3
    //   354: fload_3
    //   355: fstore_2
    //   356: fload #6
    //   358: fconst_0
    //   359: fcmpg
    //   360: ifge -> 453
    //   363: fload_3
    //   364: fstore_2
    //   365: fload_3
    //   366: fconst_0
    //   367: fcmpg
    //   368: ifgt -> 453
    //   371: aload_0
    //   372: fconst_0
    //   373: putfield a0 : F
    //   376: aload_0
    //   377: iconst_0
    //   378: putfield e0 : Z
    //   381: fconst_0
    //   382: fstore_2
    //   383: goto -> 461
    //   386: aload #15
    //   388: fload_2
    //   389: invokeinterface getInterpolation : (F)F
    //   394: fstore #4
    //   396: aload_0
    //   397: getfield M : Landroid/view/animation/Interpolator;
    //   400: astore #15
    //   402: aload #15
    //   404: instanceof androidx/constraintlayout/motion/widget/i
    //   407: ifeq -> 428
    //   410: aload_0
    //   411: aload #15
    //   413: checkcast androidx/constraintlayout/motion/widget/i
    //   416: invokevirtual a : ()F
    //   419: putfield O : F
    //   422: fload #4
    //   424: fstore_2
    //   425: goto -> 453
    //   428: aload_0
    //   429: aload #15
    //   431: fload_2
    //   432: fload_3
    //   433: fadd
    //   434: invokeinterface getInterpolation : (F)F
    //   439: fload #4
    //   441: fsub
    //   442: fload #5
    //   444: fmul
    //   445: fload_3
    //   446: fdiv
    //   447: putfield O : F
    //   450: fload #4
    //   452: fstore_2
    //   453: goto -> 461
    //   456: aload_0
    //   457: fload_3
    //   458: putfield O : F
    //   461: aload_0
    //   462: getfield O : F
    //   465: invokestatic abs : (F)F
    //   468: ldc 1.0E-5
    //   470: fcmpl
    //   471: ifle -> 481
    //   474: aload_0
    //   475: getstatic androidx/constraintlayout/motion/widget/j$e.q : Landroidx/constraintlayout/motion/widget/j$e;
    //   478: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   481: fload #5
    //   483: fconst_0
    //   484: fcmpl
    //   485: ifle -> 497
    //   488: fload_2
    //   489: aload_0
    //   490: getfield c0 : F
    //   493: fcmpl
    //   494: ifge -> 517
    //   497: fload_2
    //   498: fstore_3
    //   499: fload #5
    //   501: fconst_0
    //   502: fcmpg
    //   503: ifgt -> 527
    //   506: fload_2
    //   507: fstore_3
    //   508: fload_2
    //   509: aload_0
    //   510: getfield c0 : F
    //   513: fcmpg
    //   514: ifgt -> 527
    //   517: aload_0
    //   518: getfield c0 : F
    //   521: fstore_3
    //   522: aload_0
    //   523: iconst_0
    //   524: putfield e0 : Z
    //   527: fload_3
    //   528: fconst_1
    //   529: fcmpl
    //   530: ifge -> 539
    //   533: fload_3
    //   534: fconst_0
    //   535: fcmpg
    //   536: ifgt -> 551
    //   539: aload_0
    //   540: iconst_0
    //   541: putfield e0 : Z
    //   544: aload_0
    //   545: getstatic androidx/constraintlayout/motion/widget/j$e.r : Landroidx/constraintlayout/motion/widget/j$e;
    //   548: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   551: aload_0
    //   552: invokevirtual getChildCount : ()I
    //   555: istore #11
    //   557: aload_0
    //   558: iconst_0
    //   559: putfield o0 : Z
    //   562: aload_0
    //   563: invokevirtual getNanoTime : ()J
    //   566: lstore #13
    //   568: aload_0
    //   569: fload_3
    //   570: putfield x0 : F
    //   573: aload_0
    //   574: getfield N : Landroid/view/animation/Interpolator;
    //   577: astore #15
    //   579: aload #15
    //   581: ifnonnull -> 589
    //   584: fload_3
    //   585: fstore_2
    //   586: goto -> 598
    //   589: aload #15
    //   591: fload_3
    //   592: invokeinterface getInterpolation : (F)F
    //   597: fstore_2
    //   598: aload_0
    //   599: getfield N : Landroid/view/animation/Interpolator;
    //   602: astore #15
    //   604: aload #15
    //   606: ifnull -> 650
    //   609: aload #15
    //   611: fload #5
    //   613: aload_0
    //   614: getfield V : F
    //   617: fdiv
    //   618: fload_3
    //   619: fadd
    //   620: invokeinterface getInterpolation : (F)F
    //   625: fstore #4
    //   627: aload_0
    //   628: fload #4
    //   630: putfield O : F
    //   633: aload_0
    //   634: fload #4
    //   636: aload_0
    //   637: getfield N : Landroid/view/animation/Interpolator;
    //   640: fload_3
    //   641: invokeinterface getInterpolation : (F)F
    //   646: fsub
    //   647: putfield O : F
    //   650: iconst_0
    //   651: istore #7
    //   653: iload #7
    //   655: iload #11
    //   657: if_icmpge -> 716
    //   660: aload_0
    //   661: iload #7
    //   663: invokevirtual getChildAt : (I)Landroid/view/View;
    //   666: astore #15
    //   668: aload_0
    //   669: getfield T : Ljava/util/HashMap;
    //   672: aload #15
    //   674: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   677: checkcast androidx/constraintlayout/motion/widget/g
    //   680: astore #16
    //   682: aload #16
    //   684: ifnull -> 707
    //   687: aload_0
    //   688: aload_0
    //   689: getfield o0 : Z
    //   692: aload #16
    //   694: aload #15
    //   696: fload_2
    //   697: lload #13
    //   699: aconst_null
    //   700: invokevirtual c : (Landroid/view/View;FJLq/c;)Z
    //   703: ior
    //   704: putfield o0 : Z
    //   707: iload #7
    //   709: iconst_1
    //   710: iadd
    //   711: istore #7
    //   713: goto -> 653
    //   716: fload #5
    //   718: fconst_0
    //   719: fcmpl
    //   720: ifle -> 732
    //   723: fload_3
    //   724: aload_0
    //   725: getfield c0 : F
    //   728: fcmpl
    //   729: ifge -> 748
    //   732: fload #5
    //   734: fconst_0
    //   735: fcmpg
    //   736: ifgt -> 754
    //   739: fload_3
    //   740: aload_0
    //   741: getfield c0 : F
    //   744: fcmpg
    //   745: ifgt -> 754
    //   748: iconst_1
    //   749: istore #7
    //   751: goto -> 757
    //   754: iconst_0
    //   755: istore #7
    //   757: aload_0
    //   758: getfield o0 : Z
    //   761: ifne -> 783
    //   764: aload_0
    //   765: getfield e0 : Z
    //   768: ifne -> 783
    //   771: iload #7
    //   773: ifeq -> 783
    //   776: aload_0
    //   777: getstatic androidx/constraintlayout/motion/widget/j$e.r : Landroidx/constraintlayout/motion/widget/j$e;
    //   780: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   783: aload_0
    //   784: getfield w0 : Z
    //   787: ifeq -> 794
    //   790: aload_0
    //   791: invokevirtual requestLayout : ()V
    //   794: iload #7
    //   796: iconst_1
    //   797: ixor
    //   798: aload_0
    //   799: getfield o0 : Z
    //   802: ior
    //   803: istore_1
    //   804: aload_0
    //   805: iload_1
    //   806: putfield o0 : Z
    //   809: fload_3
    //   810: fconst_0
    //   811: fcmpg
    //   812: ifgt -> 847
    //   815: aload_0
    //   816: getfield P : I
    //   819: istore #7
    //   821: iload #7
    //   823: iconst_m1
    //   824: if_icmpeq -> 847
    //   827: aload_0
    //   828: getfield Q : I
    //   831: iload #7
    //   833: if_icmpne -> 839
    //   836: goto -> 847
    //   839: aload_0
    //   840: iload #7
    //   842: putfield Q : I
    //   845: aconst_null
    //   846: athrow
    //   847: fload_3
    //   848: f2d
    //   849: dconst_1
    //   850: dcmpl
    //   851: iflt -> 884
    //   854: aload_0
    //   855: getfield Q : I
    //   858: istore #7
    //   860: aload_0
    //   861: getfield R : I
    //   864: istore #11
    //   866: iload #7
    //   868: iload #11
    //   870: if_icmpne -> 876
    //   873: goto -> 884
    //   876: aload_0
    //   877: iload #11
    //   879: putfield Q : I
    //   882: aconst_null
    //   883: athrow
    //   884: iload_1
    //   885: ifne -> 934
    //   888: aload_0
    //   889: getfield e0 : Z
    //   892: ifeq -> 898
    //   895: goto -> 934
    //   898: fload #5
    //   900: fconst_0
    //   901: fcmpl
    //   902: ifle -> 911
    //   905: fload_3
    //   906: fconst_1
    //   907: fcmpl
    //   908: ifeq -> 924
    //   911: fload #5
    //   913: fconst_0
    //   914: fcmpg
    //   915: ifge -> 938
    //   918: fload_3
    //   919: fconst_0
    //   920: fcmpl
    //   921: ifne -> 938
    //   924: aload_0
    //   925: getstatic androidx/constraintlayout/motion/widget/j$e.r : Landroidx/constraintlayout/motion/widget/j$e;
    //   928: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   931: goto -> 938
    //   934: aload_0
    //   935: invokevirtual invalidate : ()V
    //   938: aload_0
    //   939: getfield o0 : Z
    //   942: ifne -> 982
    //   945: aload_0
    //   946: getfield e0 : Z
    //   949: ifne -> 982
    //   952: fload #5
    //   954: fconst_0
    //   955: fcmpl
    //   956: ifle -> 965
    //   959: fload_3
    //   960: fconst_1
    //   961: fcmpl
    //   962: ifeq -> 978
    //   965: fload #5
    //   967: fconst_0
    //   968: fcmpg
    //   969: ifge -> 982
    //   972: fload_3
    //   973: fconst_0
    //   974: fcmpl
    //   975: ifne -> 982
    //   978: aload_0
    //   979: invokevirtual I : ()V
    //   982: aload_0
    //   983: getfield a0 : F
    //   986: fstore_2
    //   987: fload_2
    //   988: fconst_1
    //   989: fcmpl
    //   990: iflt -> 1031
    //   993: aload_0
    //   994: getfield Q : I
    //   997: istore #7
    //   999: aload_0
    //   1000: getfield R : I
    //   1003: istore #8
    //   1005: iload #7
    //   1007: iload #8
    //   1009: if_icmpeq -> 1019
    //   1012: iload #9
    //   1014: istore #7
    //   1016: goto -> 1022
    //   1019: iconst_0
    //   1020: istore #7
    //   1022: aload_0
    //   1023: iload #8
    //   1025: putfield Q : I
    //   1028: goto -> 1079
    //   1031: iload #10
    //   1033: istore #7
    //   1035: fload_2
    //   1036: fconst_0
    //   1037: fcmpg
    //   1038: ifgt -> 1079
    //   1041: aload_0
    //   1042: getfield Q : I
    //   1045: istore #7
    //   1047: aload_0
    //   1048: getfield P : I
    //   1051: istore #9
    //   1053: iload #7
    //   1055: iload #9
    //   1057: if_icmpeq -> 1067
    //   1060: iload #8
    //   1062: istore #7
    //   1064: goto -> 1070
    //   1067: iconst_0
    //   1068: istore #7
    //   1070: aload_0
    //   1071: iload #9
    //   1073: putfield Q : I
    //   1076: goto -> 1028
    //   1079: aload_0
    //   1080: aload_0
    //   1081: getfield G0 : Z
    //   1084: iload #7
    //   1086: ior
    //   1087: putfield G0 : Z
    //   1090: iload #7
    //   1092: ifeq -> 1106
    //   1095: aload_0
    //   1096: getfield y0 : Z
    //   1099: ifne -> 1106
    //   1102: aload_0
    //   1103: invokevirtual requestLayout : ()V
    //   1106: aload_0
    //   1107: aload_0
    //   1108: getfield a0 : F
    //   1111: putfield W : F
    //   1114: return
  }
  
  protected void H() {
    // Byte code:
    //   0: aload_0
    //   1: getfield f0 : Landroidx/constraintlayout/motion/widget/j$d;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield s0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   11: astore_3
    //   12: aload_3
    //   13: ifnull -> 103
    //   16: aload_3
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 103
    //   23: aload_0
    //   24: getfield t0 : I
    //   27: iconst_m1
    //   28: if_icmpne -> 103
    //   31: aload_0
    //   32: aload_0
    //   33: getfield Q : I
    //   36: putfield t0 : I
    //   39: aload_0
    //   40: getfield H0 : Ljava/util/ArrayList;
    //   43: invokevirtual isEmpty : ()Z
    //   46: ifne -> 74
    //   49: aload_0
    //   50: getfield H0 : Ljava/util/ArrayList;
    //   53: astore_3
    //   54: aload_3
    //   55: aload_3
    //   56: invokevirtual size : ()I
    //   59: iconst_1
    //   60: isub
    //   61: invokevirtual get : (I)Ljava/lang/Object;
    //   64: checkcast java/lang/Integer
    //   67: invokevirtual intValue : ()I
    //   70: istore_1
    //   71: goto -> 76
    //   74: iconst_m1
    //   75: istore_1
    //   76: aload_0
    //   77: getfield Q : I
    //   80: istore_2
    //   81: iload_1
    //   82: iload_2
    //   83: if_icmpeq -> 103
    //   86: iload_2
    //   87: iconst_m1
    //   88: if_icmpeq -> 103
    //   91: aload_0
    //   92: getfield H0 : Ljava/util/ArrayList;
    //   95: iload_2
    //   96: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   99: invokevirtual add : (Ljava/lang/Object;)Z
    //   102: pop
    //   103: aload_0
    //   104: invokespecial J : ()V
    //   107: aload_0
    //   108: getfield A0 : Ljava/lang/Runnable;
    //   111: astore_3
    //   112: aload_3
    //   113: ifnull -> 122
    //   116: aload_3
    //   117: invokeinterface run : ()V
    //   122: aload_0
    //   123: getfield B0 : [I
    //   126: astore_3
    //   127: aload_3
    //   128: ifnull -> 171
    //   131: aload_0
    //   132: getfield C0 : I
    //   135: ifle -> 171
    //   138: aload_0
    //   139: aload_3
    //   140: iconst_0
    //   141: iaload
    //   142: invokevirtual O : (I)V
    //   145: aload_0
    //   146: getfield B0 : [I
    //   149: astore_3
    //   150: aload_3
    //   151: iconst_1
    //   152: aload_3
    //   153: iconst_0
    //   154: aload_3
    //   155: arraylength
    //   156: iconst_1
    //   157: isub
    //   158: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   161: aload_0
    //   162: aload_0
    //   163: getfield C0 : I
    //   166: iconst_1
    //   167: isub
    //   168: putfield C0 : I
    //   171: return
  }
  
  void I() {}
  
  public void K(float paramFloat1, float paramFloat2) {
    if (!isAttachedToWindow()) {
      if (this.z0 == null)
        this.z0 = new c(this); 
      this.z0.e(paramFloat1);
      this.z0.h(paramFloat2);
      return;
    } 
    setProgress(paramFloat1);
    setState(e.q);
    this.O = paramFloat2;
    float f = 1.0F;
    if (paramFloat2 != 0.0F) {
      if (paramFloat2 <= 0.0F)
        f = 0.0F; 
      E(f);
      return;
    } 
    if (paramFloat1 != 0.0F && paramFloat1 != 1.0F) {
      if (paramFloat1 <= 0.5F)
        f = 0.0F; 
      E(f);
    } 
  }
  
  public void L(int paramInt1, int paramInt2, int paramInt3) {
    setState(e.p);
    this.Q = paramInt1;
    this.P = -1;
    this.R = -1;
    androidx.constraintlayout.widget.c c1 = this.y;
    if (c1 != null)
      c1.d(paramInt1, paramInt2, paramInt3); 
  }
  
  public void M(int paramInt1, int paramInt2) {
    if (!isAttachedToWindow()) {
      if (this.z0 == null)
        this.z0 = new c(this); 
      this.z0.f(paramInt1);
      this.z0.d(paramInt2);
    } 
  }
  
  public void N() {
    E(1.0F);
    this.A0 = null;
  }
  
  public void O(int paramInt) {
    if (!isAttachedToWindow()) {
      if (this.z0 == null)
        this.z0 = new c(this); 
      this.z0.d(paramInt);
      return;
    } 
    P(paramInt, -1, -1);
  }
  
  public void P(int paramInt1, int paramInt2, int paramInt3) {
    Q(paramInt1, paramInt2, paramInt3, -1);
  }
  
  public void Q(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = this.Q;
    if (paramInt2 == paramInt1)
      return; 
    if (this.P == paramInt1) {
      E(0.0F);
      if (paramInt4 > 0)
        this.V = paramInt4 / 1000.0F; 
      return;
    } 
    if (this.R == paramInt1) {
      E(1.0F);
      if (paramInt4 > 0)
        this.V = paramInt4 / 1000.0F; 
      return;
    } 
    this.R = paramInt1;
    if (paramInt2 != -1) {
      M(paramInt2, paramInt1);
      E(1.0F);
      this.a0 = 0.0F;
      N();
      if (paramInt4 > 0)
        this.V = paramInt4 / 1000.0F; 
      return;
    } 
    this.h0 = false;
    this.c0 = 1.0F;
    this.W = 0.0F;
    this.a0 = 0.0F;
    this.b0 = getNanoTime();
    this.U = getNanoTime();
    this.d0 = false;
    this.M = null;
    if (paramInt4 == -1)
      throw null; 
    this.P = -1;
    throw null;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList<h> arrayList = this.r0;
    if (arrayList != null) {
      Iterator<h> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((h)iterator.next()).w(paramCanvas); 
    } 
    F(false);
    super.dispatchDraw(paramCanvas);
  }
  
  public int[] getConstraintSetIds() {
    return null;
  }
  
  public int getCurrentState() {
    return this.Q;
  }
  
  public ArrayList<l.a> getDefinedTransitions() {
    return null;
  }
  
  public b getDesignTool() {
    if (this.i0 == null)
      this.i0 = new b(this); 
    return this.i0;
  }
  
  public int getEndState() {
    return this.R;
  }
  
  protected long getNanoTime() {
    return System.nanoTime();
  }
  
  public float getProgress() {
    return this.a0;
  }
  
  public l getScene() {
    return null;
  }
  
  public int getStartState() {
    return this.P;
  }
  
  public float getTargetPosition() {
    return this.c0;
  }
  
  public Bundle getTransitionState() {
    if (this.z0 == null)
      this.z0 = new c(this); 
    this.z0.c();
    return this.z0.b();
  }
  
  public long getTransitionTimeMs() {
    return (long)(this.V * 1000.0F);
  }
  
  public float getVelocity() {
    return this.O;
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.m0 = getNanoTime();
    this.n0 = 0.0F;
    this.k0 = 0.0F;
    this.l0 = 0.0F;
  }
  
  public void i(View paramView, int paramInt) {}
  
  public boolean isAttachedToWindow() {
    return super.isAttachedToWindow();
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {}
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (this.j0 || paramInt1 != 0 || paramInt2 != 0) {
      paramArrayOfint[0] = paramArrayOfint[0] + paramInt3;
      paramArrayOfint[1] = paramArrayOfint[1] + paramInt4;
    } 
    this.j0 = false;
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return false;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    Display display = getDisplay();
    if (display != null)
      this.D0 = display.getRotation(); 
    I();
    c c1 = this.z0;
    if (c1 != null) {
      if (this.E0) {
        post(new a(this));
        return;
      } 
      c1.a();
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return false;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.y0 = true;
    try {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } finally {
      this.y0 = false;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onRtlPropertiesChanged(int paramInt) {}
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void onViewAdded(View paramView) {
    super.onViewAdded(paramView);
    if (paramView instanceof h) {
      h h = (h)paramView;
      if (this.s0 == null)
        this.s0 = new CopyOnWriteArrayList<d>(); 
      this.s0.add(h);
      if (h.v()) {
        if (this.p0 == null)
          this.p0 = new ArrayList<h>(); 
        this.p0.add(h);
      } 
      if (h.u()) {
        if (this.q0 == null)
          this.q0 = new ArrayList<h>(); 
        this.q0.add(h);
      } 
      if (h.t()) {
        if (this.r0 == null)
          this.r0 = new ArrayList<h>(); 
        this.r0.add(h);
      } 
    } 
  }
  
  public void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    ArrayList<h> arrayList = this.p0;
    if (arrayList != null)
      arrayList.remove(paramView); 
    arrayList = this.q0;
    if (arrayList != null)
      arrayList.remove(paramView); 
  }
  
  public void requestLayout() {
    if (!this.w0)
      int i = this.Q; 
    super.requestLayout();
  }
  
  public void setDebugMode(int paramInt) {
    this.g0 = paramInt;
    invalidate();
  }
  
  public void setDelayedApplicationOfInitialState(boolean paramBoolean) {
    this.E0 = paramBoolean;
  }
  
  public void setInteractionEnabled(boolean paramBoolean) {
    this.S = paramBoolean;
  }
  
  public void setInterpolatedProgress(float paramFloat) {
    setProgress(paramFloat);
  }
  
  public void setOnHide(float paramFloat) {
    ArrayList<h> arrayList = this.q0;
    if (arrayList != null) {
      int k = arrayList.size();
      for (int i = 0; i < k; i++)
        ((h)this.q0.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setOnShow(float paramFloat) {
    ArrayList<h> arrayList = this.p0;
    if (arrayList != null) {
      int k = arrayList.size();
      for (int i = 0; i < k; i++)
        ((h)this.p0.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setProgress(float paramFloat) {
    if (paramFloat < 0.0F || paramFloat > 1.0F)
      Log.w("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive"); 
    if (!isAttachedToWindow()) {
      if (this.z0 == null)
        this.z0 = new c(this); 
      this.z0.e(paramFloat);
      return;
    } 
    if (paramFloat <= 0.0F) {
      if (this.a0 == 1.0F && this.Q == this.R)
        setState(e.q); 
      this.Q = this.P;
      if (this.a0 == 0.0F) {
        setState(e.r);
        return;
      } 
    } else if (paramFloat >= 1.0F) {
      if (this.a0 == 0.0F && this.Q == this.P)
        setState(e.q); 
      this.Q = this.R;
      if (this.a0 == 1.0F) {
        setState(e.r);
        return;
      } 
    } else {
      this.Q = -1;
      setState(e.q);
    } 
  }
  
  public void setScene(l paraml) {
    r();
    throw null;
  }
  
  void setStartState(int paramInt) {
    if (!isAttachedToWindow()) {
      if (this.z0 == null)
        this.z0 = new c(this); 
      this.z0.f(paramInt);
      this.z0.d(paramInt);
      return;
    } 
    this.Q = paramInt;
  }
  
  void setState(e parame) {
    e e1 = e.r;
    if (parame == e1 && this.Q == -1)
      return; 
    e e2 = this.F0;
    this.F0 = parame;
    e e3 = e.q;
    if (e2 == e3 && parame == e3)
      G(); 
    int i = b.a[e2.ordinal()];
    if (i != 1 && i != 2) {
      if (i != 3)
        return; 
      if (parame == e1) {
        H();
        return;
      } 
    } else {
      if (parame == e3)
        G(); 
      if (parame == e1)
        H(); 
    } 
  }
  
  public void setTransition(int paramInt) {}
  
  protected void setTransition(l.a parama) {
    throw null;
  }
  
  public void setTransitionDuration(int paramInt) {
    Log.e("MotionLayout", "MotionScene not defined");
  }
  
  public void setTransitionListener(d paramd) {
    this.f0 = paramd;
  }
  
  public void setTransitionState(Bundle paramBundle) {
    if (this.z0 == null)
      this.z0 = new c(this); 
    this.z0.g(paramBundle);
    if (isAttachedToWindow())
      this.z0.a(); 
  }
  
  protected void t(int paramInt) {
    this.y = null;
  }
  
  public String toString() {
    Context context = getContext();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(a.a(context, this.P));
    stringBuilder.append("->");
    stringBuilder.append(a.a(context, this.R));
    stringBuilder.append(" (pos:");
    stringBuilder.append(this.a0);
    stringBuilder.append(" Dpos/Dt:");
    stringBuilder.append(this.O);
    return stringBuilder.toString();
  }
  
  class a implements Runnable {
    a(j this$0) {}
    
    public void run() {
      j.B(this.o).a();
    }
  }
  
  class c {
    float a = Float.NaN;
    
    float b = Float.NaN;
    
    int c = -1;
    
    int d = -1;
    
    final String e = "motion.progress";
    
    final String f = "motion.velocity";
    
    final String g = "motion.StartState";
    
    final String h = "motion.EndState";
    
    c(j this$0) {}
    
    void a() {
      int i = this.c;
      if (i != -1 || this.d != -1) {
        if (i == -1) {
          this.i.O(this.d);
        } else {
          int k = this.d;
          if (k == -1) {
            this.i.L(i, -1, -1);
          } else {
            this.i.M(i, k);
          } 
        } 
        this.i.setState(j.e.p);
      } 
      if (Float.isNaN(this.b)) {
        if (Float.isNaN(this.a))
          return; 
        this.i.setProgress(this.a);
        return;
      } 
      this.i.K(this.a, this.b);
      this.a = Float.NaN;
      this.b = Float.NaN;
      this.c = -1;
      this.d = -1;
    }
    
    public Bundle b() {
      Bundle bundle = new Bundle();
      bundle.putFloat("motion.progress", this.a);
      bundle.putFloat("motion.velocity", this.b);
      bundle.putInt("motion.StartState", this.c);
      bundle.putInt("motion.EndState", this.d);
      return bundle;
    }
    
    public void c() {
      this.d = j.C(this.i);
      this.c = j.D(this.i);
      this.b = this.i.getVelocity();
      this.a = this.i.getProgress();
    }
    
    public void d(int param1Int) {
      this.d = param1Int;
    }
    
    public void e(float param1Float) {
      this.a = param1Float;
    }
    
    public void f(int param1Int) {
      this.c = param1Int;
    }
    
    public void g(Bundle param1Bundle) {
      this.a = param1Bundle.getFloat("motion.progress");
      this.b = param1Bundle.getFloat("motion.velocity");
      this.c = param1Bundle.getInt("motion.StartState");
      this.d = param1Bundle.getInt("motion.EndState");
    }
    
    public void h(float param1Float) {
      this.b = param1Float;
    }
  }
  
  public static interface d {
    void a(j param1j, int param1Int1, int param1Int2, float param1Float);
    
    void b(j param1j, int param1Int1, int param1Int2);
    
    void c(j param1j, int param1Int);
  }
  
  enum e {
    o, p, q, r;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\constraintlayout\motion\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */