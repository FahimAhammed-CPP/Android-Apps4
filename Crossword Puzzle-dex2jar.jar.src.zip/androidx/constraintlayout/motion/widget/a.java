package androidx.constraintlayout.motion.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;

@SuppressLint({"LogConditional"})
public class a {
  public static String a(Context paramContext, int paramInt) {
    if (paramInt != -1)
      try {
        return paramContext.getResources().getResourceEntryName(paramInt);
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("?");
        stringBuilder.append(paramInt);
        return stringBuilder.toString();
      }  
    return "UNKNOWN";
  }
  
  public static String b(View paramView) {
    try {
      return paramView.getContext().getResources().getResourceEntryName(paramView.getId());
    } catch (Exception exception) {
      return "UNKNOWN";
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\constraintlayout\motion\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */