package androidx.constraintlayout.motion.widget;

import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.b;
import androidx.constraintlayout.widget.i;

public class h extends b implements j.d {
  protected View[] A;
  
  private boolean x;
  
  private boolean y;
  
  private float z;
  
  public void a(j paramj, int paramInt1, int paramInt2, float paramFloat) {}
  
  public void b(j paramj, int paramInt1, int paramInt2) {}
  
  public void c(j paramj, int paramInt) {}
  
  public float getProgress() {
    return this.z;
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    super.m(paramAttributeSet);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.B6);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == i.D6) {
          this.x = typedArray.getBoolean(k, this.x);
        } else if (k == i.C6) {
          this.y = typedArray.getBoolean(k, this.y);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void setProgress(float paramFloat) {
    this.z = paramFloat;
    int k = this.p;
    int i = 0;
    int j = 0;
    if (k > 0) {
      this.A = l((ConstraintLayout)getParent());
      for (i = j; i < this.p; i++)
        x(this.A[i], paramFloat); 
    } else {
      ViewGroup viewGroup = (ViewGroup)getParent();
      j = viewGroup.getChildCount();
      while (i < j) {
        View view = viewGroup.getChildAt(i);
        if (!(view instanceof h))
          x(view, paramFloat); 
        i++;
      } 
    } 
  }
  
  public boolean t() {
    return false;
  }
  
  public boolean u() {
    return this.y;
  }
  
  public boolean v() {
    return this.x;
  }
  
  public void w(Canvas paramCanvas) {}
  
  public void x(View paramView, float paramFloat) {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\constraintlayout\motion\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */