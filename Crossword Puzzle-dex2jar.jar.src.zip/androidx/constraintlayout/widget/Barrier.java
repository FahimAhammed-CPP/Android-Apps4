package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import s.a;
import s.e;
import s.h;

public class Barrier extends b {
  private int x;
  
  private int y;
  
  private a z;
  
  public Barrier(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  public Barrier(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setVisibility(8);
  }
  
  private void t(e parame, int paramInt, boolean paramBoolean) {
    this.y = paramInt;
    if (paramBoolean) {
      paramInt = this.x;
      if (paramInt == 5) {
        this.y = 1;
      } else if (paramInt == 6) {
        this.y = 0;
      } 
    } else {
      paramInt = this.x;
      if (paramInt == 5) {
        this.y = 0;
      } else if (paramInt == 6) {
        this.y = 1;
      } 
    } 
    if (parame instanceof a)
      ((a)parame).x1(this.y); 
  }
  
  public boolean getAllowsGoneWidget() {
    return this.z.r1();
  }
  
  public int getMargin() {
    return this.z.t1();
  }
  
  public int getType() {
    return this.x;
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    super.m(paramAttributeSet);
    this.z = new a();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == i.w1) {
          setType(typedArray.getInt(k, 0));
        } else if (k == i.v1) {
          this.z.w1(typedArray.getBoolean(k, true));
        } else if (k == i.x1) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.z.y1(k);
        } 
      } 
      typedArray.recycle();
    } 
    this.r = (h)this.z;
    s();
  }
  
  public void n(e parame, boolean paramBoolean) {
    t(parame, this.x, paramBoolean);
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.z.w1(paramBoolean);
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.z.y1(paramInt);
  }
  
  public void setMargin(int paramInt) {
    this.z.y1(paramInt);
  }
  
  public void setType(int paramInt) {
    this.x = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\constraintlayout\widget\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */