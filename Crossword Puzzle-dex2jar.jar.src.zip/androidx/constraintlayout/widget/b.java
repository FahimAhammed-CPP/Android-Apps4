package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.Arrays;
import java.util.HashMap;
import s.e;
import s.h;

public abstract class b extends View {
  protected int[] o = new int[32];
  
  protected int p;
  
  protected Context q;
  
  protected h r;
  
  protected boolean s = false;
  
  protected String t;
  
  protected String u;
  
  private View[] v = null;
  
  protected HashMap<Integer, String> w = new HashMap<Integer, String>();
  
  public b(Context paramContext) {
    super(paramContext);
    this.q = paramContext;
    m(null);
  }
  
  public b(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.q = paramContext;
    m(paramAttributeSet);
  }
  
  private void d(String paramString) {
    if (paramString != null) {
      if (paramString.length() == 0)
        return; 
      if (this.q == null)
        return; 
      paramString = paramString.trim();
      if (getParent() instanceof ConstraintLayout)
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent(); 
      int i = k(paramString);
      if (i != 0) {
        this.w.put(Integer.valueOf(i), paramString);
        e(i);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find id of \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      Log.w("ConstraintHelper", stringBuilder.toString());
    } 
  }
  
  private void e(int paramInt) {
    if (paramInt == getId())
      return; 
    int i = this.p;
    int[] arrayOfInt = this.o;
    if (i + 1 > arrayOfInt.length)
      this.o = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2); 
    arrayOfInt = this.o;
    i = this.p;
    arrayOfInt[i] = paramInt;
    this.p = i + 1;
  }
  
  private void f(String paramString) {
    if (paramString != null) {
      ConstraintLayout constraintLayout;
      if (paramString.length() == 0)
        return; 
      if (this.q == null)
        return; 
      String str = paramString.trim();
      paramString = null;
      if (getParent() instanceof ConstraintLayout)
        constraintLayout = (ConstraintLayout)getParent(); 
      if (constraintLayout == null) {
        Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
        return;
      } 
      int j = constraintLayout.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = constraintLayout.getChildAt(i);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.b && str.equals(((ConstraintLayout.b)layoutParams).c0))
          if (view.getId() == -1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("to use ConstraintTag view ");
            stringBuilder.append(view.getClass().getSimpleName());
            stringBuilder.append(" must have an ID");
            Log.w("ConstraintHelper", stringBuilder.toString());
          } else {
            e(view.getId());
          }  
      } 
    } 
  }
  
  private int j(ConstraintLayout paramConstraintLayout, String paramString) {
    if (paramString != null) {
      if (paramConstraintLayout == null)
        return 0; 
      Resources resources = this.q.getResources();
      if (resources == null)
        return 0; 
      int j = paramConstraintLayout.getChildCount();
      int i = 0;
      while (true) {
        if (i < j) {
          View view = paramConstraintLayout.getChildAt(i);
          if (view.getId() != -1) {
            String str = null;
            try {
              String str1 = resources.getResourceEntryName(view.getId());
              str = str1;
            } catch (android.content.res.Resources.NotFoundException notFoundException) {}
            if (paramString.equals(str))
              return view.getId(); 
          } 
          i++;
          continue;
        } 
        return 0;
      } 
    } 
    return 0;
  }
  
  private int k(String paramString) {
    ConstraintLayout constraintLayout;
    if (getParent() instanceof ConstraintLayout) {
      constraintLayout = (ConstraintLayout)getParent();
    } else {
      constraintLayout = null;
    } 
    boolean bool = isInEditMode();
    int i = 0;
    int j = i;
    if (bool) {
      j = i;
      if (constraintLayout != null) {
        Object object = constraintLayout.g(0, paramString);
        j = i;
        if (object instanceof Integer)
          j = ((Integer)object).intValue(); 
      } 
    } 
    i = j;
    if (j == 0) {
      i = j;
      if (constraintLayout != null)
        i = j(constraintLayout, paramString); 
    } 
    j = i;
    if (i == 0)
      try {
        j = h.class.getField(paramString).getInt(null);
      } catch (Exception exception) {
        j = i;
      }  
    i = j;
    if (j == 0)
      i = this.q.getResources().getIdentifier(paramString, "id", this.q.getPackageName()); 
    return i;
  }
  
  protected void g() {
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout)
      h((ConstraintLayout)viewParent); 
  }
  
  public int[] getReferencedIds() {
    return Arrays.copyOf(this.o, this.p);
  }
  
  protected void h(ConstraintLayout paramConstraintLayout) {
    float f;
    int j = getVisibility();
    if (Build.VERSION.SDK_INT >= 21) {
      f = getElevation();
    } else {
      f = 0.0F;
    } 
    for (int i = 0; i < this.p; i++) {
      View view = paramConstraintLayout.l(this.o[i]);
      if (view != null) {
        view.setVisibility(j);
        if (f > 0.0F && Build.VERSION.SDK_INT >= 21)
          view.setTranslationZ(view.getTranslationZ() + f); 
      } 
    } 
  }
  
  protected void i(ConstraintLayout paramConstraintLayout) {}
  
  protected View[] l(ConstraintLayout paramConstraintLayout) {
    View[] arrayOfView = this.v;
    if (arrayOfView == null || arrayOfView.length != this.p)
      this.v = new View[this.p]; 
    for (int i = 0; i < this.p; i++) {
      int j = this.o[i];
      this.v[i] = paramConstraintLayout.l(j);
    } 
    return this.v;
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == i.z1) {
          String str = typedArray.getString(k);
          this.t = str;
          setIds(str);
        } else if (k == i.A1) {
          String str = typedArray.getString(k);
          this.u = str;
          setReferenceTags(str);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void n(e parame, boolean paramBoolean) {}
  
  public void o(ConstraintLayout paramConstraintLayout) {}
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    String str = this.t;
    if (str != null)
      setIds(str); 
    str = this.u;
    if (str != null)
      setReferenceTags(str); 
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.s) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    setMeasuredDimension(0, 0);
  }
  
  public void p(ConstraintLayout paramConstraintLayout) {}
  
  public void q(ConstraintLayout paramConstraintLayout) {}
  
  public void r(ConstraintLayout paramConstraintLayout) {
    if (isInEditMode())
      setIds(this.t); 
    h h1 = this.r;
    if (h1 == null)
      return; 
    h1.c();
    for (int i = 0; i < this.p; i++) {
      int j = this.o[i];
      View view2 = paramConstraintLayout.l(j);
      View view1 = view2;
      if (view2 == null) {
        String str = this.w.get(Integer.valueOf(j));
        j = j(paramConstraintLayout, str);
        view1 = view2;
        if (j != 0) {
          this.o[i] = j;
          this.w.put(Integer.valueOf(j), str);
          view1 = paramConstraintLayout.l(j);
        } 
      } 
      if (view1 != null)
        this.r.a(paramConstraintLayout.p(view1)); 
    } 
    this.r.b(paramConstraintLayout.q);
  }
  
  public void s() {
    if (this.r == null)
      return; 
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.b)
      ((ConstraintLayout.b)layoutParams).v0 = (e)this.r; 
  }
  
  protected void setIds(String paramString) {
    this.t = paramString;
    if (paramString == null)
      return; 
    int i = 0;
    this.p = 0;
    while (true) {
      int j = paramString.indexOf(',', i);
      if (j == -1) {
        d(paramString.substring(i));
        return;
      } 
      d(paramString.substring(i, j));
      i = j + 1;
    } 
  }
  
  protected void setReferenceTags(String paramString) {
    this.u = paramString;
    if (paramString == null)
      return; 
    int i = 0;
    this.p = 0;
    while (true) {
      int j = paramString.indexOf(',', i);
      if (j == -1) {
        f(paramString.substring(i));
        return;
      } 
      f(paramString.substring(i, j));
      i = j + 1;
    } 
  }
  
  public void setReferencedIds(int[] paramArrayOfint) {
    this.t = null;
    int i = 0;
    this.p = 0;
    while (i < paramArrayOfint.length) {
      e(paramArrayOfint[i]);
      i++;
    } 
  }
  
  public void setTag(int paramInt, Object paramObject) {
    super.setTag(paramInt, paramObject);
    if (paramObject == null && this.t == null)
      e(paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\constraintlayout\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */