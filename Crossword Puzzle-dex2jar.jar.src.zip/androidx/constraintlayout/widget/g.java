package androidx.constraintlayout.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;
import s.e;

public class g extends View {
  private int o;
  
  private View p;
  
  private int q;
  
  public void a(ConstraintLayout paramConstraintLayout) {
    if (this.p == null)
      return; 
    ConstraintLayout.b b1 = (ConstraintLayout.b)getLayoutParams();
    ConstraintLayout.b b2 = (ConstraintLayout.b)this.p.getLayoutParams();
    b2.v0.g1(0);
    e.b b3 = b1.v0.y();
    e.b b4 = e.b.o;
    if (b3 != b4)
      b1.v0.h1(b2.v0.U()); 
    if (b1.v0.R() != b4)
      b1.v0.I0(b2.v0.v()); 
    b2.v0.g1(8);
  }
  
  public void b(ConstraintLayout paramConstraintLayout) {
    if (this.o == -1 && !isInEditMode())
      setVisibility(this.q); 
    View view = paramConstraintLayout.findViewById(this.o);
    this.p = view;
    if (view != null) {
      ((ConstraintLayout.b)view.getLayoutParams()).j0 = true;
      this.p.setVisibility(0);
      setVisibility(0);
    } 
  }
  
  public View getContent() {
    return this.p;
  }
  
  public int getEmptyVisibility() {
    return this.q;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (isInEditMode()) {
      paramCanvas.drawRGB(223, 223, 223);
      Paint paint = new Paint();
      paint.setARGB(255, 210, 210, 210);
      paint.setTextAlign(Paint.Align.CENTER);
      paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
      Rect rect = new Rect();
      paramCanvas.getClipBounds(rect);
      paint.setTextSize(rect.height());
      int i = rect.height();
      int j = rect.width();
      paint.setTextAlign(Paint.Align.LEFT);
      paint.getTextBounds("?", 0, 1, rect);
      paramCanvas.drawText("?", j / 2.0F - rect.width() / 2.0F - rect.left, i / 2.0F + rect.height() / 2.0F - rect.bottom, paint);
    } 
  }
  
  public void setContentId(int paramInt) {
    if (this.o == paramInt)
      return; 
    View view = this.p;
    if (view != null) {
      view.setVisibility(0);
      ((ConstraintLayout.b)this.p.getLayoutParams()).j0 = false;
      this.p = null;
    } 
    this.o = paramInt;
    if (paramInt != -1) {
      view = ((View)getParent()).findViewById(paramInt);
      if (view != null)
        view.setVisibility(8); 
    } 
  }
  
  public void setEmptyVisibility(int paramInt) {
    this.q = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\constraintlayout\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */