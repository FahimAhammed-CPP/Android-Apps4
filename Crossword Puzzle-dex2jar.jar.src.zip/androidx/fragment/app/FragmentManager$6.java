package androidx.fragment.app;

import android.os.Bundle;
import androidx.lifecycle.i;
import androidx.lifecycle.k;
import androidx.lifecycle.l;
import androidx.lifecycle.m;

class FragmentManager$6 implements k {
  public void d(m paramm, i.b paramb) {
    if (paramb == i.b.ON_START) {
      Bundle bundle = (Bundle)m.a(this.d).get(this.a);
      if (bundle != null) {
        this.b.a(this.a, bundle);
        this.d.q(this.a);
      } 
    } 
    if (paramb == i.b.ON_DESTROY) {
      this.c.c((l)this);
      m.b(this.d).remove(this.a);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\FragmentManager$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */