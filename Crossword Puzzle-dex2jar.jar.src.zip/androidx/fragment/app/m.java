package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.lifecycle.h0;
import androidx.lifecycle.i0;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class m {
  private static boolean O = false;
  
  static boolean P = true;
  
  private androidx.activity.result.c<androidx.activity.result.e> A;
  
  private androidx.activity.result.c<String[]> B;
  
  ArrayDeque<m> C = new ArrayDeque<m>();
  
  private boolean D;
  
  private boolean E;
  
  private boolean F;
  
  private boolean G;
  
  private boolean H;
  
  private ArrayList<a> I;
  
  private ArrayList<Boolean> J;
  
  private ArrayList<Fragment> K;
  
  private ArrayList<q> L;
  
  private p M;
  
  private Runnable N = new g(this);
  
  private final ArrayList<o> a = new ArrayList<o>();
  
  private boolean b;
  
  private final u c = new u();
  
  ArrayList<a> d;
  
  private ArrayList<Fragment> e;
  
  private final k f = new k(this);
  
  private OnBackPressedDispatcher g;
  
  private final androidx.activity.g h = new c(this, false);
  
  private final AtomicInteger i = new AtomicInteger();
  
  private final Map<String, Bundle> j = Collections.synchronizedMap(new HashMap<String, Bundle>());
  
  private final Map<String, Object> k = Collections.synchronizedMap(new HashMap<String, Object>());
  
  private ArrayList<n> l;
  
  private Map<Fragment, HashSet<androidx.core.os.e>> m = Collections.synchronizedMap(new HashMap<Fragment, HashSet<androidx.core.os.e>>());
  
  private final w.g n = new d(this);
  
  private final l o = new l(this);
  
  private final CopyOnWriteArrayList<q> p = new CopyOnWriteArrayList<q>();
  
  int q = -1;
  
  private j<?> r;
  
  private g s;
  
  private Fragment t;
  
  Fragment u;
  
  private i v = null;
  
  private i w = new e(this);
  
  private c0 x = null;
  
  private c0 y = new f(this);
  
  private androidx.activity.result.c<Intent> z;
  
  static boolean E0(int paramInt) {
    return (O || Log.isLoggable("FragmentManager", paramInt));
  }
  
  private boolean F0(Fragment paramFragment) {
    return ((paramFragment.R && paramFragment.S) || paramFragment.I.n());
  }
  
  private void L(Fragment paramFragment) {
    if (paramFragment != null && paramFragment.equals(f0(paramFragment.t)))
      paramFragment.k1(); 
  }
  
  private void L0(o.b<Fragment> paramb) {
    int i1 = paramb.size();
    for (int n = 0; n < i1; n++) {
      Fragment fragment = (Fragment)paramb.r(n);
      if (!fragment.z) {
        View view = fragment.s1();
        fragment.c0 = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  private void S(int paramInt) {
    try {
      this.b = true;
      this.c.d(paramInt);
      N0(paramInt, false);
      if (P) {
        Iterator<b0> iterator = r().iterator();
        while (iterator.hasNext())
          ((b0)iterator.next()).j(); 
      } 
      this.b = false;
      return;
    } finally {
      this.b = false;
    } 
  }
  
  private void V() {
    if (this.H) {
      this.H = false;
      n1();
    } 
  }
  
  private boolean W0(String paramString, int paramInt1, int paramInt2) {
    a0(false);
    Z(true);
    Fragment fragment = this.u;
    if (fragment != null && paramInt1 < 0 && paramString == null && fragment.t().V0())
      return true; 
    boolean bool = X0(this.I, this.J, paramString, paramInt1, paramInt2);
    if (bool) {
      this.b = true;
      try {
        c1(this.I, this.J);
      } finally {
        p();
      } 
    } 
    p1();
    V();
    this.c.b();
    return bool;
  }
  
  private void X() {
    if (P) {
      Iterator<b0> iterator = r().iterator();
      while (iterator.hasNext())
        ((b0)iterator.next()).j(); 
    } else if (!this.m.isEmpty()) {
      for (Fragment fragment : this.m.keySet()) {
        m(fragment);
        O0(fragment);
      } 
    } 
  }
  
  private int Y0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, o.b<Fragment> paramb) {
    int n = paramInt2 - 1;
    int i1;
    for (i1 = paramInt2; n >= paramInt1; i1 = i2) {
      boolean bool;
      a a = paramArrayList.get(n);
      boolean bool1 = ((Boolean)paramArrayList1.get(n)).booleanValue();
      if (a.D() && !a.B(paramArrayList, n + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int i2 = i1;
      if (bool) {
        if (this.L == null)
          this.L = new ArrayList<q>(); 
        q q = new q(a, bool1);
        this.L.add(q);
        a.F(q);
        if (bool1) {
          a.w();
        } else {
          a.x(false);
        } 
        i2 = i1 - 1;
        if (n != i2) {
          paramArrayList.remove(n);
          paramArrayList.add(i2, a);
        } 
        d(paramb);
      } 
      n--;
    } 
    return i1;
  }
  
  private void Z(boolean paramBoolean) {
    if (!this.b) {
      if (this.r == null) {
        if (this.G)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      if (Looper.myLooper() == this.r.l().getLooper()) {
        if (!paramBoolean)
          o(); 
        if (this.I == null) {
          this.I = new ArrayList<a>();
          this.J = new ArrayList<Boolean>();
        } 
        this.b = true;
        try {
          e0(null, null);
          return;
        } finally {
          this.b = false;
        } 
      } 
      throw new IllegalStateException("Must be called from main thread of fragment host");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private static void c0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      a a = paramArrayList.get(paramInt1);
      boolean bool1 = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool = true;
      if (bool1) {
        a.s(-1);
        if (paramInt1 != paramInt2 - 1)
          bool = false; 
        a.x(bool);
      } else {
        a.s(1);
        a.w();
      } 
      paramInt1++;
    } 
  }
  
  private void c1(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList.isEmpty())
      return; 
    if (paramArrayList.size() == paramArrayList1.size()) {
      e0(paramArrayList, paramArrayList1);
      int i2 = paramArrayList.size();
      int n = 0;
      int i1;
      for (i1 = 0; n < i2; i1 = i3) {
        int i4 = n;
        int i3 = i1;
        if (!((a)paramArrayList.get(n)).r) {
          if (i1 != n)
            d0(paramArrayList, paramArrayList1, i1, n); 
          i1 = n + 1;
          i3 = i1;
          if (((Boolean)paramArrayList1.get(n)).booleanValue())
            while (true) {
              i3 = i1;
              if (i1 < i2) {
                i3 = i1;
                if (((Boolean)paramArrayList1.get(i1)).booleanValue()) {
                  i3 = i1;
                  if (!((a)paramArrayList.get(i1)).r) {
                    i1++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          d0(paramArrayList, paramArrayList1, n, i3);
          i4 = i3 - 1;
        } 
        n = i4 + 1;
      } 
      if (i1 != i2)
        d0(paramArrayList, paramArrayList1, i1, i2); 
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Internal error with the back stack records");
    throw illegalStateException;
  }
  
  private void d(o.b<Fragment> paramb) {
    int n = this.q;
    if (n < 1)
      return; 
    n = Math.min(n, 5);
    for (Fragment fragment : this.c.n()) {
      if (fragment.o < n) {
        P0(fragment, n);
        if (fragment.V != null && !fragment.N && fragment.a0)
          paramb.add(fragment); 
      } 
    } 
  }
  
  private void d0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    boolean bool1 = ((a)paramArrayList.get(paramInt1)).r;
    ArrayList<Fragment> arrayList = this.K;
    if (arrayList == null) {
      this.K = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.K.addAll(this.c.n());
    Fragment fragment = w0();
    int n = paramInt1;
    boolean bool = false;
    while (n < paramInt2) {
      a a = paramArrayList.get(n);
      if (!((Boolean)paramArrayList1.get(n)).booleanValue()) {
        fragment = a.y(this.K, fragment);
      } else {
        fragment = a.G(this.K, fragment);
      } 
      if (bool || a.i) {
        bool = true;
      } else {
        bool = false;
      } 
      n++;
    } 
    this.K.clear();
    if (!bool1 && this.q >= 1)
      if (P) {
        for (n = paramInt1; n < paramInt2; n++) {
          Iterator<v.a> iterator = ((a)paramArrayList.get(n)).c.iterator();
          while (iterator.hasNext()) {
            Fragment fragment1 = ((v.a)iterator.next()).b;
            if (fragment1 != null && fragment1.G != null) {
              t t = v(fragment1);
              this.c.p(t);
            } 
          } 
        } 
      } else {
        w.B(this.r.j(), this.s, paramArrayList, paramArrayList1, paramInt1, paramInt2, false, this.n);
      }  
    c0(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (P) {
      bool1 = ((Boolean)paramArrayList1.get(paramInt2 - 1)).booleanValue();
      for (n = paramInt1; n < paramInt2; n++) {
        a a = paramArrayList.get(n);
        if (bool1) {
          int i1;
          for (i1 = a.c.size() - 1; i1 >= 0; i1--) {
            Fragment fragment1 = ((v.a)a.c.get(i1)).b;
            if (fragment1 != null)
              v(fragment1).m(); 
          } 
        } else {
          Iterator<v.a> iterator = a.c.iterator();
          while (iterator.hasNext()) {
            Fragment fragment1 = ((v.a)iterator.next()).b;
            if (fragment1 != null)
              v(fragment1).m(); 
          } 
        } 
      } 
      N0(this.q, true);
      for (b0 b0 : s(paramArrayList, paramInt1, paramInt2)) {
        b0.r(bool1);
        b0.p();
        b0.g();
      } 
    } else {
      if (bool1) {
        o.b<Fragment> b = new o.b();
        d(b);
        n = Y0(paramArrayList, paramArrayList1, paramInt1, paramInt2, b);
        L0(b);
      } else {
        n = paramInt2;
      } 
      ArrayList<Boolean> arrayList1 = paramArrayList1;
      if (n != paramInt1 && bool1) {
        if (this.q >= 1)
          w.B(this.r.j(), this.s, paramArrayList, paramArrayList1, paramInt1, n, true, this.n); 
        paramArrayList1 = arrayList1;
        N0(this.q, true);
      } else {
        paramArrayList1 = arrayList1;
      } 
    } 
    while (paramInt1 < paramInt2) {
      a a = paramArrayList.get(paramInt1);
      if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue() && a.v >= 0)
        a.v = -1; 
      a.E();
      paramInt1++;
    } 
    if (bool)
      d1(); 
  }
  
  private void d1() {
    if (this.l != null)
      for (int n = 0; n < this.l.size(); n++)
        ((n)this.l.get(n)).a();  
  }
  
  private void e0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield L : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 16
    //   11: iconst_0
    //   12: istore_3
    //   13: goto -> 22
    //   16: aload #7
    //   18: invokevirtual size : ()I
    //   21: istore_3
    //   22: iconst_0
    //   23: istore #4
    //   25: iload_3
    //   26: istore #6
    //   28: iload #4
    //   30: iload #6
    //   32: if_icmpge -> 260
    //   35: aload_0
    //   36: getfield L : Ljava/util/ArrayList;
    //   39: iload #4
    //   41: invokevirtual get : (I)Ljava/lang/Object;
    //   44: checkcast androidx/fragment/app/m$q
    //   47: astore #7
    //   49: aload_1
    //   50: ifnull -> 123
    //   53: aload #7
    //   55: getfield a : Z
    //   58: ifne -> 123
    //   61: aload_1
    //   62: aload #7
    //   64: getfield b : Landroidx/fragment/app/a;
    //   67: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   70: istore_3
    //   71: iload_3
    //   72: iconst_m1
    //   73: if_icmpeq -> 123
    //   76: aload_2
    //   77: ifnull -> 123
    //   80: aload_2
    //   81: iload_3
    //   82: invokevirtual get : (I)Ljava/lang/Object;
    //   85: checkcast java/lang/Boolean
    //   88: invokevirtual booleanValue : ()Z
    //   91: ifeq -> 123
    //   94: aload_0
    //   95: getfield L : Ljava/util/ArrayList;
    //   98: iload #4
    //   100: invokevirtual remove : (I)Ljava/lang/Object;
    //   103: pop
    //   104: iload #4
    //   106: iconst_1
    //   107: isub
    //   108: istore #5
    //   110: iload #6
    //   112: iconst_1
    //   113: isub
    //   114: istore_3
    //   115: aload #7
    //   117: invokevirtual c : ()V
    //   120: goto -> 248
    //   123: aload #7
    //   125: invokevirtual e : ()Z
    //   128: ifne -> 166
    //   131: iload #6
    //   133: istore_3
    //   134: iload #4
    //   136: istore #5
    //   138: aload_1
    //   139: ifnull -> 248
    //   142: iload #6
    //   144: istore_3
    //   145: iload #4
    //   147: istore #5
    //   149: aload #7
    //   151: getfield b : Landroidx/fragment/app/a;
    //   154: aload_1
    //   155: iconst_0
    //   156: aload_1
    //   157: invokevirtual size : ()I
    //   160: invokevirtual B : (Ljava/util/ArrayList;II)Z
    //   163: ifeq -> 248
    //   166: aload_0
    //   167: getfield L : Ljava/util/ArrayList;
    //   170: iload #4
    //   172: invokevirtual remove : (I)Ljava/lang/Object;
    //   175: pop
    //   176: iload #4
    //   178: iconst_1
    //   179: isub
    //   180: istore #5
    //   182: iload #6
    //   184: iconst_1
    //   185: isub
    //   186: istore_3
    //   187: aload_1
    //   188: ifnull -> 243
    //   191: aload #7
    //   193: getfield a : Z
    //   196: ifne -> 243
    //   199: aload_1
    //   200: aload #7
    //   202: getfield b : Landroidx/fragment/app/a;
    //   205: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   208: istore #4
    //   210: iload #4
    //   212: iconst_m1
    //   213: if_icmpeq -> 243
    //   216: aload_2
    //   217: ifnull -> 243
    //   220: aload_2
    //   221: iload #4
    //   223: invokevirtual get : (I)Ljava/lang/Object;
    //   226: checkcast java/lang/Boolean
    //   229: invokevirtual booleanValue : ()Z
    //   232: ifeq -> 243
    //   235: aload #7
    //   237: invokevirtual c : ()V
    //   240: goto -> 248
    //   243: aload #7
    //   245: invokevirtual d : ()V
    //   248: iload #5
    //   250: iconst_1
    //   251: iadd
    //   252: istore #4
    //   254: iload_3
    //   255: istore #6
    //   257: goto -> 28
    //   260: return
  }
  
  static int f1(int paramInt) {
    char c1 = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != 8194) ? 0 : 4097; 
      c1 = 'ဃ';
    } 
    return c1;
  }
  
  private void j0() {
    if (P) {
      Iterator<b0> iterator = r().iterator();
      while (iterator.hasNext())
        ((b0)iterator.next()).k(); 
    } else if (this.L != null) {
      while (!this.L.isEmpty())
        ((q)this.L.remove(0)).d(); 
    } 
  }
  
  private boolean k0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    synchronized (this.a) {
      boolean bool = this.a.isEmpty();
      int n = 0;
      if (bool)
        return false; 
      int i1 = this.a.size();
      bool = false;
      while (n < i1) {
        bool |= ((o)this.a.get(n)).a(paramArrayList, paramArrayList1);
        n++;
      } 
      this.a.clear();
      this.r.l().removeCallbacks(this.N);
      return bool;
    } 
  }
  
  private void l1(Fragment paramFragment) {
    ViewGroup viewGroup = o0(paramFragment);
    if (viewGroup != null && paramFragment.v() + paramFragment.y() + paramFragment.J() + paramFragment.K() > 0) {
      int n = f0.b.c;
      if (viewGroup.getTag(n) == null)
        viewGroup.setTag(n, paramFragment); 
      ((Fragment)viewGroup.getTag(n)).E1(paramFragment.I());
    } 
  }
  
  private void m(Fragment paramFragment) {
    HashSet hashSet = this.m.get(paramFragment);
    if (hashSet != null) {
      Iterator<androidx.core.os.e> iterator = hashSet.iterator();
      while (iterator.hasNext())
        ((androidx.core.os.e)iterator.next()).a(); 
      hashSet.clear();
      w(paramFragment);
      this.m.remove(paramFragment);
    } 
  }
  
  private p m0(Fragment paramFragment) {
    return this.M.h(paramFragment);
  }
  
  private void n1() {
    Iterator<t> iterator = this.c.k().iterator();
    while (iterator.hasNext())
      S0(iterator.next()); 
  }
  
  private void o() {
    if (!J0())
      return; 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private ViewGroup o0(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.U;
    if (viewGroup != null)
      return viewGroup; 
    if (paramFragment.L <= 0)
      return null; 
    if (this.s.g()) {
      View view = this.s.f(paramFragment.L);
      if (view instanceof ViewGroup)
        return (ViewGroup)view; 
    } 
    return null;
  }
  
  private void p() {
    this.b = false;
    this.J.clear();
    this.I.clear();
  }
  
  private void p1() {
    ArrayList<o> arrayList;
    androidx.activity.g g1;
    synchronized (this.a) {
      boolean bool1 = this.a.isEmpty();
      boolean bool = true;
      if (!bool1) {
        this.h.f(true);
        return;
      } 
      g1 = this.h;
      if (l0() <= 0 || !H0(this.t))
        bool = false; 
      g1.f(bool);
      return;
    } 
  }
  
  private Set<b0> r() {
    HashSet<b0> hashSet = new HashSet();
    Iterator<t> iterator = this.c.k().iterator();
    while (iterator.hasNext()) {
      ViewGroup viewGroup = (((t)iterator.next()).k()).U;
      if (viewGroup != null)
        hashSet.add(b0.o(viewGroup, x0())); 
    } 
    return hashSet;
  }
  
  private Set<b0> s(ArrayList<a> paramArrayList, int paramInt1, int paramInt2) {
    HashSet<b0> hashSet = new HashSet();
    while (paramInt1 < paramInt2) {
      Iterator<v.a> iterator = ((a)paramArrayList.get(paramInt1)).c.iterator();
      while (iterator.hasNext()) {
        Fragment fragment = ((v.a)iterator.next()).b;
        if (fragment != null) {
          ViewGroup viewGroup = fragment.U;
          if (viewGroup != null)
            hashSet.add(b0.n(viewGroup, this)); 
        } 
      } 
      paramInt1++;
    } 
    return hashSet;
  }
  
  private void u(Fragment paramFragment) {
    // Byte code:
    //   0: aload_1
    //   1: getfield V : Landroid/view/View;
    //   4: ifnull -> 199
    //   7: aload_0
    //   8: getfield r : Landroidx/fragment/app/j;
    //   11: invokevirtual j : ()Landroid/content/Context;
    //   14: aload_1
    //   15: aload_1
    //   16: getfield N : Z
    //   19: iconst_1
    //   20: ixor
    //   21: aload_1
    //   22: invokevirtual I : ()Z
    //   25: invokestatic c : (Landroid/content/Context;Landroidx/fragment/app/Fragment;ZZ)Landroidx/fragment/app/f$d;
    //   28: astore_3
    //   29: aload_3
    //   30: ifnull -> 135
    //   33: aload_3
    //   34: getfield b : Landroid/animation/Animator;
    //   37: astore #4
    //   39: aload #4
    //   41: ifnull -> 135
    //   44: aload #4
    //   46: aload_1
    //   47: getfield V : Landroid/view/View;
    //   50: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   53: aload_1
    //   54: getfield N : Z
    //   57: ifeq -> 117
    //   60: aload_1
    //   61: invokevirtual c0 : ()Z
    //   64: ifeq -> 75
    //   67: aload_1
    //   68: iconst_0
    //   69: invokevirtual B1 : (Z)V
    //   72: goto -> 125
    //   75: aload_1
    //   76: getfield U : Landroid/view/ViewGroup;
    //   79: astore #4
    //   81: aload_1
    //   82: getfield V : Landroid/view/View;
    //   85: astore #5
    //   87: aload #4
    //   89: aload #5
    //   91: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   94: aload_3
    //   95: getfield b : Landroid/animation/Animator;
    //   98: new androidx/fragment/app/m$h
    //   101: dup
    //   102: aload_0
    //   103: aload #4
    //   105: aload #5
    //   107: aload_1
    //   108: invokespecial <init> : (Landroidx/fragment/app/m;Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/Fragment;)V
    //   111: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   114: goto -> 125
    //   117: aload_1
    //   118: getfield V : Landroid/view/View;
    //   121: iconst_0
    //   122: invokevirtual setVisibility : (I)V
    //   125: aload_3
    //   126: getfield b : Landroid/animation/Animator;
    //   129: invokevirtual start : ()V
    //   132: goto -> 199
    //   135: aload_3
    //   136: ifnull -> 157
    //   139: aload_1
    //   140: getfield V : Landroid/view/View;
    //   143: aload_3
    //   144: getfield a : Landroid/view/animation/Animation;
    //   147: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   150: aload_3
    //   151: getfield a : Landroid/view/animation/Animation;
    //   154: invokevirtual start : ()V
    //   157: aload_1
    //   158: getfield N : Z
    //   161: ifeq -> 177
    //   164: aload_1
    //   165: invokevirtual c0 : ()Z
    //   168: ifne -> 177
    //   171: bipush #8
    //   173: istore_2
    //   174: goto -> 179
    //   177: iconst_0
    //   178: istore_2
    //   179: aload_1
    //   180: getfield V : Landroid/view/View;
    //   183: iload_2
    //   184: invokevirtual setVisibility : (I)V
    //   187: aload_1
    //   188: invokevirtual c0 : ()Z
    //   191: ifeq -> 199
    //   194: aload_1
    //   195: iconst_0
    //   196: invokevirtual B1 : (Z)V
    //   199: aload_0
    //   200: aload_1
    //   201: invokevirtual C0 : (Landroidx/fragment/app/Fragment;)V
    //   204: aload_1
    //   205: iconst_0
    //   206: putfield b0 : Z
    //   209: aload_1
    //   210: aload_1
    //   211: getfield N : Z
    //   214: invokevirtual B0 : (Z)V
    //   217: return
  }
  
  private void w(Fragment paramFragment) {
    paramFragment.a1();
    this.o.n(paramFragment, false);
    paramFragment.U = null;
    paramFragment.V = null;
    paramFragment.h0 = null;
    paramFragment.i0.n(null);
    paramFragment.C = false;
  }
  
  static Fragment y0(View paramView) {
    Object object = paramView.getTag(f0.b.a);
    return (object instanceof Fragment) ? (Fragment)object : null;
  }
  
  void A(Configuration paramConfiguration) {
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.U0(paramConfiguration); 
    } 
  }
  
  void A0() {
    a0(true);
    if (this.h.c()) {
      V0();
      return;
    } 
    this.g.c();
  }
  
  boolean B(MenuItem paramMenuItem) {
    if (this.q < 1)
      return false; 
    for (Fragment fragment : this.c.n()) {
      if (fragment != null && fragment.V0(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  void B0(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.N) {
      paramFragment.N = true;
      paramFragment.b0 = true ^ paramFragment.b0;
      l1(paramFragment);
    } 
  }
  
  void C() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    S(1);
  }
  
  void C0(Fragment paramFragment) {
    if (paramFragment.z && F0(paramFragment))
      this.D = true; 
  }
  
  boolean D(Menu paramMenu, MenuInflater paramMenuInflater) {
    int i1 = this.q;
    int n = 0;
    if (i1 < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    Iterator<Fragment> iterator = this.c.n().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment != null && G0(fragment) && fragment.X0(paramMenu, paramMenuInflater)) {
        ArrayList<Fragment> arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        arrayList1.add(fragment);
        bool = true;
        arrayList = arrayList1;
      } 
    } 
    if (this.e != null)
      while (n < this.e.size()) {
        Fragment fragment = this.e.get(n);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.x0(); 
        n++;
      }  
    this.e = arrayList;
    return bool;
  }
  
  public boolean D0() {
    return this.G;
  }
  
  void E() {
    this.G = true;
    a0(true);
    X();
    S(-1);
    this.r = null;
    this.s = null;
    this.t = null;
    if (this.g != null) {
      this.h.d();
      this.g = null;
    } 
    androidx.activity.result.c<Intent> c1 = this.z;
    if (c1 != null) {
      c1.c();
      this.A.c();
      this.B.c();
    } 
  }
  
  void F() {
    S(1);
  }
  
  void G() {
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.d1(); 
    } 
  }
  
  boolean G0(Fragment paramFragment) {
    return (paramFragment == null) ? true : paramFragment.e0();
  }
  
  void H(boolean paramBoolean) {
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.e1(paramBoolean); 
    } 
  }
  
  boolean H0(Fragment paramFragment) {
    if (paramFragment == null)
      return true; 
    m m1 = paramFragment.G;
    return (paramFragment.equals(m1.w0()) && H0(m1.t));
  }
  
  void I(Fragment paramFragment) {
    Iterator<q> iterator = this.p.iterator();
    while (iterator.hasNext())
      ((q)iterator.next()).b(this, paramFragment); 
  }
  
  boolean I0(int paramInt) {
    return (this.q >= paramInt);
  }
  
  boolean J(MenuItem paramMenuItem) {
    if (this.q < 1)
      return false; 
    for (Fragment fragment : this.c.n()) {
      if (fragment != null && fragment.f1(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public boolean J0() {
    return (this.E || this.F);
  }
  
  void K(Menu paramMenu) {
    if (this.q < 1)
      return; 
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.g1(paramMenu); 
    } 
  }
  
  void K0(Fragment paramFragment, @SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    m m1;
    if (this.z != null) {
      m1 = new m(paramFragment.t, paramInt);
      this.C.addLast(m1);
      if (paramIntent != null && paramBundle != null)
        paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle); 
      this.z.a(paramIntent);
      return;
    } 
    this.r.p((Fragment)m1, paramIntent, paramInt, paramBundle);
  }
  
  void M() {
    S(5);
  }
  
  void M0(Fragment paramFragment) {
    if (!this.c.c(paramFragment.t)) {
      if (E0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring moving ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(" to state ");
        stringBuilder.append(this.q);
        stringBuilder.append("since it is not added to ");
        stringBuilder.append(this);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    O0(paramFragment);
    View view = paramFragment.V;
    if (view != null && paramFragment.a0 && paramFragment.U != null) {
      float f = paramFragment.c0;
      if (f > 0.0F)
        view.setAlpha(f); 
      paramFragment.c0 = 0.0F;
      paramFragment.a0 = false;
      f.d d = f.c(this.r.j(), paramFragment, true, paramFragment.I());
      if (d != null) {
        Animation animation = d.a;
        if (animation != null) {
          paramFragment.V.startAnimation(animation);
        } else {
          d.b.setTarget(paramFragment.V);
          d.b.start();
        } 
      } 
    } 
    if (paramFragment.b0)
      u(paramFragment); 
  }
  
  void N(boolean paramBoolean) {
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.i1(paramBoolean); 
    } 
  }
  
  void N0(int paramInt, boolean paramBoolean) {
    if (this.r != null || paramInt == -1) {
      if (!paramBoolean && paramInt == this.q)
        return; 
      this.q = paramInt;
      if (P) {
        this.c.r();
      } else {
        null = this.c.n().iterator();
        while (null.hasNext())
          M0(null.next()); 
        for (t t : this.c.k()) {
          Fragment fragment = t.k();
          if (!fragment.a0)
            M0(fragment); 
          if (fragment.A && !fragment.d0()) {
            paramInt = 1;
          } else {
            paramInt = 0;
          } 
          if (paramInt != 0)
            this.c.q(t); 
        } 
      } 
      n1();
      if (this.D) {
        j<?> j1 = this.r;
        if (j1 != null && this.q == 7) {
          j1.q();
          this.D = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  boolean O(Menu paramMenu) {
    int n = this.q;
    boolean bool = false;
    if (n < 1)
      return false; 
    for (Fragment fragment : this.c.n()) {
      if (fragment != null && G0(fragment) && fragment.j1(paramMenu))
        bool = true; 
    } 
    return bool;
  }
  
  void O0(Fragment paramFragment) {
    P0(paramFragment, this.q);
  }
  
  void P() {
    p1();
    L(this.u);
  }
  
  void P0(Fragment paramFragment, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroidx/fragment/app/u;
    //   4: aload_1
    //   5: getfield t : Ljava/lang/String;
    //   8: invokevirtual m : (Ljava/lang/String;)Landroidx/fragment/app/t;
    //   11: astore #7
    //   13: iconst_1
    //   14: istore #4
    //   16: aload #7
    //   18: astore #6
    //   20: aload #7
    //   22: ifnonnull -> 49
    //   25: new androidx/fragment/app/t
    //   28: dup
    //   29: aload_0
    //   30: getfield o : Landroidx/fragment/app/l;
    //   33: aload_0
    //   34: getfield c : Landroidx/fragment/app/u;
    //   37: aload_1
    //   38: invokespecial <init> : (Landroidx/fragment/app/l;Landroidx/fragment/app/u;Landroidx/fragment/app/Fragment;)V
    //   41: astore #6
    //   43: aload #6
    //   45: iconst_1
    //   46: invokevirtual t : (I)V
    //   49: iload_2
    //   50: istore_3
    //   51: aload_1
    //   52: getfield B : Z
    //   55: ifeq -> 83
    //   58: iload_2
    //   59: istore_3
    //   60: aload_1
    //   61: getfield C : Z
    //   64: ifeq -> 83
    //   67: iload_2
    //   68: istore_3
    //   69: aload_1
    //   70: getfield o : I
    //   73: iconst_2
    //   74: if_icmpne -> 83
    //   77: iload_2
    //   78: iconst_2
    //   79: invokestatic max : (II)I
    //   82: istore_3
    //   83: iload_3
    //   84: aload #6
    //   86: invokevirtual d : ()I
    //   89: invokestatic min : (II)I
    //   92: istore_2
    //   93: aload_1
    //   94: getfield o : I
    //   97: istore #5
    //   99: iload #5
    //   101: iload_2
    //   102: if_icmpgt -> 243
    //   105: iload #5
    //   107: iload_2
    //   108: if_icmpge -> 128
    //   111: aload_0
    //   112: getfield m : Ljava/util/Map;
    //   115: invokeinterface isEmpty : ()Z
    //   120: ifne -> 128
    //   123: aload_0
    //   124: aload_1
    //   125: invokespecial m : (Landroidx/fragment/app/Fragment;)V
    //   128: aload_1
    //   129: getfield o : I
    //   132: istore_3
    //   133: iload_3
    //   134: iconst_m1
    //   135: if_icmpeq -> 167
    //   138: iload_3
    //   139: ifeq -> 177
    //   142: iload_3
    //   143: iconst_1
    //   144: if_icmpeq -> 186
    //   147: iload_3
    //   148: iconst_2
    //   149: if_icmpeq -> 206
    //   152: iload_3
    //   153: iconst_4
    //   154: if_icmpeq -> 216
    //   157: iload_3
    //   158: iconst_5
    //   159: if_icmpeq -> 226
    //   162: iload_2
    //   163: istore_3
    //   164: goto -> 694
    //   167: iload_2
    //   168: iconst_m1
    //   169: if_icmple -> 177
    //   172: aload #6
    //   174: invokevirtual c : ()V
    //   177: iload_2
    //   178: ifle -> 186
    //   181: aload #6
    //   183: invokevirtual e : ()V
    //   186: iload_2
    //   187: iconst_m1
    //   188: if_icmple -> 196
    //   191: aload #6
    //   193: invokevirtual j : ()V
    //   196: iload_2
    //   197: iconst_1
    //   198: if_icmple -> 206
    //   201: aload #6
    //   203: invokevirtual f : ()V
    //   206: iload_2
    //   207: iconst_2
    //   208: if_icmple -> 216
    //   211: aload #6
    //   213: invokevirtual a : ()V
    //   216: iload_2
    //   217: iconst_4
    //   218: if_icmple -> 226
    //   221: aload #6
    //   223: invokevirtual u : ()V
    //   226: iload_2
    //   227: istore_3
    //   228: iload_2
    //   229: iconst_5
    //   230: if_icmple -> 694
    //   233: aload #6
    //   235: invokevirtual p : ()V
    //   238: iload_2
    //   239: istore_3
    //   240: goto -> 694
    //   243: iload_2
    //   244: istore_3
    //   245: iload #5
    //   247: iload_2
    //   248: if_icmple -> 694
    //   251: iload #5
    //   253: ifeq -> 683
    //   256: iload #5
    //   258: iconst_1
    //   259: if_icmpeq -> 654
    //   262: iload #5
    //   264: iconst_2
    //   265: if_icmpeq -> 391
    //   268: iload #5
    //   270: iconst_4
    //   271: if_icmpeq -> 313
    //   274: iload #5
    //   276: iconst_5
    //   277: if_icmpeq -> 303
    //   280: iload #5
    //   282: bipush #7
    //   284: if_icmpeq -> 292
    //   287: iload_2
    //   288: istore_3
    //   289: goto -> 694
    //   292: iload_2
    //   293: bipush #7
    //   295: if_icmpge -> 303
    //   298: aload #6
    //   300: invokevirtual n : ()V
    //   303: iload_2
    //   304: iconst_5
    //   305: if_icmpge -> 313
    //   308: aload #6
    //   310: invokevirtual v : ()V
    //   313: iload_2
    //   314: iconst_4
    //   315: if_icmpge -> 391
    //   318: iconst_3
    //   319: invokestatic E0 : (I)Z
    //   322: ifeq -> 361
    //   325: new java/lang/StringBuilder
    //   328: dup
    //   329: invokespecial <init> : ()V
    //   332: astore #7
    //   334: aload #7
    //   336: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   339: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   342: pop
    //   343: aload #7
    //   345: aload_1
    //   346: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   349: pop
    //   350: ldc 'FragmentManager'
    //   352: aload #7
    //   354: invokevirtual toString : ()Ljava/lang/String;
    //   357: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   360: pop
    //   361: aload_1
    //   362: getfield V : Landroid/view/View;
    //   365: ifnull -> 391
    //   368: aload_0
    //   369: getfield r : Landroidx/fragment/app/j;
    //   372: aload_1
    //   373: invokevirtual o : (Landroidx/fragment/app/Fragment;)Z
    //   376: ifeq -> 391
    //   379: aload_1
    //   380: getfield q : Landroid/util/SparseArray;
    //   383: ifnonnull -> 391
    //   386: aload #6
    //   388: invokevirtual s : ()V
    //   391: iload_2
    //   392: iconst_2
    //   393: if_icmpge -> 654
    //   396: aconst_null
    //   397: astore #8
    //   399: aload_1
    //   400: getfield V : Landroid/view/View;
    //   403: astore #7
    //   405: aload #7
    //   407: ifnull -> 636
    //   410: aload_1
    //   411: getfield U : Landroid/view/ViewGroup;
    //   414: astore #9
    //   416: aload #9
    //   418: ifnull -> 636
    //   421: aload #9
    //   423: aload #7
    //   425: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   428: aload_1
    //   429: getfield V : Landroid/view/View;
    //   432: invokevirtual clearAnimation : ()V
    //   435: aload_1
    //   436: invokevirtual h0 : ()Z
    //   439: ifne -> 636
    //   442: aload #8
    //   444: astore #7
    //   446: aload_0
    //   447: getfield q : I
    //   450: iconst_m1
    //   451: if_icmple -> 510
    //   454: aload #8
    //   456: astore #7
    //   458: aload_0
    //   459: getfield G : Z
    //   462: ifne -> 510
    //   465: aload #8
    //   467: astore #7
    //   469: aload_1
    //   470: getfield V : Landroid/view/View;
    //   473: invokevirtual getVisibility : ()I
    //   476: ifne -> 510
    //   479: aload #8
    //   481: astore #7
    //   483: aload_1
    //   484: getfield c0 : F
    //   487: fconst_0
    //   488: fcmpl
    //   489: iflt -> 510
    //   492: aload_0
    //   493: getfield r : Landroidx/fragment/app/j;
    //   496: invokevirtual j : ()Landroid/content/Context;
    //   499: aload_1
    //   500: iconst_0
    //   501: aload_1
    //   502: invokevirtual I : ()Z
    //   505: invokestatic c : (Landroid/content/Context;Landroidx/fragment/app/Fragment;ZZ)Landroidx/fragment/app/f$d;
    //   508: astore #7
    //   510: aload_1
    //   511: fconst_0
    //   512: putfield c0 : F
    //   515: aload_1
    //   516: getfield U : Landroid/view/ViewGroup;
    //   519: astore #8
    //   521: aload_1
    //   522: getfield V : Landroid/view/View;
    //   525: astore #9
    //   527: aload #7
    //   529: ifnull -> 542
    //   532: aload_1
    //   533: aload #7
    //   535: aload_0
    //   536: getfield n : Landroidx/fragment/app/w$g;
    //   539: invokestatic a : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/f$d;Landroidx/fragment/app/w$g;)V
    //   542: aload #8
    //   544: aload #9
    //   546: invokevirtual removeView : (Landroid/view/View;)V
    //   549: iconst_2
    //   550: invokestatic E0 : (I)Z
    //   553: ifeq -> 626
    //   556: new java/lang/StringBuilder
    //   559: dup
    //   560: invokespecial <init> : ()V
    //   563: astore #7
    //   565: aload #7
    //   567: ldc_w 'Removing view '
    //   570: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   573: pop
    //   574: aload #7
    //   576: aload #9
    //   578: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   581: pop
    //   582: aload #7
    //   584: ldc_w ' for fragment '
    //   587: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   590: pop
    //   591: aload #7
    //   593: aload_1
    //   594: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   597: pop
    //   598: aload #7
    //   600: ldc_w ' from container '
    //   603: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   606: pop
    //   607: aload #7
    //   609: aload #8
    //   611: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   614: pop
    //   615: ldc 'FragmentManager'
    //   617: aload #7
    //   619: invokevirtual toString : ()Ljava/lang/String;
    //   622: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   625: pop
    //   626: aload #8
    //   628: aload_1
    //   629: getfield U : Landroid/view/ViewGroup;
    //   632: if_acmpeq -> 636
    //   635: return
    //   636: aload_0
    //   637: getfield m : Ljava/util/Map;
    //   640: aload_1
    //   641: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   646: ifnonnull -> 654
    //   649: aload #6
    //   651: invokevirtual h : ()V
    //   654: iload_2
    //   655: iconst_1
    //   656: if_icmpge -> 683
    //   659: aload_0
    //   660: getfield m : Ljava/util/Map;
    //   663: aload_1
    //   664: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   669: ifnull -> 678
    //   672: iload #4
    //   674: istore_2
    //   675: goto -> 683
    //   678: aload #6
    //   680: invokevirtual g : ()V
    //   683: iload_2
    //   684: ifge -> 692
    //   687: aload #6
    //   689: invokevirtual i : ()V
    //   692: iload_2
    //   693: istore_3
    //   694: aload_1
    //   695: getfield o : I
    //   698: iload_3
    //   699: if_icmpeq -> 785
    //   702: iconst_3
    //   703: invokestatic E0 : (I)Z
    //   706: ifeq -> 780
    //   709: new java/lang/StringBuilder
    //   712: dup
    //   713: invokespecial <init> : ()V
    //   716: astore #6
    //   718: aload #6
    //   720: ldc_w 'moveToState: Fragment state for '
    //   723: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   726: pop
    //   727: aload #6
    //   729: aload_1
    //   730: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   733: pop
    //   734: aload #6
    //   736: ldc_w ' not updated inline; expected state '
    //   739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   742: pop
    //   743: aload #6
    //   745: iload_3
    //   746: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   749: pop
    //   750: aload #6
    //   752: ldc_w ' found '
    //   755: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   758: pop
    //   759: aload #6
    //   761: aload_1
    //   762: getfield o : I
    //   765: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   768: pop
    //   769: ldc 'FragmentManager'
    //   771: aload #6
    //   773: invokevirtual toString : ()Ljava/lang/String;
    //   776: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   779: pop
    //   780: aload_1
    //   781: iload_3
    //   782: putfield o : I
    //   785: return
  }
  
  void Q() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    S(7);
  }
  
  void Q0() {
    if (this.r == null)
      return; 
    this.E = false;
    this.F = false;
    this.M.n(false);
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.k0(); 
    } 
  }
  
  void R() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    S(5);
  }
  
  void R0(FragmentContainerView paramFragmentContainerView) {
    for (t t : this.c.k()) {
      Fragment fragment = t.k();
      if (fragment.L == paramFragmentContainerView.getId()) {
        View view = fragment.V;
        if (view != null && view.getParent() == null) {
          fragment.U = (ViewGroup)paramFragmentContainerView;
          t.b();
        } 
      } 
    } 
  }
  
  void S0(t paramt) {
    Fragment fragment = paramt.k();
    if (fragment.W) {
      if (this.b) {
        this.H = true;
        return;
      } 
      fragment.W = false;
      if (P) {
        paramt.m();
        return;
      } 
      O0(fragment);
    } 
  }
  
  void T() {
    this.F = true;
    this.M.n(true);
    S(4);
  }
  
  public void T0() {
    Y(new p(this, null, -1, 0), false);
  }
  
  void U() {
    S(2);
  }
  
  public void U0(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      Y(new p(this, null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean V0() {
    return W0(null, -1, 0);
  }
  
  public void W(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("    ");
    String str = stringBuilder2.toString();
    this.c.e(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    ArrayList<Fragment> arrayList1 = this.e;
    byte b = 0;
    if (arrayList1 != null) {
      int n = arrayList1.size();
      if (n > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Fragments Created Menus:");
        int i1;
        for (i1 = 0; i1 < n; i1++) {
          Fragment fragment = this.e.get(i1);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i1);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(fragment.toString());
        } 
      } 
    } 
    ArrayList<a> arrayList = this.d;
    if (arrayList != null) {
      int n = arrayList.size();
      if (n > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Back Stack:");
        int i1;
        for (i1 = 0; i1 < n; i1++) {
          a a = this.d.get(i1);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i1);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(a.toString());
          a.u(str, paramPrintWriter);
        } 
      } 
    } 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Back Stack Index: ");
    stringBuilder1.append(this.i.get());
    paramPrintWriter.println(stringBuilder1.toString());
    synchronized (this.a) {
      int n = this.a.size();
      if (n > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Pending Actions:");
        int i1;
        for (i1 = b; i1 < n; i1++) {
          o o = this.a.get(i1);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i1);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(o);
        } 
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("FragmentManager misc state:");
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mHost=");
      paramPrintWriter.println(this.r);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mContainer=");
      paramPrintWriter.println(this.s);
      if (this.t != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mParent=");
        paramPrintWriter.println(this.t);
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mCurState=");
      paramPrintWriter.print(this.q);
      paramPrintWriter.print(" mStateSaved=");
      paramPrintWriter.print(this.E);
      paramPrintWriter.print(" mStopped=");
      paramPrintWriter.print(this.F);
      paramPrintWriter.print(" mDestroyed=");
      paramPrintWriter.println(this.G);
      if (this.D) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mNeedMenuInvalidate=");
        paramPrintWriter.println(this.D);
      } 
      return;
    } 
  }
  
  boolean X0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 69
    //   17: iload #4
    //   19: ifge -> 69
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 69
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield d : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   63: invokevirtual add : (Ljava/lang/Object;)Z
    //   66: pop
    //   67: iconst_1
    //   68: ireturn
    //   69: aload_3
    //   70: ifnonnull -> 87
    //   73: iload #4
    //   75: iflt -> 81
    //   78: goto -> 87
    //   81: iconst_m1
    //   82: istore #4
    //   84: goto -> 262
    //   87: aload #8
    //   89: invokevirtual size : ()I
    //   92: iconst_1
    //   93: isub
    //   94: istore #6
    //   96: iload #6
    //   98: iflt -> 161
    //   101: aload_0
    //   102: getfield d : Ljava/util/ArrayList;
    //   105: iload #6
    //   107: invokevirtual get : (I)Ljava/lang/Object;
    //   110: checkcast androidx/fragment/app/a
    //   113: astore #8
    //   115: aload_3
    //   116: ifnull -> 134
    //   119: aload_3
    //   120: aload #8
    //   122: invokevirtual z : ()Ljava/lang/String;
    //   125: invokevirtual equals : (Ljava/lang/Object;)Z
    //   128: ifeq -> 134
    //   131: goto -> 161
    //   134: iload #4
    //   136: iflt -> 152
    //   139: iload #4
    //   141: aload #8
    //   143: getfield v : I
    //   146: if_icmpne -> 152
    //   149: goto -> 161
    //   152: iload #6
    //   154: iconst_1
    //   155: isub
    //   156: istore #6
    //   158: goto -> 96
    //   161: iload #6
    //   163: ifge -> 168
    //   166: iconst_0
    //   167: ireturn
    //   168: iload #6
    //   170: istore #7
    //   172: iload #5
    //   174: iconst_1
    //   175: iand
    //   176: ifeq -> 258
    //   179: iload #6
    //   181: iconst_1
    //   182: isub
    //   183: istore #5
    //   185: iload #5
    //   187: istore #7
    //   189: iload #5
    //   191: iflt -> 258
    //   194: aload_0
    //   195: getfield d : Ljava/util/ArrayList;
    //   198: iload #5
    //   200: invokevirtual get : (I)Ljava/lang/Object;
    //   203: checkcast androidx/fragment/app/a
    //   206: astore #8
    //   208: aload_3
    //   209: ifnull -> 228
    //   212: iload #5
    //   214: istore #6
    //   216: aload_3
    //   217: aload #8
    //   219: invokevirtual z : ()Ljava/lang/String;
    //   222: invokevirtual equals : (Ljava/lang/Object;)Z
    //   225: ifne -> 179
    //   228: iload #5
    //   230: istore #7
    //   232: iload #4
    //   234: iflt -> 258
    //   237: iload #5
    //   239: istore #7
    //   241: iload #4
    //   243: aload #8
    //   245: getfield v : I
    //   248: if_icmpne -> 258
    //   251: iload #5
    //   253: istore #6
    //   255: goto -> 179
    //   258: iload #7
    //   260: istore #4
    //   262: iload #4
    //   264: aload_0
    //   265: getfield d : Ljava/util/ArrayList;
    //   268: invokevirtual size : ()I
    //   271: iconst_1
    //   272: isub
    //   273: if_icmpne -> 278
    //   276: iconst_0
    //   277: ireturn
    //   278: aload_0
    //   279: getfield d : Ljava/util/ArrayList;
    //   282: invokevirtual size : ()I
    //   285: iconst_1
    //   286: isub
    //   287: istore #5
    //   289: iload #5
    //   291: iload #4
    //   293: if_icmple -> 327
    //   296: aload_1
    //   297: aload_0
    //   298: getfield d : Ljava/util/ArrayList;
    //   301: iload #5
    //   303: invokevirtual remove : (I)Ljava/lang/Object;
    //   306: invokevirtual add : (Ljava/lang/Object;)Z
    //   309: pop
    //   310: aload_2
    //   311: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   314: invokevirtual add : (Ljava/lang/Object;)Z
    //   317: pop
    //   318: iload #5
    //   320: iconst_1
    //   321: isub
    //   322: istore #5
    //   324: goto -> 289
    //   327: iconst_1
    //   328: ireturn
  }
  
  void Y(o paramo, boolean paramBoolean) {
    if (!paramBoolean) {
      if (this.r == null) {
        if (this.G)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      o();
    } 
    synchronized (this.a) {
      if (this.r == null) {
        if (paramBoolean)
          return; 
        throw new IllegalStateException("Activity has been destroyed");
      } 
      this.a.add(paramo);
      h1();
      return;
    } 
  }
  
  public void Z0(l paraml, boolean paramBoolean) {
    this.o.o(paraml, paramBoolean);
  }
  
  boolean a0(boolean paramBoolean) {
    Z(paramBoolean);
    paramBoolean = false;
    while (k0(this.I, this.J)) {
      this.b = true;
      try {
        c1(this.I, this.J);
        p();
      } finally {
        p();
      } 
    } 
    p1();
    V();
    this.c.b();
    return paramBoolean;
  }
  
  void a1(Fragment paramFragment, androidx.core.os.e parame) {
    HashSet hashSet = this.m.get(paramFragment);
    if (hashSet != null && hashSet.remove(parame) && hashSet.isEmpty()) {
      this.m.remove(paramFragment);
      if (paramFragment.o < 5) {
        w(paramFragment);
        O0(paramFragment);
      } 
    } 
  }
  
  void b0(o paramo, boolean paramBoolean) {
    if (paramBoolean && (this.r == null || this.G))
      return; 
    Z(paramBoolean);
    if (paramo.a(this.I, this.J)) {
      this.b = true;
      try {
        c1(this.I, this.J);
      } finally {
        p();
      } 
    } 
    p1();
    V();
    this.c.b();
  }
  
  void b1(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.F);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.d0();
    if (!paramFragment.O || (bool ^ true) != 0) {
      this.c.s(paramFragment);
      if (F0(paramFragment))
        this.D = true; 
      paramFragment.A = true;
      l1(paramFragment);
    } 
  }
  
  void e(a parama) {
    if (this.d == null)
      this.d = new ArrayList<a>(); 
    this.d.add(parama);
  }
  
  void e1(Parcelable paramParcelable) {
    if (paramParcelable == null)
      return; 
    o o = (o)paramParcelable;
    if (o.o == null)
      return; 
    this.c.t();
    for (Parcelable paramParcelable : o.o) {
      if (paramParcelable != null) {
        t t;
        Fragment fragment = this.M.g(((s)paramParcelable).p);
        if (fragment != null) {
          if (E0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreSaveState: re-attaching retained ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          t = new t(this.o, this.c, fragment, (s)paramParcelable);
        } else {
          t = new t(this.o, this.c, this.r.j().getClassLoader(), p0(), (s)t);
        } 
        fragment = t.k();
        fragment.G = this;
        if (E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreSaveState: active (");
          stringBuilder.append(fragment.t);
          stringBuilder.append("): ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        t.o(this.r.j().getClassLoader());
        this.c.p(t);
        t.t(this.q);
      } 
    } 
    for (Fragment fragment : this.M.j()) {
      if (!this.c.c(fragment.t)) {
        if (E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Discarding retained Fragment ");
          stringBuilder.append(fragment);
          stringBuilder.append(" that was not found in the set of active Fragments ");
          stringBuilder.append(o.o);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.M.m(fragment);
        fragment.G = this;
        t t = new t(this.o, this.c, fragment);
        t.t(1);
        t.m();
        fragment.A = true;
        t.m();
      } 
    } 
    this.c.u(o.p);
    b[] arrayOfB = o.q;
    byte b = 0;
    if (arrayOfB != null) {
      this.d = new ArrayList<a>(o.q.length);
      int n = 0;
      while (true) {
        arrayOfB = o.q;
        if (n < arrayOfB.length) {
          a a = arrayOfB[n].i(this);
          if (E0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreAllState: back stack #");
            stringBuilder.append(n);
            stringBuilder.append(" (index ");
            stringBuilder.append(a.v);
            stringBuilder.append("): ");
            stringBuilder.append(a);
            Log.v("FragmentManager", stringBuilder.toString());
            PrintWriter printWriter = new PrintWriter(new a0("FragmentManager"));
            a.v("  ", printWriter, false);
            printWriter.close();
          } 
          this.d.add(a);
          n++;
          continue;
        } 
        break;
      } 
    } else {
      this.d = null;
    } 
    this.i.set(o.r);
    String str = o.s;
    if (str != null) {
      Fragment fragment = f0(str);
      this.u = fragment;
      L(fragment);
    } 
    ArrayList<String> arrayList = o.t;
    if (arrayList != null)
      for (int n = b; n < arrayList.size(); n++) {
        Bundle bundle = o.u.get(n);
        bundle.setClassLoader(this.r.j().getClassLoader());
        this.j.put(arrayList.get(n), bundle);
      }  
    this.C = new ArrayDeque<m>(o.v);
  }
  
  void f(Fragment paramFragment, androidx.core.os.e parame) {
    if (this.m.get(paramFragment) == null)
      this.m.put(paramFragment, new HashSet<androidx.core.os.e>()); 
    ((HashSet<androidx.core.os.e>)this.m.get(paramFragment)).add(parame);
  }
  
  Fragment f0(String paramString) {
    return this.c.f(paramString);
  }
  
  t g(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    t t = v(paramFragment);
    paramFragment.G = this;
    this.c.p(t);
    if (!paramFragment.O) {
      this.c.a(paramFragment);
      paramFragment.A = false;
      if (paramFragment.V == null)
        paramFragment.b0 = false; 
      if (F0(paramFragment))
        this.D = true; 
    } 
    return t;
  }
  
  public Fragment g0(int paramInt) {
    return this.c.g(paramInt);
  }
  
  Parcelable g1() {
    StringBuilder stringBuilder;
    j0();
    X();
    a0(true);
    this.E = true;
    this.M.n(true);
    ArrayList<s> arrayList = this.c.v();
    boolean bool = arrayList.isEmpty();
    b[] arrayOfB2 = null;
    if (bool) {
      if (E0(2))
        Log.v("FragmentManager", "saveAllState: no fragments!"); 
      return null;
    } 
    ArrayList<String> arrayList1 = this.c.w();
    ArrayList<a> arrayList2 = this.d;
    b[] arrayOfB1 = arrayOfB2;
    if (arrayList2 != null) {
      int n = arrayList2.size();
      arrayOfB1 = arrayOfB2;
      if (n > 0) {
        arrayOfB2 = new b[n];
        int i1 = 0;
        while (true) {
          arrayOfB1 = arrayOfB2;
          if (i1 < n) {
            arrayOfB2[i1] = new b(this.d.get(i1));
            if (E0(2)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("saveAllState: adding back stack #");
              stringBuilder.append(i1);
              stringBuilder.append(": ");
              stringBuilder.append(this.d.get(i1));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            i1++;
            continue;
          } 
          break;
        } 
      } 
    } 
    o o = new o();
    o.o = arrayList;
    o.p = arrayList1;
    o.q = (b[])stringBuilder;
    o.r = this.i.get();
    Fragment fragment = this.u;
    if (fragment != null)
      o.s = fragment.t; 
    o.t.addAll(this.j.keySet());
    o.u.addAll(this.j.values());
    o.v = new ArrayList<m>(this.C);
    return o;
  }
  
  public void h(q paramq) {
    this.p.add(paramq);
  }
  
  public Fragment h0(String paramString) {
    return this.c.h(paramString);
  }
  
  void h1() {
    boolean bool1;
    boolean bool2;
    synchronized (this.a) {
      ArrayList<q> arrayList = this.L;
      bool2 = false;
      if (arrayList != null && !arrayList.isEmpty()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (this.a.size() == 1)
        bool2 = true; 
    } 
    if (bool1 || bool2) {
      this.r.l().removeCallbacks(this.N);
      this.r.l().post(this.N);
      p1();
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
  }
  
  int i() {
    return this.i.getAndIncrement();
  }
  
  Fragment i0(String paramString) {
    return this.c.i(paramString);
  }
  
  void i1(Fragment paramFragment, boolean paramBoolean) {
    ViewGroup viewGroup = o0(paramFragment);
    if (viewGroup != null && viewGroup instanceof FragmentContainerView)
      ((FragmentContainerView)viewGroup).setDrawDisappearingViewsLast(paramBoolean ^ true); 
  }
  
  @SuppressLint({"SyntheticAccessor"})
  void j(j<?> paramj, g paramg, Fragment paramFragment) {
    if (this.r == null) {
      this.r = paramj;
      this.s = paramg;
      this.t = paramFragment;
      if (paramFragment != null) {
        h(new i(this, paramFragment));
      } else if (paramj instanceof q) {
        h((q)paramj);
      } 
      if (this.t != null)
        p1(); 
      if (paramj instanceof androidx.activity.h) {
        Fragment fragment;
        androidx.activity.h h = (androidx.activity.h)paramj;
        OnBackPressedDispatcher onBackPressedDispatcher = h.c();
        this.g = onBackPressedDispatcher;
        if (paramFragment != null)
          fragment = paramFragment; 
        onBackPressedDispatcher.a(fragment, this.h);
      } 
      if (paramFragment != null) {
        this.M = paramFragment.G.m0(paramFragment);
      } else if (paramj instanceof i0) {
        this.M = p.i(((i0)paramj).k());
      } else {
        this.M = new p(false);
      } 
      this.M.n(J0());
      this.c.x(this.M);
      paramj = this.r;
      if (paramj instanceof androidx.activity.result.d) {
        ActivityResultRegistry activityResultRegistry = ((androidx.activity.result.d)paramj).i();
        if (paramFragment != null) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramFragment.t);
          stringBuilder1.append(":");
          str = stringBuilder1.toString();
        } else {
          str = "";
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentManager:");
        stringBuilder.append(str);
        String str = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartActivityForResult");
        this.z = activityResultRegistry.j(stringBuilder.toString(), (d.a)new d.c(), new j(this));
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartIntentSenderForResult");
        this.A = activityResultRegistry.j(stringBuilder.toString(), new k(), new a(this));
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("RequestPermissions");
        this.B = activityResultRegistry.j(stringBuilder.toString(), (d.a)new d.b(), new b(this));
      } 
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  void j1(Fragment paramFragment, androidx.lifecycle.i.c paramc) {
    if (paramFragment.equals(f0(paramFragment.t)) && (paramFragment.H == null || paramFragment.G == this)) {
      paramFragment.f0 = paramc;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void k(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.O) {
      paramFragment.O = false;
      if (!paramFragment.z) {
        this.c.a(paramFragment);
        if (E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("add from attach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (F0(paramFragment))
          this.D = true; 
      } 
    } 
  }
  
  void k1(Fragment paramFragment) {
    if (paramFragment == null || (paramFragment.equals(f0(paramFragment.t)) && (paramFragment.H == null || paramFragment.G == this))) {
      Fragment fragment = this.u;
      this.u = paramFragment;
      L(fragment);
      L(this.u);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public v l() {
    return new a(this);
  }
  
  public int l0() {
    ArrayList<a> arrayList = this.d;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  void m1(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.N) {
      paramFragment.N = false;
      paramFragment.b0 ^= 0x1;
    } 
  }
  
  boolean n() {
    Iterator<Fragment> iterator = this.c.l().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      boolean bool1 = bool;
      if (fragment != null)
        bool1 = F0(fragment); 
      bool = bool1;
      if (bool1)
        return true; 
    } 
    return false;
  }
  
  g n0() {
    return this.s;
  }
  
  public void o1(l paraml) {
    this.o.p(paraml);
  }
  
  public i p0() {
    i i1 = this.v;
    if (i1 != null)
      return i1; 
    Fragment fragment = this.t;
    return (fragment != null) ? fragment.G.p0() : this.w;
  }
  
  public final void q(String paramString) {
    this.j.remove(paramString);
  }
  
  u q0() {
    return this.c;
  }
  
  public List<Fragment> r0() {
    return this.c.n();
  }
  
  j<?> s0() {
    return this.r;
  }
  
  void t(a parama, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      parama.x(paramBoolean3);
    } else {
      parama.w();
    } 
    ArrayList<a> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(parama);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2 && this.q >= 1)
      w.B(this.r.j(), this.s, arrayList, arrayList1, 0, 1, true, this.n); 
    if (paramBoolean3)
      N0(this.q, true); 
    for (Fragment fragment : this.c.l()) {
      if (fragment != null && fragment.V != null && fragment.a0 && parama.A(fragment.L)) {
        float f = fragment.c0;
        if (f > 0.0F)
          fragment.V.setAlpha(f); 
        if (paramBoolean3) {
          fragment.c0 = 0.0F;
          continue;
        } 
        fragment.c0 = -1.0F;
        fragment.a0 = false;
      } 
    } 
  }
  
  LayoutInflater.Factory2 t0() {
    return this.f;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.t;
    if (fragment != null) {
      stringBuilder.append(fragment.getClass().getSimpleName());
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this.t)));
      stringBuilder.append("}");
    } else {
      j<?> j1 = this.r;
      if (j1 != null) {
        stringBuilder.append(j1.getClass().getSimpleName());
        stringBuilder.append("{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this.r)));
        stringBuilder.append("}");
      } else {
        stringBuilder.append("null");
      } 
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  l u0() {
    return this.o;
  }
  
  t v(Fragment paramFragment) {
    t t2 = this.c.m(paramFragment.t);
    if (t2 != null)
      return t2; 
    t t1 = new t(this.o, this.c, paramFragment);
    t1.o(this.r.j().getClassLoader());
    t1.t(this.q);
    return t1;
  }
  
  Fragment v0() {
    return this.t;
  }
  
  public Fragment w0() {
    return this.u;
  }
  
  void x(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.O) {
      paramFragment.O = true;
      if (paramFragment.z) {
        if (E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.c.s(paramFragment);
        if (F0(paramFragment))
          this.D = true; 
        l1(paramFragment);
      } 
    } 
  }
  
  c0 x0() {
    c0 c01 = this.x;
    if (c01 != null)
      return c01; 
    Fragment fragment = this.t;
    return (fragment != null) ? fragment.G.x0() : this.y;
  }
  
  void y() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    S(4);
  }
  
  void z() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    S(0);
  }
  
  h0 z0(Fragment paramFragment) {
    return this.M.k(paramFragment);
  }
  
  class a implements androidx.activity.result.b<androidx.activity.result.a> {
    a(m this$0) {}
    
    public void b(androidx.activity.result.a param1a) {
      StringBuilder stringBuilder;
      m.m m1 = this.a.C.pollFirst();
      if (m1 == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("No IntentSenders were started for ");
        stringBuilder.append(this);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      String str = m1.o;
      int i = m1.p;
      Fragment fragment = m.c(this.a).i(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Intent Sender result delivered for unknown Fragment ");
        stringBuilder.append(str);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.m0(i, stringBuilder.j(), stringBuilder.i());
    }
  }
  
  class b implements androidx.activity.result.b<Map<String, Boolean>> {
    b(m this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void b(Map<String, Boolean> param1Map) {
      StringBuilder stringBuilder;
      String[] arrayOfString = (String[])param1Map.keySet().toArray((Object[])new String[0]);
      ArrayList<Boolean> arrayList = new ArrayList(param1Map.values());
      int[] arrayOfInt = new int[arrayList.size()];
      int i;
      for (i = 0; i < arrayList.size(); i++) {
        byte b1;
        if (((Boolean)arrayList.get(i)).booleanValue()) {
          b1 = 0;
        } else {
          b1 = -1;
        } 
        arrayOfInt[i] = b1;
      } 
      m.m m1 = this.a.C.pollFirst();
      if (m1 == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("No permissions were requested for ");
        stringBuilder.append(this);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      String str = m1.o;
      i = m1.p;
      Fragment fragment = m.c(this.a).i(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Permission request result delivered for unknown Fragment ");
        stringBuilder.append(str);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.L0(i, arrayOfString, (int[])stringBuilder);
    }
  }
  
  class c extends androidx.activity.g {
    c(m this$0, boolean param1Boolean) {
      super(param1Boolean);
    }
    
    public void b() {
      this.c.A0();
    }
  }
  
  class d implements w.g {
    d(m this$0) {}
    
    public void a(Fragment param1Fragment, androidx.core.os.e param1e) {
      if (!param1e.b())
        this.a.a1(param1Fragment, param1e); 
    }
    
    public void b(Fragment param1Fragment, androidx.core.os.e param1e) {
      this.a.f(param1Fragment, param1e);
    }
  }
  
  class e extends i {
    e(m this$0) {}
    
    public Fragment a(ClassLoader param1ClassLoader, String param1String) {
      return this.b.s0().e(this.b.s0().j(), param1String, null);
    }
  }
  
  class f implements c0 {
    f(m this$0) {}
    
    public b0 a(ViewGroup param1ViewGroup) {
      return new c(param1ViewGroup);
    }
  }
  
  class g implements Runnable {
    g(m this$0) {}
    
    public void run() {
      this.o.a0(true);
    }
  }
  
  class h extends AnimatorListenerAdapter {
    h(m this$0, ViewGroup param1ViewGroup, View param1View, Fragment param1Fragment) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator.removeListener((Animator.AnimatorListener)this);
      Fragment fragment = this.c;
      View view = fragment.V;
      if (view != null && fragment.N)
        view.setVisibility(8); 
    }
  }
  
  class i implements q {
    i(m this$0, Fragment param1Fragment) {}
    
    public void b(m param1m, Fragment param1Fragment) {
      this.o.p0(param1Fragment);
    }
  }
  
  class j implements androidx.activity.result.b<androidx.activity.result.a> {
    j(m this$0) {}
    
    public void b(androidx.activity.result.a param1a) {
      StringBuilder stringBuilder;
      m.m m1 = this.a.C.pollFirst();
      if (m1 == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("No Activities were started for result for ");
        stringBuilder.append(this);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      String str = m1.o;
      int i = m1.p;
      Fragment fragment = m.c(this.a).i(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result delivered for unknown Fragment ");
        stringBuilder.append(str);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.m0(i, stringBuilder.j(), stringBuilder.i());
    }
  }
  
  static class k extends d.a<androidx.activity.result.e, androidx.activity.result.a> {
    public Intent d(Context param1Context, androidx.activity.result.e param1e) {
      Intent intent1 = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
      Intent intent2 = param1e.i();
      androidx.activity.result.e e1 = param1e;
      if (intent2 != null) {
        Bundle bundle = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        e1 = param1e;
        if (bundle != null) {
          intent1.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
          intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
          e1 = param1e;
          if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false))
            e1 = (new androidx.activity.result.e.b(param1e.l())).b(null).c(param1e.k(), param1e.j()).a(); 
        } 
      } 
      intent1.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", (Parcelable)e1);
      if (m.E0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CreateIntent created the following intent: ");
        stringBuilder.append(intent1);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return intent1;
    }
    
    public androidx.activity.result.a e(int param1Int, Intent param1Intent) {
      return new androidx.activity.result.a(param1Int, param1Intent);
    }
  }
  
  public static abstract class l {
    @Deprecated
    public void a(m param1m, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void b(m param1m, Fragment param1Fragment, Context param1Context) {}
    
    public void c(m param1m, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void d(m param1m, Fragment param1Fragment) {}
    
    public void e(m param1m, Fragment param1Fragment) {}
    
    public void f(m param1m, Fragment param1Fragment) {}
    
    public void g(m param1m, Fragment param1Fragment, Context param1Context) {}
    
    public void h(m param1m, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void i(m param1m, Fragment param1Fragment) {}
    
    public void j(m param1m, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void k(m param1m, Fragment param1Fragment) {}
    
    public void l(m param1m, Fragment param1Fragment) {}
    
    public void m(m param1m, Fragment param1Fragment, View param1View, Bundle param1Bundle) {}
    
    public void n(m param1m, Fragment param1Fragment) {}
  }
  
  @SuppressLint({"BanParcelableUsage"})
  static class m implements Parcelable {
    public static final Parcelable.Creator<m> CREATOR = new a();
    
    String o;
    
    int p;
    
    m(Parcel param1Parcel) {
      this.o = param1Parcel.readString();
      this.p = param1Parcel.readInt();
    }
    
    m(String param1String, int param1Int) {
      this.o = param1String;
      this.p = param1Int;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.o);
      param1Parcel.writeInt(this.p);
    }
    
    class a implements Parcelable.Creator<m> {
      public m.m a(Parcel param2Parcel) {
        return new m.m(param2Parcel);
      }
      
      public m.m[] b(int param2Int) {
        return new m.m[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<m> {
    public m.m a(Parcel param1Parcel) {
      return new m.m(param1Parcel);
    }
    
    public m.m[] b(int param1Int) {
      return new m.m[param1Int];
    }
  }
  
  public static interface n {
    void a();
  }
  
  static interface o {
    boolean a(ArrayList<a> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class p implements o {
    final String a;
    
    final int b;
    
    final int c;
    
    p(m this$0, String param1String, int param1Int1, int param1Int2) {
      this.a = param1String;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public boolean a(ArrayList<a> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      Fragment fragment = this.d.u;
      return (fragment != null && this.b < 0 && this.a == null && fragment.t().V0()) ? false : this.d.X0(param1ArrayList, param1ArrayList1, this.a, this.b, this.c);
    }
  }
  
  static class q implements Fragment.g {
    final boolean a;
    
    final a b;
    
    private int c;
    
    q(a param1a, boolean param1Boolean) {
      this.a = param1Boolean;
      this.b = param1a;
    }
    
    public void a() {
      int i = this.c - 1;
      this.c = i;
      if (i != 0)
        return; 
      this.b.t.h1();
    }
    
    public void b() {
      this.c++;
    }
    
    void c() {
      a a1 = this.b;
      a1.t.t(a1, this.a, false, false);
    }
    
    void d() {
      boolean bool;
      if (this.c > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      for (Fragment fragment : this.b.t.r0()) {
        fragment.D1(null);
        if (bool && fragment.f0())
          fragment.K1(); 
      } 
      a a1 = this.b;
      a1.t.t(a1, this.a, bool ^ true, true);
    }
    
    public boolean e() {
      return (this.c == 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */