package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.d0;
import androidx.lifecycle.e0;
import androidx.lifecycle.f0;
import androidx.lifecycle.h0;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

final class p extends d0 {
  private static final e0.b k = new a();
  
  private final HashMap<String, Fragment> d = new HashMap<String, Fragment>();
  
  private final HashMap<String, p> e = new HashMap<String, p>();
  
  private final HashMap<String, h0> f = new HashMap<String, h0>();
  
  private final boolean g;
  
  private boolean h = false;
  
  private boolean i = false;
  
  private boolean j = false;
  
  p(boolean paramBoolean) {
    this.g = paramBoolean;
  }
  
  static p i(h0 paramh0) {
    return (p)(new e0(paramh0, k)).a(p.class);
  }
  
  protected void d() {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCleared called for ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.h = true;
  }
  
  void e(Fragment paramFragment) {
    if (this.j) {
      if (m.E0(2))
        Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.d.containsKey(paramFragment.t))
      return; 
    this.d.put(paramFragment.t, paramFragment);
    if (m.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Added ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (p.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.d.equals(((p)paramObject).d) && this.e.equals(((p)paramObject).e) && this.f.equals(((p)paramObject).f));
    } 
    return false;
  }
  
  void f(Fragment paramFragment) {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Clearing non-config state for ");
      stringBuilder.append(paramFragment);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    p p1 = this.e.get(paramFragment.t);
    if (p1 != null) {
      p1.d();
      this.e.remove(paramFragment.t);
    } 
    h0 h0 = this.f.get(paramFragment.t);
    if (h0 != null) {
      h0.a();
      this.f.remove(paramFragment.t);
    } 
  }
  
  Fragment g(String paramString) {
    return this.d.get(paramString);
  }
  
  p h(Fragment paramFragment) {
    p p2 = this.e.get(paramFragment.t);
    p p1 = p2;
    if (p2 == null) {
      p1 = new p(this.g);
      this.e.put(paramFragment.t, p1);
    } 
    return p1;
  }
  
  public int hashCode() {
    return (this.d.hashCode() * 31 + this.e.hashCode()) * 31 + this.f.hashCode();
  }
  
  Collection<Fragment> j() {
    return new ArrayList<Fragment>(this.d.values());
  }
  
  h0 k(Fragment paramFragment) {
    h0 h02 = this.f.get(paramFragment.t);
    h0 h01 = h02;
    if (h02 == null) {
      h01 = new h0();
      this.f.put(paramFragment.t, h01);
    } 
    return h01;
  }
  
  boolean l() {
    return this.h;
  }
  
  void m(Fragment paramFragment) {
    boolean bool;
    if (this.j) {
      if (m.E0(2))
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.d.remove(paramFragment.t) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool && m.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Removed ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void n(boolean paramBoolean) {
    this.j = paramBoolean;
  }
  
  boolean o(Fragment paramFragment) {
    return !this.d.containsKey(paramFragment.t) ? true : (this.g ? this.h : (this.i ^ true));
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("FragmentManagerViewModel{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("} Fragments (");
    Iterator<String> iterator = this.d.values().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") Child Non Config (");
    iterator = this.e.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") ViewModelStores (");
    iterator = this.f.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  class a implements e0.b {
    public <T extends d0> T a(Class<T> param1Class) {
      return (T)new p(true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */