package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.lifecycle.j0;
import androidx.lifecycle.k0;
import androidx.lifecycle.m;
import androidx.lifecycle.t;
import q0.f;

public class d extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
  private Dialog A0;
  
  private boolean B0;
  
  private boolean C0;
  
  private boolean D0;
  
  private boolean E0 = false;
  
  private Handler p0;
  
  private Runnable q0 = new a(this);
  
  private DialogInterface.OnCancelListener r0 = new b(this);
  
  private DialogInterface.OnDismissListener s0 = new c(this);
  
  private int t0 = 0;
  
  private int u0 = 0;
  
  private boolean v0 = true;
  
  private boolean w0 = true;
  
  private int x0 = -1;
  
  private boolean y0;
  
  private t<m> z0 = new d(this);
  
  private void P1(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.C0)
      return; 
    this.C0 = true;
    this.D0 = false;
    Dialog dialog = this.A0;
    if (dialog != null) {
      dialog.setOnDismissListener(null);
      this.A0.dismiss();
      if (!paramBoolean2)
        if (Looper.myLooper() == this.p0.getLooper()) {
          onDismiss((DialogInterface)this.A0);
        } else {
          this.p0.post(this.q0);
        }  
    } 
    this.B0 = true;
    if (this.x0 >= 0) {
      H().U0(this.x0, 1);
      this.x0 = -1;
      return;
    } 
    v v = H().l();
    v.m(this);
    if (paramBoolean1) {
      v.h();
      return;
    } 
    v.g();
  }
  
  private void V1(Bundle paramBundle) {
    if (!this.w0)
      return; 
    if (!this.E0)
      try {
        this.y0 = true;
        Dialog dialog = S1(paramBundle);
        this.A0 = dialog;
        if (this.w0) {
          Y1(dialog, this.t0);
          Context context = u();
          if (context instanceof Activity)
            this.A0.setOwnerActivity((Activity)context); 
          this.A0.setCancelable(this.v0);
          this.A0.setOnCancelListener(this.r0);
          this.A0.setOnDismissListener(this.s0);
          this.E0 = true;
        } else {
          this.A0 = null;
        } 
        return;
      } finally {
        this.y0 = false;
      }  
  }
  
  public LayoutInflater A0(Bundle paramBundle) {
    String str;
    LayoutInflater layoutInflater2 = super.A0(paramBundle);
    if (!this.w0 || this.y0) {
      if (m.E0(2)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("getting layout inflater for DialogFragment ");
        stringBuilder1.append(this);
        str = stringBuilder1.toString();
        if (!this.w0) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("mShowsDialog = false: ");
          stringBuilder.append(str);
          Log.d("FragmentManager", stringBuilder.toString());
          return layoutInflater2;
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("mCreatingDialog = true: ");
        stringBuilder2.append(str);
        Log.d("FragmentManager", stringBuilder2.toString());
      } 
      return layoutInflater2;
    } 
    V1((Bundle)str);
    if (m.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("get layout inflater for DialogFragment ");
      stringBuilder.append(this);
      stringBuilder.append(" from dialog context");
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Dialog dialog = this.A0;
    LayoutInflater layoutInflater1 = layoutInflater2;
    if (dialog != null)
      layoutInflater1 = layoutInflater2.cloneInContext(dialog.getContext()); 
    return layoutInflater1;
  }
  
  public void N0(Bundle paramBundle) {
    super.N0(paramBundle);
    Dialog dialog = this.A0;
    if (dialog != null) {
      Bundle bundle = dialog.onSaveInstanceState();
      bundle.putBoolean("android:dialogShowing", false);
      paramBundle.putBundle("android:savedDialogState", bundle);
    } 
    int i = this.t0;
    if (i != 0)
      paramBundle.putInt("android:style", i); 
    i = this.u0;
    if (i != 0)
      paramBundle.putInt("android:theme", i); 
    boolean bool = this.v0;
    if (!bool)
      paramBundle.putBoolean("android:cancelable", bool); 
    bool = this.w0;
    if (!bool)
      paramBundle.putBoolean("android:showsDialog", bool); 
    i = this.x0;
    if (i != -1)
      paramBundle.putInt("android:backStackId", i); 
  }
  
  public void O0() {
    super.O0();
    Dialog dialog = this.A0;
    if (dialog != null) {
      this.B0 = false;
      dialog.show();
      View view = this.A0.getWindow().getDecorView();
      j0.a(view, this);
      k0.a(view, this);
      f.a(view, this);
    } 
  }
  
  public void O1() {
    P1(false, false);
  }
  
  public void P0() {
    super.P0();
    Dialog dialog = this.A0;
    if (dialog != null)
      dialog.hide(); 
  }
  
  public Dialog Q1() {
    return this.A0;
  }
  
  public void R0(Bundle paramBundle) {
    super.R0(paramBundle);
    if (this.A0 != null && paramBundle != null) {
      paramBundle = paramBundle.getBundle("android:savedDialogState");
      if (paramBundle != null)
        this.A0.onRestoreInstanceState(paramBundle); 
    } 
  }
  
  public int R1() {
    return this.u0;
  }
  
  public Dialog S1(Bundle paramBundle) {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCreateDialog called for DialogFragment ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    return new Dialog(r1(), R1());
  }
  
  View T1(int paramInt) {
    Dialog dialog = this.A0;
    return (dialog != null) ? dialog.findViewById(paramInt) : null;
  }
  
  boolean U1() {
    return this.E0;
  }
  
  public final Dialog W1() {
    Dialog dialog = Q1();
    if (dialog != null)
      return dialog; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DialogFragment ");
    stringBuilder.append(this);
    stringBuilder.append(" does not have a Dialog.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void X1(boolean paramBoolean) {
    this.w0 = paramBoolean;
  }
  
  void Y0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    super.Y0(paramLayoutInflater, paramViewGroup, paramBundle);
    if (this.V == null && this.A0 != null && paramBundle != null) {
      Bundle bundle = paramBundle.getBundle("android:savedDialogState");
      if (bundle != null)
        this.A0.onRestoreInstanceState(bundle); 
    } 
  }
  
  public void Y1(Dialog paramDialog, int paramInt) {
    if (paramInt != 1 && paramInt != 2) {
      if (paramInt != 3)
        return; 
      Window window = paramDialog.getWindow();
      if (window != null)
        window.addFlags(24); 
    } 
    paramDialog.requestWindowFeature(1);
  }
  
  public void Z1(m paramm, String paramString) {
    this.C0 = false;
    this.D0 = true;
    v v = paramm.l();
    v.d(this, paramString);
    v.g();
  }
  
  g i() {
    return new e(this, super.i());
  }
  
  public void o0(Context paramContext) {
    super.o0(paramContext);
    W().i(this.z0);
    if (!this.D0)
      this.C0 = false; 
  }
  
  public void onCancel(DialogInterface paramDialogInterface) {}
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    if (!this.B0) {
      if (m.E0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onDismiss called for DialogFragment ");
        stringBuilder.append(this);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      P1(true, true);
    } 
  }
  
  public void r0(Bundle paramBundle) {
    boolean bool;
    super.r0(paramBundle);
    this.p0 = new Handler();
    if (this.L == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.w0 = bool;
    if (paramBundle != null) {
      this.t0 = paramBundle.getInt("android:style", 0);
      this.u0 = paramBundle.getInt("android:theme", 0);
      this.v0 = paramBundle.getBoolean("android:cancelable", true);
      this.w0 = paramBundle.getBoolean("android:showsDialog", this.w0);
      this.x0 = paramBundle.getInt("android:backStackId", -1);
    } 
  }
  
  public void y0() {
    super.y0();
    Dialog dialog = this.A0;
    if (dialog != null) {
      this.B0 = true;
      dialog.setOnDismissListener(null);
      this.A0.dismiss();
      if (!this.C0)
        onDismiss((DialogInterface)this.A0); 
      this.A0 = null;
      this.E0 = false;
    } 
  }
  
  public void z0() {
    super.z0();
    if (!this.D0 && !this.C0)
      this.C0 = true; 
    W().m(this.z0);
  }
  
  class a implements Runnable {
    a(d this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void run() {
      d.M1(this.o).onDismiss((DialogInterface)d.L1(this.o));
    }
  }
  
  class b implements DialogInterface.OnCancelListener {
    b(d this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void onCancel(DialogInterface param1DialogInterface) {
      if (d.L1(this.o) != null) {
        d d1 = this.o;
        d1.onCancel((DialogInterface)d.L1(d1));
      } 
    }
  }
  
  class c implements DialogInterface.OnDismissListener {
    c(d this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void onDismiss(DialogInterface param1DialogInterface) {
      if (d.L1(this.o) != null) {
        d d1 = this.o;
        d1.onDismiss((DialogInterface)d.L1(d1));
      } 
    }
  }
  
  class d implements t<m> {
    d(d this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void b(m param1m) {
      if (param1m != null && d.N1(this.a)) {
        View view = this.a.s1();
        if (view.getParent() == null) {
          if (d.L1(this.a) != null) {
            if (m.E0(3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("DialogFragment ");
              stringBuilder.append(this);
              stringBuilder.append(" setting the content view on ");
              stringBuilder.append(d.L1(this.a));
              Log.d("FragmentManager", stringBuilder.toString());
            } 
            d.L1(this.a).setContentView(view);
            return;
          } 
        } else {
          throw new IllegalStateException("DialogFragment can not be attached to a container view");
        } 
      } 
    }
  }
  
  class e extends g {
    e(d this$0, g param1g) {}
    
    public View f(int param1Int) {
      return this.a.g() ? this.a.f(param1Int) : this.b.T1(param1Int);
    }
    
    public boolean g() {
      return (this.a.g() || this.b.U1());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */