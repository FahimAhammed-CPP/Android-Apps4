package androidx.fragment.app;

import android.view.ViewGroup;
import androidx.lifecycle.i;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public abstract class v {
  private final i a;
  
  private final ClassLoader b;
  
  ArrayList<a> c = new ArrayList<a>();
  
  int d;
  
  int e;
  
  int f;
  
  int g;
  
  int h;
  
  boolean i;
  
  boolean j = true;
  
  String k;
  
  int l;
  
  CharSequence m;
  
  int n;
  
  CharSequence o;
  
  ArrayList<String> p;
  
  ArrayList<String> q;
  
  boolean r = false;
  
  ArrayList<Runnable> s;
  
  v(i parami, ClassLoader paramClassLoader) {
    this.a = parami;
    this.b = paramClassLoader;
  }
  
  public v b(int paramInt, Fragment paramFragment, String paramString) {
    l(paramInt, paramFragment, paramString, 1);
    return this;
  }
  
  v c(ViewGroup paramViewGroup, Fragment paramFragment, String paramString) {
    paramFragment.U = paramViewGroup;
    return b(paramViewGroup.getId(), paramFragment, paramString);
  }
  
  public v d(Fragment paramFragment, String paramString) {
    l(0, paramFragment, paramString, 1);
    return this;
  }
  
  void e(a parama) {
    this.c.add(parama);
    parama.c = this.d;
    parama.d = this.e;
    parama.e = this.f;
    parama.f = this.g;
  }
  
  public v f(String paramString) {
    if (this.j) {
      this.i = true;
      this.k = paramString;
      return this;
    } 
    throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
  }
  
  public abstract int g();
  
  public abstract int h();
  
  public abstract void i();
  
  public abstract void j();
  
  public v k() {
    if (!this.i) {
      this.j = false;
      return this;
    } 
    throw new IllegalStateException("This transaction is already being added to the back stack");
  }
  
  void l(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    StringBuilder stringBuilder2;
    Class<?> clazz = paramFragment.getClass();
    int j = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(j) && (!clazz.isMemberClass() || Modifier.isStatic(j))) {
      if (paramString != null) {
        String str = paramFragment.M;
        if (str == null || paramString.equals(str)) {
          paramFragment.M = paramString;
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't change tag of fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(": was ");
          stringBuilder2.append(paramFragment.M);
          stringBuilder2.append(" now ");
          stringBuilder2.append(paramString);
          throw new IllegalStateException(stringBuilder2.toString());
        } 
      } 
      if (paramInt1 != 0) {
        StringBuilder stringBuilder;
        if (paramInt1 != -1) {
          j = paramFragment.K;
          if (j == 0 || j == paramInt1) {
            paramFragment.K = paramInt1;
            paramFragment.L = paramInt1;
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can't change container ID of fragment ");
            stringBuilder.append(paramFragment);
            stringBuilder.append(": was ");
            stringBuilder.append(paramFragment.K);
            stringBuilder.append(" now ");
            stringBuilder.append(paramInt1);
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't add fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(" with tag ");
          stringBuilder2.append((String)stringBuilder);
          stringBuilder2.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
      } 
      e(new a(paramInt2, paramFragment));
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Fragment ");
    stringBuilder1.append(stringBuilder2.getCanonicalName());
    stringBuilder1.append(" must be a public static class to be  properly recreated from instance state.");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  public v m(Fragment paramFragment) {
    e(new a(3, paramFragment));
    return this;
  }
  
  public v n(int paramInt, Fragment paramFragment) {
    return o(paramInt, paramFragment, null);
  }
  
  public v o(int paramInt, Fragment paramFragment, String paramString) {
    if (paramInt != 0) {
      l(paramInt, paramFragment, paramString, 2);
      return this;
    } 
    throw new IllegalArgumentException("Must use non-zero containerViewId");
  }
  
  public v p(int paramInt1, int paramInt2) {
    return q(paramInt1, paramInt2, 0, 0);
  }
  
  public v q(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.d = paramInt1;
    this.e = paramInt2;
    this.f = paramInt3;
    this.g = paramInt4;
    return this;
  }
  
  public v r(boolean paramBoolean) {
    this.r = paramBoolean;
    return this;
  }
  
  static final class a {
    int a;
    
    Fragment b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    i.c g;
    
    i.c h;
    
    a() {}
    
    a(int param1Int, Fragment param1Fragment) {
      this.a = param1Int;
      this.b = param1Fragment;
      i.c c1 = i.c.s;
      this.g = c1;
      this.h = c1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */