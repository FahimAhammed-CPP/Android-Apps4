package androidx.fragment.app;

import android.util.Log;
import java.io.PrintWriter;
import java.util.ArrayList;

final class a extends v implements m.o {
  final m t;
  
  boolean u;
  
  int v;
  
  a(m paramm) {
    super(i, classLoader);
    ClassLoader classLoader;
    this.v = -1;
    this.t = paramm;
  }
  
  private static boolean C(v.a parama) {
    Fragment fragment = parama.b;
    return (fragment != null && fragment.z && fragment.V != null && !fragment.O && !fragment.N && fragment.f0());
  }
  
  boolean A(int paramInt) {
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      int k;
      Fragment fragment = ((v.a)this.c.get(i)).b;
      if (fragment != null) {
        k = fragment.L;
      } else {
        k = 0;
      } 
      if (k && k == paramInt)
        return true; 
    } 
    return false;
  }
  
  boolean B(ArrayList<a> paramArrayList, int paramInt1, int paramInt2) {
    if (paramInt2 == paramInt1)
      return false; 
    int k = this.c.size();
    int j = -1;
    int i = 0;
    while (i < k) {
      int n;
      Fragment fragment = ((v.a)this.c.get(i)).b;
      if (fragment != null) {
        n = fragment.L;
      } else {
        n = 0;
      } 
      int i1 = j;
      if (n) {
        i1 = j;
        if (n != j) {
          for (j = paramInt1; j < paramInt2; j++) {
            a a1 = paramArrayList.get(j);
            int i2 = a1.c.size();
            for (i1 = 0; i1 < i2; i1++) {
              int i3;
              Fragment fragment1 = ((v.a)a1.c.get(i1)).b;
              if (fragment1 != null) {
                i3 = fragment1.L;
              } else {
                i3 = 0;
              } 
              if (i3 == n)
                return true; 
            } 
          } 
          i1 = n;
        } 
      } 
      i++;
      j = i1;
    } 
    return false;
  }
  
  boolean D() {
    for (int i = 0; i < this.c.size(); i++) {
      if (C(this.c.get(i)))
        return true; 
    } 
    return false;
  }
  
  public void E() {
    if (this.s != null) {
      for (int i = 0; i < this.s.size(); i++)
        ((Runnable)this.s.get(i)).run(); 
      this.s = null;
    } 
  }
  
  void F(Fragment.g paramg) {
    for (int i = 0; i < this.c.size(); i++) {
      v.a a1 = this.c.get(i);
      if (C(a1))
        a1.b.D1(paramg); 
    } 
  }
  
  Fragment G(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = this.c.size() - 1;
    while (i >= 0) {
      v.a a1 = this.c.get(i);
      int j = a1.a;
      if (j != 1)
        if (j != 3) {
          switch (j) {
            case 10:
              a1.h = a1.g;
              break;
            case 9:
              paramFragment = a1.b;
              break;
            case 8:
              paramFragment = null;
              break;
            case 6:
              paramArrayList.add(a1.b);
              break;
            case 7:
              paramArrayList.remove(a1.b);
              break;
          } 
          i--;
        }  
    } 
    return paramFragment;
  }
  
  public boolean a(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (m.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.FALSE);
    if (this.i)
      this.t.e(this); 
    return true;
  }
  
  public int g() {
    return t(false);
  }
  
  public int h() {
    return t(true);
  }
  
  public void i() {
    k();
    this.t.b0(this, false);
  }
  
  public void j() {
    k();
    this.t.b0(this, true);
  }
  
  void l(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    super.l(paramInt1, paramFragment, paramString, paramInt2);
    paramFragment.G = this.t;
  }
  
  public v m(Fragment paramFragment) {
    m m1 = paramFragment.G;
    if (m1 == null || m1 == this.t)
      return super.m(paramFragment); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
    stringBuilder.append(paramFragment.toString());
    stringBuilder.append(" is already attached to a FragmentManager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void s(int paramInt) {
    if (!this.i)
      return; 
    if (m.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      v.a a1 = this.c.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.F += paramInt;
        if (m.E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bump nesting of ");
          stringBuilder.append(a1.b);
          stringBuilder.append(" to ");
          stringBuilder.append(a1.b.F);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  int t(boolean paramBoolean) {
    if (!this.u) {
      if (m.E0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter(new a0("FragmentManager"));
        u("  ", printWriter);
        printWriter.close();
      } 
      this.u = true;
      if (this.i) {
        this.v = this.t.i();
      } else {
        this.v = -1;
      } 
      this.t.Y(this, paramBoolean);
      return this.v;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.v >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.v);
    } 
    if (this.k != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.k);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void u(String paramString, PrintWriter paramPrintWriter) {
    v(paramString, paramPrintWriter, true);
  }
  
  public void v(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.k);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.v);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.u);
      if (this.h != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.h));
      } 
      if (this.d != 0 || this.e != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.d));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.e));
      } 
      if (this.f != 0 || this.g != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.f));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.g));
      } 
      if (this.l != 0 || this.m != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.l));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.m);
      } 
      if (this.n != 0 || this.o != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.n));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.o);
      } 
    } 
    if (!this.c.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      int j = this.c.size();
      int i;
      for (i = 0; i < j; i++) {
        StringBuilder stringBuilder;
        String str;
        v.a a1 = this.c.get(i);
        switch (a1.a) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("cmd=");
            stringBuilder.append(a1.a);
            str = stringBuilder.toString();
            break;
          case 10:
            str = "OP_SET_MAX_LIFECYCLE";
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(i);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(a1.b);
        if (paramBoolean) {
          if (a1.c != 0 || a1.d != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.c));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.d));
          } 
          if (a1.e != 0 || a1.f != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.e));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.f));
          } 
        } 
      } 
    } 
  }
  
  void w() {
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      StringBuilder stringBuilder;
      v.a a1 = this.c.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.E1(false);
        fragment.C1(this.h);
        fragment.G1(this.p, this.q);
      } 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.t.j1((Fragment)stringBuilder, a1.h);
          break;
        case 9:
          this.t.k1(null);
          break;
        case 8:
          this.t.k1((Fragment)stringBuilder);
          break;
        case 7:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.i1((Fragment)stringBuilder, false);
          this.t.k((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.x((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.i1((Fragment)stringBuilder, false);
          this.t.m1((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.B0((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.b1((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.i1((Fragment)stringBuilder, false);
          this.t.g((Fragment)stringBuilder);
          break;
      } 
      if (!this.r && a1.a != 1 && stringBuilder != null && !m.P)
        this.t.M0((Fragment)stringBuilder); 
    } 
    if (!this.r && !m.P) {
      m m1 = this.t;
      m1.N0(m1.q, true);
    } 
  }
  
  void x(boolean paramBoolean) {
    for (int i = this.c.size() - 1; i >= 0; i--) {
      StringBuilder stringBuilder;
      v.a a1 = this.c.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.E1(true);
        fragment.C1(m.f1(this.h));
        fragment.G1(this.q, this.p);
      } 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.t.j1((Fragment)stringBuilder, a1.g);
          break;
        case 9:
          this.t.k1((Fragment)stringBuilder);
          break;
        case 8:
          this.t.k1(null);
          break;
        case 7:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.i1((Fragment)stringBuilder, true);
          this.t.x((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.k((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.i1((Fragment)stringBuilder, true);
          this.t.B0((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.m1((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.g((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.x1(a1.c, a1.d, a1.e, a1.f);
          this.t.i1((Fragment)stringBuilder, true);
          this.t.b1((Fragment)stringBuilder);
          break;
      } 
      if (!this.r && a1.a != 3 && stringBuilder != null && !m.P)
        this.t.M0((Fragment)stringBuilder); 
    } 
    if (!this.r && paramBoolean && !m.P) {
      m m1 = this.t;
      m1.N0(m1.q, true);
    } 
  }
  
  Fragment y(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = 0;
    Fragment fragment;
    for (fragment = paramFragment; i < this.c.size(); fragment = paramFragment) {
      Fragment fragment1;
      v.a a1 = this.c.get(i);
      int j = a1.a;
      if (j != 1)
        if (j != 2) {
          if (j != 3 && j != 6) {
            if (j != 7) {
              if (j != 8) {
                paramFragment = fragment;
                j = i;
              } else {
                this.c.add(i, new v.a(9, fragment));
                j = i + 1;
                paramFragment = a1.b;
              } 
              continue;
            } 
          } else {
            paramArrayList.remove(a1.b);
            fragment1 = a1.b;
            paramFragment = fragment;
            j = i;
            if (fragment1 == fragment) {
              this.c.add(i, new v.a(9, fragment1));
              j = i + 1;
              paramFragment = null;
            } 
            continue;
          } 
        } else {
          Fragment fragment2 = ((v.a)fragment1).b;
          int n = fragment2.L;
          int k = paramArrayList.size() - 1;
          boolean bool = false;
          j = i;
          paramFragment = fragment;
          while (k >= 0) {
            Fragment fragment3 = paramArrayList.get(k);
            fragment = paramFragment;
            i = j;
            boolean bool1 = bool;
            if (fragment3.L == n)
              if (fragment3 == fragment2) {
                bool1 = true;
                fragment = paramFragment;
                i = j;
              } else {
                fragment = paramFragment;
                i = j;
                if (fragment3 == paramFragment) {
                  this.c.add(j, new v.a(9, fragment3));
                  i = j + 1;
                  fragment = null;
                } 
                v.a a2 = new v.a(3, fragment3);
                a2.c = ((v.a)fragment1).c;
                a2.e = ((v.a)fragment1).e;
                a2.d = ((v.a)fragment1).d;
                a2.f = ((v.a)fragment1).f;
                this.c.add(i, a2);
                paramArrayList.remove(fragment3);
                i++;
                bool1 = bool;
              }  
            k--;
            paramFragment = fragment;
            j = i;
            bool = bool1;
          } 
          if (bool) {
            this.c.remove(j);
            j--;
          } else {
            ((v.a)fragment1).a = 1;
            paramArrayList.add(fragment2);
          } 
          continue;
        }  
      paramArrayList.add(((v.a)fragment1).b);
      j = i;
      paramFragment = fragment;
      continue;
      i = SYNTHETIC_LOCAL_VARIABLE_3 + 1;
    } 
    return fragment;
  }
  
  public String z() {
    return this.k;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */