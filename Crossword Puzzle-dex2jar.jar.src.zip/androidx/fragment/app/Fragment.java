package androidx.fragment.app;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.core.app.s;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.e0;
import androidx.lifecycle.h;
import androidx.lifecycle.h0;
import androidx.lifecycle.i;
import androidx.lifecycle.i0;
import androidx.lifecycle.j0;
import androidx.lifecycle.k;
import androidx.lifecycle.k0;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.n;
import androidx.lifecycle.s;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import q0.e;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, m, i0, h, e {
  static final Object o0 = new Object();
  
  boolean A;
  
  boolean B;
  
  boolean C;
  
  boolean D;
  
  boolean E;
  
  int F;
  
  m G;
  
  j<?> H;
  
  m I = new n();
  
  Fragment J;
  
  int K;
  
  int L;
  
  String M;
  
  boolean N;
  
  boolean O;
  
  boolean P;
  
  boolean Q;
  
  boolean R;
  
  boolean S = true;
  
  private boolean T;
  
  ViewGroup U;
  
  View V;
  
  boolean W;
  
  boolean X = true;
  
  e Y;
  
  Runnable Z = new a(this);
  
  boolean a0;
  
  boolean b0;
  
  float c0;
  
  LayoutInflater d0;
  
  boolean e0;
  
  i.c f0 = i.c.s;
  
  n g0;
  
  z h0;
  
  s<m> i0 = new s();
  
  e0.b j0;
  
  q0.d k0;
  
  private int l0;
  
  private final AtomicInteger m0 = new AtomicInteger();
  
  private final ArrayList<f> n0 = new ArrayList<f>();
  
  int o = -1;
  
  Bundle p;
  
  SparseArray<Parcelable> q;
  
  Bundle r;
  
  Boolean s;
  
  String t = UUID.randomUUID().toString();
  
  Bundle u;
  
  Fragment v;
  
  String w = null;
  
  int x;
  
  private Boolean y = null;
  
  boolean z;
  
  public Fragment() {
    X();
  }
  
  private int E() {
    i.c c1 = this.f0;
    return (c1 == i.c.p || this.J == null) ? c1.ordinal() : Math.min(c1.ordinal(), this.J.E());
  }
  
  private void X() {
    this.g0 = new n(this);
    this.k0 = q0.d.a(this);
    this.j0 = null;
  }
  
  @Deprecated
  public static Fragment Z(Context paramContext, String paramString, Bundle paramBundle) {
    try {
      Fragment fragment = i.d(paramContext.getClassLoader(), paramString).getConstructor(new Class[0]).newInstance(new Object[0]);
      if (paramBundle != null) {
        paramBundle.setClassLoader(fragment.getClass().getClassLoader());
        fragment.z1(paramBundle);
      } 
      return fragment;
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an empty constructor that is public");
      throw new InstantiationException(stringBuilder.toString(), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an empty constructor that is public");
      throw new InstantiationException(stringBuilder.toString(), illegalAccessException);
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": could not find Fragment constructor");
      throw new InstantiationException(stringBuilder.toString(), noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": calling Fragment constructor caused an exception");
      throw new InstantiationException(stringBuilder.toString(), invocationTargetException);
    } 
  }
  
  private e l() {
    if (this.Y == null)
      this.Y = new e(); 
    return this.Y;
  }
  
  private void u1() {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto RESTORE_VIEW_STATE: ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    if (this.V != null)
      v1(this.p); 
    this.p = null;
  }
  
  s A() {
    e e1 = this.Y;
    if (e1 == null)
      return null; 
    Objects.requireNonNull(e1);
    return null;
  }
  
  public LayoutInflater A0(Bundle paramBundle) {
    return D(paramBundle);
  }
  
  void A1(View paramView) {
    (l()).t = paramView;
  }
  
  View B() {
    e e1 = this.Y;
    return (e1 == null) ? null : e1.t;
  }
  
  public void B0(boolean paramBoolean) {}
  
  void B1(boolean paramBoolean) {
    (l()).w = paramBoolean;
  }
  
  public final Object C() {
    j<?> j1 = this.H;
    return (j1 == null) ? null : j1.m();
  }
  
  @Deprecated
  public void C0(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle) {
    this.T = true;
  }
  
  void C1(int paramInt) {
    if (this.Y == null && paramInt == 0)
      return; 
    l();
    this.Y.h = paramInt;
  }
  
  @Deprecated
  public LayoutInflater D(Bundle paramBundle) {
    j<?> j1 = this.H;
    if (j1 != null) {
      LayoutInflater layoutInflater = j1.n();
      androidx.core.view.g.b(layoutInflater, this.I.t0());
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public void D0(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.T = true;
    j<?> j1 = this.H;
    if (j1 == null) {
      j1 = null;
    } else {
      activity = j1.h();
    } 
    if (activity != null) {
      this.T = false;
      C0(activity, paramAttributeSet, paramBundle);
    } 
  }
  
  void D1(g paramg) {
    l();
    e e1 = this.Y;
    g g1 = e1.v;
    if (paramg == g1)
      return; 
    if (paramg == null || g1 == null) {
      if (e1.u)
        e1.v = paramg; 
      if (paramg != null)
        paramg.b(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void E0(boolean paramBoolean) {}
  
  void E1(boolean paramBoolean) {
    if (this.Y == null)
      return; 
    (l()).c = paramBoolean;
  }
  
  int F() {
    e e1 = this.Y;
    return (e1 == null) ? 0 : e1.h;
  }
  
  public boolean F0(MenuItem paramMenuItem) {
    return false;
  }
  
  void F1(float paramFloat) {
    (l()).s = paramFloat;
  }
  
  public final Fragment G() {
    return this.J;
  }
  
  public void G0(Menu paramMenu) {}
  
  void G1(ArrayList<String> paramArrayList1, ArrayList<String> paramArrayList2) {
    l();
    e e1 = this.Y;
    e1.i = paramArrayList1;
    e1.j = paramArrayList2;
  }
  
  public final m H() {
    m m1 = this.G;
    if (m1 != null)
      return m1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not associated with a fragment manager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void H0() {
    this.T = true;
  }
  
  public void H1(@SuppressLint({"UnknownNullness"}) Intent paramIntent) {
    I1(paramIntent, null);
  }
  
  boolean I() {
    e e1 = this.Y;
    return (e1 == null) ? false : e1.c;
  }
  
  public void I0(boolean paramBoolean) {}
  
  public void I1(@SuppressLint({"UnknownNullness"}) Intent paramIntent, Bundle paramBundle) {
    j<?> j1 = this.H;
    if (j1 != null) {
      j1.p(this, paramIntent, -1, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  int J() {
    e e1 = this.Y;
    return (e1 == null) ? 0 : e1.f;
  }
  
  public void J0(Menu paramMenu) {}
  
  @Deprecated
  public void J1(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (this.H != null) {
      H().K0(this, paramIntent, paramInt, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  int K() {
    e e1 = this.Y;
    return (e1 == null) ? 0 : e1.g;
  }
  
  public void K0(boolean paramBoolean) {}
  
  public void K1() {
    if (this.Y != null) {
      if (!(l()).u)
        return; 
      if (this.H == null) {
        (l()).u = false;
        return;
      } 
      if (Looper.myLooper() != this.H.l().getLooper()) {
        this.H.l().postAtFrontOfQueue(new b(this));
        return;
      } 
      g(true);
    } 
  }
  
  float L() {
    e e1 = this.Y;
    return (e1 == null) ? 1.0F : e1.s;
  }
  
  @Deprecated
  public void L0(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {}
  
  public Object M() {
    e e1 = this.Y;
    if (e1 == null)
      return null; 
    Object object2 = e1.n;
    Object object1 = object2;
    if (object2 == o0)
      object1 = z(); 
    return object1;
  }
  
  public void M0() {
    this.T = true;
  }
  
  public final Resources N() {
    return r1().getResources();
  }
  
  public void N0(Bundle paramBundle) {}
  
  public Object O() {
    e e1 = this.Y;
    if (e1 == null)
      return null; 
    Object object2 = e1.l;
    Object object1 = object2;
    if (object2 == o0)
      object1 = w(); 
    return object1;
  }
  
  public void O0() {
    this.T = true;
  }
  
  public Object P() {
    e e1 = this.Y;
    return (e1 == null) ? null : e1.o;
  }
  
  public void P0() {
    this.T = true;
  }
  
  public Object Q() {
    e e1 = this.Y;
    if (e1 == null)
      return null; 
    Object object2 = e1.p;
    Object object1 = object2;
    if (object2 == o0)
      object1 = P(); 
    return object1;
  }
  
  public void Q0(View paramView, Bundle paramBundle) {}
  
  ArrayList<String> R() {
    e e1 = this.Y;
    if (e1 != null) {
      ArrayList<String> arrayList = e1.i;
      if (arrayList != null)
        return arrayList; 
    } 
    return new ArrayList<String>();
  }
  
  public void R0(Bundle paramBundle) {
    this.T = true;
  }
  
  ArrayList<String> S() {
    e e1 = this.Y;
    if (e1 != null) {
      ArrayList<String> arrayList = e1.j;
      if (arrayList != null)
        return arrayList; 
    } 
    return new ArrayList<String>();
  }
  
  void S0(Bundle paramBundle) {
    this.I.Q0();
    this.o = 3;
    this.T = false;
    l0(paramBundle);
    if (this.T) {
      u1();
      this.I.y();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onActivityCreated()");
    throw new d0(stringBuilder.toString());
  }
  
  public final String T(int paramInt) {
    return N().getString(paramInt);
  }
  
  void T0() {
    Iterator<f> iterator = this.n0.iterator();
    while (iterator.hasNext())
      ((f)iterator.next()).a(); 
    this.n0.clear();
    this.I.j(this.H, i(), this);
    this.o = 0;
    this.T = false;
    o0(this.H.j());
    if (this.T) {
      this.G.I(this);
      this.I.z();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onAttach()");
    d0 d0 = new d0(stringBuilder.toString());
    throw d0;
  }
  
  @Deprecated
  public final Fragment U() {
    Fragment fragment = this.v;
    if (fragment != null)
      return fragment; 
    m m1 = this.G;
    if (m1 != null) {
      String str = this.w;
      if (str != null)
        return m1.f0(str); 
    } 
    return null;
  }
  
  void U0(Configuration paramConfiguration) {
    onConfigurationChanged(paramConfiguration);
    this.I.A(paramConfiguration);
  }
  
  public View V() {
    return this.V;
  }
  
  boolean V0(MenuItem paramMenuItem) {
    return !this.N ? (q0(paramMenuItem) ? true : this.I.B(paramMenuItem)) : false;
  }
  
  public LiveData<m> W() {
    return (LiveData<m>)this.i0;
  }
  
  void W0(Bundle paramBundle) {
    this.I.Q0();
    this.o = 1;
    this.T = false;
    this.g0.a((l)new k(this) {
          public void d(m param1m, i.b param1b) {
            if (param1b == i.b.ON_STOP) {
              View view = this.a.V;
              if (view != null)
                view.cancelPendingInputEvents(); 
            } 
          }
        });
    this.k0.d(paramBundle);
    r0(paramBundle);
    this.e0 = true;
    if (this.T) {
      this.g0.h(i.b.ON_CREATE);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onCreate()");
    throw new d0(stringBuilder.toString());
  }
  
  boolean X0(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool3 = this.N;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.R) {
        bool = bool1;
        if (this.S) {
          bool = true;
          u0(paramMenu, paramMenuInflater);
        } 
      } 
      bool2 = bool | this.I.D(paramMenu, paramMenuInflater);
    } 
    return bool2;
  }
  
  void Y() {
    X();
    this.t = UUID.randomUUID().toString();
    this.z = false;
    this.A = false;
    this.B = false;
    this.C = false;
    this.D = false;
    this.F = 0;
    this.G = null;
    this.I = new n();
    this.H = null;
    this.K = 0;
    this.L = 0;
    this.M = null;
    this.N = false;
    this.O = false;
  }
  
  void Y0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    this.I.Q0();
    this.E = true;
    this.h0 = new z(this, k());
    View view = v0(paramLayoutInflater, paramViewGroup, paramBundle);
    this.V = view;
    if (view != null) {
      this.h0.e();
      j0.a(this.V, (m)this.h0);
      k0.a(this.V, this.h0);
      q0.f.a(this.V, this.h0);
      this.i0.n(this.h0);
      return;
    } 
    if (!this.h0.f()) {
      this.h0 = null;
      return;
    } 
    throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
  }
  
  void Z0() {
    this.I.E();
    this.g0.h(i.b.ON_DESTROY);
    this.o = 0;
    this.T = false;
    this.e0 = false;
    w0();
    if (this.T)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroy()");
    throw new d0(stringBuilder.toString());
  }
  
  public i a() {
    return (i)this.g0;
  }
  
  public final boolean a0() {
    return (this.H != null && this.z);
  }
  
  void a1() {
    this.I.F();
    if (this.V != null && this.h0.a().b().c(i.c.q))
      this.h0.b(i.b.ON_DESTROY); 
    this.o = 1;
    this.T = false;
    y0();
    if (this.T) {
      androidx.loader.app.a.b(this).d();
      this.E = false;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroyView()");
    throw new d0(stringBuilder.toString());
  }
  
  public final boolean b0() {
    return this.N;
  }
  
  void b1() {
    this.o = -1;
    this.T = false;
    z0();
    this.d0 = null;
    if (this.T) {
      if (!this.I.D0()) {
        this.I.E();
        this.I = new n();
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDetach()");
    throw new d0(stringBuilder.toString());
  }
  
  boolean c0() {
    e e1 = this.Y;
    return (e1 == null) ? false : e1.w;
  }
  
  LayoutInflater c1(Bundle paramBundle) {
    LayoutInflater layoutInflater = A0(paramBundle);
    this.d0 = layoutInflater;
    return layoutInflater;
  }
  
  public final q0.c d() {
    return this.k0.b();
  }
  
  final boolean d0() {
    return (this.F > 0);
  }
  
  void d1() {
    onLowMemory();
    this.I.G();
  }
  
  public final boolean e0() {
    if (this.S) {
      m m1 = this.G;
      if (m1 == null || m1.G0(this.J))
        return true; 
    } 
    return false;
  }
  
  void e1(boolean paramBoolean) {
    E0(paramBoolean);
    this.I.H(paramBoolean);
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  boolean f0() {
    e e1 = this.Y;
    return (e1 == null) ? false : e1.u;
  }
  
  boolean f1(MenuItem paramMenuItem) {
    return !this.N ? ((this.R && this.S && F0(paramMenuItem)) ? true : this.I.J(paramMenuItem)) : false;
  }
  
  void g(boolean paramBoolean) {
    e e1 = this.Y;
    g g = null;
    if (e1 != null) {
      e1.u = false;
      g = e1.v;
      e1.v = null;
    } 
    if (g != null) {
      g.a();
      return;
    } 
    if (m.P && this.V != null) {
      ViewGroup viewGroup = this.U;
      if (viewGroup != null) {
        m m1 = this.G;
        if (m1 != null) {
          b0 b0 = b0.n(viewGroup, m1);
          b0.p();
          if (paramBoolean) {
            this.H.l().post(new c(this, b0));
            return;
          } 
          b0.g();
        } 
      } 
    } 
  }
  
  public final boolean g0() {
    return this.A;
  }
  
  void g1(Menu paramMenu) {
    if (!this.N) {
      if (this.R && this.S)
        G0(paramMenu); 
      this.I.K(paramMenu);
    } 
  }
  
  final boolean h0() {
    Fragment fragment = G();
    return (fragment != null && (fragment.g0() || fragment.h0()));
  }
  
  void h1() {
    this.I.M();
    if (this.V != null)
      this.h0.b(i.b.ON_PAUSE); 
    this.g0.h(i.b.ON_PAUSE);
    this.o = 6;
    this.T = false;
    H0();
    if (this.T)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onPause()");
    throw new d0(stringBuilder.toString());
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  g i() {
    return new d(this);
  }
  
  public final boolean i0() {
    m m1 = this.G;
    return (m1 == null) ? false : m1.J0();
  }
  
  void i1(boolean paramBoolean) {
    I0(paramBoolean);
    this.I.N(paramBoolean);
  }
  
  public void j(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.K));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.L));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.M);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.o);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.t);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.F);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.z);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.A);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.B);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.C);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.N);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.O);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.S);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.R);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.P);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.X);
    if (this.G != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.G);
    } 
    if (this.H != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.H);
    } 
    if (this.J != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.J);
    } 
    if (this.u != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.u);
    } 
    if (this.p != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.p);
    } 
    if (this.q != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.q);
    } 
    if (this.r != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewRegistryState=");
      paramPrintWriter.println(this.r);
    } 
    Fragment fragment = U();
    if (fragment != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(fragment);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.x);
    } 
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mPopDirection=");
    paramPrintWriter.println(I());
    if (v() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getEnterAnim=");
      paramPrintWriter.println(v());
    } 
    if (y() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getExitAnim=");
      paramPrintWriter.println(y());
    } 
    if (J() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getPopEnterAnim=");
      paramPrintWriter.println(J());
    } 
    if (K() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getPopExitAnim=");
      paramPrintWriter.println(K());
    } 
    if (this.U != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.U);
    } 
    if (this.V != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.V);
    } 
    if (q() != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(q());
    } 
    if (u() != null)
      androidx.loader.app.a.b(this).a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Child ");
    stringBuilder1.append(this.I);
    stringBuilder1.append(":");
    paramPrintWriter.println(stringBuilder1.toString());
    m m1 = this.I;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("  ");
    m1.W(stringBuilder2.toString(), paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public final boolean j0() {
    if (a0() && !b0()) {
      View view = this.V;
      if (view != null && view.getWindowToken() != null && this.V.getVisibility() == 0)
        return true; 
    } 
    return false;
  }
  
  boolean j1(Menu paramMenu) {
    boolean bool3 = this.N;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.R) {
        bool = bool1;
        if (this.S) {
          bool = true;
          J0(paramMenu);
        } 
      } 
      bool2 = bool | this.I.O(paramMenu);
    } 
    return bool2;
  }
  
  public h0 k() {
    if (this.G != null) {
      if (E() != i.c.p.ordinal())
        return this.G.z0(this); 
      throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  void k0() {
    this.I.Q0();
  }
  
  void k1() {
    boolean bool = this.G.H0(this);
    Boolean bool1 = this.y;
    if (bool1 == null || bool1.booleanValue() != bool) {
      this.y = Boolean.valueOf(bool);
      K0(bool);
      this.I.P();
    } 
  }
  
  @Deprecated
  public void l0(Bundle paramBundle) {
    this.T = true;
  }
  
  void l1() {
    this.I.Q0();
    this.I.a0(true);
    this.o = 7;
    this.T = false;
    M0();
    if (this.T) {
      n n1 = this.g0;
      i.b b1 = i.b.ON_RESUME;
      n1.h(b1);
      if (this.V != null)
        this.h0.b(b1); 
      this.I.Q();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onResume()");
    throw new d0(stringBuilder.toString());
  }
  
  Fragment m(String paramString) {
    return paramString.equals(this.t) ? this : this.I.i0(paramString);
  }
  
  @Deprecated
  public void m0(int paramInt1, int paramInt2, Intent paramIntent) {
    if (m.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this);
      stringBuilder.append(" received the following in onActivityResult(): requestCode: ");
      stringBuilder.append(paramInt1);
      stringBuilder.append(" resultCode: ");
      stringBuilder.append(paramInt2);
      stringBuilder.append(" data: ");
      stringBuilder.append(paramIntent);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void m1(Bundle paramBundle) {
    N0(paramBundle);
    this.k0.e(paramBundle);
    Parcelable parcelable = this.I.g1();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
  }
  
  public final e n() {
    j<?> j1 = this.H;
    return (j1 == null) ? null : (e)j1.h();
  }
  
  @Deprecated
  public void n0(Activity paramActivity) {
    this.T = true;
  }
  
  void n1() {
    this.I.Q0();
    this.I.a0(true);
    this.o = 5;
    this.T = false;
    O0();
    if (this.T) {
      n n1 = this.g0;
      i.b b1 = i.b.ON_START;
      n1.h(b1);
      if (this.V != null)
        this.h0.b(b1); 
      this.I.R();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStart()");
    throw new d0(stringBuilder.toString());
  }
  
  public boolean o() {
    e e1 = this.Y;
    if (e1 != null) {
      Boolean bool = e1.r;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  public void o0(Context paramContext) {
    Activity activity;
    this.T = true;
    j<?> j1 = this.H;
    if (j1 == null) {
      j1 = null;
    } else {
      activity = j1.h();
    } 
    if (activity != null) {
      this.T = false;
      n0(activity);
    } 
  }
  
  void o1() {
    this.I.T();
    if (this.V != null)
      this.h0.b(i.b.ON_STOP); 
    this.g0.h(i.b.ON_STOP);
    this.o = 4;
    this.T = false;
    P0();
    if (this.T)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStop()");
    throw new d0(stringBuilder.toString());
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.T = true;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    q1().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }
  
  public void onLowMemory() {
    this.T = true;
  }
  
  public boolean p() {
    e e1 = this.Y;
    if (e1 != null) {
      Boolean bool = e1.q;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  @Deprecated
  public void p0(Fragment paramFragment) {}
  
  void p1() {
    Q0(this.V, this.p);
    this.I.U();
  }
  
  View q() {
    e e1 = this.Y;
    return (e1 == null) ? null : e1.a;
  }
  
  public boolean q0(MenuItem paramMenuItem) {
    return false;
  }
  
  public final e q1() {
    e e1 = n();
    if (e1 != null)
      return e1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to an activity.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  Animator r() {
    e e1 = this.Y;
    return (e1 == null) ? null : e1.b;
  }
  
  public void r0(Bundle paramBundle) {
    this.T = true;
    t1(paramBundle);
    if (!this.I.I0(1))
      this.I.C(); 
  }
  
  public final Context r1() {
    Context context = u();
    if (context != null)
      return context; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to a context.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final Bundle s() {
    return this.u;
  }
  
  public Animation s0(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public final View s1() {
    View view = V();
    if (view != null)
      return view; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not return a View from onCreateView() or this was called before onCreateView().");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    J1(paramIntent, paramInt, null);
  }
  
  public final m t() {
    if (this.H != null)
      return this.I; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" has not been attached yet.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public Animator t0(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  void t1(Bundle paramBundle) {
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        this.I.e1(parcelable);
        this.I.C();
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append("{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("}");
    stringBuilder.append(" (");
    stringBuilder.append(this.t);
    if (this.K != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.K));
    } 
    if (this.M != null) {
      stringBuilder.append(" tag=");
      stringBuilder.append(this.M);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public Context u() {
    j<?> j1 = this.H;
    return (j1 == null) ? null : j1.j();
  }
  
  public void u0(Menu paramMenu, MenuInflater paramMenuInflater) {}
  
  int v() {
    e e1 = this.Y;
    return (e1 == null) ? 0 : e1.d;
  }
  
  public View v0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    int i = this.l0;
    return (i != 0) ? paramLayoutInflater.inflate(i, paramViewGroup, false) : null;
  }
  
  final void v1(Bundle paramBundle) {
    SparseArray<Parcelable> sparseArray = this.q;
    if (sparseArray != null) {
      this.V.restoreHierarchyState(sparseArray);
      this.q = null;
    } 
    if (this.V != null) {
      this.h0.g(this.r);
      this.r = null;
    } 
    this.T = false;
    R0(paramBundle);
    if (this.T) {
      if (this.V != null)
        this.h0.b(i.b.ON_CREATE); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onViewStateRestored()");
    throw new d0(stringBuilder.toString());
  }
  
  public Object w() {
    e e1 = this.Y;
    return (e1 == null) ? null : e1.k;
  }
  
  public void w0() {
    this.T = true;
  }
  
  void w1(View paramView) {
    (l()).a = paramView;
  }
  
  s x() {
    e e1 = this.Y;
    if (e1 == null)
      return null; 
    Objects.requireNonNull(e1);
    return null;
  }
  
  public void x0() {}
  
  void x1(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.Y == null && paramInt1 == 0 && paramInt2 == 0 && paramInt3 == 0 && paramInt4 == 0)
      return; 
    (l()).d = paramInt1;
    (l()).e = paramInt2;
    (l()).f = paramInt3;
    (l()).g = paramInt4;
  }
  
  int y() {
    e e1 = this.Y;
    return (e1 == null) ? 0 : e1.e;
  }
  
  public void y0() {
    this.T = true;
  }
  
  void y1(Animator paramAnimator) {
    (l()).b = paramAnimator;
  }
  
  public Object z() {
    e e1 = this.Y;
    return (e1 == null) ? null : e1.m;
  }
  
  public void z0() {
    this.T = true;
  }
  
  public void z1(Bundle paramBundle) {
    if (this.G == null || !i0()) {
      this.u = paramBundle;
      return;
    } 
    throw new IllegalStateException("Fragment already added and state has been saved");
  }
  
  public static class InstantiationException extends RuntimeException {
    public InstantiationException(String param1String, Exception param1Exception) {
      super(param1String, param1Exception);
    }
  }
  
  class a implements Runnable {
    a(Fragment this$0) {}
    
    public void run() {
      this.o.K1();
    }
  }
  
  class b implements Runnable {
    b(Fragment this$0) {}
    
    public void run() {
      this.o.g(false);
    }
  }
  
  class c implements Runnable {
    c(Fragment this$0, b0 param1b0) {}
    
    public void run() {
      this.o.g();
    }
  }
  
  class d extends g {
    d(Fragment this$0) {}
    
    public View f(int param1Int) {
      View view = this.a.V;
      if (view != null)
        return view.findViewById(param1Int); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this.a);
      stringBuilder.append(" does not have a view");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public boolean g() {
      return (this.a.V != null);
    }
  }
  
  static class e {
    View a;
    
    Animator b;
    
    boolean c;
    
    int d;
    
    int e;
    
    int f;
    
    int g;
    
    int h;
    
    ArrayList<String> i;
    
    ArrayList<String> j;
    
    Object k = null;
    
    Object l;
    
    Object m;
    
    Object n;
    
    Object o;
    
    Object p;
    
    Boolean q;
    
    Boolean r;
    
    float s;
    
    View t;
    
    boolean u;
    
    Fragment.g v;
    
    boolean w;
    
    e() {
      Object object = Fragment.o0;
      this.l = object;
      this.m = null;
      this.n = object;
      this.o = null;
      this.p = object;
      this.s = 1.0F;
      this.t = null;
    }
  }
  
  private static abstract class f {
    abstract void a();
  }
  
  static interface g {
    void a();
    
    void b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\Fragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */