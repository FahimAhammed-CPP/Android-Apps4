package androidx.fragment.app;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.view.v;
import androidx.core.view.y;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

class w {
  private static final int[] a = new int[] { 
      0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 
      10 };
  
  static final y b;
  
  static final y c = w();
  
  static void A(ArrayList<View> paramArrayList, int paramInt) {
    if (paramArrayList == null)
      return; 
    for (int i = paramArrayList.size() - 1; i >= 0; i--)
      ((View)paramArrayList.get(i)).setVisibility(paramInt); 
  }
  
  static void B(Context paramContext, g paramg, ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, boolean paramBoolean, g paramg1) {
    SparseArray<h> sparseArray = new SparseArray();
    int i;
    for (i = paramInt1; i < paramInt2; i++) {
      a a = paramArrayList.get(i);
      if (((Boolean)paramArrayList1.get(i)).booleanValue()) {
        e(a, sparseArray, paramBoolean);
      } else {
        c(a, sparseArray, paramBoolean);
      } 
    } 
    if (sparseArray.size() != 0) {
      View view = new View(paramContext);
      int j = sparseArray.size();
      for (i = 0; i < j; i++) {
        int k = sparseArray.keyAt(i);
        o.a<String, String> a = d(k, paramArrayList, paramArrayList1, paramInt1, paramInt2);
        h h = (h)sparseArray.valueAt(i);
        if (paramg.g()) {
          ViewGroup viewGroup = (ViewGroup)paramg.f(k);
          if (viewGroup != null)
            if (paramBoolean) {
              o(viewGroup, h, view, a, paramg1);
            } else {
              n(viewGroup, h, view, a, paramg1);
            }  
        } 
      } 
    } 
  }
  
  private static void a(ArrayList<View> paramArrayList, o.a<String, View> parama, Collection<String> paramCollection) {
    for (int i = parama.size() - 1; i >= 0; i--) {
      View view = (View)parama.m(i);
      if (paramCollection.contains(y.M(view)))
        paramArrayList.add(view); 
    } 
  }
  
  private static void b(a parama, v.a parama1, SparseArray<h> paramSparseArray, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_1
    //   1: getfield b : Landroidx/fragment/app/Fragment;
    //   4: astore #12
    //   6: aload #12
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload #12
    //   14: getfield L : I
    //   17: istore #8
    //   19: iload #8
    //   21: ifne -> 25
    //   24: return
    //   25: iload_3
    //   26: ifeq -> 42
    //   29: getstatic androidx/fragment/app/w.a : [I
    //   32: aload_1
    //   33: getfield a : I
    //   36: iaload
    //   37: istore #5
    //   39: goto -> 48
    //   42: aload_1
    //   43: getfield a : I
    //   46: istore #5
    //   48: iconst_0
    //   49: istore #10
    //   51: iconst_0
    //   52: istore #9
    //   54: iconst_1
    //   55: istore #6
    //   57: iload #5
    //   59: iconst_1
    //   60: if_icmpeq -> 288
    //   63: iload #5
    //   65: iconst_3
    //   66: if_icmpeq -> 200
    //   69: iload #5
    //   71: iconst_4
    //   72: if_icmpeq -> 149
    //   75: iload #5
    //   77: iconst_5
    //   78: if_icmpeq -> 107
    //   81: iload #5
    //   83: bipush #6
    //   85: if_icmpeq -> 200
    //   88: iload #5
    //   90: bipush #7
    //   92: if_icmpeq -> 288
    //   95: iconst_0
    //   96: istore #5
    //   98: iconst_0
    //   99: istore #7
    //   101: iconst_0
    //   102: istore #6
    //   104: goto -> 335
    //   107: iload #4
    //   109: ifeq -> 139
    //   112: aload #12
    //   114: getfield b0 : Z
    //   117: ifeq -> 325
    //   120: aload #12
    //   122: getfield N : Z
    //   125: ifne -> 325
    //   128: aload #12
    //   130: getfield z : Z
    //   133: ifeq -> 325
    //   136: goto -> 319
    //   139: aload #12
    //   141: getfield N : Z
    //   144: istore #9
    //   146: goto -> 328
    //   149: iload #4
    //   151: ifeq -> 181
    //   154: aload #12
    //   156: getfield b0 : Z
    //   159: ifeq -> 246
    //   162: aload #12
    //   164: getfield z : Z
    //   167: ifeq -> 246
    //   170: aload #12
    //   172: getfield N : Z
    //   175: ifeq -> 246
    //   178: goto -> 240
    //   181: aload #12
    //   183: getfield z : Z
    //   186: ifeq -> 246
    //   189: aload #12
    //   191: getfield N : Z
    //   194: ifne -> 246
    //   197: goto -> 178
    //   200: iload #4
    //   202: ifeq -> 252
    //   205: aload #12
    //   207: getfield z : Z
    //   210: ifne -> 246
    //   213: aload #12
    //   215: getfield V : Landroid/view/View;
    //   218: astore_1
    //   219: aload_1
    //   220: ifnull -> 246
    //   223: aload_1
    //   224: invokevirtual getVisibility : ()I
    //   227: ifne -> 246
    //   230: aload #12
    //   232: getfield c0 : F
    //   235: fconst_0
    //   236: fcmpl
    //   237: iflt -> 246
    //   240: iconst_1
    //   241: istore #5
    //   243: goto -> 271
    //   246: iconst_0
    //   247: istore #5
    //   249: goto -> 271
    //   252: aload #12
    //   254: getfield z : Z
    //   257: ifeq -> 246
    //   260: aload #12
    //   262: getfield N : Z
    //   265: ifne -> 246
    //   268: goto -> 240
    //   271: iload #5
    //   273: istore #6
    //   275: iconst_1
    //   276: istore #7
    //   278: iconst_0
    //   279: istore #5
    //   281: iload #10
    //   283: istore #9
    //   285: goto -> 335
    //   288: iload #4
    //   290: ifeq -> 303
    //   293: aload #12
    //   295: getfield a0 : Z
    //   298: istore #9
    //   300: goto -> 328
    //   303: aload #12
    //   305: getfield z : Z
    //   308: ifne -> 325
    //   311: aload #12
    //   313: getfield N : Z
    //   316: ifne -> 325
    //   319: iconst_1
    //   320: istore #9
    //   322: goto -> 328
    //   325: iconst_0
    //   326: istore #9
    //   328: iload #6
    //   330: istore #5
    //   332: goto -> 98
    //   335: aload_2
    //   336: iload #8
    //   338: invokevirtual get : (I)Ljava/lang/Object;
    //   341: checkcast androidx/fragment/app/w$h
    //   344: astore #11
    //   346: aload #11
    //   348: astore_1
    //   349: iload #9
    //   351: ifeq -> 379
    //   354: aload #11
    //   356: aload_2
    //   357: iload #8
    //   359: invokestatic p : (Landroidx/fragment/app/w$h;Landroid/util/SparseArray;I)Landroidx/fragment/app/w$h;
    //   362: astore_1
    //   363: aload_1
    //   364: aload #12
    //   366: putfield a : Landroidx/fragment/app/Fragment;
    //   369: aload_1
    //   370: iload_3
    //   371: putfield b : Z
    //   374: aload_1
    //   375: aload_0
    //   376: putfield c : Landroidx/fragment/app/a;
    //   379: iload #4
    //   381: ifne -> 446
    //   384: iload #5
    //   386: ifeq -> 446
    //   389: aload_1
    //   390: ifnull -> 407
    //   393: aload_1
    //   394: getfield d : Landroidx/fragment/app/Fragment;
    //   397: aload #12
    //   399: if_acmpne -> 407
    //   402: aload_1
    //   403: aconst_null
    //   404: putfield d : Landroidx/fragment/app/Fragment;
    //   407: aload_0
    //   408: getfield r : Z
    //   411: ifne -> 446
    //   414: aload_0
    //   415: getfield t : Landroidx/fragment/app/m;
    //   418: astore #11
    //   420: aload #11
    //   422: aload #12
    //   424: invokevirtual v : (Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/t;
    //   427: astore #13
    //   429: aload #11
    //   431: invokevirtual q0 : ()Landroidx/fragment/app/u;
    //   434: aload #13
    //   436: invokevirtual p : (Landroidx/fragment/app/t;)V
    //   439: aload #11
    //   441: aload #12
    //   443: invokevirtual O0 : (Landroidx/fragment/app/Fragment;)V
    //   446: aload_1
    //   447: astore #11
    //   449: iload #6
    //   451: ifeq -> 496
    //   454: aload_1
    //   455: ifnull -> 468
    //   458: aload_1
    //   459: astore #11
    //   461: aload_1
    //   462: getfield d : Landroidx/fragment/app/Fragment;
    //   465: ifnonnull -> 496
    //   468: aload_1
    //   469: aload_2
    //   470: iload #8
    //   472: invokestatic p : (Landroidx/fragment/app/w$h;Landroid/util/SparseArray;I)Landroidx/fragment/app/w$h;
    //   475: astore #11
    //   477: aload #11
    //   479: aload #12
    //   481: putfield d : Landroidx/fragment/app/Fragment;
    //   484: aload #11
    //   486: iload_3
    //   487: putfield e : Z
    //   490: aload #11
    //   492: aload_0
    //   493: putfield f : Landroidx/fragment/app/a;
    //   496: iload #4
    //   498: ifne -> 527
    //   501: iload #7
    //   503: ifeq -> 527
    //   506: aload #11
    //   508: ifnull -> 527
    //   511: aload #11
    //   513: getfield a : Landroidx/fragment/app/Fragment;
    //   516: aload #12
    //   518: if_acmpne -> 527
    //   521: aload #11
    //   523: aconst_null
    //   524: putfield a : Landroidx/fragment/app/Fragment;
    //   527: return
  }
  
  public static void c(a parama, SparseArray<h> paramSparseArray, boolean paramBoolean) {
    int j = parama.c.size();
    for (int i = 0; i < j; i++)
      b(parama, parama.c.get(i), paramSparseArray, false, paramBoolean); 
  }
  
  private static o.a<String, String> d(int paramInt1, ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt2, int paramInt3) {
    o.a<String, String> a = new o.a();
    while (--paramInt3 >= paramInt2) {
      a a1 = paramArrayList.get(paramInt3);
      if (a1.A(paramInt1)) {
        boolean bool = ((Boolean)paramArrayList1.get(paramInt3)).booleanValue();
        ArrayList<String> arrayList = a1.p;
        if (arrayList != null) {
          ArrayList<String> arrayList1;
          int j = arrayList.size();
          if (bool) {
            arrayList1 = a1.p;
            arrayList = a1.q;
          } else {
            arrayList = a1.p;
            arrayList1 = a1.q;
          } 
          int i;
          for (i = 0; i < j; i++) {
            String str1 = arrayList.get(i);
            String str2 = arrayList1.get(i);
            String str3 = (String)a.remove(str2);
            if (str3 != null) {
              a.put(str1, str3);
            } else {
              a.put(str1, str2);
            } 
          } 
        } 
      } 
      paramInt3--;
    } 
    return a;
  }
  
  public static void e(a parama, SparseArray<h> paramSparseArray, boolean paramBoolean) {
    if (!parama.t.n0().g())
      return; 
    for (int i = parama.c.size() - 1; i >= 0; i--)
      b(parama, parama.c.get(i), paramSparseArray, true, paramBoolean); 
  }
  
  static void f(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean1, o.a<String, View> parama, boolean paramBoolean2) {
    if (paramBoolean1) {
      paramFragment2.x();
      return;
    } 
    paramFragment1.x();
  }
  
  private static boolean g(y paramy, List<Object> paramList) {
    int j = paramList.size();
    for (int i = 0; i < j; i++) {
      if (!paramy.e(paramList.get(i)))
        return false; 
    } 
    return true;
  }
  
  static o.a<String, View> h(y paramy, o.a<String, String> parama, Object paramObject, h paramh) {
    ArrayList<String> arrayList;
    Fragment fragment = paramh.a;
    View view = fragment.V();
    if (parama.isEmpty() || paramObject == null || view == null) {
      parama.clear();
      return null;
    } 
    paramObject = new o.a();
    paramy.j((Map<String, View>)paramObject, view);
    a a1 = paramh.c;
    if (paramh.b) {
      fragment.A();
      arrayList = a1.p;
    } else {
      fragment.x();
      arrayList = ((v)arrayList).q;
    } 
    if (arrayList != null) {
      paramObject.o(arrayList);
      paramObject.o(parama.values());
    } 
    x(parama, (o.a<String, View>)paramObject);
    return (o.a<String, View>)paramObject;
  }
  
  private static o.a<String, View> i(y paramy, o.a<String, String> parama, Object paramObject, h paramh) {
    ArrayList<String> arrayList;
    if (parama.isEmpty() || paramObject == null) {
      parama.clear();
      return null;
    } 
    Fragment fragment = paramh.d;
    paramObject = new o.a();
    paramy.j((Map<String, View>)paramObject, fragment.s1());
    a a1 = paramh.f;
    if (paramh.e) {
      fragment.x();
      arrayList = a1.q;
    } else {
      fragment.A();
      arrayList = ((v)arrayList).p;
    } 
    if (arrayList != null)
      paramObject.o(arrayList); 
    parama.o(paramObject.keySet());
    return (o.a<String, View>)paramObject;
  }
  
  private static y j(Fragment paramFragment1, Fragment paramFragment2) {
    ArrayList<Object> arrayList = new ArrayList();
    if (paramFragment1 != null) {
      Object object2 = paramFragment1.z();
      if (object2 != null)
        arrayList.add(object2); 
      object2 = paramFragment1.O();
      if (object2 != null)
        arrayList.add(object2); 
      Object object1 = paramFragment1.Q();
      if (object1 != null)
        arrayList.add(object1); 
    } 
    if (paramFragment2 != null) {
      Object object = paramFragment2.w();
      if (object != null)
        arrayList.add(object); 
      object = paramFragment2.M();
      if (object != null)
        arrayList.add(object); 
      object = paramFragment2.P();
      if (object != null)
        arrayList.add(object); 
    } 
    if (arrayList.isEmpty())
      return null; 
    y y1 = b;
    if (y1 != null && g(y1, arrayList))
      return y1; 
    y y2 = c;
    if (y2 != null && g(y2, arrayList))
      return y2; 
    if (y1 == null && y2 == null)
      return null; 
    throw new IllegalArgumentException("Invalid Transition types");
  }
  
  static ArrayList<View> k(y paramy, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList, View paramView) {
    if (paramObject != null) {
      ArrayList<View> arrayList2 = new ArrayList();
      View view = paramFragment.V();
      if (view != null)
        paramy.f(arrayList2, view); 
      if (paramArrayList != null)
        arrayList2.removeAll(paramArrayList); 
      ArrayList<View> arrayList1 = arrayList2;
      if (!arrayList2.isEmpty()) {
        arrayList2.add(paramView);
        paramy.b(paramObject, arrayList2);
        return arrayList2;
      } 
    } else {
      paramFragment = null;
    } 
    return (ArrayList<View>)paramFragment;
  }
  
  private static Object l(y paramy, ViewGroup paramViewGroup, View paramView, o.a<String, String> parama, h paramh, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2) {
    Fragment fragment1 = paramh.a;
    Fragment fragment2 = paramh.d;
    if (fragment1 != null) {
      Object object;
      if (fragment2 == null)
        return null; 
      boolean bool = paramh.b;
      if (parama.isEmpty()) {
        object = null;
      } else {
        object = t(paramy, fragment1, fragment2, bool);
      } 
      o.a<String, View> a1 = i(paramy, parama, object, paramh);
      if (parama.isEmpty()) {
        object = null;
      } else {
        paramArrayList1.addAll(a1.values());
      } 
      if (paramObject1 == null && paramObject2 == null && object == null)
        return null; 
      f(fragment1, fragment2, bool, a1, true);
      if (object != null) {
        Rect rect = new Rect();
        paramy.z(object, paramView, paramArrayList1);
        z(paramy, object, paramObject2, a1, paramh.e, paramh.f);
        paramObject2 = rect;
        if (paramObject1 != null) {
          paramy.u(paramObject1, rect);
          paramObject2 = rect;
        } 
      } else {
        paramObject2 = null;
      } 
      v.a((View)paramViewGroup, new f(paramy, parama, object, paramh, paramArrayList2, paramView, fragment1, fragment2, bool, paramArrayList1, paramObject1, (Rect)paramObject2));
      return object;
    } 
    return null;
  }
  
  private static Object m(y paramy, ViewGroup paramViewGroup, View paramView, o.a<String, String> parama, h paramh, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2) {
    Fragment fragment1 = paramh.a;
    Fragment fragment2 = paramh.d;
    if (fragment1 != null)
      fragment1.s1().setVisibility(0); 
    if (fragment1 != null) {
      Object object1;
      View view1;
      View view2;
      Object object2;
      if (fragment2 == null)
        return null; 
      boolean bool = paramh.b;
      if (parama.isEmpty()) {
        object2 = null;
      } else {
        object2 = t(paramy, fragment1, fragment2, bool);
      } 
      o.a<String, View> a2 = i(paramy, parama, object2, paramh);
      o.a<String, View> a1 = h(paramy, parama, object2, paramh);
      if (parama.isEmpty()) {
        if (a2 != null)
          a2.clear(); 
        if (a1 != null)
          a1.clear(); 
        parama = null;
      } else {
        a(paramArrayList1, a2, parama.keySet());
        a(paramArrayList2, a1, parama.values());
        object1 = object2;
      } 
      if (paramObject1 == null && paramObject2 == null && object1 == null)
        return null; 
      f(fragment1, fragment2, bool, a2, true);
      if (object1 != null) {
        paramArrayList2.add(paramView);
        paramy.z(object1, paramView, paramArrayList1);
        z(paramy, object1, paramObject2, a2, paramh.e, paramh.f);
        Rect rect1 = new Rect();
        view1 = s(a1, paramh, paramObject1, bool);
        if (view1 != null)
          paramy.u(paramObject1, rect1); 
        Rect rect2 = rect1;
      } else {
        paramView = null;
        view2 = paramView;
        view1 = paramView;
      } 
      v.a((View)paramViewGroup, new e(fragment1, fragment2, bool, a1, view1, paramy, (Rect)view2));
      return object1;
    } 
    return null;
  }
  
  private static void n(ViewGroup paramViewGroup, h paramh, View paramView, o.a<String, String> parama, g paramg) {
    Fragment fragment1 = paramh.a;
    Fragment fragment2 = paramh.d;
    y y1 = j(fragment2, fragment1);
    if (y1 == null)
      return; 
    boolean bool1 = paramh.b;
    boolean bool2 = paramh.e;
    Object object3 = q(y1, fragment1, bool1);
    Object object2 = r(y1, fragment2, bool2);
    ArrayList<View> arrayList3 = new ArrayList();
    ArrayList<View> arrayList1 = new ArrayList();
    Object object4 = l(y1, paramViewGroup, paramView, parama, paramh, arrayList3, arrayList1, object3, object2);
    if (object3 == null && object4 == null && object2 == null)
      return; 
    ArrayList<View> arrayList2 = k(y1, object2, fragment2, arrayList3, paramView);
    if (arrayList2 == null || arrayList2.isEmpty())
      object2 = null; 
    y1.a(object3, paramView);
    Object object1 = u(y1, object3, object2, object4, fragment1, paramh.b);
    if (fragment2 != null && arrayList2 != null && (arrayList2.size() > 0 || arrayList3.size() > 0)) {
      androidx.core.os.e e = new androidx.core.os.e();
      paramg.b(fragment2, e);
      y1.w(fragment2, object1, e, new c(paramg, fragment2, e));
    } 
    if (object1 != null) {
      ArrayList<View> arrayList = new ArrayList();
      y1.t(object1, object3, arrayList, object2, arrayList2, object4, arrayList1);
      y(y1, paramViewGroup, fragment1, paramView, arrayList1, object3, arrayList, object2, arrayList2);
      y1.x((View)paramViewGroup, arrayList1, (Map<String, String>)parama);
      y1.c(paramViewGroup, object1);
      y1.s(paramViewGroup, arrayList1, (Map<String, String>)parama);
    } 
  }
  
  private static void o(ViewGroup paramViewGroup, h paramh, View paramView, o.a<String, String> parama, g paramg) {
    Fragment fragment2 = paramh.a;
    Fragment fragment1 = paramh.d;
    y y1 = j(fragment1, fragment2);
    if (y1 == null)
      return; 
    boolean bool1 = paramh.b;
    boolean bool2 = paramh.e;
    ArrayList<View> arrayList2 = new ArrayList();
    ArrayList<View> arrayList3 = new ArrayList();
    Object object3 = q(y1, fragment2, bool1);
    Object<View> object2 = (Object<View>)r(y1, fragment1, bool2);
    Object object4 = m(y1, paramViewGroup, paramView, parama, paramh, arrayList3, arrayList2, object3, object2);
    if (object3 == null && object4 == null && object2 == null)
      return; 
    Object<View> object1 = object2;
    object2 = (Object<View>)k(y1, object1, fragment1, arrayList3, paramView);
    ArrayList<View> arrayList1 = k(y1, object3, fragment2, arrayList2, paramView);
    A(arrayList1, 4);
    Object object5 = u(y1, object3, object1, object4, fragment2, bool1);
    if (fragment1 != null && object2 != null && (object2.size() > 0 || arrayList3.size() > 0)) {
      androidx.core.os.e e = new androidx.core.os.e();
      paramg.b(fragment1, e);
      y1.w(fragment1, object5, e, new a(paramg, fragment1, e));
    } 
    if (object5 != null) {
      v(y1, object1, fragment1, (ArrayList<View>)object2);
      ArrayList<String> arrayList = y1.o(arrayList2);
      y1.t(object5, object3, arrayList1, object1, (ArrayList<View>)object2, object4, arrayList2);
      y1.c(paramViewGroup, object5);
      y1.y((View)paramViewGroup, arrayList3, arrayList2, arrayList, (Map<String, String>)parama);
      A(arrayList1, 0);
      y1.A(object4, arrayList3, arrayList2);
    } 
  }
  
  private static h p(h paramh, SparseArray<h> paramSparseArray, int paramInt) {
    h h1 = paramh;
    if (paramh == null) {
      h1 = new h();
      paramSparseArray.put(paramInt, h1);
    } 
    return h1;
  }
  
  private static Object q(y paramy, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.M();
    } else {
      object = object.w();
    } 
    return paramy.g(object);
  }
  
  private static Object r(y paramy, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.O();
    } else {
      object = object.z();
    } 
    return paramy.g(object);
  }
  
  static View s(o.a<String, View> parama, h paramh, Object<String> paramObject, boolean paramBoolean) {
    a a1 = paramh.c;
    if (paramObject != null && parama != null) {
      paramObject = (Object<String>)a1.p;
      if (paramObject != null && !paramObject.isEmpty()) {
        String str;
        if (paramBoolean) {
          str = a1.p.get(0);
        } else {
          str = ((v)str).q.get(0);
        } 
        return (View)parama.get(str);
      } 
    } 
    return null;
  }
  
  private static Object t(y paramy, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean) {
    Object object;
    if (paramFragment1 == null || paramFragment2 == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment2.Q();
    } else {
      object = object.P();
    } 
    return paramy.B(paramy.g(object));
  }
  
  private static Object u(y paramy, Object paramObject1, Object paramObject2, Object paramObject3, Fragment paramFragment, boolean paramBoolean) {
    if (paramObject1 != null && paramObject2 != null && paramFragment != null) {
      if (paramBoolean) {
        paramBoolean = paramFragment.p();
      } else {
        paramBoolean = paramFragment.o();
      } 
    } else {
      paramBoolean = true;
    } 
    return paramBoolean ? paramy.n(paramObject2, paramObject1, paramObject3) : paramy.m(paramObject2, paramObject1, paramObject3);
  }
  
  private static void v(y paramy, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList) {
    if (paramFragment != null && paramObject != null && paramFragment.z && paramFragment.N && paramFragment.b0) {
      paramFragment.B1(true);
      paramy.r(paramObject, paramFragment.V(), paramArrayList);
      v.a((View)paramFragment.U, new b(paramArrayList));
    } 
  }
  
  private static y w() {
    try {
      return v0.e.class.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  static void x(o.a<String, String> parama, o.a<String, View> parama1) {
    for (int i = parama.size() - 1; i >= 0; i--) {
      if (!parama1.containsKey(parama.m(i)))
        parama.k(i); 
    } 
  }
  
  private static void y(y paramy, ViewGroup paramViewGroup, Fragment paramFragment, View paramView, ArrayList<View> paramArrayList1, Object paramObject1, ArrayList<View> paramArrayList2, Object paramObject2, ArrayList<View> paramArrayList3) {
    v.a((View)paramViewGroup, new d(paramObject1, paramy, paramView, paramFragment, paramArrayList1, paramArrayList2, paramArrayList3, paramObject2));
  }
  
  private static void z(y paramy, Object paramObject1, Object paramObject2, o.a<String, View> parama, boolean paramBoolean, a parama1) {
    ArrayList<String> arrayList = parama1.p;
    if (arrayList != null && !arrayList.isEmpty()) {
      String str;
      if (paramBoolean) {
        str = parama1.q.get(0);
      } else {
        str = ((v)str).p.get(0);
      } 
      View view = (View)parama.get(str);
      paramy.v(paramObject1, view);
      if (paramObject2 != null)
        paramy.v(paramObject2, view); 
    } 
  }
  
  static {
    y y1;
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 21) {
      y1 = new x();
    } else {
      y1 = null;
    } 
    b = y1;
  }
  
  class a implements Runnable {
    a(w this$0, Fragment param1Fragment, androidx.core.os.e param1e) {}
    
    public void run() {
      this.o.a(this.p, this.q);
    }
  }
  
  class b implements Runnable {
    b(w this$0) {}
    
    public void run() {
      w.A(this.o, 4);
    }
  }
  
  class c implements Runnable {
    c(w this$0, Fragment param1Fragment, androidx.core.os.e param1e) {}
    
    public void run() {
      this.o.a(this.p, this.q);
    }
  }
  
  class d implements Runnable {
    d(w this$0, y param1y, View param1View, Fragment param1Fragment, ArrayList param1ArrayList1, ArrayList param1ArrayList2, ArrayList param1ArrayList3, Object param1Object1) {}
    
    public void run() {
      Object<View> object = (Object<View>)this.o;
      if (object != null) {
        this.p.p(object, this.q);
        object = (Object<View>)w.k(this.p, this.o, this.r, this.s, this.q);
        this.t.addAll((Collection<? extends View>)object);
      } 
      if (this.u != null) {
        if (this.v != null) {
          object = (Object<View>)new ArrayList();
          object.add(this.q);
          this.p.q(this.v, this.u, (ArrayList<View>)object);
        } 
        this.u.clear();
        this.u.add(this.q);
      } 
    }
  }
  
  class e implements Runnable {
    e(w this$0, Fragment param1Fragment1, boolean param1Boolean, o.a param1a, View param1View, y param1y, Rect param1Rect) {}
    
    public void run() {
      w.f(this.o, this.p, this.q, this.r, false);
      View view = this.s;
      if (view != null)
        this.t.k(view, this.u); 
    }
  }
  
  class f implements Runnable {
    f(w this$0, o.a param1a, Object param1Object1, w.h param1h, ArrayList param1ArrayList1, View param1View, Fragment param1Fragment1, Fragment param1Fragment2, boolean param1Boolean, ArrayList param1ArrayList2, Object param1Object2, Rect param1Rect) {}
    
    public void run() {
      o.a<String, View> a1 = w.h(this.o, this.p, this.q, this.r);
      if (a1 != null) {
        this.s.addAll(a1.values());
        this.s.add(this.t);
      } 
      w.f(this.u, this.v, this.w, a1, false);
      Object object = this.q;
      if (object != null) {
        this.o.A(object, this.x, this.s);
        View view = w.s(a1, this.r, this.y, this.w);
        if (view != null)
          this.o.k(view, this.z); 
      } 
    }
  }
  
  static interface g {
    void a(Fragment param1Fragment, androidx.core.os.e param1e);
    
    void b(Fragment param1Fragment, androidx.core.os.e param1e);
  }
  
  static class h {
    public Fragment a;
    
    public boolean b;
    
    public a c;
    
    public Fragment d;
    
    public boolean e;
    
    public a f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */