package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import androidx.core.content.a;
import androidx.core.util.h;

public abstract class j<E> extends g {
  private final Activity o;
  
  private final Context p;
  
  private final Handler q;
  
  private final int r;
  
  final m s = new n();
  
  j(Activity paramActivity, Context paramContext, Handler paramHandler, int paramInt) {
    this.o = paramActivity;
    this.p = (Context)h.g(paramContext, "context == null");
    this.q = (Handler)h.g(paramHandler, "handler == null");
    this.r = paramInt;
  }
  
  j(e parame) {
    this((Activity)parame, (Context)parame, new Handler(), 0);
  }
  
  public View f(int paramInt) {
    return null;
  }
  
  public boolean g() {
    return true;
  }
  
  Activity h() {
    return this.o;
  }
  
  Context j() {
    return this.p;
  }
  
  Handler l() {
    return this.q;
  }
  
  public abstract E m();
  
  public LayoutInflater n() {
    return LayoutInflater.from(this.p);
  }
  
  public boolean o(Fragment paramFragment) {
    return true;
  }
  
  public void p(Fragment paramFragment, @SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (paramInt == -1) {
      a.g(this.p, paramIntent, paramBundle);
      return;
    } 
    throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
  }
  
  public void q() {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */