package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import androidx.core.view.j0;
import androidx.core.view.y;
import f0.c;
import java.util.ArrayList;

public final class FragmentContainerView extends FrameLayout {
  private ArrayList<View> o;
  
  private ArrayList<View> p;
  
  private View.OnApplyWindowInsetsListener q;
  
  private boolean r = true;
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    if (paramAttributeSet != null) {
      String str1;
      String str2;
      String str3 = paramAttributeSet.getClassAttribute();
      TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c.h);
      if (str3 == null) {
        str2 = typedArray.getString(c.i);
        str1 = "android:name";
      } else {
        str1 = "class";
        str2 = str3;
      } 
      typedArray.recycle();
      if (str2 != null) {
        if (isInEditMode())
          return; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentContainerView must be within a FragmentActivity to use ");
        stringBuilder.append(str1);
        stringBuilder.append("=\"");
        stringBuilder.append(str2);
        stringBuilder.append("\"");
        throw new UnsupportedOperationException(stringBuilder.toString());
      } 
    } 
  }
  
  FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet, m paramm) {
    super(paramContext, paramAttributeSet);
    String str2 = paramAttributeSet.getClassAttribute();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c.h);
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(c.i); 
    str2 = typedArray.getString(c.j);
    typedArray.recycle();
    int i = getId();
    Fragment fragment = paramm.g0(i);
    if (str1 != null && fragment == null) {
      String str;
      StringBuilder stringBuilder;
      if (i <= 0) {
        if (str2 != null) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" with tag ");
          stringBuilder1.append(str2);
          str = stringBuilder1.toString();
        } else {
          str = "";
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentContainerView must have an android:id to add Fragment ");
        stringBuilder.append(str1);
        stringBuilder.append(str);
        throw new IllegalStateException(stringBuilder.toString());
      } 
      Fragment fragment1 = paramm.p0().a(str.getClassLoader(), str1);
      fragment1.D0((Context)str, (AttributeSet)stringBuilder, null);
      paramm.l().r(true).c((ViewGroup)this, fragment1, str2).j();
    } 
    paramm.R0(this);
  }
  
  private void a(View paramView) {
    ArrayList<View> arrayList = this.p;
    if (arrayList != null && arrayList.contains(paramView)) {
      if (this.o == null)
        this.o = new ArrayList<View>(); 
      this.o.add(paramView);
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (m.y0(paramView) != null) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected boolean addViewInLayout(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    if (m.y0(paramView) != null)
      return super.addViewInLayout(paramView, paramInt, paramLayoutParams, paramBoolean); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public WindowInsets dispatchApplyWindowInsets(WindowInsets paramWindowInsets) {
    j0 j0 = j0.u(paramWindowInsets);
    View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.q;
    if (onApplyWindowInsetsListener != null) {
      j0 = j0.u(onApplyWindowInsetsListener.onApplyWindowInsets((View)this, paramWindowInsets));
    } else {
      j0 = y.d0((View)this, j0);
    } 
    if (!j0.n()) {
      int j = getChildCount();
      for (int i = 0; i < j; i++)
        y.i(getChildAt(i), j0); 
    } 
    return paramWindowInsets;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    if (this.r && this.o != null)
      for (int i = 0; i < this.o.size(); i++)
        super.drawChild(paramCanvas, this.o.get(i), getDrawingTime());  
    super.dispatchDraw(paramCanvas);
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    if (this.r) {
      ArrayList<View> arrayList = this.o;
      if (arrayList != null && arrayList.size() > 0 && this.o.contains(paramView))
        return false; 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void endViewTransition(View paramView) {
    ArrayList<View> arrayList = this.p;
    if (arrayList != null) {
      arrayList.remove(paramView);
      arrayList = this.o;
      if (arrayList != null && arrayList.remove(paramView))
        this.r = true; 
    } 
    super.endViewTransition(paramView);
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    return paramWindowInsets;
  }
  
  public void removeAllViewsInLayout() {
    for (int i = getChildCount() - 1; i >= 0; i--)
      a(getChildAt(i)); 
    super.removeAllViewsInLayout();
  }
  
  protected void removeDetachedView(View paramView, boolean paramBoolean) {
    if (paramBoolean)
      a(paramView); 
    super.removeDetachedView(paramView, paramBoolean);
  }
  
  public void removeView(View paramView) {
    a(paramView);
    super.removeView(paramView);
  }
  
  public void removeViewAt(int paramInt) {
    a(getChildAt(paramInt));
    super.removeViewAt(paramInt);
  }
  
  public void removeViewInLayout(View paramView) {
    a(paramView);
    super.removeViewInLayout(paramView);
  }
  
  public void removeViews(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViews(paramInt1, paramInt2);
  }
  
  public void removeViewsInLayout(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViewsInLayout(paramInt1, paramInt2);
  }
  
  void setDrawDisappearingViewsLast(boolean paramBoolean) {
    this.r = paramBoolean;
  }
  
  public void setLayoutTransition(LayoutTransition paramLayoutTransition) {
    throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
  }
  
  public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener) {
    this.q = paramOnApplyWindowInsetsListener;
  }
  
  public void startViewTransition(View paramView) {
    if (paramView.getParent() == this) {
      if (this.p == null)
        this.p = new ArrayList<View>(); 
      this.p.add(paramView);
    } 
    super.startViewTransition(paramView);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\FragmentContainerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */