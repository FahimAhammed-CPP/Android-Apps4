package androidx.fragment.app;

import android.util.Log;
import java.io.Writer;

final class a0 extends Writer {
  private final String o;
  
  private StringBuilder p = new StringBuilder(128);
  
  a0(String paramString) {
    this.o = paramString;
  }
  
  private void c() {
    if (this.p.length() > 0) {
      Log.d(this.o, this.p.toString());
      StringBuilder stringBuilder = this.p;
      stringBuilder.delete(0, stringBuilder.length());
    } 
  }
  
  public void close() {
    c();
  }
  
  public void flush() {
    c();
  }
  
  public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    int i;
    for (i = 0; i < paramInt2; i++) {
      char c = paramArrayOfchar[paramInt1 + i];
      if (c == '\n') {
        c();
      } else {
        this.p.append(c);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */