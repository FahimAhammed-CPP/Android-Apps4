package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class g {
  @Deprecated
  public Fragment e(Context paramContext, String paramString, Bundle paramBundle) {
    return Fragment.Z(paramContext, paramString, paramBundle);
  }
  
  public abstract View f(int paramInt);
  
  public abstract boolean g();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */