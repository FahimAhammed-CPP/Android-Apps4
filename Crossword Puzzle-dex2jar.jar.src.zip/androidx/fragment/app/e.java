package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.h;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.d;
import androidx.core.app.b;
import androidx.lifecycle.h0;
import androidx.lifecycle.i;
import androidx.lifecycle.i0;
import androidx.lifecycle.m;
import androidx.lifecycle.n;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class e extends ComponentActivity implements b.d, b.f {
  final h E = h.b(new c(this));
  
  final n F = new n((m)this);
  
  boolean G;
  
  boolean H;
  
  boolean I = true;
  
  public e() {
    B();
  }
  
  private void B() {
    d().h("android:support:fragments", new a(this));
    p(new b(this));
  }
  
  private static boolean D(m paramm, i.c paramc) {
    Iterator<Fragment> iterator = paramm.r0().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment == null)
        continue; 
      boolean bool1 = bool;
      if (fragment.C() != null)
        bool1 = bool | D(fragment.t(), paramc); 
      z z = fragment.h0;
      bool = bool1;
      if (z != null) {
        bool = bool1;
        if (z.a().b().c(i.c.r)) {
          fragment.h0.j(paramc);
          bool = true;
        } 
      } 
      if (fragment.g0.b().c(i.c.r)) {
        fragment.g0.o(paramc);
        bool = true;
      } 
    } 
    return bool;
  }
  
  @Deprecated
  public androidx.loader.app.a A() {
    return androidx.loader.app.a.b((m)this);
  }
  
  void C() {
    do {
    
    } while (D(z(), i.c.q));
  }
  
  @Deprecated
  public void E(Fragment paramFragment) {}
  
  @Deprecated
  protected boolean F(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  protected void G() {
    this.F.h(i.b.ON_RESUME);
    this.E.p();
  }
  
  @Deprecated
  public void H() {
    invalidateOptionsMenu();
  }
  
  @Deprecated
  public final void b(int paramInt) {}
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.G);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.H);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.I);
    if (getApplication() != null)
      androidx.loader.app.a.b((m)this).a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.E.t().W(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    this.E.u();
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.E.u();
    super.onConfigurationChanged(paramConfiguration);
    this.E.d(paramConfiguration);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.F.h(i.b.ON_CREATE);
    this.E.f();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return (paramInt == 0) ? (super.onCreatePanelMenu(paramInt, paramMenu) | this.E.g(paramMenu, getMenuInflater())) : super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = y(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = y(null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  protected void onDestroy() {
    super.onDestroy();
    this.E.h();
    this.F.h(i.b.ON_DESTROY);
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.E.i();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.E.e(paramMenuItem)) : this.E.k(paramMenuItem));
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    this.E.j(paramBoolean);
  }
  
  protected void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent paramIntent) {
    this.E.u();
    super.onNewIntent(paramIntent);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.E.l(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPause() {
    super.onPause();
    this.H = false;
    this.E.m();
    this.F.h(i.b.ON_PAUSE);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    this.E.n(paramBoolean);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    G();
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0) ? (F(paramView, paramMenu) | this.E.o(paramMenu)) : super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.E.u();
    super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint);
  }
  
  protected void onResume() {
    this.E.u();
    super.onResume();
    this.H = true;
    this.E.s();
  }
  
  protected void onStart() {
    this.E.u();
    super.onStart();
    this.I = false;
    if (!this.G) {
      this.G = true;
      this.E.c();
    } 
    this.E.s();
    this.F.h(i.b.ON_START);
    this.E.q();
  }
  
  public void onStateNotSaved() {
    this.E.u();
  }
  
  protected void onStop() {
    super.onStop();
    this.I = true;
    C();
    this.E.r();
    this.F.h(i.b.ON_STOP);
  }
  
  final View y(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.E.v(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public m z() {
    return this.E.t();
  }
  
  class a implements q0.c.c {
    a(e this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.C();
      this.a.F.h(i.b.ON_STOP);
      Parcelable parcelable = this.a.E.x();
      if (parcelable != null)
        bundle.putParcelable("android:support:fragments", parcelable); 
      return bundle;
    }
  }
  
  class b implements c.b {
    b(e this$0) {}
    
    public void a(Context param1Context) {
      this.a.E.a(null);
      Bundle bundle = this.a.d().b("android:support:fragments");
      if (bundle != null) {
        Parcelable parcelable = bundle.getParcelable("android:support:fragments");
        this.a.E.w(parcelable);
      } 
    }
  }
  
  class c extends j<e> implements i0, h, d, q {
    public c(e this$0) {
      super(this$0);
    }
    
    public i a() {
      return (i)this.t.F;
    }
    
    public void b(m param1m, Fragment param1Fragment) {
      this.t.E(param1Fragment);
    }
    
    public OnBackPressedDispatcher c() {
      return this.t.c();
    }
    
    public View f(int param1Int) {
      return this.t.findViewById(param1Int);
    }
    
    public boolean g() {
      Window window = this.t.getWindow();
      return (window != null && window.peekDecorView() != null);
    }
    
    public ActivityResultRegistry i() {
      return this.t.i();
    }
    
    public h0 k() {
      return this.t.k();
    }
    
    public LayoutInflater n() {
      return this.t.getLayoutInflater().cloneInContext((Context)this.t);
    }
    
    public boolean o(Fragment param1Fragment) {
      return this.t.isFinishing() ^ true;
    }
    
    public void q() {
      this.t.H();
    }
    
    public e r() {
      return this.t;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */