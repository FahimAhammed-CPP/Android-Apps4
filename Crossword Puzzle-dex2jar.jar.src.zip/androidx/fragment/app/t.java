package androidx.fragment.app;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.core.view.y;
import androidx.lifecycle.i;

class t {
  private final l a;
  
  private final u b;
  
  private final Fragment c;
  
  private boolean d = false;
  
  private int e = -1;
  
  t(l paraml, u paramu, Fragment paramFragment) {
    this.a = paraml;
    this.b = paramu;
    this.c = paramFragment;
  }
  
  t(l paraml, u paramu, Fragment paramFragment, s params) {
    this.a = paraml;
    this.b = paramu;
    this.c = paramFragment;
    paramFragment.q = null;
    paramFragment.r = null;
    paramFragment.F = 0;
    paramFragment.C = false;
    paramFragment.z = false;
    Fragment fragment = paramFragment.v;
    if (fragment != null) {
      String str = fragment.t;
    } else {
      fragment = null;
    } 
    paramFragment.w = (String)fragment;
    paramFragment.v = null;
    Bundle bundle = params.A;
    if (bundle != null) {
      paramFragment.p = bundle;
      return;
    } 
    paramFragment.p = new Bundle();
  }
  
  t(l paraml, u paramu, ClassLoader paramClassLoader, i parami, s params) {
    this.a = paraml;
    this.b = paramu;
    Fragment fragment = parami.a(paramClassLoader, params.o);
    this.c = fragment;
    Bundle bundle = params.x;
    if (bundle != null)
      bundle.setClassLoader(paramClassLoader); 
    fragment.z1(params.x);
    fragment.t = params.p;
    fragment.B = params.q;
    fragment.D = true;
    fragment.K = params.r;
    fragment.L = params.s;
    fragment.M = params.t;
    fragment.P = params.u;
    fragment.A = params.v;
    fragment.O = params.w;
    fragment.N = params.y;
    fragment.f0 = i.c.values()[params.z];
    bundle = params.A;
    if (bundle != null) {
      fragment.p = bundle;
    } else {
      fragment.p = new Bundle();
    } 
    if (m.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Instantiated fragment ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  private boolean l(View paramView) {
    if (paramView == this.c.V)
      return true; 
    for (ViewParent viewParent = paramView.getParent(); viewParent != null; viewParent = viewParent.getParent()) {
      if (viewParent == this.c.V)
        return true; 
    } 
    return false;
  }
  
  private Bundle q() {
    Bundle bundle2 = new Bundle();
    this.c.m1(bundle2);
    this.a.j(this.c, bundle2, false);
    Bundle bundle1 = bundle2;
    if (bundle2.isEmpty())
      bundle1 = null; 
    if (this.c.V != null)
      s(); 
    bundle2 = bundle1;
    if (this.c.q != null) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putSparseParcelableArray("android:view_state", this.c.q);
    } 
    bundle1 = bundle2;
    if (this.c.r != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putBundle("android:view_registry_state", this.c.r);
    } 
    bundle2 = bundle1;
    if (!this.c.X) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", this.c.X);
    } 
    return bundle2;
  }
  
  void a() {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto ACTIVITY_CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment1 = this.c;
    fragment1.S0(fragment1.p);
    l l1 = this.a;
    Fragment fragment2 = this.c;
    l1.a(fragment2, fragment2.p, false);
  }
  
  void b() {
    int i = this.b.j(this.c);
    Fragment fragment = this.c;
    fragment.U.addView(fragment.V, i);
  }
  
  void c() {
    StringBuilder stringBuilder;
    if (m.E0(3)) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("moveto ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    Fragment fragment3 = fragment2.v;
    t t1 = null;
    if (fragment3 != null) {
      t1 = this.b.m(fragment3.t);
      if (t1 != null) {
        fragment2 = this.c;
        fragment2.w = fragment2.v.t;
        fragment2.v = null;
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" declared target fragment ");
        stringBuilder.append(this.c.v);
        stringBuilder.append(" that does not belong to this FragmentManager!");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } else {
      String str = fragment2.w;
      if (str != null) {
        t1 = this.b.m(str);
        if (t1 == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" declared target fragment ");
          stringBuilder.append(this.c.w);
          stringBuilder.append(" that does not belong to this FragmentManager!");
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
    } 
    if (stringBuilder != null && (m.P || (stringBuilder.k()).o < 1))
      stringBuilder.m(); 
    Fragment fragment1 = this.c;
    fragment1.H = fragment1.G.s0();
    fragment1 = this.c;
    fragment1.J = fragment1.G.v0();
    this.a.g(this.c, false);
    this.c.T0();
    this.a.b(this.c, false);
  }
  
  int d() {
    b0.e.b b;
    Fragment fragment2 = this.c;
    if (fragment2.G == null)
      return fragment2.o; 
    int j = this.e;
    int k = b.a[fragment2.f0.ordinal()];
    int i = j;
    if (k != 1)
      if (k != 2) {
        if (k != 3) {
          if (k != 4) {
            i = Math.min(j, -1);
          } else {
            i = Math.min(j, 0);
          } 
        } else {
          i = Math.min(j, 1);
        } 
      } else {
        i = Math.min(j, 5);
      }  
    fragment2 = this.c;
    j = i;
    if (fragment2.B) {
      View view;
      if (fragment2.C) {
        i = Math.max(this.e, 2);
        view = this.c.V;
        j = i;
        if (view != null) {
          j = i;
          if (view.getParent() == null)
            j = Math.min(i, 2); 
        } 
      } else if (this.e < 4) {
        j = Math.min(i, ((Fragment)view).o);
      } else {
        j = Math.min(i, 1);
      } 
    } 
    k = j;
    if (!this.c.z)
      k = Math.min(j, 1); 
    Fragment fragment3 = null;
    fragment2 = fragment3;
    if (m.P) {
      Fragment fragment = this.c;
      ViewGroup viewGroup = fragment.U;
      fragment2 = fragment3;
      if (viewGroup != null)
        b = b0.n(viewGroup, fragment.H()).l(this); 
    } 
    if (b == b0.e.b.p) {
      i = Math.min(k, 6);
    } else if (b == b0.e.b.q) {
      i = Math.max(k, 3);
    } else {
      Fragment fragment = this.c;
      i = k;
      if (fragment.A)
        if (fragment.d0()) {
          i = Math.min(k, 1);
        } else {
          i = Math.min(k, -1);
        }  
    } 
    Fragment fragment1 = this.c;
    j = i;
    if (fragment1.W) {
      j = i;
      if (fragment1.o < 5)
        j = Math.min(i, 4); 
    } 
    if (m.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("computeExpectedState() of ");
      stringBuilder.append(j);
      stringBuilder.append(" for ");
      stringBuilder.append(this.c);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    return j;
  }
  
  void e() {
    l l1;
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment = this.c;
    if (!fragment.e0) {
      this.a.h(fragment, fragment.p, false);
      fragment = this.c;
      fragment.W0(fragment.p);
      l1 = this.a;
      Fragment fragment1 = this.c;
      l1.c(fragment1, fragment1.p, false);
      return;
    } 
    l1.t1(((Fragment)l1).p);
    this.c.o = 1;
  }
  
  void f() {
    StringBuilder stringBuilder;
    if (this.c.B)
      return; 
    if (m.E0(3)) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("moveto CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment1 = this.c;
    LayoutInflater layoutInflater = fragment1.c1(fragment1.p);
    fragment1 = null;
    Fragment fragment3 = this.c;
    ViewGroup viewGroup = fragment3.U;
    if (viewGroup != null) {
      ViewGroup viewGroup1 = viewGroup;
    } else {
      int i = fragment3.L;
      if (i != 0)
        if (i != -1) {
          viewGroup = (ViewGroup)fragment3.G.n0().f(this.c.L);
          ViewGroup viewGroup1 = viewGroup;
          if (viewGroup == null) {
            ViewGroup viewGroup2;
            Fragment fragment = this.c;
            if (fragment.D) {
              viewGroup2 = viewGroup;
            } else {
              String str;
              try {
                str = viewGroup2.N().getResourceName(this.c.L);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                str = "unknown";
              } 
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("No view found for id 0x");
              stringBuilder1.append(Integer.toHexString(this.c.L));
              stringBuilder1.append(" (");
              stringBuilder1.append(str);
              stringBuilder1.append(") for fragment ");
              stringBuilder1.append(this.c);
              throw new IllegalArgumentException(stringBuilder1.toString());
            } 
          } 
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot create fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" for a container view with no id");
          throw new IllegalArgumentException(stringBuilder.toString());
        }  
    } 
    Fragment fragment2 = this.c;
    fragment2.U = (ViewGroup)stringBuilder;
    fragment2.Y0(layoutInflater, (ViewGroup)stringBuilder, fragment2.p);
    View view = this.c.V;
    if (view != null) {
      boolean bool = false;
      view.setSaveFromParentEnabled(false);
      Fragment fragment5 = this.c;
      fragment5.V.setTag(f0.b.a, fragment5);
      if (stringBuilder != null)
        b(); 
      Fragment fragment4 = this.c;
      if (fragment4.N)
        fragment4.V.setVisibility(8); 
      if (y.U(this.c.V)) {
        y.o0(this.c.V);
      } else {
        View view1 = this.c.V;
        view1.addOnAttachStateChangeListener(new a(this, view1));
      } 
      this.c.p1();
      l l1 = this.a;
      fragment5 = this.c;
      l1.m(fragment5, fragment5.V, fragment5.p, false);
      int i = this.c.V.getVisibility();
      float f = this.c.V.getAlpha();
      if (m.P) {
        this.c.F1(f);
        Fragment fragment = this.c;
        if (fragment.U != null && i == 0) {
          View view1 = fragment.V.findFocus();
          if (view1 != null) {
            this.c.A1(view1);
            if (m.E0(2)) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("requestFocus: Saved focused view ");
              stringBuilder1.append(view1);
              stringBuilder1.append(" for Fragment ");
              stringBuilder1.append(this.c);
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
          } 
          this.c.V.setAlpha(0.0F);
        } 
      } else {
        Fragment fragment = this.c;
        boolean bool1 = bool;
        if (i == 0) {
          bool1 = bool;
          if (fragment.U != null)
            bool1 = true; 
        } 
        fragment.a0 = bool1;
      } 
    } 
    this.c.o = 2;
  }
  
  void g() {
    boolean bool1;
    boolean bool2;
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment = this.c;
    boolean bool4 = fragment.A;
    boolean bool3 = true;
    if (bool4 && !fragment.d0()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1 || this.b.o().o(this.c)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool2) {
      int i;
      j<?> j = this.c.H;
      if (j instanceof androidx.lifecycle.i0) {
        bool3 = this.b.o().l();
      } else if (j.j() instanceof Activity) {
        i = true ^ ((Activity)j.j()).isChangingConfigurations();
      } 
      if (bool1 || i != 0)
        this.b.o().f(this.c); 
      this.c.Z0();
      this.a.d(this.c, false);
      for (t t1 : this.b.k()) {
        if (t1 != null) {
          Fragment fragment2 = t1.k();
          if (this.c.t.equals(fragment2.w)) {
            fragment2.v = this.c;
            fragment2.w = null;
          } 
        } 
      } 
      Fragment fragment1 = this.c;
      String str1 = fragment1.w;
      if (str1 != null)
        fragment1.v = this.b.f(str1); 
      this.b.q(this);
      return;
    } 
    String str = this.c.w;
    if (str != null) {
      Fragment fragment1 = this.b.f(str);
      if (fragment1 != null && fragment1.P)
        this.c.v = fragment1; 
    } 
    this.c.o = 0;
  }
  
  void h() {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    ViewGroup viewGroup = fragment2.U;
    if (viewGroup != null) {
      View view = fragment2.V;
      if (view != null)
        viewGroup.removeView(view); 
    } 
    this.c.a1();
    this.a.n(this.c, false);
    Fragment fragment1 = this.c;
    fragment1.U = null;
    fragment1.V = null;
    fragment1.h0 = null;
    fragment1.i0.n(null);
    this.c.C = false;
  }
  
  void i() {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.b1();
    l l1 = this.a;
    Fragment fragment2 = this.c;
    boolean bool2 = false;
    l1.e(fragment2, false);
    Fragment fragment1 = this.c;
    fragment1.o = -1;
    fragment1.H = null;
    fragment1.J = null;
    fragment1.G = null;
    boolean bool1 = bool2;
    if (fragment1.A) {
      bool1 = bool2;
      if (!fragment1.d0())
        bool1 = true; 
    } 
    if (bool1 || this.b.o().o(this.c)) {
      if (m.E0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("initState called for fragment: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      this.c.Y();
    } 
  }
  
  void j() {
    Fragment fragment = this.c;
    if (fragment.B && fragment.C && !fragment.E) {
      if (m.E0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("moveto CREATE_VIEW: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      fragment = this.c;
      fragment.Y0(fragment.c1(fragment.p), null, this.c.p);
      View view = this.c.V;
      if (view != null) {
        view.setSaveFromParentEnabled(false);
        Fragment fragment1 = this.c;
        fragment1.V.setTag(f0.b.a, fragment1);
        fragment1 = this.c;
        if (fragment1.N)
          fragment1.V.setVisibility(8); 
        this.c.p1();
        l l1 = this.a;
        Fragment fragment2 = this.c;
        l1.m(fragment2, fragment2.V, fragment2.p, false);
        this.c.o = 2;
      } 
    } 
  }
  
  Fragment k() {
    return this.c;
  }
  
  void m() {
    if (this.d) {
      if (m.E0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring re-entrant call to moveToExpectedState() for ");
        stringBuilder.append(k());
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    try {
      this.d = true;
      while (true) {
        int i = d();
        Fragment fragment = this.c;
        int j = fragment.o;
        if (i != j) {
          if (i > j) {
            switch (j + 1) {
              case 7:
                p();
                continue;
              case 6:
                fragment.o = 6;
                continue;
              case 5:
                u();
                continue;
              case 4:
                if (fragment.V != null) {
                  ViewGroup viewGroup = fragment.U;
                  if (viewGroup != null)
                    b0.n(viewGroup, fragment.H()).b(b0.e.c.d(this.c.V.getVisibility()), this); 
                } 
                this.c.o = 4;
                continue;
              case 3:
                a();
                continue;
              case 2:
                j();
                f();
                continue;
              case 1:
                e();
                continue;
              case 0:
                c();
                continue;
            } 
            continue;
          } 
        } else {
          if (m.P && fragment.b0) {
            if (fragment.V != null) {
              ViewGroup viewGroup = fragment.U;
              if (viewGroup != null) {
                b0 b0 = b0.n(viewGroup, fragment.H());
                if (this.c.N) {
                  b0.c(this);
                } else {
                  b0.e(this);
                } 
              } 
            } 
            fragment = this.c;
            m m = fragment.G;
            if (m != null)
              m.C0(fragment); 
            fragment = this.c;
            fragment.b0 = false;
            fragment.B0(fragment.N);
          } 
          return;
        } 
        switch (j - 1) {
          case 6:
            n();
          case 5:
            fragment.o = 5;
          case 4:
            v();
          case 3:
            if (m.E0(3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("movefrom ACTIVITY_CREATED: ");
              stringBuilder.append(this.c);
              Log.d("FragmentManager", stringBuilder.toString());
            } 
            fragment = this.c;
            if (fragment.V != null && fragment.q == null)
              s(); 
            fragment = this.c;
            if (fragment.V != null) {
              ViewGroup viewGroup = fragment.U;
              if (viewGroup != null)
                b0.n(viewGroup, fragment.H()).d(this); 
            } 
            this.c.o = 3;
          case 2:
            fragment.C = false;
            fragment.o = 2;
          case 1:
            h();
            this.c.o = 1;
          case 0:
            g();
          case -1:
            i();
        } 
      } 
    } finally {
      this.d = false;
    } 
  }
  
  void n() {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.h1();
    this.a.f(this.c, false);
  }
  
  void o(ClassLoader paramClassLoader) {
    Bundle bundle = this.c.p;
    if (bundle == null)
      return; 
    bundle.setClassLoader(paramClassLoader);
    Fragment fragment = this.c;
    fragment.q = fragment.p.getSparseParcelableArray("android:view_state");
    fragment = this.c;
    fragment.r = fragment.p.getBundle("android:view_registry_state");
    fragment = this.c;
    fragment.w = fragment.p.getString("android:target_state");
    fragment = this.c;
    if (fragment.w != null)
      fragment.x = fragment.p.getInt("android:target_req_state", 0); 
    fragment = this.c;
    Boolean bool = fragment.s;
    if (bool != null) {
      fragment.X = bool.booleanValue();
      this.c.s = null;
    } else {
      fragment.X = fragment.p.getBoolean("android:user_visible_hint", true);
    } 
    fragment = this.c;
    if (!fragment.X)
      fragment.W = true; 
  }
  
  void p() {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    View view = this.c.B();
    if (view != null && l(view)) {
      boolean bool = view.requestFocus();
      if (m.E0(2)) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("requestFocus: Restoring focused view ");
        stringBuilder.append(view);
        stringBuilder.append(" ");
        if (bool) {
          str = "succeeded";
        } else {
          str = "failed";
        } 
        stringBuilder.append(str);
        stringBuilder.append(" on Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" resulting in focused view ");
        stringBuilder.append(this.c.V.findFocus());
        Log.v("FragmentManager", stringBuilder.toString());
      } 
    } 
    this.c.A1(null);
    this.c.l1();
    this.a.i(this.c, false);
    Fragment fragment = this.c;
    fragment.p = null;
    fragment.q = null;
    fragment.r = null;
  }
  
  s r() {
    Bundle bundle;
    s s = new s(this.c);
    Fragment fragment = this.c;
    if (fragment.o > -1 && s.A == null) {
      bundle = q();
      s.A = bundle;
      if (this.c.w != null) {
        if (bundle == null)
          s.A = new Bundle(); 
        s.A.putString("android:target_state", this.c.w);
        int i = this.c.x;
        if (i != 0) {
          s.A.putInt("android:target_req_state", i);
          return s;
        } 
      } 
    } else {
      s.A = ((Fragment)bundle).p;
    } 
    return s;
  }
  
  void s() {
    if (this.c.V == null)
      return; 
    SparseArray<Parcelable> sparseArray = new SparseArray();
    this.c.V.saveHierarchyState(sparseArray);
    if (sparseArray.size() > 0)
      this.c.q = sparseArray; 
    Bundle bundle = new Bundle();
    this.c.h0.i(bundle);
    if (!bundle.isEmpty())
      this.c.r = bundle; 
  }
  
  void t(int paramInt) {
    this.e = paramInt;
  }
  
  void u() {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.n1();
    this.a.k(this.c, false);
  }
  
  void v() {
    if (m.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.o1();
    this.a.l(this.c, false);
  }
  
  class a implements View.OnAttachStateChangeListener {
    a(t this$0, View param1View) {}
    
    public void onViewAttachedToWindow(View param1View) {
      this.o.removeOnAttachStateChangeListener(this);
      y.o0(this.o);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */