package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
final class o implements Parcelable {
  public static final Parcelable.Creator<o> CREATOR = new a();
  
  ArrayList<s> o;
  
  ArrayList<String> p;
  
  b[] q;
  
  int r;
  
  String s = null;
  
  ArrayList<String> t = new ArrayList<String>();
  
  ArrayList<Bundle> u = new ArrayList<Bundle>();
  
  ArrayList<m.m> v;
  
  public o() {}
  
  public o(Parcel paramParcel) {
    this.o = paramParcel.createTypedArrayList(s.CREATOR);
    this.p = paramParcel.createStringArrayList();
    this.q = (b[])paramParcel.createTypedArray(b.CREATOR);
    this.r = paramParcel.readInt();
    this.s = paramParcel.readString();
    this.t = paramParcel.createStringArrayList();
    this.u = paramParcel.createTypedArrayList(Bundle.CREATOR);
    this.v = paramParcel.createTypedArrayList(m.m.CREATOR);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeTypedList(this.o);
    paramParcel.writeStringList(this.p);
    paramParcel.writeTypedArray((Parcelable[])this.q, paramInt);
    paramParcel.writeInt(this.r);
    paramParcel.writeString(this.s);
    paramParcel.writeStringList(this.t);
    paramParcel.writeTypedList(this.u);
    paramParcel.writeTypedList(this.v);
  }
  
  class a implements Parcelable.Creator<o> {
    public o a(Parcel param1Parcel) {
      return new o(param1Parcel);
    }
    
    public o[] b(int param1Int) {
      return new o[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */