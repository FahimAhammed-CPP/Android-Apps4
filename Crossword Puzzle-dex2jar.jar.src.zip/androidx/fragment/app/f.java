package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import androidx.core.view.v;

class f {
  static void a(Fragment paramFragment, d paramd, w.g paramg) {
    e e;
    View view = paramFragment.V;
    ViewGroup viewGroup = paramFragment.U;
    viewGroup.startViewTransition(view);
    androidx.core.os.e e1 = new androidx.core.os.e();
    e1.c(new a(paramFragment));
    paramg.b(paramFragment, e1);
    if (paramd.a != null) {
      e = new e(paramd.a, viewGroup, view);
      paramFragment.w1(paramFragment.V);
      e.setAnimationListener(new b(viewGroup, paramFragment, paramg, e1));
      paramFragment.V.startAnimation((Animation)e);
      return;
    } 
    Animator animator = ((d)e).b;
    paramFragment.y1(animator);
    animator.addListener((Animator.AnimatorListener)new c(viewGroup, view, paramFragment, paramg, e1));
    animator.setTarget(paramFragment.V);
    animator.start();
  }
  
  private static int b(Fragment paramFragment, boolean paramBoolean1, boolean paramBoolean2) {
    return paramBoolean2 ? (paramBoolean1 ? paramFragment.J() : paramFragment.K()) : (paramBoolean1 ? paramFragment.v() : paramFragment.y());
  }
  
  static d c(Context paramContext, Fragment paramFragment, boolean paramBoolean1, boolean paramBoolean2) {
    int k = paramFragment.F();
    int j = b(paramFragment, paramBoolean1, paramBoolean2);
    boolean bool = false;
    paramFragment.x1(0, 0, 0, 0);
    ViewGroup viewGroup = paramFragment.U;
    if (viewGroup != null) {
      int m = f0.b.c;
      if (viewGroup.getTag(m) != null)
        paramFragment.U.setTag(m, null); 
    } 
    viewGroup = paramFragment.U;
    if (viewGroup != null && viewGroup.getLayoutTransition() != null)
      return null; 
    Animation animation = paramFragment.s0(k, paramBoolean1, j);
    if (animation != null)
      return new d(animation); 
    Animator animator = paramFragment.t0(k, paramBoolean1, j);
    if (animator != null)
      return new d(animator); 
    int i = j;
    if (j == 0) {
      i = j;
      if (k != 0)
        i = d(k, paramBoolean1); 
    } 
    if (i != 0) {
      paramBoolean1 = "anim".equals(paramContext.getResources().getResourceTypeName(i));
      j = bool;
      if (paramBoolean1)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(paramContext, i);
          if (animation1 != null)
            return new d(animation1); 
          j = 1;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          j = bool;
        }  
      if (j == 0)
        try {
          animator = AnimatorInflater.loadAnimator((Context)notFoundException, i);
          if (animator != null)
            return new d(animator); 
        } catch (RuntimeException runtimeException) {
          if (!paramBoolean1) {
            Animation animation1 = AnimationUtils.loadAnimation((Context)notFoundException, i);
            if (animation1 != null)
              return new d(animation1); 
          } else {
            throw runtimeException;
          } 
        }  
    } 
    return null;
  }
  
  private static int d(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? f0.a.a : f0.a.b)) : (paramBoolean ? f0.a.c : f0.a.d)) : (paramBoolean ? f0.a.e : f0.a.f);
  }
  
  class a implements androidx.core.os.e.b {
    a(f this$0) {}
    
    public void a() {
      if (this.a.q() != null) {
        View view = this.a.q();
        this.a.w1(null);
        view.clearAnimation();
      } 
      this.a.y1(null);
    }
  }
  
  class b implements Animation.AnimationListener {
    b(f this$0, Fragment param1Fragment, w.g param1g, androidx.core.os.e param1e) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      this.a.post(new a(this));
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
    
    class a implements Runnable {
      a(f.b this$0) {}
      
      public void run() {
        if (this.o.b.q() != null) {
          this.o.b.w1(null);
          f.b b1 = this.o;
          b1.c.a(b1.b, b1.d);
        } 
      }
    }
  }
  
  class a implements Runnable {
    a(f this$0) {}
    
    public void run() {
      if (this.o.b.q() != null) {
        this.o.b.w1(null);
        f.b b1 = this.o;
        b1.c.a(b1.b, b1.d);
      } 
    }
  }
  
  class c extends AnimatorListenerAdapter {
    c(f this$0, View param1View, Fragment param1Fragment, w.g param1g, androidx.core.os.e param1e) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator = this.c.r();
      this.c.y1(null);
      if (param1Animator != null && this.a.indexOfChild(this.b) < 0)
        this.d.a(this.c, this.e); 
    }
  }
  
  static class d {
    public final Animation a = null;
    
    public final Animator b;
    
    d(Animator param1Animator) {
      this.b = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    d(Animation param1Animation) {
      this.b = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  static class e extends AnimationSet implements Runnable {
    private final ViewGroup o;
    
    private final View p;
    
    private boolean q;
    
    private boolean r;
    
    private boolean s = true;
    
    e(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.o = param1ViewGroup;
      this.p = param1View;
      addAnimation(param1Animation);
      param1ViewGroup.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.s = true;
      if (this.q)
        return this.r ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.q = true;
        v.a((View)this.o, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.s = true;
      if (this.q)
        return this.r ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.q = true;
        v.a((View)this.o, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.q && this.s) {
        this.s = false;
        this.o.post(this);
        return;
      } 
      this.o.endViewTransition(this.p);
      this.r = true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */