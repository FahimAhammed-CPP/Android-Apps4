package androidx.fragment.app;

import android.os.Bundle;
import androidx.lifecycle.g;
import androidx.lifecycle.h;
import androidx.lifecycle.h0;
import androidx.lifecycle.i;
import androidx.lifecycle.i0;
import androidx.lifecycle.m;
import androidx.lifecycle.n;
import j0.a;
import q0.c;
import q0.d;
import q0.e;

class z implements h, e, i0 {
  private final Fragment o;
  
  private final h0 p;
  
  private n q = null;
  
  private d r = null;
  
  z(Fragment paramFragment, h0 paramh0) {
    this.o = paramFragment;
    this.p = paramh0;
  }
  
  public i a() {
    e();
    return (i)this.q;
  }
  
  void b(i.b paramb) {
    this.q.h(paramb);
  }
  
  public c d() {
    e();
    return this.r.b();
  }
  
  void e() {
    if (this.q == null) {
      this.q = new n((m)this);
      this.r = d.a(this);
    } 
  }
  
  boolean f() {
    return (this.q != null);
  }
  
  void g(Bundle paramBundle) {
    this.r.d(paramBundle);
  }
  
  void i(Bundle paramBundle) {
    this.r.e(paramBundle);
  }
  
  void j(i.c paramc) {
    this.q.o(paramc);
  }
  
  public h0 k() {
    e();
    return this.p;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */