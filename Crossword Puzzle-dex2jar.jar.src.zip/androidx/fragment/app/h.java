package androidx.fragment.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class h {
  private final j<?> a;
  
  private h(j<?> paramj) {
    this.a = paramj;
  }
  
  public static h b(j<?> paramj) {
    return new h((j)androidx.core.util.h.g(paramj, "callbacks == null"));
  }
  
  public void a(Fragment paramFragment) {
    j<?> j1 = this.a;
    j1.s.j(j1, j1, paramFragment);
  }
  
  public void c() {
    this.a.s.y();
  }
  
  public void d(Configuration paramConfiguration) {
    this.a.s.A(paramConfiguration);
  }
  
  public boolean e(MenuItem paramMenuItem) {
    return this.a.s.B(paramMenuItem);
  }
  
  public void f() {
    this.a.s.C();
  }
  
  public boolean g(Menu paramMenu, MenuInflater paramMenuInflater) {
    return this.a.s.D(paramMenu, paramMenuInflater);
  }
  
  public void h() {
    this.a.s.E();
  }
  
  public void i() {
    this.a.s.G();
  }
  
  public void j(boolean paramBoolean) {
    this.a.s.H(paramBoolean);
  }
  
  public boolean k(MenuItem paramMenuItem) {
    return this.a.s.J(paramMenuItem);
  }
  
  public void l(Menu paramMenu) {
    this.a.s.K(paramMenu);
  }
  
  public void m() {
    this.a.s.M();
  }
  
  public void n(boolean paramBoolean) {
    this.a.s.N(paramBoolean);
  }
  
  public boolean o(Menu paramMenu) {
    return this.a.s.O(paramMenu);
  }
  
  public void p() {
    this.a.s.Q();
  }
  
  public void q() {
    this.a.s.R();
  }
  
  public void r() {
    this.a.s.T();
  }
  
  public boolean s() {
    return this.a.s.a0(true);
  }
  
  public m t() {
    return this.a.s;
  }
  
  public void u() {
    this.a.s.Q0();
  }
  
  public View v(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.a.s.t0().onCreateView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void w(Parcelable paramParcelable) {
    j<?> j1 = this.a;
    if (j1 instanceof androidx.lifecycle.i0) {
      j1.s.e1(paramParcelable);
      return;
    } 
    throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
  }
  
  public Parcelable x() {
    return this.a.s.g1();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\fragment\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */