package androidx.loader.app;

import android.os.Bundle;
import androidx.lifecycle.i0;
import androidx.lifecycle.m;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import k0.b;

public abstract class a {
  public static <T extends m & i0> a b(T paramT) {
    return new b((m)paramT, ((i0)paramT).k());
  }
  
  @Deprecated
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract <D> b<D> c(int paramInt, Bundle paramBundle, a<D> parama);
  
  public abstract void d();
  
  public static interface a<D> {
    void a(b<D> param1b, D param1D);
    
    b<D> b(int param1Int, Bundle param1Bundle);
    
    void c(b<D> param1b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\loader\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */