package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class b implements m {
  protected Context o;
  
  protected Context p;
  
  protected g q;
  
  protected LayoutInflater r;
  
  protected LayoutInflater s;
  
  private m.a t;
  
  private int u;
  
  private int v;
  
  protected n w;
  
  private int x;
  
  public b(Context paramContext, int paramInt1, int paramInt2) {
    this.o = paramContext;
    this.r = LayoutInflater.from(paramContext);
    this.u = paramInt1;
    this.v = paramInt2;
  }
  
  protected void a(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.w).addView(paramView, paramInt);
  }
  
  public void b(g paramg, boolean paramBoolean) {
    m.a a1 = this.t;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public abstract void c(i parami, n.a parama);
  
  public void d(Context paramContext, g paramg) {
    this.p = paramContext;
    this.s = LayoutInflater.from(paramContext);
    this.q = paramg;
  }
  
  public boolean e(r paramr) {
    m.a a1 = this.t;
    if (a1 != null) {
      g g1;
      if (paramr == null)
        g1 = this.q; 
      return a1.c(g1);
    } 
    return false;
  }
  
  public void f(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.w;
    if (viewGroup == null)
      return; 
    g g1 = this.q;
    int i = 0;
    if (g1 != null) {
      g1.r();
      ArrayList<i> arrayList = this.q.E();
      int k = arrayList.size();
      int j = 0;
      for (i = 0; j < k; i = i1) {
        i i2 = arrayList.get(j);
        int i1 = i;
        if (q(i, i2)) {
          View view1 = viewGroup.getChildAt(i);
          if (view1 instanceof n.a) {
            i i3 = ((n.a)view1).getItemData();
          } else {
            g1 = null;
          } 
          View view2 = n(i2, view1, viewGroup);
          if (i2 != g1) {
            view2.setPressed(false);
            view2.jumpDrawablesToCurrentState();
          } 
          if (view2 != view1)
            a(view2, i); 
          i1 = i + 1;
        } 
        j++;
      } 
    } 
    while (i < viewGroup.getChildCount()) {
      if (!l(viewGroup, i))
        i++; 
    } 
  }
  
  public n.a h(ViewGroup paramViewGroup) {
    return (n.a)this.r.inflate(this.v, paramViewGroup, false);
  }
  
  public boolean i(g paramg, i parami) {
    return false;
  }
  
  public boolean j(g paramg, i parami) {
    return false;
  }
  
  public void k(m.a parama) {
    this.t = parama;
  }
  
  protected boolean l(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public m.a m() {
    return this.t;
  }
  
  public View n(i parami, View paramView, ViewGroup paramViewGroup) {
    n.a a1;
    if (paramView instanceof n.a) {
      a1 = (n.a)paramView;
    } else {
      a1 = h(paramViewGroup);
    } 
    c(parami, a1);
    return (View)a1;
  }
  
  public n o(ViewGroup paramViewGroup) {
    if (this.w == null) {
      n n1 = (n)this.r.inflate(this.u, paramViewGroup, false);
      this.w = n1;
      n1.b(this.q);
      f(true);
    } 
    return this.w;
  }
  
  public void p(int paramInt) {
    this.x = paramInt;
  }
  
  public abstract boolean q(int paramInt, i parami);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\menu\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */