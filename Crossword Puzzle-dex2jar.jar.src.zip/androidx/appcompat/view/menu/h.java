package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.b;
import e.g;

class h implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, m.a {
  private g o;
  
  private b p;
  
  e q;
  
  private m.a r;
  
  public h(g paramg) {
    this.o = paramg;
  }
  
  public void a() {
    b b1 = this.p;
    if (b1 != null)
      b1.dismiss(); 
  }
  
  public void b(g paramg, boolean paramBoolean) {
    if (paramBoolean || paramg == this.o)
      a(); 
    m.a a1 = this.r;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public boolean c(g paramg) {
    m.a a1 = this.r;
    return (a1 != null) ? a1.c(paramg) : false;
  }
  
  public void d(IBinder paramIBinder) {
    g g1 = this.o;
    b.a a1 = new b.a(g1.u());
    e e1 = new e(a1.b(), g.j);
    this.q = e1;
    e1.k(this);
    this.o.b(this.q);
    a1.c(this.q.a(), this);
    View view = g1.y();
    if (view != null) {
      a1.d(view);
    } else {
      a1.f(g1.w()).l(g1.x());
    } 
    a1.i(this);
    b b1 = a1.a();
    this.p = b1;
    b1.setOnDismissListener(this);
    WindowManager.LayoutParams layoutParams = this.p.getWindow().getAttributes();
    layoutParams.type = 1003;
    if (paramIBinder != null)
      layoutParams.token = paramIBinder; 
    layoutParams.flags |= 0x20000;
    this.p.show();
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.o.L((MenuItem)this.q.a().getItem(paramInt), 0);
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    this.q.b(this.o, true);
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 82 || paramInt == 4) {
      KeyEvent.DispatcherState dispatcherState;
      if (paramKeyEvent.getAction() == 0 && paramKeyEvent.getRepeatCount() == 0) {
        Window window = this.p.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            dispatcherState = view.getKeyDispatcherState();
            if (dispatcherState != null) {
              dispatcherState.startTracking(paramKeyEvent, this);
              return true;
            } 
          } 
        } 
      } else if (paramKeyEvent.getAction() == 1 && !paramKeyEvent.isCanceled()) {
        Window window = this.p.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            KeyEvent.DispatcherState dispatcherState1 = view.getKeyDispatcherState();
            if (dispatcherState1 != null && dispatcherState1.isTracking(paramKeyEvent)) {
              this.o.e(true);
              dispatcherState.dismiss();
              return true;
            } 
          } 
        } 
      } 
    } 
    return this.o.performShortcut(paramInt, paramKeyEvent, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\menu\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */