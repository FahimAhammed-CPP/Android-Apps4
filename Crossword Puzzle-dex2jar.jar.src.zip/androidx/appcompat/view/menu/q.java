package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.p0;
import androidx.core.view.y;
import e.d;
import e.g;

final class q extends k implements PopupWindow.OnDismissListener, View.OnKeyListener {
  private static final int J = g.m;
  
  private View A;
  
  View B;
  
  private m.a C;
  
  ViewTreeObserver D;
  
  private boolean E;
  
  private boolean F;
  
  private int G;
  
  private int H = 0;
  
  private boolean I;
  
  private final Context p;
  
  private final g q;
  
  private final f r;
  
  private final boolean s;
  
  private final int t;
  
  private final int u;
  
  private final int v;
  
  final p0 w;
  
  final ViewTreeObserver.OnGlobalLayoutListener x = new a(this);
  
  private final View.OnAttachStateChangeListener y = new b(this);
  
  private PopupWindow.OnDismissListener z;
  
  public q(Context paramContext, g paramg, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.p = paramContext;
    this.q = paramg;
    this.s = paramBoolean;
    this.r = new f(paramg, LayoutInflater.from(paramContext), paramBoolean, J);
    this.u = paramInt1;
    this.v = paramInt2;
    Resources resources = paramContext.getResources();
    this.t = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.d));
    this.A = paramView;
    this.w = new p0(paramContext, null, paramInt1, paramInt2);
    paramg.c(this, paramContext);
  }
  
  private boolean z() {
    if (c())
      return true; 
    if (!this.E) {
      boolean bool;
      View view = this.A;
      if (view == null)
        return false; 
      this.B = view;
      this.w.K(this);
      this.w.L(this);
      this.w.J(true);
      view = this.B;
      if (this.D == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.D = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.x); 
      view.addOnAttachStateChangeListener(this.y);
      this.w.D(view);
      this.w.G(this.H);
      if (!this.F) {
        this.G = k.o((ListAdapter)this.r, null, this.p, this.t);
        this.F = true;
      } 
      this.w.F(this.G);
      this.w.I(2);
      this.w.H(n());
      this.w.a();
      ListView listView = this.w.h();
      listView.setOnKeyListener(this);
      if (this.I && this.q.x() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.p).inflate(g.l, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.q.x()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.w.p((ListAdapter)this.r);
      this.w.a();
      return true;
    } 
    return false;
  }
  
  public void a() {
    if (z())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void b(g paramg, boolean paramBoolean) {
    if (paramg != this.q)
      return; 
    dismiss();
    m.a a1 = this.C;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public boolean c() {
    return (!this.E && this.w.c());
  }
  
  public void dismiss() {
    if (c())
      this.w.dismiss(); 
  }
  
  public boolean e(r paramr) {
    if (paramr.hasVisibleItems()) {
      l l = new l(this.p, paramr, this.B, this.s, this.u, this.v);
      l.j(this.C);
      l.g(k.x(paramr));
      l.i(this.z);
      this.z = null;
      this.q.e(false);
      int j = this.w.d();
      int m = this.w.n();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.H, y.E(this.A)) & 0x7) == 5)
        i = j + this.A.getWidth(); 
      if (l.n(i, m)) {
        m.a a1 = this.C;
        if (a1 != null)
          a1.c(paramr); 
        return true;
      } 
    } 
    return false;
  }
  
  public void f(boolean paramBoolean) {
    this.F = false;
    f f1 = this.r;
    if (f1 != null)
      f1.notifyDataSetChanged(); 
  }
  
  public boolean g() {
    return false;
  }
  
  public ListView h() {
    return this.w.h();
  }
  
  public void k(m.a parama) {
    this.C = parama;
  }
  
  public void l(g paramg) {}
  
  public void onDismiss() {
    this.E = true;
    this.q.close();
    ViewTreeObserver viewTreeObserver = this.D;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.D = this.B.getViewTreeObserver(); 
      this.D.removeGlobalOnLayoutListener(this.x);
      this.D = null;
    } 
    this.B.removeOnAttachStateChangeListener(this.y);
    PopupWindow.OnDismissListener onDismissListener = this.z;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void p(View paramView) {
    this.A = paramView;
  }
  
  public void r(boolean paramBoolean) {
    this.r.d(paramBoolean);
  }
  
  public void s(int paramInt) {
    this.H = paramInt;
  }
  
  public void t(int paramInt) {
    this.w.l(paramInt);
  }
  
  public void u(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.z = paramOnDismissListener;
  }
  
  public void v(boolean paramBoolean) {
    this.I = paramBoolean;
  }
  
  public void w(int paramInt) {
    this.w.j(paramInt);
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    a(q this$0) {}
    
    public void onGlobalLayout() {
      if (this.o.c() && !this.o.w.B()) {
        View view = this.o.B;
        if (view == null || !view.isShown()) {
          this.o.dismiss();
          return;
        } 
        this.o.w.a();
        return;
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    b(q this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.o.D;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.o.D = param1View.getViewTreeObserver(); 
        q q1 = this.o;
        q1.D.removeGlobalOnLayoutListener(q1.x);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\menu\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */