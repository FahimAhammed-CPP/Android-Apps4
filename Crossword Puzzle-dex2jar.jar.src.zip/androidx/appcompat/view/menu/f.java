package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class f extends BaseAdapter {
  g o;
  
  private int p = -1;
  
  private boolean q;
  
  private final boolean r;
  
  private final LayoutInflater s;
  
  private final int t;
  
  public f(g paramg, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.r = paramBoolean;
    this.s = paramLayoutInflater;
    this.o = paramg;
    this.t = paramInt;
    a();
  }
  
  void a() {
    i i = this.o.v();
    if (i != null) {
      ArrayList<i> arrayList = this.o.z();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        if ((i)arrayList.get(j) == i) {
          this.p = j;
          return;
        } 
      } 
    } 
    this.p = -1;
  }
  
  public g b() {
    return this.o;
  }
  
  public i c(int paramInt) {
    ArrayList<i> arrayList;
    if (this.r) {
      arrayList = this.o.z();
    } else {
      arrayList = this.o.E();
    } 
    int j = this.p;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public void d(boolean paramBoolean) {
    this.q = paramBoolean;
  }
  
  public int getCount() {
    ArrayList<i> arrayList;
    if (this.r) {
      arrayList = this.o.z();
    } else {
      arrayList = this.o.E();
    } 
    return (this.p < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.s.inflate(this.t, paramViewGroup, false); 
    int j = c(paramInt).getGroupId();
    int i = paramInt - 1;
    if (i >= 0) {
      i = c(i).getGroupId();
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.o.F() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    n.a a = (n.a)view;
    if (this.q)
      listMenuItemView.setForceShowIcon(true); 
    a.g(c(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */