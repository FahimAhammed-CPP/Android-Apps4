package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import o.g;
import x.b;

abstract class c {
  final Context a;
  
  private g<b, MenuItem> b;
  
  private g<x.c, SubMenu> c;
  
  c(Context paramContext) {
    this.a = paramContext;
  }
  
  final MenuItem c(MenuItem paramMenuItem) {
    if (paramMenuItem instanceof b) {
      b b = (b)paramMenuItem;
      if (this.b == null)
        this.b = new g(); 
      MenuItem menuItem = (MenuItem)this.b.get(b);
      paramMenuItem = menuItem;
      if (menuItem == null) {
        paramMenuItem = new j(this.a, b);
        this.b.put(b, paramMenuItem);
      } 
      return paramMenuItem;
    } 
    return paramMenuItem;
  }
  
  final SubMenu d(SubMenu paramSubMenu) {
    if (paramSubMenu instanceof x.c) {
      x.c c1 = (x.c)paramSubMenu;
      if (this.c == null)
        this.c = new g(); 
      SubMenu subMenu = (SubMenu)this.c.get(c1);
      paramSubMenu = subMenu;
      if (subMenu == null) {
        paramSubMenu = new s(this.a, c1);
        this.c.put(c1, paramSubMenu);
      } 
      return paramSubMenu;
    } 
    return paramSubMenu;
  }
  
  final void e() {
    g<b, MenuItem> g2 = this.b;
    if (g2 != null)
      g2.clear(); 
    g<x.c, SubMenu> g1 = this.c;
    if (g1 != null)
      g1.clear(); 
  }
  
  final void f(int paramInt) {
    if (this.b == null)
      return; 
    for (int i = 0; i < this.b.size(); i = j + 1) {
      int j = i;
      if (((b)this.b.i(i)).getGroupId() == paramInt) {
        this.b.k(i);
        j = i - 1;
      } 
    } 
  }
  
  final void g(int paramInt) {
    if (this.b == null)
      return; 
    for (int i = 0; i < this.b.size(); i++) {
      if (((b)this.b.i(i)).getItemId() == paramInt) {
        this.b.k(i);
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\menu\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */