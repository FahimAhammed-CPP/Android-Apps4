package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.a1;
import androidx.core.view.y;
import e.a;
import e.f;
import e.g;
import e.j;

public class ListMenuItemView extends LinearLayout implements n.a, AbsListView.SelectionBoundsAdjuster {
  private boolean A;
  
  private Drawable B;
  
  private boolean C;
  
  private LayoutInflater D;
  
  private boolean E;
  
  private i o;
  
  private ImageView p;
  
  private RadioButton q;
  
  private TextView r;
  
  private CheckBox s;
  
  private TextView t;
  
  private ImageView u;
  
  private ImageView v;
  
  private LinearLayout w;
  
  private Drawable x;
  
  private int y;
  
  private Context z;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.D);
  }
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    a1 a1 = a1.v(getContext(), paramAttributeSet, j.T1, paramInt, 0);
    this.x = a1.g(j.V1);
    this.y = a1.n(j.U1, -1);
    this.A = a1.a(j.W1, false);
    this.z = paramContext;
    this.B = a1.g(j.X1);
    Resources.Theme theme = paramContext.getTheme();
    paramInt = a.A;
    TypedArray typedArray = theme.obtainStyledAttributes(null, new int[] { 16843049 }, paramInt, 0);
    this.C = typedArray.hasValue(0);
    a1.w();
    typedArray.recycle();
  }
  
  private void a(View paramView) {
    b(paramView, -1);
  }
  
  private void b(View paramView, int paramInt) {
    LinearLayout linearLayout = this.w;
    if (linearLayout != null) {
      linearLayout.addView(paramView, paramInt);
      return;
    } 
    addView(paramView, paramInt);
  }
  
  private void c() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(g.h, (ViewGroup)this, false);
    this.s = checkBox;
    a((View)checkBox);
  }
  
  private void d() {
    ImageView imageView = (ImageView)getInflater().inflate(g.i, (ViewGroup)this, false);
    this.p = imageView;
    b((View)imageView, 0);
  }
  
  private void f() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(g.k, (ViewGroup)this, false);
    this.q = radioButton;
    a((View)radioButton);
  }
  
  private LayoutInflater getInflater() {
    if (this.D == null)
      this.D = LayoutInflater.from(getContext()); 
    return this.D;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.u;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.v;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.v.getLayoutParams();
      paramRect.top += this.v.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    } 
  }
  
  public boolean e() {
    return false;
  }
  
  public void g(i parami, int paramInt) {
    this.o = parami;
    if (parami.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(parami.i(this));
    setCheckable(parami.isCheckable());
    h(parami.A(), parami.g());
    setIcon(parami.getIcon());
    setEnabled(parami.isEnabled());
    setSubMenuArrowVisible(parami.hasSubMenu());
    setContentDescription(parami.getContentDescription());
  }
  
  public i getItemData() {
    return this.o;
  }
  
  public void h(boolean paramBoolean, char paramChar) {
    if (paramBoolean && this.o.A()) {
      paramChar = Character.MIN_VALUE;
    } else {
      paramChar = '\b';
    } 
    if (paramChar == '\000')
      this.t.setText(this.o.h()); 
    if (this.t.getVisibility() != paramChar)
      this.t.setVisibility(paramChar); 
  }
  
  protected void onFinishInflate() {
    super.onFinishInflate();
    y.v0((View)this, this.x);
    TextView textView = (TextView)findViewById(f.M);
    this.r = textView;
    int j = this.y;
    if (j != -1)
      textView.setTextAppearance(this.z, j); 
    this.t = (TextView)findViewById(f.F);
    ImageView imageView = (ImageView)findViewById(f.I);
    this.u = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.B); 
    this.v = (ImageView)findViewById(f.r);
    this.w = (LinearLayout)findViewById(f.l);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.p != null && this.A) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.p.getLayoutParams();
      int j = layoutParams.height;
      if (j > 0 && layoutParams1.width <= 0)
        layoutParams1.width = j; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.q == null && this.s == null)
      return; 
    if (this.o.m()) {
      if (this.q == null)
        f(); 
      RadioButton radioButton1 = this.q;
      CheckBox checkBox1 = this.s;
    } else {
      if (this.s == null)
        c(); 
      checkBox = this.s;
      radioButton = this.q;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.o.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.s;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.q;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.o.m()) {
      if (this.q == null)
        f(); 
      RadioButton radioButton = this.q;
    } else {
      if (this.s == null)
        c(); 
      checkBox = this.s;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.E = paramBoolean;
    this.A = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.v;
    if (imageView != null) {
      byte b;
      if (!this.C && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    if (this.o.z() || this.E) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.A)
      return; 
    ImageView imageView = this.p;
    if (imageView == null && paramDrawable == null && !this.A)
      return; 
    if (imageView == null)
      d(); 
    if (paramDrawable != null || this.A) {
      imageView = this.p;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.p.getVisibility() != 0)
        this.p.setVisibility(0); 
      return;
    } 
    this.p.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.r.setText(paramCharSequence);
      if (this.r.getVisibility() != 0) {
        this.r.setVisibility(0);
        return;
      } 
    } else if (this.r.getVisibility() != 8) {
      this.r.setVisibility(8);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */