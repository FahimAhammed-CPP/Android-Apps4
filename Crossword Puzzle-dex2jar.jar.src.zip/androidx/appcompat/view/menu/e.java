package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import e.g;
import java.util.ArrayList;

public class e implements m, AdapterView.OnItemClickListener {
  Context o;
  
  LayoutInflater p;
  
  g q;
  
  ExpandedMenuView r;
  
  int s;
  
  int t;
  
  int u;
  
  private m.a v;
  
  a w;
  
  public e(int paramInt1, int paramInt2) {
    this.u = paramInt1;
    this.t = paramInt2;
  }
  
  public e(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.o = paramContext;
    this.p = LayoutInflater.from(paramContext);
  }
  
  public ListAdapter a() {
    if (this.w == null)
      this.w = new a(this); 
    return (ListAdapter)this.w;
  }
  
  public void b(g paramg, boolean paramBoolean) {
    m.a a1 = this.v;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public n c(ViewGroup paramViewGroup) {
    if (this.r == null) {
      this.r = (ExpandedMenuView)this.p.inflate(g.g, paramViewGroup, false);
      if (this.w == null)
        this.w = new a(this); 
      this.r.setAdapter((ListAdapter)this.w);
      this.r.setOnItemClickListener(this);
    } 
    return this.r;
  }
  
  public void d(Context paramContext, g paramg) {
    ContextThemeWrapper contextThemeWrapper;
    if (this.t != 0) {
      contextThemeWrapper = new ContextThemeWrapper(paramContext, this.t);
      this.o = (Context)contextThemeWrapper;
      this.p = LayoutInflater.from((Context)contextThemeWrapper);
    } else if (this.o != null) {
      this.o = (Context)contextThemeWrapper;
      if (this.p == null)
        this.p = LayoutInflater.from((Context)contextThemeWrapper); 
    } 
    this.q = paramg;
    a a1 = this.w;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean e(r paramr) {
    if (!paramr.hasVisibleItems())
      return false; 
    (new h(paramr)).d(null);
    m.a a1 = this.v;
    if (a1 != null)
      a1.c(paramr); 
    return true;
  }
  
  public void f(boolean paramBoolean) {
    a a1 = this.w;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean g() {
    return false;
  }
  
  public boolean i(g paramg, i parami) {
    return false;
  }
  
  public boolean j(g paramg, i parami) {
    return false;
  }
  
  public void k(m.a parama) {
    this.v = parama;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.q.M((MenuItem)this.w.b(paramInt), this, 0);
  }
  
  private class a extends BaseAdapter {
    private int o = -1;
    
    public a(e this$0) {
      a();
    }
    
    void a() {
      i i = this.p.q.v();
      if (i != null) {
        ArrayList<i> arrayList = this.p.q.z();
        int k = arrayList.size();
        for (int j = 0; j < k; j++) {
          if ((i)arrayList.get(j) == i) {
            this.o = j;
            return;
          } 
        } 
      } 
      this.o = -1;
    }
    
    public i b(int param1Int) {
      ArrayList<i> arrayList = this.p.q.z();
      int i = param1Int + this.p.s;
      int j = this.o;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      int i = this.p.q.z().size() - this.p.s;
      return (this.o < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null) {
        e e1 = this.p;
        view = e1.p.inflate(e1.u, param1ViewGroup, false);
      } 
      ((n.a)view).g(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\menu\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */