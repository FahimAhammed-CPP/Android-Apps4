package androidx.appcompat.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.widget.a1;

public final class ExpandedMenuView extends ListView implements g.b, n, AdapterView.OnItemClickListener {
  private static final int[] q = new int[] { 16842964, 16843049 };
  
  private g o;
  
  private int p;
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842868);
  }
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    setOnItemClickListener(this);
    a1 a1 = a1.v(paramContext, paramAttributeSet, q, paramInt, 0);
    if (a1.s(0))
      setBackgroundDrawable(a1.g(0)); 
    if (a1.s(1))
      setDivider(a1.g(1)); 
    a1.w();
  }
  
  public boolean a(i parami) {
    return this.o.L((MenuItem)parami, 0);
  }
  
  public void b(g paramg) {
    this.o = paramg;
  }
  
  public int getWindowAnimations() {
    return this.p;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    setChildrenDrawingCacheEnabled(false);
  }
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {
    a((i)getAdapter().getItem(paramInt));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\menu\ExpandedMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */