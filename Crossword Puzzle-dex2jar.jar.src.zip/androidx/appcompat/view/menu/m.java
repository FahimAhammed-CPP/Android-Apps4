package androidx.appcompat.view.menu;

import android.content.Context;

public interface m {
  void b(g paramg, boolean paramBoolean);
  
  void d(Context paramContext, g paramg);
  
  boolean e(r paramr);
  
  void f(boolean paramBoolean);
  
  boolean g();
  
  boolean i(g paramg, i parami);
  
  boolean j(g paramg, i parami);
  
  void k(a parama);
  
  public static interface a {
    void b(g param1g, boolean param1Boolean);
    
    boolean c(g param1g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\menu\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */