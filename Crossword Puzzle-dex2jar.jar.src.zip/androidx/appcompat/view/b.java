package androidx.appcompat.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public abstract class b {
  private Object o;
  
  private boolean p;
  
  public abstract void c();
  
  public abstract View d();
  
  public abstract Menu e();
  
  public abstract MenuInflater f();
  
  public abstract CharSequence g();
  
  public Object h() {
    return this.o;
  }
  
  public abstract CharSequence i();
  
  public boolean j() {
    return this.p;
  }
  
  public abstract void k();
  
  public abstract boolean l();
  
  public abstract void m(View paramView);
  
  public abstract void n(int paramInt);
  
  public abstract void o(CharSequence paramCharSequence);
  
  public void p(Object paramObject) {
    this.o = paramObject;
  }
  
  public abstract void q(int paramInt);
  
  public abstract void r(CharSequence paramCharSequence);
  
  public void s(boolean paramBoolean) {
    this.p = paramBoolean;
  }
  
  public static interface a {
    boolean a(b param1b, Menu param1Menu);
    
    void b(b param1b);
    
    boolean c(b param1b, MenuItem param1MenuItem);
    
    boolean d(b param1b, Menu param1Menu);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */