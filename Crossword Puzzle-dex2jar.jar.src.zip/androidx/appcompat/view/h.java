package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.view.e0;
import androidx.core.view.f0;
import androidx.core.view.g0;
import java.util.ArrayList;
import java.util.Iterator;

public class h {
  final ArrayList<e0> a = new ArrayList<e0>();
  
  private long b = -1L;
  
  private Interpolator c;
  
  f0 d;
  
  private boolean e;
  
  private final g0 f = new a(this);
  
  public void a() {
    if (!this.e)
      return; 
    Iterator<e0> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((e0)iterator.next()).c(); 
    this.e = false;
  }
  
  void b() {
    this.e = false;
  }
  
  public h c(e0 parame0) {
    if (!this.e)
      this.a.add(parame0); 
    return this;
  }
  
  public h d(e0 parame01, e0 parame02) {
    this.a.add(parame01);
    parame02.j(parame01.d());
    this.a.add(parame02);
    return this;
  }
  
  public h e(long paramLong) {
    if (!this.e)
      this.b = paramLong; 
    return this;
  }
  
  public h f(Interpolator paramInterpolator) {
    if (!this.e)
      this.c = paramInterpolator; 
    return this;
  }
  
  public h g(f0 paramf0) {
    if (!this.e)
      this.d = paramf0; 
    return this;
  }
  
  public void h() {
    if (this.e)
      return; 
    for (e0 e0 : this.a) {
      long l = this.b;
      if (l >= 0L)
        e0.f(l); 
      Interpolator interpolator = this.c;
      if (interpolator != null)
        e0.g(interpolator); 
      if (this.d != null)
        e0.h((f0)this.f); 
      e0.l();
    } 
    this.e = true;
  }
  
  class a extends g0 {
    private boolean a = false;
    
    private int b = 0;
    
    a(h this$0) {}
    
    public void b(View param1View) {
      int i = this.b + 1;
      this.b = i;
      if (i == this.c.a.size()) {
        f0 f0 = this.c.d;
        if (f0 != null)
          f0.b(null); 
        d();
      } 
    }
    
    public void c(View param1View) {
      if (this.a)
        return; 
      this.a = true;
      f0 f0 = this.c.d;
      if (f0 != null)
        f0.c(null); 
    }
    
    void d() {
      this.b = 0;
      this.a = false;
      this.c.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */