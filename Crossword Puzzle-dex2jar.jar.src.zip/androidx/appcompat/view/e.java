package androidx.appcompat.view;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

public class e extends b implements g.a {
  private Context q;
  
  private ActionBarContextView r;
  
  private b.a s;
  
  private WeakReference<View> t;
  
  private boolean u;
  
  private boolean v;
  
  private g w;
  
  public e(Context paramContext, ActionBarContextView paramActionBarContextView, b.a parama, boolean paramBoolean) {
    this.q = paramContext;
    this.r = paramActionBarContextView;
    this.s = parama;
    g g1 = (new g(paramActionBarContextView.getContext())).S(1);
    this.w = g1;
    g1.R(this);
    this.v = paramBoolean;
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    return this.s.c(this, paramMenuItem);
  }
  
  public void b(g paramg) {
    k();
    this.r.l();
  }
  
  public void c() {
    if (this.u)
      return; 
    this.u = true;
    this.s.b(this);
  }
  
  public View d() {
    WeakReference<View> weakReference = this.t;
    return (weakReference != null) ? weakReference.get() : null;
  }
  
  public Menu e() {
    return (Menu)this.w;
  }
  
  public MenuInflater f() {
    return new g(this.r.getContext());
  }
  
  public CharSequence g() {
    return this.r.getSubtitle();
  }
  
  public CharSequence i() {
    return this.r.getTitle();
  }
  
  public void k() {
    this.s.a(this, (Menu)this.w);
  }
  
  public boolean l() {
    return this.r.j();
  }
  
  public void m(View paramView) {
    this.r.setCustomView(paramView);
    if (paramView != null) {
      WeakReference<View> weakReference = new WeakReference<View>(paramView);
    } else {
      paramView = null;
    } 
    this.t = (WeakReference<View>)paramView;
  }
  
  public void n(int paramInt) {
    o(this.q.getString(paramInt));
  }
  
  public void o(CharSequence paramCharSequence) {
    this.r.setSubtitle(paramCharSequence);
  }
  
  public void q(int paramInt) {
    r(this.q.getString(paramInt));
  }
  
  public void r(CharSequence paramCharSequence) {
    this.r.setTitle(paramCharSequence);
  }
  
  public void s(boolean paramBoolean) {
    super.s(paramBoolean);
    this.r.setTitleOptional(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\view\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */