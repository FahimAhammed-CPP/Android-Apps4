package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.core.view.w;
import androidx.core.widget.m;
import androidx.core.widget.n;
import e.a;
import f.a;

public class v extends RadioButton implements m, w, n {
  private final j o;
  
  private final e p;
  
  private final c0 q;
  
  private n r;
  
  public v(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.G);
  }
  
  public v(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(x0.b(paramContext), paramAttributeSet, paramInt);
    v0.a((View)this, getContext());
    j j1 = new j((CompoundButton)this);
    this.o = j1;
    j1.e(paramAttributeSet, paramInt);
    e e1 = new e((View)this);
    this.p = e1;
    e1.e(paramAttributeSet, paramInt);
    c0 c01 = new c0((TextView)this);
    this.q = c01;
    c01.m(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().b(paramAttributeSet, paramInt);
  }
  
  private n getEmojiTextViewHelper() {
    if (this.r == null)
      this.r = new n((TextView)this); 
    return this.r;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.p;
    if (e1 != null)
      e1.b(); 
    c0 c01 = this.q;
    if (c01 != null)
      c01.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    int k = super.getCompoundPaddingLeft();
    j j1 = this.o;
    int i = k;
    if (j1 != null)
      i = j1.b(k); 
    return i;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.p;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.p;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    j j1 = this.o;
    return (j1 != null) ? j1.c() : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    j j1 = this.o;
    return (j1 != null) ? j1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.q.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.q.k();
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().c(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.p;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.p;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(a.b(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    j j1 = this.o;
    if (j1 != null)
      j1.f(); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.q;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.q;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.p;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.p;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    j j1 = this.o;
    if (j1 != null)
      j1.g(paramColorStateList); 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    j j1 = this.o;
    if (j1 != null)
      j1.h(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.q.w(paramColorStateList);
    this.q.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.q.x(paramMode);
    this.q.b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */