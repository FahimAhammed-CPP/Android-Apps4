package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import e.j;
import e0.a;

class m {
  private final EditText a;
  
  private final a b;
  
  m(EditText paramEditText) {
    this.a = paramEditText;
    this.b = new a(paramEditText, false);
  }
  
  KeyListener a(KeyListener paramKeyListener) {
    KeyListener keyListener = paramKeyListener;
    if (b(paramKeyListener))
      keyListener = this.b.a(paramKeyListener); 
    return keyListener;
  }
  
  boolean b(KeyListener paramKeyListener) {
    return paramKeyListener instanceof android.text.method.NumberKeyListener ^ true;
  }
  
  void c(AttributeSet paramAttributeSet, int paramInt) {
    TypedArray typedArray = this.a.getContext().obtainStyledAttributes(paramAttributeSet, j.g0, paramInt, 0);
    try {
      paramInt = j.u0;
      boolean bool2 = typedArray.hasValue(paramInt);
      boolean bool1 = true;
      if (bool2)
        bool1 = typedArray.getBoolean(paramInt, true); 
      typedArray.recycle();
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  InputConnection d(InputConnection paramInputConnection, EditorInfo paramEditorInfo) {
    return this.b.b(paramInputConnection, paramEditorInfo);
  }
  
  void e(boolean paramBoolean) {
    this.b.c(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */