package androidx.appcompat.widget;

import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;

public class i0 {
  private static final int[] a = new int[] { 16842912 };
  
  private static final int[] b = new int[0];
  
  public static final Rect c = new Rect();
  
  public static boolean a(Drawable paramDrawable) {
    return true;
  }
  
  static void b(Drawable paramDrawable) {
    String str = paramDrawable.getClass().getName();
    int i = Build.VERSION.SDK_INT;
    if (i == 21 && "android.graphics.drawable.VectorDrawable".equals(str)) {
      c(paramDrawable);
      return;
    } 
    if (i >= 29 && i < 31 && "android.graphics.drawable.ColorStateListDrawable".equals(str))
      c(paramDrawable); 
  }
  
  private static void c(Drawable paramDrawable) {
    int[] arrayOfInt = paramDrawable.getState();
    if (arrayOfInt == null || arrayOfInt.length == 0) {
      paramDrawable.setState(a);
    } else {
      paramDrawable.setState(b);
    } 
    paramDrawable.setState(arrayOfInt);
  }
  
  public static PorterDuff.Mode d(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */