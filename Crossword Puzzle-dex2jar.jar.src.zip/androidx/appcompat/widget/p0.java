package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.view.menu.f;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.i;
import java.lang.reflect.Method;

public class p0 extends n0 implements o0 {
  private static Method Y;
  
  private o0 X;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        Y = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public p0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void S(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      a.a(this.T, (Transition)paramObject); 
  }
  
  public void T(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      a.b(this.T, (Transition)paramObject); 
  }
  
  public void U(o0 paramo0) {
    this.X = paramo0;
  }
  
  public void V(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = Y;
      if (method != null)
        try {
          method.invoke(this.T, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      b.a(this.T, paramBoolean);
    } 
  }
  
  public void e(g paramg, MenuItem paramMenuItem) {
    o0 o01 = this.X;
    if (o01 != null)
      o01.e(paramg, paramMenuItem); 
  }
  
  public void f(g paramg, MenuItem paramMenuItem) {
    o0 o01 = this.X;
    if (o01 != null)
      o01.f(paramg, paramMenuItem); 
  }
  
  j0 s(Context paramContext, boolean paramBoolean) {
    c c = new c(paramContext, paramBoolean);
    c.setHoverListener(this);
    return c;
  }
  
  static class a {
    static void a(PopupWindow param1PopupWindow, Transition param1Transition) {
      param1PopupWindow.setEnterTransition(param1Transition);
    }
    
    static void b(PopupWindow param1PopupWindow, Transition param1Transition) {
      param1PopupWindow.setExitTransition(param1Transition);
    }
  }
  
  static class b {
    static void a(PopupWindow param1PopupWindow, boolean param1Boolean) {
      param1PopupWindow.setTouchModal(param1Boolean);
    }
  }
  
  public static class c extends j0 {
    final int C;
    
    final int D;
    
    private o0 E;
    
    private MenuItem F;
    
    public c(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      if (1 == a.a(param1Context.getResources().getConfiguration())) {
        this.C = 21;
        this.D = 22;
        return;
      } 
      this.C = 22;
      this.D = 21;
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      if (this.E != null) {
        int i;
        f f;
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter)listAdapter;
          i = headerViewListAdapter.getHeadersCount();
          f = (f)headerViewListAdapter.getWrappedAdapter();
        } else {
          i = 0;
          f = f;
        } 
        i i2 = null;
        i i1 = i2;
        if (param1MotionEvent.getAction() != 10) {
          int j = pointToPosition((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY());
          i1 = i2;
          if (j != -1) {
            i = j - i;
            i1 = i2;
            if (i >= 0) {
              i1 = i2;
              if (i < f.getCount())
                i1 = f.c(i); 
            } 
          } 
        } 
        MenuItem menuItem = this.F;
        if (menuItem != i1) {
          g g = f.b();
          if (menuItem != null)
            this.E.f(g, menuItem); 
          this.F = (MenuItem)i1;
          if (i1 != null)
            this.E.e(g, (MenuItem)i1); 
        } 
      } 
      return super.onHoverEvent(param1MotionEvent);
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      f f;
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.C) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.D) {
        setSelection(-1);
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          f = (f)((HeaderViewListAdapter)listAdapter).getWrappedAdapter();
        } else {
          f = f;
        } 
        f.b().e(false);
        return true;
      } 
      return super.onKeyDown(param1Int, (KeyEvent)f);
    }
    
    public void setHoverListener(o0 param1o0) {
      this.E = param1o0;
    }
    
    static class a {
      static int a(Configuration param2Configuration) {
        return param2Configuration.getLayoutDirection();
      }
    }
  }
  
  static class a {
    static int a(Configuration param1Configuration) {
      return param1Configuration.getLayoutDirection();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */