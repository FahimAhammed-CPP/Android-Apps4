package androidx.appcompat.widget;

import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import androidx.core.view.y;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class j1 {
  private static Method a;
  
  static {
    try {
      Method method = View.class.getDeclaredMethod("computeFitSystemWindows", new Class[] { Rect.class, Rect.class });
      a = method;
      if (!method.isAccessible()) {
        a.setAccessible(true);
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.d("ViewUtils", "Could not find method computeFitSystemWindows. Oh well.");
    } 
  }
  
  public static void a(View paramView, Rect paramRect1, Rect paramRect2) {
    Method method = a;
    if (method != null)
      try {
        method.invoke(paramView, new Object[] { paramRect1, paramRect2 });
        return;
      } catch (Exception exception) {
        Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", exception);
      }  
  }
  
  public static boolean b(View paramView) {
    return (y.E(paramView) == 1);
  }
  
  public static void c(View paramView) {
    try {
      Method method = paramView.getClass().getMethod("makeOptionalFitsSystemWindows", new Class[0]);
      if (!method.isAccessible())
        method.setAccessible(true); 
      method.invoke(paramView, new Object[0]);
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.d("ViewUtils", "Could not find method makeOptionalFitsSystemWindows. Oh well...");
      return;
    } catch (InvocationTargetException invocationTargetException) {
      Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", invocationTargetException);
      return;
    } catch (IllegalAccessException illegalAccessException) {
      Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", illegalAccessException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\j1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */