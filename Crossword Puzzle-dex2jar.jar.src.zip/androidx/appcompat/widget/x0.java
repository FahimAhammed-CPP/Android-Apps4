package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Build;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class x0 extends ContextWrapper {
  private static final Object c = new Object();
  
  private static ArrayList<WeakReference<x0>> d;
  
  private final Resources a;
  
  private final Resources.Theme b;
  
  private x0(Context paramContext) {
    super(paramContext);
    if (i1.c()) {
      i1 i1 = new i1((Context)this, paramContext.getResources());
      this.a = i1;
      Resources.Theme theme = i1.newTheme();
      this.b = theme;
      theme.setTo(paramContext.getTheme());
      return;
    } 
    this.a = new z0((Context)this, paramContext.getResources());
    this.b = null;
  }
  
  private static boolean a(Context paramContext) {
    boolean bool1 = paramContext instanceof x0;
    boolean bool = false;
    null = bool;
    if (!bool1) {
      null = bool;
      if (!(paramContext.getResources() instanceof z0)) {
        if (paramContext.getResources() instanceof i1)
          return false; 
        if (Build.VERSION.SDK_INT >= 21) {
          null = bool;
          return i1.c() ? true : null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public static Context b(Context paramContext) {
    if (a(paramContext))
      synchronized (c) {
        ArrayList<WeakReference<x0>> arrayList = d;
        if (arrayList == null) {
          d = new ArrayList<WeakReference<x0>>();
        } else {
          for (int i = arrayList.size() - 1;; i--) {
            if (i >= 0) {
              WeakReference weakReference = d.get(i);
              if (weakReference == null || weakReference.get() == null)
                d.remove(i); 
            } else {
              for (i = d.size() - 1;; i--) {
                if (i >= 0) {
                  WeakReference<x0> weakReference = d.get(i);
                  if (weakReference != null) {
                    x0 x02 = weakReference.get();
                  } else {
                    weakReference = null;
                  } 
                  if (weakReference != null && weakReference.getBaseContext() == paramContext)
                    return (Context)weakReference; 
                } else {
                  x01 = new x0(paramContext);
                  d.add(new WeakReference<x0>(x01));
                  return (Context)x01;
                } 
              } 
            } 
          } 
          i--;
        } 
        x0 x01 = new x0((Context)x01);
        d.add(new WeakReference<x0>(x01));
        return (Context)x01;
      }  
    return paramContext;
  }
  
  public AssetManager getAssets() {
    return this.a.getAssets();
  }
  
  public Resources getResources() {
    return this.a;
  }
  
  public Resources.Theme getTheme() {
    Resources.Theme theme2 = this.b;
    Resources.Theme theme1 = theme2;
    if (theme2 == null)
      theme1 = super.getTheme(); 
    return theme1;
  }
  
  public void setTheme(int paramInt) {
    Resources.Theme theme = this.b;
    if (theme == null) {
      super.setTheme(paramInt);
      return;
    } 
    theme.applyStyle(paramInt, true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */