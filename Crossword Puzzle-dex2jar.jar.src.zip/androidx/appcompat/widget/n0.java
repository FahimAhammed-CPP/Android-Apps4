package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.p;
import androidx.core.view.y;
import e.j;
import java.lang.reflect.Method;

public class n0 implements p {
  private static Method U;
  
  private static Method V;
  
  private static Method W;
  
  private boolean A = false;
  
  private boolean B = false;
  
  int C = Integer.MAX_VALUE;
  
  private View D;
  
  private int E = 0;
  
  private DataSetObserver F;
  
  private View G;
  
  private Drawable H;
  
  private AdapterView.OnItemClickListener I;
  
  private AdapterView.OnItemSelectedListener J;
  
  final i K = new i(this);
  
  private final h L = new h(this);
  
  private final g M = new g(this);
  
  private final e N = new e(this);
  
  private Runnable O;
  
  final Handler P;
  
  private final Rect Q = new Rect();
  
  private Rect R;
  
  private boolean S;
  
  PopupWindow T;
  
  private Context o;
  
  private ListAdapter p;
  
  j0 q;
  
  private int r = -2;
  
  private int s = -2;
  
  private int t;
  
  private int u;
  
  private int v = 1002;
  
  private boolean w;
  
  private boolean x;
  
  private boolean y;
  
  private int z = 0;
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        U = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      } 
      try {
        W = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      } 
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        V = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }  
  }
  
  public n0(Context paramContext) {
    this(paramContext, null, e.a.E);
  }
  
  public n0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public n0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.o = paramContext;
    this.P = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.l1, paramInt1, paramInt2);
    this.t = typedArray.getDimensionPixelOffset(j.m1, 0);
    int j = typedArray.getDimensionPixelOffset(j.n1, 0);
    this.u = j;
    if (j != 0)
      this.w = true; 
    typedArray.recycle();
    t t = new t(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.T = t;
    t.setInputMethodMode(1);
  }
  
  private void C() {
    View view = this.D;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.D); 
    } 
  }
  
  private void O(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = U;
      if (method != null)
        try {
          method.invoke(this.T, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      d.b(this.T, paramBoolean);
    } 
  }
  
  private int q() {
    byte b1;
    byte b2;
    j0 j01 = this.q;
    boolean bool = true;
    if (j01 == null) {
      LinearLayout.LayoutParams layoutParams1;
      LinearLayout.LayoutParams layoutParams2;
      Context context = this.o;
      this.O = new a(this);
      j0 j03 = s(context, this.S ^ true);
      this.q = j03;
      Drawable drawable1 = this.H;
      if (drawable1 != null)
        j03.setSelector(drawable1); 
      this.q.setAdapter(this.p);
      this.q.setOnItemClickListener(this.I);
      this.q.setFocusable(true);
      this.q.setFocusableInTouchMode(true);
      this.q.setOnItemSelectedListener(new b(this));
      this.q.setOnScrollListener(this.M);
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.J;
      if (onItemSelectedListener != null)
        this.q.setOnItemSelectedListener(onItemSelectedListener); 
      j0 j02 = this.q;
      View view = this.D;
      if (view != null) {
        boolean bool1;
        StringBuilder stringBuilder;
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        b1 = this.E;
        if (b1 != 0) {
          if (b1 != 1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid hint position ");
            stringBuilder.append(this.E);
            Log.e("ListPopupWindow", stringBuilder.toString());
          } else {
            linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
            linearLayout.addView(view);
          } 
        } else {
          linearLayout.addView(view);
          linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
        } 
        b1 = this.s;
        if (b1 >= 0) {
          bool1 = true;
        } else {
          b1 = 0;
          bool1 = false;
        } 
        view.measure(View.MeasureSpec.makeMeasureSpec(b1, bool1), 0);
        layoutParams2 = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
      } else {
        b1 = 0;
        layoutParams1 = layoutParams2;
      } 
      this.T.setContentView((View)layoutParams1);
    } else {
      ViewGroup viewGroup = (ViewGroup)this.T.getContentView();
      View view = this.D;
      if (view != null) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } else {
        b1 = 0;
      } 
    } 
    Drawable drawable = this.T.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.Q);
      Rect rect = this.Q;
      int n = rect.top;
      int m = rect.bottom + n;
      b2 = m;
      if (!this.w) {
        this.u = -n;
        b2 = m;
      } 
    } else {
      this.Q.setEmpty();
      b2 = 0;
    } 
    if (this.T.getInputMethodMode() != 2)
      bool = false; 
    int k = u(t(), this.u, bool);
    if (this.A || this.r == -1)
      return k + b2; 
    int j = this.s;
    if (j != -2) {
      if (j != -1) {
        j = View.MeasureSpec.makeMeasureSpec(j, 1073741824);
      } else {
        j = (this.o.getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.Q;
        j = View.MeasureSpec.makeMeasureSpec(j - rect.left + rect.right, 1073741824);
      } 
    } else {
      j = (this.o.getResources().getDisplayMetrics()).widthPixels;
      Rect rect = this.Q;
      j = View.MeasureSpec.makeMeasureSpec(j - rect.left + rect.right, -2147483648);
    } 
    k = this.q.d(j, 0, -1, k - b1, -1);
    j = b1;
    if (k > 0)
      j = b1 + b2 + this.q.getPaddingTop() + this.q.getPaddingBottom(); 
    return k + j;
  }
  
  private int u(View paramView, int paramInt, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 23) {
      Method method = V;
      if (method != null)
        try {
          return ((Integer)method.invoke(this.T, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
        }  
      return this.T.getMaxAvailableHeight(paramView, paramInt);
    } 
    return c.a(this.T, paramView, paramInt, paramBoolean);
  }
  
  public boolean A() {
    return (this.T.getInputMethodMode() == 2);
  }
  
  public boolean B() {
    return this.S;
  }
  
  public void D(View paramView) {
    this.G = paramView;
  }
  
  public void E(int paramInt) {
    this.T.setAnimationStyle(paramInt);
  }
  
  public void F(int paramInt) {
    Drawable drawable = this.T.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.Q);
      Rect rect = this.Q;
      this.s = rect.left + rect.right + paramInt;
      return;
    } 
    R(paramInt);
  }
  
  public void G(int paramInt) {
    this.z = paramInt;
  }
  
  public void H(Rect paramRect) {
    if (paramRect != null) {
      paramRect = new Rect(paramRect);
    } else {
      paramRect = null;
    } 
    this.R = paramRect;
  }
  
  public void I(int paramInt) {
    this.T.setInputMethodMode(paramInt);
  }
  
  public void J(boolean paramBoolean) {
    this.S = paramBoolean;
    this.T.setFocusable(paramBoolean);
  }
  
  public void K(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.T.setOnDismissListener(paramOnDismissListener);
  }
  
  public void L(AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.I = paramOnItemClickListener;
  }
  
  public void M(AdapterView.OnItemSelectedListener paramOnItemSelectedListener) {
    this.J = paramOnItemSelectedListener;
  }
  
  public void N(boolean paramBoolean) {
    this.y = true;
    this.x = paramBoolean;
  }
  
  public void P(int paramInt) {
    this.E = paramInt;
  }
  
  public void Q(int paramInt) {
    j0 j01 = this.q;
    if (c() && j01 != null) {
      j01.setListSelectionHidden(false);
      j01.setSelection(paramInt);
      if (j01.getChoiceMode() != 0)
        j01.setItemChecked(paramInt, true); 
    } 
  }
  
  public void R(int paramInt) {
    this.s = paramInt;
  }
  
  public void a() {
    int j;
    int k = q();
    boolean bool1 = A();
    androidx.core.widget.i.b(this.T, this.v);
    boolean bool2 = this.T.isShowing();
    boolean bool = true;
    if (bool2) {
      if (!y.U(t()))
        return; 
      int n = this.s;
      if (n == -1) {
        j = -1;
      } else {
        j = n;
        if (n == -2)
          j = t().getWidth(); 
      } 
      n = this.r;
      if (n == -1) {
        if (!bool1)
          k = -1; 
        if (bool1) {
          PopupWindow popupWindow2 = this.T;
          if (this.s == -1) {
            n = -1;
          } else {
            n = 0;
          } 
          popupWindow2.setWidth(n);
          this.T.setHeight(0);
        } else {
          PopupWindow popupWindow2 = this.T;
          if (this.s == -1) {
            n = -1;
          } else {
            n = 0;
          } 
          popupWindow2.setWidth(n);
          this.T.setHeight(-1);
        } 
      } else if (n != -2) {
        k = n;
      } 
      PopupWindow popupWindow1 = this.T;
      if (this.B || this.A)
        bool = false; 
      popupWindow1.setOutsideTouchable(bool);
      popupWindow1 = this.T;
      View view = t();
      n = this.t;
      int i1 = this.u;
      if (j < 0)
        j = -1; 
      if (k < 0)
        k = -1; 
      popupWindow1.update(view, n, i1, j, k);
      return;
    } 
    int m = this.s;
    if (m == -1) {
      j = -1;
    } else {
      j = m;
      if (m == -2)
        j = t().getWidth(); 
    } 
    m = this.r;
    if (m == -1) {
      k = -1;
    } else if (m != -2) {
      k = m;
    } 
    this.T.setWidth(j);
    this.T.setHeight(k);
    O(true);
    PopupWindow popupWindow = this.T;
    if (!this.B && !this.A) {
      bool = true;
    } else {
      bool = false;
    } 
    popupWindow.setOutsideTouchable(bool);
    this.T.setTouchInterceptor(this.L);
    if (this.y)
      androidx.core.widget.i.a(this.T, this.x); 
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = W;
      if (method != null)
        try {
          method.invoke(this.T, new Object[] { this.R });
        } catch (Exception exception) {
          Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", exception);
        }  
    } else {
      d.a(this.T, this.R);
    } 
    androidx.core.widget.i.c(this.T, t(), this.t, this.u, this.z);
    this.q.setSelection(-1);
    if (!this.S || this.q.isInTouchMode())
      r(); 
    if (!this.S)
      this.P.post(this.N); 
  }
  
  public void b(Drawable paramDrawable) {
    this.T.setBackgroundDrawable(paramDrawable);
  }
  
  public boolean c() {
    return this.T.isShowing();
  }
  
  public int d() {
    return this.t;
  }
  
  public void dismiss() {
    this.T.dismiss();
    C();
    this.T.setContentView(null);
    this.q = null;
    this.P.removeCallbacks(this.K);
  }
  
  public Drawable g() {
    return this.T.getBackground();
  }
  
  public ListView h() {
    return this.q;
  }
  
  public void j(int paramInt) {
    this.u = paramInt;
    this.w = true;
  }
  
  public void l(int paramInt) {
    this.t = paramInt;
  }
  
  public int n() {
    return !this.w ? 0 : this.u;
  }
  
  public void p(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.F;
    if (dataSetObserver == null) {
      this.F = new f(this);
    } else {
      ListAdapter listAdapter = this.p;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.p = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.F); 
    j0 j01 = this.q;
    if (j01 != null)
      j01.setAdapter(this.p); 
  }
  
  public void r() {
    j0 j01 = this.q;
    if (j01 != null) {
      j01.setListSelectionHidden(true);
      j01.requestLayout();
    } 
  }
  
  j0 s(Context paramContext, boolean paramBoolean) {
    return new j0(paramContext, paramBoolean);
  }
  
  public View t() {
    return this.G;
  }
  
  public Object v() {
    return !c() ? null : this.q.getSelectedItem();
  }
  
  public long w() {
    return !c() ? Long.MIN_VALUE : this.q.getSelectedItemId();
  }
  
  public int x() {
    return !c() ? -1 : this.q.getSelectedItemPosition();
  }
  
  public View y() {
    return !c() ? null : this.q.getSelectedView();
  }
  
  public int z() {
    return this.s;
  }
  
  class a implements Runnable {
    a(n0 this$0) {}
    
    public void run() {
      View view = this.o.t();
      if (view != null && view.getWindowToken() != null)
        this.o.a(); 
    }
  }
  
  class b implements AdapterView.OnItemSelectedListener {
    b(n0 this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int != -1) {
        j0 j0 = this.o.q;
        if (j0 != null)
          j0.setListSelectionHidden(false); 
      } 
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  static class c {
    static int a(PopupWindow param1PopupWindow, View param1View, int param1Int, boolean param1Boolean) {
      return param1PopupWindow.getMaxAvailableHeight(param1View, param1Int, param1Boolean);
    }
  }
  
  static class d {
    static void a(PopupWindow param1PopupWindow, Rect param1Rect) {
      param1PopupWindow.setEpicenterBounds(param1Rect);
    }
    
    static void b(PopupWindow param1PopupWindow, boolean param1Boolean) {
      param1PopupWindow.setIsClippedToScreen(param1Boolean);
    }
  }
  
  private class e implements Runnable {
    e(n0 this$0) {}
    
    public void run() {
      this.o.r();
    }
  }
  
  private class f extends DataSetObserver {
    f(n0 this$0) {}
    
    public void onChanged() {
      if (this.a.c())
        this.a.a(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  private class g implements AbsListView.OnScrollListener {
    g(n0 this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !this.a.A() && this.a.T.getContentView() != null) {
        n0 n01 = this.a;
        n01.P.removeCallbacks(n01.K);
        this.a.K.run();
      } 
    }
  }
  
  private class h implements View.OnTouchListener {
    h(n0 this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.o.T;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.o.T.getWidth() && k >= 0 && k < this.o.T.getHeight()) {
          n0 n01 = this.o;
          n01.P.postDelayed(n01.K, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        n0 n01 = this.o;
        n01.P.removeCallbacks(n01.K);
      } 
      return false;
    }
  }
  
  private class i implements Runnable {
    i(n0 this$0) {}
    
    public void run() {
      j0 j0 = this.o.q;
      if (j0 != null && y.U((View)j0) && this.o.q.getCount() > this.o.q.getChildCount()) {
        int j = this.o.q.getChildCount();
        n0 n01 = this.o;
        if (j <= n01.C) {
          n01.T.setInputMethodMode(2);
          this.o.a();
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */