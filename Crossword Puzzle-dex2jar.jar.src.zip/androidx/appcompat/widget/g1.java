package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.a0;
import androidx.core.view.y;

class g1 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  private static g1 y;
  
  private static g1 z;
  
  private final View o;
  
  private final CharSequence p;
  
  private final int q;
  
  private final Runnable r = new f1(this);
  
  private final Runnable s = new e1(this);
  
  private int t;
  
  private int u;
  
  private h1 v;
  
  private boolean w;
  
  private boolean x;
  
  private g1(View paramView, CharSequence paramCharSequence) {
    this.o = paramView;
    this.p = paramCharSequence;
    this.q = a0.c(ViewConfiguration.get(paramView.getContext()));
    c();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  private void b() {
    this.o.removeCallbacks(this.r);
  }
  
  private void c() {
    this.x = true;
  }
  
  private void f() {
    this.o.postDelayed(this.r, ViewConfiguration.getLongPressTimeout());
  }
  
  private static void g(g1 paramg1) {
    g1 g11 = y;
    if (g11 != null)
      g11.b(); 
    y = paramg1;
    if (paramg1 != null)
      paramg1.f(); 
  }
  
  public static void h(View paramView, CharSequence paramCharSequence) {
    g1 g11;
    g1 g12 = y;
    if (g12 != null && g12.o == paramView)
      g(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      g11 = z;
      if (g11 != null && g11.o == paramView)
        g11.d(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new g1(paramView, (CharSequence)g11);
  }
  
  private boolean j(MotionEvent paramMotionEvent) {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if (this.x || Math.abs(i - this.t) > this.q || Math.abs(j - this.u) > this.q) {
      this.t = i;
      this.u = j;
      this.x = false;
      return true;
    } 
    return false;
  }
  
  void d() {
    if (z == this) {
      z = null;
      h1 h11 = this.v;
      if (h11 != null) {
        h11.c();
        this.v = null;
        c();
        this.o.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (y == this)
      g(null); 
    this.o.removeCallbacks(this.s);
  }
  
  void i(boolean paramBoolean) {
    long l;
    if (!y.U(this.o))
      return; 
    g(null);
    g1 g11 = z;
    if (g11 != null)
      g11.d(); 
    z = this;
    this.w = paramBoolean;
    h1 h11 = new h1(this.o.getContext());
    this.v = h11;
    h11.e(this.o, this.t, this.u, this.w, this.p);
    this.o.addOnAttachStateChangeListener(this);
    if (this.w) {
      l = 2500L;
    } else {
      int i;
      if ((y.N(this.o) & 0x1) == 1) {
        l = 3000L;
        i = ViewConfiguration.getLongPressTimeout();
      } else {
        l = 15000L;
        i = ViewConfiguration.getLongPressTimeout();
      } 
      l -= i;
    } 
    this.o.removeCallbacks(this.s);
    this.o.postDelayed(this.s, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.v != null && this.w)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.o.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      c();
      d();
      return false;
    } 
    if (this.o.isEnabled() && this.v == null && j(paramMotionEvent))
      g(this); 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.t = paramView.getWidth() / 2;
    this.u = paramView.getHeight() / 2;
    i(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */