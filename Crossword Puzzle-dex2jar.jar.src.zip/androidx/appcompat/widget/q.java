package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.core.view.y;
import androidx.core.widget.f;
import e.j;
import f.a;

public class q {
  private final ImageView a;
  
  private y0 b;
  
  private y0 c;
  
  private y0 d;
  
  private int e = 0;
  
  public q(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.d == null)
      this.d = new y0(); 
    y0 y01 = this.d;
    y01.a();
    ColorStateList colorStateList = f.a(this.a);
    if (colorStateList != null) {
      y01.d = true;
      y01.a = colorStateList;
    } 
    PorterDuff.Mode mode = f.b(this.a);
    if (mode != null) {
      y01.c = true;
      y01.b = mode;
    } 
    if (y01.d || y01.c) {
      k.i(paramDrawable, y01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean l() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.b != null)) : ((i == 21));
  }
  
  void b() {
    if (this.a.getDrawable() != null)
      this.a.getDrawable().setLevel(this.e); 
  }
  
  void c() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      i0.b(drawable); 
    if (drawable != null) {
      if (l() && a(drawable))
        return; 
      y0 y01 = this.c;
      if (y01 != null) {
        k.i(drawable, y01, this.a.getDrawableState());
        return;
      } 
      y01 = this.b;
      if (y01 != null)
        k.i(drawable, y01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList d() {
    y0 y01 = this.c;
    return (y01 != null) ? y01.a : null;
  }
  
  PorterDuff.Mode e() {
    y0 y01 = this.c;
    return (y01 != null) ? y01.b : null;
  }
  
  boolean f() {
    Drawable drawable = this.a.getBackground();
    return !(Build.VERSION.SDK_INT >= 21 && drawable instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void g(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.P;
    a1 a1 = a1.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    y.p0((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, a1.r(), paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = a1.n(j.Q, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.b(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        i0.b(drawable1); 
      paramInt = j.R;
      if (a1.s(paramInt))
        f.c(this.a, a1.c(paramInt)); 
      paramInt = j.S;
      if (a1.s(paramInt))
        f.d(this.a, i0.d(a1.k(paramInt, -1), null)); 
      return;
    } finally {
      a1.w();
    } 
  }
  
  void h(Drawable paramDrawable) {
    this.e = paramDrawable.getLevel();
  }
  
  public void i(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.b(this.a.getContext(), paramInt);
      if (drawable != null)
        i0.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    c();
  }
  
  void j(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new y0(); 
    y0 y01 = this.c;
    y01.a = paramColorStateList;
    y01.d = true;
    c();
  }
  
  void k(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new y0(); 
    y0 y01 = this.c;
    y01.b = paramMode;
    y01.c = true;
    c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */