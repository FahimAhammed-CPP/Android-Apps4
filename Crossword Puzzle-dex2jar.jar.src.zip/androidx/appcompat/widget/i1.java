package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Movie;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import java.io.InputStream;
import java.lang.ref.WeakReference;

public class i1 extends r0 {
  private static boolean c = false;
  
  private final WeakReference<Context> b;
  
  public i1(Context paramContext, Resources paramResources) {
    super(paramResources);
    this.b = new WeakReference<Context>(paramContext);
  }
  
  public static boolean b() {
    return c;
  }
  
  public static boolean c() {
    return (b() && Build.VERSION.SDK_INT <= 20);
  }
  
  public Drawable getDrawable(int paramInt) {
    Context context = this.b.get();
    return (context != null) ? q0.h().t(context, this, paramInt) : a(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\i1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */