package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.view.menu.p;
import androidx.core.view.w;
import androidx.core.view.y;

public class a0 extends Spinner implements w {
  @SuppressLint({"ResourceType"})
  private static final int[] w = new int[] { 16843505 };
  
  private final e o;
  
  private final Context p;
  
  private l0 q;
  
  private SpinnerAdapter r;
  
  private final boolean s;
  
  private j t;
  
  int u;
  
  final Rect v;
  
  public a0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.K);
  }
  
  public a0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public a0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public a0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield v : Landroid/graphics/Rect;
    //   18: aload_0
    //   19: aload_0
    //   20: invokevirtual getContext : ()Landroid/content/Context;
    //   23: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   26: aload_1
    //   27: aload_2
    //   28: getstatic e/j.x2 : [I
    //   31: iload_3
    //   32: iconst_0
    //   33: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/a1;
    //   36: astore #9
    //   38: aload_0
    //   39: new androidx/appcompat/widget/e
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Landroid/view/View;)V
    //   47: putfield o : Landroidx/appcompat/widget/e;
    //   50: aload #5
    //   52: ifnull -> 72
    //   55: aload_0
    //   56: new androidx/appcompat/view/d
    //   59: dup
    //   60: aload_1
    //   61: aload #5
    //   63: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/Resources$Theme;)V
    //   66: putfield p : Landroid/content/Context;
    //   69: goto -> 110
    //   72: aload #9
    //   74: getstatic e/j.C2 : I
    //   77: iconst_0
    //   78: invokevirtual n : (II)I
    //   81: istore #6
    //   83: iload #6
    //   85: ifeq -> 105
    //   88: aload_0
    //   89: new androidx/appcompat/view/d
    //   92: dup
    //   93: aload_1
    //   94: iload #6
    //   96: invokespecial <init> : (Landroid/content/Context;I)V
    //   99: putfield p : Landroid/content/Context;
    //   102: goto -> 110
    //   105: aload_0
    //   106: aload_1
    //   107: putfield p : Landroid/content/Context;
    //   110: aconst_null
    //   111: astore #7
    //   113: iload #4
    //   115: istore #6
    //   117: iload #4
    //   119: iconst_m1
    //   120: if_icmpne -> 242
    //   123: aload_1
    //   124: aload_2
    //   125: getstatic androidx/appcompat/widget/a0.w : [I
    //   128: iload_3
    //   129: iconst_0
    //   130: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   133: astore #5
    //   135: iload #4
    //   137: istore #6
    //   139: aload #5
    //   141: astore #8
    //   143: aload #5
    //   145: astore #7
    //   147: aload #5
    //   149: iconst_0
    //   150: invokevirtual hasValue : (I)Z
    //   153: ifeq -> 173
    //   156: aload #5
    //   158: astore #7
    //   160: aload #5
    //   162: iconst_0
    //   163: iconst_0
    //   164: invokevirtual getInt : (II)I
    //   167: istore #6
    //   169: aload #5
    //   171: astore #8
    //   173: aload #8
    //   175: invokevirtual recycle : ()V
    //   178: goto -> 242
    //   181: astore #8
    //   183: goto -> 195
    //   186: astore_1
    //   187: goto -> 230
    //   190: astore #8
    //   192: aconst_null
    //   193: astore #5
    //   195: aload #5
    //   197: astore #7
    //   199: ldc 'AppCompatSpinner'
    //   201: ldc 'Could not read android:spinnerMode'
    //   203: aload #8
    //   205: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   208: pop
    //   209: iload #4
    //   211: istore #6
    //   213: aload #5
    //   215: ifnull -> 242
    //   218: iload #4
    //   220: istore #6
    //   222: aload #5
    //   224: astore #8
    //   226: goto -> 173
    //   229: astore_1
    //   230: aload #7
    //   232: ifnull -> 240
    //   235: aload #7
    //   237: invokevirtual recycle : ()V
    //   240: aload_1
    //   241: athrow
    //   242: iload #6
    //   244: ifeq -> 356
    //   247: iload #6
    //   249: iconst_1
    //   250: if_icmpeq -> 256
    //   253: goto -> 387
    //   256: new androidx/appcompat/widget/a0$h
    //   259: dup
    //   260: aload_0
    //   261: aload_0
    //   262: getfield p : Landroid/content/Context;
    //   265: aload_2
    //   266: iload_3
    //   267: invokespecial <init> : (Landroidx/appcompat/widget/a0;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   270: astore #5
    //   272: aload_0
    //   273: getfield p : Landroid/content/Context;
    //   276: aload_2
    //   277: getstatic e/j.x2 : [I
    //   280: iload_3
    //   281: iconst_0
    //   282: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/a1;
    //   285: astore #7
    //   287: aload_0
    //   288: aload #7
    //   290: getstatic e/j.B2 : I
    //   293: bipush #-2
    //   295: invokevirtual m : (II)I
    //   298: putfield u : I
    //   301: aload #5
    //   303: aload #7
    //   305: getstatic e/j.z2 : I
    //   308: invokevirtual g : (I)Landroid/graphics/drawable/Drawable;
    //   311: invokevirtual b : (Landroid/graphics/drawable/Drawable;)V
    //   314: aload #5
    //   316: aload #9
    //   318: getstatic e/j.A2 : I
    //   321: invokevirtual o : (I)Ljava/lang/String;
    //   324: invokevirtual i : (Ljava/lang/CharSequence;)V
    //   327: aload #7
    //   329: invokevirtual w : ()V
    //   332: aload_0
    //   333: aload #5
    //   335: putfield t : Landroidx/appcompat/widget/a0$j;
    //   338: aload_0
    //   339: new androidx/appcompat/widget/a0$a
    //   342: dup
    //   343: aload_0
    //   344: aload_0
    //   345: aload #5
    //   347: invokespecial <init> : (Landroidx/appcompat/widget/a0;Landroid/view/View;Landroidx/appcompat/widget/a0$h;)V
    //   350: putfield q : Landroidx/appcompat/widget/l0;
    //   353: goto -> 387
    //   356: new androidx/appcompat/widget/a0$f
    //   359: dup
    //   360: aload_0
    //   361: invokespecial <init> : (Landroidx/appcompat/widget/a0;)V
    //   364: astore #5
    //   366: aload_0
    //   367: aload #5
    //   369: putfield t : Landroidx/appcompat/widget/a0$j;
    //   372: aload #5
    //   374: aload #9
    //   376: getstatic e/j.A2 : I
    //   379: invokevirtual o : (I)Ljava/lang/String;
    //   382: invokeinterface i : (Ljava/lang/CharSequence;)V
    //   387: aload #9
    //   389: getstatic e/j.y2 : I
    //   392: invokevirtual q : (I)[Ljava/lang/CharSequence;
    //   395: astore #5
    //   397: aload #5
    //   399: ifnull -> 427
    //   402: new android/widget/ArrayAdapter
    //   405: dup
    //   406: aload_1
    //   407: ldc 17367048
    //   409: aload #5
    //   411: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   414: astore_1
    //   415: aload_1
    //   416: getstatic e/g.t : I
    //   419: invokevirtual setDropDownViewResource : (I)V
    //   422: aload_0
    //   423: aload_1
    //   424: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   427: aload #9
    //   429: invokevirtual w : ()V
    //   432: aload_0
    //   433: iconst_1
    //   434: putfield s : Z
    //   437: aload_0
    //   438: getfield r : Landroid/widget/SpinnerAdapter;
    //   441: astore_1
    //   442: aload_1
    //   443: ifnull -> 456
    //   446: aload_0
    //   447: aload_1
    //   448: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   451: aload_0
    //   452: aconst_null
    //   453: putfield r : Landroid/widget/SpinnerAdapter;
    //   456: aload_0
    //   457: getfield o : Landroidx/appcompat/widget/e;
    //   460: aload_2
    //   461: iload_3
    //   462: invokevirtual e : (Landroid/util/AttributeSet;I)V
    //   465: return
    // Exception table:
    //   from	to	target	type
    //   123	135	190	java/lang/Exception
    //   123	135	186	finally
    //   147	156	181	java/lang/Exception
    //   147	156	229	finally
    //   160	169	181	java/lang/Exception
    //   160	169	229	finally
    //   199	209	229	finally
  }
  
  int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int m = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int i1 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i2 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int k = Math.max(0, i - 15 - i2 - i);
    View view = null;
    i = 0;
    while (k < i2) {
      int i4 = paramSpinnerAdapter.getItemViewType(k);
      int i3 = m;
      if (i4 != m) {
        view = null;
        i3 = i4;
      } 
      view = paramSpinnerAdapter.getView(k, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(n, i1);
      i = Math.max(i, view.getMeasuredWidth());
      k++;
      m = i3;
    } 
    k = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.v);
      Rect rect = this.v;
      k = i + rect.left + rect.right;
    } 
    return k;
  }
  
  void b() {
    this.t.m(d.b((View)this), d.a((View)this));
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.o;
    if (e1 != null)
      e1.b(); 
  }
  
  public int getDropDownHorizontalOffset() {
    j j1 = this.t;
    return (j1 != null) ? j1.d() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    j j1 = this.t;
    return (j1 != null) ? j1.n() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.t != null) ? this.u : super.getDropDownWidth();
  }
  
  final j getInternalPopup() {
    return this.t;
  }
  
  public Drawable getPopupBackground() {
    j j1 = this.t;
    return (j1 != null) ? j1.g() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.p;
  }
  
  public CharSequence getPrompt() {
    j j1 = this.t;
    return (j1 != null) ? j1.o() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.o;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.o;
    return (e1 != null) ? e1.d() : null;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    j j1 = this.t;
    if (j1 != null && j1.c())
      this.t.dismiss(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.t != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    i i = (i)paramParcelable;
    super.onRestoreInstanceState(i.getSuperState());
    if (i.o) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new b(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    i i = new i(super.onSaveInstanceState());
    j j1 = this.t;
    if (j1 != null && j1.c()) {
      bool = true;
    } else {
      bool = false;
    } 
    i.o = bool;
    return (Parcelable)i;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    l0 l01 = this.q;
    return (l01 != null && l01.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    j j1 = this.t;
    if (j1 != null) {
      if (!j1.c())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.s) {
      this.r = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.t != null) {
      Context context2 = this.p;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.t.p(new g(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.o;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.o;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    j j1 = this.t;
    if (j1 != null) {
      j1.k(paramInt);
      this.t.l(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    j j1 = this.t;
    if (j1 != null) {
      j1.j(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.t != null) {
      this.u = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    j j1 = this.t;
    if (j1 != null) {
      j1.b(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(f.a.b(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    j j1 = this.t;
    if (j1 != null) {
      j1.i(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.o;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.o;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  class a extends l0 {
    a(a0 this$0, View param1View, a0.h param1h) {
      super(param1View);
    }
    
    public p b() {
      return this.x;
    }
    
    @SuppressLint({"SyntheticAccessor"})
    public boolean c() {
      if (!this.y.getInternalPopup().c())
        this.y.b(); 
      return true;
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(a0 this$0) {}
    
    public void onGlobalLayout() {
      if (!this.o.getInternalPopup().c())
        this.o.b(); 
      ViewTreeObserver viewTreeObserver = this.o.getViewTreeObserver();
      if (viewTreeObserver != null)
        a0.c.a(viewTreeObserver, this); 
    }
  }
  
  private static final class c {
    static void a(ViewTreeObserver param1ViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {
      param1ViewTreeObserver.removeOnGlobalLayoutListener(param1OnGlobalLayoutListener);
    }
  }
  
  private static final class d {
    static int a(View param1View) {
      return param1View.getTextAlignment();
    }
    
    static int b(View param1View) {
      return param1View.getTextDirection();
    }
    
    static void c(View param1View, int param1Int) {
      param1View.setTextAlignment(param1Int);
    }
    
    static void d(View param1View, int param1Int) {
      param1View.setTextDirection(param1Int);
    }
  }
  
  private static final class e {
    static void a(ThemedSpinnerAdapter param1ThemedSpinnerAdapter, Resources.Theme param1Theme) {
      if (param1ThemedSpinnerAdapter.getDropDownViewTheme() != param1Theme)
        param1ThemedSpinnerAdapter.setDropDownViewTheme(param1Theme); 
    }
  }
  
  class f implements j, DialogInterface.OnClickListener {
    androidx.appcompat.app.b o;
    
    private ListAdapter p;
    
    private CharSequence q;
    
    f(a0 this$0) {}
    
    public void b(Drawable param1Drawable) {
      Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }
    
    public boolean c() {
      androidx.appcompat.app.b b1 = this.o;
      return (b1 != null) ? b1.isShowing() : false;
    }
    
    public int d() {
      return 0;
    }
    
    public void dismiss() {
      androidx.appcompat.app.b b1 = this.o;
      if (b1 != null) {
        b1.dismiss();
        this.o = null;
      } 
    }
    
    public Drawable g() {
      return null;
    }
    
    public void i(CharSequence param1CharSequence) {
      this.q = param1CharSequence;
    }
    
    public void j(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }
    
    public void k(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
    
    public void l(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }
    
    public void m(int param1Int1, int param1Int2) {
      if (this.p == null)
        return; 
      androidx.appcompat.app.b.a a = new androidx.appcompat.app.b.a(this.r.getPopupContext());
      CharSequence charSequence = this.q;
      if (charSequence != null)
        a.l(charSequence); 
      androidx.appcompat.app.b b1 = a.k(this.p, this.r.getSelectedItemPosition(), this).a();
      this.o = b1;
      ListView listView = b1.n();
      a0.d.d((View)listView, param1Int1);
      a0.d.c((View)listView, param1Int2);
      this.o.show();
    }
    
    public int n() {
      return 0;
    }
    
    public CharSequence o() {
      return this.q;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.r.setSelection(param1Int);
      if (this.r.getOnItemClickListener() != null)
        this.r.performItemClick(null, param1Int, this.p.getItemId(param1Int)); 
      dismiss();
    }
    
    public void p(ListAdapter param1ListAdapter) {
      this.p = param1ListAdapter;
    }
  }
  
  private static class g implements ListAdapter, SpinnerAdapter {
    private SpinnerAdapter o;
    
    private ListAdapter p;
    
    public g(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.o = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.p = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        if (Build.VERSION.SDK_INT >= 23 && param1SpinnerAdapter instanceof ThemedSpinnerAdapter) {
          a0.e.a((ThemedSpinnerAdapter)param1SpinnerAdapter, param1Theme);
          return;
        } 
        if (param1SpinnerAdapter instanceof w0) {
          param1SpinnerAdapter = param1SpinnerAdapter;
          if (param1SpinnerAdapter.getDropDownViewTheme() == null)
            param1SpinnerAdapter.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.p;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.o;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.o;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.o;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.o;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.o;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.p;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.o;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.o;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  class h extends n0 implements j {
    private CharSequence X;
    
    ListAdapter Y;
    
    private final Rect Z = new Rect();
    
    private int a0;
    
    public h(a0 this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
      D((View)this$0);
      J(true);
      P(0);
      L(new a(this, this$0));
    }
    
    void T() {
      Drawable drawable = g();
      int i = 0;
      if (drawable != null) {
        drawable.getPadding(this.b0.v);
        if (j1.b((View)this.b0)) {
          i = this.b0.v.right;
        } else {
          i = -this.b0.v.left;
        } 
      } else {
        Rect rect = this.b0.v;
        rect.right = 0;
        rect.left = 0;
      } 
      int m = this.b0.getPaddingLeft();
      int n = this.b0.getPaddingRight();
      int i1 = this.b0.getWidth();
      a0 a01 = this.b0;
      int k = a01.u;
      if (k == -2) {
        int i2 = a01.a((SpinnerAdapter)this.Y, g());
        k = (this.b0.getContext().getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.b0.v;
        int i3 = k - rect.left - rect.right;
        k = i2;
        if (i2 > i3)
          k = i3; 
        F(Math.max(k, i1 - m - n));
      } else if (k == -1) {
        F(i1 - m - n);
      } else {
        F(k);
      } 
      if (j1.b((View)this.b0)) {
        i += i1 - n - z() - U();
      } else {
        i += m + U();
      } 
      l(i);
    }
    
    public int U() {
      return this.a0;
    }
    
    boolean V(View param1View) {
      return (y.U(param1View) && param1View.getGlobalVisibleRect(this.Z));
    }
    
    public void i(CharSequence param1CharSequence) {
      this.X = param1CharSequence;
    }
    
    public void k(int param1Int) {
      this.a0 = param1Int;
    }
    
    public void m(int param1Int1, int param1Int2) {
      boolean bool = c();
      T();
      I(2);
      a();
      ListView listView = h();
      listView.setChoiceMode(1);
      a0.d.d((View)listView, param1Int1);
      a0.d.c((View)listView, param1Int2);
      Q(this.b0.getSelectedItemPosition());
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.b0.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        K(new c(this, b));
      } 
    }
    
    public CharSequence o() {
      return this.X;
    }
    
    public void p(ListAdapter param1ListAdapter) {
      super.p(param1ListAdapter);
      this.Y = param1ListAdapter;
    }
    
    class a implements AdapterView.OnItemClickListener {
      a(a0.h this$0, a0 param2a0) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.p.b0.setSelection(param2Int);
        if (this.p.b0.getOnItemClickListener() != null) {
          a0.h h1 = this.p;
          h1.b0.performItemClick(param2View, param2Int, h1.Y.getItemId(param2Int));
        } 
        this.p.dismiss();
      }
    }
    
    class b implements ViewTreeObserver.OnGlobalLayoutListener {
      b(a0.h this$0) {}
      
      public void onGlobalLayout() {
        a0.h h1 = this.o;
        if (!h1.V((View)h1.b0)) {
          this.o.dismiss();
          return;
        } 
        this.o.T();
        a0.h.S(this.o);
      }
    }
    
    class c implements PopupWindow.OnDismissListener {
      c(a0.h this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.p.b0.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.o); 
      }
    }
  }
  
  class a implements AdapterView.OnItemClickListener {
    a(a0 this$0, a0 param1a0) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.p.b0.setSelection(param1Int);
      if (this.p.b0.getOnItemClickListener() != null) {
        a0.h h1 = this.p;
        h1.b0.performItemClick(param1View, param1Int, h1.Y.getItemId(param1Int));
      } 
      this.p.dismiss();
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(a0 this$0) {}
    
    public void onGlobalLayout() {
      a0.h h1 = this.o;
      if (!h1.V((View)h1.b0)) {
        this.o.dismiss();
        return;
      } 
      this.o.T();
      a0.h.S(this.o);
    }
  }
  
  class c implements PopupWindow.OnDismissListener {
    c(a0 this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.p.b0.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.o); 
    }
  }
  
  static class i extends View.BaseSavedState {
    public static final Parcelable.Creator<i> CREATOR = new a();
    
    boolean o;
    
    i(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.o = bool;
    }
    
    i(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.o);
    }
    
    class a implements Parcelable.Creator<i> {
      public a0.i a(Parcel param2Parcel) {
        return new a0.i(param2Parcel);
      }
      
      public a0.i[] b(int param2Int) {
        return new a0.i[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<i> {
    public a0.i a(Parcel param1Parcel) {
      return new a0.i(param1Parcel);
    }
    
    public a0.i[] b(int param1Int) {
      return new a0.i[param1Int];
    }
  }
  
  static interface j {
    void b(Drawable param1Drawable);
    
    boolean c();
    
    int d();
    
    void dismiss();
    
    Drawable g();
    
    void i(CharSequence param1CharSequence);
    
    void j(int param1Int);
    
    void k(int param1Int);
    
    void l(int param1Int);
    
    void m(int param1Int1, int param1Int2);
    
    int n();
    
    CharSequence o();
    
    void p(ListAdapter param1ListAdapter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */