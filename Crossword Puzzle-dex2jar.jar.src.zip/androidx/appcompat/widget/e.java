package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.view.y;
import e.j;

class e {
  private final View a;
  
  private final k b;
  
  private int c = -1;
  
  private y0 d;
  
  private y0 e;
  
  private y0 f;
  
  e(View paramView) {
    this.a = paramView;
    this.b = k.b();
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new y0(); 
    y0 y01 = this.f;
    y01.a();
    ColorStateList colorStateList = y.u(this.a);
    if (colorStateList != null) {
      y01.d = true;
      y01.a = colorStateList;
    } 
    PorterDuff.Mode mode = y.v(this.a);
    if (mode != null) {
      y01.c = true;
      y01.b = mode;
    } 
    if (y01.d || y01.c) {
      k.i(paramDrawable, y01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.d != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      y0 y01 = this.e;
      if (y01 != null) {
        k.i(drawable, y01, this.a.getDrawableState());
        return;
      } 
      y01 = this.d;
      if (y01 != null)
        k.i(drawable, y01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    y0 y01 = this.e;
    return (y01 != null) ? y01.a : null;
  }
  
  PorterDuff.Mode d() {
    y0 y01 = this.e;
    return (y01 != null) ? y01.b : null;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.y3;
    a1 a1 = a1.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    View view = this.a;
    y.p0(view, view.getContext(), arrayOfInt, paramAttributeSet, a1.r(), paramInt, 0);
    try {
      paramInt = j.z3;
      if (a1.s(paramInt)) {
        this.c = a1.n(paramInt, -1);
        ColorStateList colorStateList = this.b.f(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.A3;
      if (a1.s(paramInt))
        y.w0(this.a, a1.c(paramInt)); 
      paramInt = j.B3;
      if (a1.s(paramInt))
        y.x0(this.a, i0.d(a1.k(paramInt, -1), null)); 
      return;
    } finally {
      a1.w();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    k k1 = this.b;
    if (k1 != null) {
      ColorStateList colorStateList = k1.f(this.a.getContext(), paramInt);
    } else {
      k1 = null;
    } 
    h((ColorStateList)k1);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new y0(); 
      y0 y01 = this.d;
      y01.a = paramColorStateList;
      y01.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new y0(); 
    y0 y01 = this.e;
    y01.a = paramColorStateList;
    y01.d = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new y0(); 
    y0 y01 = this.e;
    y01.b = paramMode;
    y01.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */