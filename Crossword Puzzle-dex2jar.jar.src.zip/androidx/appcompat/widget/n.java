package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.TextView;
import e.j;
import e0.f;

class n {
  private final TextView a;
  
  private final f b;
  
  n(TextView paramTextView) {
    this.a = paramTextView;
    this.b = new f(paramTextView, false);
  }
  
  InputFilter[] a(InputFilter[] paramArrayOfInputFilter) {
    return this.b.a(paramArrayOfInputFilter);
  }
  
  void b(AttributeSet paramAttributeSet, int paramInt) {
    TypedArray typedArray = this.a.getContext().obtainStyledAttributes(paramAttributeSet, j.g0, paramInt, 0);
    try {
      paramInt = j.u0;
      boolean bool2 = typedArray.hasValue(paramInt);
      boolean bool1 = true;
      if (bool2)
        bool1 = typedArray.getBoolean(paramInt, true); 
      typedArray.recycle();
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  void c(boolean paramBoolean) {
    this.b.b(paramBoolean);
  }
  
  void d(boolean paramBoolean) {
    this.b.c(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */