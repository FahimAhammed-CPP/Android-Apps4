package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.core.view.w;
import androidx.core.widget.o;

public class r extends ImageView implements w, o {
  private final e o;
  
  private final q p;
  
  private boolean q = false;
  
  public r(Context paramContext) {
    this(paramContext, null);
  }
  
  public r(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public r(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(x0.b(paramContext), paramAttributeSet, paramInt);
    v0.a((View)this, getContext());
    e e1 = new e((View)this);
    this.o = e1;
    e1.e(paramAttributeSet, paramInt);
    q q1 = new q(this);
    this.p = q1;
    q1.g(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.o;
    if (e1 != null)
      e1.b(); 
    q q1 = this.p;
    if (q1 != null)
      q1.c(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.o;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.o;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    q q1 = this.p;
    return (q1 != null) ? q1.d() : null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    q q1 = this.p;
    return (q1 != null) ? q1.e() : null;
  }
  
  public boolean hasOverlappingRendering() {
    return (this.p.f() && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.o;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.o;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    q q1 = this.p;
    if (q1 != null)
      q1.c(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    q q2 = this.p;
    if (q2 != null && paramDrawable != null && !this.q)
      q2.h(paramDrawable); 
    super.setImageDrawable(paramDrawable);
    q q1 = this.p;
    if (q1 != null) {
      q1.c();
      if (!this.q)
        this.p.b(); 
    } 
  }
  
  public void setImageLevel(int paramInt) {
    super.setImageLevel(paramInt);
    this.q = true;
  }
  
  public void setImageResource(int paramInt) {
    q q1 = this.p;
    if (q1 != null)
      q1.i(paramInt); 
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    q q1 = this.p;
    if (q1 != null)
      q1.c(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.o;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.o;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    q q1 = this.p;
    if (q1 != null)
      q1.j(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    q q1 = this.p;
    if (q1 != null)
      q1.k(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */