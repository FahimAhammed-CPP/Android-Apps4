package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import e.c;
import e.d;
import e.e;

public final class k {
  private static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;
  
  private static k c;
  
  private q0 a;
  
  public static k b() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/k
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   6: ifnonnull -> 12
    //   9: invokestatic h : ()V
    //   12: getstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   15: astore_0
    //   16: ldc androidx/appcompat/widget/k
    //   18: monitorexit
    //   19: aload_0
    //   20: areturn
    //   21: astore_0
    //   22: ldc androidx/appcompat/widget/k
    //   24: monitorexit
    //   25: aload_0
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   3	12	21	finally
    //   12	16	21	finally
  }
  
  public static PorterDuffColorFilter e(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/k
    //   2: monitorenter
    //   3: iload_0
    //   4: aload_1
    //   5: invokestatic l : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   8: astore_1
    //   9: ldc androidx/appcompat/widget/k
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: ldc androidx/appcompat/widget/k
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	14	finally
  }
  
  public static void h() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/k
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   6: ifnonnull -> 44
    //   9: new androidx/appcompat/widget/k
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   21: aload_0
    //   22: invokestatic h : ()Landroidx/appcompat/widget/q0;
    //   25: putfield a : Landroidx/appcompat/widget/q0;
    //   28: getstatic androidx/appcompat/widget/k.c : Landroidx/appcompat/widget/k;
    //   31: getfield a : Landroidx/appcompat/widget/q0;
    //   34: new androidx/appcompat/widget/k$a
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: invokevirtual u : (Landroidx/appcompat/widget/q0$f;)V
    //   44: ldc androidx/appcompat/widget/k
    //   46: monitorexit
    //   47: return
    //   48: astore_0
    //   49: ldc androidx/appcompat/widget/k
    //   51: monitorexit
    //   52: aload_0
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   3	44	48	finally
  }
  
  static void i(Drawable paramDrawable, y0 paramy0, int[] paramArrayOfint) {
    q0.w(paramDrawable, paramy0, paramArrayOfint);
  }
  
  public Drawable c(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/q0;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual j : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  Drawable d(Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/q0;
    //   6: aload_1
    //   7: iload_2
    //   8: iload_3
    //   9: invokevirtual k : (Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  ColorStateList f(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/q0;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual m : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public void g(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/q0;
    //   6: aload_1
    //   7: invokevirtual s : (Landroid/content/Context;)V
    //   10: aload_0
    //   11: monitorexit
    //   12: return
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	13	finally
  }
  
  class a implements q0.f {
    private final int[] a = new int[] { e.R, e.P, e.a };
    
    private final int[] b = new int[] { e.o, e.B, e.t, e.p, e.q, e.s, e.r };
    
    private final int[] c = new int[] { e.O, e.Q, e.k, e.K, e.L, e.M, e.N };
    
    private final int[] d = new int[] { e.w, e.i, e.v };
    
    private final int[] e = new int[] { e.J, e.S };
    
    private final int[] f = new int[] { e.c, e.g, e.d, e.h };
    
    private boolean f(int[] param1ArrayOfint, int param1Int) {
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++) {
        if (param1ArrayOfint[i] == param1Int)
          return true; 
      } 
      return false;
    }
    
    private ColorStateList g(Context param1Context) {
      return h(param1Context, 0);
    }
    
    private ColorStateList h(Context param1Context, int param1Int) {
      int k = v0.c(param1Context, e.a.w);
      int i = v0.b(param1Context, e.a.u);
      int[] arrayOfInt1 = v0.b;
      int[] arrayOfInt2 = v0.e;
      int j = androidx.core.graphics.a.f(k, param1Int);
      int[] arrayOfInt3 = v0.c;
      k = androidx.core.graphics.a.f(k, param1Int);
      return new ColorStateList(new int[][] { arrayOfInt1, arrayOfInt2, arrayOfInt3, v0.i }, new int[] { i, j, k, param1Int });
    }
    
    private ColorStateList i(Context param1Context) {
      return h(param1Context, v0.c(param1Context, e.a.t));
    }
    
    private ColorStateList j(Context param1Context) {
      return h(param1Context, v0.c(param1Context, e.a.u));
    }
    
    private ColorStateList k(Context param1Context) {
      int[][] arrayOfInt = new int[3][];
      int[] arrayOfInt1 = new int[3];
      int i = e.a.y;
      ColorStateList colorStateList = v0.e(param1Context, i);
      if (colorStateList != null && colorStateList.isStateful()) {
        arrayOfInt[0] = v0.b;
        arrayOfInt1[0] = colorStateList.getColorForState(arrayOfInt[0], 0);
        arrayOfInt[1] = v0.f;
        arrayOfInt1[1] = v0.c(param1Context, e.a.v);
        arrayOfInt[2] = v0.i;
        arrayOfInt1[2] = colorStateList.getDefaultColor();
      } else {
        arrayOfInt[0] = v0.b;
        arrayOfInt1[0] = v0.b(param1Context, i);
        arrayOfInt[1] = v0.f;
        arrayOfInt1[1] = v0.c(param1Context, e.a.v);
        arrayOfInt[2] = v0.i;
        arrayOfInt1[2] = v0.c(param1Context, i);
      } 
      return new ColorStateList(arrayOfInt, arrayOfInt1);
    }
    
    private LayerDrawable l(q0 param1q0, Context param1Context, int param1Int) {
      BitmapDrawable bitmapDrawable1;
      BitmapDrawable bitmapDrawable2;
      BitmapDrawable bitmapDrawable3;
      param1Int = param1Context.getResources().getDimensionPixelSize(param1Int);
      Drawable drawable2 = param1q0.j(param1Context, e.F);
      Drawable drawable1 = param1q0.j(param1Context, e.G);
      if (drawable2 instanceof BitmapDrawable && drawable2.getIntrinsicWidth() == param1Int && drawable2.getIntrinsicHeight() == param1Int) {
        bitmapDrawable1 = (BitmapDrawable)drawable2;
        bitmapDrawable2 = new BitmapDrawable(bitmapDrawable1.getBitmap());
      } else {
        Bitmap bitmap = Bitmap.createBitmap(param1Int, param1Int, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable2.setBounds(0, 0, param1Int, param1Int);
        drawable2.draw(canvas);
        bitmapDrawable1 = new BitmapDrawable(bitmap);
        bitmapDrawable2 = new BitmapDrawable(bitmap);
      } 
      bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
      if (drawable1 instanceof BitmapDrawable && drawable1.getIntrinsicWidth() == param1Int && drawable1.getIntrinsicHeight() == param1Int) {
        bitmapDrawable3 = (BitmapDrawable)drawable1;
      } else {
        Bitmap bitmap = Bitmap.createBitmap(param1Int, param1Int, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        bitmapDrawable3.setBounds(0, 0, param1Int, param1Int);
        bitmapDrawable3.draw(canvas);
        bitmapDrawable3 = new BitmapDrawable(bitmap);
      } 
      LayerDrawable layerDrawable = new LayerDrawable(new Drawable[] { (Drawable)bitmapDrawable1, (Drawable)bitmapDrawable3, (Drawable)bitmapDrawable2 });
      layerDrawable.setId(0, 16908288);
      layerDrawable.setId(1, 16908303);
      layerDrawable.setId(2, 16908301);
      return layerDrawable;
    }
    
    private void m(Drawable param1Drawable, int param1Int, PorterDuff.Mode param1Mode) {
      Drawable drawable = param1Drawable;
      if (i0.a(param1Drawable))
        drawable = param1Drawable.mutate(); 
      PorterDuff.Mode mode = param1Mode;
      if (param1Mode == null)
        mode = k.a(); 
      drawable.setColorFilter((ColorFilter)k.e(param1Int, mode));
    }
    
    public boolean a(Context param1Context, int param1Int, Drawable param1Drawable) {
      // Byte code:
      //   0: invokestatic a : ()Landroid/graphics/PorterDuff$Mode;
      //   3: astore #7
      //   5: aload_0
      //   6: aload_0
      //   7: getfield a : [I
      //   10: iload_2
      //   11: invokespecial f : ([II)Z
      //   14: istore #6
      //   16: ldc_w 16842801
      //   19: istore #4
      //   21: iload #6
      //   23: ifeq -> 39
      //   26: getstatic e/a.x : I
      //   29: istore_2
      //   30: iconst_m1
      //   31: istore #4
      //   33: iconst_1
      //   34: istore #5
      //   36: goto -> 124
      //   39: aload_0
      //   40: aload_0
      //   41: getfield c : [I
      //   44: iload_2
      //   45: invokespecial f : ([II)Z
      //   48: ifeq -> 58
      //   51: getstatic e/a.v : I
      //   54: istore_2
      //   55: goto -> 30
      //   58: aload_0
      //   59: aload_0
      //   60: getfield d : [I
      //   63: iload_2
      //   64: invokespecial f : ([II)Z
      //   67: ifeq -> 81
      //   70: getstatic android/graphics/PorterDuff$Mode.MULTIPLY : Landroid/graphics/PorterDuff$Mode;
      //   73: astore #7
      //   75: iload #4
      //   77: istore_2
      //   78: goto -> 30
      //   81: iload_2
      //   82: getstatic e/e.u : I
      //   85: if_icmpne -> 103
      //   88: ldc_w 16842800
      //   91: istore_2
      //   92: ldc_w 40.8
      //   95: invokestatic round : (F)I
      //   98: istore #4
      //   100: goto -> 33
      //   103: iload_2
      //   104: getstatic e/e.l : I
      //   107: if_icmpne -> 116
      //   110: iload #4
      //   112: istore_2
      //   113: goto -> 30
      //   116: iconst_m1
      //   117: istore #4
      //   119: iconst_0
      //   120: istore #5
      //   122: iconst_0
      //   123: istore_2
      //   124: iload #5
      //   126: ifeq -> 175
      //   129: aload_3
      //   130: astore #8
      //   132: aload_3
      //   133: invokestatic a : (Landroid/graphics/drawable/Drawable;)Z
      //   136: ifeq -> 145
      //   139: aload_3
      //   140: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
      //   143: astore #8
      //   145: aload #8
      //   147: aload_1
      //   148: iload_2
      //   149: invokestatic c : (Landroid/content/Context;I)I
      //   152: aload #7
      //   154: invokestatic e : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
      //   157: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
      //   160: iload #4
      //   162: iconst_m1
      //   163: if_icmpeq -> 173
      //   166: aload #8
      //   168: iload #4
      //   170: invokevirtual setAlpha : (I)V
      //   173: iconst_1
      //   174: ireturn
      //   175: iconst_0
      //   176: ireturn
    }
    
    public PorterDuff.Mode b(int param1Int) {
      return (param1Int == e.H) ? PorterDuff.Mode.MULTIPLY : null;
    }
    
    public Drawable c(q0 param1q0, Context param1Context, int param1Int) {
      return (Drawable)((param1Int == e.j) ? new LayerDrawable(new Drawable[] { param1q0.j(param1Context, e.i), param1q0.j(param1Context, e.k) }) : ((param1Int == e.y) ? l(param1q0, param1Context, d.i) : ((param1Int == e.x) ? l(param1q0, param1Context, d.j) : ((param1Int == e.z) ? l(param1q0, param1Context, d.k) : null))));
    }
    
    public ColorStateList d(Context param1Context, int param1Int) {
      return (param1Int == e.m) ? f.a.a(param1Context, c.e) : ((param1Int == e.I) ? f.a.a(param1Context, c.h) : ((param1Int == e.H) ? k(param1Context) : ((param1Int == e.f) ? j(param1Context) : ((param1Int == e.b) ? g(param1Context) : ((param1Int == e.e) ? i(param1Context) : ((param1Int == e.D || param1Int == e.E) ? f.a.a(param1Context, c.g) : (f(this.b, param1Int) ? v0.e(param1Context, e.a.x) : (f(this.e, param1Int) ? f.a.a(param1Context, c.d) : (f(this.f, param1Int) ? f.a.a(param1Context, c.c) : ((param1Int == e.A) ? f.a.a(param1Context, c.f) : null))))))))));
    }
    
    public boolean e(Context param1Context, int param1Int, Drawable param1Drawable) {
      LayerDrawable layerDrawable;
      if (param1Int == e.C) {
        layerDrawable = (LayerDrawable)param1Drawable;
        Drawable drawable = layerDrawable.findDrawableByLayerId(16908288);
        param1Int = e.a.x;
        m(drawable, v0.c(param1Context, param1Int), k.a());
        m(layerDrawable.findDrawableByLayerId(16908303), v0.c(param1Context, param1Int), k.a());
        m(layerDrawable.findDrawableByLayerId(16908301), v0.c(param1Context, e.a.v), k.a());
        return true;
      } 
      if (param1Int == e.y || param1Int == e.x || param1Int == e.z) {
        layerDrawable = layerDrawable;
        m(layerDrawable.findDrawableByLayerId(16908288), v0.b(param1Context, e.a.x), k.a());
        Drawable drawable = layerDrawable.findDrawableByLayerId(16908303);
        param1Int = e.a.v;
        m(drawable, v0.c(param1Context, param1Int), k.a());
        m(layerDrawable.findDrawableByLayerId(16908301), v0.c(param1Context, param1Int), k.a());
        return true;
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */