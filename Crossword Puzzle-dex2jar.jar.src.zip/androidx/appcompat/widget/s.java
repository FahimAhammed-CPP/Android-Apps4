package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import androidx.core.view.w;
import androidx.core.widget.n;
import e.a;
import f.a;

public class s extends MultiAutoCompleteTextView implements w, n {
  private static final int[] r = new int[] { 16843126 };
  
  private final e o;
  
  private final c0 p;
  
  private final m q;
  
  public s(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.p);
  }
  
  public s(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(x0.b(paramContext), paramAttributeSet, paramInt);
    v0.a((View)this, getContext());
    a1 a1 = a1.v(getContext(), paramAttributeSet, r, paramInt, 0);
    if (a1.s(0))
      setDropDownBackgroundDrawable(a1.g(0)); 
    a1.w();
    e e1 = new e((View)this);
    this.o = e1;
    e1.e(paramAttributeSet, paramInt);
    c0 c01 = new c0((TextView)this);
    this.p = c01;
    c01.m(paramAttributeSet, paramInt);
    c01.b();
    m m1 = new m((EditText)this);
    this.q = m1;
    m1.c(paramAttributeSet, paramInt);
    a(m1);
  }
  
  void a(m paramm) {
    KeyListener keyListener = getKeyListener();
    if (paramm.b(keyListener)) {
      boolean bool1 = isFocusable();
      boolean bool2 = isClickable();
      boolean bool3 = isLongClickable();
      int i = getInputType();
      KeyListener keyListener1 = paramm.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(i);
      setFocusable(bool1);
      setClickable(bool2);
      setLongClickable(bool3);
    } 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.o;
    if (e1 != null)
      e1.b(); 
    c0 c01 = this.p;
    if (c01 != null)
      c01.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.o;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.o;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.p.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.p.k();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = o.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
    return this.q.d(inputConnection, paramEditorInfo);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.o;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.o;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(a.b(getContext(), paramInt));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.q.e(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.q.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.o;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.o;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.p.w(paramColorStateList);
    this.p.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.p.x(paramMode);
    this.p.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.p;
    if (c01 != null)
      c01.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */