package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.view.b;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.view.e0;
import androidx.core.view.y;
import e.f;
import e.g;
import e.j;

public class ActionBarContextView extends a {
  private View A;
  
  private LinearLayout B;
  
  private TextView C;
  
  private TextView D;
  
  private int E;
  
  private int F;
  
  private boolean G;
  
  private int H;
  
  private CharSequence w;
  
  private CharSequence x;
  
  private View y;
  
  private View z;
  
  public ActionBarContextView(Context paramContext) {
    this(paramContext, null);
  }
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.j);
  }
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    a1 a1 = a1.v(paramContext, paramAttributeSet, j.y, paramInt, 0);
    y.v0((View)this, a1.g(j.z));
    this.E = a1.n(j.D, 0);
    this.F = a1.n(j.C, 0);
    this.s = a1.m(j.B, 0);
    this.H = a1.n(j.A, g.d);
    a1.w();
  }
  
  private void i() {
    if (this.B == null) {
      LayoutInflater.from(getContext()).inflate(g.a, this);
      LinearLayout linearLayout1 = (LinearLayout)getChildAt(getChildCount() - 1);
      this.B = linearLayout1;
      this.C = (TextView)linearLayout1.findViewById(f.e);
      this.D = (TextView)this.B.findViewById(f.d);
      if (this.E != 0)
        this.C.setTextAppearance(getContext(), this.E); 
      if (this.F != 0)
        this.D.setTextAppearance(getContext(), this.F); 
    } 
    this.C.setText(this.w);
    this.D.setText(this.x);
    boolean bool1 = TextUtils.isEmpty(this.w);
    int i = TextUtils.isEmpty(this.x) ^ true;
    TextView textView = this.D;
    boolean bool = false;
    if (i != 0) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    LinearLayout linearLayout = this.B;
    byte b = bool;
    if ((bool1 ^ true) == 0)
      if (i != 0) {
        b = bool;
      } else {
        b = 8;
      }  
    linearLayout.setVisibility(b);
    if (this.B.getParent() == null)
      addView((View)this.B); 
  }
  
  public void g() {
    if (this.y == null)
      k(); 
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-1, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }
  
  public CharSequence getSubtitle() {
    return this.x;
  }
  
  public CharSequence getTitle() {
    return this.w;
  }
  
  public void h(b paramb) {
    View view = this.y;
    if (view == null) {
      view = LayoutInflater.from(getContext()).inflate(this.H, this, false);
      this.y = view;
      addView(view);
    } else if (view.getParent() == null) {
      addView(this.y);
    } 
    view = this.y.findViewById(f.i);
    this.z = view;
    view.setOnClickListener(new a(this, paramb));
    g g = (g)paramb.e();
    c c = this.r;
    if (c != null)
      c.y(); 
    c = new c(getContext());
    this.r = c;
    c.J(true);
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
    g.c((m)this.r, this.p);
    ActionMenuView actionMenuView = (ActionMenuView)this.r.o(this);
    this.q = actionMenuView;
    y.v0((View)actionMenuView, null);
    addView((View)this.q, layoutParams);
  }
  
  public boolean j() {
    return this.G;
  }
  
  public void k() {
    removeAllViews();
    this.A = null;
    this.q = null;
    this.r = null;
    View view = this.z;
    if (view != null)
      view.setOnClickListener(null); 
  }
  
  public boolean l() {
    c c = this.r;
    return (c != null) ? c.K() : false;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    c c = this.r;
    if (c != null) {
      c.B();
      this.r.C();
    } 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    paramBoolean = j1.b((View)this);
    if (paramBoolean) {
      i = paramInt3 - paramInt1 - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    View view2 = this.y;
    paramInt2 = i;
    if (view2 != null) {
      paramInt2 = i;
      if (view2.getVisibility() != 8) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.y.getLayoutParams();
        if (paramBoolean) {
          paramInt2 = marginLayoutParams.rightMargin;
        } else {
          paramInt2 = marginLayoutParams.leftMargin;
        } 
        if (paramBoolean) {
          paramInt4 = marginLayoutParams.leftMargin;
        } else {
          paramInt4 = marginLayoutParams.rightMargin;
        } 
        paramInt2 = a.d(i, paramInt2, paramBoolean);
        paramInt2 = a.d(paramInt2 + e(this.y, paramInt2, j, k, paramBoolean), paramInt4, paramBoolean);
      } 
    } 
    LinearLayout linearLayout = this.B;
    paramInt4 = paramInt2;
    if (linearLayout != null) {
      paramInt4 = paramInt2;
      if (this.A == null) {
        paramInt4 = paramInt2;
        if (linearLayout.getVisibility() != 8)
          paramInt4 = paramInt2 + e((View)this.B, paramInt2, j, k, paramBoolean); 
      } 
    } 
    View view1 = this.A;
    if (view1 != null)
      e(view1, paramInt4, j, k, paramBoolean); 
    if (paramBoolean) {
      paramInt1 = getPaddingLeft();
    } else {
      paramInt1 = paramInt3 - paramInt1 - getPaddingRight();
    } 
    ActionMenuView actionMenuView = this.q;
    if (actionMenuView != null)
      e((View)actionMenuView, paramInt1, j, k, paramBoolean ^ true); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = 1073741824;
    if (i == 1073741824) {
      if (View.MeasureSpec.getMode(paramInt2) != 0) {
        int n = View.MeasureSpec.getSize(paramInt1);
        i = this.s;
        if (i <= 0)
          i = View.MeasureSpec.getSize(paramInt2); 
        int i1 = getPaddingTop() + getPaddingBottom();
        paramInt1 = n - getPaddingLeft() - getPaddingRight();
        int m = i - i1;
        int k = View.MeasureSpec.makeMeasureSpec(m, -2147483648);
        View view2 = this.y;
        boolean bool = false;
        paramInt2 = paramInt1;
        if (view2 != null) {
          paramInt1 = c(view2, paramInt1, k, 0);
          ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.y.getLayoutParams();
          paramInt2 = paramInt1 - marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
        } 
        ActionMenuView actionMenuView = this.q;
        paramInt1 = paramInt2;
        if (actionMenuView != null) {
          paramInt1 = paramInt2;
          if (actionMenuView.getParent() == this)
            paramInt1 = c((View)this.q, paramInt2, k, 0); 
        } 
        LinearLayout linearLayout = this.B;
        paramInt2 = paramInt1;
        if (linearLayout != null) {
          paramInt2 = paramInt1;
          if (this.A == null)
            if (this.G) {
              paramInt2 = View.MeasureSpec.makeMeasureSpec(0, 0);
              this.B.measure(paramInt2, k);
              int i2 = this.B.getMeasuredWidth();
              if (i2 <= paramInt1) {
                k = 1;
              } else {
                k = 0;
              } 
              paramInt2 = paramInt1;
              if (k != 0)
                paramInt2 = paramInt1 - i2; 
              linearLayout = this.B;
              if (k != 0) {
                paramInt1 = 0;
              } else {
                paramInt1 = 8;
              } 
              linearLayout.setVisibility(paramInt1);
            } else {
              paramInt2 = c((View)linearLayout, paramInt1, k, 0);
            }  
        } 
        View view1 = this.A;
        if (view1 != null) {
          ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
          int i2 = layoutParams.width;
          if (i2 != -2) {
            paramInt1 = 1073741824;
          } else {
            paramInt1 = Integer.MIN_VALUE;
          } 
          k = paramInt2;
          if (i2 >= 0)
            k = Math.min(i2, paramInt2); 
          i2 = layoutParams.height;
          if (i2 != -2) {
            paramInt2 = j;
          } else {
            paramInt2 = Integer.MIN_VALUE;
          } 
          j = m;
          if (i2 >= 0)
            j = Math.min(i2, m); 
          this.A.measure(View.MeasureSpec.makeMeasureSpec(k, paramInt1), View.MeasureSpec.makeMeasureSpec(j, paramInt2));
        } 
        if (this.s <= 0) {
          j = getChildCount();
          paramInt2 = 0;
          paramInt1 = bool;
          while (paramInt1 < j) {
            k = getChildAt(paramInt1).getMeasuredHeight() + i1;
            i = paramInt2;
            if (k > paramInt2)
              i = k; 
            paramInt1++;
            paramInt2 = i;
          } 
          setMeasuredDimension(n, paramInt2);
          return;
        } 
        setMeasuredDimension(n, i);
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getClass().getSimpleName());
      stringBuilder1.append(" can only be used with android:layout_height=\"wrap_content\"");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
    IllegalStateException illegalStateException = new IllegalStateException(stringBuilder.toString());
    throw illegalStateException;
  }
  
  public void setContentHeight(int paramInt) {
    this.s = paramInt;
  }
  
  public void setCustomView(View paramView) {
    View view = this.A;
    if (view != null)
      removeView(view); 
    this.A = paramView;
    if (paramView != null) {
      LinearLayout linearLayout = this.B;
      if (linearLayout != null) {
        removeView((View)linearLayout);
        this.B = null;
      } 
    } 
    if (paramView != null)
      addView(paramView); 
    requestLayout();
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.x = paramCharSequence;
    i();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.w = paramCharSequence;
    i();
    y.u0((View)this, paramCharSequence);
  }
  
  public void setTitleOptional(boolean paramBoolean) {
    if (paramBoolean != this.G)
      requestLayout(); 
    this.G = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  class a implements View.OnClickListener {
    a(ActionBarContextView this$0, b param1b) {}
    
    public void onClick(View param1View) {
      this.o.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\ActionBarContextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */