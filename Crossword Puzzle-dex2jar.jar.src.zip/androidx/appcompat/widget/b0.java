package androidx.appcompat.widget;

import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.core.util.h;

final class b0 {
  private TextView a;
  
  private TextClassifier b;
  
  b0(TextView paramTextView) {
    this.a = (TextView)h.f(paramTextView);
  }
  
  public TextClassifier a() {
    TextClassifier textClassifier2 = this.b;
    TextClassifier textClassifier1 = textClassifier2;
    if (textClassifier2 == null)
      textClassifier1 = a.a(this.a); 
    return textClassifier1;
  }
  
  public void b(TextClassifier paramTextClassifier) {
    this.b = paramTextClassifier;
  }
  
  private static final class a {
    static TextClassifier a(TextView param1TextView) {
      TextClassificationManager textClassificationManager = (TextClassificationManager)param1TextView.getContext().getSystemService(TextClassificationManager.class);
      return (textClassificationManager != null) ? textClassificationManager.getTextClassifier() : TextClassifier.NO_OP;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */