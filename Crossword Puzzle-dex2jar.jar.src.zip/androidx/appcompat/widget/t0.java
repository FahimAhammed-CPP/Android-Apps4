package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class t0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  private static final Interpolator x = (Interpolator)new DecelerateInterpolator();
  
  Runnable o;
  
  private c p;
  
  m0 q;
  
  private Spinner r;
  
  private boolean s;
  
  int t;
  
  int u;
  
  private int v;
  
  private int w;
  
  private Spinner b() {
    a0 a0 = new a0(getContext(), null, e.a.h);
    a0.setLayoutParams((ViewGroup.LayoutParams)new m0.a(-2, -1));
    a0.setOnItemSelectedListener(this);
    return a0;
  }
  
  private boolean d() {
    Spinner spinner = this.r;
    return (spinner != null && spinner.getParent() == this);
  }
  
  private void e() {
    if (d())
      return; 
    if (this.r == null)
      this.r = b(); 
    removeView((View)this.q);
    addView((View)this.r, new ViewGroup.LayoutParams(-2, -1));
    if (this.r.getAdapter() == null)
      this.r.setAdapter((SpinnerAdapter)new b(this)); 
    Runnable runnable = this.o;
    if (runnable != null) {
      removeCallbacks(runnable);
      this.o = null;
    } 
    this.r.setSelection(this.w);
  }
  
  private boolean f() {
    if (!d())
      return false; 
    removeView((View)this.r);
    addView((View)this.q, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.r.getSelectedItemPosition());
    return false;
  }
  
  public void a(int paramInt) {
    View view = this.q.getChildAt(paramInt);
    Runnable runnable = this.o;
    if (runnable != null)
      removeCallbacks(runnable); 
    a a = new a(this, view);
    this.o = a;
    post(a);
  }
  
  d c(androidx.appcompat.app.a.c paramc, boolean paramBoolean) {
    d d = new d(this, getContext(), paramc, paramBoolean);
    if (paramBoolean) {
      d.setBackgroundDrawable(null);
      d.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, this.v));
      return d;
    } 
    d.setFocusable(true);
    if (this.p == null)
      this.p = new c(this); 
    d.setOnClickListener(this.p);
    return d;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Runnable runnable = this.o;
    if (runnable != null)
      post(runnable); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    androidx.appcompat.view.a a = androidx.appcompat.view.a.b(getContext());
    setContentHeight(a.f());
    this.u = a.e();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Runnable runnable = this.o;
    if (runnable != null)
      removeCallbacks(runnable); 
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((d)paramView).b().e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt2 = 1;
    if (i == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    setFillViewport(bool);
    int j = this.q.getChildCount();
    if (j > 1 && (i == 1073741824 || i == Integer.MIN_VALUE)) {
      if (j > 2) {
        this.t = (int)(View.MeasureSpec.getSize(paramInt1) * 0.4F);
      } else {
        this.t = View.MeasureSpec.getSize(paramInt1) / 2;
      } 
      this.t = Math.min(this.t, this.u);
    } else {
      this.t = -1;
    } 
    i = View.MeasureSpec.makeMeasureSpec(this.v, 1073741824);
    if (bool || !this.s)
      paramInt2 = 0; 
    if (paramInt2 != 0) {
      this.q.measure(0, i);
      if (this.q.getMeasuredWidth() > View.MeasureSpec.getSize(paramInt1)) {
        e();
      } else {
        f();
      } 
    } else {
      f();
    } 
    paramInt2 = getMeasuredWidth();
    super.onMeasure(paramInt1, i);
    paramInt1 = getMeasuredWidth();
    if (bool && paramInt2 != paramInt1)
      setTabSelected(this.w); 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void setAllowCollapse(boolean paramBoolean) {
    this.s = paramBoolean;
  }
  
  public void setContentHeight(int paramInt) {
    this.v = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.w = paramInt;
    int j = this.q.getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool;
      View view = this.q.getChildAt(i);
      if (i == paramInt) {
        bool = true;
      } else {
        bool = false;
      } 
      view.setSelected(bool);
      if (bool)
        a(paramInt); 
    } 
    Spinner spinner = this.r;
    if (spinner != null && paramInt >= 0)
      spinner.setSelection(paramInt); 
  }
  
  class a implements Runnable {
    a(t0 this$0, View param1View) {}
    
    public void run() {
      int i = this.o.getLeft();
      int j = (this.p.getWidth() - this.o.getWidth()) / 2;
      this.p.smoothScrollTo(i - j, 0);
      this.p.o = null;
    }
  }
  
  private class b extends BaseAdapter {
    b(t0 this$0) {}
    
    public int getCount() {
      return this.o.q.getChildCount();
    }
    
    public Object getItem(int param1Int) {
      return ((t0.d)this.o.q.getChildAt(param1Int)).b();
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null)
        return (View)this.o.c((androidx.appcompat.app.a.c)getItem(param1Int), true); 
      ((t0.d)param1View).a((androidx.appcompat.app.a.c)getItem(param1Int));
      return param1View;
    }
  }
  
  private class c implements View.OnClickListener {
    c(t0 this$0) {}
    
    public void onClick(View param1View) {
      ((t0.d)param1View).b().e();
      int j = this.o.q.getChildCount();
      for (int i = 0; i < j; i++) {
        boolean bool;
        View view = this.o.q.getChildAt(i);
        if (view == param1View) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      } 
    }
  }
  
  private class d extends LinearLayout {
    private final int[] o;
    
    private androidx.appcompat.app.a.c p;
    
    private TextView q;
    
    private ImageView r;
    
    private View s;
    
    public d(t0 this$0, Context param1Context, androidx.appcompat.app.a.c param1c, boolean param1Boolean) {
      super(param1Context, null, i);
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = 16842964;
      this.o = arrayOfInt;
      this.p = param1c;
      a1 a1 = a1.v(param1Context, null, arrayOfInt, i, 0);
      if (a1.s(0))
        setBackgroundDrawable(a1.g(0)); 
      a1.w();
      if (param1Boolean)
        setGravity(8388627); 
      c();
    }
    
    public void a(androidx.appcompat.app.a.c param1c) {
      this.p = param1c;
      c();
    }
    
    public androidx.appcompat.app.a.c b() {
      return this.p;
    }
    
    public void c() {
      androidx.appcompat.app.a.c c1 = this.p;
      View view = c1.b();
      ViewParent viewParent = null;
      if (view != null) {
        viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.s = view;
        TextView textView = this.q;
        if (textView != null)
          textView.setVisibility(8); 
        ImageView imageView = this.r;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.r.setImageDrawable(null);
          return;
        } 
      } else {
        CharSequence charSequence1;
        view = this.s;
        if (view != null) {
          removeView(view);
          this.s = null;
        } 
        Drawable drawable = c1.c();
        CharSequence charSequence2 = c1.d();
        if (drawable != null) {
          if (this.r == null) {
            r r = new r(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            r.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)r, 0);
            this.r = r;
          } 
          this.r.setImageDrawable(drawable);
          this.r.setVisibility(0);
        } else {
          ImageView imageView1 = this.r;
          if (imageView1 != null) {
            imageView1.setVisibility(8);
            this.r.setImageDrawable(null);
          } 
        } 
        int i = TextUtils.isEmpty(charSequence2) ^ true;
        if (i != 0) {
          if (this.q == null) {
            d0 d0 = new d0(getContext(), null, e.a.e);
            d0.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            d0.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)d0);
            this.q = d0;
          } 
          this.q.setText(charSequence2);
          this.q.setVisibility(0);
        } else {
          TextView textView = this.q;
          if (textView != null) {
            textView.setVisibility(8);
            this.q.setText(null);
          } 
        } 
        ImageView imageView = this.r;
        if (imageView != null)
          imageView.setContentDescription(c1.a()); 
        if (i == 0)
          charSequence1 = c1.a(); 
        d1.a((View)this, charSequence1);
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (this.t.t > 0) {
        param1Int1 = getMeasuredWidth();
        int i = this.t.t;
        if (param1Int1 > i)
          super.onMeasure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), param1Int2); 
      } 
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */