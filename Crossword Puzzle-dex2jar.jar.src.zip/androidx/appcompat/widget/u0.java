package androidx.appcompat.widget;

import a0.c;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import e.f;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.WeakHashMap;

class u0 extends c implements View.OnClickListener {
  private final SearchableInfo A;
  
  private final Context B;
  
  private final WeakHashMap<String, Drawable.ConstantState> C;
  
  private final int D;
  
  private boolean E = false;
  
  private int F = 1;
  
  private ColorStateList G;
  
  private int H = -1;
  
  private int I = -1;
  
  private int J = -1;
  
  private int K = -1;
  
  private int L = -1;
  
  private int M = -1;
  
  private final SearchView z;
  
  public u0(Context paramContext, SearchView paramSearchView, SearchableInfo paramSearchableInfo, WeakHashMap<String, Drawable.ConstantState> paramWeakHashMap) {
    super(paramContext, paramSearchView.getSuggestionRowLayout(), null, true);
    this.z = paramSearchView;
    this.A = paramSearchableInfo;
    this.D = paramSearchView.getSuggestionCommitIconResId();
    this.B = paramContext;
    this.C = paramWeakHashMap;
  }
  
  private Drawable A(Uri paramUri) {
    try {
      boolean bool = "android.resource".equals(paramUri.getScheme());
      if (bool)
        try {
          return B(paramUri);
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Resource does not exist: ");
          stringBuilder1.append(paramUri);
          throw new FileNotFoundException(stringBuilder1.toString());
        }  
      InputStream inputStream = this.B.getContentResolver().openInputStream(paramUri);
      if (inputStream != null)
        try {
          Drawable drawable = Drawable.createFromStream(inputStream, null);
        } finally {
          try {
            iOException.close();
          } catch (IOException iOException1) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Error closing icon stream for ");
            stringBuilder1.append(paramUri);
            Log.e("SuggestionsAdapter", stringBuilder1.toString(), iOException1);
          } 
        }  
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to open ");
      stringBuilder.append(paramUri);
      throw new FileNotFoundException(stringBuilder.toString());
    } catch (FileNotFoundException fileNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Icon not found: ");
      stringBuilder.append(paramUri);
      stringBuilder.append(", ");
      stringBuilder.append(fileNotFoundException.getMessage());
      Log.w("SuggestionsAdapter", stringBuilder.toString());
      return null;
    } 
  }
  
  private Drawable C(String paramString) {
    StringBuilder stringBuilder2 = null;
    StringBuilder stringBuilder1 = stringBuilder2;
    if (paramString != null) {
      stringBuilder1 = stringBuilder2;
      if (!paramString.isEmpty()) {
        if ("0".equals(paramString))
          return null; 
        try {
          int i = Integer.parseInt(paramString);
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("android.resource://");
          stringBuilder1.append(this.B.getPackageName());
          stringBuilder1.append("/");
          stringBuilder1.append(i);
          String str = stringBuilder1.toString();
          Drawable drawable = u(str);
          if (drawable != null)
            return drawable; 
          drawable = androidx.core.content.a.e(this.B, i);
          K(str, drawable);
          return drawable;
        } catch (NumberFormatException numberFormatException) {
          Drawable drawable = u(paramString);
          if (drawable != null)
            return drawable; 
          drawable = A(Uri.parse(paramString));
          K(paramString, drawable);
          return drawable;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Icon resource not found: ");
          stringBuilder1.append(paramString);
          Log.w("SuggestionsAdapter", stringBuilder1.toString());
          return null;
        } 
      } 
    } 
    return (Drawable)stringBuilder1;
  }
  
  private Drawable D(Cursor paramCursor) {
    int i = this.K;
    if (i == -1)
      return null; 
    Drawable drawable = C(paramCursor.getString(i));
    return (drawable != null) ? drawable : z();
  }
  
  private Drawable E(Cursor paramCursor) {
    int i = this.L;
    return (i == -1) ? null : C(paramCursor.getString(i));
  }
  
  private static String G(Cursor paramCursor, int paramInt) {
    if (paramInt == -1)
      return null; 
    try {
      return paramCursor.getString(paramInt);
    } catch (Exception exception) {
      Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", exception);
      return null;
    } 
  }
  
  private void I(ImageView paramImageView, Drawable paramDrawable, int paramInt) {
    paramImageView.setImageDrawable(paramDrawable);
    if (paramDrawable == null) {
      paramImageView.setVisibility(paramInt);
      return;
    } 
    paramImageView.setVisibility(0);
    paramDrawable.setVisible(false, false);
    paramDrawable.setVisible(true, false);
  }
  
  private void J(TextView paramTextView, CharSequence paramCharSequence) {
    paramTextView.setText(paramCharSequence);
    if (TextUtils.isEmpty(paramCharSequence)) {
      paramTextView.setVisibility(8);
      return;
    } 
    paramTextView.setVisibility(0);
  }
  
  private void K(String paramString, Drawable paramDrawable) {
    if (paramDrawable != null)
      this.C.put(paramString, paramDrawable.getConstantState()); 
  }
  
  private void L(Cursor paramCursor) {
    if (paramCursor != null) {
      Bundle bundle = paramCursor.getExtras();
    } else {
      paramCursor = null;
    } 
    if (paramCursor != null)
      paramCursor.getBoolean("in_progress"); 
  }
  
  private Drawable u(String paramString) {
    Drawable.ConstantState constantState = this.C.get(paramString);
    return (constantState == null) ? null : constantState.newDrawable();
  }
  
  private CharSequence v(CharSequence paramCharSequence) {
    if (this.G == null) {
      TypedValue typedValue = new TypedValue();
      this.B.getTheme().resolveAttribute(e.a.L, typedValue, true);
      this.G = this.B.getResources().getColorStateList(typedValue.resourceId);
    } 
    SpannableString spannableString = new SpannableString(paramCharSequence);
    spannableString.setSpan(new TextAppearanceSpan(null, 0, 0, this.G, null), 0, paramCharSequence.length(), 33);
    return (CharSequence)spannableString;
  }
  
  private Drawable w(ComponentName paramComponentName) {
    PackageManager packageManager = this.B.getPackageManager();
    try {
      StringBuilder stringBuilder;
      ActivityInfo activityInfo = packageManager.getActivityInfo(paramComponentName, 128);
      int i = activityInfo.getIconResource();
      if (i == 0)
        return null; 
      Drawable drawable = packageManager.getDrawable(paramComponentName.getPackageName(), i, activityInfo.applicationInfo);
      if (drawable == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid icon resource ");
        stringBuilder.append(i);
        stringBuilder.append(" for ");
        stringBuilder.append(paramComponentName.flattenToShortString());
        Log.w("SuggestionsAdapter", stringBuilder.toString());
        return null;
      } 
      return (Drawable)stringBuilder;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.w("SuggestionsAdapter", nameNotFoundException.toString());
      return null;
    } 
  }
  
  private Drawable x(ComponentName paramComponentName) {
    Drawable.ConstantState constantState1;
    String str = paramComponentName.flattenToShortString();
    boolean bool = this.C.containsKey(str);
    Drawable.ConstantState constantState2 = null;
    if (bool) {
      constantState1 = this.C.get(str);
      return (constantState1 == null) ? null : constantState1.newDrawable(this.B.getResources());
    } 
    Drawable drawable = w((ComponentName)constantState1);
    if (drawable == null) {
      constantState1 = constantState2;
    } else {
      constantState1 = drawable.getConstantState();
    } 
    this.C.put(str, constantState1);
    return drawable;
  }
  
  public static String y(Cursor paramCursor, String paramString) {
    return G(paramCursor, paramCursor.getColumnIndex(paramString));
  }
  
  private Drawable z() {
    Drawable drawable = x(this.A.getSearchActivity());
    return (drawable != null) ? drawable : this.B.getPackageManager().getDefaultActivityIcon();
  }
  
  Drawable B(Uri paramUri) {
    String str = paramUri.getAuthority();
    if (!TextUtils.isEmpty(str))
      try {
        int i;
        Resources resources = this.B.getPackageManager().getResourcesForApplication(str);
        List<String> list = paramUri.getPathSegments();
        if (list != null) {
          StringBuilder stringBuilder2;
          i = list.size();
          if (i == 1)
            try {
              i = Integer.parseInt(list.get(0));
              if (i != 0)
                return resources.getDrawable(i); 
              stringBuilder2 = new StringBuilder();
              stringBuilder2.append("No resource found for: ");
              stringBuilder2.append(paramUri);
              throw new FileNotFoundException(stringBuilder2.toString());
            } catch (NumberFormatException numberFormatException) {
              stringBuilder2 = new StringBuilder();
              stringBuilder2.append("Single path segment is not a resource ID: ");
              stringBuilder2.append(paramUri);
              throw new FileNotFoundException(stringBuilder2.toString());
            }  
          if (i == 2) {
            i = resources.getIdentifier(list.get(1), list.get(0), (String)stringBuilder2);
          } else {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("More than two path segments: ");
            stringBuilder2.append(paramUri);
            throw new FileNotFoundException(stringBuilder2.toString());
          } 
        } else {
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("No path: ");
          stringBuilder2.append(paramUri);
          throw new FileNotFoundException(stringBuilder2.toString());
        } 
        if (i != 0)
          return resources.getDrawable(i); 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("No resource found for: ");
        stringBuilder1.append(paramUri);
        throw new FileNotFoundException(stringBuilder1.toString());
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("No package found for authority: ");
        stringBuilder1.append(paramUri);
        throw new FileNotFoundException(stringBuilder1.toString());
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No authority: ");
    stringBuilder.append(paramUri);
    throw new FileNotFoundException(stringBuilder.toString());
  }
  
  Cursor F(SearchableInfo paramSearchableInfo, String paramString, int paramInt) {
    SearchableInfo searchableInfo = null;
    if (paramSearchableInfo == null)
      return null; 
    String str1 = paramSearchableInfo.getSuggestAuthority();
    if (str1 == null)
      return null; 
    Uri.Builder builder = (new Uri.Builder()).scheme("content").authority(str1).query("").fragment("");
    String str2 = paramSearchableInfo.getSuggestPath();
    if (str2 != null)
      builder.appendEncodedPath(str2); 
    builder.appendPath("search_suggest_query");
    str2 = paramSearchableInfo.getSuggestSelection();
    if (str2 != null) {
      String[] arrayOfString = new String[1];
      arrayOfString[0] = paramString;
    } else {
      builder.appendPath(paramString);
      paramSearchableInfo = searchableInfo;
    } 
    if (paramInt > 0)
      builder.appendQueryParameter("limit", String.valueOf(paramInt)); 
    Uri uri = builder.build();
    return this.B.getContentResolver().query(uri, null, str2, (String[])paramSearchableInfo, null);
  }
  
  public void H(int paramInt) {
    this.F = paramInt;
  }
  
  public void a(Cursor paramCursor) {
    if (this.E) {
      Log.w("SuggestionsAdapter", "Tried to change cursor after adapter was closed.");
      if (paramCursor != null)
        paramCursor.close(); 
      return;
    } 
    try {
      super.a(paramCursor);
      if (paramCursor != null) {
        this.H = paramCursor.getColumnIndex("suggest_text_1");
        this.I = paramCursor.getColumnIndex("suggest_text_2");
        this.J = paramCursor.getColumnIndex("suggest_text_2_url");
        this.K = paramCursor.getColumnIndex("suggest_icon_1");
        this.L = paramCursor.getColumnIndex("suggest_icon_2");
        this.M = paramCursor.getColumnIndex("suggest_flags");
        return;
      } 
    } catch (Exception exception) {
      Log.e("SuggestionsAdapter", "error changing cursor and caching columns", exception);
    } 
  }
  
  public CharSequence c(Cursor paramCursor) {
    if (paramCursor == null)
      return null; 
    String str = y(paramCursor, "suggest_intent_query");
    if (str != null)
      return str; 
    if (this.A.shouldRewriteQueryFromData()) {
      str = y(paramCursor, "suggest_intent_data");
      if (str != null)
        return str; 
    } 
    if (this.A.shouldRewriteQueryFromText()) {
      String str1 = y(paramCursor, "suggest_text_1");
      if (str1 != null)
        return str1; 
    } 
    return null;
  }
  
  public Cursor e(CharSequence paramCharSequence) {
    if (paramCharSequence == null) {
      paramCharSequence = "";
    } else {
      paramCharSequence = paramCharSequence.toString();
    } 
    if (this.z.getVisibility() == 0) {
      if (this.z.getWindowVisibility() != 0)
        return null; 
      try {
        Cursor cursor = F(this.A, (String)paramCharSequence, 50);
        if (cursor != null) {
          cursor.getCount();
          return cursor;
        } 
      } catch (RuntimeException runtimeException) {
        Log.w("SuggestionsAdapter", "Search suggestions query threw an exception.", runtimeException);
      } 
    } 
    return null;
  }
  
  public void g(View paramView, Context paramContext, Cursor paramCursor) {
    a a = (a)paramView.getTag();
    int i = this.M;
    if (i != -1) {
      i = paramCursor.getInt(i);
    } else {
      i = 0;
    } 
    if (a.a != null) {
      String str = G(paramCursor, this.H);
      J(a.a, str);
    } 
    if (a.b != null) {
      String str = G(paramCursor, this.J);
      if (str != null) {
        CharSequence charSequence = v(str);
      } else {
        str = G(paramCursor, this.I);
      } 
      if (TextUtils.isEmpty(str)) {
        TextView textView = a.a;
        if (textView != null) {
          textView.setSingleLine(false);
          a.a.setMaxLines(2);
        } 
      } else {
        TextView textView = a.a;
        if (textView != null) {
          textView.setSingleLine(true);
          a.a.setMaxLines(1);
        } 
      } 
      J(a.b, str);
    } 
    ImageView imageView = a.c;
    if (imageView != null)
      I(imageView, D(paramCursor), 4); 
    imageView = a.d;
    if (imageView != null)
      I(imageView, E(paramCursor), 8); 
    int j = this.F;
    if (j == 2 || (j == 1 && (i & 0x1) != 0)) {
      a.e.setVisibility(0);
      a.e.setTag(a.a.getText());
      a.e.setOnClickListener(this);
      return;
    } 
    a.e.setVisibility(8);
  }
  
  public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    try {
      return super.getDropDownView(paramInt, paramView, paramViewGroup);
    } catch (RuntimeException runtimeException) {
      Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", runtimeException);
      View view = q(this.B, b(), paramViewGroup);
      if (view != null)
        ((a)view.getTag()).a.setText(runtimeException.toString()); 
      return view;
    } 
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    try {
      return super.getView(paramInt, paramView, paramViewGroup);
    } catch (RuntimeException runtimeException) {
      Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", runtimeException);
      View view = r(this.B, b(), paramViewGroup);
      if (view != null)
        ((a)view.getTag()).a.setText(runtimeException.toString()); 
      return view;
    } 
  }
  
  public boolean hasStableIds() {
    return false;
  }
  
  public void notifyDataSetChanged() {
    super.notifyDataSetChanged();
    L(b());
  }
  
  public void notifyDataSetInvalidated() {
    super.notifyDataSetInvalidated();
    L(b());
  }
  
  public void onClick(View paramView) {
    Object object = paramView.getTag();
    if (object instanceof CharSequence)
      this.z.U((CharSequence)object); 
  }
  
  public View r(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup) {
    View view = super.r(paramContext, paramCursor, paramViewGroup);
    view.setTag(new a(view));
    ((ImageView)view.findViewById(f.q)).setImageResource(this.D);
    return view;
  }
  
  private static final class a {
    public final TextView a;
    
    public final TextView b;
    
    public final ImageView c;
    
    public final ImageView d;
    
    public final ImageView e;
    
    public a(View param1View) {
      this.a = (TextView)param1View.findViewById(16908308);
      this.b = (TextView)param1View.findViewById(16908309);
      this.c = (ImageView)param1View.findViewById(16908295);
      this.d = (ImageView)param1View.findViewById(16908296);
      this.e = (ImageView)param1View.findViewById(f.q);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widge\\u0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */