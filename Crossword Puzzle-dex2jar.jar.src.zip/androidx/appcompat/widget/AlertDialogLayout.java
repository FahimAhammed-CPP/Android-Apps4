package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.view.e;
import androidx.core.view.y;
import e.f;

public class AlertDialogLayout extends m0 {
  public AlertDialogLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  private void A(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  private static int B(View paramView) {
    int i = y.F(paramView);
    if (i > 0)
      return i; 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      if (viewGroup.getChildCount() == 1)
        return B(viewGroup.getChildAt(0)); 
    } 
    return 0;
  }
  
  private boolean C(int paramInt1, int paramInt2) {
    int i1;
    byte b;
    int i4 = getChildCount();
    View view3 = null;
    View view2 = null;
    View view1 = view2;
    int i;
    for (i = 0; i < i4; i++) {
      View view = getChildAt(i);
      if (view.getVisibility() != 8) {
        j = view.getId();
        if (j == f.P) {
          view3 = view;
        } else if (j == f.k) {
          view2 = view;
        } else if (j == f.m || j == f.o) {
          if (view1 != null)
            return false; 
          view1 = view;
        } else {
          return false;
        } 
      } 
    } 
    int i6 = View.MeasureSpec.getMode(paramInt2);
    int n = View.MeasureSpec.getSize(paramInt2);
    int i5 = View.MeasureSpec.getMode(paramInt1);
    int k = getPaddingTop() + getPaddingBottom();
    if (view3 != null) {
      view3.measure(paramInt1, 0);
      k += view3.getMeasuredHeight();
      j = View.combineMeasuredStates(0, view3.getMeasuredState());
    } else {
      j = 0;
    } 
    if (view2 != null) {
      view2.measure(paramInt1, 0);
      i = B(view2);
      i1 = view2.getMeasuredHeight() - i;
      k += i;
      j = View.combineMeasuredStates(j, view2.getMeasuredState());
    } else {
      i = 0;
      i1 = 0;
    } 
    if (view1 != null) {
      int i7;
      if (i6 == 0) {
        i7 = 0;
      } else {
        i7 = View.MeasureSpec.makeMeasureSpec(Math.max(0, n - k), i6);
      } 
      view1.measure(paramInt1, i7);
      b = view1.getMeasuredHeight();
      k += b;
      j = View.combineMeasuredStates(j, view1.getMeasuredState());
    } else {
      b = 0;
    } 
    int i2 = n - k;
    n = j;
    int i3 = i2;
    int m = k;
    if (view2 != null) {
      i1 = Math.min(i2, i1);
      n = i2;
      m = i;
      if (i1 > 0) {
        n = i2 - i1;
        m = i + i1;
      } 
      view2.measure(paramInt1, View.MeasureSpec.makeMeasureSpec(m, 1073741824));
      m = k - i + view2.getMeasuredHeight();
      i = View.combineMeasuredStates(j, view2.getMeasuredState());
      i3 = n;
      n = i;
    } 
    int j = n;
    i = m;
    if (view1 != null) {
      j = n;
      i = m;
      if (i3 > 0) {
        view1.measure(paramInt1, View.MeasureSpec.makeMeasureSpec(b + i3, i6));
        i = m - b + view1.getMeasuredHeight();
        j = View.combineMeasuredStates(n, view1.getMeasuredState());
      } 
    } 
    k = 0;
    for (m = 0; k < i4; m = n) {
      View view = getChildAt(k);
      n = m;
      if (view.getVisibility() != 8)
        n = Math.max(m, view.getMeasuredWidth()); 
      k++;
    } 
    setMeasuredDimension(View.resolveSizeAndState(m + getPaddingLeft() + getPaddingRight(), paramInt1, j), View.resolveSizeAndState(i, paramInt2, 0));
    if (i5 != 1073741824)
      l(i4, paramInt2); 
    return true;
  }
  
  private void l(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getChildAt(i);
      if (view.getVisibility() != 8) {
        m0.a a = (m0.a)view.getLayoutParams();
        if (a.width == -1) {
          int k = a.height;
          a.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          a.height = k;
        } 
      } 
    } 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    paramInt1 = getMeasuredHeight();
    int n = getChildCount();
    int i1 = getGravity();
    paramInt3 = i1 & 0x70;
    if (paramInt3 != 16) {
      if (paramInt3 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - paramInt1;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - paramInt1) / 2;
    } 
    Drawable drawable = getDividerDrawable();
    if (drawable == null) {
      paramInt2 = 0;
    } else {
      paramInt2 = drawable.getIntrinsicHeight();
    } 
    paramInt3 = 0;
    while (paramInt3 < n) {
      View view = getChildAt(paramInt3);
      paramInt4 = paramInt1;
      if (view != null) {
        paramInt4 = paramInt1;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i4 = view.getMeasuredHeight();
          m0.a a = (m0.a)view.getLayoutParams();
          int i2 = a.gravity;
          paramInt4 = i2;
          if (i2 < 0)
            paramInt4 = i1 & 0x800007; 
          paramInt4 = e.b(paramInt4, y.E((View)this)) & 0x7;
          if (paramInt4 != 1) {
            if (paramInt4 != 5) {
              paramInt4 = a.leftMargin + i;
            } else {
              paramInt4 = j - k - i3;
              i2 = a.rightMargin;
              paramInt4 -= i2;
            } 
          } else {
            paramInt4 = (j - i - m - i3) / 2 + i + a.leftMargin;
            i2 = a.rightMargin;
            paramInt4 -= i2;
          } 
          i2 = paramInt1;
          if (t(paramInt3))
            i2 = paramInt1 + paramInt2; 
          paramInt1 = i2 + a.topMargin;
          A(view, paramInt4, paramInt1, i3, i4);
          paramInt4 = paramInt1 + i4 + a.bottomMargin;
        } 
      } 
      paramInt3++;
      paramInt1 = paramInt4;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!C(paramInt1, paramInt2))
      super.onMeasure(paramInt1, paramInt2); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\AlertDialogLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */