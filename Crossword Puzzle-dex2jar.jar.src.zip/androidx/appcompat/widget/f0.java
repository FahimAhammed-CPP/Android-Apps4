package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;
import androidx.core.view.w;
import androidx.core.widget.n;

public class f0 extends ToggleButton implements w, n {
  private final e o;
  
  private final c0 p;
  
  private n q;
  
  public f0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842827);
  }
  
  public f0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    v0.a((View)this, getContext());
    e e1 = new e((View)this);
    this.o = e1;
    e1.e(paramAttributeSet, paramInt);
    c0 c01 = new c0((TextView)this);
    this.p = c01;
    c01.m(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().b(paramAttributeSet, paramInt);
  }
  
  private n getEmojiTextViewHelper() {
    if (this.q == null)
      this.q = new n((TextView)this); 
    return this.q;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.o;
    if (e1 != null)
      e1.b(); 
    c0 c01 = this.p;
    if (c01 != null)
      c01.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.o;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.o;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.p.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.p.k();
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().c(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.o;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.o;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.o;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.o;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.p.w(paramColorStateList);
    this.p.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.p.x(paramMode);
    this.p.b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */