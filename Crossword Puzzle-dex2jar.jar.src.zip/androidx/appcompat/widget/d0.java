package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.core.graphics.e;
import androidx.core.text.b;
import androidx.core.view.w;
import androidx.core.widget.b;
import androidx.core.widget.j;
import androidx.core.widget.n;
import f.a;
import java.util.concurrent.Future;

public class d0 extends TextView implements w, n, b {
  private final e o;
  
  private final c0 p;
  
  private final b0 q;
  
  private n r;
  
  private boolean s = false;
  
  private Future<b> t;
  
  public d0(Context paramContext) {
    this(paramContext, null);
  }
  
  public d0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public d0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(x0.b(paramContext), paramAttributeSet, paramInt);
    v0.a((View)this, getContext());
    e e1 = new e((View)this);
    this.o = e1;
    e1.e(paramAttributeSet, paramInt);
    c0 c01 = new c0(this);
    this.p = c01;
    c01.m(paramAttributeSet, paramInt);
    c01.b();
    this.q = new b0(this);
    getEmojiTextViewHelper().b(paramAttributeSet, paramInt);
  }
  
  private void c() {
    Future<b> future = this.t;
    if (future != null)
      try {
        this.t = null;
        j.m(this, future.get());
        return;
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
        return;
      }  
  }
  
  private n getEmojiTextViewHelper() {
    if (this.r == null)
      this.r = new n(this); 
    return this.r;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.o;
    if (e1 != null)
      e1.b(); 
    c0 c01 = this.p;
    if (c01 != null)
      c01.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.a)
      return super.getAutoSizeMaxTextSize(); 
    c0 c01 = this.p;
    return (c01 != null) ? c01.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.a)
      return super.getAutoSizeMinTextSize(); 
    c0 c01 = this.p;
    return (c01 != null) ? c01.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.a)
      return super.getAutoSizeStepGranularity(); 
    c0 c01 = this.p;
    return (c01 != null) ? c01.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.a)
      return super.getAutoSizeTextAvailableSizes(); 
    c0 c01 = this.p;
    return (c01 != null) ? c01.h() : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = b.a;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    c0 c01 = this.p;
    return (c01 != null) ? c01.i() : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.p(super.getCustomSelectionActionModeCallback());
  }
  
  public int getFirstBaselineToTopHeight() {
    return j.b(this);
  }
  
  public int getLastBaselineToBottomHeight() {
    return j.c(this);
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.o;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.o;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.p.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.p.k();
  }
  
  public CharSequence getText() {
    c();
    return super.getText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      b0 b01 = this.q;
      if (b01 != null)
        return b01.a(); 
    } 
    return super.getTextClassifier();
  }
  
  public b.a getTextMetricsParamsCompat() {
    return j.f(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    this.p.r(this, inputConnection, paramEditorInfo);
    return o.a(inputConnection, paramEditorInfo, (View)this);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    c();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    c0 c01 = this.p;
    if (c01 != null && !b.a && c01.l())
      this.p.c(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().c(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (b.a) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    c0 c01 = this.p;
    if (c01 != null)
      c01.t(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (b.a) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    c0 c01 = this.p;
    if (c01 != null)
      c01.u(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.a) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    c0 c01 = this.p;
    if (c01 != null)
      c01.v(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.o;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.o;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    c0 c01 = this.p;
    if (c01 != null)
      c01.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.q(this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setFirstBaselineToTopHeight(paramInt);
      return;
    } 
    j.j(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setLastBaselineToBottomHeight(paramInt);
      return;
    } 
    j.k(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    j.l(this, paramInt);
  }
  
  public void setPrecomputedText(b paramb) {
    j.m(this, paramb);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.o;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.o;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.p.w(paramColorStateList);
    this.p.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.p.x(paramMode);
    this.p.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    c0 c01 = this.p;
    if (c01 != null)
      c01.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      b0 b01 = this.q;
      if (b01 != null) {
        b01.b(paramTextClassifier);
        return;
      } 
    } 
    super.setTextClassifier(paramTextClassifier);
  }
  
  public void setTextFuture(Future<b> paramFuture) {
    this.t = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(b.a parama) {
    j.o(this, parama);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (b.a) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    c0 c01 = this.p;
    if (c01 != null)
      c01.A(paramInt, paramFloat); 
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt) {
    if (this.s)
      return; 
    Typeface typeface2 = null;
    Typeface typeface1 = typeface2;
    if (paramTypeface != null) {
      typeface1 = typeface2;
      if (paramInt > 0)
        typeface1 = e.a(getContext(), paramTypeface, paramInt); 
    } 
    this.s = true;
    if (typeface1 != null)
      paramTypeface = typeface1; 
    try {
      super.setTypeface(paramTypeface, paramInt);
      return;
    } finally {
      this.s = false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */