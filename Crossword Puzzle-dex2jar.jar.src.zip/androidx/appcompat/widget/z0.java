package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

class z0 extends r0 {
  private final WeakReference<Context> b;
  
  public z0(Context paramContext, Resources paramResources) {
    super(paramResources);
    this.b = new WeakReference<Context>(paramContext);
  }
  
  public Drawable getDrawable(int paramInt) {
    Drawable drawable = a(paramInt);
    Context context = this.b.get();
    if (drawable != null && context != null)
      q0.h().x(context, paramInt, drawable); 
    return drawable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\z0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */