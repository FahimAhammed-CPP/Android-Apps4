package androidx.appcompat.widget;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import androidx.appcompat.view.menu.p;

public abstract class l0 implements View.OnTouchListener, View.OnAttachStateChangeListener {
  private final float o;
  
  private final int p;
  
  private final int q;
  
  final View r;
  
  private Runnable s;
  
  private Runnable t;
  
  private boolean u;
  
  private int v;
  
  private final int[] w = new int[2];
  
  public l0(View paramView) {
    this.r = paramView;
    paramView.setLongClickable(true);
    paramView.addOnAttachStateChangeListener(this);
    this.o = ViewConfiguration.get(paramView.getContext()).getScaledTouchSlop();
    int i = ViewConfiguration.getTapTimeout();
    this.p = i;
    this.q = (i + ViewConfiguration.getLongPressTimeout()) / 2;
  }
  
  private void a() {
    Runnable runnable = this.t;
    if (runnable != null)
      this.r.removeCallbacks(runnable); 
    runnable = this.s;
    if (runnable != null)
      this.r.removeCallbacks(runnable); 
  }
  
  private boolean p(MotionEvent paramMotionEvent) {
    View view = this.r;
    p p = b();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (p != null) {
      if (!p.c())
        return false; 
      j0 j0 = (j0)p.h();
      bool1 = bool2;
      if (j0 != null) {
        if (!j0.isShown())
          return false; 
        MotionEvent motionEvent = MotionEvent.obtainNoHistory(paramMotionEvent);
        s(view, motionEvent);
        t((View)j0, motionEvent);
        boolean bool = j0.e(motionEvent, this.v);
        motionEvent.recycle();
        int i = paramMotionEvent.getActionMasked();
        if (i != 1 && i != 3) {
          i = 1;
        } else {
          i = 0;
        } 
        bool1 = bool2;
        if (bool) {
          bool1 = bool2;
          if (i != 0)
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  private boolean q(MotionEvent paramMotionEvent) {
    View view = this.r;
    if (!view.isEnabled())
      return false; 
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3)
            return false; 
        } else {
          i = paramMotionEvent.findPointerIndex(this.v);
          if (i >= 0 && !r(view, paramMotionEvent.getX(i), paramMotionEvent.getY(i), this.o)) {
            a();
            view.getParent().requestDisallowInterceptTouchEvent(true);
            return true;
          } 
          return false;
        }  
      a();
      return false;
    } 
    this.v = paramMotionEvent.getPointerId(0);
    if (this.s == null)
      this.s = new a(this); 
    view.postDelayed(this.s, this.p);
    if (this.t == null)
      this.t = new b(this); 
    view.postDelayed(this.t, this.q);
    return false;
  }
  
  private static boolean r(View paramView, float paramFloat1, float paramFloat2, float paramFloat3) {
    float f = -paramFloat3;
    return (paramFloat1 >= f && paramFloat2 >= f && paramFloat1 < (paramView.getRight() - paramView.getLeft()) + paramFloat3 && paramFloat2 < (paramView.getBottom() - paramView.getTop()) + paramFloat3);
  }
  
  private boolean s(View paramView, MotionEvent paramMotionEvent) {
    int[] arrayOfInt = this.w;
    paramView.getLocationOnScreen(arrayOfInt);
    paramMotionEvent.offsetLocation(arrayOfInt[0], arrayOfInt[1]);
    return true;
  }
  
  private boolean t(View paramView, MotionEvent paramMotionEvent) {
    int[] arrayOfInt = this.w;
    paramView.getLocationOnScreen(arrayOfInt);
    paramMotionEvent.offsetLocation(-arrayOfInt[0], -arrayOfInt[1]);
    return true;
  }
  
  public abstract p b();
  
  protected abstract boolean c();
  
  protected boolean e() {
    p p = b();
    if (p != null && p.c())
      p.dismiss(); 
    return true;
  }
  
  void g() {
    a();
    View view = this.r;
    if (view.isEnabled()) {
      if (view.isLongClickable())
        return; 
      if (!c())
        return; 
      view.getParent().requestDisallowInterceptTouchEvent(true);
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      view.onTouchEvent(motionEvent);
      motionEvent.recycle();
      this.u = true;
    } 
  }
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    boolean bool1;
    boolean bool = this.u;
    boolean bool3 = true;
    if (bool) {
      if (p(paramMotionEvent) || !e()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
    } else {
      boolean bool4;
      if (q(paramMotionEvent) && c()) {
        bool4 = true;
      } else {
        bool4 = false;
      } 
      bool1 = bool4;
      if (bool4) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        this.r.onTouchEvent(motionEvent);
        motionEvent.recycle();
        bool1 = bool4;
      } 
    } 
    this.u = bool1;
    boolean bool2 = bool3;
    if (!bool1) {
      if (bool)
        return true; 
      bool2 = false;
    } 
    return bool2;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    this.u = false;
    this.v = -1;
    Runnable runnable = this.s;
    if (runnable != null)
      this.r.removeCallbacks(runnable); 
  }
  
  private class a implements Runnable {
    a(l0 this$0) {}
    
    public void run() {
      ViewParent viewParent = this.o.r.getParent();
      if (viewParent != null)
        viewParent.requestDisallowInterceptTouchEvent(true); 
    }
  }
  
  private class b implements Runnable {
    b(l0 this$0) {}
    
    public void run() {
      this.o.g();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\widget\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */