package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.view.g;
import androidx.appcompat.view.h;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.h0;
import androidx.appcompat.widget.t0;
import androidx.core.view.e0;
import androidx.core.view.f0;
import androidx.core.view.g0;
import androidx.core.view.h0;
import androidx.core.view.y;
import e.f;
import e.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class n extends a implements ActionBarOverlayLayout.d {
  private static final Interpolator E = (Interpolator)new AccelerateInterpolator();
  
  private static final Interpolator F = (Interpolator)new DecelerateInterpolator();
  
  boolean A;
  
  final f0 B = (f0)new a(this);
  
  final f0 C = (f0)new b(this);
  
  final h0 D = new c(this);
  
  Context a;
  
  private Context b;
  
  private Activity c;
  
  ActionBarOverlayLayout d;
  
  ActionBarContainer e;
  
  h0 f;
  
  ActionBarContextView g;
  
  View h;
  
  t0 i;
  
  private ArrayList<Object> j = new ArrayList();
  
  private int k = -1;
  
  private boolean l;
  
  d m;
  
  androidx.appcompat.view.b n;
  
  androidx.appcompat.view.b.a o;
  
  private boolean p;
  
  private ArrayList<a.b> q = new ArrayList<a.b>();
  
  private boolean r;
  
  private int s = 0;
  
  boolean t = true;
  
  boolean u;
  
  boolean v;
  
  private boolean w;
  
  private boolean x = true;
  
  h y;
  
  private boolean z;
  
  public n(Activity paramActivity, boolean paramBoolean) {
    this.c = paramActivity;
    View view = paramActivity.getWindow().getDecorView();
    C(view);
    if (!paramBoolean)
      this.h = view.findViewById(16908290); 
  }
  
  public n(Dialog paramDialog) {
    C(paramDialog.getWindow().getDecorView());
  }
  
  private void B() {
    if (this.w) {
      this.w = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      L(false);
    } 
  }
  
  private void C(View paramView) {
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(f.p);
    this.d = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    this.f = z(paramView.findViewById(f.a));
    this.g = (ActionBarContextView)paramView.findViewById(f.f);
    ActionBarContainer actionBarContainer = (ActionBarContainer)paramView.findViewById(f.c);
    this.e = actionBarContainer;
    h0 h01 = this.f;
    if (h01 != null && this.g != null && actionBarContainer != null) {
      boolean bool;
      this.a = h01.getContext();
      if ((this.f.n() & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.l = true; 
      androidx.appcompat.view.a a1 = androidx.appcompat.view.a.b(this.a);
      if (a1.a() || i) {
        bool = true;
      } else {
        bool = false;
      } 
      I(bool);
      G(a1.g());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, j.a, e.a.c, 0);
      if (typedArray.getBoolean(j.k, false))
        H(true); 
      int i = typedArray.getDimensionPixelSize(j.i, 0);
      if (i != 0)
        F(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void G(boolean paramBoolean) {
    this.r = paramBoolean;
    if (!paramBoolean) {
      this.f.j(null);
      this.e.setTabContainer(this.i);
    } else {
      this.e.setTabContainer(null);
      this.f.j(this.i);
    } 
    int i = A();
    boolean bool = true;
    if (i == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    t0 t01 = this.i;
    if (t01 != null) {
      ActionBarOverlayLayout actionBarOverlayLayout1;
      if (i != 0) {
        t01.setVisibility(0);
        actionBarOverlayLayout1 = this.d;
        if (actionBarOverlayLayout1 != null)
          y.o0((View)actionBarOverlayLayout1); 
      } else {
        actionBarOverlayLayout1.setVisibility(8);
      } 
    } 
    h0 h01 = this.f;
    if (!this.r && i != 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    h01.t(paramBoolean);
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (!this.r && i != 0) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(paramBoolean);
  }
  
  private boolean J() {
    return y.V((View)this.e);
  }
  
  private void K() {
    if (!this.w) {
      this.w = true;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(true); 
      L(false);
    } 
  }
  
  private void L(boolean paramBoolean) {
    if (v(this.u, this.v, this.w)) {
      if (!this.x) {
        this.x = true;
        y(paramBoolean);
        return;
      } 
    } else if (this.x) {
      this.x = false;
      x(paramBoolean);
    } 
  }
  
  static boolean v(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  private h0 z(View paramView) {
    String str;
    if (paramView instanceof h0)
      return (h0)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    if (paramView != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    stringBuilder.append(str);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int A() {
    return this.f.p();
  }
  
  public void D(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    E(bool, 4);
  }
  
  public void E(int paramInt1, int paramInt2) {
    int i = this.f.n();
    if ((paramInt2 & 0x4) != 0)
      this.l = true; 
    this.f.m(paramInt1 & paramInt2 | (paramInt2 ^ 0xFFFFFFFF) & i);
  }
  
  public void F(float paramFloat) {
    y.z0((View)this.e, paramFloat);
  }
  
  public void H(boolean paramBoolean) {
    if (!paramBoolean || this.d.w()) {
      this.A = paramBoolean;
      this.d.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void I(boolean paramBoolean) {
    this.f.k(paramBoolean);
  }
  
  public void a() {
    if (this.v) {
      this.v = false;
      L(true);
    } 
  }
  
  public void b() {
    h h1 = this.y;
    if (h1 != null) {
      h1.a();
      this.y = null;
    } 
  }
  
  public void c() {}
  
  public void d(boolean paramBoolean) {
    this.t = paramBoolean;
  }
  
  public void e() {
    if (!this.v) {
      this.v = true;
      L(true);
    } 
  }
  
  public boolean g() {
    h0 h01 = this.f;
    if (h01 != null && h01.l()) {
      this.f.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void h(boolean paramBoolean) {
    if (paramBoolean == this.p)
      return; 
    this.p = paramBoolean;
    int j = this.q.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.q.get(i)).a(paramBoolean); 
  }
  
  public int i() {
    return this.f.n();
  }
  
  public Context j() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(e.a.g, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void l(Configuration paramConfiguration) {
    G(androidx.appcompat.view.a.b(this.a).g());
  }
  
  public boolean n(int paramInt, KeyEvent paramKeyEvent) {
    d d1 = this.m;
    if (d1 == null)
      return false; 
    Menu menu = d1.e();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    this.s = paramInt;
  }
  
  public void q(boolean paramBoolean) {
    if (!this.l)
      D(paramBoolean); 
  }
  
  public void r(boolean paramBoolean) {
    this.z = paramBoolean;
    if (!paramBoolean) {
      h h1 = this.y;
      if (h1 != null)
        h1.a(); 
    } 
  }
  
  public void s(CharSequence paramCharSequence) {
    this.f.setWindowTitle(paramCharSequence);
  }
  
  public androidx.appcompat.view.b t(androidx.appcompat.view.b.a parama) {
    d d2 = this.m;
    if (d2 != null)
      d2.c(); 
    this.d.setHideOnContentScrollEnabled(false);
    this.g.k();
    d d1 = new d(this, this.g.getContext(), parama);
    if (d1.t()) {
      this.m = d1;
      d1.k();
      this.g.h(d1);
      u(true);
      return d1;
    } 
    return null;
  }
  
  public void u(boolean paramBoolean) {
    if (paramBoolean) {
      K();
    } else {
      B();
    } 
    if (J()) {
      e0 e01;
      e0 e02;
      if (paramBoolean) {
        e02 = this.f.q(4, 100L);
        e01 = this.g.f(0, 200L);
      } else {
        e01 = this.f.q(0, 200L);
        e02 = this.g.f(8, 100L);
      } 
      h h1 = new h();
      h1.d(e02, e01);
      h1.h();
      return;
    } 
    if (paramBoolean) {
      this.f.i(4);
      this.g.setVisibility(0);
      return;
    } 
    this.f.i(0);
    this.g.setVisibility(8);
  }
  
  void w() {
    androidx.appcompat.view.b.a a1 = this.o;
    if (a1 != null) {
      a1.b(this.n);
      this.n = null;
      this.o = null;
    } 
  }
  
  public void x(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setAlpha(1.0F);
      this.e.setTransitioning(true);
      h1 = new h();
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      e0 e0 = y.e((View)this.e).m(f1);
      e0.k(this.D);
      h1.c(e0);
      if (this.t) {
        View view = this.h;
        if (view != null)
          h1.c(y.e(view).m(f1)); 
      } 
      h1.f(E);
      h1.e(250L);
      h1.g(this.B);
      this.y = h1;
      h1.h();
      return;
    } 
    this.B.b(null);
  }
  
  public void y(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    this.e.setVisibility(0);
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setTranslationY(0.0F);
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      this.e.setTranslationY(f1);
      h1 = new h();
      e0 e0 = y.e((View)this.e).m(0.0F);
      e0.k(this.D);
      h1.c(e0);
      if (this.t) {
        View view = this.h;
        if (view != null) {
          view.setTranslationY(f1);
          h1.c(y.e(this.h).m(0.0F));
        } 
      } 
      h1.f(F);
      h1.e(250L);
      h1.g(this.C);
      this.y = h1;
      h1.h();
    } else {
      this.e.setAlpha(1.0F);
      this.e.setTranslationY(0.0F);
      if (this.t) {
        View view = this.h;
        if (view != null)
          view.setTranslationY(0.0F); 
      } 
      this.C.b(null);
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (actionBarOverlayLayout != null)
      y.o0((View)actionBarOverlayLayout); 
  }
  
  class a extends g0 {
    a(n this$0) {}
    
    public void b(View param1View) {
      n n1 = this.a;
      if (n1.t) {
        View view = n1.h;
        if (view != null) {
          view.setTranslationY(0.0F);
          this.a.e.setTranslationY(0.0F);
        } 
      } 
      this.a.e.setVisibility(8);
      this.a.e.setTransitioning(false);
      n1 = this.a;
      n1.y = null;
      n1.w();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a.d;
      if (actionBarOverlayLayout != null)
        y.o0((View)actionBarOverlayLayout); 
    }
  }
  
  class b extends g0 {
    b(n this$0) {}
    
    public void b(View param1View) {
      n n1 = this.a;
      n1.y = null;
      n1.e.requestLayout();
    }
  }
  
  class c implements h0 {
    c(n this$0) {}
    
    public void a(View param1View) {
      ((View)this.a.e.getParent()).invalidate();
    }
  }
  
  public class d extends androidx.appcompat.view.b implements g.a {
    private final Context q;
    
    private final g r;
    
    private androidx.appcompat.view.b.a s;
    
    private WeakReference<View> t;
    
    public d(n this$0, Context param1Context, androidx.appcompat.view.b.a param1a) {
      this.q = param1Context;
      this.s = param1a;
      g g1 = (new g(param1Context)).S(1);
      this.r = g1;
      g1.R(this);
    }
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      androidx.appcompat.view.b.a a1 = this.s;
      return (a1 != null) ? a1.c(this, param1MenuItem) : false;
    }
    
    public void b(g param1g) {
      if (this.s == null)
        return; 
      k();
      this.u.g.l();
    }
    
    public void c() {
      n n1 = this.u;
      if (n1.m != this)
        return; 
      if (!n.v(n1.u, n1.v, false)) {
        n1 = this.u;
        n1.n = this;
        n1.o = this.s;
      } else {
        this.s.b(this);
      } 
      this.s = null;
      this.u.u(false);
      this.u.g.g();
      n1 = this.u;
      n1.d.setHideOnContentScrollEnabled(n1.A);
      this.u.m = null;
    }
    
    public View d() {
      WeakReference<View> weakReference = this.t;
      return (weakReference != null) ? weakReference.get() : null;
    }
    
    public Menu e() {
      return (Menu)this.r;
    }
    
    public MenuInflater f() {
      return (MenuInflater)new g(this.q);
    }
    
    public CharSequence g() {
      return this.u.g.getSubtitle();
    }
    
    public CharSequence i() {
      return this.u.g.getTitle();
    }
    
    public void k() {
      if (this.u.m != this)
        return; 
      this.r.d0();
      try {
        this.s.a(this, (Menu)this.r);
        return;
      } finally {
        this.r.c0();
      } 
    }
    
    public boolean l() {
      return this.u.g.j();
    }
    
    public void m(View param1View) {
      this.u.g.setCustomView(param1View);
      this.t = new WeakReference<View>(param1View);
    }
    
    public void n(int param1Int) {
      o(this.u.a.getResources().getString(param1Int));
    }
    
    public void o(CharSequence param1CharSequence) {
      this.u.g.setSubtitle(param1CharSequence);
    }
    
    public void q(int param1Int) {
      r(this.u.a.getResources().getString(param1Int));
    }
    
    public void r(CharSequence param1CharSequence) {
      this.u.g.setTitle(param1CharSequence);
    }
    
    public void s(boolean param1Boolean) {
      super.s(param1Boolean);
      this.u.g.setTitleOptional(param1Boolean);
    }
    
    public boolean t() {
      this.r.d0();
      try {
        return this.s.d(this, (Menu)this.r);
      } finally {
        this.r.c0();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */