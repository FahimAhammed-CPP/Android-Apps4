package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import o.b;

public abstract class e {
  private static int o = -100;
  
  private static final b<WeakReference<e>> p = new b();
  
  private static final Object q = new Object();
  
  static void c(e parame) {
    synchronized (q) {
      y(parame);
      p.add(new WeakReference<e>(parame));
      return;
    } 
  }
  
  public static e g(Activity paramActivity, d paramd) {
    return new f(paramActivity, paramd);
  }
  
  public static e h(Dialog paramDialog, d paramd) {
    return new f(paramDialog, paramd);
  }
  
  public static int j() {
    return o;
  }
  
  static void x(e parame) {
    synchronized (q) {
      y(parame);
      return;
    } 
  }
  
  private static void y(e parame) {
    synchronized (q) {
      Iterator<WeakReference<e>> iterator = p.iterator();
      while (iterator.hasNext()) {
        e e1 = ((WeakReference<e>)iterator.next()).get();
        if (e1 == parame || e1 == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  public abstract void A(int paramInt);
  
  public abstract void B(View paramView);
  
  public abstract void C(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public void D(int paramInt) {}
  
  public abstract void E(CharSequence paramCharSequence);
  
  public abstract void d(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  @Deprecated
  public void e(Context paramContext) {}
  
  public Context f(Context paramContext) {
    e(paramContext);
    return paramContext;
  }
  
  public abstract <T extends View> T i(int paramInt);
  
  public int k() {
    return -100;
  }
  
  public abstract MenuInflater l();
  
  public abstract a m();
  
  public abstract void n();
  
  public abstract void o();
  
  public abstract void p(Configuration paramConfiguration);
  
  public abstract void q(Bundle paramBundle);
  
  public abstract void r();
  
  public abstract void s(Bundle paramBundle);
  
  public abstract void t();
  
  public abstract void u(Bundle paramBundle);
  
  public abstract void v();
  
  public abstract void w();
  
  public abstract boolean z(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */