package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.a1;
import androidx.appcompat.widget.g0;
import androidx.appcompat.widget.i1;
import androidx.appcompat.widget.j1;
import androidx.appcompat.widget.k0;
import androidx.core.view.e0;
import androidx.core.view.f0;
import androidx.core.view.g0;
import androidx.core.view.j0;
import androidx.core.view.y;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

class f extends e implements g.a, LayoutInflater.Factory2 {
  private static final o.g<String, Integer> p0 = new o.g();
  
  private static final boolean q0;
  
  private static final int[] r0 = new int[] { 16842836 };
  
  private static final boolean s0 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  private static final boolean t0 = true;
  
  private static boolean u0;
  
  private i A;
  
  private v B;
  
  androidx.appcompat.view.b C;
  
  ActionBarContextView D;
  
  PopupWindow E;
  
  Runnable F;
  
  e0 G = null;
  
  private boolean H = true;
  
  private boolean I;
  
  ViewGroup J;
  
  private TextView K;
  
  private View L;
  
  private boolean M;
  
  private boolean N;
  
  boolean O;
  
  boolean P;
  
  boolean Q;
  
  boolean R;
  
  boolean S;
  
  private boolean T;
  
  private u[] U;
  
  private u V;
  
  private boolean W;
  
  private boolean X;
  
  private boolean Y;
  
  boolean Z;
  
  private Configuration a0;
  
  private int b0 = -100;
  
  private int c0;
  
  private boolean d0;
  
  private boolean e0;
  
  private q f0;
  
  private q g0;
  
  boolean h0;
  
  int i0;
  
  private final Runnable j0 = new b(this);
  
  private boolean k0;
  
  private Rect l0;
  
  private Rect m0;
  
  private i n0;
  
  private j o0;
  
  final Object r;
  
  final Context s;
  
  Window t;
  
  private o u;
  
  final d v;
  
  a w;
  
  MenuInflater x;
  
  private CharSequence y;
  
  private g0 z;
  
  static {
    if (bool && !u0) {
      Thread.setDefaultUncaughtExceptionHandler(new a(Thread.getDefaultUncaughtExceptionHandler()));
      u0 = true;
    } 
  }
  
  f(Activity paramActivity, d paramd) {
    this((Context)paramActivity, null, paramd, paramActivity);
  }
  
  f(Dialog paramDialog, d paramd) {
    this(paramDialog.getContext(), paramDialog.getWindow(), paramd, paramDialog);
  }
  
  private f(Context paramContext, Window paramWindow, d paramd, Object paramObject) {
    this.s = paramContext;
    this.v = paramd;
    this.r = paramObject;
    if (this.b0 == -100 && paramObject instanceof Dialog) {
      c c = I0();
      if (c != null)
        this.b0 = c.I().k(); 
    } 
    if (this.b0 == -100) {
      o.g<String, Integer> g1 = p0;
      Integer integer = (Integer)g1.get(paramObject.getClass().getName());
      if (integer != null) {
        this.b0 = integer.intValue();
        g1.remove(paramObject.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      I(paramWindow); 
    androidx.appcompat.widget.k.h();
  }
  
  private boolean A0(u paramu, KeyEvent paramKeyEvent) {
    g0 g01;
    if (this.Z)
      return false; 
    if (paramu.m)
      return true; 
    u u1 = this.V;
    if (u1 != null && u1 != paramu)
      O(u1, false); 
    Window.Callback callback = f0();
    if (callback != null)
      paramu.i = callback.onCreatePanelView(paramu.a); 
    int k = paramu.a;
    if (k == 0 || k == 108) {
      k = 1;
    } else {
      k = 0;
    } 
    if (k != 0) {
      g0 g02 = this.z;
      if (g02 != null)
        g02.c(); 
    } 
    if (paramu.i == null) {
      g0 g02;
      boolean bool;
      if (k != 0)
        y0(); 
      g g1 = paramu.j;
      if (g1 == null || paramu.r) {
        if (g1 == null && (!j0(paramu) || paramu.j == null))
          return false; 
        if (k != 0 && this.z != null) {
          if (this.A == null)
            this.A = new i(this); 
          this.z.a((Menu)paramu.j, this.A);
        } 
        paramu.j.d0();
        if (!callback.onCreatePanelMenu(paramu.a, (Menu)paramu.j)) {
          paramu.c(null);
          if (k != 0) {
            g01 = this.z;
            if (g01 != null)
              g01.a(null, this.A); 
          } 
          return false;
        } 
        ((u)g01).r = false;
      } 
      ((u)g01).j.d0();
      Bundle bundle = ((u)g01).s;
      if (bundle != null) {
        ((u)g01).j.P(bundle);
        ((u)g01).s = null;
      } 
      if (!callback.onPreparePanel(0, ((u)g01).i, (Menu)((u)g01).j)) {
        if (k != 0) {
          g02 = this.z;
          if (g02 != null)
            g02.a(null, this.A); 
        } 
        ((u)g01).j.c0();
        return false;
      } 
      if (g02 != null) {
        k = g02.getDeviceId();
      } else {
        k = -1;
      } 
      if (KeyCharacterMap.load(k).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((u)g01).p = bool;
      ((u)g01).j.setQwertyMode(bool);
      ((u)g01).j.c0();
    } 
    ((u)g01).m = true;
    ((u)g01).n = false;
    this.V = (u)g01;
    return true;
  }
  
  private void B0(boolean paramBoolean) {
    g0 g01 = this.z;
    if (g01 != null && g01.g() && (!ViewConfiguration.get(this.s).hasPermanentMenuKey() || this.z.d())) {
      Window.Callback callback = f0();
      if (!this.z.b() || !paramBoolean) {
        if (callback != null && !this.Z) {
          if (this.h0 && (this.i0 & 0x1) != 0) {
            this.t.getDecorView().removeCallbacks(this.j0);
            this.j0.run();
          } 
          u u2 = d0(0, true);
          g g1 = u2.j;
          if (g1 != null && !u2.r && callback.onPreparePanel(0, u2.i, (Menu)g1)) {
            callback.onMenuOpened(108, (Menu)u2.j);
            this.z.f();
          } 
        } 
        return;
      } 
      this.z.e();
      if (!this.Z) {
        callback.onPanelClosed(108, (Menu)(d0(0, true)).j);
        return;
      } 
      return;
    } 
    u u1 = d0(0, true);
    u1.q = true;
    O(u1, false);
    x0(u1, null);
  }
  
  private int C0(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    int k = paramInt;
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      k = 109;
    } 
    return k;
  }
  
  private boolean E0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.t.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (y.U((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  private boolean G(boolean paramBoolean) {
    if (this.Z)
      return false; 
    int k = J();
    paramBoolean = J0(n0(this.s, k), paramBoolean);
    if (k == 0) {
      c0(this.s).e();
    } else {
      q q2 = this.f0;
      if (q2 != null)
        q2.a(); 
    } 
    if (k == 3) {
      b0(this.s).e();
      return paramBoolean;
    } 
    q q1 = this.g0;
    if (q1 != null)
      q1.a(); 
    return paramBoolean;
  }
  
  private void H() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.J.findViewById(16908290);
    View view = this.t.getDecorView();
    contentFrameLayout.b(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.s.obtainStyledAttributes(e.j.y0);
    typedArray.getValue(e.j.K0, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(e.j.L0, contentFrameLayout.getMinWidthMinor());
    int k = e.j.I0;
    if (typedArray.hasValue(k))
      typedArray.getValue(k, contentFrameLayout.getFixedWidthMajor()); 
    k = e.j.J0;
    if (typedArray.hasValue(k))
      typedArray.getValue(k, contentFrameLayout.getFixedWidthMinor()); 
    k = e.j.G0;
    if (typedArray.hasValue(k))
      typedArray.getValue(k, contentFrameLayout.getFixedHeightMajor()); 
    k = e.j.H0;
    if (typedArray.hasValue(k))
      typedArray.getValue(k, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private void H0() {
    if (!this.I)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  private void I(Window paramWindow) {
    if (this.t == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof o)) {
        o o1 = new o(this, callback);
        this.u = o1;
        paramWindow.setCallback((Window.Callback)o1);
        a1 a1 = a1.u(this.s, null, r0);
        Drawable drawable = a1.h(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        a1.w();
        this.t = paramWindow;
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  private c I0() {
    Context context = this.s;
    while (context != null) {
      if (context instanceof c)
        return (c)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  private int J() {
    int k = this.b0;
    return (k != -100) ? k : e.j();
  }
  
  private boolean J0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield s : Landroid/content/Context;
    //   4: astore #9
    //   6: iconst_0
    //   7: istore #7
    //   9: aload_0
    //   10: aload #9
    //   12: iload_1
    //   13: aconst_null
    //   14: iconst_0
    //   15: invokespecial P : (Landroid/content/Context;ILandroid/content/res/Configuration;Z)Landroid/content/res/Configuration;
    //   18: astore #11
    //   20: aload_0
    //   21: aload_0
    //   22: getfield s : Landroid/content/Context;
    //   25: invokespecial l0 : (Landroid/content/Context;)Z
    //   28: istore #8
    //   30: aload_0
    //   31: getfield a0 : Landroid/content/res/Configuration;
    //   34: astore #10
    //   36: aload #10
    //   38: astore #9
    //   40: aload #10
    //   42: ifnonnull -> 57
    //   45: aload_0
    //   46: getfield s : Landroid/content/Context;
    //   49: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   52: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   55: astore #9
    //   57: aload #9
    //   59: getfield uiMode : I
    //   62: bipush #48
    //   64: iand
    //   65: istore_3
    //   66: aload #11
    //   68: getfield uiMode : I
    //   71: bipush #48
    //   73: iand
    //   74: istore #4
    //   76: iconst_1
    //   77: istore #6
    //   79: iload #7
    //   81: istore #5
    //   83: iload_3
    //   84: iload #4
    //   86: if_icmpeq -> 180
    //   89: iload #7
    //   91: istore #5
    //   93: iload_2
    //   94: ifeq -> 180
    //   97: iload #7
    //   99: istore #5
    //   101: iload #8
    //   103: ifne -> 180
    //   106: iload #7
    //   108: istore #5
    //   110: aload_0
    //   111: getfield X : Z
    //   114: ifeq -> 180
    //   117: getstatic androidx/appcompat/app/f.s0 : Z
    //   120: ifne -> 134
    //   123: iload #7
    //   125: istore #5
    //   127: aload_0
    //   128: getfield Y : Z
    //   131: ifeq -> 180
    //   134: aload_0
    //   135: getfield r : Ljava/lang/Object;
    //   138: astore #9
    //   140: iload #7
    //   142: istore #5
    //   144: aload #9
    //   146: instanceof android/app/Activity
    //   149: ifeq -> 180
    //   152: iload #7
    //   154: istore #5
    //   156: aload #9
    //   158: checkcast android/app/Activity
    //   161: invokevirtual isChild : ()Z
    //   164: ifne -> 180
    //   167: aload_0
    //   168: getfield r : Ljava/lang/Object;
    //   171: checkcast android/app/Activity
    //   174: invokestatic l : (Landroid/app/Activity;)V
    //   177: iconst_1
    //   178: istore #5
    //   180: iload #5
    //   182: ifne -> 207
    //   185: iload_3
    //   186: iload #4
    //   188: if_icmpeq -> 207
    //   191: aload_0
    //   192: iload #4
    //   194: iload #8
    //   196: aconst_null
    //   197: invokespecial K0 : (IZLandroid/content/res/Configuration;)V
    //   200: iload #6
    //   202: istore #5
    //   204: goto -> 207
    //   207: iload #5
    //   209: ifeq -> 235
    //   212: aload_0
    //   213: getfield r : Ljava/lang/Object;
    //   216: astore #9
    //   218: aload #9
    //   220: instanceof androidx/appcompat/app/c
    //   223: ifeq -> 235
    //   226: aload #9
    //   228: checkcast androidx/appcompat/app/c
    //   231: iload_1
    //   232: invokevirtual M : (I)V
    //   235: iload #5
    //   237: ireturn
  }
  
  private void K0(int paramInt, boolean paramBoolean, Configuration paramConfiguration) {
    Resources resources = this.s.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    if (paramConfiguration != null)
      configuration.updateFrom(paramConfiguration); 
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    resources.updateConfiguration(configuration, null);
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 26)
      k.a(resources); 
    int k = this.c0;
    if (k != 0) {
      this.s.setTheme(k);
      if (paramInt >= 23)
        this.s.getTheme().applyStyle(this.c0, true); 
    } 
    if (paramBoolean) {
      Object object = this.r;
      if (object instanceof Activity) {
        object = object;
        if (object instanceof androidx.lifecycle.m) {
          if (((androidx.lifecycle.m)object).a().b().c(androidx.lifecycle.i.c.q)) {
            object.onConfigurationChanged(configuration);
            return;
          } 
        } else if (this.Y && !this.Z) {
          object.onConfigurationChanged(configuration);
        } 
      } 
    } 
  }
  
  private void M() {
    q q1 = this.f0;
    if (q1 != null)
      q1.a(); 
    q1 = this.g0;
    if (q1 != null)
      q1.a(); 
  }
  
  private void M0(View paramView) {
    int k;
    if ((y.N(paramView) & 0x2000) != 0) {
      k = 1;
    } else {
      k = 0;
    } 
    if (k) {
      k = androidx.core.content.a.c(this.s, e.c.b);
    } else {
      k = androidx.core.content.a.c(this.s, e.c.a);
    } 
    paramView.setBackgroundColor(k);
  }
  
  private Configuration P(Context paramContext, int paramInt, Configuration paramConfiguration, boolean paramBoolean) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramBoolean) {
          paramInt = 0;
        } else {
          paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
        } 
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    return configuration;
  }
  
  private ViewGroup Q() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.s.obtainStyledAttributes(e.j.y0);
    int k = e.j.D0;
    if (typedArray.hasValue(k)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(e.j.M0, false)) {
        z(1);
      } else if (typedArray.getBoolean(k, false)) {
        z(108);
      } 
      if (typedArray.getBoolean(e.j.E0, false))
        z(109); 
      if (typedArray.getBoolean(e.j.F0, false))
        z(10); 
      this.R = typedArray.getBoolean(e.j.z0, false);
      typedArray.recycle();
      X();
      this.t.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.s);
      if (!this.S) {
        if (this.R) {
          viewGroup = (ViewGroup)layoutInflater.inflate(e.g.f, null);
          this.P = false;
          this.O = false;
        } else if (this.O) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.s.getTheme().resolveAttribute(e.a.f, typedValue, true);
          if (typedValue.resourceId != 0) {
            androidx.appcompat.view.d d1 = new androidx.appcompat.view.d(this.s, typedValue.resourceId);
          } else {
            context = this.s;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(e.g.p, null);
          g0 g01 = (g0)viewGroup1.findViewById(e.f.p);
          this.z = g01;
          g01.setWindowCallback(f0());
          if (this.P)
            this.z.k(109); 
          if (this.M)
            this.z.k(2); 
          viewGroup = viewGroup1;
          if (this.N) {
            this.z.k(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else if (this.Q) {
        viewGroup = (ViewGroup)layoutInflater.inflate(e.g.o, null);
      } else {
        viewGroup = (ViewGroup)viewGroup.inflate(e.g.n, null);
      } 
      if (viewGroup != null) {
        if (Build.VERSION.SDK_INT >= 21) {
          y.F0((View)viewGroup, new c(this));
        } else if (viewGroup instanceof k0) {
          ((k0)viewGroup).setOnFitSystemWindowsListener(new d(this));
        } 
        if (this.z == null)
          this.K = (TextView)viewGroup.findViewById(e.f.M); 
        j1.c((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(e.f.b);
        ViewGroup viewGroup1 = (ViewGroup)this.t.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.t.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new e(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.O);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.P);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.R);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.Q);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.S);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    IllegalStateException illegalStateException = new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
    throw illegalStateException;
  }
  
  private void W() {
    if (!this.I) {
      this.J = Q();
      CharSequence charSequence = e0();
      if (!TextUtils.isEmpty(charSequence)) {
        g0 g01 = this.z;
        if (g01 != null) {
          g01.setWindowTitle(charSequence);
        } else if (y0() != null) {
          y0().s(charSequence);
        } else {
          TextView textView = this.K;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      H();
      w0(this.J);
      this.I = true;
      u u1 = d0(0, false);
      if (!this.Z && (u1 == null || u1.j == null))
        k0(108); 
    } 
  }
  
  private void X() {
    if (this.t == null) {
      Object object = this.r;
      if (object instanceof Activity)
        I(((Activity)object).getWindow()); 
    } 
    if (this.t != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  private static Configuration Z(Configuration paramConfiguration1, Configuration paramConfiguration2) {
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration2 != null) {
      if (paramConfiguration1.diff(paramConfiguration2) == 0)
        return configuration; 
      float f1 = paramConfiguration1.fontScale;
      float f2 = paramConfiguration2.fontScale;
      if (f1 != f2)
        configuration.fontScale = f2; 
      int k = paramConfiguration1.mcc;
      int m = paramConfiguration2.mcc;
      if (k != m)
        configuration.mcc = m; 
      k = paramConfiguration1.mnc;
      m = paramConfiguration2.mnc;
      if (k != m)
        configuration.mnc = m; 
      k = Build.VERSION.SDK_INT;
      if (k >= 24) {
        m.a(paramConfiguration1, paramConfiguration2, configuration);
      } else if (!androidx.core.util.c.a(paramConfiguration1.locale, paramConfiguration2.locale)) {
        configuration.locale = paramConfiguration2.locale;
      } 
      m = paramConfiguration1.touchscreen;
      int n = paramConfiguration2.touchscreen;
      if (m != n)
        configuration.touchscreen = n; 
      m = paramConfiguration1.keyboard;
      n = paramConfiguration2.keyboard;
      if (m != n)
        configuration.keyboard = n; 
      m = paramConfiguration1.keyboardHidden;
      n = paramConfiguration2.keyboardHidden;
      if (m != n)
        configuration.keyboardHidden = n; 
      m = paramConfiguration1.navigation;
      n = paramConfiguration2.navigation;
      if (m != n)
        configuration.navigation = n; 
      m = paramConfiguration1.navigationHidden;
      n = paramConfiguration2.navigationHidden;
      if (m != n)
        configuration.navigationHidden = n; 
      m = paramConfiguration1.orientation;
      n = paramConfiguration2.orientation;
      if (m != n)
        configuration.orientation = n; 
      m = paramConfiguration1.screenLayout;
      n = paramConfiguration2.screenLayout;
      if ((m & 0xF) != (n & 0xF))
        configuration.screenLayout |= n & 0xF; 
      m = paramConfiguration1.screenLayout;
      n = paramConfiguration2.screenLayout;
      if ((m & 0xC0) != (n & 0xC0))
        configuration.screenLayout |= n & 0xC0; 
      m = paramConfiguration1.screenLayout;
      n = paramConfiguration2.screenLayout;
      if ((m & 0x30) != (n & 0x30))
        configuration.screenLayout |= n & 0x30; 
      m = paramConfiguration1.screenLayout;
      n = paramConfiguration2.screenLayout;
      if ((m & 0x300) != (n & 0x300))
        configuration.screenLayout |= n & 0x300; 
      if (k >= 26)
        n.a(paramConfiguration1, paramConfiguration2, configuration); 
      k = paramConfiguration1.uiMode;
      m = paramConfiguration2.uiMode;
      if ((k & 0xF) != (m & 0xF))
        configuration.uiMode |= m & 0xF; 
      k = paramConfiguration1.uiMode;
      m = paramConfiguration2.uiMode;
      if ((k & 0x30) != (m & 0x30))
        configuration.uiMode |= m & 0x30; 
      k = paramConfiguration1.screenWidthDp;
      m = paramConfiguration2.screenWidthDp;
      if (k != m)
        configuration.screenWidthDp = m; 
      k = paramConfiguration1.screenHeightDp;
      m = paramConfiguration2.screenHeightDp;
      if (k != m)
        configuration.screenHeightDp = m; 
      k = paramConfiguration1.smallestScreenWidthDp;
      m = paramConfiguration2.smallestScreenWidthDp;
      if (k != m)
        configuration.smallestScreenWidthDp = m; 
      k.b(paramConfiguration1, paramConfiguration2, configuration);
    } 
    return configuration;
  }
  
  private q b0(Context paramContext) {
    if (this.g0 == null)
      this.g0 = new p(this, paramContext); 
    return this.g0;
  }
  
  private q c0(Context paramContext) {
    if (this.f0 == null)
      this.f0 = new r(this, m.a(paramContext)); 
    return this.f0;
  }
  
  private void g0() {
    W();
    if (this.O) {
      if (this.w != null)
        return; 
      Object object = this.r;
      if (object instanceof Activity) {
        this.w = new n((Activity)this.r, this.P);
      } else if (object instanceof Dialog) {
        this.w = new n((Dialog)this.r);
      } 
      object = this.w;
      if (object != null)
        object.q(this.k0); 
    } 
  }
  
  private boolean h0(u paramu) {
    View view = paramu.i;
    if (view != null) {
      paramu.h = view;
      return true;
    } 
    if (paramu.j == null)
      return false; 
    if (this.B == null)
      this.B = new v(this); 
    view = (View)paramu.a(this.B);
    paramu.h = view;
    return (view != null);
  }
  
  private boolean i0(u paramu) {
    paramu.d(a0());
    paramu.g = (ViewGroup)new t(this, paramu.l);
    paramu.c = 81;
    return true;
  }
  
  private boolean j0(u paramu) {
    // Byte code:
    //   0: aload_0
    //   1: getfield s : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield z : Landroidx/appcompat/widget/g0;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #6
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #7
    //   50: aload #7
    //   52: getstatic e/a.f : I
    //   55: aload #6
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aconst_null
    //   63: astore_3
    //   64: aload #6
    //   66: getfield resourceId : I
    //   69: ifeq -> 111
    //   72: aload #5
    //   74: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   77: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   80: astore_3
    //   81: aload_3
    //   82: aload #7
    //   84: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   87: aload_3
    //   88: aload #6
    //   90: getfield resourceId : I
    //   93: iconst_1
    //   94: invokevirtual applyStyle : (IZ)V
    //   97: aload_3
    //   98: getstatic e/a.g : I
    //   101: aload #6
    //   103: iconst_1
    //   104: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   107: pop
    //   108: goto -> 123
    //   111: aload #7
    //   113: getstatic e/a.g : I
    //   116: aload #6
    //   118: iconst_1
    //   119: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   122: pop
    //   123: aload_3
    //   124: astore #4
    //   126: aload #6
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #7
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #6
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new androidx/appcompat/view/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new androidx/appcompat/view/menu/g
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual R : (Landroidx/appcompat/view/menu/g$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Landroidx/appcompat/view/menu/g;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  private void k0(int paramInt) {
    this.i0 = 1 << paramInt | this.i0;
    if (!this.h0) {
      y.j0(this.t.getDecorView(), this.j0);
      this.h0 = true;
    } 
  }
  
  private boolean l0(Context paramContext) {
    if (!this.e0 && this.r instanceof Activity) {
      PackageManager packageManager = paramContext.getPackageManager();
      if (packageManager == null)
        return false; 
      try {
        boolean bool;
        int k = Build.VERSION.SDK_INT;
        if (k >= 29) {
          k = 269221888;
        } else if (k >= 24) {
          k = 786432;
        } else {
          k = 0;
        } 
        ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(paramContext, this.r.getClass()), k);
        if (activityInfo != null && (activityInfo.configChanges & 0x200) != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        this.d0 = bool;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
        this.d0 = false;
      } 
    } 
    this.e0 = true;
    return this.d0;
  }
  
  private boolean q0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      u u1 = d0(paramInt, true);
      if (!u1.o)
        return A0(u1, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean t0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield C : Landroidx/appcompat/view/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual d0 : (IZ)Landroidx/appcompat/app/f$u;
    //   18: astore #5
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield z : Landroidx/appcompat/widget/g0;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 113
    //   35: aload #6
    //   37: invokeinterface g : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield s : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield z : Landroidx/appcompat/widget/g0;
    //   62: invokeinterface b : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield Z : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #5
    //   80: aload_2
    //   81: invokespecial A0 : (Landroidx/appcompat/app/f$u;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield z : Landroidx/appcompat/widget/g0;
    //   91: invokeinterface f : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield z : Landroidx/appcompat/widget/g0;
    //   104: invokeinterface e : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #5
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #5
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #5
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #5
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #5
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #5
    //   159: aload_2
    //   160: invokespecial A0 : (Landroidx/appcompat/app/f$u;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #5
    //   176: aload_2
    //   177: invokespecial x0 : (Landroidx/appcompat/app/f$u;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #5
    //   194: iconst_1
    //   195: invokevirtual O : (Landroidx/appcompat/app/f$u;Z)V
    //   198: iload_3
    //   199: ifeq -> 240
    //   202: aload_0
    //   203: getfield s : Landroid/content/Context;
    //   206: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   209: ldc_w 'audio'
    //   212: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   215: checkcast android/media/AudioManager
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 230
    //   223: aload_2
    //   224: iconst_0
    //   225: invokevirtual playSoundEffect : (I)V
    //   228: iload_3
    //   229: ireturn
    //   230: ldc_w 'AppCompatDelegate'
    //   233: ldc_w 'Couldn't get audio manager'
    //   236: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: iload_3
    //   241: ireturn
  }
  
  private void x0(u paramu, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 405
    //   7: aload_0
    //   8: getfield Z : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield s : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual f0 : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Landroidx/appcompat/view/menu/g;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual O : (Landroidx/appcompat/app/f$u;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield s : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokespecial A0 : (Landroidx/appcompat/app/f$u;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield q : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield i : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 331
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 331
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 331
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 334
    //   171: aload_2
    //   172: ifnonnull -> 191
    //   175: aload_0
    //   176: aload_1
    //   177: invokespecial i0 : (Landroidx/appcompat/app/f$u;)Z
    //   180: ifeq -> 190
    //   183: aload_1
    //   184: getfield g : Landroid/view/ViewGroup;
    //   187: ifnonnull -> 212
    //   190: return
    //   191: aload_1
    //   192: getfield q : Z
    //   195: ifeq -> 212
    //   198: aload_2
    //   199: invokevirtual getChildCount : ()I
    //   202: ifle -> 212
    //   205: aload_1
    //   206: getfield g : Landroid/view/ViewGroup;
    //   209: invokevirtual removeAllViews : ()V
    //   212: aload_0
    //   213: aload_1
    //   214: invokespecial h0 : (Landroidx/appcompat/app/f$u;)Z
    //   217: ifeq -> 400
    //   220: aload_1
    //   221: invokevirtual b : ()Z
    //   224: ifne -> 230
    //   227: goto -> 400
    //   230: aload_1
    //   231: getfield h : Landroid/view/View;
    //   234: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   237: astore #4
    //   239: aload #4
    //   241: astore_2
    //   242: aload #4
    //   244: ifnonnull -> 259
    //   247: new android/view/ViewGroup$LayoutParams
    //   250: dup
    //   251: bipush #-2
    //   253: bipush #-2
    //   255: invokespecial <init> : (II)V
    //   258: astore_2
    //   259: aload_1
    //   260: getfield b : I
    //   263: istore_3
    //   264: aload_1
    //   265: getfield g : Landroid/view/ViewGroup;
    //   268: iload_3
    //   269: invokevirtual setBackgroundResource : (I)V
    //   272: aload_1
    //   273: getfield h : Landroid/view/View;
    //   276: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   279: astore #4
    //   281: aload #4
    //   283: instanceof android/view/ViewGroup
    //   286: ifeq -> 301
    //   289: aload #4
    //   291: checkcast android/view/ViewGroup
    //   294: aload_1
    //   295: getfield h : Landroid/view/View;
    //   298: invokevirtual removeView : (Landroid/view/View;)V
    //   301: aload_1
    //   302: getfield g : Landroid/view/ViewGroup;
    //   305: aload_1
    //   306: getfield h : Landroid/view/View;
    //   309: aload_2
    //   310: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   313: aload_1
    //   314: getfield h : Landroid/view/View;
    //   317: invokevirtual hasFocus : ()Z
    //   320: ifne -> 331
    //   323: aload_1
    //   324: getfield h : Landroid/view/View;
    //   327: invokevirtual requestFocus : ()Z
    //   330: pop
    //   331: bipush #-2
    //   333: istore_3
    //   334: aload_1
    //   335: iconst_0
    //   336: putfield n : Z
    //   339: new android/view/WindowManager$LayoutParams
    //   342: dup
    //   343: iload_3
    //   344: bipush #-2
    //   346: aload_1
    //   347: getfield d : I
    //   350: aload_1
    //   351: getfield e : I
    //   354: sipush #1002
    //   357: ldc_w 8519680
    //   360: bipush #-3
    //   362: invokespecial <init> : (IIIIIII)V
    //   365: astore_2
    //   366: aload_2
    //   367: aload_1
    //   368: getfield c : I
    //   371: putfield gravity : I
    //   374: aload_2
    //   375: aload_1
    //   376: getfield f : I
    //   379: putfield windowAnimations : I
    //   382: aload #5
    //   384: aload_1
    //   385: getfield g : Landroid/view/ViewGroup;
    //   388: aload_2
    //   389: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   394: aload_1
    //   395: iconst_1
    //   396: putfield o : Z
    //   399: return
    //   400: aload_1
    //   401: iconst_1
    //   402: putfield q : Z
    //   405: return
  }
  
  private boolean z0(u paramu, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokespecial A0 : (Landroidx/appcompat/app/f$u;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Landroidx/appcompat/view/menu/g;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield z : Landroidx/appcompat/widget/g0;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual O : (Landroidx/appcompat/app/f$u;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  public void A(int paramInt) {
    W();
    ViewGroup viewGroup = (ViewGroup)this.J.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.s).inflate(paramInt, viewGroup);
    this.u.c(this.t.getCallback());
  }
  
  public void B(View paramView) {
    W();
    ViewGroup viewGroup = (ViewGroup)this.J.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.u.c(this.t.getCallback());
  }
  
  public void C(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    W();
    ViewGroup viewGroup = (ViewGroup)this.J.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.u.c(this.t.getCallback());
  }
  
  public void D(int paramInt) {
    this.c0 = paramInt;
  }
  
  final boolean D0() {
    if (this.I) {
      ViewGroup viewGroup = this.J;
      if (viewGroup != null && y.V((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  public final void E(CharSequence paramCharSequence) {
    this.y = paramCharSequence;
    g0 g01 = this.z;
    if (g01 != null) {
      g01.setWindowTitle(paramCharSequence);
      return;
    } 
    if (y0() != null) {
      y0().s(paramCharSequence);
      return;
    } 
    TextView textView = this.K;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public boolean F() {
    return G(true);
  }
  
  public androidx.appcompat.view.b F0(androidx.appcompat.view.b.a parama) {
    if (parama != null) {
      androidx.appcompat.view.b b1 = this.C;
      if (b1 != null)
        b1.c(); 
      parama = new j(this, parama);
      a a1 = m();
      if (a1 != null) {
        androidx.appcompat.view.b b2 = a1.t(parama);
        this.C = b2;
        if (b2 != null) {
          d d1 = this.v;
          if (d1 != null)
            d1.f(b2); 
        } 
      } 
      if (this.C == null)
        this.C = G0(parama); 
      return this.C;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  androidx.appcompat.view.b G0(androidx.appcompat.view.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual V : ()V
    //   4: aload_0
    //   5: getfield C : Landroidx/appcompat/view/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual c : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof androidx/appcompat/app/f$j
    //   27: ifne -> 41
    //   30: new androidx/appcompat/app/f$j
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Landroidx/appcompat/app/f;Landroidx/appcompat/view/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield v : Landroidx/appcompat/app/d;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield Z : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface l : (Landroidx/appcompat/view/b$a;)Landroidx/appcompat/view/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield C : Landroidx/appcompat/view/b;
    //   80: goto -> 565
    //   83: aload_0
    //   84: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield R : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield s : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic e/a.f : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield s : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new androidx/appcompat/view/d
    //   169: dup
    //   170: aload_0
    //   171: getfield s : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield s : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic e/a.i : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield E : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield E : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield E : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic e/a.b : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield E : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new androidx/appcompat/app/f$f
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Landroidx/appcompat/app/f;)V
    //   309: putfield F : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield J : Landroid/view/ViewGroup;
    //   319: getstatic e/f.h : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual a0 : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual a : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 565
    //   362: aload_0
    //   363: invokevirtual V : ()V
    //   366: aload_0
    //   367: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual k : ()V
    //   373: aload_0
    //   374: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore_1
    //   381: aload_0
    //   382: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   385: astore #5
    //   387: aload_0
    //   388: getfield E : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new androidx/appcompat/view/e
    //   402: dup
    //   403: aload_1
    //   404: aload #5
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Landroidx/appcompat/view/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual e : ()Landroid/view/Menu;
    //   420: invokeinterface d : (Landroidx/appcompat/view/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 560
    //   428: aload_1
    //   429: invokevirtual k : ()V
    //   432: aload_0
    //   433: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual h : (Landroidx/appcompat/view/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield C : Landroidx/appcompat/view/b;
    //   445: aload_0
    //   446: invokevirtual D0 : ()Z
    //   449: ifeq -> 493
    //   452: aload_0
    //   453: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic e : (Landroid/view/View;)Landroidx/core/view/e0;
    //   467: fconst_1
    //   468: invokevirtual b : (F)Landroidx/core/view/e0;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield G : Landroidx/core/view/e0;
    //   477: aload_1
    //   478: new androidx/appcompat/app/f$g
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/appcompat/app/f;)V
    //   486: invokevirtual h : (Landroidx/core/view/f0;)Landroidx/core/view/e0;
    //   489: pop
    //   490: goto -> 535
    //   493: aload_0
    //   494: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   497: fconst_1
    //   498: invokevirtual setAlpha : (F)V
    //   501: aload_0
    //   502: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   505: iconst_0
    //   506: invokevirtual setVisibility : (I)V
    //   509: aload_0
    //   510: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   513: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   516: instanceof android/view/View
    //   519: ifeq -> 535
    //   522: aload_0
    //   523: getfield D : Landroidx/appcompat/widget/ActionBarContextView;
    //   526: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   529: checkcast android/view/View
    //   532: invokestatic o0 : (Landroid/view/View;)V
    //   535: aload_0
    //   536: getfield E : Landroid/widget/PopupWindow;
    //   539: ifnull -> 565
    //   542: aload_0
    //   543: getfield t : Landroid/view/Window;
    //   546: invokevirtual getDecorView : ()Landroid/view/View;
    //   549: aload_0
    //   550: getfield F : Ljava/lang/Runnable;
    //   553: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   556: pop
    //   557: goto -> 565
    //   560: aload_0
    //   561: aconst_null
    //   562: putfield C : Landroidx/appcompat/view/b;
    //   565: aload_0
    //   566: getfield C : Landroidx/appcompat/view/b;
    //   569: astore_1
    //   570: aload_1
    //   571: ifnull -> 593
    //   574: aload_0
    //   575: getfield v : Landroidx/appcompat/app/d;
    //   578: astore #4
    //   580: aload #4
    //   582: ifnull -> 593
    //   585: aload #4
    //   587: aload_1
    //   588: invokeinterface f : (Landroidx/appcompat/view/b;)V
    //   593: aload_0
    //   594: getfield C : Landroidx/appcompat/view/b;
    //   597: areturn
    //   598: astore_1
    //   599: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	598	java/lang/AbstractMethodError
  }
  
  void K(int paramInt, u paramu, Menu paramMenu) {
    g g1;
    u u1 = paramu;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      u u2 = paramu;
      if (paramu == null) {
        u2 = paramu;
        if (paramInt >= 0) {
          u[] arrayOfU = this.U;
          u2 = paramu;
          if (paramInt < arrayOfU.length)
            u2 = arrayOfU[paramInt]; 
        } 
      } 
      u1 = u2;
      menu = paramMenu;
      if (u2 != null) {
        g1 = u2.j;
        u1 = u2;
      } 
    } 
    if (u1 != null && !u1.o)
      return; 
    if (!this.Z)
      this.u.d(this.t.getCallback(), paramInt, (Menu)g1); 
  }
  
  void L(g paramg) {
    if (this.T)
      return; 
    this.T = true;
    this.z.l();
    Window.Callback callback = f0();
    if (callback != null && !this.Z)
      callback.onPanelClosed(108, (Menu)paramg); 
    this.T = false;
  }
  
  final int L0(j0 paramj0, Rect paramRect) {
    int k;
    int m;
    boolean bool1;
    boolean bool2 = false;
    if (paramj0 != null) {
      k = paramj0.k();
    } else if (paramRect != null) {
      k = paramRect.top;
    } else {
      k = 0;
    } 
    ActionBarContextView actionBarContextView = this.D;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.D.getLayoutParams();
      boolean bool3 = this.D.isShown();
      int n = 1;
      bool1 = true;
      if (bool3) {
        int i1;
        if (this.l0 == null) {
          this.l0 = new Rect();
          this.m0 = new Rect();
        } 
        Rect rect1 = this.l0;
        Rect rect2 = this.m0;
        if (paramj0 == null) {
          rect1.set(paramRect);
        } else {
          rect1.set(paramj0.i(), paramj0.k(), paramj0.j(), paramj0.h());
        } 
        j1.a((View)this.J, rect1, rect2);
        int i2 = rect1.top;
        bool = rect1.left;
        int i3 = rect1.right;
        paramj0 = y.K((View)this.J);
        if (paramj0 == null) {
          n = 0;
        } else {
          n = paramj0.i();
        } 
        if (paramj0 == null) {
          i1 = 0;
        } else {
          i1 = paramj0.j();
        } 
        if (marginLayoutParams.topMargin != i2 || marginLayoutParams.leftMargin != bool || marginLayoutParams.rightMargin != i3) {
          marginLayoutParams.topMargin = i2;
          marginLayoutParams.leftMargin = bool;
          marginLayoutParams.rightMargin = i3;
          bool = true;
        } else {
          bool = false;
        } 
        if (i2 > 0 && this.L == null) {
          View view2 = new View(this.s);
          this.L = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = n;
          layoutParams.rightMargin = i1;
          this.J.addView(this.L, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.L;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            i2 = marginLayoutParams1.height;
            i3 = marginLayoutParams.topMargin;
            if (i2 != i3 || marginLayoutParams1.leftMargin != n || marginLayoutParams1.rightMargin != i1) {
              marginLayoutParams1.height = i3;
              marginLayoutParams1.leftMargin = n;
              marginLayoutParams1.rightMargin = i1;
              this.L.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.L;
        if (view1 != null) {
          i1 = bool1;
        } else {
          i1 = 0;
        } 
        if (i1 != 0 && view1.getVisibility() != 0)
          M0(this.L); 
        n = k;
        if (!this.Q) {
          n = k;
          if (i1 != 0)
            n = 0; 
        } 
        k = n;
        n = bool;
        bool = i1;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
      } else {
        bool = false;
        n = 0;
      } 
      m = k;
      bool1 = bool;
      if (n != 0) {
        this.D.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        m = k;
        bool1 = bool;
      } 
    } else {
      bool1 = false;
      m = k;
    } 
    View view = this.L;
    if (view != null) {
      if (bool1) {
        k = bool2;
      } else {
        k = 8;
      } 
      view.setVisibility(k);
    } 
    return m;
  }
  
  void N(int paramInt) {
    O(d0(paramInt, true), true);
  }
  
  void O(u paramu, boolean paramBoolean) {
    if (paramBoolean && paramu.a == 0) {
      g0 g01 = this.z;
      if (g01 != null && g01.b()) {
        L(paramu.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.s.getSystemService("window");
    if (windowManager != null && paramu.o) {
      ViewGroup viewGroup = paramu.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          K(paramu.a, paramu, null); 
      } 
    } 
    paramu.m = false;
    paramu.n = false;
    paramu.o = false;
    paramu.h = null;
    paramu.q = true;
    if (this.V == paramu)
      this.V = null; 
  }
  
  public View R(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    i i1 = this.n0;
    boolean bool1 = false;
    if (i1 == null) {
      String str = this.s.obtainStyledAttributes(e.j.y0).getString(e.j.C0);
      if (str == null) {
        this.n0 = new i();
      } else {
        try {
          this.n0 = this.s.getClassLoader().loadClass(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } finally {
          Exception exception = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), exception);
        } 
      } 
    } 
    boolean bool2 = q0;
    if (bool2) {
      if (this.o0 == null)
        this.o0 = new j(); 
      if (this.o0.a(paramAttributeSet)) {
        bool1 = true;
      } else if (paramAttributeSet instanceof XmlPullParser) {
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = true; 
      } else {
        bool1 = E0((ViewParent)paramView);
      } 
    } else {
      bool1 = false;
    } 
    return this.n0.r(paramView, paramString, paramContext, paramAttributeSet, bool1, bool2, true, i1.c());
  }
  
  void S() {
    g0 g01 = this.z;
    if (g01 != null)
      g01.l(); 
    if (this.E != null) {
      this.t.getDecorView().removeCallbacks(this.F);
      if (this.E.isShowing())
        try {
          this.E.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.E = null;
    } 
    V();
    u u1 = d0(0, false);
    if (u1 != null) {
      g g1 = u1.j;
      if (g1 != null)
        g1.close(); 
    } 
  }
  
  boolean T(KeyEvent paramKeyEvent) {
    Object object = this.r;
    boolean bool1 = object instanceof androidx.core.view.f.a;
    boolean bool = true;
    if (bool1 || object instanceof h) {
      object = this.t.getDecorView();
      if (object != null && androidx.core.view.f.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.u.b(this.t.getCallback(), paramKeyEvent))
      return true; 
    int k = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? p0(k, paramKeyEvent) : s0(k, paramKeyEvent);
  }
  
  void U(int paramInt) {
    u u1 = d0(paramInt, true);
    if (u1.j != null) {
      Bundle bundle = new Bundle();
      u1.j.Q(bundle);
      if (bundle.size() > 0)
        u1.s = bundle; 
      u1.j.d0();
      u1.j.clear();
    } 
    u1.r = true;
    u1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.z != null) {
      u1 = d0(0, false);
      if (u1 != null) {
        u1.m = false;
        A0(u1, null);
      } 
    } 
  }
  
  void V() {
    e0 e01 = this.G;
    if (e01 != null)
      e01.c(); 
  }
  
  u Y(Menu paramMenu) {
    byte b1;
    u[] arrayOfU = this.U;
    int k = 0;
    if (arrayOfU != null) {
      b1 = arrayOfU.length;
    } else {
      b1 = 0;
    } 
    while (k < b1) {
      u u1 = arrayOfU[k];
      if (u1 != null && u1.j == paramMenu)
        return u1; 
      k++;
    } 
    return null;
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    Window.Callback callback = f0();
    if (callback != null && !this.Z) {
      u u1 = Y((Menu)paramg.D());
      if (u1 != null)
        return callback.onMenuItemSelected(u1.a, paramMenuItem); 
    } 
    return false;
  }
  
  final Context a0() {
    Context context;
    a a1 = m();
    if (a1 != null) {
      Context context1 = a1.j();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null)
      context = this.s; 
    return context;
  }
  
  public void b(g paramg) {
    B0(true);
  }
  
  public void d(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    W();
    ((ViewGroup)this.J.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.u.c(this.t.getCallback());
  }
  
  protected u d0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield U : [Landroidx/appcompat/app/f$u;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray androidx/appcompat/app/f$u
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield U : [Landroidx/appcompat/app/f$u;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new androidx/appcompat/app/f$u
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  final CharSequence e0() {
    Object object = this.r;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.y;
  }
  
  public Context f(Context paramContext) {
    boolean bool1 = true;
    this.X = true;
    int k = n0(paramContext, J());
    boolean bool = t0;
    Configuration configuration1 = null;
    boolean bool2 = false;
    if (bool && paramContext instanceof ContextThemeWrapper) {
      Configuration configuration = P(paramContext, k, null, false);
      try {
        s.a((ContextThemeWrapper)paramContext, configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (paramContext instanceof androidx.appcompat.view.d) {
      Configuration configuration = P(paramContext, k, null, false);
      try {
        ((androidx.appcompat.view.d)paramContext).a(configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (!s0)
      return super.f(paramContext); 
    Configuration configuration2 = new Configuration();
    configuration2.uiMode = -1;
    configuration2.fontScale = 0.0F;
    configuration2 = k.a(paramContext, configuration2).getResources().getConfiguration();
    Configuration configuration3 = paramContext.getResources().getConfiguration();
    configuration2.uiMode = configuration3.uiMode;
    if (!configuration2.equals(configuration3))
      configuration1 = Z(configuration2, configuration3); 
    configuration2 = P(paramContext, k, configuration1, true);
    androidx.appcompat.view.d d1 = new androidx.appcompat.view.d(paramContext, e.i.c);
    d1.a(configuration2);
    try {
      Resources.Theme theme = paramContext.getTheme();
      if (theme == null)
        bool1 = false; 
    } catch (NullPointerException nullPointerException) {
      bool1 = bool2;
    } 
    if (bool1)
      androidx.core.content.res.h.g.a(d1.getTheme()); 
    return super.f((Context)d1);
  }
  
  final Window.Callback f0() {
    return this.t.getCallback();
  }
  
  public <T extends View> T i(int paramInt) {
    W();
    return (T)this.t.findViewById(paramInt);
  }
  
  public int k() {
    return this.b0;
  }
  
  public MenuInflater l() {
    if (this.x == null) {
      Context context;
      g0();
      a a1 = this.w;
      if (a1 != null) {
        context = a1.j();
      } else {
        context = this.s;
      } 
      this.x = (MenuInflater)new androidx.appcompat.view.g(context);
    } 
    return this.x;
  }
  
  public a m() {
    g0();
    return this.w;
  }
  
  public boolean m0() {
    return this.H;
  }
  
  public void n() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.s);
    if (layoutInflater.getFactory() == null) {
      androidx.core.view.g.b(layoutInflater, this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof f))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  int n0(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1)
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3)
              return b0(paramContext).c(); 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          return (Build.VERSION.SDK_INT >= 23 && ((UiModeManager)paramContext.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) ? -1 : c0(paramContext).c();
        }  
      return paramInt;
    } 
    return -1;
  }
  
  public void o() {
    if (y0() != null) {
      if (m().k())
        return; 
      k0(0);
    } 
  }
  
  boolean o0() {
    androidx.appcompat.view.b b1 = this.C;
    if (b1 != null) {
      b1.c();
      return true;
    } 
    a a1 = m();
    return (a1 != null && a1.g());
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return R(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void p(Configuration paramConfiguration) {
    if (this.O && this.I) {
      a a1 = m();
      if (a1 != null)
        a1.l(paramConfiguration); 
    } 
    androidx.appcompat.widget.k.b().g(this.s);
    this.a0 = new Configuration(this.s.getResources().getConfiguration());
    G(false);
    paramConfiguration.updateFrom(this.s.getResources().getConfiguration());
  }
  
  boolean p0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      q0(0, paramKeyEvent);
      return true;
    } 
    if ((paramKeyEvent.getFlags() & 0x80) == 0)
      bool = false; 
    this.W = bool;
    return false;
  }
  
  public void q(Bundle paramBundle) {
    this.X = true;
    G(false);
    X();
    Object object = this.r;
    if (object instanceof Activity) {
      Object object1;
      paramBundle = null;
      try {
        object = androidx.core.app.j.c((Activity)object);
        object1 = object;
      } catch (IllegalArgumentException illegalArgumentException) {}
      if (object1 != null) {
        object1 = y0();
        if (object1 == null) {
          this.k0 = true;
        } else {
          object1.q(true);
        } 
      } 
      e.c(this);
    } 
    this.a0 = new Configuration(this.s.getResources().getConfiguration());
    this.Y = true;
  }
  
  public void r() {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 14
    //   10: aload_0
    //   11: invokestatic x : (Landroidx/appcompat/app/e;)V
    //   14: aload_0
    //   15: getfield h0 : Z
    //   18: ifeq -> 36
    //   21: aload_0
    //   22: getfield t : Landroid/view/Window;
    //   25: invokevirtual getDecorView : ()Landroid/view/View;
    //   28: aload_0
    //   29: getfield j0 : Ljava/lang/Runnable;
    //   32: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   35: pop
    //   36: aload_0
    //   37: iconst_1
    //   38: putfield Z : Z
    //   41: aload_0
    //   42: getfield b0 : I
    //   45: bipush #-100
    //   47: if_icmpeq -> 99
    //   50: aload_0
    //   51: getfield r : Ljava/lang/Object;
    //   54: astore_1
    //   55: aload_1
    //   56: instanceof android/app/Activity
    //   59: ifeq -> 99
    //   62: aload_1
    //   63: checkcast android/app/Activity
    //   66: invokevirtual isChangingConfigurations : ()Z
    //   69: ifeq -> 99
    //   72: getstatic androidx/appcompat/app/f.p0 : Lo/g;
    //   75: aload_0
    //   76: getfield r : Ljava/lang/Object;
    //   79: invokevirtual getClass : ()Ljava/lang/Class;
    //   82: invokevirtual getName : ()Ljava/lang/String;
    //   85: aload_0
    //   86: getfield b0 : I
    //   89: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   92: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   95: pop
    //   96: goto -> 116
    //   99: getstatic androidx/appcompat/app/f.p0 : Lo/g;
    //   102: aload_0
    //   103: getfield r : Ljava/lang/Object;
    //   106: invokevirtual getClass : ()Ljava/lang/Class;
    //   109: invokevirtual getName : ()Ljava/lang/String;
    //   112: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   115: pop
    //   116: aload_0
    //   117: getfield w : Landroidx/appcompat/app/a;
    //   120: astore_1
    //   121: aload_1
    //   122: ifnull -> 129
    //   125: aload_1
    //   126: invokevirtual m : ()V
    //   129: aload_0
    //   130: invokespecial M : ()V
    //   133: return
  }
  
  boolean r0(int paramInt, KeyEvent paramKeyEvent) {
    u u1;
    a a1 = m();
    if (a1 != null && a1.n(paramInt, paramKeyEvent))
      return true; 
    u u2 = this.V;
    if (u2 != null && z0(u2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      u1 = this.V;
      if (u1 != null)
        u1.n = true; 
      return true;
    } 
    if (this.V == null) {
      u2 = d0(0, true);
      A0(u2, (KeyEvent)u1);
      boolean bool = z0(u2, u1.getKeyCode(), (KeyEvent)u1, 1);
      u2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void s(Bundle paramBundle) {
    W();
  }
  
  boolean s0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      t0(0, paramKeyEvent);
      return true;
    } 
    boolean bool = this.W;
    this.W = false;
    u u1 = d0(0, false);
    if (u1 != null && u1.o) {
      if (!bool)
        O(u1, true); 
      return true;
    } 
    return o0();
  }
  
  public void t() {
    a a1 = m();
    if (a1 != null)
      a1.r(true); 
  }
  
  public void u(Bundle paramBundle) {}
  
  void u0(int paramInt) {
    if (paramInt == 108) {
      a a1 = m();
      if (a1 != null)
        a1.h(true); 
    } 
  }
  
  public void v() {
    F();
  }
  
  void v0(int paramInt) {
    if (paramInt == 108) {
      a a1 = m();
      if (a1 != null) {
        a1.h(false);
        return;
      } 
    } else if (paramInt == 0) {
      u u1 = d0(paramInt, true);
      if (u1.o)
        O(u1, false); 
    } 
  }
  
  public void w() {
    a a1 = m();
    if (a1 != null)
      a1.r(false); 
  }
  
  void w0(ViewGroup paramViewGroup) {}
  
  final a y0() {
    return this.w;
  }
  
  public boolean z(int paramInt) {
    paramInt = C0(paramInt);
    if (this.S && paramInt == 108)
      return false; 
    if (this.O && paramInt == 1)
      this.O = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.t.requestFeature(paramInt); 
              H0();
              this.P = true;
              return true;
            } 
            H0();
            this.O = true;
            return true;
          } 
          H0();
          this.Q = true;
          return true;
        } 
        H0();
        this.N = true;
        return true;
      } 
      H0();
      this.M = true;
      return true;
    } 
    H0();
    this.S = true;
    return true;
  }
  
  static {
    boolean bool;
  }
  
  static {
    if (Build.VERSION.SDK_INT < 21) {
      bool = true;
    } else {
      bool = false;
    } 
    q0 = bool;
  }
  
  class a implements Thread.UncaughtExceptionHandler {
    a(f this$0) {}
    
    private boolean a(Throwable param1Throwable) {
      boolean bool1 = param1Throwable instanceof Resources.NotFoundException;
      boolean bool = false;
      null = bool;
      if (bool1) {
        String str = param1Throwable.getMessage();
        null = bool;
        if (str != null) {
          if (!str.contains("drawable")) {
            null = bool;
            return str.contains("Drawable") ? true : null;
          } 
        } else {
          return null;
        } 
      } else {
        return null;
      } 
      return true;
    }
    
    public void uncaughtException(Thread param1Thread, Throwable param1Throwable) {
      if (a(param1Throwable)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1Throwable.getMessage());
        stringBuilder.append(". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
        Resources.NotFoundException notFoundException = new Resources.NotFoundException(stringBuilder.toString());
        notFoundException.initCause(param1Throwable.getCause());
        notFoundException.setStackTrace(param1Throwable.getStackTrace());
        this.a.uncaughtException(param1Thread, (Throwable)notFoundException);
        return;
      } 
      this.a.uncaughtException(param1Thread, param1Throwable);
    }
  }
  
  class b implements Runnable {
    b(f this$0) {}
    
    public void run() {
      f f1 = this.o;
      if ((f1.i0 & 0x1) != 0)
        f1.U(0); 
      f1 = this.o;
      if ((f1.i0 & 0x1000) != 0)
        f1.U(108); 
      f1 = this.o;
      f1.h0 = false;
      f1.i0 = 0;
    }
  }
  
  class c implements androidx.core.view.s {
    c(f this$0) {}
    
    public j0 a(View param1View, j0 param1j0) {
      int i = param1j0.k();
      int j = this.a.L0(param1j0, null);
      j0 j01 = param1j0;
      if (i != j)
        j01 = param1j0.o(param1j0.i(), j, param1j0.j(), param1j0.h()); 
      return y.d0(param1View, j01);
    }
  }
  
  class d implements k0.a {
    d(f this$0) {}
    
    public void a(Rect param1Rect) {
      param1Rect.top = this.a.L0(null, param1Rect);
    }
  }
  
  class e implements ContentFrameLayout.a {
    e(f this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.S();
    }
  }
  
  class f implements Runnable {
    f(f this$0) {}
    
    public void run() {
      f f1 = this.o;
      f1.E.showAtLocation((View)f1.D, 55, 0, 0);
      this.o.V();
      if (this.o.D0()) {
        this.o.D.setAlpha(0.0F);
        f1 = this.o;
        f1.G = y.e((View)f1.D).b(1.0F);
        this.o.G.h((f0)new a(this));
        return;
      } 
      this.o.D.setAlpha(1.0F);
      this.o.D.setVisibility(0);
    }
    
    class a extends g0 {
      a(f.f this$0) {}
      
      public void b(View param2View) {
        this.a.o.D.setAlpha(1.0F);
        this.a.o.G.h(null);
        this.a.o.G = null;
      }
      
      public void c(View param2View) {
        this.a.o.D.setVisibility(0);
      }
    }
  }
  
  class a extends g0 {
    a(f this$0) {}
    
    public void b(View param1View) {
      this.a.o.D.setAlpha(1.0F);
      this.a.o.G.h(null);
      this.a.o.G = null;
    }
    
    public void c(View param1View) {
      this.a.o.D.setVisibility(0);
    }
  }
  
  class g extends g0 {
    g(f this$0) {}
    
    public void b(View param1View) {
      this.a.D.setAlpha(1.0F);
      this.a.G.h(null);
      this.a.G = null;
    }
    
    public void c(View param1View) {
      this.a.D.setVisibility(0);
      if (this.a.D.getParent() instanceof View)
        y.o0((View)this.a.D.getParent()); 
    }
  }
  
  static interface h {
    boolean a(int param1Int);
    
    View onCreatePanelView(int param1Int);
  }
  
  private final class i implements androidx.appcompat.view.menu.m.a {
    i(f this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      this.o.L(param1g);
    }
    
    public boolean c(g param1g) {
      Window.Callback callback = this.o.f0();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1g); 
      return true;
    }
  }
  
  class j implements androidx.appcompat.view.b.a {
    private androidx.appcompat.view.b.a a;
    
    public j(f this$0, androidx.appcompat.view.b.a param1a) {
      this.a = param1a;
    }
    
    public boolean a(androidx.appcompat.view.b param1b, Menu param1Menu) {
      y.o0((View)this.b.J);
      return this.a.a(param1b, param1Menu);
    }
    
    public void b(androidx.appcompat.view.b param1b) {
      this.a.b(param1b);
      f f1 = this.b;
      if (f1.E != null)
        f1.t.getDecorView().removeCallbacks(this.b.F); 
      f1 = this.b;
      if (f1.D != null) {
        f1.V();
        f1 = this.b;
        f1.G = y.e((View)f1.D).b(0.0F);
        this.b.G.h((f0)new a(this));
      } 
      f1 = this.b;
      d d = f1.v;
      if (d != null)
        d.g(f1.C); 
      f1 = this.b;
      f1.C = null;
      y.o0((View)f1.J);
    }
    
    public boolean c(androidx.appcompat.view.b param1b, MenuItem param1MenuItem) {
      return this.a.c(param1b, param1MenuItem);
    }
    
    public boolean d(androidx.appcompat.view.b param1b, Menu param1Menu) {
      return this.a.d(param1b, param1Menu);
    }
    
    class a extends g0 {
      a(f.j this$0) {}
      
      public void b(View param2View) {
        this.a.b.D.setVisibility(8);
        f f = this.a.b;
        PopupWindow popupWindow = f.E;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (f.D.getParent() instanceof View) {
          y.o0((View)this.a.b.D.getParent());
        } 
        this.a.b.D.k();
        this.a.b.G.h(null);
        f = this.a.b;
        f.G = null;
        y.o0((View)f.J);
      }
    }
  }
  
  class a extends g0 {
    a(f this$0) {}
    
    public void b(View param1View) {
      this.a.b.D.setVisibility(8);
      f f = this.a.b;
      PopupWindow popupWindow = f.E;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (f.D.getParent() instanceof View) {
        y.o0((View)this.a.b.D.getParent());
      } 
      this.a.b.D.k();
      this.a.b.G.h(null);
      f = this.a.b;
      f.G = null;
      y.o0((View)f.J);
    }
  }
  
  static class k {
    static Context a(Context param1Context, Configuration param1Configuration) {
      return param1Context.createConfigurationContext(param1Configuration);
    }
    
    static void b(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.densityDpi;
      int j = param1Configuration2.densityDpi;
      if (i != j)
        param1Configuration3.densityDpi = j; 
    }
  }
  
  static class l {
    static boolean a(PowerManager param1PowerManager) {
      return param1PowerManager.isPowerSaveMode();
    }
  }
  
  static class m {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      LocaleList localeList1 = param1Configuration1.getLocales();
      LocaleList localeList2 = param1Configuration2.getLocales();
      if (!localeList1.equals(localeList2)) {
        param1Configuration3.setLocales(localeList2);
        param1Configuration3.locale = param1Configuration2.locale;
      } 
    }
  }
  
  static class n {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.colorMode;
      int j = param1Configuration2.colorMode;
      if ((i & 0x3) != (j & 0x3))
        param1Configuration3.colorMode |= j & 0x3; 
      i = param1Configuration1.colorMode;
      j = param1Configuration2.colorMode;
      if ((i & 0xC) != (j & 0xC))
        param1Configuration3.colorMode |= j & 0xC; 
    }
  }
  
  class o extends androidx.appcompat.view.i {
    private f.h p;
    
    private boolean q;
    
    private boolean r;
    
    private boolean s;
    
    o(f this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public boolean b(Window.Callback param1Callback, KeyEvent param1KeyEvent) {
      try {
        this.r = true;
        return param1Callback.dispatchKeyEvent(param1KeyEvent);
      } finally {
        this.r = false;
      } 
    }
    
    public void c(Window.Callback param1Callback) {
      try {
        this.q = true;
        param1Callback.onContentChanged();
        return;
      } finally {
        this.q = false;
      } 
    }
    
    public void d(Window.Callback param1Callback, int param1Int, Menu param1Menu) {
      try {
        this.s = true;
        param1Callback.onPanelClosed(param1Int, param1Menu);
        return;
      } finally {
        this.s = false;
      } 
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return this.r ? a().dispatchKeyEvent(param1KeyEvent) : ((this.t.T(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent)));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.t.r0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    final ActionMode e(ActionMode.Callback param1Callback) {
      androidx.appcompat.view.f.a a = new androidx.appcompat.view.f.a(this.t.s, param1Callback);
      androidx.appcompat.view.b b = this.t.F0((androidx.appcompat.view.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public void onContentChanged() {
      if (this.q)
        a().onContentChanged(); 
    }
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof g)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public View onCreatePanelView(int param1Int) {
      f.h h1 = this.p;
      if (h1 != null) {
        View view = h1.onCreatePanelView(param1Int);
        if (view != null)
          return view; 
      } 
      return super.onCreatePanelView(param1Int);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.t.u0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      if (this.s) {
        a().onPanelClosed(param1Int, param1Menu);
        return;
      } 
      super.onPanelClosed(param1Int, param1Menu);
      this.t.v0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      g g;
      if (param1Menu instanceof g) {
        g = (g)param1Menu;
      } else {
        g = null;
      } 
      if (param1Int == 0 && g == null)
        return false; 
      boolean bool1 = true;
      if (g != null)
        g.a0(true); 
      f.h h1 = this.p;
      if (h1 == null || !h1.a(param1Int))
        bool1 = false; 
      boolean bool2 = bool1;
      if (!bool1)
        bool2 = super.onPreparePanel(param1Int, param1View, param1Menu); 
      if (g != null)
        g.a0(false); 
      return bool2;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      f.u u = this.t.d0(0, true);
      if (u != null) {
        g g = u.j;
        if (g != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)g, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return (Build.VERSION.SDK_INT >= 23) ? null : (this.t.m0() ? e(param1Callback) : super.onWindowStartingActionMode(param1Callback));
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.t.m0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : e(param1Callback);
    }
  }
  
  private class p extends q {
    private final PowerManager c;
    
    p(f this$0, Context param1Context) {
      super(this$0);
      this.c = (PowerManager)param1Context.getApplicationContext().getSystemService("power");
    }
    
    IntentFilter b() {
      if (Build.VERSION.SDK_INT >= 21) {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
        return intentFilter;
      } 
      return null;
    }
    
    public int c() {
      int i = Build.VERSION.SDK_INT;
      byte b2 = 1;
      byte b1 = b2;
      if (i >= 21) {
        b1 = b2;
        if (f.l.a(this.c))
          b1 = 2; 
      } 
      return b1;
    }
    
    public void d() {
      this.d.F();
    }
  }
  
  abstract class q {
    private BroadcastReceiver a;
    
    q(f this$0) {}
    
    void a() {
      BroadcastReceiver broadcastReceiver = this.a;
      if (broadcastReceiver != null) {
        try {
          this.b.s.unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException illegalArgumentException) {}
        this.a = null;
      } 
    }
    
    abstract IntentFilter b();
    
    abstract int c();
    
    abstract void d();
    
    void e() {
      a();
      IntentFilter intentFilter = b();
      if (intentFilter != null) {
        if (intentFilter.countActions() == 0)
          return; 
        if (this.a == null)
          this.a = new a(this); 
        this.b.s.registerReceiver(this.a, intentFilter);
      } 
    }
    
    class a extends BroadcastReceiver {
      a(f.q this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.d();
      }
    }
  }
  
  class a extends BroadcastReceiver {
    a(f this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.d();
    }
  }
  
  private class r extends q {
    private final m c;
    
    r(f this$0, m param1m) {
      super(this$0);
      this.c = param1m;
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.TIME_SET");
      intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
      intentFilter.addAction("android.intent.action.TIME_TICK");
      return intentFilter;
    }
    
    public int c() {
      return this.c.d() ? 2 : 1;
    }
    
    public void d() {
      this.d.F();
    }
  }
  
  private static class s {
    static void a(ContextThemeWrapper param1ContextThemeWrapper, Configuration param1Configuration) {
      param1ContextThemeWrapper.applyOverrideConfiguration(param1Configuration);
    }
  }
  
  private class t extends ContentFrameLayout {
    public t(f this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean c(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.w.T(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && c((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.w.N(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(f.a.b(getContext(), param1Int));
    }
  }
  
  protected static final class u {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    g j;
    
    androidx.appcompat.view.menu.e k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    public boolean p;
    
    boolean q;
    
    boolean r;
    
    Bundle s;
    
    u(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    androidx.appcompat.view.menu.n a(androidx.appcompat.view.menu.m.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        androidx.appcompat.view.menu.e e1 = new androidx.appcompat.view.menu.e(this.l, e.g.j);
        this.k = e1;
        e1.k(param1a);
        this.j.b((androidx.appcompat.view.menu.m)this.k);
      } 
      return this.k.c(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.a().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    void c(g param1g) {
      g g1 = this.j;
      if (param1g == g1)
        return; 
      if (g1 != null)
        g1.O((androidx.appcompat.view.menu.m)this.k); 
      this.j = param1g;
      if (param1g != null) {
        androidx.appcompat.view.menu.e e1 = this.k;
        if (e1 != null)
          param1g.b((androidx.appcompat.view.menu.m)e1); 
      } 
    }
    
    void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(e.a.a, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(e.a.F, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(e.i.b, true);
      } 
      androidx.appcompat.view.d d = new androidx.appcompat.view.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(e.j.y0);
      this.b = typedArray.getResourceId(e.j.B0, 0);
      this.f = typedArray.getResourceId(e.j.A0, 0);
      typedArray.recycle();
    }
  }
  
  private final class v implements androidx.appcompat.view.menu.m.a {
    v(f this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      boolean bool;
      g g1 = param1g.D();
      if (g1 != param1g) {
        bool = true;
      } else {
        bool = false;
      } 
      f f1 = this.o;
      if (bool)
        param1g = g1; 
      f.u u = f1.Y((Menu)param1g);
      if (u != null) {
        if (bool) {
          this.o.K(u.a, u, (Menu)g1);
          this.o.O(u, true);
          return;
        } 
        this.o.O(u, param1Boolean);
      } 
    }
    
    public boolean c(g param1g) {
      if (param1g == param1g.D()) {
        f f1 = this.o;
        if (f1.O) {
          Window.Callback callback = f1.f0();
          if (callback != null && !this.o.Z)
            callback.onMenuOpened(108, (Menu)param1g); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */