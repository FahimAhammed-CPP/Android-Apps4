package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.i1;
import androidx.core.app.j;
import androidx.core.app.t;
import androidx.fragment.app.e;
import androidx.lifecycle.i0;
import androidx.lifecycle.j0;
import androidx.lifecycle.k0;
import androidx.lifecycle.m;
import q0.e;
import q0.f;

public class c extends e implements d, t.b {
  private e J;
  
  private Resources K;
  
  public c() {
    K();
  }
  
  private void K() {
    d().h("androidx:appcompat", new a(this));
    p(new b(this));
  }
  
  private boolean Q(KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  private void r() {
    j0.a(getWindow().getDecorView(), (m)this);
    k0.a(getWindow().getDecorView(), (i0)this);
    f.a(getWindow().getDecorView(), (e)this);
  }
  
  public void H() {
    I().o();
  }
  
  public e I() {
    if (this.J == null)
      this.J = e.g((Activity)this, this); 
    return this.J;
  }
  
  public a J() {
    return I().m();
  }
  
  public void L(t paramt) {
    paramt.e((Activity)this);
  }
  
  protected void M(int paramInt) {}
  
  public void N(t paramt) {}
  
  @Deprecated
  public void O() {}
  
  public boolean P() {
    Intent intent = j();
    if (intent != null) {
      if (S(intent)) {
        t t = t.k((Context)this);
        L(t);
        N(t);
        t.r();
        try {
          androidx.core.app.b.j((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        R((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  public void R(Intent paramIntent) {
    j.e((Activity)this, paramIntent);
  }
  
  public boolean S(Intent paramIntent) {
    return j.f((Activity)this, paramIntent);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    r();
    I().d(paramView, paramLayoutParams);
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(I().f(paramContext));
  }
  
  public void closeOptionsMenu() {
    a a = J();
    if (getWindow().hasFeature(0) && (a == null || !a.f()))
      super.closeOptionsMenu(); 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a = J();
    return (i == 82 && a != null && a.o(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public void f(androidx.appcompat.view.b paramb) {}
  
  public <T extends View> T findViewById(int paramInt) {
    return I().i(paramInt);
  }
  
  public void g(androidx.appcompat.view.b paramb) {}
  
  public MenuInflater getMenuInflater() {
    return I().l();
  }
  
  public Resources getResources() {
    if (this.K == null && i1.c())
      this.K = (Resources)new i1((Context)this, super.getResources()); 
    Resources resources2 = this.K;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public void invalidateOptionsMenu() {
    I().o();
  }
  
  public Intent j() {
    return j.a((Activity)this);
  }
  
  public androidx.appcompat.view.b l(androidx.appcompat.view.b.a parama) {
    return null;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    I().p(paramConfiguration);
    if (this.K != null) {
      paramConfiguration = super.getResources().getConfiguration();
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.K.updateConfiguration(paramConfiguration, displayMetrics);
    } 
  }
  
  public void onContentChanged() {
    O();
  }
  
  protected void onDestroy() {
    super.onDestroy();
    I().r();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return Q(paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a = J();
    return (paramMenuItem.getItemId() == 16908332 && a != null && (a.i() & 0x4) != 0) ? P() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    I().s(paramBundle);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    I().t();
  }
  
  protected void onStart() {
    super.onStart();
    I().v();
  }
  
  protected void onStop() {
    super.onStop();
    I().w();
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    I().E(paramCharSequence);
  }
  
  public void openOptionsMenu() {
    a a = J();
    if (getWindow().hasFeature(0) && (a == null || !a.p()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    r();
    I().A(paramInt);
  }
  
  public void setContentView(View paramView) {
    r();
    I().B(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    r();
    I().C(paramView, paramLayoutParams);
  }
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    I().D(paramInt);
  }
  
  class a implements q0.c.c {
    a(c this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.I().u(bundle);
      return bundle;
    }
  }
  
  class b implements c.b {
    b(c this$0) {}
    
    public void a(Context param1Context) {
      e e = this.a.I();
      e.n();
      e.q(this.a.d().b("androidx:appcompat"));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */