package androidx.appcompat.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.f;
import androidx.appcompat.view.b;
import androidx.core.view.f;
import e.a;

public class h extends f implements d {
  private e q;
  
  private final f.a r = new g(this);
  
  public h(Context paramContext, int paramInt) {
    super(paramContext, j(paramContext, paramInt));
    e e1 = i();
    e1.D(j(paramContext, paramInt));
    e1.q(null);
  }
  
  private static int j(Context paramContext, int paramInt) {
    int i = paramInt;
    if (paramInt == 0) {
      TypedValue typedValue = new TypedValue();
      paramContext.getTheme().resolveAttribute(a.z, typedValue, true);
      i = typedValue.resourceId;
    } 
    return i;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    i().d(paramView, paramLayoutParams);
  }
  
  public void dismiss() {
    super.dismiss();
    i().r();
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return f.e(this.r, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public void f(b paramb) {}
  
  public <T extends View> T findViewById(int paramInt) {
    return i().i(paramInt);
  }
  
  public void g(b paramb) {}
  
  public e i() {
    if (this.q == null)
      this.q = e.h((Dialog)this, this); 
    return this.q;
  }
  
  public void invalidateOptionsMenu() {
    i().o();
  }
  
  boolean k(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public b l(b.a parama) {
    return null;
  }
  
  public boolean m(int paramInt) {
    return i().z(paramInt);
  }
  
  protected void onCreate(Bundle paramBundle) {
    i().n();
    super.onCreate(paramBundle);
    i().q(paramBundle);
  }
  
  protected void onStop() {
    super.onStop();
    i().w();
  }
  
  public void setContentView(int paramInt) {
    i().A(paramInt);
  }
  
  public void setContentView(View paramView) {
    i().B(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    i().C(paramView, paramLayoutParams);
  }
  
  public void setTitle(int paramInt) {
    super.setTitle(paramInt);
    i().E(getContext().getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    i().E(paramCharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\appcompat\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */