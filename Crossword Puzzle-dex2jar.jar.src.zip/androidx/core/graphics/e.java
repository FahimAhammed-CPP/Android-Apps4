package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import androidx.core.content.res.h;
import androidx.core.provider.g;

public class e {
  private static final k a;
  
  private static final o.e<String, Typeface> b = new o.e(16);
  
  public static Typeface a(Context paramContext, Typeface paramTypeface, int paramInt) {
    if (paramContext != null) {
      if (Build.VERSION.SDK_INT < 21) {
        Typeface typeface = g(paramContext, paramTypeface, paramInt);
        if (typeface != null)
          return typeface; 
      } 
      return Typeface.create(paramTypeface, paramInt);
    } 
    throw new IllegalArgumentException("Context cannot be null");
  }
  
  public static Typeface b(Context paramContext, CancellationSignal paramCancellationSignal, g.b[] paramArrayOfb, int paramInt) {
    return a.c(paramContext, paramCancellationSignal, paramArrayOfb, paramInt);
  }
  
  public static Typeface c(Context paramContext, androidx.core.content.res.e.b paramb, Resources paramResources, int paramInt1, String paramString, int paramInt2, int paramInt3, h.f paramf, Handler paramHandler, boolean paramBoolean) {
    Typeface typeface;
    androidx.core.content.res.e.e e1;
    a a;
    if (paramb instanceof androidx.core.content.res.e.e) {
      byte b1;
      boolean bool;
      e1 = (androidx.core.content.res.e.e)paramb;
      Typeface typeface1 = h(e1.c());
      if (typeface1 != null) {
        if (paramf != null)
          paramf.d(typeface1, paramHandler); 
        return typeface1;
      } 
      if (paramBoolean ? (e1.a() == 0) : (paramf == null)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (paramBoolean) {
        b1 = e1.d();
      } else {
        b1 = -1;
      } 
      paramHandler = h.f.e(paramHandler);
      a = new a(paramf);
      typeface = g.c(paramContext, e1.b(), paramInt3, bool, b1, paramHandler, a);
    } else {
      Typeface typeface1 = a.b((Context)typeface, (androidx.core.content.res.e.c)e1, paramResources, paramInt3);
      typeface = typeface1;
      if (a != null)
        if (typeface1 != null) {
          a.d(typeface1, paramHandler);
          typeface = typeface1;
        } else {
          a.c(-3, paramHandler);
          typeface = typeface1;
        }  
    } 
    if (typeface != null)
      b.d(e(paramResources, paramInt1, paramString, paramInt2, paramInt3), typeface); 
    return typeface;
  }
  
  public static Typeface d(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2, int paramInt3) {
    Typeface typeface = a.e(paramContext, paramResources, paramInt1, paramString, paramInt3);
    if (typeface != null) {
      String str = e(paramResources, paramInt1, paramString, paramInt2, paramInt3);
      b.d(str, typeface);
    } 
    return typeface;
  }
  
  private static String e(Resources paramResources, int paramInt1, String paramString, int paramInt2, int paramInt3) {
    StringBuilder stringBuilder = new StringBuilder(paramResources.getResourcePackageName(paramInt1));
    stringBuilder.append('-');
    stringBuilder.append(paramString);
    stringBuilder.append('-');
    stringBuilder.append(paramInt2);
    stringBuilder.append('-');
    stringBuilder.append(paramInt1);
    stringBuilder.append('-');
    stringBuilder.append(paramInt3);
    return stringBuilder.toString();
  }
  
  public static Typeface f(Resources paramResources, int paramInt1, String paramString, int paramInt2, int paramInt3) {
    return (Typeface)b.c(e(paramResources, paramInt1, paramString, paramInt2, paramInt3));
  }
  
  private static Typeface g(Context paramContext, Typeface paramTypeface, int paramInt) {
    k k1 = a;
    androidx.core.content.res.e.c c = k1.i(paramTypeface);
    return (c == null) ? null : k1.b(paramContext, c, paramContext.getResources(), paramInt);
  }
  
  private static Typeface h(String paramString) {
    Typeface typeface2 = null;
    Typeface typeface1 = typeface2;
    if (paramString != null) {
      if (paramString.isEmpty())
        return null; 
      Typeface typeface3 = Typeface.create(paramString, 0);
      Typeface typeface4 = Typeface.create(Typeface.DEFAULT, 0);
      typeface1 = typeface2;
      if (typeface3 != null) {
        typeface1 = typeface2;
        if (!typeface3.equals(typeface4))
          typeface1 = typeface3; 
      } 
    } 
    return typeface1;
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      a = new j();
    } else if (i >= 28) {
      a = new i();
    } else if (i >= 26) {
      a = new h();
    } else if (i >= 24 && g.m()) {
      a = new g();
    } else if (i >= 21) {
      a = new f();
    } else {
      a = new k();
    } 
  }
  
  public static class a extends g.c {
    private h.f a;
    
    public a(h.f param1f) {
      this.a = param1f;
    }
    
    public void a(int param1Int) {
      h.f f1 = this.a;
      if (f1 != null)
        f1.h(param1Int); 
    }
    
    public void b(Typeface param1Typeface) {
      h.f f1 = this.a;
      if (f1 != null)
        f1.i(param1Typeface); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\graphics\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */