package androidx.core.graphics;

import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import androidx.core.util.d;

public final class c {
  private static final ThreadLocal<d<Rect, Rect>> a = new ThreadLocal<d<Rect, Rect>>();
  
  public static boolean a(Paint paramPaint, String paramString) {
    if (Build.VERSION.SDK_INT >= 23)
      return a.a(paramPaint, paramString); 
    int i = paramString.length();
    if (i == 1 && Character.isWhitespace(paramString.charAt(0)))
      return true; 
    float f2 = paramPaint.measureText("󟿽");
    float f4 = paramPaint.measureText("m");
    float f3 = paramPaint.measureText(paramString);
    float f1 = 0.0F;
    if (f3 == 0.0F)
      return false; 
    if (paramString.codePointCount(0, paramString.length()) > 1) {
      if (f3 > f4 * 2.0F)
        return false; 
      int j;
      for (j = 0; j < i; j = k) {
        int k = Character.charCount(paramString.codePointAt(j)) + j;
        f1 += paramPaint.measureText(paramString, j, k);
      } 
      if (f3 >= f1)
        return false; 
    } 
    if (f3 != f2)
      return true; 
    d<Rect, Rect> d = b();
    paramPaint.getTextBounds("󟿽", 0, 2, (Rect)d.a);
    paramPaint.getTextBounds(paramString, 0, i, (Rect)d.b);
    return ((Rect)d.a).equals(d.b) ^ true;
  }
  
  private static d<Rect, Rect> b() {
    ThreadLocal<d<Rect, Rect>> threadLocal = a;
    d<Rect, Rect> d = threadLocal.get();
    if (d == null) {
      d = new d(new Rect(), new Rect());
      threadLocal.set(d);
      return d;
    } 
    ((Rect)d.a).setEmpty();
    ((Rect)d.b).setEmpty();
    return d;
  }
  
  static class a {
    static boolean a(Paint param1Paint, String param1String) {
      return param1Paint.hasGlyph(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\graphics\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */