package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.core.content.res.e;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;

class g extends k {
  private static final Class<?> b;
  
  private static final Constructor<?> c;
  
  private static final Method d;
  
  private static final Method e;
  
  static {
    ClassNotFoundException classNotFoundException1;
    ClassNotFoundException classNotFoundException2;
    Constructor<?> constructor = null;
    try {
      Class<?> clazz1 = Class.forName("android.graphics.FontFamily");
      Constructor<?> constructor1 = clazz1.getConstructor(new Class[0]);
      Class<int> clazz = int.class;
      Method method2 = clazz1.getMethod("addFontWeightStyle", new Class[] { ByteBuffer.class, clazz, List.class, clazz, boolean.class });
      Method method1 = Typeface.class.getMethod("createFromFamiliesWithDefault", new Class[] { Array.newInstance(clazz1, 1).getClass() });
      constructor = constructor1;
    } catch (ClassNotFoundException classNotFoundException) {
      Log.e("TypefaceCompatApi24Impl", classNotFoundException.getClass().getName(), classNotFoundException);
      classNotFoundException1 = null;
      classNotFoundException = classNotFoundException1;
      classNotFoundException2 = classNotFoundException;
    } catch (NoSuchMethodException noSuchMethodException) {}
    c = constructor;
    b = (Class<?>)classNotFoundException1;
    d = (Method)classNotFoundException2;
    e = (Method)noSuchMethodException;
  }
  
  private static boolean k(Object paramObject, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, boolean paramBoolean) {
    try {
      return ((Boolean)d.invoke(paramObject, new Object[] { paramByteBuffer, Integer.valueOf(paramInt1), null, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) })).booleanValue();
    } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      return false;
    } 
  }
  
  private static Typeface l(Object paramObject) {
    try {
      Object object = Array.newInstance(b, 1);
      Array.set(object, 0, paramObject);
      return (Typeface)e.invoke(null, new Object[] { object });
    } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      return null;
    } 
  }
  
  public static boolean m() {
    Method method = d;
    if (method == null)
      Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation."); 
    return (method != null);
  }
  
  private static Object n() {
    try {
      return c.newInstance(new Object[0]);
    } catch (IllegalAccessException|InstantiationException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      return null;
    } 
  }
  
  public Typeface b(Context paramContext, e.c paramc, Resources paramResources, int paramInt) {
    Object object = n();
    if (object == null)
      return null; 
    e.d[] arrayOfD = paramc.a();
    int i = arrayOfD.length;
    for (paramInt = 0; paramInt < i; paramInt++) {
      e.d d = arrayOfD[paramInt];
      ByteBuffer byteBuffer = l.b(paramContext, paramResources, d.b());
      if (byteBuffer == null)
        return null; 
      if (!k(object, byteBuffer, d.c(), d.e(), d.f()))
        return null; 
    } 
    return l(object);
  }
  
  public Typeface c(Context paramContext, CancellationSignal paramCancellationSignal, androidx.core.provider.g.b[] paramArrayOfb, int paramInt) {
    Object object = n();
    if (object == null)
      return null; 
    o.g g1 = new o.g();
    int j = paramArrayOfb.length;
    int i;
    for (i = 0; i < j; i++) {
      androidx.core.provider.g.b b1 = paramArrayOfb[i];
      Uri uri = b1.d();
      ByteBuffer byteBuffer2 = (ByteBuffer)g1.get(uri);
      ByteBuffer byteBuffer1 = byteBuffer2;
      if (byteBuffer2 == null) {
        byteBuffer1 = l.f(paramContext, paramCancellationSignal, uri);
        g1.put(uri, byteBuffer1);
      } 
      if (byteBuffer1 == null)
        return null; 
      if (!k(object, byteBuffer1, b1.c(), b1.e(), b1.f()))
        return null; 
    } 
    Typeface typeface = l(object);
    return (typeface == null) ? null : Typeface.create(typeface, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\graphics\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */