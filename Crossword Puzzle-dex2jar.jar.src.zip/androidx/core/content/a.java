package androidx.core.content;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import androidx.core.content.res.h;
import java.io.File;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class a {
  private static final Object a = new Object();
  
  private static final Object b = new Object();
  
  public static int a(Context paramContext, String paramString) {
    androidx.core.util.c.d(paramString, "permission must be non-null");
    return paramContext.checkPermission(paramString, Process.myPid(), Process.myUid());
  }
  
  public static Context b(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? d.a(paramContext) : null;
  }
  
  public static int c(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 23) ? c.a(paramContext, paramInt) : paramContext.getResources().getColor(paramInt);
  }
  
  public static ColorStateList d(Context paramContext, int paramInt) {
    return h.d(paramContext.getResources(), paramInt, paramContext.getTheme());
  }
  
  public static Drawable e(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 21) ? b.b(paramContext, paramInt) : paramContext.getResources().getDrawable(paramInt);
  }
  
  public static boolean f(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle) {
    a.a(paramContext, paramArrayOfIntent, paramBundle);
    return true;
  }
  
  public static void g(Context paramContext, Intent paramIntent, Bundle paramBundle) {
    a.b(paramContext, paramIntent, paramBundle);
  }
  
  public static void h(Context paramContext, Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 26) {
      e.a(paramContext, paramIntent);
      return;
    } 
    paramContext.startService(paramIntent);
  }
  
  static class a {
    static void a(Context param1Context, Intent[] param1ArrayOfIntent, Bundle param1Bundle) {
      param1Context.startActivities(param1ArrayOfIntent, param1Bundle);
    }
    
    static void b(Context param1Context, Intent param1Intent, Bundle param1Bundle) {
      param1Context.startActivity(param1Intent, param1Bundle);
    }
  }
  
  static class b {
    static File a(Context param1Context) {
      return param1Context.getCodeCacheDir();
    }
    
    static Drawable b(Context param1Context, int param1Int) {
      return param1Context.getDrawable(param1Int);
    }
    
    static File c(Context param1Context) {
      return param1Context.getNoBackupFilesDir();
    }
  }
  
  static class c {
    static int a(Context param1Context, int param1Int) {
      return param1Context.getColor(param1Int);
    }
    
    static <T> T b(Context param1Context, Class<T> param1Class) {
      return (T)param1Context.getSystemService(param1Class);
    }
    
    static String c(Context param1Context, Class<?> param1Class) {
      return param1Context.getSystemServiceName(param1Class);
    }
  }
  
  static class d {
    static Context a(Context param1Context) {
      return param1Context.createDeviceProtectedStorageContext();
    }
    
    static File b(Context param1Context) {
      return param1Context.getDataDir();
    }
    
    static boolean c(Context param1Context) {
      return param1Context.isDeviceProtectedStorage();
    }
  }
  
  static class e {
    static ComponentName a(Context param1Context, Intent param1Intent) {
      return param1Context.startForegroundService(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\content\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */