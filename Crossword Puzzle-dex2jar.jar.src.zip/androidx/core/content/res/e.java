package androidx.core.content.res;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.Base64;
import android.util.TypedValue;
import android.util.Xml;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class e {
  private static int a(TypedArray paramTypedArray, int paramInt) {
    if (Build.VERSION.SDK_INT >= 21)
      return a.a(paramTypedArray, paramInt); 
    TypedValue typedValue = new TypedValue();
    paramTypedArray.getValue(paramInt, typedValue);
    return typedValue.type;
  }
  
  public static b b(XmlPullParser paramXmlPullParser, Resources paramResources) {
    int i;
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2)
      return d(paramXmlPullParser, paramResources); 
    XmlPullParserException xmlPullParserException = new XmlPullParserException("No start tag found");
    throw xmlPullParserException;
  }
  
  public static List<List<byte[]>> c(Resources paramResources, int paramInt) {
    if (paramInt == 0)
      return Collections.emptyList(); 
    TypedArray typedArray = paramResources.obtainTypedArray(paramInt);
    try {
      List<?> list;
      if (typedArray.length() == 0) {
        list = Collections.emptyList();
        return (List)list;
      } 
      ArrayList<List<byte[]>> arrayList = new ArrayList();
      if (a(typedArray, 0) == 1)
        for (paramInt = 0;; paramInt++) {
          if (paramInt < typedArray.length()) {
            int i = typedArray.getResourceId(paramInt, 0);
            if (i != 0)
              arrayList.add(h(list.getStringArray(i))); 
          } else {
            return arrayList;
          } 
        }  
      arrayList.add(h(list.getStringArray(paramInt)));
      return arrayList;
    } finally {
      typedArray.recycle();
    } 
  }
  
  private static b d(XmlPullParser paramXmlPullParser, Resources paramResources) {
    paramXmlPullParser.require(2, null, "font-family");
    if (paramXmlPullParser.getName().equals("font-family"))
      return e(paramXmlPullParser, paramResources); 
    g(paramXmlPullParser);
    return null;
  }
  
  private static b e(XmlPullParser paramXmlPullParser, Resources paramResources) {
    TypedArray typedArray = paramResources.obtainAttributes(Xml.asAttributeSet(paramXmlPullParser), w.c.h);
    String str1 = typedArray.getString(w.c.i);
    String str2 = typedArray.getString(w.c.m);
    String str3 = typedArray.getString(w.c.n);
    int i = typedArray.getResourceId(w.c.j, 0);
    int j = typedArray.getInteger(w.c.k, 1);
    int k = typedArray.getInteger(w.c.l, 500);
    String str4 = typedArray.getString(w.c.o);
    typedArray.recycle();
    if (str1 != null && str2 != null && str3 != null) {
      while (paramXmlPullParser.next() != 3)
        g(paramXmlPullParser); 
      return new e(new androidx.core.provider.e(str1, str2, str3, c(paramResources, i)), j, k, str4);
    } 
    ArrayList<d> arrayList = new ArrayList();
    while (paramXmlPullParser.next() != 3) {
      if (paramXmlPullParser.getEventType() != 2)
        continue; 
      if (paramXmlPullParser.getName().equals("font")) {
        arrayList.add(f(paramXmlPullParser, paramResources));
        continue;
      } 
      g(paramXmlPullParser);
    } 
    return arrayList.isEmpty() ? null : new c(arrayList.<d>toArray(new d[0]));
  }
  
  private static d f(XmlPullParser paramXmlPullParser, Resources paramResources) {
    boolean bool;
    TypedArray typedArray = paramResources.obtainAttributes(Xml.asAttributeSet(paramXmlPullParser), w.c.p);
    int i = w.c.y;
    if (!typedArray.hasValue(i))
      i = w.c.r; 
    int k = typedArray.getInt(i, 400);
    i = w.c.w;
    if (!typedArray.hasValue(i))
      i = w.c.s; 
    if (1 == typedArray.getInt(i, 0)) {
      bool = true;
    } else {
      bool = false;
    } 
    i = w.c.z;
    if (!typedArray.hasValue(i))
      i = w.c.t; 
    int j = w.c.x;
    if (!typedArray.hasValue(j))
      j = w.c.u; 
    String str1 = typedArray.getString(j);
    j = typedArray.getInt(i, 0);
    i = w.c.v;
    if (!typedArray.hasValue(i))
      i = w.c.q; 
    int m = typedArray.getResourceId(i, 0);
    String str2 = typedArray.getString(i);
    typedArray.recycle();
    while (paramXmlPullParser.next() != 3)
      g(paramXmlPullParser); 
    return new d(str2, k, bool, str1, j, m);
  }
  
  private static void g(XmlPullParser paramXmlPullParser) {
    for (int i = 1; i; i++) {
      int j = paramXmlPullParser.next();
      if (j != 2) {
        if (j != 3)
          continue; 
        i--;
        continue;
      } 
    } 
  }
  
  private static List<byte[]> h(String[] paramArrayOfString) {
    ArrayList<byte[]> arrayList = new ArrayList();
    int j = paramArrayOfString.length;
    for (int i = 0; i < j; i++)
      arrayList.add(Base64.decode(paramArrayOfString[i], 0)); 
    return (List<byte[]>)arrayList;
  }
  
  static class a {
    static int a(TypedArray param1TypedArray, int param1Int) {
      return param1TypedArray.getType(param1Int);
    }
  }
  
  public static interface b {}
  
  public static final class c implements b {
    private final e.d[] a;
    
    public c(e.d[] param1ArrayOfd) {
      this.a = param1ArrayOfd;
    }
    
    public e.d[] a() {
      return this.a;
    }
  }
  
  public static final class d {
    private final String a;
    
    private final int b;
    
    private final boolean c;
    
    private final String d;
    
    private final int e;
    
    private final int f;
    
    public d(String param1String1, int param1Int1, boolean param1Boolean, String param1String2, int param1Int2, int param1Int3) {
      this.a = param1String1;
      this.b = param1Int1;
      this.c = param1Boolean;
      this.d = param1String2;
      this.e = param1Int2;
      this.f = param1Int3;
    }
    
    public String a() {
      return this.a;
    }
    
    public int b() {
      return this.f;
    }
    
    public int c() {
      return this.e;
    }
    
    public String d() {
      return this.d;
    }
    
    public int e() {
      return this.b;
    }
    
    public boolean f() {
      return this.c;
    }
  }
  
  public static final class e implements b {
    private final androidx.core.provider.e a;
    
    private final int b;
    
    private final int c;
    
    private final String d;
    
    public e(androidx.core.provider.e param1e, int param1Int1, int param1Int2, String param1String) {
      this.a = param1e;
      this.c = param1Int1;
      this.b = param1Int2;
      this.d = param1String;
    }
    
    public int a() {
      return this.c;
    }
    
    public androidx.core.provider.e b() {
      return this.a;
    }
    
    public String c() {
      return this.d;
    }
    
    public int d() {
      return this.b;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\content\res\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */