package androidx.core.content.res;

final class l {
  static final l k;
  
  private final float a;
  
  private final float b;
  
  private final float c;
  
  private final float d;
  
  private final float e;
  
  private final float f;
  
  private final float[] g;
  
  private final float h;
  
  private final float i;
  
  private final float j;
  
  static {
    float[] arrayOfFloat = b.c;
    double d = b.h(50.0F);
    Double.isNaN(d);
    k = k(arrayOfFloat, (float)(d * 63.66197723675813D / 100.0D), 50.0F, 2.0F, false);
  }
  
  private l(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float[] paramArrayOffloat, float paramFloat7, float paramFloat8, float paramFloat9) {
    this.f = paramFloat1;
    this.a = paramFloat2;
    this.b = paramFloat3;
    this.c = paramFloat4;
    this.d = paramFloat5;
    this.e = paramFloat6;
    this.g = paramArrayOffloat;
    this.h = paramFloat7;
    this.i = paramFloat8;
    this.j = paramFloat9;
  }
  
  static l k(float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, boolean paramBoolean) {
    float f1;
    float[][] arrayOfFloat = b.a;
    float f2 = paramArrayOffloat[0] * arrayOfFloat[0][0] + paramArrayOffloat[1] * arrayOfFloat[0][1] + paramArrayOffloat[2] * arrayOfFloat[0][2];
    float f3 = paramArrayOffloat[0] * arrayOfFloat[1][0] + paramArrayOffloat[1] * arrayOfFloat[1][1] + paramArrayOffloat[2] * arrayOfFloat[1][2];
    float f4 = paramArrayOffloat[0] * arrayOfFloat[2][0] + paramArrayOffloat[1] * arrayOfFloat[2][1] + paramArrayOffloat[2] * arrayOfFloat[2][2];
    float f5 = paramFloat3 / 10.0F + 0.8F;
    if (f5 >= 0.9D) {
      f1 = b.d(0.59F, 0.69F, (f5 - 0.9F) * 10.0F);
    } else {
      f1 = b.d(0.525F, 0.59F, (f5 - 0.8F) * 10.0F);
    } 
    if (paramBoolean) {
      paramFloat3 = 1.0F;
    } else {
      paramFloat3 = (1.0F - (float)Math.exp(((-paramFloat1 - 42.0F) / 92.0F)) * 0.2777778F) * f5;
    } 
    double d = paramFloat3;
    if (d > 1.0D) {
      paramFloat3 = 1.0F;
    } else if (d < 0.0D) {
      paramFloat3 = 0.0F;
    } 
    float[] arrayOfFloat1 = new float[3];
    arrayOfFloat1[0] = 100.0F / f2 * paramFloat3 + 1.0F - paramFloat3;
    arrayOfFloat1[1] = 100.0F / f3 * paramFloat3 + 1.0F - paramFloat3;
    arrayOfFloat1[2] = 100.0F / f4 * paramFloat3 + 1.0F - paramFloat3;
    paramFloat3 = 1.0F / (5.0F * paramFloat1 + 1.0F);
    paramFloat3 = paramFloat3 * paramFloat3 * paramFloat3 * paramFloat3;
    float f6 = 1.0F - paramFloat3;
    d = paramFloat1;
    Double.isNaN(d);
    paramFloat1 = paramFloat3 * paramFloat1 + 0.1F * f6 * f6 * (float)Math.cbrt(d * 5.0D);
    paramFloat2 = b.h(paramFloat2) / paramArrayOffloat[1];
    d = paramFloat2;
    paramFloat3 = (float)Math.sqrt(d);
    f6 = 0.725F / (float)Math.pow(d, 0.2D);
    paramArrayOffloat = new float[3];
    d = (arrayOfFloat1[0] * paramFloat1 * f2);
    Double.isNaN(d);
    paramArrayOffloat[0] = (float)Math.pow(d / 100.0D, 0.42D);
    d = (arrayOfFloat1[1] * paramFloat1 * f3);
    Double.isNaN(d);
    paramArrayOffloat[1] = (float)Math.pow(d / 100.0D, 0.42D);
    d = (arrayOfFloat1[2] * paramFloat1 * f4);
    Double.isNaN(d);
    paramArrayOffloat[2] = (float)Math.pow(d / 100.0D, 0.42D);
    float[] arrayOfFloat2 = new float[3];
    arrayOfFloat2[0] = paramArrayOffloat[0] * 400.0F / (paramArrayOffloat[0] + 27.13F);
    arrayOfFloat2[1] = paramArrayOffloat[1] * 400.0F / (paramArrayOffloat[1] + 27.13F);
    arrayOfFloat2[2] = paramArrayOffloat[2] * 400.0F / (paramArrayOffloat[2] + 27.13F);
    return new l(paramFloat2, (arrayOfFloat2[0] * 2.0F + arrayOfFloat2[1] + arrayOfFloat2[2] * 0.05F) * f6, f6, f6, f1, f5, arrayOfFloat1, paramFloat1, (float)Math.pow(paramFloat1, 0.25D), paramFloat3 + 1.48F);
  }
  
  float a() {
    return this.a;
  }
  
  float b() {
    return this.d;
  }
  
  float c() {
    return this.h;
  }
  
  float d() {
    return this.i;
  }
  
  float e() {
    return this.f;
  }
  
  float f() {
    return this.b;
  }
  
  float g() {
    return this.e;
  }
  
  float h() {
    return this.c;
  }
  
  float[] i() {
    return this.g;
  }
  
  float j() {
    return this.j;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\content\res\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */