package androidx.core.app;

import android.app.Notification;

public interface k {
  Notification.Builder a();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\app\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */