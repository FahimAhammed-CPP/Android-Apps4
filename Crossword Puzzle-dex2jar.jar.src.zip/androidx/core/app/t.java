package androidx.core.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public final class t implements Iterable<Intent> {
  private final ArrayList<Intent> o = new ArrayList<Intent>();
  
  private final Context p;
  
  private t(Context paramContext) {
    this.p = paramContext;
  }
  
  public static t k(Context paramContext) {
    return new t(paramContext);
  }
  
  public t d(Intent paramIntent) {
    this.o.add(paramIntent);
    return this;
  }
  
  public t e(Activity paramActivity) {
    Intent intent1;
    if (paramActivity instanceof b) {
      intent1 = ((b)paramActivity).j();
    } else {
      intent1 = null;
    } 
    Intent intent2 = intent1;
    if (intent1 == null)
      intent2 = j.a(paramActivity); 
    if (intent2 != null) {
      ComponentName componentName2 = intent2.getComponent();
      ComponentName componentName1 = componentName2;
      if (componentName2 == null)
        componentName1 = intent2.resolveActivity(this.p.getPackageManager()); 
      g(componentName1);
      d(intent2);
    } 
    return this;
  }
  
  public t g(ComponentName paramComponentName) {
    int i = this.o.size();
    try {
      for (Intent intent = j.b(this.p, paramComponentName); intent != null; intent = j.b(this.p, intent.getComponent()))
        this.o.add(i, intent); 
      return this;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
      IllegalArgumentException illegalArgumentException = new IllegalArgumentException((Throwable)nameNotFoundException);
      throw illegalArgumentException;
    } 
  }
  
  public t h(Class<?> paramClass) {
    return g(new ComponentName(this.p, paramClass));
  }
  
  @Deprecated
  public Iterator<Intent> iterator() {
    return this.o.iterator();
  }
  
  public PendingIntent p(int paramInt1, int paramInt2) {
    return q(paramInt1, paramInt2, null);
  }
  
  public PendingIntent q(int paramInt1, int paramInt2, Bundle paramBundle) {
    if (!this.o.isEmpty()) {
      Intent[] arrayOfIntent = this.o.<Intent>toArray(new Intent[0]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      return a.a(this.p, paramInt1, arrayOfIntent, paramInt2, paramBundle);
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot getPendingIntent");
  }
  
  public void r() {
    s(null);
  }
  
  public void s(Bundle paramBundle) {
    if (!this.o.isEmpty()) {
      Intent[] arrayOfIntent = this.o.<Intent>toArray(new Intent[0]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      if (!androidx.core.content.a.f(this.p, arrayOfIntent, paramBundle)) {
        Intent intent = new Intent(arrayOfIntent[arrayOfIntent.length - 1]);
        intent.addFlags(268435456);
        this.p.startActivity(intent);
      } 
      return;
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
  }
  
  static class a {
    static PendingIntent a(Context param1Context, int param1Int1, Intent[] param1ArrayOfIntent, int param1Int2, Bundle param1Bundle) {
      return PendingIntent.getActivities(param1Context, param1Int1, param1ArrayOfIntent, param1Int2, param1Bundle);
    }
  }
  
  public static interface b {
    Intent j();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\app\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */