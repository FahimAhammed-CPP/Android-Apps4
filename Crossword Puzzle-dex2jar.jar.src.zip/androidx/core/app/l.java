package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;

public class l {
  public static Bundle a(Notification paramNotification) {
    return paramNotification.extras;
  }
  
  public static class a {
    final Bundle a;
    
    private IconCompat b;
    
    private final r[] c;
    
    private final r[] d;
    
    private boolean e;
    
    boolean f = true;
    
    private final int g;
    
    private final boolean h;
    
    @Deprecated
    public int i;
    
    public CharSequence j;
    
    public PendingIntent k;
    
    private boolean l;
    
    public a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(iconCompat, param1CharSequence, param1PendingIntent);
    }
    
    public a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(param1IconCompat, param1CharSequence, param1PendingIntent, new Bundle(), null, null, true, 0, true, false, false);
    }
    
    a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent, Bundle param1Bundle, r[] param1ArrayOfr1, r[] param1ArrayOfr2, boolean param1Boolean1, int param1Int, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      this.b = param1IconCompat;
      if (param1IconCompat != null && param1IconCompat.j() == 2)
        this.i = param1IconCompat.h(); 
      this.j = l.d.d(param1CharSequence);
      this.k = param1PendingIntent;
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      this.a = param1Bundle;
      this.c = param1ArrayOfr1;
      this.d = param1ArrayOfr2;
      this.e = param1Boolean1;
      this.g = param1Int;
      this.f = param1Boolean2;
      this.h = param1Boolean3;
      this.l = param1Boolean4;
    }
    
    public PendingIntent a() {
      return this.k;
    }
    
    public boolean b() {
      return this.e;
    }
    
    public r[] c() {
      return this.d;
    }
    
    public Bundle d() {
      return this.a;
    }
    
    public IconCompat e() {
      if (this.b == null) {
        int i = this.i;
        if (i != 0)
          this.b = IconCompat.g(null, "", i); 
      } 
      return this.b;
    }
    
    public r[] f() {
      return this.c;
    }
    
    public int g() {
      return this.g;
    }
    
    public boolean h() {
      return this.f;
    }
    
    public CharSequence i() {
      return this.j;
    }
    
    public boolean j() {
      return this.l;
    }
    
    public boolean k() {
      return this.h;
    }
  }
  
  public static class b extends e {
    private CharSequence e;
    
    public void a(Bundle param1Bundle) {
      super.a(param1Bundle);
      if (Build.VERSION.SDK_INT < 21)
        param1Bundle.putCharSequence("android.bigText", this.e); 
    }
    
    public void b(k param1k) {
      Notification.BigTextStyle bigTextStyle = (new Notification.BigTextStyle(param1k.a())).setBigContentTitle(this.b).bigText(this.e);
      if (this.d)
        bigTextStyle.setSummaryText(this.c); 
    }
    
    protected String c() {
      return "androidx.core.app.NotificationCompat$BigTextStyle";
    }
    
    public b h(CharSequence param1CharSequence) {
      this.e = l.d.d(param1CharSequence);
      return this;
    }
  }
  
  public static final class c {
    public static Notification.BubbleMetadata a(c param1c) {
      return null;
    }
  }
  
  public static class d {
    boolean A;
    
    boolean B;
    
    String C;
    
    Bundle D;
    
    int E = 0;
    
    int F = 0;
    
    Notification G;
    
    RemoteViews H;
    
    RemoteViews I;
    
    RemoteViews J;
    
    String K;
    
    int L = 0;
    
    String M;
    
    long N;
    
    int O = 0;
    
    int P = 0;
    
    boolean Q;
    
    Notification R;
    
    boolean S;
    
    Icon T;
    
    @Deprecated
    public ArrayList<String> U;
    
    public Context a;
    
    public ArrayList<l.a> b = new ArrayList<l.a>();
    
    public ArrayList<p> c = new ArrayList<p>();
    
    ArrayList<l.a> d = new ArrayList<l.a>();
    
    CharSequence e;
    
    CharSequence f;
    
    PendingIntent g;
    
    PendingIntent h;
    
    RemoteViews i;
    
    Bitmap j;
    
    CharSequence k;
    
    int l;
    
    int m;
    
    boolean n = true;
    
    boolean o;
    
    l.e p;
    
    CharSequence q;
    
    CharSequence r;
    
    CharSequence[] s;
    
    int t;
    
    int u;
    
    boolean v;
    
    String w;
    
    boolean x;
    
    String y;
    
    boolean z = false;
    
    @Deprecated
    public d(Context param1Context) {
      this(param1Context, null);
    }
    
    public d(Context param1Context, String param1String) {
      Notification notification = new Notification();
      this.R = notification;
      this.a = param1Context;
      this.K = param1String;
      notification.when = System.currentTimeMillis();
      this.R.audioStreamType = -1;
      this.m = 0;
      this.U = new ArrayList<String>();
      this.Q = true;
    }
    
    protected static CharSequence d(CharSequence param1CharSequence) {
      if (param1CharSequence == null)
        return param1CharSequence; 
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence.length() > 5120)
        charSequence = param1CharSequence.subSequence(0, 5120); 
      return charSequence;
    }
    
    private void k(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        Notification notification1 = this.R;
        notification1.flags = param1Int | notification1.flags;
        return;
      } 
      Notification notification = this.R;
      notification.flags = (param1Int ^ 0xFFFFFFFF) & notification.flags;
    }
    
    public d a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this.b.add(new l.a(param1Int, param1CharSequence, param1PendingIntent));
      return this;
    }
    
    public Notification b() {
      return (new m(this)).c();
    }
    
    public Bundle c() {
      if (this.D == null)
        this.D = new Bundle(); 
      return this.D;
    }
    
    public d e(boolean param1Boolean) {
      k(16, param1Boolean);
      return this;
    }
    
    public d f(String param1String) {
      this.K = param1String;
      return this;
    }
    
    public d g(PendingIntent param1PendingIntent) {
      this.g = param1PendingIntent;
      return this;
    }
    
    public d h(CharSequence param1CharSequence) {
      this.f = d(param1CharSequence);
      return this;
    }
    
    public d i(CharSequence param1CharSequence) {
      this.e = d(param1CharSequence);
      return this;
    }
    
    public d j(PendingIntent param1PendingIntent) {
      this.R.deleteIntent = param1PendingIntent;
      return this;
    }
    
    public d l(boolean param1Boolean) {
      this.z = param1Boolean;
      return this;
    }
    
    public d m(int param1Int) {
      this.m = param1Int;
      return this;
    }
    
    public d n(int param1Int) {
      this.R.icon = param1Int;
      return this;
    }
    
    public d o(l.e param1e) {
      if (this.p != param1e) {
        this.p = param1e;
        if (param1e != null)
          param1e.g(this); 
      } 
      return this;
    }
    
    public d p(CharSequence param1CharSequence) {
      this.R.tickerText = d(param1CharSequence);
      return this;
    }
    
    public d q(long param1Long) {
      this.R.when = param1Long;
      return this;
    }
  }
  
  public static abstract class e {
    protected l.d a;
    
    CharSequence b;
    
    CharSequence c;
    
    boolean d = false;
    
    public void a(Bundle param1Bundle) {
      if (this.d)
        param1Bundle.putCharSequence("android.summaryText", this.c); 
      CharSequence charSequence = this.b;
      if (charSequence != null)
        param1Bundle.putCharSequence("android.title.big", charSequence); 
      charSequence = c();
      if (charSequence != null)
        param1Bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", (String)charSequence); 
    }
    
    public abstract void b(k param1k);
    
    protected abstract String c();
    
    public RemoteViews d(k param1k) {
      return null;
    }
    
    public RemoteViews e(k param1k) {
      return null;
    }
    
    public RemoteViews f(k param1k) {
      return null;
    }
    
    public void g(l.d param1d) {
      if (this.a != param1d) {
        this.a = param1d;
        if (param1d != null)
          param1d.o(this); 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\app\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */