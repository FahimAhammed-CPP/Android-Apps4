package androidx.core.app;

import android.content.res.Configuration;

public final class i {
  private final boolean a;
  
  private final Configuration b;
  
  public i(boolean paramBoolean) {
    this.a = paramBoolean;
    this.b = null;
  }
  
  public i(boolean paramBoolean, Configuration paramConfiguration) {
    this.a = paramBoolean;
    this.b = paramConfiguration;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\app\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */