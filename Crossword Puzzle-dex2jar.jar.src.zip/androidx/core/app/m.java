package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import o.b;

class m implements k {
  private final Context a;
  
  private final Notification.Builder b;
  
  private final l.d c;
  
  private RemoteViews d;
  
  private RemoteViews e;
  
  private final List<Bundle> f;
  
  private final Bundle g;
  
  private int h;
  
  private RemoteViews i;
  
  m(l.d paramd) {
    boolean bool;
    this.f = new ArrayList<Bundle>();
    this.g = new Bundle();
    this.c = paramd;
    this.a = paramd.a;
    int i = Build.VERSION.SDK_INT;
    if (i >= 26) {
      this.b = new Notification.Builder(paramd.a, paramd.K);
    } else {
      this.b = new Notification.Builder(paramd.a);
    } 
    Notification notification = paramd.R;
    Notification.Builder builder = this.b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, paramd.i).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(paramd.e).setContentText(paramd.f).setContentInfo(paramd.k).setContentIntent(paramd.g).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = paramd.h;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(paramd.j).setNumber(paramd.l).setProgress(paramd.t, paramd.u, paramd.v);
    if (i < 21)
      this.b.setSound(notification.sound, notification.audioStreamType); 
    this.b.setSubText(paramd.q).setUsesChronometer(paramd.o).setPriority(paramd.m);
    Iterator<l.a> iterator = paramd.b.iterator();
    while (iterator.hasNext())
      b(iterator.next()); 
    Bundle bundle = paramd.D;
    if (bundle != null)
      this.g.putAll(bundle); 
    i = Build.VERSION.SDK_INT;
    if (i < 20) {
      if (paramd.z)
        this.g.putBoolean("android.support.localOnly", true); 
      String str = paramd.w;
      if (str != null) {
        this.g.putString("android.support.groupKey", str);
        if (paramd.x) {
          this.g.putBoolean("android.support.isGroupSummary", true);
        } else {
          this.g.putBoolean("android.support.useSideChannel", true);
        } 
      } 
      str = paramd.y;
      if (str != null)
        this.g.putString("android.support.sortKey", str); 
    } 
    this.d = paramd.H;
    this.e = paramd.I;
    this.b.setShowWhen(paramd.n);
    if (i < 21) {
      List<String> list = e(f(paramd.c), paramd.U);
      if (list != null && !list.isEmpty())
        this.g.putStringArray("android.people", list.<String>toArray(new String[list.size()])); 
    } 
    if (i >= 20) {
      this.b.setLocalOnly(paramd.z).setGroup(paramd.w).setGroupSummary(paramd.x).setSortKey(paramd.y);
      this.h = paramd.O;
    } 
    if (i >= 21) {
      List<String> list;
      this.b.setCategory(paramd.C).setColor(paramd.E).setVisibility(paramd.F).setPublicVersion(paramd.G).setSound(notification.sound, notification.audioAttributes);
      if (i < 28) {
        list = e(f(paramd.c), paramd.U);
      } else {
        list = paramd.U;
      } 
      if (list != null && !list.isEmpty())
        for (String str : list)
          this.b.addPerson(str);  
      this.i = paramd.J;
      if (paramd.d.size() > 0) {
        Bundle bundle2 = paramd.c().getBundle("android.car.EXTENSIONS");
        Bundle bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        bundle2 = new Bundle(bundle1);
        Bundle bundle3 = new Bundle();
        for (i = 0; i < paramd.d.size(); i++)
          bundle3.putBundle(Integer.toString(i), n.b(paramd.d.get(i))); 
        bundle1.putBundle("invisible_actions", bundle3);
        bundle2.putBundle("invisible_actions", bundle3);
        paramd.c().putBundle("android.car.EXTENSIONS", bundle1);
        this.g.putBundle("android.car.EXTENSIONS", bundle2);
      } 
    } 
    i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      Icon icon = paramd.T;
      if (icon != null)
        this.b.setSmallIcon(icon); 
    } 
    if (i >= 24) {
      this.b.setExtras(paramd.D).setRemoteInputHistory(paramd.s);
      RemoteViews remoteViews = paramd.H;
      if (remoteViews != null)
        this.b.setCustomContentView(remoteViews); 
      remoteViews = paramd.I;
      if (remoteViews != null)
        this.b.setCustomBigContentView(remoteViews); 
      remoteViews = paramd.J;
      if (remoteViews != null)
        this.b.setCustomHeadsUpContentView(remoteViews); 
    } 
    if (i >= 26) {
      this.b.setBadgeIconType(paramd.L).setSettingsText(paramd.r).setShortcutId(paramd.M).setTimeoutAfter(paramd.N).setGroupAlertBehavior(paramd.O);
      if (paramd.B)
        this.b.setColorized(paramd.A); 
      if (!TextUtils.isEmpty(paramd.K))
        this.b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (i >= 28)
      for (p p : paramd.c)
        this.b.addPerson(p.h());  
    i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      this.b.setAllowSystemGeneratedContextualActions(paramd.Q);
      this.b.setBubbleMetadata(l.c.a(null));
    } 
    if (i >= 31) {
      int j = paramd.P;
      if (j != 0)
        this.b.setForegroundServiceBehavior(j); 
    } 
    if (paramd.S) {
      if (this.c.x) {
        this.h = 2;
      } else {
        this.h = 1;
      } 
      this.b.setVibrate(null);
      this.b.setSound(null);
      int j = notification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
      notification.defaults = j;
      this.b.setDefaults(j);
      if (i >= 26) {
        if (TextUtils.isEmpty(this.c.w))
          this.b.setGroup("silent"); 
        this.b.setGroupAlertBehavior(this.h);
      } 
    } 
  }
  
  private void b(l.a parama) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 20) {
      Notification.Action.Builder builder;
      Bundle bundle;
      IconCompat iconCompat = parama.e();
      boolean bool = false;
      if (i >= 23) {
        if (iconCompat != null) {
          Icon icon = iconCompat.o();
        } else {
          iconCompat = null;
        } 
        builder = new Notification.Action.Builder((Icon)iconCompat, parama.i(), parama.a());
      } else {
        if (builder != null) {
          i = builder.h();
        } else {
          i = 0;
        } 
        builder = new Notification.Action.Builder(i, parama.i(), parama.a());
      } 
      if (parama.f() != null) {
        RemoteInput[] arrayOfRemoteInput = r.b(parama.f());
        int j = arrayOfRemoteInput.length;
        for (i = bool; i < j; i++)
          builder.addRemoteInput(arrayOfRemoteInput[i]); 
      } 
      if (parama.d() != null) {
        bundle = new Bundle(parama.d());
      } else {
        bundle = new Bundle();
      } 
      bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
      i = Build.VERSION.SDK_INT;
      if (i >= 24)
        builder.setAllowGeneratedReplies(parama.b()); 
      bundle.putInt("android.support.action.semanticAction", parama.g());
      if (i >= 28)
        builder.setSemanticAction(parama.g()); 
      if (i >= 29)
        builder.setContextual(parama.k()); 
      if (i >= 31)
        builder.setAuthenticationRequired(parama.j()); 
      bundle.putBoolean("android.support.action.showsUserInterface", parama.h());
      builder.addExtras(bundle);
      this.b.addAction(builder.build());
      return;
    } 
    this.f.add(n.e(this.b, parama));
  }
  
  private static List<String> e(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    b b = new b(paramList1.size() + paramList2.size());
    b.addAll(paramList1);
    b.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)b);
  }
  
  private static List<String> f(List<p> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<p> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(((p)iterator.next()).g()); 
    return arrayList;
  }
  
  private void g(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    paramNotification.defaults = paramNotification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
  }
  
  public Notification.Builder a() {
    return this.b;
  }
  
  public Notification c() {
    RemoteViews remoteViews;
    l.e e = this.c.p;
    if (e != null)
      e.b(this); 
    if (e != null) {
      remoteViews = e.e(this);
    } else {
      remoteViews = null;
    } 
    Notification notification = d();
    if (remoteViews != null) {
      notification.contentView = remoteViews;
    } else {
      remoteViews = this.c.H;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
    } 
    int i = Build.VERSION.SDK_INT;
    if (e != null) {
      remoteViews = e.d(this);
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
    } 
    if (i >= 21 && e != null) {
      remoteViews = this.c.p.f(this);
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
    } 
    if (e != null) {
      Bundle bundle = l.a(notification);
      if (bundle != null)
        e.a(bundle); 
    } 
    return notification;
  }
  
  protected Notification d() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26)
      return this.b.build(); 
    if (i >= 24) {
      Notification notification1 = this.b.build();
      if (this.h != 0) {
        if (notification1.getGroup() != null && (notification1.flags & 0x200) != 0 && this.h == 2)
          g(notification1); 
        if (notification1.getGroup() != null && (notification1.flags & 0x200) == 0 && this.h == 1)
          g(notification1); 
      } 
      return notification1;
    } 
    if (i >= 21) {
      this.b.setExtras(this.g);
      Notification notification1 = this.b.build();
      RemoteViews remoteViews1 = this.d;
      if (remoteViews1 != null)
        notification1.contentView = remoteViews1; 
      remoteViews1 = this.e;
      if (remoteViews1 != null)
        notification1.bigContentView = remoteViews1; 
      remoteViews1 = this.i;
      if (remoteViews1 != null)
        notification1.headsUpContentView = remoteViews1; 
      if (this.h != 0) {
        if (notification1.getGroup() != null && (notification1.flags & 0x200) != 0 && this.h == 2)
          g(notification1); 
        if (notification1.getGroup() != null && (notification1.flags & 0x200) == 0 && this.h == 1)
          g(notification1); 
      } 
      return notification1;
    } 
    if (i >= 20) {
      this.b.setExtras(this.g);
      Notification notification1 = this.b.build();
      RemoteViews remoteViews1 = this.d;
      if (remoteViews1 != null)
        notification1.contentView = remoteViews1; 
      remoteViews1 = this.e;
      if (remoteViews1 != null)
        notification1.bigContentView = remoteViews1; 
      if (this.h != 0) {
        if (notification1.getGroup() != null && (notification1.flags & 0x200) != 0 && this.h == 2)
          g(notification1); 
        if (notification1.getGroup() != null && (notification1.flags & 0x200) == 0 && this.h == 1)
          g(notification1); 
      } 
      return notification1;
    } 
    SparseArray<Bundle> sparseArray = n.a(this.f);
    if (sparseArray != null)
      this.g.putSparseParcelableArray("android.support.actionExtras", sparseArray); 
    this.b.setExtras(this.g);
    Notification notification = this.b.build();
    RemoteViews remoteViews = this.d;
    if (remoteViews != null)
      notification.contentView = remoteViews; 
    remoteViews = this.e;
    if (remoteViews != null)
      notification.bigContentView = remoteViews; 
    return notification;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\app\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */