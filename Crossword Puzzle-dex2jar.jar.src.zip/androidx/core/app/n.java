package androidx.core.app;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import androidx.core.graphics.drawable.IconCompat;
import java.util.List;

class n {
  private static final Object a = new Object();
  
  private static final Object b = new Object();
  
  public static SparseArray<Bundle> a(List<Bundle> paramList) {
    int j = paramList.size();
    SparseArray<Bundle> sparseArray = null;
    int i = 0;
    while (i < j) {
      Bundle bundle = paramList.get(i);
      SparseArray<Bundle> sparseArray1 = sparseArray;
      if (bundle != null) {
        sparseArray1 = sparseArray;
        if (sparseArray == null)
          sparseArray1 = new SparseArray(); 
        sparseArray1.put(i, bundle);
      } 
      i++;
      sparseArray = sparseArray1;
    } 
    return sparseArray;
  }
  
  static Bundle b(l.a parama) {
    boolean bool;
    Bundle bundle1;
    Bundle bundle2 = new Bundle();
    IconCompat iconCompat = parama.e();
    if (iconCompat != null) {
      bool = iconCompat.h();
    } else {
      bool = false;
    } 
    bundle2.putInt("icon", bool);
    bundle2.putCharSequence("title", parama.i());
    bundle2.putParcelable("actionIntent", (Parcelable)parama.a());
    if (parama.d() != null) {
      bundle1 = new Bundle(parama.d());
    } else {
      bundle1 = new Bundle();
    } 
    bundle1.putBoolean("android.support.allowGeneratedReplies", parama.b());
    bundle2.putBundle("extras", bundle1);
    bundle2.putParcelableArray("remoteInputs", (Parcelable[])d(parama.f()));
    bundle2.putBoolean("showsUserInterface", parama.h());
    bundle2.putInt("semanticAction", parama.g());
    return bundle2;
  }
  
  private static Bundle c(r paramr) {
    new Bundle();
    throw null;
  }
  
  private static Bundle[] d(r[] paramArrayOfr) {
    if (paramArrayOfr == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfr.length];
    for (int i = 0; i < paramArrayOfr.length; i++) {
      r r1 = paramArrayOfr[i];
      arrayOfBundle[i] = c(null);
    } 
    return arrayOfBundle;
  }
  
  public static Bundle e(Notification.Builder paramBuilder, l.a parama) {
    boolean bool;
    IconCompat iconCompat = parama.e();
    if (iconCompat != null) {
      bool = iconCompat.h();
    } else {
      bool = false;
    } 
    paramBuilder.addAction(bool, parama.i(), parama.a());
    Bundle bundle = new Bundle(parama.d());
    if (parama.f() != null)
      bundle.putParcelableArray("android.support.remoteInputs", (Parcelable[])d(parama.f())); 
    if (parama.c() != null)
      bundle.putParcelableArray("android.support.dataRemoteInputs", (Parcelable[])d(parama.c())); 
    bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
    return bundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */