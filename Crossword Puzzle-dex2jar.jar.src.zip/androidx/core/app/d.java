package androidx.core.app;

import android.app.Activity;
import android.app.Application;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

final class d {
  protected static final Class<?> a;
  
  protected static final Field b;
  
  protected static final Field c;
  
  protected static final Method d;
  
  protected static final Method e;
  
  protected static final Method f;
  
  private static final Handler g = new Handler(Looper.getMainLooper());
  
  static {
    Class<?> clazz = a();
    a = clazz;
    b = b();
    c = f();
    d = d(clazz);
    e = c(clazz);
    f = e(clazz);
  }
  
  private static Class<?> a() {
    try {
      return Class.forName("android.app.ActivityThread");
    } finally {
      Exception exception = null;
    } 
  }
  
  private static Field b() {
    try {
      Field field = Activity.class.getDeclaredField("mMainThread");
      return field;
    } finally {
      Exception exception = null;
    } 
  }
  
  private static Method c(Class<?> paramClass) {
    if (paramClass == null)
      return null; 
    try {
      Method method = paramClass.getDeclaredMethod("performStopActivity", new Class[] { IBinder.class, boolean.class });
      return method;
    } finally {
      paramClass = null;
    } 
  }
  
  private static Method d(Class<?> paramClass) {
    if (paramClass == null)
      return null; 
    try {
      Method method = paramClass.getDeclaredMethod("performStopActivity", new Class[] { IBinder.class, boolean.class, String.class });
      return method;
    } finally {
      paramClass = null;
    } 
  }
  
  private static Method e(Class<?> paramClass) {
    if (g()) {
      if (paramClass == null)
        return null; 
      try {
        Class<int> clazz = int.class;
        Class<boolean> clazz1 = boolean.class;
        Method method = paramClass.getDeclaredMethod("requestRelaunchActivity", new Class[] { IBinder.class, List.class, List.class, clazz, clazz1, Configuration.class, Configuration.class, clazz1, clazz1 });
        return method;
      } finally {
        paramClass = null;
      } 
    } 
    return null;
  }
  
  private static Field f() {
    try {
      Field field = Activity.class.getDeclaredField("mToken");
      return field;
    } finally {
      Exception exception = null;
    } 
  }
  
  private static boolean g() {
    int i = Build.VERSION.SDK_INT;
    return (i == 26 || i == 27);
  }
  
  protected static boolean h(Object paramObject, int paramInt, Activity paramActivity) {
    try {
      return false;
    } finally {
      paramObject = null;
      Log.e("ActivityRecreator", "Exception while fetching field values", (Throwable)paramObject);
    } 
  }
  
  static boolean i(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 28) {
      paramActivity.recreate();
      return true;
    } 
    if (g() && f == null)
      return false; 
    if (e == null && d == null)
      return false; 
    try {
      Object object1 = c.get(paramActivity);
      if (object1 == null)
        return false; 
      Object object2 = b.get(paramActivity);
      if (object2 == null)
        return false; 
      Application application = paramActivity.getApplication();
      d d1 = new d(paramActivity);
      application.registerActivityLifecycleCallbacks(d1);
      Handler handler = g;
      handler.post(new a(d1, object1));
    } finally {
      paramActivity = null;
    } 
  }
  
  class a implements Runnable {
    a(d this$0, Object param1Object) {}
    
    public void run() {
      this.o.o = this.p;
    }
  }
  
  class b implements Runnable {
    b(d this$0, d.d param1d) {}
    
    public void run() {
      this.o.unregisterActivityLifecycleCallbacks(this.p);
    }
  }
  
  class c implements Runnable {
    c(d this$0, Object param1Object1) {}
    
    public void run() {
      try {
        Method method = d.d;
        return;
      } catch (RuntimeException runtimeException) {
        return;
      } finally {
        Exception exception = null;
        Log.e("ActivityRecreator", "Exception while invoking performStopActivity", exception);
      } 
    }
  }
  
  private static final class d implements Application.ActivityLifecycleCallbacks {
    Object o;
    
    private Activity p;
    
    private final int q;
    
    private boolean r = false;
    
    private boolean s = false;
    
    private boolean t = false;
    
    d(Activity param1Activity) {
      this.p = param1Activity;
      this.q = param1Activity.hashCode();
    }
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityDestroyed(Activity param1Activity) {
      if (this.p == param1Activity) {
        this.p = null;
        this.s = true;
      } 
    }
    
    public void onActivityPaused(Activity param1Activity) {
      if (this.s && !this.t && !this.r && d.h(this.o, this.q, param1Activity)) {
        this.t = true;
        this.o = null;
      } 
    }
    
    public void onActivityResumed(Activity param1Activity) {}
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(Activity param1Activity) {
      if (this.p == param1Activity)
        this.r = true; 
    }
    
    public void onActivityStopped(Activity param1Activity) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */