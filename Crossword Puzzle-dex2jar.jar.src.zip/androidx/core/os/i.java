package androidx.core.os;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;

final class i implements j {
  private static final Locale[] c = new Locale[0];
  
  private static final Locale d = new Locale("en", "XA");
  
  private static final Locale e = new Locale("ar", "XB");
  
  private static final Locale f = h.b("en-Latn");
  
  private final Locale[] a;
  
  private final String b;
  
  i(Locale... paramVarArgs) {
    if (paramVarArgs.length == 0) {
      this.a = c;
      this.b = "";
      return;
    } 
    ArrayList<Locale> arrayList = new ArrayList();
    HashSet<Locale> hashSet = new HashSet();
    StringBuilder stringBuilder = new StringBuilder();
    int k = 0;
    while (k < paramVarArgs.length) {
      Locale locale = paramVarArgs[k];
      if (locale != null) {
        if (!hashSet.contains(locale)) {
          locale = (Locale)locale.clone();
          arrayList.add(locale);
          b(stringBuilder, locale);
          if (k < paramVarArgs.length - 1)
            stringBuilder.append(','); 
          hashSet.add(locale);
        } 
        k++;
        continue;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("list[");
      stringBuilder1.append(k);
      stringBuilder1.append("] is null");
      throw new NullPointerException(stringBuilder1.toString());
    } 
    this.a = arrayList.<Locale>toArray(new Locale[0]);
    this.b = stringBuilder.toString();
  }
  
  static void b(StringBuilder paramStringBuilder, Locale paramLocale) {
    paramStringBuilder.append(paramLocale.getLanguage());
    String str = paramLocale.getCountry();
    if (str != null && !str.isEmpty()) {
      paramStringBuilder.append('-');
      paramStringBuilder.append(paramLocale.getCountry());
    } 
  }
  
  public Object a() {
    return null;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof i))
      return false; 
    paramObject = ((i)paramObject).a;
    if (this.a.length != paramObject.length)
      return false; 
    int k = 0;
    while (true) {
      Locale[] arrayOfLocale = this.a;
      if (k < arrayOfLocale.length) {
        if (!arrayOfLocale[k].equals(paramObject[k]))
          return false; 
        k++;
        continue;
      } 
      return true;
    } 
  }
  
  public Locale get(int paramInt) {
    if (paramInt >= 0) {
      Locale[] arrayOfLocale = this.a;
      if (paramInt < arrayOfLocale.length)
        return arrayOfLocale[paramInt]; 
    } 
    return null;
  }
  
  public int hashCode() {
    Locale[] arrayOfLocale = this.a;
    int n = arrayOfLocale.length;
    int m = 1;
    for (int k = 0; k < n; k++)
      m = m * 31 + arrayOfLocale[k].hashCode(); 
    return m;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    int k = 0;
    while (true) {
      Locale[] arrayOfLocale = this.a;
      if (k < arrayOfLocale.length) {
        stringBuilder.append(arrayOfLocale[k]);
        if (k < this.a.length - 1)
          stringBuilder.append(','); 
        k++;
        continue;
      } 
      stringBuilder.append("]");
      return stringBuilder.toString();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\os\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */