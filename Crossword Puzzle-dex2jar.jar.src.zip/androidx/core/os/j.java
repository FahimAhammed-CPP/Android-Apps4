package androidx.core.os;

import java.util.Locale;

interface j {
  Object a();
  
  Locale get(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\os\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */