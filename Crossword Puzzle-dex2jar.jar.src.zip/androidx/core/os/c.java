package androidx.core.os;

import android.os.Bundle;
import android.util.Size;
import android.util.SizeF;
import c8.g;

final class c {
  public static final c a = new c();
  
  public static final void a(Bundle paramBundle, String paramString, Size paramSize) {
    g.e(paramBundle, "bundle");
    g.e(paramString, "key");
    paramBundle.putSize(paramString, paramSize);
  }
  
  public static final void b(Bundle paramBundle, String paramString, SizeF paramSizeF) {
    g.e(paramBundle, "bundle");
    g.e(paramString, "key");
    paramBundle.putSizeF(paramString, paramSizeF);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\os\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */