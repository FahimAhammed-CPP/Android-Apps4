package androidx.core.os;

import android.os.CancellationSignal;

public final class e {
  private boolean a;
  
  private b b;
  
  private Object c;
  
  private boolean d;
  
  private void d() {
    while (true) {
      if (this.d) {
        try {
          wait();
        } catch (InterruptedException interruptedException) {}
        continue;
      } 
      return;
    } 
  }
  
  public void a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Z
    //   6: ifeq -> 12
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: aload_0
    //   13: iconst_1
    //   14: putfield a : Z
    //   17: aload_0
    //   18: iconst_1
    //   19: putfield d : Z
    //   22: aload_0
    //   23: getfield b : Landroidx/core/os/e$b;
    //   26: astore_1
    //   27: aload_0
    //   28: getfield c : Ljava/lang/Object;
    //   31: astore_2
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: ifnull -> 47
    //   38: aload_1
    //   39: invokeinterface a : ()V
    //   44: goto -> 47
    //   47: aload_2
    //   48: ifnull -> 78
    //   51: aload_2
    //   52: invokestatic a : (Ljava/lang/Object;)V
    //   55: goto -> 78
    //   58: aload_0
    //   59: monitorenter
    //   60: aload_0
    //   61: iconst_0
    //   62: putfield d : Z
    //   65: aload_0
    //   66: invokevirtual notifyAll : ()V
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_1
    //   72: athrow
    //   73: astore_1
    //   74: aload_0
    //   75: monitorexit
    //   76: aload_1
    //   77: athrow
    //   78: aload_0
    //   79: monitorenter
    //   80: aload_0
    //   81: iconst_0
    //   82: putfield d : Z
    //   85: aload_0
    //   86: invokevirtual notifyAll : ()V
    //   89: aload_0
    //   90: monitorexit
    //   91: return
    //   92: astore_1
    //   93: aload_0
    //   94: monitorexit
    //   95: aload_1
    //   96: athrow
    //   97: astore_1
    //   98: aload_0
    //   99: monitorexit
    //   100: aload_1
    //   101: athrow
    //   102: astore_1
    //   103: goto -> 58
    // Exception table:
    //   from	to	target	type
    //   2	11	97	finally
    //   12	34	97	finally
    //   38	44	102	finally
    //   51	55	102	finally
    //   60	71	73	finally
    //   74	76	73	finally
    //   80	91	92	finally
    //   93	95	92	finally
    //   98	100	97	finally
  }
  
  public boolean b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	11	finally
    //   12	14	11	finally
  }
  
  public void c(b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial d : ()V
    //   6: aload_0
    //   7: getfield b : Landroidx/core/os/e$b;
    //   10: aload_1
    //   11: if_acmpne -> 17
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: aload_1
    //   19: putfield b : Landroidx/core/os/e$b;
    //   22: aload_0
    //   23: getfield a : Z
    //   26: ifeq -> 45
    //   29: aload_1
    //   30: ifnonnull -> 36
    //   33: goto -> 45
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: invokeinterface a : ()V
    //   44: return
    //   45: aload_0
    //   46: monitorexit
    //   47: return
    //   48: astore_1
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_1
    //   52: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	48	finally
    //   17	29	48	finally
    //   36	38	48	finally
    //   45	47	48	finally
    //   49	51	48	finally
  }
  
  static class a {
    static void a(Object param1Object) {
      ((CancellationSignal)param1Object).cancel();
    }
    
    static CancellationSignal b() {
      return new CancellationSignal();
    }
  }
  
  public static interface b {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\os\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */