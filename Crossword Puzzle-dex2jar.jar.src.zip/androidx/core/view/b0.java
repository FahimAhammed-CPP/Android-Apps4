package androidx.core.view;

import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import w.b;

public final class b0 {
  public static boolean a(ViewGroup paramViewGroup) {
    if (Build.VERSION.SDK_INT >= 21)
      return a.b(paramViewGroup); 
    Boolean bool = (Boolean)paramViewGroup.getTag(b.Q);
    return ((bool != null && bool.booleanValue()) || paramViewGroup.getBackground() != null || y.M((View)paramViewGroup) != null);
  }
  
  static class a {
    static int a(ViewGroup param1ViewGroup) {
      return param1ViewGroup.getNestedScrollAxes();
    }
    
    static boolean b(ViewGroup param1ViewGroup) {
      return param1ViewGroup.isTransitionGroup();
    }
    
    static void c(ViewGroup param1ViewGroup, boolean param1Boolean) {
      param1ViewGroup.setTransitionGroup(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */