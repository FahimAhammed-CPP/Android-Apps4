package androidx.core.view;

import android.view.View;
import android.view.ViewTreeObserver;
import java.util.Objects;

public final class v implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
  private final View o;
  
  private ViewTreeObserver p;
  
  private final Runnable q;
  
  private v(View paramView, Runnable paramRunnable) {
    this.o = paramView;
    this.p = paramView.getViewTreeObserver();
    this.q = paramRunnable;
  }
  
  public static v a(View paramView, Runnable paramRunnable) {
    Objects.requireNonNull(paramView, "view == null");
    Objects.requireNonNull(paramRunnable, "runnable == null");
    v v1 = new v(paramView, paramRunnable);
    paramView.getViewTreeObserver().addOnPreDrawListener(v1);
    paramView.addOnAttachStateChangeListener(v1);
    return v1;
  }
  
  public void b() {
    if (this.p.isAlive()) {
      this.p.removeOnPreDrawListener(this);
    } else {
      this.o.getViewTreeObserver().removeOnPreDrawListener(this);
    } 
    this.o.removeOnAttachStateChangeListener(this);
  }
  
  public boolean onPreDraw() {
    b();
    this.q.run();
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {
    this.p = paramView.getViewTreeObserver();
  }
  
  public void onViewDetachedFromWindow(View paramView) {
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */