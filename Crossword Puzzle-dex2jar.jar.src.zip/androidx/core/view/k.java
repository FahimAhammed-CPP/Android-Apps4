package androidx.core.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public interface k {
  boolean a(MenuItem paramMenuItem);
  
  void b(Menu paramMenu);
  
  void c(Menu paramMenu, MenuInflater paramMenuInflater);
  
  void d(Menu paramMenu);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */