package androidx.core.view.accessibility;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

public final class a extends ClickableSpan {
  private final int o;
  
  private final d p;
  
  private final int q;
  
  public a(int paramInt1, d paramd, int paramInt2) {
    this.o = paramInt1;
    this.p = paramd;
    this.q = paramInt2;
  }
  
  public void onClick(View paramView) {
    Bundle bundle = new Bundle();
    bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.o);
    this.p.N(this.q, bundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\accessibility\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */