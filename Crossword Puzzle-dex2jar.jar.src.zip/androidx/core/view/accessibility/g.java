package androidx.core.view.accessibility;

import android.os.Bundle;
import android.view.View;

public interface g {
  boolean a(View paramView, a parama);
  
  public static abstract class a {
    Bundle a;
    
    public void a(Bundle param1Bundle) {
      this.a = param1Bundle;
    }
  }
  
  public static final class b extends a {}
  
  public static final class c extends a {}
  
  public static final class d extends a {}
  
  public static final class e extends a {}
  
  public static final class f extends a {}
  
  public static final class g extends a {}
  
  public static final class h extends a {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\accessibility\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */