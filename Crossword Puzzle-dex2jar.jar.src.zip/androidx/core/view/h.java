package androidx.core.view;

import android.view.ViewGroup;

public final class h {
  public static int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams) {
    return a.b(paramMarginLayoutParams);
  }
  
  public static int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams) {
    return a.c(paramMarginLayoutParams);
  }
  
  public static void c(ViewGroup.MarginLayoutParams paramMarginLayoutParams, int paramInt) {
    a.g(paramMarginLayoutParams, paramInt);
  }
  
  public static void d(ViewGroup.MarginLayoutParams paramMarginLayoutParams, int paramInt) {
    a.h(paramMarginLayoutParams, paramInt);
  }
  
  static class a {
    static int a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      return param1MarginLayoutParams.getLayoutDirection();
    }
    
    static int b(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      return param1MarginLayoutParams.getMarginEnd();
    }
    
    static int c(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      return param1MarginLayoutParams.getMarginStart();
    }
    
    static boolean d(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      return param1MarginLayoutParams.isMarginRelative();
    }
    
    static void e(ViewGroup.MarginLayoutParams param1MarginLayoutParams, int param1Int) {
      param1MarginLayoutParams.resolveLayoutDirection(param1Int);
    }
    
    static void f(ViewGroup.MarginLayoutParams param1MarginLayoutParams, int param1Int) {
      param1MarginLayoutParams.setLayoutDirection(param1Int);
    }
    
    static void g(ViewGroup.MarginLayoutParams param1MarginLayoutParams, int param1Int) {
      param1MarginLayoutParams.setMarginEnd(param1Int);
    }
    
    static void h(ViewGroup.MarginLayoutParams param1MarginLayoutParams, int param1Int) {
      param1MarginLayoutParams.setMarginStart(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */