package androidx.core.view;

import android.os.Build;
import android.view.View;
import android.view.Window;

public final class i0 {
  public static k0 a(Window paramWindow, View paramView) {
    return new k0(paramWindow, paramView);
  }
  
  public static void b(Window paramWindow, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 30) {
      b.a(paramWindow, paramBoolean);
      return;
    } 
    a.a(paramWindow, paramBoolean);
  }
  
  static class a {
    static void a(Window param1Window, boolean param1Boolean) {
      View view = param1Window.getDecorView();
      int i = view.getSystemUiVisibility();
      if (param1Boolean) {
        i &= 0xFFFFF8FF;
      } else {
        i |= 0x700;
      } 
      view.setSystemUiVisibility(i);
    }
  }
  
  static class b {
    static void a(Window param1Window, boolean param1Boolean) {
      param1Window.setDecorFitsSystemWindows(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */