package androidx.core.view;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;
import o.g;

public final class k0 {
  private final e a;
  
  public k0(Window paramWindow, View paramView) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      this.a = new d(paramWindow, this);
      return;
    } 
    if (i >= 26) {
      this.a = new c(paramWindow, paramView);
      return;
    } 
    if (i >= 23) {
      this.a = new b(paramWindow, paramView);
      return;
    } 
    if (i >= 20) {
      this.a = new a(paramWindow, paramView);
      return;
    } 
    this.a = new e();
  }
  
  public void a(boolean paramBoolean) {
    this.a.a(paramBoolean);
  }
  
  public void b(boolean paramBoolean) {
    this.a.b(paramBoolean);
  }
  
  private static class a extends e {
    protected final Window a;
    
    private final View b;
    
    a(Window param1Window, View param1View) {
      this.a = param1Window;
      this.b = param1View;
    }
    
    protected void c(int param1Int) {
      View view = this.a.getDecorView();
      view.setSystemUiVisibility(param1Int | view.getSystemUiVisibility());
    }
    
    protected void d(int param1Int) {
      this.a.addFlags(param1Int);
    }
    
    protected void e(int param1Int) {
      View view = this.a.getDecorView();
      view.setSystemUiVisibility((param1Int ^ 0xFFFFFFFF) & view.getSystemUiVisibility());
    }
    
    protected void f(int param1Int) {
      this.a.clearFlags(param1Int);
    }
  }
  
  private static class b extends a {
    b(Window param1Window, View param1View) {
      super(param1Window, param1View);
    }
    
    public void b(boolean param1Boolean) {
      if (param1Boolean) {
        f(67108864);
        d(-2147483648);
        c(8192);
        return;
      } 
      e(8192);
    }
  }
  
  private static class c extends b {
    c(Window param1Window, View param1View) {
      super(param1Window, param1View);
    }
    
    public void a(boolean param1Boolean) {
      if (param1Boolean) {
        f(134217728);
        d(-2147483648);
        c(16);
        return;
      } 
      e(16);
    }
  }
  
  private static class d extends e {
    final k0 a;
    
    final WindowInsetsController b;
    
    private final g<Object, WindowInsetsController.OnControllableInsetsChangedListener> c = new g();
    
    protected Window d;
    
    d(Window param1Window, k0 param1k0) {
      this(param1Window.getInsetsController(), param1k0);
      this.d = param1Window;
    }
    
    d(WindowInsetsController param1WindowInsetsController, k0 param1k0) {
      this.b = param1WindowInsetsController;
      this.a = param1k0;
    }
    
    public void a(boolean param1Boolean) {
      if (param1Boolean) {
        if (this.d != null)
          c(16); 
        this.b.setSystemBarsAppearance(16, 16);
        return;
      } 
      if (this.d != null)
        d(16); 
      this.b.setSystemBarsAppearance(0, 16);
    }
    
    public void b(boolean param1Boolean) {
      if (param1Boolean) {
        if (this.d != null)
          c(8192); 
        this.b.setSystemBarsAppearance(8, 8);
        return;
      } 
      if (this.d != null)
        d(8192); 
      this.b.setSystemBarsAppearance(0, 8);
    }
    
    protected void c(int param1Int) {
      View view = this.d.getDecorView();
      view.setSystemUiVisibility(param1Int | view.getSystemUiVisibility());
    }
    
    protected void d(int param1Int) {
      View view = this.d.getDecorView();
      view.setSystemUiVisibility((param1Int ^ 0xFFFFFFFF) & view.getSystemUiVisibility());
    }
  }
  
  private static class e {
    public void a(boolean param1Boolean) {}
    
    public void b(boolean param1Boolean) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */