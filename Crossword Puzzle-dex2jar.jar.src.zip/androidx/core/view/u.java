package androidx.core.view;

public interface u {
  c a(c paramc);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\vie\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */