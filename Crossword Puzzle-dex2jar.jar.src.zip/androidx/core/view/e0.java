package androidx.core.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

public final class e0 {
  private final WeakReference<View> a;
  
  Runnable b = null;
  
  Runnable c = null;
  
  int d = -1;
  
  e0(View paramView) {
    this.a = new WeakReference<View>(paramView);
  }
  
  private void i(View paramView, f0 paramf0) {
    if (paramf0 != null) {
      paramView.animate().setListener((Animator.AnimatorListener)new a(this, paramf0, paramView));
      return;
    } 
    paramView.animate().setListener(null);
  }
  
  public e0 b(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().alpha(paramFloat); 
    return this;
  }
  
  public void c() {
    View view = this.a.get();
    if (view != null)
      view.animate().cancel(); 
  }
  
  public long d() {
    View view = this.a.get();
    return (view != null) ? view.animate().getDuration() : 0L;
  }
  
  public e0 f(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setDuration(paramLong); 
    return this;
  }
  
  public e0 g(Interpolator paramInterpolator) {
    View view = this.a.get();
    if (view != null)
      view.animate().setInterpolator((TimeInterpolator)paramInterpolator); 
    return this;
  }
  
  public e0 h(f0 paramf0) {
    View view = this.a.get();
    if (view != null)
      i(view, paramf0); 
    return this;
  }
  
  public e0 j(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setStartDelay(paramLong); 
    return this;
  }
  
  public e0 k(h0 paramh0) {
    View view = this.a.get();
    if (view != null) {
      d0 d0 = null;
      if (paramh0 != null)
        d0 = new d0(paramh0, view); 
      b.a(view.animate(), d0);
    } 
    return this;
  }
  
  public void l() {
    View view = this.a.get();
    if (view != null)
      view.animate().start(); 
  }
  
  public e0 m(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().translationY(paramFloat); 
    return this;
  }
  
  class a extends AnimatorListenerAdapter {
    a(e0 this$0, f0 param1f0, View param1View) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.a.a(this.b);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.b(this.b);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.c(this.b);
    }
  }
  
  static class b {
    static ViewPropertyAnimator a(ViewPropertyAnimator param1ViewPropertyAnimator, ValueAnimator.AnimatorUpdateListener param1AnimatorUpdateListener) {
      return param1ViewPropertyAnimator.setUpdateListener(param1AnimatorUpdateListener);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */