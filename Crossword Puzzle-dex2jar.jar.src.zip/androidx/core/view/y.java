package androidx.core.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContentInfo;
import android.view.Display;
import android.view.KeyEvent;
import android.view.OnReceiveContentListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import androidx.core.view.accessibility.d;
import androidx.core.view.accessibility.g;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class y {
  private static final AtomicInteger a = new AtomicInteger(1);
  
  private static WeakHashMap<View, String> b;
  
  private static WeakHashMap<View, e0> c = null;
  
  private static Field d;
  
  private static boolean e = false;
  
  private static ThreadLocal<Rect> f;
  
  private static final int[] g = new int[] { 
      w.b.b, w.b.c, w.b.n, w.b.y, w.b.B, w.b.C, w.b.D, w.b.E, w.b.F, w.b.G, 
      w.b.d, w.b.e, w.b.f, w.b.g, w.b.h, w.b.i, w.b.j, w.b.k, w.b.l, w.b.m, 
      w.b.o, w.b.p, w.b.q, w.b.r, w.b.s, w.b.t, w.b.u, w.b.v, w.b.w, w.b.x, 
      w.b.z, w.b.A };
  
  private static final u h = x.o;
  
  private static final e i = new e();
  
  private static u A(View paramView) {
    return (paramView instanceof u) ? (u)paramView : h;
  }
  
  @Deprecated
  public static void A0(View paramView, boolean paramBoolean) {
    paramView.setFitsSystemWindows(paramBoolean);
  }
  
  public static boolean B(View paramView) {
    return h.b(paramView);
  }
  
  public static void B0(View paramView, boolean paramBoolean) {
    h.r(paramView, paramBoolean);
  }
  
  public static int C(View paramView) {
    return h.c(paramView);
  }
  
  public static void C0(View paramView, int paramInt) {
    h.s(paramView, paramInt);
  }
  
  @SuppressLint({"InlinedApi"})
  public static int D(View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? o.b(paramView) : 0;
  }
  
  public static void D0(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 26)
      o.l(paramView, paramInt); 
  }
  
  public static int E(View paramView) {
    return i.d(paramView);
  }
  
  public static void E0(View paramView, int paramInt) {
    i.h(paramView, paramInt);
  }
  
  public static int F(View paramView) {
    return h.d(paramView);
  }
  
  public static void F0(View paramView, s params) {
    if (Build.VERSION.SDK_INT >= 21)
      m.u(paramView, params); 
  }
  
  public static int G(View paramView) {
    return h.e(paramView);
  }
  
  public static void G0(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    i.k(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static String[] H(View paramView) {
    return (Build.VERSION.SDK_INT >= 31) ? s.a(paramView) : (String[])paramView.getTag(w.b.N);
  }
  
  public static void H0(View paramView, boolean paramBoolean) {
    q0().g(paramView, Boolean.valueOf(paramBoolean));
  }
  
  public static int I(View paramView) {
    return i.e(paramView);
  }
  
  public static void I0(View paramView, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 23)
      n.d(paramView, paramInt1, paramInt2); 
  }
  
  public static int J(View paramView) {
    return i.f(paramView);
  }
  
  public static void J0(View paramView, String paramString) {
    if (Build.VERSION.SDK_INT >= 21) {
      m.v(paramView, paramString);
      return;
    } 
    if (b == null)
      b = new WeakHashMap<View, String>(); 
    b.put(paramView, paramString);
  }
  
  public static j0 K(View paramView) {
    int i = Build.VERSION.SDK_INT;
    return (i >= 23) ? n.a(paramView) : ((i >= 21) ? m.j(paramView) : null);
  }
  
  private static void K0(View paramView) {
    if (C(paramView) == 0)
      C0(paramView, 1); 
    for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
      if (C((View)viewParent) == 4) {
        C0(paramView, 2);
        return;
      } 
    } 
  }
  
  public static CharSequence L(View paramView) {
    return L0().f(paramView);
  }
  
  private static f<CharSequence> L0() {
    return new c(w.b.P, CharSequence.class, 64, 30);
  }
  
  public static String M(View paramView) {
    if (Build.VERSION.SDK_INT >= 21)
      return m.k(paramView); 
    WeakHashMap<View, String> weakHashMap = b;
    return (weakHashMap == null) ? null : weakHashMap.get(paramView);
  }
  
  public static void M0(View paramView) {
    if (Build.VERSION.SDK_INT >= 21) {
      m.z(paramView);
      return;
    } 
    if (paramView instanceof m)
      ((m)paramView).stopNestedScroll(); 
  }
  
  @Deprecated
  public static int N(View paramView) {
    return h.g(paramView);
  }
  
  private static void N0(View paramView) {
    float f = paramView.getTranslationY();
    paramView.setTranslationY(1.0F + f);
    paramView.setTranslationY(f);
  }
  
  public static float O(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? m.m(paramView) : 0.0F;
  }
  
  public static boolean P(View paramView) {
    return (o(paramView) != null);
  }
  
  public static boolean Q(View paramView) {
    return g.a(paramView);
  }
  
  public static boolean R(View paramView) {
    return h.h(paramView);
  }
  
  public static boolean S(View paramView) {
    return h.i(paramView);
  }
  
  public static boolean T(View paramView) {
    Boolean bool = b().f(paramView);
    return (bool != null && bool.booleanValue());
  }
  
  public static boolean U(View paramView) {
    return k.b(paramView);
  }
  
  public static boolean V(View paramView) {
    return k.c(paramView);
  }
  
  public static boolean W(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? m.p(paramView) : ((paramView instanceof m) ? ((m)paramView).isNestedScrollingEnabled() : false);
  }
  
  public static boolean X(View paramView) {
    return i.g(paramView);
  }
  
  public static boolean Y(View paramView) {
    Boolean bool = q0().f(paramView);
    return (bool != null && bool.booleanValue());
  }
  
  static void a0(View paramView, int paramInt) {
    boolean bool;
    AccessibilityEvent accessibilityEvent;
    AccessibilityManager accessibilityManager = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
    if (!accessibilityManager.isEnabled())
      return; 
    if (r(paramView) != null && paramView.isShown() && paramView.getWindowVisibility() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = q(paramView);
    char c = ' ';
    if (i != 0 || bool) {
      accessibilityEvent = AccessibilityEvent.obtain();
      if (!bool)
        c = 'ࠀ'; 
      accessibilityEvent.setEventType(c);
      k.g(accessibilityEvent, paramInt);
      if (bool) {
        accessibilityEvent.getText().add(r(paramView));
        K0(paramView);
      } 
      paramView.sendAccessibilityEventUnchecked(accessibilityEvent);
      return;
    } 
    if (paramInt == 32) {
      AccessibilityEvent accessibilityEvent1 = AccessibilityEvent.obtain();
      paramView.onInitializeAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.setEventType(32);
      k.g(accessibilityEvent1, paramInt);
      accessibilityEvent1.setSource(paramView);
      paramView.onPopulateAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.getText().add(r(paramView));
      accessibilityEvent.sendAccessibilityEvent(accessibilityEvent1);
      return;
    } 
    if (paramView.getParent() != null) {
      ViewParent viewParent = paramView.getParent();
      try {
        k.e(viewParent, paramView, paramView, paramInt);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramView.getParent().getClass().getSimpleName());
        stringBuilder.append(" does not fully implement ViewParent");
        Log.e("ViewCompat", stringBuilder.toString(), abstractMethodError);
        return;
      } 
    } 
  }
  
  private static f<Boolean> b() {
    return new d(w.b.J, Boolean.class, 28);
  }
  
  public static void b0(View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      paramView.offsetLeftAndRight(paramInt);
      return;
    } 
    if (i >= 21) {
      Rect rect = z();
      i = 0;
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
      } 
      f(paramView, paramInt);
      if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())) {
        ((View)viewParent).invalidate(rect);
        return;
      } 
    } else {
      f(paramView, paramInt);
    } 
  }
  
  public static int c(View paramView, CharSequence paramCharSequence, g paramg) {
    int i = t(paramView, paramCharSequence);
    if (i != -1)
      d(paramView, new d.a(i, paramCharSequence, paramg)); 
    return i;
  }
  
  public static void c0(View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      paramView.offsetTopAndBottom(paramInt);
      return;
    } 
    if (i >= 21) {
      Rect rect = z();
      i = 0;
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
      } 
      g(paramView, paramInt);
      if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())) {
        ((View)viewParent).invalidate(rect);
        return;
      } 
    } else {
      g(paramView, paramInt);
    } 
  }
  
  private static void d(View paramView, d.a parama) {
    if (Build.VERSION.SDK_INT >= 21) {
      l(paramView);
      m0(parama.b(), paramView);
      s(paramView).add(parama);
      a0(paramView, 0);
    } 
  }
  
  public static j0 d0(View paramView, j0 paramj0) {
    if (Build.VERSION.SDK_INT >= 21) {
      WindowInsets windowInsets = paramj0.t();
      if (windowInsets != null) {
        WindowInsets windowInsets1 = l.b(paramView, windowInsets);
        if (!windowInsets1.equals(windowInsets))
          return j0.v(windowInsets1, paramView); 
      } 
    } 
    return paramj0;
  }
  
  public static e0 e(View paramView) {
    if (c == null)
      c = new WeakHashMap<View, e0>(); 
    e0 e02 = c.get(paramView);
    e0 e01 = e02;
    if (e02 == null) {
      e01 = new e0(paramView);
      c.put(paramView, e01);
    } 
    return e01;
  }
  
  public static void e0(View paramView, d paramd) {
    paramView.onInitializeAccessibilityNodeInfo(paramd.w0());
  }
  
  private static void f(View paramView, int paramInt) {
    paramView.offsetLeftAndRight(paramInt);
    if (paramView.getVisibility() == 0) {
      N0(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        N0((View)viewParent); 
    } 
  }
  
  private static f<CharSequence> f0() {
    return new b(w.b.K, CharSequence.class, 8, 28);
  }
  
  private static void g(View paramView, int paramInt) {
    paramView.offsetTopAndBottom(paramInt);
    if (paramView.getVisibility() == 0) {
      N0(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        N0((View)viewParent); 
    } 
  }
  
  public static boolean g0(View paramView, int paramInt, Bundle paramBundle) {
    return h.j(paramView, paramInt, paramBundle);
  }
  
  public static j0 h(View paramView, j0 paramj0, Rect paramRect) {
    return (Build.VERSION.SDK_INT >= 21) ? m.b(paramView, paramj0, paramRect) : paramj0;
  }
  
  public static c h0(View paramView, c paramc) {
    if (Log.isLoggable("ViewCompat", 3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("performReceiveContent: ");
      stringBuilder.append(paramc);
      stringBuilder.append(", view=");
      stringBuilder.append(paramView.getClass().getSimpleName());
      stringBuilder.append("[");
      stringBuilder.append(paramView.getId());
      stringBuilder.append("]");
      Log.d("ViewCompat", stringBuilder.toString());
    } 
    if (Build.VERSION.SDK_INT >= 31)
      return s.b(paramView, paramc); 
    t t = (t)paramView.getTag(w.b.M);
    if (t != null) {
      paramc = t.a(paramView, paramc);
      return (paramc == null) ? null : A(paramView).a(paramc);
    } 
    return A(paramView).a(paramc);
  }
  
  public static j0 i(View paramView, j0 paramj0) {
    if (Build.VERSION.SDK_INT >= 21) {
      WindowInsets windowInsets = paramj0.t();
      if (windowInsets != null) {
        WindowInsets windowInsets1 = l.a(paramView, windowInsets);
        if (!windowInsets1.equals(windowInsets))
          return j0.v(windowInsets1, paramView); 
      } 
    } 
    return paramj0;
  }
  
  public static void i0(View paramView) {
    h.k(paramView);
  }
  
  static boolean j(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : v.a(paramView).b(paramView, paramKeyEvent);
  }
  
  public static void j0(View paramView, Runnable paramRunnable) {
    h.m(paramView, paramRunnable);
  }
  
  static boolean k(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : v.a(paramView).f(paramKeyEvent);
  }
  
  @SuppressLint({"LambdaLast"})
  public static void k0(View paramView, Runnable paramRunnable, long paramLong) {
    h.n(paramView, paramRunnable, paramLong);
  }
  
  static void l(View paramView) {
    a a2 = n(paramView);
    a a1 = a2;
    if (a2 == null)
      a1 = new a(); 
    r0(paramView, a1);
  }
  
  public static void l0(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 21) {
      m0(paramInt, paramView);
      a0(paramView, 0);
    } 
  }
  
  public static int m() {
    return i.a();
  }
  
  private static void m0(int paramInt, View paramView) {
    List<d.a> list = s(paramView);
    for (int i = 0; i < list.size(); i++) {
      if (((d.a)list.get(i)).b() == paramInt) {
        list.remove(i);
        return;
      } 
    } 
  }
  
  public static a n(View paramView) {
    View.AccessibilityDelegate accessibilityDelegate = o(paramView);
    return (accessibilityDelegate == null) ? null : ((accessibilityDelegate instanceof a.a) ? ((a.a)accessibilityDelegate).a : new a(accessibilityDelegate));
  }
  
  public static void n0(View paramView, d.a parama, CharSequence paramCharSequence, g paramg) {
    if (paramg == null && paramCharSequence == null) {
      l0(paramView, parama.b());
      return;
    } 
    d(paramView, parama.a(paramCharSequence, paramg));
  }
  
  private static View.AccessibilityDelegate o(View paramView) {
    return (Build.VERSION.SDK_INT >= 29) ? q.a(paramView) : p(paramView);
  }
  
  public static void o0(View paramView) {
    if (Build.VERSION.SDK_INT >= 20) {
      l.c(paramView);
      return;
    } 
    h.p(paramView);
  }
  
  private static View.AccessibilityDelegate p(View paramView) {
    // Byte code:
    //   0: getstatic androidx/core/view/y.e : Z
    //   3: ifeq -> 8
    //   6: aconst_null
    //   7: areturn
    //   8: getstatic androidx/core/view/y.d : Ljava/lang/reflect/Field;
    //   11: ifnonnull -> 41
    //   14: ldc android/view/View
    //   16: ldc_w 'mAccessibilityDelegate'
    //   19: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   22: astore_1
    //   23: aload_1
    //   24: putstatic androidx/core/view/y.d : Ljava/lang/reflect/Field;
    //   27: aload_1
    //   28: iconst_1
    //   29: invokevirtual setAccessible : (Z)V
    //   32: goto -> 41
    //   35: iconst_1
    //   36: putstatic androidx/core/view/y.e : Z
    //   39: aconst_null
    //   40: areturn
    //   41: getstatic androidx/core/view/y.d : Ljava/lang/reflect/Field;
    //   44: aload_0
    //   45: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   48: astore_0
    //   49: aload_0
    //   50: instanceof android/view/View$AccessibilityDelegate
    //   53: ifeq -> 63
    //   56: aload_0
    //   57: checkcast android/view/View$AccessibilityDelegate
    //   60: astore_0
    //   61: aload_0
    //   62: areturn
    //   63: aconst_null
    //   64: areturn
    //   65: iconst_1
    //   66: putstatic androidx/core/view/y.e : Z
    //   69: aconst_null
    //   70: areturn
    //   71: astore_0
    //   72: goto -> 35
    //   75: astore_0
    //   76: goto -> 65
    // Exception table:
    //   from	to	target	type
    //   14	32	71	finally
    //   41	61	75	finally
  }
  
  public static void p0(View paramView, @SuppressLint({"ContextFirst"}) Context paramContext, int[] paramArrayOfint, AttributeSet paramAttributeSet, TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 29)
      q.c(paramView, paramContext, paramArrayOfint, paramAttributeSet, paramTypedArray, paramInt1, paramInt2); 
  }
  
  public static int q(View paramView) {
    return k.a(paramView);
  }
  
  private static f<Boolean> q0() {
    return new a(w.b.O, Boolean.class, 28);
  }
  
  public static CharSequence r(View paramView) {
    return f0().f(paramView);
  }
  
  public static void r0(View paramView, a parama) {
    View.AccessibilityDelegate accessibilityDelegate;
    a a1 = parama;
    if (parama == null) {
      a1 = parama;
      if (o(paramView) instanceof a.a)
        a1 = new a(); 
    } 
    if (a1 == null) {
      parama = null;
    } else {
      accessibilityDelegate = a1.d();
    } 
    paramView.setAccessibilityDelegate(accessibilityDelegate);
  }
  
  private static List<d.a> s(View paramView) {
    int i = w.b.H;
    ArrayList<d.a> arrayList2 = (ArrayList)paramView.getTag(i);
    ArrayList<d.a> arrayList1 = arrayList2;
    if (arrayList2 == null) {
      arrayList1 = new ArrayList();
      paramView.setTag(i, arrayList1);
    } 
    return arrayList1;
  }
  
  public static void s0(View paramView, boolean paramBoolean) {
    b().g(paramView, Boolean.valueOf(paramBoolean));
  }
  
  private static int t(View paramView, CharSequence paramCharSequence) {
    List<d.a> list = s(paramView);
    int i;
    for (i = 0; i < list.size(); i++) {
      if (TextUtils.equals(paramCharSequence, ((d.a)list.get(i)).c()))
        return ((d.a)list.get(i)).b(); 
    } 
    i = 0;
    int j = -1;
    while (true) {
      int[] arrayOfInt = g;
      if (i < arrayOfInt.length && j == -1) {
        int n = arrayOfInt[i];
        int m = 0;
        int k = 1;
        while (m < list.size()) {
          byte b;
          if (((d.a)list.get(m)).b() != n) {
            b = 1;
          } else {
            b = 0;
          } 
          k &= b;
          m++;
        } 
        if (k != 0)
          j = n; 
        i++;
        continue;
      } 
      break;
    } 
    return j;
  }
  
  public static void t0(View paramView, int paramInt) {
    k.f(paramView, paramInt);
  }
  
  public static ColorStateList u(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? m.g(paramView) : ((paramView instanceof w) ? ((w)paramView).getSupportBackgroundTintList() : null);
  }
  
  public static void u0(View paramView, CharSequence paramCharSequence) {
    f0().g(paramView, paramCharSequence);
    if (paramCharSequence != null) {
      i.a(paramView);
      return;
    } 
    i.d(paramView);
  }
  
  public static PorterDuff.Mode v(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? m.h(paramView) : ((paramView instanceof w) ? ((w)paramView).getSupportBackgroundTintMode() : null);
  }
  
  public static void v0(View paramView, Drawable paramDrawable) {
    h.q(paramView, paramDrawable);
  }
  
  public static Rect w(View paramView) {
    return j.a(paramView);
  }
  
  public static void w0(View paramView, ColorStateList paramColorStateList) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      m.q(paramView, paramColorStateList);
      if (i == 21) {
        drawable = paramView.getBackground();
        if (m.g(paramView) != null || m.h(paramView) != null) {
          i = 1;
        } else {
          i = 0;
        } 
        if (drawable != null && i != 0) {
          if (drawable.isStateful())
            drawable.setState(paramView.getDrawableState()); 
          h.q(paramView, drawable);
          return;
        } 
      } 
    } else if (paramView instanceof w) {
      ((w)paramView).setSupportBackgroundTintList((ColorStateList)drawable);
    } 
  }
  
  public static Display x(View paramView) {
    return i.b(paramView);
  }
  
  public static void x0(View paramView, PorterDuff.Mode paramMode) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      m.r(paramView, paramMode);
      if (i == 21) {
        drawable = paramView.getBackground();
        if (m.g(paramView) != null || m.h(paramView) != null) {
          i = 1;
        } else {
          i = 0;
        } 
        if (drawable != null && i != 0) {
          if (drawable.isStateful())
            drawable.setState(paramView.getDrawableState()); 
          h.q(paramView, drawable);
          return;
        } 
      } 
    } else if (paramView instanceof w) {
      ((w)paramView).setSupportBackgroundTintMode((PorterDuff.Mode)drawable);
    } 
  }
  
  public static float y(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? m.i(paramView) : 0.0F;
  }
  
  public static void y0(View paramView, Rect paramRect) {
    j.c(paramView, paramRect);
  }
  
  private static Rect z() {
    if (f == null)
      f = new ThreadLocal<Rect>(); 
    Rect rect2 = f.get();
    Rect rect1 = rect2;
    if (rect2 == null) {
      rect1 = new Rect();
      f.set(rect1);
    } 
    rect1.setEmpty();
    return rect1;
  }
  
  public static void z0(View paramView, float paramFloat) {
    if (Build.VERSION.SDK_INT >= 21)
      m.s(paramView, paramFloat); 
  }
  
  class a extends f<Boolean> {
    a(y this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    Boolean i(View param1View) {
      return Boolean.valueOf(y.p.d(param1View));
    }
    
    void j(View param1View, Boolean param1Boolean) {
      y.p.i(param1View, param1Boolean.booleanValue());
    }
    
    boolean k(Boolean param1Boolean1, Boolean param1Boolean2) {
      return a(param1Boolean1, param1Boolean2) ^ true;
    }
  }
  
  class b extends f<CharSequence> {
    b(y this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    CharSequence i(View param1View) {
      return y.p.b(param1View);
    }
    
    void j(View param1View, CharSequence param1CharSequence) {
      y.p.h(param1View, param1CharSequence);
    }
    
    boolean k(CharSequence param1CharSequence1, CharSequence param1CharSequence2) {
      return TextUtils.equals(param1CharSequence1, param1CharSequence2) ^ true;
    }
  }
  
  class c extends f<CharSequence> {
    c(y this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    CharSequence i(View param1View) {
      return y.r.a(param1View);
    }
    
    void j(View param1View, CharSequence param1CharSequence) {
      y.r.b(param1View, param1CharSequence);
    }
    
    boolean k(CharSequence param1CharSequence1, CharSequence param1CharSequence2) {
      return TextUtils.equals(param1CharSequence1, param1CharSequence2) ^ true;
    }
  }
  
  class d extends f<Boolean> {
    d(y this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    Boolean i(View param1View) {
      return Boolean.valueOf(y.p.c(param1View));
    }
    
    void j(View param1View, Boolean param1Boolean) {
      y.p.g(param1View, param1Boolean.booleanValue());
    }
    
    boolean k(Boolean param1Boolean1, Boolean param1Boolean2) {
      return a(param1Boolean1, param1Boolean2) ^ true;
    }
  }
  
  static class e implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {
    private final WeakHashMap<View, Boolean> o = new WeakHashMap<View, Boolean>();
    
    private void b(View param1View, boolean param1Boolean) {
      boolean bool;
      if (param1View.isShown() && param1View.getWindowVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (param1Boolean != bool) {
        byte b;
        if (bool) {
          b = 16;
        } else {
          b = 32;
        } 
        y.a0(param1View, b);
        this.o.put(param1View, Boolean.valueOf(bool));
      } 
    }
    
    private void c(View param1View) {
      param1View.getViewTreeObserver().addOnGlobalLayoutListener(this);
    }
    
    private void e(View param1View) {
      y.h.o(param1View.getViewTreeObserver(), this);
    }
    
    void a(View param1View) {
      boolean bool;
      WeakHashMap<View, Boolean> weakHashMap = this.o;
      if (param1View.isShown() && param1View.getWindowVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      weakHashMap.put(param1View, Boolean.valueOf(bool));
      param1View.addOnAttachStateChangeListener(this);
      if (y.k.b(param1View))
        c(param1View); 
    }
    
    void d(View param1View) {
      this.o.remove(param1View);
      param1View.removeOnAttachStateChangeListener(this);
      e(param1View);
    }
    
    public void onGlobalLayout() {
      if (Build.VERSION.SDK_INT < 28)
        for (Map.Entry<View, Boolean> entry : this.o.entrySet())
          b((View)entry.getKey(), ((Boolean)entry.getValue()).booleanValue());  
    }
    
    public void onViewAttachedToWindow(View param1View) {
      c(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
  
  static abstract class f<T> {
    private final int a;
    
    private final Class<T> b;
    
    private final int c;
    
    private final int d;
    
    f(int param1Int1, Class<T> param1Class, int param1Int2) {
      this(param1Int1, param1Class, 0, param1Int2);
    }
    
    f(int param1Int1, Class<T> param1Class, int param1Int2, int param1Int3) {
      this.a = param1Int1;
      this.b = param1Class;
      this.d = param1Int2;
      this.c = param1Int3;
    }
    
    private boolean b() {
      return true;
    }
    
    private boolean c() {
      return (Build.VERSION.SDK_INT >= this.c);
    }
    
    boolean a(Boolean param1Boolean1, Boolean param1Boolean2) {
      boolean bool1;
      boolean bool2;
      if (param1Boolean1 != null && param1Boolean1.booleanValue()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (param1Boolean2 != null && param1Boolean2.booleanValue()) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      return (bool1 == bool2);
    }
    
    abstract T d(View param1View);
    
    abstract void e(View param1View, T param1T);
    
    T f(View param1View) {
      if (c())
        return d(param1View); 
      if (b()) {
        Object object = param1View.getTag(this.a);
        if (this.b.isInstance(object))
          return (T)object; 
      } 
      return null;
    }
    
    void g(View param1View, T param1T) {
      if (c()) {
        e(param1View, param1T);
        return;
      } 
      if (b() && h(f(param1View), param1T)) {
        y.l(param1View);
        param1View.setTag(this.a, param1T);
        y.a0(param1View, this.d);
      } 
    }
    
    abstract boolean h(T param1T1, T param1T2);
  }
  
  static class g {
    static boolean a(View param1View) {
      return param1View.hasOnClickListeners();
    }
  }
  
  static class h {
    static AccessibilityNodeProvider a(View param1View) {
      return param1View.getAccessibilityNodeProvider();
    }
    
    static boolean b(View param1View) {
      return param1View.getFitsSystemWindows();
    }
    
    static int c(View param1View) {
      return param1View.getImportantForAccessibility();
    }
    
    static int d(View param1View) {
      return param1View.getMinimumHeight();
    }
    
    static int e(View param1View) {
      return param1View.getMinimumWidth();
    }
    
    static ViewParent f(View param1View) {
      return param1View.getParentForAccessibility();
    }
    
    static int g(View param1View) {
      return param1View.getWindowSystemUiVisibility();
    }
    
    static boolean h(View param1View) {
      return param1View.hasOverlappingRendering();
    }
    
    static boolean i(View param1View) {
      return param1View.hasTransientState();
    }
    
    static boolean j(View param1View, int param1Int, Bundle param1Bundle) {
      return param1View.performAccessibilityAction(param1Int, param1Bundle);
    }
    
    static void k(View param1View) {
      param1View.postInvalidateOnAnimation();
    }
    
    static void l(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.postInvalidateOnAnimation(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void m(View param1View, Runnable param1Runnable) {
      param1View.postOnAnimation(param1Runnable);
    }
    
    static void n(View param1View, Runnable param1Runnable, long param1Long) {
      param1View.postOnAnimationDelayed(param1Runnable, param1Long);
    }
    
    static void o(ViewTreeObserver param1ViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {
      param1ViewTreeObserver.removeOnGlobalLayoutListener(param1OnGlobalLayoutListener);
    }
    
    static void p(View param1View) {
      param1View.requestFitSystemWindows();
    }
    
    static void q(View param1View, Drawable param1Drawable) {
      param1View.setBackground(param1Drawable);
    }
    
    static void r(View param1View, boolean param1Boolean) {
      param1View.setHasTransientState(param1Boolean);
    }
    
    static void s(View param1View, int param1Int) {
      param1View.setImportantForAccessibility(param1Int);
    }
  }
  
  static class i {
    static int a() {
      return View.generateViewId();
    }
    
    static Display b(View param1View) {
      return param1View.getDisplay();
    }
    
    static int c(View param1View) {
      return param1View.getLabelFor();
    }
    
    static int d(View param1View) {
      return param1View.getLayoutDirection();
    }
    
    static int e(View param1View) {
      return param1View.getPaddingEnd();
    }
    
    static int f(View param1View) {
      return param1View.getPaddingStart();
    }
    
    static boolean g(View param1View) {
      return param1View.isPaddingRelative();
    }
    
    static void h(View param1View, int param1Int) {
      param1View.setLabelFor(param1Int);
    }
    
    static void i(View param1View, Paint param1Paint) {
      param1View.setLayerPaint(param1Paint);
    }
    
    static void j(View param1View, int param1Int) {
      param1View.setLayoutDirection(param1Int);
    }
    
    static void k(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.setPaddingRelative(param1Int1, param1Int2, param1Int3, param1Int4);
    }
  }
  
  static class j {
    static Rect a(View param1View) {
      return param1View.getClipBounds();
    }
    
    static boolean b(View param1View) {
      return param1View.isInLayout();
    }
    
    static void c(View param1View, Rect param1Rect) {
      param1View.setClipBounds(param1Rect);
    }
  }
  
  static class k {
    static int a(View param1View) {
      return param1View.getAccessibilityLiveRegion();
    }
    
    static boolean b(View param1View) {
      return param1View.isAttachedToWindow();
    }
    
    static boolean c(View param1View) {
      return param1View.isLaidOut();
    }
    
    static boolean d(View param1View) {
      return param1View.isLayoutDirectionResolved();
    }
    
    static void e(ViewParent param1ViewParent, View param1View1, View param1View2, int param1Int) {
      param1ViewParent.notifySubtreeAccessibilityStateChanged(param1View1, param1View2, param1Int);
    }
    
    static void f(View param1View, int param1Int) {
      param1View.setAccessibilityLiveRegion(param1Int);
    }
    
    static void g(AccessibilityEvent param1AccessibilityEvent, int param1Int) {
      param1AccessibilityEvent.setContentChangeTypes(param1Int);
    }
  }
  
  static class l {
    static WindowInsets a(View param1View, WindowInsets param1WindowInsets) {
      return param1View.dispatchApplyWindowInsets(param1WindowInsets);
    }
    
    static WindowInsets b(View param1View, WindowInsets param1WindowInsets) {
      return param1View.onApplyWindowInsets(param1WindowInsets);
    }
    
    static void c(View param1View) {
      param1View.requestApplyInsets();
    }
  }
  
  private static class m {
    static void a(WindowInsets param1WindowInsets, View param1View) {
      View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener)param1View.getTag(w.b.T);
      if (onApplyWindowInsetsListener != null)
        onApplyWindowInsetsListener.onApplyWindowInsets(param1View, param1WindowInsets); 
    }
    
    static j0 b(View param1View, j0 param1j0, Rect param1Rect) {
      WindowInsets windowInsets = param1j0.t();
      if (windowInsets != null)
        return j0.v(param1View.computeSystemWindowInsets(windowInsets, param1Rect), param1View); 
      param1Rect.setEmpty();
      return param1j0;
    }
    
    static boolean c(View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return param1View.dispatchNestedFling(param1Float1, param1Float2, param1Boolean);
    }
    
    static boolean d(View param1View, float param1Float1, float param1Float2) {
      return param1View.dispatchNestedPreFling(param1Float1, param1Float2);
    }
    
    static boolean e(View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint1, int[] param1ArrayOfint2) {
      return param1View.dispatchNestedPreScroll(param1Int1, param1Int2, param1ArrayOfint1, param1ArrayOfint2);
    }
    
    static boolean f(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int[] param1ArrayOfint) {
      return param1View.dispatchNestedScroll(param1Int1, param1Int2, param1Int3, param1Int4, param1ArrayOfint);
    }
    
    static ColorStateList g(View param1View) {
      return param1View.getBackgroundTintList();
    }
    
    static PorterDuff.Mode h(View param1View) {
      return param1View.getBackgroundTintMode();
    }
    
    static float i(View param1View) {
      return param1View.getElevation();
    }
    
    public static j0 j(View param1View) {
      return j0.a.a(param1View);
    }
    
    static String k(View param1View) {
      return param1View.getTransitionName();
    }
    
    static float l(View param1View) {
      return param1View.getTranslationZ();
    }
    
    static float m(View param1View) {
      return param1View.getZ();
    }
    
    static boolean n(View param1View) {
      return param1View.hasNestedScrollingParent();
    }
    
    static boolean o(View param1View) {
      return param1View.isImportantForAccessibility();
    }
    
    static boolean p(View param1View) {
      return param1View.isNestedScrollingEnabled();
    }
    
    static void q(View param1View, ColorStateList param1ColorStateList) {
      param1View.setBackgroundTintList(param1ColorStateList);
    }
    
    static void r(View param1View, PorterDuff.Mode param1Mode) {
      param1View.setBackgroundTintMode(param1Mode);
    }
    
    static void s(View param1View, float param1Float) {
      param1View.setElevation(param1Float);
    }
    
    static void t(View param1View, boolean param1Boolean) {
      param1View.setNestedScrollingEnabled(param1Boolean);
    }
    
    static void u(View param1View, s param1s) {
      if (Build.VERSION.SDK_INT < 30)
        param1View.setTag(w.b.L, param1s); 
      if (param1s == null) {
        param1View.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener)param1View.getTag(w.b.T));
        return;
      } 
      param1View.setOnApplyWindowInsetsListener(new a(param1View, param1s));
    }
    
    static void v(View param1View, String param1String) {
      param1View.setTransitionName(param1String);
    }
    
    static void w(View param1View, float param1Float) {
      param1View.setTranslationZ(param1Float);
    }
    
    static void x(View param1View, float param1Float) {
      param1View.setZ(param1Float);
    }
    
    static boolean y(View param1View, int param1Int) {
      return param1View.startNestedScroll(param1Int);
    }
    
    static void z(View param1View) {
      param1View.stopNestedScroll();
    }
    
    class a implements View.OnApplyWindowInsetsListener {
      j0 a = null;
      
      a(y.m this$0, s param2s) {}
      
      public WindowInsets onApplyWindowInsets(View param2View, WindowInsets param2WindowInsets) {
        j0 j02 = j0.v(param2WindowInsets, param2View);
        int i = Build.VERSION.SDK_INT;
        if (i < 30) {
          y.m.a(param2WindowInsets, this.b);
          if (j02.equals(this.a))
            return this.c.a(param2View, j02).t(); 
        } 
        this.a = j02;
        j0 j01 = this.c.a(param2View, j02);
        if (i >= 30)
          return j01.t(); 
        y.o0(param2View);
        return j01.t();
      }
    }
  }
  
  class a implements View.OnApplyWindowInsetsListener {
    j0 a = null;
    
    a(y this$0, s param1s) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      j0 j02 = j0.v(param1WindowInsets, param1View);
      int i = Build.VERSION.SDK_INT;
      if (i < 30) {
        y.m.a(param1WindowInsets, this.b);
        if (j02.equals(this.a))
          return this.c.a(param1View, j02).t(); 
      } 
      this.a = j02;
      j0 j01 = this.c.a(param1View, j02);
      if (i >= 30)
        return j01.t(); 
      y.o0(param1View);
      return j01.t();
    }
  }
  
  private static class n {
    public static j0 a(View param1View) {
      WindowInsets windowInsets = param1View.getRootWindowInsets();
      if (windowInsets == null)
        return null; 
      j0 j0 = j0.u(windowInsets);
      j0.r(j0);
      j0.d(param1View.getRootView());
      return j0;
    }
    
    static int b(View param1View) {
      return param1View.getScrollIndicators();
    }
    
    static void c(View param1View, int param1Int) {
      param1View.setScrollIndicators(param1Int);
    }
    
    static void d(View param1View, int param1Int1, int param1Int2) {
      param1View.setScrollIndicators(param1Int1, param1Int2);
    }
  }
  
  static class o {
    static void a(View param1View, Collection<View> param1Collection, int param1Int) {
      param1View.addKeyboardNavigationClusters(param1Collection, param1Int);
    }
    
    static int b(View param1View) {
      return param1View.getImportantForAutofill();
    }
    
    static int c(View param1View) {
      return param1View.getNextClusterForwardId();
    }
    
    static boolean d(View param1View) {
      return param1View.hasExplicitFocusable();
    }
    
    static boolean e(View param1View) {
      return param1View.isFocusedByDefault();
    }
    
    static boolean f(View param1View) {
      return param1View.isImportantForAutofill();
    }
    
    static boolean g(View param1View) {
      return param1View.isKeyboardNavigationCluster();
    }
    
    static View h(View param1View1, View param1View2, int param1Int) {
      return param1View1.keyboardNavigationClusterSearch(param1View2, param1Int);
    }
    
    static boolean i(View param1View) {
      return param1View.restoreDefaultFocus();
    }
    
    static void j(View param1View, String... param1VarArgs) {
      param1View.setAutofillHints(param1VarArgs);
    }
    
    static void k(View param1View, boolean param1Boolean) {
      param1View.setFocusedByDefault(param1Boolean);
    }
    
    static void l(View param1View, int param1Int) {
      param1View.setImportantForAutofill(param1Int);
    }
    
    static void m(View param1View, boolean param1Boolean) {
      param1View.setKeyboardNavigationCluster(param1Boolean);
    }
    
    static void n(View param1View, int param1Int) {
      param1View.setNextClusterForwardId(param1Int);
    }
    
    static void o(View param1View, CharSequence param1CharSequence) {
      param1View.setTooltipText(param1CharSequence);
    }
  }
  
  static class p {
    static void a(View param1View, y.u param1u) {
      int i = w.b.S;
      o.g g2 = (o.g)param1View.getTag(i);
      o.g g1 = g2;
      if (g2 == null) {
        g1 = new o.g();
        param1View.setTag(i, g1);
      } 
      Objects.requireNonNull(param1u);
      z z = new z(param1u);
      g1.put(param1u, z);
      param1View.addOnUnhandledKeyEventListener(z);
    }
    
    static CharSequence b(View param1View) {
      return param1View.getAccessibilityPaneTitle();
    }
    
    static boolean c(View param1View) {
      return param1View.isAccessibilityHeading();
    }
    
    static boolean d(View param1View) {
      return param1View.isScreenReaderFocusable();
    }
    
    static void e(View param1View, y.u param1u) {
      o.g g = (o.g)param1View.getTag(w.b.S);
      if (g == null)
        return; 
      View.OnUnhandledKeyEventListener onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener)g.get(param1u);
      if (onUnhandledKeyEventListener != null)
        param1View.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener); 
    }
    
    static <T> T f(View param1View, int param1Int) {
      return (T)param1View.requireViewById(param1Int);
    }
    
    static void g(View param1View, boolean param1Boolean) {
      param1View.setAccessibilityHeading(param1Boolean);
    }
    
    static void h(View param1View, CharSequence param1CharSequence) {
      param1View.setAccessibilityPaneTitle(param1CharSequence);
    }
    
    static void i(View param1View, boolean param1Boolean) {
      param1View.setScreenReaderFocusable(param1Boolean);
    }
  }
  
  private static class q {
    static View.AccessibilityDelegate a(View param1View) {
      return param1View.getAccessibilityDelegate();
    }
    
    static List<Rect> b(View param1View) {
      return param1View.getSystemGestureExclusionRects();
    }
    
    static void c(View param1View, Context param1Context, int[] param1ArrayOfint, AttributeSet param1AttributeSet, TypedArray param1TypedArray, int param1Int1, int param1Int2) {
      param1View.saveAttributeDataForStyleable(param1Context, param1ArrayOfint, param1AttributeSet, param1TypedArray, param1Int1, param1Int2);
    }
    
    static void d(View param1View, List<Rect> param1List) {
      param1View.setSystemGestureExclusionRects(param1List);
    }
  }
  
  private static class r {
    static CharSequence a(View param1View) {
      return param1View.getStateDescription();
    }
    
    static void b(View param1View, CharSequence param1CharSequence) {
      param1View.setStateDescription(param1CharSequence);
    }
  }
  
  private static final class s {
    public static String[] a(View param1View) {
      return param1View.getReceiveContentMimeTypes();
    }
    
    public static c b(View param1View, c param1c) {
      ContentInfo contentInfo2 = param1c.f();
      ContentInfo contentInfo1 = param1View.performReceiveContent(contentInfo2);
      return (contentInfo1 == null) ? null : ((contentInfo1 == contentInfo2) ? param1c : c.g(contentInfo1));
    }
    
    public static void c(View param1View, String[] param1ArrayOfString, t param1t) {
      if (param1t == null) {
        param1View.setOnReceiveContentListener(param1ArrayOfString, null);
        return;
      } 
      param1View.setOnReceiveContentListener(param1ArrayOfString, new y.t(param1t));
    }
  }
  
  private static final class t implements OnReceiveContentListener {
    private final t a;
    
    t(t param1t) {
      this.a = param1t;
    }
    
    public ContentInfo onReceiveContent(View param1View, ContentInfo param1ContentInfo) {
      c c2 = c.g(param1ContentInfo);
      c c1 = this.a.a(param1View, c2);
      return (c1 == null) ? null : ((c1 == c2) ? param1ContentInfo : c1.f());
    }
  }
  
  public static interface u {
    boolean onUnhandledKeyEvent(View param1View, KeyEvent param1KeyEvent);
  }
  
  static class v {
    private static final ArrayList<WeakReference<View>> d = new ArrayList<WeakReference<View>>();
    
    private WeakHashMap<View, Boolean> a = null;
    
    private SparseArray<WeakReference<View>> b = null;
    
    private WeakReference<KeyEvent> c = null;
    
    static v a(View param1View) {
      int i = w.b.R;
      v v2 = (v)param1View.getTag(i);
      v v1 = v2;
      if (v2 == null) {
        v1 = new v();
        param1View.setTag(i, v1);
      } 
      return v1;
    }
    
    private View c(View param1View, KeyEvent param1KeyEvent) {
      WeakHashMap<View, Boolean> weakHashMap = this.a;
      if (weakHashMap != null) {
        if (!weakHashMap.containsKey(param1View))
          return null; 
        if (param1View instanceof ViewGroup) {
          ViewGroup viewGroup = (ViewGroup)param1View;
          for (int i = viewGroup.getChildCount() - 1; i >= 0; i--) {
            View view = c(viewGroup.getChildAt(i), param1KeyEvent);
            if (view != null)
              return view; 
          } 
        } 
        if (e(param1View, param1KeyEvent))
          return param1View; 
      } 
      return null;
    }
    
    private SparseArray<WeakReference<View>> d() {
      if (this.b == null)
        this.b = new SparseArray(); 
      return this.b;
    }
    
    private boolean e(View param1View, KeyEvent param1KeyEvent) {
      ArrayList<y.u> arrayList = (ArrayList)param1View.getTag(w.b.S);
      if (arrayList != null)
        for (int i = arrayList.size() - 1; i >= 0; i--) {
          if (((y.u)arrayList.get(i)).onUnhandledKeyEvent(param1View, param1KeyEvent))
            return true; 
        }  
      return false;
    }
    
    private void g() {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Ljava/util/WeakHashMap;
      //   4: astore_2
      //   5: aload_2
      //   6: ifnull -> 13
      //   9: aload_2
      //   10: invokevirtual clear : ()V
      //   13: getstatic androidx/core/view/y$v.d : Ljava/util/ArrayList;
      //   16: astore_3
      //   17: aload_3
      //   18: invokevirtual isEmpty : ()Z
      //   21: ifeq -> 25
      //   24: return
      //   25: aload_3
      //   26: monitorenter
      //   27: aload_0
      //   28: getfield a : Ljava/util/WeakHashMap;
      //   31: ifnonnull -> 45
      //   34: aload_0
      //   35: new java/util/WeakHashMap
      //   38: dup
      //   39: invokespecial <init> : ()V
      //   42: putfield a : Ljava/util/WeakHashMap;
      //   45: aload_3
      //   46: invokevirtual size : ()I
      //   49: iconst_1
      //   50: isub
      //   51: istore_1
      //   52: iload_1
      //   53: iflt -> 141
      //   56: getstatic androidx/core/view/y$v.d : Ljava/util/ArrayList;
      //   59: astore_2
      //   60: aload_2
      //   61: iload_1
      //   62: invokevirtual get : (I)Ljava/lang/Object;
      //   65: checkcast java/lang/ref/WeakReference
      //   68: invokevirtual get : ()Ljava/lang/Object;
      //   71: checkcast android/view/View
      //   74: astore #4
      //   76: aload #4
      //   78: ifnonnull -> 90
      //   81: aload_2
      //   82: iload_1
      //   83: invokevirtual remove : (I)Ljava/lang/Object;
      //   86: pop
      //   87: goto -> 155
      //   90: aload_0
      //   91: getfield a : Ljava/util/WeakHashMap;
      //   94: aload #4
      //   96: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   99: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   102: pop
      //   103: aload #4
      //   105: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   108: astore_2
      //   109: aload_2
      //   110: instanceof android/view/View
      //   113: ifeq -> 155
      //   116: aload_0
      //   117: getfield a : Ljava/util/WeakHashMap;
      //   120: aload_2
      //   121: checkcast android/view/View
      //   124: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   127: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   130: pop
      //   131: aload_2
      //   132: invokeinterface getParent : ()Landroid/view/ViewParent;
      //   137: astore_2
      //   138: goto -> 109
      //   141: aload_3
      //   142: monitorexit
      //   143: return
      //   144: astore_2
      //   145: aload_3
      //   146: monitorexit
      //   147: goto -> 152
      //   150: aload_2
      //   151: athrow
      //   152: goto -> 150
      //   155: iload_1
      //   156: iconst_1
      //   157: isub
      //   158: istore_1
      //   159: goto -> 52
      // Exception table:
      //   from	to	target	type
      //   27	45	144	finally
      //   45	52	144	finally
      //   56	76	144	finally
      //   81	87	144	finally
      //   90	109	144	finally
      //   109	138	144	finally
      //   141	143	144	finally
      //   145	147	144	finally
    }
    
    boolean b(View param1View, KeyEvent param1KeyEvent) {
      if (param1KeyEvent.getAction() == 0)
        g(); 
      param1View = c(param1View, param1KeyEvent);
      if (param1KeyEvent.getAction() == 0) {
        int i = param1KeyEvent.getKeyCode();
        if (param1View != null && !KeyEvent.isModifierKey(i))
          d().put(i, new WeakReference<View>(param1View)); 
      } 
      return (param1View != null);
    }
    
    boolean f(KeyEvent param1KeyEvent) {
      WeakReference<KeyEvent> weakReference1 = this.c;
      if (weakReference1 != null && weakReference1.get() == param1KeyEvent)
        return false; 
      this.c = new WeakReference<KeyEvent>(param1KeyEvent);
      WeakReference<KeyEvent> weakReference2 = null;
      SparseArray<WeakReference<View>> sparseArray = d();
      weakReference1 = weakReference2;
      if (param1KeyEvent.getAction() == 1) {
        int i = sparseArray.indexOfKey(param1KeyEvent.getKeyCode());
        weakReference1 = weakReference2;
        if (i >= 0) {
          weakReference1 = (WeakReference<KeyEvent>)sparseArray.valueAt(i);
          sparseArray.removeAt(i);
        } 
      } 
      weakReference2 = weakReference1;
      if (weakReference1 == null)
        weakReference2 = (WeakReference<KeyEvent>)sparseArray.get(param1KeyEvent.getKeyCode()); 
      if (weakReference2 != null) {
        View view = (View)weakReference2.get();
        if (view != null && y.U(view))
          e(view, param1KeyEvent); 
        return true;
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */