package androidx.core.view;

import android.graphics.Rect;
import android.view.Gravity;

public final class e {
  public static void a(int paramInt1, int paramInt2, int paramInt3, Rect paramRect1, Rect paramRect2, int paramInt4) {
    a.b(paramInt1, paramInt2, paramInt3, paramRect1, paramRect2, paramInt4);
  }
  
  public static int b(int paramInt1, int paramInt2) {
    return Gravity.getAbsoluteGravity(paramInt1, paramInt2);
  }
  
  static class a {
    static void a(int param1Int1, int param1Int2, int param1Int3, Rect param1Rect1, int param1Int4, int param1Int5, Rect param1Rect2, int param1Int6) {
      Gravity.apply(param1Int1, param1Int2, param1Int3, param1Rect1, param1Int4, param1Int5, param1Rect2, param1Int6);
    }
    
    static void b(int param1Int1, int param1Int2, int param1Int3, Rect param1Rect1, Rect param1Rect2, int param1Int4) {
      Gravity.apply(param1Int1, param1Int2, param1Int3, param1Rect1, param1Rect2, param1Int4);
    }
    
    static void c(int param1Int1, Rect param1Rect1, Rect param1Rect2, int param1Int2) {
      Gravity.applyDisplay(param1Int1, param1Rect1, param1Rect2, param1Int2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */