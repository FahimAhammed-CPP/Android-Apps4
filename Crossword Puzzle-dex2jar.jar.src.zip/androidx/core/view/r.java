package androidx.core.view;

import android.view.View;
import android.view.ViewGroup;

public class r {
  private int a;
  
  private int b;
  
  public r(ViewGroup paramViewGroup) {}
  
  public int a() {
    return this.a | this.b;
  }
  
  public void b(View paramView1, View paramView2, int paramInt) {
    c(paramView1, paramView2, paramInt, 0);
  }
  
  public void c(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramInt2 == 1) {
      this.b = paramInt1;
      return;
    } 
    this.a = paramInt1;
  }
  
  public void d(View paramView, int paramInt) {
    if (paramInt == 1) {
      this.b = 0;
      return;
    } 
    this.a = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */