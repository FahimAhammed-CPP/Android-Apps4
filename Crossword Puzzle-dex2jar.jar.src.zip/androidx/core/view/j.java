package androidx.core.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.MenuItem;
import x.b;

public final class j {
  public static MenuItem a(MenuItem paramMenuItem, b paramb) {
    if (paramMenuItem instanceof b)
      return (MenuItem)((b)paramMenuItem).a(paramb); 
    Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
    return paramMenuItem;
  }
  
  public static void b(MenuItem paramMenuItem, char paramChar, int paramInt) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setAlphabeticShortcut(paramChar, paramInt);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      a.g(paramMenuItem, paramChar, paramInt); 
  }
  
  public static void c(MenuItem paramMenuItem, CharSequence paramCharSequence) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setContentDescription(paramCharSequence);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      a.h(paramMenuItem, paramCharSequence); 
  }
  
  public static void d(MenuItem paramMenuItem, ColorStateList paramColorStateList) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setIconTintList(paramColorStateList);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      a.i(paramMenuItem, paramColorStateList); 
  }
  
  public static void e(MenuItem paramMenuItem, PorterDuff.Mode paramMode) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setIconTintMode(paramMode);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      a.j(paramMenuItem, paramMode); 
  }
  
  public static void f(MenuItem paramMenuItem, char paramChar, int paramInt) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setNumericShortcut(paramChar, paramInt);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      a.k(paramMenuItem, paramChar, paramInt); 
  }
  
  public static void g(MenuItem paramMenuItem, CharSequence paramCharSequence) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setTooltipText(paramCharSequence);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      a.m(paramMenuItem, paramCharSequence); 
  }
  
  static class a {
    static int a(MenuItem param1MenuItem) {
      return param1MenuItem.getAlphabeticModifiers();
    }
    
    static CharSequence b(MenuItem param1MenuItem) {
      return param1MenuItem.getContentDescription();
    }
    
    static ColorStateList c(MenuItem param1MenuItem) {
      return param1MenuItem.getIconTintList();
    }
    
    static PorterDuff.Mode d(MenuItem param1MenuItem) {
      return param1MenuItem.getIconTintMode();
    }
    
    static int e(MenuItem param1MenuItem) {
      return param1MenuItem.getNumericModifiers();
    }
    
    static CharSequence f(MenuItem param1MenuItem) {
      return param1MenuItem.getTooltipText();
    }
    
    static MenuItem g(MenuItem param1MenuItem, char param1Char, int param1Int) {
      return param1MenuItem.setAlphabeticShortcut(param1Char, param1Int);
    }
    
    static MenuItem h(MenuItem param1MenuItem, CharSequence param1CharSequence) {
      return param1MenuItem.setContentDescription(param1CharSequence);
    }
    
    static MenuItem i(MenuItem param1MenuItem, ColorStateList param1ColorStateList) {
      return param1MenuItem.setIconTintList(param1ColorStateList);
    }
    
    static MenuItem j(MenuItem param1MenuItem, PorterDuff.Mode param1Mode) {
      return param1MenuItem.setIconTintMode(param1Mode);
    }
    
    static MenuItem k(MenuItem param1MenuItem, char param1Char, int param1Int) {
      return param1MenuItem.setNumericShortcut(param1Char, param1Int);
    }
    
    static MenuItem l(MenuItem param1MenuItem, char param1Char1, char param1Char2, int param1Int1, int param1Int2) {
      return param1MenuItem.setShortcut(param1Char1, param1Char2, param1Int1, param1Int2);
    }
    
    static MenuItem m(MenuItem param1MenuItem, CharSequence param1CharSequence) {
      return param1MenuItem.setTooltipText(param1CharSequence);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\view\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */