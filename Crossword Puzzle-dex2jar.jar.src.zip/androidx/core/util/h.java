package androidx.core.util;

import java.util.Locale;
import java.util.Objects;

public final class h {
  public static void a(boolean paramBoolean, Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(String.valueOf(paramObject));
  }
  
  public static int b(int paramInt1, int paramInt2, int paramInt3, String paramString) {
    if (paramInt1 >= paramInt2) {
      if (paramInt1 <= paramInt3)
        return paramInt1; 
      throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%d, %d] (too high)", new Object[] { paramString, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) }));
    } 
    throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%d, %d] (too low)", new Object[] { paramString, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) }));
  }
  
  public static int c(int paramInt) {
    if (paramInt >= 0)
      return paramInt; 
    throw new IllegalArgumentException();
  }
  
  public static int d(int paramInt, String paramString) {
    if (paramInt >= 0)
      return paramInt; 
    throw new IllegalArgumentException(paramString);
  }
  
  public static int e(int paramInt1, int paramInt2) {
    if ((paramInt1 & paramInt2) == paramInt1)
      return paramInt1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Requested flags 0x");
    stringBuilder.append(Integer.toHexString(paramInt1));
    stringBuilder.append(", but only 0x");
    stringBuilder.append(Integer.toHexString(paramInt2));
    stringBuilder.append(" are allowed");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static <T> T f(T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  public static <T> T g(T paramT, Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(String.valueOf(paramObject));
  }
  
  public static void h(boolean paramBoolean, String paramString) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\cor\\util\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */