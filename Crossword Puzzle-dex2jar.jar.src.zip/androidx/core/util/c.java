package androidx.core.util;

import java.util.Objects;

public class c {
  public static boolean a(Object paramObject1, Object paramObject2) {
    return a.a(paramObject1, paramObject2);
  }
  
  public static int b(Object... paramVarArgs) {
    return a.b(paramVarArgs);
  }
  
  public static <T> T c(T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  public static <T> T d(T paramT, String paramString) {
    Objects.requireNonNull(paramT, paramString);
    return paramT;
  }
  
  public static String e(Object paramObject, String paramString) {
    if (paramObject != null)
      paramString = paramObject.toString(); 
    return paramString;
  }
  
  static class a {
    static boolean a(Object param1Object1, Object param1Object2) {
      return Objects.equals(param1Object1, param1Object2);
    }
    
    static int b(Object... param1VarArgs) {
      return Objects.hash(param1VarArgs);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\cor\\util\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */