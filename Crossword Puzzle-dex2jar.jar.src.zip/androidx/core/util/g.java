package androidx.core.util;

public class g<T> extends f<T> {
  private final Object c = new Object();
  
  public g(int paramInt) {
    super(paramInt);
  }
  
  public boolean a(T paramT) {
    synchronized (this.c) {
      return super.a(paramT);
    } 
  }
  
  public T b() {
    synchronized (this.c) {
      return super.b();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\cor\\util\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */