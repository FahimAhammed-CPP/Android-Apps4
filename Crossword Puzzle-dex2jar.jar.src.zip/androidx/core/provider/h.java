package androidx.core.provider;

import android.os.Handler;
import android.os.Process;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

class h {
  static ThreadPoolExecutor a(String paramString, int paramInt1, int paramInt2) {
    a a = new a(paramString, paramInt1);
    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, paramInt2, TimeUnit.MILLISECONDS, new LinkedBlockingDeque<Runnable>(), a);
    threadPoolExecutor.allowCoreThreadTimeOut(true);
    return threadPoolExecutor;
  }
  
  static <T> void b(Executor paramExecutor, Callable<T> paramCallable, androidx.core.util.a<T> parama) {
    paramExecutor.execute(new b<T>(b.a(), paramCallable, parama));
  }
  
  static <T> T c(ExecutorService paramExecutorService, Callable<T> paramCallable, int paramInt) {
    Future<T> future = paramExecutorService.submit(paramCallable);
    long l = paramInt;
    try {
      return future.get(l, TimeUnit.MILLISECONDS);
    } catch (ExecutionException executionException) {
      throw new RuntimeException(executionException);
    } catch (InterruptedException interruptedException) {
      throw interruptedException;
    } catch (TimeoutException timeoutException) {
      throw new InterruptedException("timeout");
    } 
  }
  
  private static class a implements ThreadFactory {
    private String a;
    
    private int b;
    
    a(String param1String, int param1Int) {
      this.a = param1String;
      this.b = param1Int;
    }
    
    public Thread newThread(Runnable param1Runnable) {
      return new a(param1Runnable, this.a, this.b);
    }
    
    private static class a extends Thread {
      private final int o;
      
      a(Runnable param2Runnable, String param2String, int param2Int) {
        super(param2Runnable, param2String);
        this.o = param2Int;
      }
      
      public void run() {
        Process.setThreadPriority(this.o);
        super.run();
      }
    }
  }
  
  private static class a extends Thread {
    private final int o;
    
    a(Runnable param1Runnable, String param1String, int param1Int) {
      super(param1Runnable, param1String);
      this.o = param1Int;
    }
    
    public void run() {
      Process.setThreadPriority(this.o);
      super.run();
    }
  }
  
  private static class b<T> implements Runnable {
    private Callable<T> o;
    
    private androidx.core.util.a<T> p;
    
    private Handler q;
    
    b(Handler param1Handler, Callable<T> param1Callable, androidx.core.util.a<T> param1a) {
      this.o = param1Callable;
      this.p = param1a;
      this.q = param1Handler;
    }
    
    public void run() {
      try {
        T t = this.o.call();
      } catch (Exception exception) {
        exception = null;
      } 
      androidx.core.util.a<T> a1 = this.p;
      this.q.post(new a(this, a1, exception));
    }
    
    class a implements Runnable {
      a(h.b this$0, androidx.core.util.a param2a, Object param2Object) {}
      
      public void run() {
        this.o.a(this.p);
      }
    }
  }
  
  class a implements Runnable {
    a(h this$0, androidx.core.util.a param1a, Object param1Object) {}
    
    public void run() {
      this.o.a(this.p);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\provider\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */