package androidx.core.provider;

import android.util.Base64;
import androidx.core.util.h;
import java.util.List;

public final class e {
  private final String a;
  
  private final String b;
  
  private final String c;
  
  private final List<List<byte[]>> d;
  
  private final int e;
  
  private final String f;
  
  public e(String paramString1, String paramString2, String paramString3, List<List<byte[]>> paramList) {
    this.a = (String)h.f(paramString1);
    this.b = (String)h.f(paramString2);
    this.c = (String)h.f(paramString3);
    this.d = (List<List<byte[]>>)h.f(paramList);
    this.e = 0;
    this.f = a(paramString1, paramString2, paramString3);
  }
  
  private String a(String paramString1, String paramString2, String paramString3) {
    StringBuilder stringBuilder = new StringBuilder(paramString1);
    stringBuilder.append("-");
    stringBuilder.append(paramString2);
    stringBuilder.append("-");
    stringBuilder.append(paramString3);
    return stringBuilder.toString();
  }
  
  public List<List<byte[]>> b() {
    return this.d;
  }
  
  public int c() {
    return this.e;
  }
  
  String d() {
    return this.f;
  }
  
  public String e() {
    return this.a;
  }
  
  public String f() {
    return this.b;
  }
  
  public String g() {
    return this.c;
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("FontRequest {mProviderAuthority: ");
    stringBuilder2.append(this.a);
    stringBuilder2.append(", mProviderPackage: ");
    stringBuilder2.append(this.b);
    stringBuilder2.append(", mQuery: ");
    stringBuilder2.append(this.c);
    stringBuilder2.append(", mCertificates:");
    stringBuilder1.append(stringBuilder2.toString());
    for (int i = 0; i < this.d.size(); i++) {
      stringBuilder1.append(" [");
      List<byte[]> list = this.d.get(i);
      for (int j = 0; j < list.size(); j++) {
        stringBuilder1.append(" \"");
        stringBuilder1.append(Base64.encodeToString(list.get(j), 0));
        stringBuilder1.append("\"");
      } 
      stringBuilder1.append(" ]");
    } 
    stringBuilder1.append("}");
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("mCertificatesArray: ");
    stringBuilder2.append(this.e);
    stringBuilder1.append(stringBuilder2.toString());
    return stringBuilder1.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\provider\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */