package androidx.core.text;

public interface c {
  boolean a(CharSequence paramCharSequence, int paramInt1, int paramInt2);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\text\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */