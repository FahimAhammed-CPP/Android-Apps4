package androidx.core.text;

import android.text.SpannableStringBuilder;
import java.util.Locale;

public final class a {
  static final c d;
  
  private static final String e = Character.toString('‎');
  
  private static final String f = Character.toString('‏');
  
  static final a g;
  
  static final a h;
  
  private final boolean a;
  
  private final int b;
  
  private final c c;
  
  static {
    g = new a(false, 2, c1);
    h = new a(true, 2, c1);
  }
  
  a(boolean paramBoolean, int paramInt, c paramc) {
    this.a = paramBoolean;
    this.b = paramInt;
    this.c = paramc;
  }
  
  private static int a(CharSequence paramCharSequence) {
    return (new b(paramCharSequence, false)).d();
  }
  
  private static int b(CharSequence paramCharSequence) {
    return (new b(paramCharSequence, false)).e();
  }
  
  public static a c() {
    return (new a()).a();
  }
  
  static boolean e(Locale paramLocale) {
    return (e.a(paramLocale) == 1);
  }
  
  private String f(CharSequence paramCharSequence, c paramc) {
    boolean bool = paramc.a(paramCharSequence, 0, paramCharSequence.length());
    return (!this.a && (bool || b(paramCharSequence) == 1)) ? e : ((this.a && (!bool || b(paramCharSequence) == -1)) ? f : "");
  }
  
  private String g(CharSequence paramCharSequence, c paramc) {
    boolean bool = paramc.a(paramCharSequence, 0, paramCharSequence.length());
    return (!this.a && (bool || a(paramCharSequence) == 1)) ? e : ((this.a && (!bool || a(paramCharSequence) == -1)) ? f : "");
  }
  
  public boolean d() {
    return ((this.b & 0x2) != 0);
  }
  
  public CharSequence h(CharSequence paramCharSequence) {
    return i(paramCharSequence, this.c, true);
  }
  
  public CharSequence i(CharSequence paramCharSequence, c paramc, boolean paramBoolean) {
    if (paramCharSequence == null)
      return null; 
    boolean bool = paramc.a(paramCharSequence, 0, paramCharSequence.length());
    SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
    if (d() && paramBoolean) {
      if (bool) {
        paramc = d.b;
      } else {
        paramc = d.a;
      } 
      spannableStringBuilder.append(g(paramCharSequence, paramc));
    } 
    if (bool != this.a) {
      char c1;
      if (bool) {
        c1 = '‫';
      } else {
        c1 = '‪';
      } 
      spannableStringBuilder.append(c1);
      spannableStringBuilder.append(paramCharSequence);
      spannableStringBuilder.append('‬');
    } else {
      spannableStringBuilder.append(paramCharSequence);
    } 
    if (paramBoolean) {
      if (bool) {
        paramc = d.b;
      } else {
        paramc = d.a;
      } 
      spannableStringBuilder.append(f(paramCharSequence, paramc));
    } 
    return (CharSequence)spannableStringBuilder;
  }
  
  public String j(String paramString) {
    return k(paramString, this.c, true);
  }
  
  public String k(String paramString, c paramc, boolean paramBoolean) {
    return (paramString == null) ? null : i(paramString, paramc, paramBoolean).toString();
  }
  
  static {
    c c1 = d.c;
    d = c1;
  }
  
  public static final class a {
    private boolean a;
    
    private int b;
    
    private c c;
    
    public a() {
      c(a.e(Locale.getDefault()));
    }
    
    private static a b(boolean param1Boolean) {
      return param1Boolean ? a.h : a.g;
    }
    
    private void c(boolean param1Boolean) {
      this.a = param1Boolean;
      this.c = a.d;
      this.b = 2;
    }
    
    public a a() {
      return (this.b == 2 && this.c == a.d) ? b(this.a) : new a(this.a, this.b, this.c);
    }
  }
  
  private static class b {
    private static final byte[] f = new byte[1792];
    
    private final CharSequence a;
    
    private final boolean b;
    
    private final int c;
    
    private int d;
    
    private char e;
    
    static {
      for (int i = 0; i < 1792; i++)
        f[i] = Character.getDirectionality(i); 
    }
    
    b(CharSequence param1CharSequence, boolean param1Boolean) {
      this.a = param1CharSequence;
      this.b = param1Boolean;
      this.c = param1CharSequence.length();
    }
    
    private static byte c(char param1Char) {
      return (param1Char < '܀') ? f[param1Char] : Character.getDirectionality(param1Char);
    }
    
    private byte f() {
      int i = this.d;
      while (true) {
        int j = this.d;
        if (j > 0) {
          CharSequence charSequence = this.a;
          this.d = --j;
          char c = charSequence.charAt(j);
          this.e = c;
          if (c == '&')
            return 12; 
          if (c == ';')
            break; 
          continue;
        } 
        break;
      } 
      this.d = i;
      this.e = ';';
      return 13;
    }
    
    private byte g() {
      while (true) {
        int i = this.d;
        if (i < this.c) {
          CharSequence charSequence = this.a;
          this.d = i + 1;
          char c = charSequence.charAt(i);
          this.e = c;
          if (c != ';')
            continue; 
        } 
        break;
      } 
      return 12;
    }
    
    private byte h() {
      int i = this.d;
      label20: while (true) {
        int j = this.d;
        if (j > 0) {
          CharSequence charSequence = this.a;
          this.d = --j;
          char c = charSequence.charAt(j);
          this.e = c;
          if (c == '<')
            return 12; 
          if (c == '>')
            break; 
          if (c == '"' || c == '\'')
            while (true) {
              j = this.d;
              if (j > 0) {
                charSequence = this.a;
                this.d = --j;
                char c1 = charSequence.charAt(j);
                this.e = c1;
                if (c1 != c)
                  continue; 
                continue label20;
              } 
              continue label20;
            }  
          continue;
        } 
        break;
      } 
      this.d = i;
      this.e = '>';
      return 13;
    }
    
    private byte i() {
      int i = this.d;
      label18: while (true) {
        int j = this.d;
        if (j < this.c) {
          CharSequence charSequence = this.a;
          this.d = j + 1;
          char c = charSequence.charAt(j);
          this.e = c;
          if (c == '>')
            return 12; 
          if (c == '"' || c == '\'') {
            while (true) {
              j = this.d;
              if (j < this.c) {
                charSequence = this.a;
                this.d = j + 1;
                char c1 = charSequence.charAt(j);
                this.e = c1;
                if (c1 != c)
                  continue; 
                continue label18;
              } 
              continue label18;
            } 
            break;
          } 
          continue;
        } 
        this.d = i;
        this.e = '<';
        return 13;
      } 
    }
    
    byte a() {
      char c = this.a.charAt(this.d - 1);
      this.e = c;
      if (Character.isLowSurrogate(c)) {
        int i = Character.codePointBefore(this.a, this.d);
        this.d -= Character.charCount(i);
        return Character.getDirectionality(i);
      } 
      this.d--;
      byte b2 = c(this.e);
      byte b1 = b2;
      if (this.b) {
        char c1 = this.e;
        if (c1 == '>')
          return h(); 
        b1 = b2;
        if (c1 == ';')
          b1 = f(); 
      } 
      return b1;
    }
    
    byte b() {
      char c = this.a.charAt(this.d);
      this.e = c;
      if (Character.isHighSurrogate(c)) {
        int i = Character.codePointAt(this.a, this.d);
        this.d += Character.charCount(i);
        return Character.getDirectionality(i);
      } 
      this.d++;
      byte b2 = c(this.e);
      byte b1 = b2;
      if (this.b) {
        char c1 = this.e;
        if (c1 == '<')
          return i(); 
        b1 = b2;
        if (c1 == '&')
          b1 = g(); 
      } 
      return b1;
    }
    
    int d() {
      this.d = 0;
      int j = 0;
      byte b1 = 0;
      int i = 0;
      while (this.d < this.c && !j) {
        byte b2 = b();
        if (b2 != 0) {
          if (b2 != 1 && b2 != 2) {
            if (b2 != 9) {
              switch (b2) {
                case 18:
                  i--;
                  b1 = 0;
                  continue;
                case 16:
                case 17:
                  i++;
                  b1 = 1;
                  continue;
                case 14:
                case 15:
                  i++;
                  b1 = -1;
                  continue;
              } 
            } else {
              continue;
            } 
          } else if (i == 0) {
            return 1;
          } 
        } else if (i == 0) {
          return -1;
        } 
        j = i;
      } 
      if (j == 0)
        return 0; 
      if (b1 != 0)
        return b1; 
      while (this.d > 0) {
        switch (a()) {
          default:
            continue;
          case 18:
            i++;
            continue;
          case 16:
          case 17:
            if (j == i)
              return 1; 
            break;
          case 14:
          case 15:
            if (j == i)
              return -1; 
            break;
        } 
        i--;
      } 
      return 0;
    }
    
    int e() {
      this.d = this.c;
      int i = 0;
      for (int j = 0; this.d > 0; j = i) {
        byte b1 = a();
        if (b1 != 0) {
          if (b1 != 1 && b1 != 2) {
            if (b1 != 9) {
              switch (b1) {
                default:
                  if (!j)
                    break; 
                  continue;
                case 18:
                  i++;
                  continue;
                case 16:
                case 17:
                  if (j == i)
                    return 1; 
                  i--;
                  continue;
                case 14:
                case 15:
                  if (j == i)
                    return -1; 
                  i--;
                  continue;
              } 
            } else {
              continue;
            } 
            continue;
          } 
          if (i == 0)
            return 1; 
          if (j == 0)
            continue; 
          continue;
        } 
        if (i == 0)
          return -1; 
        if (j == 0)
          continue; 
        continue;
      } 
      return 0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\text\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */