package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityRecord;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.core.view.accessibility.f;
import androidx.core.view.m;
import androidx.core.view.n;
import androidx.core.view.p;
import androidx.core.view.r;
import androidx.core.view.y;

public class NestedScrollView extends FrameLayout implements p, m {
  private static final a O = new a();
  
  private static final int[] P = new int[] { 16843130 };
  
  private boolean A = true;
  
  private int B;
  
  private int C;
  
  private int D;
  
  private int E = -1;
  
  private final int[] F = new int[2];
  
  private final int[] G = new int[2];
  
  private int H;
  
  private int I;
  
  private d J;
  
  private final r K;
  
  private final n L;
  
  private float M;
  
  private c N;
  
  private long o;
  
  private final Rect p = new Rect();
  
  private OverScroller q;
  
  public EdgeEffect r;
  
  public EdgeEffect s;
  
  private int t;
  
  private boolean u = true;
  
  private boolean v = false;
  
  private View w = null;
  
  private boolean x = false;
  
  private VelocityTracker y;
  
  private boolean z;
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, w.a.c);
  }
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    this.r = e.a(paramContext, paramAttributeSet);
    this.s = e.a(paramContext, paramAttributeSet);
    y();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, P, paramInt, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.K = new r((ViewGroup)this);
    this.L = new n((View)this);
    setNestedScrollingEnabled(true);
    y.r0((View)this, O);
  }
  
  private boolean A(View paramView) {
    return C(paramView, 0, getHeight()) ^ true;
  }
  
  private static boolean B(View paramView1, View paramView2) {
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    return (viewParent instanceof ViewGroup && B((View)viewParent, paramView2));
  }
  
  private boolean C(View paramView, int paramInt1, int paramInt2) {
    paramView.getDrawingRect(this.p);
    offsetDescendantRectToMyCoords(paramView, this.p);
    return (this.p.bottom + paramInt1 >= getScrollY() && this.p.top - paramInt1 <= getScrollY() + paramInt2);
  }
  
  private void D(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    int i = getScrollY();
    scrollBy(0, paramInt1);
    i = getScrollY() - i;
    if (paramArrayOfint != null)
      paramArrayOfint[1] = paramArrayOfint[1] + i; 
    this.L.e(0, i, 0, paramInt1 - i, null, paramInt2, paramArrayOfint);
  }
  
  private void E(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.E) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.t = (int)paramMotionEvent.getY(i);
      this.E = paramMotionEvent.getPointerId(i);
      VelocityTracker velocityTracker = this.y;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  private void H() {
    VelocityTracker velocityTracker = this.y;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.y = null;
    } 
  }
  
  private int I(int paramInt, float paramFloat) {
    float f1 = paramFloat / getWidth();
    float f2 = paramInt / getHeight();
    float f3 = e.b(this.r);
    paramFloat = 0.0F;
    if (f3 != 0.0F) {
      f1 = -e.d(this.r, -f2, f1);
      paramFloat = f1;
      if (e.b(this.r) == 0.0F) {
        this.r.onRelease();
        paramFloat = f1;
      } 
    } else if (e.b(this.s) != 0.0F) {
      f1 = e.d(this.s, f2, 1.0F - f1);
      paramFloat = f1;
      if (e.b(this.s) == 0.0F) {
        this.s.onRelease();
        paramFloat = f1;
      } 
    } 
    paramInt = Math.round(paramFloat * getHeight());
    if (paramInt != 0)
      invalidate(); 
    return paramInt;
  }
  
  private void J(boolean paramBoolean) {
    if (paramBoolean) {
      R(2, 1);
    } else {
      T(1);
    } 
    this.I = getScrollY();
    y.i0((View)this);
  }
  
  private boolean K(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool1;
    NestedScrollView nestedScrollView;
    int j = getHeight();
    int i = getScrollY();
    j += i;
    boolean bool2 = false;
    if (paramInt1 == 33) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    View view2 = s(bool1, paramInt2, paramInt3);
    View view1 = view2;
    if (view2 == null)
      nestedScrollView = this; 
    if (paramInt2 >= i && paramInt3 <= j) {
      bool1 = bool2;
    } else {
      if (bool1) {
        paramInt2 -= i;
      } else {
        paramInt2 = paramInt3 - j;
      } 
      l(paramInt2);
      bool1 = true;
    } 
    if (nestedScrollView != findFocus())
      nestedScrollView.requestFocus(paramInt1); 
    return bool1;
  }
  
  private void L(View paramView) {
    paramView.getDrawingRect(this.p);
    offsetDescendantRectToMyCoords(paramView, this.p);
    int i = f(this.p);
    if (i != 0)
      scrollBy(0, i); 
  }
  
  private boolean M(Rect paramRect, boolean paramBoolean) {
    boolean bool;
    int i = f(paramRect);
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean) {
        scrollBy(0, i);
        return bool;
      } 
      N(0, i);
    } 
    return bool;
  }
  
  private void O(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.o > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i = view.getHeight();
      int j = layoutParams.topMargin;
      int k = layoutParams.bottomMargin;
      int i1 = getHeight();
      int i2 = getPaddingTop();
      int i3 = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt2 + paramInt1, Math.max(0, i + j + k - i1 - i2 - i3)));
      this.q.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1, paramInt3);
      J(paramBoolean);
    } else {
      if (!this.q.isFinished())
        a(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.o = AnimationUtils.currentAnimationTimeMillis();
  }
  
  private boolean S(MotionEvent paramMotionEvent) {
    boolean bool;
    if (e.b(this.r) != 0.0F) {
      e.d(this.r, 0.0F, paramMotionEvent.getX() / getWidth());
      bool = true;
    } else {
      bool = false;
    } 
    if (e.b(this.s) != 0.0F) {
      e.d(this.s, 0.0F, 1.0F - paramMotionEvent.getX() / getWidth());
      return true;
    } 
    return bool;
  }
  
  private void a() {
    this.q.abortAnimation();
    T(1);
  }
  
  private boolean c() {
    int i = getOverScrollMode();
    boolean bool = true;
    if (i != 0) {
      if (i == 1 && getScrollRange() > 0)
        return true; 
      bool = false;
    } 
    return bool;
  }
  
  private boolean d() {
    int i = getChildCount();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      bool1 = bool2;
      if (view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > getHeight() - getPaddingTop() - getPaddingBottom())
        bool1 = true; 
    } 
    return bool1;
  }
  
  private static int e(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.M == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.M = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.M;
  }
  
  private void l(int paramInt) {
    if (paramInt != 0) {
      if (this.A) {
        N(0, paramInt);
        return;
      } 
      scrollBy(0, paramInt);
    } 
  }
  
  private boolean p(int paramInt) {
    if (e.b(this.r) != 0.0F) {
      this.r.onAbsorb(paramInt);
    } else {
      if (e.b(this.s) != 0.0F) {
        this.s.onAbsorb(-paramInt);
        return true;
      } 
      return false;
    } 
    return true;
  }
  
  private void q() {
    this.x = false;
    H();
    T(0);
    this.r.onRelease();
    this.s.onRelease();
  }
  
  private View s(boolean paramBoolean, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_2
    //   2: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   5: astore #14
    //   7: aload #14
    //   9: invokeinterface size : ()I
    //   14: istore #9
    //   16: aconst_null
    //   17: astore #13
    //   19: iconst_0
    //   20: istore #6
    //   22: iconst_0
    //   23: istore #7
    //   25: iload #6
    //   27: iload #9
    //   29: if_icmpge -> 249
    //   32: aload #14
    //   34: iload #6
    //   36: invokeinterface get : (I)Ljava/lang/Object;
    //   41: checkcast android/view/View
    //   44: astore #12
    //   46: aload #12
    //   48: invokevirtual getTop : ()I
    //   51: istore #8
    //   53: aload #12
    //   55: invokevirtual getBottom : ()I
    //   58: istore #10
    //   60: aload #13
    //   62: astore #11
    //   64: iload #7
    //   66: istore #5
    //   68: iload_2
    //   69: iload #10
    //   71: if_icmpge -> 232
    //   74: aload #13
    //   76: astore #11
    //   78: iload #7
    //   80: istore #5
    //   82: iload #8
    //   84: iload_3
    //   85: if_icmpge -> 232
    //   88: iload_2
    //   89: iload #8
    //   91: if_icmpge -> 106
    //   94: iload #10
    //   96: iload_3
    //   97: if_icmpge -> 106
    //   100: iconst_1
    //   101: istore #4
    //   103: goto -> 109
    //   106: iconst_0
    //   107: istore #4
    //   109: aload #13
    //   111: ifnonnull -> 125
    //   114: aload #12
    //   116: astore #11
    //   118: iload #4
    //   120: istore #5
    //   122: goto -> 232
    //   125: iload_1
    //   126: ifeq -> 139
    //   129: iload #8
    //   131: aload #13
    //   133: invokevirtual getTop : ()I
    //   136: if_icmplt -> 153
    //   139: iload_1
    //   140: ifne -> 159
    //   143: iload #10
    //   145: aload #13
    //   147: invokevirtual getBottom : ()I
    //   150: if_icmple -> 159
    //   153: iconst_1
    //   154: istore #8
    //   156: goto -> 162
    //   159: iconst_0
    //   160: istore #8
    //   162: iload #7
    //   164: ifeq -> 196
    //   167: aload #13
    //   169: astore #11
    //   171: iload #7
    //   173: istore #5
    //   175: iload #4
    //   177: ifeq -> 232
    //   180: aload #13
    //   182: astore #11
    //   184: iload #7
    //   186: istore #5
    //   188: iload #8
    //   190: ifeq -> 232
    //   193: goto -> 224
    //   196: iload #4
    //   198: ifeq -> 211
    //   201: aload #12
    //   203: astore #11
    //   205: iconst_1
    //   206: istore #5
    //   208: goto -> 232
    //   211: aload #13
    //   213: astore #11
    //   215: iload #7
    //   217: istore #5
    //   219: iload #8
    //   221: ifeq -> 232
    //   224: aload #12
    //   226: astore #11
    //   228: iload #7
    //   230: istore #5
    //   232: iload #6
    //   234: iconst_1
    //   235: iadd
    //   236: istore #6
    //   238: aload #11
    //   240: astore #13
    //   242: iload #5
    //   244: istore #7
    //   246: goto -> 25
    //   249: aload #13
    //   251: areturn
  }
  
  private boolean w(int paramInt1, int paramInt2) {
    int i = getChildCount();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      i = getScrollY();
      View view = getChildAt(0);
      bool1 = bool2;
      if (paramInt2 >= view.getTop() - i) {
        bool1 = bool2;
        if (paramInt2 < view.getBottom() - i) {
          bool1 = bool2;
          if (paramInt1 >= view.getLeft()) {
            bool1 = bool2;
            if (paramInt1 < view.getRight())
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  private void x() {
    VelocityTracker velocityTracker = this.y;
    if (velocityTracker == null) {
      this.y = VelocityTracker.obtain();
      return;
    } 
    velocityTracker.clear();
  }
  
  private void y() {
    this.q = new OverScroller(getContext());
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.B = viewConfiguration.getScaledTouchSlop();
    this.C = viewConfiguration.getScaledMinimumFlingVelocity();
    this.D = viewConfiguration.getScaledMaximumFlingVelocity();
  }
  
  private void z() {
    if (this.y == null)
      this.y = VelocityTracker.obtain(); 
  }
  
  boolean F(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getOverScrollMode : ()I
    //   4: istore #12
    //   6: aload_0
    //   7: invokevirtual computeHorizontalScrollRange : ()I
    //   10: istore #10
    //   12: aload_0
    //   13: invokevirtual computeHorizontalScrollExtent : ()I
    //   16: istore #11
    //   18: iconst_0
    //   19: istore #14
    //   21: iload #10
    //   23: iload #11
    //   25: if_icmple -> 34
    //   28: iconst_1
    //   29: istore #10
    //   31: goto -> 37
    //   34: iconst_0
    //   35: istore #10
    //   37: aload_0
    //   38: invokevirtual computeVerticalScrollRange : ()I
    //   41: aload_0
    //   42: invokevirtual computeVerticalScrollExtent : ()I
    //   45: if_icmple -> 54
    //   48: iconst_1
    //   49: istore #11
    //   51: goto -> 57
    //   54: iconst_0
    //   55: istore #11
    //   57: iload #12
    //   59: ifeq -> 82
    //   62: iload #12
    //   64: iconst_1
    //   65: if_icmpne -> 76
    //   68: iload #10
    //   70: ifeq -> 76
    //   73: goto -> 82
    //   76: iconst_0
    //   77: istore #10
    //   79: goto -> 85
    //   82: iconst_1
    //   83: istore #10
    //   85: iload #12
    //   87: ifeq -> 110
    //   90: iload #12
    //   92: iconst_1
    //   93: if_icmpne -> 104
    //   96: iload #11
    //   98: ifeq -> 104
    //   101: goto -> 110
    //   104: iconst_0
    //   105: istore #11
    //   107: goto -> 113
    //   110: iconst_1
    //   111: istore #11
    //   113: iload_3
    //   114: iload_1
    //   115: iadd
    //   116: istore_3
    //   117: iload #10
    //   119: ifne -> 127
    //   122: iconst_0
    //   123: istore_1
    //   124: goto -> 130
    //   127: iload #7
    //   129: istore_1
    //   130: iload #4
    //   132: iload_2
    //   133: iadd
    //   134: istore #4
    //   136: iload #11
    //   138: ifne -> 146
    //   141: iconst_0
    //   142: istore_2
    //   143: goto -> 149
    //   146: iload #8
    //   148: istore_2
    //   149: iload_1
    //   150: ineg
    //   151: istore #7
    //   153: iload_1
    //   154: iload #5
    //   156: iadd
    //   157: istore_1
    //   158: iload_2
    //   159: ineg
    //   160: istore #5
    //   162: iload_2
    //   163: iload #6
    //   165: iadd
    //   166: istore #6
    //   168: iload_3
    //   169: iload_1
    //   170: if_icmple -> 181
    //   173: iconst_1
    //   174: istore #9
    //   176: iload_1
    //   177: istore_2
    //   178: goto -> 198
    //   181: iload_3
    //   182: iload #7
    //   184: if_icmpge -> 193
    //   187: iload #7
    //   189: istore_1
    //   190: goto -> 173
    //   193: iconst_0
    //   194: istore #9
    //   196: iload_3
    //   197: istore_2
    //   198: iload #4
    //   200: iload #6
    //   202: if_icmple -> 214
    //   205: iload #6
    //   207: istore_1
    //   208: iconst_1
    //   209: istore #13
    //   211: goto -> 233
    //   214: iload #4
    //   216: iload #5
    //   218: if_icmpge -> 227
    //   221: iload #5
    //   223: istore_1
    //   224: goto -> 208
    //   227: iconst_0
    //   228: istore #13
    //   230: iload #4
    //   232: istore_1
    //   233: iload #13
    //   235: ifeq -> 263
    //   238: aload_0
    //   239: iconst_1
    //   240: invokevirtual v : (I)Z
    //   243: ifne -> 263
    //   246: aload_0
    //   247: getfield q : Landroid/widget/OverScroller;
    //   250: iload_2
    //   251: iload_1
    //   252: iconst_0
    //   253: iconst_0
    //   254: iconst_0
    //   255: aload_0
    //   256: invokevirtual getScrollRange : ()I
    //   259: invokevirtual springBack : (IIIIII)Z
    //   262: pop
    //   263: aload_0
    //   264: iload_2
    //   265: iload_1
    //   266: iload #9
    //   268: iload #13
    //   270: invokevirtual onOverScrolled : (IIZZ)V
    //   273: iload #9
    //   275: ifne -> 287
    //   278: iload #14
    //   280: istore #9
    //   282: iload #13
    //   284: ifeq -> 290
    //   287: iconst_1
    //   288: istore #9
    //   290: iload #9
    //   292: ireturn
  }
  
  public boolean G(int paramInt) {
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int j = getHeight();
    if (i) {
      this.p.top = getScrollY() + j;
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        i = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.p;
        if (rect1.top + j > i)
          rect1.top = i - j; 
      } 
    } else {
      this.p.top = getScrollY() - j;
      Rect rect1 = this.p;
      if (rect1.top < 0)
        rect1.top = 0; 
    } 
    Rect rect = this.p;
    int i = rect.top;
    j += i;
    rect.bottom = j;
    return K(paramInt, i, j);
  }
  
  public final void N(int paramInt1, int paramInt2) {
    O(paramInt1, paramInt2, 250, false);
  }
  
  void P(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    O(paramInt1 - getScrollX(), paramInt2 - getScrollY(), paramInt3, paramBoolean);
  }
  
  void Q(int paramInt1, int paramInt2, boolean paramBoolean) {
    P(paramInt1, paramInt2, 250, paramBoolean);
  }
  
  public boolean R(int paramInt1, int paramInt2) {
    return this.L.p(paramInt1, paramInt2);
  }
  
  public void T(int paramInt) {
    this.L.r(paramInt);
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public boolean b(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int i = getMaxScrollAmount();
    if (view2 != null && C(view2, i, getHeight())) {
      view2.getDrawingRect(this.p);
      offsetDescendantRectToMyCoords(view2, this.p);
      l(f(this.p));
      view2.requestFocus(paramInt);
    } else {
      int j;
      if (paramInt == 33 && getScrollY() < i) {
        j = getScrollY();
      } else {
        j = i;
        if (paramInt == 130) {
          j = i;
          if (getChildCount() > 0) {
            view2 = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view2.getLayoutParams();
            j = Math.min(view2.getBottom() + layoutParams.bottomMargin - getScrollY() + getHeight() - getPaddingBottom(), i);
          } 
        } 
      } 
      if (j == 0)
        return false; 
      if (paramInt != 130)
        j = -j; 
      l(j);
    } 
    if (view1 != null && view1.isFocused() && A(view1)) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Landroid/widget/OverScroller;
    //   4: invokevirtual isFinished : ()Z
    //   7: ifeq -> 11
    //   10: return
    //   11: aload_0
    //   12: getfield q : Landroid/widget/OverScroller;
    //   15: invokevirtual computeScrollOffset : ()Z
    //   18: pop
    //   19: aload_0
    //   20: getfield q : Landroid/widget/OverScroller;
    //   23: invokevirtual getCurrY : ()I
    //   26: istore_2
    //   27: iload_2
    //   28: aload_0
    //   29: getfield I : I
    //   32: isub
    //   33: istore_1
    //   34: aload_0
    //   35: iload_2
    //   36: putfield I : I
    //   39: aload_0
    //   40: getfield G : [I
    //   43: astore #6
    //   45: iconst_0
    //   46: istore_3
    //   47: aload #6
    //   49: iconst_1
    //   50: iconst_0
    //   51: iastore
    //   52: aload_0
    //   53: iconst_0
    //   54: iload_1
    //   55: aload #6
    //   57: aconst_null
    //   58: iconst_1
    //   59: invokevirtual g : (II[I[II)Z
    //   62: pop
    //   63: iload_1
    //   64: aload_0
    //   65: getfield G : [I
    //   68: iconst_1
    //   69: iaload
    //   70: isub
    //   71: istore_2
    //   72: aload_0
    //   73: invokevirtual getScrollRange : ()I
    //   76: istore #4
    //   78: iload_2
    //   79: istore_1
    //   80: iload_2
    //   81: ifeq -> 153
    //   84: aload_0
    //   85: invokevirtual getScrollY : ()I
    //   88: istore_1
    //   89: aload_0
    //   90: iconst_0
    //   91: iload_2
    //   92: aload_0
    //   93: invokevirtual getScrollX : ()I
    //   96: iload_1
    //   97: iconst_0
    //   98: iload #4
    //   100: iconst_0
    //   101: iconst_0
    //   102: iconst_0
    //   103: invokevirtual F : (IIIIIIIIZ)Z
    //   106: pop
    //   107: aload_0
    //   108: invokevirtual getScrollY : ()I
    //   111: iload_1
    //   112: isub
    //   113: istore_1
    //   114: iload_2
    //   115: iload_1
    //   116: isub
    //   117: istore_2
    //   118: aload_0
    //   119: getfield G : [I
    //   122: astore #6
    //   124: aload #6
    //   126: iconst_1
    //   127: iconst_0
    //   128: iastore
    //   129: aload_0
    //   130: iconst_0
    //   131: iload_1
    //   132: iconst_0
    //   133: iload_2
    //   134: aload_0
    //   135: getfield F : [I
    //   138: iconst_1
    //   139: aload #6
    //   141: invokevirtual k : (IIII[II[I)V
    //   144: iload_2
    //   145: aload_0
    //   146: getfield G : [I
    //   149: iconst_1
    //   150: iaload
    //   151: isub
    //   152: istore_1
    //   153: iload_1
    //   154: ifeq -> 250
    //   157: aload_0
    //   158: invokevirtual getOverScrollMode : ()I
    //   161: istore #5
    //   163: iload #5
    //   165: ifeq -> 183
    //   168: iload_3
    //   169: istore_2
    //   170: iload #5
    //   172: iconst_1
    //   173: if_icmpne -> 185
    //   176: iload_3
    //   177: istore_2
    //   178: iload #4
    //   180: ifle -> 185
    //   183: iconst_1
    //   184: istore_2
    //   185: iload_2
    //   186: ifeq -> 246
    //   189: iload_1
    //   190: ifge -> 221
    //   193: aload_0
    //   194: getfield r : Landroid/widget/EdgeEffect;
    //   197: invokevirtual isFinished : ()Z
    //   200: ifeq -> 246
    //   203: aload_0
    //   204: getfield r : Landroid/widget/EdgeEffect;
    //   207: aload_0
    //   208: getfield q : Landroid/widget/OverScroller;
    //   211: invokevirtual getCurrVelocity : ()F
    //   214: f2i
    //   215: invokevirtual onAbsorb : (I)V
    //   218: goto -> 246
    //   221: aload_0
    //   222: getfield s : Landroid/widget/EdgeEffect;
    //   225: invokevirtual isFinished : ()Z
    //   228: ifeq -> 246
    //   231: aload_0
    //   232: getfield s : Landroid/widget/EdgeEffect;
    //   235: aload_0
    //   236: getfield q : Landroid/widget/OverScroller;
    //   239: invokevirtual getCurrVelocity : ()F
    //   242: f2i
    //   243: invokevirtual onAbsorb : (I)V
    //   246: aload_0
    //   247: invokespecial a : ()V
    //   250: aload_0
    //   251: getfield q : Landroid/widget/OverScroller;
    //   254: invokevirtual isFinished : ()Z
    //   257: ifne -> 265
    //   260: aload_0
    //   261: invokestatic i0 : (Landroid/view/View;)V
    //   264: return
    //   265: aload_0
    //   266: iconst_1
    //   267: invokevirtual T : (I)V
    //   270: return
  }
  
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public int computeVerticalScrollRange() {
    int j = getChildCount();
    int i = getHeight() - getPaddingBottom() - getPaddingTop();
    if (j == 0)
      return i; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    j = view.getBottom() + layoutParams.bottomMargin;
    int k = getScrollY();
    int i1 = Math.max(0, j - i);
    if (k < 0)
      return j - k; 
    i = j;
    if (k > i1)
      i = j + k - i1; 
    return i;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || r(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.L.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.L.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return g(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.L.f(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   5: aload_0
    //   6: invokevirtual getScrollY : ()I
    //   9: istore #9
    //   11: aload_0
    //   12: getfield r : Landroid/widget/EdgeEffect;
    //   15: invokevirtual isFinished : ()Z
    //   18: istore #12
    //   20: iconst_0
    //   21: istore #6
    //   23: iload #12
    //   25: ifne -> 192
    //   28: aload_1
    //   29: invokevirtual save : ()I
    //   32: istore #10
    //   34: aload_0
    //   35: invokevirtual getWidth : ()I
    //   38: istore_2
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: istore #8
    //   45: iconst_0
    //   46: iload #9
    //   48: invokestatic min : (II)I
    //   51: istore #7
    //   53: getstatic android/os/Build$VERSION.SDK_INT : I
    //   56: istore #11
    //   58: iload #11
    //   60: bipush #21
    //   62: if_icmplt -> 80
    //   65: aload_0
    //   66: invokestatic a : (Landroid/view/ViewGroup;)Z
    //   69: ifeq -> 75
    //   72: goto -> 80
    //   75: iconst_0
    //   76: istore_3
    //   77: goto -> 99
    //   80: iload_2
    //   81: aload_0
    //   82: invokevirtual getPaddingLeft : ()I
    //   85: aload_0
    //   86: invokevirtual getPaddingRight : ()I
    //   89: iadd
    //   90: isub
    //   91: istore_2
    //   92: aload_0
    //   93: invokevirtual getPaddingLeft : ()I
    //   96: iconst_0
    //   97: iadd
    //   98: istore_3
    //   99: iload #8
    //   101: istore #5
    //   103: iload #7
    //   105: istore #4
    //   107: iload #11
    //   109: bipush #21
    //   111: if_icmplt -> 152
    //   114: iload #8
    //   116: istore #5
    //   118: iload #7
    //   120: istore #4
    //   122: aload_0
    //   123: invokestatic a : (Landroid/view/ViewGroup;)Z
    //   126: ifeq -> 152
    //   129: iload #8
    //   131: aload_0
    //   132: invokevirtual getPaddingTop : ()I
    //   135: aload_0
    //   136: invokevirtual getPaddingBottom : ()I
    //   139: iadd
    //   140: isub
    //   141: istore #5
    //   143: iload #7
    //   145: aload_0
    //   146: invokevirtual getPaddingTop : ()I
    //   149: iadd
    //   150: istore #4
    //   152: aload_1
    //   153: iload_3
    //   154: i2f
    //   155: iload #4
    //   157: i2f
    //   158: invokevirtual translate : (FF)V
    //   161: aload_0
    //   162: getfield r : Landroid/widget/EdgeEffect;
    //   165: iload_2
    //   166: iload #5
    //   168: invokevirtual setSize : (II)V
    //   171: aload_0
    //   172: getfield r : Landroid/widget/EdgeEffect;
    //   175: aload_1
    //   176: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   179: ifeq -> 186
    //   182: aload_0
    //   183: invokestatic i0 : (Landroid/view/View;)V
    //   186: aload_1
    //   187: iload #10
    //   189: invokevirtual restoreToCount : (I)V
    //   192: aload_0
    //   193: getfield s : Landroid/widget/EdgeEffect;
    //   196: invokevirtual isFinished : ()Z
    //   199: ifne -> 384
    //   202: aload_1
    //   203: invokevirtual save : ()I
    //   206: istore #10
    //   208: aload_0
    //   209: invokevirtual getWidth : ()I
    //   212: istore #4
    //   214: aload_0
    //   215: invokevirtual getHeight : ()I
    //   218: istore #7
    //   220: aload_0
    //   221: invokevirtual getScrollRange : ()I
    //   224: iload #9
    //   226: invokestatic max : (II)I
    //   229: iload #7
    //   231: iadd
    //   232: istore #8
    //   234: getstatic android/os/Build$VERSION.SDK_INT : I
    //   237: istore #9
    //   239: iload #9
    //   241: bipush #21
    //   243: if_icmplt -> 259
    //   246: iload #6
    //   248: istore_3
    //   249: iload #4
    //   251: istore_2
    //   252: aload_0
    //   253: invokestatic a : (Landroid/view/ViewGroup;)Z
    //   256: ifeq -> 279
    //   259: iload #4
    //   261: aload_0
    //   262: invokevirtual getPaddingLeft : ()I
    //   265: aload_0
    //   266: invokevirtual getPaddingRight : ()I
    //   269: iadd
    //   270: isub
    //   271: istore_2
    //   272: iconst_0
    //   273: aload_0
    //   274: invokevirtual getPaddingLeft : ()I
    //   277: iadd
    //   278: istore_3
    //   279: iload #8
    //   281: istore #5
    //   283: iload #7
    //   285: istore #4
    //   287: iload #9
    //   289: bipush #21
    //   291: if_icmplt -> 332
    //   294: iload #8
    //   296: istore #5
    //   298: iload #7
    //   300: istore #4
    //   302: aload_0
    //   303: invokestatic a : (Landroid/view/ViewGroup;)Z
    //   306: ifeq -> 332
    //   309: iload #7
    //   311: aload_0
    //   312: invokevirtual getPaddingTop : ()I
    //   315: aload_0
    //   316: invokevirtual getPaddingBottom : ()I
    //   319: iadd
    //   320: isub
    //   321: istore #4
    //   323: iload #8
    //   325: aload_0
    //   326: invokevirtual getPaddingBottom : ()I
    //   329: isub
    //   330: istore #5
    //   332: aload_1
    //   333: iload_3
    //   334: iload_2
    //   335: isub
    //   336: i2f
    //   337: iload #5
    //   339: i2f
    //   340: invokevirtual translate : (FF)V
    //   343: aload_1
    //   344: ldc_w 180.0
    //   347: iload_2
    //   348: i2f
    //   349: fconst_0
    //   350: invokevirtual rotate : (FFF)V
    //   353: aload_0
    //   354: getfield s : Landroid/widget/EdgeEffect;
    //   357: iload_2
    //   358: iload #4
    //   360: invokevirtual setSize : (II)V
    //   363: aload_0
    //   364: getfield s : Landroid/widget/EdgeEffect;
    //   367: aload_1
    //   368: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   371: ifeq -> 378
    //   374: aload_0
    //   375: invokestatic i0 : (Landroid/view/View;)V
    //   378: aload_1
    //   379: iload #10
    //   381: invokevirtual restoreToCount : (I)V
    //   384: return
  }
  
  protected int f(Rect paramRect) {
    int i = getChildCount();
    boolean bool = false;
    if (i == 0)
      return 0; 
    int i1 = getHeight();
    int j = getScrollY();
    int k = j + i1;
    int i2 = getVerticalFadingEdgeLength();
    i = j;
    if (paramRect.top > 0)
      i = j + i2; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
      j = k - i2;
    } else {
      j = k;
    } 
    i2 = paramRect.bottom;
    if (i2 > j && paramRect.top > i) {
      if (paramRect.height() > i1) {
        i = paramRect.top - i;
      } else {
        i = paramRect.bottom - j;
      } 
      return Math.min(i + 0, view.getBottom() + layoutParams.bottomMargin - k);
    } 
    k = bool;
    if (paramRect.top < i) {
      k = bool;
      if (i2 < j) {
        if (paramRect.height() > i1) {
          i = 0 - j - paramRect.bottom;
        } else {
          i = 0 - i - paramRect.top;
        } 
        k = Math.max(i, -getScrollY());
      } 
    } 
    return k;
  }
  
  public boolean g(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.L.d(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  protected float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int i = getVerticalFadingEdgeLength();
    int j = getHeight();
    int k = getPaddingBottom();
    j = view.getBottom() + layoutParams.bottomMargin - getScrollY() - j - k;
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    return this.K.a();
  }
  
  int getScrollRange() {
    int j = getChildCount();
    int i = 0;
    if (j > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      i = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return i;
  }
  
  protected float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int i = getVerticalFadingEdgeLength();
    int j = getScrollY();
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.K.c(paramView1, paramView2, paramInt1, paramInt2);
    R(2, paramInt2);
  }
  
  public boolean hasNestedScrollingParent() {
    return v(0);
  }
  
  public void i(View paramView, int paramInt) {
    this.K.d(paramView, paramInt);
    T(paramInt);
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.L.l();
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    g(paramInt1, paramInt2, paramArrayOfint, null, paramInt3);
  }
  
  public void k(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint1, int paramInt5, int[] paramArrayOfint2) {
    this.L.e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint1, paramInt5, paramArrayOfint2);
  }
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    D(paramInt4, paramInt5, paramArrayOfint);
  }
  
  protected void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  protected void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    D(paramInt4, paramInt5, null);
  }
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return ((paramInt1 & 0x2) != 0);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.v = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getAction : ()I
    //   4: istore #4
    //   6: iconst_0
    //   7: istore_3
    //   8: iconst_0
    //   9: istore #6
    //   11: iconst_0
    //   12: istore #8
    //   14: iload #4
    //   16: bipush #8
    //   18: if_icmpne -> 283
    //   21: aload_0
    //   22: getfield x : Z
    //   25: ifne -> 283
    //   28: aload_1
    //   29: iconst_2
    //   30: invokestatic a : (Landroid/view/MotionEvent;I)Z
    //   33: ifeq -> 46
    //   36: aload_1
    //   37: bipush #9
    //   39: invokevirtual getAxisValue : (I)F
    //   42: fstore_2
    //   43: goto -> 68
    //   46: aload_1
    //   47: ldc_w 4194304
    //   50: invokestatic a : (Landroid/view/MotionEvent;I)Z
    //   53: ifeq -> 66
    //   56: aload_1
    //   57: bipush #26
    //   59: invokevirtual getAxisValue : (I)F
    //   62: fstore_2
    //   63: goto -> 68
    //   66: fconst_0
    //   67: fstore_2
    //   68: fload_2
    //   69: fconst_0
    //   70: fcmpl
    //   71: ifeq -> 283
    //   74: fload_2
    //   75: aload_0
    //   76: invokespecial getVerticalScrollFactorCompat : ()F
    //   79: fmul
    //   80: f2i
    //   81: istore #5
    //   83: aload_0
    //   84: invokevirtual getScrollRange : ()I
    //   87: istore #4
    //   89: aload_0
    //   90: invokevirtual getScrollY : ()I
    //   93: istore #7
    //   95: iload #7
    //   97: iload #5
    //   99: isub
    //   100: istore #5
    //   102: iload #5
    //   104: ifge -> 179
    //   107: aload_0
    //   108: invokespecial c : ()Z
    //   111: ifeq -> 130
    //   114: aload_1
    //   115: sipush #8194
    //   118: invokestatic a : (Landroid/view/MotionEvent;I)Z
    //   121: ifne -> 130
    //   124: iconst_1
    //   125: istore #4
    //   127: goto -> 133
    //   130: iconst_0
    //   131: istore #4
    //   133: iload #4
    //   135: ifeq -> 260
    //   138: aload_0
    //   139: getfield r : Landroid/widget/EdgeEffect;
    //   142: iload #5
    //   144: i2f
    //   145: fneg
    //   146: aload_0
    //   147: invokevirtual getHeight : ()I
    //   150: i2f
    //   151: fdiv
    //   152: ldc_w 0.5
    //   155: invokestatic d : (Landroid/widget/EdgeEffect;FF)F
    //   158: pop
    //   159: aload_0
    //   160: getfield r : Landroid/widget/EdgeEffect;
    //   163: invokevirtual onRelease : ()V
    //   166: aload_0
    //   167: invokevirtual invalidate : ()V
    //   170: iconst_1
    //   171: istore #8
    //   173: iload #6
    //   175: istore_3
    //   176: goto -> 263
    //   179: iload #5
    //   181: iload #4
    //   183: if_icmple -> 257
    //   186: aload_0
    //   187: invokespecial c : ()Z
    //   190: ifeq -> 208
    //   193: aload_1
    //   194: sipush #8194
    //   197: invokestatic a : (Landroid/view/MotionEvent;I)Z
    //   200: ifne -> 208
    //   203: iconst_1
    //   204: istore_3
    //   205: goto -> 210
    //   208: iconst_0
    //   209: istore_3
    //   210: iload_3
    //   211: ifeq -> 251
    //   214: aload_0
    //   215: getfield s : Landroid/widget/EdgeEffect;
    //   218: iload #5
    //   220: iload #4
    //   222: isub
    //   223: i2f
    //   224: aload_0
    //   225: invokevirtual getHeight : ()I
    //   228: i2f
    //   229: fdiv
    //   230: ldc_w 0.5
    //   233: invokestatic d : (Landroid/widget/EdgeEffect;FF)F
    //   236: pop
    //   237: aload_0
    //   238: getfield s : Landroid/widget/EdgeEffect;
    //   241: invokevirtual onRelease : ()V
    //   244: aload_0
    //   245: invokevirtual invalidate : ()V
    //   248: iconst_1
    //   249: istore #8
    //   251: iload #4
    //   253: istore_3
    //   254: goto -> 263
    //   257: iload #5
    //   259: istore_3
    //   260: iconst_0
    //   261: istore #8
    //   263: iload_3
    //   264: iload #7
    //   266: if_icmpeq -> 280
    //   269: aload_0
    //   270: aload_0
    //   271: invokevirtual getScrollX : ()I
    //   274: iload_3
    //   275: invokespecial scrollTo : (II)V
    //   278: iconst_1
    //   279: ireturn
    //   280: iload #8
    //   282: ireturn
    //   283: iconst_0
    //   284: ireturn
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    ViewParent viewParent;
    int i = paramMotionEvent.getAction();
    boolean bool2 = true;
    boolean bool1 = true;
    if (i == 2 && this.x)
      return true; 
    i &= 0xFF;
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            if (i == 6)
              E(paramMotionEvent); 
            return this.x;
          } 
        } else {
          i = this.E;
          if (i != -1) {
            StringBuilder stringBuilder;
            int j = paramMotionEvent.findPointerIndex(i);
            if (j == -1) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("Invalid pointerId=");
              stringBuilder.append(i);
              stringBuilder.append(" in onInterceptTouchEvent");
              Log.e("NestedScrollView", stringBuilder.toString());
            } else {
              i = (int)stringBuilder.getY(j);
              if (Math.abs(i - this.t) > this.B && (0x2 & getNestedScrollAxes()) == 0) {
                this.x = true;
                this.t = i;
                z();
                this.y.addMovement((MotionEvent)stringBuilder);
                this.H = 0;
                viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
              } 
            } 
          } 
          return this.x;
        }  
      this.x = false;
      this.E = -1;
      H();
      if (this.q.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
        y.i0((View)this); 
      T(0);
    } else {
      i = (int)viewParent.getY();
      if (!w((int)viewParent.getX(), i)) {
        boolean bool = bool1;
        if (!S((MotionEvent)viewParent))
          if (!this.q.isFinished()) {
            bool = bool1;
          } else {
            bool = false;
          }  
        this.x = bool;
        H();
      } else {
        this.t = i;
        this.E = viewParent.getPointerId(0);
        x();
        this.y.addMovement((MotionEvent)viewParent);
        this.q.computeScrollOffset();
        boolean bool = bool2;
        if (!S((MotionEvent)viewParent))
          if (!this.q.isFinished()) {
            bool = bool2;
          } else {
            bool = false;
          }  
        this.x = bool;
        R(2, 0);
      } 
    } 
    return this.x;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = 0;
    this.u = false;
    View view = this.w;
    if (view != null && B(view, (View)this))
      L(this.w); 
    this.w = null;
    if (!this.v) {
      if (this.J != null) {
        scrollTo(getScrollX(), this.J.o);
        this.J = null;
      } 
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } 
      int i = getPaddingTop();
      int j = getPaddingBottom();
      paramInt3 = getScrollY();
      paramInt1 = e(paramInt3, paramInt4 - paramInt2 - i - j, paramInt1);
      if (paramInt1 != paramInt3)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.v = true;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.z)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      paramInt2 = view.getMeasuredHeight();
      int i = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (paramInt2 < i)
        view.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(i, 1073741824)); 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      dispatchNestedFling(0.0F, paramFloat2, true);
      t((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    j(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    D(paramInt4, 0, null);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    h(paramView1, paramView2, paramInt, 0);
  }
  
  protected void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int i;
    View view;
    if (paramInt == 2) {
      i = 130;
    } else {
      i = paramInt;
      if (paramInt == 1)
        i = 33; 
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, i);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, i);
    } 
    return (view == null) ? false : (A(view) ? false : view.requestFocus(i, paramRect));
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof d)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    d d1 = (d)paramParcelable;
    super.onRestoreInstanceState(d1.getSuperState());
    this.J = d1;
    requestLayout();
  }
  
  protected Parcelable onSaveInstanceState() {
    d d1 = new d(super.onSaveInstanceState());
    d1.o = getScrollY();
    return (Parcelable)d1;
  }
  
  protected void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    c c1 = this.N;
    if (c1 != null)
      c1.a(this, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null) {
      if (this == view)
        return; 
      if (C(view, 0, paramInt4)) {
        view.getDrawingRect(this.p);
        offsetDescendantRectToMyCoords(view, this.p);
        l(f(this.p));
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return o(paramView1, paramView2, paramInt, 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    i(paramView, 0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    z();
    int i = paramMotionEvent.getActionMasked();
    boolean bool = false;
    if (i == 0)
      this.H = 0; 
    MotionEvent motionEvent = MotionEvent.obtain(paramMotionEvent);
    motionEvent.offsetLocation(0.0F, this.H);
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5) {
              if (i == 6) {
                E(paramMotionEvent);
                this.t = (int)paramMotionEvent.getY(paramMotionEvent.findPointerIndex(this.E));
              } 
            } else {
              i = paramMotionEvent.getActionIndex();
              this.t = (int)paramMotionEvent.getY(i);
              this.E = paramMotionEvent.getPointerId(i);
            } 
          } else {
            if (this.x && getChildCount() > 0 && this.q.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
              y.i0((View)this); 
            this.E = -1;
            q();
          } 
        } else {
          StringBuilder stringBuilder;
          int j = paramMotionEvent.findPointerIndex(this.E);
          if (j == -1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid pointerId=");
            stringBuilder.append(this.E);
            stringBuilder.append(" in onTouchEvent");
            Log.e("NestedScrollView", stringBuilder.toString());
          } else {
            int i1 = (int)stringBuilder.getY(j);
            i = this.t - i1;
            int k = i - I(i, stringBuilder.getX(j));
            i = k;
            if (!this.x) {
              i = k;
              if (Math.abs(k) > this.B) {
                ViewParent viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
                this.x = true;
                if (k > 0) {
                  i = k - this.B;
                } else {
                  i = k + this.B;
                } 
              } 
            } 
            if (this.x) {
              k = i;
              if (g(0, i, this.G, this.F, 0)) {
                k = i - this.G[1];
                this.H += this.F[1];
              } 
              this.t = i1 - this.F[1];
              int i3 = getScrollY();
              int i2 = getScrollRange();
              i = getOverScrollMode();
              if (i == 0 || (i == 1 && i2 > 0)) {
                i1 = 1;
              } else {
                i1 = 0;
              } 
              if (F(0, k, 0, getScrollY(), 0, i2, 0, 0, true) && !v(0)) {
                i = 1;
              } else {
                i = 0;
              } 
              int i4 = getScrollY() - i3;
              int[] arrayOfInt = this.G;
              arrayOfInt[1] = 0;
              k(0, i4, 0, k - i4, this.F, 0, arrayOfInt);
              i4 = this.t;
              arrayOfInt = this.F;
              this.t = i4 - arrayOfInt[1];
              this.H += arrayOfInt[1];
              if (i1 != 0) {
                k -= this.G[1];
                i1 = i3 + k;
                if (i1 < 0) {
                  e.d(this.r, -k / getHeight(), stringBuilder.getX(j) / getWidth());
                  if (!this.s.isFinished())
                    this.s.onRelease(); 
                } else if (i1 > i2) {
                  e.d(this.s, k / getHeight(), 1.0F - stringBuilder.getX(j) / getWidth());
                  if (!this.r.isFinished())
                    this.r.onRelease(); 
                } 
                if (!this.r.isFinished() || !this.s.isFinished()) {
                  y.i0((View)this);
                  i = bool;
                } 
              } 
              if (i != 0)
                this.y.clear(); 
            } 
          } 
        } 
      } else {
        velocityTracker = this.y;
        velocityTracker.computeCurrentVelocity(1000, this.D);
        i = (int)velocityTracker.getYVelocity(this.E);
        if (Math.abs(i) >= this.C) {
          if (!p(i)) {
            i = -i;
            float f = i;
            if (!dispatchNestedPreFling(0.0F, f)) {
              dispatchNestedFling(0.0F, f, true);
              t(i);
            } 
          } 
        } else if (this.q.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
          y.i0((View)this);
        } 
        this.E = -1;
        q();
      } 
    } else {
      if (getChildCount() == 0)
        return false; 
      if (this.x) {
        ViewParent viewParent = getParent();
        if (viewParent != null)
          viewParent.requestDisallowInterceptTouchEvent(true); 
      } 
      if (!this.q.isFinished())
        a(); 
      this.t = (int)velocityTracker.getY();
      this.E = velocityTracker.getPointerId(0);
      R(2, 0);
    } 
    VelocityTracker velocityTracker = this.y;
    if (velocityTracker != null)
      velocityTracker.addMovement(motionEvent); 
    motionEvent.recycle();
    return true;
  }
  
  public boolean r(KeyEvent paramKeyEvent) {
    View view;
    this.p.setEmpty();
    boolean bool3 = d();
    boolean bool1 = false;
    boolean bool2 = false;
    char c1 = '';
    if (!bool3) {
      bool1 = bool2;
      if (isFocused()) {
        bool1 = bool2;
        if (paramKeyEvent.getKeyCode() != 4) {
          View view1 = findFocus();
          view = view1;
          if (view1 == this)
            view = null; 
          view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view, 130);
          bool1 = bool2;
          if (view != null) {
            bool1 = bool2;
            if (view != this) {
              bool1 = bool2;
              if (view.requestFocus(130))
                bool1 = true; 
            } 
          } 
        } 
      } 
      return bool1;
    } 
    if (view.getAction() == 0) {
      int i = view.getKeyCode();
      if (i != 19) {
        if (i != 20) {
          if (i != 62)
            return false; 
          if (view.isShiftPressed())
            c1 = '!'; 
          G(c1);
          return false;
        } 
        return !view.isAltPressed() ? b(130) : u(130);
      } 
      if (!view.isAltPressed())
        return b(33); 
      bool1 = u(33);
    } 
    return bool1;
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.u) {
      L(paramView2);
    } else {
      this.w = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    return M(paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      H(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.u = true;
    super.requestLayout();
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i4 = getWidth();
      int i5 = getPaddingLeft();
      int i6 = getPaddingRight();
      int i7 = view.getWidth();
      int i8 = layoutParams.leftMargin;
      int i9 = layoutParams.rightMargin;
      int i = getHeight();
      int j = getPaddingTop();
      int k = getPaddingBottom();
      int i1 = view.getHeight();
      int i2 = layoutParams.topMargin;
      int i3 = layoutParams.bottomMargin;
      paramInt1 = e(paramInt1, i4 - i5 - i6, i7 + i8 + i9);
      paramInt2 = e(paramInt2, i - j - k, i1 + i2 + i3);
      if (paramInt1 != getScrollX() || paramInt2 != getScrollY())
        super.scrollTo(paramInt1, paramInt2); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.z) {
      this.z = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.L.m(paramBoolean);
  }
  
  public void setOnScrollChangeListener(c paramc) {
    this.N = paramc;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.A = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public boolean startNestedScroll(int paramInt) {
    return R(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    T(0);
  }
  
  public void t(int paramInt) {
    if (getChildCount() > 0) {
      this.q.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      J(true);
    } 
  }
  
  public boolean u(int paramInt) {
    int i;
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int j = getHeight();
    Rect rect = this.p;
    rect.top = 0;
    rect.bottom = j;
    if (i) {
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        this.p.bottom = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.p;
        rect1.top = rect1.bottom - j;
      } 
    } 
    rect = this.p;
    return K(paramInt, rect.top, rect.bottom);
  }
  
  public boolean v(int paramInt) {
    return this.L.k(paramInt);
  }
  
  static class a extends androidx.core.view.a {
    public void f(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      super.f(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      f.a((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollX());
      f.b((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollRange());
    }
    
    public void g(View param1View, androidx.core.view.accessibility.d param1d) {
      super.g(param1View, param1d);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1d.W(ScrollView.class.getName());
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1d.p0(true);
          if (nestedScrollView.getScrollY() > 0) {
            param1d.b(androidx.core.view.accessibility.d.a.r);
            param1d.b(androidx.core.view.accessibility.d.a.C);
          } 
          if (nestedScrollView.getScrollY() < i) {
            param1d.b(androidx.core.view.accessibility.d.a.q);
            param1d.b(androidx.core.view.accessibility.d.a.E);
          } 
        } 
      } 
    }
    
    public boolean j(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.j(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      int j = nestedScrollView.getHeight();
      Rect rect = new Rect();
      int i = j;
      if (nestedScrollView.getMatrix().isIdentity()) {
        i = j;
        if (nestedScrollView.getGlobalVisibleRect(rect))
          i = rect.height(); 
      } 
      if (param1Int != 4096)
        if (param1Int != 8192 && param1Int != 16908344) {
          if (param1Int != 16908346)
            return false; 
        } else {
          param1Int = nestedScrollView.getPaddingBottom();
          j = nestedScrollView.getPaddingTop();
          param1Int = Math.max(nestedScrollView.getScrollY() - i - param1Int - j, 0);
          if (param1Int != nestedScrollView.getScrollY()) {
            nestedScrollView.Q(0, param1Int, true);
            return true;
          } 
          return false;
        }  
      param1Int = nestedScrollView.getPaddingBottom();
      j = nestedScrollView.getPaddingTop();
      param1Int = Math.min(nestedScrollView.getScrollY() + i - param1Int - j, nestedScrollView.getScrollRange());
      if (param1Int != nestedScrollView.getScrollY()) {
        nestedScrollView.Q(0, param1Int, true);
        return true;
      } 
      return false;
    }
  }
  
  static class b {
    static boolean a(ViewGroup param1ViewGroup) {
      return param1ViewGroup.getClipToPadding();
    }
  }
  
  public static interface c {
    void a(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
  }
  
  static class d extends View.BaseSavedState {
    public static final Parcelable.Creator<d> CREATOR = new a();
    
    public int o;
    
    d(Parcel param1Parcel) {
      super(param1Parcel);
      this.o = param1Parcel.readInt();
    }
    
    d(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("HorizontalScrollView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" scrollPosition=");
      stringBuilder.append(this.o);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.o);
    }
    
    class a implements Parcelable.Creator<d> {
      public NestedScrollView.d a(Parcel param2Parcel) {
        return new NestedScrollView.d(param2Parcel);
      }
      
      public NestedScrollView.d[] b(int param2Int) {
        return new NestedScrollView.d[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<d> {
    public NestedScrollView.d a(Parcel param1Parcel) {
      return new NestedScrollView.d(param1Parcel);
    }
    
    public NestedScrollView.d[] b(int param1Int) {
      return new NestedScrollView.d[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */