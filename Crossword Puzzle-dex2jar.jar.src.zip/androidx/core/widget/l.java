package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public interface l {
  void setSupportCheckMarkTintList(ColorStateList paramColorStateList);
  
  void setSupportCheckMarkTintMode(PorterDuff.Mode paramMode);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\widget\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */