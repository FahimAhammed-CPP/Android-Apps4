package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.ImageView;

public class f {
  public static ColorStateList a(ImageView paramImageView) {
    return (Build.VERSION.SDK_INT >= 21) ? a.a(paramImageView) : ((paramImageView instanceof o) ? ((o)paramImageView).getSupportImageTintList() : null);
  }
  
  public static PorterDuff.Mode b(ImageView paramImageView) {
    return (Build.VERSION.SDK_INT >= 21) ? a.b(paramImageView) : ((paramImageView instanceof o) ? ((o)paramImageView).getSupportImageTintMode() : null);
  }
  
  public static void c(ImageView paramImageView, ColorStateList paramColorStateList) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      a.c(paramImageView, paramColorStateList);
      if (i == 21) {
        drawable = paramImageView.getDrawable();
        if (drawable != null && a.a(paramImageView) != null) {
          if (drawable.isStateful())
            drawable.setState(paramImageView.getDrawableState()); 
          paramImageView.setImageDrawable(drawable);
          return;
        } 
      } 
    } else if (paramImageView instanceof o) {
      ((o)paramImageView).setSupportImageTintList((ColorStateList)drawable);
    } 
  }
  
  public static void d(ImageView paramImageView, PorterDuff.Mode paramMode) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      a.d(paramImageView, paramMode);
      if (i == 21) {
        drawable = paramImageView.getDrawable();
        if (drawable != null && a.a(paramImageView) != null) {
          if (drawable.isStateful())
            drawable.setState(paramImageView.getDrawableState()); 
          paramImageView.setImageDrawable(drawable);
          return;
        } 
      } 
    } else if (paramImageView instanceof o) {
      ((o)paramImageView).setSupportImageTintMode((PorterDuff.Mode)drawable);
    } 
  }
  
  static class a {
    static ColorStateList a(ImageView param1ImageView) {
      return param1ImageView.getImageTintList();
    }
    
    static PorterDuff.Mode b(ImageView param1ImageView) {
      return param1ImageView.getImageTintMode();
    }
    
    static void c(ImageView param1ImageView, ColorStateList param1ColorStateList) {
      param1ImageView.setImageTintList(param1ColorStateList);
    }
    
    static void d(ImageView param1ImageView, PorterDuff.Mode param1Mode) {
      param1ImageView.setImageTintMode(param1Mode);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */