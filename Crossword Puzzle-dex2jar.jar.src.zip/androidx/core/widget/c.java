package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.CheckedTextView;

public final class c {
  public static Drawable a(CheckedTextView paramCheckedTextView) {
    return a.a(paramCheckedTextView);
  }
  
  public static void b(CheckedTextView paramCheckedTextView, ColorStateList paramColorStateList) {
    if (Build.VERSION.SDK_INT >= 21) {
      b.a(paramCheckedTextView, paramColorStateList);
      return;
    } 
    if (paramCheckedTextView instanceof l)
      ((l)paramCheckedTextView).setSupportCheckMarkTintList(paramColorStateList); 
  }
  
  public static void c(CheckedTextView paramCheckedTextView, PorterDuff.Mode paramMode) {
    if (Build.VERSION.SDK_INT >= 21) {
      b.b(paramCheckedTextView, paramMode);
      return;
    } 
    if (paramCheckedTextView instanceof l)
      ((l)paramCheckedTextView).setSupportCheckMarkTintMode(paramMode); 
  }
  
  private static class a {
    static Drawable a(CheckedTextView param1CheckedTextView) {
      return param1CheckedTextView.getCheckMarkDrawable();
    }
  }
  
  private static class b {
    static void a(CheckedTextView param1CheckedTextView, ColorStateList param1ColorStateList) {
      param1CheckedTextView.setCheckMarkTintList(param1ColorStateList);
    }
    
    static void b(CheckedTextView param1CheckedTextView, PorterDuff.Mode param1Mode) {
      param1CheckedTextView.setCheckMarkTintMode(param1Mode);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */