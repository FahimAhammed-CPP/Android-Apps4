package androidx.core.widget;

import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.PopupWindow;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class i {
  private static Method a;
  
  private static boolean b;
  
  private static Field c;
  
  private static boolean d;
  
  public static void a(PopupWindow paramPopupWindow, boolean paramBoolean) {
    int j = Build.VERSION.SDK_INT;
    if (j >= 23) {
      b.c(paramPopupWindow, paramBoolean);
      return;
    } 
    if (j >= 21) {
      if (!d) {
        try {
          Field field1 = PopupWindow.class.getDeclaredField("mOverlapAnchor");
          c = field1;
          field1.setAccessible(true);
        } catch (NoSuchFieldException noSuchFieldException) {
          Log.i("PopupWindowCompatApi21", "Could not fetch mOverlapAnchor field from PopupWindow", noSuchFieldException);
        } 
        d = true;
      } 
      Field field = c;
      if (field != null)
        try {
          field.set(paramPopupWindow, Boolean.valueOf(paramBoolean));
          return;
        } catch (IllegalAccessException illegalAccessException) {
          Log.i("PopupWindowCompatApi21", "Could not set overlap anchor field in PopupWindow", illegalAccessException);
        }  
    } 
  }
  
  public static void b(PopupWindow paramPopupWindow, int paramInt) {
    if (Build.VERSION.SDK_INT >= 23) {
      b.d(paramPopupWindow, paramInt);
      return;
    } 
    if (!b) {
      try {
        Method method1 = PopupWindow.class.getDeclaredMethod("setWindowLayoutType", new Class[] { int.class });
        a = method1;
        method1.setAccessible(true);
      } catch (Exception exception) {}
      b = true;
    } 
    Method method = a;
    if (method != null)
      try {
        method.invoke(paramPopupWindow, new Object[] { Integer.valueOf(paramInt) });
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public static void c(PopupWindow paramPopupWindow, View paramView, int paramInt1, int paramInt2, int paramInt3) {
    a.a(paramPopupWindow, paramView, paramInt1, paramInt2, paramInt3);
  }
  
  static class a {
    static void a(PopupWindow param1PopupWindow, View param1View, int param1Int1, int param1Int2, int param1Int3) {
      param1PopupWindow.showAsDropDown(param1View, param1Int1, param1Int2, param1Int3);
    }
  }
  
  static class b {
    static boolean a(PopupWindow param1PopupWindow) {
      return param1PopupWindow.getOverlapAnchor();
    }
    
    static int b(PopupWindow param1PopupWindow) {
      return param1PopupWindow.getWindowLayoutType();
    }
    
    static void c(PopupWindow param1PopupWindow, boolean param1Boolean) {
      param1PopupWindow.setOverlapAnchor(param1Boolean);
    }
    
    static void d(PopupWindow param1PopupWindow, int param1Int) {
      param1PopupWindow.setWindowLayoutType(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */