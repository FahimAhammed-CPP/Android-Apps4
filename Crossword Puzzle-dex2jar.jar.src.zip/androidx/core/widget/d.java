package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.widget.CompoundButton;
import java.lang.reflect.Field;

public final class d {
  private static Field a;
  
  private static boolean b;
  
  public static Drawable a(CompoundButton paramCompoundButton) {
    if (Build.VERSION.SDK_INT >= 23)
      return b.a(paramCompoundButton); 
    if (!b) {
      try {
        Field field1 = CompoundButton.class.getDeclaredField("mButtonDrawable");
        a = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.i("CompoundButtonCompat", "Failed to retrieve mButtonDrawable field", noSuchFieldException);
      } 
      b = true;
    } 
    Field field = a;
    if (field != null)
      try {
        return (Drawable)field.get(paramCompoundButton);
      } catch (IllegalAccessException illegalAccessException) {
        Log.i("CompoundButtonCompat", "Failed to get button drawable via reflection", illegalAccessException);
        a = null;
      }  
    return null;
  }
  
  public static ColorStateList b(CompoundButton paramCompoundButton) {
    return (Build.VERSION.SDK_INT >= 21) ? a.a(paramCompoundButton) : ((paramCompoundButton instanceof m) ? ((m)paramCompoundButton).getSupportButtonTintList() : null);
  }
  
  public static PorterDuff.Mode c(CompoundButton paramCompoundButton) {
    return (Build.VERSION.SDK_INT >= 21) ? a.b(paramCompoundButton) : ((paramCompoundButton instanceof m) ? ((m)paramCompoundButton).getSupportButtonTintMode() : null);
  }
  
  public static void d(CompoundButton paramCompoundButton, ColorStateList paramColorStateList) {
    if (Build.VERSION.SDK_INT >= 21) {
      a.c(paramCompoundButton, paramColorStateList);
      return;
    } 
    if (paramCompoundButton instanceof m)
      ((m)paramCompoundButton).setSupportButtonTintList(paramColorStateList); 
  }
  
  public static void e(CompoundButton paramCompoundButton, PorterDuff.Mode paramMode) {
    if (Build.VERSION.SDK_INT >= 21) {
      a.d(paramCompoundButton, paramMode);
      return;
    } 
    if (paramCompoundButton instanceof m)
      ((m)paramCompoundButton).setSupportButtonTintMode(paramMode); 
  }
  
  static class a {
    static ColorStateList a(CompoundButton param1CompoundButton) {
      return param1CompoundButton.getButtonTintList();
    }
    
    static PorterDuff.Mode b(CompoundButton param1CompoundButton) {
      return param1CompoundButton.getButtonTintMode();
    }
    
    static void c(CompoundButton param1CompoundButton, ColorStateList param1ColorStateList) {
      param1CompoundButton.setButtonTintList(param1ColorStateList);
    }
    
    static void d(CompoundButton param1CompoundButton, PorterDuff.Mode param1Mode) {
      param1CompoundButton.setButtonTintMode(param1Mode);
    }
  }
  
  static class b {
    static Drawable a(CompoundButton param1CompoundButton) {
      return param1CompoundButton.getButtonDrawable();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */