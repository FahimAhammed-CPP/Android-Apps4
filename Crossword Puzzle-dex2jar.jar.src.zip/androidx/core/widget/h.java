package androidx.core.widget;

import android.widget.ListView;

public final class h {
  public static void a(ListView paramListView, int paramInt) {
    a.b(paramListView, paramInt);
  }
  
  static class a {
    static boolean a(ListView param1ListView, int param1Int) {
      return param1ListView.canScrollList(param1Int);
    }
    
    static void b(ListView param1ListView, int param1Int) {
      param1ListView.scrollListBy(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\core\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */