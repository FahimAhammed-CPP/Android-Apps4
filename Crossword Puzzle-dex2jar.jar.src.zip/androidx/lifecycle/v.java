package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

public class v implements m {
  private static final v w = new v();
  
  private int o = 0;
  
  private int p = 0;
  
  private boolean q = true;
  
  private boolean r = true;
  
  private Handler s;
  
  private final n t = new n(this);
  
  private Runnable u = new a(this);
  
  w.a v = new b(this);
  
  public static m k() {
    return w;
  }
  
  static void l(Context paramContext) {
    w.h(paramContext);
  }
  
  public i a() {
    return this.t;
  }
  
  void b() {
    int i = this.p - 1;
    this.p = i;
    if (i == 0)
      this.s.postDelayed(this.u, 700L); 
  }
  
  void e() {
    int i = this.p + 1;
    this.p = i;
    if (i == 1) {
      if (this.q) {
        this.t.h(i.b.ON_RESUME);
        this.q = false;
        return;
      } 
      this.s.removeCallbacks(this.u);
    } 
  }
  
  void f() {
    int i = this.o + 1;
    this.o = i;
    if (i == 1 && this.r) {
      this.t.h(i.b.ON_START);
      this.r = false;
    } 
  }
  
  void g() {
    this.o--;
    j();
  }
  
  void h(Context paramContext) {
    this.s = new Handler();
    this.t.h(i.b.ON_CREATE);
    ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks(new c());
  }
  
  void i() {
    if (this.p == 0) {
      this.q = true;
      this.t.h(i.b.ON_PAUSE);
    } 
  }
  
  void j() {
    if (this.o == 0 && this.q) {
      this.t.h(i.b.ON_STOP);
      this.r = true;
    } 
  }
  
  class a implements Runnable {
    a(v this$0) {}
    
    public void run() {
      this.o.i();
      this.o.j();
    }
  }
  
  class b implements w.a {
    b(v this$0) {}
    
    public void a() {}
    
    public void b() {
      this.a.f();
    }
    
    public void onResume() {
      this.a.e();
    }
  }
  
  class c extends d {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      if (Build.VERSION.SDK_INT < 29)
        w.f(param1Activity).h(v.this.v); 
    }
    
    public void onActivityPaused(Activity param1Activity) {
      v.this.b();
    }
    
    public void onActivityPreCreated(Activity param1Activity, Bundle param1Bundle) {
      param1Activity.registerActivityLifecycleCallbacks(new a());
    }
    
    public void onActivityStopped(Activity param1Activity) {
      v.this.g();
    }
    
    class a extends d {
      public void onActivityPostResumed(Activity param2Activity) {
        v.this.e();
      }
      
      public void onActivityPostStarted(Activity param2Activity) {
        v.this.f();
      }
    }
  }
  
  class a extends d {
    public void onActivityPostResumed(Activity param1Activity) {
      v.this.e();
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      v.this.f();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */