package androidx.lifecycle;

import java.util.Map;

public abstract class LiveData<T> {
  static final Object k = new Object();
  
  final Object a = new Object();
  
  private j.b<t<? super T>, c> b = new j.b();
  
  int c = 0;
  
  private boolean d;
  
  private volatile Object e;
  
  volatile Object f;
  
  private int g;
  
  private boolean h;
  
  private boolean i;
  
  private final Runnable j;
  
  public LiveData() {
    Object object = k;
    this.f = object;
    this.j = new a(this);
    this.e = object;
    this.g = -1;
  }
  
  static void b(String paramString) {
    if (i.a.e().b())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void d(c paramc) {
    if (!paramc.b)
      return; 
    if (!paramc.k()) {
      paramc.h(false);
      return;
    } 
    int i = paramc.c;
    int j = this.g;
    if (i >= j)
      return; 
    paramc.c = j;
    paramc.a.a((T)this.e);
  }
  
  void c(int paramInt) {
    int i = this.c;
    this.c = paramInt + i;
    if (this.d)
      return; 
    this.d = true;
    while (true) {
      int j;
      try {
        j = this.c;
      } finally {
        this.d = false;
      } 
      if (i > 0 && j == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (paramInt != 0) {
        j();
      } else if (i != 0) {
        k();
      } 
      i = j;
    } 
  }
  
  void e(c paramc) {
    if (this.h) {
      this.i = true;
      return;
    } 
    this.h = true;
    while (true) {
      c c1;
      this.i = false;
      if (paramc != null) {
        d(paramc);
        c1 = null;
      } else {
        j.b.d<Map.Entry> d = this.b.g();
        while (true) {
          c1 = paramc;
          if (d.hasNext()) {
            d((c)((Map.Entry)d.next()).getValue());
            if (this.i) {
              c1 = paramc;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramc = c1;
      if (!this.i) {
        this.h = false;
        return;
      } 
    } 
  }
  
  public T f() {
    Object object = this.e;
    return (T)((object != k) ? object : null);
  }
  
  public boolean g() {
    return (this.c > 0);
  }
  
  public void h(m paramm, t<? super T> paramt) {
    b("observe");
    if (paramm.a().b() == i.c.o)
      return; 
    LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(this, paramm, paramt);
    c c = (c)this.b.p(paramt, lifecycleBoundObserver);
    if (c == null || c.j(paramm)) {
      if (c != null)
        return; 
      paramm.a().a(lifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void i(t<? super T> paramt) {
    b("observeForever");
    b b1 = new b(this, paramt);
    c c = (c)this.b.p(paramt, b1);
    if (!(c instanceof LifecycleBoundObserver)) {
      if (c != null)
        return; 
      b1.h(true);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  protected void j() {}
  
  protected void k() {}
  
  protected void l(T paramT) {
    synchronized (this.a) {
      boolean bool;
      if (this.f == k) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = paramT;
      if (!bool)
        return; 
      i.a.e().c(this.j);
      return;
    } 
  }
  
  public void m(t<? super T> paramt) {
    b("removeObserver");
    c c = (c)this.b.q(paramt);
    if (c == null)
      return; 
    c.i();
    c.h(false);
  }
  
  protected void n(T paramT) {
    b("setValue");
    this.g++;
    this.e = paramT;
    e(null);
  }
  
  class LifecycleBoundObserver extends c implements k {
    final m e;
    
    LifecycleBoundObserver(LiveData this$0, m param1m, t<? super T> param1t) {
      super(this$0, param1t);
      this.e = param1m;
    }
    
    public void d(m param1m, i.b param1b) {
      i.c c1 = this.e.a().b();
      if (c1 == i.c.o) {
        this.f.m(this.a);
        return;
      } 
      param1b = null;
      while (param1b != c1) {
        h(k());
        i.c c3 = this.e.a().b();
        i.c c2 = c1;
        c1 = c3;
      } 
    }
    
    void i() {
      this.e.a().c(this);
    }
    
    boolean j(m param1m) {
      return (this.e == param1m);
    }
    
    boolean k() {
      return this.e.a().b().c(i.c.r);
    }
  }
  
  class a implements Runnable {
    a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.o.a) {
        Object object = this.o.f;
        this.o.f = LiveData.k;
        this.o.n(object);
        return;
      } 
    }
  }
  
  private class b extends c {
    b(LiveData this$0, t<? super T> param1t) {
      super(this$0, param1t);
    }
    
    boolean k() {
      return true;
    }
  }
  
  private abstract class c {
    final t<? super T> a;
    
    boolean b;
    
    int c = -1;
    
    c(LiveData this$0, t<? super T> param1t) {
      this.a = param1t;
    }
    
    void h(boolean param1Boolean) {
      byte b;
      if (param1Boolean == this.b)
        return; 
      this.b = param1Boolean;
      LiveData liveData = this.d;
      if (param1Boolean) {
        b = 1;
      } else {
        b = -1;
      } 
      liveData.c(b);
      if (this.b)
        this.d.e(this); 
    }
    
    void i() {}
    
    boolean j(m param1m) {
      return false;
    }
    
    abstract boolean k();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */