package androidx.lifecycle;

import android.view.View;
import j0.e;

public class k0 {
  public static void a(View paramView, i0 parami0) {
    paramView.setTag(e.a, parami0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */