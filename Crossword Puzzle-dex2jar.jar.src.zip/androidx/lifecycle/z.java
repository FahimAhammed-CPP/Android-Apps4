package androidx.lifecycle;

import android.os.Bundle;
import b8.l;
import c8.g;
import c8.h;
import c8.m;
import q0.e;

public final class z {
  public static final j0.a.b<e> a = new b();
  
  public static final j0.a.b<i0> b = new c();
  
  public static final j0.a.b<Bundle> c = new a();
  
  public static final <T extends e & i0> void a(T paramT) {
    boolean bool;
    g.e(paramT, "<this>");
    i.c c = paramT.a().b();
    g.d(c, "lifecycle.currentState");
    if (c == i.c.p || c == i.c.q) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramT.d().c("androidx.lifecycle.internal.SavedStateHandlesProvider") == null) {
        a0 a0 = new a0(paramT.d(), (i0)paramT);
        paramT.d().h("androidx.lifecycle.internal.SavedStateHandlesProvider", a0);
        paramT.a().a(new SavedStateHandleAttacher(a0));
      } 
      return;
    } 
    throw new IllegalArgumentException("Failed requirement.".toString());
  }
  
  public static final b0 b(i0 parami0) {
    g.e(parami0, "<this>");
    j0.c c = new j0.c();
    d d = d.p;
    c.a(m.a(b0.class), d);
    return (new e0(parami0, c.b())).<b0>b("androidx.lifecycle.internal.SavedStateHandlesVM", b0.class);
  }
  
  public static final class a implements j0.a.b<Bundle> {}
  
  public static final class b implements j0.a.b<e> {}
  
  public static final class c implements j0.a.b<i0> {}
  
  static final class d extends h implements l<j0.a, b0> {
    public static final d p = new d();
    
    d() {
      super(1);
    }
    
    public final b0 c(j0.a param1a) {
      g.e(param1a, "$this$initializer");
      return new b0();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */