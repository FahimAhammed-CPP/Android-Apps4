package androidx.lifecycle;

public class s<T> extends LiveData<T> {
  public void l(T paramT) {
    super.l(paramT);
  }
  
  public void n(T paramT) {
    super.n(paramT);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */