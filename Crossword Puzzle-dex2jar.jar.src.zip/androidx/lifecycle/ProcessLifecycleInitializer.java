package androidx.lifecycle;

import android.content.Context;
import androidx.startup.a;
import java.util.Collections;
import java.util.List;
import t0.a;

public final class ProcessLifecycleInitializer implements a<m> {
  public List<Class<? extends a<?>>> a() {
    return Collections.emptyList();
  }
  
  public m c(Context paramContext) {
    if (a.e(paramContext).g(ProcessLifecycleInitializer.class)) {
      j.a(paramContext);
      v.l(paramContext);
      return v.k();
    } 
    throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily. \nPlease ensure that you have: \n<meta-data\n    android:name='androidx.lifecycle.ProcessLifecycleInitializer' \n    android:value='androidx.startup' /> \nunder InitializationProvider in your AndroidManifest.xml");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */