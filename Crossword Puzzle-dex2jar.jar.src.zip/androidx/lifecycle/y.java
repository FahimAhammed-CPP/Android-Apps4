package androidx.lifecycle;

import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import androidx.core.os.d;
import c8.e;
import c8.g;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import q0.c;
import r7.i;
import r7.m;
import s7.w;

public final class y {
  static {
    Class<boolean> clazz4 = boolean.class;
    Class<double> clazz5 = double.class;
    Class<int> clazz2 = int.class;
    Class<long> clazz6 = long.class;
    Class<byte> clazz7 = byte.class;
    Class<char> clazz8 = char.class;
    Class<float> clazz9 = float.class;
    Class<short> clazz10 = short.class;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      Class<Size> clazz11 = Size.class;
    } else {
      clazz3 = clazz2;
    } 
    Class<int> clazz1 = clazz2;
    if (i >= 21)
      clazz = SizeF.class; 
    g = (Class<? extends Object>[])new Class[] { 
        clazz4, boolean[].class, clazz5, double[].class, clazz2, int[].class, clazz6, long[].class, String.class, String[].class, 
        Binder.class, Bundle.class, clazz7, byte[].class, clazz8, char[].class, CharSequence.class, CharSequence[].class, ArrayList.class, clazz9, 
        float[].class, Parcelable.class, Parcelable[].class, Serializable.class, clazz10, short[].class, SparseArray.class, clazz3, clazz };
  }
  
  private static final Bundle d(y paramy) {
    g.e(paramy, "this$0");
    for (Map.Entry entry : w.i(paramy.b).entrySet())
      paramy.e((String)entry.getKey(), ((c.c)entry.getValue()).a()); 
    Set<String> set = paramy.a.keySet();
    ArrayList<String> arrayList = new ArrayList(set.size());
    ArrayList arrayList1 = new ArrayList(arrayList.size());
    for (String str : set) {
      arrayList.add(str);
      arrayList1.add(paramy.a.get(str));
    } 
    return d.a(new i[] { m.a("keys", arrayList), m.a("values", arrayList1) });
  }
  
  public final c.c c() {
    return this.e;
  }
  
  public final <T> void e(String paramString, T paramT) {
    g.e(paramString, "key");
    if (f.a(paramT)) {
      Object object = this.c.get(paramString);
      if (object instanceof s) {
        object = object;
      } else {
        object = null;
      } 
      if (object != null) {
        object.n(paramT);
      } else {
        this.a.put(paramString, paramT);
      } 
      l8.a a1 = this.d.get(paramString);
      if (a1 == null)
        return; 
      a1.setValue(paramT);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't put value with type ");
    g.b(paramT);
    stringBuilder.append(paramT.getClass());
    stringBuilder.append(" into saved state");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  static {
    Class<SizeF> clazz;
    Class<int> clazz3;
  }
  
  public static final a f = new a(null);
  
  private static final Class<? extends Object>[] g;
  
  private final Map<String, Object> a = new LinkedHashMap<String, Object>();
  
  private final Map<String, c.c> b = new LinkedHashMap<String, c.c>();
  
  private final Map<String, Object> c = new LinkedHashMap<String, Object>();
  
  private final Map<String, l8.a<Object>> d = new LinkedHashMap<String, l8.a<Object>>();
  
  private final c.c e = new x(this);
  
  public static final class a {
    private a() {}
    
    public final boolean a(Object param1Object) {
      if (param1Object == null)
        return true; 
      for (Class clazz : y.b()) {
        g.b(clazz);
        if (clazz.isInstance(param1Object))
          return true; 
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */