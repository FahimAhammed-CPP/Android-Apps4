package androidx.lifecycle;

import c8.g;

public final class SavedStateHandleAttacher implements k {
  private final a0 a;
  
  public SavedStateHandleAttacher(a0 parama0) {
    this.a = parama0;
  }
  
  public void d(m paramm, i.b paramb) {
    boolean bool;
    g.e(paramm, "source");
    g.e(paramb, "event");
    if (paramb == i.b.ON_CREATE) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      paramm.a().c(this);
      this.a.c();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Next event must be ON_CREATE, it was ");
    stringBuilder.append(paramb);
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\SavedStateHandleAttacher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */