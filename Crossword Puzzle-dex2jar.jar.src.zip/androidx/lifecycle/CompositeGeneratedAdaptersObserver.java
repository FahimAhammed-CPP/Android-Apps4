package androidx.lifecycle;

class CompositeGeneratedAdaptersObserver implements k {
  private final f[] a;
  
  CompositeGeneratedAdaptersObserver(f[] paramArrayOff) {
    this.a = paramArrayOff;
  }
  
  public void d(m paramm, i.b paramb) {
    r r = new r();
    f[] arrayOfF = this.a;
    int j = arrayOfF.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++)
      arrayOfF[i].a(paramm, paramb, false, r); 
    arrayOfF = this.a;
    j = arrayOfF.length;
    for (i = bool; i < j; i++)
      arrayOfF[i].a(paramm, paramb, true, r); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */