package androidx.lifecycle;

import android.os.Bundle;
import q0.c;



/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */