package androidx.lifecycle;

public interface t<T> {
  void a(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */