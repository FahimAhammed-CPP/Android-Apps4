package androidx.lifecycle;

class SingleGeneratedAdapterObserver implements k {
  private final f a;
  
  SingleGeneratedAdapterObserver(f paramf) {
    this.a = paramf;
  }
  
  public void d(m paramm, i.b paramb) {
    this.a.a(paramm, paramb, false, null);
    this.a.a(paramm, paramb, true, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */