package androidx.lifecycle;

import java.util.Iterator;
import q0.c;
import q0.e;

class LegacySavedStateHandleController {
  static void a(d0 paramd0, c paramc, i parami) {
    SavedStateHandleController savedStateHandleController = paramd0.<SavedStateHandleController>c("androidx.lifecycle.savedstate.vm.tag");
    if (savedStateHandleController != null && !savedStateHandleController.i()) {
      savedStateHandleController.h(paramc, parami);
      b(paramc, parami);
    } 
  }
  
  private static void b(c paramc, i parami) {
    i.c c1 = parami.b();
    if (c1 == i.c.p || c1.c(i.c.r)) {
      paramc.i(a.class);
      return;
    } 
    parami.a(new k(parami, paramc) {
          public void d(m param1m, i.b param1b) {
            if (param1b == i.b.ON_START) {
              this.a.c(this);
              this.b.i(LegacySavedStateHandleController.a.class);
            } 
          }
        });
  }
  
  static final class a implements c.a {
    public void a(e param1e) {
      if (param1e instanceof i0) {
        h0 h0 = ((i0)param1e).k();
        c c = param1e.d();
        Iterator<String> iterator = h0.c().iterator();
        while (iterator.hasNext())
          LegacySavedStateHandleController.a(h0.b(iterator.next()), c, param1e.a()); 
        if (!h0.c().isEmpty())
          c.i(a.class); 
        return;
      } 
      IllegalStateException illegalStateException = new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner");
      throw illegalStateException;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\LegacySavedStateHandleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */