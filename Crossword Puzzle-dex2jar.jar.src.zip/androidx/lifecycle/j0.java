package androidx.lifecycle;

import android.view.View;
import i0.a;

public class j0 {
  public static void a(View paramView, m paramm) {
    paramView.setTag(a.a, paramm);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */