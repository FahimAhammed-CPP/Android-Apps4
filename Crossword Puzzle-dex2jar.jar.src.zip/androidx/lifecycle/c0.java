package androidx.lifecycle;

import android.os.Handler;

public class c0 {
  private final n a;
  
  private final Handler b;
  
  private a c;
  
  public c0(m paramm) {
    this.a = new n(paramm);
    this.b = new Handler();
  }
  
  private void f(i.b paramb) {
    a a2 = this.c;
    if (a2 != null)
      a2.run(); 
    a a1 = new a(this.a, paramb);
    this.c = a1;
    this.b.postAtFrontOfQueue(a1);
  }
  
  public i a() {
    return this.a;
  }
  
  public void b() {
    f(i.b.ON_START);
  }
  
  public void c() {
    f(i.b.ON_CREATE);
  }
  
  public void d() {
    f(i.b.ON_STOP);
    f(i.b.ON_DESTROY);
  }
  
  public void e() {
    f(i.b.ON_START);
  }
  
  static class a implements Runnable {
    private final n o;
    
    final i.b p;
    
    private boolean q = false;
    
    a(n param1n, i.b param1b) {
      this.o = param1n;
      this.p = param1b;
    }
    
    public void run() {
      if (!this.q) {
        this.o.h(this.p);
        this.q = true;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */