package androidx.lifecycle;

import c8.g;
import j0.a;

public final class g0 {
  public static final a a(i0 parami0) {
    g.e(parami0, "owner");
    if (parami0 instanceof h) {
      a a = ((h)parami0).h();
      g.d(a, "{\n        owner.defaultV…ModelCreationExtras\n    }");
      return a;
    } 
    return (a)a.a.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */