package androidx.lifecycle;

import q0.c;

final class SavedStateHandleController implements k {
  private final String a;
  
  private boolean b;
  
  private final y c;
  
  public void d(m paramm, i.b paramb) {
    if (paramb == i.b.ON_DESTROY) {
      this.b = false;
      paramm.a().c(this);
    } 
  }
  
  void h(c paramc, i parami) {
    if (!this.b) {
      this.b = true;
      parami.a(this);
      paramc.h(this.a, this.c.c());
      return;
    } 
    throw new IllegalStateException("Already attached to lifecycleOwner");
  }
  
  boolean i() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\SavedStateHandleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */