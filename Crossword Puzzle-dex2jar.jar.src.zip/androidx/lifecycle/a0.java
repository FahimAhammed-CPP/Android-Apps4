package androidx.lifecycle;

import android.os.Bundle;
import c8.g;
import c8.h;
import java.util.Map;
import q0.c;
import r7.e;
import r7.f;

public final class a0 implements c.c {
  private final c a;
  
  private boolean b;
  
  private Bundle c;
  
  private final e d;
  
  public a0(c paramc, i0 parami0) {
    this.a = paramc;
    this.d = f.a(new a(parami0));
  }
  
  private final b0 b() {
    return (b0)this.d.getValue();
  }
  
  public Bundle a() {
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = this.c;
    if (bundle2 != null)
      bundle1.putAll(bundle2); 
    for (Map.Entry<String, y> entry : b().e().entrySet()) {
      String str = (String)entry.getKey();
      Bundle bundle = ((y)entry.getValue()).c().a();
      if (!g.a(bundle, Bundle.EMPTY))
        bundle1.putBundle(str, bundle); 
    } 
    this.b = false;
    return bundle1;
  }
  
  public final void c() {
    if (!this.b) {
      this.c = this.a.b("androidx.lifecycle.internal.SavedStateHandlesProvider");
      this.b = true;
      b();
    } 
  }
  
  static final class a extends h implements b8.a<b0> {
    a(i0 param1i0) {
      super(0);
    }
    
    public final b0 c() {
      return z.b(this.p);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */