package androidx.lifecycle;

import java.util.LinkedHashMap;
import java.util.Map;

public final class b0 extends d0 {
  private final Map<String, y> d = new LinkedHashMap<String, y>();
  
  public final Map<String, y> e() {
    return this.d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */