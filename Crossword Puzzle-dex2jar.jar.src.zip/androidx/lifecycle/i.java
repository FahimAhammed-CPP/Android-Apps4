package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicReference;

public abstract class i {
  AtomicReference<Object> a = new AtomicReference();
  
  public abstract void a(l paraml);
  
  public abstract c b();
  
  public abstract void c(l paraml);
  
  public enum b {
    ON_ANY, ON_CREATE, ON_DESTROY, ON_PAUSE, ON_RESUME, ON_START, ON_STOP;
    
    static {
      b b1 = new b("ON_CREATE", 0);
      ON_CREATE = b1;
      b b2 = new b("ON_START", 1);
      ON_START = b2;
      b b3 = new b("ON_RESUME", 2);
      ON_RESUME = b3;
      b b4 = new b("ON_PAUSE", 3);
      ON_PAUSE = b4;
      b b5 = new b("ON_STOP", 4);
      ON_STOP = b5;
      b b6 = new b("ON_DESTROY", 5);
      ON_DESTROY = b6;
      b b7 = new b("ON_ANY", 6);
      ON_ANY = b7;
      $VALUES = new b[] { b1, b2, b3, b4, b5, b6, b7 };
    }
    
    public static b c(i.c param1c) {
      int i = i.a.a[param1c.ordinal()];
      return (i != 1) ? ((i != 2) ? ((i != 3) ? null : ON_PAUSE) : ON_STOP) : ON_DESTROY;
    }
    
    public static b e(i.c param1c) {
      int i = i.a.a[param1c.ordinal()];
      return (i != 1) ? ((i != 2) ? ((i != 5) ? null : ON_CREATE) : ON_RESUME) : ON_START;
    }
    
    public i.c d() {
      StringBuilder stringBuilder;
      switch (i.a.b[ordinal()]) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append(this);
          stringBuilder.append(" has no target state");
          throw new IllegalArgumentException(stringBuilder.toString());
        case 6:
          return i.c.o;
        case 5:
          return i.c.s;
        case 3:
        case 4:
          return i.c.r;
        case 1:
        case 2:
          break;
      } 
      return i.c.q;
    }
  }
  
  public enum c {
    o, p, q, r, s;
    
    static {
      c c1 = new c("DESTROYED", 0);
      o = c1;
      c c2 = new c("INITIALIZED", 1);
      p = c2;
      c c3 = new c("CREATED", 2);
      q = c3;
      c c4 = new c("STARTED", 3);
      r = c4;
      c c5 = new c("RESUMED", 4);
      s = c5;
      t = new c[] { c1, c2, c3, c4, c5 };
    }
    
    public boolean c(c param1c) {
      return (compareTo((E)param1c) >= 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */