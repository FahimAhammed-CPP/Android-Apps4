package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class p extends Service implements m {
  private final c0 o = new c0(this);
  
  public i a() {
    return this.o.a();
  }
  
  public IBinder onBind(Intent paramIntent) {
    this.o.b();
    return null;
  }
  
  public void onCreate() {
    this.o.c();
    super.onCreate();
  }
  
  public void onDestroy() {
    this.o.d();
    super.onDestroy();
  }
  
  public void onStart(Intent paramIntent, int paramInt) {
    this.o.e();
    super.onStart(paramIntent, paramInt);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */