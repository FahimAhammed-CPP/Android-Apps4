package androidx.lifecycle;

import android.app.Application;
import c8.e;
import c8.g;
import java.util.Objects;

public class e0 {
  private final h0 a;
  
  private final b b;
  
  private final j0.a c;
  
  public e0(h0 paramh0, b paramb) {
    this(paramh0, paramb, null, 4, null);
  }
  
  public e0(h0 paramh0, b paramb, j0.a parama) {
    this.a = paramh0;
    this.b = paramb;
    this.c = parama;
  }
  
  public e0(i0 parami0, b paramb) {
    this(h01, paramb, g0.a(parami0));
  }
  
  public <T extends d0> T a(Class<T> paramClass) {
    g.e(paramClass, "modelClass");
    String str = paramClass.getCanonicalName();
    if (str != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("androidx.lifecycle.ViewModelProvider.DefaultKey:");
      stringBuilder.append(str);
      return b(stringBuilder.toString(), paramClass);
    } 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public <T extends d0> T b(String paramString, Class<T> paramClass) {
    b b1;
    j0.d d1;
    g.e(paramString, "key");
    g.e(paramClass, "modelClass");
    d0 d0 = this.a.b(paramString);
    if (paramClass.isInstance(d0)) {
      b1 = this.b;
      if (b1 instanceof d) {
        d d = (d)b1;
      } else {
        b1 = null;
      } 
      if (b1 != null) {
        g.d(d0, "viewModel");
        b1.a(d0);
      } 
      Objects.requireNonNull(d0, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
      return (T)d0;
    } 
    j0.d d2 = new j0.d(this.c);
    d2.b(c.c, b1);
    try {
      d2 = this.b.b((Class)paramClass, (j0.a)d2);
      d1 = d2;
    } catch (AbstractMethodError abstractMethodError) {
      d1 = this.b.a((Class<j0.d>)d1);
    } 
    this.a.d((String)b1, (d0)d1);
    return (T)d1;
  }
  
  public static class a extends c {
    public static final a d = new a(null);
    
    public static final j0.a.b<Application> e = a.a.a;
    
    public static final class a {
      private a() {}
      
      private static final class a implements j0.a.b<Application> {
        public static final a a = new a();
      }
    }
    
    private static final class a implements j0.a.b<Application> {
      public static final a a = new a();
    }
  }
  
  public static final class a {
    private a() {}
    
    private static final class a implements j0.a.b<Application> {
      public static final a a = new a();
    }
  }
  
  private static final class a implements j0.a.b<Application> {
    public static final a a = new a();
  }
  
  public static interface b {
    public static final a a = a.a;
    
    <T extends d0> T a(Class<T> param1Class);
    
    <T extends d0> T b(Class<T> param1Class, j0.a param1a);
    
    public static final class a {}
  }
  
  public static final class a {}
  
  public static class c implements b {
    public static final a b = new a(null);
    
    public static final j0.a.b<String> c = a.a.a;
    
    public static final class a {
      private a() {}
      
      private static final class a implements j0.a.b<String> {
        public static final a a = new a();
      }
    }
    
    private static final class a implements j0.a.b<String> {
      public static final a a = new a();
    }
  }
  
  public static final class a {
    private a() {}
    
    private static final class a implements j0.a.b<String> {
      public static final a a = new a();
    }
  }
  
  private static final class a implements j0.a.b<String> {
    public static final a a = new a();
  }
  
  public static class d {
    public void a(d0 param1d0) {
      g.e(param1d0, "viewModel");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */