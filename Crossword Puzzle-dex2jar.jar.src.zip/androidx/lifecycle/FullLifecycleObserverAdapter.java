package androidx.lifecycle;

class FullLifecycleObserverAdapter implements k {
  private final e a;
  
  private final k b;
  
  FullLifecycleObserverAdapter(e parame, k paramk) {
    this.a = parame;
    this.b = paramk;
  }
  
  public void d(m paramm, i.b paramb) {
    switch (a.a[paramb.ordinal()]) {
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        this.a.b(paramm);
        break;
      case 5:
        this.a.g(paramm);
        break;
      case 4:
        this.a.e(paramm);
        break;
      case 3:
        this.a.a(paramm);
        break;
      case 2:
        this.a.f(paramm);
        break;
      case 1:
        this.a.c(paramm);
        break;
    } 
    k k1 = this.b;
    if (k1 != null)
      k1.d(paramm, paramb); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\androidx\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */