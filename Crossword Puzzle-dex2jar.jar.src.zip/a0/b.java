package a0;

import android.database.Cursor;
import android.widget.Filter;

class b extends Filter {
  a a;
  
  b(a parama) {
    this.a = parama;
  }
  
  public CharSequence convertResultToString(Object paramObject) {
    return this.a.c((Cursor)paramObject);
  }
  
  protected Filter.FilterResults performFiltering(CharSequence paramCharSequence) {
    Cursor cursor = this.a.e(paramCharSequence);
    Filter.FilterResults filterResults = new Filter.FilterResults();
    if (cursor != null) {
      filterResults.count = cursor.getCount();
      filterResults.values = cursor;
      return filterResults;
    } 
    filterResults.count = 0;
    filterResults.values = null;
    return filterResults;
  }
  
  protected void publishResults(CharSequence paramCharSequence, Filter.FilterResults paramFilterResults) {
    Cursor cursor = this.a.b();
    Object object = paramFilterResults.values;
    if (object != null && object != cursor)
      this.a.a((Cursor)object); 
  }
  
  static interface a {
    void a(Cursor param1Cursor);
    
    Cursor b();
    
    CharSequence c(Cursor param1Cursor);
    
    Cursor e(CharSequence param1CharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */