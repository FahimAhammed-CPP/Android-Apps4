package a0;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;

public abstract class a extends BaseAdapter implements Filterable, b.a {
  protected boolean o;
  
  protected boolean p;
  
  protected Cursor q;
  
  protected Context r;
  
  protected int s;
  
  protected a t;
  
  protected DataSetObserver u;
  
  protected b v;
  
  public a(Context paramContext, Cursor paramCursor, boolean paramBoolean) {
    byte b1;
    if (paramBoolean) {
      b1 = 1;
    } else {
      b1 = 2;
    } 
    p(paramContext, paramCursor, b1);
  }
  
  public void a(Cursor paramCursor) {
    paramCursor = t(paramCursor);
    if (paramCursor != null)
      paramCursor.close(); 
  }
  
  public Cursor b() {
    return this.q;
  }
  
  public abstract CharSequence c(Cursor paramCursor);
  
  public abstract void g(View paramView, Context paramContext, Cursor paramCursor);
  
  public int getCount() {
    if (this.o) {
      Cursor cursor = this.q;
      if (cursor != null)
        return cursor.getCount(); 
    } 
    return 0;
  }
  
  public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    if (this.o) {
      this.q.moveToPosition(paramInt);
      View view = paramView;
      if (paramView == null)
        view = q(this.r, this.q, paramViewGroup); 
      g(view, this.r, this.q);
      return view;
    } 
    return null;
  }
  
  public Filter getFilter() {
    if (this.v == null)
      this.v = new b(this); 
    return this.v;
  }
  
  public Object getItem(int paramInt) {
    if (this.o) {
      Cursor cursor = this.q;
      if (cursor != null) {
        cursor.moveToPosition(paramInt);
        return this.q;
      } 
    } 
    return null;
  }
  
  public long getItemId(int paramInt) {
    if (this.o) {
      Cursor cursor = this.q;
      if (cursor != null && cursor.moveToPosition(paramInt))
        return this.q.getLong(this.s); 
    } 
    return 0L;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    if (this.o) {
      if (this.q.moveToPosition(paramInt)) {
        View view = paramView;
        if (paramView == null)
          view = r(this.r, this.q, paramViewGroup); 
        g(view, this.r, this.q);
        return view;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("couldn't move cursor to position ");
      stringBuilder.append(paramInt);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    throw new IllegalStateException("this should only be called when the cursor is valid");
  }
  
  void p(Context paramContext, Cursor paramCursor, int paramInt) {
    byte b1;
    boolean bool = false;
    if ((paramInt & 0x1) == 1) {
      paramInt |= 0x2;
      this.p = true;
    } else {
      this.p = false;
    } 
    if (paramCursor != null)
      bool = true; 
    this.q = paramCursor;
    this.o = bool;
    this.r = paramContext;
    if (bool) {
      b1 = paramCursor.getColumnIndexOrThrow("_id");
    } else {
      b1 = -1;
    } 
    this.s = b1;
    if ((paramInt & 0x2) == 2) {
      this.t = new a(this);
      this.u = new b(this);
    } else {
      this.t = null;
      this.u = null;
    } 
    if (bool) {
      a a1 = this.t;
      if (a1 != null)
        paramCursor.registerContentObserver(a1); 
      DataSetObserver dataSetObserver = this.u;
      if (dataSetObserver != null)
        paramCursor.registerDataSetObserver(dataSetObserver); 
    } 
  }
  
  public abstract View q(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup);
  
  public abstract View r(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup);
  
  protected void s() {
    if (this.p) {
      Cursor cursor = this.q;
      if (cursor != null && !cursor.isClosed())
        this.o = this.q.requery(); 
    } 
  }
  
  public Cursor t(Cursor paramCursor) {
    Cursor cursor = this.q;
    if (paramCursor == cursor)
      return null; 
    if (cursor != null) {
      a a1 = this.t;
      if (a1 != null)
        cursor.unregisterContentObserver(a1); 
      DataSetObserver dataSetObserver = this.u;
      if (dataSetObserver != null)
        cursor.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.q = paramCursor;
    if (paramCursor != null) {
      a a1 = this.t;
      if (a1 != null)
        paramCursor.registerContentObserver(a1); 
      DataSetObserver dataSetObserver = this.u;
      if (dataSetObserver != null)
        paramCursor.registerDataSetObserver(dataSetObserver); 
      this.s = paramCursor.getColumnIndexOrThrow("_id");
      this.o = true;
      notifyDataSetChanged();
      return cursor;
    } 
    this.s = -1;
    this.o = false;
    notifyDataSetInvalidated();
    return cursor;
  }
  
  private class a extends ContentObserver {
    a(a this$0) {
      super(new Handler());
    }
    
    public boolean deliverSelfNotifications() {
      return true;
    }
    
    public void onChange(boolean param1Boolean) {
      this.a.s();
    }
  }
  
  private class b extends DataSetObserver {
    b(a this$0) {}
    
    public void onChanged() {
      a a1 = this.a;
      a1.o = true;
      a1.notifyDataSetChanged();
    }
    
    public void onInvalidated() {
      a a1 = this.a;
      a1.o = false;
      a1.notifyDataSetInvalidated();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */