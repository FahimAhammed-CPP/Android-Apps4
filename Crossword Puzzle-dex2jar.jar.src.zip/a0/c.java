package a0;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class c extends a {
  private int w;
  
  private int x;
  
  private LayoutInflater y;
  
  @Deprecated
  public c(Context paramContext, int paramInt, Cursor paramCursor, boolean paramBoolean) {
    super(paramContext, paramCursor, paramBoolean);
    this.x = paramInt;
    this.w = paramInt;
    this.y = (LayoutInflater)paramContext.getSystemService("layout_inflater");
  }
  
  public View q(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup) {
    return this.y.inflate(this.x, paramViewGroup, false);
  }
  
  public View r(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup) {
    return this.y.inflate(this.w, paramViewGroup, false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */