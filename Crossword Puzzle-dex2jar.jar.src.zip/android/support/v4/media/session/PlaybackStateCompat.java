package android.support.v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
  
  final int o;
  
  final long p;
  
  final long q;
  
  final float r;
  
  final long s;
  
  final int t;
  
  final CharSequence u;
  
  final long v;
  
  List<CustomAction> w;
  
  final long x;
  
  final Bundle y;
  
  private Object z;
  
  PlaybackStateCompat(int paramInt1, long paramLong1, long paramLong2, float paramFloat, long paramLong3, int paramInt2, CharSequence paramCharSequence, long paramLong4, List<CustomAction> paramList, long paramLong5, Bundle paramBundle) {
    this.o = paramInt1;
    this.p = paramLong1;
    this.q = paramLong2;
    this.r = paramFloat;
    this.s = paramLong3;
    this.t = paramInt2;
    this.u = paramCharSequence;
    this.v = paramLong4;
    this.w = new ArrayList<CustomAction>(paramList);
    this.x = paramLong5;
    this.y = paramBundle;
  }
  
  PlaybackStateCompat(Parcel paramParcel) {
    this.o = paramParcel.readInt();
    this.p = paramParcel.readLong();
    this.r = paramParcel.readFloat();
    this.v = paramParcel.readLong();
    this.q = paramParcel.readLong();
    this.s = paramParcel.readLong();
    this.u = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.w = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.x = paramParcel.readLong();
    this.y = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
    this.t = paramParcel.readInt();
  }
  
  public static PlaybackStateCompat i(Object paramObject) {
    PlaybackStateCompat playbackStateCompat;
    List<Object> list2 = null;
    Bundle bundle = null;
    List<Object> list1 = list2;
    if (paramObject != null) {
      list1 = list2;
      if (Build.VERSION.SDK_INT >= 21) {
        list2 = g.d(paramObject);
        if (list2 != null) {
          list1 = new ArrayList(list2.size());
          Iterator iterator = list2.iterator();
          while (iterator.hasNext())
            list1.add(CustomAction.i(iterator.next())); 
        } else {
          list1 = null;
        } 
        if (Build.VERSION.SDK_INT >= 22)
          bundle = h.a(paramObject); 
        playbackStateCompat = new PlaybackStateCompat(g.i(paramObject), g.h(paramObject), g.c(paramObject), g.g(paramObject), g.a(paramObject), 0, g.e(paramObject), g.f(paramObject), (List)list1, g.b(paramObject), bundle);
        playbackStateCompat.z = paramObject;
      } 
    } 
    return playbackStateCompat;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=");
    stringBuilder.append(this.o);
    stringBuilder.append(", position=");
    stringBuilder.append(this.p);
    stringBuilder.append(", buffered position=");
    stringBuilder.append(this.q);
    stringBuilder.append(", speed=");
    stringBuilder.append(this.r);
    stringBuilder.append(", updated=");
    stringBuilder.append(this.v);
    stringBuilder.append(", actions=");
    stringBuilder.append(this.s);
    stringBuilder.append(", error code=");
    stringBuilder.append(this.t);
    stringBuilder.append(", error message=");
    stringBuilder.append(this.u);
    stringBuilder.append(", custom actions=");
    stringBuilder.append(this.w);
    stringBuilder.append(", active item id=");
    stringBuilder.append(this.x);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.o);
    paramParcel.writeLong(this.p);
    paramParcel.writeFloat(this.r);
    paramParcel.writeLong(this.v);
    paramParcel.writeLong(this.q);
    paramParcel.writeLong(this.s);
    TextUtils.writeToParcel(this.u, paramParcel, paramInt);
    paramParcel.writeTypedList(this.w);
    paramParcel.writeLong(this.x);
    paramParcel.writeBundle(this.y);
    paramParcel.writeInt(this.t);
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new a();
    
    private final String o;
    
    private final CharSequence p;
    
    private final int q;
    
    private final Bundle r;
    
    private Object s;
    
    CustomAction(Parcel param1Parcel) {
      this.o = param1Parcel.readString();
      this.p = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.q = param1Parcel.readInt();
      this.r = param1Parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }
    
    CustomAction(String param1String, CharSequence param1CharSequence, int param1Int, Bundle param1Bundle) {
      this.o = param1String;
      this.p = param1CharSequence;
      this.q = param1Int;
      this.r = param1Bundle;
    }
    
    public static CustomAction i(Object param1Object) {
      if (param1Object == null || Build.VERSION.SDK_INT < 21)
        return null; 
      CustomAction customAction = new CustomAction(g.a.a(param1Object), g.a.d(param1Object), g.a.c(param1Object), g.a.b(param1Object));
      customAction.s = param1Object;
      return customAction;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Action:mName='");
      stringBuilder.append(this.p);
      stringBuilder.append(", mIcon=");
      stringBuilder.append(this.q);
      stringBuilder.append(", mExtras=");
      stringBuilder.append(this.r);
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.o);
      TextUtils.writeToParcel(this.p, param1Parcel, param1Int);
      param1Parcel.writeInt(this.q);
      param1Parcel.writeBundle(this.r);
    }
    
    static final class a implements Parcelable.Creator<CustomAction> {
      public PlaybackStateCompat.CustomAction a(Parcel param2Parcel) {
        return new PlaybackStateCompat.CustomAction(param2Parcel);
      }
      
      public PlaybackStateCompat.CustomAction[] b(int param2Int) {
        return new PlaybackStateCompat.CustomAction[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<CustomAction> {
    public PlaybackStateCompat.CustomAction a(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public PlaybackStateCompat.CustomAction[] b(int param1Int) {
      return new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  static final class a implements Parcelable.Creator<PlaybackStateCompat> {
    public PlaybackStateCompat a(Parcel param1Parcel) {
      return new PlaybackStateCompat(param1Parcel);
    }
    
    public PlaybackStateCompat[] b(int param1Int) {
      return new PlaybackStateCompat[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\android\support\v4\media\session\PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */