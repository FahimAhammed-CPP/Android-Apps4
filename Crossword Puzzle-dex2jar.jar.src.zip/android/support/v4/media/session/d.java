package android.support.v4.media.session;

public final class d {
  private final int a;
  
  private final int b;
  
  private final int c;
  
  private final int d;
  
  private final int e;
  
  d(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
    this.d = paramInt4;
    this.e = paramInt5;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\android\support\v4\media\session\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */