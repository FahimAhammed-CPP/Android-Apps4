package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;

public class ParcelableVolumeInfo implements Parcelable {
  public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new a();
  
  public int o;
  
  public int p;
  
  public int q;
  
  public int r;
  
  public int s;
  
  public ParcelableVolumeInfo(Parcel paramParcel) {
    this.o = paramParcel.readInt();
    this.q = paramParcel.readInt();
    this.r = paramParcel.readInt();
    this.s = paramParcel.readInt();
    this.p = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.o);
    paramParcel.writeInt(this.q);
    paramParcel.writeInt(this.r);
    paramParcel.writeInt(this.s);
    paramParcel.writeInt(this.p);
  }
  
  static final class a implements Parcelable.Creator<ParcelableVolumeInfo> {
    public ParcelableVolumeInfo a(Parcel param1Parcel) {
      return new ParcelableVolumeInfo(param1Parcel);
    }
    
    public ParcelableVolumeInfo[] b(int param1Int) {
      return new ParcelableVolumeInfo[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\android\support\v4\media\session\ParcelableVolumeInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */