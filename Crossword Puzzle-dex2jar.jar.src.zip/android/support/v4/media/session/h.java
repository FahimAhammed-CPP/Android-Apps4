package android.support.v4.media.session;

import android.media.session.PlaybackState;
import android.os.Bundle;

class h {
  public static Bundle a(Object paramObject) {
    return ((PlaybackState)paramObject).getExtras();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\android\support\v4\media\session\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */