package android.support.v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.media.MediaMetadataCompat;
import java.lang.ref.WeakReference;
import java.util.List;

public abstract class c implements IBinder.DeathRecipient {
  final Object a;
  
  a b;
  
  public c() {
    if (Build.VERSION.SDK_INT >= 21) {
      this.a = e.a(new a(this));
      return;
    } 
    b b = new b(this);
    this.b = b;
    this.a = b;
  }
  
  public void a(d paramd) {}
  
  public void b(Bundle paramBundle) {}
  
  public void binderDied() {
    i(8, null, null);
  }
  
  public void c(MediaMetadataCompat paramMediaMetadataCompat) {}
  
  public void d(PlaybackStateCompat paramPlaybackStateCompat) {}
  
  public void e(List<MediaSessionCompat.QueueItem> paramList) {}
  
  public void f(CharSequence paramCharSequence) {}
  
  public void g() {}
  
  public void h(String paramString, Bundle paramBundle) {}
  
  void i(int paramInt, Object paramObject, Bundle paramBundle) {}
  
  private static class a implements e.a {
    private final WeakReference<c> a;
    
    a(c param1c) {
      this.a = new WeakReference<c>(param1c);
    }
    
    public void a(Object param1Object) {
      c c = this.a.get();
      if (c != null)
        c.c(MediaMetadataCompat.i(param1Object)); 
    }
    
    public void b(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      c c = this.a.get();
      if (c != null)
        c.a(new d(param1Int1, param1Int2, param1Int3, param1Int4, param1Int5)); 
    }
    
    public void c(Object param1Object) {
      c c = this.a.get();
      if (c != null) {
        if (c.b != null)
          return; 
        c.d(PlaybackStateCompat.i(param1Object));
      } 
    }
    
    public void d(String param1String, Bundle param1Bundle) {
      c c = this.a.get();
      if (c != null) {
        if (c.b != null && Build.VERSION.SDK_INT < 23)
          return; 
        c.h(param1String, param1Bundle);
      } 
    }
    
    public void h0(CharSequence param1CharSequence) {
      c c = this.a.get();
      if (c != null)
        c.f(param1CharSequence); 
    }
    
    public void j0() {
      c c = this.a.get();
      if (c != null)
        c.g(); 
    }
    
    public void u0(Bundle param1Bundle) {
      c c = this.a.get();
      if (c != null)
        c.b(param1Bundle); 
    }
    
    public void w0(List<?> param1List) {
      c c = this.a.get();
      if (c != null)
        c.e(MediaSessionCompat.QueueItem.j(param1List)); 
    }
  }
  
  private static class b extends a.a {
    private final WeakReference<c> o;
    
    b(c param1c) {
      this.o = new WeakReference<c>(param1c);
    }
    
    public void A5(PlaybackStateCompat param1PlaybackStateCompat) {
      c c = this.o.get();
      if (c != null)
        c.i(2, param1PlaybackStateCompat, null); 
    }
    
    public void H0(String param1String, Bundle param1Bundle) {
      c c = this.o.get();
      if (c != null)
        c.i(1, param1String, param1Bundle); 
    }
    
    public void Q0(boolean param1Boolean) {}
    
    public void R2(int param1Int) {
      c c = this.o.get();
      if (c != null)
        c.i(12, Integer.valueOf(param1Int), null); 
    }
    
    public void R4(boolean param1Boolean) {
      c c = this.o.get();
      if (c != null)
        c.i(11, Boolean.valueOf(param1Boolean), null); 
    }
    
    public void U2() {
      c c = this.o.get();
      if (c != null)
        c.i(13, null, null); 
    }
    
    public void W1(int param1Int) {
      c c = this.o.get();
      if (c != null)
        c.i(9, Integer.valueOf(param1Int), null); 
    }
    
    public void W5(ParcelableVolumeInfo param1ParcelableVolumeInfo) {
      c c = this.o.get();
      if (c != null) {
        if (param1ParcelableVolumeInfo != null) {
          d d = new d(param1ParcelableVolumeInfo.o, param1ParcelableVolumeInfo.p, param1ParcelableVolumeInfo.q, param1ParcelableVolumeInfo.r, param1ParcelableVolumeInfo.s);
        } else {
          param1ParcelableVolumeInfo = null;
        } 
        c.i(4, param1ParcelableVolumeInfo, null);
      } 
    }
    
    public void h0(CharSequence param1CharSequence) {
      c c = this.o.get();
      if (c != null)
        c.i(6, param1CharSequence, null); 
    }
    
    public void j0() {
      c c = this.o.get();
      if (c != null)
        c.i(8, null, null); 
    }
    
    public void s1(MediaMetadataCompat param1MediaMetadataCompat) {
      c c = this.o.get();
      if (c != null)
        c.i(3, param1MediaMetadataCompat, null); 
    }
    
    public void u0(Bundle param1Bundle) {
      c c = this.o.get();
      if (c != null)
        c.i(7, param1Bundle, null); 
    }
    
    public void w0(List<MediaSessionCompat.QueueItem> param1List) {
      c c = this.o.get();
      if (c != null)
        c.i(5, param1List, null); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\android\support\v4\media\session\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */