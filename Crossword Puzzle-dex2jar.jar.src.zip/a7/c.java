package a7;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import com.google.firebase.d;
import com.google.firebase.perf.config.RemoteConfigManager;
import com.google.firebase.perf.config.a;
import com.google.firebase.perf.session.SessionManager;
import d7.a;
import d7.b;
import i7.k;
import j7.f;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import t6.b;
import u1.g;
import u6.e;

public class c {
  private static final a i = a.e();
  
  private final Map<String, String> a = new ConcurrentHashMap<String, String>();
  
  private final a b;
  
  private final f c;
  
  private Boolean d = null;
  
  private final d e;
  
  private final b<com.google.firebase.remoteconfig.c> f;
  
  private final e g;
  
  private final b<g> h;
  
  c(d paramd, b<com.google.firebase.remoteconfig.c> paramb, e parame, b<g> paramb1, RemoteConfigManager paramRemoteConfigManager, a parama, SessionManager paramSessionManager) {
    this.e = paramd;
    this.f = paramb;
    this.g = parame;
    this.h = paramb1;
    if (paramd == null) {
      this.d = Boolean.FALSE;
      this.b = parama;
      this.c = new f(new Bundle());
      return;
    } 
    k.k().r(paramd, parame, paramb1);
    Context context = paramd.j();
    f f1 = a(context);
    this.c = f1;
    paramRemoteConfigManager.setFirebaseRemoteConfigProvider(paramb);
    this.b = parama;
    parama.Q(f1);
    parama.O(context);
    paramSessionManager.setApplicationContext(context);
    this.d = parama.j();
    a a1 = i;
    if (a1.h() && d())
      a1.f(String.format("Firebase Performance Monitoring is successfully initialized! In a minute, visit the Firebase console to view your data: %s", new Object[] { b.b(paramd.m().e(), context.getPackageName()) })); 
  }
  
  private static f a(Context paramContext) {
    try {
      Bundle bundle = (paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128)).metaData;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("No perf enable meta data found ");
      stringBuilder.append(nameNotFoundException.getMessage());
      Log.d("isEnabled", stringBuilder.toString());
      nameNotFoundException = null;
    } catch (NullPointerException nullPointerException) {}
    return (nullPointerException != null) ? new f((Bundle)nullPointerException) : new f();
  }
  
  public static c c() {
    return (c)d.k().i(c.class);
  }
  
  public Map<String, String> b() {
    return new HashMap<String, String>(this.a);
  }
  
  public boolean d() {
    Boolean bool = this.d;
    return (bool != null) ? bool.booleanValue() : d.k().s();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a7\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */