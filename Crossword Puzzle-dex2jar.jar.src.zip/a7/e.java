package a7;

import com.google.firebase.d;
import com.google.firebase.perf.config.RemoteConfigManager;
import com.google.firebase.perf.config.a;
import com.google.firebase.perf.session.SessionManager;
import com.google.firebase.remoteconfig.c;
import q7.a;
import t6.b;
import u1.g;

public final class e implements a {
  private final a<d> a;
  
  private final a<b<c>> b;
  
  private final a<u6.e> c;
  
  private final a<b<g>> d;
  
  private final a<RemoteConfigManager> e;
  
  private final a<a> f;
  
  private final a<SessionManager> g;
  
  public e(a<d> parama, a<b<c>> parama1, a<u6.e> parama2, a<b<g>> parama3, a<RemoteConfigManager> parama4, a<a> parama5, a<SessionManager> parama6) {
    this.a = parama;
    this.b = parama1;
    this.c = parama2;
    this.d = parama3;
    this.e = parama4;
    this.f = parama5;
    this.g = parama6;
  }
  
  public static e a(a<d> parama, a<b<c>> parama1, a<u6.e> parama2, a<b<g>> parama3, a<RemoteConfigManager> parama4, a<a> parama5, a<SessionManager> parama6) {
    return new e(parama, parama1, parama2, parama3, parama4, parama5, parama6);
  }
  
  public static c c(d paramd, b<c> paramb, u6.e parame, b<g> paramb1, RemoteConfigManager paramRemoteConfigManager, a parama, SessionManager paramSessionManager) {
    return new c(paramd, paramb, parame, paramb1, paramRemoteConfigManager, parama, paramSessionManager);
  }
  
  public c b() {
    return c((d)this.a.get(), (b<c>)this.b.get(), (u6.e)this.c.get(), (b<g>)this.d.get(), (RemoteConfigManager)this.e.get(), (a)this.f.get(), (SessionManager)this.g.get());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a7\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */