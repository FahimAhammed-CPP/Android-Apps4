package a7;

public final class a {
  public static final Boolean a = Boolean.FALSE;
  
  public static final String b = "20.3.0";
  
  public static final String c = "FIREPERF";
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a7\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */