package a6;

import android.os.Bundle;

public class f implements a {
  public void a(String paramString, Bundle paramBundle) {
    z5.f.f().b("Skipping logging Crashlytics event to Firebase, no Firebase Analytics");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a6\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */