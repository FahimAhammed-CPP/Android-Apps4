package a6;

import android.os.Bundle;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import z5.f;

public class c implements b, a {
  private final e a;
  
  private final int b;
  
  private final TimeUnit c;
  
  private final Object d = new Object();
  
  private CountDownLatch e;
  
  private boolean f = false;
  
  public c(e parame, int paramInt, TimeUnit paramTimeUnit) {
    this.a = parame;
    this.b = paramInt;
    this.c = paramTimeUnit;
  }
  
  public void H0(String paramString, Bundle paramBundle) {
    CountDownLatch countDownLatch = this.e;
    if (countDownLatch == null)
      return; 
    if ("_ae".equals(paramString))
      countDownLatch.countDown(); 
  }
  
  public void a(String paramString, Bundle paramBundle) {
    synchronized (this.d) {
      f f = f.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Logging event ");
      stringBuilder.append(paramString);
      stringBuilder.append(" to Firebase Analytics with params ");
      stringBuilder.append(paramBundle);
      f.i(stringBuilder.toString());
      this.e = new CountDownLatch(1);
      this.f = false;
      this.a.a(paramString, paramBundle);
      f.f().i("Awaiting app exception callback from Analytics...");
      try {
        if (this.e.await(this.b, this.c)) {
          this.f = true;
          f.f().i("App exception callback received from Analytics listener.");
        } else {
          f.f().k("Timeout exceeded while awaiting app exception callback from Analytics listener.");
        } 
      } catch (InterruptedException interruptedException) {
        f.f().d("Interrupted while awaiting app exception callback from Analytics listener.");
      } 
      this.e = null;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a6\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */