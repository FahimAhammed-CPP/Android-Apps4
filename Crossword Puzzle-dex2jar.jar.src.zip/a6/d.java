package a6;

import android.os.Bundle;
import b6.a;
import b6.b;
import org.json.JSONException;
import org.json.JSONObject;
import z5.f;

public class d implements b, b {
  private a a;
  
  private static String b(String paramString, Bundle paramBundle) {
    JSONObject jSONObject1 = new JSONObject();
    JSONObject jSONObject2 = new JSONObject();
    for (String str : paramBundle.keySet())
      jSONObject2.put(str, paramBundle.get(str)); 
    jSONObject1.put("name", paramString);
    jSONObject1.put("parameters", jSONObject2);
    return jSONObject1.toString();
  }
  
  public void H0(String paramString, Bundle paramBundle) {
    a a1 = this.a;
    if (a1 != null)
      try {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("$A$:");
        stringBuilder.append(b(paramString, paramBundle));
        a1.a(stringBuilder.toString());
        return;
      } catch (JSONException jSONException) {
        f.f().k("Unable to serialize Firebase Analytics event to breadcrumb.");
      }  
  }
  
  public void a(a parama) {
    this.a = parama;
    f.f().b("Registered Firebase Analytics event receiver for breadcrumbs");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a6\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */