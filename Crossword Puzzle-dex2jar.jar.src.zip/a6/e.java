package a6;

import android.os.Bundle;
import w5.a;

public class e implements a {
  private final a a;
  
  public e(a parama) {
    this.a = parama;
  }
  
  public void a(String paramString, Bundle paramBundle) {
    this.a.e("clx", paramString, paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a6\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */