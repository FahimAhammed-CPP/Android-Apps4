package a4;

@Deprecated
public interface a {}


/* Location:              C:\soft\dex2jar-2.0\Crossword Puzzle-dex2jar.jar!\a4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */