package a1;

import d1.g;

public abstract class b {
  public final int a;
  
  public final int b;
  
  public b(int paramInt1, int paramInt2) {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  public abstract void a(g paramg);
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\a1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */