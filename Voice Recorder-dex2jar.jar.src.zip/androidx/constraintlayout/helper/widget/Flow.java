package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.b;
import androidx.constraintlayout.widget.h;
import androidx.constraintlayout.widget.j;
import r.e;
import r.g;
import r.i;
import r.l;

public class Flow extends j {
  private g l;
  
  public Flow(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  protected void i(AttributeSet paramAttributeSet) {
    super.i(paramAttributeSet);
    this.l = new g();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, h.ConstraintLayout_Layout);
      int k = typedArray.getIndexCount();
      for (int i = 0; i < k; i++) {
        int m = typedArray.getIndex(i);
        if (m == h.ConstraintLayout_Layout_android_orientation) {
          this.l.D2(typedArray.getInt(m, 0));
        } else if (m == h.ConstraintLayout_Layout_android_padding) {
          this.l.I1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == h.ConstraintLayout_Layout_android_paddingStart) {
          this.l.N1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == h.ConstraintLayout_Layout_android_paddingEnd) {
          this.l.K1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == h.ConstraintLayout_Layout_android_paddingLeft) {
          this.l.L1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == h.ConstraintLayout_Layout_android_paddingTop) {
          this.l.O1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == h.ConstraintLayout_Layout_android_paddingRight) {
          this.l.M1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == h.ConstraintLayout_Layout_android_paddingBottom) {
          this.l.J1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_wrapMode) {
          this.l.I2(typedArray.getInt(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_horizontalStyle) {
          this.l.x2(typedArray.getInt(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_verticalStyle) {
          this.l.H2(typedArray.getInt(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_firstHorizontalStyle) {
          this.l.r2(typedArray.getInt(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_lastHorizontalStyle) {
          this.l.z2(typedArray.getInt(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_firstVerticalStyle) {
          this.l.t2(typedArray.getInt(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_lastVerticalStyle) {
          this.l.B2(typedArray.getInt(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_horizontalBias) {
          this.l.v2(typedArray.getFloat(m, 0.5F));
        } else if (m == h.ConstraintLayout_Layout_flow_firstHorizontalBias) {
          this.l.q2(typedArray.getFloat(m, 0.5F));
        } else if (m == h.ConstraintLayout_Layout_flow_lastHorizontalBias) {
          this.l.y2(typedArray.getFloat(m, 0.5F));
        } else if (m == h.ConstraintLayout_Layout_flow_firstVerticalBias) {
          this.l.s2(typedArray.getFloat(m, 0.5F));
        } else if (m == h.ConstraintLayout_Layout_flow_lastVerticalBias) {
          this.l.A2(typedArray.getFloat(m, 0.5F));
        } else if (m == h.ConstraintLayout_Layout_flow_verticalBias) {
          this.l.F2(typedArray.getFloat(m, 0.5F));
        } else if (m == h.ConstraintLayout_Layout_flow_horizontalAlign) {
          this.l.u2(typedArray.getInt(m, 2));
        } else if (m == h.ConstraintLayout_Layout_flow_verticalAlign) {
          this.l.E2(typedArray.getInt(m, 2));
        } else if (m == h.ConstraintLayout_Layout_flow_horizontalGap) {
          this.l.w2(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_verticalGap) {
          this.l.G2(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == h.ConstraintLayout_Layout_flow_maxElementsWrap) {
          this.l.C2(typedArray.getInt(m, -1));
        } 
      } 
      typedArray.recycle();
    } 
    ((b)this).d = (i)this.l;
    o();
  }
  
  public void j(e parame, boolean paramBoolean) {
    this.l.t1(paramBoolean);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    p((l)this.l, paramInt1, paramInt2);
  }
  
  public void p(l paraml, int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int k = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (paraml != null) {
      paraml.C1(i, paramInt1, k, paramInt2);
      setMeasuredDimension(paraml.x1(), paraml.w1());
      return;
    } 
    setMeasuredDimension(0, 0);
  }
  
  public void setFirstHorizontalBias(float paramFloat) {
    this.l.q2(paramFloat);
    requestLayout();
  }
  
  public void setFirstHorizontalStyle(int paramInt) {
    this.l.r2(paramInt);
    requestLayout();
  }
  
  public void setFirstVerticalBias(float paramFloat) {
    this.l.s2(paramFloat);
    requestLayout();
  }
  
  public void setFirstVerticalStyle(int paramInt) {
    this.l.t2(paramInt);
    requestLayout();
  }
  
  public void setHorizontalAlign(int paramInt) {
    this.l.u2(paramInt);
    requestLayout();
  }
  
  public void setHorizontalBias(float paramFloat) {
    this.l.v2(paramFloat);
    requestLayout();
  }
  
  public void setHorizontalGap(int paramInt) {
    this.l.w2(paramInt);
    requestLayout();
  }
  
  public void setHorizontalStyle(int paramInt) {
    this.l.x2(paramInt);
    requestLayout();
  }
  
  public void setLastHorizontalBias(float paramFloat) {
    this.l.y2(paramFloat);
    requestLayout();
  }
  
  public void setLastHorizontalStyle(int paramInt) {
    this.l.z2(paramInt);
    requestLayout();
  }
  
  public void setLastVerticalBias(float paramFloat) {
    this.l.A2(paramFloat);
    requestLayout();
  }
  
  public void setLastVerticalStyle(int paramInt) {
    this.l.B2(paramInt);
    requestLayout();
  }
  
  public void setMaxElementsWrap(int paramInt) {
    this.l.C2(paramInt);
    requestLayout();
  }
  
  public void setOrientation(int paramInt) {
    this.l.D2(paramInt);
    requestLayout();
  }
  
  public void setPadding(int paramInt) {
    this.l.I1(paramInt);
    requestLayout();
  }
  
  public void setPaddingBottom(int paramInt) {
    this.l.J1(paramInt);
    requestLayout();
  }
  
  public void setPaddingLeft(int paramInt) {
    this.l.L1(paramInt);
    requestLayout();
  }
  
  public void setPaddingRight(int paramInt) {
    this.l.M1(paramInt);
    requestLayout();
  }
  
  public void setPaddingTop(int paramInt) {
    this.l.O1(paramInt);
    requestLayout();
  }
  
  public void setVerticalAlign(int paramInt) {
    this.l.E2(paramInt);
    requestLayout();
  }
  
  public void setVerticalBias(float paramFloat) {
    this.l.F2(paramFloat);
    requestLayout();
  }
  
  public void setVerticalGap(int paramInt) {
    this.l.G2(paramInt);
    requestLayout();
  }
  
  public void setVerticalStyle(int paramInt) {
    this.l.H2(paramInt);
    requestLayout();
  }
  
  public void setWrapMode(int paramInt) {
    this.l.I2(paramInt);
    requestLayout();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\constraintlayout\helper\widget\Flow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */