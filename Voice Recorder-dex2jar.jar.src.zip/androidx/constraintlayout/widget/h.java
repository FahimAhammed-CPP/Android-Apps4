package androidx.constraintlayout.widget;

public abstract class h {
  public static final int[] ActionBar = new int[] { 
      2130968655, 2130968662, 2130968663, 2130968909, 2130968910, 2130968911, 2130968912, 2130968913, 2130968914, 2130968953, 
      2130968980, 2130968981, 2130969014, 2130969140, 2130969148, 2130969154, 2130969155, 2130969159, 2130969179, 2130969207, 
      2130969337, 2130969473, 2130969527, 2130969546, 2130969547, 2130969680, 2130969684, 2130969823, 2130969837 };
  
  public static final int[] ActionBarLayout = new int[] { 16842931 };
  
  public static final int ActionBarLayout_android_layout_gravity = 0;
  
  public static final int ActionBar_background = 0;
  
  public static final int ActionBar_backgroundSplit = 1;
  
  public static final int ActionBar_backgroundStacked = 2;
  
  public static final int ActionBar_contentInsetEnd = 3;
  
  public static final int ActionBar_contentInsetEndWithActions = 4;
  
  public static final int ActionBar_contentInsetLeft = 5;
  
  public static final int ActionBar_contentInsetRight = 6;
  
  public static final int ActionBar_contentInsetStart = 7;
  
  public static final int ActionBar_contentInsetStartWithNavigation = 8;
  
  public static final int ActionBar_customNavigationLayout = 9;
  
  public static final int ActionBar_displayOptions = 10;
  
  public static final int ActionBar_divider = 11;
  
  public static final int ActionBar_elevation = 12;
  
  public static final int ActionBar_height = 13;
  
  public static final int ActionBar_hideOnContentScroll = 14;
  
  public static final int ActionBar_homeAsUpIndicator = 15;
  
  public static final int ActionBar_homeLayout = 16;
  
  public static final int ActionBar_icon = 17;
  
  public static final int ActionBar_indeterminateProgressStyle = 18;
  
  public static final int ActionBar_itemPadding = 19;
  
  public static final int ActionBar_logo = 20;
  
  public static final int ActionBar_navigationMode = 21;
  
  public static final int ActionBar_popupTheme = 22;
  
  public static final int ActionBar_progressBarPadding = 23;
  
  public static final int ActionBar_progressBarStyle = 24;
  
  public static final int ActionBar_subtitle = 25;
  
  public static final int ActionBar_subtitleTextStyle = 26;
  
  public static final int ActionBar_title = 27;
  
  public static final int ActionBar_titleTextStyle = 28;
  
  public static final int[] ActionMenuItemView = new int[] { 16843071 };
  
  public static final int ActionMenuItemView_android_minWidth = 0;
  
  public static final int[] ActionMenuView = new int[0];
  
  public static final int[] ActionMode = new int[] { 2130968655, 2130968662, 2130968822, 2130969140, 2130969684, 2130969837 };
  
  public static final int ActionMode_background = 0;
  
  public static final int ActionMode_backgroundSplit = 1;
  
  public static final int ActionMode_closeItemLayout = 2;
  
  public static final int ActionMode_height = 3;
  
  public static final int ActionMode_subtitleTextStyle = 4;
  
  public static final int ActionMode_titleTextStyle = 5;
  
  public static final int[] ActivityChooserView = new int[] { 2130969045, 2130969189 };
  
  public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
  
  public static final int ActivityChooserView_initialActivityCount = 1;
  
  public static final int[] AlertDialog = new int[] { 16842994, 2130968728, 2130968731, 2130969324, 2130969325, 2130969464, 2130969619, 2130969627 };
  
  public static final int AlertDialog_android_layout = 0;
  
  public static final int AlertDialog_buttonIconDimen = 1;
  
  public static final int AlertDialog_buttonPanelSideLayout = 2;
  
  public static final int AlertDialog_listItemLayout = 3;
  
  public static final int AlertDialog_listLayout = 4;
  
  public static final int AlertDialog_multiChoiceItemLayout = 5;
  
  public static final int AlertDialog_showTitle = 6;
  
  public static final int AlertDialog_singleChoiceItemLayout = 7;
  
  public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
  
  public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
  
  public static final int AnimatedStateListDrawableCompat_android_dither = 0;
  
  public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
  
  public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
  
  public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
  
  public static final int AnimatedStateListDrawableCompat_android_visible = 1;
  
  public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
  
  public static final int AnimatedStateListDrawableItem_android_drawable = 1;
  
  public static final int AnimatedStateListDrawableItem_android_id = 0;
  
  public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
  
  public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
  
  public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
  
  public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
  
  public static final int AnimatedStateListDrawableTransition_android_toId = 1;
  
  public static final int[] AppCompatImageView = new int[] { 16843033, 2130969650, 2130969820, 2130969821 };
  
  public static final int AppCompatImageView_android_src = 0;
  
  public static final int AppCompatImageView_srcCompat = 1;
  
  public static final int AppCompatImageView_tint = 2;
  
  public static final int AppCompatImageView_tintMode = 3;
  
  public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130969814, 2130969815, 2130969816 };
  
  public static final int AppCompatSeekBar_android_thumb = 0;
  
  public static final int AppCompatSeekBar_tickMark = 1;
  
  public static final int AppCompatSeekBar_tickMarkTint = 2;
  
  public static final int AppCompatSeekBar_tickMarkTintMode = 3;
  
  public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
  
  public static final int AppCompatTextHelper_android_drawableBottom = 2;
  
  public static final int AppCompatTextHelper_android_drawableEnd = 6;
  
  public static final int AppCompatTextHelper_android_drawableLeft = 3;
  
  public static final int AppCompatTextHelper_android_drawableRight = 4;
  
  public static final int AppCompatTextHelper_android_drawableStart = 5;
  
  public static final int AppCompatTextHelper_android_drawableTop = 1;
  
  public static final int AppCompatTextHelper_android_textAppearance = 0;
  
  public static final int[] AppCompatTextView = new int[] { 
      16842804, 2130968649, 2130968650, 2130968651, 2130968652, 2130968653, 2130968993, 2130968994, 2130968995, 2130968996, 
      2130968998, 2130968999, 2130969000, 2130969001, 2130969018, 2130969080, 2130969116, 2130969125, 2130969234, 2130969317, 
      2130969733, 2130969788 };
  
  public static final int AppCompatTextView_android_textAppearance = 0;
  
  public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
  
  public static final int AppCompatTextView_autoSizeMinTextSize = 2;
  
  public static final int AppCompatTextView_autoSizePresetSizes = 3;
  
  public static final int AppCompatTextView_autoSizeStepGranularity = 4;
  
  public static final int AppCompatTextView_autoSizeTextType = 5;
  
  public static final int AppCompatTextView_drawableBottomCompat = 6;
  
  public static final int AppCompatTextView_drawableEndCompat = 7;
  
  public static final int AppCompatTextView_drawableLeftCompat = 8;
  
  public static final int AppCompatTextView_drawableRightCompat = 9;
  
  public static final int AppCompatTextView_drawableStartCompat = 10;
  
  public static final int AppCompatTextView_drawableTint = 11;
  
  public static final int AppCompatTextView_drawableTintMode = 12;
  
  public static final int AppCompatTextView_drawableTopCompat = 13;
  
  public static final int AppCompatTextView_emojiCompatEnabled = 14;
  
  public static final int AppCompatTextView_firstBaselineToTopHeight = 15;
  
  public static final int AppCompatTextView_fontFamily = 16;
  
  public static final int AppCompatTextView_fontVariationSettings = 17;
  
  public static final int AppCompatTextView_lastBaselineToBottomHeight = 18;
  
  public static final int AppCompatTextView_lineHeight = 19;
  
  public static final int AppCompatTextView_textAllCaps = 20;
  
  public static final int AppCompatTextView_textLocale = 21;
  
  public static final int[] AppCompatTheme = new int[] { 
      16842839, 16842926, 2130968578, 2130968579, 2130968580, 2130968581, 2130968582, 2130968583, 2130968584, 2130968585, 
      2130968586, 2130968587, 2130968588, 2130968589, 2130968590, 2130968592, 2130968593, 2130968594, 2130968595, 2130968596, 
      2130968597, 2130968598, 2130968599, 2130968600, 2130968601, 2130968602, 2130968603, 2130968604, 2130968605, 2130968606, 
      2130968607, 2130968608, 2130968609, 2130968610, 2130968615, 2130968622, 2130968623, 2130968624, 2130968625, 2130968647, 
      2130968701, 2130968720, 2130968721, 2130968722, 2130968723, 2130968724, 2130968733, 2130968734, 2130968768, 2130968779, 
      2130968835, 2130968836, 2130968837, 2130968839, 2130968840, 2130968841, 2130968843, 2130968868, 2130968870, 2130968892, 
      2130968924, 2130968971, 2130968976, 2130968977, 2130968983, 2130968988, 2130969005, 2130969006, 2130969010, 2130969011, 
      2130969013, 2130969154, 2130969173, 2130969320, 2130969321, 2130969322, 2130969323, 2130969326, 2130969327, 2130969328, 
      2130969329, 2130969330, 2130969331, 2130969332, 2130969333, 2130969334, 2130969502, 2130969503, 2130969504, 2130969526, 
      2130969528, 2130969554, 2130969556, 2130969557, 2130969558, 2130969585, 2130969590, 2130969592, 2130969593, 2130969638, 
      2130969639, 2130969696, 2130969756, 2130969758, 2130969759, 2130969760, 2130969762, 2130969763, 2130969764, 2130969765, 
      2130969776, 2130969777, 2130969840, 2130969841, 2130969843, 2130969844, 2130969891, 2130969906, 2130969907, 2130969908, 
      2130969909, 2130969910, 2130969911, 2130969912, 2130969913, 2130969914, 2130969915 };
  
  public static final int AppCompatTheme_actionBarDivider = 2;
  
  public static final int AppCompatTheme_actionBarItemBackground = 3;
  
  public static final int AppCompatTheme_actionBarPopupTheme = 4;
  
  public static final int AppCompatTheme_actionBarSize = 5;
  
  public static final int AppCompatTheme_actionBarSplitStyle = 6;
  
  public static final int AppCompatTheme_actionBarStyle = 7;
  
  public static final int AppCompatTheme_actionBarTabBarStyle = 8;
  
  public static final int AppCompatTheme_actionBarTabStyle = 9;
  
  public static final int AppCompatTheme_actionBarTabTextStyle = 10;
  
  public static final int AppCompatTheme_actionBarTheme = 11;
  
  public static final int AppCompatTheme_actionBarWidgetTheme = 12;
  
  public static final int AppCompatTheme_actionButtonStyle = 13;
  
  public static final int AppCompatTheme_actionDropDownStyle = 14;
  
  public static final int AppCompatTheme_actionMenuTextAppearance = 15;
  
  public static final int AppCompatTheme_actionMenuTextColor = 16;
  
  public static final int AppCompatTheme_actionModeBackground = 17;
  
  public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
  
  public static final int AppCompatTheme_actionModeCloseContentDescription = 19;
  
  public static final int AppCompatTheme_actionModeCloseDrawable = 20;
  
  public static final int AppCompatTheme_actionModeCopyDrawable = 21;
  
  public static final int AppCompatTheme_actionModeCutDrawable = 22;
  
  public static final int AppCompatTheme_actionModeFindDrawable = 23;
  
  public static final int AppCompatTheme_actionModePasteDrawable = 24;
  
  public static final int AppCompatTheme_actionModePopupWindowStyle = 25;
  
  public static final int AppCompatTheme_actionModeSelectAllDrawable = 26;
  
  public static final int AppCompatTheme_actionModeShareDrawable = 27;
  
  public static final int AppCompatTheme_actionModeSplitBackground = 28;
  
  public static final int AppCompatTheme_actionModeStyle = 29;
  
  public static final int AppCompatTheme_actionModeTheme = 30;
  
  public static final int AppCompatTheme_actionModeWebSearchDrawable = 31;
  
  public static final int AppCompatTheme_actionOverflowButtonStyle = 32;
  
  public static final int AppCompatTheme_actionOverflowMenuStyle = 33;
  
  public static final int AppCompatTheme_activityChooserViewStyle = 34;
  
  public static final int AppCompatTheme_alertDialogButtonGroupStyle = 35;
  
  public static final int AppCompatTheme_alertDialogCenterButtons = 36;
  
  public static final int AppCompatTheme_alertDialogStyle = 37;
  
  public static final int AppCompatTheme_alertDialogTheme = 38;
  
  public static final int AppCompatTheme_android_windowAnimationStyle = 1;
  
  public static final int AppCompatTheme_android_windowIsFloating = 0;
  
  public static final int AppCompatTheme_autoCompleteTextViewStyle = 39;
  
  public static final int AppCompatTheme_borderlessButtonStyle = 40;
  
  public static final int AppCompatTheme_buttonBarButtonStyle = 41;
  
  public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 42;
  
  public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 43;
  
  public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 44;
  
  public static final int AppCompatTheme_buttonBarStyle = 45;
  
  public static final int AppCompatTheme_buttonStyle = 46;
  
  public static final int AppCompatTheme_buttonStyleSmall = 47;
  
  public static final int AppCompatTheme_checkboxStyle = 48;
  
  public static final int AppCompatTheme_checkedTextViewStyle = 49;
  
  public static final int AppCompatTheme_colorAccent = 50;
  
  public static final int AppCompatTheme_colorBackgroundFloating = 51;
  
  public static final int AppCompatTheme_colorButtonNormal = 52;
  
  public static final int AppCompatTheme_colorControlActivated = 53;
  
  public static final int AppCompatTheme_colorControlHighlight = 54;
  
  public static final int AppCompatTheme_colorControlNormal = 55;
  
  public static final int AppCompatTheme_colorError = 56;
  
  public static final int AppCompatTheme_colorPrimary = 57;
  
  public static final int AppCompatTheme_colorPrimaryDark = 58;
  
  public static final int AppCompatTheme_colorSwitchThumbNormal = 59;
  
  public static final int AppCompatTheme_controlBackground = 60;
  
  public static final int AppCompatTheme_dialogCornerRadius = 61;
  
  public static final int AppCompatTheme_dialogPreferredPadding = 62;
  
  public static final int AppCompatTheme_dialogTheme = 63;
  
  public static final int AppCompatTheme_dividerHorizontal = 64;
  
  public static final int AppCompatTheme_dividerVertical = 65;
  
  public static final int AppCompatTheme_dropDownListViewStyle = 66;
  
  public static final int AppCompatTheme_dropdownListPreferredItemHeight = 67;
  
  public static final int AppCompatTheme_editTextBackground = 68;
  
  public static final int AppCompatTheme_editTextColor = 69;
  
  public static final int AppCompatTheme_editTextStyle = 70;
  
  public static final int AppCompatTheme_homeAsUpIndicator = 71;
  
  public static final int AppCompatTheme_imageButtonStyle = 72;
  
  public static final int AppCompatTheme_listChoiceBackgroundIndicator = 73;
  
  public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 74;
  
  public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 75;
  
  public static final int AppCompatTheme_listDividerAlertDialog = 76;
  
  public static final int AppCompatTheme_listMenuViewStyle = 77;
  
  public static final int AppCompatTheme_listPopupWindowStyle = 78;
  
  public static final int AppCompatTheme_listPreferredItemHeight = 79;
  
  public static final int AppCompatTheme_listPreferredItemHeightLarge = 80;
  
  public static final int AppCompatTheme_listPreferredItemHeightSmall = 81;
  
  public static final int AppCompatTheme_listPreferredItemPaddingEnd = 82;
  
  public static final int AppCompatTheme_listPreferredItemPaddingLeft = 83;
  
  public static final int AppCompatTheme_listPreferredItemPaddingRight = 84;
  
  public static final int AppCompatTheme_listPreferredItemPaddingStart = 85;
  
  public static final int AppCompatTheme_panelBackground = 86;
  
  public static final int AppCompatTheme_panelMenuListTheme = 87;
  
  public static final int AppCompatTheme_panelMenuListWidth = 88;
  
  public static final int AppCompatTheme_popupMenuStyle = 89;
  
  public static final int AppCompatTheme_popupWindowStyle = 90;
  
  public static final int AppCompatTheme_radioButtonStyle = 91;
  
  public static final int AppCompatTheme_ratingBarStyle = 92;
  
  public static final int AppCompatTheme_ratingBarStyleIndicator = 93;
  
  public static final int AppCompatTheme_ratingBarStyleSmall = 94;
  
  public static final int AppCompatTheme_searchViewStyle = 95;
  
  public static final int AppCompatTheme_seekBarStyle = 96;
  
  public static final int AppCompatTheme_selectableItemBackground = 97;
  
  public static final int AppCompatTheme_selectableItemBackgroundBorderless = 98;
  
  public static final int AppCompatTheme_spinnerDropDownItemStyle = 99;
  
  public static final int AppCompatTheme_spinnerStyle = 100;
  
  public static final int AppCompatTheme_switchStyle = 101;
  
  public static final int AppCompatTheme_textAppearanceLargePopupMenu = 102;
  
  public static final int AppCompatTheme_textAppearanceListItem = 103;
  
  public static final int AppCompatTheme_textAppearanceListItemSecondary = 104;
  
  public static final int AppCompatTheme_textAppearanceListItemSmall = 105;
  
  public static final int AppCompatTheme_textAppearancePopupMenuHeader = 106;
  
  public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 107;
  
  public static final int AppCompatTheme_textAppearanceSearchResultTitle = 108;
  
  public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 109;
  
  public static final int AppCompatTheme_textColorAlertDialogListItem = 110;
  
  public static final int AppCompatTheme_textColorSearchUrl = 111;
  
  public static final int AppCompatTheme_toolbarNavigationButtonStyle = 112;
  
  public static final int AppCompatTheme_toolbarStyle = 113;
  
  public static final int AppCompatTheme_tooltipForegroundColor = 114;
  
  public static final int AppCompatTheme_tooltipFrameBackground = 115;
  
  public static final int AppCompatTheme_viewInflaterClass = 116;
  
  public static final int AppCompatTheme_windowActionBar = 117;
  
  public static final int AppCompatTheme_windowActionBarOverlay = 118;
  
  public static final int AppCompatTheme_windowActionModeOverlay = 119;
  
  public static final int AppCompatTheme_windowFixedHeightMajor = 120;
  
  public static final int AppCompatTheme_windowFixedHeightMinor = 121;
  
  public static final int AppCompatTheme_windowFixedWidthMajor = 122;
  
  public static final int AppCompatTheme_windowFixedWidthMinor = 123;
  
  public static final int AppCompatTheme_windowMinWidthMajor = 124;
  
  public static final int AppCompatTheme_windowMinWidthMinor = 125;
  
  public static final int AppCompatTheme_windowNoTitle = 126;
  
  public static final int[] ButtonBarLayout = new int[] { 2130968629 };
  
  public static final int ButtonBarLayout_allowStacking = 0;
  
  public static final int[] Carousel = new int[] { 2130968752, 2130968753, 2130968754, 2130968755, 2130968756, 2130968757, 2130968758, 2130968759, 2130968760, 2130968761 };
  
  public static final int Carousel_carousel_backwardTransition = 0;
  
  public static final int Carousel_carousel_emptyViewsBehavior = 1;
  
  public static final int Carousel_carousel_firstView = 2;
  
  public static final int Carousel_carousel_forwardTransition = 3;
  
  public static final int Carousel_carousel_infinite = 4;
  
  public static final int Carousel_carousel_nextState = 5;
  
  public static final int Carousel_carousel_previousState = 6;
  
  public static final int Carousel_carousel_touchUpMode = 7;
  
  public static final int Carousel_carousel_touchUp_dampeningFactor = 8;
  
  public static final int Carousel_carousel_touchUp_velocityThreshold = 9;
  
  public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130968630, 2130969230 };
  
  public static final int ColorStateListItem_alpha = 3;
  
  public static final int ColorStateListItem_android_alpha = 1;
  
  public static final int ColorStateListItem_android_color = 0;
  
  public static final int ColorStateListItem_android_lStar = 2;
  
  public static final int ColorStateListItem_lStar = 4;
  
  public static final int[] CompoundButton = new int[] { 16843015, 2130968725, 2130968735, 2130968736 };
  
  public static final int CompoundButton_android_button = 0;
  
  public static final int CompoundButton_buttonCompat = 1;
  
  public static final int CompoundButton_buttonTint = 2;
  
  public static final int CompoundButton_buttonTintMode = 3;
  
  public static final int[] Constraint = new int[] { 
      16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
      16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
      16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130968635, 2130968638, 2130968682, 
      2130968683, 2130968684, 2130968763, 2130968904, 2130968905, 2130968992, 2130969096, 2130969097, 2130969098, 2130969099, 
      2130969100, 2130969101, 2130969102, 2130969103, 2130969104, 2130969105, 2130969106, 2130969107, 2130969108, 2130969110, 
      2130969111, 2130969112, 2130969113, 2130969114, 2130969136, 2130969249, 2130969250, 2130969251, 2130969252, 2130969253, 
      2130969254, 2130969255, 2130969256, 2130969257, 2130969258, 2130969259, 2130969260, 2130969261, 2130969262, 2130969263, 
      2130969264, 2130969265, 2130969266, 2130969267, 2130969268, 2130969269, 2130969270, 2130969271, 2130969272, 2130969273, 
      2130969274, 2130969275, 2130969276, 2130969277, 2130969278, 2130969279, 2130969280, 2130969281, 2130969282, 2130969283, 
      2130969284, 2130969285, 2130969286, 2130969287, 2130969288, 2130969289, 2130969290, 2130969291, 2130969292, 2130969293, 
      2130969294, 2130969296, 2130969297, 2130969298, 2130969299, 2130969300, 2130969301, 2130969302, 2130969303, 2130969304, 
      2130969307, 2130969312, 2130969458, 2130969459, 2130969510, 2130969518, 2130969524, 2130969548, 2130969549, 2130969550, 
      2130969863, 2130969865, 2130969867, 2130969896 };
  
  public static final int[] ConstraintLayout_Layout = new int[] { 
      16842948, 16842965, 16842966, 16842967, 16842968, 16842969, 16842972, 16842996, 16842997, 16842998, 
      16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843699, 16843700, 
      16843701, 16843702, 16843840, 16844091, 16844092, 2130968682, 2130968683, 2130968684, 2130968763, 2130968803, 
      2130968804, 2130968805, 2130968806, 2130968807, 2130968901, 2130968904, 2130968905, 2130969096, 2130969097, 2130969098, 
      2130969099, 2130969100, 2130969101, 2130969102, 2130969103, 2130969104, 2130969105, 2130969106, 2130969107, 2130969108, 
      2130969110, 2130969111, 2130969112, 2130969113, 2130969114, 2130969136, 2130969241, 2130969249, 2130969250, 2130969251, 
      2130969252, 2130969253, 2130969254, 2130969255, 2130969256, 2130969257, 2130969258, 2130969259, 2130969260, 2130969261, 
      2130969262, 2130969263, 2130969264, 2130969265, 2130969266, 2130969267, 2130969268, 2130969269, 2130969270, 2130969271, 
      2130969272, 2130969273, 2130969274, 2130969275, 2130969276, 2130969277, 2130969278, 2130969279, 2130969280, 2130969281, 
      2130969282, 2130969283, 2130969284, 2130969285, 2130969286, 2130969287, 2130969288, 2130969289, 2130969290, 2130969291, 
      2130969292, 2130969293, 2130969294, 2130969296, 2130969297, 2130969298, 2130969299, 2130969300, 2130969301, 2130969302, 
      2130969303, 2130969304, 2130969307, 2130969308, 2130969312 };
  
  public static final int ConstraintLayout_Layout_android_elevation = 22;
  
  public static final int ConstraintLayout_Layout_android_layout_height = 8;
  
  public static final int ConstraintLayout_Layout_android_layout_margin = 9;
  
  public static final int ConstraintLayout_Layout_android_layout_marginBottom = 13;
  
  public static final int ConstraintLayout_Layout_android_layout_marginEnd = 21;
  
  public static final int ConstraintLayout_Layout_android_layout_marginHorizontal = 23;
  
  public static final int ConstraintLayout_Layout_android_layout_marginLeft = 10;
  
  public static final int ConstraintLayout_Layout_android_layout_marginRight = 12;
  
  public static final int ConstraintLayout_Layout_android_layout_marginStart = 20;
  
  public static final int ConstraintLayout_Layout_android_layout_marginTop = 11;
  
  public static final int ConstraintLayout_Layout_android_layout_marginVertical = 24;
  
  public static final int ConstraintLayout_Layout_android_layout_width = 7;
  
  public static final int ConstraintLayout_Layout_android_maxHeight = 15;
  
  public static final int ConstraintLayout_Layout_android_maxWidth = 14;
  
  public static final int ConstraintLayout_Layout_android_minHeight = 17;
  
  public static final int ConstraintLayout_Layout_android_minWidth = 16;
  
  public static final int ConstraintLayout_Layout_android_orientation = 0;
  
  public static final int ConstraintLayout_Layout_android_padding = 1;
  
  public static final int ConstraintLayout_Layout_android_paddingBottom = 5;
  
  public static final int ConstraintLayout_Layout_android_paddingEnd = 19;
  
  public static final int ConstraintLayout_Layout_android_paddingLeft = 2;
  
  public static final int ConstraintLayout_Layout_android_paddingRight = 4;
  
  public static final int ConstraintLayout_Layout_android_paddingStart = 18;
  
  public static final int ConstraintLayout_Layout_android_paddingTop = 3;
  
  public static final int ConstraintLayout_Layout_android_visibility = 6;
  
  public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 25;
  
  public static final int ConstraintLayout_Layout_barrierDirection = 26;
  
  public static final int ConstraintLayout_Layout_barrierMargin = 27;
  
  public static final int ConstraintLayout_Layout_chainUseRtl = 28;
  
  public static final int ConstraintLayout_Layout_circularflow_angles = 29;
  
  public static final int ConstraintLayout_Layout_circularflow_defaultAngle = 30;
  
  public static final int ConstraintLayout_Layout_circularflow_defaultRadius = 31;
  
  public static final int ConstraintLayout_Layout_circularflow_radiusInDP = 32;
  
  public static final int ConstraintLayout_Layout_circularflow_viewCenter = 33;
  
  public static final int ConstraintLayout_Layout_constraintSet = 34;
  
  public static final int ConstraintLayout_Layout_constraint_referenced_ids = 35;
  
  public static final int ConstraintLayout_Layout_constraint_referenced_tags = 36;
  
  public static final int ConstraintLayout_Layout_flow_firstHorizontalBias = 37;
  
  public static final int ConstraintLayout_Layout_flow_firstHorizontalStyle = 38;
  
  public static final int ConstraintLayout_Layout_flow_firstVerticalBias = 39;
  
  public static final int ConstraintLayout_Layout_flow_firstVerticalStyle = 40;
  
  public static final int ConstraintLayout_Layout_flow_horizontalAlign = 41;
  
  public static final int ConstraintLayout_Layout_flow_horizontalBias = 42;
  
  public static final int ConstraintLayout_Layout_flow_horizontalGap = 43;
  
  public static final int ConstraintLayout_Layout_flow_horizontalStyle = 44;
  
  public static final int ConstraintLayout_Layout_flow_lastHorizontalBias = 45;
  
  public static final int ConstraintLayout_Layout_flow_lastHorizontalStyle = 46;
  
  public static final int ConstraintLayout_Layout_flow_lastVerticalBias = 47;
  
  public static final int ConstraintLayout_Layout_flow_lastVerticalStyle = 48;
  
  public static final int ConstraintLayout_Layout_flow_maxElementsWrap = 49;
  
  public static final int ConstraintLayout_Layout_flow_verticalAlign = 50;
  
  public static final int ConstraintLayout_Layout_flow_verticalBias = 51;
  
  public static final int ConstraintLayout_Layout_flow_verticalGap = 52;
  
  public static final int ConstraintLayout_Layout_flow_verticalStyle = 53;
  
  public static final int ConstraintLayout_Layout_flow_wrapMode = 54;
  
  public static final int ConstraintLayout_Layout_guidelineUseRtl = 55;
  
  public static final int ConstraintLayout_Layout_layoutDescription = 56;
  
  public static final int ConstraintLayout_Layout_layout_constrainedHeight = 57;
  
  public static final int ConstraintLayout_Layout_layout_constrainedWidth = 58;
  
  public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 59;
  
  public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 60;
  
  public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf = 61;
  
  public static final int ConstraintLayout_Layout_layout_constraintBaseline_toTopOf = 62;
  
  public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 63;
  
  public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 64;
  
  public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 65;
  
  public static final int ConstraintLayout_Layout_layout_constraintCircle = 66;
  
  public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 67;
  
  public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 68;
  
  public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 69;
  
  public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 70;
  
  public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 71;
  
  public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 72;
  
  public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 73;
  
  public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 74;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight = 75;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 76;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 77;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 78;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 79;
  
  public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 80;
  
  public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 81;
  
  public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 82;
  
  public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 83;
  
  public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 84;
  
  public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 85;
  
  public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 86;
  
  public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 87;
  
  public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 88;
  
  public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 89;
  
  public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 90;
  
  public static final int ConstraintLayout_Layout_layout_constraintTag = 91;
  
  public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 92;
  
  public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 93;
  
  public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 94;
  
  public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 95;
  
  public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 96;
  
  public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 97;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth = 98;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 99;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 100;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 101;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 102;
  
  public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 103;
  
  public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 104;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginBaseline = 105;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 106;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 107;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 108;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginRight = 109;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginStart = 110;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginTop = 111;
  
  public static final int ConstraintLayout_Layout_layout_marginBaseline = 112;
  
  public static final int ConstraintLayout_Layout_layout_optimizationLevel = 113;
  
  public static final int ConstraintLayout_Layout_layout_wrapBehaviorInParent = 114;
  
  public static final int[] ConstraintLayout_ReactiveGuide = new int[] { 2130969559, 2130969560, 2130969561, 2130969562 };
  
  public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_animateChange = 0;
  
  public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_applyToAllConstraintSets = 1;
  
  public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_applyToConstraintSet = 2;
  
  public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_valueId = 3;
  
  public static final int[] ConstraintLayout_placeholder = new int[] { 2130968907, 2130969523 };
  
  public static final int ConstraintLayout_placeholder_content = 0;
  
  public static final int ConstraintLayout_placeholder_placeholder_emptyVisibility = 1;
  
  public static final int[] ConstraintOverride = new int[] { 
      16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
      16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
      16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130968635, 2130968638, 2130968682, 
      2130968683, 2130968684, 2130968763, 2130968904, 2130968992, 2130969096, 2130969097, 2130969098, 2130969099, 2130969100, 
      2130969101, 2130969102, 2130969103, 2130969104, 2130969105, 2130969106, 2130969107, 2130969108, 2130969110, 2130969111, 
      2130969112, 2130969113, 2130969114, 2130969136, 2130969249, 2130969250, 2130969251, 2130969255, 2130969259, 2130969260, 
      2130969261, 2130969264, 2130969265, 2130969266, 2130969267, 2130969268, 2130969269, 2130969270, 2130969271, 2130969272, 
      2130969273, 2130969274, 2130969275, 2130969278, 2130969283, 2130969284, 2130969287, 2130969288, 2130969289, 2130969290, 
      2130969291, 2130969292, 2130969293, 2130969294, 2130969296, 2130969297, 2130969298, 2130969299, 2130969300, 2130969301, 
      2130969302, 2130969303, 2130969304, 2130969307, 2130969312, 2130969458, 2130969459, 2130969460, 2130969510, 2130969518, 
      2130969524, 2130969548, 2130969549, 2130969550, 2130969863, 2130969865, 2130969867, 2130969896 };
  
  public static final int ConstraintOverride_android_alpha = 13;
  
  public static final int ConstraintOverride_android_elevation = 26;
  
  public static final int ConstraintOverride_android_id = 1;
  
  public static final int ConstraintOverride_android_layout_height = 4;
  
  public static final int ConstraintOverride_android_layout_marginBottom = 8;
  
  public static final int ConstraintOverride_android_layout_marginEnd = 24;
  
  public static final int ConstraintOverride_android_layout_marginLeft = 5;
  
  public static final int ConstraintOverride_android_layout_marginRight = 7;
  
  public static final int ConstraintOverride_android_layout_marginStart = 23;
  
  public static final int ConstraintOverride_android_layout_marginTop = 6;
  
  public static final int ConstraintOverride_android_layout_width = 3;
  
  public static final int ConstraintOverride_android_maxHeight = 10;
  
  public static final int ConstraintOverride_android_maxWidth = 9;
  
  public static final int ConstraintOverride_android_minHeight = 12;
  
  public static final int ConstraintOverride_android_minWidth = 11;
  
  public static final int ConstraintOverride_android_orientation = 0;
  
  public static final int ConstraintOverride_android_rotation = 20;
  
  public static final int ConstraintOverride_android_rotationX = 21;
  
  public static final int ConstraintOverride_android_rotationY = 22;
  
  public static final int ConstraintOverride_android_scaleX = 18;
  
  public static final int ConstraintOverride_android_scaleY = 19;
  
  public static final int ConstraintOverride_android_transformPivotX = 14;
  
  public static final int ConstraintOverride_android_transformPivotY = 15;
  
  public static final int ConstraintOverride_android_translationX = 16;
  
  public static final int ConstraintOverride_android_translationY = 17;
  
  public static final int ConstraintOverride_android_translationZ = 25;
  
  public static final int ConstraintOverride_android_visibility = 2;
  
  public static final int ConstraintOverride_animateCircleAngleTo = 27;
  
  public static final int ConstraintOverride_animateRelativeTo = 28;
  
  public static final int ConstraintOverride_barrierAllowsGoneWidgets = 29;
  
  public static final int ConstraintOverride_barrierDirection = 30;
  
  public static final int ConstraintOverride_barrierMargin = 31;
  
  public static final int ConstraintOverride_chainUseRtl = 32;
  
  public static final int ConstraintOverride_constraint_referenced_ids = 33;
  
  public static final int ConstraintOverride_drawPath = 34;
  
  public static final int ConstraintOverride_flow_firstHorizontalBias = 35;
  
  public static final int ConstraintOverride_flow_firstHorizontalStyle = 36;
  
  public static final int ConstraintOverride_flow_firstVerticalBias = 37;
  
  public static final int ConstraintOverride_flow_firstVerticalStyle = 38;
  
  public static final int ConstraintOverride_flow_horizontalAlign = 39;
  
  public static final int ConstraintOverride_flow_horizontalBias = 40;
  
  public static final int ConstraintOverride_flow_horizontalGap = 41;
  
  public static final int ConstraintOverride_flow_horizontalStyle = 42;
  
  public static final int ConstraintOverride_flow_lastHorizontalBias = 43;
  
  public static final int ConstraintOverride_flow_lastHorizontalStyle = 44;
  
  public static final int ConstraintOverride_flow_lastVerticalBias = 45;
  
  public static final int ConstraintOverride_flow_lastVerticalStyle = 46;
  
  public static final int ConstraintOverride_flow_maxElementsWrap = 47;
  
  public static final int ConstraintOverride_flow_verticalAlign = 48;
  
  public static final int ConstraintOverride_flow_verticalBias = 49;
  
  public static final int ConstraintOverride_flow_verticalGap = 50;
  
  public static final int ConstraintOverride_flow_verticalStyle = 51;
  
  public static final int ConstraintOverride_flow_wrapMode = 52;
  
  public static final int ConstraintOverride_guidelineUseRtl = 53;
  
  public static final int ConstraintOverride_layout_constrainedHeight = 54;
  
  public static final int ConstraintOverride_layout_constrainedWidth = 55;
  
  public static final int ConstraintOverride_layout_constraintBaseline_creator = 56;
  
  public static final int ConstraintOverride_layout_constraintBottom_creator = 57;
  
  public static final int ConstraintOverride_layout_constraintCircleAngle = 58;
  
  public static final int ConstraintOverride_layout_constraintCircleRadius = 59;
  
  public static final int ConstraintOverride_layout_constraintDimensionRatio = 60;
  
  public static final int ConstraintOverride_layout_constraintGuide_begin = 61;
  
  public static final int ConstraintOverride_layout_constraintGuide_end = 62;
  
  public static final int ConstraintOverride_layout_constraintGuide_percent = 63;
  
  public static final int ConstraintOverride_layout_constraintHeight = 64;
  
  public static final int ConstraintOverride_layout_constraintHeight_default = 65;
  
  public static final int ConstraintOverride_layout_constraintHeight_max = 66;
  
  public static final int ConstraintOverride_layout_constraintHeight_min = 67;
  
  public static final int ConstraintOverride_layout_constraintHeight_percent = 68;
  
  public static final int ConstraintOverride_layout_constraintHorizontal_bias = 69;
  
  public static final int ConstraintOverride_layout_constraintHorizontal_chainStyle = 70;
  
  public static final int ConstraintOverride_layout_constraintHorizontal_weight = 71;
  
  public static final int ConstraintOverride_layout_constraintLeft_creator = 72;
  
  public static final int ConstraintOverride_layout_constraintRight_creator = 73;
  
  public static final int ConstraintOverride_layout_constraintTag = 74;
  
  public static final int ConstraintOverride_layout_constraintTop_creator = 75;
  
  public static final int ConstraintOverride_layout_constraintVertical_bias = 76;
  
  public static final int ConstraintOverride_layout_constraintVertical_chainStyle = 77;
  
  public static final int ConstraintOverride_layout_constraintVertical_weight = 78;
  
  public static final int ConstraintOverride_layout_constraintWidth = 79;
  
  public static final int ConstraintOverride_layout_constraintWidth_default = 80;
  
  public static final int ConstraintOverride_layout_constraintWidth_max = 81;
  
  public static final int ConstraintOverride_layout_constraintWidth_min = 82;
  
  public static final int ConstraintOverride_layout_constraintWidth_percent = 83;
  
  public static final int ConstraintOverride_layout_editor_absoluteX = 84;
  
  public static final int ConstraintOverride_layout_editor_absoluteY = 85;
  
  public static final int ConstraintOverride_layout_goneMarginBaseline = 86;
  
  public static final int ConstraintOverride_layout_goneMarginBottom = 87;
  
  public static final int ConstraintOverride_layout_goneMarginEnd = 88;
  
  public static final int ConstraintOverride_layout_goneMarginLeft = 89;
  
  public static final int ConstraintOverride_layout_goneMarginRight = 90;
  
  public static final int ConstraintOverride_layout_goneMarginStart = 91;
  
  public static final int ConstraintOverride_layout_goneMarginTop = 92;
  
  public static final int ConstraintOverride_layout_marginBaseline = 93;
  
  public static final int ConstraintOverride_layout_wrapBehaviorInParent = 94;
  
  public static final int ConstraintOverride_motionProgress = 95;
  
  public static final int ConstraintOverride_motionStagger = 96;
  
  public static final int ConstraintOverride_motionTarget = 97;
  
  public static final int ConstraintOverride_pathMotionArc = 98;
  
  public static final int ConstraintOverride_pivotAnchor = 99;
  
  public static final int ConstraintOverride_polarRelativeTo = 100;
  
  public static final int ConstraintOverride_quantizeMotionInterpolator = 101;
  
  public static final int ConstraintOverride_quantizeMotionPhase = 102;
  
  public static final int ConstraintOverride_quantizeMotionSteps = 103;
  
  public static final int ConstraintOverride_transformPivotTarget = 104;
  
  public static final int ConstraintOverride_transitionEasing = 105;
  
  public static final int ConstraintOverride_transitionPathRotate = 106;
  
  public static final int ConstraintOverride_visibilityMode = 107;
  
  public static final int[] ConstraintSet = new int[] { 
      16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
      16843040, 16843071, 16843072, 16843189, 16843190, 16843551, 16843552, 16843553, 16843554, 16843555, 
      16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130968635, 
      2130968638, 2130968682, 2130968683, 2130968684, 2130968763, 2130968900, 2130968904, 2130968905, 2130968970, 2130968992, 
      2130969096, 2130969097, 2130969098, 2130969099, 2130969100, 2130969101, 2130969102, 2130969103, 2130969104, 2130969105, 
      2130969106, 2130969107, 2130969108, 2130969110, 2130969111, 2130969112, 2130969113, 2130969114, 2130969136, 2130969249, 
      2130969250, 2130969251, 2130969252, 2130969253, 2130969254, 2130969255, 2130969256, 2130969257, 2130969258, 2130969259, 
      2130969260, 2130969261, 2130969262, 2130969263, 2130969264, 2130969265, 2130969266, 2130969268, 2130969269, 2130969270, 
      2130969271, 2130969272, 2130969273, 2130969274, 2130969275, 2130969276, 2130969277, 2130969278, 2130969279, 2130969280, 
      2130969281, 2130969282, 2130969283, 2130969284, 2130969285, 2130969286, 2130969287, 2130969288, 2130969289, 2130969291, 
      2130969292, 2130969293, 2130969294, 2130969296, 2130969297, 2130969298, 2130969299, 2130969300, 2130969301, 2130969302, 
      2130969303, 2130969304, 2130969307, 2130969312, 2130969458, 2130969459, 2130969510, 2130969518, 2130969524, 2130969550, 
      2130969865, 2130969867 };
  
  public static final int ConstraintSet_android_alpha = 15;
  
  public static final int ConstraintSet_android_elevation = 28;
  
  public static final int ConstraintSet_android_id = 1;
  
  public static final int ConstraintSet_android_layout_height = 4;
  
  public static final int ConstraintSet_android_layout_marginBottom = 8;
  
  public static final int ConstraintSet_android_layout_marginEnd = 26;
  
  public static final int ConstraintSet_android_layout_marginLeft = 5;
  
  public static final int ConstraintSet_android_layout_marginRight = 7;
  
  public static final int ConstraintSet_android_layout_marginStart = 25;
  
  public static final int ConstraintSet_android_layout_marginTop = 6;
  
  public static final int ConstraintSet_android_layout_width = 3;
  
  public static final int ConstraintSet_android_maxHeight = 10;
  
  public static final int ConstraintSet_android_maxWidth = 9;
  
  public static final int ConstraintSet_android_minHeight = 12;
  
  public static final int ConstraintSet_android_minWidth = 11;
  
  public static final int ConstraintSet_android_orientation = 0;
  
  public static final int ConstraintSet_android_pivotX = 13;
  
  public static final int ConstraintSet_android_pivotY = 14;
  
  public static final int ConstraintSet_android_rotation = 22;
  
  public static final int ConstraintSet_android_rotationX = 23;
  
  public static final int ConstraintSet_android_rotationY = 24;
  
  public static final int ConstraintSet_android_scaleX = 20;
  
  public static final int ConstraintSet_android_scaleY = 21;
  
  public static final int ConstraintSet_android_transformPivotX = 16;
  
  public static final int ConstraintSet_android_transformPivotY = 17;
  
  public static final int ConstraintSet_android_translationX = 18;
  
  public static final int ConstraintSet_android_translationY = 19;
  
  public static final int ConstraintSet_android_translationZ = 27;
  
  public static final int ConstraintSet_android_visibility = 2;
  
  public static final int ConstraintSet_animateCircleAngleTo = 29;
  
  public static final int ConstraintSet_animateRelativeTo = 30;
  
  public static final int ConstraintSet_barrierAllowsGoneWidgets = 31;
  
  public static final int ConstraintSet_barrierDirection = 32;
  
  public static final int ConstraintSet_barrierMargin = 33;
  
  public static final int ConstraintSet_chainUseRtl = 34;
  
  public static final int ConstraintSet_constraintRotate = 35;
  
  public static final int ConstraintSet_constraint_referenced_ids = 36;
  
  public static final int ConstraintSet_constraint_referenced_tags = 37;
  
  public static final int ConstraintSet_deriveConstraintsFrom = 38;
  
  public static final int ConstraintSet_drawPath = 39;
  
  public static final int ConstraintSet_flow_firstHorizontalBias = 40;
  
  public static final int ConstraintSet_flow_firstHorizontalStyle = 41;
  
  public static final int ConstraintSet_flow_firstVerticalBias = 42;
  
  public static final int ConstraintSet_flow_firstVerticalStyle = 43;
  
  public static final int ConstraintSet_flow_horizontalAlign = 44;
  
  public static final int ConstraintSet_flow_horizontalBias = 45;
  
  public static final int ConstraintSet_flow_horizontalGap = 46;
  
  public static final int ConstraintSet_flow_horizontalStyle = 47;
  
  public static final int ConstraintSet_flow_lastHorizontalBias = 48;
  
  public static final int ConstraintSet_flow_lastHorizontalStyle = 49;
  
  public static final int ConstraintSet_flow_lastVerticalBias = 50;
  
  public static final int ConstraintSet_flow_lastVerticalStyle = 51;
  
  public static final int ConstraintSet_flow_maxElementsWrap = 52;
  
  public static final int ConstraintSet_flow_verticalAlign = 53;
  
  public static final int ConstraintSet_flow_verticalBias = 54;
  
  public static final int ConstraintSet_flow_verticalGap = 55;
  
  public static final int ConstraintSet_flow_verticalStyle = 56;
  
  public static final int ConstraintSet_flow_wrapMode = 57;
  
  public static final int ConstraintSet_guidelineUseRtl = 58;
  
  public static final int ConstraintSet_layout_constrainedHeight = 59;
  
  public static final int ConstraintSet_layout_constrainedWidth = 60;
  
  public static final int ConstraintSet_layout_constraintBaseline_creator = 61;
  
  public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 62;
  
  public static final int ConstraintSet_layout_constraintBaseline_toBottomOf = 63;
  
  public static final int ConstraintSet_layout_constraintBaseline_toTopOf = 64;
  
  public static final int ConstraintSet_layout_constraintBottom_creator = 65;
  
  public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 66;
  
  public static final int ConstraintSet_layout_constraintBottom_toTopOf = 67;
  
  public static final int ConstraintSet_layout_constraintCircle = 68;
  
  public static final int ConstraintSet_layout_constraintCircleAngle = 69;
  
  public static final int ConstraintSet_layout_constraintCircleRadius = 70;
  
  public static final int ConstraintSet_layout_constraintDimensionRatio = 71;
  
  public static final int ConstraintSet_layout_constraintEnd_toEndOf = 72;
  
  public static final int ConstraintSet_layout_constraintEnd_toStartOf = 73;
  
  public static final int ConstraintSet_layout_constraintGuide_begin = 74;
  
  public static final int ConstraintSet_layout_constraintGuide_end = 75;
  
  public static final int ConstraintSet_layout_constraintGuide_percent = 76;
  
  public static final int ConstraintSet_layout_constraintHeight_default = 77;
  
  public static final int ConstraintSet_layout_constraintHeight_max = 78;
  
  public static final int ConstraintSet_layout_constraintHeight_min = 79;
  
  public static final int ConstraintSet_layout_constraintHeight_percent = 80;
  
  public static final int ConstraintSet_layout_constraintHorizontal_bias = 81;
  
  public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 82;
  
  public static final int ConstraintSet_layout_constraintHorizontal_weight = 83;
  
  public static final int ConstraintSet_layout_constraintLeft_creator = 84;
  
  public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 85;
  
  public static final int ConstraintSet_layout_constraintLeft_toRightOf = 86;
  
  public static final int ConstraintSet_layout_constraintRight_creator = 87;
  
  public static final int ConstraintSet_layout_constraintRight_toLeftOf = 88;
  
  public static final int ConstraintSet_layout_constraintRight_toRightOf = 89;
  
  public static final int ConstraintSet_layout_constraintStart_toEndOf = 90;
  
  public static final int ConstraintSet_layout_constraintStart_toStartOf = 91;
  
  public static final int ConstraintSet_layout_constraintTag = 92;
  
  public static final int ConstraintSet_layout_constraintTop_creator = 93;
  
  public static final int ConstraintSet_layout_constraintTop_toBottomOf = 94;
  
  public static final int ConstraintSet_layout_constraintTop_toTopOf = 95;
  
  public static final int ConstraintSet_layout_constraintVertical_bias = 96;
  
  public static final int ConstraintSet_layout_constraintVertical_chainStyle = 97;
  
  public static final int ConstraintSet_layout_constraintVertical_weight = 98;
  
  public static final int ConstraintSet_layout_constraintWidth_default = 99;
  
  public static final int ConstraintSet_layout_constraintWidth_max = 100;
  
  public static final int ConstraintSet_layout_constraintWidth_min = 101;
  
  public static final int ConstraintSet_layout_constraintWidth_percent = 102;
  
  public static final int ConstraintSet_layout_editor_absoluteX = 103;
  
  public static final int ConstraintSet_layout_editor_absoluteY = 104;
  
  public static final int ConstraintSet_layout_goneMarginBaseline = 105;
  
  public static final int ConstraintSet_layout_goneMarginBottom = 106;
  
  public static final int ConstraintSet_layout_goneMarginEnd = 107;
  
  public static final int ConstraintSet_layout_goneMarginLeft = 108;
  
  public static final int ConstraintSet_layout_goneMarginRight = 109;
  
  public static final int ConstraintSet_layout_goneMarginStart = 110;
  
  public static final int ConstraintSet_layout_goneMarginTop = 111;
  
  public static final int ConstraintSet_layout_marginBaseline = 112;
  
  public static final int ConstraintSet_layout_wrapBehaviorInParent = 113;
  
  public static final int ConstraintSet_motionProgress = 114;
  
  public static final int ConstraintSet_motionStagger = 115;
  
  public static final int ConstraintSet_pathMotionArc = 116;
  
  public static final int ConstraintSet_pivotAnchor = 117;
  
  public static final int ConstraintSet_polarRelativeTo = 118;
  
  public static final int ConstraintSet_quantizeMotionSteps = 119;
  
  public static final int ConstraintSet_transitionEasing = 120;
  
  public static final int ConstraintSet_transitionPathRotate = 121;
  
  public static final int Constraint_android_alpha = 13;
  
  public static final int Constraint_android_elevation = 26;
  
  public static final int Constraint_android_id = 1;
  
  public static final int Constraint_android_layout_height = 4;
  
  public static final int Constraint_android_layout_marginBottom = 8;
  
  public static final int Constraint_android_layout_marginEnd = 24;
  
  public static final int Constraint_android_layout_marginLeft = 5;
  
  public static final int Constraint_android_layout_marginRight = 7;
  
  public static final int Constraint_android_layout_marginStart = 23;
  
  public static final int Constraint_android_layout_marginTop = 6;
  
  public static final int Constraint_android_layout_width = 3;
  
  public static final int Constraint_android_maxHeight = 10;
  
  public static final int Constraint_android_maxWidth = 9;
  
  public static final int Constraint_android_minHeight = 12;
  
  public static final int Constraint_android_minWidth = 11;
  
  public static final int Constraint_android_orientation = 0;
  
  public static final int Constraint_android_rotation = 20;
  
  public static final int Constraint_android_rotationX = 21;
  
  public static final int Constraint_android_rotationY = 22;
  
  public static final int Constraint_android_scaleX = 18;
  
  public static final int Constraint_android_scaleY = 19;
  
  public static final int Constraint_android_transformPivotX = 14;
  
  public static final int Constraint_android_transformPivotY = 15;
  
  public static final int Constraint_android_translationX = 16;
  
  public static final int Constraint_android_translationY = 17;
  
  public static final int Constraint_android_translationZ = 25;
  
  public static final int Constraint_android_visibility = 2;
  
  public static final int Constraint_animateCircleAngleTo = 27;
  
  public static final int Constraint_animateRelativeTo = 28;
  
  public static final int Constraint_barrierAllowsGoneWidgets = 29;
  
  public static final int Constraint_barrierDirection = 30;
  
  public static final int Constraint_barrierMargin = 31;
  
  public static final int Constraint_chainUseRtl = 32;
  
  public static final int Constraint_constraint_referenced_ids = 33;
  
  public static final int Constraint_constraint_referenced_tags = 34;
  
  public static final int Constraint_drawPath = 35;
  
  public static final int Constraint_flow_firstHorizontalBias = 36;
  
  public static final int Constraint_flow_firstHorizontalStyle = 37;
  
  public static final int Constraint_flow_firstVerticalBias = 38;
  
  public static final int Constraint_flow_firstVerticalStyle = 39;
  
  public static final int Constraint_flow_horizontalAlign = 40;
  
  public static final int Constraint_flow_horizontalBias = 41;
  
  public static final int Constraint_flow_horizontalGap = 42;
  
  public static final int Constraint_flow_horizontalStyle = 43;
  
  public static final int Constraint_flow_lastHorizontalBias = 44;
  
  public static final int Constraint_flow_lastHorizontalStyle = 45;
  
  public static final int Constraint_flow_lastVerticalBias = 46;
  
  public static final int Constraint_flow_lastVerticalStyle = 47;
  
  public static final int Constraint_flow_maxElementsWrap = 48;
  
  public static final int Constraint_flow_verticalAlign = 49;
  
  public static final int Constraint_flow_verticalBias = 50;
  
  public static final int Constraint_flow_verticalGap = 51;
  
  public static final int Constraint_flow_verticalStyle = 52;
  
  public static final int Constraint_flow_wrapMode = 53;
  
  public static final int Constraint_guidelineUseRtl = 54;
  
  public static final int Constraint_layout_constrainedHeight = 55;
  
  public static final int Constraint_layout_constrainedWidth = 56;
  
  public static final int Constraint_layout_constraintBaseline_creator = 57;
  
  public static final int Constraint_layout_constraintBaseline_toBaselineOf = 58;
  
  public static final int Constraint_layout_constraintBaseline_toBottomOf = 59;
  
  public static final int Constraint_layout_constraintBaseline_toTopOf = 60;
  
  public static final int Constraint_layout_constraintBottom_creator = 61;
  
  public static final int Constraint_layout_constraintBottom_toBottomOf = 62;
  
  public static final int Constraint_layout_constraintBottom_toTopOf = 63;
  
  public static final int Constraint_layout_constraintCircle = 64;
  
  public static final int Constraint_layout_constraintCircleAngle = 65;
  
  public static final int Constraint_layout_constraintCircleRadius = 66;
  
  public static final int Constraint_layout_constraintDimensionRatio = 67;
  
  public static final int Constraint_layout_constraintEnd_toEndOf = 68;
  
  public static final int Constraint_layout_constraintEnd_toStartOf = 69;
  
  public static final int Constraint_layout_constraintGuide_begin = 70;
  
  public static final int Constraint_layout_constraintGuide_end = 71;
  
  public static final int Constraint_layout_constraintGuide_percent = 72;
  
  public static final int Constraint_layout_constraintHeight = 73;
  
  public static final int Constraint_layout_constraintHeight_default = 74;
  
  public static final int Constraint_layout_constraintHeight_max = 75;
  
  public static final int Constraint_layout_constraintHeight_min = 76;
  
  public static final int Constraint_layout_constraintHeight_percent = 77;
  
  public static final int Constraint_layout_constraintHorizontal_bias = 78;
  
  public static final int Constraint_layout_constraintHorizontal_chainStyle = 79;
  
  public static final int Constraint_layout_constraintHorizontal_weight = 80;
  
  public static final int Constraint_layout_constraintLeft_creator = 81;
  
  public static final int Constraint_layout_constraintLeft_toLeftOf = 82;
  
  public static final int Constraint_layout_constraintLeft_toRightOf = 83;
  
  public static final int Constraint_layout_constraintRight_creator = 84;
  
  public static final int Constraint_layout_constraintRight_toLeftOf = 85;
  
  public static final int Constraint_layout_constraintRight_toRightOf = 86;
  
  public static final int Constraint_layout_constraintStart_toEndOf = 87;
  
  public static final int Constraint_layout_constraintStart_toStartOf = 88;
  
  public static final int Constraint_layout_constraintTag = 89;
  
  public static final int Constraint_layout_constraintTop_creator = 90;
  
  public static final int Constraint_layout_constraintTop_toBottomOf = 91;
  
  public static final int Constraint_layout_constraintTop_toTopOf = 92;
  
  public static final int Constraint_layout_constraintVertical_bias = 93;
  
  public static final int Constraint_layout_constraintVertical_chainStyle = 94;
  
  public static final int Constraint_layout_constraintVertical_weight = 95;
  
  public static final int Constraint_layout_constraintWidth = 96;
  
  public static final int Constraint_layout_constraintWidth_default = 97;
  
  public static final int Constraint_layout_constraintWidth_max = 98;
  
  public static final int Constraint_layout_constraintWidth_min = 99;
  
  public static final int Constraint_layout_constraintWidth_percent = 100;
  
  public static final int Constraint_layout_editor_absoluteX = 101;
  
  public static final int Constraint_layout_editor_absoluteY = 102;
  
  public static final int Constraint_layout_goneMarginBaseline = 103;
  
  public static final int Constraint_layout_goneMarginBottom = 104;
  
  public static final int Constraint_layout_goneMarginEnd = 105;
  
  public static final int Constraint_layout_goneMarginLeft = 106;
  
  public static final int Constraint_layout_goneMarginRight = 107;
  
  public static final int Constraint_layout_goneMarginStart = 108;
  
  public static final int Constraint_layout_goneMarginTop = 109;
  
  public static final int Constraint_layout_marginBaseline = 110;
  
  public static final int Constraint_layout_wrapBehaviorInParent = 111;
  
  public static final int Constraint_motionProgress = 112;
  
  public static final int Constraint_motionStagger = 113;
  
  public static final int Constraint_pathMotionArc = 114;
  
  public static final int Constraint_pivotAnchor = 115;
  
  public static final int Constraint_polarRelativeTo = 116;
  
  public static final int Constraint_quantizeMotionInterpolator = 117;
  
  public static final int Constraint_quantizeMotionPhase = 118;
  
  public static final int Constraint_quantizeMotionSteps = 119;
  
  public static final int Constraint_transformPivotTarget = 120;
  
  public static final int Constraint_transitionEasing = 121;
  
  public static final int Constraint_transitionPathRotate = 122;
  
  public static final int Constraint_visibilityMode = 123;
  
  public static final int[] CustomAttribute = new int[] { 
      2130968645, 2130968947, 2130968948, 2130968949, 2130968950, 2130968951, 2130968952, 2130968954, 2130968955, 2130968956, 
      2130969405 };
  
  public static final int CustomAttribute_attributeName = 0;
  
  public static final int CustomAttribute_customBoolean = 1;
  
  public static final int CustomAttribute_customColorDrawableValue = 2;
  
  public static final int CustomAttribute_customColorValue = 3;
  
  public static final int CustomAttribute_customDimension = 4;
  
  public static final int CustomAttribute_customFloatValue = 5;
  
  public static final int CustomAttribute_customIntegerValue = 6;
  
  public static final int CustomAttribute_customPixelDimension = 7;
  
  public static final int CustomAttribute_customReference = 8;
  
  public static final int CustomAttribute_customStringValue = 9;
  
  public static final int CustomAttribute_methodName = 10;
  
  public static final int[] DrawerArrowToggle = new int[] { 2130968643, 2130968644, 2130968681, 2130968834, 2130968997, 2130969133, 2130969637, 2130969799 };
  
  public static final int DrawerArrowToggle_arrowHeadLength = 0;
  
  public static final int DrawerArrowToggle_arrowShaftLength = 1;
  
  public static final int DrawerArrowToggle_barLength = 2;
  
  public static final int DrawerArrowToggle_color = 3;
  
  public static final int DrawerArrowToggle_drawableSize = 4;
  
  public static final int DrawerArrowToggle_gapBetweenBars = 5;
  
  public static final int DrawerArrowToggle_spinBars = 6;
  
  public static final int DrawerArrowToggle_thickness = 7;
  
  public static final int[] FontFamily = new int[] { 2130969117, 2130969118, 2130969119, 2130969120, 2130969121, 2130969122, 2130969123 };
  
  public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130969115, 2130969124, 2130969125, 2130969126, 2130969872 };
  
  public static final int FontFamilyFont_android_font = 0;
  
  public static final int FontFamilyFont_android_fontStyle = 2;
  
  public static final int FontFamilyFont_android_fontVariationSettings = 4;
  
  public static final int FontFamilyFont_android_fontWeight = 1;
  
  public static final int FontFamilyFont_android_ttcIndex = 3;
  
  public static final int FontFamilyFont_font = 5;
  
  public static final int FontFamilyFont_fontStyle = 6;
  
  public static final int FontFamilyFont_fontVariationSettings = 7;
  
  public static final int FontFamilyFont_fontWeight = 8;
  
  public static final int FontFamilyFont_ttcIndex = 9;
  
  public static final int FontFamily_fontProviderAuthority = 0;
  
  public static final int FontFamily_fontProviderCerts = 1;
  
  public static final int FontFamily_fontProviderFetchStrategy = 2;
  
  public static final int FontFamily_fontProviderFetchTimeout = 3;
  
  public static final int FontFamily_fontProviderPackage = 4;
  
  public static final int FontFamily_fontProviderQuery = 5;
  
  public static final int FontFamily_fontProviderSystemFontFamily = 6;
  
  public static final int[] GradientColor = new int[] { 
      16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
      16844050, 16844051 };
  
  public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
  
  public static final int GradientColorItem_android_color = 0;
  
  public static final int GradientColorItem_android_offset = 1;
  
  public static final int GradientColor_android_centerColor = 7;
  
  public static final int GradientColor_android_centerX = 3;
  
  public static final int GradientColor_android_centerY = 4;
  
  public static final int GradientColor_android_endColor = 1;
  
  public static final int GradientColor_android_endX = 10;
  
  public static final int GradientColor_android_endY = 11;
  
  public static final int GradientColor_android_gradientRadius = 5;
  
  public static final int GradientColor_android_startColor = 0;
  
  public static final int GradientColor_android_startX = 8;
  
  public static final int GradientColor_android_startY = 9;
  
  public static final int GradientColor_android_tileMode = 6;
  
  public static final int GradientColor_android_type = 2;
  
  public static final int[] ImageFilterView = new int[] { 
      2130968632, 2130968697, 2130968719, 2130968923, 2130968944, 2130969174, 2130969175, 2130969176, 2130969177, 2130969493, 
      2130969573, 2130969574, 2130969575, 2130969898 };
  
  public static final int ImageFilterView_altSrc = 0;
  
  public static final int ImageFilterView_blendSrc = 1;
  
  public static final int ImageFilterView_brightness = 2;
  
  public static final int ImageFilterView_contrast = 3;
  
  public static final int ImageFilterView_crossfade = 4;
  
  public static final int ImageFilterView_imagePanX = 5;
  
  public static final int ImageFilterView_imagePanY = 6;
  
  public static final int ImageFilterView_imageRotate = 7;
  
  public static final int ImageFilterView_imageZoom = 8;
  
  public static final int ImageFilterView_overlay = 9;
  
  public static final int ImageFilterView_round = 10;
  
  public static final int ImageFilterView_roundPercent = 11;
  
  public static final int ImageFilterView_saturation = 12;
  
  public static final int ImageFilterView_warmth = 13;
  
  public static final int[] KeyAttribute = new int[] { 
      16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 
      16843770, 16843840, 2130968946, 2130969131, 2130969458, 2130969460, 2130969863, 2130969865, 2130969867 };
  
  public static final int KeyAttribute_android_alpha = 0;
  
  public static final int KeyAttribute_android_elevation = 11;
  
  public static final int KeyAttribute_android_rotation = 7;
  
  public static final int KeyAttribute_android_rotationX = 8;
  
  public static final int KeyAttribute_android_rotationY = 9;
  
  public static final int KeyAttribute_android_scaleX = 5;
  
  public static final int KeyAttribute_android_scaleY = 6;
  
  public static final int KeyAttribute_android_transformPivotX = 1;
  
  public static final int KeyAttribute_android_transformPivotY = 2;
  
  public static final int KeyAttribute_android_translationX = 3;
  
  public static final int KeyAttribute_android_translationY = 4;
  
  public static final int KeyAttribute_android_translationZ = 10;
  
  public static final int KeyAttribute_curveFit = 12;
  
  public static final int KeyAttribute_framePosition = 13;
  
  public static final int KeyAttribute_motionProgress = 14;
  
  public static final int KeyAttribute_motionTarget = 15;
  
  public static final int KeyAttribute_transformPivotTarget = 16;
  
  public static final int KeyAttribute_transitionEasing = 17;
  
  public static final int KeyAttribute_transitionPathRotate = 18;
  
  public static final int[] KeyCycle = new int[] { 
      16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, 
      2130968946, 2130969131, 2130969458, 2130969460, 2130969865, 2130969867, 2130969900, 2130969901, 2130969902, 2130969903, 
      2130969904 };
  
  public static final int KeyCycle_android_alpha = 0;
  
  public static final int KeyCycle_android_elevation = 9;
  
  public static final int KeyCycle_android_rotation = 5;
  
  public static final int KeyCycle_android_rotationX = 6;
  
  public static final int KeyCycle_android_rotationY = 7;
  
  public static final int KeyCycle_android_scaleX = 3;
  
  public static final int KeyCycle_android_scaleY = 4;
  
  public static final int KeyCycle_android_translationX = 1;
  
  public static final int KeyCycle_android_translationY = 2;
  
  public static final int KeyCycle_android_translationZ = 8;
  
  public static final int KeyCycle_curveFit = 10;
  
  public static final int KeyCycle_framePosition = 11;
  
  public static final int KeyCycle_motionProgress = 12;
  
  public static final int KeyCycle_motionTarget = 13;
  
  public static final int KeyCycle_transitionEasing = 14;
  
  public static final int KeyCycle_transitionPathRotate = 15;
  
  public static final int KeyCycle_waveOffset = 16;
  
  public static final int KeyCycle_wavePeriod = 17;
  
  public static final int KeyCycle_wavePhase = 18;
  
  public static final int KeyCycle_waveShape = 19;
  
  public static final int KeyCycle_waveVariesBy = 20;
  
  public static final int[] KeyFrame = new int[0];
  
  public static final int[] KeyFramesAcceleration = new int[0];
  
  public static final int[] KeyFramesVelocity = new int[0];
  
  public static final int[] KeyPosition = new int[] { 
      2130968946, 2130968992, 2130969131, 2130969227, 2130969460, 2130969510, 2130969512, 2130969513, 2130969514, 2130969515, 
      2130969631, 2130969865 };
  
  public static final int KeyPosition_curveFit = 0;
  
  public static final int KeyPosition_drawPath = 1;
  
  public static final int KeyPosition_framePosition = 2;
  
  public static final int KeyPosition_keyPositionType = 3;
  
  public static final int KeyPosition_motionTarget = 4;
  
  public static final int KeyPosition_pathMotionArc = 5;
  
  public static final int KeyPosition_percentHeight = 6;
  
  public static final int KeyPosition_percentWidth = 7;
  
  public static final int KeyPosition_percentX = 8;
  
  public static final int KeyPosition_percentY = 9;
  
  public static final int KeyPosition_sizePercent = 10;
  
  public static final int KeyPosition_transitionEasing = 11;
  
  public static final int[] KeyTimeCycle = new int[] { 
      16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, 
      2130968946, 2130969131, 2130969458, 2130969460, 2130969865, 2130969867, 2130969899, 2130969900, 2130969901, 2130969902, 
      2130969903 };
  
  public static final int KeyTimeCycle_android_alpha = 0;
  
  public static final int KeyTimeCycle_android_elevation = 9;
  
  public static final int KeyTimeCycle_android_rotation = 5;
  
  public static final int KeyTimeCycle_android_rotationX = 6;
  
  public static final int KeyTimeCycle_android_rotationY = 7;
  
  public static final int KeyTimeCycle_android_scaleX = 3;
  
  public static final int KeyTimeCycle_android_scaleY = 4;
  
  public static final int KeyTimeCycle_android_translationX = 1;
  
  public static final int KeyTimeCycle_android_translationY = 2;
  
  public static final int KeyTimeCycle_android_translationZ = 8;
  
  public static final int KeyTimeCycle_curveFit = 10;
  
  public static final int KeyTimeCycle_framePosition = 11;
  
  public static final int KeyTimeCycle_motionProgress = 12;
  
  public static final int KeyTimeCycle_motionTarget = 13;
  
  public static final int KeyTimeCycle_transitionEasing = 14;
  
  public static final int KeyTimeCycle_transitionPathRotate = 15;
  
  public static final int KeyTimeCycle_waveDecay = 16;
  
  public static final int KeyTimeCycle_waveOffset = 17;
  
  public static final int KeyTimeCycle_wavePeriod = 18;
  
  public static final int KeyTimeCycle_wavePhase = 19;
  
  public static final int KeyTimeCycle_waveShape = 20;
  
  public static final int[] KeyTrigger = new int[] { 
      2130969131, 2130969460, 2130969461, 2130969462, 2130969483, 2130969485, 2130969486, 2130969869, 2130969870, 2130969871, 
      2130969893, 2130969894, 2130969895 };
  
  public static final int KeyTrigger_framePosition = 0;
  
  public static final int KeyTrigger_motionTarget = 1;
  
  public static final int KeyTrigger_motion_postLayoutCollision = 2;
  
  public static final int KeyTrigger_motion_triggerOnCollision = 3;
  
  public static final int KeyTrigger_onCross = 4;
  
  public static final int KeyTrigger_onNegativeCross = 5;
  
  public static final int KeyTrigger_onPositiveCross = 6;
  
  public static final int KeyTrigger_triggerId = 7;
  
  public static final int KeyTrigger_triggerReceiver = 8;
  
  public static final int KeyTrigger_triggerSlack = 9;
  
  public static final int KeyTrigger_viewTransitionOnCross = 10;
  
  public static final int KeyTrigger_viewTransitionOnNegativeCross = 11;
  
  public static final int KeyTrigger_viewTransitionOnPositiveCross = 12;
  
  public static final int[] Layout = new int[] { 
      16842948, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843701, 16843702, 2130968682, 
      2130968683, 2130968684, 2130968763, 2130968904, 2130968905, 2130969136, 2130969249, 2130969250, 2130969251, 2130969252, 
      2130969253, 2130969254, 2130969255, 2130969256, 2130969257, 2130969258, 2130969259, 2130969260, 2130969261, 2130969262, 
      2130969263, 2130969264, 2130969265, 2130969266, 2130969267, 2130969268, 2130969269, 2130969270, 2130969271, 2130969272, 
      2130969273, 2130969274, 2130969275, 2130969276, 2130969277, 2130969278, 2130969279, 2130969280, 2130969281, 2130969282, 
      2130969284, 2130969285, 2130969286, 2130969287, 2130969288, 2130969289, 2130969290, 2130969291, 2130969292, 2130969293, 
      2130969294, 2130969296, 2130969297, 2130969298, 2130969299, 2130969300, 2130969301, 2130969302, 2130969303, 2130969304, 
      2130969307, 2130969312, 2130969396, 2130969400, 2130969407, 2130969411 };
  
  public static final int Layout_android_layout_height = 2;
  
  public static final int Layout_android_layout_marginBottom = 6;
  
  public static final int Layout_android_layout_marginEnd = 8;
  
  public static final int Layout_android_layout_marginLeft = 3;
  
  public static final int Layout_android_layout_marginRight = 5;
  
  public static final int Layout_android_layout_marginStart = 7;
  
  public static final int Layout_android_layout_marginTop = 4;
  
  public static final int Layout_android_layout_width = 1;
  
  public static final int Layout_android_orientation = 0;
  
  public static final int Layout_barrierAllowsGoneWidgets = 9;
  
  public static final int Layout_barrierDirection = 10;
  
  public static final int Layout_barrierMargin = 11;
  
  public static final int Layout_chainUseRtl = 12;
  
  public static final int Layout_constraint_referenced_ids = 13;
  
  public static final int Layout_constraint_referenced_tags = 14;
  
  public static final int Layout_guidelineUseRtl = 15;
  
  public static final int Layout_layout_constrainedHeight = 16;
  
  public static final int Layout_layout_constrainedWidth = 17;
  
  public static final int Layout_layout_constraintBaseline_creator = 18;
  
  public static final int Layout_layout_constraintBaseline_toBaselineOf = 19;
  
  public static final int Layout_layout_constraintBaseline_toBottomOf = 20;
  
  public static final int Layout_layout_constraintBaseline_toTopOf = 21;
  
  public static final int Layout_layout_constraintBottom_creator = 22;
  
  public static final int Layout_layout_constraintBottom_toBottomOf = 23;
  
  public static final int Layout_layout_constraintBottom_toTopOf = 24;
  
  public static final int Layout_layout_constraintCircle = 25;
  
  public static final int Layout_layout_constraintCircleAngle = 26;
  
  public static final int Layout_layout_constraintCircleRadius = 27;
  
  public static final int Layout_layout_constraintDimensionRatio = 28;
  
  public static final int Layout_layout_constraintEnd_toEndOf = 29;
  
  public static final int Layout_layout_constraintEnd_toStartOf = 30;
  
  public static final int Layout_layout_constraintGuide_begin = 31;
  
  public static final int Layout_layout_constraintGuide_end = 32;
  
  public static final int Layout_layout_constraintGuide_percent = 33;
  
  public static final int Layout_layout_constraintHeight = 34;
  
  public static final int Layout_layout_constraintHeight_default = 35;
  
  public static final int Layout_layout_constraintHeight_max = 36;
  
  public static final int Layout_layout_constraintHeight_min = 37;
  
  public static final int Layout_layout_constraintHeight_percent = 38;
  
  public static final int Layout_layout_constraintHorizontal_bias = 39;
  
  public static final int Layout_layout_constraintHorizontal_chainStyle = 40;
  
  public static final int Layout_layout_constraintHorizontal_weight = 41;
  
  public static final int Layout_layout_constraintLeft_creator = 42;
  
  public static final int Layout_layout_constraintLeft_toLeftOf = 43;
  
  public static final int Layout_layout_constraintLeft_toRightOf = 44;
  
  public static final int Layout_layout_constraintRight_creator = 45;
  
  public static final int Layout_layout_constraintRight_toLeftOf = 46;
  
  public static final int Layout_layout_constraintRight_toRightOf = 47;
  
  public static final int Layout_layout_constraintStart_toEndOf = 48;
  
  public static final int Layout_layout_constraintStart_toStartOf = 49;
  
  public static final int Layout_layout_constraintTop_creator = 50;
  
  public static final int Layout_layout_constraintTop_toBottomOf = 51;
  
  public static final int Layout_layout_constraintTop_toTopOf = 52;
  
  public static final int Layout_layout_constraintVertical_bias = 53;
  
  public static final int Layout_layout_constraintVertical_chainStyle = 54;
  
  public static final int Layout_layout_constraintVertical_weight = 55;
  
  public static final int Layout_layout_constraintWidth = 56;
  
  public static final int Layout_layout_constraintWidth_default = 57;
  
  public static final int Layout_layout_constraintWidth_max = 58;
  
  public static final int Layout_layout_constraintWidth_min = 59;
  
  public static final int Layout_layout_constraintWidth_percent = 60;
  
  public static final int Layout_layout_editor_absoluteX = 61;
  
  public static final int Layout_layout_editor_absoluteY = 62;
  
  public static final int Layout_layout_goneMarginBaseline = 63;
  
  public static final int Layout_layout_goneMarginBottom = 64;
  
  public static final int Layout_layout_goneMarginEnd = 65;
  
  public static final int Layout_layout_goneMarginLeft = 66;
  
  public static final int Layout_layout_goneMarginRight = 67;
  
  public static final int Layout_layout_goneMarginStart = 68;
  
  public static final int Layout_layout_goneMarginTop = 69;
  
  public static final int Layout_layout_marginBaseline = 70;
  
  public static final int Layout_layout_wrapBehaviorInParent = 71;
  
  public static final int Layout_maxHeight = 72;
  
  public static final int Layout_maxWidth = 73;
  
  public static final int Layout_minHeight = 74;
  
  public static final int Layout_minWidth = 75;
  
  public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130968981, 2130968986, 2130969401, 2130969614 };
  
  public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
  
  public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
  
  public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
  
  public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
  
  public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
  
  public static final int LinearLayoutCompat_android_baselineAligned = 2;
  
  public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
  
  public static final int LinearLayoutCompat_android_gravity = 0;
  
  public static final int LinearLayoutCompat_android_orientation = 1;
  
  public static final int LinearLayoutCompat_android_weightSum = 4;
  
  public static final int LinearLayoutCompat_divider = 5;
  
  public static final int LinearLayoutCompat_dividerPadding = 6;
  
  public static final int LinearLayoutCompat_measureWithLargestChild = 7;
  
  public static final int LinearLayoutCompat_showDividers = 8;
  
  public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
  
  public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
  
  public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
  
  public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
  
  public static final int MenuGroup_android_checkableBehavior = 5;
  
  public static final int MenuGroup_android_enabled = 0;
  
  public static final int MenuGroup_android_id = 1;
  
  public static final int MenuGroup_android_menuCategory = 3;
  
  public static final int MenuGroup_android_orderInCategory = 4;
  
  public static final int MenuGroup_android_visible = 2;
  
  public static final int[] MenuItem = new int[] { 
      16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
      16843236, 16843237, 16843375, 2130968591, 2130968611, 2130968613, 2130968631, 2130968908, 2130969166, 2130969167, 
      2130969481, 2130969612, 2130969846 };
  
  public static final int MenuItem_actionLayout = 13;
  
  public static final int MenuItem_actionProviderClass = 14;
  
  public static final int MenuItem_actionViewClass = 15;
  
  public static final int MenuItem_alphabeticModifiers = 16;
  
  public static final int MenuItem_android_alphabeticShortcut = 9;
  
  public static final int MenuItem_android_checkable = 11;
  
  public static final int MenuItem_android_checked = 3;
  
  public static final int MenuItem_android_enabled = 1;
  
  public static final int MenuItem_android_icon = 0;
  
  public static final int MenuItem_android_id = 2;
  
  public static final int MenuItem_android_menuCategory = 5;
  
  public static final int MenuItem_android_numericShortcut = 10;
  
  public static final int MenuItem_android_onClick = 12;
  
  public static final int MenuItem_android_orderInCategory = 6;
  
  public static final int MenuItem_android_title = 7;
  
  public static final int MenuItem_android_titleCondensed = 8;
  
  public static final int MenuItem_android_visible = 4;
  
  public static final int MenuItem_contentDescription = 17;
  
  public static final int MenuItem_iconTint = 18;
  
  public static final int MenuItem_iconTintMode = 19;
  
  public static final int MenuItem_numericModifiers = 20;
  
  public static final int MenuItem_showAsAction = 21;
  
  public static final int MenuItem_tooltipText = 22;
  
  public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130969543, 2130969674 };
  
  public static final int MenuView_android_headerBackground = 4;
  
  public static final int MenuView_android_horizontalDivider = 2;
  
  public static final int MenuView_android_itemBackground = 5;
  
  public static final int MenuView_android_itemIconDisabledAlpha = 6;
  
  public static final int MenuView_android_itemTextAppearance = 1;
  
  public static final int MenuView_android_verticalDivider = 3;
  
  public static final int MenuView_android_windowAnimationStyle = 0;
  
  public static final int MenuView_preserveIconSpacing = 7;
  
  public static final int MenuView_subMenuArrow = 8;
  
  public static final int[] MockView = new int[] { 2130969412, 2130969413, 2130969414, 2130969415, 2130969416, 2130969417 };
  
  public static final int MockView_mock_diagonalsColor = 0;
  
  public static final int MockView_mock_label = 1;
  
  public static final int MockView_mock_labelBackgroundColor = 2;
  
  public static final int MockView_mock_labelColor = 3;
  
  public static final int MockView_mock_showDiagonals = 4;
  
  public static final int MockView_mock_showLabel = 5;
  
  public static final int[] Motion = new int[] { 2130968635, 2130968638, 2130968992, 2130969457, 2130969459, 2130969510, 2130969548, 2130969549, 2130969550, 2130969865 };
  
  public static final int[] MotionEffect = new int[] { 2130969447, 2130969448, 2130969449, 2130969450, 2130969451, 2130969452, 2130969453, 2130969454 };
  
  public static final int MotionEffect_motionEffect_alpha = 0;
  
  public static final int MotionEffect_motionEffect_end = 1;
  
  public static final int MotionEffect_motionEffect_move = 2;
  
  public static final int MotionEffect_motionEffect_start = 3;
  
  public static final int MotionEffect_motionEffect_strict = 4;
  
  public static final int MotionEffect_motionEffect_translationX = 5;
  
  public static final int MotionEffect_motionEffect_translationY = 6;
  
  public static final int MotionEffect_motionEffect_viewTransition = 7;
  
  public static final int[] MotionHelper = new int[] { 2130969484, 2130969487 };
  
  public static final int MotionHelper_onHide = 0;
  
  public static final int MotionHelper_onShow = 1;
  
  public static final int[] MotionLabel = new int[] { 
      16842901, 16842902, 16842903, 16842904, 16842927, 16843087, 16843108, 16843692, 16844085, 2130968698, 
      2130968699, 2130969576, 2130969771, 2130969772, 2130969773, 2130969774, 2130969775, 2130969789, 2130969790, 2130969791, 
      2130969792, 2130969794, 2130969795, 2130969796, 2130969797 };
  
  public static final int MotionLabel_android_autoSizeTextType = 8;
  
  public static final int MotionLabel_android_fontFamily = 7;
  
  public static final int MotionLabel_android_gravity = 4;
  
  public static final int MotionLabel_android_shadowRadius = 6;
  
  public static final int MotionLabel_android_text = 5;
  
  public static final int MotionLabel_android_textColor = 3;
  
  public static final int MotionLabel_android_textSize = 0;
  
  public static final int MotionLabel_android_textStyle = 2;
  
  public static final int MotionLabel_android_typeface = 1;
  
  public static final int MotionLabel_borderRound = 9;
  
  public static final int MotionLabel_borderRoundPercent = 10;
  
  public static final int MotionLabel_scaleFromTextSize = 11;
  
  public static final int MotionLabel_textBackground = 12;
  
  public static final int MotionLabel_textBackgroundPanX = 13;
  
  public static final int MotionLabel_textBackgroundPanY = 14;
  
  public static final int MotionLabel_textBackgroundRotate = 15;
  
  public static final int MotionLabel_textBackgroundZoom = 16;
  
  public static final int MotionLabel_textOutlineColor = 17;
  
  public static final int MotionLabel_textOutlineThickness = 18;
  
  public static final int MotionLabel_textPanX = 19;
  
  public static final int MotionLabel_textPanY = 20;
  
  public static final int MotionLabel_textureBlurFactor = 21;
  
  public static final int MotionLabel_textureEffect = 22;
  
  public static final int MotionLabel_textureHeight = 23;
  
  public static final int MotionLabel_textureWidth = 24;
  
  public static final int[] MotionLayout = new int[] { 2130968641, 2130968945, 2130969241, 2130969418, 2130969458, 2130969616 };
  
  public static final int MotionLayout_applyMotionScene = 0;
  
  public static final int MotionLayout_currentState = 1;
  
  public static final int MotionLayout_layoutDescription = 2;
  
  public static final int MotionLayout_motionDebug = 3;
  
  public static final int MotionLayout_motionProgress = 4;
  
  public static final int MotionLayout_showPaths = 5;
  
  public static final int[] MotionScene = new int[] { 2130968961, 2130969242 };
  
  public static final int MotionScene_defaultDuration = 0;
  
  public static final int MotionScene_layoutDuringTransition = 1;
  
  public static final int[] MotionTelltales = new int[] { 2130969730, 2130969731, 2130969732 };
  
  public static final int MotionTelltales_telltales_tailColor = 0;
  
  public static final int MotionTelltales_telltales_tailScale = 1;
  
  public static final int MotionTelltales_telltales_velocityMode = 2;
  
  public static final int Motion_animateCircleAngleTo = 0;
  
  public static final int Motion_animateRelativeTo = 1;
  
  public static final int Motion_drawPath = 2;
  
  public static final int Motion_motionPathRotate = 3;
  
  public static final int Motion_motionStagger = 4;
  
  public static final int Motion_pathMotionArc = 5;
  
  public static final int Motion_quantizeMotionInterpolator = 6;
  
  public static final int Motion_quantizeMotionPhase = 7;
  
  public static final int Motion_quantizeMotionSteps = 8;
  
  public static final int Motion_transitionEasing = 9;
  
  public static final int[] OnClick = new int[] { 2130968810, 2130969729 };
  
  public static final int OnClick_clickAction = 0;
  
  public static final int OnClick_targetId = 1;
  
  public static final int[] OnSwipe = new int[] { 
      2130968646, 2130968989, 2130968990, 2130968991, 2130969316, 2130969392, 2130969399, 2130969463, 2130969477, 2130969489, 
      2130969572, 2130969645, 2130969646, 2130969647, 2130969648, 2130969649, 2130969848, 2130969849, 2130969850 };
  
  public static final int OnSwipe_autoCompleteMode = 0;
  
  public static final int OnSwipe_dragDirection = 1;
  
  public static final int OnSwipe_dragScale = 2;
  
  public static final int OnSwipe_dragThreshold = 3;
  
  public static final int OnSwipe_limitBoundsTo = 4;
  
  public static final int OnSwipe_maxAcceleration = 5;
  
  public static final int OnSwipe_maxVelocity = 6;
  
  public static final int OnSwipe_moveWhenScrollAtTop = 7;
  
  public static final int OnSwipe_nestedScrollFlags = 8;
  
  public static final int OnSwipe_onTouchUp = 9;
  
  public static final int OnSwipe_rotationCenterId = 10;
  
  public static final int OnSwipe_springBoundary = 11;
  
  public static final int OnSwipe_springDamping = 12;
  
  public static final int OnSwipe_springMass = 13;
  
  public static final int OnSwipe_springStiffness = 14;
  
  public static final int OnSwipe_springStopThreshold = 15;
  
  public static final int OnSwipe_touchAnchorId = 16;
  
  public static final int OnSwipe_touchAnchorSide = 17;
  
  public static final int OnSwipe_touchRegionId = 18;
  
  public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130969492 };
  
  public static final int[] PopupWindowBackgroundState = new int[] { 2130969660 };
  
  public static final int PopupWindowBackgroundState_state_above_anchor = 0;
  
  public static final int PopupWindow_android_popupAnimationStyle = 1;
  
  public static final int PopupWindow_android_popupBackground = 0;
  
  public static final int PopupWindow_overlapAnchor = 2;
  
  public static final int[] PropertySet = new int[] { 16842972, 16843551, 2130969283, 2130969458, 2130969896 };
  
  public static final int PropertySet_android_alpha = 1;
  
  public static final int PropertySet_android_visibility = 0;
  
  public static final int PropertySet_layout_constraintTag = 2;
  
  public static final int PropertySet_motionProgress = 3;
  
  public static final int PropertySet_visibilityMode = 4;
  
  public static final int[] RecycleListView = new int[] { 2130969494, 2130969500 };
  
  public static final int RecycleListView_paddingBottomNoButtons = 0;
  
  public static final int RecycleListView_paddingTopNoTitle = 1;
  
  public static final int[] SearchView = new int[] { 
      16842804, 16842970, 16843039, 16843087, 16843088, 16843296, 16843364, 2130968636, 2130968637, 2130968648, 
      2130968815, 2130968898, 2130968963, 2130969135, 2130969139, 2130969147, 2130969168, 2130969240, 2130969551, 2130969552, 
      2130969582, 2130969583, 2130969584, 2130969679, 2130969688, 2130969884, 2130969897 };
  
  public static final int SearchView_android_focusable = 1;
  
  public static final int SearchView_android_hint = 4;
  
  public static final int SearchView_android_imeOptions = 6;
  
  public static final int SearchView_android_inputType = 5;
  
  public static final int SearchView_android_maxWidth = 2;
  
  public static final int SearchView_android_text = 3;
  
  public static final int SearchView_android_textAppearance = 0;
  
  public static final int SearchView_animateMenuItems = 7;
  
  public static final int SearchView_animateNavigationIcon = 8;
  
  public static final int SearchView_autoShowKeyboard = 9;
  
  public static final int SearchView_closeIcon = 10;
  
  public static final int SearchView_commitIcon = 11;
  
  public static final int SearchView_defaultQueryHint = 12;
  
  public static final int SearchView_goIcon = 13;
  
  public static final int SearchView_headerLayout = 14;
  
  public static final int SearchView_hideNavigationIcon = 15;
  
  public static final int SearchView_iconifiedByDefault = 16;
  
  public static final int SearchView_layout = 17;
  
  public static final int SearchView_queryBackground = 18;
  
  public static final int SearchView_queryHint = 19;
  
  public static final int SearchView_searchHintIcon = 20;
  
  public static final int SearchView_searchIcon = 21;
  
  public static final int SearchView_searchPrefixText = 22;
  
  public static final int SearchView_submitBackground = 23;
  
  public static final int SearchView_suggestionRowLayout = 24;
  
  public static final int SearchView_useDrawerArrowDrawable = 25;
  
  public static final int SearchView_voiceIcon = 26;
  
  public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130969527 };
  
  public static final int Spinner_android_dropDownWidth = 3;
  
  public static final int Spinner_android_entries = 0;
  
  public static final int Spinner_android_popupBackground = 1;
  
  public static final int Spinner_android_prompt = 2;
  
  public static final int Spinner_popupTheme = 4;
  
  public static final int[] State = new int[] { 16842960, 2130968906 };
  
  public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
  
  public static final int[] StateListDrawableItem = new int[] { 16843161 };
  
  public static final int StateListDrawableItem_android_drawable = 0;
  
  public static final int StateListDrawable_android_constantSize = 3;
  
  public static final int StateListDrawable_android_dither = 0;
  
  public static final int StateListDrawable_android_enterFadeDuration = 4;
  
  public static final int StateListDrawable_android_exitFadeDuration = 5;
  
  public static final int StateListDrawable_android_variablePadding = 2;
  
  public static final int StateListDrawable_android_visible = 1;
  
  public static final int[] StateSet = new int[] { 2130968965 };
  
  public static final int StateSet_defaultState = 0;
  
  public static final int State_android_id = 0;
  
  public static final int State_constraints = 1;
  
  public static final int[] SwitchCompat = new int[] { 
      16843044, 16843045, 16843074, 2130969618, 2130969644, 2130969692, 2130969693, 2130969697, 2130969808, 2130969809, 
      2130969810, 2130969851, 2130969861, 2130969862 };
  
  public static final int SwitchCompat_android_textOff = 1;
  
  public static final int SwitchCompat_android_textOn = 0;
  
  public static final int SwitchCompat_android_thumb = 2;
  
  public static final int SwitchCompat_showText = 3;
  
  public static final int SwitchCompat_splitTrack = 4;
  
  public static final int SwitchCompat_switchMinWidth = 5;
  
  public static final int SwitchCompat_switchPadding = 6;
  
  public static final int SwitchCompat_switchTextAppearance = 7;
  
  public static final int SwitchCompat_thumbTextPadding = 8;
  
  public static final int SwitchCompat_thumbTint = 9;
  
  public static final int SwitchCompat_thumbTintMode = 10;
  
  public static final int SwitchCompat_track = 11;
  
  public static final int SwitchCompat_trackTint = 12;
  
  public static final int SwitchCompat_trackTintMode = 13;
  
  public static final int[] TextAppearance = new int[] { 
      16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
      16843692, 16844165, 2130969116, 2130969125, 2130969733, 2130969788 };
  
  public static final int TextAppearance_android_fontFamily = 10;
  
  public static final int TextAppearance_android_shadowColor = 6;
  
  public static final int TextAppearance_android_shadowDx = 7;
  
  public static final int TextAppearance_android_shadowDy = 8;
  
  public static final int TextAppearance_android_shadowRadius = 9;
  
  public static final int TextAppearance_android_textColor = 3;
  
  public static final int TextAppearance_android_textColorHint = 4;
  
  public static final int TextAppearance_android_textColorLink = 5;
  
  public static final int TextAppearance_android_textFontWeight = 11;
  
  public static final int TextAppearance_android_textSize = 0;
  
  public static final int TextAppearance_android_textStyle = 2;
  
  public static final int TextAppearance_android_typeface = 1;
  
  public static final int TextAppearance_fontFamily = 12;
  
  public static final int TextAppearance_fontVariationSettings = 13;
  
  public static final int TextAppearance_textAllCaps = 14;
  
  public static final int TextAppearance_textLocale = 15;
  
  public static final int[] TextEffects = new int[] { 
      16842901, 16842902, 16842903, 16843087, 16843105, 16843106, 16843107, 16843108, 16843692, 2130968698, 
      2130968699, 2130969779, 2130969789, 2130969790 };
  
  public static final int TextEffects_android_fontFamily = 8;
  
  public static final int TextEffects_android_shadowColor = 4;
  
  public static final int TextEffects_android_shadowDx = 5;
  
  public static final int TextEffects_android_shadowDy = 6;
  
  public static final int TextEffects_android_shadowRadius = 7;
  
  public static final int TextEffects_android_text = 3;
  
  public static final int TextEffects_android_textSize = 0;
  
  public static final int TextEffects_android_textStyle = 2;
  
  public static final int TextEffects_android_typeface = 1;
  
  public static final int TextEffects_borderRound = 9;
  
  public static final int TextEffects_borderRoundPercent = 10;
  
  public static final int TextEffects_textFillColor = 11;
  
  public static final int TextEffects_textOutlineColor = 12;
  
  public static final int TextEffects_textOutlineThickness = 13;
  
  public static final int[] Toolbar = new int[] { 
      16842927, 16843072, 2130968726, 2130968823, 2130968824, 2130968909, 2130968910, 2130968911, 2130968912, 2130968913, 
      2130968914, 2130969337, 2130969339, 2130969394, 2130969402, 2130969470, 2130969471, 2130969527, 2130969680, 2130969682, 
      2130969683, 2130969823, 2130969827, 2130969828, 2130969829, 2130969830, 2130969831, 2130969832, 2130969834, 2130969835 };
  
  public static final int Toolbar_android_gravity = 0;
  
  public static final int Toolbar_android_minHeight = 1;
  
  public static final int Toolbar_buttonGravity = 2;
  
  public static final int Toolbar_collapseContentDescription = 3;
  
  public static final int Toolbar_collapseIcon = 4;
  
  public static final int Toolbar_contentInsetEnd = 5;
  
  public static final int Toolbar_contentInsetEndWithActions = 6;
  
  public static final int Toolbar_contentInsetLeft = 7;
  
  public static final int Toolbar_contentInsetRight = 8;
  
  public static final int Toolbar_contentInsetStart = 9;
  
  public static final int Toolbar_contentInsetStartWithNavigation = 10;
  
  public static final int Toolbar_logo = 11;
  
  public static final int Toolbar_logoDescription = 12;
  
  public static final int Toolbar_maxButtonHeight = 13;
  
  public static final int Toolbar_menu = 14;
  
  public static final int Toolbar_navigationContentDescription = 15;
  
  public static final int Toolbar_navigationIcon = 16;
  
  public static final int Toolbar_popupTheme = 17;
  
  public static final int Toolbar_subtitle = 18;
  
  public static final int Toolbar_subtitleTextAppearance = 19;
  
  public static final int Toolbar_subtitleTextColor = 20;
  
  public static final int Toolbar_title = 21;
  
  public static final int Toolbar_titleMargin = 22;
  
  public static final int Toolbar_titleMarginBottom = 23;
  
  public static final int Toolbar_titleMarginEnd = 24;
  
  public static final int Toolbar_titleMarginStart = 25;
  
  public static final int Toolbar_titleMarginTop = 26;
  
  public static final int Toolbar_titleMargins = 27;
  
  public static final int Toolbar_titleTextAppearance = 28;
  
  public static final int Toolbar_titleTextColor = 29;
  
  public static final int[] Transform = new int[] { 
      16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 
      16843840, 2130969863 };
  
  public static final int Transform_android_elevation = 10;
  
  public static final int Transform_android_rotation = 6;
  
  public static final int Transform_android_rotationX = 7;
  
  public static final int Transform_android_rotationY = 8;
  
  public static final int Transform_android_scaleX = 4;
  
  public static final int Transform_android_scaleY = 5;
  
  public static final int Transform_android_transformPivotX = 0;
  
  public static final int Transform_android_transformPivotY = 1;
  
  public static final int Transform_android_translationX = 2;
  
  public static final int Transform_android_translationY = 3;
  
  public static final int Transform_android_translationZ = 9;
  
  public static final int Transform_transformPivotTarget = 11;
  
  public static final int[] Transition = new int[] { 
      16842960, 2130968654, 2130968902, 2130968903, 2130969008, 2130969242, 2130969455, 2130969510, 2130969652, 2130969864, 
      2130969866 };
  
  public static final int Transition_android_id = 0;
  
  public static final int Transition_autoTransition = 1;
  
  public static final int Transition_constraintSetEnd = 2;
  
  public static final int Transition_constraintSetStart = 3;
  
  public static final int Transition_duration = 4;
  
  public static final int Transition_layoutDuringTransition = 5;
  
  public static final int Transition_motionInterpolator = 6;
  
  public static final int Transition_pathMotionArc = 7;
  
  public static final int Transition_staggered = 8;
  
  public static final int Transition_transitionDisable = 9;
  
  public static final int Transition_transitionFlags = 10;
  
  public static final int[] Variant = new int[] { 2130968906, 2130969565, 2130969566, 2130969567, 2130969568 };
  
  public static final int Variant_constraints = 0;
  
  public static final int Variant_region_heightLessThan = 1;
  
  public static final int Variant_region_heightMoreThan = 2;
  
  public static final int Variant_region_widthLessThan = 3;
  
  public static final int Variant_region_widthMoreThan = 4;
  
  public static final int[] View = new int[] { 16842752, 16842970, 2130969496, 2130969499, 2130969798 };
  
  public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130968664, 2130968665 };
  
  public static final int ViewBackgroundHelper_android_background = 0;
  
  public static final int ViewBackgroundHelper_backgroundTint = 1;
  
  public static final int ViewBackgroundHelper_backgroundTintMode = 2;
  
  public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
  
  public static final int ViewStubCompat_android_id = 0;
  
  public static final int ViewStubCompat_android_inflatedId = 2;
  
  public static final int ViewStubCompat_android_layout = 1;
  
  public static final int[] ViewTransition = new int[] { 
      16842960, 2130968576, 2130968577, 2130968809, 2130969008, 2130969169, 2130969170, 2130969455, 2130969460, 2130969488, 
      2130969510, 2130969596, 2130969864, 2130969881, 2130969892 };
  
  public static final int ViewTransition_SharedValue = 1;
  
  public static final int ViewTransition_SharedValueId = 2;
  
  public static final int ViewTransition_android_id = 0;
  
  public static final int ViewTransition_clearsTag = 3;
  
  public static final int ViewTransition_duration = 4;
  
  public static final int ViewTransition_ifTagNotSet = 5;
  
  public static final int ViewTransition_ifTagSet = 6;
  
  public static final int ViewTransition_motionInterpolator = 7;
  
  public static final int ViewTransition_motionTarget = 8;
  
  public static final int ViewTransition_onStateTransition = 9;
  
  public static final int ViewTransition_pathMotionArc = 10;
  
  public static final int ViewTransition_setsTag = 11;
  
  public static final int ViewTransition_transitionDisable = 12;
  
  public static final int ViewTransition_upDuration = 13;
  
  public static final int ViewTransition_viewTransitionMode = 14;
  
  public static final int View_android_focusable = 1;
  
  public static final int View_android_theme = 0;
  
  public static final int View_paddingEnd = 2;
  
  public static final int View_paddingStart = 3;
  
  public static final int View_theme = 4;
  
  public static final int[] include = new int[] { 2130968901 };
  
  public static final int include_constraintSet = 0;
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\constraintlayout\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */