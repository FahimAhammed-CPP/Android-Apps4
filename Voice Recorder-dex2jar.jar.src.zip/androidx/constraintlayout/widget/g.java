package androidx.constraintlayout.widget;

public abstract class g {
  public static final int NO_DEBUG = 2131361799;
  
  public static final int SHOW_ALL = 2131361801;
  
  public static final int SHOW_PATH = 2131361802;
  
  public static final int SHOW_PROGRESS = 2131361803;
  
  public static final int accelerate = 2131361808;
  
  public static final int accessibility_action_clickable_span = 2131361809;
  
  public static final int accessibility_custom_action_0 = 2131361810;
  
  public static final int accessibility_custom_action_1 = 2131361811;
  
  public static final int accessibility_custom_action_10 = 2131361812;
  
  public static final int accessibility_custom_action_11 = 2131361813;
  
  public static final int accessibility_custom_action_12 = 2131361814;
  
  public static final int accessibility_custom_action_13 = 2131361815;
  
  public static final int accessibility_custom_action_14 = 2131361816;
  
  public static final int accessibility_custom_action_15 = 2131361817;
  
  public static final int accessibility_custom_action_16 = 2131361818;
  
  public static final int accessibility_custom_action_17 = 2131361819;
  
  public static final int accessibility_custom_action_18 = 2131361820;
  
  public static final int accessibility_custom_action_19 = 2131361821;
  
  public static final int accessibility_custom_action_2 = 2131361822;
  
  public static final int accessibility_custom_action_20 = 2131361823;
  
  public static final int accessibility_custom_action_21 = 2131361824;
  
  public static final int accessibility_custom_action_22 = 2131361825;
  
  public static final int accessibility_custom_action_23 = 2131361826;
  
  public static final int accessibility_custom_action_24 = 2131361827;
  
  public static final int accessibility_custom_action_25 = 2131361828;
  
  public static final int accessibility_custom_action_26 = 2131361829;
  
  public static final int accessibility_custom_action_27 = 2131361830;
  
  public static final int accessibility_custom_action_28 = 2131361831;
  
  public static final int accessibility_custom_action_29 = 2131361832;
  
  public static final int accessibility_custom_action_3 = 2131361833;
  
  public static final int accessibility_custom_action_30 = 2131361834;
  
  public static final int accessibility_custom_action_31 = 2131361835;
  
  public static final int accessibility_custom_action_4 = 2131361836;
  
  public static final int accessibility_custom_action_5 = 2131361837;
  
  public static final int accessibility_custom_action_6 = 2131361838;
  
  public static final int accessibility_custom_action_7 = 2131361839;
  
  public static final int accessibility_custom_action_8 = 2131361840;
  
  public static final int accessibility_custom_action_9 = 2131361841;
  
  public static final int actionDown = 2131361845;
  
  public static final int actionDownUp = 2131361846;
  
  public static final int actionUp = 2131361847;
  
  public static final int action_bar = 2131361848;
  
  public static final int action_bar_activity_content = 2131361849;
  
  public static final int action_bar_container = 2131361850;
  
  public static final int action_bar_root = 2131361851;
  
  public static final int action_bar_spinner = 2131361852;
  
  public static final int action_bar_subtitle = 2131361853;
  
  public static final int action_bar_title = 2131361854;
  
  public static final int action_container = 2131361857;
  
  public static final int action_context_bar = 2131361858;
  
  public static final int action_divider = 2131361860;
  
  public static final int action_image = 2131361861;
  
  public static final int action_menu_divider = 2131361862;
  
  public static final int action_menu_presenter = 2131361863;
  
  public static final int action_mode_bar = 2131361864;
  
  public static final int action_mode_bar_stub = 2131361865;
  
  public static final int action_mode_close_button = 2131361866;
  
  public static final int action_text = 2131361872;
  
  public static final int actions = 2131361873;
  
  public static final int activity_chooser_view_content = 2131361874;
  
  public static final int add = 2131361883;
  
  public static final int alertTitle = 2131361893;
  
  public static final int aligned = 2131361894;
  
  public static final int allStates = 2131361896;
  
  public static final int animateToEnd = 2131361902;
  
  public static final int animateToStart = 2131361903;
  
  public static final int antiClockwise = 2131361906;
  
  public static final int anticipate = 2131361907;
  
  public static final int asConfigured = 2131361912;
  
  public static final int async = 2131361914;
  
  public static final int auto = 2131361918;
  
  public static final int autoComplete = 2131361919;
  
  public static final int autoCompleteToEnd = 2131361920;
  
  public static final int autoCompleteToStart = 2131361921;
  
  public static final int baseline = 2131361927;
  
  public static final int bestChoice = 2131361932;
  
  public static final int blocking = 2131361938;
  
  public static final int bottom = 2131361943;
  
  public static final int bounce = 2131361946;
  
  public static final int buttonPanel = 2131361957;
  
  public static final int callMeasure = 2131361965;
  
  public static final int carryVelocity = 2131361968;
  
  public static final int center = 2131361970;
  
  public static final int chain = 2131361975;
  
  public static final int chain2 = 2131361976;
  
  public static final int checkbox = 2131361981;
  
  public static final int checked = 2131361982;
  
  public static final int chronometer = 2131361985;
  
  public static final int clockwise = 2131361995;
  
  public static final int closest = 2131361997;
  
  public static final int constraint = 2131362006;
  
  public static final int content = 2131362008;
  
  public static final int contentPanel = 2131362009;
  
  public static final int continuousVelocity = 2131362015;
  
  public static final int cos = 2131362017;
  
  public static final int currentState = 2131362021;
  
  public static final int custom = 2131362025;
  
  public static final int customPanel = 2131362026;
  
  public static final int decelerate = 2131362039;
  
  public static final int decelerateAndComplete = 2131362040;
  
  public static final int decor_content_parent = 2131362041;
  
  public static final int default_activity_button = 2131362043;
  
  public static final int deltaRelative = 2131362048;
  
  public static final int dialog_button = 2131362058;
  
  public static final int dragAnticlockwise = 2131362073;
  
  public static final int dragClockwise = 2131362074;
  
  public static final int dragDown = 2131362075;
  
  public static final int dragEnd = 2131362076;
  
  public static final int dragLeft = 2131362077;
  
  public static final int dragRight = 2131362078;
  
  public static final int dragStart = 2131362079;
  
  public static final int dragUp = 2131362080;
  
  public static final int easeIn = 2131362089;
  
  public static final int easeInOut = 2131362090;
  
  public static final int easeOut = 2131362091;
  
  public static final int east = 2131362092;
  
  public static final int edit_query = 2131362095;
  
  public static final int end = 2131362106;
  
  public static final int expand_activities_button = 2131362120;
  
  public static final int expanded_menu = 2131362122;
  
  public static final int flip = 2131362141;
  
  public static final int forever = 2131362145;
  
  public static final int frost = 2131362150;
  
  public static final int gone = 2131362157;
  
  public static final int group_divider = 2131362167;
  
  public static final int home = 2131362178;
  
  public static final int honorRequest = 2131362180;
  
  public static final int horizontal_only = 2131362182;
  
  public static final int icon = 2131362186;
  
  public static final int icon_group = 2131362188;
  
  public static final int ignore = 2131362191;
  
  public static final int ignoreRequest = 2131362192;
  
  public static final int image = 2131362193;
  
  public static final int immediateStop = 2131362194;
  
  public static final int included = 2131362195;
  
  public static final int info = 2131362198;
  
  public static final int invisible = 2131362200;
  
  public static final int italic = 2131362202;
  
  public static final int jumpToEnd = 2131362205;
  
  public static final int jumpToStart = 2131362206;
  
  public static final int layout = 2131362210;
  
  public static final int left = 2131362212;
  
  public static final int line1 = 2131362221;
  
  public static final int line3 = 2131362222;
  
  public static final int linear = 2131362223;
  
  public static final int listMode = 2131362224;
  
  public static final int list_item = 2131362226;
  
  public static final int match_constraint = 2131362250;
  
  public static final int match_parent = 2131362251;
  
  public static final int message = 2131362276;
  
  public static final int middle = 2131362278;
  
  public static final int motion_base = 2131362292;
  
  public static final int multiply = 2131362321;
  
  public static final int neverCompleteToEnd = 2131362338;
  
  public static final int neverCompleteToStart = 2131362339;
  
  public static final int noState = 2131362342;
  
  public static final int none = 2131362348;
  
  public static final int normal = 2131362349;
  
  public static final int north = 2131362350;
  
  public static final int notification_background = 2131362352;
  
  public static final int notification_main_column = 2131362353;
  
  public static final int notification_main_column_container = 2131362354;
  
  public static final int off = 2131362365;
  
  public static final int on = 2131362366;
  
  public static final int overshoot = 2131362372;
  
  public static final int packed = 2131362373;
  
  public static final int parent = 2131362375;
  
  public static final int parentPanel = 2131362376;
  
  public static final int parentRelative = 2131362377;
  
  public static final int path = 2131362382;
  
  public static final int pathRelative = 2131362383;
  
  public static final int percent = 2131362391;
  
  public static final int position = 2131362403;
  
  public static final int postLayout = 2131362405;
  
  public static final int progress_circular = 2131362418;
  
  public static final int progress_horizontal = 2131362421;
  
  public static final int radio = 2131362426;
  
  public static final int rectangles = 2131362446;
  
  public static final int reverseSawtooth = 2131362461;
  
  public static final int right = 2131362467;
  
  public static final int right_icon = 2131362470;
  
  public static final int right_side = 2131362471;
  
  public static final int sawtooth = 2131362483;
  
  public static final int screen = 2131362487;
  
  public static final int scrollIndicatorDown = 2131362490;
  
  public static final int scrollIndicatorUp = 2131362491;
  
  public static final int scrollView = 2131362492;
  
  public static final int search_badge = 2131362495;
  
  public static final int search_bar = 2131362496;
  
  public static final int search_button = 2131362498;
  
  public static final int search_close_btn = 2131362499;
  
  public static final int search_edit_frame = 2131362500;
  
  public static final int search_go_btn = 2131362501;
  
  public static final int search_mag_icon = 2131362502;
  
  public static final int search_plate = 2131362503;
  
  public static final int search_src_text = 2131362504;
  
  public static final int search_voice_btn = 2131362518;
  
  public static final int select_dialog_listview = 2131362525;
  
  public static final int sharedValueSet = 2131362535;
  
  public static final int sharedValueUnset = 2131362536;
  
  public static final int shortcut = 2131362538;
  
  public static final int sin = 2131362547;
  
  public static final int skipped = 2131362553;
  
  public static final int south = 2131362563;
  
  public static final int spacer = 2131362565;
  
  public static final int spline = 2131362568;
  
  public static final int split_action_bar = 2131362569;
  
  public static final int spread = 2131362570;
  
  public static final int spread_inside = 2131362571;
  
  public static final int spring = 2131362572;
  
  public static final int square = 2131362573;
  
  public static final int src_atop = 2131362574;
  
  public static final int src_in = 2131362575;
  
  public static final int src_over = 2131362576;
  
  public static final int standard = 2131362577;
  
  public static final int start = 2131362578;
  
  public static final int startHorizontal = 2131362579;
  
  public static final int startVertical = 2131362581;
  
  public static final int staticLayout = 2131362584;
  
  public static final int staticPostLayout = 2131362585;
  
  public static final int stop = 2131362589;
  
  public static final int submenuarrow = 2131362592;
  
  public static final int submit_area = 2131362593;
  
  public static final int tabMode = 2131362606;
  
  public static final int tag_accessibility_actions = 2131362607;
  
  public static final int tag_accessibility_clickable_spans = 2131362608;
  
  public static final int tag_accessibility_heading = 2131362609;
  
  public static final int tag_accessibility_pane_title = 2131362610;
  
  public static final int tag_screen_reader_focusable = 2131362616;
  
  public static final int tag_transition_group = 2131362618;
  
  public static final int tag_unhandled_key_event_manager = 2131362619;
  
  public static final int tag_unhandled_key_listeners = 2131362620;
  
  public static final int text = 2131362624;
  
  public static final int text2 = 2131362626;
  
  public static final int textSpacerNoButtons = 2131362628;
  
  public static final int textSpacerNoTitle = 2131362629;
  
  public static final int time = 2131362642;
  
  public static final int title = 2131362648;
  
  public static final int titleDividerNoCustom = 2131362649;
  
  public static final int title_template = 2131362650;
  
  public static final int top = 2131362654;
  
  public static final int topPanel = 2131362655;
  
  public static final int triangle = 2131362683;
  
  public static final int unchecked = 2131362700;
  
  public static final int uniform = 2131362703;
  
  public static final int up = 2131362710;
  
  public static final int vertical_only = 2131362717;
  
  public static final int view_transition = 2131362719;
  
  public static final int visible = 2131362724;
  
  public static final int west = 2131362731;
  
  public static final int wrap = 2131362744;
  
  public static final int wrap_content = 2131362745;
  
  public static final int wrap_content_constrained = 2131362746;
  
  public static final int x_left = 2131362747;
  
  public static final int x_right = 2131362748;
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\constraintlayout\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */