package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import r.l;

public abstract class j extends b {
  private boolean j;
  
  private boolean k;
  
  public j(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  protected void f(ConstraintLayout paramConstraintLayout) {
    e(paramConstraintLayout);
  }
  
  protected void i(AttributeSet paramAttributeSet) {
    super.i(paramAttributeSet);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, h.ConstraintLayout_Layout);
      int k = typedArray.getIndexCount();
      for (int i = 0; i < k; i++) {
        int m = typedArray.getIndex(i);
        if (m == h.ConstraintLayout_Layout_android_visibility) {
          this.j = true;
        } else if (m == h.ConstraintLayout_Layout_android_elevation) {
          this.k = true;
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.j || this.k) {
      ViewParent viewParent = getParent();
      if (viewParent instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)viewParent;
        int k = getVisibility();
        float f = getElevation();
        for (int i = 0; i < this.b; i++) {
          View view = constraintLayout.i(this.a[i]);
          if (view != null) {
            if (this.j)
              view.setVisibility(k); 
            if (this.k && f > 0.0F)
              view.setTranslationZ(view.getTranslationZ() + f); 
          } 
        } 
      } 
    } 
  }
  
  public abstract void p(l paraml, int paramInt1, int paramInt2);
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    d();
  }
  
  public void setVisibility(int paramInt) {
    super.setVisibility(paramInt);
    d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\constraintlayout\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */