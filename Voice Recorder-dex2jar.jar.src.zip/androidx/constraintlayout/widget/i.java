package androidx.constraintlayout.widget;

import android.util.SparseIntArray;
import java.util.HashMap;

public class i {
  private SparseIntArray a = new SparseIntArray();
  
  private HashMap b = new HashMap<Object, Object>();
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\constraintlayout\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */