package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.Arrays;
import java.util.HashMap;
import r.e;
import r.i;

public abstract class b extends View {
  protected int[] a = new int[32];
  
  protected int b;
  
  protected Context c;
  
  protected i d;
  
  protected boolean e = false;
  
  protected String f;
  
  protected String g;
  
  private View[] h = null;
  
  protected HashMap i = new HashMap<Object, Object>();
  
  public b(Context paramContext) {
    super(paramContext);
    this.c = paramContext;
    i(null);
  }
  
  public b(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.c = paramContext;
    i(paramAttributeSet);
  }
  
  private void a(String paramString) {
    if (paramString != null) {
      if (paramString.length() == 0)
        return; 
      if (this.c == null)
        return; 
      paramString = paramString.trim();
      if (getParent() instanceof ConstraintLayout)
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent(); 
      int j = h(paramString);
      if (j != 0) {
        this.i.put(Integer.valueOf(j), paramString);
        b(j);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find id of \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      Log.w("ConstraintHelper", stringBuilder.toString());
    } 
  }
  
  private void b(int paramInt) {
    if (paramInt == getId())
      return; 
    int j = this.b;
    int[] arrayOfInt = this.a;
    if (j + 1 > arrayOfInt.length)
      this.a = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2); 
    arrayOfInt = this.a;
    j = this.b;
    arrayOfInt[j] = paramInt;
    this.b = j + 1;
  }
  
  private void c(String paramString) {
    if (paramString != null) {
      if (paramString.length() == 0)
        return; 
      if (this.c == null)
        return; 
      String str = paramString.trim();
      if (getParent() instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent();
      } else {
        paramString = null;
      } 
      if (paramString == null) {
        Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
        return;
      } 
      int k = paramString.getChildCount();
      for (int j = 0; j < k; j++) {
        View view = paramString.getChildAt(j);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.b && str.equals(((ConstraintLayout.b)layoutParams).c0))
          if (view.getId() == -1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("to use ConstraintTag view ");
            stringBuilder.append(view.getClass().getSimpleName());
            stringBuilder.append(" must have an ID");
            Log.w("ConstraintHelper", stringBuilder.toString());
          } else {
            b(view.getId());
          }  
      } 
    } 
  }
  
  private int g(ConstraintLayout paramConstraintLayout, String paramString) {
    if (paramString != null) {
      if (paramConstraintLayout == null)
        return 0; 
      Resources resources = this.c.getResources();
      if (resources == null)
        return 0; 
      int k = paramConstraintLayout.getChildCount();
      int j = 0;
      while (true) {
        if (j < k) {
          View view = paramConstraintLayout.getChildAt(j);
          if (view.getId() != -1) {
            try {
              String str = resources.getResourceEntryName(view.getId());
            } catch (android.content.res.Resources.NotFoundException notFoundException) {
              notFoundException = null;
            } 
            if (paramString.equals(notFoundException))
              return view.getId(); 
          } 
          j++;
          continue;
        } 
        return 0;
      } 
    } 
    return 0;
  }
  
  private int h(String paramString) {
    ConstraintLayout constraintLayout;
    if (getParent() instanceof ConstraintLayout) {
      constraintLayout = (ConstraintLayout)getParent();
    } else {
      constraintLayout = null;
    } 
    boolean bool = isInEditMode();
    int j = 0;
    int k = j;
    if (bool) {
      k = j;
      if (constraintLayout != null) {
        Object object = constraintLayout.g(0, paramString);
        k = j;
        if (object instanceof Integer)
          k = ((Integer)object).intValue(); 
      } 
    } 
    j = k;
    if (k == 0) {
      j = k;
      if (constraintLayout != null)
        j = g(constraintLayout, paramString); 
    } 
    k = j;
    if (j == 0)
      try {
        k = g.class.getField(paramString).getInt(null);
      } catch (Exception exception) {
        k = j;
      }  
    j = k;
    if (k == 0)
      j = this.c.getResources().getIdentifier(paramString, "id", this.c.getPackageName()); 
    return j;
  }
  
  protected void d() {
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout)
      e((ConstraintLayout)viewParent); 
  }
  
  protected void e(ConstraintLayout paramConstraintLayout) {
    int k = getVisibility();
    float f = getElevation();
    for (int j = 0; j < this.b; j++) {
      View view = paramConstraintLayout.i(this.a[j]);
      if (view != null) {
        view.setVisibility(k);
        if (f > 0.0F)
          view.setTranslationZ(view.getTranslationZ() + f); 
      } 
    } 
  }
  
  protected void f(ConstraintLayout paramConstraintLayout) {}
  
  public int[] getReferencedIds() {
    return Arrays.copyOf(this.a, this.b);
  }
  
  protected void i(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, h.ConstraintLayout_Layout);
      int k = typedArray.getIndexCount();
      for (int j = 0; j < k; j++) {
        int m = typedArray.getIndex(j);
        if (m == h.ConstraintLayout_Layout_constraint_referenced_ids) {
          String str = typedArray.getString(m);
          this.f = str;
          setIds(str);
        } else if (m == h.ConstraintLayout_Layout_constraint_referenced_tags) {
          String str = typedArray.getString(m);
          this.g = str;
          setReferenceTags(str);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public abstract void j(e parame, boolean paramBoolean);
  
  public void k(ConstraintLayout paramConstraintLayout) {}
  
  public void l(ConstraintLayout paramConstraintLayout) {}
  
  public void m(ConstraintLayout paramConstraintLayout) {}
  
  public void n(ConstraintLayout paramConstraintLayout) {
    if (isInEditMode())
      setIds(this.f); 
    i i1 = this.d;
    if (i1 == null)
      return; 
    i1.b();
    for (int j = 0; j < this.b; j++) {
      int k = this.a[j];
      View view2 = paramConstraintLayout.i(k);
      View view1 = view2;
      if (view2 == null) {
        String str = (String)this.i.get(Integer.valueOf(k));
        k = g(paramConstraintLayout, str);
        view1 = view2;
        if (k != 0) {
          this.a[j] = k;
          this.i.put(Integer.valueOf(k), str);
          view1 = paramConstraintLayout.i(k);
        } 
      } 
      if (view1 != null)
        this.d.c(paramConstraintLayout.p(view1)); 
    } 
    this.d.a(paramConstraintLayout.c);
  }
  
  public void o() {
    if (this.d == null)
      return; 
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.b)
      ((ConstraintLayout.b)layoutParams).v0 = (e)this.d; 
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    String str = this.f;
    if (str != null)
      setIds(str); 
    str = this.g;
    if (str != null)
      setReferenceTags(str); 
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.e) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    setMeasuredDimension(0, 0);
  }
  
  protected void setIds(String paramString) {
    this.f = paramString;
    if (paramString == null)
      return; 
    int j = 0;
    this.b = 0;
    while (true) {
      int k = paramString.indexOf(',', j);
      if (k == -1) {
        a(paramString.substring(j));
        return;
      } 
      a(paramString.substring(j, k));
      j = k + 1;
    } 
  }
  
  protected void setReferenceTags(String paramString) {
    this.g = paramString;
    if (paramString == null)
      return; 
    int j = 0;
    this.b = 0;
    while (true) {
      int k = paramString.indexOf(',', j);
      if (k == -1) {
        c(paramString.substring(j));
        return;
      } 
      c(paramString.substring(j, k));
      j = k + 1;
    } 
  }
  
  public void setReferencedIds(int[] paramArrayOfint) {
    this.f = null;
    int j = 0;
    this.b = 0;
    while (j < paramArrayOfint.length) {
      b(paramArrayOfint[j]);
      j++;
    } 
  }
  
  public void setTag(int paramInt, Object paramObject) {
    super.setTag(paramInt, paramObject);
    if (paramObject == null && this.f == null)
      b(paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\constraintlayout\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */