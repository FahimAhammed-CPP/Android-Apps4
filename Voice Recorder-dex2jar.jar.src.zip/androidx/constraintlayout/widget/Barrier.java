package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import r.a;
import r.e;
import r.i;

public class Barrier extends b {
  private int j;
  
  private int k;
  
  private a l;
  
  public Barrier(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  public Barrier(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setVisibility(8);
  }
  
  private void p(e parame, int paramInt, boolean paramBoolean) {
    this.k = paramInt;
    if (paramBoolean) {
      paramInt = this.j;
      if (paramInt == 5) {
        this.k = 1;
      } else if (paramInt == 6) {
        this.k = 0;
      } 
    } else {
      paramInt = this.j;
      if (paramInt == 5) {
        this.k = 0;
      } else if (paramInt == 6) {
        this.k = 1;
      } 
    } 
    if (parame instanceof a)
      ((a)parame).A1(this.k); 
  }
  
  public boolean getAllowsGoneWidget() {
    return this.l.u1();
  }
  
  public int getMargin() {
    return this.l.w1();
  }
  
  public int getType() {
    return this.j;
  }
  
  protected void i(AttributeSet paramAttributeSet) {
    super.i(paramAttributeSet);
    this.l = new a();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, h.ConstraintLayout_Layout);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == h.ConstraintLayout_Layout_barrierDirection) {
          setType(typedArray.getInt(k, 0));
        } else if (k == h.ConstraintLayout_Layout_barrierAllowsGoneWidgets) {
          this.l.z1(typedArray.getBoolean(k, true));
        } else if (k == h.ConstraintLayout_Layout_barrierMargin) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.l.B1(k);
        } 
      } 
      typedArray.recycle();
    } 
    this.d = (i)this.l;
    o();
  }
  
  public void j(e parame, boolean paramBoolean) {
    p(parame, this.j, paramBoolean);
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.l.z1(paramBoolean);
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.l.B1(paramInt);
  }
  
  public void setMargin(int paramInt) {
    this.l.B1(paramInt);
  }
  
  public void setType(int paramInt) {
    this.j = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\constraintlayout\widget\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */