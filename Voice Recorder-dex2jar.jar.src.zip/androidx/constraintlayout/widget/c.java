package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class c {
  private final ConstraintLayout a;
  
  int b = -1;
  
  int c = -1;
  
  private SparseArray d = new SparseArray();
  
  private SparseArray e = new SparseArray();
  
  c(Context paramContext, ConstraintLayout paramConstraintLayout, int paramInt) {
    this.a = paramConstraintLayout;
    a(paramContext, paramInt);
  }
  
  private void a(Context paramContext, int paramInt) {
    String str;
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    try {
      paramInt = xmlResourceParser.getEventType();
      str = null;
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      boolean bool = true;
      if (paramInt != 1) {
        String str1;
        if (paramInt != 0) {
          if (paramInt != 2) {
            str1 = str;
          } else {
            str1 = xmlResourceParser.getName();
            switch (str1.hashCode()) {
              case 1901439077:
                if (str1.equals("Variant")) {
                  paramInt = 3;
                  break;
                } 
              case 1657696882:
                if (str1.equals("layoutDescription")) {
                  paramInt = 0;
                  break;
                } 
              case 1382829617:
                if (str1.equals("StateSet")) {
                  paramInt = bool;
                  break;
                } 
              case 80204913:
                if (str1.equals("State")) {
                  paramInt = 2;
                  break;
                } 
              case -1349929691:
                if (str1.equals("ConstraintSet")) {
                  paramInt = 4;
                  break;
                } 
              default:
                paramInt = -1;
                break;
            } 
            if (paramInt != 2) {
              if (paramInt != 3) {
                if (paramInt != 4) {
                  str1 = str;
                } else {
                  b((Context)iOException, (XmlPullParser)xmlResourceParser);
                  str1 = str;
                } 
              } else {
                b b = new b((Context)iOException, (XmlPullParser)xmlResourceParser);
                str1 = str;
                if (str != null) {
                  str.a(b);
                  str1 = str;
                } 
              } 
            } else {
              a a = new a((Context)iOException, (XmlPullParser)xmlResourceParser);
              this.d.put(a.a, a);
            } 
          } 
        } else {
          xmlResourceParser.getName();
          str1 = str;
        } 
        paramInt = xmlResourceParser.next();
        str = str1;
        continue;
      } 
      return;
    } 
  }
  
  private void b(Context paramContext, XmlPullParser paramXmlPullParser) {
    d d = new d();
    int j = paramXmlPullParser.getAttributeCount();
    for (int i = 0; i < j; i++) {
      String str2 = paramXmlPullParser.getAttributeName(i);
      String str1 = paramXmlPullParser.getAttributeValue(i);
      if (str2 != null && str1 != null && "id".equals(str2)) {
        if (str1.contains("/")) {
          str2 = str1.substring(str1.indexOf('/') + 1);
          i = paramContext.getResources().getIdentifier(str2, "id", paramContext.getPackageName());
        } else {
          i = -1;
        } 
        j = i;
        if (i == -1)
          if (str1.length() > 1) {
            j = Integer.parseInt(str1.substring(1));
          } else {
            Log.e("ConstraintLayoutStates", "error in parsing id");
            j = i;
          }  
        d.l(paramContext, paramXmlPullParser);
        this.e.put(j, d);
        return;
      } 
    } 
  }
  
  public void c(e parame) {}
  
  static class a {
    int a;
    
    ArrayList b = new ArrayList();
    
    int c = -1;
    
    d d;
    
    public a(Context param1Context, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), h.State);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == h.State_android_id) {
          this.a = typedArray.getResourceId(k, this.a);
        } else if (k == h.State_constraints) {
          this.c = typedArray.getResourceId(k, this.c);
          String str = param1Context.getResources().getResourceTypeName(this.c);
          param1Context.getResources().getResourceName(this.c);
          if ("layout".equals(str)) {
            d d1 = new d();
            this.d = d1;
            d1.e(param1Context, this.c);
          } 
        } 
      } 
      typedArray.recycle();
    }
    
    void a(c.b param1b) {
      this.b.add(param1b);
    }
  }
  
  static class b {
    float a = Float.NaN;
    
    float b = Float.NaN;
    
    float c = Float.NaN;
    
    float d = Float.NaN;
    
    int e = -1;
    
    d f;
    
    public b(Context param1Context, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), h.Variant);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == h.Variant_constraints) {
          this.e = typedArray.getResourceId(k, this.e);
          String str = param1Context.getResources().getResourceTypeName(this.e);
          param1Context.getResources().getResourceName(this.e);
          if ("layout".equals(str)) {
            d d1 = new d();
            this.f = d1;
            d1.e(param1Context, this.e);
          } 
        } else if (k == h.Variant_region_heightLessThan) {
          this.d = typedArray.getDimension(k, this.d);
        } else if (k == h.Variant_region_heightMoreThan) {
          this.b = typedArray.getDimension(k, this.b);
        } else if (k == h.Variant_region_widthLessThan) {
          this.c = typedArray.getDimension(k, this.c);
        } else if (k == h.Variant_region_widthMoreThan) {
          this.a = typedArray.getDimension(k, this.a);
        } else {
          Log.v("ConstraintLayoutStates", "Unknown tag");
        } 
      } 
      typedArray.recycle();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\constraintlayout\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */