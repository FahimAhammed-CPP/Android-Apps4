package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.HashMap;
import r.d;
import r.e;
import r.f;
import r.h;

public class ConstraintLayout extends ViewGroup {
  private static i x;
  
  SparseArray a = new SparseArray();
  
  private ArrayList b = new ArrayList(4);
  
  protected f c = new f();
  
  private int d = 0;
  
  private int e = 0;
  
  private int f = Integer.MAX_VALUE;
  
  private int g = Integer.MAX_VALUE;
  
  protected boolean h = true;
  
  private int i = 257;
  
  private d j = null;
  
  protected c k = null;
  
  private int l = -1;
  
  private HashMap m = new HashMap<Object, Object>();
  
  private int n = -1;
  
  private int o = -1;
  
  int p = -1;
  
  int q = -1;
  
  int r = 0;
  
  int s = 0;
  
  private SparseArray t = new SparseArray();
  
  c u = new c(this, this);
  
  private int v = 0;
  
  private int w = 0;
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    q(paramAttributeSet, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    q(paramAttributeSet, paramInt, 0);
  }
  
  private boolean A() {
    boolean bool1;
    int k = getChildCount();
    boolean bool2 = false;
    int j = 0;
    while (true) {
      bool1 = bool2;
      if (j < k) {
        if (getChildAt(j).isLayoutRequested()) {
          bool1 = true;
          break;
        } 
        j++;
        continue;
      } 
      break;
    } 
    if (bool1)
      w(); 
    return bool1;
  }
  
  private int getPaddingWidth() {
    int j = Math.max(0, getPaddingLeft()) + Math.max(0, getPaddingRight());
    int k = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
    if (k > 0)
      j = k; 
    return j;
  }
  
  public static i getSharedValues() {
    if (x == null)
      x = new i(); 
    return x;
  }
  
  private final e h(int paramInt) {
    if (paramInt == 0)
      return (e)this.c; 
    View view2 = (View)this.a.get(paramInt);
    View view1 = view2;
    if (view2 == null) {
      view2 = findViewById(paramInt);
      view1 = view2;
      if (view2 != null) {
        view1 = view2;
        if (view2 != this) {
          view1 = view2;
          if (view2.getParent() == this) {
            onViewAdded(view2);
            view1 = view2;
          } 
        } 
      } 
    } 
    return (e)((view1 == this) ? this.c : ((view1 == null) ? null : ((b)view1.getLayoutParams()).v0));
  }
  
  private void q(AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.c.B0(this);
    this.c.V1(this.u);
    this.a.put(getId(), this);
    this.j = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, h.ConstraintLayout_Layout, paramInt1, paramInt2);
      paramInt2 = typedArray.getIndexCount();
      paramInt1 = 0;
      while (true) {
        if (paramInt1 < paramInt2) {
          int j = typedArray.getIndex(paramInt1);
          if (j == h.ConstraintLayout_Layout_android_minWidth) {
            this.d = typedArray.getDimensionPixelOffset(j, this.d);
          } else if (j == h.ConstraintLayout_Layout_android_minHeight) {
            this.e = typedArray.getDimensionPixelOffset(j, this.e);
          } else if (j == h.ConstraintLayout_Layout_android_maxWidth) {
            this.f = typedArray.getDimensionPixelOffset(j, this.f);
          } else if (j == h.ConstraintLayout_Layout_android_maxHeight) {
            this.g = typedArray.getDimensionPixelOffset(j, this.g);
          } else if (j == h.ConstraintLayout_Layout_layout_optimizationLevel) {
            this.i = typedArray.getInt(j, this.i);
          } else if (j == h.ConstraintLayout_Layout_layoutDescription) {
            j = typedArray.getResourceId(j, 0);
            if (j != 0)
              try {
                t(j);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                this.k = null;
              }  
          } else if (j == h.ConstraintLayout_Layout_constraintSet) {
            j = typedArray.getResourceId(j, 0);
            try {
              d d1 = new d();
              this.j = d1;
              d1.k(getContext(), j);
            } catch (android.content.res.Resources.NotFoundException notFoundException) {
              this.j = null;
            } 
            this.l = j;
          } 
          paramInt1++;
          continue;
        } 
        typedArray.recycle();
        this.c.W1(this.i);
        return;
      } 
    } 
    this.c.W1(this.i);
  }
  
  private void s() {
    this.h = true;
    this.n = -1;
    this.o = -1;
    this.p = -1;
    this.q = -1;
    this.r = 0;
    this.s = 0;
  }
  
  private void w() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getChildCount : ()I
    //   10: istore_2
    //   11: iconst_0
    //   12: istore_1
    //   13: iload_1
    //   14: iload_2
    //   15: if_icmpge -> 49
    //   18: aload_0
    //   19: aload_0
    //   20: iload_1
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: invokevirtual p : (Landroid/view/View;)Lr/e;
    //   27: astore #5
    //   29: aload #5
    //   31: ifnonnull -> 37
    //   34: goto -> 42
    //   37: aload #5
    //   39: invokevirtual t0 : ()V
    //   42: iload_1
    //   43: iconst_1
    //   44: iadd
    //   45: istore_1
    //   46: goto -> 13
    //   49: iload #4
    //   51: ifeq -> 145
    //   54: iconst_0
    //   55: istore_1
    //   56: iload_1
    //   57: iload_2
    //   58: if_icmpge -> 145
    //   61: aload_0
    //   62: iload_1
    //   63: invokevirtual getChildAt : (I)Landroid/view/View;
    //   66: astore #7
    //   68: aload_0
    //   69: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   72: aload #7
    //   74: invokevirtual getId : ()I
    //   77: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   80: astore #6
    //   82: aload_0
    //   83: iconst_0
    //   84: aload #6
    //   86: aload #7
    //   88: invokevirtual getId : ()I
    //   91: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   94: invokevirtual x : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   97: aload #6
    //   99: bipush #47
    //   101: invokevirtual indexOf : (I)I
    //   104: istore_3
    //   105: aload #6
    //   107: astore #5
    //   109: iload_3
    //   110: iconst_m1
    //   111: if_icmpeq -> 124
    //   114: aload #6
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: invokevirtual substring : (I)Ljava/lang/String;
    //   122: astore #5
    //   124: aload_0
    //   125: aload #7
    //   127: invokevirtual getId : ()I
    //   130: invokespecial h : (I)Lr/e;
    //   133: aload #5
    //   135: invokevirtual C0 : (Ljava/lang/String;)V
    //   138: iload_1
    //   139: iconst_1
    //   140: iadd
    //   141: istore_1
    //   142: goto -> 56
    //   145: aload_0
    //   146: getfield l : I
    //   149: iconst_m1
    //   150: if_icmpeq -> 181
    //   153: iconst_0
    //   154: istore_1
    //   155: iload_1
    //   156: iload_2
    //   157: if_icmpge -> 181
    //   160: aload_0
    //   161: iload_1
    //   162: invokevirtual getChildAt : (I)Landroid/view/View;
    //   165: invokevirtual getId : ()I
    //   168: pop
    //   169: aload_0
    //   170: getfield l : I
    //   173: istore_3
    //   174: iload_1
    //   175: iconst_1
    //   176: iadd
    //   177: istore_1
    //   178: goto -> 155
    //   181: aload_0
    //   182: getfield j : Landroidx/constraintlayout/widget/d;
    //   185: astore #5
    //   187: aload #5
    //   189: ifnull -> 199
    //   192: aload #5
    //   194: aload_0
    //   195: iconst_1
    //   196: invokevirtual d : (Landroidx/constraintlayout/widget/ConstraintLayout;Z)V
    //   199: aload_0
    //   200: getfield c : Lr/f;
    //   203: invokevirtual u1 : ()V
    //   206: aload_0
    //   207: getfield b : Ljava/util/ArrayList;
    //   210: invokevirtual size : ()I
    //   213: istore_3
    //   214: iload_3
    //   215: ifle -> 247
    //   218: iconst_0
    //   219: istore_1
    //   220: iload_1
    //   221: iload_3
    //   222: if_icmpge -> 247
    //   225: aload_0
    //   226: getfield b : Ljava/util/ArrayList;
    //   229: iload_1
    //   230: invokevirtual get : (I)Ljava/lang/Object;
    //   233: checkcast androidx/constraintlayout/widget/b
    //   236: aload_0
    //   237: invokevirtual n : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   240: iload_1
    //   241: iconst_1
    //   242: iadd
    //   243: istore_1
    //   244: goto -> 220
    //   247: iconst_0
    //   248: istore_1
    //   249: iload_1
    //   250: iload_2
    //   251: if_icmpge -> 267
    //   254: aload_0
    //   255: iload_1
    //   256: invokevirtual getChildAt : (I)Landroid/view/View;
    //   259: pop
    //   260: iload_1
    //   261: iconst_1
    //   262: iadd
    //   263: istore_1
    //   264: goto -> 249
    //   267: aload_0
    //   268: getfield t : Landroid/util/SparseArray;
    //   271: invokevirtual clear : ()V
    //   274: aload_0
    //   275: getfield t : Landroid/util/SparseArray;
    //   278: iconst_0
    //   279: aload_0
    //   280: getfield c : Lr/f;
    //   283: invokevirtual put : (ILjava/lang/Object;)V
    //   286: aload_0
    //   287: getfield t : Landroid/util/SparseArray;
    //   290: aload_0
    //   291: invokevirtual getId : ()I
    //   294: aload_0
    //   295: getfield c : Lr/f;
    //   298: invokevirtual put : (ILjava/lang/Object;)V
    //   301: iconst_0
    //   302: istore_1
    //   303: iload_1
    //   304: iload_2
    //   305: if_icmpge -> 344
    //   308: aload_0
    //   309: iload_1
    //   310: invokevirtual getChildAt : (I)Landroid/view/View;
    //   313: astore #5
    //   315: aload_0
    //   316: aload #5
    //   318: invokevirtual p : (Landroid/view/View;)Lr/e;
    //   321: astore #6
    //   323: aload_0
    //   324: getfield t : Landroid/util/SparseArray;
    //   327: aload #5
    //   329: invokevirtual getId : ()I
    //   332: aload #6
    //   334: invokevirtual put : (ILjava/lang/Object;)V
    //   337: iload_1
    //   338: iconst_1
    //   339: iadd
    //   340: istore_1
    //   341: goto -> 303
    //   344: iconst_0
    //   345: istore_1
    //   346: iload_1
    //   347: iload_2
    //   348: if_icmpge -> 416
    //   351: aload_0
    //   352: iload_1
    //   353: invokevirtual getChildAt : (I)Landroid/view/View;
    //   356: astore #5
    //   358: aload_0
    //   359: aload #5
    //   361: invokevirtual p : (Landroid/view/View;)Lr/e;
    //   364: astore #6
    //   366: aload #6
    //   368: ifnonnull -> 374
    //   371: goto -> 409
    //   374: aload #5
    //   376: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   379: checkcast androidx/constraintlayout/widget/ConstraintLayout$b
    //   382: astore #7
    //   384: aload_0
    //   385: getfield c : Lr/f;
    //   388: aload #6
    //   390: invokevirtual c : (Lr/e;)V
    //   393: aload_0
    //   394: iload #4
    //   396: aload #5
    //   398: aload #6
    //   400: aload #7
    //   402: aload_0
    //   403: getfield t : Landroid/util/SparseArray;
    //   406: invokevirtual d : (ZLandroid/view/View;Lr/e;Landroidx/constraintlayout/widget/ConstraintLayout$b;Landroid/util/SparseArray;)V
    //   409: iload_1
    //   410: iconst_1
    //   411: iadd
    //   412: istore_1
    //   413: goto -> 346
    //   416: return
    //   417: astore #5
    //   419: goto -> 138
    // Exception table:
    //   from	to	target	type
    //   68	105	417	android/content/res/Resources$NotFoundException
    //   114	124	417	android/content/res/Resources$NotFoundException
    //   124	138	417	android/content/res/Resources$NotFoundException
  }
  
  private void z(e parame, b paramb, SparseArray paramSparseArray, int paramInt, d.b paramb1) {
    View view = (View)this.a.get(paramInt);
    e e1 = (e)paramSparseArray.get(paramInt);
    if (e1 != null && view != null && view.getLayoutParams() instanceof b) {
      paramb.g0 = true;
      d.b b1 = d.b.f;
      if (paramb1 == b1) {
        b b2 = (b)view.getLayoutParams();
        b2.g0 = true;
        b2.v0.K0(true);
      } 
      parame.o(b1).b(e1.o(paramb1), paramb.D, paramb.C, true);
      parame.K0(true);
      parame.o(d.b.c).q();
      parame.o(d.b.e).q();
    } 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof b;
  }
  
  protected void d(boolean paramBoolean, View paramView, e parame, b paramb, SparseArray paramSparseArray) {
    paramb.a();
    paramb.w0 = false;
    parame.j1(paramView.getVisibility());
    if (paramb.j0) {
      parame.T0(true);
      parame.j1(8);
    } 
    parame.B0(paramView);
    if (paramView instanceof b)
      ((b)paramView).j(parame, this.c.P1()); 
    if (paramb.h0) {
      h h = (h)parame;
      int j = paramb.s0;
      int k = paramb.t0;
      float f1 = paramb.u0;
      if (f1 != -1.0F) {
        h.z1(f1);
        return;
      } 
      if (j != -1) {
        h.x1(j);
        return;
      } 
      if (k != -1) {
        h.y1(k);
        return;
      } 
    } else {
      int j = paramb.l0;
      int k = paramb.m0;
      int m = paramb.n0;
      int n = paramb.o0;
      int i1 = paramb.p0;
      int i2 = paramb.q0;
      float f1 = paramb.r0;
      int i3 = paramb.p;
      if (i3 != -1) {
        e e1 = (e)paramSparseArray.get(i3);
        if (e1 != null)
          parame.l(e1, paramb.r, paramb.q); 
      } else {
        if (j != -1) {
          e e1 = (e)paramSparseArray.get(j);
          if (e1 != null) {
            d.b b1 = d.b.b;
            parame.e0(b1, e1, b1, paramb.leftMargin, i1);
          } 
        } else if (k != -1) {
          e e1 = (e)paramSparseArray.get(k);
          if (e1 != null)
            parame.e0(d.b.b, e1, d.b.d, paramb.leftMargin, i1); 
        } 
        if (m != -1) {
          e e1 = (e)paramSparseArray.get(m);
          if (e1 != null)
            parame.e0(d.b.d, e1, d.b.b, paramb.rightMargin, i2); 
        } else if (n != -1) {
          e e1 = (e)paramSparseArray.get(n);
          if (e1 != null) {
            d.b b1 = d.b.d;
            parame.e0(b1, e1, b1, paramb.rightMargin, i2);
          } 
        } 
        j = paramb.i;
        if (j != -1) {
          e e1 = (e)paramSparseArray.get(j);
          if (e1 != null) {
            d.b b1 = d.b.c;
            parame.e0(b1, e1, b1, paramb.topMargin, paramb.x);
          } 
        } else {
          j = paramb.j;
          if (j != -1) {
            e e1 = (e)paramSparseArray.get(j);
            if (e1 != null)
              parame.e0(d.b.c, e1, d.b.e, paramb.topMargin, paramb.x); 
          } 
        } 
        j = paramb.k;
        if (j != -1) {
          e e1 = (e)paramSparseArray.get(j);
          if (e1 != null)
            parame.e0(d.b.e, e1, d.b.c, paramb.bottomMargin, paramb.z); 
        } else {
          j = paramb.l;
          if (j != -1) {
            e e1 = (e)paramSparseArray.get(j);
            if (e1 != null) {
              d.b b1 = d.b.e;
              parame.e0(b1, e1, b1, paramb.bottomMargin, paramb.z);
            } 
          } 
        } 
        j = paramb.m;
        if (j != -1) {
          z(parame, paramb, paramSparseArray, j, d.b.f);
        } else {
          j = paramb.n;
          if (j != -1) {
            z(parame, paramb, paramSparseArray, j, d.b.c);
          } else {
            j = paramb.o;
            if (j != -1)
              z(parame, paramb, paramSparseArray, j, d.b.e); 
          } 
        } 
        if (f1 >= 0.0F)
          parame.M0(f1); 
        f1 = paramb.H;
        if (f1 >= 0.0F)
          parame.d1(f1); 
      } 
      if (paramBoolean) {
        j = paramb.X;
        if (j != -1 || paramb.Y != -1)
          parame.b1(j, paramb.Y); 
      } 
      if (!paramb.e0) {
        if (paramb.width == -1) {
          if (paramb.a0) {
            parame.P0(e.b.c);
          } else {
            parame.P0(e.b.d);
          } 
          (parame.o(d.b.b)).g = paramb.leftMargin;
          (parame.o(d.b.d)).g = paramb.rightMargin;
        } else {
          parame.P0(e.b.c);
          parame.k1(0);
        } 
      } else {
        parame.P0(e.b.a);
        parame.k1(paramb.width);
        if (paramb.width == -2)
          parame.P0(e.b.b); 
      } 
      if (!paramb.f0) {
        if (paramb.height == -1) {
          if (paramb.b0) {
            parame.g1(e.b.c);
          } else {
            parame.g1(e.b.d);
          } 
          (parame.o(d.b.c)).g = paramb.topMargin;
          (parame.o(d.b.e)).g = paramb.bottomMargin;
        } else {
          parame.g1(e.b.c);
          parame.L0(0);
        } 
      } else {
        parame.g1(e.b.a);
        parame.L0(paramb.height);
        if (paramb.height == -2)
          parame.g1(e.b.b); 
      } 
      parame.D0(paramb.I);
      parame.R0(paramb.L);
      parame.i1(paramb.M);
      parame.N0(paramb.N);
      parame.e1(paramb.O);
      parame.l1(paramb.d0);
      parame.Q0(paramb.P, paramb.R, paramb.T, paramb.V);
      parame.h1(paramb.Q, paramb.S, paramb.U, paramb.W);
    } 
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList arrayList = this.b;
    if (arrayList != null) {
      int j = arrayList.size();
      if (j > 0) {
        int k;
        for (k = 0; k < j; k++)
          ((b)this.b.get(k)).m(this); 
      } 
    } 
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      float f1 = getWidth();
      float f2 = getHeight();
      int k = getChildCount();
      int j;
      for (j = 0; j < k; j++) {
        View view = getChildAt(j);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(",");
            if (object.length == 4) {
              int n = Integer.parseInt((String)object[0]);
              int i2 = Integer.parseInt((String)object[1]);
              int i1 = Integer.parseInt((String)object[2]);
              int m = Integer.parseInt((String)object[3]);
              n = (int)(n / 1080.0F * f1);
              i2 = (int)(i2 / 1920.0F * f2);
              i1 = (int)(i1 / 1080.0F * f1);
              m = (int)(m / 1920.0F * f2);
              object = new Paint();
              object.setColor(-65536);
              float f3 = n;
              float f4 = i2;
              float f5 = (n + i1);
              paramCanvas.drawLine(f3, f4, f5, f4, (Paint)object);
              float f6 = (i2 + m);
              paramCanvas.drawLine(f5, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f5, f6, f3, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f3, f4, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(f3, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f5, f4, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  protected b e() {
    return new b(-2, -2);
  }
  
  public b f(AttributeSet paramAttributeSet) {
    return new b(getContext(), paramAttributeSet);
  }
  
  public void forceLayout() {
    s();
    super.forceLayout();
  }
  
  public Object g(int paramInt, Object paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      paramObject = paramObject;
      HashMap hashMap = this.m;
      if (hashMap != null && hashMap.containsKey(paramObject))
        return this.m.get(paramObject); 
    } 
    return null;
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new b(paramLayoutParams);
  }
  
  public int getMaxHeight() {
    return this.g;
  }
  
  public int getMaxWidth() {
    return this.f;
  }
  
  public int getMinHeight() {
    return this.e;
  }
  
  public int getMinWidth() {
    return this.d;
  }
  
  public int getOptimizationLevel() {
    return this.c.J1();
  }
  
  public String getSceneString() {
    StringBuilder stringBuilder = new StringBuilder();
    if (((e)this.c).o == null) {
      int j = getId();
      if (j != -1) {
        String str = getContext().getResources().getResourceEntryName(j);
        ((e)this.c).o = str;
      } else {
        ((e)this.c).o = "parent";
      } 
    } 
    if (this.c.t() == null) {
      f f1 = this.c;
      f1.C0(((e)f1).o);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" setDebugName ");
      stringBuilder1.append(this.c.t());
      Log.v("ConstraintLayout", stringBuilder1.toString());
    } 
    for (e e : this.c.r1()) {
      View view = (View)e.s();
      if (view != null) {
        if (e.o == null) {
          int j = view.getId();
          if (j != -1)
            e.o = getContext().getResources().getResourceEntryName(j); 
        } 
        if (e.t() == null) {
          e.C0(e.o);
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" setDebugName ");
          stringBuilder1.append(e.t());
          Log.v("ConstraintLayout", stringBuilder1.toString());
        } 
      } 
    } 
    this.c.O(stringBuilder);
    return stringBuilder.toString();
  }
  
  public View i(int paramInt) {
    return (View)this.a.get(paramInt);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt2 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      b b = (b)view.getLayoutParams();
      e e = b.v0;
      if ((view.getVisibility() != 8 || b.h0 || b.i0 || b.k0 || paramBoolean) && !b.j0) {
        paramInt4 = e.X();
        int j = e.Y();
        view.layout(paramInt4, j, e.W() + paramInt4, e.x() + j);
      } 
    } 
    paramInt3 = this.b.size();
    if (paramInt3 > 0)
      for (paramInt1 = paramInt2; paramInt1 < paramInt3; paramInt1++)
        ((b)this.b.get(paramInt1)).k(this);  
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.v == paramInt1)
      int j = this.w; 
    if (!this.h) {
      int k = getChildCount();
      for (int j = 0; j < k; j++) {
        if (getChildAt(j).isLayoutRequested()) {
          this.h = true;
          break;
        } 
      } 
    } 
    boolean bool = this.h;
    this.v = paramInt1;
    this.w = paramInt2;
    this.c.Y1(r());
    if (this.h) {
      this.h = false;
      if (A())
        this.c.a2(); 
    } 
    v(this.c, this.i, paramInt1, paramInt2);
    u(paramInt1, paramInt2, this.c.W(), this.c.x(), this.c.Q1(), this.c.O1());
  }
  
  public void onViewAdded(View paramView) {
    super.onViewAdded(paramView);
    e e = p(paramView);
    if (paramView instanceof f && !(e instanceof h)) {
      b b = (b)paramView.getLayoutParams();
      h h = new h();
      b.v0 = (e)h;
      b.h0 = true;
      h.A1(b.Z);
    } 
    if (paramView instanceof b) {
      b b = (b)paramView;
      b.o();
      ((b)paramView.getLayoutParams()).i0 = true;
      if (!this.b.contains(b))
        this.b.add(b); 
    } 
    this.a.put(paramView.getId(), paramView);
    this.h = true;
  }
  
  public void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    this.a.remove(paramView.getId());
    e e = p(paramView);
    this.c.t1(e);
    this.b.remove(paramView);
    this.h = true;
  }
  
  public final e p(View paramView) {
    if (paramView == this)
      return (e)this.c; 
    if (paramView != null) {
      if (paramView.getLayoutParams() instanceof b)
        return ((b)paramView.getLayoutParams()).v0; 
      paramView.setLayoutParams(generateLayoutParams(paramView.getLayoutParams()));
      if (paramView.getLayoutParams() instanceof b)
        return ((b)paramView.getLayoutParams()).v0; 
    } 
    return null;
  }
  
  protected boolean r() {
    int j = (getContext().getApplicationInfo()).flags;
    boolean bool2 = false;
    if ((j & 0x400000) != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    boolean bool1 = bool2;
    if (j != 0) {
      bool1 = bool2;
      if (1 == getLayoutDirection())
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void requestLayout() {
    s();
    super.requestLayout();
  }
  
  public void setConstraintSet(d paramd) {
    this.j = paramd;
  }
  
  public void setId(int paramInt) {
    this.a.remove(getId());
    super.setId(paramInt);
    this.a.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.g)
      return; 
    this.g = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.f)
      return; 
    this.f = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.e)
      return; 
    this.e = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.d)
      return; 
    this.d = paramInt;
    requestLayout();
  }
  
  public void setOnConstraintsChanged(e parame) {
    c c1 = this.k;
    if (c1 != null)
      c1.c(parame); 
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.i = paramInt;
    this.c.W1(paramInt);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  protected void t(int paramInt) {
    this.k = new c(getContext(), this, paramInt);
  }
  
  protected void u(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2) {
    c c1 = this.u;
    int j = c1.e;
    paramInt1 = View.resolveSizeAndState(paramInt3 + c1.d, paramInt1, 0);
    paramInt3 = View.resolveSizeAndState(paramInt4 + j, paramInt2, 0);
    paramInt2 = Math.min(this.f, paramInt1 & 0xFFFFFF);
    paramInt3 = Math.min(this.g, paramInt3 & 0xFFFFFF);
    paramInt1 = paramInt2;
    if (paramBoolean1)
      paramInt1 = paramInt2 | 0x1000000; 
    paramInt2 = paramInt3;
    if (paramBoolean2)
      paramInt2 = paramInt3 | 0x1000000; 
    setMeasuredDimension(paramInt1, paramInt2);
    this.n = paramInt1;
    this.o = paramInt2;
  }
  
  protected void v(f paramf, int paramInt1, int paramInt2, int paramInt3) {
    int j = View.MeasureSpec.getMode(paramInt2);
    int i2 = View.MeasureSpec.getSize(paramInt2);
    int k = View.MeasureSpec.getMode(paramInt3);
    int n = View.MeasureSpec.getSize(paramInt3);
    int m = Math.max(0, getPaddingTop());
    int i4 = Math.max(0, getPaddingBottom());
    int i1 = m + i4;
    int i3 = getPaddingWidth();
    this.u.c(paramInt2, paramInt3, m, i4, i3, i1);
    paramInt2 = Math.max(0, getPaddingStart());
    paramInt3 = Math.max(0, getPaddingEnd());
    if (paramInt2 > 0 || paramInt3 > 0) {
      if (r())
        paramInt2 = paramInt3; 
    } else {
      paramInt2 = Math.max(0, getPaddingLeft());
    } 
    paramInt3 = i2 - i3;
    n -= i1;
    y(paramf, j, paramInt3, k, n);
    paramf.R1(paramInt1, j, paramInt3, k, n, this.n, this.o, paramInt2, m);
  }
  
  public void x(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.m == null)
        this.m = new HashMap<Object, Object>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramInt = ((Integer)paramObject2).intValue();
      this.m.put(paramObject1, Integer.valueOf(paramInt));
    } 
  }
  
  protected void y(f paramf, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: getfield u : Landroidx/constraintlayout/widget/ConstraintLayout$c;
    //   4: astore #9
    //   6: aload #9
    //   8: getfield e : I
    //   11: istore #6
    //   13: aload #9
    //   15: getfield d : I
    //   18: istore #7
    //   20: getstatic r/e$b.a : Lr/e$b;
    //   23: astore #9
    //   25: aload_0
    //   26: invokevirtual getChildCount : ()I
    //   29: istore #8
    //   31: iload_2
    //   32: ldc_w -2147483648
    //   35: if_icmpeq -> 107
    //   38: iload_2
    //   39: ifeq -> 77
    //   42: iload_2
    //   43: ldc_w 1073741824
    //   46: if_icmpeq -> 58
    //   49: aload #9
    //   51: astore #10
    //   53: iconst_0
    //   54: istore_3
    //   55: goto -> 134
    //   58: aload_0
    //   59: getfield f : I
    //   62: iload #7
    //   64: isub
    //   65: iload_3
    //   66: invokestatic min : (II)I
    //   69: istore_3
    //   70: aload #9
    //   72: astore #10
    //   74: goto -> 134
    //   77: getstatic r/e$b.b : Lr/e$b;
    //   80: astore #11
    //   82: aload #11
    //   84: astore #10
    //   86: iload #8
    //   88: ifne -> 53
    //   91: iconst_0
    //   92: aload_0
    //   93: getfield d : I
    //   96: invokestatic max : (II)I
    //   99: istore_3
    //   100: aload #11
    //   102: astore #10
    //   104: goto -> 134
    //   107: getstatic r/e$b.b : Lr/e$b;
    //   110: astore #11
    //   112: aload #11
    //   114: astore #10
    //   116: iload #8
    //   118: ifne -> 134
    //   121: iconst_0
    //   122: aload_0
    //   123: getfield d : I
    //   126: invokestatic max : (II)I
    //   129: istore_3
    //   130: aload #11
    //   132: astore #10
    //   134: iload #4
    //   136: ldc_w -2147483648
    //   139: if_icmpeq -> 209
    //   142: iload #4
    //   144: ifeq -> 178
    //   147: iload #4
    //   149: ldc_w 1073741824
    //   152: if_icmpeq -> 161
    //   155: iconst_0
    //   156: istore #5
    //   158: goto -> 237
    //   161: aload_0
    //   162: getfield g : I
    //   165: iload #6
    //   167: isub
    //   168: iload #5
    //   170: invokestatic min : (II)I
    //   173: istore #5
    //   175: goto -> 237
    //   178: getstatic r/e$b.b : Lr/e$b;
    //   181: astore #11
    //   183: aload #11
    //   185: astore #9
    //   187: iload #8
    //   189: ifne -> 155
    //   192: iconst_0
    //   193: aload_0
    //   194: getfield e : I
    //   197: invokestatic max : (II)I
    //   200: istore #5
    //   202: aload #11
    //   204: astore #9
    //   206: goto -> 237
    //   209: getstatic r/e$b.b : Lr/e$b;
    //   212: astore #11
    //   214: aload #11
    //   216: astore #9
    //   218: iload #8
    //   220: ifne -> 237
    //   223: iconst_0
    //   224: aload_0
    //   225: getfield e : I
    //   228: invokestatic max : (II)I
    //   231: istore #5
    //   233: aload #11
    //   235: astore #9
    //   237: iload_3
    //   238: aload_1
    //   239: invokevirtual W : ()I
    //   242: if_icmpne -> 254
    //   245: iload #5
    //   247: aload_1
    //   248: invokevirtual x : ()I
    //   251: if_icmpeq -> 258
    //   254: aload_1
    //   255: invokevirtual N1 : ()V
    //   258: aload_1
    //   259: iconst_0
    //   260: invokevirtual m1 : (I)V
    //   263: aload_1
    //   264: iconst_0
    //   265: invokevirtual n1 : (I)V
    //   268: aload_1
    //   269: aload_0
    //   270: getfield f : I
    //   273: iload #7
    //   275: isub
    //   276: invokevirtual X0 : (I)V
    //   279: aload_1
    //   280: aload_0
    //   281: getfield g : I
    //   284: iload #6
    //   286: isub
    //   287: invokevirtual W0 : (I)V
    //   290: aload_1
    //   291: iconst_0
    //   292: invokevirtual a1 : (I)V
    //   295: aload_1
    //   296: iconst_0
    //   297: invokevirtual Z0 : (I)V
    //   300: aload_1
    //   301: aload #10
    //   303: invokevirtual P0 : (Lr/e$b;)V
    //   306: aload_1
    //   307: iload_3
    //   308: invokevirtual k1 : (I)V
    //   311: aload_1
    //   312: aload #9
    //   314: invokevirtual g1 : (Lr/e$b;)V
    //   317: aload_1
    //   318: iload #5
    //   320: invokevirtual L0 : (I)V
    //   323: aload_1
    //   324: aload_0
    //   325: getfield d : I
    //   328: iload #7
    //   330: isub
    //   331: invokevirtual a1 : (I)V
    //   334: aload_1
    //   335: aload_0
    //   336: getfield e : I
    //   339: iload #6
    //   341: isub
    //   342: invokevirtual Z0 : (I)V
    //   345: return
  }
  
  public static class b extends ViewGroup.MarginLayoutParams {
    public int A = Integer.MIN_VALUE;
    
    public int B = Integer.MIN_VALUE;
    
    public int C = Integer.MIN_VALUE;
    
    public int D = 0;
    
    boolean E = true;
    
    boolean F = true;
    
    public float G = 0.5F;
    
    public float H = 0.5F;
    
    public String I = null;
    
    float J = 0.0F;
    
    int K = 1;
    
    public float L = -1.0F;
    
    public float M = -1.0F;
    
    public int N = 0;
    
    public int O = 0;
    
    public int P = 0;
    
    public int Q = 0;
    
    public int R = 0;
    
    public int S = 0;
    
    public int T = 0;
    
    public int U = 0;
    
    public float V = 1.0F;
    
    public float W = 1.0F;
    
    public int X = -1;
    
    public int Y = -1;
    
    public int Z = -1;
    
    public int a = -1;
    
    public boolean a0 = false;
    
    public int b = -1;
    
    public boolean b0 = false;
    
    public float c = -1.0F;
    
    public String c0 = null;
    
    public boolean d = true;
    
    public int d0 = 0;
    
    public int e = -1;
    
    boolean e0 = true;
    
    public int f = -1;
    
    boolean f0 = true;
    
    public int g = -1;
    
    boolean g0 = false;
    
    public int h = -1;
    
    boolean h0 = false;
    
    public int i = -1;
    
    boolean i0 = false;
    
    public int j = -1;
    
    boolean j0 = false;
    
    public int k = -1;
    
    boolean k0 = false;
    
    public int l = -1;
    
    int l0 = -1;
    
    public int m = -1;
    
    int m0 = -1;
    
    public int n = -1;
    
    int n0 = -1;
    
    public int o = -1;
    
    int o0 = -1;
    
    public int p = -1;
    
    int p0 = Integer.MIN_VALUE;
    
    public int q = 0;
    
    int q0 = Integer.MIN_VALUE;
    
    public float r = 0.0F;
    
    float r0 = 0.5F;
    
    public int s = -1;
    
    int s0;
    
    public int t = -1;
    
    int t0;
    
    public int u = -1;
    
    float u0;
    
    public int v = -1;
    
    e v0 = new e();
    
    public int w = Integer.MIN_VALUE;
    
    public boolean w0 = false;
    
    public int x = Integer.MIN_VALUE;
    
    public int y = Integer.MIN_VALUE;
    
    public int z = Integer.MIN_VALUE;
    
    public b(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public b(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_m1
      //   8: putfield a : I
      //   11: aload_0
      //   12: iconst_m1
      //   13: putfield b : I
      //   16: aload_0
      //   17: ldc -1.0
      //   19: putfield c : F
      //   22: aload_0
      //   23: iconst_1
      //   24: putfield d : Z
      //   27: aload_0
      //   28: iconst_m1
      //   29: putfield e : I
      //   32: aload_0
      //   33: iconst_m1
      //   34: putfield f : I
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield g : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield h : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield i : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield j : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield k : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield l : I
      //   67: aload_0
      //   68: iconst_m1
      //   69: putfield m : I
      //   72: aload_0
      //   73: iconst_m1
      //   74: putfield n : I
      //   77: aload_0
      //   78: iconst_m1
      //   79: putfield o : I
      //   82: aload_0
      //   83: iconst_m1
      //   84: putfield p : I
      //   87: aload_0
      //   88: iconst_0
      //   89: putfield q : I
      //   92: aload_0
      //   93: fconst_0
      //   94: putfield r : F
      //   97: aload_0
      //   98: iconst_m1
      //   99: putfield s : I
      //   102: aload_0
      //   103: iconst_m1
      //   104: putfield t : I
      //   107: aload_0
      //   108: iconst_m1
      //   109: putfield u : I
      //   112: aload_0
      //   113: iconst_m1
      //   114: putfield v : I
      //   117: aload_0
      //   118: ldc -2147483648
      //   120: putfield w : I
      //   123: aload_0
      //   124: ldc -2147483648
      //   126: putfield x : I
      //   129: aload_0
      //   130: ldc -2147483648
      //   132: putfield y : I
      //   135: aload_0
      //   136: ldc -2147483648
      //   138: putfield z : I
      //   141: aload_0
      //   142: ldc -2147483648
      //   144: putfield A : I
      //   147: aload_0
      //   148: ldc -2147483648
      //   150: putfield B : I
      //   153: aload_0
      //   154: ldc -2147483648
      //   156: putfield C : I
      //   159: aload_0
      //   160: iconst_0
      //   161: putfield D : I
      //   164: aload_0
      //   165: iconst_1
      //   166: putfield E : Z
      //   169: aload_0
      //   170: iconst_1
      //   171: putfield F : Z
      //   174: aload_0
      //   175: ldc 0.5
      //   177: putfield G : F
      //   180: aload_0
      //   181: ldc 0.5
      //   183: putfield H : F
      //   186: aload_0
      //   187: aconst_null
      //   188: putfield I : Ljava/lang/String;
      //   191: aload_0
      //   192: fconst_0
      //   193: putfield J : F
      //   196: aload_0
      //   197: iconst_1
      //   198: putfield K : I
      //   201: aload_0
      //   202: ldc -1.0
      //   204: putfield L : F
      //   207: aload_0
      //   208: ldc -1.0
      //   210: putfield M : F
      //   213: aload_0
      //   214: iconst_0
      //   215: putfield N : I
      //   218: aload_0
      //   219: iconst_0
      //   220: putfield O : I
      //   223: aload_0
      //   224: iconst_0
      //   225: putfield P : I
      //   228: aload_0
      //   229: iconst_0
      //   230: putfield Q : I
      //   233: aload_0
      //   234: iconst_0
      //   235: putfield R : I
      //   238: aload_0
      //   239: iconst_0
      //   240: putfield S : I
      //   243: aload_0
      //   244: iconst_0
      //   245: putfield T : I
      //   248: aload_0
      //   249: iconst_0
      //   250: putfield U : I
      //   253: aload_0
      //   254: fconst_1
      //   255: putfield V : F
      //   258: aload_0
      //   259: fconst_1
      //   260: putfield W : F
      //   263: aload_0
      //   264: iconst_m1
      //   265: putfield X : I
      //   268: aload_0
      //   269: iconst_m1
      //   270: putfield Y : I
      //   273: aload_0
      //   274: iconst_m1
      //   275: putfield Z : I
      //   278: aload_0
      //   279: iconst_0
      //   280: putfield a0 : Z
      //   283: aload_0
      //   284: iconst_0
      //   285: putfield b0 : Z
      //   288: aload_0
      //   289: aconst_null
      //   290: putfield c0 : Ljava/lang/String;
      //   293: aload_0
      //   294: iconst_0
      //   295: putfield d0 : I
      //   298: aload_0
      //   299: iconst_1
      //   300: putfield e0 : Z
      //   303: aload_0
      //   304: iconst_1
      //   305: putfield f0 : Z
      //   308: aload_0
      //   309: iconst_0
      //   310: putfield g0 : Z
      //   313: aload_0
      //   314: iconst_0
      //   315: putfield h0 : Z
      //   318: aload_0
      //   319: iconst_0
      //   320: putfield i0 : Z
      //   323: aload_0
      //   324: iconst_0
      //   325: putfield j0 : Z
      //   328: aload_0
      //   329: iconst_0
      //   330: putfield k0 : Z
      //   333: aload_0
      //   334: iconst_m1
      //   335: putfield l0 : I
      //   338: aload_0
      //   339: iconst_m1
      //   340: putfield m0 : I
      //   343: aload_0
      //   344: iconst_m1
      //   345: putfield n0 : I
      //   348: aload_0
      //   349: iconst_m1
      //   350: putfield o0 : I
      //   353: aload_0
      //   354: ldc -2147483648
      //   356: putfield p0 : I
      //   359: aload_0
      //   360: ldc -2147483648
      //   362: putfield q0 : I
      //   365: aload_0
      //   366: ldc 0.5
      //   368: putfield r0 : F
      //   371: aload_0
      //   372: new r/e
      //   375: dup
      //   376: invokespecial <init> : ()V
      //   379: putfield v0 : Lr/e;
      //   382: aload_0
      //   383: iconst_0
      //   384: putfield w0 : Z
      //   387: aload_1
      //   388: aload_2
      //   389: getstatic androidx/constraintlayout/widget/h.ConstraintLayout_Layout : [I
      //   392: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   395: astore_1
      //   396: aload_1
      //   397: invokevirtual getIndexCount : ()I
      //   400: istore #5
      //   402: iconst_0
      //   403: istore #4
      //   405: iload #4
      //   407: iload #5
      //   409: if_icmpge -> 2116
      //   412: aload_1
      //   413: iload #4
      //   415: invokevirtual getIndex : (I)I
      //   418: istore #6
      //   420: getstatic androidx/constraintlayout/widget/ConstraintLayout$b$a.a : Landroid/util/SparseIntArray;
      //   423: iload #6
      //   425: invokevirtual get : (I)I
      //   428: istore #7
      //   430: iload #7
      //   432: tableswitch default -> 600, 1 -> 2093, 2 -> 2055, 3 -> 2038, 4 -> 1996, 5 -> 1979, 6 -> 1962, 7 -> 1945, 8 -> 1907, 9 -> 1869, 10 -> 1831, 11 -> 1793, 12 -> 1755, 13 -> 1717, 14 -> 1679, 15 -> 1641, 16 -> 1603, 17 -> 1565, 18 -> 1527, 19 -> 1489, 20 -> 1451, 21 -> 1434, 22 -> 1417, 23 -> 1400, 24 -> 1383, 25 -> 1366, 26 -> 1349, 27 -> 1332, 28 -> 1315, 29 -> 1298, 30 -> 1281, 31 -> 1247, 32 -> 1213, 33 -> 1172, 34 -> 1131, 35 -> 1105, 36 -> 1064, 37 -> 1023, 38 -> 997
      //   600: iload #7
      //   602: tableswitch default -> 664, 44 -> 984, 45 -> 967, 46 -> 950, 47 -> 936, 48 -> 922, 49 -> 905, 50 -> 888, 51 -> 875, 52 -> 837, 53 -> 799, 54 -> 782, 55 -> 765
      //   664: iload #7
      //   666: tableswitch default -> 696, 64 -> 749, 65 -> 733, 66 -> 716, 67 -> 699
      //   696: goto -> 2107
      //   699: aload_0
      //   700: aload_1
      //   701: iload #6
      //   703: aload_0
      //   704: getfield d : Z
      //   707: invokevirtual getBoolean : (IZ)Z
      //   710: putfield d : Z
      //   713: goto -> 2107
      //   716: aload_0
      //   717: aload_1
      //   718: iload #6
      //   720: aload_0
      //   721: getfield d0 : I
      //   724: invokevirtual getInt : (II)I
      //   727: putfield d0 : I
      //   730: goto -> 2107
      //   733: aload_0
      //   734: aload_1
      //   735: iload #6
      //   737: iconst_1
      //   738: invokestatic n : (Ljava/lang/Object;Landroid/content/res/TypedArray;II)V
      //   741: aload_0
      //   742: iconst_1
      //   743: putfield F : Z
      //   746: goto -> 2107
      //   749: aload_0
      //   750: aload_1
      //   751: iload #6
      //   753: iconst_0
      //   754: invokestatic n : (Ljava/lang/Object;Landroid/content/res/TypedArray;II)V
      //   757: aload_0
      //   758: iconst_1
      //   759: putfield E : Z
      //   762: goto -> 2107
      //   765: aload_0
      //   766: aload_1
      //   767: iload #6
      //   769: aload_0
      //   770: getfield C : I
      //   773: invokevirtual getDimensionPixelSize : (II)I
      //   776: putfield C : I
      //   779: goto -> 2107
      //   782: aload_0
      //   783: aload_1
      //   784: iload #6
      //   786: aload_0
      //   787: getfield D : I
      //   790: invokevirtual getDimensionPixelSize : (II)I
      //   793: putfield D : I
      //   796: goto -> 2107
      //   799: aload_1
      //   800: iload #6
      //   802: aload_0
      //   803: getfield o : I
      //   806: invokevirtual getResourceId : (II)I
      //   809: istore #7
      //   811: aload_0
      //   812: iload #7
      //   814: putfield o : I
      //   817: iload #7
      //   819: iconst_m1
      //   820: if_icmpne -> 2107
      //   823: aload_0
      //   824: aload_1
      //   825: iload #6
      //   827: iconst_m1
      //   828: invokevirtual getInt : (II)I
      //   831: putfield o : I
      //   834: goto -> 2107
      //   837: aload_1
      //   838: iload #6
      //   840: aload_0
      //   841: getfield n : I
      //   844: invokevirtual getResourceId : (II)I
      //   847: istore #7
      //   849: aload_0
      //   850: iload #7
      //   852: putfield n : I
      //   855: iload #7
      //   857: iconst_m1
      //   858: if_icmpne -> 2107
      //   861: aload_0
      //   862: aload_1
      //   863: iload #6
      //   865: iconst_m1
      //   866: invokevirtual getInt : (II)I
      //   869: putfield n : I
      //   872: goto -> 2107
      //   875: aload_0
      //   876: aload_1
      //   877: iload #6
      //   879: invokevirtual getString : (I)Ljava/lang/String;
      //   882: putfield c0 : Ljava/lang/String;
      //   885: goto -> 2107
      //   888: aload_0
      //   889: aload_1
      //   890: iload #6
      //   892: aload_0
      //   893: getfield Y : I
      //   896: invokevirtual getDimensionPixelOffset : (II)I
      //   899: putfield Y : I
      //   902: goto -> 2107
      //   905: aload_0
      //   906: aload_1
      //   907: iload #6
      //   909: aload_0
      //   910: getfield X : I
      //   913: invokevirtual getDimensionPixelOffset : (II)I
      //   916: putfield X : I
      //   919: goto -> 2107
      //   922: aload_0
      //   923: aload_1
      //   924: iload #6
      //   926: iconst_0
      //   927: invokevirtual getInt : (II)I
      //   930: putfield O : I
      //   933: goto -> 2107
      //   936: aload_0
      //   937: aload_1
      //   938: iload #6
      //   940: iconst_0
      //   941: invokevirtual getInt : (II)I
      //   944: putfield N : I
      //   947: goto -> 2107
      //   950: aload_0
      //   951: aload_1
      //   952: iload #6
      //   954: aload_0
      //   955: getfield M : F
      //   958: invokevirtual getFloat : (IF)F
      //   961: putfield M : F
      //   964: goto -> 2107
      //   967: aload_0
      //   968: aload_1
      //   969: iload #6
      //   971: aload_0
      //   972: getfield L : F
      //   975: invokevirtual getFloat : (IF)F
      //   978: putfield L : F
      //   981: goto -> 2107
      //   984: aload_0
      //   985: aload_1
      //   986: iload #6
      //   988: invokevirtual getString : (I)Ljava/lang/String;
      //   991: invokestatic p : (Landroidx/constraintlayout/widget/ConstraintLayout$b;Ljava/lang/String;)V
      //   994: goto -> 2107
      //   997: aload_0
      //   998: fconst_0
      //   999: aload_1
      //   1000: iload #6
      //   1002: aload_0
      //   1003: getfield W : F
      //   1006: invokevirtual getFloat : (IF)F
      //   1009: invokestatic max : (FF)F
      //   1012: putfield W : F
      //   1015: aload_0
      //   1016: iconst_2
      //   1017: putfield Q : I
      //   1020: goto -> 2107
      //   1023: aload_0
      //   1024: aload_1
      //   1025: iload #6
      //   1027: aload_0
      //   1028: getfield U : I
      //   1031: invokevirtual getDimensionPixelSize : (II)I
      //   1034: putfield U : I
      //   1037: goto -> 2107
      //   1040: aload_1
      //   1041: iload #6
      //   1043: aload_0
      //   1044: getfield U : I
      //   1047: invokevirtual getInt : (II)I
      //   1050: bipush #-2
      //   1052: if_icmpne -> 2107
      //   1055: aload_0
      //   1056: bipush #-2
      //   1058: putfield U : I
      //   1061: goto -> 2107
      //   1064: aload_0
      //   1065: aload_1
      //   1066: iload #6
      //   1068: aload_0
      //   1069: getfield S : I
      //   1072: invokevirtual getDimensionPixelSize : (II)I
      //   1075: putfield S : I
      //   1078: goto -> 2107
      //   1081: aload_1
      //   1082: iload #6
      //   1084: aload_0
      //   1085: getfield S : I
      //   1088: invokevirtual getInt : (II)I
      //   1091: bipush #-2
      //   1093: if_icmpne -> 2107
      //   1096: aload_0
      //   1097: bipush #-2
      //   1099: putfield S : I
      //   1102: goto -> 2107
      //   1105: aload_0
      //   1106: fconst_0
      //   1107: aload_1
      //   1108: iload #6
      //   1110: aload_0
      //   1111: getfield V : F
      //   1114: invokevirtual getFloat : (IF)F
      //   1117: invokestatic max : (FF)F
      //   1120: putfield V : F
      //   1123: aload_0
      //   1124: iconst_2
      //   1125: putfield P : I
      //   1128: goto -> 2107
      //   1131: aload_0
      //   1132: aload_1
      //   1133: iload #6
      //   1135: aload_0
      //   1136: getfield T : I
      //   1139: invokevirtual getDimensionPixelSize : (II)I
      //   1142: putfield T : I
      //   1145: goto -> 2107
      //   1148: aload_1
      //   1149: iload #6
      //   1151: aload_0
      //   1152: getfield T : I
      //   1155: invokevirtual getInt : (II)I
      //   1158: bipush #-2
      //   1160: if_icmpne -> 2107
      //   1163: aload_0
      //   1164: bipush #-2
      //   1166: putfield T : I
      //   1169: goto -> 2107
      //   1172: aload_0
      //   1173: aload_1
      //   1174: iload #6
      //   1176: aload_0
      //   1177: getfield R : I
      //   1180: invokevirtual getDimensionPixelSize : (II)I
      //   1183: putfield R : I
      //   1186: goto -> 2107
      //   1189: aload_1
      //   1190: iload #6
      //   1192: aload_0
      //   1193: getfield R : I
      //   1196: invokevirtual getInt : (II)I
      //   1199: bipush #-2
      //   1201: if_icmpne -> 2107
      //   1204: aload_0
      //   1205: bipush #-2
      //   1207: putfield R : I
      //   1210: goto -> 2107
      //   1213: aload_1
      //   1214: iload #6
      //   1216: iconst_0
      //   1217: invokevirtual getInt : (II)I
      //   1220: istore #6
      //   1222: aload_0
      //   1223: iload #6
      //   1225: putfield Q : I
      //   1228: iload #6
      //   1230: iconst_1
      //   1231: if_icmpne -> 2107
      //   1234: ldc_w 'ConstraintLayout'
      //   1237: ldc_w 'layout_constraintHeight_default="wrap" is deprecated.\\nUse layout_height="WRAP_CONTENT" and layout_constrainedHeight="true" instead.'
      //   1240: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1243: pop
      //   1244: goto -> 2107
      //   1247: aload_1
      //   1248: iload #6
      //   1250: iconst_0
      //   1251: invokevirtual getInt : (II)I
      //   1254: istore #6
      //   1256: aload_0
      //   1257: iload #6
      //   1259: putfield P : I
      //   1262: iload #6
      //   1264: iconst_1
      //   1265: if_icmpne -> 2107
      //   1268: ldc_w 'ConstraintLayout'
      //   1271: ldc_w 'layout_constraintWidth_default="wrap" is deprecated.\\nUse layout_width="WRAP_CONTENT" and layout_constrainedWidth="true" instead.'
      //   1274: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1277: pop
      //   1278: goto -> 2107
      //   1281: aload_0
      //   1282: aload_1
      //   1283: iload #6
      //   1285: aload_0
      //   1286: getfield H : F
      //   1289: invokevirtual getFloat : (IF)F
      //   1292: putfield H : F
      //   1295: goto -> 2107
      //   1298: aload_0
      //   1299: aload_1
      //   1300: iload #6
      //   1302: aload_0
      //   1303: getfield G : F
      //   1306: invokevirtual getFloat : (IF)F
      //   1309: putfield G : F
      //   1312: goto -> 2107
      //   1315: aload_0
      //   1316: aload_1
      //   1317: iload #6
      //   1319: aload_0
      //   1320: getfield b0 : Z
      //   1323: invokevirtual getBoolean : (IZ)Z
      //   1326: putfield b0 : Z
      //   1329: goto -> 2107
      //   1332: aload_0
      //   1333: aload_1
      //   1334: iload #6
      //   1336: aload_0
      //   1337: getfield a0 : Z
      //   1340: invokevirtual getBoolean : (IZ)Z
      //   1343: putfield a0 : Z
      //   1346: goto -> 2107
      //   1349: aload_0
      //   1350: aload_1
      //   1351: iload #6
      //   1353: aload_0
      //   1354: getfield B : I
      //   1357: invokevirtual getDimensionPixelSize : (II)I
      //   1360: putfield B : I
      //   1363: goto -> 2107
      //   1366: aload_0
      //   1367: aload_1
      //   1368: iload #6
      //   1370: aload_0
      //   1371: getfield A : I
      //   1374: invokevirtual getDimensionPixelSize : (II)I
      //   1377: putfield A : I
      //   1380: goto -> 2107
      //   1383: aload_0
      //   1384: aload_1
      //   1385: iload #6
      //   1387: aload_0
      //   1388: getfield z : I
      //   1391: invokevirtual getDimensionPixelSize : (II)I
      //   1394: putfield z : I
      //   1397: goto -> 2107
      //   1400: aload_0
      //   1401: aload_1
      //   1402: iload #6
      //   1404: aload_0
      //   1405: getfield y : I
      //   1408: invokevirtual getDimensionPixelSize : (II)I
      //   1411: putfield y : I
      //   1414: goto -> 2107
      //   1417: aload_0
      //   1418: aload_1
      //   1419: iload #6
      //   1421: aload_0
      //   1422: getfield x : I
      //   1425: invokevirtual getDimensionPixelSize : (II)I
      //   1428: putfield x : I
      //   1431: goto -> 2107
      //   1434: aload_0
      //   1435: aload_1
      //   1436: iload #6
      //   1438: aload_0
      //   1439: getfield w : I
      //   1442: invokevirtual getDimensionPixelSize : (II)I
      //   1445: putfield w : I
      //   1448: goto -> 2107
      //   1451: aload_1
      //   1452: iload #6
      //   1454: aload_0
      //   1455: getfield v : I
      //   1458: invokevirtual getResourceId : (II)I
      //   1461: istore #7
      //   1463: aload_0
      //   1464: iload #7
      //   1466: putfield v : I
      //   1469: iload #7
      //   1471: iconst_m1
      //   1472: if_icmpne -> 2107
      //   1475: aload_0
      //   1476: aload_1
      //   1477: iload #6
      //   1479: iconst_m1
      //   1480: invokevirtual getInt : (II)I
      //   1483: putfield v : I
      //   1486: goto -> 2107
      //   1489: aload_1
      //   1490: iload #6
      //   1492: aload_0
      //   1493: getfield u : I
      //   1496: invokevirtual getResourceId : (II)I
      //   1499: istore #7
      //   1501: aload_0
      //   1502: iload #7
      //   1504: putfield u : I
      //   1507: iload #7
      //   1509: iconst_m1
      //   1510: if_icmpne -> 2107
      //   1513: aload_0
      //   1514: aload_1
      //   1515: iload #6
      //   1517: iconst_m1
      //   1518: invokevirtual getInt : (II)I
      //   1521: putfield u : I
      //   1524: goto -> 2107
      //   1527: aload_1
      //   1528: iload #6
      //   1530: aload_0
      //   1531: getfield t : I
      //   1534: invokevirtual getResourceId : (II)I
      //   1537: istore #7
      //   1539: aload_0
      //   1540: iload #7
      //   1542: putfield t : I
      //   1545: iload #7
      //   1547: iconst_m1
      //   1548: if_icmpne -> 2107
      //   1551: aload_0
      //   1552: aload_1
      //   1553: iload #6
      //   1555: iconst_m1
      //   1556: invokevirtual getInt : (II)I
      //   1559: putfield t : I
      //   1562: goto -> 2107
      //   1565: aload_1
      //   1566: iload #6
      //   1568: aload_0
      //   1569: getfield s : I
      //   1572: invokevirtual getResourceId : (II)I
      //   1575: istore #7
      //   1577: aload_0
      //   1578: iload #7
      //   1580: putfield s : I
      //   1583: iload #7
      //   1585: iconst_m1
      //   1586: if_icmpne -> 2107
      //   1589: aload_0
      //   1590: aload_1
      //   1591: iload #6
      //   1593: iconst_m1
      //   1594: invokevirtual getInt : (II)I
      //   1597: putfield s : I
      //   1600: goto -> 2107
      //   1603: aload_1
      //   1604: iload #6
      //   1606: aload_0
      //   1607: getfield m : I
      //   1610: invokevirtual getResourceId : (II)I
      //   1613: istore #7
      //   1615: aload_0
      //   1616: iload #7
      //   1618: putfield m : I
      //   1621: iload #7
      //   1623: iconst_m1
      //   1624: if_icmpne -> 2107
      //   1627: aload_0
      //   1628: aload_1
      //   1629: iload #6
      //   1631: iconst_m1
      //   1632: invokevirtual getInt : (II)I
      //   1635: putfield m : I
      //   1638: goto -> 2107
      //   1641: aload_1
      //   1642: iload #6
      //   1644: aload_0
      //   1645: getfield l : I
      //   1648: invokevirtual getResourceId : (II)I
      //   1651: istore #7
      //   1653: aload_0
      //   1654: iload #7
      //   1656: putfield l : I
      //   1659: iload #7
      //   1661: iconst_m1
      //   1662: if_icmpne -> 2107
      //   1665: aload_0
      //   1666: aload_1
      //   1667: iload #6
      //   1669: iconst_m1
      //   1670: invokevirtual getInt : (II)I
      //   1673: putfield l : I
      //   1676: goto -> 2107
      //   1679: aload_1
      //   1680: iload #6
      //   1682: aload_0
      //   1683: getfield k : I
      //   1686: invokevirtual getResourceId : (II)I
      //   1689: istore #7
      //   1691: aload_0
      //   1692: iload #7
      //   1694: putfield k : I
      //   1697: iload #7
      //   1699: iconst_m1
      //   1700: if_icmpne -> 2107
      //   1703: aload_0
      //   1704: aload_1
      //   1705: iload #6
      //   1707: iconst_m1
      //   1708: invokevirtual getInt : (II)I
      //   1711: putfield k : I
      //   1714: goto -> 2107
      //   1717: aload_1
      //   1718: iload #6
      //   1720: aload_0
      //   1721: getfield j : I
      //   1724: invokevirtual getResourceId : (II)I
      //   1727: istore #7
      //   1729: aload_0
      //   1730: iload #7
      //   1732: putfield j : I
      //   1735: iload #7
      //   1737: iconst_m1
      //   1738: if_icmpne -> 2107
      //   1741: aload_0
      //   1742: aload_1
      //   1743: iload #6
      //   1745: iconst_m1
      //   1746: invokevirtual getInt : (II)I
      //   1749: putfield j : I
      //   1752: goto -> 2107
      //   1755: aload_1
      //   1756: iload #6
      //   1758: aload_0
      //   1759: getfield i : I
      //   1762: invokevirtual getResourceId : (II)I
      //   1765: istore #7
      //   1767: aload_0
      //   1768: iload #7
      //   1770: putfield i : I
      //   1773: iload #7
      //   1775: iconst_m1
      //   1776: if_icmpne -> 2107
      //   1779: aload_0
      //   1780: aload_1
      //   1781: iload #6
      //   1783: iconst_m1
      //   1784: invokevirtual getInt : (II)I
      //   1787: putfield i : I
      //   1790: goto -> 2107
      //   1793: aload_1
      //   1794: iload #6
      //   1796: aload_0
      //   1797: getfield h : I
      //   1800: invokevirtual getResourceId : (II)I
      //   1803: istore #7
      //   1805: aload_0
      //   1806: iload #7
      //   1808: putfield h : I
      //   1811: iload #7
      //   1813: iconst_m1
      //   1814: if_icmpne -> 2107
      //   1817: aload_0
      //   1818: aload_1
      //   1819: iload #6
      //   1821: iconst_m1
      //   1822: invokevirtual getInt : (II)I
      //   1825: putfield h : I
      //   1828: goto -> 2107
      //   1831: aload_1
      //   1832: iload #6
      //   1834: aload_0
      //   1835: getfield g : I
      //   1838: invokevirtual getResourceId : (II)I
      //   1841: istore #7
      //   1843: aload_0
      //   1844: iload #7
      //   1846: putfield g : I
      //   1849: iload #7
      //   1851: iconst_m1
      //   1852: if_icmpne -> 2107
      //   1855: aload_0
      //   1856: aload_1
      //   1857: iload #6
      //   1859: iconst_m1
      //   1860: invokevirtual getInt : (II)I
      //   1863: putfield g : I
      //   1866: goto -> 2107
      //   1869: aload_1
      //   1870: iload #6
      //   1872: aload_0
      //   1873: getfield f : I
      //   1876: invokevirtual getResourceId : (II)I
      //   1879: istore #7
      //   1881: aload_0
      //   1882: iload #7
      //   1884: putfield f : I
      //   1887: iload #7
      //   1889: iconst_m1
      //   1890: if_icmpne -> 2107
      //   1893: aload_0
      //   1894: aload_1
      //   1895: iload #6
      //   1897: iconst_m1
      //   1898: invokevirtual getInt : (II)I
      //   1901: putfield f : I
      //   1904: goto -> 2107
      //   1907: aload_1
      //   1908: iload #6
      //   1910: aload_0
      //   1911: getfield e : I
      //   1914: invokevirtual getResourceId : (II)I
      //   1917: istore #7
      //   1919: aload_0
      //   1920: iload #7
      //   1922: putfield e : I
      //   1925: iload #7
      //   1927: iconst_m1
      //   1928: if_icmpne -> 2107
      //   1931: aload_0
      //   1932: aload_1
      //   1933: iload #6
      //   1935: iconst_m1
      //   1936: invokevirtual getInt : (II)I
      //   1939: putfield e : I
      //   1942: goto -> 2107
      //   1945: aload_0
      //   1946: aload_1
      //   1947: iload #6
      //   1949: aload_0
      //   1950: getfield c : F
      //   1953: invokevirtual getFloat : (IF)F
      //   1956: putfield c : F
      //   1959: goto -> 2107
      //   1962: aload_0
      //   1963: aload_1
      //   1964: iload #6
      //   1966: aload_0
      //   1967: getfield b : I
      //   1970: invokevirtual getDimensionPixelOffset : (II)I
      //   1973: putfield b : I
      //   1976: goto -> 2107
      //   1979: aload_0
      //   1980: aload_1
      //   1981: iload #6
      //   1983: aload_0
      //   1984: getfield a : I
      //   1987: invokevirtual getDimensionPixelOffset : (II)I
      //   1990: putfield a : I
      //   1993: goto -> 2107
      //   1996: aload_1
      //   1997: iload #6
      //   1999: aload_0
      //   2000: getfield r : F
      //   2003: invokevirtual getFloat : (IF)F
      //   2006: ldc_w 360.0
      //   2009: frem
      //   2010: fstore_3
      //   2011: aload_0
      //   2012: fload_3
      //   2013: putfield r : F
      //   2016: fload_3
      //   2017: fconst_0
      //   2018: fcmpg
      //   2019: ifge -> 2107
      //   2022: aload_0
      //   2023: ldc_w 360.0
      //   2026: fload_3
      //   2027: fsub
      //   2028: ldc_w 360.0
      //   2031: frem
      //   2032: putfield r : F
      //   2035: goto -> 2107
      //   2038: aload_0
      //   2039: aload_1
      //   2040: iload #6
      //   2042: aload_0
      //   2043: getfield q : I
      //   2046: invokevirtual getDimensionPixelSize : (II)I
      //   2049: putfield q : I
      //   2052: goto -> 2107
      //   2055: aload_1
      //   2056: iload #6
      //   2058: aload_0
      //   2059: getfield p : I
      //   2062: invokevirtual getResourceId : (II)I
      //   2065: istore #7
      //   2067: aload_0
      //   2068: iload #7
      //   2070: putfield p : I
      //   2073: iload #7
      //   2075: iconst_m1
      //   2076: if_icmpne -> 2107
      //   2079: aload_0
      //   2080: aload_1
      //   2081: iload #6
      //   2083: iconst_m1
      //   2084: invokevirtual getInt : (II)I
      //   2087: putfield p : I
      //   2090: goto -> 2107
      //   2093: aload_0
      //   2094: aload_1
      //   2095: iload #6
      //   2097: aload_0
      //   2098: getfield Z : I
      //   2101: invokevirtual getInt : (II)I
      //   2104: putfield Z : I
      //   2107: iload #4
      //   2109: iconst_1
      //   2110: iadd
      //   2111: istore #4
      //   2113: goto -> 405
      //   2116: aload_1
      //   2117: invokevirtual recycle : ()V
      //   2120: aload_0
      //   2121: invokevirtual a : ()V
      //   2124: return
      //   2125: astore_2
      //   2126: goto -> 1040
      //   2129: astore_2
      //   2130: goto -> 1081
      //   2133: astore_2
      //   2134: goto -> 1148
      //   2137: astore_2
      //   2138: goto -> 1189
      // Exception table:
      //   from	to	target	type
      //   1023	1037	2125	java/lang/Exception
      //   1064	1078	2129	java/lang/Exception
      //   1131	1145	2133	java/lang/Exception
      //   1172	1186	2137	java/lang/Exception
    }
    
    public b(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public void a() {
      this.h0 = false;
      this.e0 = true;
      this.f0 = true;
      int i = this.width;
      if (i == -2 && this.a0) {
        this.e0 = false;
        if (this.P == 0)
          this.P = 1; 
      } 
      int j = this.height;
      if (j == -2 && this.b0) {
        this.f0 = false;
        if (this.Q == 0)
          this.Q = 1; 
      } 
      if (i == 0 || i == -1) {
        this.e0 = false;
        if (i == 0 && this.P == 1) {
          this.width = -2;
          this.a0 = true;
        } 
      } 
      if (j == 0 || j == -1) {
        this.f0 = false;
        if (j == 0 && this.Q == 1) {
          this.height = -2;
          this.b0 = true;
        } 
      } 
      if (this.c != -1.0F || this.a != -1 || this.b != -1) {
        this.h0 = true;
        this.e0 = true;
        this.f0 = true;
        if (!(this.v0 instanceof h))
          this.v0 = (e)new h(); 
        ((h)this.v0).A1(this.Z);
      } 
    }
    
    public void resolveLayoutDirection(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield leftMargin : I
      //   4: istore #5
      //   6: aload_0
      //   7: getfield rightMargin : I
      //   10: istore #6
      //   12: aload_0
      //   13: iload_1
      //   14: invokespecial resolveLayoutDirection : (I)V
      //   17: aload_0
      //   18: invokevirtual getLayoutDirection : ()I
      //   21: istore_1
      //   22: iconst_0
      //   23: istore #4
      //   25: iconst_1
      //   26: iload_1
      //   27: if_icmpne -> 35
      //   30: iconst_1
      //   31: istore_1
      //   32: goto -> 37
      //   35: iconst_0
      //   36: istore_1
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield n0 : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield o0 : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield l0 : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield m0 : I
      //   57: aload_0
      //   58: aload_0
      //   59: getfield w : I
      //   62: putfield p0 : I
      //   65: aload_0
      //   66: aload_0
      //   67: getfield y : I
      //   70: putfield q0 : I
      //   73: aload_0
      //   74: getfield G : F
      //   77: fstore_2
      //   78: aload_0
      //   79: fload_2
      //   80: putfield r0 : F
      //   83: aload_0
      //   84: getfield a : I
      //   87: istore #7
      //   89: aload_0
      //   90: iload #7
      //   92: putfield s0 : I
      //   95: aload_0
      //   96: getfield b : I
      //   99: istore #8
      //   101: aload_0
      //   102: iload #8
      //   104: putfield t0 : I
      //   107: aload_0
      //   108: getfield c : F
      //   111: fstore_3
      //   112: aload_0
      //   113: fload_3
      //   114: putfield u0 : F
      //   117: iload_1
      //   118: ifeq -> 355
      //   121: aload_0
      //   122: getfield s : I
      //   125: istore_1
      //   126: iload_1
      //   127: iconst_m1
      //   128: if_icmpeq -> 141
      //   131: aload_0
      //   132: iload_1
      //   133: putfield n0 : I
      //   136: iconst_1
      //   137: istore_1
      //   138: goto -> 165
      //   141: aload_0
      //   142: getfield t : I
      //   145: istore #9
      //   147: iload #4
      //   149: istore_1
      //   150: iload #9
      //   152: iconst_m1
      //   153: if_icmpeq -> 165
      //   156: aload_0
      //   157: iload #9
      //   159: putfield o0 : I
      //   162: goto -> 136
      //   165: aload_0
      //   166: getfield u : I
      //   169: istore #4
      //   171: iload #4
      //   173: iconst_m1
      //   174: if_icmpeq -> 185
      //   177: aload_0
      //   178: iload #4
      //   180: putfield m0 : I
      //   183: iconst_1
      //   184: istore_1
      //   185: aload_0
      //   186: getfield v : I
      //   189: istore #4
      //   191: iload #4
      //   193: iconst_m1
      //   194: if_icmpeq -> 205
      //   197: aload_0
      //   198: iload #4
      //   200: putfield l0 : I
      //   203: iconst_1
      //   204: istore_1
      //   205: aload_0
      //   206: getfield A : I
      //   209: istore #4
      //   211: iload #4
      //   213: ldc -2147483648
      //   215: if_icmpeq -> 224
      //   218: aload_0
      //   219: iload #4
      //   221: putfield q0 : I
      //   224: aload_0
      //   225: getfield B : I
      //   228: istore #4
      //   230: iload #4
      //   232: ldc -2147483648
      //   234: if_icmpeq -> 243
      //   237: aload_0
      //   238: iload #4
      //   240: putfield p0 : I
      //   243: iload_1
      //   244: ifeq -> 254
      //   247: aload_0
      //   248: fconst_1
      //   249: fload_2
      //   250: fsub
      //   251: putfield r0 : F
      //   254: aload_0
      //   255: getfield h0 : Z
      //   258: ifeq -> 447
      //   261: aload_0
      //   262: getfield Z : I
      //   265: iconst_1
      //   266: if_icmpne -> 447
      //   269: aload_0
      //   270: getfield d : Z
      //   273: ifeq -> 447
      //   276: fload_3
      //   277: ldc -1.0
      //   279: fcmpl
      //   280: ifeq -> 303
      //   283: aload_0
      //   284: fconst_1
      //   285: fload_3
      //   286: fsub
      //   287: putfield u0 : F
      //   290: aload_0
      //   291: iconst_m1
      //   292: putfield s0 : I
      //   295: aload_0
      //   296: iconst_m1
      //   297: putfield t0 : I
      //   300: goto -> 447
      //   303: iload #7
      //   305: iconst_m1
      //   306: if_icmpeq -> 329
      //   309: aload_0
      //   310: iload #7
      //   312: putfield t0 : I
      //   315: aload_0
      //   316: iconst_m1
      //   317: putfield s0 : I
      //   320: aload_0
      //   321: ldc -1.0
      //   323: putfield u0 : F
      //   326: goto -> 447
      //   329: iload #8
      //   331: iconst_m1
      //   332: if_icmpeq -> 447
      //   335: aload_0
      //   336: iload #8
      //   338: putfield s0 : I
      //   341: aload_0
      //   342: iconst_m1
      //   343: putfield t0 : I
      //   346: aload_0
      //   347: ldc -1.0
      //   349: putfield u0 : F
      //   352: goto -> 447
      //   355: aload_0
      //   356: getfield s : I
      //   359: istore_1
      //   360: iload_1
      //   361: iconst_m1
      //   362: if_icmpeq -> 370
      //   365: aload_0
      //   366: iload_1
      //   367: putfield m0 : I
      //   370: aload_0
      //   371: getfield t : I
      //   374: istore_1
      //   375: iload_1
      //   376: iconst_m1
      //   377: if_icmpeq -> 385
      //   380: aload_0
      //   381: iload_1
      //   382: putfield l0 : I
      //   385: aload_0
      //   386: getfield u : I
      //   389: istore_1
      //   390: iload_1
      //   391: iconst_m1
      //   392: if_icmpeq -> 400
      //   395: aload_0
      //   396: iload_1
      //   397: putfield n0 : I
      //   400: aload_0
      //   401: getfield v : I
      //   404: istore_1
      //   405: iload_1
      //   406: iconst_m1
      //   407: if_icmpeq -> 415
      //   410: aload_0
      //   411: iload_1
      //   412: putfield o0 : I
      //   415: aload_0
      //   416: getfield A : I
      //   419: istore_1
      //   420: iload_1
      //   421: ldc -2147483648
      //   423: if_icmpeq -> 431
      //   426: aload_0
      //   427: iload_1
      //   428: putfield p0 : I
      //   431: aload_0
      //   432: getfield B : I
      //   435: istore_1
      //   436: iload_1
      //   437: ldc -2147483648
      //   439: if_icmpeq -> 447
      //   442: aload_0
      //   443: iload_1
      //   444: putfield q0 : I
      //   447: aload_0
      //   448: getfield u : I
      //   451: iconst_m1
      //   452: if_icmpne -> 615
      //   455: aload_0
      //   456: getfield v : I
      //   459: iconst_m1
      //   460: if_icmpne -> 615
      //   463: aload_0
      //   464: getfield t : I
      //   467: iconst_m1
      //   468: if_icmpne -> 615
      //   471: aload_0
      //   472: getfield s : I
      //   475: iconst_m1
      //   476: if_icmpne -> 615
      //   479: aload_0
      //   480: getfield g : I
      //   483: istore_1
      //   484: iload_1
      //   485: iconst_m1
      //   486: if_icmpeq -> 515
      //   489: aload_0
      //   490: iload_1
      //   491: putfield n0 : I
      //   494: aload_0
      //   495: getfield rightMargin : I
      //   498: ifgt -> 548
      //   501: iload #6
      //   503: ifle -> 548
      //   506: aload_0
      //   507: iload #6
      //   509: putfield rightMargin : I
      //   512: goto -> 548
      //   515: aload_0
      //   516: getfield h : I
      //   519: istore_1
      //   520: iload_1
      //   521: iconst_m1
      //   522: if_icmpeq -> 548
      //   525: aload_0
      //   526: iload_1
      //   527: putfield o0 : I
      //   530: aload_0
      //   531: getfield rightMargin : I
      //   534: ifgt -> 548
      //   537: iload #6
      //   539: ifle -> 548
      //   542: aload_0
      //   543: iload #6
      //   545: putfield rightMargin : I
      //   548: aload_0
      //   549: getfield e : I
      //   552: istore_1
      //   553: iload_1
      //   554: iconst_m1
      //   555: if_icmpeq -> 582
      //   558: aload_0
      //   559: iload_1
      //   560: putfield l0 : I
      //   563: aload_0
      //   564: getfield leftMargin : I
      //   567: ifgt -> 615
      //   570: iload #5
      //   572: ifle -> 615
      //   575: aload_0
      //   576: iload #5
      //   578: putfield leftMargin : I
      //   581: return
      //   582: aload_0
      //   583: getfield f : I
      //   586: istore_1
      //   587: iload_1
      //   588: iconst_m1
      //   589: if_icmpeq -> 615
      //   592: aload_0
      //   593: iload_1
      //   594: putfield m0 : I
      //   597: aload_0
      //   598: getfield leftMargin : I
      //   601: ifgt -> 615
      //   604: iload #5
      //   606: ifle -> 615
      //   609: aload_0
      //   610: iload #5
      //   612: putfield leftMargin : I
      //   615: return
    }
    
    private static abstract class a {
      public static final SparseIntArray a;
      
      static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        a = sparseIntArray;
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth, 64);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight, 65);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBaseline_toTopOf, 52);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf, 53);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintCircle, 2);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        sparseIntArray.append(h.ConstraintLayout_Layout_guidelineUseRtl, 67);
        sparseIntArray.append(h.ConstraintLayout_Layout_android_orientation, 1);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginBaseline, 55);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_marginBaseline, 54);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintTag, 51);
        sparseIntArray.append(h.ConstraintLayout_Layout_layout_wrapBehaviorInParent, 66);
      }
    }
  }
  
  private static abstract class a {
    public static final SparseIntArray a;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      a = sparseIntArray;
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth, 64);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight, 65);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBaseline_toTopOf, 52);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf, 53);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintCircle, 2);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      sparseIntArray.append(h.ConstraintLayout_Layout_guidelineUseRtl, 67);
      sparseIntArray.append(h.ConstraintLayout_Layout_android_orientation, 1);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_goneMarginBaseline, 55);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_marginBaseline, 54);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_constraintTag, 51);
      sparseIntArray.append(h.ConstraintLayout_Layout_layout_wrapBehaviorInParent, 66);
    }
  }
  
  class c implements s.b.b {
    ConstraintLayout a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    int g;
    
    public c(ConstraintLayout this$0, ConstraintLayout param1ConstraintLayout1) {
      this.a = param1ConstraintLayout1;
    }
    
    private boolean d(int param1Int1, int param1Int2, int param1Int3) {
      if (param1Int1 == param1Int2)
        return true; 
      int i = View.MeasureSpec.getMode(param1Int1);
      View.MeasureSpec.getSize(param1Int1);
      param1Int1 = View.MeasureSpec.getMode(param1Int2);
      param1Int2 = View.MeasureSpec.getSize(param1Int2);
      return (param1Int1 == 1073741824 && (i == Integer.MIN_VALUE || i == 0) && param1Int3 == param1Int2);
    }
    
    public final void a() {
      int j = this.a.getChildCount();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++)
        this.a.getChildAt(i); 
      j = ConstraintLayout.c(this.a).size();
      if (j > 0)
        for (i = bool; i < j; i++)
          ((b)ConstraintLayout.c(this.a).get(i)).l(this.a);  
    }
    
    public final void b(e param1e, s.b.a param1a) {
      // Byte code:
      //   0: aload_1
      //   1: ifnonnull -> 5
      //   4: return
      //   5: aload_1
      //   6: invokevirtual V : ()I
      //   9: bipush #8
      //   11: if_icmpne -> 37
      //   14: aload_1
      //   15: invokevirtual j0 : ()Z
      //   18: ifne -> 37
      //   21: aload_2
      //   22: iconst_0
      //   23: putfield e : I
      //   26: aload_2
      //   27: iconst_0
      //   28: putfield f : I
      //   31: aload_2
      //   32: iconst_0
      //   33: putfield g : I
      //   36: return
      //   37: aload_1
      //   38: invokevirtual K : ()Lr/e;
      //   41: ifnonnull -> 45
      //   44: return
      //   45: aload_2
      //   46: getfield a : Lr/e$b;
      //   49: astore #20
      //   51: aload_2
      //   52: getfield b : Lr/e$b;
      //   55: astore #21
      //   57: aload_2
      //   58: getfield c : I
      //   61: istore #4
      //   63: aload_2
      //   64: getfield d : I
      //   67: istore #7
      //   69: aload_0
      //   70: getfield b : I
      //   73: aload_0
      //   74: getfield c : I
      //   77: iadd
      //   78: istore #8
      //   80: aload_0
      //   81: getfield d : I
      //   84: istore #5
      //   86: aload_1
      //   87: invokevirtual s : ()Ljava/lang/Object;
      //   90: checkcast android/view/View
      //   93: astore #19
      //   95: getstatic androidx/constraintlayout/widget/ConstraintLayout$a.a : [I
      //   98: astore #22
      //   100: aload #22
      //   102: aload #20
      //   104: invokevirtual ordinal : ()I
      //   107: iaload
      //   108: istore #6
      //   110: iload #6
      //   112: iconst_1
      //   113: if_icmpeq -> 320
      //   116: iload #6
      //   118: iconst_2
      //   119: if_icmpeq -> 304
      //   122: iload #6
      //   124: iconst_3
      //   125: if_icmpeq -> 284
      //   128: iload #6
      //   130: iconst_4
      //   131: if_icmpeq -> 140
      //   134: iconst_0
      //   135: istore #4
      //   137: goto -> 329
      //   140: aload_0
      //   141: getfield f : I
      //   144: iload #5
      //   146: bipush #-2
      //   148: invokestatic getChildMeasureSpec : (III)I
      //   151: istore #6
      //   153: aload_1
      //   154: getfield w : I
      //   157: iconst_1
      //   158: if_icmpne -> 167
      //   161: iconst_1
      //   162: istore #5
      //   164: goto -> 170
      //   167: iconst_0
      //   168: istore #5
      //   170: aload_2
      //   171: getfield j : I
      //   174: istore #9
      //   176: iload #9
      //   178: getstatic s/b$a.l : I
      //   181: if_icmpeq -> 196
      //   184: iload #6
      //   186: istore #4
      //   188: iload #9
      //   190: getstatic s/b$a.m : I
      //   193: if_icmpne -> 329
      //   196: aload #19
      //   198: invokevirtual getMeasuredHeight : ()I
      //   201: aload_1
      //   202: invokevirtual x : ()I
      //   205: if_icmpne -> 214
      //   208: iconst_1
      //   209: istore #4
      //   211: goto -> 217
      //   214: iconst_0
      //   215: istore #4
      //   217: aload_2
      //   218: getfield j : I
      //   221: getstatic s/b$a.m : I
      //   224: if_icmpeq -> 258
      //   227: iload #5
      //   229: ifeq -> 258
      //   232: iload #5
      //   234: ifeq -> 242
      //   237: iload #4
      //   239: ifne -> 258
      //   242: aload_1
      //   243: invokevirtual n0 : ()Z
      //   246: ifeq -> 252
      //   249: goto -> 258
      //   252: iconst_0
      //   253: istore #5
      //   255: goto -> 261
      //   258: iconst_1
      //   259: istore #5
      //   261: iload #6
      //   263: istore #4
      //   265: iload #5
      //   267: ifeq -> 329
      //   270: aload_1
      //   271: invokevirtual W : ()I
      //   274: ldc 1073741824
      //   276: invokestatic makeMeasureSpec : (II)I
      //   279: istore #4
      //   281: goto -> 329
      //   284: aload_0
      //   285: getfield f : I
      //   288: iload #5
      //   290: aload_1
      //   291: invokevirtual B : ()I
      //   294: iadd
      //   295: iconst_m1
      //   296: invokestatic getChildMeasureSpec : (III)I
      //   299: istore #4
      //   301: goto -> 329
      //   304: aload_0
      //   305: getfield f : I
      //   308: iload #5
      //   310: bipush #-2
      //   312: invokestatic getChildMeasureSpec : (III)I
      //   315: istore #4
      //   317: goto -> 329
      //   320: iload #4
      //   322: ldc 1073741824
      //   324: invokestatic makeMeasureSpec : (II)I
      //   327: istore #4
      //   329: aload #22
      //   331: aload #21
      //   333: invokevirtual ordinal : ()I
      //   336: iaload
      //   337: istore #5
      //   339: iload #5
      //   341: iconst_1
      //   342: if_icmpeq -> 549
      //   345: iload #5
      //   347: iconst_2
      //   348: if_icmpeq -> 533
      //   351: iload #5
      //   353: iconst_3
      //   354: if_icmpeq -> 513
      //   357: iload #5
      //   359: iconst_4
      //   360: if_icmpeq -> 369
      //   363: iconst_0
      //   364: istore #5
      //   366: goto -> 558
      //   369: aload_0
      //   370: getfield g : I
      //   373: iload #8
      //   375: bipush #-2
      //   377: invokestatic getChildMeasureSpec : (III)I
      //   380: istore #7
      //   382: aload_1
      //   383: getfield x : I
      //   386: iconst_1
      //   387: if_icmpne -> 396
      //   390: iconst_1
      //   391: istore #6
      //   393: goto -> 399
      //   396: iconst_0
      //   397: istore #6
      //   399: aload_2
      //   400: getfield j : I
      //   403: istore #8
      //   405: iload #8
      //   407: getstatic s/b$a.l : I
      //   410: if_icmpeq -> 425
      //   413: iload #7
      //   415: istore #5
      //   417: iload #8
      //   419: getstatic s/b$a.m : I
      //   422: if_icmpne -> 558
      //   425: aload #19
      //   427: invokevirtual getMeasuredWidth : ()I
      //   430: aload_1
      //   431: invokevirtual W : ()I
      //   434: if_icmpne -> 443
      //   437: iconst_1
      //   438: istore #5
      //   440: goto -> 446
      //   443: iconst_0
      //   444: istore #5
      //   446: aload_2
      //   447: getfield j : I
      //   450: getstatic s/b$a.m : I
      //   453: if_icmpeq -> 487
      //   456: iload #6
      //   458: ifeq -> 487
      //   461: iload #6
      //   463: ifeq -> 471
      //   466: iload #5
      //   468: ifne -> 487
      //   471: aload_1
      //   472: invokevirtual o0 : ()Z
      //   475: ifeq -> 481
      //   478: goto -> 487
      //   481: iconst_0
      //   482: istore #6
      //   484: goto -> 490
      //   487: iconst_1
      //   488: istore #6
      //   490: iload #7
      //   492: istore #5
      //   494: iload #6
      //   496: ifeq -> 558
      //   499: aload_1
      //   500: invokevirtual x : ()I
      //   503: ldc 1073741824
      //   505: invokestatic makeMeasureSpec : (II)I
      //   508: istore #5
      //   510: goto -> 558
      //   513: aload_0
      //   514: getfield g : I
      //   517: iload #8
      //   519: aload_1
      //   520: invokevirtual U : ()I
      //   523: iadd
      //   524: iconst_m1
      //   525: invokestatic getChildMeasureSpec : (III)I
      //   528: istore #5
      //   530: goto -> 558
      //   533: aload_0
      //   534: getfield g : I
      //   537: iload #8
      //   539: bipush #-2
      //   541: invokestatic getChildMeasureSpec : (III)I
      //   544: istore #5
      //   546: goto -> 558
      //   549: iload #7
      //   551: ldc 1073741824
      //   553: invokestatic makeMeasureSpec : (II)I
      //   556: istore #5
      //   558: aload_1
      //   559: invokevirtual K : ()Lr/e;
      //   562: checkcast r/f
      //   565: astore #22
      //   567: aload #22
      //   569: ifnull -> 730
      //   572: aload_0
      //   573: getfield h : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   576: invokestatic b : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   579: sipush #256
      //   582: invokestatic b : (II)Z
      //   585: ifeq -> 730
      //   588: aload #19
      //   590: invokevirtual getMeasuredWidth : ()I
      //   593: aload_1
      //   594: invokevirtual W : ()I
      //   597: if_icmpne -> 730
      //   600: aload #19
      //   602: invokevirtual getMeasuredWidth : ()I
      //   605: aload #22
      //   607: invokevirtual W : ()I
      //   610: if_icmpge -> 730
      //   613: aload #19
      //   615: invokevirtual getMeasuredHeight : ()I
      //   618: aload_1
      //   619: invokevirtual x : ()I
      //   622: if_icmpne -> 730
      //   625: aload #19
      //   627: invokevirtual getMeasuredHeight : ()I
      //   630: aload #22
      //   632: invokevirtual x : ()I
      //   635: if_icmpge -> 730
      //   638: aload #19
      //   640: invokevirtual getBaseline : ()I
      //   643: aload_1
      //   644: invokevirtual p : ()I
      //   647: if_icmpne -> 730
      //   650: aload_1
      //   651: invokevirtual m0 : ()Z
      //   654: ifne -> 730
      //   657: aload_0
      //   658: aload_1
      //   659: invokevirtual C : ()I
      //   662: iload #4
      //   664: aload_1
      //   665: invokevirtual W : ()I
      //   668: invokespecial d : (III)Z
      //   671: ifeq -> 697
      //   674: aload_0
      //   675: aload_1
      //   676: invokevirtual D : ()I
      //   679: iload #5
      //   681: aload_1
      //   682: invokevirtual x : ()I
      //   685: invokespecial d : (III)Z
      //   688: ifeq -> 697
      //   691: iconst_1
      //   692: istore #6
      //   694: goto -> 700
      //   697: iconst_0
      //   698: istore #6
      //   700: iload #6
      //   702: ifeq -> 730
      //   705: aload_2
      //   706: aload_1
      //   707: invokevirtual W : ()I
      //   710: putfield e : I
      //   713: aload_2
      //   714: aload_1
      //   715: invokevirtual x : ()I
      //   718: putfield f : I
      //   721: aload_2
      //   722: aload_1
      //   723: invokevirtual p : ()I
      //   726: putfield g : I
      //   729: return
      //   730: getstatic r/e$b.c : Lr/e$b;
      //   733: astore #22
      //   735: aload #20
      //   737: aload #22
      //   739: if_acmpne -> 748
      //   742: iconst_1
      //   743: istore #6
      //   745: goto -> 751
      //   748: iconst_0
      //   749: istore #6
      //   751: aload #21
      //   753: aload #22
      //   755: if_acmpne -> 764
      //   758: iconst_1
      //   759: istore #7
      //   761: goto -> 767
      //   764: iconst_0
      //   765: istore #7
      //   767: getstatic r/e$b.d : Lr/e$b;
      //   770: astore #22
      //   772: aload #21
      //   774: aload #22
      //   776: if_acmpeq -> 796
      //   779: aload #21
      //   781: getstatic r/e$b.a : Lr/e$b;
      //   784: if_acmpne -> 790
      //   787: goto -> 796
      //   790: iconst_0
      //   791: istore #10
      //   793: goto -> 799
      //   796: iconst_1
      //   797: istore #10
      //   799: aload #20
      //   801: aload #22
      //   803: if_acmpeq -> 823
      //   806: aload #20
      //   808: getstatic r/e$b.a : Lr/e$b;
      //   811: if_acmpne -> 817
      //   814: goto -> 823
      //   817: iconst_0
      //   818: istore #11
      //   820: goto -> 826
      //   823: iconst_1
      //   824: istore #11
      //   826: iload #6
      //   828: ifeq -> 846
      //   831: aload_1
      //   832: getfield d0 : F
      //   835: fconst_0
      //   836: fcmpl
      //   837: ifle -> 846
      //   840: iconst_1
      //   841: istore #12
      //   843: goto -> 849
      //   846: iconst_0
      //   847: istore #12
      //   849: iload #7
      //   851: ifeq -> 869
      //   854: aload_1
      //   855: getfield d0 : F
      //   858: fconst_0
      //   859: fcmpl
      //   860: ifle -> 869
      //   863: iconst_1
      //   864: istore #13
      //   866: goto -> 872
      //   869: iconst_0
      //   870: istore #13
      //   872: aload #19
      //   874: ifnonnull -> 878
      //   877: return
      //   878: aload #19
      //   880: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   883: checkcast androidx/constraintlayout/widget/ConstraintLayout$b
      //   886: astore #20
      //   888: aload_2
      //   889: getfield j : I
      //   892: istore #8
      //   894: iload #8
      //   896: getstatic s/b$a.l : I
      //   899: if_icmpeq -> 949
      //   902: iload #8
      //   904: getstatic s/b$a.m : I
      //   907: if_icmpeq -> 949
      //   910: iload #6
      //   912: ifeq -> 949
      //   915: aload_1
      //   916: getfield w : I
      //   919: ifne -> 949
      //   922: iload #7
      //   924: ifeq -> 949
      //   927: aload_1
      //   928: getfield x : I
      //   931: ifeq -> 937
      //   934: goto -> 949
      //   937: iconst_0
      //   938: istore #6
      //   940: iconst_0
      //   941: istore #9
      //   943: iconst_0
      //   944: istore #10
      //   946: goto -> 1336
      //   949: aload #19
      //   951: instanceof androidx/constraintlayout/widget/j
      //   954: ifeq -> 987
      //   957: aload_1
      //   958: instanceof r/l
      //   961: ifeq -> 987
      //   964: aload_1
      //   965: checkcast r/l
      //   968: astore #21
      //   970: aload #19
      //   972: checkcast androidx/constraintlayout/widget/j
      //   975: aload #21
      //   977: iload #4
      //   979: iload #5
      //   981: invokevirtual p : (Lr/l;II)V
      //   984: goto -> 996
      //   987: aload #19
      //   989: iload #4
      //   991: iload #5
      //   993: invokevirtual measure : (II)V
      //   996: aload_1
      //   997: iload #4
      //   999: iload #5
      //   1001: invokevirtual V0 : (II)V
      //   1004: aload #19
      //   1006: invokevirtual getMeasuredWidth : ()I
      //   1009: istore #15
      //   1011: aload #19
      //   1013: invokevirtual getMeasuredHeight : ()I
      //   1016: istore #14
      //   1018: aload #19
      //   1020: invokevirtual getBaseline : ()I
      //   1023: istore #16
      //   1025: aload_1
      //   1026: getfield z : I
      //   1029: istore #6
      //   1031: iload #6
      //   1033: ifle -> 1048
      //   1036: iload #6
      //   1038: iload #15
      //   1040: invokestatic max : (II)I
      //   1043: istore #7
      //   1045: goto -> 1052
      //   1048: iload #15
      //   1050: istore #7
      //   1052: aload_1
      //   1053: getfield A : I
      //   1056: istore #8
      //   1058: iload #7
      //   1060: istore #6
      //   1062: iload #8
      //   1064: ifle -> 1076
      //   1067: iload #8
      //   1069: iload #7
      //   1071: invokestatic min : (II)I
      //   1074: istore #6
      //   1076: aload_1
      //   1077: getfield C : I
      //   1080: istore #7
      //   1082: iload #7
      //   1084: ifle -> 1099
      //   1087: iload #7
      //   1089: iload #14
      //   1091: invokestatic max : (II)I
      //   1094: istore #7
      //   1096: goto -> 1103
      //   1099: iload #14
      //   1101: istore #7
      //   1103: aload_1
      //   1104: getfield D : I
      //   1107: istore #8
      //   1109: iload #7
      //   1111: istore #9
      //   1113: iload #8
      //   1115: ifle -> 1127
      //   1118: iload #8
      //   1120: iload #7
      //   1122: invokestatic min : (II)I
      //   1125: istore #9
      //   1127: iload #9
      //   1129: istore #7
      //   1131: iload #6
      //   1133: istore #8
      //   1135: aload_0
      //   1136: getfield h : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   1139: invokestatic b : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   1142: iconst_1
      //   1143: invokestatic b : (II)Z
      //   1146: ifne -> 1228
      //   1149: iload #12
      //   1151: ifeq -> 1182
      //   1154: iload #10
      //   1156: ifeq -> 1182
      //   1159: aload_1
      //   1160: getfield d0 : F
      //   1163: fstore_3
      //   1164: iload #9
      //   1166: i2f
      //   1167: fload_3
      //   1168: fmul
      //   1169: ldc 0.5
      //   1171: fadd
      //   1172: f2i
      //   1173: istore #8
      //   1175: iload #9
      //   1177: istore #7
      //   1179: goto -> 1228
      //   1182: iload #9
      //   1184: istore #7
      //   1186: iload #6
      //   1188: istore #8
      //   1190: iload #13
      //   1192: ifeq -> 1228
      //   1195: iload #9
      //   1197: istore #7
      //   1199: iload #6
      //   1201: istore #8
      //   1203: iload #11
      //   1205: ifeq -> 1228
      //   1208: aload_1
      //   1209: getfield d0 : F
      //   1212: fstore_3
      //   1213: iload #6
      //   1215: i2f
      //   1216: fload_3
      //   1217: fdiv
      //   1218: ldc 0.5
      //   1220: fadd
      //   1221: f2i
      //   1222: istore #7
      //   1224: iload #6
      //   1226: istore #8
      //   1228: iload #15
      //   1230: iload #8
      //   1232: if_icmpne -> 1260
      //   1235: iload #7
      //   1237: istore #6
      //   1239: iload #16
      //   1241: istore #9
      //   1243: iload #8
      //   1245: istore #10
      //   1247: iload #14
      //   1249: iload #7
      //   1251: if_icmpeq -> 1257
      //   1254: goto -> 1260
      //   1257: goto -> 1336
      //   1260: iload #15
      //   1262: iload #8
      //   1264: if_icmpeq -> 1279
      //   1267: iload #8
      //   1269: ldc 1073741824
      //   1271: invokestatic makeMeasureSpec : (II)I
      //   1274: istore #4
      //   1276: goto -> 1279
      //   1279: iload #14
      //   1281: iload #7
      //   1283: if_icmpeq -> 1295
      //   1286: iload #7
      //   1288: ldc 1073741824
      //   1290: invokestatic makeMeasureSpec : (II)I
      //   1293: istore #5
      //   1295: aload #19
      //   1297: iload #4
      //   1299: iload #5
      //   1301: invokevirtual measure : (II)V
      //   1304: aload_1
      //   1305: iload #4
      //   1307: iload #5
      //   1309: invokevirtual V0 : (II)V
      //   1312: aload #19
      //   1314: invokevirtual getMeasuredWidth : ()I
      //   1317: istore #10
      //   1319: aload #19
      //   1321: invokevirtual getMeasuredHeight : ()I
      //   1324: istore #6
      //   1326: aload #19
      //   1328: invokevirtual getBaseline : ()I
      //   1331: istore #9
      //   1333: goto -> 1257
      //   1336: iload #9
      //   1338: iconst_m1
      //   1339: if_icmpeq -> 1348
      //   1342: iconst_1
      //   1343: istore #17
      //   1345: goto -> 1351
      //   1348: iconst_0
      //   1349: istore #17
      //   1351: iload #10
      //   1353: aload_2
      //   1354: getfield c : I
      //   1357: if_icmpne -> 1378
      //   1360: iload #6
      //   1362: aload_2
      //   1363: getfield d : I
      //   1366: if_icmpeq -> 1372
      //   1369: goto -> 1378
      //   1372: iconst_0
      //   1373: istore #18
      //   1375: goto -> 1381
      //   1378: iconst_1
      //   1379: istore #18
      //   1381: aload_2
      //   1382: iload #18
      //   1384: putfield i : Z
      //   1387: aload #20
      //   1389: getfield g0 : Z
      //   1392: ifeq -> 1398
      //   1395: iconst_1
      //   1396: istore #17
      //   1398: iload #17
      //   1400: ifeq -> 1423
      //   1403: iload #9
      //   1405: iconst_m1
      //   1406: if_icmpeq -> 1423
      //   1409: aload_1
      //   1410: invokevirtual p : ()I
      //   1413: iload #9
      //   1415: if_icmpeq -> 1423
      //   1418: aload_2
      //   1419: iconst_1
      //   1420: putfield i : Z
      //   1423: aload_2
      //   1424: iload #10
      //   1426: putfield e : I
      //   1429: aload_2
      //   1430: iload #6
      //   1432: putfield f : I
      //   1435: aload_2
      //   1436: iload #17
      //   1438: putfield h : Z
      //   1441: aload_2
      //   1442: iload #9
      //   1444: putfield g : I
      //   1447: return
    }
    
    public void c(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.b = param1Int3;
      this.c = param1Int4;
      this.d = param1Int5;
      this.e = param1Int6;
      this.f = param1Int1;
      this.g = param1Int2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */