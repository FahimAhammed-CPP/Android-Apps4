package androidx.appcompat.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.b1;
import androidx.appcompat.widget.d0;
import androidx.appcompat.widget.l1;
import androidx.appcompat.widget.m1;
import androidx.core.view.g0;
import androidx.core.view.l1;
import androidx.core.view.n0;
import androidx.core.view.t0;
import androidx.core.view.u0;
import androidx.core.view.v0;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParser;

class AppCompatDelegateImpl extends g implements g.a, LayoutInflater.Factory2 {
  private static final androidx.collection.g p0 = new androidx.collection.g();
  
  private static final boolean q0 = false;
  
  private static final int[] r0 = new int[] { 16842836 };
  
  private static final boolean s0 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  private static final boolean t0 = true;
  
  private boolean A;
  
  ViewGroup B;
  
  private TextView C;
  
  private View D;
  
  private boolean E;
  
  private boolean F;
  
  boolean G;
  
  boolean H;
  
  boolean I;
  
  boolean J;
  
  boolean K;
  
  private boolean L;
  
  private PanelFeatureState[] M;
  
  private PanelFeatureState N;
  
  private boolean O;
  
  private boolean P;
  
  private boolean Q;
  
  boolean R;
  
  private Configuration S;
  
  private int T = -100;
  
  private int U;
  
  private int V;
  
  private boolean W;
  
  private q X;
  
  private q Y;
  
  boolean Z;
  
  int g0;
  
  private final Runnable h0 = new a(this);
  
  private boolean i0;
  
  final Object j;
  
  private Rect j0;
  
  final Context k;
  
  private Rect k0;
  
  Window l;
  
  private y l0;
  
  private o m;
  
  private c0 m0;
  
  final e n;
  
  private OnBackInvokedDispatcher n0;
  
  a o;
  
  private OnBackInvokedCallback o0;
  
  MenuInflater p;
  
  private CharSequence q;
  
  private d0 r;
  
  private h s;
  
  private u t;
  
  androidx.appcompat.view.b u;
  
  ActionBarContextView v;
  
  PopupWindow w;
  
  Runnable x;
  
  t0 y = null;
  
  private boolean z = true;
  
  AppCompatDelegateImpl(Activity paramActivity, e parame) {
    this((Context)paramActivity, null, parame, paramActivity);
  }
  
  AppCompatDelegateImpl(Dialog paramDialog, e parame) {
    this(paramDialog.getContext(), paramDialog.getWindow(), parame, paramDialog);
  }
  
  private AppCompatDelegateImpl(Context paramContext, Window paramWindow, e parame, Object paramObject) {
    this.k = paramContext;
    this.n = parame;
    this.j = paramObject;
    if (this.T == -100 && paramObject instanceof Dialog) {
      d d = Z0();
      if (d != null)
        this.T = d.K().o(); 
    } 
    if (this.T == -100) {
      androidx.collection.g g1 = p0;
      Integer integer = (Integer)g1.get(paramObject.getClass().getName());
      if (integer != null) {
        this.T = integer.intValue();
        g1.remove(paramObject.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      U(paramWindow); 
    androidx.appcompat.widget.h.h();
  }
  
  private boolean E0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      PanelFeatureState panelFeatureState = s0(paramInt, true);
      if (!panelFeatureState.o)
        return O0(panelFeatureState, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean H0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield u : Landroidx/appcompat/view/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual s0 : (IZ)Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;
    //   18: astore #5
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield r : Landroidx/appcompat/widget/d0;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 113
    //   35: aload #6
    //   37: invokeinterface d : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield k : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield r : Landroidx/appcompat/widget/d0;
    //   62: invokeinterface b : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield R : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #5
    //   80: aload_2
    //   81: invokespecial O0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield r : Landroidx/appcompat/widget/d0;
    //   91: invokeinterface g : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield r : Landroidx/appcompat/widget/d0;
    //   104: invokeinterface f : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #5
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #5
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #5
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #5
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #5
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #5
    //   159: aload_2
    //   160: invokespecial O0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #5
    //   176: aload_2
    //   177: invokespecial L0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #5
    //   194: iconst_1
    //   195: invokevirtual b0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;Z)V
    //   198: iload_3
    //   199: ifeq -> 240
    //   202: aload_0
    //   203: getfield k : Landroid/content/Context;
    //   206: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   209: ldc_w 'audio'
    //   212: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   215: checkcast android/media/AudioManager
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 230
    //   223: aload_2
    //   224: iconst_0
    //   225: invokevirtual playSoundEffect : (I)V
    //   228: iload_3
    //   229: ireturn
    //   230: ldc_w 'AppCompatDelegate'
    //   233: ldc_w 'Couldn't get audio manager'
    //   236: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: iload_3
    //   241: ireturn
  }
  
  private void L0(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 416
    //   7: aload_0
    //   8: getfield R : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield k : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual u0 : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Landroidx/appcompat/view/menu/g;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual b0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield k : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokespecial O0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield q : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield i : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 331
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 331
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 331
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 334
    //   171: aload_2
    //   172: ifnonnull -> 191
    //   175: aload_0
    //   176: aload_1
    //   177: invokespecial x0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;)Z
    //   180: ifeq -> 190
    //   183: aload_1
    //   184: getfield g : Landroid/view/ViewGroup;
    //   187: ifnonnull -> 212
    //   190: return
    //   191: aload_1
    //   192: getfield q : Z
    //   195: ifeq -> 212
    //   198: aload_2
    //   199: invokevirtual getChildCount : ()I
    //   202: ifle -> 212
    //   205: aload_1
    //   206: getfield g : Landroid/view/ViewGroup;
    //   209: invokevirtual removeAllViews : ()V
    //   212: aload_0
    //   213: aload_1
    //   214: invokespecial w0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;)Z
    //   217: ifeq -> 411
    //   220: aload_1
    //   221: invokevirtual b : ()Z
    //   224: ifne -> 230
    //   227: goto -> 411
    //   230: aload_1
    //   231: getfield h : Landroid/view/View;
    //   234: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   237: astore #4
    //   239: aload #4
    //   241: astore_2
    //   242: aload #4
    //   244: ifnonnull -> 259
    //   247: new android/view/ViewGroup$LayoutParams
    //   250: dup
    //   251: bipush #-2
    //   253: bipush #-2
    //   255: invokespecial <init> : (II)V
    //   258: astore_2
    //   259: aload_1
    //   260: getfield b : I
    //   263: istore_3
    //   264: aload_1
    //   265: getfield g : Landroid/view/ViewGroup;
    //   268: iload_3
    //   269: invokevirtual setBackgroundResource : (I)V
    //   272: aload_1
    //   273: getfield h : Landroid/view/View;
    //   276: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   279: astore #4
    //   281: aload #4
    //   283: instanceof android/view/ViewGroup
    //   286: ifeq -> 301
    //   289: aload #4
    //   291: checkcast android/view/ViewGroup
    //   294: aload_1
    //   295: getfield h : Landroid/view/View;
    //   298: invokevirtual removeView : (Landroid/view/View;)V
    //   301: aload_1
    //   302: getfield g : Landroid/view/ViewGroup;
    //   305: aload_1
    //   306: getfield h : Landroid/view/View;
    //   309: aload_2
    //   310: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   313: aload_1
    //   314: getfield h : Landroid/view/View;
    //   317: invokevirtual hasFocus : ()Z
    //   320: ifne -> 331
    //   323: aload_1
    //   324: getfield h : Landroid/view/View;
    //   327: invokevirtual requestFocus : ()Z
    //   330: pop
    //   331: bipush #-2
    //   333: istore_3
    //   334: aload_1
    //   335: iconst_0
    //   336: putfield n : Z
    //   339: new android/view/WindowManager$LayoutParams
    //   342: dup
    //   343: iload_3
    //   344: bipush #-2
    //   346: aload_1
    //   347: getfield d : I
    //   350: aload_1
    //   351: getfield e : I
    //   354: sipush #1002
    //   357: ldc_w 8519680
    //   360: bipush #-3
    //   362: invokespecial <init> : (IIIIIII)V
    //   365: astore_2
    //   366: aload_2
    //   367: aload_1
    //   368: getfield c : I
    //   371: putfield gravity : I
    //   374: aload_2
    //   375: aload_1
    //   376: getfield f : I
    //   379: putfield windowAnimations : I
    //   382: aload #5
    //   384: aload_1
    //   385: getfield g : Landroid/view/ViewGroup;
    //   388: aload_2
    //   389: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   394: aload_1
    //   395: iconst_1
    //   396: putfield o : Z
    //   399: aload_1
    //   400: getfield a : I
    //   403: ifne -> 410
    //   406: aload_0
    //   407: invokevirtual c1 : ()V
    //   410: return
    //   411: aload_1
    //   412: iconst_1
    //   413: putfield q : Z
    //   416: return
  }
  
  private boolean N0(PanelFeatureState paramPanelFeatureState, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokespecial O0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Landroidx/appcompat/view/menu/g;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield r : Landroidx/appcompat/widget/d0;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual b0 : (Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  private boolean O0(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent) {
    d0 d01;
    if (this.R)
      return false; 
    if (paramPanelFeatureState.m)
      return true; 
    PanelFeatureState panelFeatureState = this.N;
    if (panelFeatureState != null && panelFeatureState != paramPanelFeatureState)
      b0(panelFeatureState, false); 
    Window.Callback callback = u0();
    if (callback != null)
      paramPanelFeatureState.i = callback.onCreatePanelView(paramPanelFeatureState.a); 
    int i = paramPanelFeatureState.a;
    if (i == 0 || i == 108) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      d0 d02 = this.r;
      if (d02 != null)
        d02.c(); 
    } 
    if (paramPanelFeatureState.i == null && (i == 0 || !(M0() instanceof g0))) {
      d0 d02;
      boolean bool;
      g g1 = paramPanelFeatureState.j;
      if (g1 == null || paramPanelFeatureState.r) {
        if (g1 == null && (!y0(paramPanelFeatureState) || paramPanelFeatureState.j == null))
          return false; 
        if (i != 0 && this.r != null) {
          if (this.s == null)
            this.s = new h(this); 
          this.r.a((Menu)paramPanelFeatureState.j, this.s);
        } 
        paramPanelFeatureState.j.h0();
        if (!callback.onCreatePanelMenu(paramPanelFeatureState.a, (Menu)paramPanelFeatureState.j)) {
          paramPanelFeatureState.c(null);
          if (i != 0) {
            d01 = this.r;
            if (d01 != null)
              d01.a(null, this.s); 
          } 
          return false;
        } 
        ((PanelFeatureState)d01).r = false;
      } 
      ((PanelFeatureState)d01).j.h0();
      Bundle bundle = ((PanelFeatureState)d01).s;
      if (bundle != null) {
        ((PanelFeatureState)d01).j.R(bundle);
        ((PanelFeatureState)d01).s = null;
      } 
      if (!callback.onPreparePanel(0, ((PanelFeatureState)d01).i, (Menu)((PanelFeatureState)d01).j)) {
        if (i != 0) {
          d02 = this.r;
          if (d02 != null)
            d02.a(null, this.s); 
        } 
        ((PanelFeatureState)d01).j.g0();
        return false;
      } 
      if (d02 != null) {
        i = d02.getDeviceId();
      } else {
        i = -1;
      } 
      if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((PanelFeatureState)d01).p = bool;
      ((PanelFeatureState)d01).j.setQwertyMode(bool);
      ((PanelFeatureState)d01).j.g0();
    } 
    ((PanelFeatureState)d01).m = true;
    ((PanelFeatureState)d01).n = false;
    this.N = (PanelFeatureState)d01;
    return true;
  }
  
  private void P0(boolean paramBoolean) {
    d0 d01 = this.r;
    if (d01 != null && d01.d() && (!ViewConfiguration.get(this.k).hasPermanentMenuKey() || this.r.e())) {
      Window.Callback callback = u0();
      if (!this.r.b() || !paramBoolean) {
        if (callback != null && !this.R) {
          if (this.Z && (this.g0 & 0x1) != 0) {
            this.l.getDecorView().removeCallbacks(this.h0);
            this.h0.run();
          } 
          PanelFeatureState panelFeatureState1 = s0(0, true);
          g g1 = panelFeatureState1.j;
          if (g1 != null && !panelFeatureState1.r && callback.onPreparePanel(0, panelFeatureState1.i, (Menu)g1)) {
            callback.onMenuOpened(108, (Menu)panelFeatureState1.j);
            this.r.g();
          } 
        } 
        return;
      } 
      this.r.f();
      if (!this.R) {
        callback.onPanelClosed(108, (Menu)(s0(0, true)).j);
        return;
      } 
      return;
    } 
    PanelFeatureState panelFeatureState = s0(0, true);
    panelFeatureState.q = true;
    b0(panelFeatureState, false);
    L0(panelFeatureState, null);
  }
  
  private boolean Q(boolean paramBoolean) {
    return R(paramBoolean, true);
  }
  
  private int Q0(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    int i = paramInt;
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      i = 109;
    } 
    return i;
  }
  
  private boolean R(boolean paramBoolean1, boolean paramBoolean2) {
    androidx.core.os.j j1;
    if (this.R)
      return false; 
    int i = W();
    int j = B0(this.k, i);
    if (Build.VERSION.SDK_INT < 33) {
      j1 = V(this.k);
    } else {
      j1 = null;
    } 
    androidx.core.os.j j2 = j1;
    if (!paramBoolean2) {
      j2 = j1;
      if (j1 != null)
        j2 = r0(this.k.getResources().getConfiguration()); 
    } 
    paramBoolean1 = b1(j, j2, paramBoolean1);
    if (i == 0) {
      q0(this.k).e();
    } else {
      q q2 = this.X;
      if (q2 != null)
        q2.a(); 
    } 
    if (i == 3) {
      p0(this.k).e();
      return paramBoolean1;
    } 
    q q1 = this.Y;
    if (q1 != null)
      q1.a(); 
    return paramBoolean1;
  }
  
  private void T() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.B.findViewById(16908290);
    View view = this.l.getDecorView();
    contentFrameLayout.a(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.k.obtainStyledAttributes(d.j.AppCompatTheme);
    typedArray.getValue(d.j.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(d.j.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
    int i = d.j.AppCompatTheme_windowFixedWidthMajor;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMajor()); 
    i = d.j.AppCompatTheme_windowFixedWidthMinor;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMinor()); 
    i = d.j.AppCompatTheme_windowFixedHeightMajor;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMajor()); 
    i = d.j.AppCompatTheme_windowFixedHeightMinor;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private void U(Window paramWindow) {
    if (this.l == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof o)) {
        o o1 = new o(this, callback);
        this.m = o1;
        paramWindow.setCallback((Window.Callback)o1);
        b1 b1 = b1.u(this.k, null, r0);
        Drawable drawable = b1.h(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        b1.w();
        this.l = paramWindow;
        if (Build.VERSION.SDK_INT >= 33 && this.n0 == null)
          L(null); 
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  private boolean U0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.l.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (n0.X((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  private int W() {
    int i = this.T;
    return (i != -100) ? i : g.m();
  }
  
  private void Y0() {
    if (!this.A)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  private void Z() {
    q q1 = this.X;
    if (q1 != null)
      q1.a(); 
    q1 = this.Y;
    if (q1 != null)
      q1.a(); 
  }
  
  private d Z0() {
    Context context = this.k;
    while (context != null) {
      if (context instanceof d)
        return (d)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  private void a1(Configuration paramConfiguration) {
    Activity activity = (Activity)this.j;
    if (activity instanceof androidx.lifecycle.n) {
      if (((androidx.lifecycle.n)activity).getLifecycle().b().d(androidx.lifecycle.h.b.c)) {
        activity.onConfigurationChanged(paramConfiguration);
        return;
      } 
    } else if (this.Q && !this.R) {
      activity.onConfigurationChanged(paramConfiguration);
    } 
  }
  
  private boolean b1(int paramInt, androidx.core.os.j paramj, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield k : Landroid/content/Context;
    //   5: iload_1
    //   6: aload_2
    //   7: aconst_null
    //   8: iconst_0
    //   9: invokespecial c0 : (Landroid/content/Context;ILandroidx/core/os/j;Landroid/content/res/Configuration;Z)Landroid/content/res/Configuration;
    //   12: astore #12
    //   14: aload_0
    //   15: aload_0
    //   16: getfield k : Landroid/content/Context;
    //   19: invokespecial o0 : (Landroid/content/Context;)I
    //   22: istore #6
    //   24: aload_0
    //   25: getfield S : Landroid/content/res/Configuration;
    //   28: astore #11
    //   30: aload #11
    //   32: astore #10
    //   34: aload #11
    //   36: ifnonnull -> 51
    //   39: aload_0
    //   40: getfield k : Landroid/content/Context;
    //   43: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   46: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   49: astore #10
    //   51: aload #10
    //   53: getfield uiMode : I
    //   56: istore #4
    //   58: aload #12
    //   60: getfield uiMode : I
    //   63: bipush #48
    //   65: iand
    //   66: istore #7
    //   68: aload_0
    //   69: aload #10
    //   71: invokevirtual r0 : (Landroid/content/res/Configuration;)Landroidx/core/os/j;
    //   74: astore #11
    //   76: aload_2
    //   77: ifnonnull -> 86
    //   80: aconst_null
    //   81: astore #10
    //   83: goto -> 94
    //   86: aload_0
    //   87: aload #12
    //   89: invokevirtual r0 : (Landroid/content/res/Configuration;)Landroidx/core/os/j;
    //   92: astore #10
    //   94: iconst_0
    //   95: istore #9
    //   97: iload #4
    //   99: bipush #48
    //   101: iand
    //   102: iload #7
    //   104: if_icmpeq -> 115
    //   107: sipush #512
    //   110: istore #4
    //   112: goto -> 118
    //   115: iconst_0
    //   116: istore #4
    //   118: iload #4
    //   120: istore #5
    //   122: aload #10
    //   124: ifnull -> 151
    //   127: iload #4
    //   129: istore #5
    //   131: aload #11
    //   133: aload #10
    //   135: invokevirtual equals : (Ljava/lang/Object;)Z
    //   138: ifne -> 151
    //   141: iload #4
    //   143: iconst_4
    //   144: ior
    //   145: sipush #8192
    //   148: ior
    //   149: istore #5
    //   151: iconst_1
    //   152: istore #8
    //   154: iload #6
    //   156: iload #5
    //   158: iand
    //   159: ifeq -> 226
    //   162: iload_3
    //   163: ifeq -> 226
    //   166: aload_0
    //   167: getfield P : Z
    //   170: ifeq -> 226
    //   173: getstatic androidx/appcompat/app/AppCompatDelegateImpl.s0 : Z
    //   176: ifne -> 186
    //   179: aload_0
    //   180: getfield Q : Z
    //   183: ifeq -> 226
    //   186: aload_0
    //   187: getfield j : Ljava/lang/Object;
    //   190: astore #11
    //   192: aload #11
    //   194: instanceof android/app/Activity
    //   197: ifeq -> 226
    //   200: aload #11
    //   202: checkcast android/app/Activity
    //   205: invokevirtual isChild : ()Z
    //   208: ifne -> 226
    //   211: aload_0
    //   212: getfield j : Ljava/lang/Object;
    //   215: checkcast android/app/Activity
    //   218: invokestatic f : (Landroid/app/Activity;)V
    //   221: iconst_1
    //   222: istore_3
    //   223: goto -> 228
    //   226: iconst_0
    //   227: istore_3
    //   228: iload_3
    //   229: ifne -> 268
    //   232: iload #5
    //   234: ifeq -> 268
    //   237: iload #9
    //   239: istore_3
    //   240: iload #5
    //   242: iload #6
    //   244: iand
    //   245: iload #5
    //   247: if_icmpne -> 252
    //   250: iconst_1
    //   251: istore_3
    //   252: aload_0
    //   253: iload #7
    //   255: aload #10
    //   257: iload_3
    //   258: aconst_null
    //   259: invokespecial d1 : (ILandroidx/core/os/j;ZLandroid/content/res/Configuration;)V
    //   262: iload #8
    //   264: istore_3
    //   265: goto -> 268
    //   268: iload_3
    //   269: ifeq -> 322
    //   272: aload_0
    //   273: getfield j : Ljava/lang/Object;
    //   276: astore #11
    //   278: aload #11
    //   280: instanceof androidx/appcompat/app/d
    //   283: ifeq -> 322
    //   286: iload #5
    //   288: sipush #512
    //   291: iand
    //   292: ifeq -> 304
    //   295: aload #11
    //   297: checkcast androidx/appcompat/app/d
    //   300: iload_1
    //   301: invokevirtual P : (I)V
    //   304: iload #5
    //   306: iconst_4
    //   307: iand
    //   308: ifeq -> 322
    //   311: aload_0
    //   312: getfield j : Ljava/lang/Object;
    //   315: checkcast androidx/appcompat/app/d
    //   318: aload_2
    //   319: invokevirtual O : (Landroidx/core/os/j;)V
    //   322: iload_3
    //   323: ifeq -> 349
    //   326: aload #10
    //   328: ifnull -> 349
    //   331: aload_0
    //   332: aload_0
    //   333: aload_0
    //   334: getfield k : Landroid/content/Context;
    //   337: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   340: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   343: invokevirtual r0 : (Landroid/content/res/Configuration;)Landroidx/core/os/j;
    //   346: invokevirtual S0 : (Landroidx/core/os/j;)V
    //   349: iload_3
    //   350: ireturn
  }
  
  private Configuration c0(Context paramContext, int paramInt, androidx.core.os.j paramj, Configuration paramConfiguration, boolean paramBoolean) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramBoolean) {
          paramInt = 0;
        } else {
          paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
        } 
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    if (paramj != null)
      R0(configuration, paramj); 
    return configuration;
  }
  
  private ViewGroup d0() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.k.obtainStyledAttributes(d.j.AppCompatTheme);
    int i = d.j.AppCompatTheme_windowActionBar;
    if (typedArray.hasValue(i)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(d.j.AppCompatTheme_windowNoTitle, false)) {
        H(1);
      } else if (typedArray.getBoolean(i, false)) {
        H(108);
      } 
      if (typedArray.getBoolean(d.j.AppCompatTheme_windowActionBarOverlay, false))
        H(109); 
      if (typedArray.getBoolean(d.j.AppCompatTheme_windowActionModeOverlay, false))
        H(10); 
      this.J = typedArray.getBoolean(d.j.AppCompatTheme_android_windowIsFloating, false);
      typedArray.recycle();
      k0();
      this.l.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.k);
      if (!this.K) {
        if (this.J) {
          viewGroup = (ViewGroup)layoutInflater.inflate(d.g.abc_dialog_title_material, null);
          this.H = false;
          this.G = false;
        } else if (this.G) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.k.getTheme().resolveAttribute(d.a.actionBarTheme, typedValue, true);
          if (typedValue.resourceId != 0) {
            androidx.appcompat.view.d d = new androidx.appcompat.view.d(this.k, typedValue.resourceId);
          } else {
            context = this.k;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(d.g.abc_screen_toolbar, null);
          d0 d01 = (d0)viewGroup1.findViewById(d.f.decor_content_parent);
          this.r = d01;
          d01.setWindowCallback(u0());
          if (this.H)
            this.r.h(109); 
          if (this.E)
            this.r.h(2); 
          viewGroup = viewGroup1;
          if (this.F) {
            this.r.h(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else if (this.I) {
        viewGroup = (ViewGroup)layoutInflater.inflate(d.g.abc_screen_simple_overlay_action_mode, null);
      } else {
        viewGroup = (ViewGroup)viewGroup.inflate(d.g.abc_screen_simple, null);
      } 
      if (viewGroup != null) {
        n0.I0((View)viewGroup, new b(this));
        if (this.r == null)
          this.C = (TextView)viewGroup.findViewById(d.f.title); 
        m1.c((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(d.f.action_bar_activity_content);
        ViewGroup viewGroup1 = (ViewGroup)this.l.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.l.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new c(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.G);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.H);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.J);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.I);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.K);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
  }
  
  private void d1(int paramInt, androidx.core.os.j paramj, boolean paramBoolean, Configuration paramConfiguration) {
    Resources resources = this.k.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    if (paramConfiguration != null)
      configuration.updateFrom(paramConfiguration); 
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    if (paramj != null)
      R0(configuration, paramj); 
    resources.updateConfiguration(configuration, null);
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 26)
      e0.a(resources); 
    int i = this.U;
    if (i != 0) {
      this.k.setTheme(i);
      if (paramInt >= 23)
        this.k.getTheme().applyStyle(this.U, true); 
    } 
    if (paramBoolean && this.j instanceof Activity)
      a1(configuration); 
  }
  
  private void f1(View paramView) {
    int i;
    if ((n0.Q(paramView) & 0x2000) != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = androidx.core.content.a.getColor(this.k, d.c.abc_decor_view_status_guard_light);
    } else {
      i = androidx.core.content.a.getColor(this.k, d.c.abc_decor_view_status_guard);
    } 
    paramView.setBackgroundColor(i);
  }
  
  private void j0() {
    if (!this.A) {
      this.B = d0();
      CharSequence charSequence = t0();
      if (!TextUtils.isEmpty(charSequence)) {
        d0 d01 = this.r;
        if (d01 != null) {
          d01.setWindowTitle(charSequence);
        } else if (M0() != null) {
          M0().A(charSequence);
        } else {
          TextView textView = this.C;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      T();
      K0(this.B);
      this.A = true;
      PanelFeatureState panelFeatureState = s0(0, false);
      if (!this.R && (panelFeatureState == null || panelFeatureState.j == null))
        z0(108); 
    } 
  }
  
  private void k0() {
    if (this.l == null) {
      Object object = this.j;
      if (object instanceof Activity)
        U(((Activity)object).getWindow()); 
    } 
    if (this.l != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  private static Configuration m0(Configuration paramConfiguration1, Configuration paramConfiguration2) {
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration2 != null) {
      if (paramConfiguration1.diff(paramConfiguration2) == 0)
        return configuration; 
      float f1 = paramConfiguration1.fontScale;
      float f2 = paramConfiguration2.fontScale;
      if (f1 != f2)
        configuration.fontScale = f2; 
      int i = paramConfiguration1.mcc;
      int j = paramConfiguration2.mcc;
      if (i != j)
        configuration.mcc = j; 
      i = paramConfiguration1.mnc;
      j = paramConfiguration2.mnc;
      if (i != j)
        configuration.mnc = j; 
      i = Build.VERSION.SDK_INT;
      if (i >= 24) {
        l.a(paramConfiguration1, paramConfiguration2, configuration);
      } else if (!androidx.core.util.c.a(paramConfiguration1.locale, paramConfiguration2.locale)) {
        configuration.locale = paramConfiguration2.locale;
      } 
      j = paramConfiguration1.touchscreen;
      int k = paramConfiguration2.touchscreen;
      if (j != k)
        configuration.touchscreen = k; 
      j = paramConfiguration1.keyboard;
      k = paramConfiguration2.keyboard;
      if (j != k)
        configuration.keyboard = k; 
      j = paramConfiguration1.keyboardHidden;
      k = paramConfiguration2.keyboardHidden;
      if (j != k)
        configuration.keyboardHidden = k; 
      j = paramConfiguration1.navigation;
      k = paramConfiguration2.navigation;
      if (j != k)
        configuration.navigation = k; 
      j = paramConfiguration1.navigationHidden;
      k = paramConfiguration2.navigationHidden;
      if (j != k)
        configuration.navigationHidden = k; 
      j = paramConfiguration1.orientation;
      k = paramConfiguration2.orientation;
      if (j != k)
        configuration.orientation = k; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xF) != (k & 0xF))
        configuration.screenLayout |= k & 0xF; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xC0) != (k & 0xC0))
        configuration.screenLayout |= k & 0xC0; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x30) != (k & 0x30))
        configuration.screenLayout |= k & 0x30; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x300) != (k & 0x300))
        configuration.screenLayout |= k & 0x300; 
      if (i >= 26)
        m.a(paramConfiguration1, paramConfiguration2, configuration); 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0xF) != (j & 0xF))
        configuration.uiMode |= j & 0xF; 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0x30) != (j & 0x30))
        configuration.uiMode |= j & 0x30; 
      i = paramConfiguration1.screenWidthDp;
      j = paramConfiguration2.screenWidthDp;
      if (i != j)
        configuration.screenWidthDp = j; 
      i = paramConfiguration1.screenHeightDp;
      j = paramConfiguration2.screenHeightDp;
      if (i != j)
        configuration.screenHeightDp = j; 
      i = paramConfiguration1.smallestScreenWidthDp;
      j = paramConfiguration2.smallestScreenWidthDp;
      if (i != j)
        configuration.smallestScreenWidthDp = j; 
      j.b(paramConfiguration1, paramConfiguration2, configuration);
    } 
    return configuration;
  }
  
  private int o0(Context paramContext) {
    if (!this.W && this.j instanceof Activity) {
      PackageManager packageManager = paramContext.getPackageManager();
      if (packageManager == null)
        return 0; 
      try {
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
          i = 269221888;
        } else if (i >= 24) {
          i = 786432;
        } else {
          i = 0;
        } 
        ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(paramContext, this.j.getClass()), i);
        if (activityInfo != null)
          this.V = activityInfo.configChanges; 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
        this.V = 0;
      } 
    } 
    this.W = true;
    return this.V;
  }
  
  private q p0(Context paramContext) {
    if (this.Y == null)
      this.Y = new p(this, paramContext); 
    return this.Y;
  }
  
  private q q0(Context paramContext) {
    if (this.X == null)
      this.X = new r(this, i0.a(paramContext)); 
    return this.X;
  }
  
  private void v0() {
    j0();
    if (this.G) {
      if (this.o != null)
        return; 
      Object object = this.j;
      if (object instanceof Activity) {
        this.o = new j0((Activity)this.j, this.H);
      } else if (object instanceof Dialog) {
        this.o = new j0((Dialog)this.j);
      } 
      object = this.o;
      if (object != null)
        object.q(this.i0); 
    } 
  }
  
  private boolean w0(PanelFeatureState paramPanelFeatureState) {
    View view = paramPanelFeatureState.i;
    if (view != null) {
      paramPanelFeatureState.h = view;
      return true;
    } 
    if (paramPanelFeatureState.j == null)
      return false; 
    if (this.t == null)
      this.t = new u(this); 
    view = (View)paramPanelFeatureState.a(this.t);
    paramPanelFeatureState.h = view;
    return (view != null);
  }
  
  private boolean x0(PanelFeatureState paramPanelFeatureState) {
    paramPanelFeatureState.d(n0());
    paramPanelFeatureState.g = (ViewGroup)new t(this, paramPanelFeatureState.l);
    paramPanelFeatureState.c = 81;
    return true;
  }
  
  private boolean y0(PanelFeatureState paramPanelFeatureState) {
    // Byte code:
    //   0: aload_0
    //   1: getfield k : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield r : Landroidx/appcompat/widget/d0;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #6
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #7
    //   50: aload #7
    //   52: getstatic d/a.actionBarTheme : I
    //   55: aload #6
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aload #6
    //   64: getfield resourceId : I
    //   67: ifeq -> 109
    //   70: aload #5
    //   72: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   75: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   78: astore_3
    //   79: aload_3
    //   80: aload #7
    //   82: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   85: aload_3
    //   86: aload #6
    //   88: getfield resourceId : I
    //   91: iconst_1
    //   92: invokevirtual applyStyle : (IZ)V
    //   95: aload_3
    //   96: getstatic d/a.actionBarWidgetTheme : I
    //   99: aload #6
    //   101: iconst_1
    //   102: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   105: pop
    //   106: goto -> 123
    //   109: aload #7
    //   111: getstatic d/a.actionBarWidgetTheme : I
    //   114: aload #6
    //   116: iconst_1
    //   117: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   120: pop
    //   121: aconst_null
    //   122: astore_3
    //   123: aload_3
    //   124: astore #4
    //   126: aload #6
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #7
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #6
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new androidx/appcompat/view/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new androidx/appcompat/view/menu/g
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual V : (Landroidx/appcompat/view/menu/g$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Landroidx/appcompat/view/menu/g;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  private void z0(int paramInt) {
    this.g0 = 1 << paramInt | this.g0;
    if (!this.Z) {
      n0.m0(this.l.getDecorView(), this.h0);
      this.Z = true;
    } 
  }
  
  public void A(Bundle paramBundle) {
    j0();
  }
  
  public boolean A0() {
    return this.z;
  }
  
  public void B() {
    a a1 = s();
    if (a1 != null)
      a1.x(true); 
  }
  
  int B0(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1)
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3)
              return p0(paramContext).c(); 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          return (Build.VERSION.SDK_INT >= 23 && ((UiModeManager)paramContext.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) ? -1 : q0(paramContext).c();
        }  
      return paramInt;
    } 
    return -1;
  }
  
  public void C(Bundle paramBundle) {}
  
  boolean C0() {
    boolean bool = this.O;
    this.O = false;
    PanelFeatureState panelFeatureState = s0(0, false);
    if (panelFeatureState != null && panelFeatureState.o) {
      if (!bool)
        b0(panelFeatureState, true); 
      return true;
    } 
    androidx.appcompat.view.b b1 = this.u;
    if (b1 != null) {
      b1.c();
      return true;
    } 
    a a1 = s();
    return (a1 != null && a1.g());
  }
  
  public void D() {
    R(true, false);
  }
  
  boolean D0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      E0(0, paramKeyEvent);
      return true;
    } 
    if ((paramKeyEvent.getFlags() & 0x80) == 0)
      bool = false; 
    this.O = bool;
    return false;
  }
  
  public void E() {
    a a1 = s();
    if (a1 != null)
      a1.x(false); 
  }
  
  boolean F0(int paramInt, KeyEvent paramKeyEvent) {
    PanelFeatureState panelFeatureState1;
    a a1 = s();
    if (a1 != null && a1.n(paramInt, paramKeyEvent))
      return true; 
    PanelFeatureState panelFeatureState2 = this.N;
    if (panelFeatureState2 != null && N0(panelFeatureState2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      panelFeatureState1 = this.N;
      if (panelFeatureState1 != null)
        panelFeatureState1.n = true; 
      return true;
    } 
    if (this.N == null) {
      panelFeatureState2 = s0(0, true);
      O0(panelFeatureState2, (KeyEvent)panelFeatureState1);
      boolean bool = N0(panelFeatureState2, panelFeatureState1.getKeyCode(), (KeyEvent)panelFeatureState1, 1);
      panelFeatureState2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  boolean G0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      H0(0, paramKeyEvent);
      return true;
    } 
    return C0();
  }
  
  public boolean H(int paramInt) {
    paramInt = Q0(paramInt);
    if (this.K && paramInt == 108)
      return false; 
    if (this.G && paramInt == 1)
      this.G = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.l.requestFeature(paramInt); 
              Y0();
              this.H = true;
              return true;
            } 
            Y0();
            this.G = true;
            return true;
          } 
          Y0();
          this.I = true;
          return true;
        } 
        Y0();
        this.F = true;
        return true;
      } 
      Y0();
      this.E = true;
      return true;
    } 
    Y0();
    this.K = true;
    return true;
  }
  
  public void I(int paramInt) {
    j0();
    ViewGroup viewGroup = (ViewGroup)this.B.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.k).inflate(paramInt, viewGroup);
    this.m.c(this.l.getCallback());
  }
  
  void I0(int paramInt) {
    if (paramInt == 108) {
      a a1 = s();
      if (a1 != null)
        a1.h(true); 
    } 
  }
  
  public void J(View paramView) {
    j0();
    ViewGroup viewGroup = (ViewGroup)this.B.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.m.c(this.l.getCallback());
  }
  
  void J0(int paramInt) {
    if (paramInt == 108) {
      a a1 = s();
      if (a1 != null) {
        a1.h(false);
        return;
      } 
    } else if (paramInt == 0) {
      PanelFeatureState panelFeatureState = s0(paramInt, true);
      if (panelFeatureState.o)
        b0(panelFeatureState, false); 
    } 
  }
  
  public void K(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    j0();
    ViewGroup viewGroup = (ViewGroup)this.B.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.m.c(this.l.getCallback());
  }
  
  void K0(ViewGroup paramViewGroup) {}
  
  public void L(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial L : (Landroid/window/OnBackInvokedDispatcher;)V
    //   5: aload_0
    //   6: getfield n0 : Landroid/window/OnBackInvokedDispatcher;
    //   9: astore_2
    //   10: aload_2
    //   11: ifnull -> 33
    //   14: aload_0
    //   15: getfield o0 : Landroid/window/OnBackInvokedCallback;
    //   18: astore_3
    //   19: aload_3
    //   20: ifnull -> 33
    //   23: aload_2
    //   24: aload_3
    //   25: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   28: aload_0
    //   29: aconst_null
    //   30: putfield o0 : Landroid/window/OnBackInvokedCallback;
    //   33: aload_1
    //   34: ifnonnull -> 76
    //   37: aload_0
    //   38: getfield j : Ljava/lang/Object;
    //   41: astore_2
    //   42: aload_2
    //   43: instanceof android/app/Activity
    //   46: ifeq -> 76
    //   49: aload_2
    //   50: checkcast android/app/Activity
    //   53: invokevirtual getWindow : ()Landroid/view/Window;
    //   56: ifnull -> 76
    //   59: aload_0
    //   60: aload_0
    //   61: getfield j : Ljava/lang/Object;
    //   64: checkcast android/app/Activity
    //   67: invokestatic a : (Landroid/app/Activity;)Landroid/window/OnBackInvokedDispatcher;
    //   70: putfield n0 : Landroid/window/OnBackInvokedDispatcher;
    //   73: goto -> 81
    //   76: aload_0
    //   77: aload_1
    //   78: putfield n0 : Landroid/window/OnBackInvokedDispatcher;
    //   81: aload_0
    //   82: invokevirtual c1 : ()V
    //   85: return
  }
  
  public void M(Toolbar paramToolbar) {
    if (!(this.j instanceof Activity))
      return; 
    a a1 = s();
    if (!(a1 instanceof j0)) {
      this.p = null;
      if (a1 != null)
        a1.m(); 
      this.o = null;
      if (paramToolbar != null) {
        a1 = new g0(paramToolbar, t0(), (Window.Callback)this.m);
        this.o = a1;
        this.m.e(((g0)a1).c);
        paramToolbar.setBackInvokedCallbackEnabled(true);
      } else {
        this.m.e(null);
      } 
      u();
      return;
    } 
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  final a M0() {
    return this.o;
  }
  
  public void N(int paramInt) {
    this.U = paramInt;
  }
  
  public final void O(CharSequence paramCharSequence) {
    this.q = paramCharSequence;
    d0 d01 = this.r;
    if (d01 != null) {
      d01.setWindowTitle(paramCharSequence);
      return;
    } 
    if (M0() != null) {
      M0().A(paramCharSequence);
      return;
    } 
    TextView textView = this.C;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  void R0(Configuration paramConfiguration, androidx.core.os.j paramj) {
    if (Build.VERSION.SDK_INT >= 24) {
      l.d(paramConfiguration, paramj);
      return;
    } 
    j.d(paramConfiguration, paramj.d(0));
    j.c(paramConfiguration, paramj.d(0));
  }
  
  public boolean S() {
    return Q(true);
  }
  
  void S0(androidx.core.os.j paramj) {
    if (Build.VERSION.SDK_INT >= 24) {
      l.c(paramj);
      return;
    } 
    Locale.setDefault(paramj.d(0));
  }
  
  final boolean T0() {
    if (this.A) {
      ViewGroup viewGroup = this.B;
      if (viewGroup != null && n0.Y((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  androidx.core.os.j V(Context paramContext) {
    androidx.core.os.j j1;
    int i = Build.VERSION.SDK_INT;
    if (i >= 33)
      return null; 
    androidx.core.os.j j3 = g.r();
    if (j3 == null)
      return null; 
    androidx.core.os.j j2 = r0(paramContext.getApplicationContext().getResources().getConfiguration());
    if (i >= 24) {
      j1 = d0.b(j3, j2);
    } else if (j3.f()) {
      j1 = androidx.core.os.j.e();
    } else {
      j1 = androidx.core.os.j.c(j3.d(0).toString());
    } 
    return j1.f() ? j2 : j1;
  }
  
  boolean V0() {
    if (this.n0 == null)
      return false; 
    PanelFeatureState panelFeatureState = s0(0, false);
    return (panelFeatureState != null && panelFeatureState.o) ? true : ((this.u != null));
  }
  
  public androidx.appcompat.view.b W0(androidx.appcompat.view.b.a parama) {
    if (parama != null) {
      androidx.appcompat.view.b b1 = this.u;
      if (b1 != null)
        b1.c(); 
      parama = new i(this, parama);
      a a1 = s();
      if (a1 != null) {
        androidx.appcompat.view.b b2 = a1.B(parama);
        this.u = b2;
        if (b2 != null) {
          e e1 = this.n;
          if (e1 != null)
            e1.a(b2); 
        } 
      } 
      if (this.u == null)
        this.u = X0(parama); 
      c1();
      return this.u;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  void X(int paramInt, PanelFeatureState paramPanelFeatureState, Menu paramMenu) {
    g g1;
    PanelFeatureState panelFeatureState = paramPanelFeatureState;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      PanelFeatureState panelFeatureState1 = paramPanelFeatureState;
      if (paramPanelFeatureState == null) {
        panelFeatureState1 = paramPanelFeatureState;
        if (paramInt >= 0) {
          PanelFeatureState[] arrayOfPanelFeatureState = this.M;
          panelFeatureState1 = paramPanelFeatureState;
          if (paramInt < arrayOfPanelFeatureState.length)
            panelFeatureState1 = arrayOfPanelFeatureState[paramInt]; 
        } 
      } 
      panelFeatureState = panelFeatureState1;
      menu = paramMenu;
      if (panelFeatureState1 != null) {
        g1 = panelFeatureState1.j;
        panelFeatureState = panelFeatureState1;
      } 
    } 
    if (panelFeatureState != null && !panelFeatureState.o)
      return; 
    if (!this.R)
      this.m.d(this.l.getCallback(), paramInt, (Menu)g1); 
  }
  
  androidx.appcompat.view.b X0(androidx.appcompat.view.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual i0 : ()V
    //   4: aload_0
    //   5: getfield u : Landroidx/appcompat/view/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual c : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof androidx/appcompat/app/AppCompatDelegateImpl$i
    //   27: ifne -> 41
    //   30: new androidx/appcompat/app/AppCompatDelegateImpl$i
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Landroidx/appcompat/app/AppCompatDelegateImpl;Landroidx/appcompat/view/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield n : Landroidx/appcompat/app/e;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield R : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface i : (Landroidx/appcompat/view/b$a;)Landroidx/appcompat/view/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield u : Landroidx/appcompat/view/b;
    //   80: goto -> 565
    //   83: aload_0
    //   84: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield J : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield k : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic d/a.actionBarTheme : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield k : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new androidx/appcompat/view/d
    //   169: dup
    //   170: aload_0
    //   171: getfield k : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield k : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic d/a.actionModePopupWindowStyle : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield w : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield w : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield w : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic d/a.actionBarSize : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield w : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new androidx/appcompat/app/AppCompatDelegateImpl$d
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Landroidx/appcompat/app/AppCompatDelegateImpl;)V
    //   309: putfield x : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield B : Landroid/view/ViewGroup;
    //   319: getstatic d/f.action_mode_bar_stub : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual n0 : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual a : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 565
    //   362: aload_0
    //   363: invokevirtual i0 : ()V
    //   366: aload_0
    //   367: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual k : ()V
    //   373: aload_0
    //   374: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore_1
    //   381: aload_0
    //   382: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   385: astore #5
    //   387: aload_0
    //   388: getfield w : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new androidx/appcompat/view/e
    //   402: dup
    //   403: aload_1
    //   404: aload #5
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Landroidx/appcompat/view/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual e : ()Landroid/view/Menu;
    //   420: invokeinterface b : (Landroidx/appcompat/view/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 560
    //   428: aload_1
    //   429: invokevirtual k : ()V
    //   432: aload_0
    //   433: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual h : (Landroidx/appcompat/view/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield u : Landroidx/appcompat/view/b;
    //   445: aload_0
    //   446: invokevirtual T0 : ()Z
    //   449: ifeq -> 493
    //   452: aload_0
    //   453: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic e : (Landroid/view/View;)Landroidx/core/view/t0;
    //   467: fconst_1
    //   468: invokevirtual b : (F)Landroidx/core/view/t0;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield y : Landroidx/core/view/t0;
    //   477: aload_1
    //   478: new androidx/appcompat/app/AppCompatDelegateImpl$e
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/appcompat/app/AppCompatDelegateImpl;)V
    //   486: invokevirtual h : (Landroidx/core/view/u0;)Landroidx/core/view/t0;
    //   489: pop
    //   490: goto -> 535
    //   493: aload_0
    //   494: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   497: fconst_1
    //   498: invokevirtual setAlpha : (F)V
    //   501: aload_0
    //   502: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   505: iconst_0
    //   506: invokevirtual setVisibility : (I)V
    //   509: aload_0
    //   510: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   513: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   516: instanceof android/view/View
    //   519: ifeq -> 535
    //   522: aload_0
    //   523: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   526: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   529: checkcast android/view/View
    //   532: invokestatic r0 : (Landroid/view/View;)V
    //   535: aload_0
    //   536: getfield w : Landroid/widget/PopupWindow;
    //   539: ifnull -> 565
    //   542: aload_0
    //   543: getfield l : Landroid/view/Window;
    //   546: invokevirtual getDecorView : ()Landroid/view/View;
    //   549: aload_0
    //   550: getfield x : Ljava/lang/Runnable;
    //   553: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   556: pop
    //   557: goto -> 565
    //   560: aload_0
    //   561: aconst_null
    //   562: putfield u : Landroidx/appcompat/view/b;
    //   565: aload_0
    //   566: getfield u : Landroidx/appcompat/view/b;
    //   569: astore_1
    //   570: aload_1
    //   571: ifnull -> 593
    //   574: aload_0
    //   575: getfield n : Landroidx/appcompat/app/e;
    //   578: astore #4
    //   580: aload #4
    //   582: ifnull -> 593
    //   585: aload #4
    //   587: aload_1
    //   588: invokeinterface a : (Landroidx/appcompat/view/b;)V
    //   593: aload_0
    //   594: invokevirtual c1 : ()V
    //   597: aload_0
    //   598: getfield u : Landroidx/appcompat/view/b;
    //   601: areturn
    //   602: astore_1
    //   603: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	602	java/lang/AbstractMethodError
  }
  
  void Y(g paramg) {
    if (this.L)
      return; 
    this.L = true;
    this.r.i();
    Window.Callback callback = u0();
    if (callback != null && !this.R)
      callback.onPanelClosed(108, (Menu)paramg); 
    this.L = false;
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    Window.Callback callback = u0();
    if (callback != null && !this.R) {
      PanelFeatureState panelFeatureState = l0((Menu)paramg.F());
      if (panelFeatureState != null)
        return callback.onMenuItemSelected(panelFeatureState.a, paramMenuItem); 
    } 
    return false;
  }
  
  void a0(int paramInt) {
    b0(s0(paramInt, true), true);
  }
  
  public void b(g paramg) {
    P0(true);
  }
  
  void b0(PanelFeatureState paramPanelFeatureState, boolean paramBoolean) {
    if (paramBoolean && paramPanelFeatureState.a == 0) {
      d0 d01 = this.r;
      if (d01 != null && d01.b()) {
        Y(paramPanelFeatureState.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.k.getSystemService("window");
    if (windowManager != null && paramPanelFeatureState.o) {
      ViewGroup viewGroup = paramPanelFeatureState.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          X(paramPanelFeatureState.a, paramPanelFeatureState, null); 
      } 
    } 
    paramPanelFeatureState.m = false;
    paramPanelFeatureState.n = false;
    paramPanelFeatureState.o = false;
    paramPanelFeatureState.h = null;
    paramPanelFeatureState.q = true;
    if (this.N == paramPanelFeatureState)
      this.N = null; 
    if (paramPanelFeatureState.a == 0)
      c1(); 
  }
  
  void c1() {
    if (Build.VERSION.SDK_INT >= 33) {
      boolean bool = V0();
      if (bool && this.o0 == null) {
        this.o0 = n.b(this.n0, this);
        return;
      } 
      if (!bool) {
        OnBackInvokedCallback onBackInvokedCallback = this.o0;
        if (onBackInvokedCallback != null)
          n.c(this.n0, onBackInvokedCallback); 
      } 
    } 
  }
  
  public void e(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    j0();
    ((ViewGroup)this.B.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.m.c(this.l.getCallback());
  }
  
  public View e0(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    y y1 = this.l0;
    boolean bool1 = false;
    if (y1 == null) {
      String str = this.k.obtainStyledAttributes(d.j.AppCompatTheme).getString(d.j.AppCompatTheme_viewInflaterClass);
      if (str == null) {
        this.l0 = new y();
      } else {
        try {
          this.l0 = this.k.getClassLoader().loadClass(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } finally {
          Exception exception = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), exception);
        } 
      } 
    } 
    boolean bool2 = q0;
    if (bool2) {
      if (this.m0 == null)
        this.m0 = new c0(); 
      if (this.m0.a(paramAttributeSet)) {
        bool1 = true;
      } else if (paramAttributeSet instanceof XmlPullParser) {
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = true; 
      } else {
        bool1 = U0((ViewParent)paramView);
      } 
    } else {
      bool1 = false;
    } 
    return this.l0.r(paramView, paramString, paramContext, paramAttributeSet, bool1, bool2, true, l1.c());
  }
  
  final int e1(l1 paraml1, Rect paramRect) {
    int i;
    int j;
    boolean bool1;
    boolean bool2 = false;
    if (paraml1 != null) {
      i = paraml1.l();
    } else if (paramRect != null) {
      i = paramRect.top;
    } else {
      i = 0;
    } 
    ActionBarContextView actionBarContextView = this.v;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.v.getLayoutParams();
      boolean bool3 = this.v.isShown();
      int k = 1;
      bool1 = true;
      if (bool3) {
        int m;
        if (this.j0 == null) {
          this.j0 = new Rect();
          this.k0 = new Rect();
        } 
        Rect rect1 = this.j0;
        Rect rect2 = this.k0;
        if (paraml1 == null) {
          rect1.set(paramRect);
        } else {
          rect1.set(paraml1.j(), paraml1.l(), paraml1.k(), paraml1.i());
        } 
        m1.a((View)this.B, rect1, rect2);
        int n = rect1.top;
        bool = rect1.left;
        int i1 = rect1.right;
        paraml1 = n0.L((View)this.B);
        if (paraml1 == null) {
          k = 0;
        } else {
          k = paraml1.j();
        } 
        if (paraml1 == null) {
          m = 0;
        } else {
          m = paraml1.k();
        } 
        if (marginLayoutParams.topMargin != n || marginLayoutParams.leftMargin != bool || marginLayoutParams.rightMargin != i1) {
          marginLayoutParams.topMargin = n;
          marginLayoutParams.leftMargin = bool;
          marginLayoutParams.rightMargin = i1;
          bool = true;
        } else {
          bool = false;
        } 
        if (n > 0 && this.D == null) {
          View view2 = new View(this.k);
          this.D = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = k;
          layoutParams.rightMargin = m;
          this.B.addView(this.D, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.D;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            n = marginLayoutParams1.height;
            i1 = marginLayoutParams.topMargin;
            if (n != i1 || marginLayoutParams1.leftMargin != k || marginLayoutParams1.rightMargin != m) {
              marginLayoutParams1.height = i1;
              marginLayoutParams1.leftMargin = k;
              marginLayoutParams1.rightMargin = m;
              this.D.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.D;
        if (view1 != null) {
          m = bool1;
        } else {
          m = 0;
        } 
        if (m != 0 && view1.getVisibility() != 0)
          f1(this.D); 
        k = i;
        if (!this.I) {
          k = i;
          if (m != 0)
            k = 0; 
        } 
        i = k;
        k = bool;
        bool = m;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
      } else {
        bool = false;
        k = 0;
      } 
      j = i;
      bool1 = bool;
      if (k != 0) {
        this.v.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        j = i;
        bool1 = bool;
      } 
    } else {
      bool1 = false;
      j = i;
    } 
    View view = this.D;
    if (view != null) {
      if (bool1) {
        i = bool2;
      } else {
        i = 8;
      } 
      view.setVisibility(i);
    } 
    return j;
  }
  
  void f0() {
    d0 d01 = this.r;
    if (d01 != null)
      d01.i(); 
    if (this.w != null) {
      this.l.getDecorView().removeCallbacks(this.x);
      if (this.w.isShowing())
        try {
          this.w.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.w = null;
    } 
    i0();
    PanelFeatureState panelFeatureState = s0(0, false);
    if (panelFeatureState != null) {
      g g1 = panelFeatureState.j;
      if (g1 != null)
        g1.close(); 
    } 
  }
  
  public Context g(Context paramContext) {
    int i = 1;
    this.P = true;
    int j = B0(paramContext, W());
    if (g.v(paramContext))
      g.P(paramContext); 
    androidx.core.os.j j1 = V(paramContext);
    if (t0 && paramContext instanceof ContextThemeWrapper) {
      Configuration configuration = c0(paramContext, j, j1, null, false);
      try {
        s.a((ContextThemeWrapper)paramContext, configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (paramContext instanceof androidx.appcompat.view.d) {
      Configuration configuration = c0(paramContext, j, j1, null, false);
      try {
        ((androidx.appcompat.view.d)paramContext).a(configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (!s0)
      return super.g(paramContext); 
    Configuration configuration1 = new Configuration();
    configuration1.uiMode = -1;
    configuration1.fontScale = 0.0F;
    configuration1 = j.a(paramContext, configuration1).getResources().getConfiguration();
    Configuration configuration3 = paramContext.getResources().getConfiguration();
    configuration1.uiMode = configuration3.uiMode;
    if (!configuration1.equals(configuration3)) {
      configuration1 = m0(configuration1, configuration3);
    } else {
      configuration1 = null;
    } 
    Configuration configuration2 = c0(paramContext, j, j1, configuration1, true);
    androidx.appcompat.view.d d = new androidx.appcompat.view.d(paramContext, d.i.Theme_AppCompat_Empty);
    d.a(configuration2);
    j = 0;
    try {
      Resources.Theme theme = paramContext.getTheme();
      if (theme == null)
        i = 0; 
    } catch (NullPointerException nullPointerException) {
      i = j;
    } 
    if (i != 0)
      androidx.core.content.res.h.f.a(d.getTheme()); 
    return super.g((Context)d);
  }
  
  boolean g0(KeyEvent paramKeyEvent) {
    Object object = this.j;
    boolean bool1 = object instanceof androidx.core.view.q.a;
    boolean bool = true;
    if (bool1 || object instanceof w) {
      object = this.l.getDecorView();
      if (object != null && androidx.core.view.q.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.m.b(this.l.getCallback(), paramKeyEvent))
      return true; 
    int i = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? D0(i, paramKeyEvent) : G0(i, paramKeyEvent);
  }
  
  void h0(int paramInt) {
    PanelFeatureState panelFeatureState = s0(paramInt, true);
    if (panelFeatureState.j != null) {
      Bundle bundle = new Bundle();
      panelFeatureState.j.T(bundle);
      if (bundle.size() > 0)
        panelFeatureState.s = bundle; 
      panelFeatureState.j.h0();
      panelFeatureState.j.clear();
    } 
    panelFeatureState.r = true;
    panelFeatureState.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.r != null) {
      panelFeatureState = s0(0, false);
      if (panelFeatureState != null) {
        panelFeatureState.m = false;
        O0(panelFeatureState, null);
      } 
    } 
  }
  
  void i0() {
    t0 t01 = this.y;
    if (t01 != null)
      t01.c(); 
  }
  
  public View j(int paramInt) {
    j0();
    return this.l.findViewById(paramInt);
  }
  
  public Context l() {
    return this.k;
  }
  
  PanelFeatureState l0(Menu paramMenu) {
    byte b1;
    PanelFeatureState[] arrayOfPanelFeatureState = this.M;
    int i = 0;
    if (arrayOfPanelFeatureState != null) {
      b1 = arrayOfPanelFeatureState.length;
    } else {
      b1 = 0;
    } 
    while (i < b1) {
      PanelFeatureState panelFeatureState = arrayOfPanelFeatureState[i];
      if (panelFeatureState != null && panelFeatureState.j == paramMenu)
        return panelFeatureState; 
      i++;
    } 
    return null;
  }
  
  public final b.b n() {
    return new f(this);
  }
  
  final Context n0() {
    Context context;
    a a1 = s();
    if (a1 != null) {
      Context context1 = a1.j();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null)
      context = this.k; 
    return context;
  }
  
  public int o() {
    return this.T;
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return e0(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public MenuInflater q() {
    if (this.p == null) {
      Context context;
      v0();
      a a1 = this.o;
      if (a1 != null) {
        context = a1.j();
      } else {
        context = this.k;
      } 
      this.p = (MenuInflater)new androidx.appcompat.view.g(context);
    } 
    return this.p;
  }
  
  androidx.core.os.j r0(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? l.b(paramConfiguration) : androidx.core.os.j.c(k.b(paramConfiguration.locale));
  }
  
  public a s() {
    v0();
    return this.o;
  }
  
  protected PanelFeatureState s0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield M : [Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray androidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield M : [Landroidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new androidx/appcompat/app/AppCompatDelegateImpl$PanelFeatureState
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  public void t() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.k);
    if (layoutInflater.getFactory() == null) {
      androidx.core.view.r.a(layoutInflater, this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof AppCompatDelegateImpl))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  final CharSequence t0() {
    Object object = this.j;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.q;
  }
  
  public void u() {
    if (M0() != null) {
      if (s().k())
        return; 
      z0(0);
    } 
  }
  
  final Window.Callback u0() {
    return this.l.getCallback();
  }
  
  public void x(Configuration paramConfiguration) {
    if (this.G && this.A) {
      a a1 = s();
      if (a1 != null)
        a1.l(paramConfiguration); 
    } 
    androidx.appcompat.widget.h.b().g(this.k);
    this.S = new Configuration(this.k.getResources().getConfiguration());
    R(false, false);
  }
  
  public void y(Bundle paramBundle) {
    this.P = true;
    Q(false);
    k0();
    Object object = this.j;
    if (object instanceof Activity) {
      try {
        object = androidx.core.app.i.c((Activity)object);
      } catch (IllegalArgumentException illegalArgumentException) {
        illegalArgumentException = null;
      } 
      if (illegalArgumentException != null) {
        a a1 = M0();
        if (a1 == null) {
          this.i0 = true;
        } else {
          a1.q(true);
        } 
      } 
      g.d(this);
    } 
    this.S = new Configuration(this.k.getResources().getConfiguration());
    this.Q = true;
  }
  
  public void z() {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 14
    //   10: aload_0
    //   11: invokestatic F : (Landroidx/appcompat/app/g;)V
    //   14: aload_0
    //   15: getfield Z : Z
    //   18: ifeq -> 36
    //   21: aload_0
    //   22: getfield l : Landroid/view/Window;
    //   25: invokevirtual getDecorView : ()Landroid/view/View;
    //   28: aload_0
    //   29: getfield h0 : Ljava/lang/Runnable;
    //   32: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   35: pop
    //   36: aload_0
    //   37: iconst_1
    //   38: putfield R : Z
    //   41: aload_0
    //   42: getfield T : I
    //   45: bipush #-100
    //   47: if_icmpeq -> 99
    //   50: aload_0
    //   51: getfield j : Ljava/lang/Object;
    //   54: astore_1
    //   55: aload_1
    //   56: instanceof android/app/Activity
    //   59: ifeq -> 99
    //   62: aload_1
    //   63: checkcast android/app/Activity
    //   66: invokevirtual isChangingConfigurations : ()Z
    //   69: ifeq -> 99
    //   72: getstatic androidx/appcompat/app/AppCompatDelegateImpl.p0 : Landroidx/collection/g;
    //   75: aload_0
    //   76: getfield j : Ljava/lang/Object;
    //   79: invokevirtual getClass : ()Ljava/lang/Class;
    //   82: invokevirtual getName : ()Ljava/lang/String;
    //   85: aload_0
    //   86: getfield T : I
    //   89: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   92: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   95: pop
    //   96: goto -> 116
    //   99: getstatic androidx/appcompat/app/AppCompatDelegateImpl.p0 : Landroidx/collection/g;
    //   102: aload_0
    //   103: getfield j : Ljava/lang/Object;
    //   106: invokevirtual getClass : ()Ljava/lang/Class;
    //   109: invokevirtual getName : ()Ljava/lang/String;
    //   112: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   115: pop
    //   116: aload_0
    //   117: getfield o : Landroidx/appcompat/app/a;
    //   120: astore_1
    //   121: aload_1
    //   122: ifnull -> 129
    //   125: aload_1
    //   126: invokevirtual m : ()V
    //   129: aload_0
    //   130: invokespecial Z : ()V
    //   133: return
  }
  
  protected static final class PanelFeatureState {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    g j;
    
    androidx.appcompat.view.menu.e k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    public boolean p;
    
    boolean q;
    
    boolean r;
    
    Bundle s;
    
    PanelFeatureState(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    androidx.appcompat.view.menu.n a(androidx.appcompat.view.menu.m.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        androidx.appcompat.view.menu.e e1 = new androidx.appcompat.view.menu.e(this.l, d.g.abc_list_menu_item_layout);
        this.k = e1;
        e1.g(param1a);
        this.j.b((androidx.appcompat.view.menu.m)this.k);
      } 
      return this.k.j(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.a().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    void c(g param1g) {
      g g1 = this.j;
      if (param1g == g1)
        return; 
      if (g1 != null)
        g1.Q((androidx.appcompat.view.menu.m)this.k); 
      this.j = param1g;
      if (param1g != null) {
        androidx.appcompat.view.menu.e e1 = this.k;
        if (e1 != null)
          param1g.b((androidx.appcompat.view.menu.m)e1); 
      } 
    }
    
    void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(d.a.actionBarPopupTheme, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(d.a.panelMenuListTheme, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(d.i.Theme_AppCompat_CompactMenu, true);
      } 
      androidx.appcompat.view.d d = new androidx.appcompat.view.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(d.j.AppCompatTheme);
      this.b = typedArray.getResourceId(d.j.AppCompatTheme_panelBackground, 0);
      this.f = typedArray.getResourceId(d.j.AppCompatTheme_android_windowAnimationStyle, 0);
      typedArray.recycle();
    }
    
    @SuppressLint({"BanParcelableUsage"})
    private static class SavedState implements Parcelable {
      public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
      
      int a;
      
      boolean b;
      
      Bundle c;
      
      static SavedState a(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        SavedState savedState = new SavedState();
        savedState.a = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        savedState.b = bool;
        if (bool)
          savedState.c = param2Parcel.readBundle(param2ClassLoader); 
        return savedState;
      }
      
      public int describeContents() {
        return 0;
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
      }
      
      class a implements Parcelable.ClassLoaderCreator {
        public AppCompatDelegateImpl.PanelFeatureState.SavedState a(Parcel param3Parcel) {
          return AppCompatDelegateImpl.PanelFeatureState.SavedState.a(param3Parcel, null);
        }
        
        public AppCompatDelegateImpl.PanelFeatureState.SavedState b(Parcel param3Parcel, ClassLoader param3ClassLoader) {
          return AppCompatDelegateImpl.PanelFeatureState.SavedState.a(param3Parcel, param3ClassLoader);
        }
        
        public AppCompatDelegateImpl.PanelFeatureState.SavedState[] c(int param3Int) {
          return new AppCompatDelegateImpl.PanelFeatureState.SavedState[param3Int];
        }
      }
    }
    
    class a implements Parcelable.ClassLoaderCreator {
      public AppCompatDelegateImpl.PanelFeatureState.SavedState a(Parcel param2Parcel) {
        return AppCompatDelegateImpl.PanelFeatureState.SavedState.a(param2Parcel, null);
      }
      
      public AppCompatDelegateImpl.PanelFeatureState.SavedState b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return AppCompatDelegateImpl.PanelFeatureState.SavedState.a(param2Parcel, param2ClassLoader);
      }
      
      public AppCompatDelegateImpl.PanelFeatureState.SavedState[] c(int param2Int) {
        return new AppCompatDelegateImpl.PanelFeatureState.SavedState[param2Int];
      }
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  private static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
    
    int a;
    
    boolean b;
    
    Bundle c;
    
    static SavedState a(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      SavedState savedState = new SavedState();
      savedState.a = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      savedState.b = bool;
      if (bool)
        savedState.c = param1Parcel.readBundle(param1ClassLoader); 
      return savedState;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    class a implements Parcelable.ClassLoaderCreator {
      public AppCompatDelegateImpl.PanelFeatureState.SavedState a(Parcel param3Parcel) {
        return AppCompatDelegateImpl.PanelFeatureState.SavedState.a(param3Parcel, null);
      }
      
      public AppCompatDelegateImpl.PanelFeatureState.SavedState b(Parcel param3Parcel, ClassLoader param3ClassLoader) {
        return AppCompatDelegateImpl.PanelFeatureState.SavedState.a(param3Parcel, param3ClassLoader);
      }
      
      public AppCompatDelegateImpl.PanelFeatureState.SavedState[] c(int param3Int) {
        return new AppCompatDelegateImpl.PanelFeatureState.SavedState[param3Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator {
    public AppCompatDelegateImpl.PanelFeatureState.SavedState a(Parcel param1Parcel) {
      return AppCompatDelegateImpl.PanelFeatureState.SavedState.a(param1Parcel, null);
    }
    
    public AppCompatDelegateImpl.PanelFeatureState.SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return AppCompatDelegateImpl.PanelFeatureState.SavedState.a(param1Parcel, param1ClassLoader);
    }
    
    public AppCompatDelegateImpl.PanelFeatureState.SavedState[] c(int param1Int) {
      return new AppCompatDelegateImpl.PanelFeatureState.SavedState[param1Int];
    }
  }
  
  class a implements Runnable {
    a(AppCompatDelegateImpl this$0) {}
    
    public void run() {
      AppCompatDelegateImpl appCompatDelegateImpl = this.a;
      if ((appCompatDelegateImpl.g0 & 0x1) != 0)
        appCompatDelegateImpl.h0(0); 
      appCompatDelegateImpl = this.a;
      if ((appCompatDelegateImpl.g0 & 0x1000) != 0)
        appCompatDelegateImpl.h0(108); 
      appCompatDelegateImpl = this.a;
      appCompatDelegateImpl.Z = false;
      appCompatDelegateImpl.g0 = 0;
    }
  }
  
  class b implements g0 {
    b(AppCompatDelegateImpl this$0) {}
    
    public l1 a(View param1View, l1 param1l1) {
      int i = param1l1.l();
      int j = this.a.e1(param1l1, null);
      l1 l11 = param1l1;
      if (i != j)
        l11 = param1l1.q(param1l1.j(), j, param1l1.k(), param1l1.i()); 
      return n0.g0(param1View, l11);
    }
  }
  
  class c implements ContentFrameLayout.a {
    c(AppCompatDelegateImpl this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.f0();
    }
  }
  
  class d implements Runnable {
    d(AppCompatDelegateImpl this$0) {}
    
    public void run() {
      AppCompatDelegateImpl appCompatDelegateImpl = this.a;
      appCompatDelegateImpl.w.showAtLocation((View)appCompatDelegateImpl.v, 55, 0, 0);
      this.a.i0();
      if (this.a.T0()) {
        this.a.v.setAlpha(0.0F);
        appCompatDelegateImpl = this.a;
        appCompatDelegateImpl.y = n0.e((View)appCompatDelegateImpl.v).b(1.0F);
        this.a.y.h((u0)new a(this));
        return;
      } 
      this.a.v.setAlpha(1.0F);
      this.a.v.setVisibility(0);
    }
    
    class a extends v0 {
      a(AppCompatDelegateImpl.d this$0) {}
      
      public void b(View param2View) {
        this.a.a.v.setAlpha(1.0F);
        this.a.a.y.h(null);
        this.a.a.y = null;
      }
      
      public void c(View param2View) {
        this.a.a.v.setVisibility(0);
      }
    }
  }
  
  class a extends v0 {
    a(AppCompatDelegateImpl this$0) {}
    
    public void b(View param1View) {
      this.a.a.v.setAlpha(1.0F);
      this.a.a.y.h(null);
      this.a.a.y = null;
    }
    
    public void c(View param1View) {
      this.a.a.v.setVisibility(0);
    }
  }
  
  class e extends v0 {
    e(AppCompatDelegateImpl this$0) {}
    
    public void b(View param1View) {
      this.a.v.setAlpha(1.0F);
      this.a.y.h(null);
      this.a.y = null;
    }
    
    public void c(View param1View) {
      this.a.v.setVisibility(0);
      if (this.a.v.getParent() instanceof View)
        n0.r0((View)this.a.v.getParent()); 
    }
  }
  
  private class f implements b.b {
    f(AppCompatDelegateImpl this$0) {}
    
    public boolean a() {
      a a = this.a.s();
      return (a != null && (a.i() & 0x4) != 0);
    }
    
    public Context b() {
      return this.a.n0();
    }
    
    public void c(Drawable param1Drawable, int param1Int) {
      a a = this.a.s();
      if (a != null) {
        a.w(param1Drawable);
        a.v(param1Int);
      } 
    }
    
    public Drawable d() {
      b1 b1 = b1.u(b(), null, new int[] { d.a.homeAsUpIndicator });
      Drawable drawable = b1.g(0);
      b1.w();
      return drawable;
    }
    
    public void e(int param1Int) {
      a a = this.a.s();
      if (a != null)
        a.v(param1Int); 
    }
  }
  
  static interface g {
    boolean a(int param1Int);
    
    View onCreatePanelView(int param1Int);
  }
  
  private final class h implements androidx.appcompat.view.menu.m.a {
    h(AppCompatDelegateImpl this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      this.a.Y(param1g);
    }
    
    public boolean c(g param1g) {
      Window.Callback callback = this.a.u0();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1g); 
      return true;
    }
  }
  
  class i implements androidx.appcompat.view.b.a {
    private androidx.appcompat.view.b.a a;
    
    public i(AppCompatDelegateImpl this$0, androidx.appcompat.view.b.a param1a) {
      this.a = param1a;
    }
    
    public void a(androidx.appcompat.view.b param1b) {
      this.a.a(param1b);
      AppCompatDelegateImpl appCompatDelegateImpl = this.b;
      if (appCompatDelegateImpl.w != null)
        appCompatDelegateImpl.l.getDecorView().removeCallbacks(this.b.x); 
      appCompatDelegateImpl = this.b;
      if (appCompatDelegateImpl.v != null) {
        appCompatDelegateImpl.i0();
        appCompatDelegateImpl = this.b;
        appCompatDelegateImpl.y = n0.e((View)appCompatDelegateImpl.v).b(0.0F);
        this.b.y.h((u0)new a(this));
      } 
      appCompatDelegateImpl = this.b;
      e e = appCompatDelegateImpl.n;
      if (e != null)
        e.c(appCompatDelegateImpl.u); 
      appCompatDelegateImpl = this.b;
      appCompatDelegateImpl.u = null;
      n0.r0((View)appCompatDelegateImpl.B);
      this.b.c1();
    }
    
    public boolean b(androidx.appcompat.view.b param1b, Menu param1Menu) {
      return this.a.b(param1b, param1Menu);
    }
    
    public boolean c(androidx.appcompat.view.b param1b, Menu param1Menu) {
      n0.r0((View)this.b.B);
      return this.a.c(param1b, param1Menu);
    }
    
    public boolean d(androidx.appcompat.view.b param1b, MenuItem param1MenuItem) {
      return this.a.d(param1b, param1MenuItem);
    }
    
    class a extends v0 {
      a(AppCompatDelegateImpl.i this$0) {}
      
      public void b(View param2View) {
        this.a.b.v.setVisibility(8);
        AppCompatDelegateImpl appCompatDelegateImpl = this.a.b;
        PopupWindow popupWindow = appCompatDelegateImpl.w;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (appCompatDelegateImpl.v.getParent() instanceof View) {
          n0.r0((View)this.a.b.v.getParent());
        } 
        this.a.b.v.k();
        this.a.b.y.h(null);
        appCompatDelegateImpl = this.a.b;
        appCompatDelegateImpl.y = null;
        n0.r0((View)appCompatDelegateImpl.B);
      }
    }
  }
  
  class a extends v0 {
    a(AppCompatDelegateImpl this$0) {}
    
    public void b(View param1View) {
      this.a.b.v.setVisibility(8);
      AppCompatDelegateImpl appCompatDelegateImpl = this.a.b;
      PopupWindow popupWindow = appCompatDelegateImpl.w;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (appCompatDelegateImpl.v.getParent() instanceof View) {
        n0.r0((View)this.a.b.v.getParent());
      } 
      this.a.b.v.k();
      this.a.b.y.h(null);
      appCompatDelegateImpl = this.a.b;
      appCompatDelegateImpl.y = null;
      n0.r0((View)appCompatDelegateImpl.B);
    }
  }
  
  static abstract class j {
    static Context a(Context param1Context, Configuration param1Configuration) {
      return param1Context.createConfigurationContext(param1Configuration);
    }
    
    static void b(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.densityDpi;
      int k = param1Configuration2.densityDpi;
      if (i != k)
        param1Configuration3.densityDpi = k; 
    }
    
    static void c(Configuration param1Configuration, Locale param1Locale) {
      param1Configuration.setLayoutDirection(param1Locale);
    }
    
    static void d(Configuration param1Configuration, Locale param1Locale) {
      param1Configuration.setLocale(param1Locale);
    }
  }
  
  static abstract class k {
    static boolean a(PowerManager param1PowerManager) {
      return param1PowerManager.isPowerSaveMode();
    }
    
    static String b(Locale param1Locale) {
      return param1Locale.toLanguageTag();
    }
  }
  
  static abstract class l {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      LocaleList localeList1 = j.a(param1Configuration1);
      LocaleList localeList2 = j.a(param1Configuration2);
      if (!m.a(localeList1, localeList2)) {
        l.a(param1Configuration3, localeList2);
        param1Configuration3.locale = param1Configuration2.locale;
      } 
    }
    
    static androidx.core.os.j b(Configuration param1Configuration) {
      return androidx.core.os.j.c(k.a(j.a(param1Configuration)));
    }
    
    public static void c(androidx.core.os.j param1j) {
      i.a(h.a(param1j.h()));
    }
    
    static void d(Configuration param1Configuration, androidx.core.os.j param1j) {
      l.a(param1Configuration, h.a(param1j.h()));
    }
  }
  
  static abstract class m {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      if ((n.a(param1Configuration1) & 0x3) != (n.a(param1Configuration2) & 0x3))
        o.a(param1Configuration3, n.a(param1Configuration3) | n.a(param1Configuration2) & 0x3); 
      if ((n.a(param1Configuration1) & 0xC) != (n.a(param1Configuration2) & 0xC))
        o.a(param1Configuration3, n.a(param1Configuration3) | n.a(param1Configuration2) & 0xC); 
    }
  }
  
  static abstract class n {
    static OnBackInvokedDispatcher a(Activity param1Activity) {
      return p.a(param1Activity);
    }
    
    static OnBackInvokedCallback b(Object param1Object, AppCompatDelegateImpl param1AppCompatDelegateImpl) {
      Objects.requireNonNull(param1AppCompatDelegateImpl);
      u u = new u(param1AppCompatDelegateImpl);
      t.a(r.a(param1Object), 1000000, u);
      return u;
    }
    
    static void c(Object param1Object1, Object param1Object2) {
      param1Object2 = q.a(param1Object2);
      s.a(r.a(param1Object1), (OnBackInvokedCallback)param1Object2);
    }
  }
  
  class o extends androidx.appcompat.view.i {
    private AppCompatDelegateImpl.g b;
    
    private boolean c;
    
    private boolean d;
    
    private boolean e;
    
    o(AppCompatDelegateImpl this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public boolean b(Window.Callback param1Callback, KeyEvent param1KeyEvent) {
      try {
        this.d = true;
        return param1Callback.dispatchKeyEvent(param1KeyEvent);
      } finally {
        this.d = false;
      } 
    }
    
    public void c(Window.Callback param1Callback) {
      try {
        this.c = true;
        param1Callback.onContentChanged();
        return;
      } finally {
        this.c = false;
      } 
    }
    
    public void d(Window.Callback param1Callback, int param1Int, Menu param1Menu) {
      try {
        this.e = true;
        param1Callback.onPanelClosed(param1Int, param1Menu);
        return;
      } finally {
        this.e = false;
      } 
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return this.d ? a().dispatchKeyEvent(param1KeyEvent) : ((this.f.g0(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent)));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.f.F0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    void e(AppCompatDelegateImpl.g param1g) {
      this.b = param1g;
    }
    
    final ActionMode f(ActionMode.Callback param1Callback) {
      androidx.appcompat.view.f.a a = new androidx.appcompat.view.f.a(this.f.k, param1Callback);
      androidx.appcompat.view.b b = this.f.W0((androidx.appcompat.view.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public void onContentChanged() {
      if (this.c)
        a().onContentChanged(); 
    }
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof g)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public View onCreatePanelView(int param1Int) {
      AppCompatDelegateImpl.g g1 = this.b;
      if (g1 != null) {
        View view = g1.onCreatePanelView(param1Int);
        if (view != null)
          return view; 
      } 
      return super.onCreatePanelView(param1Int);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.f.I0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      if (this.e) {
        a().onPanelClosed(param1Int, param1Menu);
        return;
      } 
      super.onPanelClosed(param1Int, param1Menu);
      this.f.J0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      g g1;
      if (param1Menu instanceof g) {
        g1 = (g)param1Menu;
      } else {
        g1 = null;
      } 
      if (param1Int == 0 && g1 == null)
        return false; 
      boolean bool1 = true;
      if (g1 != null)
        g1.e0(true); 
      AppCompatDelegateImpl.g g2 = this.b;
      if (g2 == null || !g2.a(param1Int))
        bool1 = false; 
      boolean bool2 = bool1;
      if (!bool1)
        bool2 = super.onPreparePanel(param1Int, param1View, param1Menu); 
      if (g1 != null)
        g1.e0(false); 
      return bool2;
    }
    
    public void onProvideKeyboardShortcuts(List param1List, Menu param1Menu, int param1Int) {
      AppCompatDelegateImpl.PanelFeatureState panelFeatureState = this.f.s0(0, true);
      if (panelFeatureState != null) {
        g g1 = panelFeatureState.j;
        if (g1 != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)g1, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return (Build.VERSION.SDK_INT >= 23) ? null : (this.f.A0() ? f(param1Callback) : super.onWindowStartingActionMode(param1Callback));
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.f.A0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : f(param1Callback);
    }
  }
  
  private class p extends q {
    private final PowerManager c;
    
    p(AppCompatDelegateImpl this$0, Context param1Context) {
      super(this$0);
      this.c = (PowerManager)param1Context.getApplicationContext().getSystemService("power");
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
      return intentFilter;
    }
    
    public int c() {
      return AppCompatDelegateImpl.k.a(this.c) ? 2 : 1;
    }
    
    public void d() {
      this.d.S();
    }
  }
  
  abstract class q {
    private BroadcastReceiver a;
    
    q(AppCompatDelegateImpl this$0) {}
    
    void a() {
      BroadcastReceiver broadcastReceiver = this.a;
      if (broadcastReceiver != null) {
        try {
          this.b.k.unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException illegalArgumentException) {}
        this.a = null;
      } 
    }
    
    abstract IntentFilter b();
    
    abstract int c();
    
    abstract void d();
    
    void e() {
      a();
      IntentFilter intentFilter = b();
      if (intentFilter != null) {
        if (intentFilter.countActions() == 0)
          return; 
        if (this.a == null)
          this.a = new a(this); 
        this.b.k.registerReceiver(this.a, intentFilter);
      } 
    }
    
    class a extends BroadcastReceiver {
      a(AppCompatDelegateImpl.q this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.d();
      }
    }
  }
  
  class a extends BroadcastReceiver {
    a(AppCompatDelegateImpl this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.d();
    }
  }
  
  private class r extends q {
    private final i0 c;
    
    r(AppCompatDelegateImpl this$0, i0 param1i0) {
      super(this$0);
      this.c = param1i0;
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.TIME_SET");
      intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
      intentFilter.addAction("android.intent.action.TIME_TICK");
      return intentFilter;
    }
    
    public int c() {
      return this.c.d() ? 2 : 1;
    }
    
    public void d() {
      this.d.S();
    }
  }
  
  private static abstract class s {
    static void a(ContextThemeWrapper param1ContextThemeWrapper, Configuration param1Configuration) {
      param1ContextThemeWrapper.applyOverrideConfiguration(param1Configuration);
    }
  }
  
  private class t extends ContentFrameLayout {
    public t(AppCompatDelegateImpl this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean b(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.i.g0(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && b((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.i.a0(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(e.a.b(getContext(), param1Int));
    }
  }
  
  private final class u implements androidx.appcompat.view.menu.m.a {
    u(AppCompatDelegateImpl this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      boolean bool;
      g g1 = param1g.F();
      if (g1 != param1g) {
        bool = true;
      } else {
        bool = false;
      } 
      AppCompatDelegateImpl appCompatDelegateImpl = this.a;
      if (bool)
        param1g = g1; 
      AppCompatDelegateImpl.PanelFeatureState panelFeatureState = appCompatDelegateImpl.l0((Menu)param1g);
      if (panelFeatureState != null) {
        if (bool) {
          this.a.X(panelFeatureState.a, panelFeatureState, (Menu)g1);
          this.a.b0(panelFeatureState, true);
          return;
        } 
        this.a.b0(panelFeatureState, param1Boolean);
      } 
    }
    
    public boolean c(g param1g) {
      if (param1g == param1g.F()) {
        AppCompatDelegateImpl appCompatDelegateImpl = this.a;
        if (appCompatDelegateImpl.G) {
          Window.Callback callback = appCompatDelegateImpl.u0();
          if (callback != null && !this.a.R)
            callback.onMenuOpened(108, (Menu)param1g); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\AppCompatDelegateImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */