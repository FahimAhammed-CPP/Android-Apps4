package androidx.appcompat.app;

import androidx.core.os.j;
import java.util.LinkedHashSet;
import java.util.Locale;

abstract class d0 {
  private static j a(j paramj1, j paramj2) {
    LinkedHashSet<Locale> linkedHashSet = new LinkedHashSet();
    for (int i = 0; i < paramj1.g() + paramj2.g(); i++) {
      Locale locale;
      if (i < paramj1.g()) {
        locale = paramj1.d(i);
      } else {
        locale = paramj2.d(i - paramj1.g());
      } 
      if (locale != null)
        linkedHashSet.add(locale); 
    } 
    return j.a(linkedHashSet.<Locale>toArray(new Locale[linkedHashSet.size()]));
  }
  
  static j b(j paramj1, j paramj2) {
    return (paramj1 == null || paramj1.f()) ? j.e() : a(paramj1, paramj2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */