package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.view.g;
import androidx.appcompat.view.h;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.e0;
import androidx.core.view.n0;
import androidx.core.view.t0;
import androidx.core.view.u0;
import androidx.core.view.v0;
import androidx.core.view.w0;
import d.f;
import d.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class j0 extends a implements ActionBarOverlayLayout.d {
  private static final Interpolator D = (Interpolator)new AccelerateInterpolator();
  
  private static final Interpolator E = (Interpolator)new DecelerateInterpolator();
  
  final u0 A = (u0)new a(this);
  
  final u0 B = (u0)new b(this);
  
  final w0 C = new c(this);
  
  Context a;
  
  private Context b;
  
  private Activity c;
  
  ActionBarOverlayLayout d;
  
  ActionBarContainer e;
  
  e0 f;
  
  ActionBarContextView g;
  
  View h;
  
  private ArrayList i = new ArrayList();
  
  private int j = -1;
  
  private boolean k;
  
  d l;
  
  androidx.appcompat.view.b m;
  
  androidx.appcompat.view.b.a n;
  
  private boolean o;
  
  private ArrayList p = new ArrayList();
  
  private boolean q;
  
  private int r = 0;
  
  boolean s = true;
  
  boolean t;
  
  boolean u;
  
  private boolean v;
  
  private boolean w = true;
  
  h x;
  
  private boolean y;
  
  boolean z;
  
  public j0(Activity paramActivity, boolean paramBoolean) {
    this.c = paramActivity;
    View view = paramActivity.getWindow().getDecorView();
    K(view);
    if (!paramBoolean)
      this.h = view.findViewById(16908290); 
  }
  
  public j0(Dialog paramDialog) {
    K(paramDialog.getWindow().getDecorView());
  }
  
  static boolean D(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  private e0 H(View paramView) {
    String str;
    if (paramView instanceof e0)
      return (e0)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    if (paramView != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    stringBuilder.append(str);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void J() {
    if (this.v) {
      this.v = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      R(false);
    } 
  }
  
  private void K(View paramView) {
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(f.decor_content_parent);
    this.d = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    this.f = H(paramView.findViewById(f.action_bar));
    this.g = (ActionBarContextView)paramView.findViewById(f.action_context_bar);
    ActionBarContainer actionBarContainer = (ActionBarContainer)paramView.findViewById(f.action_bar_container);
    this.e = actionBarContainer;
    e0 e01 = this.f;
    if (e01 != null && this.g != null && actionBarContainer != null) {
      boolean bool;
      this.a = e01.getContext();
      if ((this.f.s() & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.k = true; 
      androidx.appcompat.view.a a1 = androidx.appcompat.view.a.b(this.a);
      if (a1.a() || i) {
        bool = true;
      } else {
        bool = false;
      } 
      O(bool);
      M(a1.e());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, j.ActionBar, d.a.actionBarStyle, 0);
      if (typedArray.getBoolean(j.ActionBar_hideOnContentScroll, false))
        N(true); 
      int i = typedArray.getDimensionPixelSize(j.ActionBar_elevation, 0);
      if (i != 0)
        u(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void M(boolean paramBoolean) {
    this.q = paramBoolean;
    if (!paramBoolean) {
      this.f.i(null);
      this.e.setTabContainer(null);
    } else {
      this.e.setTabContainer(null);
      this.f.i(null);
    } 
    int i = I();
    boolean bool = true;
    if (i == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    e0 e01 = this.f;
    if (!this.q && i != 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    e01.x(paramBoolean);
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (!this.q && i != 0) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(paramBoolean);
  }
  
  private boolean P() {
    return n0.Y((View)this.e);
  }
  
  private void Q() {
    if (!this.v) {
      this.v = true;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(true); 
      R(false);
    } 
  }
  
  private void R(boolean paramBoolean) {
    if (D(this.t, this.u, this.v)) {
      if (!this.w) {
        this.w = true;
        G(paramBoolean);
        return;
      } 
    } else if (this.w) {
      this.w = false;
      F(paramBoolean);
    } 
  }
  
  public void A(CharSequence paramCharSequence) {
    this.f.setWindowTitle(paramCharSequence);
  }
  
  public androidx.appcompat.view.b B(androidx.appcompat.view.b.a parama) {
    d d2 = this.l;
    if (d2 != null)
      d2.c(); 
    this.d.setHideOnContentScrollEnabled(false);
    this.g.k();
    d d1 = new d(this, this.g.getContext(), parama);
    if (d1.t()) {
      this.l = d1;
      d1.k();
      this.g.h(d1);
      C(true);
      return d1;
    } 
    return null;
  }
  
  public void C(boolean paramBoolean) {
    if (paramBoolean) {
      Q();
    } else {
      J();
    } 
    if (P()) {
      t0 t01;
      t0 t02;
      if (paramBoolean) {
        t02 = this.f.o(4, 100L);
        t01 = this.g.f(0, 200L);
      } else {
        t01 = this.f.o(0, 200L);
        t02 = this.g.f(8, 100L);
      } 
      h h1 = new h();
      h1.d(t02, t01);
      h1.h();
      return;
    } 
    if (paramBoolean) {
      this.f.setVisibility(4);
      this.g.setVisibility(0);
      return;
    } 
    this.f.setVisibility(0);
    this.g.setVisibility(8);
  }
  
  void E() {
    androidx.appcompat.view.b.a a1 = this.n;
    if (a1 != null) {
      a1.a(this.m);
      this.m = null;
      this.n = null;
    } 
  }
  
  public void F(boolean paramBoolean) {
    h h1 = this.x;
    if (h1 != null)
      h1.a(); 
    if (this.r == 0 && (this.y || paramBoolean)) {
      this.e.setAlpha(1.0F);
      this.e.setTransitioning(true);
      h1 = new h();
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      t0 t0 = n0.e((View)this.e).m(f1);
      t0.k(this.C);
      h1.c(t0);
      if (this.s) {
        View view = this.h;
        if (view != null)
          h1.c(n0.e(view).m(f1)); 
      } 
      h1.f(D);
      h1.e(250L);
      h1.g(this.A);
      this.x = h1;
      h1.h();
      return;
    } 
    this.A.b(null);
  }
  
  public void G(boolean paramBoolean) {
    h h1 = this.x;
    if (h1 != null)
      h1.a(); 
    this.e.setVisibility(0);
    if (this.r == 0 && (this.y || paramBoolean)) {
      this.e.setTranslationY(0.0F);
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      this.e.setTranslationY(f1);
      h1 = new h();
      t0 t0 = n0.e((View)this.e).m(0.0F);
      t0.k(this.C);
      h1.c(t0);
      if (this.s) {
        View view = this.h;
        if (view != null) {
          view.setTranslationY(f1);
          h1.c(n0.e(this.h).m(0.0F));
        } 
      } 
      h1.f(E);
      h1.e(250L);
      h1.g(this.B);
      this.x = h1;
      h1.h();
    } else {
      this.e.setAlpha(1.0F);
      this.e.setTranslationY(0.0F);
      if (this.s) {
        View view = this.h;
        if (view != null)
          view.setTranslationY(0.0F); 
      } 
      this.B.b(null);
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (actionBarOverlayLayout != null)
      n0.r0((View)actionBarOverlayLayout); 
  }
  
  public int I() {
    return this.f.n();
  }
  
  public void L(int paramInt1, int paramInt2) {
    int i = this.f.s();
    if ((paramInt2 & 0x4) != 0)
      this.k = true; 
    this.f.k(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  public void N(boolean paramBoolean) {
    if (!paramBoolean || this.d.w()) {
      this.z = paramBoolean;
      this.d.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void O(boolean paramBoolean) {
    this.f.r(paramBoolean);
  }
  
  public void a() {
    if (this.u) {
      this.u = false;
      R(true);
    } 
  }
  
  public void b() {}
  
  public void c(boolean paramBoolean) {
    this.s = paramBoolean;
  }
  
  public void d() {
    if (!this.u) {
      this.u = true;
      R(true);
    } 
  }
  
  public void e() {
    h h1 = this.x;
    if (h1 != null) {
      h1.a();
      this.x = null;
    } 
  }
  
  public boolean g() {
    e0 e01 = this.f;
    if (e01 != null && e01.j()) {
      this.f.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void h(boolean paramBoolean) {
    if (paramBoolean == this.o)
      return; 
    this.o = paramBoolean;
    if (this.p.size() <= 0)
      return; 
    f0.a(this.p.get(0));
    throw null;
  }
  
  public int i() {
    return this.f.s();
  }
  
  public Context j() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(d.a.actionBarWidgetTheme, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void l(Configuration paramConfiguration) {
    M(androidx.appcompat.view.a.b(this.a).e());
  }
  
  public boolean n(int paramInt, KeyEvent paramKeyEvent) {
    d d1 = this.l;
    if (d1 == null)
      return false; 
    Menu menu = d1.e();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    this.r = paramInt;
  }
  
  public void q(boolean paramBoolean) {
    if (!this.k)
      r(paramBoolean); 
  }
  
  public void r(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    L(bool, 4);
  }
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    L(bool, 2);
  }
  
  public void t(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    L(bool, 8);
  }
  
  public void u(float paramFloat) {
    n0.C0((View)this.e, paramFloat);
  }
  
  public void v(int paramInt) {
    this.f.t(paramInt);
  }
  
  public void w(Drawable paramDrawable) {
    this.f.w(paramDrawable);
  }
  
  public void x(boolean paramBoolean) {
    this.y = paramBoolean;
    if (!paramBoolean) {
      h h1 = this.x;
      if (h1 != null)
        h1.a(); 
    } 
  }
  
  public void y(int paramInt) {
    z(this.a.getString(paramInt));
  }
  
  public void z(CharSequence paramCharSequence) {
    this.f.setTitle(paramCharSequence);
  }
  
  class a extends v0 {
    a(j0 this$0) {}
    
    public void b(View param1View) {
      j0 j01 = this.a;
      if (j01.s) {
        View view = j01.h;
        if (view != null) {
          view.setTranslationY(0.0F);
          this.a.e.setTranslationY(0.0F);
        } 
      } 
      this.a.e.setVisibility(8);
      this.a.e.setTransitioning(false);
      j01 = this.a;
      j01.x = null;
      j01.E();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a.d;
      if (actionBarOverlayLayout != null)
        n0.r0((View)actionBarOverlayLayout); 
    }
  }
  
  class b extends v0 {
    b(j0 this$0) {}
    
    public void b(View param1View) {
      j0 j01 = this.a;
      j01.x = null;
      j01.e.requestLayout();
    }
  }
  
  class c implements w0 {
    c(j0 this$0) {}
    
    public void a(View param1View) {
      ((View)this.a.e.getParent()).invalidate();
    }
  }
  
  public class d extends androidx.appcompat.view.b implements g.a {
    private final Context c;
    
    private final g d;
    
    private androidx.appcompat.view.b.a e;
    
    private WeakReference f;
    
    public d(j0 this$0, Context param1Context, androidx.appcompat.view.b.a param1a) {
      this.c = param1Context;
      this.e = param1a;
      g g1 = (new g(param1Context)).W(1);
      this.d = g1;
      g1.V(this);
    }
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      androidx.appcompat.view.b.a a1 = this.e;
      return (a1 != null) ? a1.d(this, param1MenuItem) : false;
    }
    
    public void b(g param1g) {
      if (this.e == null)
        return; 
      k();
      this.g.g.l();
    }
    
    public void c() {
      j0 j01 = this.g;
      if (j01.l != this)
        return; 
      if (!j0.D(j01.t, j01.u, false)) {
        j01 = this.g;
        j01.m = this;
        j01.n = this.e;
      } else {
        this.e.a(this);
      } 
      this.e = null;
      this.g.C(false);
      this.g.g.g();
      j01 = this.g;
      j01.d.setHideOnContentScrollEnabled(j01.z);
      this.g.l = null;
    }
    
    public View d() {
      WeakReference<View> weakReference = this.f;
      return (weakReference != null) ? weakReference.get() : null;
    }
    
    public Menu e() {
      return (Menu)this.d;
    }
    
    public MenuInflater f() {
      return (MenuInflater)new g(this.c);
    }
    
    public CharSequence g() {
      return this.g.g.getSubtitle();
    }
    
    public CharSequence i() {
      return this.g.g.getTitle();
    }
    
    public void k() {
      if (this.g.l != this)
        return; 
      this.d.h0();
      try {
        this.e.c(this, (Menu)this.d);
        return;
      } finally {
        this.d.g0();
      } 
    }
    
    public boolean l() {
      return this.g.g.j();
    }
    
    public void m(View param1View) {
      this.g.g.setCustomView(param1View);
      this.f = new WeakReference<View>(param1View);
    }
    
    public void n(int param1Int) {
      o(this.g.a.getResources().getString(param1Int));
    }
    
    public void o(CharSequence param1CharSequence) {
      this.g.g.setSubtitle(param1CharSequence);
    }
    
    public void q(int param1Int) {
      r(this.g.a.getResources().getString(param1Int));
    }
    
    public void r(CharSequence param1CharSequence) {
      this.g.g.setTitle(param1CharSequence);
    }
    
    public void s(boolean param1Boolean) {
      super.s(param1Boolean);
      this.g.g.setTitleOptional(param1Boolean);
    }
    
    public boolean t() {
      this.d.h0();
      try {
        return this.e.b(this, (Menu)this.d);
      } finally {
        this.d.g0();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */