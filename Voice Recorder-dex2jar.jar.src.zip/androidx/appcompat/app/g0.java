package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.e0;
import androidx.appcompat.widget.f1;
import androidx.core.util.h;
import androidx.core.view.n0;
import java.util.ArrayList;

class g0 extends a {
  final e0 a;
  
  final Window.Callback b;
  
  final AppCompatDelegateImpl.g c;
  
  boolean d;
  
  private boolean e;
  
  private boolean f;
  
  private ArrayList g = new ArrayList();
  
  private final Runnable h = new a(this);
  
  private final Toolbar.h i;
  
  g0(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback) {
    b b = new b(this);
    this.i = b;
    h.g(paramToolbar);
    f1 f1 = new f1(paramToolbar, false);
    this.a = (e0)f1;
    this.b = (Window.Callback)h.g(paramCallback);
    f1.setWindowCallback(paramCallback);
    paramToolbar.setOnMenuItemClickListener(b);
    f1.setWindowTitle(paramCharSequence);
    this.c = new e(this);
  }
  
  private Menu C() {
    if (!this.e) {
      this.a.p(new c(this), new d(this));
      this.e = true;
    } 
    return this.a.l();
  }
  
  public void A(CharSequence paramCharSequence) {
    this.a.setWindowTitle(paramCharSequence);
  }
  
  void D() {
    g g1;
    null = C();
    if (null instanceof g) {
      g1 = (g)null;
    } else {
      g1 = null;
    } 
    if (g1 != null)
      g1.h0(); 
    try {
      null.clear();
      if (!this.b.onCreatePanelMenu(0, null) || !this.b.onPreparePanel(0, null, null))
        null.clear(); 
      return;
    } finally {
      if (g1 != null)
        g1.g0(); 
    } 
  }
  
  public void E(int paramInt1, int paramInt2) {
    int i = this.a.s();
    this.a.k(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  public boolean f() {
    return this.a.f();
  }
  
  public boolean g() {
    if (this.a.j()) {
      this.a.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void h(boolean paramBoolean) {
    if (paramBoolean == this.f)
      return; 
    this.f = paramBoolean;
    if (this.g.size() <= 0)
      return; 
    f0.a(this.g.get(0));
    throw null;
  }
  
  public int i() {
    return this.a.s();
  }
  
  public Context j() {
    return this.a.getContext();
  }
  
  public boolean k() {
    this.a.q().removeCallbacks(this.h);
    n0.m0((View)this.a.q(), this.h);
    return true;
  }
  
  public void l(Configuration paramConfiguration) {
    super.l(paramConfiguration);
  }
  
  void m() {
    this.a.q().removeCallbacks(this.h);
  }
  
  public boolean n(int paramInt, KeyEvent paramKeyEvent) {
    Menu menu = C();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public boolean o(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1)
      p(); 
    return true;
  }
  
  public boolean p() {
    return this.a.g();
  }
  
  public void q(boolean paramBoolean) {}
  
  public void r(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    E(bool, 4);
  }
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    E(bool, 2);
  }
  
  public void t(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    E(bool, 8);
  }
  
  public void u(float paramFloat) {
    n0.C0((View)this.a.q(), paramFloat);
  }
  
  public void v(int paramInt) {
    this.a.t(paramInt);
  }
  
  public void w(Drawable paramDrawable) {
    this.a.w(paramDrawable);
  }
  
  public void x(boolean paramBoolean) {}
  
  public void y(int paramInt) {
    CharSequence charSequence;
    e0 e01 = this.a;
    if (paramInt != 0) {
      charSequence = e01.getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    e01.setTitle(charSequence);
  }
  
  public void z(CharSequence paramCharSequence) {
    this.a.setTitle(paramCharSequence);
  }
  
  class a implements Runnable {
    a(g0 this$0) {}
    
    public void run() {
      this.a.D();
    }
  }
  
  class b implements Toolbar.h {
    b(g0 this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      return this.a.b.onMenuItemSelected(0, param1MenuItem);
    }
  }
  
  private final class c implements m.a {
    private boolean a;
    
    c(g0 this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      if (this.a)
        return; 
      this.a = true;
      this.b.a.h();
      this.b.b.onPanelClosed(108, (Menu)param1g);
      this.a = false;
    }
    
    public boolean c(g param1g) {
      this.b.b.onMenuOpened(108, (Menu)param1g);
      return true;
    }
  }
  
  private final class d implements g.a {
    d(g0 this$0) {}
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      return false;
    }
    
    public void b(g param1g) {
      if (this.a.a.b()) {
        this.a.b.onPanelClosed(108, (Menu)param1g);
        return;
      } 
      if (this.a.b.onPreparePanel(0, null, (Menu)param1g))
        this.a.b.onMenuOpened(108, (Menu)param1g); 
    }
  }
  
  private class e implements AppCompatDelegateImpl.g {
    e(g0 this$0) {}
    
    public boolean a(int param1Int) {
      if (param1Int == 0) {
        g0 g01 = this.a;
        if (!g01.d) {
          g01.a.c();
          this.a.d = true;
        } 
      } 
      return false;
    }
    
    public View onCreatePanelView(int param1Int) {
      return (param1Int == 0) ? new View(this.a.a.getContext()) : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */