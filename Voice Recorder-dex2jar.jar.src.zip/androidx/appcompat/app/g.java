package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.LocaleManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.LocaleList;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.Toolbar;
import androidx.core.os.j;
import java.lang.ref.WeakReference;
import java.util.Iterator;

public abstract class g {
  static b0.a a = new b0.a(new b0.b());
  
  private static int b = -100;
  
  private static j c = null;
  
  private static j d = null;
  
  private static Boolean e = null;
  
  private static boolean f = false;
  
  private static final androidx.collection.b g = new androidx.collection.b();
  
  private static final Object h = new Object();
  
  private static final Object i = new Object();
  
  static void F(g paramg) {
    synchronized (h) {
      G(paramg);
      return;
    } 
  }
  
  private static void G(g paramg) {
    synchronized (h) {
      Iterator<WeakReference<g>> iterator = g.iterator();
      while (iterator.hasNext()) {
        g g1 = ((WeakReference<g>)iterator.next()).get();
        if (g1 == paramg || g1 == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  static void P(Context paramContext) {
    if (!v(paramContext))
      return; 
    if (androidx.core.os.a.c()) {
      if (!f) {
        a.execute(new f(paramContext));
        return;
      } 
    } else {
      synchronized (i) {
        j j1 = c;
        if (j1 == null) {
          if (d == null)
            d = j.c(b0.b(paramContext)); 
          if (d.f())
            return; 
          c = d;
        } else if (!j1.equals(d)) {
          j1 = c;
          d = j1;
          b0.a(paramContext, j1.h());
        } 
        return;
      } 
    } 
  }
  
  static void d(g paramg) {
    synchronized (h) {
      G(paramg);
      g.add(new WeakReference<g>(paramg));
      return;
    } 
  }
  
  public static g h(Activity paramActivity, e parame) {
    return new AppCompatDelegateImpl(paramActivity, parame);
  }
  
  public static g i(Dialog paramDialog, e parame) {
    return new AppCompatDelegateImpl(paramDialog, parame);
  }
  
  public static j k() {
    if (androidx.core.os.a.c()) {
      Object object = p();
      if (object != null)
        return j.i(b.a(object)); 
    } else {
      j j1 = c;
      if (j1 != null)
        return j1; 
    } 
    return j.e();
  }
  
  public static int m() {
    return b;
  }
  
  static Object p() {
    Iterator<WeakReference<g>> iterator = g.iterator();
    while (iterator.hasNext()) {
      g g1 = ((WeakReference<g>)iterator.next()).get();
      if (g1 != null) {
        Context context = g1.l();
        if (context != null)
          return context.getSystemService("locale"); 
      } 
    } 
    return null;
  }
  
  static j r() {
    return c;
  }
  
  static boolean v(Context paramContext) {
    if (e == null)
      try {
        Bundle bundle = (z.a(paramContext)).metaData;
        if (bundle != null)
          e = Boolean.valueOf(bundle.getBoolean("autoStoreLocales")); 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Checking for metadata for AppLocalesMetadataHolderService : Service not found");
        e = Boolean.FALSE;
      }  
    return e.booleanValue();
  }
  
  public abstract void A(Bundle paramBundle);
  
  public abstract void B();
  
  public abstract void C(Bundle paramBundle);
  
  public abstract void D();
  
  public abstract void E();
  
  public abstract boolean H(int paramInt);
  
  public abstract void I(int paramInt);
  
  public abstract void J(View paramView);
  
  public abstract void K(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public void L(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {}
  
  public abstract void M(Toolbar paramToolbar);
  
  public abstract void N(int paramInt);
  
  public abstract void O(CharSequence paramCharSequence);
  
  public abstract void e(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public void f(Context paramContext) {}
  
  public Context g(Context paramContext) {
    f(paramContext);
    return paramContext;
  }
  
  public abstract View j(int paramInt);
  
  public abstract Context l();
  
  public abstract b.b n();
  
  public abstract int o();
  
  public abstract MenuInflater q();
  
  public abstract a s();
  
  public abstract void t();
  
  public abstract void u();
  
  public abstract void x(Configuration paramConfiguration);
  
  public abstract void y(Bundle paramBundle);
  
  public abstract void z();
  
  static abstract class a {
    static LocaleList a(String param1String) {
      return LocaleList.forLanguageTags(param1String);
    }
  }
  
  static abstract class b {
    static LocaleList a(Object param1Object) {
      return ((LocaleManager)param1Object).getApplicationLocales();
    }
    
    static void b(Object param1Object, LocaleList param1LocaleList) {
      ((LocaleManager)param1Object).setApplicationLocales(param1LocaleList);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */