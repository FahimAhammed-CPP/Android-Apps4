package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.o;
import androidx.activity.r;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.l1;
import androidx.core.app.i;
import androidx.core.app.s0;
import androidx.core.os.j;
import androidx.fragment.app.q;
import androidx.lifecycle.n;
import androidx.lifecycle.n0;
import androidx.lifecycle.o0;
import androidx.lifecycle.p0;
import c1.e;

public abstract class d extends q implements e, s0.a, b.c {
  private g a;
  
  private Resources b;
  
  public d() {
    M();
  }
  
  private void M() {
    getSavedStateRegistry().h("androidx:appcompat", new a(this));
    addOnContextAvailableListener(new b(this));
  }
  
  private boolean T(KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  private void v() {
    o0.a(getWindow().getDecorView(), (n)this);
    p0.a(getWindow().getDecorView(), (n0)this);
    e.a(getWindow().getDecorView(), (c1.d)this);
    r.a(getWindow().getDecorView(), (o)this);
  }
  
  public g K() {
    if (this.a == null)
      this.a = g.h((Activity)this, this); 
    return this.a;
  }
  
  public a L() {
    return K().s();
  }
  
  public void N(s0 params0) {
    params0.d((Activity)this);
  }
  
  protected void O(j paramj) {}
  
  protected void P(int paramInt) {}
  
  public void Q(s0 params0) {}
  
  public void R() {}
  
  public boolean S() {
    Intent intent = f();
    if (intent != null) {
      if (W(intent)) {
        s0 s0 = s0.f((Context)this);
        N(s0);
        Q(s0);
        s0.g();
        try {
          androidx.core.app.b.b((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        V((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  public void U(Toolbar paramToolbar) {
    K().M(paramToolbar);
  }
  
  public void V(Intent paramIntent) {
    i.e((Activity)this, paramIntent);
  }
  
  public boolean W(Intent paramIntent) {
    return i.f((Activity)this, paramIntent);
  }
  
  public void a(androidx.appcompat.view.b paramb) {}
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    v();
    K().e(paramView, paramLayoutParams);
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(K().g(paramContext));
  }
  
  public b.b b() {
    return K().n();
  }
  
  public void c(androidx.appcompat.view.b paramb) {}
  
  public void closeOptionsMenu() {
    a a1 = L();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.f()))
      super.closeOptionsMenu(); 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a1 = L();
    return (i == 82 && a1 != null && a1.o(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public Intent f() {
    return i.a((Activity)this);
  }
  
  public View findViewById(int paramInt) {
    return K().j(paramInt);
  }
  
  public MenuInflater getMenuInflater() {
    return K().q();
  }
  
  public Resources getResources() {
    if (this.b == null && l1.c())
      this.b = (Resources)new l1((Context)this, super.getResources()); 
    Resources resources2 = this.b;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public androidx.appcompat.view.b i(androidx.appcompat.view.b.a parama) {
    return null;
  }
  
  public void invalidateOptionsMenu() {
    K().u();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    K().x(paramConfiguration);
    if (this.b != null) {
      paramConfiguration = super.getResources().getConfiguration();
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.b.updateConfiguration(paramConfiguration, displayMetrics);
    } 
  }
  
  public void onContentChanged() {
    R();
  }
  
  protected void onDestroy() {
    super.onDestroy();
    K().z();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return T(paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a1 = L();
    return (paramMenuItem.getItemId() == 16908332 && a1 != null && (a1.i() & 0x4) != 0) ? S() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    K().A(paramBundle);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    K().B();
  }
  
  protected void onStart() {
    super.onStart();
    K().D();
  }
  
  protected void onStop() {
    super.onStop();
    K().E();
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    K().O(paramCharSequence);
  }
  
  public void openOptionsMenu() {
    a a1 = L();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.p()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    v();
    K().I(paramInt);
  }
  
  public void setContentView(View paramView) {
    v();
    K().J(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    v();
    K().K(paramView, paramLayoutParams);
  }
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    K().N(paramInt);
  }
  
  public void supportInvalidateOptionsMenu() {
    K().u();
  }
  
  class a implements androidx.savedstate.a.c {
    a(d this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.K().C(bundle);
      return bundle;
    }
  }
  
  class b implements b.b {
    b(d this$0) {}
    
    public void a(Context param1Context) {
      g g = this.a.K();
      g.t();
      g.y(this.a.getSavedStateRegistry().b("androidx:appcompat"));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */