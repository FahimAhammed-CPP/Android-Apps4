package androidx.appcompat.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.i;
import androidx.appcompat.view.b;
import androidx.core.view.q;
import d.a;

public class w extends i implements e {
  private g d;
  
  private final q.a e = new v(this);
  
  public w(Context paramContext, int paramInt) {
    super(paramContext, h(paramContext, paramInt));
    g g1 = g();
    g1.N(h(paramContext, paramInt));
    g1.y(null);
  }
  
  private static int h(Context paramContext, int paramInt) {
    int j = paramInt;
    if (paramInt == 0) {
      TypedValue typedValue = new TypedValue();
      paramContext.getTheme().resolveAttribute(a.dialogTheme, typedValue, true);
      j = typedValue.resourceId;
    } 
    return j;
  }
  
  public void a(b paramb) {}
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    g().e(paramView, paramLayoutParams);
  }
  
  public void c(b paramb) {}
  
  public void dismiss() {
    super.dismiss();
    g().z();
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return q.e(this.e, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public View findViewById(int paramInt) {
    return g().j(paramInt);
  }
  
  public g g() {
    if (this.d == null)
      this.d = g.i((Dialog)this, this); 
    return this.d;
  }
  
  public b i(b.a parama) {
    return null;
  }
  
  public void invalidateOptionsMenu() {
    g().u();
  }
  
  boolean j(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean k(int paramInt) {
    return g().H(paramInt);
  }
  
  protected void onCreate(Bundle paramBundle) {
    g().t();
    super.onCreate(paramBundle);
    g().y(paramBundle);
  }
  
  protected void onStop() {
    super.onStop();
    g().E();
  }
  
  public void setContentView(int paramInt) {
    g().I(paramInt);
  }
  
  public void setContentView(View paramView) {
    g().J(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    g().K(paramView, paramLayoutParams);
  }
  
  public void setTitle(int paramInt) {
    super.setTitle(paramInt);
    g().O(getContext().getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    g().O(paramCharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */