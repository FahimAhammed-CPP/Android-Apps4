package androidx.appcompat.app;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ServiceInfo;
import android.os.Build;

public abstract class z extends Service {
  public static ServiceInfo a(Context paramContext) {
    char c;
    if (Build.VERSION.SDK_INT >= 24) {
      c = a.a() | 0x80;
    } else {
      c = 'ʀ';
    } 
    return paramContext.getPackageManager().getServiceInfo(new ComponentName(paramContext, z.class), c);
  }
  
  private static abstract class a {
    static int a() {
      return 512;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */