package androidx.appcompat.app;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

public abstract class b implements DrawerLayout.e {
  private final b a;
  
  private final DrawerLayout b;
  
  private f.d c;
  
  private boolean d = true;
  
  private Drawable e;
  
  boolean f = true;
  
  private final int g;
  
  private final int h;
  
  View.OnClickListener i;
  
  private boolean j = false;
  
  b(Activity paramActivity, Toolbar paramToolbar, DrawerLayout paramDrawerLayout, f.d paramd, int paramInt1, int paramInt2) {
    if (paramToolbar != null) {
      this.a = new e(paramToolbar);
      paramToolbar.setNavigationOnClickListener(new a(this));
    } else if (paramActivity instanceof c) {
      this.a = ((c)paramActivity).b();
    } else {
      this.a = new d(paramActivity);
    } 
    this.b = paramDrawerLayout;
    this.g = paramInt1;
    this.h = paramInt2;
    if (paramd == null) {
      this.c = new f.d(this.a.b());
    } else {
      this.c = paramd;
    } 
    this.e = e();
  }
  
  public b(Activity paramActivity, DrawerLayout paramDrawerLayout, int paramInt1, int paramInt2) {
    this(paramActivity, null, paramDrawerLayout, null, paramInt1, paramInt2);
  }
  
  private void j(float paramFloat) {
    if (paramFloat == 1.0F) {
      this.c.g(true);
    } else if (paramFloat == 0.0F) {
      this.c.g(false);
    } 
    this.c.e(paramFloat);
  }
  
  public void a(View paramView) {
    j(1.0F);
    if (this.f)
      g(this.h); 
  }
  
  public void b(View paramView) {
    j(0.0F);
    if (this.f)
      g(this.g); 
  }
  
  public void d(View paramView, float paramFloat) {
    if (this.d) {
      j(Math.min(1.0F, Math.max(0.0F, paramFloat)));
      return;
    } 
    j(0.0F);
  }
  
  Drawable e() {
    return this.a.d();
  }
  
  public boolean f(MenuItem paramMenuItem) {
    if (paramMenuItem != null && paramMenuItem.getItemId() == 16908332 && this.f) {
      l();
      return true;
    } 
    return false;
  }
  
  void g(int paramInt) {
    this.a.e(paramInt);
  }
  
  void h(Drawable paramDrawable, int paramInt) {
    if (!this.j && !this.a.a()) {
      Log.w("ActionBarDrawerToggle", "DrawerToggle may not show up because NavigationIcon is not visible. You may need to call actionbar.setDisplayHomeAsUpEnabled(true);");
      this.j = true;
    } 
    this.a.c(paramDrawable, paramInt);
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean != this.f) {
      if (paramBoolean) {
        int i;
        f.d d1 = this.c;
        if (this.b.D(8388611)) {
          i = this.h;
        } else {
          i = this.g;
        } 
        h((Drawable)d1, i);
      } else {
        h(this.e, 0);
      } 
      this.f = paramBoolean;
    } 
  }
  
  public void k() {
    if (this.b.D(8388611)) {
      j(1.0F);
    } else {
      j(0.0F);
    } 
    if (this.f) {
      int i;
      f.d d1 = this.c;
      if (this.b.D(8388611)) {
        i = this.h;
      } else {
        i = this.g;
      } 
      h((Drawable)d1, i);
    } 
  }
  
  void l() {
    int i = this.b.r(8388611);
    if (this.b.G(8388611) && i != 2) {
      this.b.e(8388611);
      return;
    } 
    if (i != 1)
      this.b.M(8388611); 
  }
  
  class a implements View.OnClickListener {
    a(b this$0) {}
    
    public void onClick(View param1View) {
      b b1 = this.a;
      if (b1.f) {
        b1.l();
        return;
      } 
      View.OnClickListener onClickListener = b1.i;
      if (onClickListener != null)
        onClickListener.onClick(param1View); 
    }
  }
  
  public static interface b {
    boolean a();
    
    Context b();
    
    void c(Drawable param1Drawable, int param1Int);
    
    Drawable d();
    
    void e(int param1Int);
  }
  
  public static interface c {
    b.b b();
  }
  
  private static class d implements b {
    private final Activity a;
    
    d(Activity param1Activity) {
      this.a = param1Activity;
    }
    
    public boolean a() {
      ActionBar actionBar = this.a.getActionBar();
      return (actionBar != null && (actionBar.getDisplayOptions() & 0x4) != 0);
    }
    
    public Context b() {
      ActionBar actionBar = this.a.getActionBar();
      return (Context)((actionBar != null) ? actionBar.getThemedContext() : this.a);
    }
    
    public void c(Drawable param1Drawable, int param1Int) {
      ActionBar actionBar = this.a.getActionBar();
      if (actionBar != null) {
        a.b(actionBar, param1Drawable);
        a.a(actionBar, param1Int);
      } 
    }
    
    public Drawable d() {
      TypedArray typedArray = b().obtainStyledAttributes(null, new int[] { 16843531 }, 16843470, 0);
      Drawable drawable = typedArray.getDrawable(0);
      typedArray.recycle();
      return drawable;
    }
    
    public void e(int param1Int) {
      ActionBar actionBar = this.a.getActionBar();
      if (actionBar != null)
        a.a(actionBar, param1Int); 
    }
    
    static abstract class a {
      static void a(ActionBar param2ActionBar, int param2Int) {
        param2ActionBar.setHomeActionContentDescription(param2Int);
      }
      
      static void b(ActionBar param2ActionBar, Drawable param2Drawable) {
        param2ActionBar.setHomeAsUpIndicator(param2Drawable);
      }
    }
  }
  
  static abstract class a {
    static void a(ActionBar param1ActionBar, int param1Int) {
      param1ActionBar.setHomeActionContentDescription(param1Int);
    }
    
    static void b(ActionBar param1ActionBar, Drawable param1Drawable) {
      param1ActionBar.setHomeAsUpIndicator(param1Drawable);
    }
  }
  
  static class e implements b {
    final Toolbar a;
    
    final Drawable b;
    
    final CharSequence c;
    
    e(Toolbar param1Toolbar) {
      this.a = param1Toolbar;
      this.b = param1Toolbar.getNavigationIcon();
      this.c = param1Toolbar.getNavigationContentDescription();
    }
    
    public boolean a() {
      return true;
    }
    
    public Context b() {
      return this.a.getContext();
    }
    
    public void c(Drawable param1Drawable, int param1Int) {
      this.a.setNavigationIcon(param1Drawable);
      e(param1Int);
    }
    
    public Drawable d() {
      return this.b;
    }
    
    public void e(int param1Int) {
      if (param1Int == 0) {
        this.a.setNavigationContentDescription(this.c);
        return;
      } 
      this.a.setNavigationContentDescription(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */