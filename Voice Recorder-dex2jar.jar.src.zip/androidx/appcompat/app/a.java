package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.ViewGroup;
import androidx.appcompat.view.b;
import d.j;

public abstract class a {
  public abstract void A(CharSequence paramCharSequence);
  
  public b B(b.a parama) {
    return null;
  }
  
  public boolean f() {
    return false;
  }
  
  public abstract boolean g();
  
  public abstract void h(boolean paramBoolean);
  
  public abstract int i();
  
  public abstract Context j();
  
  public boolean k() {
    return false;
  }
  
  public void l(Configuration paramConfiguration) {}
  
  void m() {}
  
  public abstract boolean n(int paramInt, KeyEvent paramKeyEvent);
  
  public boolean o(KeyEvent paramKeyEvent) {
    return false;
  }
  
  public boolean p() {
    return false;
  }
  
  public abstract void q(boolean paramBoolean);
  
  public abstract void r(boolean paramBoolean);
  
  public abstract void s(boolean paramBoolean);
  
  public abstract void t(boolean paramBoolean);
  
  public abstract void u(float paramFloat);
  
  public abstract void v(int paramInt);
  
  public abstract void w(Drawable paramDrawable);
  
  public abstract void x(boolean paramBoolean);
  
  public abstract void y(int paramInt);
  
  public abstract void z(CharSequence paramCharSequence);
  
  public static abstract class a extends ViewGroup.MarginLayoutParams {
    public int a = 8388627;
    
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, j.ActionBarLayout);
      this.a = typedArray.getInt(j.ActionBarLayout_android_layout_gravity, 0);
      typedArray.recycle();
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public a(a param1a) {
      super(param1a);
      this.a = param1a.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */