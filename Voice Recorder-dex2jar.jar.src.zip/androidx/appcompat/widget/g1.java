package androidx.appcompat.widget;

import android.os.Build;
import android.view.View;

public abstract class g1 {
  public static void a(View paramView, CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 26) {
      a.a(paramView, paramCharSequence);
      return;
    } 
    j1.h(paramView, paramCharSequence);
  }
  
  static abstract class a {
    static void a(View param1View, CharSequence param1CharSequence) {
      param1View.setTooltipText(param1CharSequence);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */