package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;
import androidx.core.widget.j;
import androidx.core.widget.n;
import d.a;
import e.a;

public class e extends CheckedTextView implements n {
  private final f a;
  
  private final d b;
  
  private final x c;
  
  private j d;
  
  public e(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.checkedTextViewStyle);
  }
  
  public e(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(y0.b(paramContext), paramAttributeSet, paramInt);
    x0.a((View)this, getContext());
    x x1 = new x((TextView)this);
    this.c = x1;
    x1.m(paramAttributeSet, paramInt);
    x1.b();
    d d1 = new d((View)this);
    this.b = d1;
    d1.e(paramAttributeSet, paramInt);
    f f1 = new f(this);
    this.a = f1;
    f1.d(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private j getEmojiTextViewHelper() {
    if (this.d == null)
      this.d = new j((TextView)this); 
    return this.d;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    x x1 = this.c;
    if (x1 != null)
      x1.b(); 
    d d1 = this.b;
    if (d1 != null)
      d1.b(); 
    f f1 = this.a;
    if (f1 != null)
      f1.a(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.q(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.b;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.b;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCheckMarkTintList() {
    f f1 = this.a;
    return (f1 != null) ? f1.b() : null;
  }
  
  public PorterDuff.Mode getSupportCheckMarkTintMode() {
    f f1 = this.a;
    return (f1 != null) ? f1.c() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.c.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.c.k();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return k.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.b;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.b;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCheckMarkDrawable(int paramInt) {
    setCheckMarkDrawable(a.b(getContext(), paramInt));
  }
  
  public void setCheckMarkDrawable(Drawable paramDrawable) {
    super.setCheckMarkDrawable(paramDrawable);
    f f1 = this.a;
    if (f1 != null)
      f1.e(); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    x x1 = this.c;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    x x1 = this.c;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.r((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.b;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.b;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCheckMarkTintList(ColorStateList paramColorStateList) {
    f f1 = this.a;
    if (f1 != null)
      f1.f(paramColorStateList); 
  }
  
  public void setSupportCheckMarkTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.a;
    if (f1 != null)
      f1.g(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.c.w(paramColorStateList);
    this.c.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.c.x(paramMode);
    this.c.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    x x1 = this.c;
    if (x1 != null)
      x1.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */