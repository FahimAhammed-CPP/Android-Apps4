package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.core.view.n0;
import androidx.core.widget.e;
import d.j;
import e.a;

public class m {
  private final ImageView a;
  
  private z0 b;
  
  private z0 c;
  
  private z0 d;
  
  private int e = 0;
  
  public m(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.d == null)
      this.d = new z0(); 
    z0 z01 = this.d;
    z01.a();
    ColorStateList colorStateList = e.a(this.a);
    if (colorStateList != null) {
      z01.d = true;
      z01.a = colorStateList;
    } 
    PorterDuff.Mode mode = e.b(this.a);
    if (mode != null) {
      z01.c = true;
      z01.b = mode;
    } 
    if (z01.d || z01.c) {
      h.i(paramDrawable, z01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean l() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.b != null)) : ((i == 21));
  }
  
  void b() {
    if (this.a.getDrawable() != null)
      this.a.getDrawable().setLevel(this.e); 
  }
  
  void c() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      j0.b(drawable); 
    if (drawable != null) {
      if (l() && a(drawable))
        return; 
      z0 z01 = this.c;
      if (z01 != null) {
        h.i(drawable, z01, this.a.getDrawableState());
        return;
      } 
      z01 = this.b;
      if (z01 != null)
        h.i(drawable, z01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList d() {
    z0 z01 = this.c;
    return (z01 != null) ? z01.a : null;
  }
  
  PorterDuff.Mode e() {
    z0 z01 = this.c;
    return (z01 != null) ? z01.b : null;
  }
  
  boolean f() {
    return !(this.a.getBackground() instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void g(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.AppCompatImageView;
    b1 b1 = b1.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    n0.s0((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, b1.r(), paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = b1.n(j.AppCompatImageView_srcCompat, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.b(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        j0.b(drawable1); 
      paramInt = j.AppCompatImageView_tint;
      if (b1.s(paramInt))
        e.c(this.a, b1.c(paramInt)); 
      paramInt = j.AppCompatImageView_tintMode;
      if (b1.s(paramInt))
        e.d(this.a, j0.e(b1.k(paramInt, -1), null)); 
      return;
    } finally {
      b1.w();
    } 
  }
  
  void h(Drawable paramDrawable) {
    this.e = paramDrawable.getLevel();
  }
  
  public void i(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.b(this.a.getContext(), paramInt);
      if (drawable != null)
        j0.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    c();
  }
  
  void j(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new z0(); 
    z0 z01 = this.c;
    z01.a = paramColorStateList;
    z01.d = true;
    c();
  }
  
  void k(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new z0(); 
    z0 z01 = this.c;
    z01.b = paramMode;
    z01.c = true;
    c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */