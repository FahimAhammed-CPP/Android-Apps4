package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.view.n0;
import androidx.core.view.t0;
import androidx.core.view.u0;
import androidx.core.view.v0;
import d.e;
import d.f;
import d.h;
import d.j;

public class f1 implements e0 {
  Toolbar a;
  
  private int b;
  
  private View c;
  
  private View d;
  
  private Drawable e;
  
  private Drawable f;
  
  private Drawable g;
  
  private boolean h;
  
  CharSequence i;
  
  private CharSequence j;
  
  private CharSequence k;
  
  Window.Callback l;
  
  boolean m;
  
  private ActionMenuPresenter n;
  
  private int o;
  
  private int p;
  
  private Drawable q;
  
  public f1(Toolbar paramToolbar, boolean paramBoolean) {
    this(paramToolbar, paramBoolean, h.abc_action_bar_up_description, e.abc_ic_ab_back_material);
  }
  
  public f1(Toolbar paramToolbar, boolean paramBoolean, int paramInt1, int paramInt2) {
    boolean bool;
    this.o = 0;
    this.p = 0;
    this.a = paramToolbar;
    this.i = paramToolbar.getTitle();
    this.j = paramToolbar.getSubtitle();
    if (this.i != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.h = bool;
    this.g = paramToolbar.getNavigationIcon();
    b1 b1 = b1.v(paramToolbar.getContext(), null, j.ActionBar, d.a.actionBarStyle, 0);
    this.q = b1.g(j.ActionBar_homeAsUpIndicator);
    if (paramBoolean) {
      CharSequence charSequence = b1.p(j.ActionBar_title);
      if (!TextUtils.isEmpty(charSequence))
        setTitle(charSequence); 
      charSequence = b1.p(j.ActionBar_subtitle);
      if (!TextUtils.isEmpty(charSequence))
        D(charSequence); 
      Drawable drawable = b1.g(j.ActionBar_logo);
      if (drawable != null)
        B(drawable); 
      drawable = b1.g(j.ActionBar_icon);
      if (drawable != null)
        setIcon(drawable); 
      if (this.g == null) {
        drawable = this.q;
        if (drawable != null)
          w(drawable); 
      } 
      k(b1.k(j.ActionBar_displayOptions, 0));
      paramInt2 = b1.n(j.ActionBar_customNavigationLayout, 0);
      if (paramInt2 != 0) {
        z(LayoutInflater.from(this.a.getContext()).inflate(paramInt2, this.a, false));
        k(this.b | 0x10);
      } 
      paramInt2 = b1.m(j.ActionBar_height, 0);
      if (paramInt2 > 0) {
        ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
        layoutParams.height = paramInt2;
        this.a.setLayoutParams(layoutParams);
      } 
      paramInt2 = b1.e(j.ActionBar_contentInsetStart, -1);
      int i = b1.e(j.ActionBar_contentInsetEnd, -1);
      if (paramInt2 >= 0 || i >= 0)
        this.a.J(Math.max(paramInt2, 0), Math.max(i, 0)); 
      paramInt2 = b1.n(j.ActionBar_titleTextStyle, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.N(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = b1.n(j.ActionBar_subtitleTextStyle, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.M(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = b1.n(j.ActionBar_popupTheme, 0);
      if (paramInt2 != 0)
        this.a.setPopupTheme(paramInt2); 
    } else {
      this.b = y();
    } 
    b1.w();
    A(paramInt1);
    this.k = this.a.getNavigationContentDescription();
    this.a.setNavigationOnClickListener(new a(this));
  }
  
  private void E(CharSequence paramCharSequence) {
    this.i = paramCharSequence;
    if ((this.b & 0x8) != 0) {
      this.a.setTitle(paramCharSequence);
      if (this.h)
        n0.x0(this.a.getRootView(), paramCharSequence); 
    } 
  }
  
  private void F() {
    if ((this.b & 0x4) != 0) {
      if (TextUtils.isEmpty(this.k)) {
        this.a.setNavigationContentDescription(this.p);
        return;
      } 
      this.a.setNavigationContentDescription(this.k);
    } 
  }
  
  private void G() {
    if ((this.b & 0x4) != 0) {
      Toolbar toolbar = this.a;
      Drawable drawable = this.g;
      if (drawable == null)
        drawable = this.q; 
      toolbar.setNavigationIcon(drawable);
      return;
    } 
    this.a.setNavigationIcon((Drawable)null);
  }
  
  private void H() {
    Drawable drawable;
    int i = this.b;
    if ((i & 0x2) != 0) {
      if ((i & 0x1) != 0) {
        drawable = this.f;
        if (drawable == null)
          drawable = this.e; 
      } else {
        drawable = this.e;
      } 
    } else {
      drawable = null;
    } 
    this.a.setLogo(drawable);
  }
  
  private int y() {
    if (this.a.getNavigationIcon() != null) {
      this.q = this.a.getNavigationIcon();
      return 15;
    } 
    return 11;
  }
  
  public void A(int paramInt) {
    if (paramInt == this.p)
      return; 
    this.p = paramInt;
    if (TextUtils.isEmpty(this.a.getNavigationContentDescription()))
      t(this.p); 
  }
  
  public void B(Drawable paramDrawable) {
    this.f = paramDrawable;
    H();
  }
  
  public void C(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    F();
  }
  
  public void D(CharSequence paramCharSequence) {
    this.j = paramCharSequence;
    if ((this.b & 0x8) != 0)
      this.a.setSubtitle(paramCharSequence); 
  }
  
  public void a(Menu paramMenu, m.a parama) {
    if (this.n == null) {
      ActionMenuPresenter actionMenuPresenter = new ActionMenuPresenter(this.a.getContext());
      this.n = actionMenuPresenter;
      actionMenuPresenter.r(f.action_menu_presenter);
    } 
    this.n.g(parama);
    this.a.K((g)paramMenu, this.n);
  }
  
  public boolean b() {
    return this.a.B();
  }
  
  public void c() {
    this.m = true;
  }
  
  public void collapseActionView() {
    this.a.e();
  }
  
  public boolean d() {
    return this.a.d();
  }
  
  public boolean e() {
    return this.a.A();
  }
  
  public boolean f() {
    return this.a.w();
  }
  
  public boolean g() {
    return this.a.Q();
  }
  
  public Context getContext() {
    return this.a.getContext();
  }
  
  public CharSequence getTitle() {
    return this.a.getTitle();
  }
  
  public void h() {
    this.a.f();
  }
  
  public void i(v0 paramv0) {
    View view = this.c;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      Toolbar toolbar = this.a;
      if (viewParent == toolbar)
        toolbar.removeView(this.c); 
    } 
    this.c = (View)paramv0;
  }
  
  public boolean j() {
    return this.a.v();
  }
  
  public void k(int paramInt) {
    int i = this.b ^ paramInt;
    this.b = paramInt;
    if (i != 0) {
      if ((i & 0x4) != 0) {
        if ((paramInt & 0x4) != 0)
          F(); 
        G();
      } 
      if ((i & 0x3) != 0)
        H(); 
      if ((i & 0x8) != 0)
        if ((paramInt & 0x8) != 0) {
          this.a.setTitle(this.i);
          this.a.setSubtitle(this.j);
        } else {
          this.a.setTitle((CharSequence)null);
          this.a.setSubtitle((CharSequence)null);
        }  
      if ((i & 0x10) != 0) {
        View view = this.d;
        if (view != null) {
          if ((paramInt & 0x10) != 0) {
            this.a.addView(view);
            return;
          } 
          this.a.removeView(view);
        } 
      } 
    } 
  }
  
  public Menu l() {
    return this.a.getMenu();
  }
  
  public void m(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = e.a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    B(drawable);
  }
  
  public int n() {
    return this.o;
  }
  
  public t0 o(int paramInt, long paramLong) {
    float f;
    t0 t0 = n0.e((View)this.a);
    if (paramInt == 0) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return t0.b(f).f(paramLong).h((u0)new b(this, paramInt));
  }
  
  public void p(m.a parama, g.a parama1) {
    this.a.L(parama, parama1);
  }
  
  public ViewGroup q() {
    return this.a;
  }
  
  public void r(boolean paramBoolean) {}
  
  public int s() {
    return this.b;
  }
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = e.a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setIcon(drawable);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.e = paramDrawable;
    H();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.h = true;
    E(paramCharSequence);
  }
  
  public void setVisibility(int paramInt) {
    this.a.setVisibility(paramInt);
  }
  
  public void setWindowCallback(Window.Callback paramCallback) {
    this.l = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    if (!this.h)
      E(paramCharSequence); 
  }
  
  public void t(int paramInt) {
    String str;
    if (paramInt == 0) {
      str = null;
    } else {
      str = getContext().getString(paramInt);
    } 
    C(str);
  }
  
  public void u() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void v() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void w(Drawable paramDrawable) {
    this.g = paramDrawable;
    G();
  }
  
  public void x(boolean paramBoolean) {
    this.a.setCollapsible(paramBoolean);
  }
  
  public void z(View paramView) {
    View view = this.d;
    if (view != null && (this.b & 0x10) != 0)
      this.a.removeView(view); 
    this.d = paramView;
    if (paramView != null && (this.b & 0x10) != 0)
      this.a.addView(paramView); 
  }
  
  class a implements View.OnClickListener {
    final androidx.appcompat.view.menu.a a;
    
    a(f1 this$0) {
      this.a = new androidx.appcompat.view.menu.a(this$0.a.getContext(), 0, 16908332, 0, 0, this$0.i);
    }
    
    public void onClick(View param1View) {
      f1 f11 = this.b;
      Window.Callback callback = f11.l;
      if (callback != null && f11.m)
        callback.onMenuItemSelected(0, (MenuItem)this.a); 
    }
  }
  
  class b extends v0 {
    private boolean a = false;
    
    b(f1 this$0, int param1Int) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (!this.a)
        this.c.a.setVisibility(this.b); 
    }
    
    public void c(View param1View) {
      this.c.a.setVisibility(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */