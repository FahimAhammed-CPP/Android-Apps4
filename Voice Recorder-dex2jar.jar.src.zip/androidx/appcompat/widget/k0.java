package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.core.view.t0;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class k0 extends ListView {
  private final Rect a = new Rect();
  
  private int b = 0;
  
  private int c = 0;
  
  private int d = 0;
  
  private int e = 0;
  
  private int f;
  
  private d g;
  
  private boolean h;
  
  private boolean i;
  
  private boolean j;
  
  private t0 k;
  
  private androidx.core.widget.f l;
  
  f m;
  
  k0(Context paramContext, boolean paramBoolean) {
    super(paramContext, null, d.a.dropDownListViewStyle);
    this.i = paramBoolean;
    setCacheColorHint(0);
  }
  
  private void a() {
    this.j = false;
    setPressed(false);
    drawableStateChanged();
    View view = getChildAt(this.f - getFirstVisiblePosition());
    if (view != null)
      view.setPressed(false); 
    t0 t01 = this.k;
    if (t01 != null) {
      t01.c();
      this.k = null;
    } 
  }
  
  private void b(View paramView, int paramInt) {
    performItemClick(paramView, paramInt, getItemIdAtPosition(paramInt));
  }
  
  private void c(Canvas paramCanvas) {
    if (!this.a.isEmpty()) {
      Drawable drawable = getSelector();
      if (drawable != null) {
        drawable.setBounds(this.a);
        drawable.draw(paramCanvas);
      } 
    } 
  }
  
  private void f(int paramInt, View paramView) {
    Rect rect = this.a;
    rect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    rect.left -= this.b;
    rect.top -= this.c;
    rect.right += this.d;
    rect.bottom += this.e;
    boolean bool = k();
    if (paramView.isEnabled() != bool) {
      l(bool ^ true);
      if (paramInt != -1)
        refreshDrawableState(); 
    } 
  }
  
  private void g(int paramInt, View paramView) {
    boolean bool1;
    Drawable drawable = getSelector();
    boolean bool2 = true;
    if (drawable != null && paramInt != -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1)
      drawable.setVisible(false, false); 
    f(paramInt, paramView);
    if (bool1) {
      Rect rect = this.a;
      float f1 = rect.exactCenterX();
      float f2 = rect.exactCenterY();
      if (getVisibility() != 0)
        bool2 = false; 
      drawable.setVisible(bool2, false);
      androidx.core.graphics.drawable.a.k(drawable, f1, f2);
    } 
  }
  
  private void h(int paramInt, View paramView, float paramFloat1, float paramFloat2) {
    g(paramInt, paramView);
    Drawable drawable = getSelector();
    if (drawable != null && paramInt != -1)
      androidx.core.graphics.drawable.a.k(drawable, paramFloat1, paramFloat2); 
  }
  
  private void i(View paramView, int paramInt, float paramFloat1, float paramFloat2) {
    this.j = true;
    a.a((View)this, paramFloat1, paramFloat2);
    if (!isPressed())
      setPressed(true); 
    layoutChildren();
    int i = this.f;
    if (i != -1) {
      View view = getChildAt(i - getFirstVisiblePosition());
      if (view != null && view != paramView && view.isPressed())
        view.setPressed(false); 
    } 
    this.f = paramInt;
    a.a(paramView, paramFloat1 - paramView.getLeft(), paramFloat2 - paramView.getTop());
    if (!paramView.isPressed())
      paramView.setPressed(true); 
    h(paramInt, paramView, paramFloat1, paramFloat2);
    j(false);
    refreshDrawableState();
  }
  
  private void j(boolean paramBoolean) {
    d d1 = this.g;
    if (d1 != null)
      d1.b(paramBoolean); 
  }
  
  private boolean k() {
    return androidx.core.os.a.c() ? c.a((AbsListView)this) : e.a((AbsListView)this);
  }
  
  private void l(boolean paramBoolean) {
    if (androidx.core.os.a.c()) {
      c.b((AbsListView)this, paramBoolean);
      return;
    } 
    e.b((AbsListView)this, paramBoolean);
  }
  
  private boolean m() {
    return this.j;
  }
  
  private void n() {
    Drawable drawable = getSelector();
    if (drawable != null && m() && isPressed())
      drawable.setState(getDrawableState()); 
  }
  
  public int d(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    paramInt2 = getListPaddingTop();
    paramInt3 = getListPaddingBottom();
    int i = getDividerHeight();
    Drawable drawable = getDivider();
    ListAdapter listAdapter = getAdapter();
    if (listAdapter == null)
      return paramInt2 + paramInt3; 
    paramInt3 = paramInt2 + paramInt3;
    if (i <= 0 || drawable == null)
      i = 0; 
    int m = listAdapter.getCount();
    drawable = null;
    int j = 0;
    int k = 0;
    for (paramInt2 = 0; j < m; paramInt2 = i1) {
      int i1 = listAdapter.getItemViewType(j);
      int n = k;
      if (i1 != k) {
        drawable = null;
        n = i1;
      } 
      View view2 = listAdapter.getView(j, (View)drawable, (ViewGroup)this);
      ViewGroup.LayoutParams layoutParams2 = view2.getLayoutParams();
      ViewGroup.LayoutParams layoutParams1 = layoutParams2;
      if (layoutParams2 == null) {
        layoutParams1 = generateDefaultLayoutParams();
        view2.setLayoutParams(layoutParams1);
      } 
      k = layoutParams1.height;
      if (k > 0) {
        k = View.MeasureSpec.makeMeasureSpec(k, 1073741824);
      } else {
        k = View.MeasureSpec.makeMeasureSpec(0, 0);
      } 
      view2.measure(paramInt1, k);
      view2.forceLayout();
      k = paramInt3;
      if (j > 0)
        k = paramInt3 + i; 
      paramInt3 = k + view2.getMeasuredHeight();
      if (paramInt3 >= paramInt4) {
        paramInt1 = paramInt4;
        if (paramInt5 >= 0) {
          paramInt1 = paramInt4;
          if (j > paramInt5) {
            paramInt1 = paramInt4;
            if (paramInt2 > 0) {
              paramInt1 = paramInt4;
              if (paramInt3 != paramInt4)
                paramInt1 = paramInt2; 
            } 
          } 
        } 
        return paramInt1;
      } 
      i1 = paramInt2;
      if (paramInt5 >= 0) {
        i1 = paramInt2;
        if (j >= paramInt5)
          i1 = paramInt3; 
      } 
      j++;
      k = n;
      View view1 = view2;
    } 
    return paramInt3;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    c(paramCanvas);
    super.dispatchDraw(paramCanvas);
  }
  
  protected void drawableStateChanged() {
    if (this.m != null)
      return; 
    super.drawableStateChanged();
    j(true);
    n();
  }
  
  public boolean e(MotionEvent paramMotionEvent, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_3
    //   5: iload_3
    //   6: iconst_1
    //   7: if_icmpeq -> 42
    //   10: iload_3
    //   11: iconst_2
    //   12: if_icmpeq -> 36
    //   15: iload_3
    //   16: iconst_3
    //   17: if_icmpeq -> 28
    //   20: iconst_0
    //   21: istore_2
    //   22: iconst_1
    //   23: istore #6
    //   25: goto -> 139
    //   28: iconst_0
    //   29: istore_2
    //   30: iconst_0
    //   31: istore #6
    //   33: goto -> 139
    //   36: iconst_1
    //   37: istore #6
    //   39: goto -> 45
    //   42: iconst_0
    //   43: istore #6
    //   45: aload_1
    //   46: iload_2
    //   47: invokevirtual findPointerIndex : (I)I
    //   50: istore #4
    //   52: iload #4
    //   54: ifge -> 60
    //   57: goto -> 28
    //   60: aload_1
    //   61: iload #4
    //   63: invokevirtual getX : (I)F
    //   66: f2i
    //   67: istore_2
    //   68: aload_1
    //   69: iload #4
    //   71: invokevirtual getY : (I)F
    //   74: f2i
    //   75: istore #4
    //   77: aload_0
    //   78: iload_2
    //   79: iload #4
    //   81: invokevirtual pointToPosition : (II)I
    //   84: istore #5
    //   86: iload #5
    //   88: iconst_m1
    //   89: if_icmpne -> 97
    //   92: iconst_1
    //   93: istore_2
    //   94: goto -> 139
    //   97: aload_0
    //   98: iload #5
    //   100: aload_0
    //   101: invokevirtual getFirstVisiblePosition : ()I
    //   104: isub
    //   105: invokevirtual getChildAt : (I)Landroid/view/View;
    //   108: astore #7
    //   110: aload_0
    //   111: aload #7
    //   113: iload #5
    //   115: iload_2
    //   116: i2f
    //   117: iload #4
    //   119: i2f
    //   120: invokespecial i : (Landroid/view/View;IFF)V
    //   123: iload_3
    //   124: iconst_1
    //   125: if_icmpne -> 20
    //   128: aload_0
    //   129: aload #7
    //   131: iload #5
    //   133: invokespecial b : (Landroid/view/View;I)V
    //   136: goto -> 20
    //   139: iload #6
    //   141: ifeq -> 148
    //   144: iload_2
    //   145: ifeq -> 152
    //   148: aload_0
    //   149: invokespecial a : ()V
    //   152: iload #6
    //   154: ifeq -> 198
    //   157: aload_0
    //   158: getfield l : Landroidx/core/widget/f;
    //   161: ifnonnull -> 176
    //   164: aload_0
    //   165: new androidx/core/widget/f
    //   168: dup
    //   169: aload_0
    //   170: invokespecial <init> : (Landroid/widget/ListView;)V
    //   173: putfield l : Landroidx/core/widget/f;
    //   176: aload_0
    //   177: getfield l : Landroidx/core/widget/f;
    //   180: iconst_1
    //   181: invokevirtual m : (Z)Landroidx/core/widget/a;
    //   184: pop
    //   185: aload_0
    //   186: getfield l : Landroidx/core/widget/f;
    //   189: aload_0
    //   190: aload_1
    //   191: invokevirtual onTouch : (Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   194: pop
    //   195: iload #6
    //   197: ireturn
    //   198: aload_0
    //   199: getfield l : Landroidx/core/widget/f;
    //   202: astore_1
    //   203: aload_1
    //   204: ifnull -> 213
    //   207: aload_1
    //   208: iconst_0
    //   209: invokevirtual m : (Z)Landroidx/core/widget/a;
    //   212: pop
    //   213: iload #6
    //   215: ireturn
  }
  
  public boolean hasFocus() {
    return (this.i || super.hasFocus());
  }
  
  public boolean hasWindowFocus() {
    return (this.i || super.hasWindowFocus());
  }
  
  public boolean isFocused() {
    return (this.i || super.isFocused());
  }
  
  public boolean isInTouchMode() {
    return ((this.i && this.h) || super.isInTouchMode());
  }
  
  protected void onDetachedFromWindow() {
    this.m = null;
    super.onDetachedFromWindow();
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = Build.VERSION.SDK_INT;
    if (i < 26)
      return super.onHoverEvent(paramMotionEvent); 
    int j = paramMotionEvent.getActionMasked();
    if (j == 10 && this.m == null) {
      f f1 = new f(this);
      this.m = f1;
      f1.b();
    } 
    boolean bool = super.onHoverEvent(paramMotionEvent);
    if (j == 9 || j == 7) {
      j = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
      if (j != -1 && j != getSelectedItemPosition()) {
        View view = getChildAt(j - getFirstVisiblePosition());
        if (view.isEnabled()) {
          requestFocus();
          if (i >= 30 && b.a()) {
            b.b(this, j, view);
          } else {
            setSelectionFromTop(j, view.getTop() - getTop());
          } 
        } 
        n();
      } 
      return bool;
    } 
    setSelection(-1);
    return bool;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 0)
      this.f = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY()); 
    f f1 = this.m;
    if (f1 != null)
      f1.a(); 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  void setListSelectionHidden(boolean paramBoolean) {
    this.h = paramBoolean;
  }
  
  public void setSelector(Drawable paramDrawable) {
    d d1;
    if (paramDrawable != null) {
      d1 = new d(paramDrawable);
    } else {
      d1 = null;
    } 
    this.g = d1;
    super.setSelector((Drawable)d1);
    Rect rect = new Rect();
    if (paramDrawable != null)
      paramDrawable.getPadding(rect); 
    this.b = rect.left;
    this.c = rect.top;
    this.d = rect.right;
    this.e = rect.bottom;
  }
  
  static abstract class a {
    static void a(View param1View, float param1Float1, float param1Float2) {
      param1View.drawableHotspotChanged(param1Float1, param1Float2);
    }
  }
  
  static abstract class b {
    private static Method a;
    
    private static Method b;
    
    private static Method c;
    
    private static boolean d;
    
    static {
      try {
        Class<int> clazz = int.class;
        Class<boolean> clazz1 = boolean.class;
        Class<float> clazz2 = float.class;
        Method method2 = AbsListView.class.getDeclaredMethod("positionSelector", new Class[] { clazz, View.class, clazz1, clazz2, clazz2 });
        a = method2;
        method2.setAccessible(true);
        method2 = AdapterView.class.getDeclaredMethod("setSelectedPositionInt", new Class[] { clazz });
        b = method2;
        method2.setAccessible(true);
        Method method1 = AdapterView.class.getDeclaredMethod("setNextSelectedPositionInt", new Class[] { clazz });
        c = method1;
        method1.setAccessible(true);
        d = true;
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        noSuchMethodException.printStackTrace();
        return;
      } 
    }
    
    static boolean a() {
      return d;
    }
    
    static void b(k0 param1k0, int param1Int, View param1View) {
      try {
        a.invoke(param1k0, new Object[] { Integer.valueOf(param1Int), param1View, Boolean.FALSE, Integer.valueOf(-1), Integer.valueOf(-1) });
        b.invoke(param1k0, new Object[] { Integer.valueOf(param1Int) });
        c.invoke(param1k0, new Object[] { Integer.valueOf(param1Int) });
        return;
      } catch (IllegalAccessException illegalAccessException) {
        illegalAccessException.printStackTrace();
        return;
      } catch (InvocationTargetException invocationTargetException) {
        invocationTargetException.printStackTrace();
        return;
      } 
    }
  }
  
  static abstract class c {
    static boolean a(AbsListView param1AbsListView) {
      return param1AbsListView.isSelectedChildViewEnabled();
    }
    
    static void b(AbsListView param1AbsListView, boolean param1Boolean) {
      param1AbsListView.setSelectedChildViewEnabled(param1Boolean);
    }
  }
  
  private static class d extends f.c {
    private boolean b = true;
    
    d(Drawable param1Drawable) {
      super(param1Drawable);
    }
    
    void b(boolean param1Boolean) {
      this.b = param1Boolean;
    }
    
    public void draw(Canvas param1Canvas) {
      if (this.b)
        super.draw(param1Canvas); 
    }
    
    public void setHotspot(float param1Float1, float param1Float2) {
      if (this.b)
        super.setHotspot(param1Float1, param1Float2); 
    }
    
    public void setHotspotBounds(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (this.b)
        super.setHotspotBounds(param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public boolean setState(int[] param1ArrayOfint) {
      return this.b ? super.setState(param1ArrayOfint) : false;
    }
    
    public boolean setVisible(boolean param1Boolean1, boolean param1Boolean2) {
      return this.b ? super.setVisible(param1Boolean1, param1Boolean2) : false;
    }
  }
  
  static abstract class e {
    private static final Field a;
    
    static {
      Field field = null;
      try {
        Field field1 = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
        field = field1;
        field1.setAccessible(true);
        field = field1;
      } catch (NoSuchFieldException noSuchFieldException) {
        noSuchFieldException.printStackTrace();
      } 
      a = field;
    }
    
    static boolean a(AbsListView param1AbsListView) {
      Field field = a;
      if (field != null)
        try {
          return field.getBoolean(param1AbsListView);
        } catch (IllegalAccessException illegalAccessException) {
          illegalAccessException.printStackTrace();
        }  
      return false;
    }
    
    static void b(AbsListView param1AbsListView, boolean param1Boolean) {
      Field field = a;
      if (field != null)
        try {
          field.set(param1AbsListView, Boolean.valueOf(param1Boolean));
          return;
        } catch (IllegalAccessException illegalAccessException) {
          illegalAccessException.printStackTrace();
        }  
    }
  }
  
  private class f implements Runnable {
    f(k0 this$0) {}
    
    public void a() {
      k0 k01 = this.a;
      k01.m = null;
      k01.removeCallbacks(this);
    }
    
    public void b() {
      this.a.post(this);
    }
    
    public void run() {
      k0 k01 = this.a;
      k01.m = null;
      k01.drawableStateChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */