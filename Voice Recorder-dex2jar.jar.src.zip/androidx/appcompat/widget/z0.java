package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public class z0 {
  public ColorStateList a;
  
  public PorterDuff.Mode b;
  
  public boolean c;
  
  public boolean d;
  
  void a() {
    this.a = null;
    this.d = false;
    this.b = null;
    this.c = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\z0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */