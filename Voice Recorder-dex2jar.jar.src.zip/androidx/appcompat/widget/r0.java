package androidx.appcompat.widget;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupWindow;
import androidx.appcompat.view.g;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.l;

public class r0 {
  private final Context a;
  
  private final g b;
  
  private final View c;
  
  final l d;
  
  c e;
  
  public r0(Context paramContext, View paramView) {
    this(paramContext, paramView, 0);
  }
  
  public r0(Context paramContext, View paramView, int paramInt) {
    this(paramContext, paramView, paramInt, d.a.popupMenuStyle, 0);
  }
  
  public r0(Context paramContext, View paramView, int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramContext;
    this.c = paramView;
    g g1 = new g(paramContext);
    this.b = g1;
    g1.V(new a(this));
    l l1 = new l(paramContext, g1, paramView, false, paramInt2, paramInt3);
    this.d = l1;
    l1.h(paramInt1);
    l1.i(new b(this));
  }
  
  public MenuInflater a() {
    return (MenuInflater)new g(this.a);
  }
  
  public void b(int paramInt) {
    a().inflate(paramInt, (Menu)this.b);
  }
  
  public void c(c paramc) {
    this.e = paramc;
  }
  
  public void d() {
    this.d.k();
  }
  
  class a implements g.a {
    a(r0 this$0) {}
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      r0.c c = this.a.e;
      return (c != null) ? c.onMenuItemClick(param1MenuItem) : false;
    }
    
    public void b(g param1g) {}
  }
  
  class b implements PopupWindow.OnDismissListener {
    b(r0 this$0) {}
    
    public void onDismiss() {
      this.a.getClass();
    }
  }
  
  public static interface c {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */