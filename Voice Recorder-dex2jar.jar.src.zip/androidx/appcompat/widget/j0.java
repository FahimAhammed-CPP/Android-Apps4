package androidx.appcompat.widget;

import android.graphics.Insets;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class j0 {
  private static final int[] a = new int[] { 16842912 };
  
  private static final int[] b = new int[0];
  
  public static final Rect c = new Rect();
  
  public static boolean a(Drawable paramDrawable) {
    return true;
  }
  
  static void b(Drawable paramDrawable) {
    String str = paramDrawable.getClass().getName();
    int i = Build.VERSION.SDK_INT;
    if (i == 21 && "android.graphics.drawable.VectorDrawable".equals(str)) {
      c(paramDrawable);
      return;
    } 
    if (i >= 29 && i < 31 && "android.graphics.drawable.ColorStateListDrawable".equals(str))
      c(paramDrawable); 
  }
  
  private static void c(Drawable paramDrawable) {
    int[] arrayOfInt = paramDrawable.getState();
    if (arrayOfInt == null || arrayOfInt.length == 0) {
      paramDrawable.setState(a);
    } else {
      paramDrawable.setState(b);
    } 
    paramDrawable.setState(arrayOfInt);
  }
  
  public static Rect d(Drawable paramDrawable) {
    Insets insets;
    if (Build.VERSION.SDK_INT >= 29) {
      insets = b.a(paramDrawable);
      return new Rect(f0.a(insets), g0.a(insets), h0.a(insets), i0.a(insets));
    } 
    return a.a(androidx.core.graphics.drawable.a.q((Drawable)insets));
  }
  
  public static PorterDuff.Mode e(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
  
  static abstract class a {
    private static final boolean a;
    
    private static final Method b;
    
    private static final Field c;
    
    private static final Field d;
    
    private static final Field e;
    
    private static final Field f;
    
    static {
      // Byte code:
      //   0: ldc 'android.graphics.Insets'
      //   2: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
      //   5: astore_2
      //   6: ldc android/graphics/drawable/Drawable
      //   8: ldc 'getOpticalInsets'
      //   10: iconst_0
      //   11: anewarray java/lang/Class
      //   14: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   17: astore_1
      //   18: aload_2
      //   19: ldc 'left'
      //   21: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   24: astore_3
      //   25: aload_2
      //   26: ldc 'top'
      //   28: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   31: astore #5
      //   33: aload_2
      //   34: ldc 'right'
      //   36: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   39: astore #4
      //   41: aload_2
      //   42: ldc 'bottom'
      //   44: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   47: astore_2
      //   48: iconst_1
      //   49: istore_0
      //   50: goto -> 154
      //   53: goto -> 150
      //   56: aconst_null
      //   57: astore #4
      //   59: goto -> 150
      //   62: aconst_null
      //   63: astore #4
      //   65: aload_1
      //   66: astore_2
      //   67: aload #4
      //   69: astore_1
      //   70: goto -> 142
      //   73: aconst_null
      //   74: astore #4
      //   76: aload_1
      //   77: astore_2
      //   78: aload #4
      //   80: astore_1
      //   81: goto -> 142
      //   84: aconst_null
      //   85: astore #4
      //   87: aload_1
      //   88: astore_2
      //   89: aload #4
      //   91: astore_1
      //   92: goto -> 142
      //   95: goto -> 108
      //   98: goto -> 123
      //   101: aload_1
      //   102: astore_2
      //   103: goto -> 138
      //   106: aconst_null
      //   107: astore_1
      //   108: aconst_null
      //   109: astore_3
      //   110: aconst_null
      //   111: astore #4
      //   113: aload_1
      //   114: astore_2
      //   115: aload #4
      //   117: astore_1
      //   118: goto -> 142
      //   121: aconst_null
      //   122: astore_1
      //   123: aconst_null
      //   124: astore_3
      //   125: aconst_null
      //   126: astore #4
      //   128: aload_1
      //   129: astore_2
      //   130: aload #4
      //   132: astore_1
      //   133: goto -> 142
      //   136: aconst_null
      //   137: astore_2
      //   138: aconst_null
      //   139: astore_3
      //   140: aconst_null
      //   141: astore_1
      //   142: aload_1
      //   143: astore #4
      //   145: aload_1
      //   146: astore #5
      //   148: aload_2
      //   149: astore_1
      //   150: aconst_null
      //   151: astore_2
      //   152: iconst_0
      //   153: istore_0
      //   154: iload_0
      //   155: ifeq -> 185
      //   158: aload_1
      //   159: putstatic androidx/appcompat/widget/j0$a.b : Ljava/lang/reflect/Method;
      //   162: aload_3
      //   163: putstatic androidx/appcompat/widget/j0$a.c : Ljava/lang/reflect/Field;
      //   166: aload #5
      //   168: putstatic androidx/appcompat/widget/j0$a.d : Ljava/lang/reflect/Field;
      //   171: aload #4
      //   173: putstatic androidx/appcompat/widget/j0$a.e : Ljava/lang/reflect/Field;
      //   176: aload_2
      //   177: putstatic androidx/appcompat/widget/j0$a.f : Ljava/lang/reflect/Field;
      //   180: iconst_1
      //   181: putstatic androidx/appcompat/widget/j0$a.a : Z
      //   184: return
      //   185: aconst_null
      //   186: putstatic androidx/appcompat/widget/j0$a.b : Ljava/lang/reflect/Method;
      //   189: aconst_null
      //   190: putstatic androidx/appcompat/widget/j0$a.c : Ljava/lang/reflect/Field;
      //   193: aconst_null
      //   194: putstatic androidx/appcompat/widget/j0$a.d : Ljava/lang/reflect/Field;
      //   197: aconst_null
      //   198: putstatic androidx/appcompat/widget/j0$a.e : Ljava/lang/reflect/Field;
      //   201: aconst_null
      //   202: putstatic androidx/appcompat/widget/j0$a.f : Ljava/lang/reflect/Field;
      //   205: iconst_0
      //   206: putstatic androidx/appcompat/widget/j0$a.a : Z
      //   209: return
      //   210: astore_1
      //   211: goto -> 136
      //   214: astore_1
      //   215: goto -> 121
      //   218: astore_1
      //   219: goto -> 106
      //   222: astore_2
      //   223: goto -> 101
      //   226: astore_2
      //   227: goto -> 98
      //   230: astore_2
      //   231: goto -> 95
      //   234: astore_2
      //   235: goto -> 84
      //   238: astore_2
      //   239: goto -> 73
      //   242: astore_2
      //   243: goto -> 62
      //   246: astore_2
      //   247: goto -> 56
      //   250: astore_2
      //   251: goto -> 53
      // Exception table:
      //   from	to	target	type
      //   0	18	210	java/lang/NoSuchMethodException
      //   0	18	214	java/lang/ClassNotFoundException
      //   0	18	218	java/lang/NoSuchFieldException
      //   18	25	222	java/lang/NoSuchMethodException
      //   18	25	226	java/lang/ClassNotFoundException
      //   18	25	230	java/lang/NoSuchFieldException
      //   25	33	234	java/lang/NoSuchMethodException
      //   25	33	238	java/lang/ClassNotFoundException
      //   25	33	242	java/lang/NoSuchFieldException
      //   33	41	246	java/lang/NoSuchMethodException
      //   33	41	246	java/lang/ClassNotFoundException
      //   33	41	246	java/lang/NoSuchFieldException
      //   41	48	250	java/lang/NoSuchMethodException
      //   41	48	250	java/lang/ClassNotFoundException
      //   41	48	250	java/lang/NoSuchFieldException
    }
    
    static Rect a(Drawable param1Drawable) {
      if (Build.VERSION.SDK_INT < 29 && a)
        try {
          Object object = b.invoke(param1Drawable, new Object[0]);
          if (object != null)
            return new Rect(c.getInt(object), d.getInt(object), e.getInt(object), f.getInt(object)); 
        } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {} 
      return j0.c;
    }
  }
  
  static abstract class b {
    static Insets a(Drawable param1Drawable) {
      return param1Drawable.getOpticalInsets();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */