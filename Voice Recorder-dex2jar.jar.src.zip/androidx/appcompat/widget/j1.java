package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.n0;
import androidx.core.view.p0;

class j1 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  private static j1 k;
  
  private static j1 l;
  
  private final View a;
  
  private final CharSequence b;
  
  private final int c;
  
  private final Runnable d = new h1(this);
  
  private final Runnable e = new i1(this);
  
  private int f;
  
  private int g;
  
  private k1 h;
  
  private boolean i;
  
  private boolean j;
  
  private j1(View paramView, CharSequence paramCharSequence) {
    this.a = paramView;
    this.b = paramCharSequence;
    this.c = p0.c(ViewConfiguration.get(paramView.getContext()));
    c();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  private void b() {
    this.a.removeCallbacks(this.d);
  }
  
  private void c() {
    this.j = true;
  }
  
  private void f() {
    this.a.postDelayed(this.d, ViewConfiguration.getLongPressTimeout());
  }
  
  private static void g(j1 paramj1) {
    j1 j11 = k;
    if (j11 != null)
      j11.b(); 
    k = paramj1;
    if (paramj1 != null)
      paramj1.f(); 
  }
  
  public static void h(View paramView, CharSequence paramCharSequence) {
    j1 j11;
    j1 j12 = k;
    if (j12 != null && j12.a == paramView)
      g(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      j11 = l;
      if (j11 != null && j11.a == paramView)
        j11.d(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new j1(paramView, (CharSequence)j11);
  }
  
  private boolean j(MotionEvent paramMotionEvent) {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if (this.j || Math.abs(i - this.f) > this.c || Math.abs(j - this.g) > this.c) {
      this.f = i;
      this.g = j;
      this.j = false;
      return true;
    } 
    return false;
  }
  
  void d() {
    if (l == this) {
      l = null;
      k1 k11 = this.h;
      if (k11 != null) {
        k11.c();
        this.h = null;
        c();
        this.a.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (k == this)
      g(null); 
    this.a.removeCallbacks(this.e);
  }
  
  void i(boolean paramBoolean) {
    long l;
    if (!n0.X(this.a))
      return; 
    g(null);
    j1 j11 = l;
    if (j11 != null)
      j11.d(); 
    l = this;
    this.i = paramBoolean;
    k1 k11 = new k1(this.a.getContext());
    this.h = k11;
    k11.e(this.a, this.f, this.g, this.i, this.b);
    this.a.addOnAttachStateChangeListener(this);
    if (this.i) {
      l = 2500L;
    } else {
      long l1;
      if ((n0.Q(this.a) & 0x1) == 1) {
        l = ViewConfiguration.getLongPressTimeout();
        l1 = 3000L;
      } else {
        l = ViewConfiguration.getLongPressTimeout();
        l1 = 15000L;
      } 
      l = l1 - l;
    } 
    this.a.removeCallbacks(this.e);
    this.a.postDelayed(this.e, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.h != null && this.i)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.a.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      c();
      d();
      return false;
    } 
    if (this.a.isEnabled() && this.h == null && j(paramMotionEvent))
      g(this); 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.f = paramView.getWidth() / 2;
    this.g = paramView.getHeight() / 2;
    i(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\j1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */