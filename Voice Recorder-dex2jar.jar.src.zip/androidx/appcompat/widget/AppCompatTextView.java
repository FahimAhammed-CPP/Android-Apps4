package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.appcompat.app.f0;
import androidx.core.graphics.e;
import androidx.core.text.n;
import androidx.core.widget.j;
import androidx.core.widget.n;
import java.util.concurrent.Future;

public class AppCompatTextView extends TextView implements n {
  private final d a;
  
  private final x b;
  
  private final w c;
  
  private j d;
  
  private boolean e = false;
  
  private a f = null;
  
  private Future g;
  
  public AppCompatTextView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(y0.b(paramContext), paramAttributeSet, paramInt);
    x0.a((View)this, getContext());
    d d1 = new d((View)this);
    this.a = d1;
    d1.e(paramAttributeSet, paramInt);
    x x1 = new x(this);
    this.b = x1;
    x1.m(paramAttributeSet, paramInt);
    x1.b();
    this.c = new w(this);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private j getEmojiTextViewHelper() {
    if (this.d == null)
      this.d = new j(this); 
    return this.d;
  }
  
  private void q() {
    Future future = this.g;
    if (future != null)
      try {
        this.g = null;
        f0.a(future.get());
        j.n(this, null);
        return;
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
        return;
      }  
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.a;
    if (d1 != null)
      d1.b(); 
    x x1 = this.b;
    if (x1 != null)
      x1.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (m1.b)
      return getSuperCaller().d(); 
    x x1 = this.b;
    return (x1 != null) ? x1.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (m1.b)
      return getSuperCaller().i(); 
    x x1 = this.b;
    return (x1 != null) ? x1.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (m1.b)
      return getSuperCaller().k(); 
    x x1 = this.b;
    return (x1 != null) ? x1.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (m1.b)
      return getSuperCaller().b(); 
    x x1 = this.b;
    return (x1 != null) ? x1.h() : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = m1.b;
    boolean bool = false;
    if (bool1) {
      if (getSuperCaller().h() == 1)
        bool = true; 
      return bool;
    } 
    x x1 = this.b;
    return (x1 != null) ? x1.i() : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.q(super.getCustomSelectionActionModeCallback());
  }
  
  public int getFirstBaselineToTopHeight() {
    return j.b(this);
  }
  
  public int getLastBaselineToBottomHeight() {
    return j.c(this);
  }
  
  a getSuperCaller() {
    if (this.f == null) {
      int i = Build.VERSION.SDK_INT;
      if (i >= 28) {
        this.f = new c(this);
      } else if (i >= 26) {
        this.f = new b(this);
      } 
    } 
    return this.f;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.a;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.a;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.b.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.b.k();
  }
  
  public CharSequence getText() {
    q();
    return super.getText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      w w1 = this.c;
      if (w1 != null)
        return w1.a(); 
    } 
    return getSuperCaller().c();
  }
  
  public n.a getTextMetricsParamsCompat() {
    return j.g(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    this.b.r(this, inputConnection, paramEditorInfo);
    return k.a(inputConnection, paramEditorInfo, (View)this);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    x x1 = this.b;
    if (x1 != null)
      x1.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    q();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    x x1 = this.b;
    if (x1 != null && !m1.b && x1.l()) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt1 != 0)
      this.b.c(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (m1.b) {
      getSuperCaller().g(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    x x1 = this.b;
    if (x1 != null)
      x1.t(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (m1.b) {
      getSuperCaller().a(paramArrayOfint, paramInt);
      return;
    } 
    x x1 = this.b;
    if (x1 != null)
      x1.u(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (m1.b) {
      getSuperCaller().l(paramInt);
      return;
    } 
    x x1 = this.b;
    if (x1 != null)
      x1.v(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.a;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.a;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    x x1 = this.b;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    x x1 = this.b;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = e.a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = e.a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = e.a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = e.a.b(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    x x1 = this.b;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    x x1 = this.b;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = e.a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = e.a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = e.a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = e.a.b(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    x x1 = this.b;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    x x1 = this.b;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.r(this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      getSuperCaller().j(paramInt);
      return;
    } 
    j.k(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      getSuperCaller().f(paramInt);
      return;
    } 
    j.l(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    j.m(this, paramInt);
  }
  
  public void setPrecomputedText(n paramn) {
    j.n(this, paramn);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.a;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.a;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.b.w(paramColorStateList);
    this.b.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.b.x(paramMode);
    this.b.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    x x1 = this.b;
    if (x1 != null)
      x1.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      w w1 = this.c;
      if (w1 != null) {
        w1.b(paramTextClassifier);
        return;
      } 
    } 
    getSuperCaller().e(paramTextClassifier);
  }
  
  public void setTextFuture(Future<n> paramFuture) {
    this.g = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(n.a parama) {
    j.p(this, parama);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (m1.b) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    x x1 = this.b;
    if (x1 != null)
      x1.A(paramInt, paramFloat); 
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt) {
    Typeface typeface;
    if (this.e)
      return; 
    if (paramTypeface != null && paramInt > 0) {
      typeface = e.a(getContext(), paramTypeface, paramInt);
    } else {
      typeface = null;
    } 
    this.e = true;
    if (typeface != null)
      paramTypeface = typeface; 
    try {
      super.setTypeface(paramTypeface, paramInt);
      return;
    } finally {
      this.e = false;
    } 
  }
  
  private static interface a {
    void a(int[] param1ArrayOfint, int param1Int);
    
    int[] b();
    
    TextClassifier c();
    
    int d();
    
    void e(TextClassifier param1TextClassifier);
    
    void f(int param1Int);
    
    void g(int param1Int1, int param1Int2, int param1Int3, int param1Int4);
    
    int h();
    
    int i();
    
    void j(int param1Int);
    
    int k();
    
    void l(int param1Int);
  }
  
  class b implements a {
    b(AppCompatTextView this$0) {}
    
    public void a(int[] param1ArrayOfint, int param1Int) {
      AppCompatTextView.n(this.a, param1ArrayOfint, param1Int);
    }
    
    public int[] b() {
      return AppCompatTextView.j(this.a);
    }
    
    public TextClassifier c() {
      return AppCompatTextView.l(this.a);
    }
    
    public int d() {
      return AppCompatTextView.c(this.a);
    }
    
    public void e(TextClassifier param1TextClassifier) {
      AppCompatTextView.p(this.a, param1TextClassifier);
    }
    
    public void f(int param1Int) {}
    
    public void g(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      AppCompatTextView.m(this.a, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public int h() {
      return AppCompatTextView.k(this.a);
    }
    
    public int i() {
      return AppCompatTextView.g(this.a);
    }
    
    public void j(int param1Int) {}
    
    public int k() {
      return AppCompatTextView.i(this.a);
    }
    
    public void l(int param1Int) {
      AppCompatTextView.o(this.a, param1Int);
    }
  }
  
  class c extends b {
    c(AppCompatTextView this$0) {
      super(this$0);
    }
    
    public void f(int param1Int) {
      AppCompatTextView.h(this.b, param1Int);
    }
    
    public void j(int param1Int) {
      AppCompatTextView.f(this.b, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */