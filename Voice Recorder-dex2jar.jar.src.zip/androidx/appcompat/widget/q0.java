package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.view.menu.f;
import androidx.appcompat.view.menu.g;
import java.lang.reflect.Method;

public class q0 extends o0 implements p0 {
  private static Method K;
  
  private p0 J;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        K = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public q0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void R(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      a.a(this.F, (Transition)paramObject); 
  }
  
  public void S(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      a.b(this.F, (Transition)paramObject); 
  }
  
  public void T(p0 paramp0) {
    this.J = paramp0;
  }
  
  public void U(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = K;
      if (method != null)
        try {
          method.invoke(this.F, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      b.a(this.F, paramBoolean);
    } 
  }
  
  public void d(g paramg, MenuItem paramMenuItem) {
    p0 p01 = this.J;
    if (p01 != null)
      p01.d(paramg, paramMenuItem); 
  }
  
  public void g(g paramg, MenuItem paramMenuItem) {
    p0 p01 = this.J;
    if (p01 != null)
      p01.g(paramg, paramMenuItem); 
  }
  
  k0 r(Context paramContext, boolean paramBoolean) {
    c c = new c(paramContext, paramBoolean);
    c.setHoverListener(this);
    return c;
  }
  
  static abstract class a {
    static void a(PopupWindow param1PopupWindow, Transition param1Transition) {
      param1PopupWindow.setEnterTransition(param1Transition);
    }
    
    static void b(PopupWindow param1PopupWindow, Transition param1Transition) {
      param1PopupWindow.setExitTransition(param1Transition);
    }
  }
  
  static abstract class b {
    static void a(PopupWindow param1PopupWindow, boolean param1Boolean) {
      param1PopupWindow.setTouchModal(param1Boolean);
    }
  }
  
  public static class c extends k0 {
    final int n;
    
    final int o;
    
    private p0 p;
    
    private MenuItem q;
    
    public c(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      if (1 == a.a(param1Context.getResources().getConfiguration())) {
        this.n = 21;
        this.o = 22;
        return;
      } 
      this.n = 22;
      this.o = 21;
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_0
      //   1: getfield p : Landroidx/appcompat/widget/p0;
      //   4: ifnull -> 178
      //   7: aload_0
      //   8: invokevirtual getAdapter : ()Landroid/widget/ListAdapter;
      //   11: astore #4
      //   13: aload #4
      //   15: instanceof android/widget/HeaderViewListAdapter
      //   18: ifeq -> 47
      //   21: aload #4
      //   23: checkcast android/widget/HeaderViewListAdapter
      //   26: astore #4
      //   28: aload #4
      //   30: invokevirtual getHeadersCount : ()I
      //   33: istore_2
      //   34: aload #4
      //   36: invokevirtual getWrappedAdapter : ()Landroid/widget/ListAdapter;
      //   39: checkcast androidx/appcompat/view/menu/f
      //   42: astore #4
      //   44: goto -> 56
      //   47: aload #4
      //   49: checkcast androidx/appcompat/view/menu/f
      //   52: astore #4
      //   54: iconst_0
      //   55: istore_2
      //   56: aload_1
      //   57: invokevirtual getAction : ()I
      //   60: bipush #10
      //   62: if_icmpeq -> 113
      //   65: aload_0
      //   66: aload_1
      //   67: invokevirtual getX : ()F
      //   70: f2i
      //   71: aload_1
      //   72: invokevirtual getY : ()F
      //   75: f2i
      //   76: invokevirtual pointToPosition : (II)I
      //   79: istore_3
      //   80: iload_3
      //   81: iconst_m1
      //   82: if_icmpeq -> 113
      //   85: iload_3
      //   86: iload_2
      //   87: isub
      //   88: istore_2
      //   89: iload_2
      //   90: iflt -> 113
      //   93: iload_2
      //   94: aload #4
      //   96: invokevirtual getCount : ()I
      //   99: if_icmpge -> 113
      //   102: aload #4
      //   104: iload_2
      //   105: invokevirtual c : (I)Landroidx/appcompat/view/menu/i;
      //   108: astore #5
      //   110: goto -> 116
      //   113: aconst_null
      //   114: astore #5
      //   116: aload_0
      //   117: getfield q : Landroid/view/MenuItem;
      //   120: astore #6
      //   122: aload #6
      //   124: aload #5
      //   126: if_acmpeq -> 178
      //   129: aload #4
      //   131: invokevirtual b : ()Landroidx/appcompat/view/menu/g;
      //   134: astore #4
      //   136: aload #6
      //   138: ifnull -> 154
      //   141: aload_0
      //   142: getfield p : Landroidx/appcompat/widget/p0;
      //   145: aload #4
      //   147: aload #6
      //   149: invokeinterface g : (Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V
      //   154: aload_0
      //   155: aload #5
      //   157: putfield q : Landroid/view/MenuItem;
      //   160: aload #5
      //   162: ifnull -> 178
      //   165: aload_0
      //   166: getfield p : Landroidx/appcompat/widget/p0;
      //   169: aload #4
      //   171: aload #5
      //   173: invokeinterface d : (Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V
      //   178: aload_0
      //   179: aload_1
      //   180: invokespecial onHoverEvent : (Landroid/view/MotionEvent;)Z
      //   183: ireturn
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      f f;
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.n) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.o) {
        setSelection(-1);
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          f = (f)((HeaderViewListAdapter)listAdapter).getWrappedAdapter();
        } else {
          f = f;
        } 
        f.b().e(false);
        return true;
      } 
      return super.onKeyDown(param1Int, (KeyEvent)f);
    }
    
    public void setHoverListener(p0 param1p0) {
      this.p = param1p0;
    }
    
    static abstract class a {
      static int a(Configuration param2Configuration) {
        return param2Configuration.getLayoutDirection();
      }
    }
  }
  
  static abstract class a {
    static int a(Configuration param1Configuration) {
      return param1Configuration.getLayoutDirection();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\q0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */