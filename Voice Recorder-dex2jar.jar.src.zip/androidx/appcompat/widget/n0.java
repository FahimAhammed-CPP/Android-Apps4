package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import androidx.core.view.p;
import d.j;

public abstract class n0 extends ViewGroup {
  private boolean a = true;
  
  private int b = -1;
  
  private int c = 0;
  
  private int d;
  
  private int e = 8388659;
  
  private int f;
  
  private float g;
  
  private boolean h;
  
  private int[] i;
  
  private int[] j;
  
  private Drawable k;
  
  private int l;
  
  private int m;
  
  private int n;
  
  private int o;
  
  public n0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public n0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    int[] arrayOfInt = j.LinearLayoutCompat;
    b1 b1 = b1.v(paramContext, paramAttributeSet, arrayOfInt, paramInt, 0);
    androidx.core.view.n0.s0((View)this, paramContext, arrayOfInt, paramAttributeSet, b1.r(), paramInt, 0);
    paramInt = b1.k(j.LinearLayoutCompat_android_orientation, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = b1.k(j.LinearLayoutCompat_android_gravity, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = b1.a(j.LinearLayoutCompat_android_baselineAligned, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.g = b1.i(j.LinearLayoutCompat_android_weightSum, -1.0F);
    this.b = b1.k(j.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
    this.h = b1.a(j.LinearLayoutCompat_measureWithLargestChild, false);
    setDividerDrawable(b1.g(j.LinearLayoutCompat_divider));
    this.n = b1.k(j.LinearLayoutCompat_showDividers, 0);
    this.o = b1.f(j.LinearLayoutCompat_dividerPadding, 0);
    b1.w();
  }
  
  private void A(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  private void k(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = s(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.height == -1) {
          int k = a.width;
          a.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, j, 0);
          a.width = k;
        } 
      } 
    } 
  }
  
  private void l(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = s(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.width == -1) {
          int k = a.height;
          a.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          a.height = k;
        } 
      } 
    } 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof a;
  }
  
  void g(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = m1.b((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = s(i);
      if (view != null && view.getVisibility() != 8 && t(i)) {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + a.rightMargin;
        } else {
          k = view.getLeft() - a.leftMargin - this.l;
        } 
        j(paramCanvas, k);
      } 
    } 
    if (t(j)) {
      View view = s(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight();
          int k = this.l;
          i -= k;
        } 
      } else {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          i = view.getLeft() - a.leftMargin;
          k = this.l;
        } else {
          i = view.getRight() + a.rightMargin;
          j(paramCanvas, i);
        } 
        i -= k;
      } 
    } else {
      return;
    } 
    j(paramCanvas, i);
  }
  
  public int getBaseline() {
    if (this.b < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.b;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.b == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.c;
      i = j;
      if (this.d == 1) {
        int m = this.e & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.f;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.f) / 2;
          }  
      } 
      return i + ((a)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.b;
  }
  
  public Drawable getDividerDrawable() {
    return this.k;
  }
  
  public int getDividerPadding() {
    return this.o;
  }
  
  public int getDividerWidth() {
    return this.l;
  }
  
  public int getGravity() {
    return this.e;
  }
  
  public int getOrientation() {
    return this.d;
  }
  
  public int getShowDividers() {
    return this.n;
  }
  
  int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.g;
  }
  
  void h(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = s(i);
      if (view != null && view.getVisibility() != 8 && t(i)) {
        a a = (a)view.getLayoutParams();
        i(paramCanvas, view.getTop() - a.topMargin - this.m);
      } 
    } 
    if (t(j)) {
      View view = s(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.m;
      } else {
        a a = (a)view.getLayoutParams();
        i = view.getBottom() + a.bottomMargin;
      } 
      i(paramCanvas, i);
    } 
  }
  
  void i(Canvas paramCanvas, int paramInt) {
    this.k.setBounds(getPaddingLeft() + this.o, paramInt, getWidth() - getPaddingRight() - this.o, this.m + paramInt);
    this.k.draw(paramCanvas);
  }
  
  void j(Canvas paramCanvas, int paramInt) {
    this.k.setBounds(paramInt, getPaddingTop() + this.o, this.l + paramInt, getHeight() - getPaddingBottom() - this.o);
    this.k.draw(paramCanvas);
  }
  
  protected a m() {
    int i = this.d;
    return (i == 0) ? new a(-2, -2) : ((i == 1) ? new a(-1, -2) : null);
  }
  
  public a n(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  protected a o(ViewGroup.LayoutParams paramLayoutParams) {
    return new a(paramLayoutParams);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.k == null)
      return; 
    if (this.d == 1) {
      h(paramCanvas);
      return;
    } 
    g(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.d == 1) {
      v(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    u(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.d == 1) {
      z(paramInt1, paramInt2);
      return;
    } 
    x(paramInt1, paramInt2);
  }
  
  int p(View paramView, int paramInt) {
    return 0;
  }
  
  int q(View paramView) {
    return 0;
  }
  
  int r(View paramView) {
    return 0;
  }
  
  View s(int paramInt) {
    return getChildAt(paramInt);
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.b = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.k)
      return; 
    this.k = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.l = paramDrawable.getIntrinsicWidth();
      this.m = paramDrawable.getIntrinsicHeight();
    } else {
      this.l = 0;
      this.m = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.o = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.e != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.e = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.e;
    if ((0x800007 & i) != paramInt) {
      this.e = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.h = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.d != paramInt) {
      this.d = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.n)
      requestLayout(); 
    this.n = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.e;
    if ((i & 0x70) != paramInt) {
      this.e = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.g = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  protected boolean t(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.n & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.n & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.n & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  void u(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool1 = m1.b((View)this);
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2;
    int n = getPaddingBottom();
    int i1 = getPaddingBottom();
    int j = getVirtualChildCount();
    paramInt2 = this.e;
    paramInt4 = paramInt2 & 0x70;
    boolean bool2 = this.a;
    int[] arrayOfInt1 = this.i;
    int[] arrayOfInt2 = this.j;
    paramInt2 = p.b(0x800007 & paramInt2, androidx.core.view.n0.E((View)this));
    if (paramInt2 != 1) {
      if (paramInt2 != 5) {
        paramInt2 = getPaddingLeft();
      } else {
        paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.f;
      } 
    } else {
      paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.f) / 2;
    } 
    if (bool1) {
      b1 = j - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    int i = 0;
    paramInt3 = paramInt4;
    paramInt4 = k;
    while (i < j) {
      int i2 = b1 + b2 * i;
      View view = s(i2);
      if (view == null) {
        paramInt2 += y(i2);
      } else if (view.getVisibility() != 8) {
        int i5 = view.getMeasuredWidth();
        int i6 = view.getMeasuredHeight();
        a a = (a)view.getLayoutParams();
        if (bool2 && a.height != -1) {
          i3 = view.getBaseline();
        } else {
          i3 = -1;
        } 
        int i4 = a.gravity;
        paramInt1 = i4;
        if (i4 < 0)
          paramInt1 = paramInt3; 
        paramInt1 &= 0x70;
        if (paramInt1 != 16) {
          if (paramInt1 != 48) {
            if (paramInt1 != 80) {
              paramInt1 = paramInt4;
            } else {
              i4 = m - n - i6 - a.bottomMargin;
              paramInt1 = i4;
              if (i3 != -1) {
                paramInt1 = view.getMeasuredHeight();
                paramInt1 = i4 - arrayOfInt2[2] - paramInt1 - i3;
              } 
            } 
          } else {
            i4 = a.topMargin + paramInt4;
            paramInt1 = i4;
            if (i3 != -1)
              paramInt1 = i4 + arrayOfInt1[1] - i3; 
          } 
        } else {
          paramInt1 = (m - k - i1 - i6) / 2 + paramInt4 + a.topMargin - a.bottomMargin;
        } 
        int i3 = paramInt2;
        if (t(i2))
          i3 = paramInt2 + this.l; 
        paramInt2 = a.leftMargin + i3;
        A(view, paramInt2 + q(view), paramInt1, i5, i6);
        paramInt1 = a.rightMargin;
        i3 = r(view);
        i += p(view, i2);
        paramInt2 += i5 + paramInt1 + i3;
      } 
      i++;
    } 
  }
  
  void v(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = this.e;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.f;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.f) / 2;
    } 
    paramInt2 = 0;
    while (paramInt2 < n) {
      View view = s(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + y(paramInt2);
        paramInt4 = paramInt2;
      } else {
        paramInt3 = paramInt1;
        paramInt4 = paramInt2;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i2 = view.getMeasuredHeight();
          a a = (a)view.getLayoutParams();
          paramInt4 = a.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i1 & 0x800007; 
          paramInt3 = p.b(paramInt3, androidx.core.view.n0.E((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = a.leftMargin + i;
            } else {
              paramInt3 = j - k - i3;
              paramInt4 = a.rightMargin;
              paramInt3 -= paramInt4;
            } 
          } else {
            paramInt3 = (j - i - m - i3) / 2 + i + a.leftMargin;
            paramInt4 = a.rightMargin;
            paramInt3 -= paramInt4;
          } 
          paramInt4 = paramInt1;
          if (t(paramInt2))
            paramInt4 = paramInt1 + this.m; 
          paramInt1 = paramInt4 + a.topMargin;
          A(view, paramInt3, paramInt1 + q(view), i3, i2);
          paramInt3 = a.bottomMargin;
          i3 = r(view);
          paramInt4 = paramInt2 + p(view, paramInt2);
          paramInt3 = paramInt1 + i2 + paramInt3 + i3;
        } 
      } 
      paramInt2 = paramInt4 + 1;
      paramInt1 = paramInt3;
    } 
  }
  
  void w(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  void x(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield f : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #16
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #22
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #21
    //   23: aload_0
    //   24: getfield i : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield j : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield i : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield j : [I
    //   51: aload_0
    //   52: getfield i : [I
    //   55: astore #28
    //   57: aload_0
    //   58: getfield j : [I
    //   61: astore #26
    //   63: aload #28
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #28
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #28
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #28
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #26
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #26
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #26
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #26
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield a : Z
    //   107: istore #24
    //   109: aload_0
    //   110: getfield h : Z
    //   113: istore #25
    //   115: iload #22
    //   117: ldc 1073741824
    //   119: if_icmpne -> 128
    //   122: iconst_1
    //   123: istore #15
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #15
    //   131: fconst_0
    //   132: fstore_3
    //   133: iconst_0
    //   134: istore #8
    //   136: iconst_0
    //   137: istore #7
    //   139: iconst_0
    //   140: istore #13
    //   142: iconst_0
    //   143: istore #6
    //   145: iconst_0
    //   146: istore #11
    //   148: iconst_0
    //   149: istore #12
    //   151: iconst_0
    //   152: istore #9
    //   154: iconst_1
    //   155: istore #5
    //   157: iconst_0
    //   158: istore #10
    //   160: iload #8
    //   162: iload #16
    //   164: if_icmpge -> 845
    //   167: aload_0
    //   168: iload #8
    //   170: invokevirtual s : (I)Landroid/view/View;
    //   173: astore #27
    //   175: aload #27
    //   177: ifnonnull -> 198
    //   180: aload_0
    //   181: aload_0
    //   182: getfield f : I
    //   185: aload_0
    //   186: iload #8
    //   188: invokevirtual y : (I)I
    //   191: iadd
    //   192: putfield f : I
    //   195: goto -> 836
    //   198: aload #27
    //   200: invokevirtual getVisibility : ()I
    //   203: bipush #8
    //   205: if_icmpne -> 224
    //   208: iload #8
    //   210: aload_0
    //   211: aload #27
    //   213: iload #8
    //   215: invokevirtual p : (Landroid/view/View;I)I
    //   218: iadd
    //   219: istore #8
    //   221: goto -> 195
    //   224: aload_0
    //   225: iload #8
    //   227: invokevirtual t : (I)Z
    //   230: ifeq -> 246
    //   233: aload_0
    //   234: aload_0
    //   235: getfield f : I
    //   238: aload_0
    //   239: getfield l : I
    //   242: iadd
    //   243: putfield f : I
    //   246: aload #27
    //   248: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   251: checkcast androidx/appcompat/widget/n0$a
    //   254: astore #29
    //   256: aload #29
    //   258: getfield weight : F
    //   261: fstore #4
    //   263: fload_3
    //   264: fload #4
    //   266: fadd
    //   267: fstore_3
    //   268: iload #22
    //   270: ldc 1073741824
    //   272: if_icmpne -> 381
    //   275: aload #29
    //   277: getfield width : I
    //   280: ifne -> 381
    //   283: fload #4
    //   285: fconst_0
    //   286: fcmpl
    //   287: ifle -> 381
    //   290: iload #15
    //   292: ifeq -> 318
    //   295: aload_0
    //   296: aload_0
    //   297: getfield f : I
    //   300: aload #29
    //   302: getfield leftMargin : I
    //   305: aload #29
    //   307: getfield rightMargin : I
    //   310: iadd
    //   311: iadd
    //   312: putfield f : I
    //   315: goto -> 347
    //   318: aload_0
    //   319: getfield f : I
    //   322: istore #14
    //   324: aload_0
    //   325: iload #14
    //   327: aload #29
    //   329: getfield leftMargin : I
    //   332: iload #14
    //   334: iadd
    //   335: aload #29
    //   337: getfield rightMargin : I
    //   340: iadd
    //   341: invokestatic max : (II)I
    //   344: putfield f : I
    //   347: iload #24
    //   349: ifeq -> 375
    //   352: iconst_0
    //   353: iconst_0
    //   354: invokestatic makeMeasureSpec : (II)I
    //   357: istore #14
    //   359: aload #27
    //   361: iload #14
    //   363: iload #14
    //   365: invokevirtual measure : (II)V
    //   368: iload #7
    //   370: istore #14
    //   372: goto -> 562
    //   375: iconst_1
    //   376: istore #12
    //   378: goto -> 566
    //   381: aload #29
    //   383: getfield width : I
    //   386: ifne -> 409
    //   389: fload #4
    //   391: fconst_0
    //   392: fcmpl
    //   393: ifle -> 409
    //   396: aload #29
    //   398: bipush #-2
    //   400: putfield width : I
    //   403: iconst_0
    //   404: istore #14
    //   406: goto -> 414
    //   409: ldc_w -2147483648
    //   412: istore #14
    //   414: fload_3
    //   415: fconst_0
    //   416: fcmpl
    //   417: ifne -> 429
    //   420: aload_0
    //   421: getfield f : I
    //   424: istore #17
    //   426: goto -> 432
    //   429: iconst_0
    //   430: istore #17
    //   432: aload_0
    //   433: aload #27
    //   435: iload #8
    //   437: iload_1
    //   438: iload #17
    //   440: iload_2
    //   441: iconst_0
    //   442: invokevirtual w : (Landroid/view/View;IIIII)V
    //   445: iload #14
    //   447: ldc_w -2147483648
    //   450: if_icmpeq -> 460
    //   453: aload #29
    //   455: iload #14
    //   457: putfield width : I
    //   460: aload #27
    //   462: invokevirtual getMeasuredWidth : ()I
    //   465: istore #17
    //   467: iload #15
    //   469: ifeq -> 505
    //   472: aload_0
    //   473: aload_0
    //   474: getfield f : I
    //   477: aload #29
    //   479: getfield leftMargin : I
    //   482: iload #17
    //   484: iadd
    //   485: aload #29
    //   487: getfield rightMargin : I
    //   490: iadd
    //   491: aload_0
    //   492: aload #27
    //   494: invokevirtual r : (Landroid/view/View;)I
    //   497: iadd
    //   498: iadd
    //   499: putfield f : I
    //   502: goto -> 544
    //   505: aload_0
    //   506: getfield f : I
    //   509: istore #14
    //   511: aload_0
    //   512: iload #14
    //   514: iload #14
    //   516: iload #17
    //   518: iadd
    //   519: aload #29
    //   521: getfield leftMargin : I
    //   524: iadd
    //   525: aload #29
    //   527: getfield rightMargin : I
    //   530: iadd
    //   531: aload_0
    //   532: aload #27
    //   534: invokevirtual r : (Landroid/view/View;)I
    //   537: iadd
    //   538: invokestatic max : (II)I
    //   541: putfield f : I
    //   544: iload #7
    //   546: istore #14
    //   548: iload #25
    //   550: ifeq -> 562
    //   553: iload #17
    //   555: iload #7
    //   557: invokestatic max : (II)I
    //   560: istore #14
    //   562: iload #14
    //   564: istore #7
    //   566: iload #8
    //   568: istore #18
    //   570: iload #21
    //   572: ldc 1073741824
    //   574: if_icmpeq -> 595
    //   577: aload #29
    //   579: getfield height : I
    //   582: iconst_m1
    //   583: if_icmpne -> 595
    //   586: iconst_1
    //   587: istore #8
    //   589: iconst_1
    //   590: istore #10
    //   592: goto -> 598
    //   595: iconst_0
    //   596: istore #8
    //   598: aload #29
    //   600: getfield topMargin : I
    //   603: aload #29
    //   605: getfield bottomMargin : I
    //   608: iadd
    //   609: istore #14
    //   611: aload #27
    //   613: invokevirtual getMeasuredHeight : ()I
    //   616: iload #14
    //   618: iadd
    //   619: istore #17
    //   621: iload #9
    //   623: aload #27
    //   625: invokevirtual getMeasuredState : ()I
    //   628: invokestatic combineMeasuredStates : (II)I
    //   631: istore #19
    //   633: iload #24
    //   635: ifeq -> 720
    //   638: aload #27
    //   640: invokevirtual getBaseline : ()I
    //   643: istore #23
    //   645: iload #23
    //   647: iconst_m1
    //   648: if_icmpeq -> 720
    //   651: aload #29
    //   653: getfield gravity : I
    //   656: istore #20
    //   658: iload #20
    //   660: istore #9
    //   662: iload #20
    //   664: ifge -> 673
    //   667: aload_0
    //   668: getfield e : I
    //   671: istore #9
    //   673: iload #9
    //   675: bipush #112
    //   677: iand
    //   678: iconst_4
    //   679: ishr
    //   680: bipush #-2
    //   682: iand
    //   683: iconst_1
    //   684: ishr
    //   685: istore #9
    //   687: aload #28
    //   689: iload #9
    //   691: aload #28
    //   693: iload #9
    //   695: iaload
    //   696: iload #23
    //   698: invokestatic max : (II)I
    //   701: iastore
    //   702: aload #26
    //   704: iload #9
    //   706: aload #26
    //   708: iload #9
    //   710: iaload
    //   711: iload #17
    //   713: iload #23
    //   715: isub
    //   716: invokestatic max : (II)I
    //   719: iastore
    //   720: iload #13
    //   722: iload #17
    //   724: invokestatic max : (II)I
    //   727: istore #13
    //   729: iload #5
    //   731: ifeq -> 749
    //   734: aload #29
    //   736: getfield height : I
    //   739: iconst_m1
    //   740: if_icmpne -> 749
    //   743: iconst_1
    //   744: istore #5
    //   746: goto -> 752
    //   749: iconst_0
    //   750: istore #5
    //   752: aload #29
    //   754: getfield weight : F
    //   757: fconst_0
    //   758: fcmpl
    //   759: ifle -> 786
    //   762: iload #8
    //   764: ifeq -> 770
    //   767: goto -> 774
    //   770: iload #17
    //   772: istore #14
    //   774: iload #11
    //   776: iload #14
    //   778: invokestatic max : (II)I
    //   781: istore #8
    //   783: goto -> 811
    //   786: iload #8
    //   788: ifeq -> 794
    //   791: goto -> 798
    //   794: iload #17
    //   796: istore #14
    //   798: iload #6
    //   800: iload #14
    //   802: invokestatic max : (II)I
    //   805: istore #6
    //   807: iload #11
    //   809: istore #8
    //   811: aload_0
    //   812: aload #27
    //   814: iload #18
    //   816: invokevirtual p : (Landroid/view/View;I)I
    //   819: iload #18
    //   821: iadd
    //   822: istore #14
    //   824: iload #19
    //   826: istore #9
    //   828: iload #8
    //   830: istore #11
    //   832: iload #14
    //   834: istore #8
    //   836: iload #8
    //   838: iconst_1
    //   839: iadd
    //   840: istore #8
    //   842: goto -> 160
    //   845: aload_0
    //   846: getfield f : I
    //   849: ifle -> 874
    //   852: aload_0
    //   853: iload #16
    //   855: invokevirtual t : (I)Z
    //   858: ifeq -> 874
    //   861: aload_0
    //   862: aload_0
    //   863: getfield f : I
    //   866: aload_0
    //   867: getfield l : I
    //   870: iadd
    //   871: putfield f : I
    //   874: aload #28
    //   876: iconst_1
    //   877: iaload
    //   878: istore #8
    //   880: iload #8
    //   882: iconst_m1
    //   883: if_icmpne -> 920
    //   886: aload #28
    //   888: iconst_0
    //   889: iaload
    //   890: iconst_m1
    //   891: if_icmpne -> 920
    //   894: aload #28
    //   896: iconst_2
    //   897: iaload
    //   898: iconst_m1
    //   899: if_icmpne -> 920
    //   902: aload #28
    //   904: iconst_3
    //   905: iaload
    //   906: iconst_m1
    //   907: if_icmpeq -> 913
    //   910: goto -> 920
    //   913: iload #13
    //   915: istore #8
    //   917: goto -> 976
    //   920: iload #13
    //   922: aload #28
    //   924: iconst_3
    //   925: iaload
    //   926: aload #28
    //   928: iconst_0
    //   929: iaload
    //   930: iload #8
    //   932: aload #28
    //   934: iconst_2
    //   935: iaload
    //   936: invokestatic max : (II)I
    //   939: invokestatic max : (II)I
    //   942: invokestatic max : (II)I
    //   945: aload #26
    //   947: iconst_3
    //   948: iaload
    //   949: aload #26
    //   951: iconst_0
    //   952: iaload
    //   953: aload #26
    //   955: iconst_1
    //   956: iaload
    //   957: aload #26
    //   959: iconst_2
    //   960: iaload
    //   961: invokestatic max : (II)I
    //   964: invokestatic max : (II)I
    //   967: invokestatic max : (II)I
    //   970: iadd
    //   971: invokestatic max : (II)I
    //   974: istore #8
    //   976: iload #9
    //   978: istore #13
    //   980: iload #8
    //   982: istore #14
    //   984: iload #25
    //   986: ifeq -> 1178
    //   989: iload #22
    //   991: ldc_w -2147483648
    //   994: if_icmpeq -> 1006
    //   997: iload #8
    //   999: istore #14
    //   1001: iload #22
    //   1003: ifne -> 1178
    //   1006: aload_0
    //   1007: iconst_0
    //   1008: putfield f : I
    //   1011: iconst_0
    //   1012: istore #9
    //   1014: iload #8
    //   1016: istore #14
    //   1018: iload #9
    //   1020: iload #16
    //   1022: if_icmpge -> 1178
    //   1025: aload_0
    //   1026: iload #9
    //   1028: invokevirtual s : (I)Landroid/view/View;
    //   1031: astore #27
    //   1033: aload #27
    //   1035: ifnonnull -> 1056
    //   1038: aload_0
    //   1039: aload_0
    //   1040: getfield f : I
    //   1043: aload_0
    //   1044: iload #9
    //   1046: invokevirtual y : (I)I
    //   1049: iadd
    //   1050: putfield f : I
    //   1053: goto -> 1079
    //   1056: aload #27
    //   1058: invokevirtual getVisibility : ()I
    //   1061: bipush #8
    //   1063: if_icmpne -> 1082
    //   1066: iload #9
    //   1068: aload_0
    //   1069: aload #27
    //   1071: iload #9
    //   1073: invokevirtual p : (Landroid/view/View;I)I
    //   1076: iadd
    //   1077: istore #9
    //   1079: goto -> 1169
    //   1082: aload #27
    //   1084: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1087: checkcast androidx/appcompat/widget/n0$a
    //   1090: astore #29
    //   1092: iload #15
    //   1094: ifeq -> 1130
    //   1097: aload_0
    //   1098: aload_0
    //   1099: getfield f : I
    //   1102: aload #29
    //   1104: getfield leftMargin : I
    //   1107: iload #7
    //   1109: iadd
    //   1110: aload #29
    //   1112: getfield rightMargin : I
    //   1115: iadd
    //   1116: aload_0
    //   1117: aload #27
    //   1119: invokevirtual r : (Landroid/view/View;)I
    //   1122: iadd
    //   1123: iadd
    //   1124: putfield f : I
    //   1127: goto -> 1079
    //   1130: aload_0
    //   1131: getfield f : I
    //   1134: istore #14
    //   1136: aload_0
    //   1137: iload #14
    //   1139: iload #14
    //   1141: iload #7
    //   1143: iadd
    //   1144: aload #29
    //   1146: getfield leftMargin : I
    //   1149: iadd
    //   1150: aload #29
    //   1152: getfield rightMargin : I
    //   1155: iadd
    //   1156: aload_0
    //   1157: aload #27
    //   1159: invokevirtual r : (Landroid/view/View;)I
    //   1162: iadd
    //   1163: invokestatic max : (II)I
    //   1166: putfield f : I
    //   1169: iload #9
    //   1171: iconst_1
    //   1172: iadd
    //   1173: istore #9
    //   1175: goto -> 1014
    //   1178: aload_0
    //   1179: getfield f : I
    //   1182: aload_0
    //   1183: invokevirtual getPaddingLeft : ()I
    //   1186: aload_0
    //   1187: invokevirtual getPaddingRight : ()I
    //   1190: iadd
    //   1191: iadd
    //   1192: istore #8
    //   1194: aload_0
    //   1195: iload #8
    //   1197: putfield f : I
    //   1200: iload #8
    //   1202: aload_0
    //   1203: invokevirtual getSuggestedMinimumWidth : ()I
    //   1206: invokestatic max : (II)I
    //   1209: iload_1
    //   1210: iconst_0
    //   1211: invokestatic resolveSizeAndState : (III)I
    //   1214: istore #18
    //   1216: ldc_w 16777215
    //   1219: iload #18
    //   1221: iand
    //   1222: aload_0
    //   1223: getfield f : I
    //   1226: isub
    //   1227: istore #17
    //   1229: iload #12
    //   1231: ifne -> 1367
    //   1234: iload #17
    //   1236: ifeq -> 1248
    //   1239: fload_3
    //   1240: fconst_0
    //   1241: fcmpl
    //   1242: ifle -> 1248
    //   1245: goto -> 1367
    //   1248: iload #6
    //   1250: iload #11
    //   1252: invokestatic max : (II)I
    //   1255: istore #9
    //   1257: iload #25
    //   1259: ifeq -> 1352
    //   1262: iload #22
    //   1264: ldc 1073741824
    //   1266: if_icmpeq -> 1352
    //   1269: iconst_0
    //   1270: istore #6
    //   1272: iload #6
    //   1274: iload #16
    //   1276: if_icmpge -> 1352
    //   1279: aload_0
    //   1280: iload #6
    //   1282: invokevirtual s : (I)Landroid/view/View;
    //   1285: astore #26
    //   1287: aload #26
    //   1289: ifnull -> 1343
    //   1292: aload #26
    //   1294: invokevirtual getVisibility : ()I
    //   1297: bipush #8
    //   1299: if_icmpne -> 1305
    //   1302: goto -> 1343
    //   1305: aload #26
    //   1307: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1310: checkcast androidx/appcompat/widget/n0$a
    //   1313: getfield weight : F
    //   1316: fconst_0
    //   1317: fcmpl
    //   1318: ifle -> 1343
    //   1321: aload #26
    //   1323: iload #7
    //   1325: ldc 1073741824
    //   1327: invokestatic makeMeasureSpec : (II)I
    //   1330: aload #26
    //   1332: invokevirtual getMeasuredHeight : ()I
    //   1335: ldc 1073741824
    //   1337: invokestatic makeMeasureSpec : (II)I
    //   1340: invokevirtual measure : (II)V
    //   1343: iload #6
    //   1345: iconst_1
    //   1346: iadd
    //   1347: istore #6
    //   1349: goto -> 1272
    //   1352: iload #16
    //   1354: istore #8
    //   1356: iload #14
    //   1358: istore #7
    //   1360: iload #9
    //   1362: istore #6
    //   1364: goto -> 2110
    //   1367: aload_0
    //   1368: getfield g : F
    //   1371: fstore #4
    //   1373: fload #4
    //   1375: fconst_0
    //   1376: fcmpl
    //   1377: ifle -> 1383
    //   1380: fload #4
    //   1382: fstore_3
    //   1383: aload #28
    //   1385: iconst_3
    //   1386: iconst_m1
    //   1387: iastore
    //   1388: aload #28
    //   1390: iconst_2
    //   1391: iconst_m1
    //   1392: iastore
    //   1393: aload #28
    //   1395: iconst_1
    //   1396: iconst_m1
    //   1397: iastore
    //   1398: aload #28
    //   1400: iconst_0
    //   1401: iconst_m1
    //   1402: iastore
    //   1403: aload #26
    //   1405: iconst_3
    //   1406: iconst_m1
    //   1407: iastore
    //   1408: aload #26
    //   1410: iconst_2
    //   1411: iconst_m1
    //   1412: iastore
    //   1413: aload #26
    //   1415: iconst_1
    //   1416: iconst_m1
    //   1417: iastore
    //   1418: aload #26
    //   1420: iconst_0
    //   1421: iconst_m1
    //   1422: iastore
    //   1423: aload_0
    //   1424: iconst_0
    //   1425: putfield f : I
    //   1428: iload #13
    //   1430: istore #9
    //   1432: iconst_m1
    //   1433: istore #11
    //   1435: iconst_0
    //   1436: istore #13
    //   1438: iload #5
    //   1440: istore #8
    //   1442: iload #16
    //   1444: istore #7
    //   1446: iload #9
    //   1448: istore #5
    //   1450: iload #6
    //   1452: istore #9
    //   1454: iload #17
    //   1456: istore #6
    //   1458: iload #13
    //   1460: iload #7
    //   1462: if_icmpge -> 1970
    //   1465: aload_0
    //   1466: iload #13
    //   1468: invokevirtual s : (I)Landroid/view/View;
    //   1471: astore #27
    //   1473: aload #27
    //   1475: ifnull -> 1961
    //   1478: aload #27
    //   1480: invokevirtual getVisibility : ()I
    //   1483: bipush #8
    //   1485: if_icmpne -> 1491
    //   1488: goto -> 1961
    //   1491: aload #27
    //   1493: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1496: checkcast androidx/appcompat/widget/n0$a
    //   1499: astore #29
    //   1501: aload #29
    //   1503: getfield weight : F
    //   1506: fstore #4
    //   1508: fload #4
    //   1510: fconst_0
    //   1511: fcmpl
    //   1512: ifle -> 1675
    //   1515: iload #6
    //   1517: i2f
    //   1518: fload #4
    //   1520: fmul
    //   1521: fload_3
    //   1522: fdiv
    //   1523: f2i
    //   1524: istore #14
    //   1526: iload_2
    //   1527: aload_0
    //   1528: invokevirtual getPaddingTop : ()I
    //   1531: aload_0
    //   1532: invokevirtual getPaddingBottom : ()I
    //   1535: iadd
    //   1536: aload #29
    //   1538: getfield topMargin : I
    //   1541: iadd
    //   1542: aload #29
    //   1544: getfield bottomMargin : I
    //   1547: iadd
    //   1548: aload #29
    //   1550: getfield height : I
    //   1553: invokestatic getChildMeasureSpec : (III)I
    //   1556: istore #17
    //   1558: aload #29
    //   1560: getfield width : I
    //   1563: ifne -> 1608
    //   1566: iload #22
    //   1568: ldc 1073741824
    //   1570: if_icmpeq -> 1576
    //   1573: goto -> 1608
    //   1576: iload #14
    //   1578: ifle -> 1588
    //   1581: iload #14
    //   1583: istore #12
    //   1585: goto -> 1591
    //   1588: iconst_0
    //   1589: istore #12
    //   1591: aload #27
    //   1593: iload #12
    //   1595: ldc 1073741824
    //   1597: invokestatic makeMeasureSpec : (II)I
    //   1600: iload #17
    //   1602: invokevirtual measure : (II)V
    //   1605: goto -> 1644
    //   1608: aload #27
    //   1610: invokevirtual getMeasuredWidth : ()I
    //   1613: iload #14
    //   1615: iadd
    //   1616: istore #16
    //   1618: iload #16
    //   1620: istore #12
    //   1622: iload #16
    //   1624: ifge -> 1630
    //   1627: iconst_0
    //   1628: istore #12
    //   1630: aload #27
    //   1632: iload #12
    //   1634: ldc 1073741824
    //   1636: invokestatic makeMeasureSpec : (II)I
    //   1639: iload #17
    //   1641: invokevirtual measure : (II)V
    //   1644: iload #5
    //   1646: aload #27
    //   1648: invokevirtual getMeasuredState : ()I
    //   1651: ldc_w -16777216
    //   1654: iand
    //   1655: invokestatic combineMeasuredStates : (II)I
    //   1658: istore #5
    //   1660: fload_3
    //   1661: fload #4
    //   1663: fsub
    //   1664: fstore_3
    //   1665: iload #6
    //   1667: iload #14
    //   1669: isub
    //   1670: istore #6
    //   1672: goto -> 1675
    //   1675: iload #15
    //   1677: ifeq -> 1716
    //   1680: aload_0
    //   1681: aload_0
    //   1682: getfield f : I
    //   1685: aload #27
    //   1687: invokevirtual getMeasuredWidth : ()I
    //   1690: aload #29
    //   1692: getfield leftMargin : I
    //   1695: iadd
    //   1696: aload #29
    //   1698: getfield rightMargin : I
    //   1701: iadd
    //   1702: aload_0
    //   1703: aload #27
    //   1705: invokevirtual r : (Landroid/view/View;)I
    //   1708: iadd
    //   1709: iadd
    //   1710: putfield f : I
    //   1713: goto -> 1758
    //   1716: aload_0
    //   1717: getfield f : I
    //   1720: istore #12
    //   1722: aload_0
    //   1723: iload #12
    //   1725: aload #27
    //   1727: invokevirtual getMeasuredWidth : ()I
    //   1730: iload #12
    //   1732: iadd
    //   1733: aload #29
    //   1735: getfield leftMargin : I
    //   1738: iadd
    //   1739: aload #29
    //   1741: getfield rightMargin : I
    //   1744: iadd
    //   1745: aload_0
    //   1746: aload #27
    //   1748: invokevirtual r : (Landroid/view/View;)I
    //   1751: iadd
    //   1752: invokestatic max : (II)I
    //   1755: putfield f : I
    //   1758: iload #21
    //   1760: ldc 1073741824
    //   1762: if_icmpeq -> 1780
    //   1765: aload #29
    //   1767: getfield height : I
    //   1770: iconst_m1
    //   1771: if_icmpne -> 1780
    //   1774: iconst_1
    //   1775: istore #12
    //   1777: goto -> 1783
    //   1780: iconst_0
    //   1781: istore #12
    //   1783: aload #29
    //   1785: getfield topMargin : I
    //   1788: aload #29
    //   1790: getfield bottomMargin : I
    //   1793: iadd
    //   1794: istore #17
    //   1796: aload #27
    //   1798: invokevirtual getMeasuredHeight : ()I
    //   1801: iload #17
    //   1803: iadd
    //   1804: istore #16
    //   1806: iload #11
    //   1808: iload #16
    //   1810: invokestatic max : (II)I
    //   1813: istore #14
    //   1815: iload #12
    //   1817: ifeq -> 1827
    //   1820: iload #17
    //   1822: istore #11
    //   1824: goto -> 1831
    //   1827: iload #16
    //   1829: istore #11
    //   1831: iload #9
    //   1833: iload #11
    //   1835: invokestatic max : (II)I
    //   1838: istore #11
    //   1840: iload #8
    //   1842: ifeq -> 1860
    //   1845: aload #29
    //   1847: getfield height : I
    //   1850: iconst_m1
    //   1851: if_icmpne -> 1860
    //   1854: iconst_1
    //   1855: istore #8
    //   1857: goto -> 1863
    //   1860: iconst_0
    //   1861: istore #8
    //   1863: iload #24
    //   1865: ifeq -> 1950
    //   1868: aload #27
    //   1870: invokevirtual getBaseline : ()I
    //   1873: istore #17
    //   1875: iload #17
    //   1877: iconst_m1
    //   1878: if_icmpeq -> 1950
    //   1881: aload #29
    //   1883: getfield gravity : I
    //   1886: istore #12
    //   1888: iload #12
    //   1890: istore #9
    //   1892: iload #12
    //   1894: ifge -> 1903
    //   1897: aload_0
    //   1898: getfield e : I
    //   1901: istore #9
    //   1903: iload #9
    //   1905: bipush #112
    //   1907: iand
    //   1908: iconst_4
    //   1909: ishr
    //   1910: bipush #-2
    //   1912: iand
    //   1913: iconst_1
    //   1914: ishr
    //   1915: istore #9
    //   1917: aload #28
    //   1919: iload #9
    //   1921: aload #28
    //   1923: iload #9
    //   1925: iaload
    //   1926: iload #17
    //   1928: invokestatic max : (II)I
    //   1931: iastore
    //   1932: aload #26
    //   1934: iload #9
    //   1936: aload #26
    //   1938: iload #9
    //   1940: iaload
    //   1941: iload #16
    //   1943: iload #17
    //   1945: isub
    //   1946: invokestatic max : (II)I
    //   1949: iastore
    //   1950: iload #11
    //   1952: istore #9
    //   1954: iload #14
    //   1956: istore #11
    //   1958: goto -> 1961
    //   1961: iload #13
    //   1963: iconst_1
    //   1964: iadd
    //   1965: istore #13
    //   1967: goto -> 1458
    //   1970: aload_0
    //   1971: aload_0
    //   1972: getfield f : I
    //   1975: aload_0
    //   1976: invokevirtual getPaddingLeft : ()I
    //   1979: aload_0
    //   1980: invokevirtual getPaddingRight : ()I
    //   1983: iadd
    //   1984: iadd
    //   1985: putfield f : I
    //   1988: aload #28
    //   1990: iconst_1
    //   1991: iaload
    //   1992: istore #6
    //   1994: iload #6
    //   1996: iconst_m1
    //   1997: if_icmpne -> 2034
    //   2000: aload #28
    //   2002: iconst_0
    //   2003: iaload
    //   2004: iconst_m1
    //   2005: if_icmpne -> 2034
    //   2008: aload #28
    //   2010: iconst_2
    //   2011: iaload
    //   2012: iconst_m1
    //   2013: if_icmpne -> 2034
    //   2016: aload #28
    //   2018: iconst_3
    //   2019: iaload
    //   2020: iconst_m1
    //   2021: if_icmpeq -> 2027
    //   2024: goto -> 2034
    //   2027: iload #11
    //   2029: istore #6
    //   2031: goto -> 2090
    //   2034: iload #11
    //   2036: aload #28
    //   2038: iconst_3
    //   2039: iaload
    //   2040: aload #28
    //   2042: iconst_0
    //   2043: iaload
    //   2044: iload #6
    //   2046: aload #28
    //   2048: iconst_2
    //   2049: iaload
    //   2050: invokestatic max : (II)I
    //   2053: invokestatic max : (II)I
    //   2056: invokestatic max : (II)I
    //   2059: aload #26
    //   2061: iconst_3
    //   2062: iaload
    //   2063: aload #26
    //   2065: iconst_0
    //   2066: iaload
    //   2067: aload #26
    //   2069: iconst_1
    //   2070: iaload
    //   2071: aload #26
    //   2073: iconst_2
    //   2074: iaload
    //   2075: invokestatic max : (II)I
    //   2078: invokestatic max : (II)I
    //   2081: invokestatic max : (II)I
    //   2084: iadd
    //   2085: invokestatic max : (II)I
    //   2088: istore #6
    //   2090: iload #5
    //   2092: istore #13
    //   2094: iload #8
    //   2096: istore #5
    //   2098: iload #7
    //   2100: istore #8
    //   2102: iload #6
    //   2104: istore #7
    //   2106: iload #9
    //   2108: istore #6
    //   2110: iload #5
    //   2112: ifne -> 2125
    //   2115: iload #21
    //   2117: ldc 1073741824
    //   2119: if_icmpeq -> 2125
    //   2122: goto -> 2129
    //   2125: iload #7
    //   2127: istore #6
    //   2129: aload_0
    //   2130: iload #18
    //   2132: iload #13
    //   2134: ldc_w -16777216
    //   2137: iand
    //   2138: ior
    //   2139: iload #6
    //   2141: aload_0
    //   2142: invokevirtual getPaddingTop : ()I
    //   2145: aload_0
    //   2146: invokevirtual getPaddingBottom : ()I
    //   2149: iadd
    //   2150: iadd
    //   2151: aload_0
    //   2152: invokevirtual getSuggestedMinimumHeight : ()I
    //   2155: invokestatic max : (II)I
    //   2158: iload_2
    //   2159: iload #13
    //   2161: bipush #16
    //   2163: ishl
    //   2164: invokestatic resolveSizeAndState : (III)I
    //   2167: invokevirtual setMeasuredDimension : (II)V
    //   2170: iload #10
    //   2172: ifeq -> 2182
    //   2175: aload_0
    //   2176: iload #8
    //   2178: iload_1
    //   2179: invokespecial k : (II)V
    //   2182: return
  }
  
  int y(int paramInt) {
    return 0;
  }
  
  void z(int paramInt1, int paramInt2) {
    this.f = 0;
    int i2 = getVirtualChildCount();
    int i7 = View.MeasureSpec.getMode(paramInt1);
    int i5 = View.MeasureSpec.getMode(paramInt2);
    int i8 = this.b;
    boolean bool1 = this.h;
    float f = 0.0F;
    int i = 0;
    int i4 = 0;
    int n = 0;
    int j = 0;
    int m = 0;
    int i1 = 0;
    int i3 = 0;
    int k = 1;
    boolean bool = false;
    while (i1 < i2) {
      View view = s(i1);
      if (view == null) {
        this.f += y(i1);
      } else if (view.getVisibility() == 8) {
        i1 += p(view, i1);
      } else {
        if (t(i1))
          this.f += this.m; 
        a a = (a)view.getLayoutParams();
        float f1 = a.weight;
        f += f1;
        if (i5 == 1073741824 && a.height == 0 && f1 > 0.0F) {
          i3 = this.f;
          this.f = Math.max(i3, a.topMargin + i3 + a.bottomMargin);
          i3 = 1;
        } else {
          if (a.height == 0 && f1 > 0.0F) {
            a.height = -2;
            i10 = 0;
          } else {
            i10 = Integer.MIN_VALUE;
          } 
          if (f == 0.0F) {
            i11 = this.f;
          } else {
            i11 = 0;
          } 
          w(view, i1, paramInt1, 0, paramInt2, i11);
          if (i10 != Integer.MIN_VALUE)
            a.height = i10; 
          int i10 = view.getMeasuredHeight();
          int i11 = this.f;
          this.f = Math.max(i11, i11 + i10 + a.topMargin + a.bottomMargin + r(view));
          if (bool1)
            n = Math.max(i10, n); 
        } 
        int i9 = i1;
        if (i8 >= 0 && i8 == i9 + 1)
          this.c = this.f; 
        if (i9 >= i8 || a.weight <= 0.0F) {
          if (i7 != 1073741824 && a.width == -1) {
            i1 = 1;
            bool = true;
          } else {
            i1 = 0;
          } 
          int i10 = a.leftMargin + a.rightMargin;
          int i11 = view.getMeasuredWidth() + i10;
          i4 = Math.max(i4, i11);
          int i12 = View.combineMeasuredStates(i, view.getMeasuredState());
          if (k && a.width == -1) {
            i = 1;
          } else {
            i = 0;
          } 
          if (a.weight > 0.0F) {
            if (i1 == 0)
              i10 = i11; 
            j = Math.max(j, i10);
            k = m;
          } else {
            if (i1 == 0)
              i10 = i11; 
            k = Math.max(m, i10);
          } 
          i1 = p(view, i9);
          m = k;
          i10 = i12;
          i1 += i9;
          k = i;
          i = i10;
        } else {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        } 
      } 
      i1++;
    } 
    if (this.f > 0 && t(i2))
      this.f += this.m; 
    if (bool1 && (i5 == Integer.MIN_VALUE || i5 == 0)) {
      this.f = 0;
      for (i1 = 0; i1 < i2; i1++) {
        View view = s(i1);
        if (view == null) {
          this.f += y(i1);
        } else if (view.getVisibility() == 8) {
          i1 += p(view, i1);
        } else {
          a a = (a)view.getLayoutParams();
          int i9 = this.f;
          this.f = Math.max(i9, i9 + n + a.topMargin + a.bottomMargin + r(view));
        } 
      } 
    } 
    i1 = this.f + getPaddingTop() + getPaddingBottom();
    this.f = i1;
    int i6 = View.resolveSizeAndState(Math.max(i1, getSuggestedMinimumHeight()), paramInt2, 0);
    i1 = (0xFFFFFF & i6) - this.f;
    if (i3 != 0 || (i1 != 0 && f > 0.0F)) {
      float f1 = this.g;
      if (f1 > 0.0F)
        f = f1; 
      this.f = 0;
      j = i1;
      i1 = 0;
      n = i4;
      while (i1 < i2) {
        View view = s(i1);
        if (view.getVisibility() != 8) {
          a a = (a)view.getLayoutParams();
          f1 = a.weight;
          if (f1 > 0.0F) {
            i4 = (int)(j * f1 / f);
            int i10 = getPaddingLeft();
            int i11 = getPaddingRight();
            int i12 = a.leftMargin;
            i8 = a.rightMargin;
            int i13 = a.width;
            i3 = j - i4;
            i10 = ViewGroup.getChildMeasureSpec(paramInt1, i10 + i11 + i12 + i8, i13);
            if (a.height != 0 || i5 != 1073741824) {
              i4 = view.getMeasuredHeight() + i4;
              j = i4;
              if (i4 < 0)
                j = 0; 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } else {
              if (i4 > 0) {
                j = i4;
              } else {
                j = 0;
              } 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } 
            i = View.combineMeasuredStates(i, view.getMeasuredState() & 0xFFFFFF00);
            f -= f1;
            j = i3;
          } 
          i4 = a.leftMargin + a.rightMargin;
          int i9 = view.getMeasuredWidth() + i4;
          i3 = Math.max(n, i9);
          if (i7 != 1073741824 && a.width == -1) {
            n = 1;
          } else {
            n = 0;
          } 
          if (n != 0) {
            n = i4;
          } else {
            n = i9;
          } 
          m = Math.max(m, n);
          if (k != 0 && a.width == -1) {
            k = 1;
          } else {
            k = 0;
          } 
          n = this.f;
          this.f = Math.max(n, view.getMeasuredHeight() + n + a.topMargin + a.bottomMargin + r(view));
          n = i3;
        } 
        i1++;
      } 
      this.f += getPaddingTop() + getPaddingBottom();
      j = i;
      i = m;
    } else {
      m = Math.max(m, j);
      if (bool1 && i5 != 1073741824)
        for (j = 0; j < i2; j++) {
          View view = s(j);
          if (view != null && view.getVisibility() != 8 && ((a)view.getLayoutParams()).weight > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824)); 
        }  
      j = i;
      i = m;
      n = i4;
    } 
    if (k != 0 || i7 == 1073741824)
      i = n; 
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), paramInt1, j), i6);
    if (bool)
      l(i2, paramInt2); 
  }
  
  public static class a extends LinearLayout.LayoutParams {
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */