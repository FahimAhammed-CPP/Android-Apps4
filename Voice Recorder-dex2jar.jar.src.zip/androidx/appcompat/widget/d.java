package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.view.n0;
import d.j;

class d {
  private final View a;
  
  private final h b;
  
  private int c = -1;
  
  private z0 d;
  
  private z0 e;
  
  private z0 f;
  
  d(View paramView) {
    this.a = paramView;
    this.b = h.b();
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new z0(); 
    z0 z01 = this.f;
    z01.a();
    ColorStateList colorStateList = n0.u(this.a);
    if (colorStateList != null) {
      z01.d = true;
      z01.a = colorStateList;
    } 
    PorterDuff.Mode mode = n0.v(this.a);
    if (mode != null) {
      z01.c = true;
      z01.b = mode;
    } 
    if (z01.d || z01.c) {
      h.i(paramDrawable, z01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.d != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      z0 z01 = this.e;
      if (z01 != null) {
        h.i(drawable, z01, this.a.getDrawableState());
        return;
      } 
      z01 = this.d;
      if (z01 != null)
        h.i(drawable, z01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    z0 z01 = this.e;
    return (z01 != null) ? z01.a : null;
  }
  
  PorterDuff.Mode d() {
    z0 z01 = this.e;
    return (z01 != null) ? z01.b : null;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.ViewBackgroundHelper;
    b1 b1 = b1.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    View view = this.a;
    n0.s0(view, view.getContext(), arrayOfInt, paramAttributeSet, b1.r(), paramInt, 0);
    try {
      paramInt = j.ViewBackgroundHelper_android_background;
      if (b1.s(paramInt)) {
        this.c = b1.n(paramInt, -1);
        ColorStateList colorStateList = this.b.f(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.ViewBackgroundHelper_backgroundTint;
      if (b1.s(paramInt))
        n0.z0(this.a, b1.c(paramInt)); 
      paramInt = j.ViewBackgroundHelper_backgroundTintMode;
      if (b1.s(paramInt))
        n0.A0(this.a, j0.e(b1.k(paramInt, -1), null)); 
      return;
    } finally {
      b1.w();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    h h1 = this.b;
    if (h1 != null) {
      ColorStateList colorStateList = h1.f(this.a.getContext(), paramInt);
    } else {
      h1 = null;
    } 
    h((ColorStateList)h1);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new z0(); 
      z0 z01 = this.d;
      z01.a = paramColorStateList;
      z01.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new z0(); 
    z0 z01 = this.e;
    z01.a = paramColorStateList;
    z01.d = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new z0(); 
    z0 z01 = this.e;
    z01.b = paramMode;
    z01.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */