package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.LocaleList;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import androidx.core.content.res.h;
import androidx.core.view.n0;
import d.j;
import java.lang.ref.WeakReference;
import java.util.Locale;

class x {
  private final TextView a;
  
  private z0 b;
  
  private z0 c;
  
  private z0 d;
  
  private z0 e;
  
  private z0 f;
  
  private z0 g;
  
  private z0 h;
  
  private final y i;
  
  private int j = 0;
  
  private int k = -1;
  
  private Typeface l;
  
  private boolean m;
  
  x(TextView paramTextView) {
    this.a = paramTextView;
    this.i = new y(paramTextView);
  }
  
  private void B(int paramInt, float paramFloat) {
    this.i.t(paramInt, paramFloat);
  }
  
  private void C(Context paramContext, b1 paramb1) {
    this.j = paramb1.k(j.TextAppearance_android_textStyle, this.j);
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 28) {
      int k = paramb1.k(j.TextAppearance_android_textFontWeight, -1);
      this.k = k;
      if (k != -1)
        this.j = this.j & 0x2 | 0x0; 
    } 
    int i = j.TextAppearance_android_fontFamily;
    if (paramb1.s(i) || paramb1.s(j.TextAppearance_fontFamily)) {
      this.l = null;
      int k = j.TextAppearance_fontFamily;
      if (paramb1.s(k))
        i = k; 
      k = this.k;
      int m = this.j;
      if (!paramContext.isRestricted()) {
        a a = new a(this, k, m, new WeakReference<TextView>(this.a));
        try {
          boolean bool1;
          Typeface typeface = paramb1.j(i, this.j, a);
          if (typeface != null)
            if (j >= 28 && this.k != -1) {
              typeface = Typeface.create(typeface, 0);
              k = this.k;
              if ((this.j & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              } 
              this.l = g.a(typeface, k, bool1);
            } else {
              this.l = typeface;
            }  
          if (this.l == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.m = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.l == null) {
        String str = paramb1.o(i);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.k != -1) {
            typeface = Typeface.create(str, 0);
            i = this.k;
            boolean bool1 = bool;
            if ((this.j & 0x2) != 0)
              bool1 = true; 
            this.l = g.a(typeface, i, bool1);
            return;
          } 
          this.l = Typeface.create((String)typeface, this.j);
        } 
      } 
      return;
    } 
    i = j.TextAppearance_android_typeface;
    if (paramb1.s(i)) {
      this.m = false;
      i = paramb1.k(i, 1);
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          this.l = Typeface.MONOSPACE;
          return;
        } 
        this.l = Typeface.SERIF;
        return;
      } 
      this.l = Typeface.SANS_SERIF;
    } 
  }
  
  private void a(Drawable paramDrawable, z0 paramz0) {
    if (paramDrawable != null && paramz0 != null)
      h.i(paramDrawable, paramz0, this.a.getDrawableState()); 
  }
  
  private static z0 d(Context paramContext, h paramh, int paramInt) {
    ColorStateList colorStateList = paramh.f(paramContext, paramInt);
    if (colorStateList != null) {
      z0 z01 = new z0();
      z01.d = true;
      z01.a = colorStateList;
      return z01;
    } 
    return null;
  }
  
  private void y(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4, Drawable paramDrawable5, Drawable paramDrawable6) {
    TextView textView;
    Drawable[] arrayOfDrawable;
    if (paramDrawable5 != null || paramDrawable6 != null) {
      arrayOfDrawable = c.a(this.a);
      textView = this.a;
      if (paramDrawable5 == null)
        paramDrawable5 = arrayOfDrawable[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable[1]; 
      if (paramDrawable6 == null)
        paramDrawable6 = arrayOfDrawable[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable[3]; 
      c.b(textView, paramDrawable5, paramDrawable2, paramDrawable6, paramDrawable4);
      return;
    } 
    if (textView != null || paramDrawable2 != null || arrayOfDrawable != null || paramDrawable4 != null) {
      Drawable drawable1;
      Drawable drawable2;
      Drawable[] arrayOfDrawable1 = c.a(this.a);
      paramDrawable5 = arrayOfDrawable1[0];
      if (paramDrawable5 != null || arrayOfDrawable1[2] != null) {
        textView = this.a;
        if (paramDrawable2 == null)
          paramDrawable2 = arrayOfDrawable1[1]; 
        drawable2 = arrayOfDrawable1[2];
        if (paramDrawable4 == null)
          paramDrawable4 = arrayOfDrawable1[3]; 
        c.b(textView, paramDrawable5, paramDrawable2, drawable2, paramDrawable4);
        return;
      } 
      arrayOfDrawable1 = this.a.getCompoundDrawables();
      TextView textView1 = this.a;
      if (textView == null)
        drawable1 = arrayOfDrawable1[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable1[1]; 
      if (drawable2 == null)
        drawable2 = arrayOfDrawable1[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable1[3]; 
      textView1.setCompoundDrawablesWithIntrinsicBounds(drawable1, paramDrawable2, drawable2, paramDrawable4);
      return;
    } 
  }
  
  private void z() {
    z0 z01 = this.h;
    this.b = z01;
    this.c = z01;
    this.d = z01;
    this.e = z01;
    this.f = z01;
    this.g = z01;
  }
  
  void A(int paramInt, float paramFloat) {
    if (!m1.b && !l())
      B(paramInt, paramFloat); 
  }
  
  void b() {
    if (this.b != null || this.c != null || this.d != null || this.e != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.b);
      a(arrayOfDrawable[1], this.c);
      a(arrayOfDrawable[2], this.d);
      a(arrayOfDrawable[3], this.e);
    } 
    if (this.f != null || this.g != null) {
      Drawable[] arrayOfDrawable = c.a(this.a);
      a(arrayOfDrawable[0], this.f);
      a(arrayOfDrawable[2], this.g);
    } 
  }
  
  void c() {
    this.i.a();
  }
  
  int e() {
    return this.i.f();
  }
  
  int f() {
    return this.i.g();
  }
  
  int g() {
    return this.i.h();
  }
  
  int[] h() {
    return this.i.i();
  }
  
  int i() {
    return this.i.j();
  }
  
  ColorStateList j() {
    z0 z01 = this.h;
    return (z01 != null) ? z01.a : null;
  }
  
  PorterDuff.Mode k() {
    z0 z01 = this.h;
    return (z01 != null) ? z01.b : null;
  }
  
  boolean l() {
    return this.i.n();
  }
  
  void m(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #17
    //   9: invokestatic b : ()Landroidx/appcompat/widget/h;
    //   12: astore #16
    //   14: getstatic d/j.AppCompatTextHelper : [I
    //   17: astore #8
    //   19: aload #17
    //   21: aload_1
    //   22: aload #8
    //   24: iload_2
    //   25: iconst_0
    //   26: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/b1;
    //   29: astore #9
    //   31: aload_0
    //   32: getfield a : Landroid/widget/TextView;
    //   35: astore #10
    //   37: aload #10
    //   39: aload #10
    //   41: invokevirtual getContext : ()Landroid/content/Context;
    //   44: aload #8
    //   46: aload_1
    //   47: aload #9
    //   49: invokevirtual r : ()Landroid/content/res/TypedArray;
    //   52: iload_2
    //   53: iconst_0
    //   54: invokestatic s0 : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   57: aload #9
    //   59: getstatic d/j.AppCompatTextHelper_android_textAppearance : I
    //   62: iconst_m1
    //   63: invokevirtual n : (II)I
    //   66: istore_3
    //   67: getstatic d/j.AppCompatTextHelper_android_drawableLeft : I
    //   70: istore #4
    //   72: aload #9
    //   74: iload #4
    //   76: invokevirtual s : (I)Z
    //   79: ifeq -> 101
    //   82: aload_0
    //   83: aload #17
    //   85: aload #16
    //   87: aload #9
    //   89: iload #4
    //   91: iconst_0
    //   92: invokevirtual n : (II)I
    //   95: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/h;I)Landroidx/appcompat/widget/z0;
    //   98: putfield b : Landroidx/appcompat/widget/z0;
    //   101: getstatic d/j.AppCompatTextHelper_android_drawableTop : I
    //   104: istore #4
    //   106: aload #9
    //   108: iload #4
    //   110: invokevirtual s : (I)Z
    //   113: ifeq -> 135
    //   116: aload_0
    //   117: aload #17
    //   119: aload #16
    //   121: aload #9
    //   123: iload #4
    //   125: iconst_0
    //   126: invokevirtual n : (II)I
    //   129: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/h;I)Landroidx/appcompat/widget/z0;
    //   132: putfield c : Landroidx/appcompat/widget/z0;
    //   135: getstatic d/j.AppCompatTextHelper_android_drawableRight : I
    //   138: istore #4
    //   140: aload #9
    //   142: iload #4
    //   144: invokevirtual s : (I)Z
    //   147: ifeq -> 169
    //   150: aload_0
    //   151: aload #17
    //   153: aload #16
    //   155: aload #9
    //   157: iload #4
    //   159: iconst_0
    //   160: invokevirtual n : (II)I
    //   163: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/h;I)Landroidx/appcompat/widget/z0;
    //   166: putfield d : Landroidx/appcompat/widget/z0;
    //   169: getstatic d/j.AppCompatTextHelper_android_drawableBottom : I
    //   172: istore #4
    //   174: aload #9
    //   176: iload #4
    //   178: invokevirtual s : (I)Z
    //   181: ifeq -> 203
    //   184: aload_0
    //   185: aload #17
    //   187: aload #16
    //   189: aload #9
    //   191: iload #4
    //   193: iconst_0
    //   194: invokevirtual n : (II)I
    //   197: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/h;I)Landroidx/appcompat/widget/z0;
    //   200: putfield e : Landroidx/appcompat/widget/z0;
    //   203: getstatic android/os/Build$VERSION.SDK_INT : I
    //   206: istore #4
    //   208: getstatic d/j.AppCompatTextHelper_android_drawableStart : I
    //   211: istore #5
    //   213: aload #9
    //   215: iload #5
    //   217: invokevirtual s : (I)Z
    //   220: ifeq -> 242
    //   223: aload_0
    //   224: aload #17
    //   226: aload #16
    //   228: aload #9
    //   230: iload #5
    //   232: iconst_0
    //   233: invokevirtual n : (II)I
    //   236: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/h;I)Landroidx/appcompat/widget/z0;
    //   239: putfield f : Landroidx/appcompat/widget/z0;
    //   242: getstatic d/j.AppCompatTextHelper_android_drawableEnd : I
    //   245: istore #5
    //   247: aload #9
    //   249: iload #5
    //   251: invokevirtual s : (I)Z
    //   254: ifeq -> 276
    //   257: aload_0
    //   258: aload #17
    //   260: aload #16
    //   262: aload #9
    //   264: iload #5
    //   266: iconst_0
    //   267: invokevirtual n : (II)I
    //   270: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/h;I)Landroidx/appcompat/widget/z0;
    //   273: putfield g : Landroidx/appcompat/widget/z0;
    //   276: aload #9
    //   278: invokevirtual w : ()V
    //   281: aload_0
    //   282: getfield a : Landroid/widget/TextView;
    //   285: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   288: instanceof android/text/method/PasswordTransformationMethod
    //   291: istore #7
    //   293: iload_3
    //   294: iconst_m1
    //   295: if_icmpeq -> 560
    //   298: aload #17
    //   300: iload_3
    //   301: getstatic d/j.TextAppearance : [I
    //   304: invokestatic t : (Landroid/content/Context;I[I)Landroidx/appcompat/widget/b1;
    //   307: astore #14
    //   309: iload #7
    //   311: ifne -> 341
    //   314: getstatic d/j.TextAppearance_textAllCaps : I
    //   317: istore_3
    //   318: aload #14
    //   320: iload_3
    //   321: invokevirtual s : (I)Z
    //   324: ifeq -> 341
    //   327: aload #14
    //   329: iload_3
    //   330: iconst_0
    //   331: invokevirtual a : (IZ)Z
    //   334: istore #6
    //   336: iconst_1
    //   337: istore_3
    //   338: goto -> 346
    //   341: iconst_0
    //   342: istore #6
    //   344: iconst_0
    //   345: istore_3
    //   346: aload_0
    //   347: aload #17
    //   349: aload #14
    //   351: invokespecial C : (Landroid/content/Context;Landroidx/appcompat/widget/b1;)V
    //   354: iload #4
    //   356: bipush #23
    //   358: if_icmpge -> 464
    //   361: getstatic d/j.TextAppearance_android_textColor : I
    //   364: istore #5
    //   366: aload #14
    //   368: iload #5
    //   370: invokevirtual s : (I)Z
    //   373: ifeq -> 388
    //   376: aload #14
    //   378: iload #5
    //   380: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   383: astore #8
    //   385: goto -> 391
    //   388: aconst_null
    //   389: astore #8
    //   391: getstatic d/j.TextAppearance_android_textColorHint : I
    //   394: istore #5
    //   396: aload #14
    //   398: iload #5
    //   400: invokevirtual s : (I)Z
    //   403: ifeq -> 418
    //   406: aload #14
    //   408: iload #5
    //   410: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   413: astore #9
    //   415: goto -> 421
    //   418: aconst_null
    //   419: astore #9
    //   421: getstatic d/j.TextAppearance_android_textColorLink : I
    //   424: istore #5
    //   426: aload #8
    //   428: astore #11
    //   430: aload #9
    //   432: astore #10
    //   434: aload #14
    //   436: iload #5
    //   438: invokevirtual s : (I)Z
    //   441: ifeq -> 470
    //   444: aload #14
    //   446: iload #5
    //   448: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   451: astore #12
    //   453: aload #8
    //   455: astore #11
    //   457: aload #9
    //   459: astore #8
    //   461: goto -> 477
    //   464: aconst_null
    //   465: astore #11
    //   467: aconst_null
    //   468: astore #10
    //   470: aconst_null
    //   471: astore #12
    //   473: aload #10
    //   475: astore #8
    //   477: getstatic d/j.TextAppearance_textLocale : I
    //   480: istore #5
    //   482: aload #14
    //   484: iload #5
    //   486: invokevirtual s : (I)Z
    //   489: ifeq -> 504
    //   492: aload #14
    //   494: iload #5
    //   496: invokevirtual o : (I)Ljava/lang/String;
    //   499: astore #13
    //   501: goto -> 507
    //   504: aconst_null
    //   505: astore #13
    //   507: iload #4
    //   509: bipush #26
    //   511: if_icmplt -> 541
    //   514: getstatic d/j.TextAppearance_fontVariationSettings : I
    //   517: istore #5
    //   519: aload #14
    //   521: iload #5
    //   523: invokevirtual s : (I)Z
    //   526: ifeq -> 541
    //   529: aload #14
    //   531: iload #5
    //   533: invokevirtual o : (I)Ljava/lang/String;
    //   536: astore #10
    //   538: goto -> 544
    //   541: aconst_null
    //   542: astore #10
    //   544: aload #14
    //   546: invokevirtual w : ()V
    //   549: aload #11
    //   551: astore #9
    //   553: aload #13
    //   555: astore #11
    //   557: goto -> 580
    //   560: aconst_null
    //   561: astore #10
    //   563: aconst_null
    //   564: astore #9
    //   566: aconst_null
    //   567: astore #11
    //   569: iconst_0
    //   570: istore #6
    //   572: aconst_null
    //   573: astore #8
    //   575: aconst_null
    //   576: astore #12
    //   578: iconst_0
    //   579: istore_3
    //   580: aload #17
    //   582: aload_1
    //   583: getstatic d/j.TextAppearance : [I
    //   586: iload_2
    //   587: iconst_0
    //   588: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/b1;
    //   591: astore #18
    //   593: iload #7
    //   595: ifne -> 628
    //   598: getstatic d/j.TextAppearance_textAllCaps : I
    //   601: istore #5
    //   603: aload #18
    //   605: iload #5
    //   607: invokevirtual s : (I)Z
    //   610: ifeq -> 628
    //   613: aload #18
    //   615: iload #5
    //   617: iconst_0
    //   618: invokevirtual a : (IZ)Z
    //   621: istore #6
    //   623: iconst_1
    //   624: istore_3
    //   625: goto -> 628
    //   628: aload #9
    //   630: astore #13
    //   632: aload #8
    //   634: astore #14
    //   636: aload #12
    //   638: astore #15
    //   640: iload #4
    //   642: bipush #23
    //   644: if_icmpge -> 739
    //   647: getstatic d/j.TextAppearance_android_textColor : I
    //   650: istore #5
    //   652: aload #18
    //   654: iload #5
    //   656: invokevirtual s : (I)Z
    //   659: ifeq -> 671
    //   662: aload #18
    //   664: iload #5
    //   666: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   669: astore #9
    //   671: getstatic d/j.TextAppearance_android_textColorHint : I
    //   674: istore #5
    //   676: aload #18
    //   678: iload #5
    //   680: invokevirtual s : (I)Z
    //   683: ifeq -> 695
    //   686: aload #18
    //   688: iload #5
    //   690: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   693: astore #8
    //   695: getstatic d/j.TextAppearance_android_textColorLink : I
    //   698: istore #5
    //   700: aload #9
    //   702: astore #13
    //   704: aload #8
    //   706: astore #14
    //   708: aload #12
    //   710: astore #15
    //   712: aload #18
    //   714: iload #5
    //   716: invokevirtual s : (I)Z
    //   719: ifeq -> 739
    //   722: aload #18
    //   724: iload #5
    //   726: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   729: astore #15
    //   731: aload #8
    //   733: astore #14
    //   735: aload #9
    //   737: astore #13
    //   739: getstatic d/j.TextAppearance_textLocale : I
    //   742: istore #5
    //   744: aload #18
    //   746: iload #5
    //   748: invokevirtual s : (I)Z
    //   751: ifeq -> 763
    //   754: aload #18
    //   756: iload #5
    //   758: invokevirtual o : (I)Ljava/lang/String;
    //   761: astore #11
    //   763: iload #4
    //   765: bipush #26
    //   767: if_icmplt -> 797
    //   770: getstatic d/j.TextAppearance_fontVariationSettings : I
    //   773: istore #5
    //   775: aload #18
    //   777: iload #5
    //   779: invokevirtual s : (I)Z
    //   782: ifeq -> 797
    //   785: aload #18
    //   787: iload #5
    //   789: invokevirtual o : (I)Ljava/lang/String;
    //   792: astore #8
    //   794: goto -> 801
    //   797: aload #10
    //   799: astore #8
    //   801: iload #4
    //   803: bipush #28
    //   805: if_icmplt -> 846
    //   808: getstatic d/j.TextAppearance_android_textSize : I
    //   811: istore #5
    //   813: aload #18
    //   815: iload #5
    //   817: invokevirtual s : (I)Z
    //   820: ifeq -> 846
    //   823: aload #18
    //   825: iload #5
    //   827: iconst_m1
    //   828: invokevirtual f : (II)I
    //   831: ifne -> 846
    //   834: aload_0
    //   835: getfield a : Landroid/widget/TextView;
    //   838: iconst_0
    //   839: fconst_0
    //   840: invokevirtual setTextSize : (IF)V
    //   843: goto -> 846
    //   846: aload_0
    //   847: aload #17
    //   849: aload #18
    //   851: invokespecial C : (Landroid/content/Context;Landroidx/appcompat/widget/b1;)V
    //   854: aload #18
    //   856: invokevirtual w : ()V
    //   859: aload #13
    //   861: ifnull -> 873
    //   864: aload_0
    //   865: getfield a : Landroid/widget/TextView;
    //   868: aload #13
    //   870: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   873: aload #14
    //   875: ifnull -> 887
    //   878: aload_0
    //   879: getfield a : Landroid/widget/TextView;
    //   882: aload #14
    //   884: invokevirtual setHintTextColor : (Landroid/content/res/ColorStateList;)V
    //   887: aload #15
    //   889: ifnull -> 901
    //   892: aload_0
    //   893: getfield a : Landroid/widget/TextView;
    //   896: aload #15
    //   898: invokevirtual setLinkTextColor : (Landroid/content/res/ColorStateList;)V
    //   901: iload #7
    //   903: ifne -> 916
    //   906: iload_3
    //   907: ifeq -> 916
    //   910: aload_0
    //   911: iload #6
    //   913: invokevirtual s : (Z)V
    //   916: aload_0
    //   917: getfield l : Landroid/graphics/Typeface;
    //   920: astore #9
    //   922: aload #9
    //   924: ifnull -> 960
    //   927: aload_0
    //   928: getfield k : I
    //   931: iconst_m1
    //   932: if_icmpne -> 951
    //   935: aload_0
    //   936: getfield a : Landroid/widget/TextView;
    //   939: aload #9
    //   941: aload_0
    //   942: getfield j : I
    //   945: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   948: goto -> 960
    //   951: aload_0
    //   952: getfield a : Landroid/widget/TextView;
    //   955: aload #9
    //   957: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   960: aload #8
    //   962: ifnull -> 975
    //   965: aload_0
    //   966: getfield a : Landroid/widget/TextView;
    //   969: aload #8
    //   971: invokestatic d : (Landroid/widget/TextView;Ljava/lang/String;)Z
    //   974: pop
    //   975: aload #11
    //   977: ifnull -> 1026
    //   980: iload #4
    //   982: bipush #24
    //   984: if_icmplt -> 1002
    //   987: aload_0
    //   988: getfield a : Landroid/widget/TextView;
    //   991: aload #11
    //   993: invokestatic a : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   996: invokestatic b : (Landroid/widget/TextView;Landroid/os/LocaleList;)V
    //   999: goto -> 1026
    //   1002: aload #11
    //   1004: ldc_w ','
    //   1007: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   1010: iconst_0
    //   1011: aaload
    //   1012: astore #8
    //   1014: aload_0
    //   1015: getfield a : Landroid/widget/TextView;
    //   1018: aload #8
    //   1020: invokestatic a : (Ljava/lang/String;)Ljava/util/Locale;
    //   1023: invokestatic c : (Landroid/widget/TextView;Ljava/util/Locale;)V
    //   1026: aload_0
    //   1027: getfield i : Landroidx/appcompat/widget/y;
    //   1030: aload_1
    //   1031: iload_2
    //   1032: invokevirtual o : (Landroid/util/AttributeSet;I)V
    //   1035: getstatic androidx/appcompat/widget/m1.b : Z
    //   1038: ifeq -> 1123
    //   1041: aload_0
    //   1042: getfield i : Landroidx/appcompat/widget/y;
    //   1045: invokevirtual j : ()I
    //   1048: ifeq -> 1123
    //   1051: aload_0
    //   1052: getfield i : Landroidx/appcompat/widget/y;
    //   1055: invokevirtual i : ()[I
    //   1058: astore #8
    //   1060: aload #8
    //   1062: arraylength
    //   1063: ifle -> 1123
    //   1066: aload_0
    //   1067: getfield a : Landroid/widget/TextView;
    //   1070: invokestatic a : (Landroid/widget/TextView;)I
    //   1073: i2f
    //   1074: ldc_w -1.0
    //   1077: fcmpl
    //   1078: ifeq -> 1113
    //   1081: aload_0
    //   1082: getfield a : Landroid/widget/TextView;
    //   1085: aload_0
    //   1086: getfield i : Landroidx/appcompat/widget/y;
    //   1089: invokevirtual g : ()I
    //   1092: aload_0
    //   1093: getfield i : Landroidx/appcompat/widget/y;
    //   1096: invokevirtual f : ()I
    //   1099: aload_0
    //   1100: getfield i : Landroidx/appcompat/widget/y;
    //   1103: invokevirtual h : ()I
    //   1106: iconst_0
    //   1107: invokestatic b : (Landroid/widget/TextView;IIII)V
    //   1110: goto -> 1123
    //   1113: aload_0
    //   1114: getfield a : Landroid/widget/TextView;
    //   1117: aload #8
    //   1119: iconst_0
    //   1120: invokestatic c : (Landroid/widget/TextView;[II)V
    //   1123: aload #17
    //   1125: aload_1
    //   1126: getstatic d/j.AppCompatTextView : [I
    //   1129: invokestatic u : (Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroidx/appcompat/widget/b1;
    //   1132: astore #13
    //   1134: aload #13
    //   1136: getstatic d/j.AppCompatTextView_drawableLeftCompat : I
    //   1139: iconst_m1
    //   1140: invokevirtual n : (II)I
    //   1143: istore_2
    //   1144: iload_2
    //   1145: iconst_m1
    //   1146: if_icmpeq -> 1161
    //   1149: aload #16
    //   1151: aload #17
    //   1153: iload_2
    //   1154: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1157: astore_1
    //   1158: goto -> 1163
    //   1161: aconst_null
    //   1162: astore_1
    //   1163: aload #13
    //   1165: getstatic d/j.AppCompatTextView_drawableTopCompat : I
    //   1168: iconst_m1
    //   1169: invokevirtual n : (II)I
    //   1172: istore_2
    //   1173: iload_2
    //   1174: iconst_m1
    //   1175: if_icmpeq -> 1191
    //   1178: aload #16
    //   1180: aload #17
    //   1182: iload_2
    //   1183: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1186: astore #8
    //   1188: goto -> 1194
    //   1191: aconst_null
    //   1192: astore #8
    //   1194: aload #13
    //   1196: getstatic d/j.AppCompatTextView_drawableRightCompat : I
    //   1199: iconst_m1
    //   1200: invokevirtual n : (II)I
    //   1203: istore_2
    //   1204: iload_2
    //   1205: iconst_m1
    //   1206: if_icmpeq -> 1222
    //   1209: aload #16
    //   1211: aload #17
    //   1213: iload_2
    //   1214: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1217: astore #9
    //   1219: goto -> 1225
    //   1222: aconst_null
    //   1223: astore #9
    //   1225: aload #13
    //   1227: getstatic d/j.AppCompatTextView_drawableBottomCompat : I
    //   1230: iconst_m1
    //   1231: invokevirtual n : (II)I
    //   1234: istore_2
    //   1235: iload_2
    //   1236: iconst_m1
    //   1237: if_icmpeq -> 1253
    //   1240: aload #16
    //   1242: aload #17
    //   1244: iload_2
    //   1245: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1248: astore #10
    //   1250: goto -> 1256
    //   1253: aconst_null
    //   1254: astore #10
    //   1256: aload #13
    //   1258: getstatic d/j.AppCompatTextView_drawableStartCompat : I
    //   1261: iconst_m1
    //   1262: invokevirtual n : (II)I
    //   1265: istore_2
    //   1266: iload_2
    //   1267: iconst_m1
    //   1268: if_icmpeq -> 1284
    //   1271: aload #16
    //   1273: aload #17
    //   1275: iload_2
    //   1276: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1279: astore #11
    //   1281: goto -> 1287
    //   1284: aconst_null
    //   1285: astore #11
    //   1287: aload #13
    //   1289: getstatic d/j.AppCompatTextView_drawableEndCompat : I
    //   1292: iconst_m1
    //   1293: invokevirtual n : (II)I
    //   1296: istore_2
    //   1297: iload_2
    //   1298: iconst_m1
    //   1299: if_icmpeq -> 1315
    //   1302: aload #16
    //   1304: aload #17
    //   1306: iload_2
    //   1307: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1310: astore #12
    //   1312: goto -> 1318
    //   1315: aconst_null
    //   1316: astore #12
    //   1318: aload_0
    //   1319: aload_1
    //   1320: aload #8
    //   1322: aload #9
    //   1324: aload #10
    //   1326: aload #11
    //   1328: aload #12
    //   1330: invokespecial y : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1333: getstatic d/j.AppCompatTextView_drawableTint : I
    //   1336: istore_2
    //   1337: aload #13
    //   1339: iload_2
    //   1340: invokevirtual s : (I)Z
    //   1343: ifeq -> 1361
    //   1346: aload #13
    //   1348: iload_2
    //   1349: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   1352: astore_1
    //   1353: aload_0
    //   1354: getfield a : Landroid/widget/TextView;
    //   1357: aload_1
    //   1358: invokestatic h : (Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V
    //   1361: getstatic d/j.AppCompatTextView_drawableTintMode : I
    //   1364: istore_2
    //   1365: aload #13
    //   1367: iload_2
    //   1368: invokevirtual s : (I)Z
    //   1371: ifeq -> 1397
    //   1374: aload #13
    //   1376: iload_2
    //   1377: iconst_m1
    //   1378: invokevirtual k : (II)I
    //   1381: aconst_null
    //   1382: invokestatic e : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   1385: astore_1
    //   1386: aload_0
    //   1387: getfield a : Landroid/widget/TextView;
    //   1390: aload_1
    //   1391: invokestatic i : (Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V
    //   1394: goto -> 1397
    //   1397: aload #13
    //   1399: getstatic d/j.AppCompatTextView_firstBaselineToTopHeight : I
    //   1402: iconst_m1
    //   1403: invokevirtual f : (II)I
    //   1406: istore_2
    //   1407: aload #13
    //   1409: getstatic d/j.AppCompatTextView_lastBaselineToBottomHeight : I
    //   1412: iconst_m1
    //   1413: invokevirtual f : (II)I
    //   1416: istore_3
    //   1417: aload #13
    //   1419: getstatic d/j.AppCompatTextView_lineHeight : I
    //   1422: iconst_m1
    //   1423: invokevirtual f : (II)I
    //   1426: istore #4
    //   1428: aload #13
    //   1430: invokevirtual w : ()V
    //   1433: iload_2
    //   1434: iconst_m1
    //   1435: if_icmpeq -> 1446
    //   1438: aload_0
    //   1439: getfield a : Landroid/widget/TextView;
    //   1442: iload_2
    //   1443: invokestatic k : (Landroid/widget/TextView;I)V
    //   1446: iload_3
    //   1447: iconst_m1
    //   1448: if_icmpeq -> 1459
    //   1451: aload_0
    //   1452: getfield a : Landroid/widget/TextView;
    //   1455: iload_3
    //   1456: invokestatic l : (Landroid/widget/TextView;I)V
    //   1459: iload #4
    //   1461: iconst_m1
    //   1462: if_icmpeq -> 1474
    //   1465: aload_0
    //   1466: getfield a : Landroid/widget/TextView;
    //   1469: iload #4
    //   1471: invokestatic m : (Landroid/widget/TextView;I)V
    //   1474: return
  }
  
  void n(WeakReference<TextView> paramWeakReference, Typeface paramTypeface) {
    if (this.m) {
      this.l = paramTypeface;
      TextView textView = paramWeakReference.get();
      if (textView != null) {
        if (n0.X((View)textView)) {
          textView.post(new b(this, textView, paramTypeface, this.j));
          return;
        } 
        textView.setTypeface(paramTypeface, this.j);
      } 
    } 
  }
  
  void o(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!m1.b)
      c(); 
  }
  
  void p() {
    b();
  }
  
  void q(Context paramContext, int paramInt) {
    b1 b1 = b1.t(paramContext, paramInt, j.TextAppearance);
    paramInt = j.TextAppearance_textAllCaps;
    if (b1.s(paramInt))
      s(b1.a(paramInt, false)); 
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 23) {
      int j = j.TextAppearance_android_textColor;
      if (b1.s(j)) {
        ColorStateList colorStateList = b1.c(j);
        if (colorStateList != null)
          this.a.setTextColor(colorStateList); 
      } 
      j = j.TextAppearance_android_textColorLink;
      if (b1.s(j)) {
        ColorStateList colorStateList = b1.c(j);
        if (colorStateList != null)
          this.a.setLinkTextColor(colorStateList); 
      } 
      j = j.TextAppearance_android_textColorHint;
      if (b1.s(j)) {
        ColorStateList colorStateList = b1.c(j);
        if (colorStateList != null)
          this.a.setHintTextColor(colorStateList); 
      } 
    } 
    int i = j.TextAppearance_android_textSize;
    if (b1.s(i) && b1.f(i, -1) == 0)
      this.a.setTextSize(0, 0.0F); 
    C(paramContext, b1);
    if (paramInt >= 26) {
      paramInt = j.TextAppearance_fontVariationSettings;
      if (b1.s(paramInt)) {
        String str = b1.o(paramInt);
        if (str != null)
          f.d(this.a, str); 
      } 
    } 
    b1.w();
    Typeface typeface = this.l;
    if (typeface != null)
      this.a.setTypeface(typeface, this.j); 
  }
  
  void r(TextView paramTextView, InputConnection paramInputConnection, EditorInfo paramEditorInfo) {
    if (Build.VERSION.SDK_INT < 30 && paramInputConnection != null)
      y.c.f(paramEditorInfo, paramTextView.getText()); 
  }
  
  void s(boolean paramBoolean) {
    this.a.setAllCaps(paramBoolean);
  }
  
  void t(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.i.p(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void u(int[] paramArrayOfint, int paramInt) {
    this.i.q(paramArrayOfint, paramInt);
  }
  
  void v(int paramInt) {
    this.i.r(paramInt);
  }
  
  void w(ColorStateList paramColorStateList) {
    boolean bool;
    if (this.h == null)
      this.h = new z0(); 
    z0 z01 = this.h;
    z01.a = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    z01.d = bool;
    z();
  }
  
  void x(PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.h == null)
      this.h = new z0(); 
    z0 z01 = this.h;
    z01.b = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    z01.c = bool;
    z();
  }
  
  class a extends h.e {
    a(x this$0, int param1Int1, int param1Int2, WeakReference param1WeakReference) {}
    
    public void h(int param1Int) {}
    
    public void i(Typeface param1Typeface) {
      Typeface typeface = param1Typeface;
      if (Build.VERSION.SDK_INT >= 28) {
        int i = this.a;
        typeface = param1Typeface;
        if (i != -1) {
          boolean bool;
          if ((this.b & 0x2) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          typeface = x.g.a(param1Typeface, i, bool);
        } 
      } 
      this.d.n(this.c, typeface);
    }
  }
  
  class b implements Runnable {
    b(x this$0, TextView param1TextView, Typeface param1Typeface, int param1Int) {}
    
    public void run() {
      this.a.setTypeface(this.b, this.c);
    }
  }
  
  static abstract class c {
    static Drawable[] a(TextView param1TextView) {
      return param1TextView.getCompoundDrawablesRelative();
    }
    
    static void b(TextView param1TextView, Drawable param1Drawable1, Drawable param1Drawable2, Drawable param1Drawable3, Drawable param1Drawable4) {
      param1TextView.setCompoundDrawablesRelativeWithIntrinsicBounds(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
    
    static void c(TextView param1TextView, Locale param1Locale) {
      param1TextView.setTextLocale(param1Locale);
    }
  }
  
  static abstract class d {
    static Locale a(String param1String) {
      return Locale.forLanguageTag(param1String);
    }
  }
  
  static abstract class e {
    static LocaleList a(String param1String) {
      return LocaleList.forLanguageTags(param1String);
    }
    
    static void b(TextView param1TextView, LocaleList param1LocaleList) {
      param1TextView.setTextLocales(param1LocaleList);
    }
  }
  
  static abstract class f {
    static int a(TextView param1TextView) {
      return param1TextView.getAutoSizeStepGranularity();
    }
    
    static void b(TextView param1TextView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1TextView.setAutoSizeTextTypeUniformWithConfiguration(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void c(TextView param1TextView, int[] param1ArrayOfint, int param1Int) {
      param1TextView.setAutoSizeTextTypeUniformWithPresetSizes(param1ArrayOfint, param1Int);
    }
    
    static boolean d(TextView param1TextView, String param1String) {
      return param1TextView.setFontVariationSettings(param1String);
    }
  }
  
  static abstract class g {
    static Typeface a(Typeface param1Typeface, int param1Int, boolean param1Boolean) {
      return Typeface.create(param1Typeface, param1Int, param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */