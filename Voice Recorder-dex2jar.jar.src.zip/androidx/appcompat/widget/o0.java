package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.p;
import androidx.core.view.n0;
import d.j;
import java.lang.reflect.Method;

public class o0 implements p {
  private static Method G;
  
  private static Method H;
  
  private static Method I;
  
  private Runnable A;
  
  final Handler B;
  
  private final Rect C = new Rect();
  
  private Rect D;
  
  private boolean E;
  
  PopupWindow F;
  
  private Context a;
  
  private ListAdapter b;
  
  k0 c;
  
  private int d = -2;
  
  private int e = -2;
  
  private int f;
  
  private int g;
  
  private int h = 1002;
  
  private boolean i;
  
  private boolean j;
  
  private boolean k;
  
  private int l = 0;
  
  private boolean m = false;
  
  private boolean n = false;
  
  int o = Integer.MAX_VALUE;
  
  private View p;
  
  private int q = 0;
  
  private DataSetObserver r;
  
  private View s;
  
  private Drawable t;
  
  private AdapterView.OnItemClickListener u;
  
  private AdapterView.OnItemSelectedListener v;
  
  final i w = new i(this);
  
  private final h x = new h(this);
  
  private final g y = new g(this);
  
  private final e z = new e(this);
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        G = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      } 
      try {
        I = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      } 
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        H = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }  
  }
  
  public o0(Context paramContext) {
    this(paramContext, null, d.a.listPopupWindowStyle);
  }
  
  public o0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public o0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.B = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.ListPopupWindow, paramInt1, paramInt2);
    this.f = typedArray.getDimensionPixelOffset(j.ListPopupWindow_android_dropDownHorizontalOffset, 0);
    int j = typedArray.getDimensionPixelOffset(j.ListPopupWindow_android_dropDownVerticalOffset, 0);
    this.g = j;
    if (j != 0)
      this.i = true; 
    typedArray.recycle();
    o o = new o(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.F = o;
    o.setInputMethodMode(1);
  }
  
  private void B() {
    View view = this.p;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.p); 
    } 
  }
  
  private void N(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = G;
      if (method != null)
        try {
          method.invoke(this.F, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      d.b(this.F, paramBoolean);
    } 
  }
  
  private int p() {
    byte b1;
    byte b2;
    k0 k01 = this.c;
    boolean bool = true;
    if (k01 == null) {
      LinearLayout.LayoutParams layoutParams1;
      LinearLayout.LayoutParams layoutParams2;
      Context context = this.a;
      this.A = new a(this);
      k0 k03 = r(context, this.E ^ true);
      this.c = k03;
      Drawable drawable1 = this.t;
      if (drawable1 != null)
        k03.setSelector(drawable1); 
      this.c.setAdapter(this.b);
      this.c.setOnItemClickListener(this.u);
      this.c.setFocusable(true);
      this.c.setFocusableInTouchMode(true);
      this.c.setOnItemSelectedListener(new b(this));
      this.c.setOnScrollListener(this.y);
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.v;
      if (onItemSelectedListener != null)
        this.c.setOnItemSelectedListener(onItemSelectedListener); 
      k0 k02 = this.c;
      View view = this.p;
      if (view != null) {
        boolean bool1;
        StringBuilder stringBuilder;
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        b1 = this.q;
        if (b1 != 0) {
          if (b1 != 1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid hint position ");
            stringBuilder.append(this.q);
            Log.e("ListPopupWindow", stringBuilder.toString());
          } else {
            linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
            linearLayout.addView(view);
          } 
        } else {
          linearLayout.addView(view);
          linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
        } 
        b1 = this.e;
        if (b1 >= 0) {
          bool1 = true;
        } else {
          b1 = 0;
          bool1 = false;
        } 
        view.measure(View.MeasureSpec.makeMeasureSpec(b1, bool1), 0);
        layoutParams2 = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
      } else {
        b1 = 0;
        layoutParams1 = layoutParams2;
      } 
      this.F.setContentView((View)layoutParams1);
    } else {
      ViewGroup viewGroup = (ViewGroup)this.F.getContentView();
      View view = this.p;
      if (view != null) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } else {
        b1 = 0;
      } 
    } 
    Drawable drawable = this.F.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.C);
      Rect rect = this.C;
      int n = rect.top;
      int m = rect.bottom + n;
      b2 = m;
      if (!this.i) {
        this.g = -n;
        b2 = m;
      } 
    } else {
      this.C.setEmpty();
      b2 = 0;
    } 
    if (this.F.getInputMethodMode() != 2)
      bool = false; 
    int k = t(s(), this.g, bool);
    if (this.m || this.d == -1)
      return k + b2; 
    int j = this.e;
    if (j != -2) {
      if (j != -1) {
        j = View.MeasureSpec.makeMeasureSpec(j, 1073741824);
      } else {
        j = (this.a.getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.C;
        j = View.MeasureSpec.makeMeasureSpec(j - rect.left + rect.right, 1073741824);
      } 
    } else {
      j = (this.a.getResources().getDisplayMetrics()).widthPixels;
      Rect rect = this.C;
      j = View.MeasureSpec.makeMeasureSpec(j - rect.left + rect.right, -2147483648);
    } 
    k = this.c.d(j, 0, -1, k - b1, -1);
    j = b1;
    if (k > 0)
      j = b1 + b2 + this.c.getPaddingTop() + this.c.getPaddingBottom(); 
    return k + j;
  }
  
  private int t(View paramView, int paramInt, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 23) {
      Method method = H;
      if (method != null)
        try {
          return ((Integer)method.invoke(this.F, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
        }  
      return this.F.getMaxAvailableHeight(paramView, paramInt);
    } 
    return c.a(this.F, paramView, paramInt, paramBoolean);
  }
  
  public boolean A() {
    return this.E;
  }
  
  public void C(View paramView) {
    this.s = paramView;
  }
  
  public void D(int paramInt) {
    this.F.setAnimationStyle(paramInt);
  }
  
  public void E(int paramInt) {
    Drawable drawable = this.F.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.C);
      Rect rect = this.C;
      this.e = rect.left + rect.right + paramInt;
      return;
    } 
    Q(paramInt);
  }
  
  public void F(int paramInt) {
    this.l = paramInt;
  }
  
  public void G(Rect paramRect) {
    if (paramRect != null) {
      paramRect = new Rect(paramRect);
    } else {
      paramRect = null;
    } 
    this.D = paramRect;
  }
  
  public void H(int paramInt) {
    this.F.setInputMethodMode(paramInt);
  }
  
  public void I(boolean paramBoolean) {
    this.E = paramBoolean;
    this.F.setFocusable(paramBoolean);
  }
  
  public void J(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.F.setOnDismissListener(paramOnDismissListener);
  }
  
  public void K(AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.u = paramOnItemClickListener;
  }
  
  public void L(AdapterView.OnItemSelectedListener paramOnItemSelectedListener) {
    this.v = paramOnItemSelectedListener;
  }
  
  public void M(boolean paramBoolean) {
    this.k = true;
    this.j = paramBoolean;
  }
  
  public void O(int paramInt) {
    this.q = paramInt;
  }
  
  public void P(int paramInt) {
    k0 k01 = this.c;
    if (a() && k01 != null) {
      k01.setListSelectionHidden(false);
      k01.setSelection(paramInt);
      if (k01.getChoiceMode() != 0)
        k01.setItemChecked(paramInt, true); 
    } 
  }
  
  public void Q(int paramInt) {
    this.e = paramInt;
  }
  
  public boolean a() {
    return this.F.isShowing();
  }
  
  public void b(Drawable paramDrawable) {
    this.F.setBackgroundDrawable(paramDrawable);
  }
  
  public int c() {
    return this.f;
  }
  
  public void dismiss() {
    this.F.dismiss();
    B();
    this.F.setContentView(null);
    this.c = null;
    this.B.removeCallbacks(this.w);
  }
  
  public void e(int paramInt) {
    this.f = paramInt;
  }
  
  public Drawable h() {
    return this.F.getBackground();
  }
  
  public ListView j() {
    return this.c;
  }
  
  public void k(int paramInt) {
    this.g = paramInt;
    this.i = true;
  }
  
  public int n() {
    return !this.i ? 0 : this.g;
  }
  
  public void o(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.r;
    if (dataSetObserver == null) {
      this.r = new f(this);
    } else {
      ListAdapter listAdapter = this.b;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.b = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.r); 
    k0 k01 = this.c;
    if (k01 != null)
      k01.setAdapter(this.b); 
  }
  
  public void q() {
    k0 k01 = this.c;
    if (k01 != null) {
      k01.setListSelectionHidden(true);
      k01.requestLayout();
    } 
  }
  
  k0 r(Context paramContext, boolean paramBoolean) {
    return new k0(paramContext, paramBoolean);
  }
  
  public View s() {
    return this.s;
  }
  
  public void show() {
    int j;
    int k = p();
    boolean bool1 = z();
    androidx.core.widget.h.b(this.F, this.h);
    boolean bool2 = this.F.isShowing();
    boolean bool = true;
    if (bool2) {
      if (!n0.X(s()))
        return; 
      int n = this.e;
      if (n == -1) {
        j = -1;
      } else {
        j = n;
        if (n == -2)
          j = s().getWidth(); 
      } 
      n = this.d;
      if (n == -1) {
        if (!bool1)
          k = -1; 
        if (bool1) {
          PopupWindow popupWindow2 = this.F;
          if (this.e == -1) {
            n = -1;
          } else {
            n = 0;
          } 
          popupWindow2.setWidth(n);
          this.F.setHeight(0);
        } else {
          PopupWindow popupWindow2 = this.F;
          if (this.e == -1) {
            n = -1;
          } else {
            n = 0;
          } 
          popupWindow2.setWidth(n);
          this.F.setHeight(-1);
        } 
      } else if (n != -2) {
        k = n;
      } 
      PopupWindow popupWindow1 = this.F;
      if (this.n || this.m)
        bool = false; 
      popupWindow1.setOutsideTouchable(bool);
      popupWindow1 = this.F;
      View view = s();
      n = this.f;
      int i1 = this.g;
      if (j < 0)
        j = -1; 
      if (k < 0)
        k = -1; 
      popupWindow1.update(view, n, i1, j, k);
      return;
    } 
    int m = this.e;
    if (m == -1) {
      j = -1;
    } else {
      j = m;
      if (m == -2)
        j = s().getWidth(); 
    } 
    m = this.d;
    if (m == -1) {
      k = -1;
    } else if (m != -2) {
      k = m;
    } 
    this.F.setWidth(j);
    this.F.setHeight(k);
    N(true);
    PopupWindow popupWindow = this.F;
    if (!this.n && !this.m) {
      bool = true;
    } else {
      bool = false;
    } 
    popupWindow.setOutsideTouchable(bool);
    this.F.setTouchInterceptor(this.x);
    if (this.k)
      androidx.core.widget.h.a(this.F, this.j); 
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = I;
      if (method != null)
        try {
          method.invoke(this.F, new Object[] { this.D });
        } catch (Exception exception) {
          Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", exception);
        }  
    } else {
      d.a(this.F, this.D);
    } 
    androidx.core.widget.h.c(this.F, s(), this.f, this.g, this.l);
    this.c.setSelection(-1);
    if (!this.E || this.c.isInTouchMode())
      q(); 
    if (!this.E)
      this.B.post(this.z); 
  }
  
  public Object u() {
    return !a() ? null : this.c.getSelectedItem();
  }
  
  public long v() {
    return !a() ? Long.MIN_VALUE : this.c.getSelectedItemId();
  }
  
  public int w() {
    return !a() ? -1 : this.c.getSelectedItemPosition();
  }
  
  public View x() {
    return !a() ? null : this.c.getSelectedView();
  }
  
  public int y() {
    return this.e;
  }
  
  public boolean z() {
    return (this.F.getInputMethodMode() == 2);
  }
  
  class a implements Runnable {
    a(o0 this$0) {}
    
    public void run() {
      View view = this.a.s();
      if (view != null && view.getWindowToken() != null)
        this.a.show(); 
    }
  }
  
  class b implements AdapterView.OnItemSelectedListener {
    b(o0 this$0) {}
    
    public void onItemSelected(AdapterView param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int != -1) {
        k0 k0 = this.a.c;
        if (k0 != null)
          k0.setListSelectionHidden(false); 
      } 
    }
    
    public void onNothingSelected(AdapterView param1AdapterView) {}
  }
  
  static abstract class c {
    static int a(PopupWindow param1PopupWindow, View param1View, int param1Int, boolean param1Boolean) {
      return param1PopupWindow.getMaxAvailableHeight(param1View, param1Int, param1Boolean);
    }
  }
  
  static abstract class d {
    static void a(PopupWindow param1PopupWindow, Rect param1Rect) {
      param1PopupWindow.setEpicenterBounds(param1Rect);
    }
    
    static void b(PopupWindow param1PopupWindow, boolean param1Boolean) {
      param1PopupWindow.setIsClippedToScreen(param1Boolean);
    }
  }
  
  private class e implements Runnable {
    e(o0 this$0) {}
    
    public void run() {
      this.a.q();
    }
  }
  
  private class f extends DataSetObserver {
    f(o0 this$0) {}
    
    public void onChanged() {
      if (this.a.a())
        this.a.show(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  private class g implements AbsListView.OnScrollListener {
    g(o0 this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !this.a.z() && this.a.F.getContentView() != null) {
        o0 o01 = this.a;
        o01.B.removeCallbacks(o01.w);
        this.a.w.run();
      } 
    }
  }
  
  private class h implements View.OnTouchListener {
    h(o0 this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.a.F;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.a.F.getWidth() && k >= 0 && k < this.a.F.getHeight()) {
          o0 o01 = this.a;
          o01.B.postDelayed(o01.w, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        o0 o01 = this.a;
        o01.B.removeCallbacks(o01.w);
      } 
      return false;
    }
  }
  
  private class i implements Runnable {
    i(o0 this$0) {}
    
    public void run() {
      k0 k0 = this.a.c;
      if (k0 != null && n0.X((View)k0) && this.a.c.getCount() > this.a.c.getChildCount()) {
        int j = this.a.c.getChildCount();
        o0 o01 = this.a;
        if (j <= o01.o) {
          o01.F.setInputMethodMode(2);
          this.a.show();
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */