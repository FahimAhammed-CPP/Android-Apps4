package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.r;
import androidx.core.view.n0;
import androidx.core.view.p;
import androidx.core.view.s;
import androidx.core.view.t;
import androidx.core.view.w;
import androidx.core.view.z;
import androidx.customview.view.AbsSavedState;
import d.j;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Toolbar extends ViewGroup implements t {
  private ColorStateList A;
  
  private boolean B;
  
  private boolean C;
  
  private final ArrayList D = new ArrayList();
  
  private final ArrayList E = new ArrayList();
  
  private final int[] F = new int[2];
  
  final w G = new w(new c1(this));
  
  private ArrayList H = new ArrayList();
  
  h I;
  
  private final ActionMenuView.e J = new a(this);
  
  private f1 K;
  
  private ActionMenuPresenter L;
  
  private f M;
  
  private m.a N;
  
  androidx.appcompat.view.menu.g.a O;
  
  private boolean P;
  
  private OnBackInvokedCallback Q;
  
  private OnBackInvokedDispatcher R;
  
  private boolean S;
  
  private final Runnable T = new b(this);
  
  ActionMenuView a;
  
  private TextView b;
  
  private TextView c;
  
  private ImageButton d;
  
  private ImageView e;
  
  private Drawable f;
  
  private CharSequence g;
  
  ImageButton h;
  
  View i;
  
  private Context j;
  
  private int k;
  
  private int l;
  
  private int m;
  
  int n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private u0 t;
  
  private int u;
  
  private int v;
  
  private int w = 8388627;
  
  private CharSequence x;
  
  private CharSequence y;
  
  private ColorStateList z;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, d.a.toolbarStyle);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = j.Toolbar;
    b1 b1 = b1.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    n0.s0((View)this, paramContext, arrayOfInt, paramAttributeSet, b1.r(), paramInt, 0);
    this.l = b1.n(j.Toolbar_titleTextAppearance, 0);
    this.m = b1.n(j.Toolbar_subtitleTextAppearance, 0);
    this.w = b1.l(j.Toolbar_android_gravity, this.w);
    this.n = b1.l(j.Toolbar_buttonGravity, 48);
    int i = b1.e(j.Toolbar_titleMargin, 0);
    int j = j.Toolbar_titleMargins;
    paramInt = i;
    if (b1.s(j))
      paramInt = b1.e(j, i); 
    this.s = paramInt;
    this.r = paramInt;
    this.q = paramInt;
    this.p = paramInt;
    paramInt = b1.e(j.Toolbar_titleMarginStart, -1);
    if (paramInt >= 0)
      this.p = paramInt; 
    paramInt = b1.e(j.Toolbar_titleMarginEnd, -1);
    if (paramInt >= 0)
      this.q = paramInt; 
    paramInt = b1.e(j.Toolbar_titleMarginTop, -1);
    if (paramInt >= 0)
      this.r = paramInt; 
    paramInt = b1.e(j.Toolbar_titleMarginBottom, -1);
    if (paramInt >= 0)
      this.s = paramInt; 
    this.o = b1.f(j.Toolbar_maxButtonHeight, -1);
    paramInt = b1.e(j.Toolbar_contentInsetStart, -2147483648);
    i = b1.e(j.Toolbar_contentInsetEnd, -2147483648);
    j = b1.f(j.Toolbar_contentInsetLeft, 0);
    int k = b1.f(j.Toolbar_contentInsetRight, 0);
    h();
    this.t.e(j, k);
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      this.t.g(paramInt, i); 
    this.u = b1.e(j.Toolbar_contentInsetStartWithNavigation, -2147483648);
    this.v = b1.e(j.Toolbar_contentInsetEndWithActions, -2147483648);
    this.f = b1.g(j.Toolbar_collapseIcon);
    this.g = b1.p(j.Toolbar_collapseContentDescription);
    CharSequence charSequence3 = b1.p(j.Toolbar_title);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = b1.p(j.Toolbar_subtitle);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.j = getContext();
    setPopupTheme(b1.n(j.Toolbar_popupTheme, 0));
    Drawable drawable2 = b1.g(j.Toolbar_navigationIcon);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = b1.p(j.Toolbar_navigationContentDescription);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = b1.g(j.Toolbar_logo);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = b1.p(j.Toolbar_logoDescription);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    paramInt = j.Toolbar_titleTextColor;
    if (b1.s(paramInt))
      setTitleTextColor(b1.c(paramInt)); 
    paramInt = j.Toolbar_subtitleTextColor;
    if (b1.s(paramInt))
      setSubtitleTextColor(b1.c(paramInt)); 
    paramInt = j.Toolbar_menu;
    if (b1.s(paramInt))
      x(b1.n(paramInt, 0)); 
    b1.w();
  }
  
  private int C(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    g g = (g)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)g).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, i);
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + i + ((ViewGroup.MarginLayoutParams)g).rightMargin;
  }
  
  private int D(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    g g = (g)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)g).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)g).leftMargin;
  }
  
  private int E(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int j = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfint[0] = Math.max(0, -i);
    paramArrayOfint[1] = Math.max(0, -j);
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + k + paramInt2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + k;
  }
  
  private void F(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  private void G() {
    Menu menu = getMenu();
    ArrayList<MenuItem> arrayList1 = getCurrentMenuItems();
    this.G.h(menu, getMenuInflater());
    ArrayList<MenuItem> arrayList2 = getCurrentMenuItems();
    arrayList2.removeAll(arrayList1);
    this.H = arrayList2;
  }
  
  private void H() {
    removeCallbacks(this.T);
    post(this.T);
  }
  
  private boolean O() {
    if (!this.P)
      return false; 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (P(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  private boolean P(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  private void b(List<View> paramList, int paramInt) {
    int i = n0.E((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = p.b(paramInt, n0.E((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        g g = (g)view.getLayoutParams();
        if (g.b == 0 && P(view) && p(g.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        g g = (g)view.getLayoutParams();
        if (g.b == 0 && P(view) && p(g.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  private void c(View paramView, boolean paramBoolean) {
    g g;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      g = m();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)g)) {
      g = o((ViewGroup.LayoutParams)g);
    } else {
      g = g;
    } 
    g.b = 1;
    if (paramBoolean && this.i != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)g);
      this.E.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)g);
  }
  
  private ArrayList<MenuItem> getCurrentMenuItems() {
    ArrayList<MenuItem> arrayList = new ArrayList();
    Menu menu = getMenu();
    for (int i = 0; i < menu.size(); i++)
      arrayList.add(menu.getItem(i)); 
    return arrayList;
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new androidx.appcompat.view.g(getContext());
  }
  
  private void h() {
    if (this.t == null)
      this.t = new u0(); 
  }
  
  private void i() {
    if (this.e == null)
      this.e = new AppCompatImageView(getContext()); 
  }
  
  private void j() {
    k();
    if (this.a.N() == null) {
      androidx.appcompat.view.menu.g g = (androidx.appcompat.view.menu.g)this.a.getMenu();
      if (this.M == null)
        this.M = new f(this); 
      this.a.setExpandedActionViewsExclusive(true);
      g.c(this.M, this.j);
      R();
    } 
  }
  
  private void k() {
    if (this.a == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext());
      this.a = actionMenuView;
      actionMenuView.setPopupTheme(this.k);
      this.a.setOnMenuItemClickListener(this.J);
      this.a.O(this.N, new c(this));
      g g = m();
      g.a = this.n & 0x70 | 0x800005;
      this.a.setLayoutParams((ViewGroup.LayoutParams)g);
      c((View)this.a, false);
    } 
  }
  
  private void l() {
    if (this.d == null) {
      this.d = new l(getContext(), null, d.a.toolbarNavigationButtonStyle);
      g g = m();
      g.a = this.n & 0x70 | 0x800003;
      this.d.setLayoutParams((ViewGroup.LayoutParams)g);
    } 
  }
  
  private int p(int paramInt) {
    int i = n0.E((View)this);
    int j = p.b(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  private int q(View paramView, int paramInt) {
    g g = (g)paramView.getLayoutParams();
    int j = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (j - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = r(g.a);
    if (i != 48) {
      if (i != 80) {
        int k = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - k - m - j) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)g).topMargin;
        if (i >= paramInt) {
          j = n - m - j - i - k;
          m = ((ViewGroup.MarginLayoutParams)g).bottomMargin;
          paramInt = i;
          if (j < m)
            paramInt = Math.max(0, i - m - j); 
        } 
        return k + paramInt;
      } 
      return getHeight() - getPaddingBottom() - j - ((ViewGroup.MarginLayoutParams)g).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int r(int paramInt) {
    int i = paramInt & 0x70;
    paramInt = i;
    if (i != 16) {
      paramInt = i;
      if (i != 48) {
        paramInt = i;
        if (i != 80)
          paramInt = this.w & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  private int s(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return s.b(marginLayoutParams) + s.a(marginLayoutParams);
  }
  
  private int t(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int u(List<View> paramList, int[] paramArrayOfint) {
    int m = paramArrayOfint[0];
    int k = paramArrayOfint[1];
    int n = paramList.size();
    int i = 0;
    int j = 0;
    while (i < n) {
      View view = paramList.get(i);
      g g = (g)view.getLayoutParams();
      m = ((ViewGroup.MarginLayoutParams)g).leftMargin - m;
      k = ((ViewGroup.MarginLayoutParams)g).rightMargin - k;
      int i1 = Math.max(0, m);
      int i2 = Math.max(0, k);
      m = Math.max(0, -m);
      k = Math.max(0, -k);
      j += i1 + view.getMeasuredWidth() + i2;
      i++;
    } 
    return j;
  }
  
  private boolean z(View paramView) {
    return (paramView.getParent() == this || this.E.contains(paramView));
  }
  
  public boolean A() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.I());
  }
  
  public boolean B() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.J());
  }
  
  void I() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((g)view.getLayoutParams()).b != 2 && view != this.a) {
        removeViewAt(i);
        this.E.add(view);
      } 
    } 
  }
  
  public void J(int paramInt1, int paramInt2) {
    h();
    this.t.g(paramInt1, paramInt2);
  }
  
  public void K(androidx.appcompat.view.menu.g paramg, ActionMenuPresenter paramActionMenuPresenter) {
    if (paramg == null && this.a == null)
      return; 
    k();
    androidx.appcompat.view.menu.g g1 = this.a.N();
    if (g1 == paramg)
      return; 
    if (g1 != null) {
      g1.Q((m)this.L);
      g1.Q(this.M);
    } 
    if (this.M == null)
      this.M = new f(this); 
    paramActionMenuPresenter.I(true);
    if (paramg != null) {
      paramg.c((m)paramActionMenuPresenter, this.j);
      paramg.c(this.M, this.j);
    } else {
      paramActionMenuPresenter.h(this.j, null);
      this.M.h(this.j, null);
      paramActionMenuPresenter.c(true);
      this.M.c(true);
    } 
    this.a.setPopupTheme(this.k);
    this.a.setPresenter(paramActionMenuPresenter);
    this.L = paramActionMenuPresenter;
    R();
  }
  
  public void L(m.a parama, androidx.appcompat.view.menu.g.a parama1) {
    this.N = parama;
    this.O = parama1;
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null)
      actionMenuView.O(parama, parama1); 
  }
  
  public void M(Context paramContext, int paramInt) {
    this.m = paramInt;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void N(Context paramContext, int paramInt) {
    this.l = paramInt;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public boolean Q() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.P());
  }
  
  void R() {
    if (Build.VERSION.SDK_INT >= 33) {
      boolean bool;
      OnBackInvokedDispatcher onBackInvokedDispatcher = e.a((View)this);
      if (v() && onBackInvokedDispatcher != null && n0.X((View)this) && this.S) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool && this.R == null) {
        if (this.Q == null)
          this.Q = e.b(new d1(this)); 
        e.c(onBackInvokedDispatcher, this.Q);
        this.R = onBackInvokedDispatcher;
        return;
      } 
      if (!bool) {
        onBackInvokedDispatcher = this.R;
        if (onBackInvokedDispatcher != null) {
          e.d(onBackInvokedDispatcher, this.Q);
          this.R = null;
        } 
      } 
    } 
  }
  
  void a() {
    for (int i = this.E.size() - 1; i >= 0; i--)
      addView(this.E.get(i)); 
    this.E.clear();
  }
  
  public void addMenuProvider(z paramz) {
    this.G.c(paramz);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof g);
  }
  
  public boolean d() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.a;
      if (actionMenuView != null && actionMenuView.K())
        return true; 
    } 
    return false;
  }
  
  public void e() {
    i i;
    f f2 = this.M;
    if (f2 == null) {
      f2 = null;
    } else {
      i = f2.b;
    } 
    if (i != null)
      i.collapseActionView(); 
  }
  
  public void f() {
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null)
      actionMenuView.B(); 
  }
  
  void g() {
    if (this.h == null) {
      l l = new l(getContext(), null, d.a.toolbarNavigationButtonStyle);
      this.h = l;
      l.setImageDrawable(this.f);
      this.h.setContentDescription(this.g);
      g g = m();
      g.a = this.n & 0x70 | 0x800003;
      g.b = 2;
      this.h.setLayoutParams((ViewGroup.LayoutParams)g);
      this.h.setOnClickListener(new d(this));
    } 
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    u0 u01 = this.t;
    return (u01 != null) ? u01.a() : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.v;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    u0 u01 = this.t;
    return (u01 != null) ? u01.b() : 0;
  }
  
  public int getContentInsetRight() {
    u0 u01 = this.t;
    return (u01 != null) ? u01.c() : 0;
  }
  
  public int getContentInsetStart() {
    u0 u01 = this.t;
    return (u01 != null) ? u01.d() : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.u;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokevirtual N : ()Landroidx/appcompat/view/menu/g;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield v : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (n0.E((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (n0.E((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.u, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    j();
    return this.a.getMenu();
  }
  
  View getNavButtonView() {
    return (View)this.d;
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  ActionMenuPresenter getOuterActionMenuPresenter() {
    return this.L;
  }
  
  public Drawable getOverflowIcon() {
    j();
    return this.a.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.j;
  }
  
  public int getPopupTheme() {
    return this.k;
  }
  
  public CharSequence getSubtitle() {
    return this.y;
  }
  
  final TextView getSubtitleTextView() {
    return this.c;
  }
  
  public CharSequence getTitle() {
    return this.x;
  }
  
  public int getTitleMarginBottom() {
    return this.s;
  }
  
  public int getTitleMarginEnd() {
    return this.q;
  }
  
  public int getTitleMarginStart() {
    return this.p;
  }
  
  public int getTitleMarginTop() {
    return this.r;
  }
  
  final TextView getTitleTextView() {
    return this.b;
  }
  
  public e0 getWrapper() {
    if (this.K == null)
      this.K = new f1(this, true); 
    return this.K;
  }
  
  protected g m() {
    return new g(-2, -2);
  }
  
  public g n(AttributeSet paramAttributeSet) {
    return new g(getContext(), paramAttributeSet);
  }
  
  protected g o(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof g) ? new g((g)paramLayoutParams) : ((paramLayoutParams instanceof androidx.appcompat.app.a.a) ? new g((androidx.appcompat.app.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new g((ViewGroup.MarginLayoutParams)paramLayoutParams) : new g(paramLayoutParams)));
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    R();
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.T);
    R();
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.C = false; 
    if (!this.C) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.C = true; 
    } 
    if (i == 10 || i == 3)
      this.C = false; 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (n0.E((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    int i = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.F;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = n0.F((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (P((View)this.d)) {
      if (k) {
        j = D((View)this.d, m, arrayOfInt, paramInt4);
        paramInt3 = i;
      } else {
        paramInt3 = C((View)this.d, i, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      paramInt3 = i;
      j = m;
    } 
    paramInt1 = paramInt3;
    paramInt2 = j;
    if (P((View)this.h))
      if (k) {
        paramInt2 = D((View)this.h, j, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = C((View)this.h, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    int j = paramInt1;
    paramInt3 = paramInt2;
    if (P((View)this.a))
      if (k) {
        j = C((View)this.a, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = D((View)this.a, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - paramInt3);
    paramInt2 = Math.max(j, paramInt2);
    paramInt3 = Math.min(paramInt3, m - paramInt1);
    paramInt1 = paramInt2;
    j = paramInt3;
    if (P(this.i))
      if (k) {
        j = D(this.i, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = C(this.i, paramInt2, arrayOfInt, paramInt4);
        j = paramInt3;
      }  
    paramInt3 = paramInt1;
    paramInt2 = j;
    if (P((View)this.e))
      if (k) {
        paramInt2 = D((View)this.e, j, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = C((View)this.e, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    paramBoolean = P((View)this.b);
    boolean bool = P((View)this.c);
    if (paramBoolean) {
      g g = (g)this.b.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)g).topMargin + this.b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)g).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      g g = (g)this.c.getLayoutParams();
      paramInt1 += ((ViewGroup.MarginLayoutParams)g).topMargin + this.c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)g).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.b;
      } else {
        textView1 = this.c;
      } 
      if (bool) {
        textView2 = this.c;
      } else {
        textView2 = this.b;
      } 
      g g1 = (g)textView1.getLayoutParams();
      g g2 = (g)textView2.getLayoutParams();
      if ((paramBoolean && this.b.getMeasuredWidth() > 0) || (bool && this.c.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.w & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)g1).topMargin;
          int i6 = this.r;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)g1).bottomMargin;
            i5 = this.s;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)g2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)g2).bottomMargin - this.s - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)g1).topMargin + this.r;
      } 
      if (k) {
        if (j != 0) {
          k = this.p;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[1];
        paramInt2 -= Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          g1 = (g)this.b.getLayoutParams();
          m = paramInt2 - this.b.getMeasuredWidth();
          k = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(m, paramInt1, paramInt2, k);
          paramInt1 = m - this.q;
          m = k + ((ViewGroup.MarginLayoutParams)g1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = m + ((ViewGroup.MarginLayoutParams)this.c.getLayoutParams()).topMargin;
          m = this.c.getMeasuredWidth();
          i2 = this.c.getMeasuredHeight();
          this.c.layout(paramInt2 - m, k, paramInt2, i2 + k);
          k = paramInt2 - this.q;
        } else {
          k = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, k); 
        paramInt1 = paramInt3;
      } else {
        if (j != 0) {
          k = this.p;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[0];
        paramInt3 += Math.max(0, k);
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          g1 = (g)this.b.getLayoutParams();
          k = this.b.getMeasuredWidth() + paramInt3;
          m = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(paramInt3, paramInt1, k, m);
          k += this.q;
          paramInt1 = m + ((ViewGroup.MarginLayoutParams)g1).bottomMargin;
        } else {
          k = paramInt3;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.c.getLayoutParams()).topMargin;
          m = this.c.getMeasuredWidth() + paramInt3;
          i2 = this.c.getMeasuredHeight();
          this.c.layout(paramInt3, paramInt1, m, i2 + paramInt1);
          m += this.q;
        } else {
          m = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (j != 0) {
          paramInt1 = Math.max(k, m);
          paramInt3 = paramInt2;
        } 
        j = i;
        i = 0;
        b(this.D, 3);
        k = this.D.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    j = i;
    i = 0;
    b(this.D, 3);
    int k = this.D.size();
    paramInt2 = 0;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.a());
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.g g = actionMenuView.N();
    } else {
      actionMenuView = null;
    } 
    int i = savedState.c;
    if (i != 0 && this.M != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (savedState.d)
      H(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    h();
    u0 u01 = this.t;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    u01.f(bool);
  }
  
  protected Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    f f2 = this.M;
    if (f2 != null) {
      i i = f2.b;
      if (i != null)
        savedState.c = i.getItemId(); 
    } 
    savedState.d = B();
    return (Parcelable)savedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.B = false; 
    if (!this.B) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.B = true; 
    } 
    if (i == 1 || i == 3)
      this.B = false; 
    return true;
  }
  
  public void removeMenuProvider(z paramz) {
    this.G.l(paramz);
  }
  
  public void setBackInvokedCallbackEnabled(boolean paramBoolean) {
    if (this.S != paramBoolean) {
      this.S = paramBoolean;
      R();
    } 
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(e.a.b(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      this.h.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setImageDrawable(this.f); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.P = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.v) {
      this.v = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.u) {
      this.u = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(e.a.b(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      i();
      if (!z((View)this.e))
        c((View)this.e, true); 
    } else {
      ImageView imageView1 = this.e;
      if (imageView1 != null && z((View)imageView1)) {
        removeView((View)this.e);
        this.E.remove(this.e);
      } 
    } 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      i(); 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      l(); 
    ImageButton imageButton = this.d;
    if (imageButton != null) {
      imageButton.setContentDescription(paramCharSequence);
      g1.a((View)this.d, paramCharSequence);
    } 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(e.a.b(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      l();
      if (!z((View)this.d))
        c((View)this.d, true); 
    } else {
      ImageButton imageButton1 = this.d;
      if (imageButton1 != null && z((View)imageButton1)) {
        removeView((View)this.d);
        this.E.remove(this.d);
      } 
    } 
    ImageButton imageButton = this.d;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    l();
    this.d.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(h paramh) {
    this.I = paramh;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    j();
    this.a.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.k != paramInt) {
      this.k = paramInt;
      if (paramInt == 0) {
        this.j = getContext();
        return;
      } 
      this.j = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.c == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.c = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.c.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.m;
        if (i != 0)
          this.c.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.A;
        if (colorStateList != null)
          this.c.setTextColor(colorStateList); 
      } 
      if (!z((View)this.c))
        c((View)this.c, true); 
    } else {
      TextView textView1 = this.c;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.c);
        this.E.remove(this.c);
      } 
    } 
    TextView textView = this.c;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.y = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.A = paramColorStateList;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.b == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.b = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.b.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.l;
        if (i != 0)
          this.b.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.z;
        if (colorStateList != null)
          this.b.setTextColor(colorStateList); 
      } 
      if (!z((View)this.b))
        c((View)this.b, true); 
    } else {
      TextView textView1 = this.b;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.b);
        this.E.remove(this.b);
      } 
    } 
    TextView textView = this.b;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.x = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.s = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.q = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.p = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.r = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.z = paramColorStateList;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public boolean v() {
    f f2 = this.M;
    return (f2 != null && f2.b != null);
  }
  
  public boolean w() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.H());
  }
  
  public void x(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public void y() {
    for (MenuItem menuItem : this.H)
      getMenu().removeItem(menuItem.getItemId()); 
    G();
  }
  
  public static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
    
    int c;
    
    boolean d;
    
    public SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.c = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.d = bool;
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    class a implements Parcelable.ClassLoaderCreator {
      public Toolbar.SavedState a(Parcel param2Parcel) {
        return new Toolbar.SavedState(param2Parcel, null);
      }
      
      public Toolbar.SavedState b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.SavedState[] c(int param2Int) {
        return new Toolbar.SavedState[param2Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator {
    public Toolbar.SavedState a(Parcel param1Parcel) {
      return new Toolbar.SavedState(param1Parcel, null);
    }
    
    public Toolbar.SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.SavedState[] c(int param1Int) {
      return new Toolbar.SavedState[param1Int];
    }
  }
  
  class a implements ActionMenuView.e {
    a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      if (this.a.G.j(param1MenuItem))
        return true; 
      Toolbar.h h = this.a.I;
      return (h != null) ? h.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  class b implements Runnable {
    b(Toolbar this$0) {}
    
    public void run() {
      this.a.Q();
    }
  }
  
  class c implements androidx.appcompat.view.menu.g.a {
    c(Toolbar this$0) {}
    
    public boolean a(androidx.appcompat.view.menu.g param1g, MenuItem param1MenuItem) {
      androidx.appcompat.view.menu.g.a a1 = this.a.O;
      return (a1 != null && a1.a(param1g, param1MenuItem));
    }
    
    public void b(androidx.appcompat.view.menu.g param1g) {
      if (!this.a.a.J())
        this.a.G.k((Menu)param1g); 
      androidx.appcompat.view.menu.g.a a1 = this.a.O;
      if (a1 != null)
        a1.b(param1g); 
    }
  }
  
  class d implements View.OnClickListener {
    d(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.a.e();
    }
  }
  
  static abstract class e {
    static OnBackInvokedDispatcher a(View param1View) {
      return param1View.findOnBackInvokedDispatcher();
    }
    
    static OnBackInvokedCallback b(Runnable param1Runnable) {
      Objects.requireNonNull(param1Runnable);
      return new e1(param1Runnable);
    }
    
    static void c(Object param1Object1, Object param1Object2) {
      ((OnBackInvokedDispatcher)param1Object1).registerOnBackInvokedCallback(1000000, (OnBackInvokedCallback)param1Object2);
    }
    
    static void d(Object param1Object1, Object param1Object2) {
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  private class f implements m {
    androidx.appcompat.view.menu.g a;
    
    i b;
    
    f(Toolbar this$0) {}
    
    public void b(androidx.appcompat.view.menu.g param1g, boolean param1Boolean) {}
    
    public void c(boolean param1Boolean) {
      if (this.b != null) {
        androidx.appcompat.view.menu.g g1 = this.a;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (g1 != null) {
          int k = g1.size();
          int j = 0;
          while (true) {
            bool1 = bool2;
            if (j < k) {
              if (this.a.getItem(j) == this.b) {
                bool1 = true;
                break;
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          e(this.a, this.b); 
      } 
    }
    
    public boolean d() {
      return false;
    }
    
    public boolean e(androidx.appcompat.view.menu.g param1g, i param1i) {
      View view = this.c.i;
      if (view instanceof androidx.appcompat.view.c)
        ((androidx.appcompat.view.c)view).f(); 
      Toolbar toolbar = this.c;
      toolbar.removeView(toolbar.i);
      toolbar = this.c;
      toolbar.removeView((View)toolbar.h);
      toolbar = this.c;
      toolbar.i = null;
      toolbar.a();
      this.b = null;
      this.c.requestLayout();
      param1i.r(false);
      this.c.R();
      return true;
    }
    
    public boolean f(androidx.appcompat.view.menu.g param1g, i param1i) {
      this.c.g();
      ViewParent viewParent = this.c.h.getParent();
      Toolbar toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.h); 
        Toolbar toolbar1 = this.c;
        toolbar1.addView((View)toolbar1.h);
      } 
      this.c.i = param1i.getActionView();
      this.b = param1i;
      viewParent = this.c.i.getParent();
      toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.i); 
        Toolbar.g g1 = this.c.m();
        toolbar = this.c;
        g1.a = toolbar.n & 0x70 | 0x800003;
        g1.b = 2;
        toolbar.i.setLayoutParams((ViewGroup.LayoutParams)g1);
        Toolbar toolbar1 = this.c;
        toolbar1.addView(toolbar1.i);
      } 
      this.c.I();
      this.c.requestLayout();
      param1i.r(true);
      View view = this.c.i;
      if (view instanceof androidx.appcompat.view.c)
        ((androidx.appcompat.view.c)view).c(); 
      this.c.R();
      return true;
    }
    
    public int getId() {
      return 0;
    }
    
    public void h(Context param1Context, androidx.appcompat.view.menu.g param1g) {
      androidx.appcompat.view.menu.g g1 = this.a;
      if (g1 != null) {
        i i1 = this.b;
        if (i1 != null)
          g1.f(i1); 
      } 
      this.a = param1g;
    }
    
    public void i(Parcelable param1Parcelable) {}
    
    public boolean k(r param1r) {
      return false;
    }
    
    public Parcelable l() {
      return null;
    }
  }
  
  public static class g extends androidx.appcompat.app.a.a {
    int b = 0;
    
    public g(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public g(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public g(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public g(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    public g(androidx.appcompat.app.a.a param1a) {
      super(param1a);
    }
    
    public g(g param1g) {
      super(param1g);
      this.b = param1g.b;
    }
    
    void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface h {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */