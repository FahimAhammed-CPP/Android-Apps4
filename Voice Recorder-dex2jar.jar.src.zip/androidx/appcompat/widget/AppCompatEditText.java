package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import androidx.core.view.d;
import androidx.core.view.i0;
import androidx.core.view.n0;
import androidx.core.widget.j;
import androidx.core.widget.l;
import androidx.core.widget.n;
import y.c;
import y.f;

public class AppCompatEditText extends EditText implements i0, n {
  private final d a;
  
  private final x b;
  
  private final w c;
  
  private final l d;
  
  private final i e;
  
  private a f;
  
  public AppCompatEditText(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, d.a.editTextStyle);
  }
  
  public AppCompatEditText(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(y0.b(paramContext), paramAttributeSet, paramInt);
    x0.a((View)this, getContext());
    d d1 = new d((View)this);
    this.a = d1;
    d1.e(paramAttributeSet, paramInt);
    x x1 = new x((TextView)this);
    this.b = x1;
    x1.m(paramAttributeSet, paramInt);
    x1.b();
    this.c = new w((TextView)this);
    this.d = new l();
    i i1 = new i(this);
    this.e = i1;
    i1.c(paramAttributeSet, paramInt);
    d(i1);
  }
  
  private a getSuperCaller() {
    if (this.f == null)
      this.f = new a(this); 
    return this.f;
  }
  
  public d a(d paramd) {
    return this.d.a((View)this, paramd);
  }
  
  void d(i parami) {
    KeyListener keyListener = getKeyListener();
    if (parami.b(keyListener)) {
      boolean bool1 = isFocusable();
      boolean bool2 = isClickable();
      boolean bool3 = isLongClickable();
      int j = getInputType();
      KeyListener keyListener1 = parami.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(j);
      setFocusable(bool1);
      setClickable(bool2);
      setLongClickable(bool3);
    } 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.a;
    if (d1 != null)
      d1.b(); 
    x x1 = this.b;
    if (x1 != null)
      x1.b(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.q(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.a;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.a;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.b.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.b.k();
  }
  
  public Editable getText() {
    return (Build.VERSION.SDK_INT >= 28) ? super.getText() : getEditableText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      w w1 = this.c;
      if (w1 != null)
        return w1.a(); 
    } 
    return getSuperCaller().a();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection1 = super.onCreateInputConnection(paramEditorInfo);
    this.b.r((TextView)this, inputConnection1, paramEditorInfo);
    InputConnection inputConnection2 = k.a(inputConnection1, paramEditorInfo, (View)this);
    inputConnection1 = inputConnection2;
    if (inputConnection2 != null) {
      inputConnection1 = inputConnection2;
      if (Build.VERSION.SDK_INT <= 30) {
        String[] arrayOfString = n0.H((View)this);
        inputConnection1 = inputConnection2;
        if (arrayOfString != null) {
          c.d(paramEditorInfo, arrayOfString);
          inputConnection1 = f.c((View)this, inputConnection2, paramEditorInfo);
        } 
      } 
    } 
    return this.e.d(inputConnection1, paramEditorInfo);
  }
  
  public boolean onDragEvent(DragEvent paramDragEvent) {
    return r.a((View)this, paramDragEvent) ? true : super.onDragEvent(paramDragEvent);
  }
  
  public boolean onTextContextMenuItem(int paramInt) {
    return r.b((TextView)this, paramInt) ? true : super.onTextContextMenuItem(paramInt);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.a;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.a;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    x x1 = this.b;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    x x1 = this.b;
    if (x1 != null)
      x1.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.r((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.e.e(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.e.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.a;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.a;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.b.w(paramColorStateList);
    this.b.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.b.x(paramMode);
    this.b.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    x x1 = this.b;
    if (x1 != null)
      x1.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      w w1 = this.c;
      if (w1 != null) {
        w1.b(paramTextClassifier);
        return;
      } 
    } 
    getSuperCaller().b(paramTextClassifier);
  }
  
  class a {
    a(AppCompatEditText this$0) {}
    
    public TextClassifier a() {
      return AppCompatEditText.b(this.a);
    }
    
    public void b(TextClassifier param1TextClassifier) {
      AppCompatEditText.c(this.a, param1TextClassifier);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\AppCompatEditText.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */