package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;
import androidx.core.widget.h;
import d.j;

class o extends PopupWindow {
  private static final boolean b = false;
  
  private boolean a;
  
  public o(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    a(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  private void a(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    b1 b1 = b1.v(paramContext, paramAttributeSet, j.PopupWindow, paramInt1, paramInt2);
    paramInt1 = j.PopupWindow_overlapAnchor;
    if (b1.s(paramInt1))
      b(b1.a(paramInt1, false)); 
    setBackgroundDrawable(b1.g(j.PopupWindow_android_popupBackground));
    b1.w();
  }
  
  private void b(boolean paramBoolean) {
    if (b) {
      this.a = paramBoolean;
      return;
    } 
    h.a(this, paramBoolean);
  }
  
  public void showAsDropDown(View paramView, int paramInt1, int paramInt2) {
    int i = paramInt2;
    if (b) {
      i = paramInt2;
      if (this.a)
        i = paramInt2 - paramView.getHeight(); 
    } 
    super.showAsDropDown(paramView, paramInt1, i);
  }
  
  public void showAsDropDown(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    int i = paramInt2;
    if (b) {
      i = paramInt2;
      if (this.a)
        i = paramInt2 - paramView.getHeight(); 
    } 
    super.showAsDropDown(paramView, paramInt1, i, paramInt3);
  }
  
  public void update(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt2;
    if (b) {
      i = paramInt2;
      if (this.a)
        i = paramInt2 - paramView.getHeight(); 
    } 
    super.update(paramView, paramInt1, i, paramInt3, paramInt4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\widget\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */