package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.view.t0;
import androidx.core.view.u0;
import androidx.core.view.v0;
import java.util.ArrayList;
import java.util.Iterator;

public class h {
  final ArrayList a = new ArrayList();
  
  private long b = -1L;
  
  private Interpolator c;
  
  u0 d;
  
  private boolean e;
  
  private final v0 f = new a(this);
  
  public void a() {
    if (!this.e)
      return; 
    Iterator<t0> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((t0)iterator.next()).c(); 
    this.e = false;
  }
  
  void b() {
    this.e = false;
  }
  
  public h c(t0 paramt0) {
    if (!this.e)
      this.a.add(paramt0); 
    return this;
  }
  
  public h d(t0 paramt01, t0 paramt02) {
    this.a.add(paramt01);
    paramt02.j(paramt01.d());
    this.a.add(paramt02);
    return this;
  }
  
  public h e(long paramLong) {
    if (!this.e)
      this.b = paramLong; 
    return this;
  }
  
  public h f(Interpolator paramInterpolator) {
    if (!this.e)
      this.c = paramInterpolator; 
    return this;
  }
  
  public h g(u0 paramu0) {
    if (!this.e)
      this.d = paramu0; 
    return this;
  }
  
  public void h() {
    if (this.e)
      return; 
    for (t0 t0 : this.a) {
      long l = this.b;
      if (l >= 0L)
        t0.f(l); 
      Interpolator interpolator = this.c;
      if (interpolator != null)
        t0.g(interpolator); 
      if (this.d != null)
        t0.h((u0)this.f); 
      t0.l();
    } 
    this.e = true;
  }
  
  class a extends v0 {
    private boolean a = false;
    
    private int b = 0;
    
    a(h this$0) {}
    
    public void b(View param1View) {
      int i = this.b + 1;
      this.b = i;
      if (i == this.c.a.size()) {
        u0 u0 = this.c.d;
        if (u0 != null)
          u0.b(null); 
        d();
      } 
    }
    
    public void c(View param1View) {
      if (this.a)
        return; 
      this.a = true;
      u0 u0 = this.c.d;
      if (u0 != null)
        u0.c(null); 
    }
    
    void d() {
      this.b = 0;
      this.a = false;
      this.c.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\view\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */