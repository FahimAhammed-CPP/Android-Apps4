package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.m0;
import d.j;

public class ActionMenuItemView extends AppCompatTextView implements n.a, View.OnClickListener, ActionMenuView.a {
  i h;
  
  private CharSequence i;
  
  private Drawable j;
  
  g.b k;
  
  private m0 l;
  
  b m;
  
  private boolean n;
  
  private boolean o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Resources resources = paramContext.getResources();
    this.n = s();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.ActionMenuItemView, paramInt, 0);
    this.p = typedArray.getDimensionPixelSize(j.ActionMenuItemView_android_minWidth, 0);
    typedArray.recycle();
    this.r = (int)((resources.getDisplayMetrics()).density * 32.0F + 0.5F);
    setOnClickListener(this);
    this.q = -1;
    setSaveEnabled(false);
  }
  
  private boolean s() {
    Configuration configuration = getContext().getResources().getConfiguration();
    int j = configuration.screenWidthDp;
    int k = configuration.screenHeightDp;
    return (j >= 480 || (j >= 640 && k >= 480) || configuration.orientation == 2);
  }
  
  private void t() {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : Ljava/lang/CharSequence;
    //   4: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   7: istore_3
    //   8: iconst_1
    //   9: istore_2
    //   10: iload_2
    //   11: istore_1
    //   12: aload_0
    //   13: getfield j : Landroid/graphics/drawable/Drawable;
    //   16: ifnull -> 52
    //   19: aload_0
    //   20: getfield h : Landroidx/appcompat/view/menu/i;
    //   23: invokevirtual B : ()Z
    //   26: ifeq -> 50
    //   29: iload_2
    //   30: istore_1
    //   31: aload_0
    //   32: getfield n : Z
    //   35: ifne -> 52
    //   38: aload_0
    //   39: getfield o : Z
    //   42: ifeq -> 50
    //   45: iload_2
    //   46: istore_1
    //   47: goto -> 52
    //   50: iconst_0
    //   51: istore_1
    //   52: iload_3
    //   53: iconst_1
    //   54: ixor
    //   55: iload_1
    //   56: iand
    //   57: istore_1
    //   58: aconst_null
    //   59: astore #5
    //   61: iload_1
    //   62: ifeq -> 74
    //   65: aload_0
    //   66: getfield i : Ljava/lang/CharSequence;
    //   69: astore #4
    //   71: goto -> 77
    //   74: aconst_null
    //   75: astore #4
    //   77: aload_0
    //   78: aload #4
    //   80: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   83: aload_0
    //   84: getfield h : Landroidx/appcompat/view/menu/i;
    //   87: invokevirtual getContentDescription : ()Ljava/lang/CharSequence;
    //   90: astore #4
    //   92: aload #4
    //   94: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   97: ifeq -> 128
    //   100: iload_1
    //   101: ifeq -> 110
    //   104: aconst_null
    //   105: astore #4
    //   107: goto -> 119
    //   110: aload_0
    //   111: getfield h : Landroidx/appcompat/view/menu/i;
    //   114: invokevirtual getTitle : ()Ljava/lang/CharSequence;
    //   117: astore #4
    //   119: aload_0
    //   120: aload #4
    //   122: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   125: goto -> 134
    //   128: aload_0
    //   129: aload #4
    //   131: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   134: aload_0
    //   135: getfield h : Landroidx/appcompat/view/menu/i;
    //   138: invokevirtual getTooltipText : ()Ljava/lang/CharSequence;
    //   141: astore #4
    //   143: aload #4
    //   145: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   148: ifeq -> 178
    //   151: iload_1
    //   152: ifeq -> 162
    //   155: aload #5
    //   157: astore #4
    //   159: goto -> 171
    //   162: aload_0
    //   163: getfield h : Landroidx/appcompat/view/menu/i;
    //   166: invokevirtual getTitle : ()Ljava/lang/CharSequence;
    //   169: astore #4
    //   171: aload_0
    //   172: aload #4
    //   174: invokestatic a : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   177: return
    //   178: aload_0
    //   179: aload #4
    //   181: invokestatic a : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   184: return
  }
  
  public boolean a() {
    return r();
  }
  
  public boolean b() {
    return (r() && this.h.getIcon() == null);
  }
  
  public boolean d() {
    return true;
  }
  
  public void e(i parami, int paramInt) {
    this.h = parami;
    setIcon(parami.getIcon());
    setTitle(parami.i(this));
    setId(parami.getItemId());
    if (parami.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setEnabled(parami.isEnabled());
    if (parami.hasSubMenu() && this.l == null)
      this.l = new a(this); 
  }
  
  public CharSequence getAccessibilityClassName() {
    return Button.class.getName();
  }
  
  public i getItemData() {
    return this.h;
  }
  
  public void onClick(View paramView) {
    g.b b1 = this.k;
    if (b1 != null)
      b1.a(this.h); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.n = s();
    t();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool = r();
    if (bool) {
      int m = this.q;
      if (m >= 0)
        super.setPadding(m, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
    } 
    super.onMeasure(paramInt1, paramInt2);
    int j = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int k = getMeasuredWidth();
    if (j == Integer.MIN_VALUE) {
      paramInt1 = Math.min(paramInt1, this.p);
    } else {
      paramInt1 = this.p;
    } 
    if (j != 1073741824 && this.p > 0 && k < paramInt1)
      super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2); 
    if (!bool && this.j != null)
      super.setPadding((getMeasuredWidth() - this.j.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    super.onRestoreInstanceState(null);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.h.hasSubMenu()) {
      m0 m01 = this.l;
      if (m01 != null && m01.onTouch((View)this, paramMotionEvent))
        return true; 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean r() {
    return TextUtils.isEmpty(getText()) ^ true;
  }
  
  public void setCheckable(boolean paramBoolean) {}
  
  public void setChecked(boolean paramBoolean) {}
  
  public void setExpandedFormat(boolean paramBoolean) {
    if (this.o != paramBoolean) {
      this.o = paramBoolean;
      i i1 = this.h;
      if (i1 != null)
        i1.c(); 
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.j = paramDrawable;
    if (paramDrawable != null) {
      int n = paramDrawable.getIntrinsicWidth();
      int i1 = paramDrawable.getIntrinsicHeight();
      int m = this.r;
      int j = n;
      int k = i1;
      if (n > m) {
        float f = m / n;
        k = (int)(i1 * f);
        j = m;
      } 
      if (k > m) {
        float f = m / k;
        j = (int)(j * f);
      } else {
        m = k;
      } 
      paramDrawable.setBounds(0, 0, j, m);
    } 
    setCompoundDrawables(paramDrawable, null, null, null);
    t();
  }
  
  public void setItemInvoker(g.b paramb) {
    this.k = paramb;
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.q = paramInt1;
    super.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setPopupCallback(b paramb) {
    this.m = paramb;
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.i = paramCharSequence;
    t();
  }
  
  private class a extends m0 {
    public a(ActionMenuItemView this$0) {
      super((View)this$0);
    }
    
    public p b() {
      ActionMenuItemView.b b = this.j.m;
      return (b != null) ? b.a() : null;
    }
    
    protected boolean c() {
      ActionMenuItemView actionMenuItemView = this.j;
      g.b b = actionMenuItemView.k;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (b != null) {
        bool1 = bool2;
        if (b.a(actionMenuItemView.h)) {
          p p = b();
          bool1 = bool2;
          if (p != null) {
            bool1 = bool2;
            if (p.a())
              bool1 = true; 
          } 
        } 
      } 
      return bool1;
    }
  }
  
  public static abstract class b {
    public abstract p a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\view\menu\ActionMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */