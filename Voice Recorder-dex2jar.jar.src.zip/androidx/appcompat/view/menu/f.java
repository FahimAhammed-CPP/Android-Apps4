package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class f extends BaseAdapter {
  g a;
  
  private int b = -1;
  
  private boolean c;
  
  private final boolean d;
  
  private final LayoutInflater e;
  
  private final int f;
  
  public f(g paramg, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.d = paramBoolean;
    this.e = paramLayoutInflater;
    this.a = paramg;
    this.f = paramInt;
    a();
  }
  
  void a() {
    i i = this.a.x();
    if (i != null) {
      ArrayList<i> arrayList = this.a.B();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        if ((i)arrayList.get(j) == i) {
          this.b = j;
          return;
        } 
      } 
    } 
    this.b = -1;
  }
  
  public g b() {
    return this.a;
  }
  
  public i c(int paramInt) {
    ArrayList<i> arrayList;
    if (this.d) {
      arrayList = this.a.B();
    } else {
      arrayList = this.a.G();
    } 
    int j = this.b;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public void d(boolean paramBoolean) {
    this.c = paramBoolean;
  }
  
  public int getCount() {
    ArrayList arrayList;
    if (this.d) {
      arrayList = this.a.B();
    } else {
      arrayList = this.a.G();
    } 
    return (this.b < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.e.inflate(this.f, paramViewGroup, false); 
    int j = c(paramInt).getGroupId();
    int i = paramInt - 1;
    if (i >= 0) {
      i = c(i).getGroupId();
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.a.H() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    n.a a = (n.a)view;
    if (this.c)
      listMenuItemView.setForceShowIcon(true); 
    a.e(c(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */