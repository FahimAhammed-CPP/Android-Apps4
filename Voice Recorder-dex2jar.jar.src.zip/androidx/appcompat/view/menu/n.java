package androidx.appcompat.view.menu;

public interface n {
  void b(g paramg);
  
  public static interface a {
    boolean d();
    
    void e(i param1i, int param1Int);
    
    i getItemData();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\view\menu\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */