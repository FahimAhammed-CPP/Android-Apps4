package androidx.appcompat.view;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.view.LayoutInflater;
import d.i;

public class d extends ContextWrapper {
  private static Configuration f;
  
  private int a;
  
  private Resources.Theme b;
  
  private LayoutInflater c;
  
  private Configuration d;
  
  private Resources e;
  
  public d(Context paramContext, int paramInt) {
    super(paramContext);
    this.a = paramInt;
  }
  
  public d(Context paramContext, Resources.Theme paramTheme) {
    super(paramContext);
    this.b = paramTheme;
  }
  
  private Resources b() {
    if (this.e == null) {
      Configuration configuration = this.d;
      if (configuration == null || (Build.VERSION.SDK_INT >= 26 && e(configuration))) {
        this.e = super.getResources();
        return this.e;
      } 
      this.e = a.a(this, this.d).getResources();
    } 
    return this.e;
  }
  
  private void d() {
    boolean bool;
    if (this.b == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      this.b = getResources().newTheme();
      Resources.Theme theme = getBaseContext().getTheme();
      if (theme != null)
        this.b.setTo(theme); 
    } 
    f(this.b, this.a, bool);
  }
  
  private static boolean e(Configuration paramConfiguration) {
    if (paramConfiguration == null)
      return true; 
    if (f == null) {
      Configuration configuration = new Configuration();
      configuration.fontScale = 0.0F;
      f = configuration;
    } 
    return paramConfiguration.equals(f);
  }
  
  public void a(Configuration paramConfiguration) {
    if (this.e == null) {
      if (this.d == null) {
        this.d = new Configuration(paramConfiguration);
        return;
      } 
      throw new IllegalStateException("Override configuration has already been set");
    } 
    throw new IllegalStateException("getResources() or getAssets() has already been called");
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(paramContext);
  }
  
  public int c() {
    return this.a;
  }
  
  protected void f(Resources.Theme paramTheme, int paramInt, boolean paramBoolean) {
    paramTheme.applyStyle(paramInt, true);
  }
  
  public AssetManager getAssets() {
    return getResources().getAssets();
  }
  
  public Resources getResources() {
    return b();
  }
  
  public Object getSystemService(String paramString) {
    if ("layout_inflater".equals(paramString)) {
      if (this.c == null)
        this.c = LayoutInflater.from(getBaseContext()).cloneInContext((Context)this); 
      return this.c;
    } 
    return getBaseContext().getSystemService(paramString);
  }
  
  public Resources.Theme getTheme() {
    Resources.Theme theme = this.b;
    if (theme != null)
      return theme; 
    if (this.a == 0)
      this.a = i.Theme_AppCompat_Light; 
    d();
    return this.b;
  }
  
  public void setTheme(int paramInt) {
    if (this.a != paramInt) {
      this.a = paramInt;
      d();
    } 
  }
  
  static abstract class a {
    static Context a(d param1d, Configuration param1Configuration) {
      return param1d.createConfigurationContext(param1Configuration);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\view\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */