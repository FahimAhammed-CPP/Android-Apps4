package androidx.appcompat.view;

import android.content.Context;
import android.content.res.Configuration;
import d.b;

public class a {
  private Context a;
  
  private a(Context paramContext) {
    this.a = paramContext;
  }
  
  public static a b(Context paramContext) {
    return new a(paramContext);
  }
  
  public boolean a() {
    return ((this.a.getApplicationInfo()).targetSdkVersion < 14);
  }
  
  public int c() {
    return (this.a.getResources().getDisplayMetrics()).widthPixels / 2;
  }
  
  public int d() {
    Configuration configuration = this.a.getResources().getConfiguration();
    int i = configuration.screenWidthDp;
    int j = configuration.screenHeightDp;
    return (configuration.smallestScreenWidthDp > 600 || i > 600 || (i > 960 && j > 720) || (i > 720 && j > 960)) ? 5 : ((i >= 500 || (i > 640 && j > 480) || (i > 480 && j > 640)) ? 4 : ((i >= 360) ? 3 : 2));
  }
  
  public boolean e() {
    return this.a.getResources().getBoolean(b.abc_action_bar_embed_tabs);
  }
  
  public boolean f() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\appcompat\view\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */