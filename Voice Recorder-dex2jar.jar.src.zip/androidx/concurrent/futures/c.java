package androidx.concurrent.futures;

import java.lang.ref.WeakReference;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

public abstract class c {
  public static v4.a a(c paramc) {
    a a = new a();
    d d = new d(a);
    a.b = d;
    a.a = paramc.getClass();
    try {
      Object object = paramc.a(a);
      if (object != null) {
        a.a = object;
        return d;
      } 
    } catch (Exception exception) {
      d.c(exception);
    } 
    return d;
  }
  
  public static final class a {
    Object a;
    
    c.d b;
    
    private d c = d.A();
    
    private boolean d;
    
    private void d() {
      this.a = null;
      this.b = null;
      this.c = null;
    }
    
    void a() {
      this.a = null;
      this.b = null;
      this.c.u(null);
    }
    
    public boolean b(Object param1Object) {
      boolean bool = true;
      this.d = true;
      c.d d1 = this.b;
      if (d1 == null || !d1.b(param1Object))
        bool = false; 
      if (bool)
        d(); 
      return bool;
    }
    
    public boolean c() {
      boolean bool = true;
      this.d = true;
      c.d d1 = this.b;
      if (d1 == null || !d1.a(true))
        bool = false; 
      if (bool)
        d(); 
      return bool;
    }
    
    public boolean e(Throwable param1Throwable) {
      boolean bool = true;
      this.d = true;
      c.d d1 = this.b;
      if (d1 == null || !d1.c(param1Throwable))
        bool = false; 
      if (bool)
        d(); 
      return bool;
    }
    
    protected void finalize() {
      c.d d1 = this.b;
      if (d1 != null && !d1.isDone()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("The completer object was garbage collected - this future would otherwise never complete. The tag was: ");
        stringBuilder.append(this.a);
        d1.c(new c.b(stringBuilder.toString()));
      } 
      if (!this.d) {
        d d2 = this.c;
        if (d2 != null)
          d2.u(null); 
      } 
    }
  }
  
  static final class b extends Throwable {
    b(String param1String) {
      super(param1String);
    }
    
    public Throwable fillInStackTrace() {
      /* monitor enter ThisExpression{InnerObjectType{ObjectType{androidx/concurrent/futures/c}.Landroidx/concurrent/futures/c$b;}} */
      /* monitor exit ThisExpression{InnerObjectType{ObjectType{androidx/concurrent/futures/c}.Landroidx/concurrent/futures/c$b;}} */
      return this;
    }
  }
  
  public static interface c {
    Object a(c.a param1a);
  }
  
  private static final class d implements v4.a {
    final WeakReference a;
    
    private final a b = new a(this);
    
    d(c.a param1a) {
      this.a = new WeakReference<c.a>(param1a);
    }
    
    boolean a(boolean param1Boolean) {
      return this.b.cancel(param1Boolean);
    }
    
    public void addListener(Runnable param1Runnable, Executor param1Executor) {
      this.b.addListener(param1Runnable, param1Executor);
    }
    
    boolean b(Object param1Object) {
      return this.b.u(param1Object);
    }
    
    boolean c(Throwable param1Throwable) {
      return this.b.w(param1Throwable);
    }
    
    public boolean cancel(boolean param1Boolean) {
      c.a a1 = this.a.get();
      param1Boolean = this.b.cancel(param1Boolean);
      if (param1Boolean && a1 != null)
        a1.a(); 
      return param1Boolean;
    }
    
    public Object get() {
      return this.b.get();
    }
    
    public Object get(long param1Long, TimeUnit param1TimeUnit) {
      return this.b.get(param1Long, param1TimeUnit);
    }
    
    public boolean isCancelled() {
      return this.b.isCancelled();
    }
    
    public boolean isDone() {
      return this.b.isDone();
    }
    
    public String toString() {
      return this.b.toString();
    }
    
    class a extends a {
      a(c.d this$0) {}
      
      protected String p() {
        c.a a1 = this.h.a.get();
        if (a1 == null)
          return "Completer object has been garbage collected, future will fail soon"; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("tag=[");
        stringBuilder.append(a1.a);
        stringBuilder.append("]");
        return stringBuilder.toString();
      }
    }
  }
  
  class a extends a {
    a(c this$0) {}
    
    protected String p() {
      c.a a1 = this.h.a.get();
      if (a1 == null)
        return "Completer object has been garbage collected, future will fail soon"; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("tag=[");
      stringBuilder.append(a1.a);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\concurrent\futures\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */