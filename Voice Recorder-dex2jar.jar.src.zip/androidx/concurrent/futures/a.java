package androidx.concurrent.futures;

import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;
import v4.a;

public abstract class a implements a {
  static final boolean d = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
  
  private static final Logger e = Logger.getLogger(a.class.getName());
  
  static final b f;
  
  private static final Object g = new Object();
  
  volatile Object a;
  
  volatile e b;
  
  volatile h c;
  
  private void a(StringBuilder paramStringBuilder) {
    try {
      Object object = n((Future)this);
      paramStringBuilder.append("SUCCESS, result=[");
      paramStringBuilder.append(x(object));
      paramStringBuilder.append("]");
      return;
    } catch (ExecutionException executionException) {
      paramStringBuilder.append("FAILURE, cause=[");
      paramStringBuilder.append(executionException.getCause());
      paramStringBuilder.append("]");
      return;
    } catch (CancellationException cancellationException) {
      paramStringBuilder.append("CANCELLED");
      return;
    } catch (RuntimeException runtimeException) {
      paramStringBuilder.append("UNKNOWN, cause=[");
      paramStringBuilder.append(runtimeException.getClass());
      paramStringBuilder.append(" thrown from get()]");
      return;
    } 
  }
  
  private static CancellationException d(String paramString, Throwable paramThrowable) {
    CancellationException cancellationException = new CancellationException(paramString);
    cancellationException.initCause(paramThrowable);
    return cancellationException;
  }
  
  static Object e(Object paramObject) {
    paramObject.getClass();
    return paramObject;
  }
  
  private e f(e parame) {
    while (true) {
      e e1 = this.b;
      if (f.a(this, e1, e.d)) {
        e e2 = parame;
        for (parame = e1; parame != null; parame = e1) {
          e1 = parame.c;
          parame.c = e2;
          e2 = parame;
        } 
        return e2;
      } 
    } 
  }
  
  static void g(a parama) {
    parama.r();
    parama.b();
    for (e e1 = parama.f(null); e1 != null; e1 = e2) {
      e e2 = e1.c;
      i(e1.a, e1.b);
    } 
  }
  
  private static void i(Runnable paramRunnable, Executor paramExecutor) {
    try {
      paramExecutor.execute(paramRunnable);
      return;
    } catch (RuntimeException runtimeException) {
      Logger logger = e;
      Level level = Level.SEVERE;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("RuntimeException while executing runnable ");
      stringBuilder.append(paramRunnable);
      stringBuilder.append(" with executor ");
      stringBuilder.append(paramExecutor);
      logger.log(level, stringBuilder.toString(), runtimeException);
      return;
    } 
  }
  
  private Object k(Object paramObject) {
    if (!(paramObject instanceof c)) {
      if (!(paramObject instanceof d)) {
        Object object = paramObject;
        if (paramObject == g)
          object = null; 
        return object;
      } 
      throw new ExecutionException(((d)paramObject).a);
    } 
    throw d("Task was cancelled.", ((c)paramObject).b);
  }
  
  static Object n(Future<Object> paramFuture) {
    boolean bool = false;
    while (true) {
      try {
        return paramFuture.get();
      } catch (InterruptedException interruptedException) {
      
      } finally {
        if (bool)
          Thread.currentThread().interrupt(); 
      } 
    } 
  }
  
  private void r() {
    h h1;
    do {
      h1 = this.c;
    } while (!f.c(this, h1, h.c));
    while (h1 != null) {
      h1.b();
      h1 = h1.b;
    } 
  }
  
  private void t(h paramh) {
    paramh.a = null;
    label24: while (true) {
      paramh = this.c;
      if (paramh == h.c)
        return; 
      for (Object object = null; paramh != null; object = object1) {
        Object object1;
        h h1 = paramh.b;
        if (paramh.a != null) {
          object1 = paramh;
        } else if (object != null) {
          ((h)object).b = h1;
          object1 = object;
          if (((h)object).a == null)
            continue label24; 
        } else {
          object1 = object;
          if (!f.c(this, paramh, h1))
            continue label24; 
        } 
        paramh = h1;
      } 
      break;
    } 
  }
  
  private String x(Object paramObject) {
    return (paramObject == this) ? "this future" : String.valueOf(paramObject);
  }
  
  public final void addListener(Runnable paramRunnable, Executor paramExecutor) {
    e(paramRunnable);
    e(paramExecutor);
    e e1 = this.b;
    if (e1 != e.d) {
      e e2;
      e e3 = new e(paramRunnable, paramExecutor);
      do {
        e3.c = e1;
        if (f.a(this, e1, e3))
          return; 
        e2 = this.b;
        e1 = e2;
      } while (e2 != e.d);
    } 
    i(paramRunnable, paramExecutor);
  }
  
  protected void b() {}
  
  public final boolean cancel(boolean paramBoolean) {
    boolean bool;
    Object object = this.a;
    if (object == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if ((bool | false) != 0) {
      c c;
      if (d) {
        c = new c(paramBoolean, new CancellationException("Future.cancel() was called."));
      } else if (paramBoolean) {
        c = c.c;
      } else {
        c = c.d;
      } 
      if (f.b(this, object, c)) {
        if (paramBoolean)
          o(); 
        g(this);
        return true;
      } 
    } 
    return false;
  }
  
  public final Object get() {
    if (!Thread.interrupted()) {
      boolean bool;
      Object object = this.a;
      if (object != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool & true) != 0)
        return k(object); 
      object = this.c;
      if (object != h.c) {
        h h1;
        h h2 = new h();
        do {
          h2.a((h)object);
          if (f.c(this, (h)object, h2))
            while (true) {
              LockSupport.park(this);
              if (!Thread.interrupted()) {
                object = this.a;
                if (object != null) {
                  bool = true;
                } else {
                  bool = false;
                } 
                if ((bool & true) != 0)
                  return k(object); 
                continue;
              } 
              t(h2);
              throw new InterruptedException();
            }  
          h1 = this.c;
          object = h1;
        } while (h1 != h.c);
      } 
      return k(this.a);
    } 
    throw new InterruptedException();
  }
  
  public final Object get(long paramLong, TimeUnit paramTimeUnit) {
    long l = paramTimeUnit.toNanos(paramLong);
    if (!Thread.interrupted()) {
      boolean bool;
      long l2;
      Object object = this.a;
      if (object != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool & true) != 0)
        return k(object); 
      if (l > 0L) {
        l2 = System.nanoTime() + l;
      } else {
        l2 = 0L;
      } 
      long l1 = l;
      if (l >= 1000L) {
        object = this.c;
        if (object != h.c) {
          h h1 = new h();
          label75: while (true) {
            h1.a((h)object);
            if (f.c(this, (h)object, h1))
              while (true) {
                LockSupport.parkNanos(this, l);
                if (!Thread.interrupted()) {
                  object = this.a;
                  if (object != null) {
                    bool = true;
                  } else {
                    bool = false;
                  } 
                  if ((bool & true) != 0)
                    return k(object); 
                  l1 = l2 - System.nanoTime();
                  l = l1;
                  if (l1 < 1000L) {
                    t(h1);
                    break;
                  } 
                  continue;
                } 
                t(h1);
                throw new InterruptedException();
              }  
            h h2 = this.c;
            object = h2;
            if (h2 == h.c)
              break label75; 
          } 
        } else {
          return k(this.a);
        } 
      } 
      while (l1 > 0L) {
        object = this.a;
        if (object != null) {
          bool = true;
        } else {
          bool = false;
        } 
        if ((bool & true) != 0)
          return k(object); 
        if (!Thread.interrupted()) {
          l1 = l2 - System.nanoTime();
          continue;
        } 
        throw new InterruptedException();
      } 
      String str3 = toString();
      String str2 = paramTimeUnit.toString();
      object = Locale.ROOT;
      String str4 = str2.toLowerCase((Locale)object);
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Waited ");
      stringBuilder2.append(paramLong);
      stringBuilder2.append(" ");
      stringBuilder2.append(paramTimeUnit.toString().toLowerCase((Locale)object));
      String str1 = stringBuilder2.toString();
      object = str1;
      if (l1 + 1000L < 0L) {
        object = new StringBuilder();
        object.append(str1);
        object.append(" (plus ");
        object = object.toString();
        l1 = -l1;
        paramLong = paramTimeUnit.convert(l1, TimeUnit.NANOSECONDS);
        l1 -= paramTimeUnit.toNanos(paramLong);
        int i = paramLong cmp 0L;
        if (i == 0 || l1 > 1000L) {
          bool = true;
        } else {
          bool = false;
        } 
        Object object1 = object;
        if (i > 0) {
          object1 = new StringBuilder();
          object1.append((String)object);
          object1.append(paramLong);
          object1.append(" ");
          object1.append(str4);
          object = object1.toString();
          object1 = object;
          if (bool) {
            object1 = new StringBuilder();
            object1.append((String)object);
            object1.append(",");
            object1 = object1.toString();
          } 
          object = new StringBuilder();
          object.append((String)object1);
          object.append(" ");
          object1 = object.toString();
        } 
        object = object1;
        if (bool) {
          object = new StringBuilder();
          object.append((String)object1);
          object.append(l1);
          object.append(" nanoseconds ");
          object = object.toString();
        } 
        object1 = new StringBuilder();
        object1.append((String)object);
        object1.append("delay)");
        object = object1.toString();
      } 
      if (isDone()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((String)object);
        stringBuilder.append(" but future completed as timeout expired");
        throw new TimeoutException(stringBuilder.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append((String)object);
      stringBuilder1.append(" for ");
      stringBuilder1.append(str3);
      throw new TimeoutException(stringBuilder1.toString());
    } 
    throw new InterruptedException();
  }
  
  public final boolean isCancelled() {
    return this.a instanceof c;
  }
  
  public final boolean isDone() {
    boolean bool;
    if (this.a != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool & true;
  }
  
  protected void o() {}
  
  protected String p() {
    if (this instanceof ScheduledFuture) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remaining delay=[");
      stringBuilder.append(((ScheduledFuture)this).getDelay(TimeUnit.MILLISECONDS));
      stringBuilder.append(" ms]");
      return stringBuilder.toString();
    } 
    return null;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.toString());
    stringBuilder.append("[status=");
    if (isCancelled()) {
      stringBuilder.append("CANCELLED");
    } else if (isDone()) {
      a(stringBuilder);
    } else {
      String str;
      try {
        str = p();
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Exception thrown from implementation: ");
        stringBuilder1.append(runtimeException.getClass());
        str = stringBuilder1.toString();
      } 
      if (str != null && !str.isEmpty()) {
        stringBuilder.append("PENDING, info=[");
        stringBuilder.append(str);
        stringBuilder.append("]");
      } else if (isDone()) {
        a(stringBuilder);
      } else {
        stringBuilder.append("PENDING");
      } 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  protected boolean u(Object paramObject) {
    Object object = paramObject;
    if (paramObject == null)
      object = g; 
    if (f.b(this, null, object)) {
      g(this);
      return true;
    } 
    return false;
  }
  
  protected boolean w(Throwable paramThrowable) {
    d d = new d((Throwable)e(paramThrowable));
    if (f.b(this, null, d)) {
      g(this);
      return true;
    } 
    return false;
  }
  
  protected final boolean z() {
    Object object = this.a;
    return (object instanceof c && ((c)object).a);
  }
  
  static {
    Exception exception;
    g g;
  }
  
  static {
    try {
      f f = new f(AtomicReferenceFieldUpdater.newUpdater(h.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(h.class, h.class, "b"), AtomicReferenceFieldUpdater.newUpdater(a.class, h.class, "c"), AtomicReferenceFieldUpdater.newUpdater(a.class, e.class, "b"), AtomicReferenceFieldUpdater.newUpdater(a.class, Object.class, "a"));
    } finally {
      exception = null;
    } 
    f = g;
    if (exception != null)
      e.log(Level.SEVERE, "SafeAtomicHelper is broken!", exception); 
  }
  
  private static abstract class b {
    private b() {}
    
    abstract boolean a(a param1a, a.e param1e1, a.e param1e2);
    
    abstract boolean b(a param1a, Object param1Object1, Object param1Object2);
    
    abstract boolean c(a param1a, a.h param1h1, a.h param1h2);
    
    abstract void d(a.h param1h1, a.h param1h2);
    
    abstract void e(a.h param1h, Thread param1Thread);
  }
  
  private static final class c {
    static final c c = new c(true, null);
    
    static final c d = new c(false, null);
    
    final boolean a;
    
    final Throwable b;
    
    static {
    
    }
    
    c(boolean param1Boolean, Throwable param1Throwable) {
      this.a = param1Boolean;
      this.b = param1Throwable;
    }
    
    static {
      if (a.d) {
        d = null;
        c = null;
        return;
      } 
    }
  }
  
  private static final class d {
    static final d b = new d(new a("Failure occurred while trying to finish a future."));
    
    final Throwable a;
    
    d(Throwable param1Throwable) {
      this.a = (Throwable)a.e(param1Throwable);
    }
    
    class a extends Throwable {
      a(a.d this$0) {
        super((String)this$0);
      }
      
      public Throwable fillInStackTrace() {
        /* monitor enter ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/concurrent/futures/a}.Landroidx/concurrent/futures/a$d;}.Landroidx/concurrent/futures/a$d$a;}} */
        /* monitor exit ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/concurrent/futures/a}.Landroidx/concurrent/futures/a$d;}.Landroidx/concurrent/futures/a$d$a;}} */
        return this;
      }
    }
  }
  
  class a extends Throwable {
    a(a this$0) {
      super((String)this$0);
    }
    
    public Throwable fillInStackTrace() {
      /* monitor enter ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/concurrent/futures/a}.Landroidx/concurrent/futures/a$d;}.Landroidx/concurrent/futures/a$d$a;}} */
      /* monitor exit ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/concurrent/futures/a}.Landroidx/concurrent/futures/a$d;}.Landroidx/concurrent/futures/a$d$a;}} */
      return this;
    }
  }
  
  private static final class e {
    static final e d = new e(null, null);
    
    final Runnable a;
    
    final Executor b;
    
    e c;
    
    e(Runnable param1Runnable, Executor param1Executor) {
      this.a = param1Runnable;
      this.b = param1Executor;
    }
  }
  
  private static final class f extends b {
    final AtomicReferenceFieldUpdater a;
    
    final AtomicReferenceFieldUpdater b;
    
    final AtomicReferenceFieldUpdater c;
    
    final AtomicReferenceFieldUpdater d;
    
    final AtomicReferenceFieldUpdater e;
    
    f(AtomicReferenceFieldUpdater param1AtomicReferenceFieldUpdater1, AtomicReferenceFieldUpdater param1AtomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater param1AtomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater param1AtomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater param1AtomicReferenceFieldUpdater5) {
      super(null);
      this.a = param1AtomicReferenceFieldUpdater1;
      this.b = param1AtomicReferenceFieldUpdater2;
      this.c = param1AtomicReferenceFieldUpdater3;
      this.d = param1AtomicReferenceFieldUpdater4;
      this.e = param1AtomicReferenceFieldUpdater5;
    }
    
    boolean a(a param1a, a.e param1e1, a.e param1e2) {
      return b.a(this.d, param1a, param1e1, param1e2);
    }
    
    boolean b(a param1a, Object param1Object1, Object param1Object2) {
      return b.a(this.e, param1a, param1Object1, param1Object2);
    }
    
    boolean c(a param1a, a.h param1h1, a.h param1h2) {
      return b.a(this.c, param1a, param1h1, param1h2);
    }
    
    void d(a.h param1h1, a.h param1h2) {
      this.b.lazySet(param1h1, param1h2);
    }
    
    void e(a.h param1h, Thread param1Thread) {
      this.a.lazySet(param1h, param1Thread);
    }
  }
  
  private static final class g extends b {
    g() {
      super(null);
    }
    
    boolean a(a param1a, a.e param1e1, a.e param1e2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield b : Landroidx/concurrent/futures/a$e;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield b : Landroidx/concurrent/futures/a$e;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    boolean b(a param1a, Object param1Object1, Object param1Object2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield a : Ljava/lang/Object;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield a : Ljava/lang/Object;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    boolean c(a param1a, a.h param1h1, a.h param1h2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield c : Landroidx/concurrent/futures/a$h;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield c : Landroidx/concurrent/futures/a$h;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    void d(a.h param1h1, a.h param1h2) {
      param1h1.b = param1h2;
    }
    
    void e(a.h param1h, Thread param1Thread) {
      param1h.a = param1Thread;
    }
  }
  
  private static final class h {
    static final h c = new h(false);
    
    volatile Thread a;
    
    volatile h b;
    
    h() {
      a.f.e(this, Thread.currentThread());
    }
    
    h(boolean param1Boolean) {}
    
    void a(h param1h) {
      a.f.d(this, param1h);
    }
    
    void b() {
      Thread thread = this.a;
      if (thread != null) {
        this.a = null;
        LockSupport.unpark(thread);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\concurrent\futures\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */