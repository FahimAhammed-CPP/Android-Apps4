package androidx.concurrent.futures;

public final class d extends a {
  public static d A() {
    return new d();
  }
  
  public boolean u(Object paramObject) {
    return super.u(paramObject);
  }
  
  public boolean w(Throwable paramThrowable) {
    return super.w(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\concurrent\futures\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */