package androidx.activity;

public abstract class p {
  public static final int report_drawn = 2131362457;
  
  public static final int view_tree_on_back_pressed_dispatcher_owner = 2131362721;
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */