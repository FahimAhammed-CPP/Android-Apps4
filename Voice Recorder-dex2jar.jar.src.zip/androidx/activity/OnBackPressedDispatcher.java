package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.h;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.n;
import g8.t;
import h8.h;
import java.util.Iterator;
import s8.k;
import s8.l;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  private final h b;
  
  private r8.a c;
  
  private OnBackInvokedCallback d;
  
  private OnBackInvokedDispatcher e;
  
  private boolean f;
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
    this.b = new h();
    if (Build.VERSION.SDK_INT >= 33) {
      this.c = new a(this);
      this.d = c.a.b(new b(this));
    } 
  }
  
  public final void b(m paramm) {
    k.e(paramm, "onBackPressedCallback");
    d(paramm);
  }
  
  public final void c(n paramn, m paramm) {
    k.e(paramn, "owner");
    k.e(paramm, "onBackPressedCallback");
    h h1 = paramn.getLifecycle();
    if (h1.b() == h.b.a)
      return; 
    paramm.a(new LifecycleOnBackPressedCancellable(this, h1, paramm));
    if (Build.VERSION.SDK_INT >= 33) {
      h();
      paramm.g(this.c);
    } 
  }
  
  public final a d(m paramm) {
    k.e(paramm, "onBackPressedCallback");
    this.b.add(paramm);
    d d = new d(this, paramm);
    paramm.a(d);
    if (Build.VERSION.SDK_INT >= 33) {
      h();
      paramm.g(this.c);
    } 
    return d;
  }
  
  public final boolean e() {
    h h1 = this.b;
    boolean bool = h1 instanceof java.util.Collection;
    boolean bool1 = false;
    if (bool && h1.isEmpty())
      return false; 
    Iterator<m> iterator = h1.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        if (((m)iterator.next()).c()) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  public final void f() {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Lh8/h;
    //   4: astore_1
    //   5: aload_1
    //   6: aload_1
    //   7: invokeinterface size : ()I
    //   12: invokeinterface listIterator : (I)Ljava/util/ListIterator;
    //   17: astore_2
    //   18: aload_2
    //   19: invokeinterface hasPrevious : ()Z
    //   24: ifeq -> 47
    //   27: aload_2
    //   28: invokeinterface previous : ()Ljava/lang/Object;
    //   33: astore_1
    //   34: aload_1
    //   35: checkcast androidx/activity/m
    //   38: invokevirtual c : ()Z
    //   41: ifeq -> 18
    //   44: goto -> 49
    //   47: aconst_null
    //   48: astore_1
    //   49: aload_1
    //   50: checkcast androidx/activity/m
    //   53: astore_1
    //   54: aload_1
    //   55: ifnull -> 63
    //   58: aload_1
    //   59: invokevirtual b : ()V
    //   62: return
    //   63: aload_0
    //   64: getfield a : Ljava/lang/Runnable;
    //   67: astore_1
    //   68: aload_1
    //   69: ifnull -> 78
    //   72: aload_1
    //   73: invokeinterface run : ()V
    //   78: return
  }
  
  public final void g(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    k.e(paramOnBackInvokedDispatcher, "invoker");
    this.e = paramOnBackInvokedDispatcher;
    h();
  }
  
  public final void h() {
    boolean bool = e();
    OnBackInvokedDispatcher onBackInvokedDispatcher = this.e;
    OnBackInvokedCallback onBackInvokedCallback = this.d;
    if (onBackInvokedDispatcher != null && onBackInvokedCallback != null) {
      if (bool && !this.f) {
        c.a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
        this.f = true;
        return;
      } 
      if (!bool && this.f) {
        c.a.e(onBackInvokedDispatcher, onBackInvokedCallback);
        this.f = false;
      } 
    } 
  }
  
  private final class LifecycleOnBackPressedCancellable implements l, a {
    private final h a;
    
    private final m b;
    
    private a c;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, h param1h, m param1m) {
      this.a = param1h;
      this.b = param1m;
      param1h.a((m)this);
    }
    
    public void c(n param1n, h.a param1a) {
      k.e(param1n, "source");
      k.e(param1a, "event");
      if (param1a == h.a.ON_START) {
        this.c = this.d.d(this.b);
        return;
      } 
      if (param1a == h.a.ON_STOP) {
        a a1 = this.c;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1a == h.a.ON_DESTROY) {
        cancel();
      } 
    }
    
    public void cancel() {
      this.a.c((m)this);
      this.b.e(this);
      a a1 = this.c;
      if (a1 != null)
        a1.cancel(); 
      this.c = null;
    }
  }
  
  static final class a extends l implements r8.a {
    a(OnBackPressedDispatcher param1OnBackPressedDispatcher) {
      super(0);
    }
    
    public final void e() {
      this.a.h();
    }
  }
  
  static final class b extends l implements r8.a {
    b(OnBackPressedDispatcher param1OnBackPressedDispatcher) {
      super(0);
    }
    
    public final void e() {
      this.a.f();
    }
  }
  
  public static final class c {
    public static final c a = new c();
    
    private static final void c(r8.a param1a) {
      k.e(param1a, "$onBackInvoked");
      param1a.b();
    }
    
    public final OnBackInvokedCallback b(r8.a param1a) {
      k.e(param1a, "onBackInvoked");
      return new n(param1a);
    }
    
    public final void d(Object param1Object1, int param1Int, Object param1Object2) {
      k.e(param1Object1, "dispatcher");
      k.e(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).registerOnBackInvokedCallback(param1Int, (OnBackInvokedCallback)param1Object2);
    }
    
    public final void e(Object param1Object1, Object param1Object2) {
      k.e(param1Object1, "dispatcher");
      k.e(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  private final class d implements a {
    private final m a;
    
    public d(OnBackPressedDispatcher this$0, m param1m) {
      this.a = param1m;
    }
    
    public void cancel() {
      OnBackPressedDispatcher.a(this.b).remove(this.a);
      this.a.e(this);
      if (Build.VERSION.SDK_INT >= 33) {
        this.a.g(null);
        this.b.h();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */