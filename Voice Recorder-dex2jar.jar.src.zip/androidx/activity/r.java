package androidx.activity;

import android.view.View;
import s8.k;

public abstract class r {
  public static final void a(View paramView, o paramo) {
    k.e(paramView, "<this>");
    k.e(paramo, "onBackPressedDispatcherOwner");
    paramView.setTag(p.view_tree_on_back_pressed_dispatcher_owner, paramo);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */