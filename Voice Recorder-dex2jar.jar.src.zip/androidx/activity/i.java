package androidx.activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.h;
import androidx.lifecycle.n;
import androidx.lifecycle.o;
import androidx.lifecycle.o0;
import androidx.savedstate.a;
import c1.c;
import c1.d;
import c1.e;
import s8.k;

public class i extends Dialog implements n, o, d {
  private o a;
  
  private final c b = c.d.a(this);
  
  private final OnBackPressedDispatcher c = new OnBackPressedDispatcher(new h(this));
  
  public i(Context paramContext, int paramInt) {
    super(paramContext, paramInt);
  }
  
  private final o d() {
    o o2 = this.a;
    o o1 = o2;
    if (o2 == null) {
      o1 = new o(this);
      this.a = o1;
    } 
    return o1;
  }
  
  private final void e() {
    Window window3 = getWindow();
    k.b(window3);
    View view3 = window3.getDecorView();
    k.d(view3, "window!!.decorView");
    o0.a(view3, this);
    Window window2 = getWindow();
    k.b(window2);
    View view2 = window2.getDecorView();
    k.d(view2, "window!!.decorView");
    r.a(view2, this);
    Window window1 = getWindow();
    k.b(window1);
    View view1 = window1.getDecorView();
    k.d(view1, "window!!.decorView");
    e.a(view1, this);
  }
  
  private static final void f(i parami) {
    k.e(parami, "this$0");
    parami.onBackPressed();
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    k.e(paramView, "view");
    e();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public h getLifecycle() {
    return (h)d();
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.c;
  }
  
  public a getSavedStateRegistry() {
    return this.b.b();
  }
  
  public void onBackPressed() {
    this.c.f();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (Build.VERSION.SDK_INT >= 33) {
      OnBackPressedDispatcher onBackPressedDispatcher = this.c;
      OnBackInvokedDispatcher onBackInvokedDispatcher = g.a(this);
      k.d(onBackInvokedDispatcher, "onBackInvokedDispatcher");
      onBackPressedDispatcher.g(onBackInvokedDispatcher);
    } 
    this.b.d(paramBundle);
    d().h(h.a.ON_CREATE);
  }
  
  public Bundle onSaveInstanceState() {
    Bundle bundle = super.onSaveInstanceState();
    k.d(bundle, "super.onSaveInstanceState()");
    this.b.e(bundle);
    return bundle;
  }
  
  protected void onStart() {
    super.onStart();
    d().h(h.a.ON_RESUME);
  }
  
  protected void onStop() {
    d().h(h.a.ON_DESTROY);
    this.a = null;
    super.onStop();
  }
  
  public void setContentView(int paramInt) {
    e();
    super.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    k.e(paramView, "view");
    e();
    super.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    k.e(paramView, "view");
    e();
    super.setContentView(paramView, paramLayoutParams);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */