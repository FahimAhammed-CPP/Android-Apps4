package androidx.activity;

import android.view.View;
import s8.k;

public abstract class q {
  public static final void a(View paramView, l paraml) {
    k.e(paramView, "<this>");
    k.e(paraml, "fullyDrawnReporterOwner");
    paramView.setTag(p.report_drawn, paraml);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */