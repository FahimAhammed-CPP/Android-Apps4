package androidx.activity;

import androidx.lifecycle.n;

public interface o extends n {
  OnBackPressedDispatcher getOnBackPressedDispatcher();
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */