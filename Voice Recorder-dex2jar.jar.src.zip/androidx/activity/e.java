package androidx.activity;

import android.content.Context;
import b.b;



/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */