package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.a;
import androidx.activity.result.b;
import androidx.activity.result.c;
import androidx.core.app.g;
import androidx.core.app.h;
import androidx.core.app.n0;
import androidx.core.app.o0;
import androidx.core.app.p0;
import androidx.core.content.c;
import androidx.core.content.d;
import androidx.core.view.t;
import androidx.core.view.w;
import androidx.core.view.z;
import androidx.lifecycle.c0;
import androidx.lifecycle.f0;
import androidx.lifecycle.g;
import androidx.lifecycle.h;
import androidx.lifecycle.j0;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.m0;
import androidx.lifecycle.n;
import androidx.lifecycle.n0;
import androidx.lifecycle.o;
import androidx.lifecycle.o0;
import androidx.lifecycle.p0;
import androidx.lifecycle.y;
import c1.d;
import g8.t;
import java.io.Serializable;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class ComponentActivity extends g implements n0, g, d, o, c, c, d, n0, o0, t, l {
  private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
  
  private final ActivityResultRegistry mActivityResultRegistry;
  
  private int mContentLayoutId;
  
  final b.a mContextAwareHelper = new b.a();
  
  private j0.b mDefaultFactory;
  
  private boolean mDispatchingOnMultiWindowModeChanged;
  
  private boolean mDispatchingOnPictureInPictureModeChanged;
  
  final k mFullyDrawnReporter;
  
  private final o mLifecycleRegistry = new o(this);
  
  private final w mMenuHostHelper = new w(new b(this));
  
  private final AtomicInteger mNextLocalRequestCode;
  
  private final OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  private final CopyOnWriteArrayList<androidx.core.util.a> mOnConfigurationChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a> mOnMultiWindowModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a> mOnNewIntentListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a> mOnPictureInPictureModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a> mOnTrimMemoryListeners;
  
  final f mReportFullyDrawnExecutor;
  
  final c1.c mSavedStateRegistryController;
  
  private m0 mViewModelStore;
  
  public ComponentActivity() {
    c1.c c1 = c1.c.a(this);
    this.mSavedStateRegistryController = c1;
    this.mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a(this));
    f f1 = u();
    this.mReportFullyDrawnExecutor = f1;
    this.mFullyDrawnReporter = new k(f1, new c(this));
    this.mNextLocalRequestCode = new AtomicInteger();
    this.mActivityResultRegistry = new b(this);
    this.mOnConfigurationChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a>();
    this.mOnTrimMemoryListeners = new CopyOnWriteArrayList<androidx.core.util.a>();
    this.mOnNewIntentListeners = new CopyOnWriteArrayList<androidx.core.util.a>();
    this.mOnMultiWindowModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a>();
    this.mOnPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a>();
    this.mDispatchingOnMultiWindowModeChanged = false;
    this.mDispatchingOnPictureInPictureModeChanged = false;
    if (getLifecycle() != null) {
      int i = Build.VERSION.SDK_INT;
      getLifecycle().a((m)new l(this) {
            public void c(n param1n, h.a param1a) {
              if (param1a == h.a.ON_STOP) {
                Window window = this.a.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  ComponentActivity.c.a((View)window); 
              } 
            }
          });
      getLifecycle().a((m)new l(this) {
            public void c(n param1n, h.a param1a) {
              if (param1a == h.a.ON_DESTROY) {
                this.a.mContextAwareHelper.b();
                if (!this.a.isChangingConfigurations())
                  this.a.getViewModelStore().a(); 
                this.a.mReportFullyDrawnExecutor.b();
              } 
            }
          });
      getLifecycle().a((m)new l(this) {
            public void c(n param1n, h.a param1a) {
              this.a.ensureViewModelStore();
              this.a.getLifecycle().c((m)this);
            }
          });
      c1.c();
      c0.c(this);
      if (i <= 23)
        getLifecycle().a((m)new ImmLeaksCleaner((Activity)this)); 
      getSavedStateRegistry().h("android:support:activity-result", new d(this));
      addOnContextAvailableListener(new e(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  private f u() {
    return new g(this);
  }
  
  private void v() {
    o0.a(getWindow().getDecorView(), this);
    p0.a(getWindow().getDecorView(), this);
    c1.e.a(getWindow().getDecorView(), this);
    r.a(getWindow().getDecorView(), this);
    q.a(getWindow().getDecorView(), this);
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    v();
    this.mReportFullyDrawnExecutor.w(getWindow().getDecorView());
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public void addMenuProvider(z paramz) {
    this.mMenuHostHelper.c(paramz);
  }
  
  public void addMenuProvider(z paramz, n paramn) {
    this.mMenuHostHelper.d(paramz, paramn);
  }
  
  @SuppressLint({"LambdaLast"})
  public void addMenuProvider(z paramz, n paramn, h.b paramb) {
    this.mMenuHostHelper.e(paramz, paramn, paramb);
  }
  
  public final void addOnConfigurationChangedListener(androidx.core.util.a parama) {
    this.mOnConfigurationChangedListeners.add(parama);
  }
  
  public final void addOnContextAvailableListener(b.b paramb) {
    this.mContextAwareHelper.a(paramb);
  }
  
  public final void addOnMultiWindowModeChangedListener(androidx.core.util.a parama) {
    this.mOnMultiWindowModeChangedListeners.add(parama);
  }
  
  public final void addOnNewIntentListener(androidx.core.util.a parama) {
    this.mOnNewIntentListeners.add(parama);
  }
  
  public final void addOnPictureInPictureModeChangedListener(androidx.core.util.a parama) {
    this.mOnPictureInPictureModeChangedListeners.add(parama);
  }
  
  public final void addOnTrimMemoryListener(androidx.core.util.a parama) {
    this.mOnTrimMemoryListeners.add(parama);
  }
  
  void ensureViewModelStore() {
    if (this.mViewModelStore == null) {
      e e = (e)getLastNonConfigurationInstance();
      if (e != null)
        this.mViewModelStore = e.b; 
      if (this.mViewModelStore == null)
        this.mViewModelStore = new m0(); 
    } 
  }
  
  public final ActivityResultRegistry getActivityResultRegistry() {
    return this.mActivityResultRegistry;
  }
  
  public q0.a getDefaultViewModelCreationExtras() {
    q0.d d1 = new q0.d();
    if (getApplication() != null)
      d1.c(j0.a.g, getApplication()); 
    d1.c(c0.a, this);
    d1.c(c0.b, this);
    if (getIntent() != null && getIntent().getExtras() != null)
      d1.c(c0.c, getIntent().getExtras()); 
    return (q0.a)d1;
  }
  
  public j0.b getDefaultViewModelProviderFactory() {
    if (this.mDefaultFactory == null) {
      Bundle bundle;
      Application application = getApplication();
      if (getIntent() != null) {
        bundle = getIntent().getExtras();
      } else {
        bundle = null;
      } 
      this.mDefaultFactory = (j0.b)new f0(application, this, bundle);
    } 
    return this.mDefaultFactory;
  }
  
  public k getFullyDrawnReporter() {
    return this.mFullyDrawnReporter;
  }
  
  @Deprecated
  public Object getLastCustomNonConfigurationInstance() {
    e e = (e)getLastNonConfigurationInstance();
    return (e != null) ? e.a : null;
  }
  
  public h getLifecycle() {
    return (h)this.mLifecycleRegistry;
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.mOnBackPressedDispatcher;
  }
  
  public final androidx.savedstate.a getSavedStateRegistry() {
    return this.mSavedStateRegistryController.b();
  }
  
  public m0 getViewModelStore() {
    if (getApplication() != null) {
      ensureViewModelStore();
      return this.mViewModelStore;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void invalidateMenu() {
    invalidateOptionsMenu();
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.mActivityResultRegistry.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.mOnBackPressedDispatcher.f();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Iterator<androidx.core.util.a> iterator = this.mOnConfigurationChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(paramConfiguration); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.mSavedStateRegistryController.d(paramBundle);
    this.mContextAwareHelper.c((Context)this);
    super.onCreate(paramBundle);
    y.e((Activity)this);
    if (androidx.core.os.a.c())
      this.mOnBackPressedDispatcher.g(d.a((Activity)this)); 
    int i = this.mContentLayoutId;
    if (i != 0)
      setContentView(i); 
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      this.mMenuHostHelper.h(paramMenu, getMenuInflater());
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 0) ? this.mMenuHostHelper.j(paramMenuItem) : false);
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    if (this.mDispatchingOnMultiWindowModeChanged)
      return; 
    Iterator<androidx.core.util.a> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(new h(paramBoolean)); 
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.mDispatchingOnMultiWindowModeChanged = true;
    try {
      super.onMultiWindowModeChanged(paramBoolean, paramConfiguration);
      this.mDispatchingOnMultiWindowModeChanged = false;
      Iterator<androidx.core.util.a> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
      return;
    } finally {
      this.mDispatchingOnMultiWindowModeChanged = false;
    } 
  }
  
  protected void onNewIntent(@SuppressLint({"UnknownNullness", "MissingNullability"}) Intent paramIntent) {
    super.onNewIntent(paramIntent);
    Iterator<androidx.core.util.a> iterator = this.mOnNewIntentListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    this.mMenuHostHelper.i(paramMenu);
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    if (this.mDispatchingOnPictureInPictureModeChanged)
      return; 
    Iterator<androidx.core.util.a> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(new p0(paramBoolean)); 
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.mDispatchingOnPictureInPictureModeChanged = true;
    try {
      super.onPictureInPictureModeChanged(paramBoolean, paramConfiguration);
      this.mDispatchingOnPictureInPictureModeChanged = false;
      Iterator<androidx.core.util.a> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
      return;
    } finally {
      this.mDispatchingOnPictureInPictureModeChanged = false;
    } 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      this.mMenuHostHelper.k(paramMenu);
    } 
    return true;
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.mActivityResultRegistry.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  @Deprecated
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = onRetainCustomNonConfigurationInstance();
    m0 m02 = this.mViewModelStore;
    m0 m01 = m02;
    if (m02 == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      m01 = m02;
      if (e1 != null)
        m01 = e1.b; 
    } 
    if (m01 == null && object == null)
      return null; 
    e e = new e();
    e.a = object;
    e.b = m01;
    return e;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    h h = getLifecycle();
    if (h instanceof o)
      ((o)h).n(h.b.c); 
    super.onSaveInstanceState(paramBundle);
    this.mSavedStateRegistryController.e(paramBundle);
  }
  
  public void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<androidx.core.util.a> iterator = this.mOnTrimMemoryListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).a(Integer.valueOf(paramInt)); 
  }
  
  public Context peekAvailableContext() {
    return this.mContextAwareHelper.d();
  }
  
  public final <I, O> b registerForActivityResult(c.a parama, ActivityResultRegistry paramActivityResultRegistry, a parama1) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("activity_rq#");
    stringBuilder.append(this.mNextLocalRequestCode.getAndIncrement());
    return paramActivityResultRegistry.i(stringBuilder.toString(), this, parama, parama1);
  }
  
  public final <I, O> b registerForActivityResult(c.a parama, a parama1) {
    return registerForActivityResult(parama, this.mActivityResultRegistry, parama1);
  }
  
  public void removeMenuProvider(z paramz) {
    this.mMenuHostHelper.l(paramz);
  }
  
  public final void removeOnConfigurationChangedListener(androidx.core.util.a parama) {
    this.mOnConfigurationChangedListeners.remove(parama);
  }
  
  public final void removeOnContextAvailableListener(b.b paramb) {
    this.mContextAwareHelper.e(paramb);
  }
  
  public final void removeOnMultiWindowModeChangedListener(androidx.core.util.a parama) {
    this.mOnMultiWindowModeChangedListeners.remove(parama);
  }
  
  public final void removeOnNewIntentListener(androidx.core.util.a parama) {
    this.mOnNewIntentListeners.remove(parama);
  }
  
  public final void removeOnPictureInPictureModeChangedListener(androidx.core.util.a parama) {
    this.mOnPictureInPictureModeChangedListeners.remove(parama);
  }
  
  public final void removeOnTrimMemoryListener(androidx.core.util.a parama) {
    this.mOnTrimMemoryListeners.remove(parama);
  }
  
  public void reportFullyDrawn() {
    try {
      if (h1.b.d())
        h1.b.a("reportFullyDrawn() for ComponentActivity"); 
      super.reportFullyDrawn();
      this.mFullyDrawnReporter.b();
      return;
    } finally {
      h1.b.b();
    } 
  }
  
  public void setContentView(int paramInt) {
    v();
    this.mReportFullyDrawnExecutor.w(getWindow().getDecorView());
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    v();
    this.mReportFullyDrawnExecutor.w(getWindow().getDecorView());
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    v();
    this.mReportFullyDrawnExecutor.w(getWindow().getDecorView());
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        this.a.onBackPressed();
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends ActivityResultRegistry {
    b(ComponentActivity this$0) {}
    
    public void f(int param1Int, c.a param1a, Object param1Object, androidx.core.app.c param1c) {
      ComponentActivity componentActivity = this.i;
      c.a.a a1 = param1a.b((Context)componentActivity, param1Object);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      param1Object = param1a.a((Context)componentActivity, param1Object);
      if (param1Object.getExtras() != null && param1Object.getExtras().getClassLoader() == null)
        param1Object.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (param1Object.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        object = param1Object.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        param1Object.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } else {
        param1a = null;
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(param1Object.getAction())) {
        param1Object = param1Object.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        object = param1Object;
        if (param1Object == null)
          object = new String[0]; 
        androidx.core.app.b.g((Activity)componentActivity, (String[])object, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(param1Object.getAction())) {
        param1Object = param1Object.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          androidx.core.app.b.l((Activity)componentActivity, param1Object.e(), param1Int, param1Object.a(), param1Object.c(), param1Object.d(), 0, (Bundle)object);
          return;
        } catch (android.content.IntentSender.SendIntentException object) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, (IntentSender.SendIntentException)object));
          return;
        } 
      } 
      androidx.core.app.b.k((Activity)componentActivity, (Intent)param1Object, param1Int, (Bundle)object);
    }
    
    class a implements Runnable {
      a(ComponentActivity.b this$0, int param2Int, c.a.a param2a) {}
      
      public void run() {
        this.c.c(this.a, this.b.a());
      }
    }
    
    class b implements Runnable {
      b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.c.b(this.a, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.b));
      }
    }
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0, int param1Int, c.a.a param1a) {}
    
    public void run() {
      this.c.c(this.a, this.b.a());
    }
  }
  
  class b implements Runnable {
    b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.c.b(this.a, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.b));
    }
  }
  
  static abstract class c {
    static void a(View param1View) {
      param1View.cancelPendingInputEvents();
    }
  }
  
  static abstract class d {
    static OnBackInvokedDispatcher a(Activity param1Activity) {
      return param1Activity.getOnBackInvokedDispatcher();
    }
  }
  
  static final class e {
    Object a;
    
    m0 b;
  }
  
  private static interface f extends Executor {
    void b();
    
    void w(View param1View);
  }
  
  class g implements f, ViewTreeObserver.OnDrawListener, Runnable {
    final long a = SystemClock.uptimeMillis() + 10000L;
    
    Runnable b;
    
    boolean c = false;
    
    g(ComponentActivity this$0) {}
    
    public void b() {
      this.d.getWindow().getDecorView().removeCallbacks(this);
      this.d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
    
    public void execute(Runnable param1Runnable) {
      this.b = param1Runnable;
      View view = this.d.getWindow().getDecorView();
      if (this.c) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
          view.invalidate();
          return;
        } 
        view.postInvalidate();
        return;
      } 
      view.postOnAnimation(new f(this));
    }
    
    public void onDraw() {
      Runnable runnable = this.b;
      if (runnable != null) {
        runnable.run();
        this.b = null;
        if (this.d.mFullyDrawnReporter.c()) {
          this.c = false;
          this.d.getWindow().getDecorView().post(this);
          return;
        } 
      } else if (SystemClock.uptimeMillis() > this.a) {
        this.c = false;
        this.d.getWindow().getDecorView().post(this);
      } 
    }
    
    public void run() {
      this.d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
    
    public void w(View param1View) {
      if (!this.c) {
        this.c = true;
        param1View.getViewTreeObserver().addOnDrawListener(this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */