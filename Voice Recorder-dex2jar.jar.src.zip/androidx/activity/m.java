package androidx.activity;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import r8.a;
import s8.k;

public abstract class m {
  private boolean a;
  
  private final CopyOnWriteArrayList b;
  
  private a c;
  
  public m(boolean paramBoolean) {
    this.a = paramBoolean;
    this.b = new CopyOnWriteArrayList();
  }
  
  public final void a(a parama) {
    k.e(parama, "cancellable");
    this.b.add(parama);
  }
  
  public abstract void b();
  
  public final boolean c() {
    return this.a;
  }
  
  public final void d() {
    Iterator<a> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).cancel(); 
  }
  
  public final void e(a parama) {
    k.e(parama, "cancellable");
    this.b.remove(parama);
  }
  
  public final void f(boolean paramBoolean) {
    this.a = paramBoolean;
    a a1 = this.c;
    if (a1 != null)
      a1.b(); 
  }
  
  public final void g(a parama) {
    this.c = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */