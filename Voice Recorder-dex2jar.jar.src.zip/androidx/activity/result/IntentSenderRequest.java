package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import s8.g;
import s8.k;

@SuppressLint({"BanParcelableUsage"})
public final class IntentSenderRequest implements Parcelable {
  public static final Parcelable.Creator<IntentSenderRequest> CREATOR;
  
  public static final c e = new c(null);
  
  private final IntentSender a;
  
  private final Intent b;
  
  private final int c;
  
  private final int d;
  
  static {
    CREATOR = new b();
  }
  
  public IntentSenderRequest(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2) {
    this.a = paramIntentSender;
    this.b = paramIntent;
    this.c = paramInt1;
    this.d = paramInt2;
  }
  
  public IntentSenderRequest(Parcel paramParcel) {
    this((IntentSender)parcelable, (Intent)paramParcel.readParcelable(Intent.class.getClassLoader()), paramParcel.readInt(), paramParcel.readInt());
  }
  
  public final Intent a() {
    return this.b;
  }
  
  public final int c() {
    return this.c;
  }
  
  public final int d() {
    return this.d;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public final IntentSender e() {
    return this.a;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    k.e(paramParcel, "dest");
    paramParcel.writeParcelable((Parcelable)this.a, paramInt);
    paramParcel.writeParcelable((Parcelable)this.b, paramInt);
    paramParcel.writeInt(this.c);
    paramParcel.writeInt(this.d);
  }
  
  public static final class a {
    private final IntentSender a;
    
    private Intent b;
    
    private int c;
    
    private int d;
    
    public a(IntentSender param1IntentSender) {
      this.a = param1IntentSender;
    }
    
    public final IntentSenderRequest a() {
      return new IntentSenderRequest(this.a, this.b, this.c, this.d);
    }
    
    public final a b(Intent param1Intent) {
      this.b = param1Intent;
      return this;
    }
    
    public final a c(int param1Int1, int param1Int2) {
      this.d = param1Int1;
      this.c = param1Int2;
      return this;
    }
  }
  
  public static final class b implements Parcelable.Creator {
    public IntentSenderRequest a(Parcel param1Parcel) {
      k.e(param1Parcel, "inParcel");
      return new IntentSenderRequest(param1Parcel);
    }
    
    public IntentSenderRequest[] b(int param1Int) {
      return new IntentSenderRequest[param1Int];
    }
  }
  
  public static final class c {
    private c() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\result\IntentSenderRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */