package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.h;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.n;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class ActivityResultRegistry {
  private Random a = new Random();
  
  private final Map b = new HashMap<Object, Object>();
  
  final Map c = new HashMap<Object, Object>();
  
  private final Map d = new HashMap<Object, Object>();
  
  ArrayList e = new ArrayList();
  
  final transient Map f = new HashMap<Object, Object>();
  
  final Map g = new HashMap<Object, Object>();
  
  final Bundle h = new Bundle();
  
  private void a(int paramInt, String paramString) {
    this.b.put(Integer.valueOf(paramInt), paramString);
    this.c.put(paramString, Integer.valueOf(paramInt));
  }
  
  private void d(String paramString, int paramInt, Intent paramIntent, c paramc) {
    if (paramc != null && paramc.a != null && this.e.contains(paramString)) {
      paramc.a.a(paramc.b.c(paramInt, paramIntent));
      this.e.remove(paramString);
      return;
    } 
    this.g.remove(paramString);
    this.h.putParcelable(paramString, new ActivityResult(paramInt, paramIntent));
  }
  
  private int e() {
    int i = this.a.nextInt(2147418112);
    while (true) {
      i += 65536;
      if (this.b.containsKey(Integer.valueOf(i))) {
        i = this.a.nextInt(2147418112);
        continue;
      } 
      return i;
    } 
  }
  
  private void k(String paramString) {
    if ((Integer)this.c.get(paramString) != null)
      return; 
    a(e(), paramString);
  }
  
  public final boolean b(int paramInt1, int paramInt2, Intent paramIntent) {
    String str = (String)this.b.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    d(str, paramInt2, paramIntent, (c)this.f.get(str));
    return true;
  }
  
  public final boolean c(int paramInt, Object paramObject) {
    String str = (String)this.b.get(Integer.valueOf(paramInt));
    if (str == null)
      return false; 
    c c = (c)this.f.get(str);
    if (c != null) {
      a a = c.a;
      if (a == null) {
        this.h.remove(str);
        this.g.put(str, paramObject);
        return true;
      } 
      if (this.e.remove(str))
        a.a(paramObject); 
      return true;
    } 
    this.h.remove(str);
    this.g.put(str, paramObject);
    return true;
  }
  
  public abstract void f(int paramInt, c.a parama, Object paramObject, androidx.core.app.c paramc);
  
  public final void g(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    ArrayList<Integer> arrayList = paramBundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
    ArrayList<String> arrayList1 = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
    if (arrayList1 != null) {
      if (arrayList == null)
        return; 
      this.e = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
      this.a = (Random)paramBundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
      this.h.putAll(paramBundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
      for (int i = 0; i < arrayList1.size(); i++) {
        String str = arrayList1.get(i);
        if (this.c.containsKey(str)) {
          Integer integer = (Integer)this.c.remove(str);
          if (!this.h.containsKey(str))
            this.b.remove(integer); 
        } 
        a(((Integer)arrayList.get(i)).intValue(), arrayList1.get(i));
      } 
    } 
  }
  
  public final void h(Bundle paramBundle) {
    paramBundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.c.values()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.c.keySet()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(this.e));
    paramBundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)this.h.clone());
    paramBundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.a);
  }
  
  public final b i(String paramString, n paramn, c.a parama, a parama1) {
    d d;
    h h = paramn.getLifecycle();
    if (!h.b().d(h.b.d)) {
      k(paramString);
      d d1 = (d)this.d.get(paramString);
      d = d1;
      if (d1 == null)
        d = new d(h); 
      d.a(new l(this, paramString, parama1, parama) {
            public void c(n param1n, h.a param1a) {
              if (h.a.ON_START.equals(param1a)) {
                this.d.f.put(this.a, new ActivityResultRegistry.c(this.b, this.c));
                if (this.d.g.containsKey(this.a)) {
                  param1n = (n)this.d.g.get(this.a);
                  this.d.g.remove(this.a);
                  this.b.a(param1n);
                } 
                ActivityResult activityResult = (ActivityResult)this.d.h.getParcelable(this.a);
                if (activityResult != null) {
                  this.d.h.remove(this.a);
                  this.b.a(this.c.c(activityResult.c(), activityResult.a()));
                  return;
                } 
              } else {
                if (h.a.ON_STOP.equals(param1a)) {
                  this.d.f.remove(this.a);
                  return;
                } 
                if (h.a.ON_DESTROY.equals(param1a))
                  this.d.l(this.a); 
              } 
            }
          });
      this.d.put(paramString, d);
      return new a(this, paramString, parama);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LifecycleOwner ");
    stringBuilder.append(d);
    stringBuilder.append(" is attempting to register while current state is ");
    stringBuilder.append(h.b());
    stringBuilder.append(". LifecycleOwners must call register before they are STARTED.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final b j(String paramString, c.a parama, a parama1) {
    k(paramString);
    this.f.put(paramString, new c(parama1, parama));
    if (this.g.containsKey(paramString)) {
      Object object = this.g.get(paramString);
      this.g.remove(paramString);
      parama1.a(object);
    } 
    ActivityResult activityResult = (ActivityResult)this.h.getParcelable(paramString);
    if (activityResult != null) {
      this.h.remove(paramString);
      parama1.a(parama.c(activityResult.c(), activityResult.a()));
    } 
    return new b(this, paramString, parama);
  }
  
  final void l(String paramString) {
    if (!this.e.contains(paramString)) {
      Integer integer = (Integer)this.c.remove(paramString);
      if (integer != null)
        this.b.remove(integer); 
    } 
    this.f.remove(paramString);
    if (this.g.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.g.get(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.g.remove(paramString);
    } 
    if (this.h.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.h.getParcelable(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.h.remove(paramString);
    } 
    d d = (d)this.d.get(paramString);
    if (d != null) {
      d.b();
      this.d.remove(paramString);
    } 
  }
  
  class a extends b {
    a(ActivityResultRegistry this$0, String param1String, c.a param1a) {}
    
    public void b(Object param1Object, androidx.core.app.c param1c) {
      Integer integer = (Integer)this.c.c.get(this.a);
      if (integer != null) {
        this.c.e.add(this.a);
        try {
          this.c.f(integer.intValue(), this.b, param1Object, param1c);
          return;
        } catch (Exception exception) {
          this.c.e.remove(this.a);
          throw exception;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to launch an unregistered ActivityResultLauncher with contract ");
      stringBuilder.append(this.b);
      stringBuilder.append(" and input ");
      stringBuilder.append(exception);
      stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void c() {
      this.c.l(this.a);
    }
  }
  
  class b extends b {
    b(ActivityResultRegistry this$0, String param1String, c.a param1a) {}
    
    public void b(Object param1Object, androidx.core.app.c param1c) {
      Integer integer = (Integer)this.c.c.get(this.a);
      if (integer != null) {
        this.c.e.add(this.a);
        try {
          this.c.f(integer.intValue(), this.b, param1Object, param1c);
          return;
        } catch (Exception exception) {
          this.c.e.remove(this.a);
          throw exception;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to launch an unregistered ActivityResultLauncher with contract ");
      stringBuilder.append(this.b);
      stringBuilder.append(" and input ");
      stringBuilder.append(exception);
      stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void c() {
      this.c.l(this.a);
    }
  }
  
  private static class c {
    final a a;
    
    final c.a b;
    
    c(a param1a, c.a param1a1) {
      this.a = param1a;
      this.b = param1a1;
    }
  }
  
  private static class d {
    final h a;
    
    private final ArrayList b;
    
    d(h param1h) {
      this.a = param1h;
      this.b = new ArrayList();
    }
    
    void a(l param1l) {
      this.a.a((m)param1l);
      this.b.add(param1l);
    }
    
    void b() {
      for (l l : this.b)
        this.a.c((m)l); 
      this.b.clear();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */