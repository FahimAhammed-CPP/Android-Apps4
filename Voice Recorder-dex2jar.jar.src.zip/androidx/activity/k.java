package androidx.activity;

import g8.t;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import r8.a;

public final class k {
  private final Executor a;
  
  private final a b;
  
  private final Object c;
  
  private int d;
  
  private boolean e;
  
  private boolean f;
  
  private final List g;
  
  private final Runnable h;
  
  public k(Executor paramExecutor, a parama) {
    this.a = paramExecutor;
    this.b = parama;
    this.c = new Object();
    this.g = new ArrayList();
    this.h = new j(this);
  }
  
  private static final void d(k paramk) {
    s8.k.e(paramk, "this$0");
    synchronized (paramk.c) {
      paramk.e = false;
      if (paramk.d == 0 && !paramk.f) {
        paramk.b.b();
        paramk.b();
      } 
      t t = t.a;
      return;
    } 
  }
  
  public final void b() {
    synchronized (this.c) {
      this.f = true;
      Iterator<a> iterator = this.g.iterator();
      while (iterator.hasNext())
        ((a)iterator.next()).b(); 
      this.g.clear();
      t t = t.a;
      return;
    } 
  }
  
  public final boolean c() {
    synchronized (this.c) {
      return this.f;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\activity\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */