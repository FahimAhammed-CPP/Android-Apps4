package androidx.coordinatorlayout.widget;

import androidx.collection.g;
import androidx.core.util.e;
import androidx.core.util.f;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public final class b {
  private final e a = (e)new f(10);
  
  private final g b = new g();
  
  private final ArrayList c = new ArrayList();
  
  private final HashSet d = new HashSet();
  
  private void e(Object paramObject, ArrayList<Object> paramArrayList, HashSet<Object> paramHashSet) {
    if (paramArrayList.contains(paramObject))
      return; 
    if (!paramHashSet.contains(paramObject)) {
      paramHashSet.add(paramObject);
      ArrayList arrayList = (ArrayList)this.b.get(paramObject);
      if (arrayList != null) {
        int j = arrayList.size();
        int i;
        for (i = 0; i < j; i++)
          e(arrayList.get(i), paramArrayList, paramHashSet); 
      } 
      paramHashSet.remove(paramObject);
      paramArrayList.add(paramObject);
      return;
    } 
    throw new RuntimeException("This graph contains cyclic dependencies");
  }
  
  private ArrayList f() {
    ArrayList arrayList2 = (ArrayList)this.a.b();
    ArrayList arrayList1 = arrayList2;
    if (arrayList2 == null)
      arrayList1 = new ArrayList(); 
    return arrayList1;
  }
  
  private void k(ArrayList paramArrayList) {
    paramArrayList.clear();
    this.a.a(paramArrayList);
  }
  
  public void a(Object paramObject1, Object paramObject2) {
    if (this.b.containsKey(paramObject1) && this.b.containsKey(paramObject2)) {
      ArrayList<Object> arrayList2 = (ArrayList)this.b.get(paramObject1);
      ArrayList<Object> arrayList1 = arrayList2;
      if (arrayList2 == null) {
        arrayList1 = f();
        this.b.put(paramObject1, arrayList1);
      } 
      arrayList1.add(paramObject2);
      return;
    } 
    throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
  }
  
  public void b(Object paramObject) {
    if (!this.b.containsKey(paramObject))
      this.b.put(paramObject, null); 
  }
  
  public void c() {
    int j = this.b.size();
    for (int i = 0; i < j; i++) {
      ArrayList arrayList = (ArrayList)this.b.n(i);
      if (arrayList != null)
        k(arrayList); 
    } 
    this.b.clear();
  }
  
  public boolean d(Object paramObject) {
    return this.b.containsKey(paramObject);
  }
  
  public List g(Object paramObject) {
    return (List)this.b.get(paramObject);
  }
  
  public List h(Object paramObject) {
    int j = this.b.size();
    ArrayList<Object> arrayList = null;
    int i = 0;
    while (i < j) {
      ArrayList arrayList2 = (ArrayList)this.b.n(i);
      ArrayList<Object> arrayList1 = arrayList;
      if (arrayList2 != null) {
        arrayList1 = arrayList;
        if (arrayList2.contains(paramObject)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(this.b.j(i));
        } 
      } 
      i++;
      arrayList = arrayList1;
    } 
    return arrayList;
  }
  
  public ArrayList i() {
    this.c.clear();
    this.d.clear();
    int j = this.b.size();
    for (int i = 0; i < j; i++)
      e(this.b.j(i), this.c, this.d); 
    return this.c;
  }
  
  public boolean j(Object paramObject) {
    int j = this.b.size();
    for (int i = 0; i < j; i++) {
      ArrayList arrayList = (ArrayList)this.b.n(i);
      if (arrayList != null && arrayList.contains(paramObject))
        return true; 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\coordinatorlayout\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */