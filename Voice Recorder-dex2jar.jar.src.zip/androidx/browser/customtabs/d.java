package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.SparseArray;
import androidx.core.app.f;
import java.util.ArrayList;

public final class d {
  public final Intent a;
  
  public final Bundle b;
  
  d(Intent paramIntent, Bundle paramBundle) {
    this.a = paramIntent;
    this.b = paramBundle;
  }
  
  public void a(Context paramContext, Uri paramUri) {
    this.a.setData(paramUri);
    androidx.core.content.a.startActivity(paramContext, this.a, this.b);
  }
  
  public static final class a {
    private final Intent a = new Intent("android.intent.action.VIEW");
    
    private final a.a b = new a.a();
    
    private ArrayList c;
    
    private Bundle d;
    
    private ArrayList e;
    
    private SparseArray f;
    
    private Bundle g;
    
    private int h = 0;
    
    private boolean i = true;
    
    public a() {}
    
    public a(f param1f) {
      if (param1f != null)
        b(param1f); 
    }
    
    private void c(IBinder param1IBinder, PendingIntent param1PendingIntent) {
      Bundle bundle = new Bundle();
      f.b(bundle, "android.support.customtabs.extra.SESSION", param1IBinder);
      if (param1PendingIntent != null)
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)param1PendingIntent); 
      this.a.putExtras(bundle);
    }
    
    public d a() {
      if (!this.a.hasExtra("android.support.customtabs.extra.SESSION"))
        c(null, null); 
      ArrayList arrayList = this.c;
      if (arrayList != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.MENU_ITEMS", arrayList); 
      arrayList = this.e;
      if (arrayList != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.TOOLBAR_ITEMS", arrayList); 
      this.a.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.i);
      this.a.putExtras(this.b.a().a());
      Bundle bundle = this.g;
      if (bundle != null)
        this.a.putExtras(bundle); 
      if (this.f != null) {
        bundle = new Bundle();
        bundle.putSparseParcelableArray("androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS", this.f);
        this.a.putExtras(bundle);
      } 
      this.a.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", this.h);
      return new d(this.a, this.d);
    }
    
    public a b(f param1f) {
      this.a.setPackage(param1f.b().getPackageName());
      c(param1f.a(), param1f.c());
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\browser\customtabs\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */