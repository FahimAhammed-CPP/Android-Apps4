package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.os.IBinder;
import android.support.customtabs.ICustomTabsCallback;
import android.support.customtabs.ICustomTabsService;

public final class f {
  private final Object a = new Object();
  
  private final ICustomTabsService b;
  
  private final ICustomTabsCallback c;
  
  private final ComponentName d;
  
  private final PendingIntent e;
  
  f(ICustomTabsService paramICustomTabsService, ICustomTabsCallback paramICustomTabsCallback, ComponentName paramComponentName, PendingIntent paramPendingIntent) {
    this.b = paramICustomTabsService;
    this.c = paramICustomTabsCallback;
    this.d = paramComponentName;
    this.e = paramPendingIntent;
  }
  
  IBinder a() {
    return this.c.asBinder();
  }
  
  ComponentName b() {
    return this.d;
  }
  
  PendingIntent c() {
    return this.e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\browser\customtabs\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */