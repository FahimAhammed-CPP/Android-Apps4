package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.customtabs.ICustomTabsCallback;
import android.support.customtabs.ICustomTabsService;
import android.text.TextUtils;

public abstract class c {
  private final ICustomTabsService a;
  
  private final ComponentName b;
  
  private final Context c;
  
  c(ICustomTabsService paramICustomTabsService, ComponentName paramComponentName, Context paramContext) {
    this.a = paramICustomTabsService;
    this.b = paramComponentName;
    this.c = paramContext;
  }
  
  public static boolean a(Context paramContext, String paramString, e parame) {
    parame.setApplicationContext(paramContext.getApplicationContext());
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, parame, 33);
  }
  
  private ICustomTabsCallback.Stub b(b paramb) {
    return new a(this, paramb);
  }
  
  private f d(b paramb, PendingIntent paramPendingIntent) {
    ICustomTabsCallback.Stub stub = b(paramb);
    if (paramPendingIntent != null)
      try {
        Bundle bundle = new Bundle();
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)paramPendingIntent);
        boolean bool1 = this.a.newSessionWithExtras((ICustomTabsCallback)stub, bundle);
        return !bool1 ? null : new f(this.a, (ICustomTabsCallback)stub, this.b, paramPendingIntent);
      } catch (RemoteException remoteException) {
        return null;
      }  
    boolean bool = this.a.newSession((ICustomTabsCallback)remoteException);
    return !bool ? null : new f(this.a, (ICustomTabsCallback)remoteException, this.b, paramPendingIntent);
  }
  
  public f c(b paramb) {
    return d(paramb, null);
  }
  
  public boolean e(long paramLong) {
    try {
      return this.a.warmup(paramLong);
    } catch (RemoteException remoteException) {
      return false;
    } 
  }
  
  class a extends ICustomTabsCallback.Stub {
    private Handler a = new Handler(Looper.getMainLooper());
    
    a(c this$0, b param1b) {}
    
    public void extraCallback(String param1String, Bundle param1Bundle) {}
    
    public Bundle extraCallbackWithResult(String param1String, Bundle param1Bundle) {
      return null;
    }
    
    public void onMessageChannelReady(Bundle param1Bundle) {}
    
    public void onNavigationEvent(int param1Int, Bundle param1Bundle) {}
    
    public void onPostMessage(String param1String, Bundle param1Bundle) {}
    
    public void onRelationshipValidationResult(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\browser\customtabs\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */