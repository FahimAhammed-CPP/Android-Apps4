package androidx.collection;

public class d implements Cloneable {
  private static final Object e = new Object();
  
  private boolean a = false;
  
  private long[] b;
  
  private Object[] c;
  
  private int d;
  
  public d() {
    this(10);
  }
  
  public d(int paramInt) {
    if (paramInt == 0) {
      this.b = c.b;
      this.c = c.c;
      return;
    } 
    paramInt = c.f(paramInt);
    this.b = new long[paramInt];
    this.c = new Object[paramInt];
  }
  
  private void d() {
    int k = this.d;
    long[] arrayOfLong = this.b;
    Object[] arrayOfObject = this.c;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != e) {
        if (i != j) {
          arrayOfLong[j] = arrayOfLong[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    this.a = false;
    this.d = j;
  }
  
  public void a(long paramLong, Object paramObject) {
    int i = this.d;
    if (i != 0 && paramLong <= this.b[i - 1]) {
      j(paramLong, paramObject);
      return;
    } 
    if (this.a && i >= this.b.length)
      d(); 
    i = this.d;
    if (i >= this.b.length) {
      int j = c.f(i + 1);
      long[] arrayOfLong1 = new long[j];
      Object[] arrayOfObject1 = new Object[j];
      long[] arrayOfLong2 = this.b;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.c;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.b = arrayOfLong1;
      this.c = arrayOfObject1;
    } 
    this.b[i] = paramLong;
    this.c[i] = paramObject;
    this.d = i + 1;
  }
  
  public void b() {
    int j = this.d;
    Object[] arrayOfObject = this.c;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.d = 0;
    this.a = false;
  }
  
  public d c() {
    try {
      d d1 = (d)super.clone();
      d1.b = (long[])this.b.clone();
      d1.c = (Object[])this.c.clone();
      return d1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public Object f(long paramLong) {
    return g(paramLong, null);
  }
  
  public Object g(long paramLong, Object paramObject) {
    int i = c.b(this.b, this.d, paramLong);
    if (i >= 0) {
      Object object = this.c[i];
      return (object == e) ? paramObject : object;
    } 
    return paramObject;
  }
  
  public int h(long paramLong) {
    if (this.a)
      d(); 
    return c.b(this.b, this.d, paramLong);
  }
  
  public long i(int paramInt) {
    if (this.a)
      d(); 
    return this.b[paramInt];
  }
  
  public void j(long paramLong, Object paramObject) {
    int i = c.b(this.b, this.d, paramLong);
    if (i >= 0) {
      this.c[i] = paramObject;
      return;
    } 
    int j = i;
    int k = this.d;
    if (j < k) {
      Object[] arrayOfObject = this.c;
      if (arrayOfObject[j] == e) {
        this.b[j] = paramLong;
        arrayOfObject[j] = paramObject;
        return;
      } 
    } 
    i = j;
    if (this.a) {
      i = j;
      if (k >= this.b.length) {
        d();
        i = c.b(this.b, this.d, paramLong);
      } 
    } 
    j = this.d;
    if (j >= this.b.length) {
      j = c.f(j + 1);
      long[] arrayOfLong1 = new long[j];
      Object[] arrayOfObject1 = new Object[j];
      long[] arrayOfLong2 = this.b;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.c;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.b = arrayOfLong1;
      this.c = arrayOfObject1;
    } 
    j = this.d;
    if (j - i != 0) {
      long[] arrayOfLong = this.b;
      k = i + 1;
      System.arraycopy(arrayOfLong, i, arrayOfLong, k, j - i);
      Object[] arrayOfObject = this.c;
      System.arraycopy(arrayOfObject, i, arrayOfObject, k, this.d - i);
    } 
    this.b[i] = paramLong;
    this.c[i] = paramObject;
    this.d++;
  }
  
  public void k(long paramLong) {
    int i = c.b(this.b, this.d, paramLong);
    if (i >= 0) {
      Object[] arrayOfObject = this.c;
      Object object1 = arrayOfObject[i];
      Object object2 = e;
      if (object1 != object2) {
        arrayOfObject[i] = object2;
        this.a = true;
      } 
    } 
  }
  
  public void l(int paramInt) {
    Object[] arrayOfObject = this.c;
    Object object1 = arrayOfObject[paramInt];
    Object object2 = e;
    if (object1 != object2) {
      arrayOfObject[paramInt] = object2;
      this.a = true;
    } 
  }
  
  public int m() {
    if (this.a)
      d(); 
    return this.d;
  }
  
  public Object n(int paramInt) {
    if (this.a)
      d(); 
    return this.c[paramInt];
  }
  
  public String toString() {
    if (m() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.d * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.d; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(i(i));
      stringBuilder.append('=');
      Object object = n(i);
      if (object != this) {
        stringBuilder.append(object);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\collection\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */