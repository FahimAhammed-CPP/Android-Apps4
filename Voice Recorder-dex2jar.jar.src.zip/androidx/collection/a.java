package androidx.collection;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class a extends g implements Map {
  f h;
  
  public a() {}
  
  public a(int paramInt) {
    super(paramInt);
  }
  
  public a(g paramg) {
    super(paramg);
  }
  
  private f o() {
    if (this.h == null)
      this.h = new a(this); 
    return this.h;
  }
  
  public Set entrySet() {
    return o().l();
  }
  
  public Set keySet() {
    return o().m();
  }
  
  public boolean p(Collection paramCollection) {
    return f.p(this, paramCollection);
  }
  
  public void putAll(Map paramMap) {
    c(this.c + paramMap.size());
    for (Map.Entry entry : paramMap.entrySet())
      put(entry.getKey(), entry.getValue()); 
  }
  
  public Collection values() {
    return o().n();
  }
  
  class a extends f {
    a(a this$0) {}
    
    protected void a() {
      this.d.clear();
    }
    
    protected Object b(int param1Int1, int param1Int2) {
      return this.d.b[(param1Int1 << 1) + param1Int2];
    }
    
    protected Map c() {
      return this.d;
    }
    
    protected int d() {
      return this.d.c;
    }
    
    protected int e(Object param1Object) {
      return this.d.g(param1Object);
    }
    
    protected int f(Object param1Object) {
      return this.d.i(param1Object);
    }
    
    protected void g(Object param1Object1, Object param1Object2) {
      this.d.put(param1Object1, param1Object2);
    }
    
    protected void h(int param1Int) {
      this.d.l(param1Int);
    }
    
    protected Object i(int param1Int, Object param1Object) {
      return this.d.m(param1Int, param1Object);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\collection\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */