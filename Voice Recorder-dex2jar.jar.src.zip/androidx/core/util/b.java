package androidx.core.util;

public abstract class b {
  public static void a(Object paramObject, StringBuilder paramStringBuilder) {
    if (paramObject == null) {
      paramStringBuilder.append("null");
      return;
    } 
    String str2 = paramObject.getClass().getSimpleName();
    String str1 = str2;
    if (str2.length() <= 0) {
      str2 = paramObject.getClass().getName();
      int i = str2.lastIndexOf('.');
      str1 = str2;
      if (i > 0)
        str1 = str2.substring(i + 1); 
    } 
    paramStringBuilder.append(str1);
    paramStringBuilder.append('{');
    paramStringBuilder.append(Integer.toHexString(System.identityHashCode(paramObject)));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\cor\\util\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */