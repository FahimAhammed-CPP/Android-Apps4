package androidx.core.util;

public class g extends f {
  private final Object c = new Object();
  
  public g(int paramInt) {
    super(paramInt);
  }
  
  public boolean a(Object paramObject) {
    synchronized (this.c) {
      return super.a(paramObject);
    } 
  }
  
  public Object b() {
    synchronized (this.c) {
      return super.b();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\cor\\util\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */