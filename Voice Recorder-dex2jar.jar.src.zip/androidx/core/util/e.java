package androidx.core.util;

public interface e {
  boolean a(Object paramObject);
  
  Object b();
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\cor\\util\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */