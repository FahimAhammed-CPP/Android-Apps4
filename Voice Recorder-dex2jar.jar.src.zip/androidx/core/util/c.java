package androidx.core.util;

import java.util.Objects;

public abstract class c {
  public static boolean a(Object paramObject1, Object paramObject2) {
    return a.a(paramObject1, paramObject2);
  }
  
  public static int b(Object... paramVarArgs) {
    return a.b(paramVarArgs);
  }
  
  public static Object c(Object paramObject) {
    paramObject.getClass();
    return paramObject;
  }
  
  public static Object d(Object paramObject, String paramString) {
    if (paramObject != null)
      return paramObject; 
    throw new NullPointerException(paramString);
  }
  
  static abstract class a {
    static boolean a(Object param1Object1, Object param1Object2) {
      return Objects.equals(param1Object1, param1Object2);
    }
    
    static int b(Object... param1VarArgs) {
      return Objects.hash(param1VarArgs);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\cor\\util\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */