package androidx.core.util;

public class d {
  public final Object a;
  
  public final Object b;
  
  public d(Object paramObject1, Object paramObject2) {
    this.a = paramObject1;
    this.b = paramObject2;
  }
  
  public static d a(Object paramObject1, Object paramObject2) {
    return new d(paramObject1, paramObject2);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof d;
    boolean bool1 = false;
    if (!bool)
      return false; 
    paramObject = paramObject;
    bool = bool1;
    if (c.a(((d)paramObject).a, this.a)) {
      bool = bool1;
      if (c.a(((d)paramObject).b, this.b))
        bool = true; 
    } 
    return bool;
  }
  
  public int hashCode() {
    int i;
    Object object = this.a;
    int j = 0;
    if (object == null) {
      i = 0;
    } else {
      i = object.hashCode();
    } 
    object = this.b;
    if (object != null)
      j = object.hashCode(); 
    return i ^ j;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Pair{");
    stringBuilder.append(this.a);
    stringBuilder.append(" ");
    stringBuilder.append(this.b);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\cor\\util\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */