package androidx.core.net;

import android.net.ConnectivityManager;

public abstract class a {
  public static boolean a(ConnectivityManager paramConnectivityManager) {
    return a.a(paramConnectivityManager);
  }
  
  static abstract class a {
    static boolean a(ConnectivityManager param1ConnectivityManager) {
      return param1ConnectivityManager.isActiveNetworkMetered();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\net\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */