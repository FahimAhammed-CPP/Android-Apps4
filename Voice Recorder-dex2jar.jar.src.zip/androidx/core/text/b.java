package androidx.core.text;

import android.icu.util.ULocale;
import android.os.Build;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

public abstract class b {
  private static Method a;
  
  static {
    if (Build.VERSION.SDK_INT < 24)
      try {
        a = Class.forName("libcore.icu.ICU").getMethod("addLikelySubtags", new Class[] { Locale.class });
        return;
      } catch (Exception exception) {
        throw new IllegalStateException(exception);
      }  
  }
  
  public static String a(Locale paramLocale) {
    if (Build.VERSION.SDK_INT >= 24)
      return b.c(b.a(b.b(paramLocale))); 
    try {
      return a.a((Locale)a.invoke(null, new Object[] { paramLocale }));
    } catch (InvocationTargetException invocationTargetException) {
      Log.w("ICUCompat", invocationTargetException);
    } catch (IllegalAccessException illegalAccessException) {
      Log.w("ICUCompat", illegalAccessException);
    } 
    return a.a(paramLocale);
  }
  
  static abstract class a {
    static String a(Locale param1Locale) {
      return param1Locale.getScript();
    }
  }
  
  static abstract class b {
    static ULocale a(Object param1Object) {
      return ULocale.addLikelySubtags((ULocale)param1Object);
    }
    
    static ULocale b(Locale param1Locale) {
      return ULocale.forLocale(param1Locale);
    }
    
    static String c(Object param1Object) {
      return ((ULocale)param1Object).getScript();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\text\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */