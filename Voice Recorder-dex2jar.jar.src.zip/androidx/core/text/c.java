package androidx.core.text;

import android.os.LocaleList;
import android.text.TextPaint;



/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\text\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */