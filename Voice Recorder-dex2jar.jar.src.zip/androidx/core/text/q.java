package androidx.core.text;

import android.text.TextUtils;
import java.util.Locale;

public abstract class q {
  private static final Locale a = new Locale("", "");
  
  public static int a(Locale paramLocale) {
    return a.a(paramLocale);
  }
  
  static abstract class a {
    static int a(Locale param1Locale) {
      return TextUtils.getLayoutDirectionFromLocale(param1Locale);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\text\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */