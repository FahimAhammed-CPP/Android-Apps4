package androidx.core.text;

import java.util.Locale;

public abstract class p {
  public static final o a = new e(null, false);
  
  public static final o b = new e(null, true);
  
  public static final o c;
  
  public static final o d;
  
  public static final o e = new e(a.b, false);
  
  public static final o f = f.b;
  
  static int a(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1 && paramInt != 2) ? 2 : 0) : 1;
  }
  
  static int b(int paramInt) {
    if (paramInt != 0)
      if (paramInt != 1 && paramInt != 2) {
        switch (paramInt) {
          default:
            return 2;
          case 16:
          case 17:
            return 0;
          case 14:
          case 15:
            break;
        } 
        return 1;
      }  
    return 1;
  }
  
  static {
    b b = b.a;
    c = new e(b, false);
    d = new e(b, true);
  }
  
  private static class a implements c {
    static final a b = new a(true);
    
    private final boolean a;
    
    private a(boolean param1Boolean) {
      this.a = param1Boolean;
    }
    
    public int a(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
  
  private static class b implements c {
    static final b a = new b();
    
    public int a(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      int j = 2;
      int i;
      for (i = param1Int1; i < param1Int2 + param1Int1 && j == 2; i++)
        j = p.b(Character.getDirectionality(param1CharSequence.charAt(i))); 
      return j;
    }
  }
  
  private static interface c {
    int a(CharSequence param1CharSequence, int param1Int1, int param1Int2);
  }
  
  private static abstract class d implements o {
    private final p.c a;
    
    d(p.c param1c) {
      this.a = param1c;
    }
    
    private boolean c(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      param1Int1 = this.a.a(param1CharSequence, param1Int1, param1Int2);
      return (param1Int1 != 0) ? ((param1Int1 != 1) ? b() : false) : true;
    }
    
    public boolean a(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      if (param1CharSequence != null && param1Int1 >= 0 && param1Int2 >= 0 && param1CharSequence.length() - param1Int2 >= param1Int1)
        return (this.a == null) ? b() : c(param1CharSequence, param1Int1, param1Int2); 
      throw new IllegalArgumentException();
    }
    
    protected abstract boolean b();
  }
  
  private static class e extends d {
    private final boolean b;
    
    e(p.c param1c, boolean param1Boolean) {
      super(param1c);
      this.b = param1Boolean;
    }
    
    protected boolean b() {
      return this.b;
    }
  }
  
  private static class f extends d {
    static final f b = new f();
    
    f() {
      super(null);
    }
    
    protected boolean b() {
      return (q.a(Locale.getDefault()) == 1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\text\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */