package androidx.core.os;

import android.os.Handler;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

public abstract class h {
  public static Executor a(Handler paramHandler) {
    return new a(paramHandler);
  }
  
  private static class a implements Executor {
    private final Handler a;
    
    a(Handler param1Handler) {
      this.a = (Handler)androidx.core.util.h.g(param1Handler);
    }
    
    public void execute(Runnable param1Runnable) {
      if (this.a.post((Runnable)androidx.core.util.h.g(param1Runnable)))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append(" is shutting down");
      throw new RejectedExecutionException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\os\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */