package androidx.core.os;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import g8.l;
import java.io.Serializable;
import s8.k;

public abstract class d {
  public static final Bundle a(l... paramVarArgs) {
    StringBuilder stringBuilder;
    k.e(paramVarArgs, "pairs");
    Bundle bundle = new Bundle(paramVarArgs.length);
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      l l1 = paramVarArgs[i];
      String str = (String)l1.b();
      Object object = l1.c();
      if (object == null) {
        bundle.putString(str, null);
      } else if (object instanceof Boolean) {
        bundle.putBoolean(str, ((Boolean)object).booleanValue());
      } else if (object instanceof Byte) {
        bundle.putByte(str, ((Number)object).byteValue());
      } else if (object instanceof Character) {
        bundle.putChar(str, ((Character)object).charValue());
      } else if (object instanceof Double) {
        bundle.putDouble(str, ((Number)object).doubleValue());
      } else if (object instanceof Float) {
        bundle.putFloat(str, ((Number)object).floatValue());
      } else if (object instanceof Integer) {
        bundle.putInt(str, ((Number)object).intValue());
      } else if (object instanceof Long) {
        bundle.putLong(str, ((Number)object).longValue());
      } else if (object instanceof Short) {
        bundle.putShort(str, ((Number)object).shortValue());
      } else if (object instanceof Bundle) {
        bundle.putBundle(str, (Bundle)object);
      } else if (object instanceof CharSequence) {
        bundle.putCharSequence(str, (CharSequence)object);
      } else if (object instanceof Parcelable) {
        bundle.putParcelable(str, (Parcelable)object);
      } else if (object instanceof boolean[]) {
        bundle.putBooleanArray(str, (boolean[])object);
      } else if (object instanceof byte[]) {
        bundle.putByteArray(str, (byte[])object);
      } else if (object instanceof char[]) {
        bundle.putCharArray(str, (char[])object);
      } else if (object instanceof double[]) {
        bundle.putDoubleArray(str, (double[])object);
      } else if (object instanceof float[]) {
        bundle.putFloatArray(str, (float[])object);
      } else if (object instanceof int[]) {
        bundle.putIntArray(str, (int[])object);
      } else if (object instanceof long[]) {
        bundle.putLongArray(str, (long[])object);
      } else if (object instanceof short[]) {
        bundle.putShortArray(str, (short[])object);
      } else if (object instanceof Object[]) {
        Class<?> clazz = object.getClass().getComponentType();
        k.b(clazz);
        if (Parcelable.class.isAssignableFrom(clazz)) {
          k.c(object, "null cannot be cast to non-null type kotlin.Array<android.os.Parcelable>");
          bundle.putParcelableArray(str, (Parcelable[])object);
        } else if (String.class.isAssignableFrom(clazz)) {
          k.c(object, "null cannot be cast to non-null type kotlin.Array<kotlin.String>");
          bundle.putStringArray(str, (String[])object);
        } else if (CharSequence.class.isAssignableFrom(clazz)) {
          k.c(object, "null cannot be cast to non-null type kotlin.Array<kotlin.CharSequence>");
          bundle.putCharSequenceArray(str, (CharSequence[])object);
        } else if (Serializable.class.isAssignableFrom(clazz)) {
          bundle.putSerializable(str, (Serializable)object);
        } else {
          String str1 = clazz.getCanonicalName();
          stringBuilder = new StringBuilder();
          stringBuilder.append("Illegal value array type ");
          stringBuilder.append(str1);
          stringBuilder.append(" for key \"");
          stringBuilder.append(str);
          stringBuilder.append('"');
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else if (object instanceof Serializable) {
        stringBuilder.putSerializable(str, (Serializable)object);
      } else if (object instanceof IBinder) {
        b.a((Bundle)stringBuilder, str, (IBinder)object);
      } else if (object instanceof Size) {
        c.a((Bundle)stringBuilder, str, (Size)object);
      } else if (object instanceof SizeF) {
        c.b((Bundle)stringBuilder, str, (SizeF)object);
      } else {
        String str1 = object.getClass().getCanonicalName();
        stringBuilder = new StringBuilder();
        stringBuilder.append("Illegal value type ");
        stringBuilder.append(str1);
        stringBuilder.append(" for key \"");
        stringBuilder.append(str);
        stringBuilder.append('"');
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return (Bundle)stringBuilder;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\os\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */