package androidx.core.os;

import android.os.LocaleList;
import androidx.appcompat.app.k;
import androidx.appcompat.app.m;
import java.util.Locale;

final class s implements l {
  private final LocaleList a;
  
  s(Object paramObject) {
    this.a = p.a(paramObject);
  }
  
  public String a() {
    return k.a(this.a);
  }
  
  public Object b() {
    return this.a;
  }
  
  public boolean equals(Object paramObject) {
    return m.a(this.a, ((l)paramObject).b());
  }
  
  public Locale get(int paramInt) {
    return m.a(this.a, paramInt);
  }
  
  public int hashCode() {
    return o.a(this.a);
  }
  
  public boolean isEmpty() {
    return r.a(this.a);
  }
  
  public int size() {
    return n.a(this.a);
  }
  
  public String toString() {
    return q.a(this.a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\os\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */