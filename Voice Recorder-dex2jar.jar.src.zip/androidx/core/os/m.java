package androidx.core.os;

import android.os.LocaleList;
import java.util.Locale;



/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\os\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */