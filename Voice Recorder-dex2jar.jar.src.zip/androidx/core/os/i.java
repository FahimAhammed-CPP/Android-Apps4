package androidx.core.os;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;

public abstract class i {
  public static Handler a(Looper paramLooper) {
    Throwable throwable;
    if (Build.VERSION.SDK_INT >= 28)
      return a.a(paramLooper); 
    try {
      return Handler.class.getDeclaredConstructor(new Class[] { Looper.class, Handler.Callback.class, boolean.class }).newInstance(new Object[] { paramLooper, null, Boolean.TRUE });
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InstantiationException instantiationException) {
    
    } catch (NoSuchMethodException noSuchMethodException) {
    
    } catch (InvocationTargetException invocationTargetException) {
      throwable = invocationTargetException.getCause();
      if (!(throwable instanceof RuntimeException)) {
        if (throwable instanceof Error)
          throw (Error)throwable; 
        throw new RuntimeException(throwable);
      } 
      throw (RuntimeException)throwable;
    } 
    Log.w("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor", noSuchMethodException);
    return new Handler((Looper)throwable);
  }
  
  private static abstract class a {
    public static Handler a(Looper param1Looper) {
      return Handler.createAsync(param1Looper);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\os\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */