package androidx.core.os;

import android.os.Build;
import android.os.LocaleList;
import java.util.Locale;

public final class j {
  private static final j b = a(new Locale[0]);
  
  private final l a;
  
  private j(l paraml) {
    this.a = paraml;
  }
  
  public static j a(Locale... paramVarArgs) {
    return (Build.VERSION.SDK_INT >= 24) ? i(b.a(paramVarArgs)) : new j(new k(paramVarArgs));
  }
  
  static Locale b(String paramString) {
    if (paramString.contains("-")) {
      String[] arrayOfString = paramString.split("-", -1);
      if (arrayOfString.length > 2)
        return new Locale(arrayOfString[0], arrayOfString[1], arrayOfString[2]); 
      if (arrayOfString.length > 1)
        return new Locale(arrayOfString[0], arrayOfString[1]); 
      if (arrayOfString.length == 1)
        return new Locale(arrayOfString[0]); 
    } else {
      if (paramString.contains("_")) {
        String[] arrayOfString = paramString.split("_", -1);
        if (arrayOfString.length > 2)
          return new Locale(arrayOfString[0], arrayOfString[1], arrayOfString[2]); 
        if (arrayOfString.length > 1)
          return new Locale(arrayOfString[0], arrayOfString[1]); 
        if (arrayOfString.length == 1)
          return new Locale(arrayOfString[0]); 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Can not parse language tag: [");
        stringBuilder1.append(paramString);
        stringBuilder1.append("]");
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      return new Locale(paramString);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can not parse language tag: [");
    stringBuilder.append(paramString);
    stringBuilder.append("]");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static j c(String paramString) {
    if (paramString == null || paramString.isEmpty())
      return e(); 
    String[] arrayOfString = paramString.split(",", -1);
    int k = arrayOfString.length;
    Locale[] arrayOfLocale = new Locale[k];
    for (int i = 0; i < k; i++)
      arrayOfLocale[i] = a.a(arrayOfString[i]); 
    return a(arrayOfLocale);
  }
  
  public static j e() {
    return b;
  }
  
  public static j i(LocaleList paramLocaleList) {
    return new j(new s(paramLocaleList));
  }
  
  public Locale d(int paramInt) {
    return this.a.get(paramInt);
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof j && this.a.equals(((j)paramObject).a));
  }
  
  public boolean f() {
    return this.a.isEmpty();
  }
  
  public int g() {
    return this.a.size();
  }
  
  public String h() {
    return this.a.a();
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public String toString() {
    return this.a.toString();
  }
  
  static abstract class a {
    private static final Locale[] a = new Locale[] { new Locale("en", "XA"), new Locale("ar", "XB") };
    
    static Locale a(String param1String) {
      return Locale.forLanguageTag(param1String);
    }
    
    private static boolean b(Locale param1Locale) {
      Locale[] arrayOfLocale = a;
      int j = arrayOfLocale.length;
      for (int i = 0; i < j; i++) {
        if (arrayOfLocale[i].equals(param1Locale))
          return true; 
      } 
      return false;
    }
    
    static boolean c(Locale param1Locale1, Locale param1Locale2) {
      boolean bool1 = param1Locale1.equals(param1Locale2);
      boolean bool = true;
      if (bool1)
        return true; 
      if (!param1Locale1.getLanguage().equals(param1Locale2.getLanguage()))
        return false; 
      if (!b(param1Locale1)) {
        if (b(param1Locale2))
          return false; 
        String str = androidx.core.text.b.a(param1Locale1);
        if (str.isEmpty()) {
          String str1 = param1Locale1.getCountry();
          if (!str1.isEmpty()) {
            if (str1.equals(param1Locale2.getCountry()))
              return true; 
            bool = false;
          } 
          return bool;
        } 
        return str.equals(androidx.core.text.b.a(param1Locale2));
      } 
      return false;
    }
  }
  
  static abstract class b {
    static LocaleList a(Locale... param1VarArgs) {
      return new LocaleList(param1VarArgs);
    }
    
    static LocaleList b() {
      return LocaleList.getAdjustedDefault();
    }
    
    static LocaleList c() {
      return LocaleList.getDefault();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\os\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */