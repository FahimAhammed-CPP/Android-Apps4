package androidx.core.os;

import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import java.util.Locale;

public abstract class f {
  public static j a(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? j.i(a.a(paramConfiguration)) : j.a(new Locale[] { paramConfiguration.locale });
  }
  
  static abstract class a {
    static LocaleList a(Configuration param1Configuration) {
      return param1Configuration.getLocales();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\os\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */