package androidx.core.os;

import android.os.OutcomeReceiver;
import k8.d;
import s8.k;

public abstract class u {
  public static final OutcomeReceiver a(d paramd) {
    k.e(paramd, "<this>");
    return t.a(new g(paramd));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\o\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */