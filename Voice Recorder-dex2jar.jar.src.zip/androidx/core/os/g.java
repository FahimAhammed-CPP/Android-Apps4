package androidx.core.os;

import android.os.OutcomeReceiver;
import g8.m;
import g8.n;
import java.util.concurrent.atomic.AtomicBoolean;
import k8.d;
import s8.k;

final class g extends AtomicBoolean implements OutcomeReceiver {
  private final d a;
  
  public g(d paramd) {
    super(false);
    this.a = paramd;
  }
  
  public void onError(Throwable paramThrowable) {
    k.e(paramThrowable, "error");
    if (compareAndSet(false, true)) {
      d d1 = this.a;
      m.a a = m.b;
      d1.resumeWith(m.b(n.a(paramThrowable)));
    } 
  }
  
  public void onResult(Object paramObject) {
    if (compareAndSet(false, true))
      this.a.resumeWith(m.b(paramObject)); 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ContinuationOutcomeReceiver(outcomeReceived = ");
    stringBuilder.append(get());
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\os\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */