package androidx.core.app;

import androidx.core.util.a;

public interface o0 {
  void addOnPictureInPictureModeChangedListener(a parama);
  
  void removeOnPictureInPictureModeChangedListener(a parama);
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\app\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */