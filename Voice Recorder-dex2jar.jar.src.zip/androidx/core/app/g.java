package androidx.core.app;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.appcompat.app.f0;
import androidx.core.view.q;
import androidx.lifecycle.h;
import androidx.lifecycle.n;
import androidx.lifecycle.o;
import androidx.lifecycle.y;

public abstract class g extends Activity implements n, q.a {
  private androidx.collection.g mExtraDataMap = new androidx.collection.g();
  
  private o mLifecycleRegistry = new o(this);
  
  private static boolean q(String[] paramArrayOfString) {
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool2 = false;
    boolean bool1 = bool4;
    if (paramArrayOfString != null) {
      bool1 = bool4;
      if (paramArrayOfString.length > 0) {
        String str = paramArrayOfString[0];
        str.hashCode();
        int i = str.hashCode();
        byte b = -1;
        switch (i) {
          case 1455016274:
            if (!str.equals("--autofill"))
              break; 
            b = 4;
            break;
          case 1159329357:
            if (!str.equals("--contentcapture"))
              break; 
            b = 3;
            break;
          case 472614934:
            if (!str.equals("--list-dumpables"))
              break; 
            b = 2;
            break;
          case 100470631:
            if (!str.equals("--dump-dumpable"))
              break; 
            b = 1;
            break;
          case -645125871:
            if (!str.equals("--translation"))
              break; 
            b = 0;
            break;
        } 
        switch (b) {
          default:
            return false;
          case 4:
            bool1 = bool2;
            if (Build.VERSION.SDK_INT >= 26)
              bool1 = true; 
            return bool1;
          case 3:
            bool1 = bool3;
            if (Build.VERSION.SDK_INT >= 29)
              bool1 = true; 
            return bool1;
          case 1:
          case 2:
            return androidx.core.os.a.c();
          case 0:
            break;
        } 
        bool1 = bool4;
        if (Build.VERSION.SDK_INT >= 31)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && q.d(view, paramKeyEvent)) ? true : q.e(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && q.d(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  @Deprecated
  public <T extends a> T getExtraData(Class<T> paramClass) {
    f0.a(this.mExtraDataMap.get(paramClass));
    return null;
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    y.e(this);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    this.mLifecycleRegistry.j(h.b.c);
    super.onSaveInstanceState(paramBundle);
  }
  
  @Deprecated
  public void putExtraData(a parama) {
    throw null;
  }
  
  protected final boolean shouldDumpInternalState(String[] paramArrayOfString) {
    return q(paramArrayOfString) ^ true;
  }
  
  public boolean superDispatchKeyEvent(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public static abstract class a {}
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */