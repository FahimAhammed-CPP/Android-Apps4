package androidx.core.app;

import android.content.res.Configuration;

public final class p0 {
  private final boolean a;
  
  private final Configuration b;
  
  public p0(boolean paramBoolean) {
    this.a = paramBoolean;
    this.b = null;
  }
  
  public p0(boolean paramBoolean, Configuration paramConfiguration) {
    this.a = paramBoolean;
    this.b = paramConfiguration;
  }
  
  public boolean a() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\app\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */