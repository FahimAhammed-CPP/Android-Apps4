package androidx.core.app;

import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;

public abstract class q0 {
  static RemoteInput a(q0 paramq0) {
    return a.b(paramq0);
  }
  
  static RemoteInput[] b(q0[] paramArrayOfq0) {
    if (paramArrayOfq0 == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfq0.length];
    for (int i = 0; i < paramArrayOfq0.length; i++) {
      q0 q01 = paramArrayOfq0[i];
      arrayOfRemoteInput[i] = a(null);
    } 
    return arrayOfRemoteInput;
  }
  
  static abstract class a {
    static void a(Object param1Object, Intent param1Intent, Bundle param1Bundle) {
      RemoteInput.addResultsToIntent((RemoteInput[])param1Object, param1Intent, param1Bundle);
    }
    
    public static RemoteInput b(q0 param1q0) {
      throw null;
    }
    
    static Bundle c(Intent param1Intent) {
      return RemoteInput.getResultsFromIntent(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\app\q0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */