package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import v.g;
import v.h;

public abstract class k {
  public static Bundle a(Notification paramNotification) {
    return paramNotification.extras;
  }
  
  public static class a {
    final Bundle a;
    
    private IconCompat b;
    
    private final q0[] c;
    
    private final q0[] d;
    
    private boolean e;
    
    boolean f = true;
    
    private final int g;
    
    private final boolean h;
    
    public int i;
    
    public CharSequence j;
    
    public PendingIntent k;
    
    private boolean l;
    
    public a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(iconCompat, param1CharSequence, param1PendingIntent);
    }
    
    public a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(param1IconCompat, param1CharSequence, param1PendingIntent, new Bundle(), null, null, true, 0, true, false, false);
    }
    
    a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent, Bundle param1Bundle, q0[] param1ArrayOfq01, q0[] param1ArrayOfq02, boolean param1Boolean1, int param1Int, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      this.b = param1IconCompat;
      if (param1IconCompat != null && param1IconCompat.i() == 2)
        this.i = param1IconCompat.f(); 
      this.j = k.d.j(param1CharSequence);
      this.k = param1PendingIntent;
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      this.a = param1Bundle;
      this.c = param1ArrayOfq01;
      this.d = param1ArrayOfq02;
      this.e = param1Boolean1;
      this.g = param1Int;
      this.f = param1Boolean2;
      this.h = param1Boolean3;
      this.l = param1Boolean4;
    }
    
    public PendingIntent a() {
      return this.k;
    }
    
    public boolean b() {
      return this.e;
    }
    
    public Bundle c() {
      return this.a;
    }
    
    public IconCompat d() {
      if (this.b == null) {
        int i = this.i;
        if (i != 0)
          this.b = IconCompat.e(null, "", i); 
      } 
      return this.b;
    }
    
    public q0[] e() {
      return this.c;
    }
    
    public int f() {
      return this.g;
    }
    
    public boolean g() {
      return this.f;
    }
    
    public CharSequence h() {
      return this.j;
    }
    
    public boolean i() {
      return this.l;
    }
    
    public boolean j() {
      return this.h;
    }
  }
  
  public static class b extends f {
    private CharSequence e;
    
    public void a(Bundle param1Bundle) {
      super.a(param1Bundle);
    }
    
    public void b(j param1j) {
      Notification.BigTextStyle bigTextStyle = (new Notification.BigTextStyle(param1j.a())).setBigContentTitle(this.b).bigText(this.e);
      if (this.d)
        bigTextStyle.setSummaryText(this.c); 
    }
    
    protected String k() {
      return "androidx.core.app.NotificationCompat$BigTextStyle";
    }
    
    public b q(CharSequence param1CharSequence) {
      this.e = k.d.j(param1CharSequence);
      return this;
    }
    
    public b r(CharSequence param1CharSequence) {
      this.b = k.d.j(param1CharSequence);
      return this;
    }
  }
  
  public static final abstract class c {
    public static Notification.BubbleMetadata a(c param1c) {
      return null;
    }
  }
  
  public static class d {
    boolean A = false;
    
    boolean B;
    
    boolean C;
    
    String D;
    
    Bundle E;
    
    int F = 0;
    
    int G = 0;
    
    Notification H;
    
    RemoteViews I;
    
    RemoteViews J;
    
    RemoteViews K;
    
    String L;
    
    int M = 0;
    
    String N;
    
    long O;
    
    int P = 0;
    
    int Q = 0;
    
    boolean R;
    
    Notification S;
    
    boolean T;
    
    Icon U;
    
    public ArrayList V;
    
    public Context a;
    
    public ArrayList b = new ArrayList();
    
    public ArrayList c = new ArrayList();
    
    ArrayList d = new ArrayList();
    
    CharSequence e;
    
    CharSequence f;
    
    PendingIntent g;
    
    PendingIntent h;
    
    RemoteViews i;
    
    Bitmap j;
    
    CharSequence k;
    
    int l;
    
    int m;
    
    boolean n = true;
    
    boolean o;
    
    boolean p;
    
    k.f q;
    
    CharSequence r;
    
    CharSequence s;
    
    CharSequence[] t;
    
    int u;
    
    int v;
    
    boolean w;
    
    String x;
    
    boolean y;
    
    String z;
    
    public d(Context param1Context) {
      this(param1Context, null);
    }
    
    public d(Context param1Context, String param1String) {
      Notification notification = new Notification();
      this.S = notification;
      this.a = param1Context;
      this.L = param1String;
      notification.when = System.currentTimeMillis();
      this.S.audioStreamType = -1;
      this.m = 0;
      this.V = new ArrayList();
      this.R = true;
    }
    
    protected static CharSequence j(CharSequence param1CharSequence) {
      if (param1CharSequence == null)
        return param1CharSequence; 
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence.length() > 5120)
        charSequence = param1CharSequence.subSequence(0, 5120); 
      return charSequence;
    }
    
    private Bitmap k(Bitmap param1Bitmap) {
      Bitmap bitmap = param1Bitmap;
      if (param1Bitmap != null) {
        if (Build.VERSION.SDK_INT >= 27)
          return param1Bitmap; 
        Resources resources = this.a.getResources();
        int i = resources.getDimensionPixelSize(v.c.compat_notification_large_icon_max_width);
        int j = resources.getDimensionPixelSize(v.c.compat_notification_large_icon_max_height);
        if (param1Bitmap.getWidth() <= i && param1Bitmap.getHeight() <= j)
          return param1Bitmap; 
        double d1 = Math.min(i / Math.max(1, param1Bitmap.getWidth()), j / Math.max(1, param1Bitmap.getHeight()));
        bitmap = Bitmap.createScaledBitmap(param1Bitmap, (int)Math.ceil(param1Bitmap.getWidth() * d1), (int)Math.ceil(param1Bitmap.getHeight() * d1), true);
      } 
      return bitmap;
    }
    
    private void u(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        Notification notification1 = this.S;
        notification1.flags = param1Int | notification1.flags;
        return;
      } 
      Notification notification = this.S;
      notification.flags = param1Int & notification.flags;
    }
    
    public d A(int param1Int1, int param1Int2, boolean param1Boolean) {
      this.u = param1Int1;
      this.v = param1Int2;
      this.w = param1Boolean;
      return this;
    }
    
    public d B(boolean param1Boolean) {
      this.n = param1Boolean;
      return this;
    }
    
    public d C(int param1Int) {
      this.S.icon = param1Int;
      return this;
    }
    
    public d D(Uri param1Uri) {
      Notification notification = this.S;
      notification.sound = param1Uri;
      notification.audioStreamType = -1;
      notification.audioAttributes = (new AudioAttributes.Builder()).setContentType(4).setUsage(5).build();
      return this;
    }
    
    public d E(k.f param1f) {
      if (this.q != param1f) {
        this.q = param1f;
        if (param1f != null)
          param1f.p(this); 
      } 
      return this;
    }
    
    public d F(CharSequence param1CharSequence) {
      this.r = j(param1CharSequence);
      return this;
    }
    
    public d G(CharSequence param1CharSequence) {
      this.S.tickerText = j(param1CharSequence);
      return this;
    }
    
    public d H(long[] param1ArrayOflong) {
      this.S.vibrate = param1ArrayOflong;
      return this;
    }
    
    public d I(int param1Int) {
      this.G = param1Int;
      return this;
    }
    
    public d J(long param1Long) {
      this.S.when = param1Long;
      return this;
    }
    
    public d a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this.b.add(new k.a(param1Int, param1CharSequence, param1PendingIntent));
      return this;
    }
    
    public Notification b() {
      return (new j0(this)).c();
    }
    
    public RemoteViews c() {
      return this.J;
    }
    
    public int d() {
      return this.F;
    }
    
    public RemoteViews e() {
      return this.I;
    }
    
    public Bundle f() {
      if (this.E == null)
        this.E = new Bundle(); 
      return this.E;
    }
    
    public RemoteViews g() {
      return this.K;
    }
    
    public int h() {
      return this.m;
    }
    
    public long i() {
      return this.n ? this.S.when : 0L;
    }
    
    public d l(boolean param1Boolean) {
      u(16, param1Boolean);
      return this;
    }
    
    public d m(String param1String) {
      this.L = param1String;
      return this;
    }
    
    public d n(int param1Int) {
      this.F = param1Int;
      return this;
    }
    
    public d o(boolean param1Boolean) {
      this.B = param1Boolean;
      this.C = true;
      return this;
    }
    
    public d p(PendingIntent param1PendingIntent) {
      this.g = param1PendingIntent;
      return this;
    }
    
    public d q(CharSequence param1CharSequence) {
      this.f = j(param1CharSequence);
      return this;
    }
    
    public d r(CharSequence param1CharSequence) {
      this.e = j(param1CharSequence);
      return this;
    }
    
    public d s(RemoteViews param1RemoteViews) {
      this.I = param1RemoteViews;
      return this;
    }
    
    public d t(PendingIntent param1PendingIntent) {
      this.S.deleteIntent = param1PendingIntent;
      return this;
    }
    
    public d v(Bitmap param1Bitmap) {
      this.j = k(param1Bitmap);
      return this;
    }
    
    public d w(boolean param1Boolean) {
      this.A = param1Boolean;
      return this;
    }
    
    public d x(boolean param1Boolean) {
      u(2, param1Boolean);
      return this;
    }
    
    public d y(boolean param1Boolean) {
      u(8, param1Boolean);
      return this;
    }
    
    public d z(int param1Int) {
      this.m = param1Int;
      return this;
    }
  }
  
  public static class e extends f {
    private RemoteViews q(RemoteViews param1RemoteViews, boolean param1Boolean) {
      // Byte code:
      //   0: getstatic v/g.notification_template_custom_big : I
      //   3: istore_3
      //   4: iconst_1
      //   5: istore #6
      //   7: iconst_0
      //   8: istore #5
      //   10: aload_0
      //   11: iconst_1
      //   12: iload_3
      //   13: iconst_0
      //   14: invokevirtual c : (ZIZ)Landroid/widget/RemoteViews;
      //   17: astore #8
      //   19: aload #8
      //   21: getstatic v/e.actions : I
      //   24: invokevirtual removeAllViews : (I)V
      //   27: aload_0
      //   28: getfield a : Landroidx/core/app/k$d;
      //   31: getfield b : Ljava/util/ArrayList;
      //   34: invokestatic s : (Ljava/util/List;)Ljava/util/List;
      //   37: astore #9
      //   39: iload_2
      //   40: ifeq -> 112
      //   43: aload #9
      //   45: ifnull -> 112
      //   48: aload #9
      //   50: invokeinterface size : ()I
      //   55: iconst_3
      //   56: invokestatic min : (II)I
      //   59: istore #7
      //   61: iload #7
      //   63: ifle -> 112
      //   66: iconst_0
      //   67: istore_3
      //   68: iload #6
      //   70: istore #4
      //   72: iload_3
      //   73: iload #7
      //   75: if_icmpge -> 115
      //   78: aload_0
      //   79: aload #9
      //   81: iload_3
      //   82: invokeinterface get : (I)Ljava/lang/Object;
      //   87: checkcast androidx/core/app/k$a
      //   90: invokespecial r : (Landroidx/core/app/k$a;)Landroid/widget/RemoteViews;
      //   93: astore #10
      //   95: aload #8
      //   97: getstatic v/e.actions : I
      //   100: aload #10
      //   102: invokevirtual addView : (ILandroid/widget/RemoteViews;)V
      //   105: iload_3
      //   106: iconst_1
      //   107: iadd
      //   108: istore_3
      //   109: goto -> 68
      //   112: iconst_0
      //   113: istore #4
      //   115: iload #4
      //   117: ifeq -> 126
      //   120: iload #5
      //   122: istore_3
      //   123: goto -> 129
      //   126: bipush #8
      //   128: istore_3
      //   129: aload #8
      //   131: getstatic v/e.actions : I
      //   134: iload_3
      //   135: invokevirtual setViewVisibility : (II)V
      //   138: aload #8
      //   140: getstatic v/e.action_divider : I
      //   143: iload_3
      //   144: invokevirtual setViewVisibility : (II)V
      //   147: aload_0
      //   148: aload #8
      //   150: aload_1
      //   151: invokevirtual d : (Landroid/widget/RemoteViews;Landroid/widget/RemoteViews;)V
      //   154: aload #8
      //   156: areturn
    }
    
    private RemoteViews r(k.a param1a) {
      boolean bool;
      int i;
      if (param1a.k == null) {
        bool = true;
      } else {
        bool = false;
      } 
      String str = this.a.a.getPackageName();
      if (bool) {
        i = g.notification_action_tombstone;
      } else {
        i = g.notification_action;
      } 
      RemoteViews remoteViews = new RemoteViews(str, i);
      IconCompat iconCompat = param1a.d();
      if (iconCompat != null)
        remoteViews.setImageViewBitmap(v.e.action_image, h(iconCompat, this.a.a.getResources().getColor(v.b.notification_action_color_filter))); 
      remoteViews.setTextViewText(v.e.action_text, param1a.j);
      if (!bool)
        remoteViews.setOnClickPendingIntent(v.e.action_container, param1a.k); 
      remoteViews.setContentDescription(v.e.action_container, param1a.j);
      return remoteViews;
    }
    
    private static List s(List param1List) {
      if (param1List == null)
        return null; 
      ArrayList<k.a> arrayList = new ArrayList();
      for (k.a a : param1List) {
        if (!a.j())
          arrayList.add(a); 
      } 
      return arrayList;
    }
    
    public void b(j param1j) {
      if (Build.VERSION.SDK_INT >= 24)
        param1j.a().setStyle((Notification.Style)l.a()); 
    }
    
    protected String k() {
      return "androidx.core.app.NotificationCompat$DecoratedCustomViewStyle";
    }
    
    public RemoteViews m(j param1j) {
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      RemoteViews remoteViews = this.a.c();
      if (remoteViews == null)
        remoteViews = this.a.e(); 
      return (remoteViews == null) ? null : q(remoteViews, true);
    }
    
    public RemoteViews n(j param1j) {
      return (Build.VERSION.SDK_INT >= 24) ? null : ((this.a.e() == null) ? null : q(this.a.e(), false));
    }
    
    public RemoteViews o(j param1j) {
      RemoteViews remoteViews1;
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      RemoteViews remoteViews2 = this.a.g();
      if (remoteViews2 != null) {
        remoteViews1 = remoteViews2;
      } else {
        remoteViews1 = this.a.e();
      } 
      return (remoteViews2 == null) ? null : q(remoteViews1, true);
    }
  }
  
  public static abstract class f {
    protected k.d a;
    
    CharSequence b;
    
    CharSequence c;
    
    boolean d = false;
    
    private int e() {
      Resources resources = this.a.a.getResources();
      int i = resources.getDimensionPixelSize(v.c.notification_top_pad);
      int j = resources.getDimensionPixelSize(v.c.notification_top_pad_large_text);
      float f1 = (f((resources.getConfiguration()).fontScale, 1.0F, 1.3F) - 1.0F) / 0.29999995F;
      return Math.round((1.0F - f1) * i + f1 * j);
    }
    
    private static float f(float param1Float1, float param1Float2, float param1Float3) {
      if (param1Float1 < param1Float2)
        return param1Float2; 
      param1Float2 = param1Float1;
      if (param1Float1 > param1Float3)
        param1Float2 = param1Float3; 
      return param1Float2;
    }
    
    private Bitmap g(int param1Int1, int param1Int2, int param1Int3) {
      return i(IconCompat.d(this.a.a, param1Int1), param1Int2, param1Int3);
    }
    
    private Bitmap i(IconCompat param1IconCompat, int param1Int1, int param1Int2) {
      int i;
      Drawable drawable = param1IconCompat.l(this.a.a);
      if (param1Int2 == 0) {
        i = drawable.getIntrinsicWidth();
      } else {
        i = param1Int2;
      } 
      int j = param1Int2;
      if (param1Int2 == 0)
        j = drawable.getIntrinsicHeight(); 
      Bitmap bitmap = Bitmap.createBitmap(i, j, Bitmap.Config.ARGB_8888);
      drawable.setBounds(0, 0, i, j);
      if (param1Int1 != 0)
        drawable.mutate().setColorFilter((ColorFilter)new PorterDuffColorFilter(param1Int1, PorterDuff.Mode.SRC_IN)); 
      drawable.draw(new Canvas(bitmap));
      return bitmap;
    }
    
    private Bitmap j(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      int j = v.d.notification_icon_background;
      int i = param1Int4;
      if (param1Int4 == 0)
        i = 0; 
      Bitmap bitmap = g(j, i, param1Int2);
      Canvas canvas = new Canvas(bitmap);
      Drawable drawable = this.a.a.getResources().getDrawable(param1Int1).mutate();
      drawable.setFilterBitmap(true);
      param1Int1 = (param1Int2 - param1Int3) / 2;
      param1Int2 = param1Int3 + param1Int1;
      drawable.setBounds(param1Int1, param1Int1, param1Int2, param1Int2);
      drawable.setColorFilter((ColorFilter)new PorterDuffColorFilter(-1, PorterDuff.Mode.SRC_ATOP));
      drawable.draw(canvas);
      return bitmap;
    }
    
    private void l(RemoteViews param1RemoteViews) {
      param1RemoteViews.setViewVisibility(v.e.title, 8);
      param1RemoteViews.setViewVisibility(v.e.text2, 8);
      param1RemoteViews.setViewVisibility(v.e.text, 8);
    }
    
    public void a(Bundle param1Bundle) {
      if (this.d)
        param1Bundle.putCharSequence("android.summaryText", this.c); 
      CharSequence charSequence = this.b;
      if (charSequence != null)
        param1Bundle.putCharSequence("android.title.big", charSequence); 
      charSequence = k();
      if (charSequence != null)
        param1Bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", (String)charSequence); 
    }
    
    public abstract void b(j param1j);
    
    public RemoteViews c(boolean param1Boolean1, int param1Int, boolean param1Boolean2) {
      Bitmap bitmap1;
      Resources resources = this.a.a.getResources();
      RemoteViews remoteViews = new RemoteViews(this.a.a.getPackageName(), param1Int);
      this.a.h();
      int i = Build.VERSION.SDK_INT;
      k.d d2 = this.a;
      Bitmap bitmap2 = d2.j;
      boolean bool2 = false;
      if (bitmap2 != null) {
        param1Int = v.e.icon;
        remoteViews.setViewVisibility(param1Int, 0);
        remoteViews.setImageViewBitmap(param1Int, this.a.j);
        if (param1Boolean1 && this.a.S.icon != 0) {
          param1Int = resources.getDimensionPixelSize(v.c.notification_right_icon_size);
          int j = resources.getDimensionPixelSize(v.c.notification_small_icon_background_padding);
          d2 = this.a;
          bitmap1 = j(d2.S.icon, param1Int, param1Int - j * 2, d2.d());
          param1Int = v.e.right_icon;
          remoteViews.setImageViewBitmap(param1Int, bitmap1);
          remoteViews.setViewVisibility(param1Int, 0);
        } 
      } else if (param1Boolean1 && ((k.d)bitmap1).S.icon != 0) {
        param1Int = v.e.icon;
        remoteViews.setViewVisibility(param1Int, 0);
        int j = resources.getDimensionPixelSize(v.c.notification_large_icon_width);
        int k = resources.getDimensionPixelSize(v.c.notification_big_circle_margin);
        int m = resources.getDimensionPixelSize(v.c.notification_small_icon_size_as_large);
        k.d d3 = this.a;
        remoteViews.setImageViewBitmap(param1Int, j(d3.S.icon, j - k, m, d3.d()));
      } 
      CharSequence charSequence2 = this.a.e;
      if (charSequence2 != null)
        remoteViews.setTextViewText(v.e.title, charSequence2); 
      charSequence2 = this.a.f;
      boolean bool3 = true;
      if (charSequence2 != null) {
        remoteViews.setTextViewText(v.e.text, charSequence2);
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      k.d d1 = this.a;
      CharSequence charSequence3 = d1.k;
      if (charSequence3 != null) {
        param1Int = v.e.info;
        remoteViews.setTextViewText(param1Int, charSequence3);
        remoteViews.setViewVisibility(param1Int, 0);
      } else if (d1.l > 0) {
        param1Int = resources.getInteger(v.f.status_bar_notification_info_maxnum);
        if (this.a.l > param1Int) {
          remoteViews.setTextViewText(v.e.info, resources.getString(h.status_bar_notification_info_overflow));
        } else {
          NumberFormat numberFormat = NumberFormat.getIntegerInstance();
          remoteViews.setTextViewText(v.e.info, numberFormat.format(this.a.l));
        } 
        remoteViews.setViewVisibility(v.e.info, 0);
      } else {
        remoteViews.setViewVisibility(v.e.info, 8);
        boolean bool = false;
        int j = param1Int;
        param1Int = bool;
        CharSequence charSequence = this.a.r;
      } 
      boolean bool1 = true;
      param1Int = 1;
      CharSequence charSequence1 = this.a.r;
    }
    
    public void d(RemoteViews param1RemoteViews1, RemoteViews param1RemoteViews2) {
      l(param1RemoteViews1);
      int i = v.e.notification_main_column;
      param1RemoteViews1.removeAllViews(i);
      param1RemoteViews1.addView(i, param1RemoteViews2.clone());
      param1RemoteViews1.setViewVisibility(i, 0);
      param1RemoteViews1.setViewPadding(v.e.notification_main_column_container, 0, e(), 0, 0);
    }
    
    Bitmap h(IconCompat param1IconCompat, int param1Int) {
      return i(param1IconCompat, param1Int, 0);
    }
    
    protected String k() {
      return null;
    }
    
    public RemoteViews m(j param1j) {
      return null;
    }
    
    public RemoteViews n(j param1j) {
      return null;
    }
    
    public RemoteViews o(j param1j) {
      return null;
    }
    
    public void p(k.d param1d) {
      if (this.a != param1d) {
        this.a = param1d;
        if (param1d != null)
          param1d.E(this); 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\app\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */