package androidx.core.app;

import android.os.Bundle;
import android.os.IBinder;

public abstract class f {
  public static IBinder a(Bundle paramBundle, String paramString) {
    return a.a(paramBundle, paramString);
  }
  
  public static void b(Bundle paramBundle, String paramString, IBinder paramIBinder) {
    a.b(paramBundle, paramString, paramIBinder);
  }
  
  static abstract class a {
    static IBinder a(Bundle param1Bundle, String param1String) {
      return param1Bundle.getBinder(param1String);
    }
    
    static void b(Bundle param1Bundle, String param1String, IBinder param1IBinder) {
      param1Bundle.putBinder(param1String, param1IBinder);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */