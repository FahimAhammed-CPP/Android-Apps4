package androidx.core.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.core.content.a;
import java.util.Arrays;
import java.util.HashSet;

public abstract class b extends a {
  public static void b(Activity paramActivity) {
    b.a(paramActivity);
  }
  
  public static void c(Activity paramActivity) {
    c.a(paramActivity);
  }
  
  public static void e(Activity paramActivity) {
    c.b(paramActivity);
  }
  
  public static void f(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 28) {
      paramActivity.recreate();
      return;
    } 
    (new Handler(paramActivity.getMainLooper())).post(new a(paramActivity));
  }
  
  public static void g(Activity paramActivity, String[] paramArrayOfString, int paramInt) {
    StringBuilder stringBuilder;
    String[] arrayOfString;
    HashSet<Integer> hashSet = new HashSet();
    int j = 0;
    int i = 0;
    while (i < paramArrayOfString.length) {
      if (!TextUtils.isEmpty(paramArrayOfString[i])) {
        if (!androidx.core.os.a.c() && TextUtils.equals(paramArrayOfString[i], "android.permission.POST_NOTIFICATIONS"))
          hashSet.add(Integer.valueOf(i)); 
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Permission request for permissions ");
      stringBuilder.append(Arrays.toString((Object[])paramArrayOfString));
      stringBuilder.append(" must not contain null or empty values");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    i = hashSet.size();
    if (i > 0) {
      arrayOfString = new String[paramArrayOfString.length - i];
    } else {
      arrayOfString = paramArrayOfString;
    } 
    if (i > 0) {
      if (i == paramArrayOfString.length)
        return; 
      int k = 0;
      i = j;
      while (i < paramArrayOfString.length) {
        j = k;
        if (!hashSet.contains(Integer.valueOf(i))) {
          arrayOfString[k] = paramArrayOfString[i];
          j = k + 1;
        } 
        i++;
        k = j;
      } 
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      if (stringBuilder instanceof f)
        ((f)stringBuilder).validateRequestPermissionsRequestCode(paramInt); 
      d.b((Activity)stringBuilder, paramArrayOfString, paramInt);
      return;
    } 
    if (stringBuilder instanceof e)
      (new Handler(Looper.getMainLooper())).post(new a(arrayOfString, (Activity)stringBuilder, paramInt)); 
  }
  
  public static void h(Activity paramActivity, r0 paramr0) {
    c.c(paramActivity, null);
  }
  
  public static void i(Activity paramActivity, r0 paramr0) {
    c.d(paramActivity, null);
  }
  
  public static boolean j(Activity paramActivity, String paramString) {
    return (!androidx.core.os.a.c() && TextUtils.equals("android.permission.POST_NOTIFICATIONS", paramString)) ? false : ((Build.VERSION.SDK_INT >= 23) ? d.c(paramActivity, paramString) : false);
  }
  
  public static void k(Activity paramActivity, Intent paramIntent, int paramInt, Bundle paramBundle) {
    b.b(paramActivity, paramIntent, paramInt, paramBundle);
  }
  
  public static void l(Activity paramActivity, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    b.c(paramActivity, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public static void m(Activity paramActivity) {
    c.e(paramActivity);
  }
  
  class a implements Runnable {
    a(b this$0, Activity param1Activity, int param1Int) {}
    
    public void run() {
      int[] arrayOfInt = new int[this.a.length];
      PackageManager packageManager = this.b.getPackageManager();
      String str = this.b.getPackageName();
      int j = this.a.length;
      for (int i = 0; i < j; i++)
        arrayOfInt[i] = packageManager.checkPermission(this.a[i], str); 
      ((b.e)this.b).onRequestPermissionsResult(this.c, this.a, arrayOfInt);
    }
  }
  
  static abstract class b {
    static void a(Activity param1Activity) {
      param1Activity.finishAffinity();
    }
    
    static void b(Activity param1Activity, Intent param1Intent, int param1Int, Bundle param1Bundle) {
      param1Activity.startActivityForResult(param1Intent, param1Int, param1Bundle);
    }
    
    static void c(Activity param1Activity, IntentSender param1IntentSender, int param1Int1, Intent param1Intent, int param1Int2, int param1Int3, int param1Int4, Bundle param1Bundle) throws IntentSender.SendIntentException {
      param1Activity.startIntentSenderForResult(param1IntentSender, param1Int1, param1Intent, param1Int2, param1Int3, param1Int4, param1Bundle);
    }
  }
  
  static abstract class c {
    static void a(Activity param1Activity) {
      param1Activity.finishAfterTransition();
    }
    
    static void b(Activity param1Activity) {
      param1Activity.postponeEnterTransition();
    }
    
    static void c(Activity param1Activity, SharedElementCallback param1SharedElementCallback) {
      param1Activity.setEnterSharedElementCallback(param1SharedElementCallback);
    }
    
    static void d(Activity param1Activity, SharedElementCallback param1SharedElementCallback) {
      param1Activity.setExitSharedElementCallback(param1SharedElementCallback);
    }
    
    static void e(Activity param1Activity) {
      param1Activity.startPostponedEnterTransition();
    }
  }
  
  static abstract class d {
    static void a(Object param1Object) {
      ((SharedElementCallback.OnSharedElementsReadyListener)param1Object).onSharedElementsReady();
    }
    
    static void b(Activity param1Activity, String[] param1ArrayOfString, int param1Int) {
      param1Activity.requestPermissions(param1ArrayOfString, param1Int);
    }
    
    static boolean c(Activity param1Activity, String param1String) {
      return param1Activity.shouldShowRequestPermissionRationale(param1String);
    }
  }
  
  public static interface e {
    void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
  }
  
  public static interface f {
    void validateRequestPermissionsRequestCode(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */