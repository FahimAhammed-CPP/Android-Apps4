package androidx.core.app;

import androidx.core.util.a;

public interface n0 {
  void addOnMultiWindowModeChangedListener(a parama);
  
  void removeOnMultiWindowModeChangedListener(a parama);
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\app\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */