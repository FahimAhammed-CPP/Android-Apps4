package androidx.core.app;

import android.app.AppOpsManager;
import android.content.Context;
import android.os.Binder;
import android.os.Build;

public abstract class e {
  public static int a(Context paramContext, int paramInt, String paramString1, String paramString2) {
    if (Build.VERSION.SDK_INT >= 29) {
      AppOpsManager appOpsManager = b.c(paramContext);
      int i = b.a(appOpsManager, paramString1, Binder.getCallingUid(), paramString2);
      return (i != 0) ? i : b.a(appOpsManager, paramString1, paramInt, b.b(paramContext));
    } 
    return b(paramContext, paramString1, paramString2);
  }
  
  public static int b(Context paramContext, String paramString1, String paramString2) {
    return (Build.VERSION.SDK_INT >= 23) ? a.c(a.<AppOpsManager>a(paramContext, AppOpsManager.class), paramString1, paramString2) : 1;
  }
  
  public static String c(String paramString) {
    return (Build.VERSION.SDK_INT >= 23) ? a.d(paramString) : null;
  }
  
  static abstract class a {
    static <T> T a(Context param1Context, Class<T> param1Class) {
      return (T)param1Context.getSystemService(param1Class);
    }
    
    static int b(AppOpsManager param1AppOpsManager, String param1String1, String param1String2) {
      return param1AppOpsManager.noteProxyOp(param1String1, param1String2);
    }
    
    static int c(AppOpsManager param1AppOpsManager, String param1String1, String param1String2) {
      return param1AppOpsManager.noteProxyOpNoThrow(param1String1, param1String2);
    }
    
    static String d(String param1String) {
      return AppOpsManager.permissionToOp(param1String);
    }
  }
  
  static abstract class b {
    static int a(AppOpsManager param1AppOpsManager, String param1String1, int param1Int, String param1String2) {
      return (param1AppOpsManager == null) ? 1 : param1AppOpsManager.checkOpNoThrow(param1String1, param1Int, param1String2);
    }
    
    static String b(Context param1Context) {
      return param1Context.getOpPackageName();
    }
    
    static AppOpsManager c(Context param1Context) {
      return (AppOpsManager)param1Context.getSystemService(AppOpsManager.class);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */