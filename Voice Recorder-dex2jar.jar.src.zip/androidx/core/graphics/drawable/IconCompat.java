package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.content.res.h;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {
  static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;
  
  public int a;
  
  Object b;
  
  public byte[] c;
  
  public Parcelable d;
  
  public int e;
  
  public int f;
  
  public ColorStateList g;
  
  PorterDuff.Mode h;
  
  public String i;
  
  public String j;
  
  public IconCompat() {
    this.a = -1;
    this.c = null;
    this.d = null;
    this.e = 0;
    this.f = 0;
    this.g = null;
    this.h = k;
    this.i = null;
  }
  
  IconCompat(int paramInt) {
    this.c = null;
    this.d = null;
    this.e = 0;
    this.f = 0;
    this.g = null;
    this.h = k;
    this.i = null;
    this.a = paramInt;
  }
  
  static Bitmap c(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, tileMode, tileMode);
    Matrix matrix = new Matrix();
    matrix.setTranslate(-(paramBitmap.getWidth() - i) / 2.0F, -(paramBitmap.getHeight() - i) / 2.0F);
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat d(Context paramContext, int paramInt) {
    androidx.core.util.c.c(paramContext);
    return e(paramContext.getResources(), paramContext.getPackageName(), paramInt);
  }
  
  public static IconCompat e(Resources paramResources, String paramString, int paramInt) {
    androidx.core.util.c.c(paramString);
    if (paramInt != 0) {
      IconCompat iconCompat = new IconCompat(2);
      iconCompat.e = paramInt;
      if (paramResources != null)
        try {
          iconCompat.b = paramResources.getResourceName(paramInt);
          iconCompat.j = paramString;
          return iconCompat;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw new IllegalArgumentException("Icon resource cannot be found");
        }  
      iconCompat.b = paramString;
      iconCompat.j = paramString;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Drawable resource ID must not be 0");
  }
  
  static Resources h(Context paramContext, String paramString) {
    if ("android".equals(paramString))
      return Resources.getSystem(); 
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      ApplicationInfo applicationInfo = packageManager.getApplicationInfo(paramString, 8192);
      return (applicationInfo != null) ? packageManager.getResourcesForApplication(applicationInfo) : null;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("IconCompat", String.format("Unable to find pkg=%s for icon", new Object[] { paramString }), (Throwable)nameNotFoundException);
      return null;
    } 
  }
  
  private Drawable m(Context paramContext) {
    InputStream inputStream;
    String str1;
    Resources resources;
    String str2;
    switch (this.a) {
      default:
        return null;
      case 6:
        inputStream = k(paramContext);
        return (Drawable)((inputStream != null) ? ((Build.VERSION.SDK_INT >= 26) ? b.a(null, (Drawable)new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeStream(inputStream))) : new BitmapDrawable(paramContext.getResources(), c(BitmapFactory.decodeStream(inputStream), false))) : null);
      case 5:
        return (Drawable)new BitmapDrawable(paramContext.getResources(), c((Bitmap)this.b, false));
      case 4:
        inputStream = k(paramContext);
        return (Drawable)((inputStream != null) ? new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeStream(inputStream)) : null);
      case 3:
        return (Drawable)new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeByteArray((byte[])this.b, this.e, this.f));
      case 2:
        str2 = g();
        str1 = str2;
        if (TextUtils.isEmpty(str2))
          str1 = paramContext.getPackageName(); 
        resources = h(paramContext, str1);
        try {
          return h.e(resources, this.e, paramContext.getTheme());
        } catch (RuntimeException runtimeException) {
          Log.e("IconCompat", String.format("Unable to load resource 0x%08x from pkg=%s", new Object[] { Integer.valueOf(this.e), this.b }), runtimeException);
          return null;
        } 
      case 1:
        break;
    } 
    return (Drawable)new BitmapDrawable(runtimeException.getResources(), (Bitmap)this.b);
  }
  
  private static String r(int paramInt) {
    switch (paramInt) {
      default:
        return "UNKNOWN";
      case 6:
        return "URI_MASKABLE";
      case 5:
        return "BITMAP_MASKABLE";
      case 4:
        return "URI";
      case 3:
        return "DATA";
      case 2:
        return "RESOURCE";
      case 1:
        break;
    } 
    return "BITMAP";
  }
  
  public void b(Context paramContext) {
    if (this.a == 2) {
      Object object = this.b;
      if (object != null) {
        object = object;
        if (!object.contains(":"))
          return; 
        String str2 = object.split(":", -1)[1];
        String str1 = str2.split("/", -1)[0];
        String str3 = str2.split("/", -1)[1];
        String str4 = object.split(":", -1)[0];
        if ("0_resource_name_obfuscated".equals(str3)) {
          Log.i("IconCompat", "Found obfuscated resource, not trying to update resource id for it");
          return;
        } 
        str2 = g();
        int i = h(paramContext, str2).getIdentifier(str3, str1, str4);
        if (this.e != i) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Id has changed for ");
          stringBuilder.append(str2);
          stringBuilder.append(" ");
          stringBuilder.append((String)object);
          Log.i("IconCompat", stringBuilder.toString());
          this.e = i;
        } 
      } 
    } 
  }
  
  public int f() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return a.a(this.b); 
    if (i == 2)
      return this.e; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String g() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return a.b(this.b); 
    if (i == 2) {
      String str = this.j;
      return (str == null || TextUtils.isEmpty(str)) ? ((String)this.b).split(":", -1)[0] : this.j;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResPackage() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int i() {
    int j = this.a;
    int i = j;
    if (j == -1) {
      i = j;
      if (Build.VERSION.SDK_INT >= 23)
        i = a.c(this.b); 
    } 
    return i;
  }
  
  public Uri j() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return a.d(this.b); 
    if (i == 4 || i == 6)
      return Uri.parse((String)this.b); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getUri() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public InputStream k(Context paramContext) {
    Uri uri = j();
    String str = uri.getScheme();
    if ("content".equals(str) || "file".equals(str)) {
      try {
        return paramContext.getContentResolver().openInputStream(uri);
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to load image from URI: ");
        stringBuilder.append(uri);
        Log.w("IconCompat", stringBuilder.toString(), exception);
      } 
      return null;
    } 
    try {
      return new FileInputStream(new File((String)this.b));
    } catch (FileNotFoundException fileNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to load image from path: ");
      stringBuilder.append(uri);
      Log.w("IconCompat", stringBuilder.toString(), fileNotFoundException);
    } 
    return null;
  }
  
  public Drawable l(Context paramContext) {
    b(paramContext);
    if (Build.VERSION.SDK_INT >= 23)
      return a.e(q(paramContext), paramContext); 
    Drawable drawable = m(paramContext);
    if (drawable != null && (this.g != null || this.h != k)) {
      drawable.mutate();
      a.o(drawable, this.g);
      a.p(drawable, this.h);
    } 
    return drawable;
  }
  
  public void n() {
    String str;
    Parcelable parcelable2;
    byte[] arrayOfByte;
    this.h = PorterDuff.Mode.valueOf(this.i);
    switch (this.a) {
      default:
        return;
      case 3:
        this.b = this.c;
        return;
      case 2:
      case 4:
      case 6:
        str = new String(this.c, Charset.forName("UTF-16"));
        this.b = str;
        if (this.a == 2 && this.j == null) {
          this.j = str.split(":", -1)[0];
          return;
        } 
        return;
      case 1:
      case 5:
        parcelable2 = this.d;
        if (parcelable2 != null) {
          this.b = parcelable2;
          return;
        } 
        arrayOfByte = this.c;
        this.b = arrayOfByte;
        this.a = 3;
        this.e = 0;
        this.f = arrayOfByte.length;
        return;
      case -1:
        break;
    } 
    Parcelable parcelable1 = this.d;
    if (parcelable1 != null) {
      this.b = parcelable1;
      return;
    } 
    throw new IllegalArgumentException("Invalid icon");
  }
  
  public void o(boolean paramBoolean) {
    this.i = this.h.name();
    switch (this.a) {
      default:
        return;
      case 4:
      case 6:
        this.c = this.b.toString().getBytes(Charset.forName("UTF-16"));
        return;
      case 3:
        this.c = (byte[])this.b;
        return;
      case 2:
        this.c = ((String)this.b).getBytes(Charset.forName("UTF-16"));
        return;
      case 1:
      case 5:
        if (paramBoolean) {
          Bitmap bitmap = (Bitmap)this.b;
          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
          bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
          this.c = byteArrayOutputStream.toByteArray();
          return;
        } 
        this.d = (Parcelable)this.b;
        return;
      case -1:
        break;
    } 
    if (!paramBoolean) {
      this.d = (Parcelable)this.b;
      return;
    } 
    throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
  }
  
  public Icon p() {
    return q(null);
  }
  
  public Icon q(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 23)
      return a.f(this, paramContext); 
    throw new UnsupportedOperationException("This method is only supported on API level 23+");
  }
  
  public String toString() {
    if (this.a == -1)
      return String.valueOf(this.b); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    stringBuilder.append(r(this.a));
    switch (this.a) {
      case 4:
      case 6:
        stringBuilder.append(" uri=");
        stringBuilder.append(this.b);
        break;
      case 3:
        stringBuilder.append(" len=");
        stringBuilder.append(this.e);
        if (this.f != 0) {
          stringBuilder.append(" off=");
          stringBuilder.append(this.f);
        } 
        break;
      case 2:
        stringBuilder.append(" pkg=");
        stringBuilder.append(this.j);
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(f()) }));
        break;
      case 1:
      case 5:
        stringBuilder.append(" size=");
        stringBuilder.append(((Bitmap)this.b).getWidth());
        stringBuilder.append("x");
        stringBuilder.append(((Bitmap)this.b).getHeight());
        break;
    } 
    if (this.g != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.g);
    } 
    if (this.h != k) {
      stringBuilder.append(" mode=");
      stringBuilder.append(this.h);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  static abstract class a {
    static int a(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.a(param1Object); 
      try {
        return ((Integer)param1Object.getClass().getMethod("getResId", new Class[0]).invoke(param1Object, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon resource", illegalAccessException);
        return 0;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon resource", invocationTargetException);
        return 0;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
        return 0;
      } 
    }
    
    static String b(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.b(param1Object); 
      try {
        return (String)param1Object.getClass().getMethod("getResPackage", new Class[0]).invoke(param1Object, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon package", illegalAccessException);
        return null;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon package", invocationTargetException);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon package", noSuchMethodException);
        return null;
      } 
    }
    
    static int c(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.c(param1Object); 
      try {
        return ((Integer)param1Object.getClass().getMethod("getType", new Class[0]).invoke(param1Object, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to get icon type ");
        stringBuilder.append(param1Object);
        Log.e("IconCompat", stringBuilder.toString(), illegalAccessException);
        return -1;
      } catch (InvocationTargetException invocationTargetException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to get icon type ");
        stringBuilder.append(param1Object);
        Log.e("IconCompat", stringBuilder.toString(), invocationTargetException);
        return -1;
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to get icon type ");
        stringBuilder.append(param1Object);
        Log.e("IconCompat", stringBuilder.toString(), noSuchMethodException);
        return -1;
      } 
    }
    
    static Uri d(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.d(param1Object); 
      try {
        return (Uri)param1Object.getClass().getMethod("getUri", new Class[0]).invoke(param1Object, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon uri", illegalAccessException);
        return null;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon uri", invocationTargetException);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon uri", noSuchMethodException);
        return null;
      } 
    }
    
    static Drawable e(Icon param1Icon, Context param1Context) {
      return param1Icon.loadDrawable(param1Context);
    }
    
    static Icon f(IconCompat param1IconCompat, Context param1Context) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : I
      //   4: tableswitch default -> 52, -1 -> 338, 0 -> 52, 1 -> 292, 2 -> 277, 3 -> 255, 4 -> 241, 5 -> 201, 6 -> 62
      //   52: new java/lang/IllegalArgumentException
      //   55: dup
      //   56: ldc 'Unknown type'
      //   58: invokespecial <init> : (Ljava/lang/String;)V
      //   61: athrow
      //   62: getstatic android/os/Build$VERSION.SDK_INT : I
      //   65: istore_2
      //   66: iload_2
      //   67: bipush #30
      //   69: if_icmplt -> 83
      //   72: aload_0
      //   73: invokevirtual j : ()Landroid/net/Uri;
      //   76: invokestatic a : (Landroid/net/Uri;)Landroid/graphics/drawable/Icon;
      //   79: astore_1
      //   80: goto -> 303
      //   83: aload_1
      //   84: ifnull -> 165
      //   87: aload_0
      //   88: aload_1
      //   89: invokevirtual k : (Landroid/content/Context;)Ljava/io/InputStream;
      //   92: astore_1
      //   93: aload_1
      //   94: ifnull -> 129
      //   97: iload_2
      //   98: bipush #26
      //   100: if_icmplt -> 114
      //   103: aload_1
      //   104: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
      //   107: invokestatic b : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   110: astore_1
      //   111: goto -> 303
      //   114: aload_1
      //   115: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
      //   118: iconst_0
      //   119: invokestatic c : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
      //   122: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   125: astore_1
      //   126: goto -> 303
      //   129: new java/lang/StringBuilder
      //   132: dup
      //   133: invokespecial <init> : ()V
      //   136: astore_1
      //   137: aload_1
      //   138: ldc 'Cannot load adaptive icon from uri: '
      //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   143: pop
      //   144: aload_1
      //   145: aload_0
      //   146: invokevirtual j : ()Landroid/net/Uri;
      //   149: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   152: pop
      //   153: new java/lang/IllegalStateException
      //   156: dup
      //   157: aload_1
      //   158: invokevirtual toString : ()Ljava/lang/String;
      //   161: invokespecial <init> : (Ljava/lang/String;)V
      //   164: athrow
      //   165: new java/lang/StringBuilder
      //   168: dup
      //   169: invokespecial <init> : ()V
      //   172: astore_1
      //   173: aload_1
      //   174: ldc 'Context is required to resolve the file uri of the icon: '
      //   176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   179: pop
      //   180: aload_1
      //   181: aload_0
      //   182: invokevirtual j : ()Landroid/net/Uri;
      //   185: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   188: pop
      //   189: new java/lang/IllegalArgumentException
      //   192: dup
      //   193: aload_1
      //   194: invokevirtual toString : ()Ljava/lang/String;
      //   197: invokespecial <init> : (Ljava/lang/String;)V
      //   200: athrow
      //   201: getstatic android/os/Build$VERSION.SDK_INT : I
      //   204: bipush #26
      //   206: if_icmplt -> 223
      //   209: aload_0
      //   210: getfield b : Ljava/lang/Object;
      //   213: checkcast android/graphics/Bitmap
      //   216: invokestatic b : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   219: astore_1
      //   220: goto -> 303
      //   223: aload_0
      //   224: getfield b : Ljava/lang/Object;
      //   227: checkcast android/graphics/Bitmap
      //   230: iconst_0
      //   231: invokestatic c : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
      //   234: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   237: astore_1
      //   238: goto -> 303
      //   241: aload_0
      //   242: getfield b : Ljava/lang/Object;
      //   245: checkcast java/lang/String
      //   248: invokestatic createWithContentUri : (Ljava/lang/String;)Landroid/graphics/drawable/Icon;
      //   251: astore_1
      //   252: goto -> 303
      //   255: aload_0
      //   256: getfield b : Ljava/lang/Object;
      //   259: checkcast [B
      //   262: aload_0
      //   263: getfield e : I
      //   266: aload_0
      //   267: getfield f : I
      //   270: invokestatic createWithData : ([BII)Landroid/graphics/drawable/Icon;
      //   273: astore_1
      //   274: goto -> 303
      //   277: aload_0
      //   278: invokevirtual g : ()Ljava/lang/String;
      //   281: aload_0
      //   282: getfield e : I
      //   285: invokestatic createWithResource : (Ljava/lang/String;I)Landroid/graphics/drawable/Icon;
      //   288: astore_1
      //   289: goto -> 303
      //   292: aload_0
      //   293: getfield b : Ljava/lang/Object;
      //   296: checkcast android/graphics/Bitmap
      //   299: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   302: astore_1
      //   303: aload_0
      //   304: getfield g : Landroid/content/res/ColorStateList;
      //   307: astore_3
      //   308: aload_3
      //   309: ifnull -> 318
      //   312: aload_1
      //   313: aload_3
      //   314: invokevirtual setTintList : (Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Icon;
      //   317: pop
      //   318: aload_0
      //   319: getfield h : Landroid/graphics/PorterDuff$Mode;
      //   322: astore_0
      //   323: aload_0
      //   324: getstatic androidx/core/graphics/drawable/IconCompat.k : Landroid/graphics/PorterDuff$Mode;
      //   327: if_acmpeq -> 336
      //   330: aload_1
      //   331: aload_0
      //   332: invokevirtual setTintMode : (Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/drawable/Icon;
      //   335: pop
      //   336: aload_1
      //   337: areturn
      //   338: aload_0
      //   339: getfield b : Ljava/lang/Object;
      //   342: checkcast android/graphics/drawable/Icon
      //   345: areturn
    }
  }
  
  static abstract class b {
    static Drawable a(Drawable param1Drawable1, Drawable param1Drawable2) {
      return (Drawable)new AdaptiveIconDrawable(param1Drawable1, param1Drawable2);
    }
    
    static Icon b(Bitmap param1Bitmap) {
      return Icon.createWithAdaptiveBitmap(param1Bitmap);
    }
  }
  
  static abstract class c {
    static int a(Object param1Object) {
      return ((Icon)param1Object).getResId();
    }
    
    static String b(Object param1Object) {
      return ((Icon)param1Object).getResPackage();
    }
    
    static int c(Object param1Object) {
      return ((Icon)param1Object).getType();
    }
    
    static Uri d(Object param1Object) {
      return ((Icon)param1Object).getUri();
    }
  }
  
  static abstract class d {
    static Icon a(Uri param1Uri) {
      return Icon.createWithAdaptiveBitmapContentUri(param1Uri);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */