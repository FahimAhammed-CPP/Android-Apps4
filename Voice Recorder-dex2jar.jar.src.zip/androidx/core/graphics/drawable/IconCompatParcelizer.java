package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import androidx.versionedparcelable.a;

public class IconCompatParcelizer {
  public static IconCompat read(a parama) {
    IconCompat iconCompat = new IconCompat();
    iconCompat.a = parama.p(iconCompat.a, 1);
    iconCompat.c = parama.j(iconCompat.c, 2);
    iconCompat.d = parama.r(iconCompat.d, 3);
    iconCompat.e = parama.p(iconCompat.e, 4);
    iconCompat.f = parama.p(iconCompat.f, 5);
    iconCompat.g = (ColorStateList)parama.r((Parcelable)iconCompat.g, 6);
    iconCompat.i = parama.t(iconCompat.i, 7);
    iconCompat.j = parama.t(iconCompat.j, 8);
    iconCompat.n();
    return iconCompat;
  }
  
  public static void write(IconCompat paramIconCompat, a parama) {
    parama.x(true, true);
    paramIconCompat.o(parama.f());
    int i = paramIconCompat.a;
    if (-1 != i)
      parama.F(i, 1); 
    byte[] arrayOfByte = paramIconCompat.c;
    if (arrayOfByte != null)
      parama.B(arrayOfByte, 2); 
    Parcelable parcelable = paramIconCompat.d;
    if (parcelable != null)
      parama.H(parcelable, 3); 
    i = paramIconCompat.e;
    if (i != 0)
      parama.F(i, 4); 
    i = paramIconCompat.f;
    if (i != 0)
      parama.F(i, 5); 
    ColorStateList colorStateList = paramIconCompat.g;
    if (colorStateList != null)
      parama.H((Parcelable)colorStateList, 6); 
    String str2 = paramIconCompat.i;
    if (str2 != null)
      parama.J(str2, 7); 
    String str1 = paramIconCompat.j;
    if (str1 != null)
      parama.J(str1, 8); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\graphics\drawable\IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */