package androidx.core.view;

import android.view.View;

public interface h0 {
  d a(View paramView, d paramd);
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */