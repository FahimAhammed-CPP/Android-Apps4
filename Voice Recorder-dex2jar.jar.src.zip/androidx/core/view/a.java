package androidx.core.view;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import androidx.core.view.accessibility.h0;
import androidx.core.view.accessibility.i0;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;
import v.e;

public class a {
  private static final View.AccessibilityDelegate c = new View.AccessibilityDelegate();
  
  private final View.AccessibilityDelegate a;
  
  private final View.AccessibilityDelegate b;
  
  public a() {
    this(c);
  }
  
  public a(View.AccessibilityDelegate paramAccessibilityDelegate) {
    this.a = paramAccessibilityDelegate;
    this.b = new a(this);
  }
  
  static List c(View paramView) {
    List<?> list2 = (List)paramView.getTag(e.tag_accessibility_actions);
    List<?> list1 = list2;
    if (list2 == null)
      list1 = Collections.emptyList(); 
    return list1;
  }
  
  private boolean e(ClickableSpan paramClickableSpan, View paramView) {
    if (paramClickableSpan != null) {
      ClickableSpan[] arrayOfClickableSpan = h0.q(paramView.createAccessibilityNodeInfo().getText());
      for (int i = 0; arrayOfClickableSpan != null && i < arrayOfClickableSpan.length; i++) {
        if (paramClickableSpan.equals(arrayOfClickableSpan[i]))
          return true; 
      } 
    } 
    return false;
  }
  
  private boolean k(int paramInt, View paramView) {
    SparseArray sparseArray = (SparseArray)paramView.getTag(e.tag_accessibility_clickable_spans);
    if (sparseArray != null) {
      WeakReference<ClickableSpan> weakReference = (WeakReference)sparseArray.get(paramInt);
      if (weakReference != null) {
        ClickableSpan clickableSpan = weakReference.get();
        if (e(clickableSpan, paramView)) {
          clickableSpan.onClick(paramView);
          return true;
        } 
      } 
    } 
    return false;
  }
  
  public boolean a(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return this.a.dispatchPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public i0 b(View paramView) {
    AccessibilityNodeProvider accessibilityNodeProvider = b.a(this.a, paramView);
    return (accessibilityNodeProvider != null) ? new i0(accessibilityNodeProvider) : null;
  }
  
  View.AccessibilityDelegate d() {
    return this.b;
  }
  
  public void f(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.a.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public void g(View paramView, h0 paramh0) {
    this.a.onInitializeAccessibilityNodeInfo(paramView, paramh0.F0());
  }
  
  public void h(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.a.onPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public boolean i(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return this.a.onRequestSendAccessibilityEvent(paramViewGroup, paramView, paramAccessibilityEvent);
  }
  
  public boolean j(View paramView, int paramInt, Bundle paramBundle) {
    List<h0.a> list = c(paramView);
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < list.size()) {
        h0.a a1 = list.get(i);
        if (a1.b() == paramInt) {
          bool1 = a1.d(paramView, paramBundle);
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    bool2 = bool1;
    if (!bool1)
      bool2 = b.b(this.a, paramView, paramInt, paramBundle); 
    boolean bool1 = bool2;
    if (!bool2) {
      bool1 = bool2;
      if (paramInt == e.accessibility_action_clickable_span) {
        bool1 = bool2;
        if (paramBundle != null)
          bool1 = k(paramBundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1), paramView); 
      } 
    } 
    return bool1;
  }
  
  public void l(View paramView, int paramInt) {
    this.a.sendAccessibilityEvent(paramView, paramInt);
  }
  
  public void m(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.a.sendAccessibilityEventUnchecked(paramView, paramAccessibilityEvent);
  }
  
  static final class a extends View.AccessibilityDelegate {
    final a a;
    
    a(a param1a) {
      this.a = param1a;
    }
    
    public boolean dispatchPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return this.a.a(param1View, param1AccessibilityEvent);
    }
    
    public AccessibilityNodeProvider getAccessibilityNodeProvider(View param1View) {
      i0 i0 = this.a.b(param1View);
      return (i0 != null) ? (AccessibilityNodeProvider)i0.e() : null;
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.f(param1View, param1AccessibilityEvent);
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      h0 h0 = h0.G0(param1AccessibilityNodeInfo);
      h0.v0(n0.b0(param1View));
      h0.l0(n0.W(param1View));
      h0.q0(n0.r(param1View));
      h0.B0(n0.M(param1View));
      this.a.g(param1View, h0);
      h0.f(param1AccessibilityNodeInfo.getText(), param1View);
      List<h0.a> list = a.c(param1View);
      for (int i = 0; i < list.size(); i++)
        h0.b(list.get(i)); 
    }
    
    public void onPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.h(param1View, param1AccessibilityEvent);
    }
    
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return this.a.i(param1ViewGroup, param1View, param1AccessibilityEvent);
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      return this.a.j(param1View, param1Int, param1Bundle);
    }
    
    public void sendAccessibilityEvent(View param1View, int param1Int) {
      this.a.l(param1View, param1Int);
    }
    
    public void sendAccessibilityEventUnchecked(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.m(param1View, param1AccessibilityEvent);
    }
  }
  
  static abstract class b {
    static AccessibilityNodeProvider a(View.AccessibilityDelegate param1AccessibilityDelegate, View param1View) {
      return param1AccessibilityDelegate.getAccessibilityNodeProvider(param1View);
    }
    
    static boolean b(View.AccessibilityDelegate param1AccessibilityDelegate, View param1View, int param1Int, Bundle param1Bundle) {
      return param1AccessibilityDelegate.performAccessibilityAction(param1View, param1Int, param1Bundle);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */