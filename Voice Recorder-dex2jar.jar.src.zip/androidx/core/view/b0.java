package androidx.core.view;

public interface b0 {}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */