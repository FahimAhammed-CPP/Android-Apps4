package androidx.core.view;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public abstract class b {
  private final Context a;
  
  private a b;
  
  private b c;
  
  public b(Context paramContext) {
    this.a = paramContext;
  }
  
  public abstract boolean a();
  
  public abstract boolean b();
  
  public abstract View c(MenuItem paramMenuItem);
  
  public abstract boolean d();
  
  public abstract void e(SubMenu paramSubMenu);
  
  public abstract boolean f();
  
  public void g() {
    this.c = null;
    this.b = null;
  }
  
  public void h(a parama) {
    this.b = parama;
  }
  
  public abstract void i(b paramb);
  
  public static interface a {}
  
  public static interface b {
    void onActionProviderVisibilityChanged(boolean param1Boolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */