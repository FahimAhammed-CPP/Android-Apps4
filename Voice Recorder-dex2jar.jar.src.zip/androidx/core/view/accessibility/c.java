package androidx.core.view.accessibility;

import android.view.accessibility.AccessibilityManager;

public abstract class c {
  public static boolean a(AccessibilityManager paramAccessibilityManager, b paramb) {
    return a.a(paramAccessibilityManager, paramb);
  }
  
  public static boolean b(AccessibilityManager paramAccessibilityManager, b paramb) {
    return a.b(paramAccessibilityManager, paramb);
  }
  
  static abstract class a {
    static boolean a(AccessibilityManager param1AccessibilityManager, c.b param1b) {
      return param1AccessibilityManager.addTouchExplorationStateChangeListener(new c.c(param1b));
    }
    
    static boolean b(AccessibilityManager param1AccessibilityManager, c.b param1b) {
      return param1AccessibilityManager.removeTouchExplorationStateChangeListener(new c.c(param1b));
    }
  }
  
  public static interface b {
    void onTouchExplorationStateChanged(boolean param1Boolean);
  }
  
  private static final class c implements AccessibilityManager.TouchExplorationStateChangeListener {
    final c.b a;
    
    c(c.b param1b) {
      this.a = param1b;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof c))
        return false; 
      param1Object = param1Object;
      return this.a.equals(((c)param1Object).a);
    }
    
    public int hashCode() {
      return this.a.hashCode();
    }
    
    public void onTouchExplorationStateChanged(boolean param1Boolean) {
      this.a.onTouchExplorationStateChanged(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\accessibility\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */