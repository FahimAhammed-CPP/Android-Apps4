package androidx.core.view.accessibility;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

public final class a extends ClickableSpan {
  private final int a;
  
  private final h0 b;
  
  private final int c;
  
  public a(int paramInt1, h0 paramh0, int paramInt2) {
    this.a = paramInt1;
    this.b = paramh0;
    this.c = paramInt2;
  }
  
  public void onClick(View paramView) {
    Bundle bundle = new Bundle();
    bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.a);
    this.b.R(this.c, bundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\accessibility\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */