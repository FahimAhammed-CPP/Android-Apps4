package androidx.core.view.accessibility;

import android.view.View;

public interface k0 {
  boolean a(View paramView, a parama);
  
  public static abstract class a {}
  
  public static final abstract class b extends a {}
  
  public static final abstract class c extends a {}
  
  public static final abstract class d extends a {}
  
  public static final abstract class e extends a {}
  
  public static final abstract class f extends a {}
  
  public static final abstract class g extends a {}
  
  public static final abstract class h extends a {}
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\accessibility\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */