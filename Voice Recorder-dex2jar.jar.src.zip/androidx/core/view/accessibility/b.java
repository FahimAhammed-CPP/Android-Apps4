package androidx.core.view.accessibility;

import android.view.accessibility.AccessibilityEvent;

public abstract class b {
  public static int a(AccessibilityEvent paramAccessibilityEvent) {
    return a.a(paramAccessibilityEvent);
  }
  
  public static void b(AccessibilityEvent paramAccessibilityEvent, int paramInt) {
    a.b(paramAccessibilityEvent, paramInt);
  }
  
  static abstract class a {
    static int a(AccessibilityEvent param1AccessibilityEvent) {
      return param1AccessibilityEvent.getContentChangeTypes();
    }
    
    static void b(AccessibilityEvent param1AccessibilityEvent, int param1Int) {
      param1AccessibilityEvent.setContentChangeTypes(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\accessibility\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */