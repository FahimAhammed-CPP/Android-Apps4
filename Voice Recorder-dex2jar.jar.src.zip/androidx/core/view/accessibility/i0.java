package androidx.core.view.accessibility;

import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.ArrayList;
import java.util.List;

public class i0 {
  private final Object a;
  
  public i0() {
    if (Build.VERSION.SDK_INT >= 26) {
      this.a = new c(this);
      return;
    } 
    this.a = new b(this);
  }
  
  public i0(Object paramObject) {
    this.a = paramObject;
  }
  
  public void a(int paramInt, h0 paramh0, String paramString, Bundle paramBundle) {}
  
  public h0 b(int paramInt) {
    return null;
  }
  
  public List c(String paramString, int paramInt) {
    return null;
  }
  
  public h0 d(int paramInt) {
    return null;
  }
  
  public Object e() {
    return this.a;
  }
  
  public boolean f(int paramInt1, int paramInt2, Bundle paramBundle) {
    return false;
  }
  
  static abstract class a extends AccessibilityNodeProvider {
    final i0 a;
    
    a(i0 param1i0) {
      this.a = param1i0;
    }
    
    public AccessibilityNodeInfo createAccessibilityNodeInfo(int param1Int) {
      h0 h0 = this.a.b(param1Int);
      return (h0 == null) ? null : h0.F0();
    }
    
    public List findAccessibilityNodeInfosByText(String param1String, int param1Int) {
      List<h0> list = this.a.c(param1String, param1Int);
      if (list == null)
        return null; 
      ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList();
      int i = list.size();
      for (param1Int = 0; param1Int < i; param1Int++)
        arrayList.add(((h0)list.get(param1Int)).F0()); 
      return arrayList;
    }
    
    public boolean performAction(int param1Int1, int param1Int2, Bundle param1Bundle) {
      return this.a.f(param1Int1, param1Int2, param1Bundle);
    }
  }
  
  static class b extends a {
    b(i0 param1i0) {
      super(param1i0);
    }
    
    public AccessibilityNodeInfo findFocus(int param1Int) {
      h0 h0 = this.a.d(param1Int);
      return (h0 == null) ? null : h0.F0();
    }
  }
  
  static class c extends b {
    c(i0 param1i0) {
      super(param1i0);
    }
    
    public void addExtraDataToAccessibilityNodeInfo(int param1Int, AccessibilityNodeInfo param1AccessibilityNodeInfo, String param1String, Bundle param1Bundle) {
      this.a.a(param1Int, h0.G0(param1AccessibilityNodeInfo), param1String, param1Bundle);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\accessibility\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */