package androidx.core.view.accessibility;

import android.view.View;
import android.view.accessibility.AccessibilityRecord;

public abstract class j0 {
  public static void a(AccessibilityRecord paramAccessibilityRecord, int paramInt) {
    a.c(paramAccessibilityRecord, paramInt);
  }
  
  public static void b(AccessibilityRecord paramAccessibilityRecord, int paramInt) {
    a.d(paramAccessibilityRecord, paramInt);
  }
  
  public static void c(AccessibilityRecord paramAccessibilityRecord, View paramView, int paramInt) {
    b.a(paramAccessibilityRecord, paramView, paramInt);
  }
  
  static abstract class a {
    static int a(AccessibilityRecord param1AccessibilityRecord) {
      return param1AccessibilityRecord.getMaxScrollX();
    }
    
    static int b(AccessibilityRecord param1AccessibilityRecord) {
      return param1AccessibilityRecord.getMaxScrollY();
    }
    
    static void c(AccessibilityRecord param1AccessibilityRecord, int param1Int) {
      param1AccessibilityRecord.setMaxScrollX(param1Int);
    }
    
    static void d(AccessibilityRecord param1AccessibilityRecord, int param1Int) {
      param1AccessibilityRecord.setMaxScrollY(param1Int);
    }
  }
  
  static abstract class b {
    static void a(AccessibilityRecord param1AccessibilityRecord, View param1View, int param1Int) {
      param1AccessibilityRecord.setSource(param1View, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\accessibility\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */