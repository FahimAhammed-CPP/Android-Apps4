package androidx.core.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Build;
import android.view.PointerIcon;

public final class k0 {
  private final PointerIcon a;
  
  private k0(PointerIcon paramPointerIcon) {
    this.a = paramPointerIcon;
  }
  
  public static k0 b(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 24) ? new k0(a.b(paramContext, paramInt)) : new k0(null);
  }
  
  public Object a() {
    return this.a;
  }
  
  static abstract class a {
    static PointerIcon a(Bitmap param1Bitmap, float param1Float1, float param1Float2) {
      return PointerIcon.create(param1Bitmap, param1Float1, param1Float2);
    }
    
    static PointerIcon b(Context param1Context, int param1Int) {
      return PointerIcon.getSystemIcon(param1Context, param1Int);
    }
    
    static PointerIcon c(Resources param1Resources, int param1Int) {
      return PointerIcon.load(param1Resources, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */