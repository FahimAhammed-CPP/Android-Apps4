package androidx.core.view;

import android.content.ClipData;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ContentInfo;
import androidx.core.util.h;
import java.util.Objects;

public final class d {
  private final f a;
  
  d(f paramf) {
    this.a = paramf;
  }
  
  static String a(int paramInt) {
    return ((paramInt & 0x1) != 0) ? "FLAG_CONVERT_TO_PLAIN_TEXT" : String.valueOf(paramInt);
  }
  
  static String e(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? String.valueOf(paramInt) : "SOURCE_PROCESS_TEXT") : "SOURCE_AUTOFILL") : "SOURCE_DRAG_AND_DROP") : "SOURCE_INPUT_METHOD") : "SOURCE_CLIPBOARD") : "SOURCE_APP";
  }
  
  public static d g(ContentInfo paramContentInfo) {
    return new d(new e(paramContentInfo));
  }
  
  public ClipData b() {
    return this.a.a();
  }
  
  public int c() {
    return this.a.getFlags();
  }
  
  public int d() {
    return this.a.c();
  }
  
  public ContentInfo f() {
    ContentInfo contentInfo = this.a.b();
    Objects.requireNonNull(contentInfo);
    return c.a(contentInfo);
  }
  
  public String toString() {
    return this.a.toString();
  }
  
  public static final class a {
    private final d.c a;
    
    public a(ClipData param1ClipData, int param1Int) {
      if (Build.VERSION.SDK_INT >= 31) {
        this.a = new d.b(param1ClipData, param1Int);
        return;
      } 
      this.a = new d.d(param1ClipData, param1Int);
    }
    
    public d a() {
      return this.a.build();
    }
    
    public a b(Bundle param1Bundle) {
      this.a.setExtras(param1Bundle);
      return this;
    }
    
    public a c(int param1Int) {
      this.a.setFlags(param1Int);
      return this;
    }
    
    public a d(Uri param1Uri) {
      this.a.a(param1Uri);
      return this;
    }
  }
  
  private static final class b implements c {
    private final ContentInfo.Builder a;
    
    b(ClipData param1ClipData, int param1Int) {
      this.a = g.a(param1ClipData, param1Int);
    }
    
    public void a(Uri param1Uri) {
      i.a(this.a, param1Uri);
    }
    
    public d build() {
      return new d(new d.e(f.a(this.a)));
    }
    
    public void setExtras(Bundle param1Bundle) {
      h.a(this.a, param1Bundle);
    }
    
    public void setFlags(int param1Int) {
      e.a(this.a, param1Int);
    }
  }
  
  private static interface c {
    void a(Uri param1Uri);
    
    d build();
    
    void setExtras(Bundle param1Bundle);
    
    void setFlags(int param1Int);
  }
  
  private static final class d implements c {
    ClipData a;
    
    int b;
    
    int c;
    
    Uri d;
    
    Bundle e;
    
    d(ClipData param1ClipData, int param1Int) {
      this.a = param1ClipData;
      this.b = param1Int;
    }
    
    public void a(Uri param1Uri) {
      this.d = param1Uri;
    }
    
    public d build() {
      return new d(new d.g(this));
    }
    
    public void setExtras(Bundle param1Bundle) {
      this.e = param1Bundle;
    }
    
    public void setFlags(int param1Int) {
      this.c = param1Int;
    }
  }
  
  private static final class e implements f {
    private final ContentInfo a;
    
    e(ContentInfo param1ContentInfo) {
      this.a = c.a(h.g(param1ContentInfo));
    }
    
    public ClipData a() {
      return j.a(this.a);
    }
    
    public ContentInfo b() {
      return this.a;
    }
    
    public int c() {
      return l.a(this.a);
    }
    
    public int getFlags() {
      return k.a(this.a);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ContentInfoCompat{");
      stringBuilder.append(this.a);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
  }
  
  private static interface f {
    ClipData a();
    
    ContentInfo b();
    
    int c();
    
    int getFlags();
  }
  
  private static final class g implements f {
    private final ClipData a;
    
    private final int b;
    
    private final int c;
    
    private final Uri d;
    
    private final Bundle e;
    
    g(d.d param1d) {
      this.a = (ClipData)h.g(param1d.a);
      this.b = h.c(param1d.b, 0, 5, "source");
      this.c = h.f(param1d.c, 1);
      this.d = param1d.d;
      this.e = param1d.e;
    }
    
    public ClipData a() {
      return this.a;
    }
    
    public ContentInfo b() {
      return null;
    }
    
    public int c() {
      return this.b;
    }
    
    public int getFlags() {
      return this.c;
    }
    
    public String toString() {
      String str1;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ContentInfoCompat{clip=");
      stringBuilder.append(this.a.getDescription());
      stringBuilder.append(", source=");
      stringBuilder.append(d.e(this.b));
      stringBuilder.append(", flags=");
      stringBuilder.append(d.a(this.c));
      Uri uri = this.d;
      String str2 = "";
      if (uri == null) {
        str1 = "";
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(", hasLinkUri(");
        stringBuilder1.append(this.d.toString().length());
        stringBuilder1.append(")");
        str1 = stringBuilder1.toString();
      } 
      stringBuilder.append(str1);
      if (this.e == null) {
        str1 = str2;
      } else {
        str1 = ", hasExtras";
      } 
      stringBuilder.append(str1);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */