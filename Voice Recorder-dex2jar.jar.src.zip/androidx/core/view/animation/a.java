package androidx.core.view.animation;

import android.graphics.Path;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;

public abstract class a {
  public static Interpolator a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return (Interpolator)a.b(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public static Interpolator b(Path paramPath) {
    return (Interpolator)a.c(paramPath);
  }
  
  static abstract class a {
    static PathInterpolator a(float param1Float1, float param1Float2) {
      return new PathInterpolator(param1Float1, param1Float2);
    }
    
    static PathInterpolator b(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      return new PathInterpolator(param1Float1, param1Float2, param1Float3, param1Float4);
    }
    
    static PathInterpolator c(Path param1Path) {
      return new PathInterpolator(param1Path);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\view\animation\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */