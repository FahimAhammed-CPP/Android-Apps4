package androidx.core.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import x.a;

public abstract class c {
  private static final ThreadLocal a = new ThreadLocal();
  
  public static ColorStateList a(Resources paramResources, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme) {
    int i;
    AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2)
      return b(paramResources, paramXmlPullParser, attributeSet, paramTheme); 
    throw new XmlPullParserException("No start tag found");
  }
  
  public static ColorStateList b(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    String str = paramXmlPullParser.getName();
    if (str.equals("selector"))
      return e(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid color state list tag ");
    stringBuilder.append(str);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  private static TypedValue c() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
  
  public static ColorStateList d(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    try {
      return a(paramResources, (XmlPullParser)paramResources.getXml(paramInt), paramTheme);
    } catch (Exception exception) {
      Log.e("CSLCompat", "Failed to inflate ColorStateList.", exception);
      return null;
    } 
  }
  
  private static ColorStateList e(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface getDepth : ()I
    //   6: iconst_1
    //   7: iadd
    //   8: istore #12
    //   10: bipush #20
    //   12: anewarray [I
    //   15: astore #15
    //   17: bipush #20
    //   19: newarray int
    //   21: astore #16
    //   23: iconst_0
    //   24: istore #7
    //   26: aload_0
    //   27: astore #19
    //   29: aload_1
    //   30: invokeinterface next : ()I
    //   35: istore #8
    //   37: iload #8
    //   39: iconst_1
    //   40: if_icmpeq -> 529
    //   43: aload_1
    //   44: invokeinterface getDepth : ()I
    //   49: istore #9
    //   51: iload #9
    //   53: iload #12
    //   55: if_icmpge -> 64
    //   58: iload #8
    //   60: iconst_3
    //   61: if_icmpeq -> 529
    //   64: aload #16
    //   66: astore #18
    //   68: aload #15
    //   70: astore #17
    //   72: iload #7
    //   74: istore #6
    //   76: iload #8
    //   78: iconst_2
    //   79: if_icmpne -> 514
    //   82: aload #16
    //   84: astore #18
    //   86: aload #15
    //   88: astore #17
    //   90: iload #7
    //   92: istore #6
    //   94: iload #9
    //   96: iload #12
    //   98: if_icmpgt -> 514
    //   101: aload_1
    //   102: invokeinterface getName : ()Ljava/lang/String;
    //   107: ldc 'item'
    //   109: invokevirtual equals : (Ljava/lang/Object;)Z
    //   112: ifne -> 130
    //   115: aload #16
    //   117: astore #18
    //   119: aload #15
    //   121: astore #17
    //   123: iload #7
    //   125: istore #6
    //   127: goto -> 514
    //   130: aload #19
    //   132: aload_3
    //   133: aload_2
    //   134: getstatic v/i.ColorStateListItem : [I
    //   137: invokestatic h : (Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   140: astore #17
    //   142: getstatic v/i.ColorStateListItem_android_color : I
    //   145: istore #6
    //   147: aload #17
    //   149: iload #6
    //   151: iconst_m1
    //   152: invokevirtual getResourceId : (II)I
    //   155: istore #8
    //   157: iload #8
    //   159: iconst_m1
    //   160: if_icmpeq -> 209
    //   163: aload #19
    //   165: iload #8
    //   167: invokestatic f : (Landroid/content/res/Resources;I)Z
    //   170: ifne -> 209
    //   173: aload #19
    //   175: aload #19
    //   177: iload #8
    //   179: invokevirtual getXml : (I)Landroid/content/res/XmlResourceParser;
    //   182: aload_3
    //   183: invokestatic a : (Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    //   186: invokevirtual getDefaultColor : ()I
    //   189: istore #6
    //   191: goto -> 220
    //   194: aload #17
    //   196: getstatic v/i.ColorStateListItem_android_color : I
    //   199: ldc -65281
    //   201: invokevirtual getColor : (II)I
    //   204: istore #6
    //   206: goto -> 220
    //   209: aload #17
    //   211: iload #6
    //   213: ldc -65281
    //   215: invokevirtual getColor : (II)I
    //   218: istore #6
    //   220: getstatic v/i.ColorStateListItem_android_alpha : I
    //   223: istore #8
    //   225: aload #17
    //   227: iload #8
    //   229: invokevirtual hasValue : (I)Z
    //   232: istore #14
    //   234: fconst_1
    //   235: fstore #4
    //   237: iload #14
    //   239: ifeq -> 255
    //   242: aload #17
    //   244: iload #8
    //   246: fconst_1
    //   247: invokevirtual getFloat : (IF)F
    //   250: fstore #4
    //   252: goto -> 280
    //   255: getstatic v/i.ColorStateListItem_alpha : I
    //   258: istore #8
    //   260: aload #17
    //   262: iload #8
    //   264: invokevirtual hasValue : (I)Z
    //   267: ifeq -> 280
    //   270: aload #17
    //   272: iload #8
    //   274: fconst_1
    //   275: invokevirtual getFloat : (IF)F
    //   278: fstore #4
    //   280: getstatic android/os/Build$VERSION.SDK_INT : I
    //   283: bipush #31
    //   285: if_icmplt -> 317
    //   288: getstatic v/i.ColorStateListItem_android_lStar : I
    //   291: istore #8
    //   293: aload #17
    //   295: iload #8
    //   297: invokevirtual hasValue : (I)Z
    //   300: ifeq -> 317
    //   303: aload #17
    //   305: iload #8
    //   307: ldc -1.0
    //   309: invokevirtual getFloat : (IF)F
    //   312: fstore #5
    //   314: goto -> 329
    //   317: aload #17
    //   319: getstatic v/i.ColorStateListItem_lStar : I
    //   322: ldc -1.0
    //   324: invokevirtual getFloat : (IF)F
    //   327: fstore #5
    //   329: aload #17
    //   331: invokevirtual recycle : ()V
    //   334: aload_2
    //   335: invokeinterface getAttributeCount : ()I
    //   340: istore #13
    //   342: iload #13
    //   344: newarray int
    //   346: astore #17
    //   348: iconst_0
    //   349: istore #8
    //   351: iconst_0
    //   352: istore #9
    //   354: iload #8
    //   356: iload #13
    //   358: if_icmpge -> 467
    //   361: aload_2
    //   362: iload #8
    //   364: invokeinterface getAttributeNameResource : (I)I
    //   369: istore #11
    //   371: iload #9
    //   373: istore #10
    //   375: iload #11
    //   377: ldc 16843173
    //   379: if_icmpeq -> 454
    //   382: iload #9
    //   384: istore #10
    //   386: iload #11
    //   388: ldc 16843551
    //   390: if_icmpeq -> 454
    //   393: iload #9
    //   395: istore #10
    //   397: iload #11
    //   399: getstatic v/a.alpha : I
    //   402: if_icmpeq -> 454
    //   405: iload #9
    //   407: istore #10
    //   409: iload #11
    //   411: getstatic v/a.lStar : I
    //   414: if_icmpeq -> 454
    //   417: aload_2
    //   418: iload #8
    //   420: iconst_0
    //   421: invokeinterface getAttributeBooleanValue : (IZ)Z
    //   426: ifeq -> 436
    //   429: iload #11
    //   431: istore #10
    //   433: goto -> 441
    //   436: iload #11
    //   438: ineg
    //   439: istore #10
    //   441: aload #17
    //   443: iload #9
    //   445: iload #10
    //   447: iastore
    //   448: iload #9
    //   450: iconst_1
    //   451: iadd
    //   452: istore #10
    //   454: iload #8
    //   456: iconst_1
    //   457: iadd
    //   458: istore #8
    //   460: iload #10
    //   462: istore #9
    //   464: goto -> 354
    //   467: aload #17
    //   469: iload #9
    //   471: invokestatic trimStateSet : ([II)[I
    //   474: astore #17
    //   476: aload #16
    //   478: iload #7
    //   480: iload #6
    //   482: fload #4
    //   484: fload #5
    //   486: invokestatic g : (IFF)I
    //   489: invokestatic a : ([III)[I
    //   492: astore #18
    //   494: aload #15
    //   496: iload #7
    //   498: aload #17
    //   500: invokestatic b : ([Ljava/lang/Object;ILjava/lang/Object;)[Ljava/lang/Object;
    //   503: checkcast [[I
    //   506: astore #17
    //   508: iload #7
    //   510: iconst_1
    //   511: iadd
    //   512: istore #6
    //   514: aload #18
    //   516: astore #16
    //   518: aload #17
    //   520: astore #15
    //   522: iload #6
    //   524: istore #7
    //   526: goto -> 26
    //   529: iload #7
    //   531: newarray int
    //   533: astore_0
    //   534: iload #7
    //   536: anewarray [I
    //   539: astore_1
    //   540: aload #16
    //   542: iconst_0
    //   543: aload_0
    //   544: iconst_0
    //   545: iload #7
    //   547: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   550: aload #15
    //   552: iconst_0
    //   553: aload_1
    //   554: iconst_0
    //   555: iload #7
    //   557: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   560: new android/content/res/ColorStateList
    //   563: dup
    //   564: aload_1
    //   565: aload_0
    //   566: invokespecial <init> : ([[I[I)V
    //   569: areturn
    //   570: astore #18
    //   572: goto -> 194
    // Exception table:
    //   from	to	target	type
    //   173	191	570	java/lang/Exception
  }
  
  private static boolean f(Resources paramResources, int paramInt) {
    TypedValue typedValue = c();
    paramResources.getValue(paramInt, typedValue, true);
    paramInt = typedValue.type;
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  private static int g(int paramInt, float paramFloat1, float paramFloat2) {
    boolean bool;
    if (paramFloat2 >= 0.0F && paramFloat2 <= 100.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (paramFloat1 == 1.0F && !bool)
      return paramInt; 
    int j = a.b((int)(Color.alpha(paramInt) * paramFloat1 + 0.5F), 0, 255);
    int i = paramInt;
    if (bool) {
      a a = a.c(paramInt);
      i = a.m(a.j(), a.i(), paramFloat2);
    } 
    return i & 0xFFFFFF | j << 24;
  }
  
  private static TypedArray h(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfint) {
    return (paramTheme == null) ? paramResources.obtainAttributes(paramAttributeSet, paramArrayOfint) : paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, 0, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\content\res\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */