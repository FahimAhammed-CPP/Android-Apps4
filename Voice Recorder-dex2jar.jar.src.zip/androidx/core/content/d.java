package androidx.core.content;

import androidx.core.util.a;

public interface d {
  void addOnTrimMemoryListener(a parama);
  
  void removeOnTrimMemoryListener(a parama);
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\content\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */