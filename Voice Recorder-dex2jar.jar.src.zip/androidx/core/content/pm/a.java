package androidx.core.content.pm;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;

public abstract class a {
  public static long a(PackageInfo paramPackageInfo) {
    return (Build.VERSION.SDK_INT >= 28) ? a.b(paramPackageInfo) : paramPackageInfo.versionCode;
  }
  
  private static abstract class a {
    static Signature[] a(SigningInfo param1SigningInfo) {
      return param1SigningInfo.getApkContentsSigners();
    }
    
    static long b(PackageInfo param1PackageInfo) {
      return param1PackageInfo.getLongVersionCode();
    }
    
    static Signature[] c(SigningInfo param1SigningInfo) {
      return param1SigningInfo.getSigningCertificateHistory();
    }
    
    static boolean d(SigningInfo param1SigningInfo) {
      return param1SigningInfo.hasMultipleSigners();
    }
    
    static boolean e(PackageManager param1PackageManager, String param1String, byte[] param1ArrayOfbyte, int param1Int) {
      return param1PackageManager.hasSigningCertificate(param1String, param1ArrayOfbyte, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\content\pm\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */