package androidx.core.content;

import androidx.core.util.a;

public interface c {
  void addOnConfigurationChangedListener(a parama);
  
  void removeOnConfigurationChangedListener(a parama);
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\content\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */