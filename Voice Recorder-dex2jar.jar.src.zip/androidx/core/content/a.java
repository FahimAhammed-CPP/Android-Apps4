package androidx.core.content;

import android.accounts.AccountManager;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AppOpsManager;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.app.SearchManager;
import android.app.UiModeManager;
import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.app.job.JobScheduler;
import android.app.usage.UsageStatsManager;
import android.appwidget.AppWidgetManager;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.RestrictionsManager;
import android.content.pm.LauncherApps;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.hardware.ConsumerIrManager;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.hardware.display.DisplayManager;
import android.hardware.input.InputManager;
import android.hardware.usb.UsbManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaRouter;
import android.media.projection.MediaProjectionManager;
import android.media.session.MediaSessionManager;
import android.media.tv.TvInputManager;
import android.net.ConnectivityManager;
import android.net.nsd.NsdManager;
import android.net.wifi.WifiManager;
import android.net.wifi.p2p.WifiP2pManager;
import android.nfc.NfcManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.DropBoxManager;
import android.os.Handler;
import android.os.PowerManager;
import android.os.Process;
import android.os.UserManager;
import android.os.Vibrator;
import android.os.storage.StorageManager;
import android.print.PrintManager;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.CaptioningManager;
import android.view.inputmethod.InputMethodManager;
import android.view.textservice.TextServicesManager;
import androidx.core.app.m0;
import androidx.core.content.res.h;
import java.io.File;
import java.util.HashMap;
import java.util.concurrent.Executor;

public abstract class a {
  private static final String DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION_SUFFIX = ".DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION";
  
  public static final int RECEIVER_EXPORTED = 2;
  
  public static final int RECEIVER_NOT_EXPORTED = 4;
  
  public static final int RECEIVER_VISIBLE_TO_INSTANT_APPS = 1;
  
  private static final String TAG = "ContextCompat";
  
  private static final Object sLock = new Object();
  
  private static final Object sSync = new Object();
  
  private static TypedValue sTempValue;
  
  public static int checkSelfPermission(Context paramContext, String paramString) {
    androidx.core.util.c.d(paramString, "permission must be non-null");
    return (!androidx.core.os.a.c() && TextUtils.equals("android.permission.POST_NOTIFICATIONS", paramString)) ? (m0.b(paramContext).a() ? 0 : -1) : paramContext.checkPermission(paramString, Process.myPid(), Process.myUid());
  }
  
  public static Context createDeviceProtectedStorageContext(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? e.a(paramContext) : null;
  }
  
  public static String getAttributionTag(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 30) ? h.a(paramContext) : null;
  }
  
  public static File getCodeCacheDir(Context paramContext) {
    return c.a(paramContext);
  }
  
  public static int getColor(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 23) ? d.a(paramContext, paramInt) : paramContext.getResources().getColor(paramInt);
  }
  
  public static ColorStateList getColorStateList(Context paramContext, int paramInt) {
    return h.d(paramContext.getResources(), paramInt, paramContext.getTheme());
  }
  
  public static File getDataDir(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 24)
      return e.b(paramContext); 
    String str = (paramContext.getApplicationInfo()).dataDir;
    return (str != null) ? new File(str) : null;
  }
  
  public static Drawable getDrawable(Context paramContext, int paramInt) {
    return c.b(paramContext, paramInt);
  }
  
  public static File[] getExternalCacheDirs(Context paramContext) {
    return b.a(paramContext);
  }
  
  public static File[] getExternalFilesDirs(Context paramContext, String paramString) {
    return b.b(paramContext, paramString);
  }
  
  public static Executor getMainExecutor(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 28) ? g.a(paramContext) : androidx.core.os.h.a(new Handler(paramContext.getMainLooper()));
  }
  
  public static File getNoBackupFilesDir(Context paramContext) {
    return c.c(paramContext);
  }
  
  public static File[] getObbDirs(Context paramContext) {
    return b.c(paramContext);
  }
  
  public static <T> T getSystemService(Context paramContext, Class<T> paramClass) {
    if (Build.VERSION.SDK_INT >= 23)
      return d.b(paramContext, paramClass); 
    String str = getSystemServiceName(paramContext, paramClass);
    return (T)((str != null) ? paramContext.getSystemService(str) : null);
  }
  
  public static String getSystemServiceName(Context paramContext, Class<?> paramClass) {
    return (Build.VERSION.SDK_INT >= 23) ? d.c(paramContext, paramClass) : (String)j.a.get(paramClass);
  }
  
  public static boolean isDeviceProtectedStorage(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? e.c(paramContext) : false;
  }
  
  static String obtainAndCheckReceiverPermission(Context paramContext) {
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramContext.getPackageName());
    stringBuilder2.append(".DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION");
    String str = stringBuilder2.toString();
    if (e.b(paramContext, str) == 0)
      return str; 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Permission ");
    stringBuilder1.append(str);
    stringBuilder1.append(" is required by your application to receive broadcasts, please add it to your manifest");
    throw new RuntimeException(stringBuilder1.toString());
  }
  
  public static Intent registerReceiver(Context paramContext, BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter, int paramInt) {
    return registerReceiver(paramContext, paramBroadcastReceiver, paramIntentFilter, null, null, paramInt);
  }
  
  public static Intent registerReceiver(Context paramContext, BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter, String paramString, Handler paramHandler, int paramInt) {
    int i = paramInt & 0x1;
    if (i == 0 || (paramInt & 0x4) == 0) {
      int j = paramInt;
      if (i != 0)
        j = paramInt | 0x2; 
      paramInt = j & 0x2;
      if (paramInt != 0 || (j & 0x4) != 0) {
        if (paramInt == 0 || (j & 0x4) == 0)
          return androidx.core.os.a.c() ? i.a(paramContext, paramBroadcastReceiver, paramIntentFilter, paramString, paramHandler, j) : ((Build.VERSION.SDK_INT >= 26) ? f.a(paramContext, paramBroadcastReceiver, paramIntentFilter, paramString, paramHandler, j) : (((j & 0x4) != 0 && paramString == null) ? paramContext.registerReceiver(paramBroadcastReceiver, paramIntentFilter, obtainAndCheckReceiverPermission(paramContext), paramHandler) : paramContext.registerReceiver(paramBroadcastReceiver, paramIntentFilter, paramString, paramHandler))); 
        throw new IllegalArgumentException("Cannot specify both RECEIVER_EXPORTED and RECEIVER_NOT_EXPORTED");
      } 
      throw new IllegalArgumentException("One of either RECEIVER_EXPORTED or RECEIVER_NOT_EXPORTED is required");
    } 
    throw new IllegalArgumentException("Cannot specify both RECEIVER_VISIBLE_TO_INSTANT_APPS and RECEIVER_NOT_EXPORTED");
  }
  
  public static boolean startActivities(Context paramContext, Intent[] paramArrayOfIntent) {
    return startActivities(paramContext, paramArrayOfIntent, null);
  }
  
  public static boolean startActivities(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle) {
    a.a(paramContext, paramArrayOfIntent, paramBundle);
    return true;
  }
  
  public static void startActivity(Context paramContext, Intent paramIntent, Bundle paramBundle) {
    a.b(paramContext, paramIntent, paramBundle);
  }
  
  public static void startForegroundService(Context paramContext, Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 26) {
      f.b(paramContext, paramIntent);
      return;
    } 
    paramContext.startService(paramIntent);
  }
  
  static abstract class a {
    static void a(Context param1Context, Intent[] param1ArrayOfIntent, Bundle param1Bundle) {
      param1Context.startActivities(param1ArrayOfIntent, param1Bundle);
    }
    
    static void b(Context param1Context, Intent param1Intent, Bundle param1Bundle) {
      param1Context.startActivity(param1Intent, param1Bundle);
    }
  }
  
  static abstract class b {
    static File[] a(Context param1Context) {
      return param1Context.getExternalCacheDirs();
    }
    
    static File[] b(Context param1Context, String param1String) {
      return param1Context.getExternalFilesDirs(param1String);
    }
    
    static File[] c(Context param1Context) {
      return param1Context.getObbDirs();
    }
  }
  
  static abstract class c {
    static File a(Context param1Context) {
      return param1Context.getCodeCacheDir();
    }
    
    static Drawable b(Context param1Context, int param1Int) {
      return param1Context.getDrawable(param1Int);
    }
    
    static File c(Context param1Context) {
      return param1Context.getNoBackupFilesDir();
    }
  }
  
  static abstract class d {
    static int a(Context param1Context, int param1Int) {
      return param1Context.getColor(param1Int);
    }
    
    static <T> T b(Context param1Context, Class<T> param1Class) {
      return (T)param1Context.getSystemService(param1Class);
    }
    
    static String c(Context param1Context, Class<?> param1Class) {
      return param1Context.getSystemServiceName(param1Class);
    }
  }
  
  static abstract class e {
    static Context a(Context param1Context) {
      return param1Context.createDeviceProtectedStorageContext();
    }
    
    static File b(Context param1Context) {
      return param1Context.getDataDir();
    }
    
    static boolean c(Context param1Context) {
      return param1Context.isDeviceProtectedStorage();
    }
  }
  
  static abstract class f {
    static Intent a(Context param1Context, BroadcastReceiver param1BroadcastReceiver, IntentFilter param1IntentFilter, String param1String, Handler param1Handler, int param1Int) {
      return ((param1Int & 0x4) != 0 && param1String == null) ? param1Context.registerReceiver(param1BroadcastReceiver, param1IntentFilter, a.obtainAndCheckReceiverPermission(param1Context), param1Handler) : param1Context.registerReceiver(param1BroadcastReceiver, param1IntentFilter, param1String, param1Handler, param1Int & 0x1);
    }
    
    static ComponentName b(Context param1Context, Intent param1Intent) {
      return param1Context.startForegroundService(param1Intent);
    }
  }
  
  static abstract class g {
    static Executor a(Context param1Context) {
      return param1Context.getMainExecutor();
    }
  }
  
  static abstract class h {
    static String a(Context param1Context) {
      return param1Context.getAttributionTag();
    }
  }
  
  static abstract class i {
    static Intent a(Context param1Context, BroadcastReceiver param1BroadcastReceiver, IntentFilter param1IntentFilter, String param1String, Handler param1Handler, int param1Int) {
      return param1Context.registerReceiver(param1BroadcastReceiver, param1IntentFilter, param1String, param1Handler, param1Int);
    }
  }
  
  private static final abstract class j {
    static final HashMap a;
    
    static {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      a = hashMap;
      if (Build.VERSION.SDK_INT >= 22) {
        hashMap.put(b.a(), "telephony_subscription_service");
        hashMap.put(UsageStatsManager.class, "usagestats");
      } 
      hashMap.put(AppWidgetManager.class, "appwidget");
      hashMap.put(BatteryManager.class, "batterymanager");
      hashMap.put(CameraManager.class, "camera");
      hashMap.put(JobScheduler.class, "jobscheduler");
      hashMap.put(LauncherApps.class, "launcherapps");
      hashMap.put(MediaProjectionManager.class, "media_projection");
      hashMap.put(MediaSessionManager.class, "media_session");
      hashMap.put(RestrictionsManager.class, "restrictions");
      hashMap.put(TelecomManager.class, "telecom");
      hashMap.put(TvInputManager.class, "tv_input");
      hashMap.put(AppOpsManager.class, "appops");
      hashMap.put(CaptioningManager.class, "captioning");
      hashMap.put(ConsumerIrManager.class, "consumer_ir");
      hashMap.put(PrintManager.class, "print");
      hashMap.put(BluetoothManager.class, "bluetooth");
      hashMap.put(DisplayManager.class, "display");
      hashMap.put(UserManager.class, "user");
      hashMap.put(InputManager.class, "input");
      hashMap.put(MediaRouter.class, "media_router");
      hashMap.put(NsdManager.class, "servicediscovery");
      hashMap.put(AccessibilityManager.class, "accessibility");
      hashMap.put(AccountManager.class, "account");
      hashMap.put(ActivityManager.class, "activity");
      hashMap.put(AlarmManager.class, "alarm");
      hashMap.put(AudioManager.class, "audio");
      hashMap.put(ClipboardManager.class, "clipboard");
      hashMap.put(ConnectivityManager.class, "connectivity");
      hashMap.put(DevicePolicyManager.class, "device_policy");
      hashMap.put(DownloadManager.class, "download");
      hashMap.put(DropBoxManager.class, "dropbox");
      hashMap.put(InputMethodManager.class, "input_method");
      hashMap.put(KeyguardManager.class, "keyguard");
      hashMap.put(LayoutInflater.class, "layout_inflater");
      hashMap.put(LocationManager.class, "location");
      hashMap.put(NfcManager.class, "nfc");
      hashMap.put(NotificationManager.class, "notification");
      hashMap.put(PowerManager.class, "power");
      hashMap.put(SearchManager.class, "search");
      hashMap.put(SensorManager.class, "sensor");
      hashMap.put(StorageManager.class, "storage");
      hashMap.put(TelephonyManager.class, "phone");
      hashMap.put(TextServicesManager.class, "textservices");
      hashMap.put(UiModeManager.class, "uimode");
      hashMap.put(UsbManager.class, "usb");
      hashMap.put(Vibrator.class, "vibrator");
      hashMap.put(WallpaperManager.class, "wallpaper");
      hashMap.put(WifiP2pManager.class, "wifip2p");
      hashMap.put(WifiManager.class, "wifi");
      hashMap.put(WindowManager.class, "window");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\content\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */