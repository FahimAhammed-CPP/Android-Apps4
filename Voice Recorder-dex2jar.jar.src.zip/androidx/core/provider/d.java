package androidx.core.provider;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.CancellationSignal;
import androidx.core.content.res.e;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

abstract class d {
  private static final Comparator a = new c();
  
  private static List b(Signature[] paramArrayOfSignature) {
    ArrayList<byte[]> arrayList = new ArrayList();
    int j = paramArrayOfSignature.length;
    for (int i = 0; i < j; i++)
      arrayList.add(paramArrayOfSignature[i].toByteArray()); 
    return arrayList;
  }
  
  private static boolean c(List<byte[]> paramList1, List<byte[]> paramList2) {
    if (paramList1.size() != paramList2.size())
      return false; 
    for (int i = 0; i < paramList1.size(); i++) {
      if (!Arrays.equals(paramList1.get(i), paramList2.get(i)))
        return false; 
    } 
    return true;
  }
  
  private static List d(e parame, Resources paramResources) {
    return (parame.b() != null) ? parame.b() : e.c(paramResources, parame.c());
  }
  
  static g.a e(Context paramContext, e parame, CancellationSignal paramCancellationSignal) {
    ProviderInfo providerInfo = f(paramContext.getPackageManager(), parame, paramContext.getResources());
    return (providerInfo == null) ? g.a.a(1, null) : g.a.a(0, h(paramContext, parame, providerInfo.authority, paramCancellationSignal));
  }
  
  static ProviderInfo f(PackageManager paramPackageManager, e parame, Resources paramResources) {
    String str = parame.e();
    int i = 0;
    ProviderInfo providerInfo = paramPackageManager.resolveContentProvider(str, 0);
    if (providerInfo != null) {
      List<Collection> list;
      if (providerInfo.packageName.equals(parame.f())) {
        List<?> list1 = b((paramPackageManager.getPackageInfo(providerInfo.packageName, 64)).signatures);
        Collections.sort(list1, a);
        list = d(parame, paramResources);
        while (i < list.size()) {
          ArrayList<?> arrayList = new ArrayList(list.get(i));
          Collections.sort(arrayList, a);
          if (c(list1, arrayList))
            return providerInfo; 
          i++;
        } 
        return null;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Found content provider ");
      stringBuilder1.append(str);
      stringBuilder1.append(", but package was not ");
      stringBuilder1.append(list.f());
      throw new PackageManager.NameNotFoundException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No package found for authority: ");
    stringBuilder.append(str);
    throw new PackageManager.NameNotFoundException(stringBuilder.toString());
  }
  
  static g.b[] h(Context paramContext, e parame, String paramString, CancellationSignal paramCancellationSignal) {
    ArrayList<g.b> arrayList = new ArrayList();
    Uri uri1 = (new Uri.Builder()).scheme("content").authority(paramString).build();
    Uri uri2 = (new Uri.Builder()).scheme("content").authority(paramString).appendPath("file").build();
    paramString = null;
    try {
      String str1;
      ContentResolver contentResolver = paramContext.getContentResolver();
      String str2 = parame.g();
      Cursor cursor2 = a.a(contentResolver, uri1, new String[] { "_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code" }, "query = ?", new String[] { str2 }, null, paramCancellationSignal);
      ArrayList<g.b> arrayList1 = arrayList;
      return (g.b[])cursor1.toArray((Object[])new g.b[0]);
    } finally {
      String str = paramString;
      if (str != null)
        str.close(); 
    } 
  }
  
  static abstract class a {
    static Cursor a(ContentResolver param1ContentResolver, Uri param1Uri, String[] param1ArrayOfString1, String param1String1, String[] param1ArrayOfString2, String param1String2, Object param1Object) {
      return param1ContentResolver.query(param1Uri, param1ArrayOfString1, param1String1, param1ArrayOfString2, param1String2, (CancellationSignal)param1Object);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\provider\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */