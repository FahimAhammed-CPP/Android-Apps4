package androidx.core.provider;

import android.graphics.Typeface;
import android.os.Handler;

class a {
  private final g.c a;
  
  private final Handler b;
  
  a(g.c paramc, Handler paramHandler) {
    this.a = paramc;
    this.b = paramHandler;
  }
  
  private void a(int paramInt) {
    g.c c1 = this.a;
    this.b.post(new b(this, c1, paramInt));
  }
  
  private void c(Typeface paramTypeface) {
    g.c c1 = this.a;
    this.b.post(new a(this, c1, paramTypeface));
  }
  
  void b(f.e parame) {
    if (parame.a()) {
      c(parame.a);
      return;
    } 
    a(parame.b);
  }
  
  class a implements Runnable {
    a(a this$0, g.c param1c, Typeface param1Typeface) {}
    
    public void run() {
      this.a.b(this.b);
    }
  }
  
  class b implements Runnable {
    b(a this$0, g.c param1c, int param1Int) {}
    
    public void run() {
      this.a.a(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\provider\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */