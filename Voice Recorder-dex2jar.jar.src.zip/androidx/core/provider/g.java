package androidx.core.provider;

import android.content.Context;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Handler;
import androidx.core.graphics.e;
import androidx.core.util.h;

public abstract class g {
  public static Typeface a(Context paramContext, CancellationSignal paramCancellationSignal, b[] paramArrayOfb) {
    return e.b(paramContext, paramCancellationSignal, paramArrayOfb, 0);
  }
  
  public static a b(Context paramContext, CancellationSignal paramCancellationSignal, e parame) {
    return d.e(paramContext, parame, paramCancellationSignal);
  }
  
  public static Typeface c(Context paramContext, e parame, int paramInt1, boolean paramBoolean, int paramInt2, Handler paramHandler, c paramc) {
    a a = new a(paramc, paramHandler);
    return paramBoolean ? f.e(paramContext, parame, a, paramInt1, paramInt2) : f.d(paramContext, parame, paramInt1, null, a);
  }
  
  public static class a {
    private final int a;
    
    private final g.b[] b;
    
    public a(int param1Int, g.b[] param1ArrayOfb) {
      this.a = param1Int;
      this.b = param1ArrayOfb;
    }
    
    static a a(int param1Int, g.b[] param1ArrayOfb) {
      return new a(param1Int, param1ArrayOfb);
    }
    
    public g.b[] b() {
      return this.b;
    }
    
    public int c() {
      return this.a;
    }
  }
  
  public static class b {
    private final Uri a;
    
    private final int b;
    
    private final int c;
    
    private final boolean d;
    
    private final int e;
    
    public b(Uri param1Uri, int param1Int1, int param1Int2, boolean param1Boolean, int param1Int3) {
      this.a = (Uri)h.g(param1Uri);
      this.b = param1Int1;
      this.c = param1Int2;
      this.d = param1Boolean;
      this.e = param1Int3;
    }
    
    static b a(Uri param1Uri, int param1Int1, int param1Int2, boolean param1Boolean, int param1Int3) {
      return new b(param1Uri, param1Int1, param1Int2, param1Boolean, param1Int3);
    }
    
    public int b() {
      return this.e;
    }
    
    public int c() {
      return this.b;
    }
    
    public Uri d() {
      return this.a;
    }
    
    public int e() {
      return this.c;
    }
    
    public boolean f() {
      return this.d;
    }
  }
  
  public static abstract class c {
    public abstract void a(int param1Int);
    
    public abstract void b(Typeface param1Typeface);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\provider\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */