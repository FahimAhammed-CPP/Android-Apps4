package androidx.core.provider;

import android.os.Handler;
import android.os.Looper;

abstract class b {
  static Handler a() {
    return (Looper.myLooper() == null) ? new Handler(Looper.getMainLooper()) : new Handler();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\provider\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */