package androidx.core.provider;

import java.util.Comparator;



/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\androidx\core\provider\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */