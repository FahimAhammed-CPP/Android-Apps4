package a0;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityRecord;
import androidx.collection.h;
import androidx.core.view.a;
import androidx.core.view.accessibility.h0;
import androidx.core.view.accessibility.i0;
import androidx.core.view.accessibility.j0;
import androidx.core.view.n0;
import java.util.ArrayList;
import java.util.List;

public abstract class a extends a {
  private static final Rect n = new Rect(2147483647, 2147483647, -2147483648, -2147483648);
  
  private static final b.a o = new a();
  
  private static final b.b p = new b();
  
  private final Rect d = new Rect();
  
  private final Rect e = new Rect();
  
  private final Rect f = new Rect();
  
  private final int[] g = new int[2];
  
  private final AccessibilityManager h;
  
  private final View i;
  
  private c j;
  
  int k = Integer.MIN_VALUE;
  
  int l = Integer.MIN_VALUE;
  
  private int m = Integer.MIN_VALUE;
  
  public a(View paramView) {
    if (paramView != null) {
      this.i = paramView;
      this.h = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
      paramView.setFocusable(true);
      if (n0.C(paramView) == 0)
        n0.F0(paramView, 1); 
      return;
    } 
    throw new IllegalArgumentException("View may not be null");
  }
  
  private static Rect D(View paramView, int paramInt, Rect paramRect) {
    int i = paramView.getWidth();
    int j = paramView.getHeight();
    if (paramInt != 17) {
      if (paramInt != 33) {
        if (paramInt != 66) {
          if (paramInt == 130) {
            paramRect.set(0, -1, i, -1);
            return paramRect;
          } 
          throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
        } 
        paramRect.set(-1, 0, -1, j);
        return paramRect;
      } 
      paramRect.set(0, j, i, j);
      return paramRect;
    } 
    paramRect.set(i, 0, i, j);
    return paramRect;
  }
  
  private boolean G(Rect paramRect) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramRect != null) {
      if (paramRect.isEmpty())
        return false; 
      if (this.i.getWindowVisibility() != 0)
        return false; 
      ViewParent viewParent = this.i.getParent();
      while (viewParent instanceof View) {
        View view = (View)viewParent;
        if (view.getAlpha() > 0.0F) {
          if (view.getVisibility() != 0)
            return false; 
          viewParent = view.getParent();
          continue;
        } 
        return false;
      } 
      bool1 = bool2;
      if (viewParent != null)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private static int H(int paramInt) {
    return (paramInt != 19) ? ((paramInt != 21) ? ((paramInt != 22) ? 130 : 66) : 17) : 33;
  }
  
  private boolean I(int paramInt, Rect paramRect) {
    h0 h01;
    h0 h02;
    h h = y();
    int j = this.l;
    int i = Integer.MIN_VALUE;
    if (j == Integer.MIN_VALUE) {
      h02 = null;
    } else {
      h02 = (h0)h.f(j);
    } 
    if (paramInt != 1 && paramInt != 2) {
      if (paramInt == 17 || paramInt == 33 || paramInt == 66 || paramInt == 130) {
        Rect rect = new Rect();
        j = this.l;
        if (j != Integer.MIN_VALUE) {
          z(j, rect);
        } else if (paramRect != null) {
          rect.set(paramRect);
        } else {
          D(this.i, paramInt, rect);
        } 
        h01 = (h0)b.c(h, p, o, h02, rect, paramInt);
      } else {
        throw new IllegalArgumentException("direction must be one of {FOCUS_FORWARD, FOCUS_BACKWARD, FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
      } 
    } else {
      boolean bool;
      if (n0.E(this.i) == 1) {
        bool = true;
      } else {
        bool = false;
      } 
      h01 = (h0)b.d(h, p, o, h02, paramInt, bool, false);
    } 
    if (h01 == null) {
      paramInt = i;
    } else {
      paramInt = h.i(h.h(h01));
    } 
    return V(paramInt);
  }
  
  private boolean S(int paramInt1, int paramInt2, Bundle paramBundle) {
    return (paramInt2 != 1) ? ((paramInt2 != 2) ? ((paramInt2 != 64) ? ((paramInt2 != 128) ? L(paramInt1, paramInt2, paramBundle) : n(paramInt1)) : U(paramInt1)) : o(paramInt1)) : V(paramInt1);
  }
  
  private boolean T(int paramInt, Bundle paramBundle) {
    return n0.j0(this.i, paramInt, paramBundle);
  }
  
  private boolean U(int paramInt) {
    if (this.h.isEnabled()) {
      if (!this.h.isTouchExplorationEnabled())
        return false; 
      int i = this.k;
      if (i != paramInt) {
        if (i != Integer.MIN_VALUE)
          n(i); 
        this.k = paramInt;
        this.i.invalidate();
        W(paramInt, 32768);
        return true;
      } 
    } 
    return false;
  }
  
  private void X(int paramInt) {
    int i = this.m;
    if (i == paramInt)
      return; 
    this.m = paramInt;
    W(paramInt, 128);
    W(i, 256);
  }
  
  private boolean n(int paramInt) {
    if (this.k == paramInt) {
      this.k = Integer.MIN_VALUE;
      this.i.invalidate();
      W(paramInt, 65536);
      return true;
    } 
    return false;
  }
  
  private boolean p() {
    int i = this.l;
    return (i != Integer.MIN_VALUE && L(i, 16, null));
  }
  
  private AccessibilityEvent q(int paramInt1, int paramInt2) {
    return (paramInt1 != -1) ? r(paramInt1, paramInt2) : s(paramInt2);
  }
  
  private AccessibilityEvent r(int paramInt1, int paramInt2) {
    AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain(paramInt2);
    h0 h0 = J(paramInt1);
    accessibilityEvent.getText().add(h0.w());
    accessibilityEvent.setContentDescription(h0.r());
    accessibilityEvent.setScrollable(h0.K());
    accessibilityEvent.setPassword(h0.J());
    accessibilityEvent.setEnabled(h0.F());
    accessibilityEvent.setChecked(h0.D());
    N(paramInt1, accessibilityEvent);
    if (!accessibilityEvent.getText().isEmpty() || accessibilityEvent.getContentDescription() != null) {
      accessibilityEvent.setClassName(h0.p());
      j0.c((AccessibilityRecord)accessibilityEvent, this.i, paramInt1);
      accessibilityEvent.setPackageName(this.i.getContext().getPackageName());
      return accessibilityEvent;
    } 
    throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
  }
  
  private AccessibilityEvent s(int paramInt) {
    AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain(paramInt);
    this.i.onInitializeAccessibilityEvent(accessibilityEvent);
    return accessibilityEvent;
  }
  
  private h0 t(int paramInt) {
    h0 h0 = h0.O();
    h0.h0(true);
    h0.j0(true);
    h0.b0("android.view.View");
    Rect rect = n;
    h0.X(rect);
    h0.Y(rect);
    h0.r0(this.i);
    P(paramInt, h0);
    if (h0.w() != null || h0.r() != null) {
      h0.m(this.e);
      if (!this.e.equals(rect)) {
        int i = h0.k();
        if ((i & 0x40) == 0) {
          if ((i & 0x80) == 0) {
            boolean bool;
            h0.p0(this.i.getContext().getPackageName());
            h0.A0(this.i, paramInt);
            if (this.k == paramInt) {
              h0.V(true);
              h0.a(128);
            } else {
              h0.V(false);
              h0.a(64);
            } 
            if (this.l == paramInt) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool) {
              h0.a(2);
            } else if (h0.G()) {
              h0.a(1);
            } 
            h0.k0(bool);
            this.i.getLocationOnScreen(this.g);
            h0.n(this.d);
            if (this.d.equals(rect)) {
              h0.m(this.d);
              if (h0.b != -1) {
                h0 h01 = h0.O();
                for (paramInt = h0.b; paramInt != -1; paramInt = h01.b) {
                  h01.s0(this.i, -1);
                  h01.X(n);
                  P(paramInt, h01);
                  h01.m(this.e);
                  Rect rect1 = this.d;
                  Rect rect2 = this.e;
                  rect1.offset(rect2.left, rect2.top);
                } 
                h01.S();
              } 
              this.d.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
            } 
            if (this.i.getLocalVisibleRect(this.f)) {
              this.f.offset(this.g[0] - this.i.getScrollX(), this.g[1] - this.i.getScrollY());
              if (this.d.intersect(this.f)) {
                h0.Y(this.d);
                if (G(this.d))
                  h0.E0(true); 
              } 
            } 
            return h0;
          } 
          throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        } 
        throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
      } 
      throw new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
    } 
    throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
  }
  
  private h0 u() {
    h0 h0 = h0.P(this.i);
    n0.h0(this.i, h0);
    ArrayList<Integer> arrayList = new ArrayList();
    C(arrayList);
    if (h0.o() <= 0 || arrayList.size() <= 0) {
      int j = arrayList.size();
      for (int i = 0; i < j; i++)
        h0.d(this.i, ((Integer)arrayList.get(i)).intValue()); 
      return h0;
    } 
    throw new RuntimeException("Views cannot have both real and virtual children");
  }
  
  private h y() {
    ArrayList<Integer> arrayList = new ArrayList();
    C(arrayList);
    h h = new h();
    for (int i = 0; i < arrayList.size(); i++) {
      h0 h0 = t(((Integer)arrayList.get(i)).intValue());
      h.j(((Integer)arrayList.get(i)).intValue(), h0);
    } 
    return h;
  }
  
  private void z(int paramInt, Rect paramRect) {
    J(paramInt).m(paramRect);
  }
  
  public final int A() {
    return this.l;
  }
  
  protected abstract int B(float paramFloat1, float paramFloat2);
  
  protected abstract void C(List paramList);
  
  public final void E(int paramInt) {
    F(paramInt, 0);
  }
  
  public final void F(int paramInt1, int paramInt2) {
    if (paramInt1 != Integer.MIN_VALUE && this.h.isEnabled()) {
      ViewParent viewParent = this.i.getParent();
      if (viewParent != null) {
        AccessibilityEvent accessibilityEvent = q(paramInt1, 2048);
        androidx.core.view.accessibility.b.b(accessibilityEvent, paramInt2);
        viewParent.requestSendAccessibilityEvent(this.i, accessibilityEvent);
      } 
    } 
  }
  
  h0 J(int paramInt) {
    return (paramInt == -1) ? u() : t(paramInt);
  }
  
  public final void K(boolean paramBoolean, int paramInt, Rect paramRect) {
    int i = this.l;
    if (i != Integer.MIN_VALUE)
      o(i); 
    if (paramBoolean)
      I(paramInt, paramRect); 
  }
  
  protected abstract boolean L(int paramInt1, int paramInt2, Bundle paramBundle);
  
  protected void M(AccessibilityEvent paramAccessibilityEvent) {}
  
  protected void N(int paramInt, AccessibilityEvent paramAccessibilityEvent) {}
  
  protected void O(h0 paramh0) {}
  
  protected abstract void P(int paramInt, h0 paramh0);
  
  protected void Q(int paramInt, boolean paramBoolean) {}
  
  boolean R(int paramInt1, int paramInt2, Bundle paramBundle) {
    return (paramInt1 != -1) ? S(paramInt1, paramInt2, paramBundle) : T(paramInt2, paramBundle);
  }
  
  public final boolean V(int paramInt) {
    if (!this.i.isFocused() && !this.i.requestFocus())
      return false; 
    int i = this.l;
    if (i == paramInt)
      return false; 
    if (i != Integer.MIN_VALUE)
      o(i); 
    if (paramInt == Integer.MIN_VALUE)
      return false; 
    this.l = paramInt;
    Q(paramInt, true);
    W(paramInt, 8);
    return true;
  }
  
  public final boolean W(int paramInt1, int paramInt2) {
    if (paramInt1 != Integer.MIN_VALUE) {
      if (!this.h.isEnabled())
        return false; 
      ViewParent viewParent = this.i.getParent();
      if (viewParent == null)
        return false; 
      AccessibilityEvent accessibilityEvent = q(paramInt1, paramInt2);
      return viewParent.requestSendAccessibilityEvent(this.i, accessibilityEvent);
    } 
    return false;
  }
  
  public i0 b(View paramView) {
    if (this.j == null)
      this.j = new c(this); 
    return this.j;
  }
  
  public void f(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    super.f(paramView, paramAccessibilityEvent);
    M(paramAccessibilityEvent);
  }
  
  public void g(View paramView, h0 paramh0) {
    super.g(paramView, paramh0);
    O(paramh0);
  }
  
  public final boolean o(int paramInt) {
    if (this.l != paramInt)
      return false; 
    this.l = Integer.MIN_VALUE;
    Q(paramInt, false);
    W(paramInt, 8);
    return true;
  }
  
  public final boolean v(MotionEvent paramMotionEvent) {
    boolean bool = this.h.isEnabled();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      if (!this.h.isTouchExplorationEnabled())
        return false; 
      int i = paramMotionEvent.getAction();
      if (i != 7 && i != 9) {
        if (i != 10)
          return false; 
        if (this.m != Integer.MIN_VALUE) {
          X(-2147483648);
          return true;
        } 
        return false;
      } 
      i = B(paramMotionEvent.getX(), paramMotionEvent.getY());
      X(i);
      bool1 = bool2;
      if (i != Integer.MIN_VALUE)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public final boolean w(KeyEvent paramKeyEvent) {
    int j = paramKeyEvent.getAction();
    boolean bool2 = false;
    int i = 0;
    boolean bool1 = bool2;
    if (j != 1) {
      j = paramKeyEvent.getKeyCode();
      if (j != 61) {
        if (j != 66)
          switch (j) {
            default:
              return false;
            case 19:
            case 20:
            case 21:
            case 22:
              bool1 = bool2;
              if (paramKeyEvent.hasNoModifiers()) {
                j = H(j);
                int k = paramKeyEvent.getRepeatCount();
                for (bool1 = false; i < k + 1 && I(j, null); bool1 = true)
                  i++; 
                return bool1;
              } 
              return bool1;
            case 23:
              break;
          }  
        bool1 = bool2;
        if (paramKeyEvent.hasNoModifiers()) {
          bool1 = bool2;
          if (paramKeyEvent.getRepeatCount() == 0) {
            p();
            return true;
          } 
        } 
      } else {
        if (paramKeyEvent.hasNoModifiers())
          return I(2, null); 
        bool1 = bool2;
        if (paramKeyEvent.hasModifiers(1))
          bool1 = I(1, null); 
      } 
    } 
    return bool1;
  }
  
  public final int x() {
    return this.k;
  }
  
  class a implements b.a {
    public void b(h0 param1h0, Rect param1Rect) {
      param1h0.m(param1Rect);
    }
  }
  
  class b implements b.b {
    public h0 c(h param1h, int param1Int) {
      return (h0)param1h.l(param1Int);
    }
    
    public int d(h param1h) {
      return param1h.k();
    }
  }
  
  private class c extends i0 {
    c(a this$0) {}
    
    public h0 b(int param1Int) {
      return h0.Q(this.b.J(param1Int));
    }
    
    public h0 d(int param1Int) {
      if (param1Int == 2) {
        param1Int = this.b.k;
      } else {
        param1Int = this.b.l;
      } 
      return (param1Int == Integer.MIN_VALUE) ? null : b(param1Int);
    }
    
    public boolean f(int param1Int1, int param1Int2, Bundle param1Bundle) {
      return this.b.R(param1Int1, param1Int2, param1Bundle);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */