package a;

public final class a {
  public final StackTraceElement a() {
    return b.a(new Exception(), c.class.getSimpleName());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Recorder-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */