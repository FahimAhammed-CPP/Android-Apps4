package androidx.core.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;

public class ContentLoadingProgressBar extends ProgressBar {
  private static final int MIN_DELAY_MS = 500;
  
  private static final int MIN_SHOW_TIME_MS = 500;
  
  private final Runnable mDelayedHide = new -$$Lambda$ContentLoadingProgressBar$9ZVtVfM7MwrgGmJEIZNfuhCC7eY(this);
  
  private final Runnable mDelayedShow = new -$$Lambda$ContentLoadingProgressBar$ovrYLeWrClCHhOWg8t_Ay80kDrs(this);
  
  boolean mDismissed = false;
  
  boolean mPostedHide = false;
  
  boolean mPostedShow = false;
  
  long mStartTime = -1L;
  
  public ContentLoadingProgressBar(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ContentLoadingProgressBar(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
  }
  
  private void hideOnUiThread() {
    this.mDismissed = true;
    removeCallbacks(this.mDelayedShow);
    this.mPostedShow = false;
    long l2 = System.currentTimeMillis();
    long l1 = this.mStartTime;
    l2 -= l1;
    if (l2 >= 500L || l1 == -1L) {
      setVisibility(8);
      return;
    } 
    if (!this.mPostedHide) {
      postDelayed(this.mDelayedHide, 500L - l2);
      this.mPostedHide = true;
      return;
    } 
  }
  
  private void removeCallbacks() {
    removeCallbacks(this.mDelayedHide);
    removeCallbacks(this.mDelayedShow);
  }
  
  private void showOnUiThread() {
    this.mStartTime = -1L;
    this.mDismissed = false;
    removeCallbacks(this.mDelayedHide);
    this.mPostedHide = false;
    if (!this.mPostedShow) {
      postDelayed(this.mDelayedShow, 500L);
      this.mPostedShow = true;
    } 
  }
  
  public void hide() {
    post(new -$$Lambda$ContentLoadingProgressBar$Ije3417V0uZgdBrD9pbxQ2_AHiI(this));
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    removeCallbacks();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks();
  }
  
  public void show() {
    post(new -$$Lambda$ContentLoadingProgressBar$tmknj5M20Tn8TaJxR587u-39ZDQ(this));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\core\widget\ContentLoadingProgressBar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */