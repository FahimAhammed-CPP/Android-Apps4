package androidx.core.widget;

import android.content.ClipData;
import android.content.Context;
import android.os.Build;
import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import androidx.core.view.ContentInfoCompat;
import androidx.core.view.OnReceiveContentListener;

public final class TextViewOnReceiveContentListener implements OnReceiveContentListener {
  private static final String LOG_TAG = "ReceiveContent";
  
  private static CharSequence coerceToText(Context paramContext, ClipData.Item paramItem, int paramInt) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.coerce(paramContext, paramItem, paramInt) : ApiImpl.coerce(paramContext, paramItem, paramInt);
  }
  
  private static void replaceSelection(Editable paramEditable, CharSequence paramCharSequence) {
    int j = Selection.getSelectionStart((CharSequence)paramEditable);
    int k = Selection.getSelectionEnd((CharSequence)paramEditable);
    int i = Math.max(0, Math.min(j, k));
    j = Math.max(0, Math.max(j, k));
    Selection.setSelection((Spannable)paramEditable, j);
    paramEditable.replace(i, j, paramCharSequence);
  }
  
  public ContentInfoCompat onReceiveContent(View paramView, ContentInfoCompat paramContentInfoCompat) {
    if (Log.isLoggable("ReceiveContent", 3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onReceive: ");
      stringBuilder.append(paramContentInfoCompat);
      Log.d("ReceiveContent", stringBuilder.toString());
    } 
    if (paramContentInfoCompat.getSource() == 2)
      return paramContentInfoCompat; 
    ClipData clipData = paramContentInfoCompat.getClip();
    int j = paramContentInfoCompat.getFlags();
    TextView textView = (TextView)paramView;
    Editable editable = (Editable)textView.getText();
    Context context = textView.getContext();
    int i = 0;
    boolean bool;
    for (bool = false; i < clipData.getItemCount(); bool = bool1) {
      CharSequence charSequence = coerceToText(context, clipData.getItemAt(i), j);
      boolean bool1 = bool;
      if (charSequence != null)
        if (!bool) {
          replaceSelection(editable, charSequence);
          bool1 = true;
        } else {
          editable.insert(Selection.getSelectionEnd((CharSequence)editable), "\n");
          editable.insert(Selection.getSelectionEnd((CharSequence)editable), charSequence);
          bool1 = bool;
        }  
      i++;
    } 
    return null;
  }
  
  private static final class Api16Impl {
    static CharSequence coerce(Context param1Context, ClipData.Item param1Item, int param1Int) {
      CharSequence charSequence1;
      CharSequence charSequence2;
      if ((param1Int & 0x1) != 0) {
        charSequence2 = param1Item.coerceToText(param1Context);
        charSequence1 = charSequence2;
        if (charSequence2 instanceof android.text.Spanned)
          charSequence1 = charSequence2.toString(); 
        return charSequence1;
      } 
      return charSequence2.coerceToStyledText((Context)charSequence1);
    }
  }
  
  private static final class ApiImpl {
    static CharSequence coerce(Context param1Context, ClipData.Item param1Item, int param1Int) {
      CharSequence charSequence2 = param1Item.coerceToText(param1Context);
      CharSequence charSequence1 = charSequence2;
      if ((param1Int & 0x1) != 0) {
        charSequence1 = charSequence2;
        if (charSequence2 instanceof android.text.Spanned)
          charSequence1 = charSequence2.toString(); 
      } 
      return charSequence1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\core\widget\TextViewOnReceiveContentListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */