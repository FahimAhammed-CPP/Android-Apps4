package androidx.core.internal.view;

import android.view.SubMenu;

public interface SupportSubMenu extends SupportMenu, SubMenu {}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\core\internal\view\SupportSubMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */