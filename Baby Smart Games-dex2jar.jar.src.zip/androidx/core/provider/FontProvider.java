package androidx.core.provider;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.os.CancellationSignal;
import androidx.core.content.res.FontResourcesParserCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class FontProvider {
  private static final Comparator<byte[]> sByteArrayComparator = new Comparator<byte[]>() {
      public int compare(byte[] param1ArrayOfbyte1, byte[] param1ArrayOfbyte2) {
        if (param1ArrayOfbyte1.length != param1ArrayOfbyte2.length) {
          int j = param1ArrayOfbyte1.length;
          int k = param1ArrayOfbyte2.length;
          return j - k;
        } 
        for (int i = 0; i < param1ArrayOfbyte1.length; i++) {
          if (param1ArrayOfbyte1[i] != param1ArrayOfbyte2[i]) {
            byte b1 = param1ArrayOfbyte1[i];
            byte b2 = param1ArrayOfbyte2[i];
            i = b1;
            b1 = b2;
            return i - b1;
          } 
        } 
        return 0;
      }
    };
  
  private static List<byte[]> convertToByteArrayList(Signature[] paramArrayOfSignature) {
    ArrayList<byte[]> arrayList = new ArrayList();
    for (int i = 0; i < paramArrayOfSignature.length; i++)
      arrayList.add(paramArrayOfSignature[i].toByteArray()); 
    return (List<byte[]>)arrayList;
  }
  
  private static boolean equalsByteArrayList(List<byte[]> paramList1, List<byte[]> paramList2) {
    if (paramList1.size() != paramList2.size())
      return false; 
    for (int i = 0; i < paramList1.size(); i++) {
      if (!Arrays.equals(paramList1.get(i), paramList2.get(i)))
        return false; 
    } 
    return true;
  }
  
  private static List<List<byte[]>> getCertificates(FontRequest paramFontRequest, Resources paramResources) {
    return (paramFontRequest.getCertificates() != null) ? paramFontRequest.getCertificates() : FontResourcesParserCompat.readCerts(paramResources, paramFontRequest.getCertificatesArrayResId());
  }
  
  static FontsContractCompat.FontFamilyResult getFontFamilyResult(Context paramContext, FontRequest paramFontRequest, CancellationSignal paramCancellationSignal) throws PackageManager.NameNotFoundException {
    ProviderInfo providerInfo = getProvider(paramContext.getPackageManager(), paramFontRequest, paramContext.getResources());
    return (providerInfo == null) ? FontsContractCompat.FontFamilyResult.create(1, null) : FontsContractCompat.FontFamilyResult.create(0, query(paramContext, paramFontRequest, providerInfo.authority, paramCancellationSignal));
  }
  
  static ProviderInfo getProvider(PackageManager paramPackageManager, FontRequest paramFontRequest, Resources paramResources) throws PackageManager.NameNotFoundException {
    String str = paramFontRequest.getProviderAuthority();
    int i = 0;
    ProviderInfo providerInfo = paramPackageManager.resolveContentProvider(str, 0);
    if (providerInfo != null) {
      List<List<byte[]>> list;
      if (providerInfo.packageName.equals(paramFontRequest.getProviderPackage())) {
        List<byte[]> list1 = convertToByteArrayList((paramPackageManager.getPackageInfo(providerInfo.packageName, 64)).signatures);
        Collections.sort((List)list1, (Comparator)sByteArrayComparator);
        list = getCertificates(paramFontRequest, paramResources);
        while (i < list.size()) {
          ArrayList<byte> arrayList = new ArrayList(list.get(i));
          Collections.sort(arrayList, (Comparator)sByteArrayComparator);
          if (equalsByteArrayList(list1, (List)arrayList))
            return providerInfo; 
          i++;
        } 
        return null;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Found content provider ");
      stringBuilder1.append(str);
      stringBuilder1.append(", but package was not ");
      stringBuilder1.append(list.getProviderPackage());
      throw new PackageManager.NameNotFoundException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No package found for authority: ");
    stringBuilder.append(str);
    PackageManager.NameNotFoundException nameNotFoundException = new PackageManager.NameNotFoundException(stringBuilder.toString());
    throw nameNotFoundException;
  }
  
  static FontsContractCompat.FontInfo[] query(Context paramContext, FontRequest paramFontRequest, String paramString, CancellationSignal paramCancellationSignal) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #14
    //   9: new android/net/Uri$Builder
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: ldc 'content'
    //   18: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   21: aload_2
    //   22: invokevirtual authority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   25: invokevirtual build : ()Landroid/net/Uri;
    //   28: astore #16
    //   30: new android/net/Uri$Builder
    //   33: dup
    //   34: invokespecial <init> : ()V
    //   37: ldc 'content'
    //   39: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   42: aload_2
    //   43: invokevirtual authority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   46: ldc 'file'
    //   48: invokevirtual appendPath : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   51: invokevirtual build : ()Landroid/net/Uri;
    //   54: astore #17
    //   56: aconst_null
    //   57: astore #15
    //   59: aload #15
    //   61: astore_2
    //   62: bipush #7
    //   64: anewarray java/lang/String
    //   67: astore #18
    //   69: aload #18
    //   71: iconst_0
    //   72: ldc '_id'
    //   74: aastore
    //   75: aload #18
    //   77: iconst_1
    //   78: ldc 'file_id'
    //   80: aastore
    //   81: aload #18
    //   83: iconst_2
    //   84: ldc 'font_ttc_index'
    //   86: aastore
    //   87: aload #18
    //   89: iconst_3
    //   90: ldc 'font_variation_settings'
    //   92: aastore
    //   93: aload #18
    //   95: iconst_4
    //   96: ldc 'font_weight'
    //   98: aastore
    //   99: aload #18
    //   101: iconst_5
    //   102: ldc 'font_italic'
    //   104: aastore
    //   105: aload #18
    //   107: bipush #6
    //   109: ldc 'result_code'
    //   111: aastore
    //   112: aload #15
    //   114: astore_2
    //   115: getstatic android/os/Build$VERSION.SDK_INT : I
    //   118: bipush #16
    //   120: if_icmple -> 156
    //   123: aload #15
    //   125: astore_2
    //   126: aload_0
    //   127: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   130: aload #16
    //   132: aload #18
    //   134: ldc 'query = ?'
    //   136: iconst_1
    //   137: anewarray java/lang/String
    //   140: dup
    //   141: iconst_0
    //   142: aload_1
    //   143: invokevirtual getQuery : ()Ljava/lang/String;
    //   146: aastore
    //   147: aconst_null
    //   148: aload_3
    //   149: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;
    //   152: astore_0
    //   153: goto -> 185
    //   156: aload #15
    //   158: astore_2
    //   159: aload_0
    //   160: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   163: aload #16
    //   165: aload #18
    //   167: ldc 'query = ?'
    //   169: iconst_1
    //   170: anewarray java/lang/String
    //   173: dup
    //   174: iconst_0
    //   175: aload_1
    //   176: invokevirtual getQuery : ()Ljava/lang/String;
    //   179: aastore
    //   180: aconst_null
    //   181: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   184: astore_0
    //   185: aload #14
    //   187: astore_1
    //   188: aload_0
    //   189: ifnull -> 453
    //   192: aload #14
    //   194: astore_1
    //   195: aload_0
    //   196: astore_2
    //   197: aload_0
    //   198: invokeinterface getCount : ()I
    //   203: ifle -> 453
    //   206: aload_0
    //   207: astore_2
    //   208: aload_0
    //   209: ldc 'result_code'
    //   211: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   216: istore #7
    //   218: aload_0
    //   219: astore_2
    //   220: new java/util/ArrayList
    //   223: dup
    //   224: invokespecial <init> : ()V
    //   227: astore_3
    //   228: aload_0
    //   229: astore_2
    //   230: aload_0
    //   231: ldc '_id'
    //   233: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   238: istore #8
    //   240: aload_0
    //   241: astore_2
    //   242: aload_0
    //   243: ldc 'file_id'
    //   245: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   250: istore #9
    //   252: aload_0
    //   253: astore_2
    //   254: aload_0
    //   255: ldc 'font_ttc_index'
    //   257: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   262: istore #10
    //   264: aload_0
    //   265: astore_2
    //   266: aload_0
    //   267: ldc 'font_weight'
    //   269: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   274: istore #11
    //   276: aload_0
    //   277: astore_2
    //   278: aload_0
    //   279: ldc 'font_italic'
    //   281: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   286: istore #12
    //   288: aload_0
    //   289: astore_2
    //   290: aload_0
    //   291: invokeinterface moveToNext : ()Z
    //   296: ifeq -> 451
    //   299: iload #7
    //   301: iconst_m1
    //   302: if_icmpeq -> 494
    //   305: aload_0
    //   306: astore_2
    //   307: aload_0
    //   308: iload #7
    //   310: invokeinterface getInt : (I)I
    //   315: istore #4
    //   317: goto -> 320
    //   320: iload #10
    //   322: iconst_m1
    //   323: if_icmpeq -> 500
    //   326: aload_0
    //   327: astore_2
    //   328: aload_0
    //   329: iload #10
    //   331: invokeinterface getInt : (I)I
    //   336: istore #5
    //   338: goto -> 341
    //   341: iload #9
    //   343: iconst_m1
    //   344: if_icmpne -> 366
    //   347: aload_0
    //   348: astore_2
    //   349: aload #16
    //   351: aload_0
    //   352: iload #8
    //   354: invokeinterface getLong : (I)J
    //   359: invokestatic withAppendedId : (Landroid/net/Uri;J)Landroid/net/Uri;
    //   362: astore_1
    //   363: goto -> 382
    //   366: aload_0
    //   367: astore_2
    //   368: aload #17
    //   370: aload_0
    //   371: iload #9
    //   373: invokeinterface getLong : (I)J
    //   378: invokestatic withAppendedId : (Landroid/net/Uri;J)Landroid/net/Uri;
    //   381: astore_1
    //   382: iload #11
    //   384: iconst_m1
    //   385: if_icmpeq -> 506
    //   388: aload_0
    //   389: astore_2
    //   390: aload_0
    //   391: iload #11
    //   393: invokeinterface getInt : (I)I
    //   398: istore #6
    //   400: goto -> 403
    //   403: iload #12
    //   405: iconst_m1
    //   406: if_icmpeq -> 514
    //   409: aload_0
    //   410: astore_2
    //   411: aload_0
    //   412: iload #12
    //   414: invokeinterface getInt : (I)I
    //   419: iconst_1
    //   420: if_icmpne -> 514
    //   423: iconst_1
    //   424: istore #13
    //   426: goto -> 429
    //   429: aload_0
    //   430: astore_2
    //   431: aload_3
    //   432: aload_1
    //   433: iload #5
    //   435: iload #6
    //   437: iload #13
    //   439: iload #4
    //   441: invokestatic create : (Landroid/net/Uri;IIZI)Landroidx/core/provider/FontsContractCompat$FontInfo;
    //   444: invokevirtual add : (Ljava/lang/Object;)Z
    //   447: pop
    //   448: goto -> 288
    //   451: aload_3
    //   452: astore_1
    //   453: aload_0
    //   454: ifnull -> 463
    //   457: aload_0
    //   458: invokeinterface close : ()V
    //   463: aload_1
    //   464: iconst_0
    //   465: anewarray androidx/core/provider/FontsContractCompat$FontInfo
    //   468: invokevirtual toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   471: checkcast [Landroidx/core/provider/FontsContractCompat$FontInfo;
    //   474: areturn
    //   475: astore_0
    //   476: aload_2
    //   477: ifnull -> 486
    //   480: aload_2
    //   481: invokeinterface close : ()V
    //   486: goto -> 491
    //   489: aload_0
    //   490: athrow
    //   491: goto -> 489
    //   494: iconst_0
    //   495: istore #4
    //   497: goto -> 320
    //   500: iconst_0
    //   501: istore #5
    //   503: goto -> 341
    //   506: sipush #400
    //   509: istore #6
    //   511: goto -> 403
    //   514: iconst_0
    //   515: istore #13
    //   517: goto -> 429
    // Exception table:
    //   from	to	target	type
    //   62	69	475	finally
    //   115	123	475	finally
    //   126	153	475	finally
    //   159	185	475	finally
    //   197	206	475	finally
    //   208	218	475	finally
    //   220	228	475	finally
    //   230	240	475	finally
    //   242	252	475	finally
    //   254	264	475	finally
    //   266	276	475	finally
    //   278	288	475	finally
    //   290	299	475	finally
    //   307	317	475	finally
    //   328	338	475	finally
    //   349	363	475	finally
    //   368	382	475	finally
    //   390	400	475	finally
    //   411	423	475	finally
    //   431	448	475	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\core\provider\FontProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */