package androidx.core.content.pm;

@Deprecated
public final class ActivityInfoCompat {
  @Deprecated
  public static final int CONFIG_UI_MODE = 512;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\core\content\pm\ActivityInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */