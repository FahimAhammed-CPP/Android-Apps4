package androidx.room;

public class FtsOptions {
  public static final String TOKENIZER_ICU = "icu";
  
  public static final String TOKENIZER_PORTER = "porter";
  
  public static final String TOKENIZER_SIMPLE = "simple";
  
  public static final String TOKENIZER_UNICODE61 = "unicode61";
  
  public enum MatchInfo {
    FTS3, FTS4;
    
    static {
      MatchInfo matchInfo1 = new MatchInfo("FTS3", 0);
      FTS3 = matchInfo1;
      MatchInfo matchInfo2 = new MatchInfo("FTS4", 1);
      FTS4 = matchInfo2;
      $VALUES = new MatchInfo[] { matchInfo1, matchInfo2 };
    }
  }
  
  public enum Order {
    ASC, DESC;
    
    static {
      Order order1 = new Order("ASC", 0);
      ASC = order1;
      Order order2 = new Order("DESC", 1);
      DESC = order2;
      $VALUES = new Order[] { order1, order2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Smart Games-dex2jar.jar!\androidx\room\FtsOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */