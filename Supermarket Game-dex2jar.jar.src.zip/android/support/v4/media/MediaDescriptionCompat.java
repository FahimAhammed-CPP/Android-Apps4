package android.support.v4.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

public final class MediaDescriptionCompat implements Parcelable {
  public static final long BT_FOLDER_TYPE_ALBUMS = 2L;
  
  public static final long BT_FOLDER_TYPE_ARTISTS = 3L;
  
  public static final long BT_FOLDER_TYPE_GENRES = 4L;
  
  public static final long BT_FOLDER_TYPE_MIXED = 0L;
  
  public static final long BT_FOLDER_TYPE_PLAYLISTS = 5L;
  
  public static final long BT_FOLDER_TYPE_TITLES = 1L;
  
  public static final long BT_FOLDER_TYPE_YEARS = 6L;
  
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new Parcelable.Creator<MediaDescriptionCompat>() {
      public MediaDescriptionCompat createFromParcel(Parcel param1Parcel) {
        return MediaDescriptionCompat.fromMediaDescription(MediaDescriptionCompatApi21.fromParcel(param1Parcel));
      }
      
      public MediaDescriptionCompat[] newArray(int param1Int) {
        return new MediaDescriptionCompat[param1Int];
      }
    };
  
  public static final String DESCRIPTION_KEY_MEDIA_URI = "android.support.v4.media.description.MEDIA_URI";
  
  public static final String DESCRIPTION_KEY_NULL_BUNDLE_FLAG = "android.support.v4.media.description.NULL_BUNDLE_FLAG";
  
  public static final String EXTRA_BT_FOLDER_TYPE = "android.media.extra.BT_FOLDER_TYPE";
  
  public static final String EXTRA_DOWNLOAD_STATUS = "android.media.extra.DOWNLOAD_STATUS";
  
  public static final long STATUS_DOWNLOADED = 2L;
  
  public static final long STATUS_DOWNLOADING = 1L;
  
  public static final long STATUS_NOT_DOWNLOADED = 0L;
  
  private final CharSequence mDescription;
  
  private Object mDescriptionObj;
  
  private final Bundle mExtras;
  
  private final Bitmap mIcon;
  
  private final Uri mIconUri;
  
  private final String mMediaId;
  
  private final Uri mMediaUri;
  
  private final CharSequence mSubtitle;
  
  private final CharSequence mTitle;
  
  MediaDescriptionCompat(Parcel paramParcel) {
    this.mMediaId = paramParcel.readString();
    this.mTitle = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.mSubtitle = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.mDescription = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    ClassLoader classLoader = getClass().getClassLoader();
    this.mIcon = (Bitmap)paramParcel.readParcelable(classLoader);
    this.mIconUri = (Uri)paramParcel.readParcelable(classLoader);
    this.mExtras = paramParcel.readBundle(classLoader);
    this.mMediaUri = (Uri)paramParcel.readParcelable(classLoader);
  }
  
  MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.mMediaId = paramString;
    this.mTitle = paramCharSequence1;
    this.mSubtitle = paramCharSequence2;
    this.mDescription = paramCharSequence3;
    this.mIcon = paramBitmap;
    this.mIconUri = paramUri1;
    this.mExtras = paramBundle;
    this.mMediaUri = paramUri2;
  }
  
  public static MediaDescriptionCompat fromMediaDescription(Object paramObject) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aconst_null
    //   3: astore_2
    //   4: aload_0
    //   5: ifnull -> 193
    //   8: new android/support/v4/media/MediaDescriptionCompat$Builder
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore #4
    //   17: aload #4
    //   19: aload_0
    //   20: invokestatic getMediaId : (Ljava/lang/Object;)Ljava/lang/String;
    //   23: invokevirtual setMediaId : (Ljava/lang/String;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   26: pop
    //   27: aload #4
    //   29: aload_0
    //   30: invokestatic getTitle : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   33: invokevirtual setTitle : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   36: pop
    //   37: aload #4
    //   39: aload_0
    //   40: invokestatic getSubtitle : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   43: invokevirtual setSubtitle : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   46: pop
    //   47: aload #4
    //   49: aload_0
    //   50: invokestatic getDescription : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   53: invokevirtual setDescription : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   56: pop
    //   57: aload #4
    //   59: aload_0
    //   60: invokestatic getIconBitmap : (Ljava/lang/Object;)Landroid/graphics/Bitmap;
    //   63: invokevirtual setIconBitmap : (Landroid/graphics/Bitmap;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   66: pop
    //   67: aload #4
    //   69: aload_0
    //   70: invokestatic getIconUri : (Ljava/lang/Object;)Landroid/net/Uri;
    //   73: invokevirtual setIconUri : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   76: pop
    //   77: aload_0
    //   78: invokestatic getExtras : (Ljava/lang/Object;)Landroid/os/Bundle;
    //   81: astore_3
    //   82: aload_3
    //   83: ifnull -> 103
    //   86: aload_3
    //   87: invokestatic ensureClassLoader : (Landroid/os/Bundle;)V
    //   90: aload_3
    //   91: ldc 'android.support.v4.media.description.MEDIA_URI'
    //   93: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   96: checkcast android/net/Uri
    //   99: astore_1
    //   100: goto -> 105
    //   103: aconst_null
    //   104: astore_1
    //   105: aload_1
    //   106: ifnull -> 141
    //   109: aload_3
    //   110: ldc 'android.support.v4.media.description.NULL_BUNDLE_FLAG'
    //   112: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   115: ifeq -> 129
    //   118: aload_3
    //   119: invokevirtual size : ()I
    //   122: iconst_2
    //   123: if_icmpne -> 129
    //   126: goto -> 143
    //   129: aload_3
    //   130: ldc 'android.support.v4.media.description.MEDIA_URI'
    //   132: invokevirtual remove : (Ljava/lang/String;)V
    //   135: aload_3
    //   136: ldc 'android.support.v4.media.description.NULL_BUNDLE_FLAG'
    //   138: invokevirtual remove : (Ljava/lang/String;)V
    //   141: aload_3
    //   142: astore_2
    //   143: aload #4
    //   145: aload_2
    //   146: invokevirtual setExtras : (Landroid/os/Bundle;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   149: pop
    //   150: aload_1
    //   151: ifnull -> 164
    //   154: aload #4
    //   156: aload_1
    //   157: invokevirtual setMediaUri : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   160: pop
    //   161: goto -> 182
    //   164: getstatic android/os/Build$VERSION.SDK_INT : I
    //   167: bipush #23
    //   169: if_icmplt -> 182
    //   172: aload #4
    //   174: aload_0
    //   175: invokestatic getMediaUri : (Ljava/lang/Object;)Landroid/net/Uri;
    //   178: invokevirtual setMediaUri : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   181: pop
    //   182: aload #4
    //   184: invokevirtual build : ()Landroid/support/v4/media/MediaDescriptionCompat;
    //   187: astore_1
    //   188: aload_1
    //   189: aload_0
    //   190: putfield mDescriptionObj : Ljava/lang/Object;
    //   193: aload_1
    //   194: areturn
  }
  
  public int describeContents() {
    return 0;
  }
  
  public CharSequence getDescription() {
    return this.mDescription;
  }
  
  public Bundle getExtras() {
    return this.mExtras;
  }
  
  public Bitmap getIconBitmap() {
    return this.mIcon;
  }
  
  public Uri getIconUri() {
    return this.mIconUri;
  }
  
  public Object getMediaDescription() {
    Object object2 = this.mDescriptionObj;
    Object object1 = object2;
    if (object2 == null) {
      Object object = MediaDescriptionCompatApi21.Builder.newInstance();
      MediaDescriptionCompatApi21.Builder.setMediaId(object, this.mMediaId);
      MediaDescriptionCompatApi21.Builder.setTitle(object, this.mTitle);
      MediaDescriptionCompatApi21.Builder.setSubtitle(object, this.mSubtitle);
      MediaDescriptionCompatApi21.Builder.setDescription(object, this.mDescription);
      MediaDescriptionCompatApi21.Builder.setIconBitmap(object, this.mIcon);
      MediaDescriptionCompatApi21.Builder.setIconUri(object, this.mIconUri);
      object2 = this.mExtras;
      object1 = object2;
      if (Build.VERSION.SDK_INT < 23) {
        object1 = object2;
        if (this.mMediaUri != null) {
          object1 = object2;
          if (object2 == null) {
            object1 = new Bundle();
            object1.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
          } 
          object1.putParcelable("android.support.v4.media.description.MEDIA_URI", (Parcelable)this.mMediaUri);
        } 
      } 
      MediaDescriptionCompatApi21.Builder.setExtras(object, (Bundle)object1);
      if (Build.VERSION.SDK_INT >= 23)
        MediaDescriptionCompatApi23.Builder.setMediaUri(object, this.mMediaUri); 
      object1 = MediaDescriptionCompatApi21.Builder.build(object);
      this.mDescriptionObj = object1;
    } 
    return object1;
  }
  
  public String getMediaId() {
    return this.mMediaId;
  }
  
  public Uri getMediaUri() {
    return this.mMediaUri;
  }
  
  public CharSequence getSubtitle() {
    return this.mSubtitle;
  }
  
  public CharSequence getTitle() {
    return this.mTitle;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mTitle);
    stringBuilder.append(", ");
    stringBuilder.append(this.mSubtitle);
    stringBuilder.append(", ");
    stringBuilder.append(this.mDescription);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    MediaDescriptionCompatApi21.writeToParcel(getMediaDescription(), paramParcel, paramInt);
  }
  
  public static final class Builder {
    private CharSequence mDescription;
    
    private Bundle mExtras;
    
    private Bitmap mIcon;
    
    private Uri mIconUri;
    
    private String mMediaId;
    
    private Uri mMediaUri;
    
    private CharSequence mSubtitle;
    
    private CharSequence mTitle;
    
    public MediaDescriptionCompat build() {
      return new MediaDescriptionCompat(this.mMediaId, this.mTitle, this.mSubtitle, this.mDescription, this.mIcon, this.mIconUri, this.mExtras, this.mMediaUri);
    }
    
    public Builder setDescription(CharSequence param1CharSequence) {
      this.mDescription = param1CharSequence;
      return this;
    }
    
    public Builder setExtras(Bundle param1Bundle) {
      this.mExtras = param1Bundle;
      return this;
    }
    
    public Builder setIconBitmap(Bitmap param1Bitmap) {
      this.mIcon = param1Bitmap;
      return this;
    }
    
    public Builder setIconUri(Uri param1Uri) {
      this.mIconUri = param1Uri;
      return this;
    }
    
    public Builder setMediaId(String param1String) {
      this.mMediaId = param1String;
      return this;
    }
    
    public Builder setMediaUri(Uri param1Uri) {
      this.mMediaUri = param1Uri;
      return this;
    }
    
    public Builder setSubtitle(CharSequence param1CharSequence) {
      this.mSubtitle = param1CharSequence;
      return this;
    }
    
    public Builder setTitle(CharSequence param1CharSequence) {
      this.mTitle = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\android\support\v4\media\MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */