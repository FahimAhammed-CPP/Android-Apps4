package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.LocaleManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.LocaleList;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.view.ActionMode;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.VectorEnabledTintResources;
import androidx.collection.ArraySet;
import androidx.core.os.BuildCompat;
import androidx.core.os.LocaleListCompat;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Objects;

public abstract class AppCompatDelegate {
  static final boolean DEBUG = false;
  
  public static final int FEATURE_ACTION_MODE_OVERLAY = 10;
  
  public static final int FEATURE_SUPPORT_ACTION_BAR = 108;
  
  public static final int FEATURE_SUPPORT_ACTION_BAR_OVERLAY = 109;
  
  @Deprecated
  public static final int MODE_NIGHT_AUTO = 0;
  
  public static final int MODE_NIGHT_AUTO_BATTERY = 3;
  
  @Deprecated
  public static final int MODE_NIGHT_AUTO_TIME = 0;
  
  public static final int MODE_NIGHT_FOLLOW_SYSTEM = -1;
  
  public static final int MODE_NIGHT_NO = 1;
  
  public static final int MODE_NIGHT_UNSPECIFIED = -100;
  
  public static final int MODE_NIGHT_YES = 2;
  
  static final String TAG = "AppCompatDelegate";
  
  private static final ArraySet<WeakReference<AppCompatDelegate>> sActivityDelegates;
  
  private static final Object sActivityDelegatesLock;
  
  private static final Object sAppLocalesStorageSyncLock;
  
  private static int sDefaultNightMode;
  
  private static Boolean sIsAutoStoreLocalesOptedIn;
  
  private static boolean sIsFrameworkSyncChecked;
  
  private static LocaleListCompat sRequestedAppLocales;
  
  static AppLocalesStorageHelper.SerialExecutor sSerialExecutorForLocalesStorage = new AppLocalesStorageHelper.SerialExecutor(new AppLocalesStorageHelper.ThreadPerTaskExecutor());
  
  private static LocaleListCompat sStoredAppLocales;
  
  static {
    sDefaultNightMode = -100;
    sRequestedAppLocales = null;
    sStoredAppLocales = null;
    sIsAutoStoreLocalesOptedIn = null;
    sIsFrameworkSyncChecked = false;
    sActivityDelegates = new ArraySet();
    sActivityDelegatesLock = new Object();
    sAppLocalesStorageSyncLock = new Object();
  }
  
  static void addActiveDelegate(AppCompatDelegate paramAppCompatDelegate) {
    synchronized (sActivityDelegatesLock) {
      removeDelegateFromActives(paramAppCompatDelegate);
      sActivityDelegates.add(new WeakReference<AppCompatDelegate>(paramAppCompatDelegate));
      return;
    } 
  }
  
  private static void applyDayNightToActiveDelegates() {
    synchronized (sActivityDelegatesLock) {
      Iterator<WeakReference<AppCompatDelegate>> iterator = sActivityDelegates.iterator();
      while (iterator.hasNext()) {
        AppCompatDelegate appCompatDelegate = ((WeakReference<AppCompatDelegate>)iterator.next()).get();
        if (appCompatDelegate != null)
          appCompatDelegate.applyDayNight(); 
      } 
      return;
    } 
  }
  
  private static void applyLocalesToActiveDelegates() {
    Iterator<WeakReference<AppCompatDelegate>> iterator = sActivityDelegates.iterator();
    while (iterator.hasNext()) {
      AppCompatDelegate appCompatDelegate = ((WeakReference<AppCompatDelegate>)iterator.next()).get();
      if (appCompatDelegate != null)
        appCompatDelegate.applyAppLocales(); 
    } 
  }
  
  public static AppCompatDelegate create(Activity paramActivity, AppCompatCallback paramAppCompatCallback) {
    return new AppCompatDelegateImpl(paramActivity, paramAppCompatCallback);
  }
  
  public static AppCompatDelegate create(Dialog paramDialog, AppCompatCallback paramAppCompatCallback) {
    return new AppCompatDelegateImpl(paramDialog, paramAppCompatCallback);
  }
  
  public static AppCompatDelegate create(Context paramContext, Activity paramActivity, AppCompatCallback paramAppCompatCallback) {
    return new AppCompatDelegateImpl(paramContext, paramActivity, paramAppCompatCallback);
  }
  
  public static AppCompatDelegate create(Context paramContext, Window paramWindow, AppCompatCallback paramAppCompatCallback) {
    return new AppCompatDelegateImpl(paramContext, paramWindow, paramAppCompatCallback);
  }
  
  public static LocaleListCompat getApplicationLocales() {
    if (BuildCompat.isAtLeastT()) {
      Object object = getLocaleManagerForApplication();
      if (object != null)
        return LocaleListCompat.wrap(Api33Impl.localeManagerGetApplicationLocales(object)); 
    } else {
      LocaleListCompat localeListCompat = sRequestedAppLocales;
      if (localeListCompat != null)
        return localeListCompat; 
    } 
    return LocaleListCompat.getEmptyLocaleList();
  }
  
  public static int getDefaultNightMode() {
    return sDefaultNightMode;
  }
  
  static Object getLocaleManagerForApplication() {
    Iterator<WeakReference<AppCompatDelegate>> iterator = sActivityDelegates.iterator();
    while (iterator.hasNext()) {
      AppCompatDelegate appCompatDelegate = ((WeakReference<AppCompatDelegate>)iterator.next()).get();
      if (appCompatDelegate != null) {
        Context context = appCompatDelegate.getContextForDelegate();
        if (context != null)
          return context.getSystemService("locale"); 
      } 
    } 
    return null;
  }
  
  static LocaleListCompat getRequestedAppLocales() {
    return sRequestedAppLocales;
  }
  
  static LocaleListCompat getStoredAppLocales() {
    return sStoredAppLocales;
  }
  
  static boolean isAutoStorageOptedIn(Context paramContext) {
    if (sIsAutoStoreLocalesOptedIn == null)
      try {
        ServiceInfo serviceInfo = AppLocalesMetadataHolderService.getServiceInfo(paramContext);
        if (serviceInfo.metaData != null)
          sIsAutoStoreLocalesOptedIn = Boolean.valueOf(serviceInfo.metaData.getBoolean("autoStoreLocales")); 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Checking for metadata for AppLocalesMetadataHolderService : Service not found");
        sIsAutoStoreLocalesOptedIn = Boolean.valueOf(false);
      }  
    return sIsAutoStoreLocalesOptedIn.booleanValue();
  }
  
  public static boolean isCompatVectorFromResourcesEnabled() {
    return VectorEnabledTintResources.isCompatVectorFromResourcesEnabled();
  }
  
  static void removeActivityDelegate(AppCompatDelegate paramAppCompatDelegate) {
    synchronized (sActivityDelegatesLock) {
      removeDelegateFromActives(paramAppCompatDelegate);
      return;
    } 
  }
  
  private static void removeDelegateFromActives(AppCompatDelegate paramAppCompatDelegate) {
    synchronized (sActivityDelegatesLock) {
      Iterator<WeakReference<AppCompatDelegate>> iterator = sActivityDelegates.iterator();
      while (iterator.hasNext()) {
        AppCompatDelegate appCompatDelegate = ((WeakReference<AppCompatDelegate>)iterator.next()).get();
        if (appCompatDelegate == paramAppCompatDelegate || appCompatDelegate == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  static void resetStaticRequestedAndStoredLocales() {
    sRequestedAppLocales = null;
    sStoredAppLocales = null;
  }
  
  public static void setApplicationLocales(LocaleListCompat paramLocaleListCompat) {
    Objects.requireNonNull(paramLocaleListCompat);
    if (BuildCompat.isAtLeastT()) {
      Object object = getLocaleManagerForApplication();
      if (object != null) {
        Api33Impl.localeManagerSetApplicationLocales(object, Api24Impl.localeListForLanguageTags(paramLocaleListCompat.toLanguageTags()));
        return;
      } 
    } else if (!paramLocaleListCompat.equals(sRequestedAppLocales)) {
      synchronized (sActivityDelegatesLock) {
        sRequestedAppLocales = paramLocaleListCompat;
        applyLocalesToActiveDelegates();
        return;
      } 
    } 
  }
  
  public static void setCompatVectorFromResourcesEnabled(boolean paramBoolean) {
    VectorEnabledTintResources.setCompatVectorFromResourcesEnabled(paramBoolean);
  }
  
  public static void setDefaultNightMode(int paramInt) {
    if (paramInt != -1 && paramInt != 0 && paramInt != 1 && paramInt != 2 && paramInt != 3) {
      Log.d("AppCompatDelegate", "setDefaultNightMode() called with an unknown mode");
      return;
    } 
    if (sDefaultNightMode != paramInt) {
      sDefaultNightMode = paramInt;
      applyDayNightToActiveDelegates();
    } 
  }
  
  static void setIsAutoStoreLocalesOptedIn(boolean paramBoolean) {
    sIsAutoStoreLocalesOptedIn = Boolean.valueOf(paramBoolean);
  }
  
  static void syncRequestedAndStoredLocales(Context paramContext) {
    if (!isAutoStorageOptedIn(paramContext))
      return; 
    if (BuildCompat.isAtLeastT()) {
      if (!sIsFrameworkSyncChecked) {
        sSerialExecutorForLocalesStorage.execute(new AppCompatDelegate$$ExternalSyntheticLambda1(paramContext));
        return;
      } 
    } else {
      synchronized (sAppLocalesStorageSyncLock) {
        LocaleListCompat localeListCompat = sRequestedAppLocales;
        if (localeListCompat == null) {
          if (sStoredAppLocales == null)
            sStoredAppLocales = LocaleListCompat.forLanguageTags(AppLocalesStorageHelper.readLocales(paramContext)); 
          if (sStoredAppLocales.isEmpty())
            return; 
          sRequestedAppLocales = sStoredAppLocales;
        } else if (!localeListCompat.equals(sStoredAppLocales)) {
          localeListCompat = sRequestedAppLocales;
          sStoredAppLocales = localeListCompat;
          AppLocalesStorageHelper.persistLocales(paramContext, localeListCompat.toLanguageTags());
        } 
        return;
      } 
    } 
  }
  
  public abstract void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  boolean applyAppLocales() {
    return false;
  }
  
  public abstract boolean applyDayNight();
  
  void asyncExecuteSyncRequestedAndStoredLocales(Context paramContext) {
    sSerialExecutorForLocalesStorage.execute(new AppCompatDelegate$$ExternalSyntheticLambda0(paramContext));
  }
  
  @Deprecated
  public void attachBaseContext(Context paramContext) {}
  
  public Context attachBaseContext2(Context paramContext) {
    attachBaseContext(paramContext);
    return paramContext;
  }
  
  public abstract View createView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet);
  
  public abstract <T extends View> T findViewById(int paramInt);
  
  public Context getContextForDelegate() {
    return null;
  }
  
  public abstract ActionBarDrawerToggle.Delegate getDrawerToggleDelegate();
  
  public int getLocalNightMode() {
    return -100;
  }
  
  public abstract MenuInflater getMenuInflater();
  
  public abstract ActionBar getSupportActionBar();
  
  public abstract boolean hasWindowFeature(int paramInt);
  
  public abstract void installViewFactory();
  
  public abstract void invalidateOptionsMenu();
  
  public abstract boolean isHandleNativeActionModesEnabled();
  
  public abstract void onConfigurationChanged(Configuration paramConfiguration);
  
  public abstract void onCreate(Bundle paramBundle);
  
  public abstract void onDestroy();
  
  public abstract void onPostCreate(Bundle paramBundle);
  
  public abstract void onPostResume();
  
  public abstract void onSaveInstanceState(Bundle paramBundle);
  
  public abstract void onStart();
  
  public abstract void onStop();
  
  public abstract boolean requestWindowFeature(int paramInt);
  
  public abstract void setContentView(int paramInt);
  
  public abstract void setContentView(View paramView);
  
  public abstract void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract void setHandleNativeActionModesEnabled(boolean paramBoolean);
  
  public abstract void setLocalNightMode(int paramInt);
  
  public void setOnBackInvokedDispatcher(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {}
  
  public abstract void setSupportActionBar(Toolbar paramToolbar);
  
  public void setTheme(int paramInt) {}
  
  public abstract void setTitle(CharSequence paramCharSequence);
  
  public abstract ActionMode startSupportActionMode(ActionMode.Callback paramCallback);
  
  static class Api24Impl {
    static LocaleList localeListForLanguageTags(String param1String) {
      return LocaleList.forLanguageTags(param1String);
    }
  }
  
  static class Api33Impl {
    static LocaleList localeManagerGetApplicationLocales(Object param1Object) {
      return ((LocaleManager)param1Object).getApplicationLocales();
    }
    
    static void localeManagerSetApplicationLocales(Object param1Object, LocaleList param1LocaleList) {
      ((LocaleManager)param1Object).setApplicationLocales(param1LocaleList);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface NightMode {}
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\appcompat\app\AppCompatDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */