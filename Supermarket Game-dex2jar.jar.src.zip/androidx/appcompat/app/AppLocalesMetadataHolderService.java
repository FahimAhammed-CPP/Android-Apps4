package androidx.appcompat.app;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

public final class AppLocalesMetadataHolderService extends Service {
  public static ServiceInfo getServiceInfo(Context paramContext) throws PackageManager.NameNotFoundException {
    char c;
    if (Build.VERSION.SDK_INT >= 24) {
      c = Api24Impl.getDisabledComponentFlag() | 0x80;
    } else {
      c = 'ʀ';
    } 
    return paramContext.getPackageManager().getServiceInfo(new ComponentName(paramContext, AppLocalesMetadataHolderService.class), c);
  }
  
  public IBinder onBind(Intent paramIntent) {
    throw new UnsupportedOperationException();
  }
  
  private static class Api24Impl {
    static int getDisabledComponentFlag() {
      return 512;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\appcompat\app\AppLocalesMetadataHolderService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */