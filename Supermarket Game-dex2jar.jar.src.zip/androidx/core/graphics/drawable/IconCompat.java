package androidx.core.graphics.drawable;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.util.ObjectsCompat;
import androidx.core.util.Preconditions;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {
  private static final float ADAPTIVE_ICON_INSET_FACTOR = 0.25F;
  
  private static final int AMBIENT_SHADOW_ALPHA = 30;
  
  private static final float BLUR_FACTOR = 0.010416667F;
  
  static final PorterDuff.Mode DEFAULT_TINT_MODE = PorterDuff.Mode.SRC_IN;
  
  private static final float DEFAULT_VIEW_PORT_SCALE = 0.6666667F;
  
  static final String EXTRA_INT1 = "int1";
  
  static final String EXTRA_INT2 = "int2";
  
  static final String EXTRA_OBJ = "obj";
  
  static final String EXTRA_STRING1 = "string1";
  
  static final String EXTRA_TINT_LIST = "tint_list";
  
  static final String EXTRA_TINT_MODE = "tint_mode";
  
  static final String EXTRA_TYPE = "type";
  
  private static final float ICON_DIAMETER_FACTOR = 0.9166667F;
  
  private static final int KEY_SHADOW_ALPHA = 61;
  
  private static final float KEY_SHADOW_OFFSET_FACTOR = 0.020833334F;
  
  private static final String TAG = "IconCompat";
  
  public static final int TYPE_ADAPTIVE_BITMAP = 5;
  
  public static final int TYPE_BITMAP = 1;
  
  public static final int TYPE_DATA = 3;
  
  public static final int TYPE_RESOURCE = 2;
  
  public static final int TYPE_UNKNOWN = -1;
  
  public static final int TYPE_URI = 4;
  
  public static final int TYPE_URI_ADAPTIVE_BITMAP = 6;
  
  public byte[] mData;
  
  public int mInt1;
  
  public int mInt2;
  
  Object mObj1;
  
  public Parcelable mParcelable;
  
  public String mString1;
  
  public ColorStateList mTintList;
  
  PorterDuff.Mode mTintMode;
  
  public String mTintModeStr;
  
  public int mType;
  
  public IconCompat() {
    this.mType = -1;
    this.mData = null;
    this.mParcelable = null;
    this.mInt1 = 0;
    this.mInt2 = 0;
    this.mTintList = null;
    this.mTintMode = DEFAULT_TINT_MODE;
    this.mTintModeStr = null;
  }
  
  IconCompat(int paramInt) {
    this.mData = null;
    this.mParcelable = null;
    this.mInt1 = 0;
    this.mInt2 = 0;
    this.mTintList = null;
    this.mTintMode = DEFAULT_TINT_MODE;
    this.mTintModeStr = null;
    this.mType = paramInt;
  }
  
  public static IconCompat createFromBundle(Bundle paramBundle) {
    StringBuilder stringBuilder;
    int i = paramBundle.getInt("type");
    IconCompat iconCompat = new IconCompat(i);
    iconCompat.mInt1 = paramBundle.getInt("int1");
    iconCompat.mInt2 = paramBundle.getInt("int2");
    iconCompat.mString1 = paramBundle.getString("string1");
    if (paramBundle.containsKey("tint_list"))
      iconCompat.mTintList = (ColorStateList)paramBundle.getParcelable("tint_list"); 
    if (paramBundle.containsKey("tint_mode"))
      iconCompat.mTintMode = PorterDuff.Mode.valueOf(paramBundle.getString("tint_mode")); 
    switch (i) {
      default:
        stringBuilder = new StringBuilder("Unknown type ");
        stringBuilder.append(i);
        Log.w("IconCompat", stringBuilder.toString());
        return null;
      case 3:
        iconCompat.mObj1 = stringBuilder.getByteArray("obj");
        return iconCompat;
      case 2:
      case 4:
      case 6:
        iconCompat.mObj1 = stringBuilder.getString("obj");
        return iconCompat;
      case -1:
      case 1:
      case 5:
        break;
    } 
    iconCompat.mObj1 = stringBuilder.getParcelable("obj");
    return iconCompat;
  }
  
  public static IconCompat createFromIcon(Context paramContext, Icon paramIcon) {
    Preconditions.checkNotNull(paramIcon);
    return Api23Impl.createFromIcon(paramContext, paramIcon);
  }
  
  public static IconCompat createFromIcon(Icon paramIcon) {
    return Api23Impl.createFromIconInner(paramIcon);
  }
  
  public static IconCompat createFromIconOrNullIfZeroResId(Icon paramIcon) {
    return (Api23Impl.getType(paramIcon) == 2 && Api23Impl.getResId(paramIcon) == 0) ? null : Api23Impl.createFromIconInner(paramIcon);
  }
  
  static Bitmap createLegacyIconFromAdaptiveIcon(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
    Matrix matrix = new Matrix();
    matrix.setTranslate(-(paramBitmap.getWidth() - i) / 2.0F, -(paramBitmap.getHeight() - i) / 2.0F);
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat createWithAdaptiveBitmap(Bitmap paramBitmap) {
    ObjectsCompat.requireNonNull(paramBitmap);
    IconCompat iconCompat = new IconCompat(5);
    iconCompat.mObj1 = paramBitmap;
    return iconCompat;
  }
  
  public static IconCompat createWithAdaptiveBitmapContentUri(Uri paramUri) {
    ObjectsCompat.requireNonNull(paramUri);
    return createWithAdaptiveBitmapContentUri(paramUri.toString());
  }
  
  public static IconCompat createWithAdaptiveBitmapContentUri(String paramString) {
    ObjectsCompat.requireNonNull(paramString);
    IconCompat iconCompat = new IconCompat(6);
    iconCompat.mObj1 = paramString;
    return iconCompat;
  }
  
  public static IconCompat createWithBitmap(Bitmap paramBitmap) {
    ObjectsCompat.requireNonNull(paramBitmap);
    IconCompat iconCompat = new IconCompat(1);
    iconCompat.mObj1 = paramBitmap;
    return iconCompat;
  }
  
  public static IconCompat createWithContentUri(Uri paramUri) {
    ObjectsCompat.requireNonNull(paramUri);
    return createWithContentUri(paramUri.toString());
  }
  
  public static IconCompat createWithContentUri(String paramString) {
    ObjectsCompat.requireNonNull(paramString);
    IconCompat iconCompat = new IconCompat(4);
    iconCompat.mObj1 = paramString;
    return iconCompat;
  }
  
  public static IconCompat createWithData(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    ObjectsCompat.requireNonNull(paramArrayOfbyte);
    IconCompat iconCompat = new IconCompat(3);
    iconCompat.mObj1 = paramArrayOfbyte;
    iconCompat.mInt1 = paramInt1;
    iconCompat.mInt2 = paramInt2;
    return iconCompat;
  }
  
  public static IconCompat createWithResource(Context paramContext, int paramInt) {
    ObjectsCompat.requireNonNull(paramContext);
    return createWithResource(paramContext.getResources(), paramContext.getPackageName(), paramInt);
  }
  
  public static IconCompat createWithResource(Resources paramResources, String paramString, int paramInt) {
    ObjectsCompat.requireNonNull(paramString);
    if (paramInt != 0) {
      IconCompat iconCompat = new IconCompat(2);
      iconCompat.mInt1 = paramInt;
      if (paramResources != null)
        try {
          iconCompat.mObj1 = paramResources.getResourceName(paramInt);
          iconCompat.mString1 = paramString;
          return iconCompat;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw new IllegalArgumentException("Icon resource cannot be found");
        }  
      iconCompat.mObj1 = paramString;
      iconCompat.mString1 = paramString;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Drawable resource ID must not be 0");
  }
  
  static Resources getResources(Context paramContext, String paramString) {
    if ("android".equals(paramString))
      return Resources.getSystem(); 
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      ApplicationInfo applicationInfo = packageManager.getApplicationInfo(paramString, 8192);
      return (applicationInfo != null) ? packageManager.getResourcesForApplication(applicationInfo) : null;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("IconCompat", String.format("Unable to find pkg=%s for icon", new Object[] { paramString }), (Throwable)nameNotFoundException);
      return null;
    } 
  }
  
  private Drawable loadDrawableInner(Context paramContext) {
    InputStream inputStream;
    String str1;
    Resources resources;
    String str2;
    switch (this.mType) {
      default:
        return null;
      case 6:
        inputStream = getUriInputStream(paramContext);
        return (Drawable)((inputStream != null) ? ((Build.VERSION.SDK_INT >= 26) ? Api26Impl.createAdaptiveIconDrawable(null, (Drawable)new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeStream(inputStream))) : new BitmapDrawable(paramContext.getResources(), createLegacyIconFromAdaptiveIcon(BitmapFactory.decodeStream(inputStream), false))) : null);
      case 5:
        return (Drawable)new BitmapDrawable(paramContext.getResources(), createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, false));
      case 4:
        inputStream = getUriInputStream(paramContext);
        return (Drawable)((inputStream != null) ? new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeStream(inputStream)) : null);
      case 3:
        return (Drawable)new BitmapDrawable(paramContext.getResources(), BitmapFactory.decodeByteArray((byte[])this.mObj1, this.mInt1, this.mInt2));
      case 2:
        str2 = getResPackage();
        str1 = str2;
        if (TextUtils.isEmpty(str2))
          str1 = paramContext.getPackageName(); 
        resources = getResources(paramContext, str1);
        try {
          return ResourcesCompat.getDrawable(resources, this.mInt1, paramContext.getTheme());
        } catch (RuntimeException runtimeException) {
          Log.e("IconCompat", String.format("Unable to load resource 0x%08x from pkg=%s", new Object[] { Integer.valueOf(this.mInt1), this.mObj1 }), runtimeException);
          return null;
        } 
      case 1:
        break;
    } 
    return (Drawable)new BitmapDrawable(runtimeException.getResources(), (Bitmap)this.mObj1);
  }
  
  private static String typeToString(int paramInt) {
    switch (paramInt) {
      default:
        return "UNKNOWN";
      case 6:
        return "URI_MASKABLE";
      case 5:
        return "BITMAP_MASKABLE";
      case 4:
        return "URI";
      case 3:
        return "DATA";
      case 2:
        return "RESOURCE";
      case 1:
        break;
    } 
    return "BITMAP";
  }
  
  public void addToShortcutIntent(Intent paramIntent, Drawable paramDrawable, Context paramContext) {
    StringBuilder stringBuilder;
    Bitmap bitmap;
    checkResource(paramContext);
    int i = this.mType;
    if (i != 1) {
      if (i != 2) {
        if (i == 5) {
          bitmap = createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, true);
        } else {
          throw new IllegalArgumentException("Icon type not supported for intent shortcuts");
        } 
      } else {
        try {
          Bitmap bitmap1;
          Context context = bitmap.createPackageContext(getResPackage(), 0);
          if (paramDrawable == null) {
            paramIntent.putExtra("android.intent.extra.shortcut.ICON_RESOURCE", (Parcelable)Intent.ShortcutIconResource.fromContext(context, this.mInt1));
            return;
          } 
          Drawable drawable = ContextCompat.getDrawable(context, this.mInt1);
          if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            i = ((ActivityManager)context.getSystemService("activity")).getLauncherLargeIconSize();
            bitmap1 = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
          } else {
            bitmap1 = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
          } 
          drawable.setBounds(0, 0, bitmap1.getWidth(), bitmap1.getHeight());
          drawable.draw(new Canvas(bitmap1));
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          stringBuilder = new StringBuilder("Can't find package ");
          stringBuilder.append(this.mObj1);
          throw new IllegalArgumentException(stringBuilder.toString(), nameNotFoundException);
        } 
      } 
    } else {
      Bitmap bitmap1 = (Bitmap)this.mObj1;
      bitmap = bitmap1;
      if (stringBuilder != null)
        bitmap = bitmap1.copy(bitmap1.getConfig(), true); 
    } 
    if (stringBuilder != null) {
      i = bitmap.getWidth();
      int j = bitmap.getHeight();
      stringBuilder.setBounds(i / 2, j / 2, i, j);
      stringBuilder.draw(new Canvas(bitmap));
    } 
    nameNotFoundException.putExtra("android.intent.extra.shortcut.ICON", (Parcelable)bitmap);
  }
  
  public void checkResource(Context paramContext) {
    if (this.mType == 2) {
      Object object = this.mObj1;
      if (object != null) {
        object = object;
        if (!object.contains(":"))
          return; 
        String str2 = object.split(":", -1)[1];
        String str1 = str2.split("/", -1)[0];
        String str3 = str2.split("/", -1)[1];
        String str4 = object.split(":", -1)[0];
        if ("0_resource_name_obfuscated".equals(str3)) {
          Log.i("IconCompat", "Found obfuscated resource, not trying to update resource id for it");
          return;
        } 
        str2 = getResPackage();
        int i = getResources(paramContext, str2).getIdentifier(str3, str1, str4);
        if (this.mInt1 != i) {
          StringBuilder stringBuilder = new StringBuilder("Id has changed for ");
          stringBuilder.append(str2);
          stringBuilder.append(" ");
          stringBuilder.append((String)object);
          Log.i("IconCompat", stringBuilder.toString());
          this.mInt1 = i;
        } 
      } 
    } 
  }
  
  public Bitmap getBitmap() {
    if (this.mType == -1 && Build.VERSION.SDK_INT >= 23) {
      Object object = this.mObj1;
      return (object instanceof Bitmap) ? (Bitmap)object : null;
    } 
    int i = this.mType;
    if (i == 1)
      return (Bitmap)this.mObj1; 
    if (i == 5)
      return createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, true); 
    StringBuilder stringBuilder = new StringBuilder("called getBitmap() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int getResId() {
    if (this.mType == -1 && Build.VERSION.SDK_INT >= 23)
      return Api23Impl.getResId(this.mObj1); 
    if (this.mType == 2)
      return this.mInt1; 
    StringBuilder stringBuilder = new StringBuilder("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String getResPackage() {
    if (this.mType == -1 && Build.VERSION.SDK_INT >= 23)
      return Api23Impl.getResPackage(this.mObj1); 
    if (this.mType == 2) {
      String str = this.mString1;
      return (str == null || TextUtils.isEmpty(str)) ? ((String)this.mObj1).split(":", -1)[0] : this.mString1;
    } 
    StringBuilder stringBuilder = new StringBuilder("called getResPackage() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int getType() {
    return (this.mType == -1 && Build.VERSION.SDK_INT >= 23) ? Api23Impl.getType(this.mObj1) : this.mType;
  }
  
  public Uri getUri() {
    if (this.mType == -1 && Build.VERSION.SDK_INT >= 23)
      return Api23Impl.getUri(this.mObj1); 
    int i = this.mType;
    if (i == 4 || i == 6)
      return Uri.parse((String)this.mObj1); 
    StringBuilder stringBuilder = new StringBuilder("called getUri() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public InputStream getUriInputStream(Context paramContext) {
    Uri uri = getUri();
    String str = uri.getScheme();
    if ("content".equals(str) || "file".equals(str)) {
      try {
        return paramContext.getContentResolver().openInputStream(uri);
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder("Unable to load image from URI: ");
        stringBuilder.append(uri);
        Log.w("IconCompat", stringBuilder.toString(), exception);
      } 
      return null;
    } 
    try {
      return new FileInputStream(new File((String)this.mObj1));
    } catch (FileNotFoundException fileNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder("Unable to load image from path: ");
      stringBuilder.append(uri);
      Log.w("IconCompat", stringBuilder.toString(), fileNotFoundException);
    } 
    return null;
  }
  
  public Drawable loadDrawable(Context paramContext) {
    checkResource(paramContext);
    if (Build.VERSION.SDK_INT >= 23)
      return Api23Impl.loadDrawable(toIcon(paramContext), paramContext); 
    Drawable drawable = loadDrawableInner(paramContext);
    if (drawable != null && (this.mTintList != null || this.mTintMode != DEFAULT_TINT_MODE)) {
      drawable.mutate();
      DrawableCompat.setTintList(drawable, this.mTintList);
      DrawableCompat.setTintMode(drawable, this.mTintMode);
    } 
    return drawable;
  }
  
  public void onPostParceling() {
    String str;
    Parcelable parcelable2;
    byte[] arrayOfByte;
    this.mTintMode = PorterDuff.Mode.valueOf(this.mTintModeStr);
    switch (this.mType) {
      default:
        return;
      case 3:
        this.mObj1 = this.mData;
        return;
      case 2:
      case 4:
      case 6:
        str = new String(this.mData, Charset.forName("UTF-16"));
        this.mObj1 = str;
        if (this.mType == 2 && this.mString1 == null) {
          String str1 = str;
          this.mString1 = str.split(":", -1)[0];
          return;
        } 
        return;
      case 1:
      case 5:
        parcelable2 = this.mParcelable;
        if (parcelable2 != null) {
          this.mObj1 = parcelable2;
          return;
        } 
        arrayOfByte = this.mData;
        this.mObj1 = arrayOfByte;
        this.mType = 3;
        this.mInt1 = 0;
        this.mInt2 = arrayOfByte.length;
        return;
      case -1:
        break;
    } 
    Parcelable parcelable1 = this.mParcelable;
    if (parcelable1 != null) {
      this.mObj1 = parcelable1;
      return;
    } 
    throw new IllegalArgumentException("Invalid icon");
  }
  
  public void onPreParceling(boolean paramBoolean) {
    this.mTintModeStr = this.mTintMode.name();
    switch (this.mType) {
      default:
        return;
      case 4:
      case 6:
        this.mData = this.mObj1.toString().getBytes(Charset.forName("UTF-16"));
        return;
      case 3:
        this.mData = (byte[])this.mObj1;
        return;
      case 2:
        this.mData = ((String)this.mObj1).getBytes(Charset.forName("UTF-16"));
        return;
      case 1:
      case 5:
        if (paramBoolean) {
          Bitmap bitmap = (Bitmap)this.mObj1;
          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
          bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
          this.mData = byteArrayOutputStream.toByteArray();
          return;
        } 
        this.mParcelable = (Parcelable)this.mObj1;
        return;
      case -1:
        break;
    } 
    if (!paramBoolean) {
      this.mParcelable = (Parcelable)this.mObj1;
      return;
    } 
    throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
  }
  
  public IconCompat setTint(int paramInt) {
    return setTintList(ColorStateList.valueOf(paramInt));
  }
  
  public IconCompat setTintList(ColorStateList paramColorStateList) {
    this.mTintList = paramColorStateList;
    return this;
  }
  
  public IconCompat setTintMode(PorterDuff.Mode paramMode) {
    this.mTintMode = paramMode;
    return this;
  }
  
  public Bundle toBundle() {
    Bundle bundle = new Bundle();
    switch (this.mType) {
      default:
        throw new IllegalArgumentException("Invalid icon");
      case 3:
        bundle.putByteArray("obj", (byte[])this.mObj1);
        break;
      case 2:
      case 4:
      case 6:
        bundle.putString("obj", (String)this.mObj1);
        break;
      case 1:
      case 5:
        bundle.putParcelable("obj", (Parcelable)this.mObj1);
        break;
      case -1:
        bundle.putParcelable("obj", (Parcelable)this.mObj1);
        break;
    } 
    bundle.putInt("type", this.mType);
    bundle.putInt("int1", this.mInt1);
    bundle.putInt("int2", this.mInt2);
    bundle.putString("string1", this.mString1);
    ColorStateList colorStateList = this.mTintList;
    if (colorStateList != null)
      bundle.putParcelable("tint_list", (Parcelable)colorStateList); 
    PorterDuff.Mode mode = this.mTintMode;
    if (mode != DEFAULT_TINT_MODE)
      bundle.putString("tint_mode", mode.name()); 
    return bundle;
  }
  
  @Deprecated
  public Icon toIcon() {
    return toIcon(null);
  }
  
  public Icon toIcon(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 23)
      return Api23Impl.toIcon(this, paramContext); 
    throw new UnsupportedOperationException("This method is only supported on API level 23+");
  }
  
  public String toString() {
    if (this.mType == -1)
      return String.valueOf(this.mObj1); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    stringBuilder.append(typeToString(this.mType));
    switch (this.mType) {
      case 4:
      case 6:
        stringBuilder.append(" uri=");
        stringBuilder.append(this.mObj1);
        break;
      case 3:
        stringBuilder.append(" len=");
        stringBuilder.append(this.mInt1);
        if (this.mInt2 != 0) {
          stringBuilder.append(" off=");
          stringBuilder.append(this.mInt2);
        } 
        break;
      case 2:
        stringBuilder.append(" pkg=");
        stringBuilder.append(this.mString1);
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(getResId()) }));
        break;
      case 1:
      case 5:
        stringBuilder.append(" size=");
        stringBuilder.append(((Bitmap)this.mObj1).getWidth());
        stringBuilder.append("x");
        stringBuilder.append(((Bitmap)this.mObj1).getHeight());
        break;
    } 
    if (this.mTintList != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.mTintList);
    } 
    if (this.mTintMode != DEFAULT_TINT_MODE) {
      stringBuilder.append(" mode=");
      stringBuilder.append(this.mTintMode);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  static class Api23Impl {
    static IconCompat createFromIcon(Context param1Context, Icon param1Icon) {
      IconCompat iconCompat;
      int i = getType(param1Icon);
      if (i != 2) {
        if (i != 4) {
          if (i != 6) {
            iconCompat = new IconCompat(-1);
            iconCompat.mObj1 = param1Icon;
            return iconCompat;
          } 
          return IconCompat.createWithAdaptiveBitmapContentUri(getUri(param1Icon));
        } 
        return IconCompat.createWithContentUri(getUri(param1Icon));
      } 
      String str = getResPackage(param1Icon);
      try {
        return IconCompat.createWithResource(IconCompat.getResources((Context)iconCompat, str), str, getResId(param1Icon));
      } catch (android.content.res.Resources.NotFoundException notFoundException) {
        throw new IllegalArgumentException("Icon resource cannot be found");
      } 
    }
    
    static IconCompat createFromIconInner(Object param1Object) {
      Preconditions.checkNotNull(param1Object);
      int i = getType(param1Object);
      if (i != 2) {
        if (i != 4) {
          if (i != 6) {
            IconCompat iconCompat = new IconCompat(-1);
            iconCompat.mObj1 = param1Object;
            return iconCompat;
          } 
          return IconCompat.createWithAdaptiveBitmapContentUri(getUri(param1Object));
        } 
        return IconCompat.createWithContentUri(getUri(param1Object));
      } 
      return IconCompat.createWithResource(null, getResPackage(param1Object), getResId(param1Object));
    }
    
    static int getResId(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.Api28Impl.getResId(param1Object); 
      try {
        return ((Integer)param1Object.getClass().getMethod("getResId", new Class[0]).invoke(param1Object, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon resource", illegalAccessException);
        return 0;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon resource", invocationTargetException);
        return 0;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
        return 0;
      } 
    }
    
    static String getResPackage(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.Api28Impl.getResPackage(param1Object); 
      try {
        return (String)param1Object.getClass().getMethod("getResPackage", new Class[0]).invoke(param1Object, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon package", illegalAccessException);
        return null;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon package", invocationTargetException);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon package", noSuchMethodException);
        return null;
      } 
    }
    
    static int getType(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.Api28Impl.getType(param1Object); 
      try {
        return ((Integer)param1Object.getClass().getMethod("getType", new Class[0]).invoke(param1Object, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder = new StringBuilder("Unable to get icon type ");
        stringBuilder.append(param1Object);
        Log.e("IconCompat", stringBuilder.toString(), illegalAccessException);
        return -1;
      } catch (InvocationTargetException invocationTargetException) {
        StringBuilder stringBuilder = new StringBuilder("Unable to get icon type ");
        stringBuilder.append(param1Object);
        Log.e("IconCompat", stringBuilder.toString(), invocationTargetException);
        return -1;
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = new StringBuilder("Unable to get icon type ");
        stringBuilder.append(param1Object);
        Log.e("IconCompat", stringBuilder.toString(), noSuchMethodException);
        return -1;
      } 
    }
    
    static Uri getUri(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.Api28Impl.getUri(param1Object); 
      try {
        return (Uri)param1Object.getClass().getMethod("getUri", new Class[0]).invoke(param1Object, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon uri", illegalAccessException);
        return null;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon uri", invocationTargetException);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon uri", noSuchMethodException);
        return null;
      } 
    }
    
    static Drawable loadDrawable(Icon param1Icon, Context param1Context) {
      return param1Icon.loadDrawable(param1Context);
    }
    
    static Icon toIcon(IconCompat param1IconCompat, Context param1Context) {
      Icon icon2;
      StringBuilder stringBuilder;
      Icon icon1;
      switch (param1IconCompat.mType) {
        default:
          throw new IllegalArgumentException("Unknown type");
        case 6:
          if (Build.VERSION.SDK_INT >= 30) {
            icon2 = IconCompat.Api30Impl.createWithAdaptiveBitmapContentUri(param1IconCompat.getUri());
          } else if (icon2 != null) {
            InputStream inputStream = param1IconCompat.getUriInputStream((Context)icon2);
            if (inputStream != null) {
              if (Build.VERSION.SDK_INT >= 26) {
                icon1 = IconCompat.Api26Impl.createWithAdaptiveBitmap(BitmapFactory.decodeStream(inputStream));
              } else {
                icon1 = Icon.createWithBitmap(IconCompat.createLegacyIconFromAdaptiveIcon(BitmapFactory.decodeStream((InputStream)icon1), false));
              } 
            } else {
              stringBuilder = new StringBuilder("Cannot load adaptive icon from uri: ");
              stringBuilder.append(param1IconCompat.getUri());
              throw new IllegalStateException(stringBuilder.toString());
            } 
          } else {
            stringBuilder = new StringBuilder("Context is required to resolve the file uri of the icon: ");
            stringBuilder.append(param1IconCompat.getUri());
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
          if (param1IconCompat.mTintList != null)
            stringBuilder.setTintList(param1IconCompat.mTintList); 
          if (param1IconCompat.mTintMode != IconCompat.DEFAULT_TINT_MODE)
            stringBuilder.setTintMode(param1IconCompat.mTintMode); 
          return (Icon)stringBuilder;
        case 5:
          if (Build.VERSION.SDK_INT >= 26) {
            icon1 = IconCompat.Api26Impl.createWithAdaptiveBitmap((Bitmap)param1IconCompat.mObj1);
          } else {
            icon1 = Icon.createWithBitmap(IconCompat.createLegacyIconFromAdaptiveIcon((Bitmap)param1IconCompat.mObj1, false));
          } 
          if (param1IconCompat.mTintList != null)
            icon1.setTintList(param1IconCompat.mTintList); 
          if (param1IconCompat.mTintMode != IconCompat.DEFAULT_TINT_MODE)
            icon1.setTintMode(param1IconCompat.mTintMode); 
          return icon1;
        case 4:
          icon1 = Icon.createWithContentUri((String)param1IconCompat.mObj1);
          if (param1IconCompat.mTintList != null)
            icon1.setTintList(param1IconCompat.mTintList); 
          if (param1IconCompat.mTintMode != IconCompat.DEFAULT_TINT_MODE)
            icon1.setTintMode(param1IconCompat.mTintMode); 
          return icon1;
        case 3:
          icon1 = Icon.createWithData((byte[])param1IconCompat.mObj1, param1IconCompat.mInt1, param1IconCompat.mInt2);
          if (param1IconCompat.mTintList != null)
            icon1.setTintList(param1IconCompat.mTintList); 
          if (param1IconCompat.mTintMode != IconCompat.DEFAULT_TINT_MODE)
            icon1.setTintMode(param1IconCompat.mTintMode); 
          return icon1;
        case 2:
          icon1 = Icon.createWithResource(param1IconCompat.getResPackage(), param1IconCompat.mInt1);
          if (param1IconCompat.mTintList != null)
            icon1.setTintList(param1IconCompat.mTintList); 
          if (param1IconCompat.mTintMode != IconCompat.DEFAULT_TINT_MODE)
            icon1.setTintMode(param1IconCompat.mTintMode); 
          return icon1;
        case 1:
          icon1 = Icon.createWithBitmap((Bitmap)param1IconCompat.mObj1);
          if (param1IconCompat.mTintList != null)
            icon1.setTintList(param1IconCompat.mTintList); 
          if (param1IconCompat.mTintMode != IconCompat.DEFAULT_TINT_MODE)
            icon1.setTintMode(param1IconCompat.mTintMode); 
          return icon1;
        case -1:
          break;
      } 
      return (Icon)param1IconCompat.mObj1;
    }
  }
  
  static class Api26Impl {
    static Drawable createAdaptiveIconDrawable(Drawable param1Drawable1, Drawable param1Drawable2) {
      return (Drawable)new AdaptiveIconDrawable(param1Drawable1, param1Drawable2);
    }
    
    static Icon createWithAdaptiveBitmap(Bitmap param1Bitmap) {
      return Icon.createWithAdaptiveBitmap(param1Bitmap);
    }
  }
  
  static class Api28Impl {
    static int getResId(Object param1Object) {
      return ((Icon)param1Object).getResId();
    }
    
    static String getResPackage(Object param1Object) {
      return ((Icon)param1Object).getResPackage();
    }
    
    static int getType(Object param1Object) {
      return ((Icon)param1Object).getType();
    }
    
    static Uri getUri(Object param1Object) {
      return ((Icon)param1Object).getUri();
    }
  }
  
  static class Api30Impl {
    static Icon createWithAdaptiveBitmapContentUri(Uri param1Uri) {
      return Icon.createWithAdaptiveBitmapContentUri(param1Uri);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface IconType {}
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */