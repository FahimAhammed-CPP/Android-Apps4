package androidx.core.content;

import android.content.UriMatcher;
import android.net.Uri;
import androidx.core.util.Predicate;



/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\core\content\UriMatcherCompat$$ExternalSyntheticLambda0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */