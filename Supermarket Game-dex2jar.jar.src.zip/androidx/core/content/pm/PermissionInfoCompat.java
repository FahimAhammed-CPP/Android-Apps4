package androidx.core.content.pm;

import android.content.pm.PermissionInfo;
import android.os.Build;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class PermissionInfoCompat {
  public static int getProtection(PermissionInfo paramPermissionInfo) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getProtection(paramPermissionInfo) : (paramPermissionInfo.protectionLevel & 0xF);
  }
  
  public static int getProtectionFlags(PermissionInfo paramPermissionInfo) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getProtectionFlags(paramPermissionInfo) : (paramPermissionInfo.protectionLevel & 0xFFFFFFF0);
  }
  
  static class Api28Impl {
    static int getProtection(PermissionInfo param1PermissionInfo) {
      return param1PermissionInfo.getProtection();
    }
    
    static int getProtectionFlags(PermissionInfo param1PermissionInfo) {
      return param1PermissionInfo.getProtectionFlags();
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Protection {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ProtectionFlags {}
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\core\content\pm\PermissionInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */