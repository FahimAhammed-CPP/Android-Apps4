package androidx.core.content;

import android.content.ClipData;
import androidx.core.util.Predicate;



/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\core\content\IntentSanitizer$Builder$$ExternalSyntheticLambda18.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */