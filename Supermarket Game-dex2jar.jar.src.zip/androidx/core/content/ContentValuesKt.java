package androidx.core.content;

import android.content.ContentValues;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\034\n\000\n\002\030\002\n\000\n\002\020\021\n\002\030\002\n\002\020\016\n\002\020\000\n\002\b\002\032;\020\000\032\0020\0012.\020\002\032\030\022\024\b\001\022\020\022\004\022\0020\005\022\006\022\004\030\0010\0060\0040\003\"\020\022\004\022\0020\005\022\006\022\004\030\0010\0060\004¢\006\002\020\007¨\006\b"}, d2 = {"contentValuesOf", "Landroid/content/ContentValues;", "pairs", "", "Lkotlin/Pair;", "", "", "([Lkotlin/Pair;)Landroid/content/ContentValues;", "core-ktx_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class ContentValuesKt {
  public static final ContentValues contentValuesOf(Pair<String, ? extends Object>... paramVarArgs) {
    StringBuilder stringBuilder;
    Intrinsics.checkNotNullParameter(paramVarArgs, "pairs");
    ContentValues contentValues = new ContentValues(paramVarArgs.length);
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      Pair<String, ? extends Object> pair = paramVarArgs[i];
      String str = (String)pair.component1();
      Object object = pair.component2();
      if (object == null) {
        contentValues.putNull(str);
      } else if (object instanceof String) {
        contentValues.put(str, (String)object);
      } else if (object instanceof Integer) {
        contentValues.put(str, (Integer)object);
      } else if (object instanceof Long) {
        contentValues.put(str, (Long)object);
      } else if (object instanceof Boolean) {
        contentValues.put(str, (Boolean)object);
      } else if (object instanceof Float) {
        contentValues.put(str, (Float)object);
      } else if (object instanceof Double) {
        contentValues.put(str, (Double)object);
      } else if (object instanceof byte[]) {
        contentValues.put(str, (byte[])object);
      } else if (object instanceof Byte) {
        contentValues.put(str, (Byte)object);
      } else if (object instanceof Short) {
        contentValues.put(str, (Short)object);
      } else {
        String str1 = object.getClass().getCanonicalName();
        stringBuilder = new StringBuilder("Illegal value type ");
        stringBuilder.append(str1);
        stringBuilder.append(" for key \"");
        stringBuilder.append(str);
        stringBuilder.append('"');
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return (ContentValues)stringBuilder;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\core\content\ContentValuesKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */