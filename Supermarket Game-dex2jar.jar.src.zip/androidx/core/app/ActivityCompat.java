package androidx.core.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentSender;
import android.content.LocusId;
import android.content.pm.PackageManager;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.Display;
import android.view.DragEvent;
import android.view.View;
import androidx.core.content.ContextCompat;
import androidx.core.content.LocusIdCompat;
import androidx.core.os.BuildCompat;
import androidx.core.view.DragAndDropPermissionsCompat;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class ActivityCompat extends ContextCompat {
  private static PermissionCompatDelegate sDelegate;
  
  public static void finishAffinity(Activity paramActivity) {
    Api16Impl.finishAffinity(paramActivity);
  }
  
  public static void finishAfterTransition(Activity paramActivity) {
    Api21Impl.finishAfterTransition(paramActivity);
  }
  
  public static PermissionCompatDelegate getPermissionCompatDelegate() {
    return sDelegate;
  }
  
  public static Uri getReferrer(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 22)
      return Api22Impl.getReferrer(paramActivity); 
    Intent intent = paramActivity.getIntent();
    Uri uri = (Uri)intent.getParcelableExtra("android.intent.extra.REFERRER");
    if (uri != null)
      return uri; 
    String str = intent.getStringExtra("android.intent.extra.REFERRER_NAME");
    return (str != null) ? Uri.parse(str) : null;
  }
  
  @Deprecated
  public static boolean invalidateOptionsMenu(Activity paramActivity) {
    paramActivity.invalidateOptionsMenu();
    return true;
  }
  
  public static boolean isLaunchedFromBubble(Activity paramActivity) {
    return (Build.VERSION.SDK_INT >= 31) ? Api31Impl.isLaunchedFromBubble(paramActivity) : ((Build.VERSION.SDK_INT == 30) ? ((Api30Impl.getDisplay((ContextWrapper)paramActivity) != null && Api30Impl.getDisplay((ContextWrapper)paramActivity).getDisplayId() != 0)) : ((Build.VERSION.SDK_INT == 29) ? ((paramActivity.getWindowManager().getDefaultDisplay() != null && paramActivity.getWindowManager().getDefaultDisplay().getDisplayId() != 0)) : false));
  }
  
  public static void postponeEnterTransition(Activity paramActivity) {
    Api21Impl.postponeEnterTransition(paramActivity);
  }
  
  public static void recreate(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 28) {
      paramActivity.recreate();
      return;
    } 
    (new Handler(paramActivity.getMainLooper())).post(new ActivityCompat$$ExternalSyntheticLambda0(paramActivity));
  }
  
  public static DragAndDropPermissionsCompat requestDragAndDropPermissions(Activity paramActivity, DragEvent paramDragEvent) {
    return DragAndDropPermissionsCompat.request(paramActivity, paramDragEvent);
  }
  
  public static void requestPermissions(Activity paramActivity, String[] paramArrayOfString, final int requestCode) {
    final StringBuilder activity;
    final String[] permissionsArray;
    PermissionCompatDelegate permissionCompatDelegate = sDelegate;
    if (permissionCompatDelegate != null && permissionCompatDelegate.requestPermissions(paramActivity, paramArrayOfString, requestCode))
      return; 
    HashSet<Integer> hashSet = new HashSet();
    int j = 0;
    int i = 0;
    while (i < paramArrayOfString.length) {
      if (!TextUtils.isEmpty(paramArrayOfString[i])) {
        if (!BuildCompat.isAtLeastT() && TextUtils.equals(paramArrayOfString[i], "android.permission.POST_NOTIFICATIONS"))
          hashSet.add(Integer.valueOf(i)); 
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder("Permission request for permissions ");
      stringBuilder.append(Arrays.toString((Object[])paramArrayOfString));
      stringBuilder.append(" must not contain null or empty values");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    i = hashSet.size();
    if (i > 0) {
      arrayOfString = new String[paramArrayOfString.length - i];
    } else {
      arrayOfString = paramArrayOfString;
    } 
    if (i > 0) {
      if (i == paramArrayOfString.length)
        return; 
      int k = 0;
      i = j;
      while (i < paramArrayOfString.length) {
        j = k;
        if (!hashSet.contains(Integer.valueOf(i))) {
          arrayOfString[k] = paramArrayOfString[i];
          j = k + 1;
        } 
        i++;
        k = j;
      } 
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      if (stringBuilder instanceof RequestPermissionsRequestCodeValidator)
        ((RequestPermissionsRequestCodeValidator)stringBuilder).validateRequestPermissionsRequestCode(requestCode); 
      Api23Impl.requestPermissions((Activity)stringBuilder, paramArrayOfString, requestCode);
      return;
    } 
    if (stringBuilder instanceof OnRequestPermissionsResultCallback)
      (new Handler(Looper.getMainLooper())).post(new Runnable() {
            public void run() {
              int[] arrayOfInt = new int[permissionsArray.length];
              PackageManager packageManager = activity.getPackageManager();
              String str = activity.getPackageName();
              int j = permissionsArray.length;
              for (int i = 0; i < j; i++)
                arrayOfInt[i] = packageManager.checkPermission(permissionsArray[i], str); 
              ((ActivityCompat.OnRequestPermissionsResultCallback)activity).onRequestPermissionsResult(requestCode, permissionsArray, arrayOfInt);
            }
          }); 
  }
  
  public static <T extends View> T requireViewById(Activity paramActivity, int paramInt) {
    if (Build.VERSION.SDK_INT >= 28)
      return (T)Api28Impl.<View>requireViewById(paramActivity, paramInt); 
    View view = paramActivity.findViewById(paramInt);
    if (view != null)
      return (T)view; 
    throw new IllegalArgumentException("ID does not reference a View inside this Activity");
  }
  
  public static void setEnterSharedElementCallback(Activity paramActivity, SharedElementCallback paramSharedElementCallback) {
    if (paramSharedElementCallback != null) {
      SharedElementCallback21Impl sharedElementCallback21Impl = new SharedElementCallback21Impl(paramSharedElementCallback);
    } else {
      paramSharedElementCallback = null;
    } 
    Api21Impl.setEnterSharedElementCallback(paramActivity, (SharedElementCallback)paramSharedElementCallback);
  }
  
  public static void setExitSharedElementCallback(Activity paramActivity, SharedElementCallback paramSharedElementCallback) {
    if (paramSharedElementCallback != null) {
      SharedElementCallback21Impl sharedElementCallback21Impl = new SharedElementCallback21Impl(paramSharedElementCallback);
    } else {
      paramSharedElementCallback = null;
    } 
    Api21Impl.setExitSharedElementCallback(paramActivity, (SharedElementCallback)paramSharedElementCallback);
  }
  
  public static void setLocusContext(Activity paramActivity, LocusIdCompat paramLocusIdCompat, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 30)
      Api30Impl.setLocusContext(paramActivity, paramLocusIdCompat, paramBundle); 
  }
  
  public static void setPermissionCompatDelegate(PermissionCompatDelegate paramPermissionCompatDelegate) {
    sDelegate = paramPermissionCompatDelegate;
  }
  
  public static boolean shouldShowRequestPermissionRationale(Activity paramActivity, String paramString) {
    return (!BuildCompat.isAtLeastT() && TextUtils.equals("android.permission.POST_NOTIFICATIONS", paramString)) ? false : ((Build.VERSION.SDK_INT >= 23) ? Api23Impl.shouldShowRequestPermissionRationale(paramActivity, paramString) : false);
  }
  
  public static void startActivityForResult(Activity paramActivity, Intent paramIntent, int paramInt, Bundle paramBundle) {
    Api16Impl.startActivityForResult(paramActivity, paramIntent, paramInt, paramBundle);
  }
  
  public static void startIntentSenderForResult(Activity paramActivity, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    Api16Impl.startIntentSenderForResult(paramActivity, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public static void startPostponedEnterTransition(Activity paramActivity) {
    Api21Impl.startPostponedEnterTransition(paramActivity);
  }
  
  static class Api16Impl {
    static void finishAffinity(Activity param1Activity) {
      param1Activity.finishAffinity();
    }
    
    static void startActivityForResult(Activity param1Activity, Intent param1Intent, int param1Int, Bundle param1Bundle) {
      param1Activity.startActivityForResult(param1Intent, param1Int, param1Bundle);
    }
    
    static void startIntentSenderForResult(Activity param1Activity, IntentSender param1IntentSender, int param1Int1, Intent param1Intent, int param1Int2, int param1Int3, int param1Int4, Bundle param1Bundle) throws IntentSender.SendIntentException {
      param1Activity.startIntentSenderForResult(param1IntentSender, param1Int1, param1Intent, param1Int2, param1Int3, param1Int4, param1Bundle);
    }
  }
  
  static class Api21Impl {
    static void finishAfterTransition(Activity param1Activity) {
      param1Activity.finishAfterTransition();
    }
    
    static void postponeEnterTransition(Activity param1Activity) {
      param1Activity.postponeEnterTransition();
    }
    
    static void setEnterSharedElementCallback(Activity param1Activity, SharedElementCallback param1SharedElementCallback) {
      param1Activity.setEnterSharedElementCallback(param1SharedElementCallback);
    }
    
    static void setExitSharedElementCallback(Activity param1Activity, SharedElementCallback param1SharedElementCallback) {
      param1Activity.setExitSharedElementCallback(param1SharedElementCallback);
    }
    
    static void startPostponedEnterTransition(Activity param1Activity) {
      param1Activity.startPostponedEnterTransition();
    }
  }
  
  static class Api22Impl {
    static Uri getReferrer(Activity param1Activity) {
      return param1Activity.getReferrer();
    }
  }
  
  static class Api23Impl {
    static void onSharedElementsReady(Object param1Object) {
      ((SharedElementCallback.OnSharedElementsReadyListener)param1Object).onSharedElementsReady();
    }
    
    static void requestPermissions(Activity param1Activity, String[] param1ArrayOfString, int param1Int) {
      param1Activity.requestPermissions(param1ArrayOfString, param1Int);
    }
    
    static boolean shouldShowRequestPermissionRationale(Activity param1Activity, String param1String) {
      return param1Activity.shouldShowRequestPermissionRationale(param1String);
    }
  }
  
  static class Api28Impl {
    static <T> T requireViewById(Activity param1Activity, int param1Int) {
      return (T)param1Activity.requireViewById(param1Int);
    }
  }
  
  static class Api30Impl {
    static Display getDisplay(ContextWrapper param1ContextWrapper) {
      return param1ContextWrapper.getDisplay();
    }
    
    static void setLocusContext(Activity param1Activity, LocusIdCompat param1LocusIdCompat, Bundle param1Bundle) {
      LocusId locusId;
      if (param1LocusIdCompat == null) {
        param1LocusIdCompat = null;
      } else {
        locusId = param1LocusIdCompat.toLocusId();
      } 
      param1Activity.setLocusContext(locusId, param1Bundle);
    }
  }
  
  static class Api31Impl {
    static boolean isLaunchedFromBubble(Activity param1Activity) {
      return param1Activity.isLaunchedFromBubble();
    }
  }
  
  public static interface OnRequestPermissionsResultCallback {
    void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
  }
  
  public static interface PermissionCompatDelegate {
    boolean onActivityResult(Activity param1Activity, int param1Int1, int param1Int2, Intent param1Intent);
    
    boolean requestPermissions(Activity param1Activity, String[] param1ArrayOfString, int param1Int);
  }
  
  public static interface RequestPermissionsRequestCodeValidator {
    void validateRequestPermissionsRequestCode(int param1Int);
  }
  
  static class SharedElementCallback21Impl extends SharedElementCallback {
    private final SharedElementCallback mCallback;
    
    SharedElementCallback21Impl(SharedElementCallback param1SharedElementCallback) {
      this.mCallback = param1SharedElementCallback;
    }
    
    public Parcelable onCaptureSharedElementSnapshot(View param1View, Matrix param1Matrix, RectF param1RectF) {
      return this.mCallback.onCaptureSharedElementSnapshot(param1View, param1Matrix, param1RectF);
    }
    
    public View onCreateSnapshotView(Context param1Context, Parcelable param1Parcelable) {
      return this.mCallback.onCreateSnapshotView(param1Context, param1Parcelable);
    }
    
    public void onMapSharedElements(List<String> param1List, Map<String, View> param1Map) {
      this.mCallback.onMapSharedElements(param1List, param1Map);
    }
    
    public void onRejectSharedElements(List<View> param1List) {
      this.mCallback.onRejectSharedElements(param1List);
    }
    
    public void onSharedElementEnd(List<String> param1List, List<View> param1List1, List<View> param1List2) {
      this.mCallback.onSharedElementEnd(param1List, param1List1, param1List2);
    }
    
    public void onSharedElementStart(List<String> param1List, List<View> param1List1, List<View> param1List2) {
      this.mCallback.onSharedElementStart(param1List, param1List1, param1List2);
    }
    
    public void onSharedElementsArrived(List<String> param1List, List<View> param1List1, SharedElementCallback.OnSharedElementsReadyListener param1OnSharedElementsReadyListener) {
      this.mCallback.onSharedElementsArrived(param1List, param1List1, new ActivityCompat$SharedElementCallback21Impl$$ExternalSyntheticLambda0(param1OnSharedElementsReadyListener));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\core\app\ActivityCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */