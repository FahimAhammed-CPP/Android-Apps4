package androidx.core.app.unusedapprestrictions;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IUnusedAppRestrictionsBackportService extends IInterface {
  public static final String DESCRIPTOR = "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService";
  
  void isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback paramIUnusedAppRestrictionsBackportCallback) throws RemoteException;
  
  public static class Default implements IUnusedAppRestrictionsBackportService {
    public IBinder asBinder() {
      return null;
    }
    
    public void isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback param1IUnusedAppRestrictionsBackportCallback) throws RemoteException {}
  }
  
  public static abstract class Stub extends Binder implements IUnusedAppRestrictionsBackportService {
    static final int TRANSACTION_isPermissionRevocationEnabledForApp = 1;
    
    public Stub() {
      attachInterface(this, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService");
    }
    
    public static IUnusedAppRestrictionsBackportService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService");
      return (iInterface != null && iInterface instanceof IUnusedAppRestrictionsBackportService) ? (IUnusedAppRestrictionsBackportService)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface("androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService"); 
      if (param1Int1 != 1598968902) {
        if (param1Int1 != 1)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback.Stub.asInterface(param1Parcel1.readStrongBinder()));
        return true;
      } 
      param1Parcel2.writeString("androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService");
      return true;
    }
    
    private static class Proxy implements IUnusedAppRestrictionsBackportService {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor() {
        return "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService";
      }
      
      public void isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback param2IUnusedAppRestrictionsBackportCallback) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService");
          parcel.writeStrongInterface(param2IUnusedAppRestrictionsBackportCallback);
          this.mRemote.transact(1, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IUnusedAppRestrictionsBackportService {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public String getInterfaceDescriptor() {
      return "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService";
    }
    
    public void isPermissionRevocationEnabledForApp(IUnusedAppRestrictionsBackportCallback param1IUnusedAppRestrictionsBackportCallback) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService");
        parcel.writeStrongInterface(param1IUnusedAppRestrictionsBackportCallback);
        this.mRemote.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\core\ap\\unusedapprestrictions\IUnusedAppRestrictionsBackportService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */