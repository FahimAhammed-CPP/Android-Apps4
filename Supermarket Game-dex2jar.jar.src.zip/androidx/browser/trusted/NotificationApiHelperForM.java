package androidx.browser.trusted;

import android.app.NotificationManager;
import android.os.Parcelable;

public class NotificationApiHelperForM {
  static Parcelable[] getActiveNotifications(NotificationManager paramNotificationManager) {
    return (Parcelable[])paramNotificationManager.getActiveNotifications();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\browser\trusted\NotificationApiHelperForM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */