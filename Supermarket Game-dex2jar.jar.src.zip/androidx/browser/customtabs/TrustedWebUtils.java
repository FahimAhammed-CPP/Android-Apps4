package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.core.app.BundleCompat;
import androidx.core.content.FileProvider;
import java.io.File;

public class TrustedWebUtils {
  public static final String ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA = "android.support.customtabs.action.ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA";
  
  public static final String EXTRA_LAUNCH_AS_TRUSTED_WEB_ACTIVITY = "android.support.customtabs.extra.LAUNCH_AS_TRUSTED_WEB_ACTIVITY";
  
  public static boolean areSplashScreensSupported(Context paramContext, String paramString1, String paramString2) {
    Intent intent = (new Intent()).setAction("android.support.customtabs.action.CustomTabsService").setPackage(paramString1);
    ResolveInfo resolveInfo = paramContext.getPackageManager().resolveService(intent, 64);
    return (resolveInfo == null || resolveInfo.filter == null) ? false : resolveInfo.filter.hasCategory(paramString2);
  }
  
  @Deprecated
  public static void launchAsTrustedWebActivity(Context paramContext, CustomTabsIntent paramCustomTabsIntent, Uri paramUri) {
    if (BundleCompat.getBinder(paramCustomTabsIntent.intent.getExtras(), "android.support.customtabs.extra.SESSION") != null) {
      paramCustomTabsIntent.intent.putExtra("android.support.customtabs.extra.LAUNCH_AS_TRUSTED_WEB_ACTIVITY", true);
      paramCustomTabsIntent.launchUrl(paramContext, paramUri);
      return;
    } 
    throw new IllegalArgumentException("Given CustomTabsIntent should be associated with a valid CustomTabsSession");
  }
  
  public static void launchBrowserSiteSettings(Context paramContext, CustomTabsSession paramCustomTabsSession, Uri paramUri) {
    Intent intent = new Intent("android.support.customtabs.action.ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA");
    intent.setPackage(paramCustomTabsSession.getComponentName().getPackageName());
    intent.setData(paramUri);
    Bundle bundle = new Bundle();
    BundleCompat.putBinder(bundle, "android.support.customtabs.extra.SESSION", paramCustomTabsSession.getBinder());
    intent.putExtras(bundle);
    PendingIntent pendingIntent = paramCustomTabsSession.getId();
    if (pendingIntent != null)
      intent.putExtra("android.support.customtabs.extra.SESSION_ID", (Parcelable)pendingIntent); 
    paramContext.startActivity(intent);
  }
  
  public static boolean transferSplashImage(Context paramContext, File paramFile, String paramString1, String paramString2, CustomTabsSession paramCustomTabsSession) {
    Uri uri = FileProvider.getUriForFile(paramContext, paramString1, paramFile);
    paramContext.grantUriPermission(paramString2, uri, 1);
    return paramCustomTabsSession.receiveFile(uri, 1, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\browser\customtabs\TrustedWebUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */