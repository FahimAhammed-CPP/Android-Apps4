package androidx.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import kotlin.Metadata;
import kotlin.annotation.AnnotationRetention;
import kotlin.annotation.AnnotationTarget;
import kotlin.annotation.Retention;
import kotlin.annotation.Target;

@Retention(RetentionPolicy.SOURCE)
@Target({ElementType.ANNOTATION_TYPE})
@Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\033\n\000\n\002\020\021\n\002\020\016\n\000\n\002\020\013\n\002\b\003\b\002\030\0002\0020\001B \022\024\b\002\020\002\032\n\022\006\b\001\022\0020\0040\003\"\0020\004\022\b\b\002\020\005\032\0020\006R\017\020\005\032\0020\006¢\006\006\032\004\b\005\020\007R\027\020\002\032\n\022\006\b\001\022\0020\0040\003¢\006\006\032\004\b\002\020\b¨\006\t"}, d2 = {"Landroidx/annotation/StringDef;", "", "value", "", "", "open", "", "()Z", "()[Ljava/lang/String;", "annotation"}, k = 1, mv = {1, 7, 1}, xi = 48)
@Retention(AnnotationRetention.SOURCE)
@Target(allowedTargets = {AnnotationTarget.ANNOTATION_CLASS})
public @interface StringDef {
  boolean open() default false;
  
  String[] value() default {};
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\annotation\StringDef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */