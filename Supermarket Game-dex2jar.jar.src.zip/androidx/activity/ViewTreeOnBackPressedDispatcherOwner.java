package androidx.activity;

import android.view.View;
import android.view.ViewParent;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.sequences.SequencesKt;

@Metadata(d1 = {"\000\026\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\032\023\020\000\032\004\030\0010\001*\0020\002H\007¢\006\002\b\003\032\031\020\004\032\0020\005*\0020\0022\006\020\006\032\0020\001H\007¢\006\002\b\007¨\006\b"}, d2 = {"findViewTreeOnBackPressedDispatcherOwner", "Landroidx/activity/OnBackPressedDispatcherOwner;", "Landroid/view/View;", "get", "setViewTreeOnBackPressedDispatcherOwner", "", "onBackPressedDispatcherOwner", "set", "activity_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class ViewTreeOnBackPressedDispatcherOwner {
  public static final OnBackPressedDispatcherOwner get(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    return (OnBackPressedDispatcherOwner)SequencesKt.firstOrNull(SequencesKt.mapNotNull(SequencesKt.generateSequence(paramView, ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$1.INSTANCE), ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2.INSTANCE));
  }
  
  public static final void set(View paramView, OnBackPressedDispatcherOwner paramOnBackPressedDispatcherOwner) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramOnBackPressedDispatcherOwner, "onBackPressedDispatcherOwner");
    paramView.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, paramOnBackPressedDispatcherOwner);
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\030\002\n\002\b\002\020\000\032\004\030\0010\0012\006\020\002\032\0020\001H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "Landroid/view/View;", "it", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$1 extends Lambda implements Function1<View, View> {
    public static final ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$1 INSTANCE = new ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$1();
    
    ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$1() {
      super(1);
    }
    
    public final View invoke(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "it");
      ViewParent viewParent = param1View.getParent();
      return (viewParent instanceof View) ? (View)viewParent : null;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/activity/OnBackPressedDispatcherOwner;", "it", "Landroid/view/View;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2 extends Lambda implements Function1<View, OnBackPressedDispatcherOwner> {
    public static final ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2 INSTANCE = new ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2();
    
    ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2() {
      super(1);
    }
    
    public final OnBackPressedDispatcherOwner invoke(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "it");
      Object object = param1View.getTag(R.id.view_tree_on_back_pressed_dispatcher_owner);
      return (object instanceof OnBackPressedDispatcherOwner) ? (OnBackPressedDispatcherOwner)object : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\activity\ViewTreeOnBackPressedDispatcherOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */