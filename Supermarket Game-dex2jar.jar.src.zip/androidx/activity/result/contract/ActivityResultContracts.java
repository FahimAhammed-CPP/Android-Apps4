package androidx.activity.result.contract;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.os.ext.SdkExtensions;
import android.provider.MediaStore;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.ReplaceWith;
import kotlin.TuplesKt;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\024\030\0002\0020\001:\022\003\004\005\006\007\b\t\n\013\f\r\016\017\020\021\022\023\024B\007\b\002¢\006\002\020\002¨\006\025"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts;", "", "()V", "Api33Impl", "CaptureVideo", "CreateDocument", "GetContent", "GetMultipleContents", "OpenDocument", "OpenDocumentTree", "OpenMultipleDocuments", "PickContact", "PickMultipleVisualMedia", "PickVisualMedia", "RequestMultiplePermissions", "RequestPermission", "StartActivityForResult", "StartIntentSenderForResult", "TakePicture", "TakePicturePreview", "TakeVideo", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class ActivityResultContracts {
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\bÁ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\003\032\0020\004H\007¨\006\005"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$Api33Impl;", "", "()V", "getPickImagesMaxLimit", "", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Api33Impl {
    public static final Api33Impl INSTANCE = new Api33Impl();
    
    public final int getPickImagesMaxLimit() {
      return MediaStore.getPickImagesMaxLimit();
    }
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\b\026\030\0002\016\022\004\022\0020\002\022\004\022\0020\0030\001B\005¢\006\002\020\004J\030\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\002H\027J\036\020\n\032\n\022\004\022\0020\003\030\0010\0132\006\020\007\032\0020\b2\006\020\t\032\0020\002J\035\020\f\032\0020\0032\006\020\r\032\0020\0162\b\020\017\032\004\030\0010\006¢\006\002\020\020¨\006\021"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$CaptureVideo;", "Landroidx/activity/result/contract/ActivityResultContract;", "Landroid/net/Uri;", "", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "(ILandroid/content/Intent;)Ljava/lang/Boolean;", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class CaptureVideo extends ActivityResultContract<Uri, Boolean> {
    public Intent createIntent(Context param1Context, Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1Uri, "input");
      Intent intent = (new Intent("android.media.action.VIDEO_CAPTURE")).putExtra("output", (Parcelable)param1Uri);
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(MediaStore.ACTION…tore.EXTRA_OUTPUT, input)");
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<Boolean> getSynchronousResult(Context param1Context, Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1Uri, "input");
      return null;
    }
    
    public final Boolean parseResult(int param1Int, Intent param1Intent) {
      boolean bool;
      if (param1Int == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return Boolean.valueOf(bool);
    }
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\020\016\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\b\027\030\0002\020\022\004\022\0020\002\022\006\022\004\030\0010\0030\001B\007\b\027¢\006\002\020\004B\r\022\006\020\005\032\0020\002¢\006\002\020\006J\030\020\007\032\0020\b2\006\020\t\032\0020\n2\006\020\013\032\0020\002H\027J \020\f\032\f\022\006\022\004\030\0010\003\030\0010\r2\006\020\t\032\0020\n2\006\020\013\032\0020\002J\032\020\016\032\004\030\0010\0032\006\020\017\032\0020\0202\b\020\021\032\004\030\0010\bR\016\020\005\032\0020\002X\004¢\006\002\n\000¨\006\022"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$CreateDocument;", "Landroidx/activity/result/contract/ActivityResultContract;", "", "Landroid/net/Uri;", "()V", "mimeType", "(Ljava/lang/String;)V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class CreateDocument extends ActivityResultContract<String, Uri> {
    private final String mimeType;
    
    @Deprecated(message = "Using a wildcard mime type with CreateDocument is not recommended as it breaks the automatic handling of file extensions. Instead, specify the mime type by using the constructor that takes an concrete mime type (e.g.., CreateDocument(\"image/png\")).", replaceWith = @ReplaceWith(expression = "CreateDocument(\"todo/todo\")", imports = {}))
    public CreateDocument() {
      this("*/*");
    }
    
    public CreateDocument(String param1String) {
      this.mimeType = param1String;
    }
    
    public Intent createIntent(Context param1Context, String param1String) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1String, "input");
      Intent intent = (new Intent("android.intent.action.CREATE_DOCUMENT")).setType(this.mimeType).putExtra("android.intent.extra.TITLE", param1String);
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(Intent.ACTION_CRE…ntent.EXTRA_TITLE, input)");
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<Uri> getSynchronousResult(Context param1Context, String param1String) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1String, "input");
      return null;
    }
    
    public final Uri parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      Uri uri = null;
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null)
        uri = param1Intent.getData(); 
      return uri;
    }
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\020\016\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\b\026\030\0002\020\022\004\022\0020\002\022\006\022\004\030\0010\0030\001B\005¢\006\002\020\004J\030\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\002H\027J \020\n\032\f\022\006\022\004\030\0010\003\030\0010\0132\006\020\007\032\0020\b2\006\020\t\032\0020\002J\032\020\f\032\004\030\0010\0032\006\020\r\032\0020\0162\b\020\017\032\004\030\0010\006¨\006\020"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$GetContent;", "Landroidx/activity/result/contract/ActivityResultContract;", "", "Landroid/net/Uri;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class GetContent extends ActivityResultContract<String, Uri> {
    public Intent createIntent(Context param1Context, String param1String) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1String, "input");
      Intent intent = (new Intent("android.intent.action.GET_CONTENT")).addCategory("android.intent.category.OPENABLE").setType(param1String);
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(Intent.ACTION_GET…          .setType(input)");
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<Uri> getSynchronousResult(Context param1Context, String param1String) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1String, "input");
      return null;
    }
    
    public final Uri parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      Uri uri = null;
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null)
        uri = param1Intent.getData(); 
      return uri;
    }
  }
  
  @Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\020\016\n\002\020 \n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\b\027\030\000 \0222\031\022\004\022\0020\002\022\017\022\r\022\t\022\0070\004¢\006\002\b\0050\0030\001:\001\022B\005¢\006\002\020\006J\030\020\007\032\0020\b2\006\020\t\032\0020\n2\006\020\013\032\0020\002H\027J$\020\f\032\020\022\n\022\b\022\004\022\0020\0040\003\030\0010\r2\006\020\t\032\0020\n2\006\020\013\032\0020\002J\036\020\016\032\b\022\004\022\0020\0040\0032\006\020\017\032\0020\0202\b\020\021\032\004\030\0010\b¨\006\023"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$GetMultipleContents;", "Landroidx/activity/result/contract/ActivityResultContract;", "", "", "Landroid/net/Uri;", "Lkotlin/jvm/JvmSuppressWildcards;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "Companion", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class GetMultipleContents extends ActivityResultContract<String, List<Uri>> {
    public static final Companion Companion = new Companion(null);
    
    public Intent createIntent(Context param1Context, String param1String) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1String, "input");
      Intent intent = (new Intent("android.intent.action.GET_CONTENT")).addCategory("android.intent.category.OPENABLE").setType(param1String).putExtra("android.intent.extra.ALLOW_MULTIPLE", true);
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(Intent.ACTION_GET…TRA_ALLOW_MULTIPLE, true)");
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<List<Uri>> getSynchronousResult(Context param1Context, String param1String) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1String, "input");
      return null;
    }
    
    public final List<Uri> parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null) {
        List<Uri> list = Companion.getClipDataUris$activity_release(param1Intent);
        if (list != null)
          return list; 
      } 
      return CollectionsKt.emptyList();
    }
    
    @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020 \n\002\030\002\n\002\030\002\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\027\020\003\032\b\022\004\022\0020\0050\004*\0020\006H\000¢\006\002\b\007¨\006\b"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$GetMultipleContents$Companion;", "", "()V", "getClipDataUris", "", "Landroid/net/Uri;", "Landroid/content/Intent;", "getClipDataUris$activity_release", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class Companion {
      private Companion() {}
      
      public final List<Uri> getClipDataUris$activity_release(Intent param2Intent) {
        Intrinsics.checkNotNullParameter(param2Intent, "<this>");
        LinkedHashSet<Uri> linkedHashSet = new LinkedHashSet();
        Uri uri = param2Intent.getData();
        if (uri != null)
          linkedHashSet.add(uri); 
        ClipData clipData = param2Intent.getClipData();
        if (clipData == null && linkedHashSet.isEmpty())
          return CollectionsKt.emptyList(); 
        if (clipData != null) {
          int j = clipData.getItemCount();
          for (int i = 0; i < j; i++) {
            uri = clipData.getItemAt(i).getUri();
            if (uri != null)
              linkedHashSet.add(uri); 
          } 
        } 
        return new ArrayList<Uri>(linkedHashSet);
      }
    }
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020 \n\002\030\002\n\002\030\002\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\027\020\003\032\b\022\004\022\0020\0050\004*\0020\006H\000¢\006\002\b\007¨\006\b"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$GetMultipleContents$Companion;", "", "()V", "getClipDataUris", "", "Landroid/net/Uri;", "Landroid/content/Intent;", "getClipDataUris$activity_release", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    public final List<Uri> getClipDataUris$activity_release(Intent param1Intent) {
      Intrinsics.checkNotNullParameter(param1Intent, "<this>");
      LinkedHashSet<Uri> linkedHashSet = new LinkedHashSet();
      Uri uri = param1Intent.getData();
      if (uri != null)
        linkedHashSet.add(uri); 
      ClipData clipData = param1Intent.getClipData();
      if (clipData == null && linkedHashSet.isEmpty())
        return CollectionsKt.emptyList(); 
      if (clipData != null) {
        int j = clipData.getItemCount();
        for (int i = 0; i < j; i++) {
          uri = clipData.getItemAt(i).getUri();
          if (uri != null)
            linkedHashSet.add(uri); 
        } 
      } 
      return new ArrayList<Uri>(linkedHashSet);
    }
  }
  
  @Metadata(d1 = {"\0006\n\002\030\002\n\002\030\002\n\002\020\021\n\002\020\016\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\002\b\027\030\0002\026\022\n\022\b\022\004\022\0020\0030\002\022\006\022\004\030\0010\0040\001B\005¢\006\002\020\005J#\020\006\032\0020\0072\006\020\b\032\0020\t2\f\020\n\032\b\022\004\022\0020\0030\002H\027¢\006\002\020\013J+\020\f\032\f\022\006\022\004\030\0010\004\030\0010\r2\006\020\b\032\0020\t2\f\020\n\032\b\022\004\022\0020\0030\002¢\006\002\020\016J\032\020\017\032\004\030\0010\0042\006\020\020\032\0020\0212\b\020\022\032\004\030\0010\007¨\006\023"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;", "Landroidx/activity/result/contract/ActivityResultContract;", "", "", "Landroid/net/Uri;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "(Landroid/content/Context;[Ljava/lang/String;)Landroid/content/Intent;", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "(Landroid/content/Context;[Ljava/lang/String;)Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class OpenDocument extends ActivityResultContract<String[], Uri> {
    public Intent createIntent(Context param1Context, String[] param1ArrayOfString) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1ArrayOfString, "input");
      Intent intent = (new Intent("android.intent.action.OPEN_DOCUMENT")).putExtra("android.intent.extra.MIME_TYPES", param1ArrayOfString).setType("*/*");
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(Intent.ACTION_OPE…          .setType(\"*/*\")");
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<Uri> getSynchronousResult(Context param1Context, String[] param1ArrayOfString) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1ArrayOfString, "input");
      return null;
    }
    
    public final Uri parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      Uri uri = null;
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null)
        uri = param1Intent.getData(); 
      return uri;
    }
  }
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\b\027\030\0002\022\022\006\022\004\030\0010\002\022\006\022\004\030\0010\0020\001B\005¢\006\002\020\003J\032\020\004\032\0020\0052\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\002H\027J\"\020\t\032\f\022\006\022\004\030\0010\002\030\0010\n2\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\002J\032\020\013\032\004\030\0010\0022\006\020\f\032\0020\r2\b\020\016\032\004\030\0010\005¨\006\017"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$OpenDocumentTree;", "Landroidx/activity/result/contract/ActivityResultContract;", "Landroid/net/Uri;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class OpenDocumentTree extends ActivityResultContract<Uri, Uri> {
    public Intent createIntent(Context param1Context, Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
      if (Build.VERSION.SDK_INT >= 26 && param1Uri != null)
        intent.putExtra("android.provider.extra.INITIAL_URI", (Parcelable)param1Uri); 
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<Uri> getSynchronousResult(Context param1Context, Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      return null;
    }
    
    public final Uri parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      Uri uri = null;
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null)
        uri = param1Intent.getData(); 
      return uri;
    }
  }
  
  @Metadata(d1 = {"\000>\n\002\030\002\n\002\030\002\n\002\020\021\n\002\020\016\n\002\020 \n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\002\b\027\030\0002\037\022\n\022\b\022\004\022\0020\0030\002\022\017\022\r\022\t\022\0070\005¢\006\002\b\0060\0040\001B\005¢\006\002\020\007J#\020\b\032\0020\t2\006\020\n\032\0020\0132\f\020\f\032\b\022\004\022\0020\0030\002H\027¢\006\002\020\rJ/\020\016\032\020\022\n\022\b\022\004\022\0020\0050\004\030\0010\0172\006\020\n\032\0020\0132\f\020\f\032\b\022\004\022\0020\0030\002¢\006\002\020\020J\036\020\021\032\b\022\004\022\0020\0050\0042\006\020\022\032\0020\0232\b\020\024\032\004\030\0010\t¨\006\025"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$OpenMultipleDocuments;", "Landroidx/activity/result/contract/ActivityResultContract;", "", "", "", "Landroid/net/Uri;", "Lkotlin/jvm/JvmSuppressWildcards;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "(Landroid/content/Context;[Ljava/lang/String;)Landroid/content/Intent;", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "(Landroid/content/Context;[Ljava/lang/String;)Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class OpenMultipleDocuments extends ActivityResultContract<String[], List<Uri>> {
    public Intent createIntent(Context param1Context, String[] param1ArrayOfString) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1ArrayOfString, "input");
      Intent intent = (new Intent("android.intent.action.OPEN_DOCUMENT")).putExtra("android.intent.extra.MIME_TYPES", param1ArrayOfString).putExtra("android.intent.extra.ALLOW_MULTIPLE", true).setType("*/*");
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(Intent.ACTION_OPE…          .setType(\"*/*\")");
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<List<Uri>> getSynchronousResult(Context param1Context, String[] param1ArrayOfString) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1ArrayOfString, "input");
      return null;
    }
    
    public final List<Uri> parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null) {
        List<Uri> list = ActivityResultContracts.GetMultipleContents.Companion.getClipDataUris$activity_release(param1Intent);
        if (list != null)
          return list; 
      } 
      return CollectionsKt.emptyList();
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\002\030\0002\022\022\006\022\004\030\0010\002\022\006\022\004\030\0010\0030\001B\005¢\006\002\020\004J\032\020\005\032\0020\0062\006\020\007\032\0020\b2\b\020\t\032\004\030\0010\002H\026J\034\020\n\032\004\030\0010\0032\006\020\013\032\0020\f2\b\020\r\032\004\030\0010\006H\026¨\006\016"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickContact;", "Landroidx/activity/result/contract/ActivityResultContract;", "Ljava/lang/Void;", "Landroid/net/Uri;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "parseResult", "resultCode", "", "intent", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class PickContact extends ActivityResultContract<Void, Uri> {
    public Intent createIntent(Context param1Context, Void param1Void) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intent intent = (new Intent("android.intent.action.PICK")).setType("vnd.android.cursor.dir/contact");
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(Intent.ACTION_PIC…ct.Contacts.CONTENT_TYPE)");
      return intent;
    }
    
    public Uri parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      Uri uri = null;
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null)
        uri = param1Intent.getData(); 
      return uri;
    }
  }
  
  @Metadata(d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020 \n\002\030\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\b\027\030\000 \0232\031\022\004\022\0020\002\022\017\022\r\022\t\022\0070\004¢\006\002\b\0050\0030\001:\001\023B\017\022\b\b\002\020\006\032\0020\007¢\006\002\020\bJ\030\020\t\032\0020\n2\006\020\013\032\0020\f2\006\020\r\032\0020\002H\027J)\020\016\032\025\022\017\022\r\022\t\022\0070\004¢\006\002\b\0050\003\030\0010\0172\006\020\013\032\0020\f2\006\020\r\032\0020\002J\036\020\020\032\b\022\004\022\0020\0040\0032\006\020\021\032\0020\0072\b\020\022\032\004\030\0010\nR\016\020\006\032\0020\007X\004¢\006\002\n\000¨\006\024"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickMultipleVisualMedia;", "Landroidx/activity/result/contract/ActivityResultContract;", "Landroidx/activity/result/PickVisualMediaRequest;", "", "Landroid/net/Uri;", "Lkotlin/jvm/JvmSuppressWildcards;", "maxItems", "", "(I)V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "intent", "Companion", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class PickMultipleVisualMedia extends ActivityResultContract<PickVisualMediaRequest, List<Uri>> {
    public static final Companion Companion = new Companion(null);
    
    private final int maxItems;
    
    public PickMultipleVisualMedia() {
      this(0, 1, null);
    }
    
    public PickMultipleVisualMedia(int param1Int) {
      this.maxItems = param1Int;
      boolean bool = true;
      if (param1Int > 1) {
        param1Int = bool;
      } else {
        param1Int = 0;
      } 
      if (param1Int != 0)
        return; 
      throw new IllegalArgumentException("Max items must be higher than 1".toString());
    }
    
    public Intent createIntent(Context param1Context, PickVisualMediaRequest param1PickVisualMediaRequest) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1PickVisualMediaRequest, "input");
      boolean bool1 = ActivityResultContracts.PickVisualMedia.Companion.isPhotoPickerAvailable();
      boolean bool = true;
      if (bool1) {
        Intent intent1 = new Intent("android.provider.action.PICK_IMAGES");
        intent1.setType(ActivityResultContracts.PickVisualMedia.Companion.getVisualMimeType$activity_release(param1PickVisualMediaRequest.getMediaType()));
        if (Build.VERSION.SDK_INT >= 33) {
          if (this.maxItems > ActivityResultContracts.Api33Impl.INSTANCE.getPickImagesMaxLimit())
            bool = false; 
          if (!bool)
            throw new IllegalArgumentException("Max items must be less or equals MediaStore.getPickImagesMaxLimit()".toString()); 
        } 
        intent1.putExtra("android.provider.extra.PICK_IMAGES_MAX", this.maxItems);
        return intent1;
      } 
      Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
      intent.setType(ActivityResultContracts.PickVisualMedia.Companion.getVisualMimeType$activity_release(param1PickVisualMediaRequest.getMediaType()));
      intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", true);
      if (intent.getType() == null) {
        intent.setType("*/*");
        intent.putExtra("android.intent.extra.MIME_TYPES", new String[] { "image/*", "video/*" });
      } 
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<List<Uri>> getSynchronousResult(Context param1Context, PickVisualMediaRequest param1PickVisualMediaRequest) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1PickVisualMediaRequest, "input");
      return null;
    }
    
    public final List<Uri> parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null) {
        List<Uri> list = ActivityResultContracts.GetMultipleContents.Companion.getClipDataUris$activity_release(param1Intent);
        if (list != null)
          return list; 
      } 
      return CollectionsKt.emptyList();
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\r\020\003\032\0020\004H\000¢\006\002\b\005¨\006\006"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickMultipleVisualMedia$Companion;", "", "()V", "getMaxItems", "", "getMaxItems$activity_release", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class Companion {
      private Companion() {}
      
      public final int getMaxItems$activity_release() {
        return (ActivityResultContracts.PickVisualMedia.Companion.isPhotoPickerAvailable() && Build.VERSION.SDK_INT >= 33) ? ActivityResultContracts.Api33Impl.INSTANCE.getPickImagesMaxLimit() : Integer.MAX_VALUE;
      }
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\r\020\003\032\0020\004H\000¢\006\002\b\005¨\006\006"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickMultipleVisualMedia$Companion;", "", "()V", "getMaxItems", "", "getMaxItems$activity_release", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    public final int getMaxItems$activity_release() {
      return (ActivityResultContracts.PickVisualMedia.Companion.isPhotoPickerAvailable() && Build.VERSION.SDK_INT >= 33) ? ActivityResultContracts.Api33Impl.INSTANCE.getPickImagesMaxLimit() : Integer.MAX_VALUE;
    }
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\b\b\026\030\000 \0202\020\022\004\022\0020\002\022\006\022\004\030\0010\0030\001:\006\020\021\022\023\024\025B\005¢\006\002\020\004J\030\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\002H\027J \020\n\032\f\022\006\022\004\030\0010\003\030\0010\0132\006\020\007\032\0020\b2\006\020\t\032\0020\002J\032\020\f\032\004\030\0010\0032\006\020\r\032\0020\0162\b\020\017\032\004\030\0010\006¨\006\026"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia;", "Landroidx/activity/result/contract/ActivityResultContract;", "Landroidx/activity/result/PickVisualMediaRequest;", "Landroid/net/Uri;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "Companion", "ImageAndVideo", "ImageOnly", "SingleMimeType", "VideoOnly", "VisualMediaType", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class PickVisualMedia extends ActivityResultContract<PickVisualMediaRequest, Uri> {
    public static final Companion Companion = new Companion(null);
    
    @JvmStatic
    public static final boolean isPhotoPickerAvailable() {
      return Companion.isPhotoPickerAvailable();
    }
    
    public Intent createIntent(Context param1Context, PickVisualMediaRequest param1PickVisualMediaRequest) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1PickVisualMediaRequest, "input");
      Companion companion = Companion;
      if (companion.isPhotoPickerAvailable()) {
        Intent intent1 = new Intent("android.provider.action.PICK_IMAGES");
        intent1.setType(companion.getVisualMimeType$activity_release(param1PickVisualMediaRequest.getMediaType()));
        return intent1;
      } 
      Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
      intent.setType(companion.getVisualMimeType$activity_release(param1PickVisualMediaRequest.getMediaType()));
      if (intent.getType() == null) {
        intent.setType("*/*");
        intent.putExtra("android.intent.extra.MIME_TYPES", new String[] { "image/*", "video/*" });
      } 
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<Uri> getSynchronousResult(Context param1Context, PickVisualMediaRequest param1PickVisualMediaRequest) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1PickVisualMediaRequest, "input");
      return null;
    }
    
    public final Uri parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      Uri uri = null;
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null)
        uri = param1Intent.getData(); 
      return uri;
    }
    
    @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\027\020\003\032\004\030\0010\0042\006\020\005\032\0020\006H\000¢\006\002\b\007J\b\020\b\032\0020\tH\007¨\006\n"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$Companion;", "", "()V", "getVisualMimeType", "", "input", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "getVisualMimeType$activity_release", "isPhotoPickerAvailable", "", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class Companion {
      private Companion() {}
      
      public final String getVisualMimeType$activity_release(ActivityResultContracts.PickVisualMedia.VisualMediaType param2VisualMediaType) {
        Intrinsics.checkNotNullParameter(param2VisualMediaType, "input");
        if (param2VisualMediaType instanceof ActivityResultContracts.PickVisualMedia.ImageOnly)
          return "image/*"; 
        if (param2VisualMediaType instanceof ActivityResultContracts.PickVisualMedia.VideoOnly)
          return "video/*"; 
        if (param2VisualMediaType instanceof ActivityResultContracts.PickVisualMedia.SingleMimeType)
          return ((ActivityResultContracts.PickVisualMedia.SingleMimeType)param2VisualMediaType).getMimeType(); 
        if (param2VisualMediaType instanceof ActivityResultContracts.PickVisualMedia.ImageAndVideo)
          return null; 
        throw new NoWhenBranchMatchedException();
      }
      
      @JvmStatic
      public final boolean isPhotoPickerAvailable() {
        return (Build.VERSION.SDK_INT >= 33) ? true : ((Build.VERSION.SDK_INT >= 30 && SdkExtensions.getExtensionVersion(30) >= 2));
      }
    }
    
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\bÆ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002¨\006\003"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$ImageAndVideo;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "()V", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class ImageAndVideo implements VisualMediaType {
      public static final ImageAndVideo INSTANCE = new ImageAndVideo();
    }
    
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\bÆ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002¨\006\003"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$ImageOnly;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "()V", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class ImageOnly implements VisualMediaType {
      public static final ImageOnly INSTANCE = new ImageOnly();
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\004\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\005\020\006¨\006\007"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$SingleMimeType;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "mimeType", "", "(Ljava/lang/String;)V", "getMimeType", "()Ljava/lang/String;", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class SingleMimeType implements VisualMediaType {
      private final String mimeType;
      
      public SingleMimeType(String param2String) {
        this.mimeType = param2String;
      }
      
      public final String getMimeType() {
        return this.mimeType;
      }
    }
    
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\bÆ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002¨\006\003"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VideoOnly;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "()V", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class VideoOnly implements VisualMediaType {
      public static final VideoOnly INSTANCE = new VideoOnly();
    }
    
    @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\bv\030\0002\0020\001\001\004\002\003\004\005¨\006\006"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$ImageAndVideo;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$ImageOnly;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$SingleMimeType;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VideoOnly;", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static interface VisualMediaType {}
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\027\020\003\032\004\030\0010\0042\006\020\005\032\0020\006H\000¢\006\002\b\007J\b\020\b\032\0020\tH\007¨\006\n"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$Companion;", "", "()V", "getVisualMimeType", "", "input", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "getVisualMimeType$activity_release", "isPhotoPickerAvailable", "", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    public final String getVisualMimeType$activity_release(ActivityResultContracts.PickVisualMedia.VisualMediaType param1VisualMediaType) {
      Intrinsics.checkNotNullParameter(param1VisualMediaType, "input");
      if (param1VisualMediaType instanceof ActivityResultContracts.PickVisualMedia.ImageOnly)
        return "image/*"; 
      if (param1VisualMediaType instanceof ActivityResultContracts.PickVisualMedia.VideoOnly)
        return "video/*"; 
      if (param1VisualMediaType instanceof ActivityResultContracts.PickVisualMedia.SingleMimeType)
        return ((ActivityResultContracts.PickVisualMedia.SingleMimeType)param1VisualMediaType).getMimeType(); 
      if (param1VisualMediaType instanceof ActivityResultContracts.PickVisualMedia.ImageAndVideo)
        return null; 
      throw new NoWhenBranchMatchedException();
    }
    
    @JvmStatic
    public final boolean isPhotoPickerAvailable() {
      return (Build.VERSION.SDK_INT >= 33) ? true : ((Build.VERSION.SDK_INT >= 30 && SdkExtensions.getExtensionVersion(30) >= 2));
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\bÆ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002¨\006\003"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$ImageAndVideo;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "()V", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class ImageAndVideo implements PickVisualMedia.VisualMediaType {
    public static final ImageAndVideo INSTANCE = new ImageAndVideo();
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\bÆ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002¨\006\003"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$ImageOnly;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "()V", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class ImageOnly implements PickVisualMedia.VisualMediaType {
    public static final ImageOnly INSTANCE = new ImageOnly();
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\004\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\005\020\006¨\006\007"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$SingleMimeType;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "mimeType", "", "(Ljava/lang/String;)V", "getMimeType", "()Ljava/lang/String;", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class SingleMimeType implements PickVisualMedia.VisualMediaType {
    private final String mimeType;
    
    public SingleMimeType(String param1String) {
      this.mimeType = param1String;
    }
    
    public final String getMimeType() {
      return this.mimeType;
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\bÆ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002¨\006\003"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VideoOnly;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "()V", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class VideoOnly implements PickVisualMedia.VisualMediaType {
    public static final VideoOnly INSTANCE = new VideoOnly();
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\bv\030\0002\0020\001\001\004\002\003\004\005¨\006\006"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$ImageAndVideo;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$ImageOnly;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$SingleMimeType;", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VideoOnly;", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static interface VisualMediaType {}
  
  @Metadata(d1 = {"\000>\n\002\030\002\n\002\030\002\n\002\020\021\n\002\020\016\n\002\020$\n\002\020\013\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\003\030\000 \0252%\022\n\022\b\022\004\022\0020\0030\002\022\025\022\023\022\004\022\0020\003\022\t\022\0070\005¢\006\002\b\0060\0040\001:\001\025B\005¢\006\002\020\007J#\020\b\032\0020\t2\006\020\n\032\0020\0132\f\020\f\032\b\022\004\022\0020\0030\002H\026¢\006\002\020\rJ7\020\016\032\026\022\020\022\016\022\004\022\0020\003\022\004\022\0020\0050\004\030\0010\0172\006\020\n\032\0020\0132\f\020\f\032\b\022\004\022\0020\0030\002H\026¢\006\002\020\020J&\020\021\032\016\022\004\022\0020\003\022\004\022\0020\0050\0042\006\020\022\032\0020\0232\b\020\024\032\004\030\0010\tH\026¨\006\026"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;", "Landroidx/activity/result/contract/ActivityResultContract;", "", "", "", "", "Lkotlin/jvm/JvmSuppressWildcards;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "(Landroid/content/Context;[Ljava/lang/String;)Landroid/content/Intent;", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "(Landroid/content/Context;[Ljava/lang/String;)Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "Companion", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class RequestMultiplePermissions extends ActivityResultContract<String[], Map<String, Boolean>> {
    public static final String ACTION_REQUEST_PERMISSIONS = "androidx.activity.result.contract.action.REQUEST_PERMISSIONS";
    
    public static final Companion Companion = new Companion(null);
    
    public static final String EXTRA_PERMISSIONS = "androidx.activity.result.contract.extra.PERMISSIONS";
    
    public static final String EXTRA_PERMISSION_GRANT_RESULTS = "androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS";
    
    public Intent createIntent(Context param1Context, String[] param1ArrayOfString) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1ArrayOfString, "input");
      return Companion.createIntent$activity_release(param1ArrayOfString);
    }
    
    public ActivityResultContract.SynchronousResult<Map<String, Boolean>> getSynchronousResult(Context param1Context, String[] param1ArrayOfString) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1ArrayOfString, "input");
      int i = param1ArrayOfString.length;
      boolean bool = false;
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0)
        return new ActivityResultContract.SynchronousResult<Map<String, Boolean>>(MapsKt.emptyMap()); 
      int j = param1ArrayOfString.length;
      i = 0;
      while (true) {
        if (i < j) {
          boolean bool1;
          if (ContextCompat.checkSelfPermission(param1Context, param1ArrayOfString[i]) == 0) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          if (!bool1) {
            i = 0;
            break;
          } 
          i++;
          continue;
        } 
        i = 1;
        break;
      } 
      if (i != 0) {
        LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<Object, Object>(RangesKt.coerceAtLeast(MapsKt.mapCapacity(param1ArrayOfString.length), 16));
        int k = param1ArrayOfString.length;
        for (i = bool; i < k; i++) {
          Pair pair = TuplesKt.to(param1ArrayOfString[i], Boolean.valueOf(true));
          linkedHashMap.put(pair.getFirst(), pair.getSecond());
        } 
        return new ActivityResultContract.SynchronousResult(linkedHashMap);
      } 
      return null;
    }
    
    public Map<String, Boolean> parseResult(int param1Int, Intent param1Intent) {
      if (param1Int != -1)
        return MapsKt.emptyMap(); 
      if (param1Intent == null)
        return MapsKt.emptyMap(); 
      String[] arrayOfString = param1Intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
      int[] arrayOfInt = param1Intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
      if (arrayOfInt == null || arrayOfString == null)
        return MapsKt.emptyMap(); 
      ArrayList<Boolean> arrayList2 = new ArrayList(arrayOfInt.length);
      int i = arrayOfInt.length;
      for (param1Int = 0; param1Int < i; param1Int++) {
        boolean bool;
        if (arrayOfInt[param1Int] == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        arrayList2.add(Boolean.valueOf(bool));
      } 
      ArrayList<Boolean> arrayList1 = arrayList2;
      return MapsKt.toMap(CollectionsKt.zip(ArraysKt.filterNotNull((Object[])arrayOfString), arrayList1));
    }
    
    @Metadata(d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\n\002\030\002\n\000\n\002\020\021\n\002\b\003\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\035\020\007\032\0020\b2\f\020\t\032\b\022\004\022\0020\0040\nH\000¢\006\004\b\013\020\fR\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000¨\006\r"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions$Companion;", "", "()V", "ACTION_REQUEST_PERMISSIONS", "", "EXTRA_PERMISSIONS", "EXTRA_PERMISSION_GRANT_RESULTS", "createIntent", "Landroid/content/Intent;", "input", "", "createIntent$activity_release", "([Ljava/lang/String;)Landroid/content/Intent;", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class Companion {
      private Companion() {}
      
      public final Intent createIntent$activity_release(String[] param2ArrayOfString) {
        Intrinsics.checkNotNullParameter(param2ArrayOfString, "input");
        Intent intent = (new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS")).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", param2ArrayOfString);
        Intrinsics.checkNotNullExpressionValue(intent, "Intent(ACTION_REQUEST_PE…EXTRA_PERMISSIONS, input)");
        return intent;
      }
    }
  }
  
  @Metadata(d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\n\002\030\002\n\000\n\002\020\021\n\002\b\003\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\035\020\007\032\0020\b2\f\020\t\032\b\022\004\022\0020\0040\nH\000¢\006\004\b\013\020\fR\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000¨\006\r"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions$Companion;", "", "()V", "ACTION_REQUEST_PERMISSIONS", "", "EXTRA_PERMISSIONS", "EXTRA_PERMISSION_GRANT_RESULTS", "createIntent", "Landroid/content/Intent;", "input", "", "createIntent$activity_release", "([Ljava/lang/String;)Landroid/content/Intent;", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    public final Intent createIntent$activity_release(String[] param1ArrayOfString) {
      Intrinsics.checkNotNullParameter(param1ArrayOfString, "input");
      Intent intent = (new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS")).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", param1ArrayOfString);
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(ACTION_REQUEST_PE…EXTRA_PERMISSIONS, input)");
      return intent;
    }
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\020\016\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\030\0002\016\022\004\022\0020\002\022\004\022\0020\0030\001B\005¢\006\002\020\004J\030\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\002H\026J \020\n\032\n\022\004\022\0020\003\030\0010\0132\006\020\007\032\0020\b2\006\020\t\032\0020\002H\026J\037\020\f\032\0020\0032\006\020\r\032\0020\0162\b\020\017\032\004\030\0010\006H\026¢\006\002\020\020¨\006\021"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$RequestPermission;", "Landroidx/activity/result/contract/ActivityResultContract;", "", "", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "(ILandroid/content/Intent;)Ljava/lang/Boolean;", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class RequestPermission extends ActivityResultContract<String, Boolean> {
    public Intent createIntent(Context param1Context, String param1String) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1String, "input");
      return ActivityResultContracts.RequestMultiplePermissions.Companion.createIntent$activity_release(new String[] { param1String });
    }
    
    public ActivityResultContract.SynchronousResult<Boolean> getSynchronousResult(Context param1Context, String param1String) {
      boolean bool;
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1String, "input");
      if (ContextCompat.checkSelfPermission(param1Context, param1String) == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return new ActivityResultContract.SynchronousResult<Boolean>(Boolean.valueOf(true)); 
      ActivityResultContract.SynchronousResult synchronousResult = (ActivityResultContract.SynchronousResult)null;
      return null;
    }
    
    public Boolean parseResult(int param1Int, Intent param1Intent) {
      boolean bool2 = false;
      if (param1Intent == null || param1Int != -1)
        return Boolean.valueOf(false); 
      int[] arrayOfInt = param1Intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
      boolean bool1 = bool2;
      if (arrayOfInt != null) {
        int i = arrayOfInt.length;
        param1Int = 0;
        while (true) {
          if (param1Int < i) {
            boolean bool;
            if (arrayOfInt[param1Int] == 0) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool) {
              param1Int = 1;
              break;
            } 
            param1Int++;
            continue;
          } 
          param1Int = 0;
          break;
        } 
        bool1 = bool2;
        if (param1Int == 1)
          bool1 = true; 
      } 
      return Boolean.valueOf(bool1);
    }
  }
  
  @Metadata(d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\003\030\000 \r2\016\022\004\022\0020\002\022\004\022\0020\0030\001:\001\rB\005¢\006\002\020\004J\030\020\005\032\0020\0022\006\020\006\032\0020\0072\006\020\b\032\0020\002H\026J\032\020\t\032\0020\0032\006\020\n\032\0020\0132\b\020\f\032\004\030\0010\002H\026¨\006\016"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$StartActivityForResult;", "Landroidx/activity/result/contract/ActivityResultContract;", "Landroid/content/Intent;", "Landroidx/activity/result/ActivityResult;", "()V", "createIntent", "context", "Landroid/content/Context;", "input", "parseResult", "resultCode", "", "intent", "Companion", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class StartActivityForResult extends ActivityResultContract<Intent, ActivityResult> {
    public static final Companion Companion = new Companion(null);
    
    public static final String EXTRA_ACTIVITY_OPTIONS_BUNDLE = "androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE";
    
    public Intent createIntent(Context param1Context, Intent param1Intent) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1Intent, "input");
      return param1Intent;
    }
    
    public ActivityResult parseResult(int param1Int, Intent param1Intent) {
      return new ActivityResult(param1Int, param1Intent);
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$StartActivityForResult$Companion;", "", "()V", "EXTRA_ACTIVITY_OPTIONS_BUNDLE", "", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$StartActivityForResult$Companion;", "", "()V", "EXTRA_ACTIVITY_OPTIONS_BUNDLE", "", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\003\030\000 \0162\016\022\004\022\0020\002\022\004\022\0020\0030\001:\001\016B\005¢\006\002\020\004J\030\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\002H\026J\032\020\n\032\0020\0032\006\020\013\032\0020\f2\b\020\r\032\004\030\0010\006H\026¨\006\017"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$StartIntentSenderForResult;", "Landroidx/activity/result/contract/ActivityResultContract;", "Landroidx/activity/result/IntentSenderRequest;", "Landroidx/activity/result/ActivityResult;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "parseResult", "resultCode", "", "intent", "Companion", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class StartIntentSenderForResult extends ActivityResultContract<IntentSenderRequest, ActivityResult> {
    public static final String ACTION_INTENT_SENDER_REQUEST = "androidx.activity.result.contract.action.INTENT_SENDER_REQUEST";
    
    public static final Companion Companion = new Companion(null);
    
    public static final String EXTRA_INTENT_SENDER_REQUEST = "androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST";
    
    public static final String EXTRA_SEND_INTENT_EXCEPTION = "androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION";
    
    public Intent createIntent(Context param1Context, IntentSenderRequest param1IntentSenderRequest) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1IntentSenderRequest, "input");
      Intent intent = (new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST")).putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", (Parcelable)param1IntentSenderRequest);
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(ACTION_INTENT_SEN…NT_SENDER_REQUEST, input)");
      return intent;
    }
    
    public ActivityResult parseResult(int param1Int, Intent param1Intent) {
      return new ActivityResult(param1Int, param1Intent);
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000¨\006\007"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$StartIntentSenderForResult$Companion;", "", "()V", "ACTION_INTENT_SENDER_REQUEST", "", "EXTRA_INTENT_SENDER_REQUEST", "EXTRA_SEND_INTENT_EXCEPTION", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000¨\006\007"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$StartIntentSenderForResult$Companion;", "", "()V", "ACTION_INTENT_SENDER_REQUEST", "", "EXTRA_INTENT_SENDER_REQUEST", "EXTRA_SEND_INTENT_EXCEPTION", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\b\026\030\0002\016\022\004\022\0020\002\022\004\022\0020\0030\001B\005¢\006\002\020\004J\030\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\002H\027J\036\020\n\032\n\022\004\022\0020\003\030\0010\0132\006\020\007\032\0020\b2\006\020\t\032\0020\002J\035\020\f\032\0020\0032\006\020\r\032\0020\0162\b\020\017\032\004\030\0010\006¢\006\002\020\020¨\006\021"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$TakePicture;", "Landroidx/activity/result/contract/ActivityResultContract;", "Landroid/net/Uri;", "", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "(ILandroid/content/Intent;)Ljava/lang/Boolean;", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class TakePicture extends ActivityResultContract<Uri, Boolean> {
    public Intent createIntent(Context param1Context, Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1Uri, "input");
      Intent intent = (new Intent("android.media.action.IMAGE_CAPTURE")).putExtra("output", (Parcelable)param1Uri);
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(MediaStore.ACTION…tore.EXTRA_OUTPUT, input)");
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<Boolean> getSynchronousResult(Context param1Context, Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1Uri, "input");
      return null;
    }
    
    public final Boolean parseResult(int param1Int, Intent param1Intent) {
      boolean bool;
      if (param1Int == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return Boolean.valueOf(bool);
    }
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\b\026\030\0002\022\022\006\022\004\030\0010\002\022\006\022\004\030\0010\0030\001B\005¢\006\002\020\004J\032\020\005\032\0020\0062\006\020\007\032\0020\b2\b\020\t\032\004\030\0010\002H\027J\"\020\n\032\f\022\006\022\004\030\0010\003\030\0010\0132\006\020\007\032\0020\b2\b\020\t\032\004\030\0010\002J\032\020\f\032\004\030\0010\0032\006\020\r\032\0020\0162\b\020\017\032\004\030\0010\006¨\006\020"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$TakePicturePreview;", "Landroidx/activity/result/contract/ActivityResultContract;", "Ljava/lang/Void;", "Landroid/graphics/Bitmap;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class TakePicturePreview extends ActivityResultContract<Void, Bitmap> {
    public Intent createIntent(Context param1Context, Void param1Void) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      return new Intent("android.media.action.IMAGE_CAPTURE");
    }
    
    public final ActivityResultContract.SynchronousResult<Bitmap> getSynchronousResult(Context param1Context, Void param1Void) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      return null;
    }
    
    public final Bitmap parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      Bitmap bitmap = null;
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null)
        bitmap = (Bitmap)param1Intent.getParcelableExtra("data"); 
      return bitmap;
    }
  }
  
  @Deprecated(message = "The thumbnail bitmap is rarely returned and is not a good signal to determine\n      whether the video was actually successfully captured. Use {@link CaptureVideo} instead.")
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\b\027\030\0002\020\022\004\022\0020\002\022\006\022\004\030\0010\0030\001B\005¢\006\002\020\004J\030\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\002H\027J \020\n\032\f\022\006\022\004\030\0010\003\030\0010\0132\006\020\007\032\0020\b2\006\020\t\032\0020\002J\032\020\f\032\004\030\0010\0032\006\020\r\032\0020\0162\b\020\017\032\004\030\0010\006¨\006\020"}, d2 = {"Landroidx/activity/result/contract/ActivityResultContracts$TakeVideo;", "Landroidx/activity/result/contract/ActivityResultContract;", "Landroid/net/Uri;", "Landroid/graphics/Bitmap;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "getSynchronousResult", "Landroidx/activity/result/contract/ActivityResultContract$SynchronousResult;", "parseResult", "resultCode", "", "intent", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class TakeVideo extends ActivityResultContract<Uri, Bitmap> {
    public Intent createIntent(Context param1Context, Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1Uri, "input");
      Intent intent = (new Intent("android.media.action.VIDEO_CAPTURE")).putExtra("output", (Parcelable)param1Uri);
      Intrinsics.checkNotNullExpressionValue(intent, "Intent(MediaStore.ACTION…tore.EXTRA_OUTPUT, input)");
      return intent;
    }
    
    public final ActivityResultContract.SynchronousResult<Bitmap> getSynchronousResult(Context param1Context, Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Intrinsics.checkNotNullParameter(param1Uri, "input");
      return null;
    }
    
    public final Bitmap parseResult(int param1Int, Intent param1Intent) {
      if (param1Int == -1) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      Bitmap bitmap = null;
      if (param1Int == 0)
        param1Intent = null; 
      if (param1Intent != null)
        bitmap = (Bitmap)param1Intent.getParcelableExtra("data"); 
      return bitmap;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\activity\result\contract\ActivityResultContracts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */