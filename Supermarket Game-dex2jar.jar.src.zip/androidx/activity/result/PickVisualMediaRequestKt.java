package androidx.activity.result;

import androidx.activity.result.contract.ActivityResultContracts;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\032\020\020\000\032\0020\0012\b\b\002\020\002\032\0020\003¨\006\004"}, d2 = {"PickVisualMediaRequest", "Landroidx/activity/result/PickVisualMediaRequest;", "mediaType", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "activity_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class PickVisualMediaRequestKt {
  public static final PickVisualMediaRequest PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VisualMediaType paramVisualMediaType) {
    Intrinsics.checkNotNullParameter(paramVisualMediaType, "mediaType");
    return (new PickVisualMediaRequest.Builder()).setMediaType(paramVisualMediaType).build();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Supermarket Game-dex2jar.jar!\androidx\activity\result\PickVisualMediaRequestKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */