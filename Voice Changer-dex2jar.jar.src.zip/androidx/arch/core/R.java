package androidx.arch.core;

public final class R {}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\arch\core\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */