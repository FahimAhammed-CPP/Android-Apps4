package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion;
import android.view.inspector.PropertyMapper;
import android.view.inspector.PropertyReader;
import androidx.appcompat.R;

public final class AppCompatImageView$InspectionCompanion implements InspectionCompanion<AppCompatImageView> {
  private int mBackgroundTintId;
  
  private int mBackgroundTintModeId;
  
  private boolean mPropertiesMapped = false;
  
  private int mTintId;
  
  private int mTintModeId;
  
  public void mapProperties(PropertyMapper paramPropertyMapper) {
    this.mBackgroundTintId = paramPropertyMapper.mapObject("backgroundTint", R.attr.backgroundTint);
    this.mBackgroundTintModeId = paramPropertyMapper.mapObject("backgroundTintMode", R.attr.backgroundTintMode);
    this.mTintId = paramPropertyMapper.mapObject("tint", R.attr.tint);
    this.mTintModeId = paramPropertyMapper.mapObject("tintMode", R.attr.tintMode);
    this.mPropertiesMapped = true;
  }
  
  public void readProperties(AppCompatImageView paramAppCompatImageView, PropertyReader paramPropertyReader) {
    if (this.mPropertiesMapped) {
      paramPropertyReader.readObject(this.mBackgroundTintId, paramAppCompatImageView.getBackgroundTintList());
      paramPropertyReader.readObject(this.mBackgroundTintModeId, paramAppCompatImageView.getBackgroundTintMode());
      paramPropertyReader.readObject(this.mTintId, paramAppCompatImageView.getImageTintList());
      paramPropertyReader.readObject(this.mTintModeId, paramAppCompatImageView.getImageTintMode());
      return;
    } 
    throw new InspectionCompanion.UninitializedPropertyMapException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\appcompat\widget\AppCompatImageView$InspectionCompanion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */