package androidx.browser;

public final class R {
  public static final class color {
    public static final int browser_actions_bg_grey = 2131099700;
    
    public static final int browser_actions_divider_color = 2131099701;
    
    public static final int browser_actions_text_color = 2131099702;
    
    public static final int browser_actions_title_color = 2131099703;
  }
  
  public static final class dimen {
    public static final int browser_actions_context_menu_max_width = 2131165930;
    
    public static final int browser_actions_context_menu_min_padding = 2131165931;
  }
  
  public static final class id {
    public static final int browser_actions_header_text = 2131361937;
    
    public static final int browser_actions_menu_item_icon = 2131361938;
    
    public static final int browser_actions_menu_item_text = 2131361939;
    
    public static final int browser_actions_menu_items = 2131361940;
    
    public static final int browser_actions_menu_view = 2131361941;
  }
  
  public static final class layout {
    public static final int browser_actions_context_menu_page = 2131558441;
    
    public static final int browser_actions_context_menu_row = 2131558442;
  }
  
  public static final class string {
    public static final int copy_toast_msg = 2131951677;
    
    public static final int fallback_menu_item_copy_link = 2131951686;
    
    public static final int fallback_menu_item_open_in_browser = 2131951687;
    
    public static final int fallback_menu_item_share_link = 2131951688;
  }
  
  public static final class xml {
    public static final int image_share_filepaths = 2132148227;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\browser\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */