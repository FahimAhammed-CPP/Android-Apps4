package androidx.browser.trusted;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;

public final class TrustedWebActivityServiceConnectionPool {
  private static final String TAG = "TWAConnectionPool";
  
  private final Map<Uri, ConnectionHolder> mConnections = new HashMap<Uri, ConnectionHolder>();
  
  private final Context mContext;
  
  private TrustedWebActivityServiceConnectionPool(Context paramContext) {
    this.mContext = paramContext.getApplicationContext();
  }
  
  public static TrustedWebActivityServiceConnectionPool create(Context paramContext) {
    return new TrustedWebActivityServiceConnectionPool(paramContext);
  }
  
  private Intent createServiceIntent(Context paramContext, Uri paramUri, Set<Token> paramSet, boolean paramBoolean) {
    if (paramSet != null) {
      StringBuilder stringBuilder2;
      StringBuilder stringBuilder1;
      String str;
      if (paramSet.size() == 0)
        return null; 
      Intent intent3 = new Intent();
      intent3.setData(paramUri);
      intent3.setAction("android.intent.action.VIEW");
      Iterator iterator = paramContext.getPackageManager().queryIntentActivities(intent3, 65536).iterator();
      intent3 = null;
      while (iterator.hasNext()) {
        String str1 = ((ResolveInfo)iterator.next()).activityInfo.packageName;
        Iterator<Token> iterator1 = paramSet.iterator();
        while (iterator1.hasNext()) {
          if (((Token)iterator1.next()).matches(str1, paramContext.getPackageManager()))
            str = str1; 
        } 
      } 
      if (str == null) {
        if (paramBoolean) {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("No TWA candidates for ");
          stringBuilder2.append(paramUri);
          stringBuilder2.append(" have been registered.");
          Log.w("TWAConnectionPool", stringBuilder2.toString());
        } 
        return null;
      } 
      Intent intent2 = new Intent();
      intent2.setPackage(str);
      intent2.setAction("android.support.customtabs.trusted.TRUSTED_WEB_ACTIVITY_SERVICE");
      ResolveInfo resolveInfo = stringBuilder2.getPackageManager().resolveService(intent2, 131072);
      if (resolveInfo == null) {
        if (paramBoolean) {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Could not find TWAService for ");
          stringBuilder1.append(str);
          Log.w("TWAConnectionPool", stringBuilder1.toString());
        } 
        return null;
      } 
      if (paramBoolean) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Found ");
        stringBuilder.append(((ResolveInfo)stringBuilder1).serviceInfo.name);
        stringBuilder.append(" to handle request for ");
        stringBuilder.append(paramUri);
        Log.i("TWAConnectionPool", stringBuilder.toString());
      } 
      Intent intent1 = new Intent();
      intent1.setComponent(new ComponentName(str, ((ResolveInfo)stringBuilder1).serviceInfo.name));
      return intent1;
    } 
    return null;
  }
  
  public ListenableFuture<TrustedWebActivityServiceConnection> connect(Uri paramUri, Set<Token> paramSet, Executor paramExecutor) {
    ConnectionHolder connectionHolder = this.mConnections.get(paramUri);
    if (connectionHolder != null)
      return connectionHolder.getServiceWrapper(); 
    Intent intent = createServiceIntent(this.mContext, paramUri, paramSet, true);
    if (intent == null)
      return FutureUtils.immediateFailedFuture(new IllegalArgumentException("No service exists for scope")); 
    connectionHolder = new ConnectionHolder(new TrustedWebActivityServiceConnectionPool$$ExternalSyntheticLambda0(this, paramUri));
    this.mConnections.put(paramUri, connectionHolder);
    (new BindToServiceAsyncTask(this.mContext, intent, connectionHolder)).executeOnExecutor(paramExecutor, (Object[])new Void[0]);
    return connectionHolder.getServiceWrapper();
  }
  
  public boolean serviceExistsForScope(Uri paramUri, Set<Token> paramSet) {
    return (this.mConnections.get(paramUri) != null) ? true : ((createServiceIntent(this.mContext, paramUri, paramSet, false) != null));
  }
  
  void unbindAllConnections() {
    for (ConnectionHolder connectionHolder : this.mConnections.values())
      this.mContext.unbindService(connectionHolder); 
    this.mConnections.clear();
  }
  
  static class BindToServiceAsyncTask extends AsyncTask<Void, Void, Exception> {
    private final Context mAppContext;
    
    private final ConnectionHolder mConnection;
    
    private final Intent mIntent;
    
    BindToServiceAsyncTask(Context param1Context, Intent param1Intent, ConnectionHolder param1ConnectionHolder) {
      this.mAppContext = param1Context.getApplicationContext();
      this.mIntent = param1Intent;
      this.mConnection = param1ConnectionHolder;
    }
    
    protected Exception doInBackground(Void... param1VarArgs) {
      try {
        if (this.mAppContext.bindService(this.mIntent, this.mConnection, 4097))
          return null; 
        this.mAppContext.unbindService(this.mConnection);
        return new IllegalStateException("Could not bind to the service");
      } catch (SecurityException securityException) {
        Log.w("TWAConnectionPool", "SecurityException while binding.", securityException);
        return securityException;
      } 
    }
    
    protected void onPostExecute(Exception param1Exception) {
      if (param1Exception != null)
        this.mConnection.cancel(param1Exception); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\browser\trusted\TrustedWebActivityServiceConnectionPool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */