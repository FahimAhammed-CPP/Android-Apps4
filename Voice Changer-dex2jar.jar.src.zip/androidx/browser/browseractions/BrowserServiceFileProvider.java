package androidx.browser.browseractions;

import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import androidx.concurrent.futures.ResolvableFuture;
import androidx.core.content.FileProvider;
import androidx.core.util.AtomicFile;
import com.google.common.util.concurrent.ListenableFuture;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Deprecated
public final class BrowserServiceFileProvider extends FileProvider {
  private static final String AUTHORITY_SUFFIX = ".image_provider";
  
  private static final String CLIP_DATA_LABEL = "image_provider_uris";
  
  private static final String CONTENT_SCHEME = "content";
  
  private static final String FILE_EXTENSION = ".png";
  
  private static final String FILE_SUB_DIR = "image_provider";
  
  private static final String FILE_SUB_DIR_NAME = "image_provider_images/";
  
  private static final String LAST_CLEANUP_TIME_KEY = "last_cleanup_time";
  
  private static final String TAG = "BrowserServiceFP";
  
  static Object sFileCleanupLock = new Object();
  
  private static Uri generateUri(Context paramContext, String paramString) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("image_provider_images/");
    stringBuilder1.append(paramString);
    stringBuilder1.append(".png");
    paramString = stringBuilder1.toString();
    Uri.Builder builder = (new Uri.Builder()).scheme("content");
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramContext.getPackageName());
    stringBuilder2.append(".image_provider");
    return builder.authority(stringBuilder2.toString()).path(paramString).build();
  }
  
  public static void grantReadPermission(Intent paramIntent, List<Uri> paramList, Context paramContext) {
    if (paramList != null) {
      if (paramList.size() == 0)
        return; 
      ContentResolver contentResolver = paramContext.getContentResolver();
      int i = 1;
      paramIntent.addFlags(1);
      ClipData clipData = ClipData.newUri(contentResolver, "image_provider_uris", paramList.get(0));
      while (i < paramList.size()) {
        clipData.addItem(new ClipData.Item(paramList.get(i)));
        i++;
      } 
      paramIntent.setClipData(clipData);
    } 
  }
  
  public static ListenableFuture<Bitmap> loadBitmap(final ContentResolver resolver, final Uri uri) {
    final ResolvableFuture result = ResolvableFuture.create();
    AsyncTask.THREAD_POOL_EXECUTOR.execute(new Runnable() {
          public void run() {
            try {
              ParcelFileDescriptor parcelFileDescriptor = resolver.openFileDescriptor(uri, "r");
              if (parcelFileDescriptor == null) {
                result.setException(new FileNotFoundException());
                return;
              } 
              Bitmap bitmap = BitmapFactory.decodeFileDescriptor(parcelFileDescriptor.getFileDescriptor());
              parcelFileDescriptor.close();
              if (bitmap == null) {
                result.setException(new IOException("File could not be decoded."));
                return;
              } 
              result.set(bitmap);
              return;
            } catch (IOException iOException) {
              result.setException(iOException);
              return;
            } 
          }
        });
    return (ListenableFuture<Bitmap>)resolvableFuture;
  }
  
  public static ResolvableFuture<Uri> saveBitmap(Context paramContext, Bitmap paramBitmap, String paramString, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("_");
    stringBuilder.append(Integer.toString(paramInt));
    paramString = stringBuilder.toString();
    Uri uri = generateUri(paramContext, paramString);
    ResolvableFuture<Uri> resolvableFuture = ResolvableFuture.create();
    (new FileSaveTask(paramContext, paramString, paramBitmap, uri, resolvableFuture)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new String[0]);
    return resolvableFuture;
  }
  
  private static class FileCleanupTask extends AsyncTask<Void, Void, Void> {
    private static final long CLEANUP_REQUIRED_TIME_SPAN = TimeUnit.DAYS.toMillis(7L);
    
    private static final long DELETION_FAILED_REATTEMPT_DURATION = TimeUnit.DAYS.toMillis(1L);
    
    private static final long IMAGE_RETENTION_DURATION = TimeUnit.DAYS.toMillis(7L);
    
    private final Context mAppContext;
    
    static {
    
    }
    
    FileCleanupTask(Context param1Context) {
      this.mAppContext = param1Context.getApplicationContext();
    }
    
    private static boolean isImageFile(File param1File) {
      return param1File.getName().endsWith("..png");
    }
    
    private static boolean shouldCleanUp(SharedPreferences param1SharedPreferences) {
      long l = param1SharedPreferences.getLong("last_cleanup_time", System.currentTimeMillis());
      return (System.currentTimeMillis() > l + CLEANUP_REQUIRED_TIME_SPAN);
    }
    
    protected Void doInBackground(Void... param1VarArgs) {
      Context context = this.mAppContext;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.mAppContext.getPackageName());
      stringBuilder.append(".image_provider");
      null = context.getSharedPreferences(stringBuilder.toString(), 0);
      if (!shouldCleanUp(null))
        return null; 
      synchronized (BrowserServiceFileProvider.sFileCleanupLock) {
        File file = new File(this.mAppContext.getFilesDir(), "image_provider");
        if (!file.exists())
          return null; 
        File[] arrayOfFile = file.listFiles();
        long l1 = System.currentTimeMillis();
        long l2 = IMAGE_RETENTION_DURATION;
        int j = arrayOfFile.length;
        boolean bool = true;
        int i = 0;
        while (true) {
          boolean bool1;
          if (i < j) {
            File file1 = arrayOfFile[i];
            if (!isImageFile(file1)) {
              bool1 = bool;
            } else {
              bool1 = bool;
              if (file1.lastModified() < l1 - l2) {
                bool1 = bool;
                if (!file1.delete()) {
                  StringBuilder stringBuilder1 = new StringBuilder();
                  stringBuilder1.append("Fail to delete image: ");
                  stringBuilder1.append(file1.getAbsoluteFile());
                  Log.e("BrowserServiceFP", stringBuilder1.toString());
                  bool1 = false;
                } 
              } 
            } 
          } else {
            if (bool) {
              l1 = System.currentTimeMillis();
            } else {
              l1 = System.currentTimeMillis() - CLEANUP_REQUIRED_TIME_SPAN + DELETION_FAILED_REATTEMPT_DURATION;
            } 
            SharedPreferences.Editor editor = null.edit();
            editor.putLong("last_cleanup_time", l1);
            editor.apply();
            return null;
          } 
          i++;
          bool = bool1;
        } 
      } 
    }
  }
  
  private static class FileSaveTask extends AsyncTask<String, Void, Void> {
    private final Context mAppContext;
    
    private final Bitmap mBitmap;
    
    private final Uri mFileUri;
    
    private final String mFilename;
    
    private final ResolvableFuture<Uri> mResultFuture;
    
    FileSaveTask(Context param1Context, String param1String, Bitmap param1Bitmap, Uri param1Uri, ResolvableFuture<Uri> param1ResolvableFuture) {
      this.mAppContext = param1Context.getApplicationContext();
      this.mFilename = param1String;
      this.mBitmap = param1Bitmap;
      this.mFileUri = param1Uri;
      this.mResultFuture = param1ResolvableFuture;
    }
    
    private void saveFileBlocking(File param1File) {
      if (Build.VERSION.SDK_INT >= 22) {
        FileOutputStream fileOutputStream;
        AtomicFile atomicFile = new AtomicFile(param1File);
        try {
          fileOutputStream = atomicFile.startWrite();
          try {
            this.mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.close();
            atomicFile.finishWrite(fileOutputStream);
            this.mResultFuture.set(this.mFileUri);
            return;
          } catch (IOException null) {}
        } catch (IOException iOException) {
          fileOutputStream = null;
        } 
        atomicFile.failWrite(fileOutputStream);
        this.mResultFuture.setException(iOException);
        return;
      } 
      try {
        FileOutputStream fileOutputStream = new FileOutputStream((File)iOException);
        this.mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
        fileOutputStream.close();
        this.mResultFuture.set(this.mFileUri);
        return;
      } catch (IOException iOException1) {
        this.mResultFuture.setException(iOException1);
        return;
      } 
    }
    
    private void saveFileIfNeededBlocking() {
      null = new File(this.mAppContext.getFilesDir(), "image_provider");
      synchronized (BrowserServiceFileProvider.sFileCleanupLock) {
        if (!null.exists() && !null.mkdir()) {
          this.mResultFuture.setException(new IOException("Could not create file directory."));
          return;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.mFilename);
        stringBuilder.append(".png");
        null = new File(null, stringBuilder.toString());
        if (null.exists()) {
          this.mResultFuture.set(this.mFileUri);
        } else {
          saveFileBlocking(null);
        } 
        null.setLastModified(System.currentTimeMillis());
        return;
      } 
    }
    
    protected Void doInBackground(String... param1VarArgs) {
      saveFileIfNeededBlocking();
      return null;
    }
    
    protected void onPostExecute(Void param1Void) {
      (new BrowserServiceFileProvider.FileCleanupTask(this.mAppContext)).executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, (Object[])new Void[0]);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\browser\browseractions\BrowserServiceFileProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */