package androidx.concurrent.futures;

import java.util.concurrent.Executor;

enum DirectExecutor implements Executor {
  INSTANCE;
  
  static {
    DirectExecutor directExecutor = new DirectExecutor("INSTANCE", 0);
    INSTANCE = directExecutor;
    $VALUES = new DirectExecutor[] { directExecutor };
  }
  
  public void execute(Runnable paramRunnable) {
    paramRunnable.run();
  }
  
  public String toString() {
    return "DirectExecutor";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\concurrent\futures\DirectExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */