package androidx.constraintlayout.core.motion.utils;

import java.lang.reflect.Array;
import java.util.Arrays;

public class MonotonicCurveFit extends CurveFit {
  private static final String TAG = "MonotonicCurveFit";
  
  private boolean mExtrapolate = true;
  
  double[] mSlopeTemp;
  
  private double[] mT;
  
  private double[][] mTangent;
  
  private double[][] mY;
  
  public MonotonicCurveFit(double[] paramArrayOfdouble, double[][] paramArrayOfdouble1) {
    int m = paramArrayOfdouble.length;
    int j = (paramArrayOfdouble1[0]).length;
    this.mSlopeTemp = new double[j];
    int k = m - 1;
    double[][] arrayOfDouble1 = (double[][])Array.newInstance(double.class, new int[] { k, j });
    double[][] arrayOfDouble2 = (double[][])Array.newInstance(double.class, new int[] { m, j });
    int i;
    for (i = 0; i < j; i++) {
      int n;
      for (n = 0; n < k; n = i1) {
        int i1 = n + 1;
        double d1 = paramArrayOfdouble[i1];
        double d2 = paramArrayOfdouble[n];
        arrayOfDouble1[n][i] = (paramArrayOfdouble1[i1][i] - paramArrayOfdouble1[n][i]) / (d1 - d2);
        if (n == 0) {
          arrayOfDouble2[n][i] = arrayOfDouble1[n][i];
        } else {
          arrayOfDouble2[n][i] = (arrayOfDouble1[n - 1][i] + arrayOfDouble1[n][i]) * 0.5D;
        } 
      } 
      arrayOfDouble2[k][i] = arrayOfDouble1[m - 2][i];
    } 
    for (i = 0; i < k; i++) {
      int n;
      for (n = 0; n < j; n++) {
        if (arrayOfDouble1[i][n] == 0.0D) {
          arrayOfDouble2[i][n] = 0L;
          arrayOfDouble2[i + 1][n] = 0L;
        } else {
          double d1 = arrayOfDouble2[i][n] / arrayOfDouble1[i][n];
          int i1 = i + 1;
          double d2 = arrayOfDouble2[i1][n] / arrayOfDouble1[i][n];
          double d3 = Math.hypot(d1, d2);
          if (d3 > 9.0D) {
            d3 = 3.0D / d3;
            arrayOfDouble2[i][n] = d1 * d3 * arrayOfDouble1[i][n];
            arrayOfDouble2[i1][n] = d3 * d2 * arrayOfDouble1[i][n];
          } 
        } 
      } 
    } 
    this.mT = paramArrayOfdouble;
    this.mY = paramArrayOfdouble1;
    this.mTangent = arrayOfDouble2;
  }
  
  public static MonotonicCurveFit buildWave(String paramString) {
    double[] arrayOfDouble = new double[paramString.length() / 2];
    int j = paramString.indexOf('(') + 1;
    int k = paramString.indexOf(',', j);
    int i;
    for (i = 0; k != -1; i++) {
      arrayOfDouble[i] = Double.parseDouble(paramString.substring(j, k).trim());
      j = k + 1;
      k = paramString.indexOf(',', j);
    } 
    arrayOfDouble[i] = Double.parseDouble(paramString.substring(j, paramString.indexOf(')', j)).trim());
    return buildWave(Arrays.copyOf(arrayOfDouble, i + 1));
  }
  
  private static MonotonicCurveFit buildWave(double[] paramArrayOfdouble) {
    int i = paramArrayOfdouble.length * 3 - 2;
    int j = paramArrayOfdouble.length - 1;
    double d = 1.0D / j;
    double[][] arrayOfDouble = (double[][])Array.newInstance(double.class, new int[] { i, 1 });
    double[] arrayOfDouble1 = new double[i];
    for (i = 0; i < paramArrayOfdouble.length; i++) {
      double d1 = paramArrayOfdouble[i];
      int k = i + j;
      arrayOfDouble[k][0] = d1;
      double d2 = i * d;
      arrayOfDouble1[k] = d2;
      if (i > 0) {
        k = j * 2 + i;
        arrayOfDouble[k][0] = d1 + 1.0D;
        arrayOfDouble1[k] = d2 + 1.0D;
        k = i - 1;
        arrayOfDouble[k][0] = d1 - 1.0D - d;
        arrayOfDouble1[k] = d2 - 1.0D - d;
      } 
    } 
    return new MonotonicCurveFit(arrayOfDouble1, arrayOfDouble);
  }
  
  private static double diff(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    double d1 = paramDouble2 * paramDouble2;
    double d2 = paramDouble2 * 6.0D;
    double d3 = 3.0D * paramDouble1;
    return -6.0D * d1 * paramDouble4 + d2 * paramDouble4 + 6.0D * d1 * paramDouble3 - d2 * paramDouble3 + d3 * paramDouble6 * d1 + d3 * paramDouble5 * d1 - 2.0D * paramDouble1 * paramDouble6 * paramDouble2 - 4.0D * paramDouble1 * paramDouble5 * paramDouble2 + paramDouble1 * paramDouble5;
  }
  
  private static double interpolate(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    double d1 = paramDouble2 * paramDouble2;
    double d2 = d1 * paramDouble2;
    double d3 = 3.0D * d1;
    paramDouble6 = paramDouble1 * paramDouble6;
    double d4 = paramDouble1 * paramDouble5;
    return -2.0D * d2 * paramDouble4 + d3 * paramDouble4 + d2 * 2.0D * paramDouble3 - d3 * paramDouble3 + paramDouble3 + paramDouble6 * d2 + d2 * d4 - paramDouble6 * d1 - paramDouble1 * 2.0D * paramDouble5 * d1 + d4 * paramDouble2;
  }
  
  public double getPos(double paramDouble, int paramInt) {
    double[] arrayOfDouble = this.mT;
    int j = arrayOfDouble.length;
    boolean bool = this.mExtrapolate;
    int i = 0;
    if (bool) {
      if (paramDouble <= arrayOfDouble[0])
        return this.mY[0][paramInt] + (paramDouble - arrayOfDouble[0]) * getSlope(arrayOfDouble[0], paramInt); 
      int k = j - 1;
      if (paramDouble >= arrayOfDouble[k])
        return this.mY[k][paramInt] + (paramDouble - arrayOfDouble[k]) * getSlope(arrayOfDouble[k], paramInt); 
    } else {
      if (paramDouble <= arrayOfDouble[0])
        return this.mY[0][paramInt]; 
      int k = j - 1;
      if (paramDouble >= arrayOfDouble[k])
        return this.mY[k][paramInt]; 
    } 
    while (i < j - 1) {
      arrayOfDouble = this.mT;
      if (paramDouble == arrayOfDouble[i])
        return this.mY[i][paramInt]; 
      int k = i + 1;
      if (paramDouble < arrayOfDouble[k]) {
        double d1 = arrayOfDouble[k] - arrayOfDouble[i];
        paramDouble = (paramDouble - arrayOfDouble[i]) / d1;
        double[][] arrayOfDouble1 = this.mY;
        double d2 = arrayOfDouble1[i][paramInt];
        double d3 = arrayOfDouble1[k][paramInt];
        arrayOfDouble1 = this.mTangent;
        return interpolate(d1, paramDouble, d2, d3, arrayOfDouble1[i][paramInt], arrayOfDouble1[k][paramInt]);
      } 
      i = k;
    } 
    return 0.0D;
  }
  
  public void getPos(double paramDouble, double[] paramArrayOfdouble) {
    double[] arrayOfDouble = this.mT;
    int m = arrayOfDouble.length;
    double[][] arrayOfDouble1 = this.mY;
    int j = 0;
    boolean bool = false;
    int i = 0;
    int k = (arrayOfDouble1[0]).length;
    if (this.mExtrapolate) {
      if (paramDouble <= arrayOfDouble[0]) {
        getSlope(arrayOfDouble[0], this.mSlopeTemp);
        for (i = 0; i < k; i++)
          paramArrayOfdouble[i] = this.mY[0][i] + (paramDouble - this.mT[0]) * this.mSlopeTemp[i]; 
        return;
      } 
      j = m - 1;
      if (paramDouble >= arrayOfDouble[j]) {
        getSlope(arrayOfDouble[j], this.mSlopeTemp);
        while (i < k) {
          paramArrayOfdouble[i] = this.mY[j][i] + (paramDouble - this.mT[j]) * this.mSlopeTemp[i];
          i++;
        } 
        return;
      } 
    } else {
      if (paramDouble <= arrayOfDouble[0]) {
        for (i = 0; i < k; i++)
          paramArrayOfdouble[i] = this.mY[0][i]; 
        return;
      } 
      int n = m - 1;
      if (paramDouble >= arrayOfDouble[n]) {
        for (i = j; i < k; i++)
          paramArrayOfdouble[i] = this.mY[n][i]; 
        return;
      } 
    } 
    for (i = 0; i < m - 1; i = n) {
      if (paramDouble == this.mT[i])
        for (j = 0; j < k; j++)
          paramArrayOfdouble[j] = this.mY[i][j];  
      arrayOfDouble = this.mT;
      int n = i + 1;
      if (paramDouble < arrayOfDouble[n]) {
        double d = arrayOfDouble[n] - arrayOfDouble[i];
        paramDouble = (paramDouble - arrayOfDouble[i]) / d;
        for (j = bool; j < k; j++) {
          double[][] arrayOfDouble2 = this.mY;
          double d1 = arrayOfDouble2[i][j];
          double d2 = arrayOfDouble2[n][j];
          arrayOfDouble2 = this.mTangent;
          paramArrayOfdouble[j] = interpolate(d, paramDouble, d1, d2, arrayOfDouble2[i][j], arrayOfDouble2[n][j]);
        } 
        return;
      } 
    } 
  }
  
  public void getPos(double paramDouble, float[] paramArrayOffloat) {
    double[] arrayOfDouble = this.mT;
    int m = arrayOfDouble.length;
    double[][] arrayOfDouble1 = this.mY;
    int j = 0;
    boolean bool = false;
    int i = 0;
    int k = (arrayOfDouble1[0]).length;
    if (this.mExtrapolate) {
      if (paramDouble <= arrayOfDouble[0]) {
        getSlope(arrayOfDouble[0], this.mSlopeTemp);
        for (i = 0; i < k; i++)
          paramArrayOffloat[i] = (float)(this.mY[0][i] + (paramDouble - this.mT[0]) * this.mSlopeTemp[i]); 
        return;
      } 
      j = m - 1;
      if (paramDouble >= arrayOfDouble[j]) {
        getSlope(arrayOfDouble[j], this.mSlopeTemp);
        while (i < k) {
          paramArrayOffloat[i] = (float)(this.mY[j][i] + (paramDouble - this.mT[j]) * this.mSlopeTemp[i]);
          i++;
        } 
        return;
      } 
    } else {
      if (paramDouble <= arrayOfDouble[0]) {
        for (i = 0; i < k; i++)
          paramArrayOffloat[i] = (float)this.mY[0][i]; 
        return;
      } 
      int n = m - 1;
      if (paramDouble >= arrayOfDouble[n]) {
        for (i = j; i < k; i++)
          paramArrayOffloat[i] = (float)this.mY[n][i]; 
        return;
      } 
    } 
    for (i = 0; i < m - 1; i = n) {
      if (paramDouble == this.mT[i])
        for (j = 0; j < k; j++)
          paramArrayOffloat[j] = (float)this.mY[i][j];  
      arrayOfDouble = this.mT;
      int n = i + 1;
      if (paramDouble < arrayOfDouble[n]) {
        double d = arrayOfDouble[n] - arrayOfDouble[i];
        paramDouble = (paramDouble - arrayOfDouble[i]) / d;
        for (j = bool; j < k; j++) {
          double[][] arrayOfDouble2 = this.mY;
          double d1 = arrayOfDouble2[i][j];
          double d2 = arrayOfDouble2[n][j];
          arrayOfDouble2 = this.mTangent;
          paramArrayOffloat[j] = (float)interpolate(d, paramDouble, d1, d2, arrayOfDouble2[i][j], arrayOfDouble2[n][j]);
        } 
        return;
      } 
    } 
  }
  
  public double getSlope(double paramDouble, int paramInt) {
    double[] arrayOfDouble = this.mT;
    int j = arrayOfDouble.length;
    int i = 0;
    if (paramDouble < arrayOfDouble[0]) {
      paramDouble = arrayOfDouble[0];
    } else {
      int k = j - 1;
      if (paramDouble >= arrayOfDouble[k])
        paramDouble = arrayOfDouble[k]; 
    } 
    while (i < j - 1) {
      arrayOfDouble = this.mT;
      int k = i + 1;
      if (paramDouble <= arrayOfDouble[k]) {
        double d1 = arrayOfDouble[k] - arrayOfDouble[i];
        paramDouble = (paramDouble - arrayOfDouble[i]) / d1;
        double[][] arrayOfDouble1 = this.mY;
        double d2 = arrayOfDouble1[i][paramInt];
        double d3 = arrayOfDouble1[k][paramInt];
        arrayOfDouble1 = this.mTangent;
        return diff(d1, paramDouble, d2, d3, arrayOfDouble1[i][paramInt], arrayOfDouble1[k][paramInt]) / d1;
      } 
      i = k;
    } 
    return 0.0D;
  }
  
  public void getSlope(double paramDouble, double[] paramArrayOfdouble) {
    double[] arrayOfDouble = this.mT;
    int m = arrayOfDouble.length;
    double[][] arrayOfDouble1 = this.mY;
    int j = 0;
    int k = (arrayOfDouble1[0]).length;
    if (paramDouble <= arrayOfDouble[0]) {
      paramDouble = arrayOfDouble[0];
    } else {
      int n = m - 1;
      if (paramDouble >= arrayOfDouble[n])
        paramDouble = arrayOfDouble[n]; 
    } 
    int i;
    for (i = 0; i < m - 1; i = n) {
      arrayOfDouble = this.mT;
      int n = i + 1;
      if (paramDouble <= arrayOfDouble[n]) {
        double d = arrayOfDouble[n] - arrayOfDouble[i];
        paramDouble = (paramDouble - arrayOfDouble[i]) / d;
        while (j < k) {
          double[][] arrayOfDouble2 = this.mY;
          double d1 = arrayOfDouble2[i][j];
          double d2 = arrayOfDouble2[n][j];
          arrayOfDouble2 = this.mTangent;
          paramArrayOfdouble[j] = diff(d, paramDouble, d1, d2, arrayOfDouble2[i][j], arrayOfDouble2[n][j]) / d;
          j++;
        } 
        break;
      } 
    } 
  }
  
  public double[] getTimePoints() {
    return this.mT;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\MonotonicCurveFit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */