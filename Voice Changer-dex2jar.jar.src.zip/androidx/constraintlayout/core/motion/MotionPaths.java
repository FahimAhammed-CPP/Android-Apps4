package androidx.constraintlayout.core.motion;

import androidx.constraintlayout.core.motion.key.MotionKeyPosition;
import androidx.constraintlayout.core.motion.utils.Easing;
import java.util.HashMap;

public class MotionPaths implements Comparable<MotionPaths> {
  public static final int CARTESIAN = 0;
  
  public static final boolean DEBUG = false;
  
  static final int OFF_HEIGHT = 4;
  
  static final int OFF_PATH_ROTATE = 5;
  
  static final int OFF_POSITION = 0;
  
  static final int OFF_WIDTH = 3;
  
  static final int OFF_X = 1;
  
  static final int OFF_Y = 2;
  
  public static final boolean OLD_WAY = false;
  
  public static final int PERPENDICULAR = 1;
  
  public static final int SCREEN = 2;
  
  public static final String TAG = "MotionPaths";
  
  static String[] names = new String[] { "position", "x", "y", "width", "height", "pathRotate" };
  
  HashMap<String, CustomVariable> customAttributes = new HashMap<String, CustomVariable>();
  
  float height;
  
  int mAnimateCircleAngleTo;
  
  int mAnimateRelativeTo = -1;
  
  int mDrawPath = 0;
  
  Easing mKeyFrameEasing;
  
  int mMode = 0;
  
  int mPathMotionArc = -1;
  
  float mPathRotate = Float.NaN;
  
  float mProgress = Float.NaN;
  
  float mRelativeAngle = Float.NaN;
  
  Motion mRelativeToController = null;
  
  double[] mTempDelta = new double[18];
  
  double[] mTempValue = new double[18];
  
  float position;
  
  float time;
  
  float width;
  
  float x;
  
  float y;
  
  public MotionPaths() {}
  
  public MotionPaths(int paramInt1, int paramInt2, MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    if (paramMotionPaths1.mAnimateRelativeTo != -1) {
      initPolar(paramInt1, paramInt2, paramMotionKeyPosition, paramMotionPaths1, paramMotionPaths2);
      return;
    } 
    int i = paramMotionKeyPosition.mPositionType;
    if (i != 1) {
      if (i != 2) {
        initCartesian(paramMotionKeyPosition, paramMotionPaths1, paramMotionPaths2);
        return;
      } 
      initScreen(paramInt1, paramInt2, paramMotionKeyPosition, paramMotionPaths1, paramMotionPaths2);
      return;
    } 
    initPath(paramMotionKeyPosition, paramMotionPaths1, paramMotionPaths2);
  }
  
  private boolean diff(float paramFloat1, float paramFloat2) {
    return (Float.isNaN(paramFloat1) || Float.isNaN(paramFloat2)) ? ((Float.isNaN(paramFloat1) != Float.isNaN(paramFloat2))) : ((Math.abs(paramFloat1 - paramFloat2) > 1.0E-6F));
  }
  
  private static final float xRotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    return (paramFloat5 - paramFloat3) * paramFloat2 - (paramFloat6 - paramFloat4) * paramFloat1 + paramFloat3;
  }
  
  private static final float yRotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    return (paramFloat5 - paramFloat3) * paramFloat1 + (paramFloat6 - paramFloat4) * paramFloat2 + paramFloat4;
  }
  
  public void applyParameters(MotionWidget paramMotionWidget) {
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionWidget.motion.mTransitionEasing);
    this.mPathMotionArc = paramMotionWidget.motion.mPathMotionArc;
    this.mAnimateRelativeTo = paramMotionWidget.motion.mAnimateRelativeTo;
    this.mPathRotate = paramMotionWidget.motion.mPathRotate;
    this.mDrawPath = paramMotionWidget.motion.mDrawPath;
    this.mAnimateCircleAngleTo = paramMotionWidget.motion.mAnimateCircleAngleTo;
    this.mProgress = paramMotionWidget.propertySet.mProgress;
    this.mRelativeAngle = 0.0F;
    for (String str : paramMotionWidget.getCustomAttributeNames()) {
      CustomVariable customVariable = paramMotionWidget.getCustomAttribute(str);
      if (customVariable != null && customVariable.isContinuous())
        this.customAttributes.put(str, customVariable); 
    } 
  }
  
  public int compareTo(MotionPaths paramMotionPaths) {
    return Float.compare(this.position, paramMotionPaths.position);
  }
  
  public void configureRelativeTo(Motion paramMotion) {
    paramMotion.getPos(this.mProgress);
  }
  
  void different(MotionPaths paramMotionPaths, boolean[] paramArrayOfboolean, String[] paramArrayOfString, boolean paramBoolean) {
    boolean bool2 = diff(this.x, paramMotionPaths.x);
    boolean bool3 = diff(this.y, paramMotionPaths.y);
    paramArrayOfboolean[0] = paramArrayOfboolean[0] | diff(this.position, paramMotionPaths.position);
    boolean bool4 = paramArrayOfboolean[1];
    boolean bool1 = bool2 | bool3 | paramBoolean;
    paramArrayOfboolean[1] = bool4 | bool1;
    paramArrayOfboolean[2] = bool1 | paramArrayOfboolean[2];
    paramArrayOfboolean[3] = paramArrayOfboolean[3] | diff(this.width, paramMotionPaths.width);
    paramBoolean = paramArrayOfboolean[4];
    paramArrayOfboolean[4] = diff(this.height, paramMotionPaths.height) | paramBoolean;
  }
  
  void fillStandard(double[] paramArrayOfdouble, int[] paramArrayOfint) {
    float f1 = this.position;
    int i = 0;
    float f2 = this.x;
    float f3 = this.y;
    float f4 = this.width;
    float f5 = this.height;
    float f6 = this.mPathRotate;
    int j;
    for (j = 0; i < paramArrayOfint.length; j = k) {
      int k = j;
      if (paramArrayOfint[i] < 6) {
        k = paramArrayOfint[i];
        (new float[6])[0] = f1;
        (new float[6])[1] = f2;
        (new float[6])[2] = f3;
        (new float[6])[3] = f4;
        (new float[6])[4] = f5;
        (new float[6])[5] = f6;
        paramArrayOfdouble[j] = (new float[6])[k];
        k = j + 1;
      } 
      i++;
    } 
  }
  
  void getBounds(int[] paramArrayOfint, double[] paramArrayOfdouble, float[] paramArrayOffloat, int paramInt) {
    float f2 = this.width;
    float f1 = this.height;
    int i;
    for (i = 0; i < paramArrayOfint.length; i++) {
      float f = (float)paramArrayOfdouble[i];
      int j = paramArrayOfint[i];
      if (j != 3) {
        if (j == 4)
          f1 = f; 
      } else {
        f2 = f;
      } 
    } 
    paramArrayOffloat[paramInt] = f2;
    paramArrayOffloat[paramInt + 1] = f1;
  }
  
  void getCenter(double paramDouble, int[] paramArrayOfint, double[] paramArrayOfdouble, float[] paramArrayOffloat, int paramInt) {
    float f3 = this.x;
    float f2 = this.y;
    float f5 = this.width;
    float f4 = this.height;
    int i;
    for (i = 0; i < paramArrayOfint.length; i++) {
      float f = (float)paramArrayOfdouble[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4)
              f4 = f; 
          } else {
            f5 = f;
          } 
        } else {
          f2 = f;
        } 
      } else {
        f3 = f;
      } 
    } 
    Motion motion = this.mRelativeToController;
    float f6 = f3;
    float f1 = f2;
    if (motion != null) {
      float[] arrayOfFloat = new float[2];
      motion.getCenter(paramDouble, arrayOfFloat, new float[2]);
      f6 = arrayOfFloat[0];
      f1 = arrayOfFloat[1];
      paramDouble = f6;
      double d1 = f3;
      double d2 = f2;
      f2 = (float)(paramDouble + Math.sin(d2) * d1 - (f5 / 2.0F));
      f1 = (float)(f1 - d1 * Math.cos(d2) - (f4 / 2.0F));
      f6 = f2;
    } 
    paramArrayOffloat[paramInt] = f6 + f5 / 2.0F + 0.0F;
    paramArrayOffloat[paramInt + 1] = f1 + f4 / 2.0F + 0.0F;
  }
  
  void getCenter(double paramDouble, int[] paramArrayOfint, double[] paramArrayOfdouble1, float[] paramArrayOffloat1, double[] paramArrayOfdouble2, float[] paramArrayOffloat2) {
    float f3 = this.x;
    float f4 = this.y;
    float f6 = this.width;
    float f5 = this.height;
    int i = 0;
    float f8 = 0.0F;
    float f10 = 0.0F;
    float f7 = 0.0F;
    float f9 = 0.0F;
    while (i < paramArrayOfint.length) {
      float f12 = (float)paramArrayOfdouble1[i];
      float f11 = (float)paramArrayOfdouble2[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4) {
              f5 = f12;
              f9 = f11;
            } 
          } else {
            f6 = f12;
            f10 = f11;
          } 
        } else {
          f4 = f12;
          f7 = f11;
        } 
      } else {
        f8 = f11;
        f3 = f12;
      } 
      i++;
    } 
    float f1 = f10 / 2.0F + f8;
    float f2 = f9 / 2.0F + f7;
    Motion motion = this.mRelativeToController;
    if (motion != null) {
      float[] arrayOfFloat1 = new float[2];
      float[] arrayOfFloat2 = new float[2];
      motion.getCenter(paramDouble, arrayOfFloat1, arrayOfFloat2);
      f10 = arrayOfFloat1[0];
      f9 = arrayOfFloat1[1];
      f1 = arrayOfFloat2[0];
      f2 = arrayOfFloat2[1];
      double d1 = f10;
      double d2 = f3;
      paramDouble = f4;
      f3 = (float)(d1 + Math.sin(paramDouble) * d2 - (f6 / 2.0F));
      f4 = (float)(f9 - d2 * Math.cos(paramDouble) - (f5 / 2.0F));
      d1 = f1;
      d2 = f8;
      double d3 = Math.sin(paramDouble);
      double d4 = Math.cos(paramDouble);
      double d5 = f7;
      f1 = (float)(d1 + d3 * d2 + d4 * d5);
      f2 = (float)(f2 - d2 * Math.cos(paramDouble) + Math.sin(paramDouble) * d5);
    } 
    paramArrayOffloat1[0] = f3 + f6 / 2.0F + 0.0F;
    paramArrayOffloat1[1] = f4 + f5 / 2.0F + 0.0F;
    paramArrayOffloat2[0] = f1;
    paramArrayOffloat2[1] = f2;
  }
  
  void getCenterVelocity(double paramDouble, int[] paramArrayOfint, double[] paramArrayOfdouble, float[] paramArrayOffloat, int paramInt) {
    float f3 = this.x;
    float f2 = this.y;
    float f5 = this.width;
    float f4 = this.height;
    int i;
    for (i = 0; i < paramArrayOfint.length; i++) {
      float f = (float)paramArrayOfdouble[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4)
              f4 = f; 
          } else {
            f5 = f;
          } 
        } else {
          f2 = f;
        } 
      } else {
        f3 = f;
      } 
    } 
    Motion motion = this.mRelativeToController;
    float f6 = f3;
    float f1 = f2;
    if (motion != null) {
      float[] arrayOfFloat = new float[2];
      motion.getCenter(paramDouble, arrayOfFloat, new float[2]);
      f6 = arrayOfFloat[0];
      f1 = arrayOfFloat[1];
      paramDouble = f6;
      double d1 = f3;
      double d2 = f2;
      f2 = (float)(paramDouble + Math.sin(d2) * d1 - (f5 / 2.0F));
      f1 = (float)(f1 - d1 * Math.cos(d2) - (f4 / 2.0F));
      f6 = f2;
    } 
    paramArrayOffloat[paramInt] = f6 + f5 / 2.0F + 0.0F;
    paramArrayOffloat[paramInt + 1] = f1 + f4 / 2.0F + 0.0F;
  }
  
  int getCustomData(String paramString, double[] paramArrayOfdouble, int paramInt) {
    CustomVariable customVariable = this.customAttributes.get(paramString);
    int i = 0;
    if (customVariable == null)
      return 0; 
    if (customVariable.numberOfInterpolatedValues() == 1) {
      paramArrayOfdouble[paramInt] = customVariable.getValueToInterpolate();
      return 1;
    } 
    int j = customVariable.numberOfInterpolatedValues();
    float[] arrayOfFloat = new float[j];
    customVariable.getValuesToInterpolate(arrayOfFloat);
    while (i < j) {
      paramArrayOfdouble[paramInt] = arrayOfFloat[i];
      i++;
      paramInt++;
    } 
    return j;
  }
  
  int getCustomDataCount(String paramString) {
    CustomVariable customVariable = this.customAttributes.get(paramString);
    return (customVariable == null) ? 0 : customVariable.numberOfInterpolatedValues();
  }
  
  void getRect(int[] paramArrayOfint, double[] paramArrayOfdouble, float[] paramArrayOffloat, int paramInt) {
    float f3 = this.x;
    float f2 = this.y;
    float f5 = this.width;
    float f4 = this.height;
    int i;
    for (i = 0; i < paramArrayOfint.length; i++) {
      float f = (float)paramArrayOfdouble[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4)
              f4 = f; 
          } else {
            f5 = f;
          } 
        } else {
          f2 = f;
        } 
      } else {
        f3 = f;
      } 
    } 
    Motion motion = this.mRelativeToController;
    float f6 = f3;
    float f1 = f2;
    if (motion != null) {
      f6 = motion.getCenterX();
      f1 = this.mRelativeToController.getCenterY();
      double d1 = f6;
      double d2 = f3;
      double d3 = f2;
      f6 = (float)(d1 + Math.sin(d3) * d2 - (f5 / 2.0F));
      f1 = (float)(f1 - d2 * Math.cos(d3) - (f4 / 2.0F));
    } 
    f2 = f5 + f6;
    f3 = f4 + f1;
    Float.isNaN(Float.NaN);
    Float.isNaN(Float.NaN);
    i = paramInt + 1;
    paramArrayOffloat[paramInt] = f6 + 0.0F;
    paramInt = i + 1;
    paramArrayOffloat[i] = f1 + 0.0F;
    i = paramInt + 1;
    paramArrayOffloat[paramInt] = f2 + 0.0F;
    paramInt = i + 1;
    paramArrayOffloat[i] = f1 + 0.0F;
    i = paramInt + 1;
    paramArrayOffloat[paramInt] = f2 + 0.0F;
    paramInt = i + 1;
    paramArrayOffloat[i] = f3 + 0.0F;
    paramArrayOffloat[paramInt] = f6 + 0.0F;
    paramArrayOffloat[paramInt + 1] = f3 + 0.0F;
  }
  
  boolean hasCustomData(String paramString) {
    return this.customAttributes.containsKey(paramString);
  }
  
  void initCartesian(MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    float f1 = paramMotionKeyPosition.mFramePosition / 100.0F;
    this.time = f1;
    this.mDrawPath = paramMotionKeyPosition.mDrawPath;
    if (Float.isNaN(paramMotionKeyPosition.mPercentWidth)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentWidth;
    } 
    if (Float.isNaN(paramMotionKeyPosition.mPercentHeight)) {
      f3 = f1;
    } else {
      f3 = paramMotionKeyPosition.mPercentHeight;
    } 
    float f7 = paramMotionPaths2.width;
    float f4 = paramMotionPaths1.width;
    float f10 = paramMotionPaths2.height;
    float f8 = paramMotionPaths1.height;
    this.position = this.time;
    float f11 = paramMotionPaths1.x;
    float f5 = f4 / 2.0F;
    float f9 = paramMotionPaths1.y;
    float f6 = f8 / 2.0F;
    float f14 = paramMotionPaths2.x;
    float f15 = f7 / 2.0F;
    float f12 = paramMotionPaths2.y;
    float f13 = f10 / 2.0F;
    f5 = f14 + f15 - f5 + f11;
    f6 = f12 + f13 - f9 + f6;
    float f2 = (f7 - f4) * f2;
    f7 = f2 / 2.0F;
    this.x = (int)(f11 + f5 * f1 - f7);
    float f3 = (f10 - f8) * f3;
    f10 = f3 / 2.0F;
    this.y = (int)(f9 + f6 * f1 - f10);
    this.width = (int)(f4 + f2);
    this.height = (int)(f8 + f3);
    if (Float.isNaN(paramMotionKeyPosition.mPercentX)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentX;
    } 
    boolean bool = Float.isNaN(paramMotionKeyPosition.mAltPercentY);
    f4 = 0.0F;
    if (bool) {
      f3 = 0.0F;
    } else {
      f3 = paramMotionKeyPosition.mAltPercentY;
    } 
    if (!Float.isNaN(paramMotionKeyPosition.mPercentY))
      f1 = paramMotionKeyPosition.mPercentY; 
    if (!Float.isNaN(paramMotionKeyPosition.mAltPercentX))
      f4 = paramMotionKeyPosition.mAltPercentX; 
    this.mMode = 0;
    this.x = (int)(paramMotionPaths1.x + f2 * f5 + f4 * f6 - f7);
    this.y = (int)(paramMotionPaths1.y + f5 * f3 + f6 * f1 - f10);
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionKeyPosition.mTransitionEasing);
    this.mPathMotionArc = paramMotionKeyPosition.mPathMotionArc;
  }
  
  void initPath(MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    float f1 = paramMotionKeyPosition.mFramePosition / 100.0F;
    this.time = f1;
    this.mDrawPath = paramMotionKeyPosition.mDrawPath;
    if (Float.isNaN(paramMotionKeyPosition.mPercentWidth)) {
      f3 = f1;
    } else {
      f3 = paramMotionKeyPosition.mPercentWidth;
    } 
    if (Float.isNaN(paramMotionKeyPosition.mPercentHeight)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentHeight;
    } 
    float f11 = paramMotionPaths2.width;
    float f12 = paramMotionPaths1.width;
    float f5 = paramMotionPaths2.height;
    float f6 = paramMotionPaths1.height;
    this.position = this.time;
    if (!Float.isNaN(paramMotionKeyPosition.mPercentX))
      f1 = paramMotionKeyPosition.mPercentX; 
    float f13 = paramMotionPaths1.x;
    float f7 = paramMotionPaths1.width;
    float f4 = f7 / 2.0F;
    float f8 = paramMotionPaths1.y;
    float f9 = paramMotionPaths1.height;
    float f10 = f9 / 2.0F;
    float f16 = paramMotionPaths2.x;
    float f17 = paramMotionPaths2.width / 2.0F;
    float f14 = paramMotionPaths2.y;
    float f15 = paramMotionPaths2.height / 2.0F;
    f4 = f16 + f17 - f4 + f13;
    f14 = f14 + f15 - f10 + f8;
    f10 = f4 * f1;
    f12 = (f11 - f12) * f3;
    float f3 = f12 / 2.0F;
    this.x = (int)(f13 + f10 - f3);
    f11 = f1 * f14;
    f1 = (f5 - f6) * f2;
    float f2 = f1 / 2.0F;
    this.y = (int)(f8 + f11 - f2);
    this.width = (int)(f7 + f12);
    this.height = (int)(f9 + f1);
    if (Float.isNaN(paramMotionKeyPosition.mPercentY)) {
      f1 = 0.0F;
    } else {
      f1 = paramMotionKeyPosition.mPercentY;
    } 
    f5 = -f14;
    this.mMode = 1;
    f3 = (int)(paramMotionPaths1.x + f10 - f3);
    this.x = f3;
    f2 = (int)(paramMotionPaths1.y + f11 - f2);
    this.x = f3 + f5 * f1;
    this.y = f2 + f4 * f1;
    this.mAnimateRelativeTo = this.mAnimateRelativeTo;
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionKeyPosition.mTransitionEasing);
    this.mPathMotionArc = paramMotionKeyPosition.mPathMotionArc;
  }
  
  void initPolar(int paramInt1, int paramInt2, MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    float f2;
    float f3;
    float f1 = paramMotionKeyPosition.mFramePosition / 100.0F;
    this.time = f1;
    this.mDrawPath = paramMotionKeyPosition.mDrawPath;
    this.mMode = paramMotionKeyPosition.mPositionType;
    if (Float.isNaN(paramMotionKeyPosition.mPercentWidth)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentWidth;
    } 
    if (Float.isNaN(paramMotionKeyPosition.mPercentHeight)) {
      f3 = f1;
    } else {
      f3 = paramMotionKeyPosition.mPercentHeight;
    } 
    float f4 = paramMotionPaths2.width;
    float f5 = paramMotionPaths1.width;
    float f6 = paramMotionPaths2.height;
    float f7 = paramMotionPaths1.height;
    this.position = this.time;
    this.width = (int)(f5 + (f4 - f5) * f2);
    this.height = (int)(f7 + (f6 - f7) * f3);
    paramInt1 = paramMotionKeyPosition.mPositionType;
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (Float.isNaN(paramMotionKeyPosition.mPercentX)) {
          f2 = f1;
        } else {
          f2 = paramMotionKeyPosition.mPercentX;
        } 
        f3 = paramMotionPaths2.x;
        f4 = paramMotionPaths1.x;
        this.x = f2 * (f3 - f4) + f4;
        if (!Float.isNaN(paramMotionKeyPosition.mPercentY))
          f1 = paramMotionKeyPosition.mPercentY; 
        f2 = paramMotionPaths2.y;
        f3 = paramMotionPaths1.y;
        this.y = f1 * (f2 - f3) + f3;
      } else {
        if (Float.isNaN(paramMotionKeyPosition.mPercentX)) {
          f2 = paramMotionPaths2.x;
          f3 = paramMotionPaths1.x;
          f2 = (f2 - f3) * f1 + f3;
        } else {
          f4 = paramMotionKeyPosition.mPercentX;
          f2 = Math.min(f3, f2) * f4;
        } 
        this.x = f2;
        if (Float.isNaN(paramMotionKeyPosition.mPercentY)) {
          f2 = paramMotionPaths2.y;
          f3 = paramMotionPaths1.y;
          f1 = f1 * (f2 - f3) + f3;
        } else {
          f1 = paramMotionKeyPosition.mPercentY;
        } 
        this.y = f1;
      } 
    } else {
      if (Float.isNaN(paramMotionKeyPosition.mPercentX)) {
        f2 = f1;
      } else {
        f2 = paramMotionKeyPosition.mPercentX;
      } 
      f3 = paramMotionPaths2.x;
      f4 = paramMotionPaths1.x;
      this.x = f2 * (f3 - f4) + f4;
      if (!Float.isNaN(paramMotionKeyPosition.mPercentY))
        f1 = paramMotionKeyPosition.mPercentY; 
      f2 = paramMotionPaths2.y;
      f3 = paramMotionPaths1.y;
      this.y = f1 * (f2 - f3) + f3;
    } 
    this.mAnimateRelativeTo = paramMotionPaths1.mAnimateRelativeTo;
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionKeyPosition.mTransitionEasing);
    this.mPathMotionArc = paramMotionKeyPosition.mPathMotionArc;
  }
  
  void initScreen(int paramInt1, int paramInt2, MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    float f1 = paramMotionKeyPosition.mFramePosition / 100.0F;
    this.time = f1;
    this.mDrawPath = paramMotionKeyPosition.mDrawPath;
    if (Float.isNaN(paramMotionKeyPosition.mPercentWidth)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentWidth;
    } 
    if (Float.isNaN(paramMotionKeyPosition.mPercentHeight)) {
      f3 = f1;
    } else {
      f3 = paramMotionKeyPosition.mPercentHeight;
    } 
    float f15 = paramMotionPaths2.width;
    float f4 = paramMotionPaths1.width;
    float f10 = paramMotionPaths2.height;
    float f5 = paramMotionPaths1.height;
    this.position = this.time;
    float f11 = paramMotionPaths1.x;
    float f12 = f4 / 2.0F;
    float f6 = paramMotionPaths1.y;
    float f7 = f5 / 2.0F;
    float f13 = paramMotionPaths2.x;
    float f14 = f15 / 2.0F;
    float f8 = paramMotionPaths2.y;
    float f9 = f10 / 2.0F;
    float f2 = (f15 - f4) * f2;
    this.x = (int)(f11 + (f13 + f14 - f12 + f11) * f1 - f2 / 2.0F);
    float f3 = (f10 - f5) * f3;
    this.y = (int)(f6 + (f8 + f9 - f6 + f7) * f1 - f3 / 2.0F);
    this.width = (int)(f4 + f2);
    this.height = (int)(f5 + f3);
    this.mMode = 2;
    if (!Float.isNaN(paramMotionKeyPosition.mPercentX)) {
      paramInt1 = (int)(paramInt1 - this.width);
      this.x = (int)(paramMotionKeyPosition.mPercentX * paramInt1);
    } 
    if (!Float.isNaN(paramMotionKeyPosition.mPercentY)) {
      paramInt1 = (int)(paramInt2 - this.height);
      this.y = (int)(paramMotionKeyPosition.mPercentY * paramInt1);
    } 
    this.mAnimateRelativeTo = this.mAnimateRelativeTo;
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionKeyPosition.mTransitionEasing);
    this.mPathMotionArc = paramMotionKeyPosition.mPathMotionArc;
  }
  
  void setBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.width = paramFloat3;
    this.height = paramFloat4;
  }
  
  void setDpDt(float paramFloat1, float paramFloat2, float[] paramArrayOffloat, int[] paramArrayOfint, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2) {
    int i = 0;
    float f5 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f2 = 0.0F;
    while (i < paramArrayOfint.length) {
      float f = (float)paramArrayOfdouble1[i];
      double d = paramArrayOfdouble2[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4)
              f2 = f; 
          } else {
            f3 = f;
          } 
        } else {
          f4 = f;
        } 
      } else {
        f5 = f;
      } 
      i++;
    } 
    float f1 = f5 - 0.0F * f3 / 2.0F;
    f4 -= 0.0F * f2 / 2.0F;
    paramArrayOffloat[0] = f1 * (1.0F - paramFloat1) + (f3 * 1.0F + f1) * paramFloat1 + 0.0F;
    paramArrayOffloat[1] = f4 * (1.0F - paramFloat2) + (f2 * 1.0F + f4) * paramFloat2 + 0.0F;
  }
  
  void setView(float paramFloat, MotionWidget paramMotionWidget, int[] paramArrayOfint, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3) {
    // Byte code:
    //   0: aload_0
    //   1: getfield x : F
    //   4: fstore #26
    //   6: aload_0
    //   7: getfield y : F
    //   10: fstore #25
    //   12: aload_0
    //   13: getfield width : F
    //   16: fstore #28
    //   18: aload_0
    //   19: getfield height : F
    //   22: fstore #27
    //   24: aload_3
    //   25: arraylength
    //   26: ifeq -> 69
    //   29: aload_0
    //   30: getfield mTempValue : [D
    //   33: arraylength
    //   34: aload_3
    //   35: aload_3
    //   36: arraylength
    //   37: iconst_1
    //   38: isub
    //   39: iaload
    //   40: if_icmpgt -> 69
    //   43: aload_3
    //   44: aload_3
    //   45: arraylength
    //   46: iconst_1
    //   47: isub
    //   48: iaload
    //   49: iconst_1
    //   50: iadd
    //   51: istore #33
    //   53: aload_0
    //   54: iload #33
    //   56: newarray double
    //   58: putfield mTempValue : [D
    //   61: aload_0
    //   62: iload #33
    //   64: newarray double
    //   66: putfield mTempDelta : [D
    //   69: aload_0
    //   70: getfield mTempValue : [D
    //   73: ldc2_w NaN
    //   76: invokestatic fill : ([DD)V
    //   79: iconst_0
    //   80: istore #33
    //   82: iload #33
    //   84: aload_3
    //   85: arraylength
    //   86: if_icmpge -> 126
    //   89: aload_0
    //   90: getfield mTempValue : [D
    //   93: aload_3
    //   94: iload #33
    //   96: iaload
    //   97: aload #4
    //   99: iload #33
    //   101: daload
    //   102: dastore
    //   103: aload_0
    //   104: getfield mTempDelta : [D
    //   107: aload_3
    //   108: iload #33
    //   110: iaload
    //   111: aload #5
    //   113: iload #33
    //   115: daload
    //   116: dastore
    //   117: iload #33
    //   119: iconst_1
    //   120: iadd
    //   121: istore #33
    //   123: goto -> 82
    //   126: ldc NaN
    //   128: fstore #23
    //   130: iconst_0
    //   131: istore #33
    //   133: fconst_0
    //   134: fstore #30
    //   136: fconst_0
    //   137: fstore #29
    //   139: fconst_0
    //   140: fstore #32
    //   142: fconst_0
    //   143: fstore #31
    //   145: aload_0
    //   146: getfield mTempValue : [D
    //   149: astore_3
    //   150: iload #33
    //   152: aload_3
    //   153: arraylength
    //   154: if_icmpge -> 361
    //   157: aload_3
    //   158: iload #33
    //   160: daload
    //   161: invokestatic isNaN : (D)Z
    //   164: istore #34
    //   166: dconst_0
    //   167: dstore #7
    //   169: iload #34
    //   171: ifeq -> 192
    //   174: aload #6
    //   176: ifnull -> 189
    //   179: aload #6
    //   181: iload #33
    //   183: daload
    //   184: dconst_0
    //   185: dcmpl
    //   186: ifne -> 192
    //   189: goto -> 281
    //   192: aload #6
    //   194: ifnull -> 204
    //   197: aload #6
    //   199: iload #33
    //   201: daload
    //   202: dstore #7
    //   204: aload_0
    //   205: getfield mTempValue : [D
    //   208: iload #33
    //   210: daload
    //   211: invokestatic isNaN : (D)Z
    //   214: ifeq -> 220
    //   217: goto -> 232
    //   220: aload_0
    //   221: getfield mTempValue : [D
    //   224: iload #33
    //   226: daload
    //   227: dload #7
    //   229: dadd
    //   230: dstore #7
    //   232: fload #23
    //   234: fstore #22
    //   236: dload #7
    //   238: d2f
    //   239: fstore #21
    //   241: aload_0
    //   242: getfield mTempDelta : [D
    //   245: iload #33
    //   247: daload
    //   248: d2f
    //   249: fstore #24
    //   251: iload #33
    //   253: iconst_1
    //   254: if_icmpeq -> 336
    //   257: iload #33
    //   259: iconst_2
    //   260: if_icmpeq -> 321
    //   263: iload #33
    //   265: iconst_3
    //   266: if_icmpeq -> 306
    //   269: iload #33
    //   271: iconst_4
    //   272: if_icmpeq -> 291
    //   275: iload #33
    //   277: iconst_5
    //   278: if_icmpeq -> 288
    //   281: fload #23
    //   283: fstore #21
    //   285: goto -> 348
    //   288: goto -> 348
    //   291: fload #21
    //   293: fstore #27
    //   295: fload #22
    //   297: fstore #21
    //   299: fload #24
    //   301: fstore #31
    //   303: goto -> 348
    //   306: fload #21
    //   308: fstore #28
    //   310: fload #22
    //   312: fstore #21
    //   314: fload #24
    //   316: fstore #32
    //   318: goto -> 348
    //   321: fload #21
    //   323: fstore #25
    //   325: fload #22
    //   327: fstore #21
    //   329: fload #24
    //   331: fstore #29
    //   333: goto -> 348
    //   336: fload #21
    //   338: fstore #26
    //   340: fload #24
    //   342: fstore #30
    //   344: fload #22
    //   346: fstore #21
    //   348: iload #33
    //   350: iconst_1
    //   351: iadd
    //   352: istore #33
    //   354: fload #21
    //   356: fstore #23
    //   358: goto -> 145
    //   361: aload_0
    //   362: getfield mRelativeToController : Landroidx/constraintlayout/core/motion/Motion;
    //   365: astore_3
    //   366: aload_3
    //   367: ifnull -> 596
    //   370: iconst_2
    //   371: newarray float
    //   373: astore #4
    //   375: iconst_2
    //   376: newarray float
    //   378: astore #6
    //   380: aload_3
    //   381: fload_1
    //   382: f2d
    //   383: aload #4
    //   385: aload #6
    //   387: invokevirtual getCenter : (D[F[F)V
    //   390: aload #4
    //   392: iconst_0
    //   393: faload
    //   394: fstore_1
    //   395: aload #4
    //   397: iconst_1
    //   398: faload
    //   399: fstore #21
    //   401: aload #6
    //   403: iconst_0
    //   404: faload
    //   405: fstore #24
    //   407: aload #6
    //   409: iconst_1
    //   410: faload
    //   411: fstore #22
    //   413: fload_1
    //   414: f2d
    //   415: dstore #11
    //   417: fload #26
    //   419: f2d
    //   420: dstore #7
    //   422: fload #25
    //   424: f2d
    //   425: dstore #9
    //   427: dload #11
    //   429: dload #9
    //   431: invokestatic sin : (D)D
    //   434: dload #7
    //   436: dmul
    //   437: dadd
    //   438: fload #28
    //   440: fconst_2
    //   441: fdiv
    //   442: f2d
    //   443: dsub
    //   444: d2f
    //   445: fstore_1
    //   446: fload #21
    //   448: f2d
    //   449: dload #9
    //   451: invokestatic cos : (D)D
    //   454: dload #7
    //   456: dmul
    //   457: dsub
    //   458: fload #27
    //   460: fconst_2
    //   461: fdiv
    //   462: f2d
    //   463: dsub
    //   464: d2f
    //   465: fstore #21
    //   467: fload #24
    //   469: f2d
    //   470: dstore #11
    //   472: fload #30
    //   474: f2d
    //   475: dstore #13
    //   477: dload #9
    //   479: invokestatic sin : (D)D
    //   482: dstore #15
    //   484: dload #9
    //   486: invokestatic cos : (D)D
    //   489: dstore #17
    //   491: fload #29
    //   493: f2d
    //   494: dstore #19
    //   496: dload #11
    //   498: dload #15
    //   500: dload #13
    //   502: dmul
    //   503: dadd
    //   504: dload #17
    //   506: dload #7
    //   508: dmul
    //   509: dload #19
    //   511: dmul
    //   512: dadd
    //   513: d2f
    //   514: fstore #24
    //   516: fload #22
    //   518: f2d
    //   519: dload #13
    //   521: dload #9
    //   523: invokestatic cos : (D)D
    //   526: dmul
    //   527: dsub
    //   528: dload #7
    //   530: dload #9
    //   532: invokestatic sin : (D)D
    //   535: dmul
    //   536: dload #19
    //   538: dmul
    //   539: dadd
    //   540: d2f
    //   541: fstore #22
    //   543: aload #5
    //   545: arraylength
    //   546: iconst_2
    //   547: if_icmplt -> 564
    //   550: aload #5
    //   552: iconst_0
    //   553: fload #24
    //   555: f2d
    //   556: dastore
    //   557: aload #5
    //   559: iconst_1
    //   560: fload #22
    //   562: f2d
    //   563: dastore
    //   564: fload #23
    //   566: invokestatic isNaN : (F)Z
    //   569: ifne -> 593
    //   572: aload_2
    //   573: fload #23
    //   575: f2d
    //   576: fload #22
    //   578: f2d
    //   579: fload #24
    //   581: f2d
    //   582: invokestatic atan2 : (DD)D
    //   585: invokestatic toDegrees : (D)D
    //   588: dadd
    //   589: d2f
    //   590: invokevirtual setRotationZ : (F)V
    //   593: goto -> 658
    //   596: fload #26
    //   598: fstore_1
    //   599: fload #25
    //   601: fstore #21
    //   603: fload #23
    //   605: invokestatic isNaN : (F)Z
    //   608: ifne -> 658
    //   611: fload #32
    //   613: fconst_2
    //   614: fdiv
    //   615: fstore_1
    //   616: fload #31
    //   618: fconst_2
    //   619: fdiv
    //   620: fstore #21
    //   622: aload_2
    //   623: fconst_0
    //   624: f2d
    //   625: fload #23
    //   627: f2d
    //   628: fload #29
    //   630: fload #21
    //   632: fadd
    //   633: f2d
    //   634: fload #30
    //   636: fload_1
    //   637: fadd
    //   638: f2d
    //   639: invokestatic atan2 : (DD)D
    //   642: invokestatic toDegrees : (D)D
    //   645: dadd
    //   646: dadd
    //   647: d2f
    //   648: invokevirtual setRotationZ : (F)V
    //   651: fload #25
    //   653: fstore #21
    //   655: fload #26
    //   657: fstore_1
    //   658: fload_1
    //   659: ldc_w 0.5
    //   662: fadd
    //   663: fstore_1
    //   664: fload_1
    //   665: f2i
    //   666: istore #33
    //   668: fload #21
    //   670: ldc_w 0.5
    //   673: fadd
    //   674: fstore #21
    //   676: aload_2
    //   677: iload #33
    //   679: fload #21
    //   681: f2i
    //   682: fload_1
    //   683: fload #28
    //   685: fadd
    //   686: f2i
    //   687: fload #21
    //   689: fload #27
    //   691: fadd
    //   692: f2i
    //   693: invokevirtual layout : (IIII)V
    //   696: return
  }
  
  public void setupRelative(Motion paramMotion, MotionPaths paramMotionPaths) {
    double d1 = (this.x + this.width / 2.0F - paramMotionPaths.x - paramMotionPaths.width / 2.0F);
    double d2 = (this.y + this.height / 2.0F - paramMotionPaths.y - paramMotionPaths.height / 2.0F);
    this.mRelativeToController = paramMotion;
    this.x = (float)Math.hypot(d2, d1);
    if (Float.isNaN(this.mRelativeAngle)) {
      this.y = (float)(Math.atan2(d2, d1) + 1.5707963267948966D);
      return;
    } 
    this.y = (float)Math.toRadians(this.mRelativeAngle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\core\motion\MotionPaths.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */