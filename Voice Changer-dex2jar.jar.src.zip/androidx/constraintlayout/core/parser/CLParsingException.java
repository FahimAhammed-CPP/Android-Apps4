package androidx.constraintlayout.core.parser;

public class CLParsingException extends Exception {
  private final String mElementClass;
  
  private final int mLineNumber;
  
  private final String mReason;
  
  public CLParsingException(String paramString, CLElement paramCLElement) {
    this.mReason = paramString;
    if (paramCLElement != null) {
      this.mElementClass = paramCLElement.getStrClass();
      this.mLineNumber = paramCLElement.getLine();
      return;
    } 
    this.mElementClass = "unknown";
    this.mLineNumber = 0;
  }
  
  public String reason() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mReason);
    stringBuilder.append(" (");
    stringBuilder.append(this.mElementClass);
    stringBuilder.append(" at line ");
    stringBuilder.append(this.mLineNumber);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CLParsingException (");
    stringBuilder.append(hashCode());
    stringBuilder.append(") : ");
    stringBuilder.append(reason());
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\core\parser\CLParsingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */