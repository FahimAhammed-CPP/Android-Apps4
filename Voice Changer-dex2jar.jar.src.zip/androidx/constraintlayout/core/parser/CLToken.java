package androidx.constraintlayout.core.parser;

public class CLToken extends CLElement {
  int index = 0;
  
  char[] tokenFalse = "false".toCharArray();
  
  char[] tokenNull = "null".toCharArray();
  
  char[] tokenTrue = "true".toCharArray();
  
  Type type = Type.UNKNOWN;
  
  public CLToken(char[] paramArrayOfchar) {
    super(paramArrayOfchar);
  }
  
  public static CLElement allocate(char[] paramArrayOfchar) {
    return new CLToken(paramArrayOfchar);
  }
  
  public boolean getBoolean() throws CLParsingException {
    if (this.type == Type.TRUE)
      return true; 
    if (this.type == Type.FALSE)
      return false; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("this token is not a boolean: <");
    stringBuilder.append(content());
    stringBuilder.append(">");
    throw new CLParsingException(stringBuilder.toString(), this);
  }
  
  public Type getType() {
    return this.type;
  }
  
  public boolean isNull() throws CLParsingException {
    if (this.type == Type.NULL)
      return true; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("this token is not a null: <");
    stringBuilder.append(content());
    stringBuilder.append(">");
    throw new CLParsingException(stringBuilder.toString(), this);
  }
  
  protected String toFormattedJSON(int paramInt1, int paramInt2) {
    StringBuilder stringBuilder = new StringBuilder();
    addIndent(stringBuilder, paramInt1);
    stringBuilder.append(content());
    return stringBuilder.toString();
  }
  
  protected String toJSON() {
    if (CLParser.DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("<");
      stringBuilder.append(content());
      stringBuilder.append(">");
      return stringBuilder.toString();
    } 
    return content();
  }
  
  public boolean validate(char paramChar, long paramLong) {
    int i = null.$SwitchMap$androidx$constraintlayout$core$parser$CLToken$Type[this.type.ordinal()];
    boolean bool1 = false;
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool2 = false;
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            bool1 = bool4;
          } else {
            char[] arrayOfChar = this.tokenTrue;
            i = this.index;
            if (arrayOfChar[i] == paramChar) {
              this.type = Type.TRUE;
            } else if (this.tokenFalse[i] == paramChar) {
              this.type = Type.FALSE;
            } else {
              bool1 = bool4;
              if (this.tokenNull[i] == paramChar) {
                this.type = Type.NULL;
              } else {
                this.index++;
                return bool1;
              } 
            } 
            bool1 = true;
          } 
        } else {
          char[] arrayOfChar = this.tokenNull;
          i = this.index;
          if (arrayOfChar[i] == paramChar)
            bool2 = true; 
          bool1 = bool2;
          if (bool2) {
            bool1 = bool2;
            if (i + 1 == arrayOfChar.length) {
              setEnd(paramLong);
              bool1 = bool2;
            } 
          } 
        } 
      } else {
        char[] arrayOfChar = this.tokenFalse;
        i = this.index;
        bool2 = bool1;
        if (arrayOfChar[i] == paramChar)
          bool2 = true; 
        bool1 = bool2;
        if (bool2) {
          bool1 = bool2;
          if (i + 1 == arrayOfChar.length) {
            setEnd(paramLong);
            bool1 = bool2;
          } 
        } 
      } 
    } else {
      char[] arrayOfChar = this.tokenTrue;
      i = this.index;
      bool2 = bool3;
      if (arrayOfChar[i] == paramChar)
        bool2 = true; 
      bool1 = bool2;
      if (bool2) {
        bool1 = bool2;
        if (i + 1 == arrayOfChar.length) {
          setEnd(paramLong);
          bool1 = bool2;
        } 
      } 
    } 
    this.index++;
    return bool1;
  }
  
  enum Type {
    FALSE, NULL, TRUE, UNKNOWN;
    
    static {
      Type type1 = new Type("UNKNOWN", 0);
      UNKNOWN = type1;
      Type type2 = new Type("TRUE", 1);
      TRUE = type2;
      Type type3 = new Type("FALSE", 2);
      FALSE = type3;
      Type type4 = new Type("NULL", 3);
      NULL = type4;
      $VALUES = new Type[] { type1, type2, type3, type4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\core\parser\CLToken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */