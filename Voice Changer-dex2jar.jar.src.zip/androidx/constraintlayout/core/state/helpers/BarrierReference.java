package androidx.constraintlayout.core.state.helpers;

import androidx.constraintlayout.core.state.ConstraintReference;
import androidx.constraintlayout.core.state.HelperReference;
import androidx.constraintlayout.core.state.State;
import androidx.constraintlayout.core.widgets.Barrier;
import androidx.constraintlayout.core.widgets.HelperWidget;

public class BarrierReference extends HelperReference {
  private Barrier mBarrierWidget;
  
  private State.Direction mDirection;
  
  private int mMargin;
  
  public BarrierReference(State paramState) {
    super(paramState, State.Helper.BARRIER);
  }
  
  public void apply() {
    getHelperWidget();
    int i = null.$SwitchMap$androidx$constraintlayout$core$state$State$Direction[this.mDirection.ordinal()];
    byte b = 3;
    if (i != 3 && i != 4) {
      if (i != 5) {
        if (i != 6)
          b = 0; 
      } else {
        b = 2;
      } 
    } else {
      b = 1;
    } 
    this.mBarrierWidget.setBarrierType(b);
    this.mBarrierWidget.setMargin(this.mMargin);
  }
  
  public HelperWidget getHelperWidget() {
    if (this.mBarrierWidget == null)
      this.mBarrierWidget = new Barrier(); 
    return (HelperWidget)this.mBarrierWidget;
  }
  
  public ConstraintReference margin(int paramInt) {
    this.mMargin = paramInt;
    return (ConstraintReference)this;
  }
  
  public ConstraintReference margin(Object paramObject) {
    margin(this.mState.convertDimension(paramObject));
    return (ConstraintReference)this;
  }
  
  public void setBarrierDirection(State.Direction paramDirection) {
    this.mDirection = paramDirection;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\core\state\helpers\BarrierReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */