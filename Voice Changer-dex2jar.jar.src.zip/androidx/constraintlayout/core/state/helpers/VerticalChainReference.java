package androidx.constraintlayout.core.state.helpers;

import androidx.constraintlayout.core.state.ConstraintReference;
import androidx.constraintlayout.core.state.State;
import java.util.Iterator;

public class VerticalChainReference extends ChainReference {
  public VerticalChainReference(State paramState) {
    super(paramState, State.Helper.VERTICAL_CHAIN);
  }
  
  public void apply() {
    for (Object object : this.mReferences)
      this.mState.constraints(object).clearVertical(); 
    Iterator<Object> iterator = this.mReferences.iterator();
    ConstraintReference constraintReference1 = null;
    ConstraintReference constraintReference2;
    for (constraintReference2 = null; iterator.hasNext(); constraintReference2 = constraintReference4) {
      ConstraintReference constraintReference3 = (ConstraintReference)iterator.next();
      constraintReference3 = this.mState.constraints(constraintReference3);
      ConstraintReference constraintReference4 = constraintReference2;
      if (constraintReference2 == null) {
        if (this.mTopToTop != null) {
          constraintReference3.topToTop(this.mTopToTop).margin(this.mMarginTop).marginGone(this.mMarginTopGone);
        } else if (this.mTopToBottom != null) {
          constraintReference3.topToBottom(this.mTopToBottom).margin(this.mMarginTop).marginGone(this.mMarginTopGone);
        } else {
          constraintReference3.topToTop(State.PARENT);
        } 
        constraintReference4 = constraintReference3;
      } 
      if (constraintReference1 != null) {
        constraintReference1.bottomToTop(constraintReference3.getKey());
        constraintReference3.topToBottom(constraintReference1.getKey());
      } 
      constraintReference1 = constraintReference3;
    } 
    if (constraintReference1 != null)
      if (this.mBottomToTop != null) {
        constraintReference1.bottomToTop(this.mBottomToTop).margin(this.mMarginBottom).marginGone(this.mMarginBottomGone);
      } else if (this.mBottomToBottom != null) {
        constraintReference1.bottomToBottom(this.mBottomToBottom).margin(this.mMarginBottom).marginGone(this.mMarginBottomGone);
      } else {
        constraintReference1.bottomToBottom(State.PARENT);
      }  
    if (constraintReference2 == null)
      return; 
    if (this.mBias != 0.5F)
      constraintReference2.verticalBias(this.mBias); 
    int i = null.$SwitchMap$androidx$constraintlayout$core$state$State$Chain[this.mStyle.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3)
          return; 
        constraintReference2.setVerticalChainStyle(2);
        return;
      } 
      constraintReference2.setVerticalChainStyle(1);
      return;
    } 
    constraintReference2.setVerticalChainStyle(0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\core\state\helpers\VerticalChainReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */