package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.Metrics;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;
import androidx.constraintlayout.core.widgets.analyzer.DependencyGraph;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidgetContainer extends WidgetContainer {
  private static final boolean DEBUG = false;
  
  static final boolean DEBUG_GRAPH = false;
  
  private static final boolean DEBUG_LAYOUT = false;
  
  private static final int MAX_ITERATIONS = 8;
  
  static int myCounter;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMin = null;
  
  BasicMeasure mBasicMeasureSolver = new BasicMeasure(this);
  
  int mDebugSolverPassCount = 0;
  
  public DependencyGraph mDependencyGraph = new DependencyGraph(this);
  
  public boolean mGroupsWrapOptimized = false;
  
  private boolean mHeightMeasuredTooSmall = false;
  
  ChainHead[] mHorizontalChainsArray = new ChainHead[4];
  
  public int mHorizontalChainsSize = 0;
  
  public boolean mHorizontalWrapOptimized = false;
  
  private boolean mIsRtl = false;
  
  public BasicMeasure.Measure mMeasure = new BasicMeasure.Measure();
  
  protected BasicMeasure.Measurer mMeasurer = null;
  
  public Metrics mMetrics;
  
  private int mOptimizationLevel = 257;
  
  int mPaddingBottom;
  
  int mPaddingLeft;
  
  int mPaddingRight;
  
  int mPaddingTop;
  
  public boolean mSkipSolver = false;
  
  protected LinearSystem mSystem = new LinearSystem();
  
  ChainHead[] mVerticalChainsArray = new ChainHead[4];
  
  public int mVerticalChainsSize = 0;
  
  public boolean mVerticalWrapOptimized = false;
  
  private boolean mWidthMeasuredTooSmall = false;
  
  public int mWrapFixedHeight = 0;
  
  public int mWrapFixedWidth = 0;
  
  private int pass;
  
  private WeakReference<ConstraintAnchor> verticalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> verticalWrapMin = null;
  
  HashSet<ConstraintWidget> widgetsToAdd = new HashSet<ConstraintWidget>();
  
  public ConstraintWidgetContainer() {}
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public ConstraintWidgetContainer(String paramString, int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  private void addHorizontalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mHorizontalChainsSize;
    ChainHead[] arrayOfChainHead = this.mHorizontalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mHorizontalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mHorizontalChainsArray[this.mHorizontalChainsSize] = new ChainHead(paramConstraintWidget, 0, isRtl());
    this.mHorizontalChainsSize++;
  }
  
  private void addMaxWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(paramSolverVariable, solverVariable, 0, 5);
  }
  
  private void addMinWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(solverVariable, paramSolverVariable, 0, 5);
  }
  
  private void addVerticalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mVerticalChainsSize;
    ChainHead[] arrayOfChainHead = this.mVerticalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mVerticalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mVerticalChainsArray[this.mVerticalChainsSize] = new ChainHead(paramConstraintWidget, 1, isRtl());
    this.mVerticalChainsSize++;
  }
  
  public static boolean measure(int paramInt1, ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer, BasicMeasure.Measure paramMeasure, int paramInt2) {
    boolean bool1;
    boolean bool2;
    if (paramMeasurer == null)
      return false; 
    if (paramConstraintWidget.getVisibility() == 8 || paramConstraintWidget instanceof Guideline || paramConstraintWidget instanceof Barrier) {
      paramMeasure.measuredWidth = 0;
      paramMeasure.measuredHeight = 0;
      return false;
    } 
    paramMeasure.horizontalBehavior = paramConstraintWidget.getHorizontalDimensionBehaviour();
    paramMeasure.verticalBehavior = paramConstraintWidget.getVerticalDimensionBehaviour();
    paramMeasure.horizontalDimension = paramConstraintWidget.getWidth();
    paramMeasure.verticalDimension = paramConstraintWidget.getHeight();
    paramMeasure.measuredNeedsSolverPass = false;
    paramMeasure.measureStrategy = paramInt2;
    if (paramMeasure.horizontalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramMeasure.verticalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    if (paramInt1 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramInt2 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int i = paramInt1;
    if (paramInt1 != 0) {
      i = paramInt1;
      if (paramConstraintWidget.hasDanglingDimension(0)) {
        i = paramInt1;
        if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0) {
          i = paramInt1;
          if (!bool2) {
            paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (paramInt2 != 0 && paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
              paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            i = 0;
          } 
        } 
      } 
    } 
    paramInt1 = paramInt2;
    if (paramInt2 != 0) {
      paramInt1 = paramInt2;
      if (paramConstraintWidget.hasDanglingDimension(1)) {
        paramInt1 = paramInt2;
        if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0) {
          paramInt1 = paramInt2;
          if (!bool1) {
            paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (i != 0 && paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
              paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            paramInt1 = 0;
          } 
        } 
      } 
    } 
    if (paramConstraintWidget.isResolvedHorizontally()) {
      paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      i = 0;
    } 
    if (paramConstraintWidget.isResolvedVertically()) {
      paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      paramInt1 = 0;
    } 
    if (bool2)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[0] == 4) {
        paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (paramInt1 == 0) {
        if (paramMeasure.verticalBehavior == ConstraintWidget.DimensionBehaviour.FIXED) {
          paramInt1 = paramMeasure.verticalDimension;
        } else {
          paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredHeight;
        } 
        paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
        paramMeasure.horizontalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
      }  
    if (bool1)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[1] == 4) {
        paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (i == 0) {
        if (paramMeasure.horizontalBehavior == ConstraintWidget.DimensionBehaviour.FIXED) {
          paramInt1 = paramMeasure.horizontalDimension;
        } else {
          paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredWidth;
        } 
        paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
        if (paramConstraintWidget.getDimensionRatioSide() == -1) {
          paramMeasure.verticalDimension = (int)(paramInt1 / paramConstraintWidget.getDimensionRatio());
        } else {
          paramMeasure.verticalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
        } 
      }  
    paramMeasurer.measure(paramConstraintWidget, paramMeasure);
    paramConstraintWidget.setWidth(paramMeasure.measuredWidth);
    paramConstraintWidget.setHeight(paramMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(paramMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(paramMeasure.measuredBaseline);
    paramMeasure.measureStrategy = BasicMeasure.Measure.SELF_DIMENSIONS;
    return paramMeasure.measuredNeedsSolverPass;
  }
  
  private void resetChains() {
    this.mHorizontalChainsSize = 0;
    this.mVerticalChainsSize = 0;
  }
  
  void addChain(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramInt == 0) {
      addHorizontalChain(paramConstraintWidget);
      return;
    } 
    if (paramInt == 1)
      addVerticalChain(paramConstraintWidget); 
  }
  
  public boolean addChildrenToSolver(LinearSystem paramLinearSystem) {
    boolean bool1 = optimizeFor(64);
    addToSolver(paramLinearSystem, bool1);
    int j = this.mChildren.size();
    int i = 0;
    boolean bool = false;
    while (i < j) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.setInBarrier(0, false);
      constraintWidget.setInBarrier(1, false);
      if (constraintWidget instanceof Barrier)
        bool = true; 
      i++;
    } 
    if (bool)
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof Barrier)
          ((Barrier)constraintWidget).markWidgets(); 
      }  
    this.widgetsToAdd.clear();
    for (i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget.addFirst())
        if (constraintWidget instanceof VirtualLayout) {
          this.widgetsToAdd.add(constraintWidget);
        } else {
          constraintWidget.addToSolver(paramLinearSystem, bool1);
        }  
    } 
    while (this.widgetsToAdd.size() > 0) {
      i = this.widgetsToAdd.size();
      for (VirtualLayout virtualLayout : this.widgetsToAdd) {
        if (virtualLayout.contains(this.widgetsToAdd)) {
          virtualLayout.addToSolver(paramLinearSystem, bool1);
          this.widgetsToAdd.remove(virtualLayout);
          break;
        } 
      } 
      if (i == this.widgetsToAdd.size()) {
        Iterator<ConstraintWidget> iterator = this.widgetsToAdd.iterator();
        while (iterator.hasNext())
          ((ConstraintWidget)iterator.next()).addToSolver(paramLinearSystem, bool1); 
        this.widgetsToAdd.clear();
      } 
    } 
    if (LinearSystem.USE_DEPENDENCY_ORDERING) {
      HashSet<ConstraintWidget> hashSet = new HashSet();
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (!constraintWidget.addFirst())
          hashSet.add(constraintWidget); 
      } 
      if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        i = 0;
      } else {
        i = 1;
      } 
      addChildrenToSolverByDependency(this, paramLinearSystem, hashSet, i, false);
      for (ConstraintWidget constraintWidget : hashSet) {
        Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
        constraintWidget.addToSolver(paramLinearSystem, bool1);
      } 
    } else {
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof ConstraintWidgetContainer) {
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = constraintWidget.mListDimensionBehaviors[0];
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = constraintWidget.mListDimensionBehaviors[1];
          if (dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          constraintWidget.addToSolver(paramLinearSystem, bool1);
          if (dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setHorizontalDimensionBehaviour(dimensionBehaviour1); 
          if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setVerticalDimensionBehaviour(dimensionBehaviour2); 
        } else {
          Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
          if (!constraintWidget.addFirst())
            constraintWidget.addToSolver(paramLinearSystem, bool1); 
        } 
      } 
    } 
    if (this.mHorizontalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 0); 
    if (this.mVerticalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 1); 
    return true;
  }
  
  public void addHorizontalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMax.get()).getFinalValue())
      this.horizontalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void addHorizontalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMin.get()).getFinalValue())
      this.horizontalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMax.get()).getFinalValue())
      this.verticalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMin.get()).getFinalValue())
      this.verticalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void defineTerminalWidgets() {
    this.mDependencyGraph.defineTerminalWidgets(getHorizontalDimensionBehaviour(), getVerticalDimensionBehaviour());
  }
  
  public boolean directMeasure(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasure(paramBoolean);
  }
  
  public boolean directMeasureSetup(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasureSetup(paramBoolean);
  }
  
  public boolean directMeasureWithOrientation(boolean paramBoolean, int paramInt) {
    return this.mDependencyGraph.directMeasureWithOrientation(paramBoolean, paramInt);
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mSystem.fillMetrics(paramMetrics);
  }
  
  public ArrayList<Guideline> getHorizontalGuidelines() {
    ArrayList<ConstraintWidget> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        constraintWidget = constraintWidget;
        if (constraintWidget.getOrientation() == 0)
          arrayList.add(constraintWidget); 
      } 
    } 
    return (ArrayList)arrayList;
  }
  
  public BasicMeasure.Measurer getMeasurer() {
    return this.mMeasurer;
  }
  
  public int getOptimizationLevel() {
    return this.mOptimizationLevel;
  }
  
  public void getSceneString(StringBuilder paramStringBuilder) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.stringId);
    stringBuilder.append(":{\n");
    paramStringBuilder.append(stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append("  actualWidth:");
    stringBuilder.append(this.mWidth);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    stringBuilder = new StringBuilder();
    stringBuilder.append("  actualHeight:");
    stringBuilder.append(this.mHeight);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    Iterator<ConstraintWidget> iterator = getChildren().iterator();
    while (iterator.hasNext()) {
      ((ConstraintWidget)iterator.next()).getSceneString(paramStringBuilder);
      paramStringBuilder.append(",\n");
    } 
    paramStringBuilder.append("}");
  }
  
  public LinearSystem getSystem() {
    return this.mSystem;
  }
  
  public String getType() {
    return "ConstraintLayout";
  }
  
  public ArrayList<Guideline> getVerticalGuidelines() {
    ArrayList<ConstraintWidget> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        constraintWidget = constraintWidget;
        if (constraintWidget.getOrientation() == 1)
          arrayList.add(constraintWidget); 
      } 
    } 
    return (ArrayList)arrayList;
  }
  
  public boolean handlesInternalConstraints() {
    return false;
  }
  
  public void invalidateGraph() {
    this.mDependencyGraph.invalidateGraph();
  }
  
  public void invalidateMeasures() {
    this.mDependencyGraph.invalidateMeasures();
  }
  
  public boolean isHeightMeasuredTooSmall() {
    return this.mHeightMeasuredTooSmall;
  }
  
  public boolean isRtl() {
    return this.mIsRtl;
  }
  
  public boolean isWidthMeasuredTooSmall() {
    return this.mWidthMeasuredTooSmall;
  }
  
  public void layout() {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mX : I
    //   5: aload_0
    //   6: iconst_0
    //   7: putfield mY : I
    //   10: aload_0
    //   11: iconst_0
    //   12: putfield mWidthMeasuredTooSmall : Z
    //   15: aload_0
    //   16: iconst_0
    //   17: putfield mHeightMeasuredTooSmall : Z
    //   20: aload_0
    //   21: getfield mChildren : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #9
    //   29: iconst_0
    //   30: aload_0
    //   31: invokevirtual getWidth : ()I
    //   34: invokestatic max : (II)I
    //   37: istore_2
    //   38: iconst_0
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: invokestatic max : (II)I
    //   46: istore_3
    //   47: aload_0
    //   48: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   51: iconst_1
    //   52: aaload
    //   53: astore #14
    //   55: aload_0
    //   56: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   59: iconst_0
    //   60: aaload
    //   61: astore #15
    //   63: aload_0
    //   64: getfield mMetrics : Landroidx/constraintlayout/core/Metrics;
    //   67: astore #16
    //   69: aload #16
    //   71: ifnull -> 86
    //   74: aload #16
    //   76: aload #16
    //   78: getfield layouts : J
    //   81: lconst_1
    //   82: ladd
    //   83: putfield layouts : J
    //   86: aload_0
    //   87: getfield pass : I
    //   90: ifne -> 269
    //   93: aload_0
    //   94: getfield mOptimizationLevel : I
    //   97: iconst_1
    //   98: invokestatic enabled : (II)Z
    //   101: ifeq -> 269
    //   104: aload_0
    //   105: aload_0
    //   106: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   109: invokestatic solvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V
    //   112: iconst_0
    //   113: istore_1
    //   114: iload_1
    //   115: iload #9
    //   117: if_icmpge -> 269
    //   120: aload_0
    //   121: getfield mChildren : Ljava/util/ArrayList;
    //   124: iload_1
    //   125: invokevirtual get : (I)Ljava/lang/Object;
    //   128: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   131: astore #16
    //   133: aload #16
    //   135: invokevirtual isMeasureRequested : ()Z
    //   138: ifeq -> 262
    //   141: aload #16
    //   143: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   146: ifne -> 262
    //   149: aload #16
    //   151: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   154: ifne -> 262
    //   157: aload #16
    //   159: instanceof androidx/constraintlayout/core/widgets/VirtualLayout
    //   162: ifne -> 262
    //   165: aload #16
    //   167: invokevirtual isInVirtualLayout : ()Z
    //   170: ifne -> 262
    //   173: aload #16
    //   175: iconst_0
    //   176: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   179: astore #17
    //   181: aload #16
    //   183: iconst_1
    //   184: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   187: astore #18
    //   189: aload #17
    //   191: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   194: if_acmpne -> 229
    //   197: aload #16
    //   199: getfield mMatchConstraintDefaultWidth : I
    //   202: iconst_1
    //   203: if_icmpeq -> 229
    //   206: aload #18
    //   208: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   211: if_acmpne -> 229
    //   214: aload #16
    //   216: getfield mMatchConstraintDefaultHeight : I
    //   219: iconst_1
    //   220: if_icmpeq -> 229
    //   223: iconst_1
    //   224: istore #4
    //   226: goto -> 232
    //   229: iconst_0
    //   230: istore #4
    //   232: iload #4
    //   234: ifne -> 262
    //   237: new androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure
    //   240: dup
    //   241: invokespecial <init> : ()V
    //   244: astore #17
    //   246: iconst_0
    //   247: aload #16
    //   249: aload_0
    //   250: getfield mMeasurer : Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   253: aload #17
    //   255: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   258: invokestatic measure : (ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   261: pop
    //   262: iload_1
    //   263: iconst_1
    //   264: iadd
    //   265: istore_1
    //   266: goto -> 114
    //   269: iload #9
    //   271: iconst_2
    //   272: if_icmple -> 410
    //   275: aload #15
    //   277: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   280: if_acmpeq -> 291
    //   283: aload #14
    //   285: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   288: if_acmpne -> 410
    //   291: aload_0
    //   292: getfield mOptimizationLevel : I
    //   295: sipush #1024
    //   298: invokestatic enabled : (II)Z
    //   301: ifeq -> 410
    //   304: aload_0
    //   305: aload_0
    //   306: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   309: invokestatic simpleSolvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)Z
    //   312: ifeq -> 410
    //   315: iload_2
    //   316: istore_1
    //   317: aload #15
    //   319: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   322: if_acmpne -> 357
    //   325: iload_2
    //   326: aload_0
    //   327: invokevirtual getWidth : ()I
    //   330: if_icmpge -> 352
    //   333: iload_2
    //   334: ifle -> 352
    //   337: aload_0
    //   338: iload_2
    //   339: invokevirtual setWidth : (I)V
    //   342: aload_0
    //   343: iconst_1
    //   344: putfield mWidthMeasuredTooSmall : Z
    //   347: iload_2
    //   348: istore_1
    //   349: goto -> 357
    //   352: aload_0
    //   353: invokevirtual getWidth : ()I
    //   356: istore_1
    //   357: iload_3
    //   358: istore_2
    //   359: aload #14
    //   361: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   364: if_acmpne -> 399
    //   367: iload_3
    //   368: aload_0
    //   369: invokevirtual getHeight : ()I
    //   372: if_icmpge -> 394
    //   375: iload_3
    //   376: ifle -> 394
    //   379: aload_0
    //   380: iload_3
    //   381: invokevirtual setHeight : (I)V
    //   384: aload_0
    //   385: iconst_1
    //   386: putfield mHeightMeasuredTooSmall : Z
    //   389: iload_3
    //   390: istore_2
    //   391: goto -> 399
    //   394: aload_0
    //   395: invokevirtual getHeight : ()I
    //   398: istore_2
    //   399: iload_1
    //   400: istore #4
    //   402: iconst_1
    //   403: istore_1
    //   404: iload_2
    //   405: istore #5
    //   407: goto -> 418
    //   410: iconst_0
    //   411: istore_1
    //   412: iload_3
    //   413: istore #5
    //   415: iload_2
    //   416: istore #4
    //   418: aload_0
    //   419: bipush #64
    //   421: invokevirtual optimizeFor : (I)Z
    //   424: ifne -> 445
    //   427: aload_0
    //   428: sipush #128
    //   431: invokevirtual optimizeFor : (I)Z
    //   434: ifeq -> 440
    //   437: goto -> 445
    //   440: iconst_0
    //   441: istore_2
    //   442: goto -> 447
    //   445: iconst_1
    //   446: istore_2
    //   447: aload_0
    //   448: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   451: iconst_0
    //   452: putfield graphOptimizer : Z
    //   455: aload_0
    //   456: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   459: iconst_0
    //   460: putfield newgraphOptimizer : Z
    //   463: aload_0
    //   464: getfield mOptimizationLevel : I
    //   467: ifeq -> 482
    //   470: iload_2
    //   471: ifeq -> 482
    //   474: aload_0
    //   475: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   478: iconst_1
    //   479: putfield newgraphOptimizer : Z
    //   482: aload_0
    //   483: getfield mChildren : Ljava/util/ArrayList;
    //   486: astore #16
    //   488: aload_0
    //   489: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   492: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   495: if_acmpeq -> 517
    //   498: aload_0
    //   499: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   502: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   505: if_acmpne -> 511
    //   508: goto -> 517
    //   511: iconst_0
    //   512: istore #6
    //   514: goto -> 520
    //   517: iconst_1
    //   518: istore #6
    //   520: aload_0
    //   521: invokespecial resetChains : ()V
    //   524: iconst_0
    //   525: istore_2
    //   526: iload_2
    //   527: iload #9
    //   529: if_icmpge -> 568
    //   532: aload_0
    //   533: getfield mChildren : Ljava/util/ArrayList;
    //   536: iload_2
    //   537: invokevirtual get : (I)Ljava/lang/Object;
    //   540: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   543: astore #17
    //   545: aload #17
    //   547: instanceof androidx/constraintlayout/core/widgets/WidgetContainer
    //   550: ifeq -> 561
    //   553: aload #17
    //   555: checkcast androidx/constraintlayout/core/widgets/WidgetContainer
    //   558: invokevirtual layout : ()V
    //   561: iload_2
    //   562: iconst_1
    //   563: iadd
    //   564: istore_2
    //   565: goto -> 526
    //   568: aload_0
    //   569: bipush #64
    //   571: invokevirtual optimizeFor : (I)Z
    //   574: istore #13
    //   576: iconst_0
    //   577: istore_2
    //   578: iconst_1
    //   579: istore #11
    //   581: iload #11
    //   583: ifeq -> 1544
    //   586: iload_2
    //   587: iconst_1
    //   588: iadd
    //   589: istore #8
    //   591: iload #11
    //   593: istore #10
    //   595: aload_0
    //   596: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   599: invokevirtual reset : ()V
    //   602: iload #11
    //   604: istore #10
    //   606: aload_0
    //   607: invokespecial resetChains : ()V
    //   610: iload #11
    //   612: istore #10
    //   614: aload_0
    //   615: aload_0
    //   616: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   619: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   622: iconst_0
    //   623: istore_2
    //   624: iload_2
    //   625: iload #9
    //   627: if_icmpge -> 659
    //   630: iload #11
    //   632: istore #10
    //   634: aload_0
    //   635: getfield mChildren : Ljava/util/ArrayList;
    //   638: iload_2
    //   639: invokevirtual get : (I)Ljava/lang/Object;
    //   642: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   645: aload_0
    //   646: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   649: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   652: iload_2
    //   653: iconst_1
    //   654: iadd
    //   655: istore_2
    //   656: goto -> 624
    //   659: iload #11
    //   661: istore #10
    //   663: aload_0
    //   664: aload_0
    //   665: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   668: invokevirtual addChildrenToSolver : (Landroidx/constraintlayout/core/LinearSystem;)Z
    //   671: istore #11
    //   673: iload #11
    //   675: istore #10
    //   677: aload_0
    //   678: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   681: astore #17
    //   683: aload #17
    //   685: ifnull -> 738
    //   688: iload #11
    //   690: istore #10
    //   692: aload #17
    //   694: invokevirtual get : ()Ljava/lang/Object;
    //   697: ifnull -> 738
    //   700: iload #11
    //   702: istore #10
    //   704: aload_0
    //   705: aload_0
    //   706: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   709: invokevirtual get : ()Ljava/lang/Object;
    //   712: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   715: aload_0
    //   716: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   719: aload_0
    //   720: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   723: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   726: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   729: iload #11
    //   731: istore #10
    //   733: aload_0
    //   734: aconst_null
    //   735: putfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   738: iload #11
    //   740: istore #10
    //   742: aload_0
    //   743: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   746: astore #17
    //   748: aload #17
    //   750: ifnull -> 803
    //   753: iload #11
    //   755: istore #10
    //   757: aload #17
    //   759: invokevirtual get : ()Ljava/lang/Object;
    //   762: ifnull -> 803
    //   765: iload #11
    //   767: istore #10
    //   769: aload_0
    //   770: aload_0
    //   771: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   774: invokevirtual get : ()Ljava/lang/Object;
    //   777: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   780: aload_0
    //   781: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   784: aload_0
    //   785: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   788: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   791: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   794: iload #11
    //   796: istore #10
    //   798: aload_0
    //   799: aconst_null
    //   800: putfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   803: iload #11
    //   805: istore #10
    //   807: aload_0
    //   808: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   811: astore #17
    //   813: aload #17
    //   815: ifnull -> 868
    //   818: iload #11
    //   820: istore #10
    //   822: aload #17
    //   824: invokevirtual get : ()Ljava/lang/Object;
    //   827: ifnull -> 868
    //   830: iload #11
    //   832: istore #10
    //   834: aload_0
    //   835: aload_0
    //   836: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   839: invokevirtual get : ()Ljava/lang/Object;
    //   842: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   845: aload_0
    //   846: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   849: aload_0
    //   850: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   853: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   856: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   859: iload #11
    //   861: istore #10
    //   863: aload_0
    //   864: aconst_null
    //   865: putfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   868: iload #11
    //   870: istore #10
    //   872: aload_0
    //   873: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   876: astore #17
    //   878: aload #17
    //   880: ifnull -> 933
    //   883: iload #11
    //   885: istore #10
    //   887: aload #17
    //   889: invokevirtual get : ()Ljava/lang/Object;
    //   892: ifnull -> 933
    //   895: iload #11
    //   897: istore #10
    //   899: aload_0
    //   900: aload_0
    //   901: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   904: invokevirtual get : ()Ljava/lang/Object;
    //   907: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   910: aload_0
    //   911: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   914: aload_0
    //   915: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   918: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   921: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   924: iload #11
    //   926: istore #10
    //   928: aload_0
    //   929: aconst_null
    //   930: putfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   933: iload #11
    //   935: istore #10
    //   937: iload #11
    //   939: ifeq -> 1008
    //   942: iload #11
    //   944: istore #10
    //   946: aload_0
    //   947: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   950: invokevirtual minimize : ()V
    //   953: iload #11
    //   955: istore #10
    //   957: goto -> 1008
    //   960: astore #17
    //   962: aload #17
    //   964: invokevirtual printStackTrace : ()V
    //   967: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   970: astore #18
    //   972: new java/lang/StringBuilder
    //   975: dup
    //   976: invokespecial <init> : ()V
    //   979: astore #19
    //   981: aload #19
    //   983: ldc_w 'EXCEPTION : '
    //   986: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   989: pop
    //   990: aload #19
    //   992: aload #17
    //   994: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   997: pop
    //   998: aload #18
    //   1000: aload #19
    //   1002: invokevirtual toString : ()Ljava/lang/String;
    //   1005: invokevirtual println : (Ljava/lang/String;)V
    //   1008: iload #10
    //   1010: ifeq -> 1029
    //   1013: aload_0
    //   1014: aload_0
    //   1015: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1018: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1021: invokevirtual updateChildrenFromSolver : (Landroidx/constraintlayout/core/LinearSystem;[Z)Z
    //   1024: istore #10
    //   1026: goto -> 1077
    //   1029: aload_0
    //   1030: aload_0
    //   1031: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1034: iload #13
    //   1036: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1039: iconst_0
    //   1040: istore_2
    //   1041: iload_2
    //   1042: iload #9
    //   1044: if_icmpge -> 1074
    //   1047: aload_0
    //   1048: getfield mChildren : Ljava/util/ArrayList;
    //   1051: iload_2
    //   1052: invokevirtual get : (I)Ljava/lang/Object;
    //   1055: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1058: aload_0
    //   1059: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1062: iload #13
    //   1064: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1067: iload_2
    //   1068: iconst_1
    //   1069: iadd
    //   1070: istore_2
    //   1071: goto -> 1041
    //   1074: iconst_0
    //   1075: istore #10
    //   1077: iload #6
    //   1079: ifeq -> 1283
    //   1082: iload #8
    //   1084: bipush #8
    //   1086: if_icmpge -> 1283
    //   1089: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1092: iconst_2
    //   1093: baload
    //   1094: ifeq -> 1283
    //   1097: iconst_0
    //   1098: istore_3
    //   1099: iconst_0
    //   1100: istore_2
    //   1101: iconst_0
    //   1102: istore #7
    //   1104: iload_3
    //   1105: iload #9
    //   1107: if_icmpge -> 1164
    //   1110: aload_0
    //   1111: getfield mChildren : Ljava/util/ArrayList;
    //   1114: iload_3
    //   1115: invokevirtual get : (I)Ljava/lang/Object;
    //   1118: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1121: astore #17
    //   1123: iload #7
    //   1125: aload #17
    //   1127: getfield mX : I
    //   1130: aload #17
    //   1132: invokevirtual getWidth : ()I
    //   1135: iadd
    //   1136: invokestatic max : (II)I
    //   1139: istore #7
    //   1141: iload_2
    //   1142: aload #17
    //   1144: getfield mY : I
    //   1147: aload #17
    //   1149: invokevirtual getHeight : ()I
    //   1152: iadd
    //   1153: invokestatic max : (II)I
    //   1156: istore_2
    //   1157: iload_3
    //   1158: iconst_1
    //   1159: iadd
    //   1160: istore_3
    //   1161: goto -> 1104
    //   1164: aload_0
    //   1165: getfield mMinWidth : I
    //   1168: iload #7
    //   1170: invokestatic max : (II)I
    //   1173: istore #7
    //   1175: aload_0
    //   1176: getfield mMinHeight : I
    //   1179: iload_2
    //   1180: invokestatic max : (II)I
    //   1183: istore_3
    //   1184: iload_1
    //   1185: istore_2
    //   1186: iload #10
    //   1188: istore #11
    //   1190: aload #15
    //   1192: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1195: if_acmpne -> 1233
    //   1198: iload_1
    //   1199: istore_2
    //   1200: iload #10
    //   1202: istore #11
    //   1204: aload_0
    //   1205: invokevirtual getWidth : ()I
    //   1208: iload #7
    //   1210: if_icmpge -> 1233
    //   1213: aload_0
    //   1214: iload #7
    //   1216: invokevirtual setWidth : (I)V
    //   1219: aload_0
    //   1220: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1223: iconst_0
    //   1224: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1227: aastore
    //   1228: iconst_1
    //   1229: istore_2
    //   1230: iconst_1
    //   1231: istore #11
    //   1233: iload_2
    //   1234: istore_1
    //   1235: iload #11
    //   1237: istore #10
    //   1239: aload #14
    //   1241: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1244: if_acmpne -> 1283
    //   1247: iload_2
    //   1248: istore_1
    //   1249: iload #11
    //   1251: istore #10
    //   1253: aload_0
    //   1254: invokevirtual getHeight : ()I
    //   1257: iload_3
    //   1258: if_icmpge -> 1283
    //   1261: aload_0
    //   1262: iload_3
    //   1263: invokevirtual setHeight : (I)V
    //   1266: aload_0
    //   1267: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1270: iconst_1
    //   1271: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1274: aastore
    //   1275: iconst_1
    //   1276: istore_1
    //   1277: iconst_1
    //   1278: istore #10
    //   1280: goto -> 1283
    //   1283: aload_0
    //   1284: getfield mMinWidth : I
    //   1287: aload_0
    //   1288: invokevirtual getWidth : ()I
    //   1291: invokestatic max : (II)I
    //   1294: istore_2
    //   1295: iload_2
    //   1296: aload_0
    //   1297: invokevirtual getWidth : ()I
    //   1300: if_icmple -> 1322
    //   1303: aload_0
    //   1304: iload_2
    //   1305: invokevirtual setWidth : (I)V
    //   1308: aload_0
    //   1309: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1312: iconst_0
    //   1313: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1316: aastore
    //   1317: iconst_1
    //   1318: istore_1
    //   1319: iconst_1
    //   1320: istore #10
    //   1322: aload_0
    //   1323: getfield mMinHeight : I
    //   1326: aload_0
    //   1327: invokevirtual getHeight : ()I
    //   1330: invokestatic max : (II)I
    //   1333: istore_2
    //   1334: iload_2
    //   1335: aload_0
    //   1336: invokevirtual getHeight : ()I
    //   1339: if_icmple -> 1364
    //   1342: aload_0
    //   1343: iload_2
    //   1344: invokevirtual setHeight : (I)V
    //   1347: aload_0
    //   1348: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1351: iconst_1
    //   1352: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1355: aastore
    //   1356: iconst_1
    //   1357: istore_1
    //   1358: iconst_1
    //   1359: istore #10
    //   1361: goto -> 1364
    //   1364: iload_1
    //   1365: istore_3
    //   1366: iload #10
    //   1368: istore #12
    //   1370: iload_1
    //   1371: ifne -> 1515
    //   1374: iload_1
    //   1375: istore_2
    //   1376: iload #10
    //   1378: istore #11
    //   1380: aload_0
    //   1381: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1384: iconst_0
    //   1385: aaload
    //   1386: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1389: if_acmpne -> 1443
    //   1392: iload_1
    //   1393: istore_2
    //   1394: iload #10
    //   1396: istore #11
    //   1398: iload #4
    //   1400: ifle -> 1443
    //   1403: iload_1
    //   1404: istore_2
    //   1405: iload #10
    //   1407: istore #11
    //   1409: aload_0
    //   1410: invokevirtual getWidth : ()I
    //   1413: iload #4
    //   1415: if_icmple -> 1443
    //   1418: aload_0
    //   1419: iconst_1
    //   1420: putfield mWidthMeasuredTooSmall : Z
    //   1423: aload_0
    //   1424: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1427: iconst_0
    //   1428: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1431: aastore
    //   1432: aload_0
    //   1433: iload #4
    //   1435: invokevirtual setWidth : (I)V
    //   1438: iconst_1
    //   1439: istore_2
    //   1440: iconst_1
    //   1441: istore #11
    //   1443: iload_2
    //   1444: istore_3
    //   1445: iload #11
    //   1447: istore #12
    //   1449: aload_0
    //   1450: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1453: iconst_1
    //   1454: aaload
    //   1455: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1458: if_acmpne -> 1515
    //   1461: iload_2
    //   1462: istore_3
    //   1463: iload #11
    //   1465: istore #12
    //   1467: iload #5
    //   1469: ifle -> 1515
    //   1472: iload_2
    //   1473: istore_3
    //   1474: iload #11
    //   1476: istore #12
    //   1478: aload_0
    //   1479: invokevirtual getHeight : ()I
    //   1482: iload #5
    //   1484: if_icmple -> 1515
    //   1487: aload_0
    //   1488: iconst_1
    //   1489: putfield mHeightMeasuredTooSmall : Z
    //   1492: aload_0
    //   1493: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1496: iconst_1
    //   1497: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1500: aastore
    //   1501: aload_0
    //   1502: iload #5
    //   1504: invokevirtual setHeight : (I)V
    //   1507: iconst_1
    //   1508: istore #10
    //   1510: iconst_1
    //   1511: istore_1
    //   1512: goto -> 1521
    //   1515: iload #12
    //   1517: istore #10
    //   1519: iload_3
    //   1520: istore_1
    //   1521: iload #8
    //   1523: bipush #8
    //   1525: if_icmple -> 1534
    //   1528: iconst_0
    //   1529: istore #11
    //   1531: goto -> 1538
    //   1534: iload #10
    //   1536: istore #11
    //   1538: iload #8
    //   1540: istore_2
    //   1541: goto -> 581
    //   1544: aload #16
    //   1546: checkcast java/util/ArrayList
    //   1549: astore #17
    //   1551: aload_0
    //   1552: aload #16
    //   1554: putfield mChildren : Ljava/util/ArrayList;
    //   1557: iload_1
    //   1558: ifeq -> 1577
    //   1561: aload_0
    //   1562: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1565: iconst_0
    //   1566: aload #15
    //   1568: aastore
    //   1569: aload_0
    //   1570: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1573: iconst_1
    //   1574: aload #14
    //   1576: aastore
    //   1577: aload_0
    //   1578: aload_0
    //   1579: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1582: invokevirtual getCache : ()Landroidx/constraintlayout/core/Cache;
    //   1585: invokevirtual resetSolverVariables : (Landroidx/constraintlayout/core/Cache;)V
    //   1588: return
    // Exception table:
    //   from	to	target	type
    //   595	602	960	java/lang/Exception
    //   606	610	960	java/lang/Exception
    //   614	622	960	java/lang/Exception
    //   634	652	960	java/lang/Exception
    //   663	673	960	java/lang/Exception
    //   677	683	960	java/lang/Exception
    //   692	700	960	java/lang/Exception
    //   704	729	960	java/lang/Exception
    //   733	738	960	java/lang/Exception
    //   742	748	960	java/lang/Exception
    //   757	765	960	java/lang/Exception
    //   769	794	960	java/lang/Exception
    //   798	803	960	java/lang/Exception
    //   807	813	960	java/lang/Exception
    //   822	830	960	java/lang/Exception
    //   834	859	960	java/lang/Exception
    //   863	868	960	java/lang/Exception
    //   872	878	960	java/lang/Exception
    //   887	895	960	java/lang/Exception
    //   899	924	960	java/lang/Exception
    //   928	933	960	java/lang/Exception
    //   946	953	960	java/lang/Exception
  }
  
  public long measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    this.mPaddingLeft = paramInt8;
    this.mPaddingTop = paramInt9;
    return this.mBasicMeasureSolver.solverMeasure(this, paramInt1, paramInt8, paramInt9, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
  }
  
  public boolean optimizeFor(int paramInt) {
    return ((this.mOptimizationLevel & paramInt) == paramInt);
  }
  
  public void reset() {
    this.mSystem.reset();
    this.mPaddingLeft = 0;
    this.mPaddingRight = 0;
    this.mPaddingTop = 0;
    this.mPaddingBottom = 0;
    this.mSkipSolver = false;
    super.reset();
  }
  
  public void setMeasurer(BasicMeasure.Measurer paramMeasurer) {
    this.mMeasurer = paramMeasurer;
    this.mDependencyGraph.setMeasurer(paramMeasurer);
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    LinearSystem.USE_DEPENDENCY_ORDERING = optimizeFor(512);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mPaddingLeft = paramInt1;
    this.mPaddingTop = paramInt2;
    this.mPaddingRight = paramInt3;
    this.mPaddingBottom = paramInt4;
  }
  
  public void setPass(int paramInt) {
    this.pass = paramInt;
  }
  
  public void setRtl(boolean paramBoolean) {
    this.mIsRtl = paramBoolean;
  }
  
  public boolean updateChildrenFromSolver(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    int i = 0;
    paramArrayOfboolean[2] = false;
    boolean bool1 = optimizeFor(64);
    updateFromSolver(paramLinearSystem, bool1);
    int j = this.mChildren.size();
    boolean bool = false;
    while (i < j) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.updateFromSolver(paramLinearSystem, bool1);
      if (constraintWidget.hasDimensionOverride())
        bool = true; 
      i++;
    } 
    return bool;
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    super.updateFromRuns(paramBoolean1, paramBoolean2);
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++)
      ((ConstraintWidget)this.mChildren.get(i)).updateFromRuns(paramBoolean1, paramBoolean2); 
  }
  
  public void updateHierarchy() {
    this.mBasicMeasureSolver.updateHierarchy(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintWidgetContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */