package androidx.constraintlayout.core.widgets;

public interface Helper {
  void add(ConstraintWidget paramConstraintWidget);
  
  void removeAllIds();
  
  void updateConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer);
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\core\widgets\Helper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */